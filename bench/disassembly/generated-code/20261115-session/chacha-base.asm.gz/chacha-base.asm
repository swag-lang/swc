
/workspace/prompt2-20261115/session-combined-micro/base/chacha/chacha:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <clock_gettime@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <clock_gettime@GLIBC_2.17>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <madvise@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf92]        # 413088 <madvise@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <pthread_key_delete@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf8a]        # 413090 <pthread_key_delete@GLIBC_2.34>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <gettid@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf82]        # 413098 <gettid@GLIBC_2.30>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <flock@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf7a]        # 4130a0 <flock@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <__errno_location@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf72]        # 4130a8 <__errno_location@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <opendir@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf6a]        # 4130b0 <opendir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <dirfd@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf62]        # 4130b8 <dirfd@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readdir@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <readdir@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <readlinkat@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <readlinkat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <openat@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <openat@GLIBC_2.4>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <closedir@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <closedir@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <memfd_create@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <memfd_create@GLIBC_2.27>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <ftruncate@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <ftruncate@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <write@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <write@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <backtrace@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <backtrace@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_3464c816_000176_2744b483+0xf60>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40caa0 <__swc_fn_3464c816_000121_12b4ed22>
  40724e:	xor    ecx,ecx
  407250:	call   40c1c0 <__swc_fn_3464c816_000094_14db3cf9>
  407255:	call   40d680 <__swc_fn_3464c816_000175_7f24d040>
  40725a:	call   40f670 <__swc_fn_3464c816_000095_337e587a>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_3464c816_000000_46f18a51>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_3464c816_000003_7ab4792e>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_3464c816_000003_7ab4792e+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409260 <__swc_fn_3464c816_000111_b25e3a45>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_3464c816_000003_7ab4792e+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_3464c816+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_3464c816+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_3464c816_000003_7ab4792e+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_3464c816_000003_7ab4792e+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_3464c816+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_3464c816+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_3464c816_000003_7ab4792e+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_3464c816_000003_7ab4792e+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_3464c816_000006_a23dca5f>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40df20 <__swc_fn_3464c816_000011_6493fbbc>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_3464c816_000012_c7df5d22>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_3464c816_000006_a23dca5f+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_3464c816_000003_7ab4792e>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_3464c816_000006_a23dca5f+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_3464c816_000009_d7e2bb25>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_3464c816_000009_d7e2bb25+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40a550 <__swc_fn_3464c816_000007_614a4804>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40df10 <__swc_fn_3464c816_000008_4e857afc>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_3464c816_000009_d7e2bb25+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_3464c816_000009_d7e2bb25+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_3464c816_000012_c7df5d22>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_3464c816_000015_07eb9884>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_3464c816_000015_07eb9884+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_3464c816_000015_07eb9884+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_3464c816_000015_07eb9884+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_3464c816_000015_07eb9884+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40e080 <__swc_fn_3464c816_000017_4df2d1a0>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_3464c816_000015_07eb9884+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_3464c816+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_3464c816+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_3464c816_000015_07eb9884+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_3464c816_000015_07eb9884+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40df20 <__swc_fn_3464c816_000011_6493fbbc>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_3464c816_000015_07eb9884+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40c7c0 <__swc_fn_3464c816_000112_759e9ceb>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_3464c816+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_3464c816+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_3464c816_000015_07eb9884+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_3464c816_000015_07eb9884+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_3464c816+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_3464c816+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_3464c816_000015_07eb9884+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_3464c816_000015_07eb9884+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_3464c816_000018_7d1e8a10>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_3464c816_000015_07eb9884+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_3464c816_000018_7d1e8a10>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_3464c816_000018_7d1e8a10+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_3464c816_000018_7d1e8a10+0x10>

0000000000407630 <__swc_fn_3464c816_000021_491ac000>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_3464c816_000015_07eb9884>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_3464c816+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098c0 <__swc_fn_3464c816_000135_e3032dc2>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_3464c816+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_3464c816+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_3464c816_000024_4aca8b9e>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_3464c816_000027_4aca8b9e>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_3464c816_000030_06a93956>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_3464c816_000030_06a93956+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_3464c816>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_3464c816_000030_06a93956+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_3464c816_000030_06a93956+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_3464c816_000030_06a93956+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40e240 <__swc_fn_3464c816_000032_84881cd8>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_3464c816_000030_06a93956+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_3464c816_000036_8d895ba1>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_3464c816_000030_06a93956+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_3464c816_000042_bab03645>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_3464c816_000033_7ca1566d>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40aa00 <__swc_fn_3464c816_000031_90860ff2>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409740 <__swc_fn_3464c816_000129_74b163fe>
  407734:	mov    rcx,rsi
  407737:	call   40e240 <__swc_fn_3464c816_000032_84881cd8>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_3464c816_000036_8d895ba1>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_3464c816_000039_40d1e569>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_3464c816_000039_40d1e569+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_3464c816_000039_40d1e569+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_3464c816_000039_40d1e569+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_3464c816_000039_40d1e569+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_3464c816_000039_40d1e569+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409340 <__swc_fn_3464c816_000114_27d95464>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_3464c816+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_3464c816+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_3464c816_000039_40d1e569+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_3464c816_000039_40d1e569+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_3464c816+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_3464c816+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_3464c816_000039_40d1e569+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_3464c816_000039_40d1e569+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_3464c816_000042_bab03645>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_3464c816_000042_bab03645+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e810 <__swc_fn_3464c816_000059_3ca3ac64>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098c0 <__swc_fn_3464c816_000135_e3032dc2>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_3464c816_000042_bab03645+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_3464c816_000042_bab03645+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_3464c816_000009_d7e2bb25>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_3464c816_000042_bab03645+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40df40 <__swc_fn_3464c816_000014_afb279e2>
  40791e:	jmp    407941 <__swc_fn_3464c816_000042_bab03645+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_3464c816_000042_bab03645+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_3464c816_000042_bab03645+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_3464c816_000042_bab03645+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40abc0 <__swc_fn_3464c816_000043_957e4917>
  407997:	mov    rcx,rdi
  40799a:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_3464c816_000039_40d1e569>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_3464c816_000045_1fe0f4e2>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_3464c816_000045_1fe0f4e2+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_3464c816_000045_1fe0f4e2+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_3464c816_000045_1fe0f4e2+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_3464c816_000045_1fe0f4e2+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098c0 <__swc_fn_3464c816_000135_e3032dc2>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_3464c816_000045_1fe0f4e2+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_3464c816_000045_1fe0f4e2+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_3464c816_000045_1fe0f4e2+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_3464c816_000045_1fe0f4e2+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_3464c816_000009_d7e2bb25>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_3464c816_000045_1fe0f4e2+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_3464c816_000045_1fe0f4e2+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_3464c816_000045_1fe0f4e2+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_3464c816_000045_1fe0f4e2+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_3464c816_000045_1fe0f4e2+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40a600 <__swc_fn_3464c816_000013_9ba72deb>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_3464c816_000045_1fe0f4e2+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_3464c816_000045_1fe0f4e2+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_3464c816_000045_1fe0f4e2+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_3464c816_000045_1fe0f4e2+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40e0c0 <__swc_fn_3464c816_000020_a66e8b97>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_3464c816_000045_1fe0f4e2+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40a600 <__swc_fn_3464c816_000013_9ba72deb>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_3464c816_000045_1fe0f4e2+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_3464c816_000021_491ac000>
  407c07:	mov    rcx,r14
  407c0a:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_3464c816_000045_1fe0f4e2+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_3464c816_000045_1fe0f4e2+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_3464c816_000045_1fe0f4e2+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_3464c816_000048_c877e9d2>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_3464c816_000048_c877e9d2+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_3464c816_000048_c877e9d2+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_3464c816_000048_c877e9d2+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_3464c816_000048_c877e9d2+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40e470 <__swc_fn_3464c816_000047_bc5ec610>
  407d14:	jmp    407ce0 <__swc_fn_3464c816_000048_c877e9d2+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_3464c816_000048_c877e9d2+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_3464c816_000048_c877e9d2+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_3464c816_000048_c877e9d2+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_3464c816_000048_c877e9d2+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_3464c816_000048_c877e9d2+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_3464c816_000048_c877e9d2+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_3464c816_000048_c877e9d2+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_3464c816_000051_f7021588>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_3464c816_000051_f7021588+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_3464c816_000051_f7021588+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_3464c816_000051_f7021588+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_3464c816_000051_f7021588+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40e3d0 <__swc_fn_3464c816_000044_9c2ade9b>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40df40 <__swc_fn_3464c816_000014_afb279e2>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_3464c816_000054_ae20ea33>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098c0 <__swc_fn_3464c816_000135_e3032dc2>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_3464c816_000054_ae20ea33+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_3464c816_000054_ae20ea33+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_3464c816_000054_ae20ea33+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_3464c816_000057_5b81d8b6>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_3464c816_000060_e6407a0a>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_3464c816_000060_e6407a0a+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_3464c816_000039_40d1e569>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_3464c816_000060_e6407a0a+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_3464c816_000063_c8a062d6>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40af40 <__swc_fn_3464c816_000052_c7484fb0>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_3464c816_000054_ae20ea33>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_3464c816_000063_c8a062d6+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_3464c816_000063_c8a062d6+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40b060 <__swc_fn_3464c816_000058_8bd8d1d5>
  407f7f:	mov    rcx,rsi
  407f82:	call   40aca0 <__swc_fn_3464c816_000049_2ff013cc>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_3464c816_000066_254b71af>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_3464c816_000066_254b71af+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_3464c816+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_3464c816+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_3464c816_000066_254b71af+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_3464c816_000066_254b71af+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40a930 <__swc_fn_3464c816_000022_3a2e2048>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_3464c816_000066_254b71af+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_3464c816_000063_c8a062d6>
  40808f:	jmp    408122 <__swc_fn_3464c816_000066_254b71af+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_3464c816>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_3464c816_000066_254b71af+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_3464c816_000066_254b71af+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_3464c816_000066_254b71af+0x135>
  4080b8:	call   40aa00 <__swc_fn_3464c816_000031_90860ff2>
  4080bd:	mov    rcx,rax
  4080c0:	call   410440 <__swc_fn_3464c816_000128_41c3251c>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_3464c816_000066_254b71af+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_3464c816_000066_254b71af+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_3464c816_000066_254b71af+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40e470 <__swc_fn_3464c816_000047_bc5ec610>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_3464c816_000066_254b71af+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_3464c816_000051_f7021588>
  408115:	jmp    408122 <__swc_fn_3464c816_000066_254b71af+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40a570 <__swc_fn_3464c816_000010_395bb04b>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_3464c816_000069_e681a956>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_3464c816_000036_8d895ba1>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_3464c816_000069_e681a956+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_3464c816+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_3464c816_000069_e681a956+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098c0 <__swc_fn_3464c816_000135_e3032dc2>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40ec40 <__swc_fn_3464c816_000068_7d4c42bf>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_3464c816_000072_bfa08900>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40e990 <__swc_fn_3464c816_000065_f9f4b610>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_3464c816_000075_524b0734>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40ec40 <__swc_fn_3464c816_000068_7d4c42bf>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_3464c816_000078_a120bd2b>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_3464c816_000078_a120bd2b+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_3464c816_000078_a120bd2b+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_3464c816_000081_c25a0e73>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_3464c816_000084_ddf2b8a1>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_3464c816_000090_a2d50c23>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_3464c816_000084_ddf2b8a1+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_3464c816_000084_ddf2b8a1+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_3464c816_000084_ddf2b8a1+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_3464c816_000084_ddf2b8a1+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_3464c816_000090_a2d50c23>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_3464c816_000084_ddf2b8a1+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_3464c816_000084_ddf2b8a1+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_3464c816_000084_ddf2b8a1+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_3464c816_000084_ddf2b8a1+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_3464c816_000084_ddf2b8a1+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_3464c816_000084_ddf2b8a1+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_3464c816_000084_ddf2b8a1+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_3464c816_000084_ddf2b8a1+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_3464c816_000084_ddf2b8a1+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_3464c816_000084_ddf2b8a1+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40c040 <__swc_fn_3464c816_000082_754dcd57>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_3464c816_000084_ddf2b8a1+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_3464c816_000084_ddf2b8a1+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_3464c816_000084_ddf2b8a1+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40c040 <__swc_fn_3464c816_000082_754dcd57>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_3464c816_000084_ddf2b8a1+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_3464c816_000084_ddf2b8a1>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_3464c816_000084_ddf2b8a1+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_3464c816_000084_ddf2b8a1+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_3464c816_000087_ea575bb3>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_3464c816_000090_a2d50c23>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_3464c816_000087_ea575bb3+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40f0a0 <__swc_fn_3464c816_000086_c45095aa>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_3464c816_000087_ea575bb3+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_3464c816_000087_ea575bb3+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_3464c816_000087_ea575bb3+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40c040 <__swc_fn_3464c816_000082_754dcd57>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_3464c816_000087_ea575bb3+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_3464c816_000087_ea575bb3>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_3464c816_000087_ea575bb3+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_3464c816_000087_ea575bb3+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_3464c816_000090_a2d50c23>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_3464c816_000090_a2d50c23+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_3464c816_000090_a2d50c23+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_3464c816_000090_a2d50c23+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_3464c816_000090_a2d50c23+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40c040 <__swc_fn_3464c816_000082_754dcd57>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40c040 <__swc_fn_3464c816_000082_754dcd57>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_3464c816_000090_a2d50c23+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_3464c816_000090_a2d50c23+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_3464c816_000090_a2d50c23+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_3464c816_000090_a2d50c23+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_3464c816_000090_a2d50c23>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_3464c816_000090_a2d50c23+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_3464c816_000090_a2d50c23+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_3464c816_000090_a2d50c23+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_3464c816_000090_a2d50c23+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_3464c816_000090_a2d50c23+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_3464c816_000090_a2d50c23+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_3464c816_000090_a2d50c23+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_3464c816_000090_a2d50c23+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_3464c816_000090_a2d50c23+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_3464c816_000090_a2d50c23+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_3464c816_000090_a2d50c23+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_3464c816_000090_a2d50c23+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_3464c816_000090_a2d50c23+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_3464c816_000090_a2d50c23+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_3464c816_000090_a2d50c23+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_3464c816_000090_a2d50c23+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409de0 <__swc_fn_3464c816_000147_32a497f3>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_3464c816_000090_a2d50c23+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_3464c816_000090_a2d50c23>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_3464c816_000090_a2d50c23+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_3464c816_000090_a2d50c23+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_3464c816_000090_a2d50c23+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409de0 <__swc_fn_3464c816_000147_32a497f3>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409de0 <__swc_fn_3464c816_000147_32a497f3>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_3464c816_000093_f8c16535>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c170 <__swc_fn_3464c816_000091_3d2f5a0d>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_3464c816_000093_f8c16535+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_3464c816_000093_f8c16535+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   4105e0 <__swc_fn_3464c816_000137_a4ba10ed>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_3464c816_000093_f8c16535+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_3464c816+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   410100 <__swc_fn_3464c816_000116_035d76a1>
  408959:	call   40c9f0 <__swc_fn_3464c816_000118_7f430081>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_3464c816_000096_ad982b35>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40896f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408975:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40897b:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  408981:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  408987:	mov    QWORD PTR [rsp+0x48],rdx
  40898c:	mov    rax,r8
  40898f:	cmp    r8,0x1
  408993:	mov    edx,0x1
  408998:	cmovb  rax,rdx
  40899c:	mov    QWORD PTR [rsp+0x50],rax
  4089a1:	mov    rbx,QWORD PTR [rcx+0x8]
  4089a5:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a9:	mov    rcx,QWORD PTR [rcx]
  4089ac:	lea    rdx,[rsp+0x8]
  4089b1:	call   rbx
  4089b3:	add    rsp,0x70
  4089b7:	pop    rbx
  4089b8:	ret
  4089b9:	add    BYTE PTR [rax],al
  4089bb:	add    BYTE PTR [rax],al
  4089bd:	add    BYTE PTR [rax],al
	...

00000000004089c0 <__swc_fn_3464c816_000099_b4c6da83>:
  4089c0:	push   rbx
  4089c1:	push   rsi
  4089c2:	push   rdi
  4089c3:	sub    rsp,0x30
  4089c7:	mov    rbx,rcx
  4089ca:	test   rcx,rcx
  4089cd:	je     4089e2 <__swc_fn_3464c816_000099_b4c6da83+0x22>
  4089cf:	mov    rcx,rbx
  4089d2:	mov    edx,0x1
  4089d7:	call   408200 <__swc_fn_3464c816_000078_a120bd2b>
  4089dc:	cmp    rax,0x1
  4089e0:	je     4089ea <__swc_fn_3464c816_000099_b4c6da83+0x2a>
  4089e2:	add    rsp,0x30
  4089e6:	pop    rdi
  4089e7:	pop    rsi
  4089e8:	pop    rbx
  4089e9:	ret
  4089ea:	lea    rsi,[rsp+0x8]
  4089ef:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089f4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089fa:	lea    rax,[rsp+0x18]
  4089ff:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  408a04:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408a0a:	mov    rcx,QWORD PTR [rsp+0x20]
  408a0f:	test   rcx,rcx
  408a12:	je     408a28 <__swc_fn_3464c816_000099_b4c6da83+0x68>
  408a14:	test   DWORD PTR [rcx+0x28],0x400000
  408a1b:	je     408a28 <__swc_fn_3464c816_000099_b4c6da83+0x68>
  408a1d:	mov    rdx,QWORD PTR [rcx+0x30]
  408a21:	test   rdx,rdx
  408a24:	cmovne rcx,rdx
  408a28:	mov    edi,DWORD PTR [rcx+0x20]
  408a2b:	mov    rcx,rax
  408a2e:	call   40c350 <__swc_fn_3464c816_000100_3ed08774>
  408a33:	mov    rcx,rsi
  408a36:	mov    rdx,QWORD PTR [rsp+0x18]
  408a3b:	mov    r8,rdi
  408a3e:	call   408960 <__swc_fn_3464c816_000096_ad982b35>
  408a43:	mov    rcx,QWORD PTR [rbx+0x28]
  408a47:	call   40f680 <__swc_fn_3464c816_000098_00f01091>
  408a4c:	mov    rcx,rsi
  408a4f:	mov    rdx,rbx
  408a52:	mov    r8d,0x30
  408a58:	call   408960 <__swc_fn_3464c816_000096_ad982b35>
  408a5d:	add    rsp,0x30
  408a61:	pop    rdi
  408a62:	pop    rsi
  408a63:	pop    rbx
  408a64:	ret
	...

0000000000408a80 <__swc_fn_3464c816_000102_e9fdc18e>:
  408a80:	push   rbp
  408a81:	push   rbx
  408a82:	push   rsi
  408a83:	push   rdi
  408a84:	push   r12
  408a86:	push   r13
  408a88:	push   r14
  408a8a:	push   r15
  408a8c:	sub    rsp,0x500
  408a93:	mov    rbp,rsp
  408a96:	mov    rbx,rsp
  408a99:	mov    rsi,rdx
  408a9c:	mov    rdi,rcx
  408a9f:	mov    rcx,QWORD PTR [rip+0x1e29a]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  408aa6:	test   rcx,rcx
  408aa9:	jne    408ac3 <__swc_fn_3464c816_000102_e9fdc18e+0x43>
  408aab:	sub    rsp,0x8
  408aaf:	call   40a1d0 <__swc_fn_3464c816_000165_cf398896>
  408ab4:	add    rsp,0x8
  408ab8:	lea    rcx,[rax+0x1]
  408abc:	mov    QWORD PTR [rip+0x1e27d],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  408ac3:	dec    rcx
  408ac6:	sub    rsp,0x8
  408aca:	call   411f00 <__swc_fn_3464c816_000167_fce60b2b>
  408acf:	add    rsp,0x8
  408ad3:	mov    r12,rax
  408ad6:	mov    QWORD PTR [rsp+0x4f0],rax
  408ade:	lea    rax,[rip+0xa81b]        # 413300 <__swc_rdata_base_3464c816+0x1f0>
  408ae5:	sub    rsp,0x20
  408ae9:	mov    rcx,rsp
  408aec:	mov    QWORD PTR [rcx],rax
  408aef:	lea    r13,[rip+0xa81a]        # 413310 <__swc_rdata_base_3464c816+0x200>
  408af6:	mov    QWORD PTR [rcx+0x8],r13
  408afa:	mov    QWORD PTR [rcx+0x10],rsp
  408afe:	mov    QWORD PTR [rcx+0x18],0x1
  408b06:	lea    rcx,[rsp+0x10]
  408b0b:	sub    rsp,0x8
  408b0f:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  408b14:	add    rsp,0x8
  408b18:	add    rsp,0x20
  408b1c:	lea    rax,[rip+0xa835]        # 413358 <__swc_rdata_base_3464c816+0x248>
  408b23:	sub    rsp,0x20
  408b27:	mov    rcx,rsp
  408b2a:	mov    QWORD PTR [rcx],rax
  408b2d:	mov    QWORD PTR [rcx+0x8],r13
  408b31:	mov    QWORD PTR [rcx+0x10],rsp
  408b35:	mov    QWORD PTR [rcx+0x18],0x1
  408b3d:	lea    rcx,[rsp+0x10]
  408b42:	sub    rsp,0x8
  408b46:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  408b4b:	add    rsp,0x8
  408b4f:	add    rsp,0x20
  408b53:	lea    r14,[rip+0xa80e]        # 413368 <__swc_rdata_base_3464c816+0x258>
  408b5a:	sub    rsp,0x50
  408b5e:	mov    rax,rsp
  408b61:	vmovups xmm0,XMMWORD PTR [rip+0xa937]        # 4134a0 <__swc_rdata_base_3464c816+0x390>
  408b69:	vmovups XMMWORD PTR [rax],xmm0
  408b6d:	mov    QWORD PTR [rax+0x10],rsp
  408b71:	mov    QWORD PTR [rax+0x18],r13
  408b75:	mov    QWORD PTR [rax+0x20],rdi
  408b79:	lea    rdi,[rip+0xa7f8]        # 413378 <__swc_rdata_base_3464c816+0x268>
  408b80:	mov    QWORD PTR [rax+0x28],rdi
  408b84:	mov    QWORD PTR [rax+0x30],r14
  408b88:	mov    QWORD PTR [rax+0x38],r13
  408b8c:	lea    rcx,[rsp+0x10]
  408b91:	mov    QWORD PTR [rax+0x40],rcx
  408b95:	mov    QWORD PTR [rax+0x48],0x3
  408b9d:	lea    rcx,[rsp+0x40]
  408ba2:	sub    rsp,0x8
  408ba6:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  408bab:	add    rsp,0x8
  408baf:	add    rsp,0x50
  408bb3:	lea    rax,[rip+0xa806]        # 4133c0 <__swc_rdata_base_3464c816+0x2b0>
  408bba:	sub    rsp,0x20
  408bbe:	mov    rcx,rsp
  408bc1:	mov    QWORD PTR [rcx],rax
  408bc4:	mov    QWORD PTR [rcx+0x8],r13
  408bc8:	mov    QWORD PTR [rcx+0x10],rsp
  408bcc:	mov    QWORD PTR [rcx+0x18],0x1
  408bd4:	lea    rcx,[rsp+0x10]
  408bd9:	sub    rsp,0x8
  408bdd:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  408be2:	add    rsp,0x8
  408be6:	add    rsp,0x20
  408bea:	mov    eax,DWORD PTR [rsi+0x20]
  408bed:	mov    ecx,DWORD PTR [rsi+0x24]
  408bf0:	sub    rsp,0xa0
  408bf7:	mov    rdx,rsp
  408bfa:	mov    QWORD PTR [rdx+0x30],rsi
  408bfe:	mov    QWORD PTR [rdx+0x38],rdi
  408c02:	vmovups xmm0,XMMWORD PTR [rip+0xa82e]        # 413438 <__swc_rdata_base_3464c816+0x328>
  408c0a:	vmovups XMMWORD PTR [rdx],xmm0
  408c0e:	mov    QWORD PTR [rdx+0x40],rsp
  408c12:	mov    QWORD PTR [rdx+0x48],r13
  408c16:	mov    DWORD PTR [rdx+0x10],eax
  408c19:	lea    rax,[rsp+0x10]
  408c1e:	mov    QWORD PTR [rdx+0x50],rax
  408c22:	lea    rax,[rip+0xa7a7]        # 4133d0 <__swc_rdata_base_3464c816+0x2c0>
  408c29:	mov    QWORD PTR [rdx+0x58],rax
  408c2d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c32:	lea    r8,[rsp+0x18]
  408c37:	mov    QWORD PTR [rdx+0x60],r8
  408c3b:	mov    QWORD PTR [rdx+0x68],r13
  408c3f:	mov    DWORD PTR [rdx+0x28],ecx
  408c42:	lea    rcx,[rdx+0x28]
  408c46:	mov    QWORD PTR [rdx+0x70],rcx
  408c4a:	mov    QWORD PTR [rdx+0x78],rax
  408c4e:	mov    QWORD PTR [rdx+0x80],r14
  408c55:	mov    QWORD PTR [rdx+0x88],r13
  408c5c:	lea    rax,[rdx+0x30]
  408c60:	mov    QWORD PTR [rdx+0x90],rax
  408c67:	mov    QWORD PTR [rdx+0x98],0x6
  408c72:	lea    rcx,[rdx+0x90]
  408c79:	sub    rsp,0x8
  408c7d:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  408c82:	add    rsp,0x8
  408c86:	add    rsp,0xa0
  408c8d:	sub    rsp,0x20
  408c91:	mov    rax,rsp
  408c94:	mov    QWORD PTR [rax],r14
  408c97:	mov    QWORD PTR [rax+0x8],r13
  408c9b:	mov    QWORD PTR [rax+0x10],rsp
  408c9f:	mov    QWORD PTR [rax+0x18],0x1
  408ca7:	lea    rcx,[rsp+0x10]
  408cac:	sub    rsp,0x8
  408cb0:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  408cb5:	add    rsp,0x8
  408cb9:	add    rsp,0x20
  408cbd:	mov    eax,DWORD PTR [r12+0x9ac]
  408cc5:	test   eax,eax
  408cc7:	je     408f00 <__swc_fn_3464c816_000102_e9fdc18e+0x480>
  408ccd:	lea    rax,[rip+0xa744]        # 413418 <__swc_rdata_base_3464c816+0x308>
  408cd4:	sub    rsp,0x20
  408cd8:	mov    rcx,rsp
  408cdb:	mov    QWORD PTR [rcx],rax
  408cde:	mov    QWORD PTR [rcx+0x8],r13
  408ce2:	mov    QWORD PTR [rcx+0x10],rsp
  408ce6:	mov    QWORD PTR [rcx+0x18],0x1
  408cee:	lea    rcx,[rsp+0x10]
  408cf3:	sub    rsp,0x8
  408cf7:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  408cfc:	add    rsp,0x8
  408d00:	add    rsp,0x20
  408d04:	mov    eax,DWORD PTR [r12+0x9ac]
  408d0c:	dec    eax
  408d0e:	mov    esi,eax
  408d10:	test   esi,esi
  408d12:	jl     408ed0 <__swc_fn_3464c816_000102_e9fdc18e+0x450>
  408d18:	jmp    408d24 <__swc_fn_3464c816_000102_e9fdc18e+0x2a4>
  408d1a:	nop    WORD PTR [rax+rax*1+0x0]
  408d20:	dec    esi
  408d22:	jmp    408d10 <__swc_fn_3464c816_000102_e9fdc18e+0x290>
  408d24:	lea    rax,[rip+0xa6fd]        # 413428 <__swc_rdata_base_3464c816+0x318>
  408d2b:	sub    rsp,0x20
  408d2f:	mov    rcx,rsp
  408d32:	mov    QWORD PTR [rcx],rax
  408d35:	mov    QWORD PTR [rcx+0x8],r13
  408d39:	mov    QWORD PTR [rcx+0x10],rsp
  408d3d:	mov    QWORD PTR [rcx+0x18],0x1
  408d45:	lea    rcx,[rsp+0x10]
  408d4a:	sub    rsp,0x8
  408d4e:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  408d53:	add    rsp,0x8
  408d57:	add    rsp,0x20
  408d5b:	movsxd rax,esi
  408d5e:	imul   r15,rax,0x30
  408d62:	add    r15,r12
  408d65:	add    r15,0xf8
  408d6c:	sub    rsp,0x20
  408d70:	mov    rax,rsp
  408d73:	mov    QWORD PTR [rax],r15
  408d76:	mov    QWORD PTR [rax+0x8],rdi
  408d7a:	mov    QWORD PTR [rax+0x10],rsp
  408d7e:	mov    QWORD PTR [rax+0x18],0x1
  408d86:	lea    rcx,[rsp+0x10]
  408d8b:	sub    rsp,0x8
  408d8f:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  408d94:	add    rsp,0x8
  408d98:	add    rsp,0x20
  408d9c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408da4:	lea    rsi,[rip+0xa68d]        # 413438 <__swc_rdata_base_3464c816+0x328>
  408dab:	sub    rsp,0x20
  408daf:	mov    rax,rsp
  408db2:	mov    QWORD PTR [rax],rsi
  408db5:	mov    QWORD PTR [rax+0x8],r13
  408db9:	mov    QWORD PTR [rax+0x10],rsp
  408dbd:	mov    QWORD PTR [rax+0x18],0x1
  408dc5:	lea    rcx,[rsp+0x10]
  408dca:	sub    rsp,0x8
  408dce:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  408dd3:	add    rsp,0x8
  408dd7:	add    rsp,0x20
  408ddb:	sub    rsp,0x30
  408ddf:	mov    rax,rsp
  408de2:	mov    ecx,DWORD PTR [r15+0x20]
  408de6:	mov    QWORD PTR [rax],rcx
  408de9:	mov    QWORD PTR [rax+0x8],rsp
  408ded:	lea    rdi,[rip+0xa654]        # 413448 <__swc_rdata_base_3464c816+0x338>
  408df4:	mov    QWORD PTR [rax+0x10],rdi
  408df8:	lea    rcx,[rsp+0x8]
  408dfd:	mov    QWORD PTR [rax+0x18],rcx
  408e01:	mov    QWORD PTR [rax+0x20],0x1
  408e09:	lea    rcx,[rsp+0x18]
  408e0e:	sub    rsp,0x8
  408e12:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  408e17:	add    rsp,0x8
  408e1b:	add    rsp,0x30
  408e1f:	sub    rsp,0x20
  408e23:	mov    rax,rsp
  408e26:	mov    QWORD PTR [rax],rsi
  408e29:	mov    QWORD PTR [rax+0x8],r13
  408e2d:	mov    QWORD PTR [rax+0x10],rsp
  408e31:	mov    QWORD PTR [rax+0x18],0x1
  408e39:	lea    rcx,[rsp+0x10]
  408e3e:	sub    rsp,0x8
  408e42:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  408e47:	add    rsp,0x8
  408e4b:	add    rsp,0x20
  408e4f:	sub    rsp,0x30
  408e53:	mov    rax,rsp
  408e56:	mov    ecx,DWORD PTR [r15+0x24]
  408e5a:	mov    QWORD PTR [rax],rcx
  408e5d:	mov    QWORD PTR [rax+0x8],rsp
  408e61:	mov    QWORD PTR [rax+0x10],rdi
  408e65:	lea    rcx,[rsp+0x8]
  408e6a:	mov    QWORD PTR [rax+0x18],rcx
  408e6e:	mov    QWORD PTR [rax+0x20],0x1
  408e76:	lea    rcx,[rsp+0x18]
  408e7b:	sub    rsp,0x8
  408e7f:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  408e84:	add    rsp,0x8
  408e88:	add    rsp,0x30
  408e8c:	sub    rsp,0x20
  408e90:	mov    rax,rsp
  408e93:	mov    QWORD PTR [rax],r14
  408e96:	mov    QWORD PTR [rax+0x8],r13
  408e9a:	mov    QWORD PTR [rax+0x10],rsp
  408e9e:	mov    QWORD PTR [rax+0x18],0x1
  408ea6:	lea    rcx,[rsp+0x10]
  408eab:	sub    rsp,0x8
  408eaf:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  408eb4:	add    rsp,0x8
  408eb8:	add    rsp,0x20
  408ebc:	lea    rdi,[rip+0xa4b5]        # 413378 <__swc_rdata_base_3464c816+0x268>
  408ec3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408ecb:	jmp    408d20 <__swc_fn_3464c816_000102_e9fdc18e+0x2a0>
  408ed0:	sub    rsp,0x20
  408ed4:	mov    rax,rsp
  408ed7:	mov    QWORD PTR [rax],r14
  408eda:	mov    QWORD PTR [rax+0x8],r13
  408ede:	mov    QWORD PTR [rax+0x10],rsp
  408ee2:	mov    QWORD PTR [rax+0x18],0x1
  408eea:	lea    rcx,[rsp+0x10]
  408eef:	sub    rsp,0x8
  408ef3:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  408ef8:	add    rsp,0x8
  408efc:	add    rsp,0x20
  408f00:	lea    rax,[rbx+0x28]
  408f04:	mov    rcx,rax
  408f07:	mov    QWORD PTR [rbx+0x28],0x0
  408f0f:	mov    QWORD PTR [rbx+0x30],0x0
  408f17:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408f1c:	add    rcx,0x10
  408f20:	mov    edx,0x1f
  408f25:	cs nop WORD PTR [rax+rax*1+0x0]
  408f2f:	nop
  408f30:	vmovups XMMWORD PTR [rcx],xmm0
  408f34:	add    rcx,0x10
  408f38:	sub    rdx,0x1
  408f3c:	jne    408f30 <__swc_fn_3464c816_000102_e9fdc18e+0x4b0>
  408f3e:	lea    rsi,[rbx+0x228]
  408f45:	xor    ecx,ecx
  408f47:	cs nop WORD PTR [rax+rax*1+0x0]
  408f51:	cs nop WORD PTR [rax+rax*1+0x0]
  408f5b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f60:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f65:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f6a:	add    rcx,0x10
  408f6e:	cmp    rcx,0x200
  408f75:	jne    408f60 <__swc_fn_3464c816_000102_e9fdc18e+0x4e0>
  408f77:	mov    eax,DWORD PTR [r12+0xbc8]
  408f7f:	lea    rcx,[r12+0x9c8]
  408f87:	mov    QWORD PTR [rbx+0x428],rcx
  408f8e:	mov    QWORD PTR [rbx+0x430],rax
  408f95:	lea    rdi,[rbx+0x438]
  408f9c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408fa4:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fac:	mov    eax,DWORD PTR [r12+0xbc8]
  408fb4:	test   eax,eax
  408fb6:	jne    409003 <__swc_fn_3464c816_000102_e9fdc18e+0x583>
  408fb8:	lea    rax,[rbx+0x448]
  408fbf:	mov    QWORD PTR [rbx+0x448],rsi
  408fc6:	mov    QWORD PTR [rax+0x8],0x40
  408fce:	mov    ecx,0x1
  408fd3:	mov    rdx,rax
  408fd6:	sub    rsp,0x8
  408fda:	call   410220 <__swc_fn_3464c816_000119_9175a56a>
  408fdf:	add    rsp,0x8
  408fe3:	mov    QWORD PTR [rbx+0x460],rsi
  408fea:	mov    ecx,eax
  408fec:	mov    QWORD PTR [rbx+0x468],rcx
  408ff3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408ffb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  409003:	mov    rsi,QWORD PTR [rbx+0x438]
  40900a:	mov    rax,QWORD PTR [rbx+0x440]
  409011:	mov    r15,rax
  409014:	xor    r12d,r12d
  409017:	test   r15,r15
  40901a:	je     4090d0 <__swc_fn_3464c816_000102_e9fdc18e+0x650>
  409020:	mov    rax,QWORD PTR [rsi+r12*8]
  409024:	test   rax,rax
  409027:	je     409046 <__swc_fn_3464c816_000102_e9fdc18e+0x5c6>
  409029:	lea    rcx,[rbx+0x4b8]
  409030:	mov    rdx,rax
  409033:	sub    rsp,0x8
  409037:	call   409f40 <__swc_fn_3464c816_000162_60216e69>
  40903c:	add    rsp,0x8
  409040:	mov    al,BYTE PTR [rax]
  409042:	test   al,al
  409044:	jne    409052 <__swc_fn_3464c816_000102_e9fdc18e+0x5d2>
  409046:	add    r12,0x1
  40904a:	sub    r15,0x1
  40904e:	jne    409020 <__swc_fn_3464c816_000102_e9fdc18e+0x5a0>
  409050:	jmp    4090d0 <__swc_fn_3464c816_000102_e9fdc18e+0x650>
  409052:	lea    rax,[rip+0xa437]        # 413490 <__swc_rdata_base_3464c816+0x380>
  409059:	sub    rsp,0x20
  40905d:	mov    rcx,rsp
  409060:	mov    QWORD PTR [rcx],rax
  409063:	mov    QWORD PTR [rcx+0x8],r13
  409067:	mov    QWORD PTR [rcx+0x10],rsp
  40906b:	mov    QWORD PTR [rcx+0x18],0x1
  409073:	lea    rcx,[rsp+0x10]
  409078:	sub    rsp,0x8
  40907c:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  409081:	add    rsp,0x8
  409085:	add    rsp,0x20
  409089:	mov    rcx,rdi
  40908c:	xor    edx,edx
  40908e:	mov    al,0x1
  409090:	mov    r8,rax
  409093:	sub    rsp,0x8
  409097:	call   40d2a0 <__swc_fn_3464c816_000163_8e41797b>
  40909c:	add    rsp,0x8
  4090a0:	sub    rsp,0x20
  4090a4:	mov    rax,rsp
  4090a7:	mov    QWORD PTR [rax],r14
  4090aa:	mov    QWORD PTR [rax+0x8],r13
  4090ae:	mov    QWORD PTR [rax+0x10],rsp
  4090b2:	mov    QWORD PTR [rax+0x18],0x1
  4090ba:	lea    rcx,[rsp+0x10]
  4090bf:	sub    rsp,0x8
  4090c3:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  4090c8:	add    rsp,0x8
  4090cc:	add    rsp,0x20
  4090d0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090d8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090e4:	add    rsp,0x500
  4090eb:	pop    r15
  4090ed:	pop    r14
  4090ef:	pop    r13
  4090f1:	pop    r12
  4090f3:	pop    rdi
  4090f4:	pop    rsi
  4090f5:	pop    rbx
  4090f6:	pop    rbp
  4090f7:	ret
	...

0000000000409100 <__swc_fn_3464c816_000105_6fd80914>:
  409100:	sub    rsp,0x8
  409104:	test   r8,r8
  409107:	je     40910e <__swc_fn_3464c816_000105_6fd80914+0xe>
  409109:	call   40f910 <__swc_fn_3464c816_000104_5589fdbd>
  40910e:	add    rsp,0x8
  409112:	ret
	...

0000000000409120 <__swc_fn_3464c816_000108_84af7666>:
  409120:	push   rsi
  409121:	push   rdi
  409122:	push   r12
  409124:	push   r13
  409126:	sub    rsp,0xd8
  40912d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409133:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409139:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40913f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409145:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40914b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409154:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40915d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409166:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40916f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409178:	xor    eax,eax
  40917a:	call   407010 <getpid@plt>
  40917f:	mov    rsi,rax
  409182:	lea    rdi,[rip+0x1dbbf]        # 426d48 <__swc_bss_base_3464c816+0x2d08>
  409189:	mov    r12,QWORD PTR [rdi]
  40918c:	test   r12,r12
  40918f:	je     40919d <__swc_fn_3464c816_000108_84af7666+0x7d>
  409191:	cmp    DWORD PTR [r12+0x10],esi
  409196:	jne    40919d <__swc_fn_3464c816_000108_84af7666+0x7d>
  409198:	mov    rax,r12
  40919b:	jmp    409200 <__swc_fn_3464c816_000108_84af7666+0xe0>
  40919d:	mov    ecx,0x4
  4091a2:	mov    edx,0x18
  4091a7:	call   40fa00 <__swc_fn_3464c816_000107_4796e893>
  4091ac:	mov    rcx,rax
  4091af:	test   rax,rax
  4091b2:	jne    4091b8 <__swc_fn_3464c816_000108_84af7666+0x98>
  4091b4:	xor    eax,eax
  4091b6:	jmp    409200 <__swc_fn_3464c816_000108_84af7666+0xe0>
  4091b8:	mov    DWORD PTR [rcx+0x10],esi
  4091bb:	mov    rax,r12
  4091be:	lock cmpxchg QWORD PTR [rdi],rcx
  4091c3:	mov    r13,rax
  4091c6:	cmp    rax,r12
  4091c9:	je     4091df <__swc_fn_3464c816_000108_84af7666+0xbf>
  4091cb:	mov    rdi,rcx
  4091ce:	mov    esi,0x18
  4091d3:	xor    eax,eax
  4091d5:	call   407020 <munmap@plt>
  4091da:	mov    rax,r13
  4091dd:	jmp    409200 <__swc_fn_3464c816_000108_84af7666+0xe0>
  4091df:	test   r12,r12
  4091e2:	je     4091fd <__swc_fn_3464c816_000108_84af7666+0xdd>
  4091e4:	mov    rdi,r12
  4091e7:	mov    esi,0x18
  4091ec:	xor    eax,eax
  4091ee:	mov    QWORD PTR [rsp+0x28],rcx
  4091f3:	call   407020 <munmap@plt>
  4091f8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091fd:	mov    rax,rcx
  409200:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  409206:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40920c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  409212:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  409218:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40921e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409227:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409230:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409239:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409242:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40924b:	add    rsp,0xd8
  409252:	pop    r13
  409254:	pop    r12
  409256:	pop    rdi
  409257:	pop    rsi
  409258:	ret
  409259:	add    BYTE PTR [rax],al
  40925b:	add    BYTE PTR [rax],al
  40925d:	add    BYTE PTR [rax],al
	...

0000000000409260 <__swc_fn_3464c816_000111_b25e3a45>:
  409260:	push   rbx
  409261:	push   r12
  409263:	push   rdi
  409264:	push   rsi
  409265:	sub    rsp,0xa8
  40926c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409272:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409278:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40927e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409284:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40928a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409290:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409296:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40929c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4092a5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4092ae:	mov    rbx,rdx
  4092b1:	mov    r12,rcx
  4092b4:	mov    rdi,rcx
  4092b7:	mov    rsi,rdx
  4092ba:	mov    edx,0x3
  4092bf:	xor    eax,eax
  4092c1:	call   407030 <mprotect@plt>
  4092c6:	test   eax,eax
  4092c8:	je     4092ce <__swc_fn_3464c816_000111_b25e3a45+0x6e>
  4092ca:	xor    eax,eax
  4092cc:	jmp    4092e3 <__swc_fn_3464c816_000111_b25e3a45+0x83>
  4092ce:	mov    rcx,r12
  4092d1:	mov    rdx,rbx
  4092d4:	mov    al,0x1
  4092d6:	mov    r8,rax
  4092d9:	call   410050 <__swc_fn_3464c816_000110_a808fe76>
  4092de:	mov    eax,0x1
  4092e3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092e9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092ef:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092f5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092fb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409301:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409307:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40930d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409313:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40931c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409325:	add    rsp,0xa8
  40932c:	pop    rsi
  40932d:	pop    rdi
  40932e:	pop    r12
  409330:	pop    rbx
  409331:	ret
	...

0000000000409340 <__swc_fn_3464c816_000114_27d95464>:
  409340:	sub    rsp,0x8
  409344:	test   rcx,rcx
  409347:	jne    40934e <__swc_fn_3464c816_000114_27d95464+0xe>
  409349:	add    rsp,0x8
  40934d:	ret
  40934e:	call   40c8a0 <__swc_fn_3464c816_000115_1ba33335>
  409353:	add    rsp,0x8
  409357:	ret
	...

0000000000409360 <__swc_fn_3464c816_000117_86a7fb9e>:
  409360:	push   rdi
  409361:	push   rsi
  409362:	sub    rsp,0xa8
  409369:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40936f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409375:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40937b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409381:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409387:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40938d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409393:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409399:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4093a2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4093ab:	xor    edi,edi
  4093ad:	xor    eax,eax
  4093af:	call   407040 <exit@plt>
  4093b4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4093ba:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093c0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093c6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093cc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093d2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093d8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093de:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093e4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093ed:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093f6:	add    rsp,0xa8
  4093fd:	pop    rsi
  4093fe:	pop    rdi
  4093ff:	ret

0000000000409400 <__swc_fn_3464c816_000120_ea68f292>:
  409400:	push   rbx
  409401:	push   rsi
  409402:	push   rdi
  409403:	push   r12
  409405:	sub    rsp,0x18
  409409:	mov    rbx,r8
  40940c:	mov    rsi,rcx
  40940f:	mov    rdi,rdx
  409412:	mov    rcx,QWORD PTR [rip+0x1d927]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  409419:	test   rcx,rcx
  40941c:	jne    40942e <__swc_fn_3464c816_000120_ea68f292+0x2e>
  40941e:	call   40a1d0 <__swc_fn_3464c816_000165_cf398896>
  409423:	lea    rcx,[rax+0x1]
  409427:	mov    QWORD PTR [rip+0x1d912],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40942e:	dec    rcx
  409431:	call   411f00 <__swc_fn_3464c816_000167_fce60b2b>
  409436:	mov    r12,rax
  409439:	cmp    ebx,0x3
  40943c:	jne    40944f <__swc_fn_3464c816_000120_ea68f292+0x4f>
  40943e:	mov    rax,QWORD PTR [r12+0xbd0]
  409446:	test   rax,rax
  409449:	jne    40958f <__swc_fn_3464c816_000120_ea68f292+0x18f>
  40944f:	cmp    ebx,0x5
  409452:	jne    409476 <__swc_fn_3464c816_000120_ea68f292+0x76>
  409454:	call   40c170 <__swc_fn_3464c816_000091_3d2f5a0d>
  409459:	test   al,al
  40945b:	jne    409476 <__swc_fn_3464c816_000120_ea68f292+0x76>
  40945d:	mov    rcx,rsi
  409460:	mov    rdx,rdi
  409463:	call   411eb0 <__swc_fn_3464c816_000164_1962e12a>
  409468:	test   al,al
  40946a:	je     409476 <__swc_fn_3464c816_000120_ea68f292+0x76>
  40946c:	add    rsp,0x18
  409470:	pop    r12
  409472:	pop    rdi
  409473:	pop    rsi
  409474:	pop    rbx
  409475:	ret
  409476:	call   40c170 <__swc_fn_3464c816_000091_3d2f5a0d>
  40947b:	test   al,al
  40947d:	jne    4094f2 <__swc_fn_3464c816_000120_ea68f292+0xf2>
  40947f:	lea    rax,[rsp+0x8]
  409484:	vmovups xmm0,XMMWORD PTR [rsi]
  409488:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40948e:	mov    rcx,QWORD PTR [rsp+0x8]
  409493:	test   rcx,rcx
  409496:	jne    4094e7 <__swc_fn_3464c816_000120_ea68f292+0xe7>
  409498:	cmp    ebx,0x3
  40949b:	je     4094a9 <__swc_fn_3464c816_000120_ea68f292+0xa9>
  40949d:	cmp    ebx,0x4
  4094a0:	je     4094b9 <__swc_fn_3464c816_000120_ea68f292+0xb9>
  4094a2:	cmp    ebx,0x5
  4094a5:	je     4094c9 <__swc_fn_3464c816_000120_ea68f292+0xc9>
  4094a7:	jmp    4094d9 <__swc_fn_3464c816_000120_ea68f292+0xd9>
  4094a9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 4134e0 <__swc_rdata_base_3464c816+0x3d0>
  4094b1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b7:	jmp    4094e7 <__swc_fn_3464c816_000120_ea68f292+0xe7>
  4094b9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 4134f0 <__swc_rdata_base_3464c816+0x3e0>
  4094c1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c7:	jmp    4094e7 <__swc_fn_3464c816_000120_ea68f292+0xe7>
  4094c9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 413500 <__swc_rdata_base_3464c816+0x3f0>
  4094d1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094d7:	jmp    4094e7 <__swc_fn_3464c816_000120_ea68f292+0xe7>
  4094d9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 413510 <__swc_rdata_base_3464c816+0x400>
  4094e1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094e7:	mov    rcx,rax
  4094ea:	mov    rdx,rdi
  4094ed:	call   40c3c0 <__swc_fn_3464c816_000103_67100064>
  4094f2:	vmovups xmm0,XMMWORD PTR [rdi]
  4094f6:	vmovups XMMWORD PTR [r12+0x940],xmm0
  409500:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  409505:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40950f:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  409514:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40951e:	lea    rax,[r12+0x940]
  409526:	mov    QWORD PTR [r12+0x970],rax
  40952e:	mov    rax,QWORD PTR [rsi]
  409531:	mov    QWORD PTR [r12+0x978],rax
  409539:	mov    rax,QWORD PTR [rsi+0x8]
  40953d:	mov    QWORD PTR [r12+0x980],rax
  409545:	movsxd rax,ebx
  409548:	mov    QWORD PTR [r12+0x988],rax
  409550:	cmp    ebx,0x5
  409553:	je     40955c <__swc_fn_3464c816_000120_ea68f292+0x15c>
  409555:	xor    ecx,ecx
  409557:	call   40a300 <__swc_fn_3464c816_000174_176517f9>
  40955c:	mov    rbx,QWORD PTR [r12+0xbe8]
  409564:	test   rbx,rbx
  409567:	je     409578 <__swc_fn_3464c816_000120_ea68f292+0x178>
  409569:	mov    rcx,r12
  40956c:	call   rbx
  40956e:	add    rsp,0x18
  409572:	pop    r12
  409574:	pop    rdi
  409575:	pop    rsi
  409576:	pop    rbx
  409577:	ret
  409578:	mov    rcx,rsi
  40957b:	call   410100 <__swc_fn_3464c816_000116_035d76a1>
  409580:	call   40c9f0 <__swc_fn_3464c816_000118_7f430081>
  409585:	add    rsp,0x18
  409589:	pop    r12
  40958b:	pop    rdi
  40958c:	pop    rsi
  40958d:	pop    rbx
  40958e:	ret
  40958f:	mov    rcx,rsi
  409592:	mov    rdx,rdi
  409595:	call   40c3c0 <__swc_fn_3464c816_000103_67100064>
  40959a:	jmp    40944f <__swc_fn_3464c816_000120_ea68f292+0x4f>
	...

00000000004095a0 <__swc_fn_3464c816_000123_9d2cbd72>:
  4095a0:	push   rdi
  4095a1:	push   rsi
  4095a2:	sub    rsp,0xb8
  4095a9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4095af:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4095b5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4095bb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095c1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095c7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095cd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095d3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095dc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095e5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ee:	mov    DWORD PTR [rsp+0x8],0x0
  4095f6:	lea    rdi,[rsp+0x8]
  4095fb:	xor    esi,esi
  4095fd:	xor    eax,eax
  4095ff:	call   407050 <pthread_key_create@plt>
  409604:	test   eax,eax
  409606:	jne    40960e <__swc_fn_3464c816_000123_9d2cbd72+0x6e>
  409608:	mov    eax,DWORD PTR [rsp+0x8]
  40960c:	jmp    409615 <__swc_fn_3464c816_000123_9d2cbd72+0x75>
  40960e:	mov    rax,0xffffffffffffffff
  409615:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40961b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409621:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409627:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40962d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409633:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409639:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40963f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409648:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409651:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40965a:	add    rsp,0xb8
  409661:	pop    rsi
  409662:	pop    rdi
  409663:	ret
	...

0000000000409670 <__swc_fn_3464c816_000126_102fe7b9>:
  409670:	push   rdi
  409671:	push   rsi
  409672:	sub    rsp,0xb8
  409679:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40967f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409685:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40968b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409691:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409697:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40969d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4096a3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4096ac:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4096b5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4096be:	mov    DWORD PTR [rsp+0x8],0x0
  4096c6:	lea    rdi,[rsp+0x8]
  4096cb:	mov    rsi,rcx
  4096ce:	xor    eax,eax
  4096d0:	call   407050 <pthread_key_create@plt>
  4096d5:	test   eax,eax
  4096d7:	jne    4096e2 <__swc_fn_3464c816_000126_102fe7b9+0x72>
  4096d9:	mov    eax,DWORD PTR [rsp+0x8]
  4096dd:	inc    rax
  4096e0:	jmp    4096e4 <__swc_fn_3464c816_000126_102fe7b9+0x74>
  4096e2:	xor    eax,eax
  4096e4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ea:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096f0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096f6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096fc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409702:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409708:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40970e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409717:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409720:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409729:	add    rsp,0xb8
  409730:	pop    rsi
  409731:	pop    rdi
  409732:	ret
	...

0000000000409740 <__swc_fn_3464c816_000129_74b163fe>:
  409740:	push   rdi
  409741:	push   rsi
  409742:	sub    rsp,0xa8
  409749:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40974f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409755:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40975b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409761:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409767:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40976d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409773:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409779:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409782:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40978b:	test   rcx,rcx
  40978e:	setne  al
  409791:	je     4097aa <__swc_fn_3464c816_000129_74b163fe+0x6a>
  409793:	lea    rax,[rcx-0x1]
  409797:	mov    eax,eax
  409799:	mov    edi,eax
  40979b:	mov    rsi,rdx
  40979e:	xor    eax,eax
  4097a0:	call   407060 <pthread_setspecific@plt>
  4097a5:	test   eax,eax
  4097a7:	sete   al
  4097aa:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4097b0:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4097b6:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4097bc:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097c2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097c8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ce:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097d4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097da:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097e3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097ec:	add    rsp,0xa8
  4097f3:	pop    rsi
  4097f4:	pop    rdi
  4097f5:	ret
	...

0000000000409800 <__swc_fn_3464c816_000132_f908e7f9>:
  409800:	push   rdi
  409801:	push   rsi
  409802:	sub    rsp,0xa8
  409809:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40980f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409815:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40981b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409821:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409827:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40982d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409833:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409839:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409842:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40984b:	mov    rax,rdx
  40984e:	mov    QWORD PTR [rsp],0x0
  409856:	mov    edi,0xca
  40985b:	mov    rsi,rcx
  40985e:	mov    edx,0x81
  409863:	mov    eax,eax
  409865:	mov    ecx,eax
  409867:	xor    r8d,r8d
  40986a:	xor    r9d,r9d
  40986d:	xor    eax,eax
  40986f:	call   407070 <syscall@plt>
  409874:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40987a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409880:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409886:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40988c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409892:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409898:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40989e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4098a4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4098ad:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4098b6:	add    rsp,0xa8
  4098bd:	pop    rsi
  4098be:	pop    rdi
  4098bf:	ret

00000000004098c0 <__swc_fn_3464c816_000135_e3032dc2>:
  4098c0:	sub    rsp,0x8
  4098c4:	call   40cd90 <__swc_fn_3464c816_000133_4b2af8da>
  4098c9:	add    rsp,0x8
  4098cd:	ret
	...

00000000004098d0 <__swc_fn_3464c816_000138_0c00232f>:
  4098d0:	push   rdi
  4098d1:	push   rsi
  4098d2:	sub    rsp,0xc8
  4098d9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098df:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098e5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098eb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098f1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098f7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098fd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  409906:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40990f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  409918:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409921:	vxorps xmm0,xmm0,xmm0
  409925:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40992b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409931:	mov    rdi,rcx
  409934:	lea    rsi,[rsp+0x8]
  409939:	xor    eax,eax
  40993b:	call   407080 <dladdr@plt>
  409940:	xor    ecx,ecx
  409942:	test   eax,eax
  409944:	je     40994b <__swc_fn_3464c816_000138_0c00232f+0x7b>
  409946:	mov    rcx,QWORD PTR [rsp+0x10]
  40994b:	mov    rax,rcx
  40994e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409954:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40995a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409960:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409966:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40996c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409972:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40997b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409984:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40998d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409996:	add    rsp,0xc8
  40999d:	pop    rsi
  40999e:	pop    rdi
  40999f:	ret

00000000004099a0 <__swc_fn_3464c816_000141_2ce79e3b>:
  4099a0:	push   rbx
  4099a1:	push   r12
  4099a3:	push   r13
  4099a5:	push   rdi
  4099a6:	push   rsi
  4099a7:	push   r14
  4099a9:	push   r15
  4099ab:	sub    rsp,0x150
  4099b2:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  4099bb:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099c4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099cd:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099d6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099df:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099e8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099f1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099fa:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  409a03:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  409a0c:	mov    rbx,rdx
  409a0f:	mov    QWORD PTR [rsp+0x98],rdx
  409a17:	mov    r12,rcx
  409a1a:	mov    QWORD PTR [rsp+0xa0],rcx
  409a22:	mov    QWORD PTR [rbx],0x0
  409a29:	lea    r13,[rip+0x1d350]        # 426d80 <__swc_bss_base_3464c816+0x2d40>
  409a30:	mov    rcx,r13
  409a33:	call   4098c0 <__swc_fn_3464c816_000135_e3032dc2>
  409a38:	mov    rax,QWORD PTR [rip+0x1d349]        # 426d88 <__swc_bss_base_3464c816+0x2d48>
  409a3f:	test   rax,rax
  409a42:	je     409a79 <__swc_fn_3464c816_000141_2ce79e3b+0xd9>
  409a44:	cs nop WORD PTR [rax+rax*1+0x0]
  409a4e:	xchg   ax,ax
  409a50:	cmp    QWORD PTR [rax+0x8],r12
  409a54:	jne    409a71 <__swc_fn_3464c816_000141_2ce79e3b+0xd1>
  409a56:	mov    rcx,QWORD PTR [rax+0x18]
  409a5a:	mov    QWORD PTR [rbx],rcx
  409a5d:	mov    rbx,QWORD PTR [rax+0x10]
  409a61:	mov    rcx,r13
  409a64:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  409a69:	mov    rax,rbx
  409a6c:	jmp    409c5b <__swc_fn_3464c816_000141_2ce79e3b+0x2bb>
  409a71:	mov    rax,QWORD PTR [rax]
  409a74:	test   rax,rax
  409a77:	jne    409a50 <__swc_fn_3464c816_000141_2ce79e3b+0xb0>
  409a79:	vxorps xmm0,xmm0,xmm0
  409a7d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a83:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a89:	mov    rdi,r12
  409a8c:	lea    rsi,[rsp+0x10]
  409a91:	xor    eax,eax
  409a93:	call   407080 <dladdr@plt>
  409a98:	test   eax,eax
  409a9a:	sete   al
  409a9d:	je     409aaa <__swc_fn_3464c816_000141_2ce79e3b+0x10a>
  409a9f:	mov    rax,QWORD PTR [rsp+0x10]
  409aa4:	test   rax,rax
  409aa7:	sete   al
  409aaa:	test   al,al
  409aac:	je     409abd <__swc_fn_3464c816_000141_2ce79e3b+0x11d>
  409aae:	mov    rcx,r13
  409ab1:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  409ab6:	xor    eax,eax
  409ab8:	jmp    409c5b <__swc_fn_3464c816_000141_2ce79e3b+0x2bb>
  409abd:	mov    rdi,QWORD PTR [rsp+0x10]
  409ac2:	mov    esi,0x80000
  409ac7:	xor    eax,eax
  409ac9:	call   407090 <open@plt>
  409ace:	lea    r14,[rsp+0x30]
  409ad3:	mov    DWORD PTR [rsp+0x30],eax
  409ad7:	cmp    DWORD PTR [r14],0x0
  409adb:	jge    409aec <__swc_fn_3464c816_000141_2ce79e3b+0x14c>
  409add:	mov    rcx,r13
  409ae0:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  409ae5:	xor    eax,eax
  409ae7:	jmp    409c5b <__swc_fn_3464c816_000141_2ce79e3b+0x2bb>
  409aec:	mov    rax,r14
  409aef:	movsxd rdi,DWORD PTR [rax]
  409af2:	xor    esi,esi
  409af4:	mov    edx,0x2
  409af9:	xor    eax,eax
  409afb:	call   4070a0 <lseek@plt>
  409b00:	mov    r15,rax
  409b03:	test   rax,rax
  409b06:	jg     409b21 <__swc_fn_3464c816_000141_2ce79e3b+0x181>
  409b08:	movsxd rdi,DWORD PTR [r14]
  409b0b:	xor    eax,eax
  409b0d:	call   4070b0 <close@plt>
  409b12:	mov    rcx,r13
  409b15:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  409b1a:	xor    eax,eax
  409b1c:	jmp    409c5b <__swc_fn_3464c816_000141_2ce79e3b+0x2bb>
  409b21:	xor    edi,edi
  409b23:	mov    rsi,r15
  409b26:	mov    edx,0x1
  409b2b:	mov    ecx,0x2
  409b30:	mov    rax,r14
  409b33:	movsxd r8,DWORD PTR [rax]
  409b36:	xor    r9d,r9d
  409b39:	xor    eax,eax
  409b3b:	call   4070c0 <mmap@plt>
  409b40:	mov    rbx,rax
  409b43:	test   rax,rax
  409b46:	sete   al
  409b49:	cmp    rbx,0xffffffffffffffff
  409b4d:	sete   cl
  409b50:	or     al,cl
  409b52:	je     409b6d <__swc_fn_3464c816_000141_2ce79e3b+0x1cd>
  409b54:	movsxd rdi,DWORD PTR [r14]
  409b57:	xor    eax,eax
  409b59:	call   4070b0 <close@plt>
  409b5e:	mov    rcx,r13
  409b61:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  409b66:	xor    eax,eax
  409b68:	jmp    409c5b <__swc_fn_3464c816_000141_2ce79e3b+0x2bb>
  409b6d:	lea    rax,[rsp+0x50]
  409b72:	mov    QWORD PTR [rax],0x0
  409b79:	mov    rcx,rbx
  409b7c:	mov    rdx,r15
  409b7f:	mov    r8,rax
  409b82:	call   4106a0 <__swc_fn_3464c816_000140_c6b99a56>
  409b87:	mov    r12,rax
  409b8a:	test   rax,rax
  409b8d:	jne    409bb5 <__swc_fn_3464c816_000141_2ce79e3b+0x215>
  409b8f:	mov    rdi,rbx
  409b92:	mov    rsi,r15
  409b95:	xor    eax,eax
  409b97:	call   407020 <munmap@plt>
  409b9c:	movsxd rdi,DWORD PTR [r14]
  409b9f:	xor    eax,eax
  409ba1:	call   4070b0 <close@plt>
  409ba6:	mov    rcx,r13
  409ba9:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  409bae:	xor    eax,eax
  409bb0:	jmp    409c5b <__swc_fn_3464c816_000141_2ce79e3b+0x2bb>
  409bb5:	mov    edi,0x20
  409bba:	xor    eax,eax
  409bbc:	call   4070d0 <malloc@plt>
  409bc1:	test   rax,rax
  409bc4:	jne    409be9 <__swc_fn_3464c816_000141_2ce79e3b+0x249>
  409bc6:	mov    rdi,rbx
  409bc9:	mov    rsi,r15
  409bcc:	xor    eax,eax
  409bce:	call   407020 <munmap@plt>
  409bd3:	movsxd rdi,DWORD PTR [r14]
  409bd6:	xor    eax,eax
  409bd8:	call   4070b0 <close@plt>
  409bdd:	mov    rcx,r13
  409be0:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  409be5:	xor    eax,eax
  409be7:	jmp    409c5b <__swc_fn_3464c816_000141_2ce79e3b+0x2bb>
  409be9:	mov    rcx,QWORD PTR [rip+0x1d198]        # 426d88 <__swc_bss_base_3464c816+0x2d48>
  409bf0:	mov    QWORD PTR [rsp+0x70],rcx
  409bf5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bfd:	mov    QWORD PTR [rsp+0x78],rcx
  409c02:	mov    QWORD PTR [rsp+0x80],r12
  409c0a:	mov    rcx,QWORD PTR [rsp+0x50]
  409c0f:	mov    QWORD PTR [rsp+0x88],rcx
  409c17:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409c1d:	vmovups XMMWORD PTR [rax],xmm0
  409c21:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c2a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c2f:	mov    QWORD PTR [rip+0x1d152],rax        # 426d88 <__swc_bss_base_3464c816+0x2d48>
  409c36:	mov    rax,QWORD PTR [rsp+0x50]
  409c3b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c43:	mov    QWORD PTR [rbx],rax
  409c46:	movsxd rdi,DWORD PTR [r14]
  409c49:	xor    eax,eax
  409c4b:	call   4070b0 <close@plt>
  409c50:	mov    rcx,r13
  409c53:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  409c58:	mov    rax,r12
  409c5b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c64:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c6d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c76:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c7f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c88:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c91:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c9a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409ca3:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409cac:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409cb5:	add    rsp,0x150
  409cbc:	pop    r15
  409cbe:	pop    r14
  409cc0:	pop    rsi
  409cc1:	pop    rdi
  409cc2:	pop    r13
  409cc4:	pop    r12
  409cc6:	pop    rbx
  409cc7:	ret
	...

0000000000409cd0 <__swc_fn_3464c816_000144_72996a5b>:
  409cd0:	push   rbx
  409cd1:	sub    rsp,0xe0
  409cd8:	lea    rbx,[rsp+0x8]
  409cdd:	vxorps xmm0,xmm0,xmm0
  409ce1:	vmovups XMMWORD PTR [rbx],xmm0
  409ce5:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409cea:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409cef:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  409cf4:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  409cf9:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  409cfe:	mov    DWORD PTR [rbx+0x60],0x0
  409d05:	mov    r8,rbx
  409d08:	nop    DWORD PTR [rax+rax*1+0x0]
  409d10:	mov    r9,rcx
  409d13:	movabs rcx,0xcccccccccccccccd
  409d1d:	mov    rax,r9
  409d20:	mul    rcx
  409d23:	mov    r10,rdx
  409d26:	shr    r10,0x3
  409d2a:	mov    rcx,r10
  409d2d:	imul   rdx,r10,0xa
  409d31:	sub    r9,rdx
  409d34:	mov    rdx,QWORD PTR [rip+0x9805]        # 413540 <__swc_rdata_base_3464c816+0x430>
  409d3b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d40:	mov    BYTE PTR [r8],dl
  409d43:	lea    rdx,[r8+0x1]
  409d47:	mov    r8,rdx
  409d4a:	test   r10,r10
  409d4d:	jne    409d10 <__swc_fn_3464c816_000144_72996a5b+0x40>
  409d4f:	mov    BYTE PTR [rdx],0x0
  409d52:	sub    r8,0x1
  409d56:	mov    rax,rbx
  409d59:	cmp    rax,r8
  409d5c:	jae    409d76 <__swc_fn_3464c816_000144_72996a5b+0xa6>
  409d5e:	xchg   ax,ax
  409d60:	mov    cl,BYTE PTR [r8]
  409d63:	mov    dl,BYTE PTR [rax]
  409d65:	mov    BYTE PTR [r8],dl
  409d68:	sub    r8,0x1
  409d6c:	mov    BYTE PTR [rax],cl
  409d6e:	inc    rax
  409d71:	cmp    rax,r8
  409d74:	jb     409d60 <__swc_fn_3464c816_000144_72996a5b+0x90>
  409d76:	xor    eax,eax
  409d78:	test   rbx,rbx
  409d7b:	je     409d9e <__swc_fn_3464c816_000144_72996a5b+0xce>
  409d7d:	mov    rcx,rbx
  409d80:	mov    dl,BYTE PTR [rcx]
  409d82:	test   dl,dl
  409d84:	je     409d9e <__swc_fn_3464c816_000144_72996a5b+0xce>
  409d86:	cs nop WORD PTR [rax+rax*1+0x0]
  409d90:	add    rcx,0x1
  409d94:	add    rax,0x1
  409d98:	mov    dl,BYTE PTR [rcx]
  409d9a:	test   dl,dl
  409d9c:	jne    409d90 <__swc_fn_3464c816_000144_72996a5b+0xc0>
  409d9e:	mov    QWORD PTR [rbx+0xa8],rbx
  409da5:	mov    QWORD PTR [rbx+0xb0],rax
  409dac:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409db4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409dbc:	lea    rcx,[rbx+0xb8]
  409dc3:	call   410100 <__swc_fn_3464c816_000116_035d76a1>
  409dc8:	add    rsp,0xe0
  409dcf:	pop    rbx
  409dd0:	ret
	...

0000000000409de0 <__swc_fn_3464c816_000147_32a497f3>:
  409de0:	sub    rsp,0x8
  409de4:	mov    rax,QWORD PTR [rcx+0x8]
  409de8:	mov    r8,QWORD PTR [rdx+0x8]
  409dec:	cmp    rax,r8
  409def:	je     409df8 <__swc_fn_3464c816_000147_32a497f3+0x18>
  409df1:	xor    eax,eax
  409df3:	add    rsp,0x8
  409df7:	ret
  409df8:	test   rax,rax
  409dfb:	jne    409e0c <__swc_fn_3464c816_000147_32a497f3+0x2c>
  409dfd:	test   r8,r8
  409e00:	jne    409e0c <__swc_fn_3464c816_000147_32a497f3+0x2c>
  409e02:	mov    eax,0x1
  409e07:	add    rsp,0x8
  409e0b:	ret
  409e0c:	mov    rcx,QWORD PTR [rcx]
  409e0f:	mov    rdx,QWORD PTR [rdx]
  409e12:	test   rcx,rcx
  409e15:	sete   r8b
  409e19:	test   rdx,rdx
  409e1c:	sete   r9b
  409e20:	or     r8b,r9b
  409e23:	je     409e30 <__swc_fn_3464c816_000147_32a497f3+0x50>
  409e25:	cmp    rcx,rdx
  409e28:	sete   al
  409e2b:	add    rsp,0x8
  409e2f:	ret
  409e30:	cmp    rcx,rdx
  409e33:	jne    409e3f <__swc_fn_3464c816_000147_32a497f3+0x5f>
  409e35:	mov    eax,0x1
  409e3a:	add    rsp,0x8
  409e3e:	ret
  409e3f:	mov    r8,rax
  409e42:	call   40c480 <__swc_fn_3464c816_000106_ed4b1681>
  409e47:	test   eax,eax
  409e49:	sete   al
  409e4c:	add    rsp,0x8
  409e50:	ret
	...

0000000000409e60 <__swc_fn_3464c816_000150_9e4bc402>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x977a]        # 4135f8 <__swc_rdata_base_3464c816+0x4e8>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	ret
	...

0000000000409e90 <__swc_fn_3464c816_000153_9e4bc402>:
  409e90:	vxorps xmm0,xmm0,xmm0
  409e94:	vmovups XMMWORD PTR [rcx],xmm0
  409e98:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e9d:	vxorps xmm0,xmm0,xmm0
  409ea1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409ea6:	vmovups xmm0,XMMWORD PTR [rip+0x986a]        # 413718 <__swc_rdata_base_3464c816+0x608>
  409eae:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409eb3:	mov    QWORD PTR [rcx+0x40],0x0
  409ebb:	ret
  409ebc:	add    BYTE PTR [rax],al
	...

0000000000409ec0 <__swc_fn_3464c816_000156_2745c4a5>:
  409ec0:	push   rbx
  409ec1:	sub    rsp,0x70
  409ec5:	mov    rax,QWORD PTR [rcx]
  409ec8:	mov    rbx,QWORD PTR [rcx+0x8]
  409ecc:	vxorps xmm0,xmm0,xmm0
  409ed0:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409ed6:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409edc:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409ee2:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  409ee8:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eee:	mov    QWORD PTR [rsp+0x48],rdx
  409ef3:	mov    QWORD PTR [rsp+0x50],r8
  409ef8:	mov    rcx,rax
  409efb:	lea    rdx,[rsp+0x8]
  409f00:	mov    rbx,QWORD PTR [rbx+0x18]
  409f04:	call   rbx
  409f06:	add    rsp,0x70
  409f0a:	pop    rbx
  409f0b:	ret
  409f0c:	add    BYTE PTR [rax],al
	...

0000000000409f10 <__swc_fn_3464c816_000159_d8afac28>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	mov    rbx,r8
  409f16:	mov    rsi,rcx
  409f19:	mov    rdi,rdx
  409f1c:	call   40d1a0 <__swc_fn_3464c816_000157_232ffa22>
  409f21:	vmovups xmm0,XMMWORD PTR [rbx]
  409f25:	vmovups XMMWORD PTR [rsi],xmm0
  409f29:	mov    QWORD PTR [rsi+0x18],rdi
  409f2d:	pop    rdi
  409f2e:	pop    rsi
  409f2f:	pop    rbx
  409f30:	ret
	...

0000000000409f40 <__swc_fn_3464c816_000162_60216e69>:
  409f40:	push   rbx
  409f41:	push   rsi
  409f42:	push   rdi
  409f43:	push   r12
  409f45:	push   r13
  409f47:	sub    rsp,0x50
  409f4b:	mov    rbx,rcx
  409f4e:	mov    rsi,rdx
  409f51:	vmovups xmm0,XMMWORD PTR [rip+0x98cf]        # 413828 <__swc_rdata_base_3464c816+0x718>
  409f59:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f5f:	vmovups xmm0,XMMWORD PTR [rip+0x98d1]        # 413838 <__swc_rdata_base_3464c816+0x728>
  409f67:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f6d:	vxorps xmm0,xmm0,xmm0
  409f71:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f77:	mov    rcx,rdx
  409f7a:	call   4098d0 <__swc_fn_3464c816_000138_0c00232f>
  409f7f:	mov    rdi,rax
  409f82:	test   rax,rax
  409f85:	jne    409fb6 <__swc_fn_3464c816_000162_60216e69+0x76>
  409f87:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f8d:	vmovups XMMWORD PTR [rbx],xmm0
  409f91:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f97:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f9c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fa2:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fa7:	mov    rax,rbx
  409faa:	add    rsp,0x50
  409fae:	pop    r13
  409fb0:	pop    r12
  409fb2:	pop    rdi
  409fb3:	pop    rsi
  409fb4:	pop    rbx
  409fb5:	ret
  409fb6:	mov    rcx,rdi
  409fb9:	call   411c00 <__swc_fn_3464c816_000161_b5a9d657>
  409fbe:	mov    r11,rax
  409fc1:	test   rax,rax
  409fc4:	je     409fce <__swc_fn_3464c816_000162_60216e69+0x8e>
  409fc6:	mov    al,BYTE PTR [r11+0x24]
  409fca:	test   al,al
  409fcc:	jne    409ffd <__swc_fn_3464c816_000162_60216e69+0xbd>
  409fce:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fd4:	vmovups XMMWORD PTR [rbx],xmm0
  409fd8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fde:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fe3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fe9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fee:	mov    rax,rbx
  409ff1:	add    rsp,0x50
  409ff5:	pop    r13
  409ff7:	pop    r12
  409ff9:	pop    rdi
  409ffa:	pop    rsi
  409ffb:	pop    rbx
  409ffc:	ret
  409ffd:	sub    rsi,rdi
  40a000:	mov    eax,0xffffffff
  40a005:	cmp    rsi,rax
  40a008:	jbe    40a039 <__swc_fn_3464c816_000162_60216e69+0xf9>
  40a00a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a010:	vmovups XMMWORD PTR [rbx],xmm0
  40a014:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a01a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a01f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a025:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a02a:	mov    rax,rbx
  40a02d:	add    rsp,0x50
  40a031:	pop    r13
  40a033:	pop    r12
  40a035:	pop    rdi
  40a036:	pop    rsi
  40a037:	pop    rbx
  40a038:	ret
  40a039:	mov    rdi,QWORD PTR [r11+0x10]
  40a03d:	mov    eax,DWORD PTR [r11+0x20]
  40a041:	xor    ecx,ecx
  40a043:	test   rax,rax
  40a046:	jbe    40a198 <__swc_fn_3464c816_000162_60216e69+0x258>
  40a04c:	nop    DWORD PTR [rax+0x0]
  40a050:	mov    edx,ecx
  40a052:	imul   r12,rdx,0x14
  40a056:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a05b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a060:	mov    r9d,esi
  40a063:	cmp    r9,rdx
  40a066:	jb     40a18b <__swc_fn_3464c816_000162_60216e69+0x24b>
  40a06c:	add    rdx,r8
  40a06f:	mov    r8d,esi
  40a072:	cmp    r8,rdx
  40a075:	jae    40a18b <__swc_fn_3464c816_000162_60216e69+0x24b>
  40a07b:	lea    rsi,[rsp+0x38]
  40a080:	mov    eax,DWORD PTR [rdi+0xc]
  40a083:	mov    DWORD PTR [rsp+0x38],eax
  40a087:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a08c:	mov    rcx,rdi
  40a08f:	mov    rdx,QWORD PTR [r11+0x18]
  40a093:	mov    r8,rsi
  40a096:	mov    r8d,DWORD PTR [r8]
  40a099:	mov    r9,rax
  40a09c:	lea    r10,[rsp+0x10]
  40a0a1:	call   40d200 <__swc_fn_3464c816_000160_01cbb887>
  40a0a6:	test   al,al
  40a0a8:	jne    40a0db <__swc_fn_3464c816_000162_60216e69+0x19b>
  40a0aa:	vmovups xmm0,XMMWORD PTR [rip+0x97a6]        # 413858 <__swc_rdata_base_3464c816+0x748>
  40a0b2:	vmovups XMMWORD PTR [rbx],xmm0
  40a0b6:	vmovups xmm0,XMMWORD PTR [rip+0x97aa]        # 413868 <__swc_rdata_base_3464c816+0x758>
  40a0be:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0c3:	vxorps xmm0,xmm0,xmm0
  40a0c7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0cc:	mov    rax,rbx
  40a0cf:	add    rsp,0x50
  40a0d3:	pop    r13
  40a0d5:	pop    r12
  40a0d7:	pop    rdi
  40a0d8:	pop    rsi
  40a0d9:	pop    rbx
  40a0da:	ret
  40a0db:	lea    r13,[rsp+0x3c]
  40a0e0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0e5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0e9:	test   eax,eax
  40a0eb:	je     40a13c <__swc_fn_3464c816_000162_60216e69+0x1fc>
  40a0ed:	mov    rcx,rdi
  40a0f0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0f4:	mov    r8d,DWORD PTR [rsi]
  40a0f7:	mov    rax,r13
  40a0fa:	mov    r9d,DWORD PTR [rax]
  40a0fd:	lea    r10,[rsp+0x20]
  40a102:	call   40d200 <__swc_fn_3464c816_000160_01cbb887>
  40a107:	test   al,al
  40a109:	jne    40a13c <__swc_fn_3464c816_000162_60216e69+0x1fc>
  40a10b:	vmovups xmm0,XMMWORD PTR [rip+0x9775]        # 413888 <__swc_rdata_base_3464c816+0x778>
  40a113:	vmovups XMMWORD PTR [rbx],xmm0
  40a117:	vmovups xmm0,XMMWORD PTR [rip+0x9779]        # 413898 <__swc_rdata_base_3464c816+0x788>
  40a11f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a124:	vxorps xmm0,xmm0,xmm0
  40a128:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a12d:	mov    rax,rbx
  40a130:	add    rsp,0x50
  40a134:	pop    r13
  40a136:	pop    r12
  40a138:	pop    rdi
  40a139:	pop    rsi
  40a13a:	pop    rbx
  40a13b:	ret
  40a13c:	mov    eax,0x1
  40a141:	rex mov BYTE PTR [rsp+0x8],al
  40a146:	cmp    DWORD PTR [r13+0x0],0x0
  40a14b:	je     40a15c <__swc_fn_3464c816_000162_60216e69+0x21c>
  40a14d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a153:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a158:	mov    DWORD PTR [rsp+0x30],eax
  40a15c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a162:	vmovups XMMWORD PTR [rbx],xmm0
  40a166:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a16c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a171:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a177:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a17c:	mov    rax,rbx
  40a17f:	add    rsp,0x50
  40a183:	pop    r13
  40a185:	pop    r12
  40a187:	pop    rdi
  40a188:	pop    rsi
  40a189:	pop    rbx
  40a18a:	ret
  40a18b:	add    rcx,0x1
  40a18f:	cmp    rcx,rax
  40a192:	jb     40a050 <__swc_fn_3464c816_000162_60216e69+0x110>
  40a198:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a19e:	vmovups XMMWORD PTR [rbx],xmm0
  40a1a2:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a1a8:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a1ad:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a1b3:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a1b8:	mov    rax,rbx
  40a1bb:	add    rsp,0x50
  40a1bf:	pop    r13
  40a1c1:	pop    r12
  40a1c3:	pop    rdi
  40a1c4:	pop    rsi
  40a1c5:	pop    rbx
  40a1c6:	ret
	...

000000000040a1d0 <__swc_fn_3464c816_000165_cf398896>:
  40a1d0:	sub    rsp,0x48
  40a1d4:	call   4095a0 <__swc_fn_3464c816_000123_9d2cbd72>
  40a1d9:	cmp    rax,0xffffffffffffffff
  40a1dd:	je     40a1e4 <__swc_fn_3464c816_000165_cf398896+0x14>
  40a1df:	add    rsp,0x48
  40a1e3:	ret
  40a1e4:	lea    rcx,[rip+0x96dd]        # 4138c8 <__swc_rdata_base_3464c816+0x7b8>
  40a1eb:	vmovups xmm0,XMMWORD PTR [rip+0x96e5]        # 4138d8 <__swc_rdata_base_3464c816+0x7c8>
  40a1f3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1f9:	vmovups xmm0,XMMWORD PTR [rip+0x96e7]        # 4138e8 <__swc_rdata_base_3464c816+0x7d8>
  40a201:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a207:	vmovups xmm0,XMMWORD PTR [rip+0x96e9]        # 4138f8 <__swc_rdata_base_3464c816+0x7e8>
  40a20f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a215:	lea    rdx,[rsp+0x8]
  40a21a:	mov    QWORD PTR [rsp+0x38],rax
  40a21f:	call   40c3c0 <__swc_fn_3464c816_000103_67100064>
  40a224:	mov    rax,QWORD PTR [rsp+0x38]
  40a229:	jmp    40a1df <__swc_fn_3464c816_000165_cf398896+0xf>
  40a22b:	add    BYTE PTR [rax],al
  40a22d:	add    BYTE PTR [rax],al
	...

000000000040a230 <__swc_fn_3464c816_000168_92b7d63c>:
  40a230:	push   rbx
  40a231:	push   rsi
  40a232:	sub    rsp,0x28
  40a236:	mov    rbx,rcx
  40a239:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a241:	mov    ecx,0xbf0
  40a246:	call   40bfb0 <__swc_fn_3464c816_000079_34776ded>
  40a24b:	mov    rsi,rax
  40a24e:	test   rax,rax
  40a251:	jne    40a25c <__swc_fn_3464c816_000168_92b7d63c+0x2c>
  40a253:	xor    eax,eax
  40a255:	add    rsp,0x28
  40a259:	pop    rsi
  40a25a:	pop    rbx
  40a25b:	ret
  40a25c:	vxorps xmm0,xmm0,xmm0
  40a260:	xor    eax,eax
  40a262:	cs nop WORD PTR [rax+rax*1+0x0]
  40a26c:	nop    DWORD PTR [rax+0x0]
  40a270:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a275:	add    rax,0x10
  40a279:	cmp    rax,0xbf0
  40a280:	jne    40a270 <__swc_fn_3464c816_000168_92b7d63c+0x40>
  40a282:	lea    rax,[rbx+0x1]
  40a286:	mov    QWORD PTR [rsi+0x9c0],rax
  40a28d:	mov    rcx,rbx
  40a290:	mov    rdx,rsi
  40a293:	call   40d560 <__swc_fn_3464c816_000166_f6173642>
  40a298:	test   al,al
  40a29a:	jne    40a2ad <__swc_fn_3464c816_000168_92b7d63c+0x7d>
  40a29c:	mov    rcx,rsi
  40a29f:	call   40f050 <__swc_fn_3464c816_000080_c1514492>
  40a2a4:	xor    eax,eax
  40a2a6:	add    rsp,0x28
  40a2aa:	pop    rsi
  40a2ab:	pop    rbx
  40a2ac:	ret
  40a2ad:	lea    rcx,[rsp+0x18]
  40a2b2:	call   40f5d0 <__swc_fn_3464c816_000092_8252f8c0>
  40a2b7:	mov    rax,rsi
  40a2ba:	add    rsp,0x28
  40a2be:	pop    rsi
  40a2bf:	pop    rbx
  40a2c0:	ret
	...

000000000040a2d0 <__swc_fn_3464c816_000171_c0e8acb1>:
  40a2d0:	xor    eax,eax
  40a2d2:	mov    edx,0x1
  40a2d7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2dc:	test   rax,rax
  40a2df:	jne    40a2e2 <__swc_fn_3464c816_000171_c0e8acb1+0x12>
  40a2e1:	ret
  40a2e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2ec:	nop    DWORD PTR [rax+0x0]
  40a2f0:	mov    rax,QWORD PTR [rcx]
  40a2f3:	test   rax,rax
  40a2f6:	je     40a2d0 <__swc_fn_3464c816_000171_c0e8acb1>
  40a2f8:	jmp    40a2f0 <__swc_fn_3464c816_000171_c0e8acb1+0x20>
  40a2fa:	add    BYTE PTR [rax],al
  40a2fc:	add    BYTE PTR [rax],al
	...

000000000040a300 <__swc_fn_3464c816_000174_176517f9>:
  40a300:	push   rsi
  40a301:	push   rdi
  40a302:	sub    rsp,0x38
  40a306:	mov    rsi,rcx
  40a309:	call   40d570 <__swc_fn_3464c816_000169_4579a84c>
  40a30e:	mov    rdi,rax
  40a311:	call   40cce0 <__swc_fn_3464c816_000130_c1196dfb>
  40a316:	mov    r8,rax
  40a319:	mov    rcx,rdi
  40a31c:	call   40a2d0 <__swc_fn_3464c816_000171_c0e8acb1>
  40a321:	mov    rax,QWORD PTR [rdi+0x8]
  40a325:	test   rax,rax
  40a328:	je     40a365 <__swc_fn_3464c816_000174_176517f9+0x65>
  40a32a:	nop    WORD PTR [rax+rax*1+0x0]
  40a330:	cmp    rax,rsi
  40a333:	je     40a365 <__swc_fn_3464c816_000174_176517f9+0x65>
  40a335:	mov    r9,QWORD PTR [rax]
  40a338:	cmp    QWORD PTR [rax+0x20],r8
  40a33c:	jne    40a35d <__swc_fn_3464c816_000174_176517f9+0x5d>
  40a33e:	mov    rcx,rdi
  40a341:	mov    rdx,rax
  40a344:	mov    QWORD PTR [rsp+0x28],r8
  40a349:	mov    QWORD PTR [rsp+0x30],r9
  40a34e:	call   412020 <__swc_fn_3464c816_000173_f69b1f05>
  40a353:	mov    r8,QWORD PTR [rsp+0x28]
  40a358:	mov    r9,QWORD PTR [rsp+0x30]
  40a35d:	mov    rax,r9
  40a360:	test   r9,r9
  40a363:	jne    40a330 <__swc_fn_3464c816_000174_176517f9+0x30>
  40a365:	xor    eax,eax
  40a367:	mov    QWORD PTR [rdi],rax
  40a36a:	add    rsp,0x38
  40a36e:	pop    rdi
  40a36f:	pop    rsi
  40a370:	ret
	...

000000000040a380 <__swc_fn_3464c816_000177_1ca87929>:
  40a380:	push   rdi
  40a381:	push   rsi
  40a382:	sub    rsp,0xb8
  40a389:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a38f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a395:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a39b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a3a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a3a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a3ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a3b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a3bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a3c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a3ce:	vxorps xmm0,xmm0,xmm0
  40a3d2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a3d8:	mov    edi,0x1
  40a3dd:	lea    rsi,[rsp+0x8]
  40a3e2:	xor    eax,eax
  40a3e4:	call   4070e0 <clock_gettime@plt>
  40a3e9:	vxorpd xmm0,xmm0,xmm0
  40a3ed:	mov    rax,QWORD PTR [rsp+0x8]
  40a3f2:	vcvtsi2sd xmm0,xmm0,rax
  40a3f7:	vxorpd xmm1,xmm1,xmm1
  40a3fb:	mov    rax,QWORD PTR [rsp+0x10]
  40a400:	vcvtsi2sd xmm1,xmm1,rax
  40a405:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x95ee]        # 4139fb <__swc_rdata_base_3464c816+0x8eb>
  40a40d:	vaddsd xmm0,xmm0,xmm1
  40a411:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a417:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a41d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a423:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a429:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a42f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a435:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a43b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a444:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a44d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a456:	add    rsp,0xb8
  40a45d:	pop    rsi
  40a45e:	pop    rdi
  40a45f:	ret

000000000040a460 <__swc_fn_3464c816_000001_46f18a51>:
  40a460:	vxorps xmm0,xmm0,xmm0
  40a464:	xor    eax,eax
  40a466:	cs nop WORD PTR [rax+rax*1+0x0]
  40a470:	cs nop WORD PTR [rax+rax*1+0x0]
  40a47a:	nop    WORD PTR [rax+rax*1+0x0]
  40a480:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a485:	add    rax,0x10
  40a489:	cmp    rax,0x2080
  40a490:	jne    40a480 <__swc_fn_3464c816_000001_46f18a51+0x20>
  40a492:	ret
	...

000000000040a4a0 <__swc_fn_3464c816_000004_1acc36a6>:
  40a4a0:	push   rsi
  40a4a1:	push   rdi
  40a4a2:	push   r12
  40a4a4:	push   r13
  40a4a6:	push   r14
  40a4a8:	mov    rsi,rcx
  40a4ab:	mov    edi,r10d
  40a4ae:	mov    r12,rcx
  40a4b1:	mov    r13,r9
  40a4b4:	mov    ecx,DWORD PTR [rdx+0x28]
  40a4b7:	shlx   r14d,r8d,ecx
  40a4bc:	mov    rcx,rdx
  40a4bf:	mov    edx,r8d
  40a4c2:	call   40df20 <__swc_fn_3464c816_000011_6493fbbc>
  40a4c7:	mov    rcx,rax
  40a4ca:	mov    eax,DWORD PTR [r12+0x3c]
  40a4cf:	xor    edx,edx
  40a4d1:	div    rdi
  40a4d4:	vxorps xmm0,xmm0,xmm0
  40a4d8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40a4dc:	mov    QWORD PTR [r12+0x60],0x0
  40a4e5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40a4ea:	mov    QWORD PTR [r12+0x10],rcx
  40a4ef:	imul   rax,rdi
  40a4f3:	lea    rdx,[rcx+rax*1]
  40a4f7:	mov    QWORD PTR [r12+0x18],rdx
  40a4fc:	mov    QWORD PTR [r12+0x20],rcx
  40a501:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40a506:	mov    DWORD PTR [r12+0x28],0x0
  40a50f:	mov    DWORD PTR [r12+0x68],0x0
  40a518:	mov    BYTE PTR [r12+0x39],r13b
  40a51d:	mov    BYTE PTR [r12+0x3a],r14b
  40a522:	mov    BYTE PTR [r12+0x3b],0x1
  40a528:	mov    DWORD PTR [r12+0x6c],0x0
  40a531:	mov    rcx,r12
  40a534:	mov    edx,edi
  40a536:	call   40de80 <__swc_fn_3464c816_000005_b2240b56>
  40a53b:	pop    r14
  40a53d:	pop    r13
  40a53f:	pop    r12
  40a541:	pop    rdi
  40a542:	pop    rsi
  40a543:	ret
	...

000000000040a550 <__swc_fn_3464c816_000007_614a4804>:
  40a550:	mov    r8d,0x1
  40a556:	xor    eax,eax
  40a558:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40a55e:	test   eax,eax
  40a560:	jne    40a550 <__swc_fn_3464c816_000007_614a4804>
  40a562:	ret
	...

000000000040a570 <__swc_fn_3464c816_000010_395bb04b>:
  40a570:	lea    r8,[rcx+0x60]
  40a574:	mov    rax,QWORD PTR [r8]
  40a577:	mov    r9,rax
  40a57a:	nop    WORD PTR [rax+rax*1+0x0]
  40a580:	mov    QWORD PTR [rdx],r9
  40a583:	mov    rax,r9
  40a586:	lock cmpxchg QWORD PTR [r8],rdx
  40a58b:	cmp    rax,r9
  40a58e:	jne    40a5f7 <__swc_fn_3464c816_000010_395bb04b+0x87>
  40a590:	mov    eax,DWORD PTR [rcx+0x6c]
  40a593:	test   eax,eax
  40a595:	je     40a5f6 <__swc_fn_3464c816_000010_395bb04b+0x86>
  40a597:	lea    rdx,[rcx+0x70]
  40a59b:	mov    r9d,0x1
  40a5a1:	xor    eax,eax
  40a5a3:	lock cmpxchg DWORD PTR [rdx],r9d
  40a5a8:	test   eax,eax
  40a5aa:	jne    40a5f6 <__swc_fn_3464c816_000010_395bb04b+0x86>
  40a5ac:	mov    rax,rcx
  40a5af:	and    rax,0xffffffffffc00000
  40a5b6:	mov    rax,QWORD PTR [rax+0x8]
  40a5ba:	test   rax,rax
  40a5bd:	jne    40a5c5 <__swc_fn_3464c816_000010_395bb04b+0x55>
  40a5bf:	xor    eax,eax
  40a5c1:	xchg   DWORD PTR [rdx],eax
  40a5c3:	jmp    40a5f6 <__swc_fn_3464c816_000010_395bb04b+0x86>
  40a5c5:	lea    rdx,[rax+0x2a80]
  40a5cc:	mov    rax,QWORD PTR [rdx]
  40a5cf:	mov    r8,rax
  40a5d2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5dc:	nop    DWORD PTR [rax+0x0]
  40a5e0:	mov    QWORD PTR [rcx+0x78],r8
  40a5e4:	mov    rax,r8
  40a5e7:	lock cmpxchg QWORD PTR [rdx],rcx
  40a5ec:	cmp    rax,r8
  40a5ef:	je     40a5f6 <__swc_fn_3464c816_000010_395bb04b+0x86>
  40a5f1:	mov    r8,rax
  40a5f4:	jmp    40a5e0 <__swc_fn_3464c816_000010_395bb04b+0x70>
  40a5f6:	ret
  40a5f7:	mov    r9,rax
  40a5fa:	jmp    40a580 <__swc_fn_3464c816_000010_395bb04b+0x10>
	...

000000000040a600 <__swc_fn_3464c816_000013_9ba72deb>:
  40a600:	push   rsi
  40a601:	push   rdi
  40a602:	push   r12
  40a604:	push   r13
  40a606:	push   r14
  40a608:	push   r15
  40a60a:	push   rbx
  40a60b:	sub    rsp,0x30
  40a60f:	mov    QWORD PTR [rsp+0x18],r8
  40a614:	mov    rsi,rcx
  40a617:	mov    rdi,rdx
  40a61a:	mov    rdx,QWORD PTR [rsi+0x40]
  40a61e:	xchg   ax,ax
  40a620:	mov    rax,rdx
  40a623:	not    rax
  40a626:	and    rax,QWORD PTR [rsi+0x20]
  40a62a:	test   rax,rax
  40a62d:	jne    40a641 <__swc_fn_3464c816_000013_9ba72deb+0x41>
  40a62f:	xor    eax,eax
  40a631:	add    rsp,0x30
  40a635:	pop    rbx
  40a636:	pop    r15
  40a638:	pop    r14
  40a63a:	pop    r13
  40a63c:	pop    r12
  40a63e:	pop    rdi
  40a63f:	pop    rsi
  40a640:	ret
  40a641:	xor    ecx,ecx
  40a643:	tzcnt  rcx,rax
  40a648:	lea    r12,[rsp+0x8]
  40a64d:	mov    DWORD PTR [rsp+0x8],ecx
  40a651:	mov    r13d,0x1
  40a657:	shl    r13,cl
  40a65a:	mov    rcx,rdx
  40a65d:	or     rcx,r13
  40a660:	mov    rax,rdx
  40a663:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40a669:	cmp    rax,rdx
  40a66c:	je     40a673 <__swc_fn_3464c816_000013_9ba72deb+0x73>
  40a66e:	mov    rdx,rax
  40a671:	jmp    40a620 <__swc_fn_3464c816_000013_9ba72deb+0x20>
  40a673:	mov    eax,DWORD PTR [r12]
  40a677:	shl    rax,0x4
  40a67b:	lea    r14,[rsi+rax*8+0x80]
  40a683:	mov    rcx,rsi
  40a686:	mov    rax,r12
  40a689:	mov    edx,DWORD PTR [rax]
  40a68b:	call   40df20 <__swc_fn_3464c816_000011_6493fbbc>
  40a690:	mov    r15,rax
  40a693:	mov    rcx,rsi
  40a696:	mov    rdx,r13
  40a699:	call   40e080 <__swc_fn_3464c816_000017_4df2d1a0>
  40a69e:	test   al,al
  40a6a0:	je     40a6d8 <__swc_fn_3464c816_000013_9ba72deb+0xd8>
  40a6a2:	mov    ecx,DWORD PTR [r14+0x3c]
  40a6a6:	lea    rdx,[rip+0x199ab]        # 424058 <__swc_bss_base_3464c816+0x18>
  40a6ad:	mov    r8,QWORD PTR [rip+0x199a4]        # 424058 <__swc_bss_base_3464c816+0x18>
  40a6b4:	cs nop WORD PTR [rax+rax*1+0x0]
  40a6be:	xchg   ax,ax
  40a6c0:	mov    r9,r8
  40a6c3:	sub    r9,rcx
  40a6c6:	mov    rax,r8
  40a6c9:	lock cmpxchg QWORD PTR [rdx],r9
  40a6ce:	cmp    rax,r8
  40a6d1:	je     40a739 <__swc_fn_3464c816_000013_9ba72deb+0x139>
  40a6d3:	mov    r8,rax
  40a6d6:	jmp    40a6c0 <__swc_fn_3464c816_000013_9ba72deb+0xc0>
  40a6d8:	mov    rcx,rsi
  40a6db:	mov    rax,r12
  40a6de:	mov    edx,DWORD PTR [rax]
  40a6e0:	call   407450 <__swc_fn_3464c816_000012_c7df5d22>
  40a6e5:	mov    rcx,r15
  40a6e8:	and    rcx,0xffffffffffff0000
  40a6ef:	lea    rcx,[rcx+0x10000]
  40a6f6:	mov    rbx,rax
  40a6f9:	cmp    rax,rcx
  40a6fc:	cmova  rbx,rcx
  40a700:	mov    rax,rbx
  40a703:	sub    rax,r15
  40a706:	mov    rcx,r15
  40a709:	mov    rdx,rax
  40a70c:	call   4072a0 <__swc_fn_3464c816_000003_7ab4792e>
  40a711:	test   al,al
  40a713:	jne    40a732 <__swc_fn_3464c816_000013_9ba72deb+0x132>
  40a715:	mov    rcx,rsi
  40a718:	mov    rdx,r13
  40a71b:	call   407600 <__swc_fn_3464c816_000018_7d1e8a10>
  40a720:	xor    eax,eax
  40a722:	add    rsp,0x30
  40a726:	pop    rbx
  40a727:	pop    r15
  40a729:	pop    r14
  40a72b:	pop    r13
  40a72d:	pop    r12
  40a72f:	pop    rdi
  40a730:	pop    rsi
  40a731:	ret
  40a732:	sub    rbx,r15
  40a735:	mov    DWORD PTR [r14+0x3c],ebx
  40a739:	mov    rcx,r14
  40a73c:	mov    rdx,rsi
  40a73f:	mov    r8d,DWORD PTR [r12]
  40a743:	mov    r9d,edi
  40a746:	mov    rbx,QWORD PTR [rsp+0x18]
  40a74b:	mov    r10d,ebx
  40a74e:	call   40a4a0 <__swc_fn_3464c816_000004_1acc36a6>
  40a753:	mov    rax,r14
  40a756:	add    rsp,0x30
  40a75a:	pop    rbx
  40a75b:	pop    r15
  40a75d:	pop    r14
  40a75f:	pop    r13
  40a761:	pop    r12
  40a763:	pop    rdi
  40a764:	pop    rsi
  40a765:	ret
	...

000000000040a770 <__swc_fn_3464c816_000016_4b207b58>:
  40a770:	mov    r8,QWORD PTR [rcx+0x48]
  40a774:	cs nop WORD PTR [rax+rax*1+0x0]
  40a77e:	xchg   ax,ax
  40a780:	mov    r9,r8
  40a783:	or     r9,rdx
  40a786:	mov    rax,r8
  40a789:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40a78f:	cmp    rax,r8
  40a792:	jne    40a795 <__swc_fn_3464c816_000016_4b207b58+0x25>
  40a794:	ret
  40a795:	mov    r8,rax
  40a798:	jmp    40a780 <__swc_fn_3464c816_000016_4b207b58+0x10>
  40a79a:	add    BYTE PTR [rax],al
  40a79c:	add    BYTE PTR [rax],al
	...

000000000040a7a0 <__swc_fn_3464c816_000019_2cc1532c>:
  40a7a0:	push   rsi
  40a7a1:	push   rdi
  40a7a2:	push   r12
  40a7a4:	mov    rsi,rcx
  40a7a7:	xor    edi,edi
  40a7a9:	lea    r12,[rip+0x198b8]        # 424068 <__swc_bss_base_3464c816+0x28>
  40a7b0:	mov    eax,DWORD PTR [r12]
  40a7b4:	xor    ecx,ecx
  40a7b6:	test   rax,rax
  40a7b9:	jbe    40a7f4 <__swc_fn_3464c816_000019_2cc1532c+0x54>
  40a7bb:	nop    DWORD PTR [rax+rax*1+0x0]
  40a7c0:	lea    rdx,[rip+0x198a9]        # 424070 <__swc_bss_base_3464c816+0x30>
  40a7c7:	mov    r8d,ecx
  40a7ca:	lea    r8,[r8+r8*2]
  40a7ce:	lea    r8,[rdx+r8*8]
  40a7d2:	mov    rdx,QWORD PTR [r8+0x10]
  40a7d6:	add    rdx,0x400000
  40a7dd:	cmp    rdx,0x40000000
  40a7e4:	ja     40a7eb <__swc_fn_3464c816_000019_2cc1532c+0x4b>
  40a7e6:	mov    rdi,r8
  40a7e9:	jmp    40a7f4 <__swc_fn_3464c816_000019_2cc1532c+0x54>
  40a7eb:	add    rcx,0x1
  40a7ef:	cmp    rcx,rax
  40a7f2:	jb     40a7c0 <__swc_fn_3464c816_000019_2cc1532c+0x20>
  40a7f4:	test   rdi,rdi
  40a7f7:	jne    40a883 <__swc_fn_3464c816_000019_2cc1532c+0xe3>
  40a7fd:	cmp    DWORD PTR [r12],0x10
  40a802:	jae    40a86b <__swc_fn_3464c816_000019_2cc1532c+0xcb>
  40a804:	mov    ecx,0x40400000
  40a809:	call   40de40 <__swc_fn_3464c816_000002_884bb5c0>
  40a80e:	test   rax,rax
  40a811:	je     40a86b <__swc_fn_3464c816_000019_2cc1532c+0xcb>
  40a813:	lea    rcx,[rip+0x19856]        # 424070 <__swc_bss_base_3464c816+0x30>
  40a81a:	mov    edx,DWORD PTR [r12]
  40a81e:	lea    rdx,[rdx+rdx*2]
  40a822:	lea    rdx,[rcx+rdx*8]
  40a826:	mov    QWORD PTR [rdx],rax
  40a829:	lea    rax,[rax+0x3fffff]
  40a830:	and    rax,0xffffffffffc00000
  40a837:	mov    QWORD PTR [rdx+0x8],rax
  40a83b:	mov    QWORD PTR [rdx+0x10],0x0
  40a843:	mov    edx,DWORD PTR [rip+0x1981f]        # 424068 <__swc_bss_base_3464c816+0x28>
  40a849:	nop    DWORD PTR [rax+0x0]
  40a850:	lea    r9d,[rdx+0x1]
  40a854:	mov    rax,rdx
  40a857:	lock cmpxchg DWORD PTR [r12],r9d
  40a85d:	mov    r8d,eax
  40a860:	cmp    eax,edx
  40a862:	je     40a872 <__swc_fn_3464c816_000019_2cc1532c+0xd2>
  40a864:	mov    rdx,r8
  40a867:	jmp    40a850 <__swc_fn_3464c816_000019_2cc1532c+0xb0>
  40a869:	jmp    40a872 <__swc_fn_3464c816_000019_2cc1532c+0xd2>
  40a86b:	xor    eax,eax
  40a86d:	pop    r12
  40a86f:	pop    rdi
  40a870:	pop    rsi
  40a871:	ret
  40a872:	mov    eax,DWORD PTR [rip+0x197f0]        # 424068 <__swc_bss_base_3464c816+0x28>
  40a878:	sub    eax,0x1
  40a87b:	lea    rdi,[rax+rax*2]
  40a87f:	lea    rdi,[rcx+rdi*8]
  40a883:	mov    r12,QWORD PTR [rdi+0x8]
  40a887:	add    r12,QWORD PTR [rdi+0x10]
  40a88b:	mov    rcx,r12
  40a88e:	mov    edx,0x3000
  40a893:	call   4072a0 <__swc_fn_3464c816_000003_7ab4792e>
  40a898:	test   al,al
  40a89a:	jne    40a8a3 <__swc_fn_3464c816_000019_2cc1532c+0x103>
  40a89c:	xor    eax,eax
  40a89e:	pop    r12
  40a8a0:	pop    rdi
  40a8a1:	pop    rsi
  40a8a2:	ret
  40a8a3:	vxorps xmm0,xmm0,xmm0
  40a8a7:	xor    eax,eax
  40a8a9:	cs nop WORD PTR [rax+rax*1+0x0]
  40a8b3:	cs nop WORD PTR [rax+rax*1+0x0]
  40a8bd:	nop    DWORD PTR [rax]
  40a8c0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40a8c6:	add    rax,0x10
  40a8ca:	cmp    rax,0x3000
  40a8d1:	jne    40a8c0 <__swc_fn_3464c816_000019_2cc1532c+0x120>
  40a8d3:	mov    DWORD PTR [r12+0x28],esi
  40a8d8:	mov    eax,0x40
  40a8dd:	mov    ecx,esi
  40a8df:	shr    eax,cl
  40a8e1:	mov    DWORD PTR [r12+0x2c],eax
  40a8e6:	cmp    DWORD PTR [r12+0x2c],0x40
  40a8ec:	jb     40a8f7 <__swc_fn_3464c816_000019_2cc1532c+0x157>
  40a8ee:	mov    rax,0xffffffffffffffff
  40a8f5:	jmp    40a907 <__swc_fn_3464c816_000019_2cc1532c+0x167>
  40a8f7:	mov    eax,0x1
  40a8fc:	mov    ecx,DWORD PTR [r12+0x2c]
  40a901:	shl    rax,cl
  40a904:	dec    rax
  40a907:	mov    QWORD PTR [r12+0x20],rax
  40a90c:	mov    DWORD PTR [r12],0x4e540001
  40a914:	mov    DWORD PTR [r12+0x4],0x53474d45
  40a91d:	add    QWORD PTR [rdi+0x10],0x400000
  40a925:	mov    rax,r12
  40a928:	pop    r12
  40a92a:	pop    rdi
  40a92b:	pop    rsi
  40a92c:	ret
  40a92d:	add    BYTE PTR [rax],al
	...

000000000040a930 <__swc_fn_3464c816_000022_3a2e2048>:
  40a930:	mov    eax,0x1
  40a935:	mov    edx,DWORD PTR [rip+0x1972d]        # 424068 <__swc_bss_base_3464c816+0x28>
  40a93b:	cmp    eax,edx
  40a93d:	jae    40a98b <__swc_fn_3464c816_000022_3a2e2048+0x5b>
  40a93f:	nop
  40a940:	lea    r8,[rip+0x19729]        # 424070 <__swc_bss_base_3464c816+0x30>
  40a947:	lea    r9,[rax+rax*2]
  40a94b:	lea    r9,[r8+r9*8]
  40a94f:	mov    r8,rcx
  40a952:	sub    r8,QWORD PTR [r9+0x8]
  40a956:	mov    r9,QWORD PTR [r9+0x10]
  40a95a:	cmp    r8,r9
  40a95d:	jae    40a985 <__swc_fn_3464c816_000022_3a2e2048+0x55>
  40a95f:	mov    rax,rcx
  40a962:	and    rax,0xffffffffffc00000
  40a969:	shr    rcx,0x10
  40a96d:	and    ecx,0x3f
  40a970:	mov    edx,DWORD PTR [rax+0x28]
  40a973:	shrx   ecx,ecx,edx
  40a978:	shl    rcx,0x4
  40a97c:	lea    rax,[rax+rcx*8+0x80]
  40a984:	ret
  40a985:	inc    eax
  40a987:	cmp    eax,edx
  40a989:	jb     40a940 <__swc_fn_3464c816_000022_3a2e2048+0x10>
  40a98b:	xor    eax,eax
  40a98d:	ret
	...

000000000040a990 <__swc_fn_3464c816_000025_4aca8b9e>:
  40a990:	vxorps xmm0,xmm0,xmm0
  40a994:	vmovups XMMWORD PTR [rcx],xmm0
  40a998:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a99d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a9a2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a9a7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a9ac:	mov    QWORD PTR [rcx+0x50],0x0
  40a9b4:	ret
	...

000000000040a9c0 <__swc_fn_3464c816_000028_4aca8b9e>:
  40a9c0:	vxorps xmm0,xmm0,xmm0
  40a9c4:	xor    eax,eax
  40a9c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9d0:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9da:	nop    WORD PTR [rax+rax*1+0x0]
  40a9e0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a9e5:	add    rax,0x10
  40a9e9:	cmp    rax,0x9b0
  40a9f0:	jne    40a9e0 <__swc_fn_3464c816_000028_4aca8b9e+0x20>
  40a9f2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40a9fd:	ret
	...

000000000040aa00 <__swc_fn_3464c816_000031_90860ff2>:
  40aa00:	push   rsi
  40aa01:	push   rdi
  40aa02:	sub    rsp,0x8
  40aa06:	lea    rsi,[rip+0x175fb]        # 422008 <__swc_data_base_3464c816+0x8>
  40aa0d:	mov    rax,QWORD PTR [rsi]
  40aa10:	mov    ecx,0xffffffff
  40aa15:	cmp    rax,rcx
  40aa18:	je     40aa21 <__swc_fn_3464c816_000031_90860ff2+0x21>
  40aa1a:	add    rsp,0x8
  40aa1e:	pop    rdi
  40aa1f:	pop    rsi
  40aa20:	ret
  40aa21:	mov    rcx,QWORD PTR [rip+0x8658]        # 413080 <__swc_fn_3464c816_000176_2744b483+0xfe0>
  40aa28:	call   409670 <__swc_fn_3464c816_000126_102fe7b9>
  40aa2d:	mov    rcx,rax
  40aa30:	mov    eax,0xffffffff
  40aa35:	lock cmpxchg QWORD PTR [rsi],rcx
  40aa3a:	mov    rdi,rax
  40aa3d:	mov    eax,0xffffffff
  40aa42:	cmp    rdi,rax
  40aa45:	je     40aa56 <__swc_fn_3464c816_000031_90860ff2+0x56>
  40aa47:	call   40cc30 <__swc_fn_3464c816_000127_8dffa290>
  40aa4c:	mov    rax,rdi
  40aa4f:	add    rsp,0x8
  40aa53:	pop    rdi
  40aa54:	pop    rsi
  40aa55:	ret
  40aa56:	mov    rax,rcx
  40aa59:	add    rsp,0x8
  40aa5d:	pop    rdi
  40aa5e:	pop    rsi
  40aa5f:	ret

000000000040aa60 <__swc_fn_3464c816_000034_25f19556>:
  40aa60:	sub    rsp,0x8
  40aa64:	vxorps xmm0,xmm0,xmm0
  40aa68:	xor    eax,eax
  40aa6a:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa74:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa7e:	xchg   ax,ax
  40aa80:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40aa85:	add    rax,0x10
  40aa89:	cmp    rax,0x2b00
  40aa90:	jne    40aa80 <__swc_fn_3464c816_000034_25f19556+0x20>
  40aa92:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40aa9c:	xor    al,al
  40aa9e:	mov    rdx,rax
  40aaa1:	xor    al,al
  40aaa3:	mov    r8,rax
  40aaa6:	xor    al,al
  40aaa8:	mov    r9,rax
  40aaab:	xor    al,al
  40aaad:	mov    r10,rax
  40aab0:	xor    al,al
  40aab2:	mov    r11,rax
  40aab5:	call   40e2b0 <__swc_fn_3464c816_000035_95622a2b>
  40aaba:	add    rsp,0x8
  40aabe:	ret
	...

000000000040aac0 <__swc_fn_3464c816_000037_b4982903>:
  40aac0:	push   rsi
  40aac1:	push   rdi
  40aac2:	push   r12
  40aac4:	mov    rsi,r8
  40aac7:	mov    rdi,rdx
  40aaca:	mov    rcx,rdx
  40aacd:	call   40de40 <__swc_fn_3464c816_000002_884bb5c0>
  40aad2:	mov    r12,rax
  40aad5:	test   rax,rax
  40aad8:	jne    40aae1 <__swc_fn_3464c816_000037_b4982903+0x21>
  40aada:	xor    eax,eax
  40aadc:	pop    r12
  40aade:	pop    rdi
  40aadf:	pop    rsi
  40aae0:	ret
  40aae1:	mov    rcx,r12
  40aae4:	mov    rdx,rsi
  40aae7:	call   4072a0 <__swc_fn_3464c816_000003_7ab4792e>
  40aaec:	test   al,al
  40aaee:	jne    40ab02 <__swc_fn_3464c816_000037_b4982903+0x42>
  40aaf0:	mov    rcx,r12
  40aaf3:	mov    rdx,rdi
  40aaf6:	call   4100e0 <__swc_fn_3464c816_000113_49b378a9>
  40aafb:	xor    eax,eax
  40aafd:	pop    r12
  40aaff:	pop    rdi
  40ab00:	pop    rsi
  40ab01:	ret
  40ab02:	mov    rax,r12
  40ab05:	pop    r12
  40ab07:	pop    rdi
  40ab08:	pop    rsi
  40ab09:	ret
	...

000000000040ab20 <__swc_fn_3464c816_000040_6895916d>:
  40ab20:	push   rsi
  40ab21:	push   rdi
  40ab22:	push   r12
  40ab24:	mov    rsi,rcx
  40ab27:	mov    edx,0x9b8
  40ab2c:	call   40e320 <__swc_fn_3464c816_000038_788ceb38>
  40ab31:	mov    rdi,rax
  40ab34:	test   rax,rax
  40ab37:	jne    40ab40 <__swc_fn_3464c816_000040_6895916d+0x20>
  40ab39:	xor    eax,eax
  40ab3b:	pop    r12
  40ab3d:	pop    rdi
  40ab3e:	pop    rsi
  40ab3f:	ret
  40ab40:	vxorps xmm0,xmm0,xmm0
  40ab44:	xor    eax,eax
  40ab46:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab50:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab5a:	nop    WORD PTR [rax+rax*1+0x0]
  40ab60:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40ab65:	add    rax,0x10
  40ab69:	cmp    rax,0x9b0
  40ab70:	jne    40ab60 <__swc_fn_3464c816_000040_6895916d+0x40>
  40ab72:	mov    QWORD PTR [rdi+0x9b0],0x0
  40ab7d:	mov    QWORD PTR [rdi],rsi
  40ab80:	call   40cce0 <__swc_fn_3464c816_000130_c1196dfb>
  40ab85:	mov    QWORD PTR [rdi+0x18],rax
  40ab89:	lea    r12,[rsi+0x10]
  40ab8d:	mov    rcx,r12
  40ab90:	call   4098c0 <__swc_fn_3464c816_000135_e3032dc2>
  40ab95:	mov    rax,QWORD PTR [rsi+0x20]
  40ab99:	mov    QWORD PTR [rdi+0x8],rax
  40ab9d:	mov    rax,QWORD PTR [rsi+0x20]
  40aba1:	test   rax,rax
  40aba4:	je     40abaa <__swc_fn_3464c816_000040_6895916d+0x8a>
  40aba6:	mov    QWORD PTR [rax+0x10],rdi
  40abaa:	mov    QWORD PTR [rsi+0x20],rdi
  40abae:	mov    rcx,r12
  40abb1:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  40abb6:	mov    rax,rdi
  40abb9:	pop    r12
  40abbb:	pop    rdi
  40abbc:	pop    rsi
  40abbd:	ret
	...

000000000040abc0 <__swc_fn_3464c816_000043_957e4917>:
  40abc0:	mov    rax,QWORD PTR [rdx+0x10]
  40abc4:	test   rax,rax
  40abc7:	je     40abd3 <__swc_fn_3464c816_000043_957e4917+0x13>
  40abc9:	mov    rcx,QWORD PTR [rdx+0x8]
  40abcd:	mov    QWORD PTR [rax+0x8],rcx
  40abd1:	jmp    40abdb <__swc_fn_3464c816_000043_957e4917+0x1b>
  40abd3:	mov    rax,QWORD PTR [rdx+0x8]
  40abd7:	mov    QWORD PTR [rcx+0x20],rax
  40abdb:	mov    rax,QWORD PTR [rdx+0x8]
  40abdf:	test   rax,rax
  40abe2:	je     40abec <__swc_fn_3464c816_000043_957e4917+0x2c>
  40abe4:	mov    rcx,QWORD PTR [rdx+0x10]
  40abe8:	mov    QWORD PTR [rax+0x10],rcx
  40abec:	vxorps xmm0,xmm0,xmm0
  40abf0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40abf5:	ret
	...

000000000040ac00 <__swc_fn_3464c816_000046_88f44774>:
  40ac00:	sub    rsp,0x8
  40ac04:	mov    r9,r8
  40ac07:	mov    r10,rdx
  40ac0a:	call   40e3d0 <__swc_fn_3464c816_000044_9c2ade9b>
  40ac0f:	mov    eax,0x1
  40ac14:	xchg   DWORD PTR [r9+0x6c],eax
  40ac18:	mov    rax,QWORD PTR [r9+0x60]
  40ac1c:	test   rax,rax
  40ac1f:	je     40ac63 <__swc_fn_3464c816_000046_88f44774+0x63>
  40ac21:	xor    eax,eax
  40ac23:	xchg   DWORD PTR [r9+0x6c],eax
  40ac27:	movzx  eax,BYTE PTR [r9+0x39]
  40ac2c:	lea    rax,[rax+rax*4]
  40ac30:	lea    rax,[r10+rax*8+0x28]
  40ac35:	mov    QWORD PTR [r9+0x50],0x0
  40ac3d:	mov    rcx,QWORD PTR [rax+0x8]
  40ac41:	mov    QWORD PTR [r9+0x48],rcx
  40ac45:	mov    rcx,QWORD PTR [rax+0x8]
  40ac49:	test   rcx,rcx
  40ac4c:	je     40ac54 <__swc_fn_3464c816_000046_88f44774+0x54>
  40ac4e:	mov    QWORD PTR [rcx+0x50],r9
  40ac52:	jmp    40ac58 <__swc_fn_3464c816_000046_88f44774+0x58>
  40ac54:	mov    QWORD PTR [rax+0x10],r9
  40ac58:	mov    QWORD PTR [rax+0x8],r9
  40ac5c:	xor    eax,eax
  40ac5e:	add    rsp,0x8
  40ac62:	ret
  40ac63:	movzx  eax,BYTE PTR [r9+0x39]
  40ac68:	lea    rax,[rax+rax*4]
  40ac6c:	lea    rax,[r10+rax*8+0x28]
  40ac71:	mov    QWORD PTR [r9+0x50],0x0
  40ac79:	mov    rcx,QWORD PTR [rax+0x18]
  40ac7d:	mov    QWORD PTR [r9+0x48],rcx
  40ac81:	mov    rcx,QWORD PTR [rax+0x18]
  40ac85:	test   rcx,rcx
  40ac88:	je     40ac8e <__swc_fn_3464c816_000046_88f44774+0x8e>
  40ac8a:	mov    QWORD PTR [rcx+0x50],r9
  40ac8e:	mov    QWORD PTR [rax+0x18],r9
  40ac92:	mov    eax,0x1
  40ac97:	add    rsp,0x8
  40ac9b:	ret
  40ac9c:	add    BYTE PTR [rax],al
	...

000000000040aca0 <__swc_fn_3464c816_000049_2ff013cc>:
  40aca0:	push   r12
  40aca2:	push   r13
  40aca4:	push   rdi
  40aca5:	push   rsi
  40aca6:	push   r14
  40aca8:	push   r15
  40acaa:	sub    rsp,0x178
  40acb1:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40acba:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40acc3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40accc:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40acd5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40acde:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40ace7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40acf0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40acf9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40ad02:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40ad0b:	mov    r12,rcx
  40ad0e:	lea    rax,[rip+0x194eb]        # 424200 <__swc_bss_base_3464c816+0x1c0>
  40ad15:	mov    rcx,QWORD PTR [rax]
  40ad18:	mov    r13,rcx
  40ad1b:	test   rcx,rcx
  40ad1e:	jne    40ad2e <__swc_fn_3464c816_000049_2ff013cc+0x8e>
  40ad20:	mov    r13d,0x1dcd6500
  40ad26:	mov    ecx,0x1dcd6500
  40ad2b:	xchg   QWORD PTR [rax],rcx
  40ad2e:	lea    rax,[rip+0x172cb]        # 422000 <__swc_data_base_3464c816>
  40ad35:	mov    rax,QWORD PTR [rax]
  40ad38:	cmp    rax,0xffffffffffffffff
  40ad3c:	je     40ad4b <__swc_fn_3464c816_000049_2ff013cc+0xab>
  40ad3e:	mov    eax,eax
  40ad40:	mov    edi,eax
  40ad42:	xor    eax,eax
  40ad44:	call   407000 <pthread_getspecific@plt>
  40ad49:	jmp    40ad4d <__swc_fn_3464c816_000049_2ff013cc+0xad>
  40ad4b:	xor    eax,eax
  40ad4d:	test   rax,rax
  40ad50:	jne    40ad5f <__swc_fn_3464c816_000049_2ff013cc+0xbf>
  40ad52:	call   40aa00 <__swc_fn_3464c816_000031_90860ff2>
  40ad57:	mov    rcx,rax
  40ad5a:	call   410440 <__swc_fn_3464c816_000128_41c3251c>
  40ad5f:	test   rax,rax
  40ad62:	je     40ad74 <__swc_fn_3464c816_000049_2ff013cc+0xd4>
  40ad64:	cmp    QWORD PTR [rax],r12
  40ad67:	jne    40ad74 <__swc_fn_3464c816_000049_2ff013cc+0xd4>
  40ad69:	cmp    DWORD PTR [rax+0x20],0x0
  40ad6d:	jne    40ad74 <__swc_fn_3464c816_000049_2ff013cc+0xd4>
  40ad6f:	mov    rsi,rax
  40ad72:	jmp    40ad76 <__swc_fn_3464c816_000049_2ff013cc+0xd6>
  40ad74:	xor    esi,esi
  40ad76:	lea    rdi,[r12+0x2a88]
  40ad7e:	mov    r14,QWORD PTR [rdi]
  40ad81:	test   r14,r14
  40ad84:	jne    40add3 <__swc_fn_3464c816_000049_2ff013cc+0x133>
  40ad86:	lea    rax,[rip+0x192cb]        # 424058 <__swc_bss_base_3464c816+0x18>
  40ad8d:	mov    rax,QWORD PTR [rax]
  40ad90:	test   rax,rax
  40ad93:	setne  al
  40ad96:	jne    40adba <__swc_fn_3464c816_000049_2ff013cc+0x11a>
  40ad98:	mov    rax,QWORD PTR [r12+0x2a70]
  40ada0:	test   rax,rax
  40ada3:	setne  al
  40ada6:	jne    40adba <__swc_fn_3464c816_000049_2ff013cc+0x11a>
  40ada8:	test   rsi,rsi
  40adab:	setne  al
  40adae:	je     40adba <__swc_fn_3464c816_000049_2ff013cc+0x11a>
  40adb0:	cmp    DWORD PTR [rsi+0x730],0x0
  40adb7:	setne  al
  40adba:	test   al,al
  40adbc:	je     40adce <__swc_fn_3464c816_000049_2ff013cc+0x12e>
  40adbe:	call   4104f0 <__swc_fn_3464c816_000131_944f555b>
  40adc3:	lea    rcx,[rax+r13*1]
  40adc7:	xor    eax,eax
  40adc9:	lock cmpxchg QWORD PTR [rdi],rcx
  40adce:	jmp    40aed3 <__swc_fn_3464c816_000049_2ff013cc+0x233>
  40add3:	call   4104f0 <__swc_fn_3464c816_000131_944f555b>
  40add8:	mov    r15,rax
  40addb:	cmp    rax,r14
  40adde:	jb     40adef <__swc_fn_3464c816_000049_2ff013cc+0x14f>
  40ade0:	xor    ecx,ecx
  40ade2:	mov    rax,r14
  40ade5:	lock cmpxchg QWORD PTR [rdi],rcx
  40adea:	cmp    rax,r14
  40aded:	je     40adf4 <__swc_fn_3464c816_000049_2ff013cc+0x154>
  40adef:	jmp    40aed3 <__swc_fn_3464c816_000049_2ff013cc+0x233>
  40adf4:	test   rsi,rsi
  40adf7:	je     40ae12 <__swc_fn_3464c816_000049_2ff013cc+0x172>
  40adf9:	cmp    r15,r13
  40adfc:	jb     40ae12 <__swc_fn_3464c816_000049_2ff013cc+0x172>
  40adfe:	mov    rax,r15
  40ae01:	sub    rax,r13
  40ae04:	mov    rcx,r12
  40ae07:	mov    rdx,rsi
  40ae0a:	mov    r8,rax
  40ae0d:	call   40e810 <__swc_fn_3464c816_000059_3ca3ac64>
  40ae12:	lea    rsi,[r12+0x10]
  40ae17:	mov    rcx,rsi
  40ae1a:	call   4098c0 <__swc_fn_3464c816_000135_e3032dc2>
  40ae1f:	mov    rax,QWORD PTR [r12+0x18]
  40ae24:	mov    rdi,rax
  40ae27:	test   rdi,rdi
  40ae2a:	je     40ae54 <__swc_fn_3464c816_000049_2ff013cc+0x1b4>
  40ae2c:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae36:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae40:	mov    rcx,rdi
  40ae43:	call   407470 <__swc_fn_3464c816_000015_07eb9884>
  40ae48:	mov    rax,QWORD PTR [rdi+0x10]
  40ae4c:	mov    rdi,rax
  40ae4f:	test   rax,rax
  40ae52:	jne    40ae40 <__swc_fn_3464c816_000049_2ff013cc+0x1a0>
  40ae54:	mov    rcx,rsi
  40ae57:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  40ae5c:	mov    rcx,r12
  40ae5f:	call   4098c0 <__swc_fn_3464c816_000135_e3032dc2>
  40ae64:	xor    esi,esi
  40ae66:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae70:	mov    rax,QWORD PTR [r12+0x2a70]
  40ae78:	cmp    rsi,rax
  40ae7b:	jae    40aecb <__swc_fn_3464c816_000049_2ff013cc+0x22b>
  40ae7d:	lea    rax,[rsi+rsi*4]
  40ae81:	lea    rax,[r12+rax*8+0x268]
  40ae89:	mov    r8,QWORD PTR [rax]
  40ae8c:	mov    r9,QWORD PTR [rax+0x8]
  40ae90:	mov    r10,QWORD PTR [rax+0x10]
  40ae94:	mov    rax,QWORD PTR [rax+0x20]
  40ae98:	cmp    rax,r15
  40ae9b:	jae    40aea8 <__swc_fn_3464c816_000049_2ff013cc+0x208>
  40ae9d:	mov    rcx,r15
  40aea0:	sub    rcx,rax
  40aea3:	cmp    rcx,r13
  40aea6:	jae    40aead <__swc_fn_3464c816_000049_2ff013cc+0x20d>
  40aea8:	inc    rsi
  40aeab:	jmp    40ae70 <__swc_fn_3464c816_000049_2ff013cc+0x1d0>
  40aead:	mov    rcx,r12
  40aeb0:	mov    rdx,rsi
  40aeb3:	call   40e7c0 <__swc_fn_3464c816_000056_38b21f11>
  40aeb8:	mov    rcx,r12
  40aebb:	mov    rdx,r8
  40aebe:	mov    r8,r9
  40aec1:	mov    r9,r10
  40aec4:	call   407750 <__swc_fn_3464c816_000039_40d1e569>
  40aec9:	jmp    40ae70 <__swc_fn_3464c816_000049_2ff013cc+0x1d0>
  40aecb:	mov    rcx,r12
  40aece:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  40aed3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40aedc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40aee5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40aeee:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40aef7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40af00:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40af09:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40af12:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40af1b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40af24:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40af2d:	add    rsp,0x178
  40af34:	pop    r15
  40af36:	pop    r14
  40af38:	pop    rsi
  40af39:	pop    rdi
  40af3a:	pop    r13
  40af3c:	pop    r12
  40af3e:	ret
	...

000000000040af40 <__swc_fn_3464c816_000052_c7484fb0>:
  40af40:	lea    rax,[rdx-0x58]
  40af44:	ret
	...

000000000040af50 <__swc_fn_3464c816_000055_81f7713d>:
  40af50:	push   rsi
  40af51:	push   rdi
  40af52:	push   r12
  40af54:	push   r13
  40af56:	sub    rsp,0x68
  40af5a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40af60:	mov    rsi,r9
  40af63:	mov    rdi,rcx
  40af66:	mov    r12,rdx
  40af69:	mov    r13,r8
  40af6c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40af74:	jne    40af83 <__swc_fn_3464c816_000055_81f7713d+0x33>
  40af76:	xor    eax,eax
  40af78:	add    rsp,0x68
  40af7c:	pop    r13
  40af7e:	pop    r12
  40af80:	pop    rdi
  40af81:	pop    rsi
  40af82:	ret
  40af83:	mov    rcx,rdi
  40af86:	call   4098c0 <__swc_fn_3464c816_000135_e3032dc2>
  40af8b:	movabs rax,0x7fffffffffffffff
  40af95:	cmp    r12,rax
  40af98:	mov    rax,0xffffffffffffffff
  40af9f:	lea    rcx,[r12+r12*1]
  40afa3:	cmovbe rax,rcx
  40afa7:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40afae:	mov    rdx,rcx
  40afb1:	sub    rax,r12
  40afb4:	inc    rax
  40afb7:	xor    r8d,r8d
  40afba:	test   rcx,rcx
  40afbd:	jbe    40afe8 <__swc_fn_3464c816_000055_81f7713d+0x98>
  40afbf:	nop
  40afc0:	lea    r9,[r8+r8*4]
  40afc4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40afcc:	sub    r9,r12
  40afcf:	cmp    r9,rax
  40afd2:	jae    40afdf <__swc_fn_3464c816_000055_81f7713d+0x8f>
  40afd4:	mov    rdx,r8
  40afd7:	mov    rax,r9
  40afda:	test   r9,r9
  40afdd:	je     40afe8 <__swc_fn_3464c816_000055_81f7713d+0x98>
  40afdf:	add    r8,0x1
  40afe3:	cmp    r8,rcx
  40afe6:	jb     40afc0 <__swc_fn_3464c816_000055_81f7713d+0x70>
  40afe8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40afef:	cmp    rdx,rax
  40aff2:	jne    40b00f <__swc_fn_3464c816_000055_81f7713d+0xbf>
  40aff4:	mov    rcx,rdi
  40aff7:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  40affc:	xor    eax,eax
  40affe:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b004:	add    rsp,0x68
  40b008:	pop    r13
  40b00a:	pop    r12
  40b00c:	pop    rdi
  40b00d:	pop    rsi
  40b00e:	ret
  40b00f:	lea    rax,[rdx+rdx*4]
  40b013:	lea    rax,[rdi+rax*8+0x268]
  40b01b:	vmovups xmm6,XMMWORD PTR [rax]
  40b01f:	mov    r8,QWORD PTR [rax+0x10]
  40b023:	mov    rcx,rdi
  40b026:	call   40e7c0 <__swc_fn_3464c816_000056_38b21f11>
  40b02b:	vpshufd xmm0,xmm6,0xee
  40b030:	vmovsd QWORD PTR [r13+0x0],xmm0
  40b036:	mov    QWORD PTR [rsi],r8
  40b039:	mov    rcx,rdi
  40b03c:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  40b041:	vmovq  rax,xmm6
  40b046:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b04c:	add    rsp,0x68
  40b050:	pop    r13
  40b052:	pop    r12
  40b054:	pop    rdi
  40b055:	pop    rsi
  40b056:	ret
	...

000000000040b060 <__swc_fn_3464c816_000058_8bd8d1d5>:
  40b060:	push   r12
  40b062:	push   r13
  40b064:	push   r14
  40b066:	push   r15
  40b068:	push   rdi
  40b069:	push   rsi
  40b06a:	sub    rsp,0x148
  40b071:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b07a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b083:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b08c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b095:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b09e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b0a7:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b0b0:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b0b9:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b0c2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b0cb:	mov    r12,r9
  40b0ce:	mov    r13,rcx
  40b0d1:	mov    r14,rdx
  40b0d4:	mov    r15,r8
  40b0d7:	test   rdx,rdx
  40b0da:	jne    40b0ee <__swc_fn_3464c816_000058_8bd8d1d5+0x8e>
  40b0dc:	add    rsp,0x148
  40b0e3:	pop    rsi
  40b0e4:	pop    rdi
  40b0e5:	pop    r15
  40b0e7:	pop    r14
  40b0e9:	pop    r13
  40b0eb:	pop    r12
  40b0ed:	ret
  40b0ee:	cmp    r12,0x200000
  40b0f5:	ja     40b187 <__swc_fn_3464c816_000058_8bd8d1d5+0x127>
  40b0fb:	lea    rax,[rip+0x16efe]        # 422000 <__swc_data_base_3464c816>
  40b102:	mov    rax,QWORD PTR [rax]
  40b105:	cmp    rax,0xffffffffffffffff
  40b109:	je     40b118 <__swc_fn_3464c816_000058_8bd8d1d5+0xb8>
  40b10b:	mov    eax,eax
  40b10d:	mov    edi,eax
  40b10f:	xor    eax,eax
  40b111:	call   407000 <pthread_getspecific@plt>
  40b116:	jmp    40b11a <__swc_fn_3464c816_000058_8bd8d1d5+0xba>
  40b118:	xor    eax,eax
  40b11a:	test   rax,rax
  40b11d:	je     40b124 <__swc_fn_3464c816_000058_8bd8d1d5+0xc4>
  40b11f:	mov    rsi,rax
  40b122:	jmp    40b134 <__swc_fn_3464c816_000058_8bd8d1d5+0xd4>
  40b124:	call   40aa00 <__swc_fn_3464c816_000031_90860ff2>
  40b129:	mov    rcx,rax
  40b12c:	call   410440 <__swc_fn_3464c816_000128_41c3251c>
  40b131:	mov    rsi,rax
  40b134:	test   rsi,rsi
  40b137:	je     40b187 <__swc_fn_3464c816_000058_8bd8d1d5+0x127>
  40b139:	cmp    QWORD PTR [rsi],r13
  40b13c:	jne    40b187 <__swc_fn_3464c816_000058_8bd8d1d5+0x127>
  40b13e:	cmp    DWORD PTR [rsi+0x20],0x0
  40b142:	jne    40b187 <__swc_fn_3464c816_000058_8bd8d1d5+0x127>
  40b144:	cmp    DWORD PTR [rsi+0x730],0x10
  40b14b:	jae    40b187 <__swc_fn_3464c816_000058_8bd8d1d5+0x127>
  40b14d:	mov    eax,DWORD PTR [rsi+0x730]
  40b153:	lea    rdi,[rax+rax*4]
  40b157:	lea    rdi,[rsi+rdi*8+0x738]
  40b15f:	mov    QWORD PTR [rdi],r14
  40b162:	mov    QWORD PTR [rdi+0x8],r15
  40b166:	mov    QWORD PTR [rdi+0x10],r12
  40b16a:	mov    QWORD PTR [rdi+0x18],0x0
  40b172:	call   4104f0 <__swc_fn_3464c816_000131_944f555b>
  40b177:	mov    QWORD PTR [rdi+0x20],rax
  40b17b:	add    DWORD PTR [rsi+0x730],0x1
  40b182:	jmp    40b2e6 <__swc_fn_3464c816_000058_8bd8d1d5+0x286>
  40b187:	mov    rcx,r13
  40b18a:	call   407e90 <__swc_fn_3464c816_000057_5b81d8b6>
  40b18f:	mov    rsi,rax
  40b192:	cmp    r12,rax
  40b195:	jbe    40b1ca <__swc_fn_3464c816_000058_8bd8d1d5+0x16a>
  40b197:	cmp    r12,0x10000000
  40b19e:	seta   al
  40b1a1:	ja     40b1b0 <__swc_fn_3464c816_000058_8bd8d1d5+0x150>
  40b1a3:	mov    rax,QWORD PTR [r13+0x2a70]
  40b1aa:	test   rax,rax
  40b1ad:	setne  al
  40b1b0:	test   al,al
  40b1b2:	je     40b1ca <__swc_fn_3464c816_000058_8bd8d1d5+0x16a>
  40b1b4:	mov    rcx,r13
  40b1b7:	mov    rdx,r14
  40b1ba:	mov    r8,r15
  40b1bd:	mov    r9,r12
  40b1c0:	call   407750 <__swc_fn_3464c816_000039_40d1e569>
  40b1c5:	jmp    40b2e6 <__swc_fn_3464c816_000058_8bd8d1d5+0x286>
  40b1ca:	call   4104f0 <__swc_fn_3464c816_000131_944f555b>
  40b1cf:	mov    rdi,rax
  40b1d2:	mov    rcx,r13
  40b1d5:	call   4098c0 <__swc_fn_3464c816_000135_e3032dc2>
  40b1da:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b1e2:	je     40b29a <__swc_fn_3464c816_000058_8bd8d1d5+0x23a>
  40b1e8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b1f0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b1fb:	jae    40b210 <__swc_fn_3464c816_000058_8bd8d1d5+0x1b0>
  40b1fd:	mov    rax,QWORD PTR [r13+0x2a68]
  40b204:	add    rax,r12
  40b207:	cmp    rax,rsi
  40b20a:	jbe    40b29a <__swc_fn_3464c816_000058_8bd8d1d5+0x23a>
  40b210:	xor    eax,eax
  40b212:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b219:	mov    edx,0x1
  40b21e:	cmp    rcx,0x1
  40b222:	jbe    40b259 <__swc_fn_3464c816_000058_8bd8d1d5+0x1f9>
  40b224:	cs nop WORD PTR [rax+rax*1+0x0]
  40b22e:	xchg   ax,ax
  40b230:	lea    r8,[rdx+rdx*4]
  40b234:	lea    r8,[r13+r8*8+0x268]
  40b23c:	lea    r9,[rax+rax*4]
  40b240:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b248:	cmp    QWORD PTR [r8+0x18],r9
  40b24c:	cmovb  rax,rdx
  40b250:	add    rdx,0x1
  40b254:	cmp    rdx,rcx
  40b257:	jb     40b230 <__swc_fn_3464c816_000058_8bd8d1d5+0x1d0>
  40b259:	lea    rcx,[rax+rax*4]
  40b25d:	lea    rcx,[r13+rcx*8+0x268]
  40b265:	mov    r8,QWORD PTR [rcx]
  40b268:	mov    r9,QWORD PTR [rcx+0x8]
  40b26c:	mov    r10,QWORD PTR [rcx+0x10]
  40b270:	mov    rcx,r13
  40b273:	mov    rdx,rax
  40b276:	call   40e7c0 <__swc_fn_3464c816_000056_38b21f11>
  40b27b:	mov    rcx,r13
  40b27e:	mov    rdx,r8
  40b281:	mov    r8,r9
  40b284:	mov    r9,r10
  40b287:	call   407750 <__swc_fn_3464c816_000039_40d1e569>
  40b28c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b294:	jne    40b1f0 <__swc_fn_3464c816_000058_8bd8d1d5+0x190>
  40b29a:	add    QWORD PTR [r13+0x2a78],0x1
  40b2a2:	mov    rax,QWORD PTR [r13+0x2a70]
  40b2a9:	lea    rax,[rax+rax*4]
  40b2ad:	lea    rax,[r13+rax*8+0x268]
  40b2b5:	mov    QWORD PTR [rax],r14
  40b2b8:	mov    QWORD PTR [rax+0x8],r15
  40b2bc:	mov    QWORD PTR [rax+0x10],r12
  40b2c0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40b2c7:	mov    QWORD PTR [rax+0x18],rcx
  40b2cb:	mov    QWORD PTR [rax+0x20],rdi
  40b2cf:	add    QWORD PTR [r13+0x2a68],r12
  40b2d6:	add    QWORD PTR [r13+0x2a70],0x1
  40b2de:	mov    rcx,r13
  40b2e1:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  40b2e6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40b2ef:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40b2f8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40b301:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40b30a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40b313:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40b31c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40b325:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40b32e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40b337:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40b340:	add    rsp,0x148
  40b347:	pop    rsi
  40b348:	pop    rdi
  40b349:	pop    r15
  40b34b:	pop    r14
  40b34d:	pop    r13
  40b34f:	pop    r12
  40b351:	ret
	...

000000000040b360 <__swc_fn_3464c816_000061_0a7f67d9>:
  40b360:	push   rbx
  40b361:	push   r12
  40b363:	push   r13
  40b365:	push   r14
  40b367:	push   r15
  40b369:	push   rdi
  40b36a:	push   rsi
  40b36b:	sub    rsp,0xf0
  40b372:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40b378:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40b37e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40b384:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40b38a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40b393:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40b39c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40b3a5:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40b3ae:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40b3b7:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40b3c0:	mov    eax,r8d
  40b3c3:	mov    rbx,rcx
  40b3c6:	mov    r12,rdx
  40b3c9:	mov    QWORD PTR [rsp+0x18],rdx
  40b3ce:	mov    ecx,DWORD PTR [r12+0x58]
  40b3d3:	mov    r13d,ecx
  40b3d6:	cmp    ecx,0x10
  40b3d9:	mov    ecx,0x10
  40b3de:	cmovb  r13d,ecx
  40b3e2:	test   r13d,r13d
  40b3e5:	mov    rcx,r13
  40b3e8:	mov    edx,0x8
  40b3ed:	cmove  ecx,edx
  40b3f0:	dec    rcx
  40b3f3:	mov    rdx,0xffffffffffffffff
  40b3fa:	sub    rdx,rcx
  40b3fd:	xor    r14d,r14d
  40b400:	mov    r8,rcx
  40b403:	not    r8
  40b406:	lea    rcx,[rcx+0x58]
  40b40a:	and    rcx,r8
  40b40d:	cmp    rdx,0x58
  40b411:	cmovae r14,rcx
  40b415:	cmp    eax,0xffffffff
  40b418:	jne    40b421 <__swc_fn_3464c816_000061_0a7f67d9+0xc1>
  40b41a:	mov    r15,QWORD PTR [r12+0x48]
  40b41f:	jmp    40b453 <__swc_fn_3464c816_000061_0a7f67d9+0xf3>
  40b421:	test   eax,eax
  40b423:	jne    40b42c <__swc_fn_3464c816_000061_0a7f67d9+0xcc>
  40b425:	mov    eax,0x8
  40b42a:	jmp    40b450 <__swc_fn_3464c816_000061_0a7f67d9+0xf0>
  40b42c:	cmp    eax,0x8
  40b42f:	ja     40b437 <__swc_fn_3464c816_000061_0a7f67d9+0xd7>
  40b431:	shl    rax,0x4
  40b435:	jmp    40b450 <__swc_fn_3464c816_000061_0a7f67d9+0xf0>
  40b437:	lea    eax,[rax-0x9]
  40b43a:	mov    ecx,eax
  40b43c:	shr    ecx,0x2
  40b43f:	and    eax,0x3
  40b442:	lea    ecx,[rcx+0x7]
  40b445:	lea    ecx,[rcx-0x2]
  40b448:	lea    eax,[rax+0x5]
  40b44b:	shlx   rax,rax,rcx
  40b450:	mov    r15,rax
  40b453:	lea    rax,[r14+r13*1]
  40b457:	mov    rcx,0xffffffffffffffff
  40b45e:	sub    rcx,rax
  40b461:	cmp    r15,rcx
  40b464:	jbe    40b474 <__swc_fn_3464c816_000061_0a7f67d9+0x114>
  40b466:	mov    QWORD PTR [r12+0x40],0x0
  40b46f:	jmp    40b846 <__swc_fn_3464c816_000061_0a7f67d9+0x4e6>
  40b474:	mov    QWORD PTR [rsp+0x20],r13
  40b479:	lea    r13,[rsp+0x8]
  40b47e:	add    rax,r15
  40b481:	mov    ecx,0x1000
  40b486:	test   ecx,ecx
  40b488:	mov    edx,0x8
  40b48d:	cmove  ecx,edx
  40b490:	dec    rcx
  40b493:	mov    rdx,0xffffffffffffffff
  40b49a:	sub    rdx,rcx
  40b49d:	cmp    rax,rdx
  40b4a0:	jbe    40b4ac <__swc_fn_3464c816_000061_0a7f67d9+0x14c>
  40b4a2:	mov    QWORD PTR [r13+0x0],0x0
  40b4aa:	jmp    40b4b9 <__swc_fn_3464c816_000061_0a7f67d9+0x159>
  40b4ac:	add    rax,rcx
  40b4af:	andn   rax,rcx,rax
  40b4b4:	mov    QWORD PTR [rsp+0x8],rax
  40b4b9:	cmp    QWORD PTR [r13+0x0],0x0
  40b4be:	jne    40b4ce <__swc_fn_3464c816_000061_0a7f67d9+0x16e>
  40b4c0:	mov    QWORD PTR [r12+0x40],0x0
  40b4c9:	jmp    40b846 <__swc_fn_3464c816_000061_0a7f67d9+0x4e6>
  40b4ce:	mov    QWORD PTR [rsp+0x30],r15
  40b4d3:	xor    r15d,r15d
  40b4d6:	mov    QWORD PTR [rsp+0x38],0x0
  40b4df:	lea    r12,[rsp+0x10]
  40b4e4:	mov    QWORD PTR [rsp+0x28],r14
  40b4e9:	mov    r14,QWORD PTR [rsp+0x8]
  40b4ee:	mov    QWORD PTR [rsp+0x10],r14
  40b4f3:	cmp    r14,0x10000
  40b4fa:	ja     40b501 <__swc_fn_3464c816_000061_0a7f67d9+0x1a1>
  40b4fc:	mov    rax,r14
  40b4ff:	jmp    40b552 <__swc_fn_3464c816_000061_0a7f67d9+0x1f2>
  40b501:	xor    eax,eax
  40b503:	lea    rcx,[r14-0x1]
  40b507:	lzcnt  rax,rcx
  40b50c:	mov    ecx,0x3f
  40b511:	sub    rcx,rax
  40b514:	mov    eax,0x1
  40b519:	lea    rcx,[rcx-0x3]
  40b51d:	shl    rax,cl
  40b520:	mov    rcx,rax
  40b523:	cmp    rax,0x1000
  40b52a:	mov    eax,0x1000
  40b52f:	cmovb  rcx,rax
  40b533:	mov    rdx,0xffffffffffffffff
  40b53a:	sub    rdx,rcx
  40b53d:	mov    rax,r14
  40b540:	lea    r8,[r14+rcx*1-0x1]
  40b545:	neg    rcx
  40b548:	and    r8,rcx
  40b54b:	cmp    r14,rdx
  40b54e:	cmovbe rax,r8
  40b552:	mov    QWORD PTR [rsp+0x8],rax
  40b557:	lea    rax,[rip+0x16aa2]        # 422000 <__swc_data_base_3464c816>
  40b55e:	mov    rax,QWORD PTR [rax]
  40b561:	cmp    rax,0xffffffffffffffff
  40b565:	je     40b574 <__swc_fn_3464c816_000061_0a7f67d9+0x214>
  40b567:	mov    eax,eax
  40b569:	mov    edi,eax
  40b56b:	xor    eax,eax
  40b56d:	call   407000 <pthread_getspecific@plt>
  40b572:	jmp    40b576 <__swc_fn_3464c816_000061_0a7f67d9+0x216>
  40b574:	xor    eax,eax
  40b576:	test   rax,rax
  40b579:	jne    40b588 <__swc_fn_3464c816_000061_0a7f67d9+0x228>
  40b57b:	call   40aa00 <__swc_fn_3464c816_000031_90860ff2>
  40b580:	mov    rcx,rax
  40b583:	call   410440 <__swc_fn_3464c816_000128_41c3251c>
  40b588:	test   rax,rax
  40b58b:	je     40b67c <__swc_fn_3464c816_000061_0a7f67d9+0x31c>
  40b591:	cmp    QWORD PTR [rax],rbx
  40b594:	jne    40b67c <__swc_fn_3464c816_000061_0a7f67d9+0x31c>
  40b59a:	cmp    DWORD PTR [rax+0x20],0x0
  40b59e:	jne    40b67c <__swc_fn_3464c816_000061_0a7f67d9+0x31c>
  40b5a4:	mov    rcx,QWORD PTR [rsp+0x8]
  40b5a9:	movabs rdx,0x7fffffffffffffff
  40b5b3:	cmp    rcx,rdx
  40b5b6:	mov    rdx,0xffffffffffffffff
  40b5bd:	lea    r8,[rcx+rcx*1]
  40b5c1:	cmovbe rdx,r8
  40b5c5:	mov    r8d,DWORD PTR [rax+0x730]
  40b5cc:	mov    r9d,r8d
  40b5cf:	sub    rdx,rcx
  40b5d2:	inc    rdx
  40b5d5:	xor    r10d,r10d
  40b5d8:	test   r8,r8
  40b5db:	jbe    40b60b <__swc_fn_3464c816_000061_0a7f67d9+0x2ab>
  40b5dd:	nop    DWORD PTR [rax]
  40b5e0:	mov    r11d,r10d
  40b5e3:	lea    r11,[r11+r11*4]
  40b5e7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40b5ef:	sub    r11,rcx
  40b5f2:	cmp    r11,rdx
  40b5f5:	jae    40b602 <__swc_fn_3464c816_000061_0a7f67d9+0x2a2>
  40b5f7:	mov    r9d,r10d
  40b5fa:	mov    rdx,r11
  40b5fd:	test   r11,r11
  40b600:	je     40b60b <__swc_fn_3464c816_000061_0a7f67d9+0x2ab>
  40b602:	add    r10,0x1
  40b606:	cmp    r10,r8
  40b609:	jb     40b5e0 <__swc_fn_3464c816_000061_0a7f67d9+0x280>
  40b60b:	mov    ecx,DWORD PTR [rax+0x730]
  40b611:	cmp    r9d,ecx
  40b614:	jne    40b61a <__swc_fn_3464c816_000061_0a7f67d9+0x2ba>
  40b616:	xor    eax,eax
  40b618:	jmp    40b679 <__swc_fn_3464c816_000061_0a7f67d9+0x319>
  40b61a:	lea    rcx,[r9+r9*4]
  40b61e:	lea    rcx,[rax+rcx*8+0x738]
  40b626:	vmovups xmm0,XMMWORD PTR [rcx]
  40b62a:	mov    rdx,QWORD PTR [rcx+0x10]
  40b62e:	sub    DWORD PTR [rax+0x730],0x1
  40b635:	mov    r8d,DWORD PTR [rax+0x730]
  40b63c:	lea    r8,[r8+r8*4]
  40b640:	lea    r8,[rax+r8*8+0x738]
  40b648:	vmovups xmm1,XMMWORD PTR [r8]
  40b64d:	vmovups XMMWORD PTR [rcx],xmm1
  40b651:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40b657:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40b65c:	mov    rax,QWORD PTR [r8+0x20]
  40b660:	mov    QWORD PTR [rcx+0x20],rax
  40b664:	vpshufd xmm1,xmm0,0xee
  40b669:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40b66f:	mov    QWORD PTR [rsp+0x10],rdx
  40b674:	vmovq  rax,xmm0
  40b679:	mov    r15,rax
  40b67c:	test   r15,r15
  40b67f:	jne    40b697 <__swc_fn_3464c816_000061_0a7f67d9+0x337>
  40b681:	mov    rcx,rbx
  40b684:	mov    rdx,QWORD PTR [rsp+0x8]
  40b689:	mov    r8,r13
  40b68c:	mov    r9,r12
  40b68f:	call   40af50 <__swc_fn_3464c816_000055_81f7713d>
  40b694:	mov    r15,rax
  40b697:	test   r15,r15
  40b69a:	je     40b6db <__swc_fn_3464c816_000061_0a7f67d9+0x37b>
  40b69c:	cmp    QWORD PTR [r12],r14
  40b6a0:	jae    40b6db <__swc_fn_3464c816_000061_0a7f67d9+0x37b>
  40b6a2:	mov    rax,r15
  40b6a5:	add    rax,QWORD PTR [r12]
  40b6a9:	mov    rdx,r14
  40b6ac:	sub    rdx,QWORD PTR [r12]
  40b6b0:	mov    rcx,rax
  40b6b3:	call   4072a0 <__swc_fn_3464c816_000003_7ab4792e>
  40b6b8:	test   al,al
  40b6ba:	je     40b6c3 <__swc_fn_3464c816_000061_0a7f67d9+0x363>
  40b6bc:	mov    QWORD PTR [rsp+0x10],r14
  40b6c1:	jmp    40b6db <__swc_fn_3464c816_000061_0a7f67d9+0x37b>
  40b6c3:	mov    rcx,rbx
  40b6c6:	mov    rdx,r15
  40b6c9:	mov    r8,QWORD PTR [rsp+0x8]
  40b6ce:	mov    r9,QWORD PTR [rsp+0x10]
  40b6d3:	call   40b060 <__swc_fn_3464c816_000058_8bd8d1d5>
  40b6d8:	xor    r15d,r15d
  40b6db:	test   r15,r15
  40b6de:	jne    40b75a <__swc_fn_3464c816_000061_0a7f67d9+0x3fa>
  40b6e0:	cmp    r14,0x10000
  40b6e7:	ja     40b6ee <__swc_fn_3464c816_000061_0a7f67d9+0x38e>
  40b6e9:	mov    rax,r14
  40b6ec:	jmp    40b73f <__swc_fn_3464c816_000061_0a7f67d9+0x3df>
  40b6ee:	xor    eax,eax
  40b6f0:	lea    rcx,[r14-0x1]
  40b6f4:	lzcnt  rax,rcx
  40b6f9:	mov    ecx,0x3f
  40b6fe:	sub    rcx,rax
  40b701:	mov    eax,0x1
  40b706:	lea    rcx,[rcx-0x3]
  40b70a:	shl    rax,cl
  40b70d:	mov    rcx,rax
  40b710:	cmp    rax,0x1000
  40b717:	mov    eax,0x1000
  40b71c:	cmovb  rcx,rax
  40b720:	mov    rdx,0xffffffffffffffff
  40b727:	sub    rdx,rcx
  40b72a:	mov    rax,r14
  40b72d:	lea    r8,[r14+rcx*1-0x1]
  40b732:	neg    rcx
  40b735:	and    r8,rcx
  40b738:	cmp    r14,rdx
  40b73b:	cmovbe rax,r8
  40b73f:	mov    QWORD PTR [rsp+0x8],rax
  40b744:	mov    QWORD PTR [rsp+0x10],r14
  40b749:	mov    rcx,rbx
  40b74c:	mov    rdx,rax
  40b74f:	mov    r8,r14
  40b752:	call   40aac0 <__swc_fn_3464c816_000037_b4982903>
  40b757:	mov    r15,rax
  40b75a:	test   r15,r15
  40b75d:	jne    40b76b <__swc_fn_3464c816_000061_0a7f67d9+0x40b>
  40b75f:	mov    r13,QWORD PTR [rsp+0x20]
  40b764:	mov    rsi,QWORD PTR [rsp+0x38]
  40b769:	jmp    40b7a7 <__swc_fn_3464c816_000061_0a7f67d9+0x447>
  40b76b:	mov    rax,r15
  40b76e:	add    rax,QWORD PTR [rsp+0x28]
  40b773:	mov    r13,QWORD PTR [rsp+0x20]
  40b778:	test   r13d,r13d
  40b77b:	mov    rcx,r13
  40b77e:	mov    edx,0x8
  40b783:	cmove  ecx,edx
  40b786:	dec    rcx
  40b789:	mov    rdx,0xffffffffffffffff
  40b790:	sub    rdx,rcx
  40b793:	cmp    rax,rdx
  40b796:	jbe    40b79c <__swc_fn_3464c816_000061_0a7f67d9+0x43c>
  40b798:	xor    eax,eax
  40b79a:	jmp    40b7a4 <__swc_fn_3464c816_000061_0a7f67d9+0x444>
  40b79c:	add    rax,rcx
  40b79f:	andn   rax,rcx,rax
  40b7a4:	mov    rsi,rax
  40b7a7:	mov    rax,QWORD PTR [rsp+0x8]
  40b7ac:	test   r15,r15
  40b7af:	je     40b7b8 <__swc_fn_3464c816_000061_0a7f67d9+0x458>
  40b7b1:	mov    rdi,QWORD PTR [rsp+0x18]
  40b7b6:	jmp    40b7ca <__swc_fn_3464c816_000061_0a7f67d9+0x46a>
  40b7b8:	mov    rdi,QWORD PTR [rsp+0x18]
  40b7bd:	mov    QWORD PTR [rdi+0x40],0x0
  40b7c5:	jmp    40b846 <__swc_fn_3464c816_000061_0a7f67d9+0x4e6>
  40b7ca:	lea    rdx,[rsi-0x58]
  40b7ce:	mov    QWORD PTR [rsi-0x58],r15
  40b7d2:	mov    QWORD PTR [rsi-0x50],rax
  40b7d6:	mov    rax,QWORD PTR [rsp+0x10]
  40b7db:	mov    QWORD PTR [rsi-0x48],rax
  40b7df:	mov    QWORD PTR [rsi-0x40],rsi
  40b7e3:	mov    rax,QWORD PTR [rdi+0x48]
  40b7e7:	mov    QWORD PTR [rsi-0x38],rax
  40b7eb:	mov    rax,QWORD PTR [rsp+0x30]
  40b7f0:	mov    QWORD PTR [rsi-0x30],rax
  40b7f4:	mov    DWORD PTR [rsi-0x10],r13d
  40b7f8:	mov    QWORD PTR [rsi-0x28],0x0
  40b800:	mov    QWORD PTR [rsi-0x20],0x0
  40b808:	add    r15,QWORD PTR [r12]
  40b80c:	sub    r15,rsi
  40b80f:	mov    QWORD PTR [rsi-0x30],r15
  40b813:	mov    rcx,QWORD PTR [rbx+0x250]
  40b81a:	nop    WORD PTR [rax+rax*1+0x0]
  40b820:	lea    r8,[rcx+r15*1]
  40b824:	mov    rax,rcx
  40b827:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40b830:	cmp    rax,rcx
  40b833:	je     40b83a <__swc_fn_3464c816_000061_0a7f67d9+0x4da>
  40b835:	mov    rcx,rax
  40b838:	jmp    40b820 <__swc_fn_3464c816_000061_0a7f67d9+0x4c0>
  40b83a:	mov    rcx,rbx
  40b83d:	call   40e730 <__swc_fn_3464c816_000053_82546d94>
  40b842:	mov    QWORD PTR [rdi+0x40],rsi
  40b846:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40b84c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40b852:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40b858:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40b85e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40b867:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40b870:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40b879:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40b882:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40b88b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40b894:	add    rsp,0xf0
  40b89b:	pop    rsi
  40b89c:	pop    rdi
  40b89d:	pop    r15
  40b89f:	pop    r14
  40b8a1:	pop    r13
  40b8a3:	pop    r12
  40b8a5:	pop    rbx
  40b8a6:	ret
	...

000000000040b8b0 <__swc_fn_3464c816_000064_b0d63361>:
  40b8b0:	push   rbx
  40b8b1:	push   r12
  40b8b3:	push   rdi
  40b8b4:	push   rsi
  40b8b5:	sub    rsp,0xb8
  40b8bc:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40b8c2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40b8c8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40b8ce:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40b8d4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40b8da:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40b8e0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40b8e6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40b8ef:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40b8f8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40b901:	mov    rbx,rdx
  40b904:	mov    r12,rcx
  40b907:	cmp    DWORD PTR [rbx+0x58],0x0
  40b90b:	je     40b925 <__swc_fn_3464c816_000064_b0d63361+0x75>
  40b90d:	mov    eax,DWORD PTR [rbx+0x58]
  40b910:	sub    eax,0x1
  40b913:	test   DWORD PTR [rbx+0x58],eax
  40b916:	je     40b925 <__swc_fn_3464c816_000064_b0d63361+0x75>
  40b918:	mov    QWORD PTR [rbx+0x40],0x0
  40b920:	jmp    40bb37 <__swc_fn_3464c816_000064_b0d63361+0x287>
  40b925:	cmp    QWORD PTR [rbx+0x48],0x0
  40b92a:	jne    40b939 <__swc_fn_3464c816_000064_b0d63361+0x89>
  40b92c:	mov    QWORD PTR [rbx+0x40],0x0
  40b934:	jmp    40bb37 <__swc_fn_3464c816_000064_b0d63361+0x287>
  40b939:	lea    rax,[rsp+0x8]
  40b93e:	mov    rcx,QWORD PTR [rbx+0x48]
  40b942:	cmp    rcx,0x8
  40b946:	ja     40b950 <__swc_fn_3464c816_000064_b0d63361+0xa0>
  40b948:	mov    DWORD PTR [rax],0x0
  40b94e:	jmp    40b9ab <__swc_fn_3464c816_000064_b0d63361+0xfb>
  40b950:	cmp    rcx,0x80
  40b957:	ja     40b967 <__swc_fn_3464c816_000064_b0d63361+0xb7>
  40b959:	lea    rcx,[rcx+0xf]
  40b95d:	shr    rcx,0x4
  40b961:	mov    DWORD PTR [rsp+0x8],ecx
  40b965:	jmp    40b9ab <__swc_fn_3464c816_000064_b0d63361+0xfb>
  40b967:	cmp    rcx,0x10000
  40b96e:	jbe    40b978 <__swc_fn_3464c816_000064_b0d63361+0xc8>
  40b970:	mov    DWORD PTR [rax],0xffffffff
  40b976:	jmp    40b9ab <__swc_fn_3464c816_000064_b0d63361+0xfb>
  40b978:	dec    rcx
  40b97b:	xor    edx,edx
  40b97d:	lzcnt  rdx,rcx
  40b982:	mov    r8d,0x3f
  40b988:	sub    r8d,edx
  40b98b:	lea    edx,[r8-0x2]
  40b98f:	shrx   rcx,rcx,rdx
  40b994:	and    ecx,0x3
  40b997:	lea    edx,[r8-0x7]
  40b99b:	lea    edx,[rdx*4+0x0]
  40b9a2:	lea    edx,[rdx+0x9]
  40b9a5:	add    edx,ecx
  40b9a7:	mov    DWORD PTR [rsp+0x8],edx
  40b9ab:	cmp    DWORD PTR [rax],0x0
  40b9ae:	jne    40b9be <__swc_fn_3464c816_000064_b0d63361+0x10e>
  40b9b0:	cmp    DWORD PTR [rbx+0x58],0x8
  40b9b4:	jbe    40b9be <__swc_fn_3464c816_000064_b0d63361+0x10e>
  40b9b6:	mov    DWORD PTR [rsp+0x8],0x1
  40b9be:	cmp    DWORD PTR [rbx+0x58],0x10
  40b9c2:	jbe    40ba41 <__swc_fn_3464c816_000064_b0d63361+0x191>
  40b9c8:	cmp    DWORD PTR [rbx+0x58],0x40
  40b9cc:	ja     40ba41 <__swc_fn_3464c816_000064_b0d63361+0x191>
  40b9ce:	cmp    DWORD PTR [rax],0xffffffff
  40b9d1:	je     40ba41 <__swc_fn_3464c816_000064_b0d63361+0x191>
  40b9d3:	mov    ecx,DWORD PTR [rsp+0x8]
  40b9d7:	mov    edx,DWORD PTR [rbx+0x58]
  40b9da:	dec    rdx
  40b9dd:	cmp    ecx,0x2d
  40b9e0:	jae    40ba38 <__swc_fn_3464c816_000064_b0d63361+0x188>
  40b9e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b9ec:	nop    DWORD PTR [rax+0x0]
  40b9f0:	mov    r8d,ecx
  40b9f3:	test   ecx,ecx
  40b9f5:	jne    40b9ff <__swc_fn_3464c816_000064_b0d63361+0x14f>
  40b9f7:	mov    r8d,0x8
  40b9fd:	jmp    40ba2b <__swc_fn_3464c816_000064_b0d63361+0x17b>
  40b9ff:	cmp    r8d,0x8
  40ba03:	ja     40ba0b <__swc_fn_3464c816_000064_b0d63361+0x15b>
  40ba05:	shl    r8,0x4
  40ba09:	jmp    40ba2b <__swc_fn_3464c816_000064_b0d63361+0x17b>
  40ba0b:	lea    r8d,[r8-0x9]
  40ba0f:	mov    r9d,r8d
  40ba12:	shr    r9d,0x2
  40ba16:	and    r8d,0x3
  40ba1a:	lea    r9d,[r9+0x7]
  40ba1e:	lea    r9d,[r9-0x2]
  40ba22:	lea    r8d,[r8+0x5]
  40ba26:	shlx   r8,r8,r9
  40ba2b:	test   r8,rdx
  40ba2e:	je     40ba3d <__swc_fn_3464c816_000064_b0d63361+0x18d>
  40ba30:	add    ecx,0x1
  40ba33:	cmp    ecx,0x2d
  40ba36:	jb     40b9f0 <__swc_fn_3464c816_000064_b0d63361+0x140>
  40ba38:	mov    ecx,0xffffffff
  40ba3d:	mov    DWORD PTR [rsp+0x8],ecx
  40ba41:	mov    ecx,DWORD PTR [rsp+0x8]
  40ba45:	cmp    ecx,0xffffffff
  40ba48:	je     40ba50 <__swc_fn_3464c816_000064_b0d63361+0x1a0>
  40ba4a:	cmp    DWORD PTR [rbx+0x58],0x40
  40ba4e:	jbe    40ba63 <__swc_fn_3464c816_000064_b0d63361+0x1b3>
  40ba50:	mov    rcx,r12
  40ba53:	mov    rdx,rbx
  40ba56:	mov    r8d,DWORD PTR [rax]
  40ba59:	call   40b360 <__swc_fn_3464c816_000061_0a7f67d9>
  40ba5e:	jmp    40bb37 <__swc_fn_3464c816_000064_b0d63361+0x287>
  40ba63:	lea    rax,[rip+0x16596]        # 422000 <__swc_data_base_3464c816>
  40ba6a:	mov    rax,QWORD PTR [rax]
  40ba6d:	cmp    rax,0xffffffffffffffff
  40ba71:	je     40ba80 <__swc_fn_3464c816_000064_b0d63361+0x1d0>
  40ba73:	mov    eax,eax
  40ba75:	mov    edi,eax
  40ba77:	xor    eax,eax
  40ba79:	call   407000 <pthread_getspecific@plt>
  40ba7e:	jmp    40ba82 <__swc_fn_3464c816_000064_b0d63361+0x1d2>
  40ba80:	xor    eax,eax
  40ba82:	test   rax,rax
  40ba85:	jne    40ba94 <__swc_fn_3464c816_000064_b0d63361+0x1e4>
  40ba87:	call   40aa00 <__swc_fn_3464c816_000031_90860ff2>
  40ba8c:	mov    rcx,rax
  40ba8f:	call   410440 <__swc_fn_3464c816_000128_41c3251c>
  40ba94:	test   rax,rax
  40ba97:	je     40baa4 <__swc_fn_3464c816_000064_b0d63361+0x1f4>
  40ba99:	cmp    QWORD PTR [rax],r12
  40ba9c:	jne    40baa4 <__swc_fn_3464c816_000064_b0d63361+0x1f4>
  40ba9e:	cmp    DWORD PTR [rax+0x20],0x0
  40baa2:	je     40baaf <__swc_fn_3464c816_000064_b0d63361+0x1ff>
  40baa4:	mov    rcx,r12
  40baa7:	mov    rdx,rax
  40baaa:	call   40e370 <__swc_fn_3464c816_000041_414cc921>
  40baaf:	test   rax,rax
  40bab2:	jne    40babe <__swc_fn_3464c816_000064_b0d63361+0x20e>
  40bab4:	mov    QWORD PTR [rbx+0x40],0x0
  40babc:	jmp    40bb37 <__swc_fn_3464c816_000064_b0d63361+0x287>
  40babe:	lea    r8,[rsp+0xc]
  40bac3:	mov    ecx,DWORD PTR [rsp+0x8]
  40bac7:	mov    DWORD PTR [rsp+0xc],ecx
  40bacb:	mov    ecx,DWORD PTR [r8]
  40bace:	lea    rcx,[rcx+rcx*4]
  40bad2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40bad7:	test   rcx,rcx
  40bada:	je     40bb13 <__swc_fn_3464c816_000064_b0d63361+0x263>
  40badc:	mov    rdx,QWORD PTR [rcx]
  40badf:	test   rdx,rdx
  40bae2:	je     40baf0 <__swc_fn_3464c816_000064_b0d63361+0x240>
  40bae4:	mov    r9,QWORD PTR [rdx]
  40bae7:	mov    QWORD PTR [rcx],r9
  40baea:	add    DWORD PTR [rcx+0x28],0x1
  40baee:	jmp    40bb0e <__swc_fn_3464c816_000064_b0d63361+0x25e>
  40baf0:	mov    rdx,QWORD PTR [rcx+0x18]
  40baf4:	cmp    QWORD PTR [rcx+0x20],rdx
  40baf8:	jae    40bb0c <__swc_fn_3464c816_000064_b0d63361+0x25c>
  40bafa:	mov    rdx,QWORD PTR [rcx+0x20]
  40bafe:	mov    r9d,DWORD PTR [rcx+0x2c]
  40bb02:	add    QWORD PTR [rcx+0x20],r9
  40bb06:	add    DWORD PTR [rcx+0x28],0x1
  40bb0a:	jmp    40bb0e <__swc_fn_3464c816_000064_b0d63361+0x25e>
  40bb0c:	xor    edx,edx
  40bb0e:	test   rdx,rdx
  40bb11:	jne    40bb24 <__swc_fn_3464c816_000064_b0d63361+0x274>
  40bb13:	mov    rcx,r12
  40bb16:	mov    rdx,rax
  40bb19:	mov    r8d,DWORD PTR [r8]
  40bb1c:	call   40e4e0 <__swc_fn_3464c816_000050_ab8077df>
  40bb21:	mov    rdx,rax
  40bb24:	test   rdx,rdx
  40bb27:	jne    40bb33 <__swc_fn_3464c816_000064_b0d63361+0x283>
  40bb29:	mov    QWORD PTR [rbx+0x40],0x0
  40bb31:	jmp    40bb37 <__swc_fn_3464c816_000064_b0d63361+0x287>
  40bb33:	mov    QWORD PTR [rbx+0x40],rdx
  40bb37:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40bb3d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40bb43:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40bb49:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40bb4f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40bb55:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40bb5b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40bb61:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40bb6a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40bb73:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40bb7c:	add    rsp,0xb8
  40bb83:	pop    rsi
  40bb84:	pop    rdi
  40bb85:	pop    r12
  40bb87:	pop    rbx
  40bb88:	ret
  40bb89:	add    BYTE PTR [rax],al
  40bb8b:	add    BYTE PTR [rax],al
  40bb8d:	add    BYTE PTR [rax],al
	...

000000000040bb90 <__swc_fn_3464c816_000067_94a51053>:
  40bb90:	ret
	...

000000000040bba0 <__swc_fn_3464c816_000070_3181d86c>:
  40bba0:	push   r12
  40bba2:	push   r13
  40bba4:	push   r14
  40bba6:	push   rdi
  40bba7:	push   rsi
  40bba8:	sub    rsp,0x1a0
  40bbaf:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40bbb8:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40bbc1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40bbca:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40bbd3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40bbdc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40bbe5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40bbee:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40bbf7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40bc00:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40bc09:	mov    r12,rdx
  40bc0c:	mov    r13,rcx
  40bc0f:	mov    rax,QWORD PTR [r12+0x48]
  40bc14:	mov    ecx,DWORD PTR [r12+0x58]
  40bc19:	lea    rdx,[rax-0x1]
  40bc1d:	cmp    rdx,0x10000
  40bc24:	jae    40bd1e <__swc_fn_3464c816_000070_3181d86c+0x17e>
  40bc2a:	cmp    rax,0x8
  40bc2e:	ja     40bc35 <__swc_fn_3464c816_000070_3181d86c+0x95>
  40bc30:	xor    r14d,r14d
  40bc33:	jmp    40bc87 <__swc_fn_3464c816_000070_3181d86c+0xe7>
  40bc35:	cmp    rax,0x80
  40bc3c:	ja     40bc48 <__swc_fn_3464c816_000070_3181d86c+0xa8>
  40bc3e:	lea    r14,[rax+0xf]
  40bc42:	shr    r14,0x4
  40bc46:	jmp    40bc87 <__swc_fn_3464c816_000070_3181d86c+0xe7>
  40bc48:	cmp    rax,0x10000
  40bc4f:	jbe    40bc59 <__swc_fn_3464c816_000070_3181d86c+0xb9>
  40bc51:	mov    r14d,0xffffffff
  40bc57:	jmp    40bc87 <__swc_fn_3464c816_000070_3181d86c+0xe7>
  40bc59:	xor    eax,eax
  40bc5b:	lzcnt  rax,rdx
  40bc60:	mov    r8d,0x3f
  40bc66:	sub    r8d,eax
  40bc69:	lea    eax,[r8-0x2]
  40bc6d:	shrx   rax,rdx,rax
  40bc72:	and    eax,0x3
  40bc75:	lea    edx,[r8-0x7]
  40bc79:	lea    edx,[rdx*4+0x0]
  40bc80:	lea    edx,[rdx+0x9]
  40bc83:	lea    r14d,[rdx+rax*1]
  40bc87:	cmp    ecx,0x8
  40bc8a:	jbe    40bca3 <__swc_fn_3464c816_000070_3181d86c+0x103>
  40bc8c:	cmp    ecx,0x10
  40bc8f:	jne    40bd1e <__swc_fn_3464c816_000070_3181d86c+0x17e>
  40bc95:	test   r14d,r14d
  40bc98:	mov    eax,0x1
  40bc9d:	cmove  r14d,eax
  40bca1:	jmp    40bcaa <__swc_fn_3464c816_000070_3181d86c+0x10a>
  40bca3:	lea    eax,[rcx-0x1]
  40bca6:	test   eax,ecx
  40bca8:	jne    40bd1e <__swc_fn_3464c816_000070_3181d86c+0x17e>
  40bcaa:	lea    rax,[rip+0x1634f]        # 422000 <__swc_data_base_3464c816>
  40bcb1:	mov    rax,QWORD PTR [rax]
  40bcb4:	cmp    rax,0xffffffffffffffff
  40bcb8:	je     40bcc7 <__swc_fn_3464c816_000070_3181d86c+0x127>
  40bcba:	mov    eax,eax
  40bcbc:	mov    edi,eax
  40bcbe:	xor    eax,eax
  40bcc0:	call   407000 <pthread_getspecific@plt>
  40bcc5:	jmp    40bcc9 <__swc_fn_3464c816_000070_3181d86c+0x129>
  40bcc7:	xor    eax,eax
  40bcc9:	test   rax,rax
  40bccc:	je     40bd1e <__swc_fn_3464c816_000070_3181d86c+0x17e>
  40bcce:	cmp    QWORD PTR [rax],r13
  40bcd1:	jne    40bd1e <__swc_fn_3464c816_000070_3181d86c+0x17e>
  40bcd3:	lea    rcx,[r14+r14*4]
  40bcd7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40bcdc:	test   rax,rax
  40bcdf:	je     40bd1e <__swc_fn_3464c816_000070_3181d86c+0x17e>
  40bce1:	mov    rcx,QWORD PTR [rax]
  40bce4:	test   rcx,rcx
  40bce7:	je     40bcf5 <__swc_fn_3464c816_000070_3181d86c+0x155>
  40bce9:	mov    rdx,QWORD PTR [rcx]
  40bcec:	mov    QWORD PTR [rax],rdx
  40bcef:	add    DWORD PTR [rax+0x28],0x1
  40bcf3:	jmp    40bd12 <__swc_fn_3464c816_000070_3181d86c+0x172>
  40bcf5:	mov    rcx,QWORD PTR [rax+0x18]
  40bcf9:	cmp    QWORD PTR [rax+0x20],rcx
  40bcfd:	jae    40bd10 <__swc_fn_3464c816_000070_3181d86c+0x170>
  40bcff:	mov    rcx,QWORD PTR [rax+0x20]
  40bd03:	mov    edx,DWORD PTR [rax+0x2c]
  40bd06:	add    QWORD PTR [rax+0x20],rdx
  40bd0a:	add    DWORD PTR [rax+0x28],0x1
  40bd0e:	jmp    40bd12 <__swc_fn_3464c816_000070_3181d86c+0x172>
  40bd10:	xor    ecx,ecx
  40bd12:	test   rcx,rcx
  40bd15:	je     40bd1e <__swc_fn_3464c816_000070_3181d86c+0x17e>
  40bd17:	mov    QWORD PTR [r12+0x40],rcx
  40bd1c:	jmp    40bd29 <__swc_fn_3464c816_000070_3181d86c+0x189>
  40bd1e:	mov    rcx,r13
  40bd21:	mov    rdx,r12
  40bd24:	call   40ef60 <__swc_fn_3464c816_000071_0d1ef36f>
  40bd29:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40bd32:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40bd3b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40bd44:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40bd4d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40bd56:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40bd5f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40bd68:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40bd71:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40bd7a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40bd83:	add    rsp,0x1a0
  40bd8a:	pop    rsi
  40bd8b:	pop    rdi
  40bd8c:	pop    r14
  40bd8e:	pop    r13
  40bd90:	pop    r12
  40bd92:	ret
	...

000000000040bda0 <__swc_fn_3464c816_000073_c6c71bf7>:
  40bda0:	push   r12
  40bda2:	push   r13
  40bda4:	push   r14
  40bda6:	push   r15
  40bda8:	push   rdi
  40bda9:	push   rsi
  40bdaa:	sub    rsp,0x188
  40bdb1:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40bdba:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40bdc3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40bdcc:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40bdd5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40bdde:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40bde7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40bdf0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40bdf9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40be02:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40be0b:	mov    r12,rdx
  40be0e:	mov    r13,rcx
  40be11:	mov    r14,QWORD PTR [r12+0x40]
  40be16:	lea    rax,[rip+0x18253]        # 424070 <__swc_bss_base_3464c816+0x30>
  40be1d:	mov    rcx,r14
  40be20:	sub    rcx,QWORD PTR [rax+0x8]
  40be24:	mov    rax,QWORD PTR [rip+0x18255]        # 424080 <__swc_bss_base_3464c816+0x40>
  40be2b:	cmp    rcx,rax
  40be2e:	jae    40be5a <__swc_fn_3464c816_000073_c6c71bf7+0xba>
  40be30:	mov    rax,r14
  40be33:	and    rax,0xffffffffffc00000
  40be3a:	mov    rcx,r14
  40be3d:	shr    rcx,0x10
  40be41:	and    ecx,0x3f
  40be44:	mov    edx,DWORD PTR [rax+0x28]
  40be47:	shrx   ecx,ecx,edx
  40be4c:	shl    rcx,0x4
  40be50:	lea    r15,[rax+rcx*8+0x80]
  40be58:	jmp    40be65 <__swc_fn_3464c816_000073_c6c71bf7+0xc5>
  40be5a:	mov    rcx,r14
  40be5d:	call   40a930 <__swc_fn_3464c816_000022_3a2e2048>
  40be62:	mov    r15,rax
  40be65:	test   r15,r15
  40be68:	je     40bf0f <__swc_fn_3464c816_000073_c6c71bf7+0x16f>
  40be6e:	lea    rax,[rip+0x1618b]        # 422000 <__swc_data_base_3464c816>
  40be75:	mov    rax,QWORD PTR [rax]
  40be78:	cmp    rax,0xffffffffffffffff
  40be7c:	je     40be8b <__swc_fn_3464c816_000073_c6c71bf7+0xeb>
  40be7e:	mov    eax,eax
  40be80:	mov    edi,eax
  40be82:	xor    eax,eax
  40be84:	call   407000 <pthread_getspecific@plt>
  40be89:	jmp    40be8d <__swc_fn_3464c816_000073_c6c71bf7+0xed>
  40be8b:	xor    eax,eax
  40be8d:	mov    rcx,QWORD PTR [r15+0x40]
  40be91:	cmp    rcx,rax
  40be94:	jne    40bef4 <__swc_fn_3464c816_000073_c6c71bf7+0x154>
  40be96:	test   rax,rax
  40be99:	je     40bf0f <__swc_fn_3464c816_000073_c6c71bf7+0x16f>
  40be9b:	mov    ecx,DWORD PTR [r15+0x6c]
  40be9f:	test   ecx,ecx
  40bea1:	je     40bec1 <__swc_fn_3464c816_000073_c6c71bf7+0x121>
  40bea3:	mov    rcx,r13
  40bea6:	mov    rdx,rax
  40bea9:	mov    r8,r15
  40beac:	mov    QWORD PTR [rsp+0xd8],rax
  40beb4:	call   40e470 <__swc_fn_3464c816_000047_bc5ec610>
  40beb9:	mov    rax,QWORD PTR [rsp+0xd8]
  40bec1:	mov    rcx,QWORD PTR [r15]
  40bec4:	mov    QWORD PTR [r14],rcx
  40bec7:	mov    QWORD PTR [r15],r14
  40beca:	sub    DWORD PTR [r15+0x28],0x1
  40becf:	jne    40bf04 <__swc_fn_3464c816_000073_c6c71bf7+0x164>
  40bed1:	movzx  ecx,BYTE PTR [r15+0x39]
  40bed6:	lea    rcx,[rcx+rcx*4]
  40beda:	lea    rcx,[rax+rcx*8+0x28]
  40bedf:	cmp    QWORD PTR [rcx],r15
  40bee2:	je     40bf04 <__swc_fn_3464c816_000073_c6c71bf7+0x164>
  40bee4:	mov    rcx,r13
  40bee7:	mov    rdx,rax
  40beea:	mov    r8,r15
  40beed:	call   407d80 <__swc_fn_3464c816_000051_f7021588>
  40bef2:	jmp    40bf04 <__swc_fn_3464c816_000073_c6c71bf7+0x164>
  40bef4:	test   rcx,rcx
  40bef7:	je     40bf0f <__swc_fn_3464c816_000073_c6c71bf7+0x16f>
  40bef9:	mov    rcx,r15
  40befc:	mov    rdx,r14
  40beff:	call   40a570 <__swc_fn_3464c816_000010_395bb04b>
  40bf04:	mov    QWORD PTR [r12+0x40],0x0
  40bf0d:	jmp    40bf1a <__swc_fn_3464c816_000073_c6c71bf7+0x17a>
  40bf0f:	mov    rcx,r13
  40bf12:	mov    rdx,r12
  40bf15:	call   40ef80 <__swc_fn_3464c816_000074_518516c2>
  40bf1a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40bf23:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40bf2c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40bf35:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40bf3e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40bf47:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40bf50:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40bf59:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40bf62:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40bf6b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40bf74:	add    rsp,0x188
  40bf7b:	pop    rsi
  40bf7c:	pop    rdi
  40bf7d:	pop    r15
  40bf7f:	pop    r14
  40bf81:	pop    r13
  40bf83:	pop    r12
  40bf85:	ret
	...

000000000040bf90 <__swc_fn_3464c816_000076_9f0c6acf>:
  40bf90:	sub    rsp,0x8
  40bf94:	mov    rax,rdx
  40bf97:	mov    rdx,QWORD PTR [rax+0x40]
  40bf9b:	mov    r8,rax
  40bf9e:	call   40bb90 <__swc_fn_3464c816_000067_94a51053>
  40bfa3:	add    rsp,0x8
  40bfa7:	ret
	...

000000000040bfb0 <__swc_fn_3464c816_000079_34776ded>:
  40bfb0:	push   rsi
  40bfb1:	push   rdi
  40bfb2:	sub    rsp,0x8
  40bfb6:	cmp    rcx,0xffffffffffffffef
  40bfba:	ja     40bfe0 <__swc_fn_3464c816_000079_34776ded+0x30>
  40bfbc:	xor    esi,esi
  40bfbe:	lea    rax,[rcx+0x100f]
  40bfc5:	and    rax,0xfffffffffffff000
  40bfcc:	lea    rcx,[rcx+0x10]
  40bfd0:	cmp    rcx,0xfffffffffffff000
  40bfd7:	cmovbe rsi,rax
  40bfdb:	test   rsi,rsi
  40bfde:	jne    40bfe9 <__swc_fn_3464c816_000079_34776ded+0x39>
  40bfe0:	xor    eax,eax
  40bfe2:	add    rsp,0x8
  40bfe6:	pop    rdi
  40bfe7:	pop    rsi
  40bfe8:	ret
  40bfe9:	mov    rcx,rsi
  40bfec:	call   40c640 <__swc_fn_3464c816_000109_8d425bd3>
  40bff1:	mov    rdi,rax
  40bff4:	test   rax,rax
  40bff7:	jne    40c002 <__swc_fn_3464c816_000079_34776ded+0x52>
  40bff9:	xor    eax,eax
  40bffb:	add    rsp,0x8
  40bfff:	pop    rdi
  40c000:	pop    rsi
  40c001:	ret
  40c002:	mov    rcx,rdi
  40c005:	mov    rdx,rsi
  40c008:	call   409260 <__swc_fn_3464c816_000111_b25e3a45>
  40c00d:	test   al,al
  40c00f:	jne    40c025 <__swc_fn_3464c816_000079_34776ded+0x75>
  40c011:	mov    rcx,rdi
  40c014:	mov    rdx,rsi
  40c017:	call   4100e0 <__swc_fn_3464c816_000113_49b378a9>
  40c01c:	xor    eax,eax
  40c01e:	add    rsp,0x8
  40c022:	pop    rdi
  40c023:	pop    rsi
  40c024:	ret
  40c025:	mov    QWORD PTR [rdi],rsi
  40c028:	mov    QWORD PTR [rdi+0x8],0x0
  40c030:	lea    rax,[rdi+0x10]
  40c034:	add    rsp,0x8
  40c038:	pop    rdi
  40c039:	pop    rsi
  40c03a:	ret
  40c03b:	add    BYTE PTR [rax],al
  40c03d:	add    BYTE PTR [rax],al
	...

000000000040c040 <__swc_fn_3464c816_000082_754dcd57>:
  40c040:	sub    rsp,0x8
  40c044:	cmp    BYTE PTR [rcx+0x2c],0x10
  40c048:	jne    40c053 <__swc_fn_3464c816_000082_754dcd57+0x13>
  40c04a:	test   DWORD PTR [rcx+0x28],0x80
  40c051:	je     40c05b <__swc_fn_3464c816_000082_754dcd57+0x1b>
  40c053:	mov    rax,rcx
  40c056:	add    rsp,0x8
  40c05a:	ret
  40c05b:	mov    rcx,QWORD PTR [rcx+0x40]
  40c05f:	call   40c040 <__swc_fn_3464c816_000082_754dcd57>
  40c064:	add    rsp,0x8
  40c068:	ret
	...

000000000040c080 <__swc_fn_3464c816_000085_1edf7c76>:
  40c080:	push   rsi
  40c081:	push   rdi
  40c082:	push   r12
  40c084:	push   r13
  40c086:	sub    rsp,0x8
  40c08a:	mov    rsi,rdx
  40c08d:	mov    rdi,rcx
  40c090:	xor    r8d,r8d
  40c093:	call   4085a0 <__swc_fn_3464c816_000090_a2d50c23>
  40c098:	test   al,al
  40c09a:	je     40c0ac <__swc_fn_3464c816_000085_1edf7c76+0x2c>
  40c09c:	mov    eax,0x1
  40c0a1:	add    rsp,0x8
  40c0a5:	pop    r13
  40c0a7:	pop    r12
  40c0a9:	pop    rdi
  40c0aa:	pop    rsi
  40c0ab:	ret
  40c0ac:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c0b1:	je     40c0c0 <__swc_fn_3464c816_000085_1edf7c76+0x40>
  40c0b3:	xor    eax,eax
  40c0b5:	add    rsp,0x8
  40c0b9:	pop    r13
  40c0bb:	pop    r12
  40c0bd:	pop    rdi
  40c0be:	pop    rsi
  40c0bf:	ret
  40c0c0:	mov    r12,QWORD PTR [rsi+0x98]
  40c0c7:	mov    rax,QWORD PTR [rsi+0xa0]
  40c0ce:	mov    rsi,rax
  40c0d1:	xor    r13d,r13d
  40c0d4:	test   rsi,rsi
  40c0d7:	je     40c134 <__swc_fn_3464c816_000085_1edf7c76+0xb4>
  40c0d9:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0e3:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0ed:	nop    DWORD PTR [rax]
  40c0f0:	lea    rax,[r13*8+0x0]
  40c0f8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c0fd:	mov    rcx,rax
  40c100:	call   40c040 <__swc_fn_3464c816_000082_754dcd57>
  40c105:	cmp    BYTE PTR [rax+0x2c],0xe
  40c109:	jne    40c12a <__swc_fn_3464c816_000085_1edf7c76+0xaa>
  40c10b:	mov    rcx,rdi
  40c10e:	mov    rdx,rax
  40c111:	call   40c080 <__swc_fn_3464c816_000085_1edf7c76>
  40c116:	test   al,al
  40c118:	je     40c12a <__swc_fn_3464c816_000085_1edf7c76+0xaa>
  40c11a:	mov    eax,0x1
  40c11f:	add    rsp,0x8
  40c123:	pop    r13
  40c125:	pop    r12
  40c127:	pop    rdi
  40c128:	pop    rsi
  40c129:	ret
  40c12a:	add    r13,0x1
  40c12e:	sub    rsi,0x1
  40c132:	jne    40c0f0 <__swc_fn_3464c816_000085_1edf7c76+0x70>
  40c134:	xor    eax,eax
  40c136:	add    rsp,0x8
  40c13a:	pop    r13
  40c13c:	pop    r12
  40c13e:	pop    rdi
  40c13f:	pop    rsi
  40c140:	ret
	...

000000000040c150 <__swc_fn_3464c816_000088_fcb34f6a>:
  40c150:	sub    rsp,0x18
  40c154:	vxorps xmm0,xmm0,xmm0
  40c158:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c15d:	call   40f190 <__swc_fn_3464c816_000089_386582f3>
  40c162:	add    rsp,0x18
  40c166:	ret
	...

000000000040c170 <__swc_fn_3464c816_000091_3d2f5a0d>:
  40c170:	sub    rsp,0x8
  40c174:	mov    rcx,QWORD PTR [rip+0x1abc5]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c17b:	test   rcx,rcx
  40c17e:	jne    40c190 <__swc_fn_3464c816_000091_3d2f5a0d+0x20>
  40c180:	call   40a1d0 <__swc_fn_3464c816_000165_cf398896>
  40c185:	lea    rcx,[rax+0x1]
  40c189:	mov    QWORD PTR [rip+0x1abb0],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c190:	dec    rcx
  40c193:	call   411f00 <__swc_fn_3464c816_000167_fce60b2b>
  40c198:	mov    rax,QWORD PTR [rax+0xc0]
  40c19f:	and    eax,0x1
  40c1a2:	setne  al
  40c1a5:	add    rsp,0x8
  40c1a9:	ret
	...

000000000040c1c0 <__swc_fn_3464c816_000094_14db3cf9>:
  40c1c0:	push   rbx
  40c1c1:	push   rsi
  40c1c2:	push   rdi
  40c1c3:	push   r12
  40c1c5:	sub    rsp,0x28
  40c1c9:	mov    rbx,rcx
  40c1cc:	call   408900 <__swc_fn_3464c816_000093_f8c16535>
  40c1d1:	mov    rcx,QWORD PTR [rip+0x1ab68]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c1d8:	test   rcx,rcx
  40c1db:	jne    40c1ed <__swc_fn_3464c816_000094_14db3cf9+0x2d>
  40c1dd:	call   40a1d0 <__swc_fn_3464c816_000165_cf398896>
  40c1e2:	lea    rcx,[rax+0x1]
  40c1e6:	mov    QWORD PTR [rip+0x1ab53],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c1ed:	dec    rcx
  40c1f0:	call   411f00 <__swc_fn_3464c816_000167_fce60b2b>
  40c1f5:	mov    rsi,rax
  40c1f8:	lea    rcx,[rsp+0x8]
  40c1fd:	call   40f5d0 <__swc_fn_3464c816_000092_8252f8c0>
  40c202:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c209:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c210:	lea    rcx,[rsi+0x10]
  40c214:	call   40d1a0 <__swc_fn_3464c816_000157_232ffa22>
  40c219:	mov    rcx,rsi
  40c21c:	call   40f740 <__swc_fn_3464c816_000101_eab3874f>
  40c221:	vxorps xmm0,xmm0,xmm0
  40c225:	xor    eax,eax
  40c227:	cs nop WORD PTR [rax+rax*1+0x0]
  40c231:	cs nop WORD PTR [rax+rax*1+0x0]
  40c23b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c240:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c245:	add    rax,0x10
  40c249:	cmp    rax,0xbf0
  40c250:	jne    40c240 <__swc_fn_3464c816_000094_14db3cf9+0x80>
  40c252:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c258:	vmovups XMMWORD PTR [rsi],xmm0
  40c25c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c262:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c26a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c271:	mov    QWORD PTR [rsi+0xbe8],r12
  40c278:	mov    rcx,QWORD PTR [rip+0x1aac1]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c27f:	test   rcx,rcx
  40c282:	jne    40c294 <__swc_fn_3464c816_000094_14db3cf9+0xd4>
  40c284:	call   40a1d0 <__swc_fn_3464c816_000165_cf398896>
  40c289:	lea    rcx,[rax+0x1]
  40c28d:	mov    QWORD PTR [rip+0x1aaac],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c294:	dec    rcx
  40c297:	call   411f00 <__swc_fn_3464c816_000167_fce60b2b>
  40c29c:	mov    rsi,rax
  40c29f:	mov    QWORD PTR [rsi+0xc0],rbx
  40c2a6:	and    ebx,0x1
  40c2a9:	jne    40c2ad <__swc_fn_3464c816_000094_14db3cf9+0xed>
  40c2ab:	xor    eax,eax
  40c2ad:	test   rbx,rbx
  40c2b0:	sete   al
  40c2b3:	xor    cl,cl
  40c2b5:	xor    dl,dl
  40c2b7:	xor    r8b,r8b
  40c2ba:	xor    r9b,r9b
  40c2bd:	xor    r10b,r10b
  40c2c0:	mov    r11,rax
  40c2c3:	call   40ef90 <__swc_fn_3464c816_000077_8b8614a7>
  40c2c8:	lea    rbx,[rsp+0x18]
  40c2cd:	mov    rcx,rbx
  40c2d0:	call   40f5d0 <__swc_fn_3464c816_000092_8252f8c0>
  40c2d5:	lea    rcx,[rsi+0x10]
  40c2d9:	mov    edx,0x400000
  40c2de:	mov    r8,rbx
  40c2e1:	call   409f10 <__swc_fn_3464c816_000159_d8afac28>
  40c2e6:	lea    rcx,[rsi+0x68]
  40c2ea:	mov    edx,0x4000
  40c2ef:	mov    r8,rbx
  40c2f2:	call   409f10 <__swc_fn_3464c816_000159_d8afac28>
  40c2f7:	add    rsp,0x28
  40c2fb:	pop    r12
  40c2fd:	pop    rdi
  40c2fe:	pop    rsi
  40c2ff:	pop    rbx
  40c300:	ret
	...

000000000040c310 <__swc_fn_3464c816_000097_4c97e0db>:
  40c310:	push   rbx
  40c311:	push   rsi
  40c312:	sub    rsp,0x18
  40c316:	mov    rbx,rcx
  40c319:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c31e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c324:	mov    rsi,QWORD PTR [rbx+0x70]
  40c328:	lea    rcx,[rcx+0x18]
  40c32c:	call   40d1a0 <__swc_fn_3464c816_000157_232ffa22>
  40c331:	lea    rcx,[rsp+0x8]
  40c336:	mov    rdx,rbx
  40c339:	mov    r8d,0x78
  40c33f:	call   408960 <__swc_fn_3464c816_000096_ad982b35>
  40c344:	mov    rax,rsi
  40c347:	add    rsp,0x18
  40c34b:	pop    rsi
  40c34c:	pop    rbx
  40c34d:	ret
	...

000000000040c350 <__swc_fn_3464c816_000100_3ed08774>:
  40c350:	push   rsi
  40c351:	push   rdi
  40c352:	sub    rsp,0x8
  40c356:	cmp    QWORD PTR [rcx],0x0
  40c35a:	jne    40c363 <__swc_fn_3464c816_000100_3ed08774+0x13>
  40c35c:	add    rsp,0x8
  40c360:	pop    rdi
  40c361:	pop    rsi
  40c362:	ret
  40c363:	mov    rsi,QWORD PTR [rcx]
  40c366:	mov    rax,QWORD PTR [rcx+0x8]
  40c36a:	test   rax,rax
  40c36d:	je     40c383 <__swc_fn_3464c816_000100_3ed08774+0x33>
  40c36f:	test   DWORD PTR [rax+0x28],0x400000
  40c376:	je     40c383 <__swc_fn_3464c816_000100_3ed08774+0x33>
  40c378:	mov    rcx,QWORD PTR [rax+0x30]
  40c37c:	test   rcx,rcx
  40c37f:	cmovne rax,rcx
  40c383:	lea    rdx,[rip+0x6e46]        # 4131d0 <__swc_rdata_base_3464c816+0xc0>
  40c38a:	lea    rcx,[rip+0x6f27]        # 4132b8 <__swc_rdata_base_3464c816+0x1a8>
  40c391:	mov    r8,rax
  40c394:	xor    r9d,r9d
  40c397:	xor    al,al
  40c399:	mov    r10,rax
  40c39c:	xor    r11d,r11d
  40c39f:	call   40c150 <__swc_fn_3464c816_000088_fcb34f6a>
  40c3a4:	test   rax,rax
  40c3a7:	je     40c3b7 <__swc_fn_3464c816_000100_3ed08774+0x67>
  40c3a9:	mov    rdi,QWORD PTR [rax+0x48]
  40c3ad:	test   rdi,rdi
  40c3b0:	je     40c3b7 <__swc_fn_3464c816_000100_3ed08774+0x67>
  40c3b2:	mov    rcx,rsi
  40c3b5:	call   rdi
  40c3b7:	add    rsp,0x8
  40c3bb:	pop    rdi
  40c3bc:	pop    rsi
  40c3bd:	ret
	...

000000000040c3c0 <__swc_fn_3464c816_000103_67100064>:
  40c3c0:	push   rbx
  40c3c1:	push   rsi
  40c3c2:	push   rdi
  40c3c3:	sub    rsp,0x20
  40c3c7:	mov    rbx,rdx
  40c3ca:	mov    rsi,rcx
  40c3cd:	mov    rcx,QWORD PTR [rip+0x1a96c]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c3d4:	test   rcx,rcx
  40c3d7:	jne    40c3e9 <__swc_fn_3464c816_000103_67100064+0x29>
  40c3d9:	call   40a1d0 <__swc_fn_3464c816_000165_cf398896>
  40c3de:	lea    rcx,[rax+0x1]
  40c3e2:	mov    QWORD PTR [rip+0x1a957],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c3e9:	dec    rcx
  40c3ec:	call   411f00 <__swc_fn_3464c816_000167_fce60b2b>
  40c3f1:	mov    rdi,rax
  40c3f4:	mov    rax,QWORD PTR [rdi+0xbd0]
  40c3fb:	xor    ecx,ecx
  40c3fd:	test   rax,rax
  40c400:	je     40c405 <__swc_fn_3464c816_000103_67100064+0x45>
  40c402:	mov    rcx,QWORD PTR [rax]
  40c405:	call   40a300 <__swc_fn_3464c816_000174_176517f9>
  40c40a:	lea    rax,[rsp+0x8]
  40c40f:	lea    rcx,[rdi+0x9c8]
  40c416:	mov    QWORD PTR [rsp+0x8],rcx
  40c41b:	mov    QWORD PTR [rax+0x8],0x40
  40c423:	xor    ecx,ecx
  40c425:	mov    rdx,rax
  40c428:	call   410220 <__swc_fn_3464c816_000119_9175a56a>
  40c42d:	mov    DWORD PTR [rdi+0xbc8],eax
  40c433:	mov    rdi,QWORD PTR [rdi+0x990]
  40c43a:	test   rdi,rdi
  40c43d:	je     40c447 <__swc_fn_3464c816_000103_67100064+0x87>
  40c43f:	mov    rcx,rsi
  40c442:	mov    rdx,rbx
  40c445:	call   rdi
  40c447:	call   40c170 <__swc_fn_3464c816_000091_3d2f5a0d>
  40c44c:	test   al,al
  40c44e:	je     40c45e <__swc_fn_3464c816_000103_67100064+0x9e>
  40c450:	mov    rcx,rsi
  40c453:	mov    rdx,rbx
  40c456:	xor    r8d,r8d
  40c459:	call   409400 <__swc_fn_3464c816_000120_ea68f292>
  40c45e:	mov    rcx,rsi
  40c461:	mov    rdx,rbx
  40c464:	call   408a80 <__swc_fn_3464c816_000102_e9fdc18e>
  40c469:	call   40c9f0 <__swc_fn_3464c816_000118_7f430081>
  40c46e:	add    rsp,0x20
  40c472:	pop    rdi
  40c473:	pop    rsi
  40c474:	pop    rbx
  40c475:	ret
	...

000000000040c480 <__swc_fn_3464c816_000106_ed4b1681>:
  40c480:	test   r8,r8
  40c483:	jne    40c488 <__swc_fn_3464c816_000106_ed4b1681+0x8>
  40c485:	xor    eax,eax
  40c487:	ret
  40c488:	xor    eax,eax
  40c48a:	nop    WORD PTR [rax+rax*1+0x0]
  40c490:	mov    r9,r8
  40c493:	sub    r9,rax
  40c496:	cmp    r9,0x10
  40c49a:	jb     40c4e4 <__swc_fn_3464c816_000106_ed4b1681+0x64>
  40c49c:	lea    r9,[rcx+rax*1]
  40c4a0:	lea    r10,[rdx+rax*1]
  40c4a4:	vmovups xmm0,XMMWORD PTR [r10]
  40c4a9:	vmovups xmm1,XMMWORD PTR [r9]
  40c4ae:	vpcmpeqb xmm0,xmm1,xmm0
  40c4b2:	vpmovmskb r9d,xmm0
  40c4b6:	cmp    r9d,0xffff
  40c4bd:	je     40c4de <__swc_fn_3464c816_000106_ed4b1681+0x5e>
  40c4bf:	not    r9d
  40c4c2:	xor    r8d,r8d
  40c4c5:	movzx  r9d,r9w
  40c4c9:	tzcnt  r8d,r9d
  40c4ce:	add    rax,r8
  40c4d1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4d5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4d9:	sub    ecx,eax
  40c4db:	mov    eax,ecx
  40c4dd:	ret
  40c4de:	lea    rax,[rax+0x10]
  40c4e2:	jmp    40c490 <__swc_fn_3464c816_000106_ed4b1681+0x10>
  40c4e4:	cmp    r9,0x8
  40c4e8:	jb     40c55b <__swc_fn_3464c816_000106_ed4b1681+0xdb>
  40c4ea:	lea    r9,[rcx+rax*1]
  40c4ee:	lea    r10,[rdx+rax*1]
  40c4f2:	mov    r9,QWORD PTR [r9]
  40c4f5:	xor    r9,QWORD PTR [r10]
  40c4f8:	test   r9,r9
  40c4fb:	je     40c519 <__swc_fn_3464c816_000106_ed4b1681+0x99>
  40c4fd:	xor    r8d,r8d
  40c500:	tzcnt  r8,r9
  40c505:	shr    r8,0x3
  40c509:	add    rax,r8
  40c50c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c510:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c514:	sub    ecx,eax
  40c516:	mov    eax,ecx
  40c518:	ret
  40c519:	lea    rax,[rax+0x8]
  40c51d:	cmp    rax,r8
  40c520:	jne    40c525 <__swc_fn_3464c816_000106_ed4b1681+0xa5>
  40c522:	xor    eax,eax
  40c524:	ret
  40c525:	lea    rax,[r8-0x8]
  40c529:	lea    r8,[rcx+rax*1]
  40c52d:	lea    r9,[rdx+rax*1]
  40c531:	mov    r8,QWORD PTR [r8]
  40c534:	xor    r8,QWORD PTR [r9]
  40c537:	test   r8,r8
  40c53a:	je     40c558 <__swc_fn_3464c816_000106_ed4b1681+0xd8>
  40c53c:	xor    r9d,r9d
  40c53f:	tzcnt  r9,r8
  40c544:	shr    r9,0x3
  40c548:	add    rax,r9
  40c54b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c54f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c553:	sub    ecx,eax
  40c555:	mov    eax,ecx
  40c557:	ret
  40c558:	xor    eax,eax
  40c55a:	ret
  40c55b:	cmp    r9,0x4
  40c55f:	jb     40c5d2 <__swc_fn_3464c816_000106_ed4b1681+0x152>
  40c561:	lea    r9,[rcx+rax*1]
  40c565:	lea    r10,[rdx+rax*1]
  40c569:	mov    r9d,DWORD PTR [r9]
  40c56c:	xor    r9d,DWORD PTR [r10]
  40c56f:	test   r9d,r9d
  40c572:	je     40c590 <__swc_fn_3464c816_000106_ed4b1681+0x110>
  40c574:	xor    r8d,r8d
  40c577:	tzcnt  r8,r9
  40c57c:	shr    r8,0x3
  40c580:	add    rax,r8
  40c583:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c587:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c58b:	sub    ecx,eax
  40c58d:	mov    eax,ecx
  40c58f:	ret
  40c590:	lea    rax,[rax+0x4]
  40c594:	cmp    rax,r8
  40c597:	jne    40c59c <__swc_fn_3464c816_000106_ed4b1681+0x11c>
  40c599:	xor    eax,eax
  40c59b:	ret
  40c59c:	lea    rax,[r8-0x4]
  40c5a0:	lea    r8,[rcx+rax*1]
  40c5a4:	lea    r9,[rdx+rax*1]
  40c5a8:	mov    r8d,DWORD PTR [r8]
  40c5ab:	xor    r8d,DWORD PTR [r9]
  40c5ae:	test   r8d,r8d
  40c5b1:	je     40c5cf <__swc_fn_3464c816_000106_ed4b1681+0x14f>
  40c5b3:	xor    r9d,r9d
  40c5b6:	tzcnt  r9,r8
  40c5bb:	shr    r9,0x3
  40c5bf:	add    rax,r9
  40c5c2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5c6:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5ca:	sub    ecx,eax
  40c5cc:	mov    eax,ecx
  40c5ce:	ret
  40c5cf:	xor    eax,eax
  40c5d1:	ret
  40c5d2:	cmp    r9,0x2
  40c5d6:	jb     40c629 <__swc_fn_3464c816_000106_ed4b1681+0x1a9>
  40c5d8:	lea    r9,[rcx+rax*1]
  40c5dc:	lea    r10,[rdx+rax*1]
  40c5e0:	mov    r9w,WORD PTR [r9]
  40c5e4:	xor    r9w,WORD PTR [r10]
  40c5e8:	test   r9w,r9w
  40c5ec:	je     40c60e <__swc_fn_3464c816_000106_ed4b1681+0x18e>
  40c5ee:	xor    r8d,r8d
  40c5f1:	movzx  r9d,r9w
  40c5f5:	tzcnt  r8,r9
  40c5fa:	shr    r8,0x3
  40c5fe:	add    rax,r8
  40c601:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c605:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c609:	sub    ecx,eax
  40c60b:	mov    eax,ecx
  40c60d:	ret
  40c60e:	lea    rax,[rax+0x2]
  40c612:	cmp    rax,r8
  40c615:	jne    40c61a <__swc_fn_3464c816_000106_ed4b1681+0x19a>
  40c617:	xor    eax,eax
  40c619:	ret
  40c61a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40c620:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40c626:	sub    eax,ecx
  40c628:	ret
  40c629:	test   r9,r9
  40c62c:	je     40c63b <__swc_fn_3464c816_000106_ed4b1681+0x1bb>
  40c62e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c632:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c636:	sub    ecx,eax
  40c638:	mov    eax,ecx
  40c63a:	ret
  40c63b:	xor    eax,eax
  40c63d:	ret
	...

000000000040c640 <__swc_fn_3464c816_000109_8d425bd3>:
  40c640:	push   r12
  40c642:	push   r13
  40c644:	push   r14
  40c646:	push   rdi
  40c647:	push   rsi
  40c648:	push   r15
  40c64a:	sub    rsp,0xd8
  40c651:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c657:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c65d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c663:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c669:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c66f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c678:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c681:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c68a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c693:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c69c:	mov    r12,rcx
  40c69f:	test   rcx,rcx
  40c6a2:	je     40c6be <__swc_fn_3464c816_000109_8d425bd3+0x7e>
  40c6a4:	mov    eax,r12d
  40c6a7:	and    eax,0xfff
  40c6ad:	setne  al
  40c6b0:	cmp    r12,0xffffffffffffefff
  40c6b7:	seta   cl
  40c6ba:	or     al,cl
  40c6bc:	je     40c6c5 <__swc_fn_3464c816_000109_8d425bd3+0x85>
  40c6be:	xor    eax,eax
  40c6c0:	jmp    40c75b <__swc_fn_3464c816_000109_8d425bd3+0x11b>
  40c6c5:	call   409120 <__swc_fn_3464c816_000108_84af7666>
  40c6ca:	mov    r13,rax
  40c6cd:	test   rax,rax
  40c6d0:	jne    40c6d9 <__swc_fn_3464c816_000109_8d425bd3+0x99>
  40c6d2:	xor    eax,eax
  40c6d4:	jmp    40c75b <__swc_fn_3464c816_000109_8d425bd3+0x11b>
  40c6d9:	lea    r14,[r12+0x1000]
  40c6e1:	xor    edi,edi
  40c6e3:	mov    rsi,r14
  40c6e6:	xor    edx,edx
  40c6e8:	mov    ecx,0x22
  40c6ed:	mov    eax,0xffffffff
  40c6f2:	movsxd r8,eax
  40c6f5:	xor    r9d,r9d
  40c6f8:	xor    eax,eax
  40c6fa:	call   4070c0 <mmap@plt>
  40c6ff:	mov    r15,rax
  40c702:	cmp    rax,0xffffffffffffffff
  40c706:	jne    40c70c <__swc_fn_3464c816_000109_8d425bd3+0xcc>
  40c708:	xor    eax,eax
  40c70a:	jmp    40c75b <__swc_fn_3464c816_000109_8d425bd3+0x11b>
  40c70c:	mov    rdi,r15
  40c70f:	mov    esi,0x1000
  40c714:	mov    edx,0x3
  40c719:	xor    eax,eax
  40c71b:	call   407030 <mprotect@plt>
  40c720:	test   eax,eax
  40c722:	je     40c735 <__swc_fn_3464c816_000109_8d425bd3+0xf5>
  40c724:	mov    rdi,r15
  40c727:	mov    rsi,r14
  40c72a:	xor    eax,eax
  40c72c:	call   407020 <munmap@plt>
  40c731:	xor    eax,eax
  40c733:	jmp    40c75b <__swc_fn_3464c816_000109_8d425bd3+0x11b>
  40c735:	mov    QWORD PTR [r15+0x8],r12
  40c739:	mov    rcx,r13
  40c73c:	call   40cd90 <__swc_fn_3464c816_000133_4b2af8da>
  40c741:	mov    rax,QWORD PTR [r13+0x8]
  40c745:	mov    QWORD PTR [r15],rax
  40c748:	mov    QWORD PTR [r13+0x8],r15
  40c74c:	mov    rcx,r13
  40c74f:	call   4105c0 <__swc_fn_3464c816_000134_29412410>
  40c754:	lea    rax,[r15+0x1000]
  40c75b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c761:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c767:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c76d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c773:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c779:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c782:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c78b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c794:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c79d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c7a6:	add    rsp,0xd8
  40c7ad:	pop    r15
  40c7af:	pop    rsi
  40c7b0:	pop    rdi
  40c7b1:	pop    r14
  40c7b3:	pop    r13
  40c7b5:	pop    r12
  40c7b7:	ret
	...

000000000040c7c0 <__swc_fn_3464c816_000112_759e9ceb>:
  40c7c0:	push   rbx
  40c7c1:	push   r12
  40c7c3:	push   rdi
  40c7c4:	push   rsi
  40c7c5:	sub    rsp,0xa8
  40c7cc:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c7d2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c7d8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c7de:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c7e4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c7ea:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c7f0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c7f6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c7fc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c805:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c80e:	mov    rbx,rdx
  40c811:	mov    r12,rcx
  40c814:	mov    rdi,rcx
  40c817:	mov    rsi,rdx
  40c81a:	xor    edx,edx
  40c81c:	xor    eax,eax
  40c81e:	call   407030 <mprotect@plt>
  40c823:	test   eax,eax
  40c825:	jne    40c849 <__swc_fn_3464c816_000112_759e9ceb+0x89>
  40c827:	mov    rcx,r12
  40c82a:	mov    rdx,rbx
  40c82d:	xor    al,al
  40c82f:	mov    r8,rax
  40c832:	call   410050 <__swc_fn_3464c816_000110_a808fe76>
  40c837:	mov    rdi,r12
  40c83a:	mov    rsi,rbx
  40c83d:	mov    edx,0x4
  40c842:	xor    eax,eax
  40c844:	call   4070f0 <madvise@plt>
  40c849:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c84f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c855:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c85b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40c861:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40c867:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40c86d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40c873:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40c879:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40c882:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40c88b:	add    rsp,0xa8
  40c892:	pop    rsi
  40c893:	pop    rdi
  40c894:	pop    r12
  40c896:	pop    rbx
  40c897:	ret
	...

000000000040c8a0 <__swc_fn_3464c816_000115_1ba33335>:
  40c8a0:	push   rsi
  40c8a1:	push   rdi
  40c8a2:	push   r12
  40c8a4:	push   r13
  40c8a6:	push   r14
  40c8a8:	sub    rsp,0xe0
  40c8af:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c8b5:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c8bb:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c8c1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c8c7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c8cd:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c8d6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c8df:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c8e8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c8f1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c8fa:	mov    rsi,rdx
  40c8fd:	mov    rdi,rcx
  40c900:	call   409120 <__swc_fn_3464c816_000108_84af7666>
  40c905:	mov    r12,rax
  40c908:	test   rax,rax
  40c90b:	jne    40c912 <__swc_fn_3464c816_000115_1ba33335+0x72>
  40c90d:	jmp    40c986 <__swc_fn_3464c816_000115_1ba33335+0xe6>
  40c912:	mov    rcx,r12
  40c915:	call   40cd90 <__swc_fn_3464c816_000133_4b2af8da>
  40c91a:	lea    r13,[r12+0x8]
  40c91f:	mov    rax,QWORD PTR [r13+0x0]
  40c923:	test   rax,rax
  40c926:	je     40c97e <__swc_fn_3464c816_000115_1ba33335+0xde>
  40c928:	nop    DWORD PTR [rax+rax*1+0x0]
  40c930:	lea    rcx,[rax+0x1000]
  40c937:	cmp    rcx,rdi
  40c93a:	jne    40c972 <__swc_fn_3464c816_000115_1ba33335+0xd2>
  40c93c:	cmp    QWORD PTR [rax+0x8],rsi
  40c940:	je     40c94c <__swc_fn_3464c816_000115_1ba33335+0xac>
  40c942:	mov    rcx,r12
  40c945:	call   4105c0 <__swc_fn_3464c816_000134_29412410>
  40c94a:	jmp    40c986 <__swc_fn_3464c816_000115_1ba33335+0xe6>
  40c94c:	mov    r14,QWORD PTR [rax]
  40c94f:	mov    rdi,rax
  40c952:	lea    rsi,[rsi+0x1000]
  40c959:	xor    eax,eax
  40c95b:	call   407020 <munmap@plt>
  40c960:	test   eax,eax
  40c962:	jne    40c968 <__swc_fn_3464c816_000115_1ba33335+0xc8>
  40c964:	mov    QWORD PTR [r13+0x0],r14
  40c968:	mov    rcx,r12
  40c96b:	call   4105c0 <__swc_fn_3464c816_000134_29412410>
  40c970:	jmp    40c986 <__swc_fn_3464c816_000115_1ba33335+0xe6>
  40c972:	mov    r13,rax
  40c975:	mov    rax,QWORD PTR [r13+0x0]
  40c979:	test   rax,rax
  40c97c:	jne    40c930 <__swc_fn_3464c816_000115_1ba33335+0x90>
  40c97e:	mov    rcx,r12
  40c981:	call   4105c0 <__swc_fn_3464c816_000134_29412410>
  40c986:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c98c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c992:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c998:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c99e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c9a4:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c9ad:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c9b6:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c9bf:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c9c8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c9d1:	add    rsp,0xe0
  40c9d8:	pop    r14
  40c9da:	pop    r13
  40c9dc:	pop    r12
  40c9de:	pop    rdi
  40c9df:	pop    rsi
  40c9e0:	ret
	...

000000000040c9f0 <__swc_fn_3464c816_000118_7f430081>:
  40c9f0:	push   rdi
  40c9f1:	push   rsi
  40c9f2:	sub    rsp,0xa8
  40c9f9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c9ff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ca05:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ca0b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40ca11:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ca17:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40ca1d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ca23:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ca29:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ca32:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ca3b:	mov    rdi,0xfffffffffffffd66
  40ca42:	xor    eax,eax
  40ca44:	call   407040 <exit@plt>
  40ca49:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ca4f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ca55:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ca5b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ca61:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ca67:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ca6d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ca73:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ca79:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ca82:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ca8b:	add    rsp,0xa8
  40ca92:	pop    rsi
  40ca93:	pop    rdi
  40ca94:	ret
	...

000000000040caa0 <__swc_fn_3464c816_000121_12b4ed22>:
  40caa0:	push   rbx
  40caa1:	push   rsi
  40caa2:	push   rdi
  40caa3:	sub    rsp,0x30
  40caa7:	mov    rbx,rdx
  40caaa:	mov    esi,ecx
  40caac:	test   ecx,ecx
  40caae:	je     40cb83 <__swc_fn_3464c816_000121_12b4ed22+0xe3>
  40cab4:	mov    rcx,rsi
  40cab7:	shl    rcx,0x4
  40cabb:	call   40bfb0 <__swc_fn_3464c816_000079_34776ded>
  40cac0:	test   rax,rax
  40cac3:	je     40cb72 <__swc_fn_3464c816_000121_12b4ed22+0xd2>
  40cac9:	mov    rcx,rsi
  40cacc:	xor    edx,edx
  40cace:	test   rsi,rsi
  40cad1:	jbe    40cb52 <__swc_fn_3464c816_000121_12b4ed22+0xb2>
  40cad7:	nop    WORD PTR [rax+rax*1+0x0]
  40cae0:	mov    r8d,edx
  40cae3:	mov    r9,QWORD PTR [rbx+r8*8]
  40cae7:	add    r8,r8
  40caea:	lea    r8,[rax+r8*8]
  40caee:	xor    r10d,r10d
  40caf1:	test   r9,r9
  40caf4:	je     40cb30 <__swc_fn_3464c816_000121_12b4ed22+0x90>
  40caf6:	mov    r11,r9
  40caf9:	mov    dil,BYTE PTR [r11]
  40cafc:	test   dil,dil
  40caff:	je     40cb30 <__swc_fn_3464c816_000121_12b4ed22+0x90>
  40cb01:	cs nop WORD PTR [rax+rax*1+0x0]
  40cb0b:	cs nop WORD PTR [rax+rax*1+0x0]
  40cb15:	cs nop WORD PTR [rax+rax*1+0x0]
  40cb1f:	nop
  40cb20:	add    r11,0x1
  40cb24:	add    r10,0x1
  40cb28:	mov    dil,BYTE PTR [r11]
  40cb2b:	test   dil,dil
  40cb2e:	jne    40cb20 <__swc_fn_3464c816_000121_12b4ed22+0x80>
  40cb30:	mov    QWORD PTR [rsp+0x18],r9
  40cb35:	mov    QWORD PTR [rsp+0x20],r10
  40cb3a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40cb40:	vmovups XMMWORD PTR [r8],xmm0
  40cb45:	add    rdx,0x1
  40cb49:	cmp    rdx,rcx
  40cb4c:	jb     40cae0 <__swc_fn_3464c816_000121_12b4ed22+0x40>
  40cb52:	lea    rcx,[rip+0x1a1f7]        # 426d50 <__swc_bss_base_3464c816+0x2d10>
  40cb59:	mov    QWORD PTR [rsp+0x8],rax
  40cb5e:	mov    esi,esi
  40cb60:	mov    QWORD PTR [rsp+0x10],rsi
  40cb65:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40cb6b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cb70:	jmp    40cb83 <__swc_fn_3464c816_000121_12b4ed22+0xe3>
  40cb72:	lea    rcx,[rip+0x69a7]        # 413520 <__swc_rdata_base_3464c816+0x410>
  40cb79:	call   410100 <__swc_fn_3464c816_000116_035d76a1>
  40cb7e:	call   40c9f0 <__swc_fn_3464c816_000118_7f430081>
  40cb83:	add    rsp,0x30
  40cb87:	pop    rdi
  40cb88:	pop    rsi
  40cb89:	pop    rbx
  40cb8a:	ret
  40cb8b:	add    BYTE PTR [rax],al
  40cb8d:	add    BYTE PTR [rax],al
	...

000000000040cb90 <__swc_fn_3464c816_000124_667fbf24>:
  40cb90:	push   rdi
  40cb91:	push   rsi
  40cb92:	sub    rsp,0xa8
  40cb99:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cb9f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cba5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cbab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cbb1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cbb7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cbbd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cbc3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cbc9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cbd2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cbdb:	mov    edi,ecx
  40cbdd:	xor    eax,eax
  40cbdf:	call   407100 <pthread_key_delete@plt>
  40cbe4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cbea:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cbf0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cbf6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cbfc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cc02:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cc08:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cc0e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cc14:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cc1d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cc26:	add    rsp,0xa8
  40cc2d:	pop    rsi
  40cc2e:	pop    rdi
  40cc2f:	ret

000000000040cc30 <__swc_fn_3464c816_000127_8dffa290>:
  40cc30:	push   rdi
  40cc31:	push   rsi
  40cc32:	sub    rsp,0xa8
  40cc39:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cc3f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cc45:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cc4b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cc51:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cc57:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cc5d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cc63:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cc69:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cc72:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cc7b:	test   rcx,rcx
  40cc7e:	je     40cc8f <__swc_fn_3464c816_000127_8dffa290+0x5f>
  40cc80:	lea    rax,[rcx-0x1]
  40cc84:	mov    eax,eax
  40cc86:	mov    edi,eax
  40cc88:	xor    eax,eax
  40cc8a:	call   407100 <pthread_key_delete@plt>
  40cc8f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cc95:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cc9b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cca1:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cca7:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ccad:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ccb3:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ccb9:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ccbf:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ccc8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ccd1:	add    rsp,0xa8
  40ccd8:	pop    rsi
  40ccd9:	pop    rdi
  40ccda:	ret
  40ccdb:	add    BYTE PTR [rax],al
  40ccdd:	add    BYTE PTR [rax],al
	...

000000000040cce0 <__swc_fn_3464c816_000130_c1196dfb>:
  40cce0:	push   rsi
  40cce1:	push   rdi
  40cce2:	sub    rsp,0xa8
  40cce9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ccef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ccf5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ccfb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cd01:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cd07:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cd0d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cd13:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cd19:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cd22:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cd2b:	xor    eax,eax
  40cd2d:	call   407110 <gettid@plt>
  40cd32:	movsxd rax,eax
  40cd35:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cd3b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cd41:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cd47:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cd4d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cd53:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cd59:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cd5f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cd65:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cd6e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cd77:	add    rsp,0xa8
  40cd7e:	pop    rdi
  40cd7f:	pop    rsi
  40cd80:	ret
	...

000000000040cd90 <__swc_fn_3464c816_000133_4b2af8da>:
  40cd90:	push   rbx
  40cd91:	push   rdi
  40cd92:	push   rsi
  40cd93:	sub    rsp,0xc0
  40cd9a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40cda0:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40cda6:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cdac:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40cdb2:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40cdb8:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cdbe:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cdc4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cdcd:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40cdd6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cddf:	mov    rbx,rcx
  40cde2:	cs nop WORD PTR [rax+rax*1+0x0]
  40cdec:	nop    DWORD PTR [rax+0x0]
  40cdf0:	mov    edx,0x80000000
  40cdf5:	xor    eax,eax
  40cdf7:	lock cmpxchg DWORD PTR [rbx],edx
  40cdfb:	test   eax,eax
  40cdfd:	je     40ce34 <__swc_fn_3464c816_000133_4b2af8da+0xa4>
  40cdff:	mov    eax,DWORD PTR [rbx]
  40ce01:	lea    rcx,[rsp+0x14]
  40ce06:	mov    DWORD PTR [rsp+0x14],eax
  40ce0a:	test   eax,eax
  40ce0c:	je     40cdf0 <__swc_fn_3464c816_000133_4b2af8da+0x60>
  40ce0e:	mov    QWORD PTR [rsp],0x0
  40ce16:	mov    edi,0xca
  40ce1b:	mov    rsi,rbx
  40ce1e:	mov    edx,0x80
  40ce23:	mov    ecx,DWORD PTR [rcx]
  40ce25:	xor    r8d,r8d
  40ce28:	xor    r9d,r9d
  40ce2b:	xor    eax,eax
  40ce2d:	call   407070 <syscall@plt>
  40ce32:	jmp    40cdf0 <__swc_fn_3464c816_000133_4b2af8da+0x60>
  40ce34:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ce3a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ce40:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ce46:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ce4c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ce52:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ce58:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ce5e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ce67:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ce70:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ce79:	add    rsp,0xc0
  40ce80:	pop    rsi
  40ce81:	pop    rdi
  40ce82:	pop    rbx
  40ce83:	ret
	...

000000000040ce90 <__swc_fn_3464c816_000136_3e875c27>:
  40ce90:	sub    rsp,0x8
  40ce94:	call   4105c0 <__swc_fn_3464c816_000134_29412410>
  40ce99:	add    rsp,0x8
  40ce9d:	ret
	...

000000000040cea0 <__swc_fn_3464c816_000139_7c02fe26>:
  40cea0:	push   rdi
  40cea1:	push   rsi
  40cea2:	sub    rsp,0xa8
  40cea9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ceaf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ceb5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cebb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cec1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cec7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cecd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ced3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ced9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cee2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ceeb:	mov    edi,0x28
  40cef0:	xor    eax,eax
  40cef2:	call   4070d0 <malloc@plt>
  40cef7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cefd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cf03:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cf09:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cf0f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cf15:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cf1b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cf21:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cf27:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cf30:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cf39:	add    rsp,0xa8
  40cf40:	pop    rsi
  40cf41:	pop    rdi
  40cf42:	ret
	...

000000000040cf50 <__swc_fn_3464c816_000142_56e56812>:
  40cf50:	mov    QWORD PTR [r8],0x0
  40cf57:	cmp    rdx,0x10
  40cf5b:	jae    40cf60 <__swc_fn_3464c816_000142_56e56812+0x10>
  40cf5d:	xor    eax,eax
  40cf5f:	ret
  40cf60:	mov    eax,DWORD PTR [rcx]
  40cf62:	cmp    eax,0x42445753
  40cf68:	jne    40cf72 <__swc_fn_3464c816_000142_56e56812+0x22>
  40cf6a:	mov    eax,DWORD PTR [rcx+0x4]
  40cf6d:	cmp    eax,0x1
  40cf70:	je     40cf75 <__swc_fn_3464c816_000142_56e56812+0x25>
  40cf72:	xor    eax,eax
  40cf74:	ret
  40cf75:	mov    QWORD PTR [r8],rdx
  40cf78:	mov    rax,rcx
  40cf7b:	ret
  40cf7c:	add    BYTE PTR [rax],al
	...

000000000040cf80 <__swc_fn_3464c816_000145_863755b5>:
  40cf80:	push   rbx
  40cf81:	sub    rsp,0xe0
  40cf88:	lea    rbx,[rsp+0x8]
  40cf8d:	vxorps xmm0,xmm0,xmm0
  40cf91:	vmovups XMMWORD PTR [rbx],xmm0
  40cf95:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40cf9a:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40cf9f:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40cfa4:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40cfa9:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  40cfae:	mov    DWORD PTR [rbx+0x60],0x0
  40cfb5:	mov    r8,rbx
  40cfb8:	mov    rdx,rcx
  40cfbb:	nop    DWORD PTR [rax+rax*1+0x0]
  40cfc0:	mov    r9,rdx
  40cfc3:	movabs rdx,0x6666666666666667
  40cfcd:	mov    rax,r9
  40cfd0:	imul   rdx
  40cfd3:	sar    rdx,0x2
  40cfd7:	mov    r10,rdx
  40cfda:	shr    rdx,0x3f
  40cfde:	add    r10,rdx
  40cfe1:	mov    rdx,r10
  40cfe4:	imul   r11,r10,0xa
  40cfe8:	sub    r9,r11
  40cfeb:	mov    r11,QWORD PTR [rip+0x654e]        # 413540 <__swc_rdata_base_3464c816+0x430>
  40cff2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40cff7:	mov    BYTE PTR [r8],r9b
  40cffa:	lea    r9,[r8+0x1]
  40cffe:	mov    r8,r9
  40d001:	test   r10,r10
  40d004:	jne    40cfc0 <__swc_fn_3464c816_000145_863755b5+0x40>
  40d006:	test   rcx,rcx
  40d009:	jge    40d013 <__swc_fn_3464c816_000145_863755b5+0x93>
  40d00b:	mov    BYTE PTR [r9],0x2d
  40d00f:	add    r8,0x1
  40d013:	mov    BYTE PTR [r8],0x0
  40d017:	sub    r8,0x1
  40d01b:	mov    rax,rbx
  40d01e:	cmp    rax,r8
  40d021:	jae    40d046 <__swc_fn_3464c816_000145_863755b5+0xc6>
  40d023:	cs nop WORD PTR [rax+rax*1+0x0]
  40d02d:	nop    DWORD PTR [rax]
  40d030:	mov    cl,BYTE PTR [r8]
  40d033:	mov    dl,BYTE PTR [rax]
  40d035:	mov    BYTE PTR [r8],dl
  40d038:	sub    r8,0x1
  40d03c:	mov    BYTE PTR [rax],cl
  40d03e:	inc    rax
  40d041:	cmp    rax,r8
  40d044:	jb     40d030 <__swc_fn_3464c816_000145_863755b5+0xb0>
  40d046:	xor    eax,eax
  40d048:	test   rbx,rbx
  40d04b:	je     40d06e <__swc_fn_3464c816_000145_863755b5+0xee>
  40d04d:	mov    rcx,rbx
  40d050:	mov    dl,BYTE PTR [rcx]
  40d052:	test   dl,dl
  40d054:	je     40d06e <__swc_fn_3464c816_000145_863755b5+0xee>
  40d056:	cs nop WORD PTR [rax+rax*1+0x0]
  40d060:	add    rcx,0x1
  40d064:	add    rax,0x1
  40d068:	mov    dl,BYTE PTR [rcx]
  40d06a:	test   dl,dl
  40d06c:	jne    40d060 <__swc_fn_3464c816_000145_863755b5+0xe0>
  40d06e:	mov    QWORD PTR [rbx+0xa8],rbx
  40d075:	mov    QWORD PTR [rbx+0xb0],rax
  40d07c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d084:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d08c:	lea    rcx,[rbx+0xb8]
  40d093:	call   410100 <__swc_fn_3464c816_000116_035d76a1>
  40d098:	add    rsp,0xe0
  40d09f:	pop    rbx
  40d0a0:	ret
	...

000000000040d0b0 <__swc_fn_3464c816_000148_9e4bc402>:
  40d0b0:	vxorps xmm0,xmm0,xmm0
  40d0b4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0b8:	mov    QWORD PTR [rcx+0x10],0x0
  40d0c0:	ret
	...

000000000040d0d0 <__swc_fn_3464c816_000151_9e4bc402>:
  40d0d0:	vxorps xmm0,xmm0,xmm0
  40d0d4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0dd:	vxorps xmm0,xmm0,xmm0
  40d0e1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0e6:	vmovups xmm0,XMMWORD PTR [rip+0x654a]        # 413638 <__swc_rdata_base_3464c816+0x528>
  40d0ee:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d0f3:	vxorps xmm0,xmm0,xmm0
  40d0f7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d0fc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d101:	mov    QWORD PTR [rcx+0x60],0x0
  40d109:	ret
  40d10a:	add    BYTE PTR [rax],al
  40d10c:	add    BYTE PTR [rax],al
	...

000000000040d110 <__swc_fn_3464c816_000154_9e4bc402>:
  40d110:	vxorps xmm0,xmm0,xmm0
  40d114:	vmovups XMMWORD PTR [rcx],xmm0
  40d118:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d11d:	vxorps xmm0,xmm0,xmm0
  40d121:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d126:	vmovups xmm0,XMMWORD PTR [rip+0x6632]        # 413760 <__swc_rdata_base_3464c816+0x650>
  40d12e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d133:	vxorps xmm0,xmm0,xmm0
  40d137:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d13c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d141:	vxorps xmm0,xmm0,xmm0
  40d145:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d14a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d14f:	vxorps xmm0,xmm0,xmm0
  40d153:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d15b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d163:	vxorps xmm0,xmm0,xmm0
  40d167:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d16f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d177:	vxorps xmm0,xmm0,xmm0
  40d17b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d183:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d18b:	mov    QWORD PTR [rcx+0xe0],0x0
  40d196:	ret
	...

000000000040d1a0 <__swc_fn_3464c816_000157_232ffa22>:
  40d1a0:	push   rbx
  40d1a1:	mov    rbx,rcx
  40d1a4:	call   411b90 <__swc_fn_3464c816_000158_b43b2f96>
  40d1a9:	mov    rax,QWORD PTR [rbx+0x10]
  40d1ad:	test   rax,rax
  40d1b0:	je     40d1c1 <__swc_fn_3464c816_000157_232ffa22+0x21>
  40d1b2:	mov    rcx,rbx
  40d1b5:	mov    rdx,rax
  40d1b8:	mov    r8,QWORD PTR [rbx+0x18]
  40d1bc:	call   409ec0 <__swc_fn_3464c816_000156_2745c4a5>
  40d1c1:	vxorps xmm0,xmm0,xmm0
  40d1c5:	vmovups XMMWORD PTR [rbx],xmm0
  40d1c9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d1ce:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d1d3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d1d8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d1dd:	mov    QWORD PTR [rbx+0x50],0x0
  40d1e5:	pop    rbx
  40d1e6:	ret
	...

000000000040d200 <__swc_fn_3464c816_000160_01cbb887>:
  40d200:	sub    rsp,0x10
  40d204:	mov    eax,r8d
  40d207:	mov    r8d,r9d
  40d20a:	test   r9d,r9d
  40d20d:	jne    40d226 <__swc_fn_3464c816_000160_01cbb887+0x26>
  40d20f:	vmovups xmm0,XMMWORD PTR [rip+0x6601]        # 413818 <__swc_rdata_base_3464c816+0x708>
  40d217:	vmovups XMMWORD PTR [r10],xmm0
  40d21c:	mov    eax,0x1
  40d221:	add    rsp,0x10
  40d225:	ret
  40d226:	mov    r9,r8
  40d229:	cmp    r8,rax
  40d22c:	jb     40d233 <__swc_fn_3464c816_000160_01cbb887+0x33>
  40d22e:	cmp    r9,rdx
  40d231:	jb     40d23a <__swc_fn_3464c816_000160_01cbb887+0x3a>
  40d233:	xor    eax,eax
  40d235:	add    rsp,0x10
  40d239:	ret
  40d23a:	xor    eax,eax
  40d23c:	lea    r8,[r9+rax*1]
  40d240:	cmp    r8,rdx
  40d243:	jae    40d273 <__swc_fn_3464c816_000160_01cbb887+0x73>
  40d245:	cs nop WORD PTR [rax+rax*1+0x0]
  40d24f:	cs nop WORD PTR [rax+rax*1+0x0]
  40d259:	nop    DWORD PTR [rax+0x0]
  40d260:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d265:	je     40d273 <__swc_fn_3464c816_000160_01cbb887+0x73>
  40d267:	inc    rax
  40d26a:	lea    r8,[r9+rax*1]
  40d26e:	cmp    r8,rdx
  40d271:	jb     40d260 <__swc_fn_3464c816_000160_01cbb887+0x60>
  40d273:	cmp    r8,rdx
  40d276:	jne    40d27f <__swc_fn_3464c816_000160_01cbb887+0x7f>
  40d278:	xor    eax,eax
  40d27a:	add    rsp,0x10
  40d27e:	ret
  40d27f:	add    rcx,r9
  40d282:	mov    QWORD PTR [rsp],rcx
  40d286:	mov    QWORD PTR [rsp+0x8],rax
  40d28b:	vmovups xmm0,XMMWORD PTR [rsp]
  40d290:	vmovups XMMWORD PTR [r10],xmm0
  40d295:	mov    eax,0x1
  40d29a:	add    rsp,0x10
  40d29e:	ret
	...

000000000040d2a0 <__swc_fn_3464c816_000163_8e41797b>:
  40d2a0:	push   rbp
  40d2a1:	push   rbx
  40d2a2:	push   rsi
  40d2a3:	push   rdi
  40d2a4:	push   r12
  40d2a6:	push   r13
  40d2a8:	push   r14
  40d2aa:	push   r15
  40d2ac:	sub    rsp,0x10
  40d2b0:	mov    rbp,rsp
  40d2b3:	vmovups XMMWORD PTR [rsp],xmm6
  40d2b8:	sub    rsp,0x50
  40d2bc:	mov    rbx,rsp
  40d2bf:	mov    rsi,r8
  40d2c2:	mov    QWORD PTR [rsp+0x30],r8
  40d2c7:	mov    rdi,rcx
  40d2ca:	mov    QWORD PTR [rsp+0x38],rcx
  40d2cf:	mov    r12,rdx
  40d2d2:	xor    r13b,r13b
  40d2d5:	mov    r14,QWORD PTR [rdi+0x8]
  40d2d9:	mov    QWORD PTR [rsp+0x40],r14
  40d2de:	xor    r15d,r15d
  40d2e1:	test   r14,r14
  40d2e4:	jbe    40d53e <__swc_fn_3464c816_000163_8e41797b+0x29e>
  40d2ea:	mov    r14,QWORD PTR [rdi]
  40d2ed:	mov    rax,QWORD PTR [rsp+0x40]
  40d2f2:	mov    QWORD PTR [rsp+0x48],r14
  40d2f7:	vmovups xmm6,XMMWORD PTR [rip+0x6139]        # 413438 <__swc_rdata_base_3464c816+0x328>
  40d2ff:	nop
  40d300:	cmp    QWORD PTR [r14+r15*8],0x0
  40d305:	jne    40d30f <__swc_fn_3464c816_000163_8e41797b+0x6f>
  40d307:	mov    r14,rax
  40d30a:	jmp    40d51e <__swc_fn_3464c816_000163_8e41797b+0x27e>
  40d30f:	mov    rcx,QWORD PTR [rdi]
  40d312:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d316:	mov    rdi,rbx
  40d319:	mov    rcx,rdi
  40d31c:	sub    rsp,0x8
  40d320:	mov    r14,rax
  40d323:	call   409f40 <__swc_fn_3464c816_000162_60216e69>
  40d328:	add    rsp,0x8
  40d32c:	mov    al,BYTE PTR [rbx]
  40d32e:	test   al,al
  40d330:	je     40d51e <__swc_fn_3464c816_000163_8e41797b+0x27e>
  40d336:	mov    al,BYTE PTR [rbx+0x1]
  40d339:	test   al,al
  40d33b:	jne    40d346 <__swc_fn_3464c816_000163_8e41797b+0xa6>
  40d33d:	test   sil,sil
  40d340:	je     40d51e <__swc_fn_3464c816_000163_8e41797b+0x27e>
  40d346:	test   r13b,r13b
  40d349:	jne    40d407 <__swc_fn_3464c816_000163_8e41797b+0x167>
  40d34f:	test   r12,r12
  40d352:	je     40d407 <__swc_fn_3464c816_000163_8e41797b+0x167>
  40d358:	mov    al,BYTE PTR [rbx+0x1]
  40d35b:	test   al,al
  40d35d:	je     40d51e <__swc_fn_3464c816_000163_8e41797b+0x27e>
  40d363:	mov    eax,DWORD PTR [rbx+0x28]
  40d366:	cmp    DWORD PTR [r12+0x20],eax
  40d36b:	jne    40d51e <__swc_fn_3464c816_000163_8e41797b+0x27e>
  40d371:	mov    rax,QWORD PTR [r12]
  40d375:	mov    rcx,QWORD PTR [r12+0x8]
  40d37a:	cmp    QWORD PTR [rbx+0x20],rcx
  40d37e:	jne    40d51e <__swc_fn_3464c816_000163_8e41797b+0x27e>
  40d384:	mov    cl,0x1
  40d386:	test   rax,rax
  40d389:	je     40d3f2 <__swc_fn_3464c816_000163_8e41797b+0x152>
  40d38f:	mov    rdx,QWORD PTR [rbx+0x20]
  40d393:	xor    r8d,r8d
  40d396:	test   rdx,rdx
  40d399:	jbe    40d3f2 <__swc_fn_3464c816_000163_8e41797b+0x152>
  40d39b:	mov    r9,QWORD PTR [rbx+0x18]
  40d39f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40d3a4:	cs nop WORD PTR [rax+rax*1+0x0]
  40d3ae:	xchg   ax,ax
  40d3b0:	mov    r10b,BYTE PTR [rax+r8*1]
  40d3b4:	cmp    BYTE PTR [r9+r8*1],r10b
  40d3b8:	je     40d3e9 <__swc_fn_3464c816_000163_8e41797b+0x149>
  40d3ba:	vmovq  r10,xmm0
  40d3bf:	cmp    BYTE PTR [r10+r8*1],0x5c
  40d3c4:	jne    40d3cd <__swc_fn_3464c816_000163_8e41797b+0x12d>
  40d3c6:	cmp    BYTE PTR [rax+r8*1],0x2f
  40d3cb:	je     40d3e9 <__swc_fn_3464c816_000163_8e41797b+0x149>
  40d3cd:	vmovq  r10,xmm0
  40d3d2:	cmp    BYTE PTR [r10+r8*1],0x2f
  40d3d7:	jne    40d3e0 <__swc_fn_3464c816_000163_8e41797b+0x140>
  40d3d9:	cmp    BYTE PTR [rax+r8*1],0x5c
  40d3de:	je     40d3e9 <__swc_fn_3464c816_000163_8e41797b+0x149>
  40d3e0:	xor    eax,eax
  40d3e2:	movzx  eax,al
  40d3e5:	mov    cl,al
  40d3e7:	jmp    40d3f2 <__swc_fn_3464c816_000163_8e41797b+0x152>
  40d3e9:	add    r8,0x1
  40d3ed:	cmp    r8,rdx
  40d3f0:	jb     40d3b0 <__swc_fn_3464c816_000163_8e41797b+0x110>
  40d3f2:	test   cl,cl
  40d3f4:	je     40d51e <__swc_fn_3464c816_000163_8e41797b+0x27e>
  40d3fa:	mov    eax,0x1
  40d3ff:	mov    r13b,al
  40d402:	jmp    40d51e <__swc_fn_3464c816_000163_8e41797b+0x27e>
  40d407:	mov    r13b,0x1
  40d40a:	sub    rsp,0x20
  40d40e:	mov    rax,rsp
  40d411:	lea    rcx,[rdi+0x8]
  40d415:	mov    QWORD PTR [rax],rcx
  40d418:	lea    rsi,[rip+0x5ef1]        # 413310 <__swc_rdata_base_3464c816+0x200>
  40d41f:	mov    QWORD PTR [rax+0x8],rsi
  40d423:	mov    QWORD PTR [rax+0x10],rsp
  40d427:	mov    QWORD PTR [rax+0x18],0x1
  40d42f:	lea    rcx,[rsp+0x10]
  40d434:	sub    rsp,0x8
  40d438:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  40d43d:	add    rsp,0x8
  40d441:	add    rsp,0x20
  40d445:	mov    al,BYTE PTR [rbx+0x1]
  40d448:	test   al,al
  40d44a:	je     40d4e7 <__swc_fn_3464c816_000163_8e41797b+0x247>
  40d450:	lea    rax,[rip+0x6461]        # 4138b8 <__swc_rdata_base_3464c816+0x7a8>
  40d457:	sub    rsp,0x20
  40d45b:	mov    rcx,rsp
  40d45e:	mov    QWORD PTR [rcx],rax
  40d461:	mov    QWORD PTR [rcx+0x8],rsi
  40d465:	mov    QWORD PTR [rcx+0x10],rsp
  40d469:	mov    QWORD PTR [rcx+0x18],0x1
  40d471:	lea    rcx,[rsp+0x10]
  40d476:	sub    rsp,0x8
  40d47a:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  40d47f:	add    rsp,0x8
  40d483:	add    rsp,0x20
  40d487:	mov    eax,DWORD PTR [rbx+0x28]
  40d48a:	sub    rsp,0x60
  40d48e:	mov    rcx,rsp
  40d491:	lea    rdx,[rdi+0x18]
  40d495:	mov    QWORD PTR [rcx+0x18],rdx
  40d499:	mov    QWORD PTR [rcx+0x20],rsi
  40d49d:	vmovups XMMWORD PTR [rcx],xmm6
  40d4a1:	mov    QWORD PTR [rcx+0x28],rsp
  40d4a5:	mov    QWORD PTR [rcx+0x30],rsi
  40d4a9:	mov    DWORD PTR [rcx+0x10],eax
  40d4ac:	lea    rax,[rsp+0x10]
  40d4b1:	mov    QWORD PTR [rcx+0x38],rax
  40d4b5:	lea    rax,[rip+0x5f14]        # 4133d0 <__swc_rdata_base_3464c816+0x2c0>
  40d4bc:	mov    QWORD PTR [rcx+0x40],rax
  40d4c0:	lea    rax,[rsp+0x18]
  40d4c5:	mov    QWORD PTR [rcx+0x48],rax
  40d4c9:	mov    QWORD PTR [rcx+0x50],0x3
  40d4d1:	lea    rcx,[rsp+0x48]
  40d4d6:	sub    rsp,0x8
  40d4da:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  40d4df:	add    rsp,0x8
  40d4e3:	add    rsp,0x60
  40d4e7:	lea    rax,[rip+0x5e7a]        # 413368 <__swc_rdata_base_3464c816+0x258>
  40d4ee:	sub    rsp,0x20
  40d4f2:	mov    rcx,rsp
  40d4f5:	mov    QWORD PTR [rcx],rax
  40d4f8:	mov    QWORD PTR [rcx+0x8],rsi
  40d4fc:	mov    QWORD PTR [rcx+0x10],rsp
  40d500:	mov    QWORD PTR [rcx+0x18],0x1
  40d508:	lea    rcx,[rsp+0x10]
  40d50d:	sub    rsp,0x8
  40d511:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  40d516:	add    rsp,0x8
  40d51a:	add    rsp,0x20
  40d51e:	add    r15,0x1
  40d522:	cmp    r15,r14
  40d525:	jae    40d53e <__swc_fn_3464c816_000163_8e41797b+0x29e>
  40d527:	mov    rsi,QWORD PTR [rsp+0x30]
  40d52c:	mov    rdi,QWORD PTR [rsp+0x38]
  40d531:	mov    rax,r14
  40d534:	mov    r14,QWORD PTR [rsp+0x48]
  40d539:	jmp    40d300 <__swc_fn_3464c816_000163_8e41797b+0x60>
  40d53e:	add    rsp,0x50
  40d542:	vmovups xmm6,XMMWORD PTR [rsp]
  40d547:	add    rsp,0x10
  40d54b:	pop    r15
  40d54d:	pop    r14
  40d54f:	pop    r13
  40d551:	pop    r12
  40d553:	pop    rdi
  40d554:	pop    rsi
  40d555:	pop    rbx
  40d556:	pop    rbp
  40d557:	ret
	...

000000000040d560 <__swc_fn_3464c816_000166_f6173642>:
  40d560:	sub    rsp,0x8
  40d564:	call   410390 <__swc_fn_3464c816_000125_ce762363>
  40d569:	add    rsp,0x8
  40d56d:	ret
	...

000000000040d570 <__swc_fn_3464c816_000169_4579a84c>:
  40d570:	push   rsi
  40d571:	sub    rsp,0x30
  40d575:	lea    rsi,[rip+0x19824]        # 426da0 <__swc_bss_base_3464c816+0x2d60>
  40d57c:	mov    rax,QWORD PTR [rsi]
  40d57f:	test   rax,rax
  40d582:	je     40d58a <__swc_fn_3464c816_000169_4579a84c+0x1a>
  40d584:	add    rsp,0x30
  40d588:	pop    rsi
  40d589:	ret
  40d58a:	mov    ecx,0x2
  40d58f:	mov    edx,0x8020
  40d594:	call   40fa00 <__swc_fn_3464c816_000107_4796e893>
  40d599:	test   rax,rax
  40d59c:	jne    40d5ad <__swc_fn_3464c816_000169_4579a84c+0x3d>
  40d59e:	mov    QWORD PTR [rsp+0x18],rax
  40d5a3:	call   40c9f0 <__swc_fn_3464c816_000118_7f430081>
  40d5a8:	mov    rax,QWORD PTR [rsp+0x18]
  40d5ad:	mov    rcx,rax
  40d5b0:	xchg   QWORD PTR [rsi],rcx
  40d5b3:	add    rsp,0x30
  40d5b7:	pop    rsi
  40d5b8:	ret
  40d5b9:	add    BYTE PTR [rax],al
  40d5bb:	add    BYTE PTR [rax],al
  40d5bd:	add    BYTE PTR [rax],al
	...

000000000040d5c0 <__swc_fn_3464c816_000172_97fbc432>:
  40d5c0:	push   rsi
  40d5c1:	test   r8,r8
  40d5c4:	jne    40d5c8 <__swc_fn_3464c816_000172_97fbc432+0x8>
  40d5c6:	pop    rsi
  40d5c7:	ret
  40d5c8:	lea    rax,[rcx+0x18]
  40d5cc:	mov    r10,QWORD PTR [rax]
  40d5cf:	lea    r11,[r10+0x1]
  40d5d3:	mov    QWORD PTR [rax],r11
  40d5d6:	mov    r11,rdx
  40d5d9:	not    rdx
  40d5dc:	lea    rsi,[r8-0x1]
  40d5e0:	cmp    rsi,rdx
  40d5e3:	ja     40d603 <__swc_fn_3464c816_000172_97fbc432+0x43>
  40d5e5:	lea    rdx,[r11+r8*1]
  40d5e9:	dec    rdx
  40d5ec:	shr    rdx,0x6
  40d5f0:	mov    r8,r11
  40d5f3:	shr    r8,0x6
  40d5f7:	mov    rsi,rdx
  40d5fa:	sub    rsi,r8
  40d5fd:	cmp    rsi,0x8
  40d601:	jb     40d619 <__swc_fn_3464c816_000172_97fbc432+0x59>
  40d603:	lea    rcx,[rcx+0x10]
  40d607:	mov    rdx,QWORD PTR [rcx]
  40d60a:	add    rdx,r9
  40d60d:	mov    QWORD PTR [rcx],rdx
  40d610:	lea    rcx,[r10+0x2]
  40d614:	mov    QWORD PTR [rax],rcx
  40d617:	pop    rsi
  40d618:	ret
  40d619:	shr    r11,0x6
  40d61d:	nop    DWORD PTR [rax]
  40d620:	cmp    r11,rdx
  40d623:	ja     40d663 <__swc_fn_3464c816_000172_97fbc432+0xa3>
  40d625:	jmp    40d636 <__swc_fn_3464c816_000172_97fbc432+0x76>
  40d627:	nop    WORD PTR [rax+rax*1+0x0]
  40d630:	add    r11,0x1
  40d634:	jmp    40d620 <__swc_fn_3464c816_000172_97fbc432+0x60>
  40d636:	mov    r8,r11
  40d639:	shr    r8,0xc
  40d63d:	mov    rsi,r11
  40d640:	xor    rsi,r8
  40d643:	mov    r8,r11
  40d646:	shr    r8,0x18
  40d64a:	xor    rsi,r8
  40d64d:	and    esi,0xfff
  40d653:	lea    r8,[rcx+rsi*8+0x20]
  40d658:	mov    rsi,QWORD PTR [r8]
  40d65b:	add    rsi,r9
  40d65e:	mov    QWORD PTR [r8],rsi
  40d661:	jmp    40d630 <__swc_fn_3464c816_000172_97fbc432+0x70>
  40d663:	lea    rcx,[r10+0x2]
  40d667:	mov    QWORD PTR [rax],rcx
  40d66a:	pop    rsi
  40d66b:	ret
	...

000000000040d680 <__swc_fn_3464c816_000175_7f24d040>:
  40d680:	push   rbp
  40d681:	push   rbx
  40d682:	push   rsi
  40d683:	push   rdi
  40d684:	push   r12
  40d686:	push   r13
  40d688:	push   r15
  40d68a:	push   r14
  40d68c:	sub    rsp,0x50
  40d690:	mov    rbp,rsp
  40d693:	vmovups XMMWORD PTR [rsp],xmm6
  40d698:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  40d69e:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  40d6a4:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  40d6aa:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  40d6b0:	sub    rsp,0x70
  40d6b4:	mov    rbx,rsp
  40d6b7:	mov    ecx,0x1000000
  40d6bc:	sub    rsp,0x8
  40d6c0:	call   4120a0 <__swc_fn_3464c816_000176_2744b483>
  40d6c5:	add    rsp,0x8
  40d6c9:	mov    rsi,rax
  40d6cc:	mov    QWORD PTR [rsp+0x50],rax
  40d6d1:	xor    ecx,ecx
  40d6d3:	cs nop WORD PTR [rax+rax*1+0x0]
  40d6dd:	cs nop WORD PTR [rax+rax*1+0x0]
  40d6e7:	nop    WORD PTR [rax+rax*1+0x0]
  40d6f0:	mov    r8,QWORD PTR [rip+0x14919]        # 422010 <__swc_data_base_3464c816+0x10>
  40d6f7:	imul   r8,r8,0x41a7
  40d6fe:	movabs rdx,0x200000005
  40d708:	mov    r11,rax
  40d70b:	mov    rax,r8
  40d70e:	mul    rdx
  40d711:	mov    r9,rdx
  40d714:	mov    rdx,r8
  40d717:	sub    rdx,r9
  40d71a:	shr    rdx,1
  40d71d:	add    rdx,r9
  40d720:	shr    rdx,0x1e
  40d724:	imul   r9,rdx,0x7fffffff
  40d72b:	sub    r8,r9
  40d72e:	mov    QWORD PTR [rip+0x148db],r8        # 422010 <__swc_data_base_3464c816+0x10>
  40d735:	mov    DWORD PTR [rsi+rcx*4],r8d
  40d739:	add    rcx,0x1
  40d73d:	mov    r8,QWORD PTR [rip+0x148cc]        # 422010 <__swc_data_base_3464c816+0x10>
  40d744:	imul   r8,r8,0x41a7
  40d74b:	movabs rdx,0x200000005
  40d755:	mov    rax,r8
  40d758:	mul    rdx
  40d75b:	mov    r9,rdx
  40d75e:	mov    rax,r11
  40d761:	mov    rdx,r8
  40d764:	sub    rdx,r9
  40d767:	shr    rdx,1
  40d76a:	add    rdx,r9
  40d76d:	shr    rdx,0x1e
  40d771:	imul   rdx,rdx,0x7fffffff
  40d778:	sub    r8,rdx
  40d77b:	mov    QWORD PTR [rip+0x1488e],r8        # 422010 <__swc_data_base_3464c816+0x10>
  40d782:	mov    DWORD PTR [rsi+rcx*4],r8d
  40d786:	add    rcx,0x1
  40d78a:	cmp    rcx,0x400000
  40d791:	jb     40d6f0 <__swc_fn_3464c816_000175_7f24d040+0x70>
  40d797:	mov    rcx,QWORD PTR [rip+0x14872]        # 422010 <__swc_data_base_3464c816+0x10>
  40d79e:	imul   rcx,rcx,0x41a7
  40d7a5:	movabs rdx,0x200000005
  40d7af:	mov    rax,rcx
  40d7b2:	mul    rdx
  40d7b5:	mov    r8,rdx
  40d7b8:	mov    rdx,rcx
  40d7bb:	sub    rdx,r8
  40d7be:	shr    rdx,1
  40d7c1:	add    rdx,r8
  40d7c4:	shr    rdx,0x1e
  40d7c8:	imul   r8,rdx,0x7fffffff
  40d7cf:	mov    rdi,rcx
  40d7d2:	sub    rdi,r8
  40d7d5:	mov    QWORD PTR [rip+0x14834],rdi        # 422010 <__swc_data_base_3464c816+0x10>
  40d7dc:	imul   rcx,rdi,0x41a7
  40d7e3:	movabs rdx,0x200000005
  40d7ed:	mov    rax,rcx
  40d7f0:	mul    rdx
  40d7f3:	mov    r8,rdx
  40d7f6:	mov    rdx,rcx
  40d7f9:	sub    rdx,r8
  40d7fc:	shr    rdx,1
  40d7ff:	add    rdx,r8
  40d802:	shr    rdx,0x1e
  40d806:	imul   rdx,rdx,0x7fffffff
  40d80d:	mov    r12,rcx
  40d810:	sub    r12,rdx
  40d813:	mov    QWORD PTR [rip+0x147f6],r12        # 422010 <__swc_data_base_3464c816+0x10>
  40d81a:	imul   rcx,r12,0x41a7
  40d821:	movabs rdx,0x200000005
  40d82b:	mov    rax,rcx
  40d82e:	mul    rdx
  40d831:	mov    r8,rdx
  40d834:	mov    rdx,rcx
  40d837:	sub    rdx,r8
  40d83a:	shr    rdx,1
  40d83d:	add    rdx,r8
  40d840:	shr    rdx,0x1e
  40d844:	imul   rdx,rdx,0x7fffffff
  40d84b:	mov    r13,rcx
  40d84e:	sub    r13,rdx
  40d851:	mov    QWORD PTR [rip+0x147b8],r13        # 422010 <__swc_data_base_3464c816+0x10>
  40d858:	imul   rcx,r13,0x41a7
  40d85f:	movabs rdx,0x200000005
  40d869:	mov    rax,rcx
  40d86c:	mul    rdx
  40d86f:	mov    r8,rdx
  40d872:	mov    rdx,rcx
  40d875:	sub    rdx,r8
  40d878:	shr    rdx,1
  40d87b:	add    rdx,r8
  40d87e:	shr    rdx,0x1e
  40d882:	imul   rdx,rdx,0x7fffffff
  40d889:	mov    r14,rcx
  40d88c:	sub    r14,rdx
  40d88f:	mov    QWORD PTR [rip+0x1477a],r14        # 422010 <__swc_data_base_3464c816+0x10>
  40d896:	imul   rcx,r14,0x41a7
  40d89d:	movabs rdx,0x200000005
  40d8a7:	mov    rax,rcx
  40d8aa:	mul    rdx
  40d8ad:	mov    r8,rdx
  40d8b0:	mov    rdx,rcx
  40d8b3:	sub    rdx,r8
  40d8b6:	shr    rdx,1
  40d8b9:	add    rdx,r8
  40d8bc:	shr    rdx,0x1e
  40d8c0:	imul   rdx,rdx,0x7fffffff
  40d8c7:	mov    r15,rcx
  40d8ca:	sub    r15,rdx
  40d8cd:	mov    QWORD PTR [rip+0x1473c],r15        # 422010 <__swc_data_base_3464c816+0x10>
  40d8d4:	imul   rcx,r15,0x41a7
  40d8db:	movabs rdx,0x200000005
  40d8e5:	mov    rax,rcx
  40d8e8:	mul    rdx
  40d8eb:	mov    r8,rdx
  40d8ee:	mov    rdx,rcx
  40d8f1:	sub    rdx,r8
  40d8f4:	shr    rdx,1
  40d8f7:	add    rdx,r8
  40d8fa:	shr    rdx,0x1e
  40d8fe:	imul   rdx,rdx,0x7fffffff
  40d905:	mov    rsi,rcx
  40d908:	sub    rsi,rdx
  40d90b:	mov    QWORD PTR [rip+0x146fe],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40d912:	imul   rcx,rsi,0x41a7
  40d919:	movabs rdx,0x200000005
  40d923:	mov    rax,rcx
  40d926:	mul    rdx
  40d929:	mov    r8,rdx
  40d92c:	mov    rdx,rcx
  40d92f:	sub    rdx,r8
  40d932:	shr    rdx,1
  40d935:	add    rdx,r8
  40d938:	shr    rdx,0x1e
  40d93c:	imul   rdx,rdx,0x7fffffff
  40d943:	mov    QWORD PTR [rsp+0x58],rsi
  40d948:	mov    rsi,rcx
  40d94b:	sub    rsi,rdx
  40d94e:	mov    QWORD PTR [rip+0x146bb],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40d955:	imul   rcx,rsi,0x41a7
  40d95c:	movabs rdx,0x200000005
  40d966:	mov    rax,rcx
  40d969:	mul    rdx
  40d96c:	mov    r8,rdx
  40d96f:	mov    rdx,rcx
  40d972:	sub    rdx,r8
  40d975:	shr    rdx,1
  40d978:	add    rdx,r8
  40d97b:	shr    rdx,0x1e
  40d97f:	imul   rdx,rdx,0x7fffffff
  40d986:	mov    QWORD PTR [rsp+0x60],rsi
  40d98b:	mov    rsi,rcx
  40d98e:	sub    rsi,rdx
  40d991:	mov    QWORD PTR [rip+0x14678],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40d998:	mov    QWORD PTR [rbx],0x0
  40d99f:	mov    rcx,QWORD PTR [rip+0x1466a]        # 422010 <__swc_data_base_3464c816+0x10>
  40d9a6:	imul   rcx,rcx,0x41a7
  40d9ad:	movabs rdx,0x200000005
  40d9b7:	mov    rax,rcx
  40d9ba:	mul    rdx
  40d9bd:	mov    r8,rdx
  40d9c0:	mov    rdx,rcx
  40d9c3:	sub    rdx,r8
  40d9c6:	shr    rdx,1
  40d9c9:	add    rdx,r8
  40d9cc:	shr    rdx,0x1e
  40d9d0:	imul   r8,rdx,0x7fffffff
  40d9d7:	mov    QWORD PTR [rsp+0x68],rsi
  40d9dc:	mov    rsi,rcx
  40d9df:	sub    rsi,r8
  40d9e2:	mov    QWORD PTR [rip+0x14627],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40d9e9:	mov    DWORD PTR [rbx],esi
  40d9eb:	mov    rcx,QWORD PTR [rip+0x1461e]        # 422010 <__swc_data_base_3464c816+0x10>
  40d9f2:	imul   rcx,rcx,0x41a7
  40d9f9:	movabs rdx,0x200000005
  40da03:	mov    rax,rcx
  40da06:	mul    rdx
  40da09:	mov    r8,rdx
  40da0c:	mov    rdx,rcx
  40da0f:	sub    rdx,r8
  40da12:	shr    rdx,1
  40da15:	add    rdx,r8
  40da18:	shr    rdx,0x1e
  40da1c:	imul   r8,rdx,0x7fffffff
  40da23:	mov    rsi,rcx
  40da26:	sub    rsi,r8
  40da29:	mov    QWORD PTR [rip+0x145e0],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40da30:	mov    DWORD PTR [rbx+0x4],esi
  40da33:	mov    rcx,QWORD PTR [rip+0x145d6]        # 422010 <__swc_data_base_3464c816+0x10>
  40da3a:	imul   rcx,rcx,0x41a7
  40da41:	movabs rdx,0x200000005
  40da4b:	mov    rax,rcx
  40da4e:	mul    rdx
  40da51:	mov    r8,rdx
  40da54:	mov    rdx,rcx
  40da57:	sub    rdx,r8
  40da5a:	shr    rdx,1
  40da5d:	add    rdx,r8
  40da60:	shr    rdx,0x1e
  40da64:	imul   r8,rdx,0x7fffffff
  40da6b:	mov    rsi,rcx
  40da6e:	sub    rsi,r8
  40da71:	mov    QWORD PTR [rip+0x14598],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40da78:	sub    rsp,0x8
  40da7c:	call   40a380 <__swc_fn_3464c816_000177_1ca87929>
  40da81:	add    rsp,0x8
  40da85:	vmovups xmm6,xmm0
  40da89:	lea    rax,[rbx+0xc]
  40da8d:	vxorps xmm0,xmm0,xmm0
  40da91:	vmovups XMMWORD PTR [rbx+0xc],xmm0
  40da96:	vmovups XMMWORD PTR [rbx+0x1c],xmm0
  40da9b:	vmovups XMMWORD PTR [rbx+0x2c],xmm0
  40daa0:	vmovups XMMWORD PTR [rbx+0x3c],xmm0
  40daa5:	mov    DWORD PTR [rax],0x61707865
  40daab:	mov    DWORD PTR [rax+0x4],0x3320646e
  40dab2:	mov    DWORD PTR [rax+0x8],0x79622d32
  40dab9:	mov    DWORD PTR [rax+0xc],0x6b206574
  40dac0:	mov    DWORD PTR [rbx+0x1c],edi
  40dac3:	mov    DWORD PTR [rbx+0x20],r12d
  40dac7:	mov    DWORD PTR [rbx+0x24],r13d
  40dacb:	mov    DWORD PTR [rbx+0x28],r14d
  40dacf:	mov    DWORD PTR [rbx+0x2c],r15d
  40dad3:	mov    rax,QWORD PTR [rsp+0x58]
  40dad8:	mov    DWORD PTR [rbx+0x30],eax
  40dadb:	mov    rax,QWORD PTR [rsp+0x60]
  40dae0:	mov    DWORD PTR [rbx+0x34],eax
  40dae3:	mov    rax,QWORD PTR [rsp+0x68]
  40dae8:	mov    DWORD PTR [rbx+0x38],eax
  40daeb:	mov    eax,DWORD PTR [rbx]
  40daed:	mov    DWORD PTR [rbx+0x40],eax
  40daf0:	mov    eax,DWORD PTR [rbx+0x4]
  40daf3:	mov    DWORD PTR [rbx+0x44],eax
  40daf6:	mov    DWORD PTR [rbx+0x48],esi
  40daf9:	xor    eax,eax
  40dafb:	mov    ecx,0x1
  40db00:	vmovups xmm0,XMMWORD PTR [rip+0x5eb8]        # 4139c0 <__swc_rdata_base_3464c816+0x8b0>
  40db08:	mov    rsi,QWORD PTR [rsp+0x50]
  40db0d:	vmovups xmm1,XMMWORD PTR [rip+0x5ebb]        # 4139d0 <__swc_rdata_base_3464c816+0x8c0>
  40db15:	cmp    rax,0x400000
  40db1c:	jae    40dc9b <__swc_fn_3464c816_000175_7f24d040+0x61b>
  40db22:	cs nop WORD PTR [rax+rax*1+0x0]
  40db2c:	nop    DWORD PTR [rax+0x0]
  40db30:	mov    DWORD PTR [rbx+0x3c],ecx
  40db33:	vmovups xmm3,XMMWORD PTR [rbx+0xc]
  40db38:	vmovups xmm4,XMMWORD PTR [rbx+0x1c]
  40db3d:	vmovups xmm5,XMMWORD PTR [rbx+0x2c]
  40db42:	vmovups xmm2,XMMWORD PTR [rbx+0x3c]
  40db47:	xor    edx,edx
  40db49:	cs nop WORD PTR [rax+rax*1+0x0]
  40db53:	cs nop WORD PTR [rax+rax*1+0x0]
  40db5d:	nop    DWORD PTR [rax]
  40db60:	vpaddd xmm3,xmm3,xmm4
  40db64:	vpxor  xmm2,xmm2,xmm3
  40db68:	vpshufb xmm2,xmm2,xmm0
  40db6d:	vpaddd xmm5,xmm5,xmm2
  40db71:	vpxor  xmm4,xmm4,xmm5
  40db75:	vpslld xmm7,xmm4,0xc
  40db7a:	vpsrld xmm4,xmm4,0x14
  40db7f:	vpor   xmm4,xmm7,xmm4
  40db83:	vpaddd xmm3,xmm3,xmm4
  40db87:	vpshufd xmm7,xmm3,0x39
  40db8c:	vpshufd xmm2,xmm2,0x39
  40db91:	vpxor  xmm2,xmm2,xmm7
  40db95:	vpshufb xmm2,xmm2,xmm1
  40db9a:	vpshufd xmm5,xmm5,0x39
  40db9f:	vpaddd xmm5,xmm5,xmm2
  40dba3:	vpshufd xmm4,xmm4,0x39
  40dba8:	vpxor  xmm4,xmm4,xmm5
  40dbac:	vpslld xmm7,xmm4,0x7
  40dbb1:	vpsrld xmm4,xmm4,0x19
  40dbb6:	vpor   xmm4,xmm7,xmm4
  40dbba:	vpaddd xmm3,xmm3,xmm4
  40dbbe:	vpshufd xmm2,xmm2,0x4e
  40dbc3:	vpxor  xmm2,xmm2,xmm3
  40dbc7:	vpshufb xmm2,xmm2,xmm0
  40dbcc:	vpshufd xmm5,xmm5,0x39
  40dbd1:	vpaddd xmm5,xmm5,xmm2
  40dbd5:	vpxor  xmm4,xmm4,xmm5
  40dbd9:	vpslld xmm7,xmm4,0xc
  40dbde:	vpsrld xmm4,xmm4,0x14
  40dbe3:	vpor   xmm4,xmm7,xmm4
  40dbe7:	vpaddd xmm3,xmm3,xmm4
  40dbeb:	vpshufd xmm2,xmm2,0x93
  40dbf0:	vpshufd xmm7,xmm3,0x93
  40dbf5:	vpxor  xmm2,xmm2,xmm7
  40dbf9:	vpshufb xmm2,xmm2,xmm1
  40dbfe:	vpshufd xmm5,xmm5,0x93
  40dc03:	vpaddd xmm5,xmm5,xmm2
  40dc07:	vpshufd xmm4,xmm4,0x93
  40dc0c:	vpxor  xmm4,xmm4,xmm5
  40dc10:	vpslld xmm7,xmm4,0x7
  40dc15:	vpsrld xmm4,xmm4,0x19
  40dc1a:	vpor   xmm4,xmm7,xmm4
  40dc1e:	vpshufd xmm5,xmm5,0x93
  40dc23:	vpshufd xmm2,xmm2,0x4e
  40dc28:	add    rdx,0x1
  40dc2c:	cmp    rdx,0xa
  40dc30:	jb     40db60 <__swc_fn_3464c816_000175_7f24d040+0x4e0>
  40dc36:	lea    rdx,[rsi+rax*4]
  40dc3a:	vpaddd xmm3,xmm3,XMMWORD PTR [rsp+0xc]
  40dc40:	vpxor  xmm3,xmm3,XMMWORD PTR [rsi+rax*4]
  40dc45:	vpaddd xmm4,xmm4,XMMWORD PTR [rsp+0x1c]
  40dc4b:	vpxor  xmm4,xmm4,XMMWORD PTR [rsi+rax*4+0x10]
  40dc51:	vpaddd xmm5,xmm5,XMMWORD PTR [rsp+0x2c]
  40dc57:	vpxor  xmm5,xmm5,XMMWORD PTR [rsi+rax*4+0x20]
  40dc5d:	vpaddd xmm7,xmm2,XMMWORD PTR [rsp+0x3c]
  40dc63:	vpxor  xmm7,xmm7,XMMWORD PTR [rsi+rax*4+0x30]
  40dc69:	vmovdqu XMMWORD PTR [rdx],xmm3
  40dc6d:	vmovdqu XMMWORD PTR [rdx+0x10],xmm4
  40dc72:	vmovdqu XMMWORD PTR [rdx+0x20],xmm5
  40dc77:	vmovdqu XMMWORD PTR [rdx+0x30],xmm7
  40dc7c:	vpshufd xmm2,xmm2,0x3
  40dc81:	vmovd  edx,xmm2
  40dc85:	add    edx,DWORD PTR [rbx+0x48]
  40dc88:	lea    rax,[rax+0x10]
  40dc8c:	inc    ecx
  40dc8e:	cmp    rax,0x400000
  40dc95:	jb     40db30 <__swc_fn_3464c816_000175_7f24d040+0x4b0>
  40dc9b:	xor    edi,edi
  40dc9d:	xor    eax,eax
  40dc9f:	vxorps xmm0,xmm0,xmm0
  40dca3:	mov    ecx,0x1
  40dca8:	vpinsrd xmm0,xmm0,ecx,0x1
  40dcae:	mov    ecx,0x2
  40dcb3:	vpinsrd xmm0,xmm0,ecx,0x2
  40dcb9:	mov    ecx,0x3
  40dcbe:	vpinsrd xmm0,xmm0,ecx,0x3
  40dcc4:	vmovss xmm1,DWORD PTR [rip+0x5d14]        # 4139e0 <__swc_rdata_base_3464c816+0x8d0>
  40dccc:	vpshufd xmm1,xmm1,0x0
  40dcd1:	vpaddd xmm2,xmm0,xmm1
  40dcd5:	vmovss xmm1,DWORD PTR [rip+0x5d0c]        # 4139e9 <__swc_rdata_base_3464c816+0x8d9>
  40dcdd:	vpshufd xmm1,xmm1,0x0
  40dce2:	vxorps xmm3,xmm3,xmm3
  40dce6:	vxorps xmm4,xmm4,xmm4
  40dcea:	nop    WORD PTR [rax+rax*1+0x0]
  40dcf0:	vpaddd xmm5,xmm0,XMMWORD PTR [rsi+rax*4]
  40dcf5:	vpxor  xmm3,xmm3,xmm5
  40dcf9:	vpaddd xmm5,xmm2,XMMWORD PTR [rsi+rax*4+0x10]
  40dcff:	vpxor  xmm4,xmm4,xmm5
  40dd03:	vpaddd xmm2,xmm2,xmm1
  40dd07:	vpaddd xmm0,xmm0,xmm1
  40dd0b:	add    rax,0x8
  40dd0f:	cmp    rax,0x3ffff9
  40dd16:	jb     40dcf0 <__swc_fn_3464c816_000175_7f24d040+0x670>
  40dd18:	vpxor  xmm3,xmm3,xmm4
  40dd1c:	vpshufd xmm5,xmm3,0x4e
  40dd21:	vpxor  xmm3,xmm3,xmm5
  40dd25:	vpshufd xmm5,xmm3,0xb1
  40dd2a:	vpxor  xmm3,xmm3,xmm5
  40dd2e:	vmovd  eax,xmm3
  40dd32:	xor    rdi,rax
  40dd35:	sub    rsp,0x8
  40dd39:	call   40a380 <__swc_fn_3464c816_000177_1ca87929>
  40dd3e:	add    rsp,0x8
  40dd42:	vsubsd xmm0,xmm0,xmm6
  40dd46:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x5ca4]        # 4139f2 <__swc_rdata_base_3464c816+0x8e2>
  40dd4e:	lea    rax,[rip+0x5613]        # 413368 <__swc_rdata_base_3464c816+0x258>
  40dd55:	sub    rsp,0x90
  40dd5c:	mov    rcx,rsp
  40dd5f:	vmovups xmm1,XMMWORD PTR [rip+0x5c31]        # 413998 <__swc_rdata_base_3464c816+0x888>
  40dd67:	vmovups XMMWORD PTR [rcx],xmm1
  40dd6b:	mov    QWORD PTR [rcx+0x30],rsp
  40dd6f:	lea    rdx,[rip+0x559a]        # 413310 <__swc_rdata_base_3464c816+0x200>
  40dd76:	mov    QWORD PTR [rcx+0x38],rdx
  40dd7a:	mov    QWORD PTR [rcx+0x10],rdi
  40dd7e:	lea    r8,[rsp+0x10]
  40dd83:	mov    QWORD PTR [rcx+0x40],r8
  40dd87:	lea    r8,[rip+0x5b7a]        # 413908 <__swc_rdata_base_3464c816+0x7f8>
  40dd8e:	mov    QWORD PTR [rcx+0x48],r8
  40dd92:	vmovups xmm1,XMMWORD PTR [rip+0x5c0e]        # 4139a8 <__swc_rdata_base_3464c816+0x898>
  40dd9a:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40dd9f:	lea    r8,[rsp+0x18]
  40dda4:	mov    QWORD PTR [rcx+0x50],r8
  40dda8:	mov    QWORD PTR [rcx+0x58],rdx
  40ddac:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40ddb1:	lea    r8,[rcx+0x28]
  40ddb5:	mov    QWORD PTR [rcx+0x60],r8
  40ddb9:	lea    r8,[rip+0x5b90]        # 413950 <__swc_rdata_base_3464c816+0x840>
  40ddc0:	mov    QWORD PTR [rcx+0x68],r8
  40ddc4:	mov    QWORD PTR [rcx+0x70],rax
  40ddc8:	mov    QWORD PTR [rcx+0x78],rdx
  40ddcc:	lea    rax,[rcx+0x30]
  40ddd0:	mov    QWORD PTR [rcx+0x80],rax
  40ddd7:	mov    QWORD PTR [rcx+0x88],0x5
  40dde2:	lea    rcx,[rcx+0x80]
  40dde9:	sub    rsp,0x8
  40dded:	call   410980 <__swc_fn_3464c816_000146_43f4fdca>
  40ddf2:	add    rsp,0x108
  40ddf9:	vmovups xmm6,XMMWORD PTR [rsp]
  40ddfe:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  40de04:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  40de0a:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  40de10:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  40de16:	add    rsp,0x50
  40de1a:	pop    r14
  40de1c:	pop    r15
  40de1e:	pop    r13
  40de20:	pop    r12
  40de22:	pop    rdi
  40de23:	pop    rsi
  40de24:	pop    rbx
  40de25:	pop    rbp
  40de26:	ret
	...

000000000040de40 <__swc_fn_3464c816_000002_884bb5c0>:
  40de40:	sub    rsp,0x8
  40de44:	call   40c640 <__swc_fn_3464c816_000109_8d425bd3>
  40de49:	mov    rcx,rax
  40de4c:	test   rax,rax
  40de4f:	je     40de76 <__swc_fn_3464c816_000002_884bb5c0+0x36>
  40de51:	lea    rdx,[rip+0x161e8]        # 424040 <__swc_bss_base_3464c816>
  40de58:	mov    r8,QWORD PTR [rip+0x161e1]        # 424040 <__swc_bss_base_3464c816>
  40de5f:	nop
  40de60:	lea    r9,[r8+0x1]
  40de64:	mov    rax,r8
  40de67:	lock cmpxchg QWORD PTR [rdx],r9
  40de6c:	cmp    rax,r8
  40de6f:	je     40de76 <__swc_fn_3464c816_000002_884bb5c0+0x36>
  40de71:	mov    r8,rax
  40de74:	jmp    40de60 <__swc_fn_3464c816_000002_884bb5c0+0x20>
  40de76:	mov    rax,rcx
  40de79:	add    rsp,0x8
  40de7d:	ret
	...

000000000040de80 <__swc_fn_3464c816_000005_b2240b56>:
  40de80:	mov    r8d,edx
  40de83:	xor    eax,eax
  40de85:	tzcnt  eax,edx
  40de89:	shrx   r9d,edx,eax
  40de8e:	mov    DWORD PTR [rcx+0x2c],edx
  40de91:	xor    eax,eax
  40de93:	tzcnt  eax,edx
  40de97:	mov    BYTE PTR [rcx+0x38],al
  40de9a:	mov    eax,0xffffffff
  40de9f:	xor    edx,edx
  40dea1:	div    r8d
  40dea4:	mov    DWORD PTR [rcx+0x34],eax
  40dea7:	mov    eax,r9d
  40deaa:	mov    edx,r9d
  40dead:	imul   edx,r9d
  40deb1:	mov    r8d,0x2
  40deb7:	sub    r8d,edx
  40deba:	imul   eax,r8d
  40debe:	mov    edx,r9d
  40dec1:	imul   edx,eax
  40dec4:	mov    r8d,0x2
  40deca:	sub    r8d,edx
  40decd:	imul   eax,r8d
  40ded1:	mov    edx,r9d
  40ded4:	imul   edx,eax
  40ded7:	mov    r8d,0x2
  40dedd:	sub    r8d,edx
  40dee0:	imul   eax,r8d
  40dee4:	mov    edx,r9d
  40dee7:	imul   edx,eax
  40deea:	mov    r8d,0x2
  40def0:	sub    r8d,edx
  40def3:	imul   eax,r8d
  40def7:	imul   r9d,eax
  40defb:	mov    edx,0x2
  40df00:	sub    edx,r9d
  40df03:	imul   eax,edx
  40df06:	mov    DWORD PTR [rcx+0x30],eax
  40df09:	ret
  40df0a:	add    BYTE PTR [rax],al
  40df0c:	add    BYTE PTR [rax],al
	...

000000000040df10 <__swc_fn_3464c816_000008_4e857afc>:
  40df10:	xor    eax,eax
  40df12:	mov    DWORD PTR [rcx+0x68],eax
  40df15:	ret
	...

000000000040df20 <__swc_fn_3464c816_000011_6493fbbc>:
  40df20:	mov    eax,DWORD PTR [rcx+0x28]
  40df23:	shlx   eax,edx,eax
  40df28:	shl    rax,0x10
  40df2c:	lea    rdx,[rcx+rax*1]
  40df30:	lea    rax,[rcx+0x3000]
  40df37:	cmp    rdx,rax
  40df3a:	cmovae rax,rdx
  40df3e:	ret
	...

000000000040df40 <__swc_fn_3464c816_000014_afb279e2>:
  40df40:	push   rsi
  40df41:	push   rdi
  40df42:	push   r12
  40df44:	push   r13
  40df46:	push   r14
  40df48:	mov    rsi,rdx
  40df4b:	mov    rdi,rcx
  40df4e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40df52:	mov    ecx,DWORD PTR [rdi+0x28]
  40df55:	shr    dl,cl
  40df57:	mov    r12d,0x1
  40df5d:	mov    ecx,edx
  40df5f:	shl    r12,cl
  40df62:	mov    r13d,DWORD PTR [rsi+0x3c]
  40df66:	rex mov BYTE PTR [rsi+0x3b],0x0
  40df6b:	mov    QWORD PTR [rsi+0x40],0x0
  40df73:	mov    QWORD PTR [rsi],0x0
  40df7a:	mov    rax,QWORD PTR [rsi+0x10]
  40df7e:	mov    QWORD PTR [rsi+0x20],rax
  40df82:	lea    r14,[rip+0x160bf]        # 424048 <__swc_bss_base_3464c816+0x8>
  40df89:	mov    rax,QWORD PTR [r14]
  40df8c:	shr    rax,0x2
  40df90:	mov    rcx,rax
  40df93:	cmp    rax,0x800000
  40df9a:	mov    eax,0x800000
  40df9f:	cmovb  rcx,rax
  40dfa3:	lea    r8,[rip+0x160ae]        # 424058 <__swc_bss_base_3464c816+0x18>
  40dfaa:	mov    rax,QWORD PTR [r8]
  40dfad:	mov    r9,rax
  40dfb0:	lea    r10,[r9+r13*1]
  40dfb4:	cmp    r10,rcx
  40dfb7:	ja     40dfdb <__swc_fn_3464c816_000014_afb279e2+0x9b>
  40dfb9:	mov    rax,r9
  40dfbc:	lock cmpxchg QWORD PTR [r8],r10
  40dfc1:	cmp    rax,r9
  40dfc4:	je     40dfcb <__swc_fn_3464c816_000014_afb279e2+0x8b>
  40dfc6:	mov    r9,rax
  40dfc9:	jmp    40dfb0 <__swc_fn_3464c816_000014_afb279e2+0x70>
  40dfcb:	mov    rcx,rdi
  40dfce:	mov    rdx,r12
  40dfd1:	call   40a770 <__swc_fn_3464c816_000016_4b207b58>
  40dfd6:	jmp    40e05d <__swc_fn_3464c816_000014_afb279e2+0x11d>
  40dfdb:	mov    rcx,rdi
  40dfde:	movzx  edx,dl
  40dfe1:	call   40df20 <__swc_fn_3464c816_000011_6493fbbc>
  40dfe6:	test   r13,r13
  40dfe9:	je     40e056 <__swc_fn_3464c816_000014_afb279e2+0x116>
  40dfef:	mov    rcx,rax
  40dff2:	mov    rdx,r13
  40dff5:	call   40c7c0 <__swc_fn_3464c816_000112_759e9ceb>
  40dffa:	mov    rcx,QWORD PTR [rip+0x16047]        # 424048 <__swc_bss_base_3464c816+0x8>
  40e001:	cs nop WORD PTR [rax+rax*1+0x0]
  40e00b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e010:	mov    rdx,rcx
  40e013:	sub    rdx,r13
  40e016:	mov    rax,rcx
  40e019:	lock cmpxchg QWORD PTR [r14],rdx
  40e01e:	cmp    rax,rcx
  40e021:	je     40e028 <__swc_fn_3464c816_000014_afb279e2+0xe8>
  40e023:	mov    rcx,rax
  40e026:	jmp    40e010 <__swc_fn_3464c816_000014_afb279e2+0xd0>
  40e028:	lea    rcx,[rip+0x16031]        # 424060 <__swc_bss_base_3464c816+0x20>
  40e02f:	mov    rdx,QWORD PTR [rip+0x1602a]        # 424060 <__swc_bss_base_3464c816+0x20>
  40e036:	cs nop WORD PTR [rax+rax*1+0x0]
  40e040:	lea    r8,[rdx+0x1]
  40e044:	mov    rax,rdx
  40e047:	lock cmpxchg QWORD PTR [rcx],r8
  40e04c:	cmp    rax,rdx
  40e04f:	je     40e056 <__swc_fn_3464c816_000014_afb279e2+0x116>
  40e051:	mov    rdx,rax
  40e054:	jmp    40e040 <__swc_fn_3464c816_000014_afb279e2+0x100>
  40e056:	mov    DWORD PTR [rsi+0x3c],0x0
  40e05d:	mov    rcx,rdi
  40e060:	mov    rdx,r12
  40e063:	call   407600 <__swc_fn_3464c816_000018_7d1e8a10>
  40e068:	pop    r14
  40e06a:	pop    r13
  40e06c:	pop    r12
  40e06e:	pop    rdi
  40e06f:	pop    rsi
  40e070:	ret
	...

000000000040e080 <__swc_fn_3464c816_000017_4df2d1a0>:
  40e080:	mov    r8,QWORD PTR [rcx+0x48]
  40e084:	test   r8,rdx
  40e087:	je     40e0b8 <__swc_fn_3464c816_000017_4df2d1a0+0x38>
  40e089:	nop    DWORD PTR [rax+0x0]
  40e090:	mov    rax,rdx
  40e093:	not    rax
  40e096:	mov    r9,r8
  40e099:	and    r9,rax
  40e09c:	mov    rax,r8
  40e09f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40e0a5:	cmp    rax,r8
  40e0a8:	jne    40e0b0 <__swc_fn_3464c816_000017_4df2d1a0+0x30>
  40e0aa:	mov    eax,0x1
  40e0af:	ret
  40e0b0:	mov    r8,rax
  40e0b3:	test   rax,rdx
  40e0b6:	jne    40e090 <__swc_fn_3464c816_000017_4df2d1a0+0x10>
  40e0b8:	xor    eax,eax
  40e0ba:	ret
  40e0bb:	add    BYTE PTR [rax],al
  40e0bd:	add    BYTE PTR [rax],al
	...

000000000040e0c0 <__swc_fn_3464c816_000020_a66e8b97>:
  40e0c0:	push   rsi
  40e0c1:	push   rdi
  40e0c2:	push   r12
  40e0c4:	push   r13
  40e0c6:	sub    rsp,0x8
  40e0ca:	mov    rsi,rdx
  40e0cd:	mov    rdi,rcx
  40e0d0:	lea    r12,[rip+0x16119]        # 4241f0 <__swc_bss_base_3464c816+0x1b0>
  40e0d7:	mov    rcx,r12
  40e0da:	call   4098c0 <__swc_fn_3464c816_000135_e3032dc2>
  40e0df:	xor    eax,eax
  40e0e1:	mov    rcx,QWORD PTR [rip+0x16110]        # 4241f8 <__swc_bss_base_3464c816+0x1b8>
  40e0e8:	mov    r13,rcx
  40e0eb:	test   r13,r13
  40e0ee:	je     40e13b <__swc_fn_3464c816_000020_a66e8b97+0x7b>
  40e0f0:	mov    rcx,QWORD PTR [r13+0x10]
  40e0f4:	cmp    DWORD PTR [r13+0x28],esi
  40e0f8:	jne    40e130 <__swc_fn_3464c816_000020_a66e8b97+0x70>
  40e0fa:	test   rax,rax
  40e0fd:	jne    40e108 <__swc_fn_3464c816_000020_a66e8b97+0x48>
  40e0ff:	mov    QWORD PTR [rip+0x160f2],rcx        # 4241f8 <__swc_bss_base_3464c816+0x1b8>
  40e106:	jmp    40e10c <__swc_fn_3464c816_000020_a66e8b97+0x4c>
  40e108:	mov    QWORD PTR [rax+0x10],rcx
  40e10c:	vxorps xmm0,xmm0,xmm0
  40e110:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40e116:	mov    QWORD PTR [r13+0x8],rdi
  40e11a:	mov    rcx,r12
  40e11d:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  40e122:	mov    rax,r13
  40e125:	add    rsp,0x8
  40e129:	pop    r13
  40e12b:	pop    r12
  40e12d:	pop    rdi
  40e12e:	pop    rsi
  40e12f:	ret
  40e130:	mov    rax,r13
  40e133:	mov    r13,rcx
  40e136:	test   rcx,rcx
  40e139:	jne    40e0f0 <__swc_fn_3464c816_000020_a66e8b97+0x30>
  40e13b:	mov    ecx,esi
  40e13d:	call   40a7a0 <__swc_fn_3464c816_000019_2cc1532c>
  40e142:	mov    rsi,rax
  40e145:	test   rax,rax
  40e148:	jne    40e15f <__swc_fn_3464c816_000020_a66e8b97+0x9f>
  40e14a:	mov    rcx,r12
  40e14d:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  40e152:	xor    eax,eax
  40e154:	add    rsp,0x8
  40e158:	pop    r13
  40e15a:	pop    r12
  40e15c:	pop    rdi
  40e15d:	pop    rsi
  40e15e:	ret
  40e15f:	mov    QWORD PTR [rsi+0x8],rdi
  40e163:	mov    rcx,r12
  40e166:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  40e16b:	mov    rax,rsi
  40e16e:	add    rsp,0x8
  40e172:	pop    r13
  40e174:	pop    r12
  40e176:	pop    rdi
  40e177:	pop    rsi
  40e178:	ret
  40e179:	add    BYTE PTR [rax],al
  40e17b:	add    BYTE PTR [rax],al
  40e17d:	add    BYTE PTR [rax],al
	...

000000000040e180 <__swc_fn_3464c816_000023_4aca8b9e>:
  40e180:	vxorps xmm0,xmm0,xmm0
  40e184:	xor    eax,eax
  40e186:	cs nop WORD PTR [rax+rax*1+0x0]
  40e190:	cs nop WORD PTR [rax+rax*1+0x0]
  40e19a:	nop    WORD PTR [rax+rax*1+0x0]
  40e1a0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40e1a5:	add    rax,0x10
  40e1a9:	cmp    rax,0x2b00
  40e1b0:	jne    40e1a0 <__swc_fn_3464c816_000023_4aca8b9e+0x20>
  40e1b2:	ret
	...

000000000040e1c0 <__swc_fn_3464c816_000026_4aca8b9e>:
  40e1c0:	vxorps xmm0,xmm0,xmm0
  40e1c4:	vmovups XMMWORD PTR [rcx],xmm0
  40e1c8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e1cd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e1d2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e1d7:	ret
	...

000000000040e1e0 <__swc_fn_3464c816_000029_4aca8b9e>:
  40e1e0:	vxorps xmm0,xmm0,xmm0
  40e1e4:	vmovups XMMWORD PTR [rcx],xmm0
  40e1e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e1ed:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e1f2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e1f7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40e1fc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40e201:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40e206:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40e20b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40e213:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40e21b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40e223:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40e22b:	mov    QWORD PTR [rcx+0xc0],0x0
  40e236:	ret
	...

000000000040e240 <__swc_fn_3464c816_000032_84881cd8>:
  40e240:	push   rsi
  40e241:	push   rdi
  40e242:	sub    rsp,0x8
  40e246:	mov    rsi,rcx
  40e249:	lea    rdi,[rip+0x13db0]        # 422000 <__swc_data_base_3464c816>
  40e250:	mov    rax,QWORD PTR [rdi]
  40e253:	cmp    rax,0xffffffffffffffff
  40e257:	je     40e25e <__swc_fn_3464c816_000032_84881cd8+0x1e>
  40e259:	mov    rdi,rax
  40e25c:	jmp    40e28b <__swc_fn_3464c816_000032_84881cd8+0x4b>
  40e25e:	call   4095a0 <__swc_fn_3464c816_000123_9d2cbd72>
  40e263:	mov    rcx,rax
  40e266:	cmp    rax,0xffffffffffffffff
  40e26a:	je     40e29c <__swc_fn_3464c816_000032_84881cd8+0x5c>
  40e26c:	mov    rax,0xffffffffffffffff
  40e273:	lock cmpxchg QWORD PTR [rdi],rcx
  40e278:	cmp    rax,0xffffffffffffffff
  40e27c:	je     40e288 <__swc_fn_3464c816_000032_84881cd8+0x48>
  40e27e:	mov    rdi,rax
  40e281:	call   40cb90 <__swc_fn_3464c816_000124_667fbf24>
  40e286:	jmp    40e28b <__swc_fn_3464c816_000032_84881cd8+0x4b>
  40e288:	mov    rdi,rcx
  40e28b:	cmp    rdi,0xffffffffffffffff
  40e28f:	je     40e29c <__swc_fn_3464c816_000032_84881cd8+0x5c>
  40e291:	mov    rcx,rdi
  40e294:	mov    rdx,rsi
  40e297:	call   410390 <__swc_fn_3464c816_000125_ce762363>
  40e29c:	add    rsp,0x8
  40e2a0:	pop    rdi
  40e2a1:	pop    rsi
  40e2a2:	ret
	...

000000000040e2b0 <__swc_fn_3464c816_000035_95622a2b>:
  40e2b0:	sub    rsp,0x38
  40e2b4:	mov    rax,rdx
  40e2b7:	test   dl,dl
  40e2b9:	jne    40e2d1 <__swc_fn_3464c816_000035_95622a2b+0x21>
  40e2bb:	mov    rax,r8
  40e2be:	test   r8b,r8b
  40e2c1:	cmove  eax,r9d
  40e2c5:	test   al,al
  40e2c7:	cmove  eax,r10d
  40e2cb:	test   al,al
  40e2cd:	cmove  eax,r11d
  40e2d1:	test   al,al
  40e2d3:	jne    40e2da <__swc_fn_3464c816_000035_95622a2b+0x2a>
  40e2d5:	add    rsp,0x38
  40e2d9:	ret
  40e2da:	lea    rcx,[rip+0x4e2f]        # 413110 <__swc_rdata_base_3464c816>
  40e2e1:	vmovups xmm0,XMMWORD PTR [rip+0x4e37]        # 413120 <__swc_rdata_base_3464c816+0x10>
  40e2e9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e2ef:	vmovups xmm0,XMMWORD PTR [rip+0x4e39]        # 413130 <__swc_rdata_base_3464c816+0x20>
  40e2f7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e2fd:	vmovups xmm0,XMMWORD PTR [rip+0x4e3b]        # 413140 <__swc_rdata_base_3464c816+0x30>
  40e305:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e30b:	lea    rdx,[rsp+0x8]
  40e310:	call   40c3c0 <__swc_fn_3464c816_000103_67100064>
  40e315:	jmp    40e2d5 <__swc_fn_3464c816_000035_95622a2b+0x25>
	...

000000000040e320 <__swc_fn_3464c816_000038_788ceb38>:
  40e320:	sub    rsp,0x8
  40e324:	mov    eax,0x1000
  40e329:	test   eax,eax
  40e32b:	mov    r8d,0x8
  40e331:	cmove  eax,r8d
  40e335:	dec    rax
  40e338:	mov    r8,0xffffffffffffffff
  40e33f:	sub    r8,rax
  40e342:	cmp    rdx,r8
  40e345:	ja     40e355 <__swc_fn_3464c816_000038_788ceb38+0x35>
  40e347:	add    rdx,rax
  40e34a:	not    rax
  40e34d:	mov    r8,rdx
  40e350:	and    r8,rax
  40e353:	jne    40e35c <__swc_fn_3464c816_000038_788ceb38+0x3c>
  40e355:	xor    eax,eax
  40e357:	add    rsp,0x8
  40e35b:	ret
  40e35c:	mov    rdx,r8
  40e35f:	call   40aac0 <__swc_fn_3464c816_000037_b4982903>
  40e364:	add    rsp,0x8
  40e368:	ret
  40e369:	add    BYTE PTR [rax],al
  40e36b:	add    BYTE PTR [rax],al
  40e36d:	add    BYTE PTR [rax],al
	...

000000000040e370 <__swc_fn_3464c816_000041_414cc921>:
  40e370:	push   rsi
  40e371:	push   rdi
  40e372:	sub    rsp,0x8
  40e376:	mov    rsi,rdx
  40e379:	mov    rdi,rcx
  40e37c:	test   rdx,rdx
  40e37f:	je     40e39b <__swc_fn_3464c816_000041_414cc921+0x2b>
  40e381:	xor    ecx,ecx
  40e383:	call   407720 <__swc_fn_3464c816_000033_7ca1566d>
  40e388:	mov    rax,QWORD PTR [rsi]
  40e38b:	test   rax,rax
  40e38e:	je     40e39b <__swc_fn_3464c816_000041_414cc921+0x2b>
  40e390:	mov    rcx,rax
  40e393:	mov    rdx,rsi
  40e396:	call   407840 <__swc_fn_3464c816_000042_bab03645>
  40e39b:	mov    rcx,rdi
  40e39e:	call   40ab20 <__swc_fn_3464c816_000040_6895916d>
  40e3a3:	mov    rsi,rax
  40e3a6:	test   rax,rax
  40e3a9:	jne    40e3b4 <__swc_fn_3464c816_000041_414cc921+0x44>
  40e3ab:	xor    eax,eax
  40e3ad:	add    rsp,0x8
  40e3b1:	pop    rdi
  40e3b2:	pop    rsi
  40e3b3:	ret
  40e3b4:	mov    rcx,rsi
  40e3b7:	call   407720 <__swc_fn_3464c816_000033_7ca1566d>
  40e3bc:	mov    rax,rsi
  40e3bf:	add    rsp,0x8
  40e3c3:	pop    rdi
  40e3c4:	pop    rsi
  40e3c5:	ret
	...

000000000040e3d0 <__swc_fn_3464c816_000044_9c2ade9b>:
  40e3d0:	movzx  eax,BYTE PTR [r8+0x39]
  40e3d5:	lea    rax,[rax+rax*4]
  40e3d9:	lea    rax,[rdx+rax*8+0x28]
  40e3de:	mov    ecx,DWORD PTR [r8+0x6c]
  40e3e2:	test   ecx,ecx
  40e3e4:	je     40e41d <__swc_fn_3464c816_000044_9c2ade9b+0x4d>
  40e3e6:	mov    rcx,QWORD PTR [r8+0x50]
  40e3ea:	test   rcx,rcx
  40e3ed:	je     40e3f9 <__swc_fn_3464c816_000044_9c2ade9b+0x29>
  40e3ef:	mov    rax,QWORD PTR [r8+0x48]
  40e3f3:	mov    QWORD PTR [rcx+0x48],rax
  40e3f7:	jmp    40e401 <__swc_fn_3464c816_000044_9c2ade9b+0x31>
  40e3f9:	mov    rcx,QWORD PTR [r8+0x48]
  40e3fd:	mov    QWORD PTR [rax+0x18],rcx
  40e401:	mov    rax,QWORD PTR [r8+0x48]
  40e405:	test   rax,rax
  40e408:	je     40e412 <__swc_fn_3464c816_000044_9c2ade9b+0x42>
  40e40a:	mov    rcx,QWORD PTR [r8+0x50]
  40e40e:	mov    QWORD PTR [rax+0x50],rcx
  40e412:	vxorps xmm0,xmm0,xmm0
  40e416:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e41c:	ret
  40e41d:	mov    rcx,QWORD PTR [r8+0x50]
  40e421:	test   rcx,rcx
  40e424:	je     40e430 <__swc_fn_3464c816_000044_9c2ade9b+0x60>
  40e426:	mov    rdx,QWORD PTR [r8+0x48]
  40e42a:	mov    QWORD PTR [rcx+0x48],rdx
  40e42e:	jmp    40e438 <__swc_fn_3464c816_000044_9c2ade9b+0x68>
  40e430:	mov    rcx,QWORD PTR [r8+0x48]
  40e434:	mov    QWORD PTR [rax+0x8],rcx
  40e438:	mov    rcx,QWORD PTR [r8+0x48]
  40e43c:	test   rcx,rcx
  40e43f:	je     40e44b <__swc_fn_3464c816_000044_9c2ade9b+0x7b>
  40e441:	mov    rdx,QWORD PTR [r8+0x50]
  40e445:	mov    QWORD PTR [rcx+0x50],rdx
  40e449:	jmp    40e453 <__swc_fn_3464c816_000044_9c2ade9b+0x83>
  40e44b:	mov    rcx,QWORD PTR [r8+0x50]
  40e44f:	mov    QWORD PTR [rax+0x10],rcx
  40e453:	cmp    QWORD PTR [rax],r8
  40e456:	jne    40e45f <__swc_fn_3464c816_000044_9c2ade9b+0x8f>
  40e458:	mov    QWORD PTR [rax],0x0
  40e45f:	vxorps xmm0,xmm0,xmm0
  40e463:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e469:	ret
  40e46a:	add    BYTE PTR [rax],al
  40e46c:	add    BYTE PTR [rax],al
	...

000000000040e470 <__swc_fn_3464c816_000047_bc5ec610>:
  40e470:	sub    rsp,0x8
  40e474:	mov    r9,r8
  40e477:	mov    r10,rdx
  40e47a:	call   40e3d0 <__swc_fn_3464c816_000044_9c2ade9b>
  40e47f:	mov    DWORD PTR [r9+0x6c],0x0
  40e487:	movzx  eax,BYTE PTR [r9+0x39]
  40e48c:	lea    rax,[rax+rax*4]
  40e490:	lea    rax,[r10+rax*8+0x28]
  40e495:	mov    rcx,QWORD PTR [rax+0x10]
  40e499:	mov    QWORD PTR [r9+0x50],rcx
  40e49d:	mov    QWORD PTR [r9+0x48],0x0
  40e4a5:	mov    rcx,QWORD PTR [rax+0x10]
  40e4a9:	test   rcx,rcx
  40e4ac:	je     40e4b4 <__swc_fn_3464c816_000047_bc5ec610+0x44>
  40e4ae:	mov    QWORD PTR [rcx+0x48],r9
  40e4b2:	jmp    40e4b8 <__swc_fn_3464c816_000047_bc5ec610+0x48>
  40e4b4:	mov    QWORD PTR [rax+0x8],r9
  40e4b8:	mov    QWORD PTR [rax+0x10],r9
  40e4bc:	add    rsp,0x8
  40e4c0:	ret
	...

000000000040e4e0 <__swc_fn_3464c816_000050_ab8077df>:
  40e4e0:	push   rsi
  40e4e1:	push   rdi
  40e4e2:	push   r12
  40e4e4:	push   r13
  40e4e6:	push   r14
  40e4e8:	push   r15
  40e4ea:	sub    rsp,0x1f8
  40e4f1:	mov    esi,r8d
  40e4f4:	mov    QWORD PTR [rsp+0x1e8],rsi
  40e4fc:	mov    rdi,rcx
  40e4ff:	mov    r12,rdx
  40e502:	lea    r13,[rsi+rsi*4]
  40e506:	lea    r13,[rdx+r13*8+0x28]
  40e50b:	call   407ca0 <__swc_fn_3464c816_000048_c877e9d2>
  40e510:	add    DWORD PTR [r12+0x24],0x1
  40e516:	test   BYTE PTR [r12+0x24],0x3f
  40e51c:	jne    40e526 <__swc_fn_3464c816_000050_ab8077df+0x46>
  40e51e:	mov    rcx,rdi
  40e521:	call   40aca0 <__swc_fn_3464c816_000049_2ff013cc>
  40e526:	mov    rax,QWORD PTR [r13+0x8]
  40e52a:	mov    r14,rax
  40e52d:	nop    DWORD PTR [rax]
  40e530:	test   r14,r14
  40e533:	jne    40e542 <__swc_fn_3464c816_000050_ab8077df+0x62>
  40e535:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40e53d:	jmp    40e649 <__swc_fn_3464c816_000050_ab8077df+0x169>
  40e542:	mov    r15,QWORD PTR [r14+0x48]
  40e546:	mov    rcx,r14
  40e549:	call   4073f0 <__swc_fn_3464c816_000009_d7e2bb25>
  40e54e:	mov    rax,QWORD PTR [r14]
  40e551:	test   rax,rax
  40e554:	je     40e566 <__swc_fn_3464c816_000050_ab8077df+0x86>
  40e556:	mov    rcx,QWORD PTR [rax]
  40e559:	mov    QWORD PTR [r14],rcx
  40e55c:	add    DWORD PTR [r14+0x28],0x1
  40e561:	mov    rsi,rax
  40e564:	jmp    40e585 <__swc_fn_3464c816_000050_ab8077df+0xa5>
  40e566:	mov    rax,QWORD PTR [r14+0x18]
  40e56a:	cmp    QWORD PTR [r14+0x20],rax
  40e56e:	jae    40e583 <__swc_fn_3464c816_000050_ab8077df+0xa3>
  40e570:	mov    rsi,QWORD PTR [r14+0x20]
  40e574:	mov    eax,DWORD PTR [r14+0x2c]
  40e578:	add    QWORD PTR [r14+0x20],rax
  40e57c:	add    DWORD PTR [r14+0x28],0x1
  40e581:	jmp    40e585 <__swc_fn_3464c816_000050_ab8077df+0xa5>
  40e583:	xor    esi,esi
  40e585:	test   rsi,rsi
  40e588:	jne    40e5cd <__swc_fn_3464c816_000050_ab8077df+0xed>
  40e58a:	mov    rcx,r14
  40e58d:	call   407320 <__swc_fn_3464c816_000006_a23dca5f>
  40e592:	test   al,al
  40e594:	je     40e5cd <__swc_fn_3464c816_000050_ab8077df+0xed>
  40e596:	mov    rax,QWORD PTR [r14]
  40e599:	test   rax,rax
  40e59c:	je     40e5ab <__swc_fn_3464c816_000050_ab8077df+0xcb>
  40e59e:	mov    rcx,QWORD PTR [rax]
  40e5a1:	mov    QWORD PTR [r14],rcx
  40e5a4:	add    DWORD PTR [r14+0x28],0x1
  40e5a9:	jmp    40e5ca <__swc_fn_3464c816_000050_ab8077df+0xea>
  40e5ab:	mov    rax,QWORD PTR [r14+0x18]
  40e5af:	cmp    QWORD PTR [r14+0x20],rax
  40e5b3:	jae    40e5c8 <__swc_fn_3464c816_000050_ab8077df+0xe8>
  40e5b5:	mov    rax,QWORD PTR [r14+0x20]
  40e5b9:	mov    ecx,DWORD PTR [r14+0x2c]
  40e5bd:	add    QWORD PTR [r14+0x20],rcx
  40e5c1:	add    DWORD PTR [r14+0x28],0x1
  40e5c6:	jmp    40e5ca <__swc_fn_3464c816_000050_ab8077df+0xea>
  40e5c8:	xor    eax,eax
  40e5ca:	mov    rsi,rax
  40e5cd:	test   rsi,rsi
  40e5d0:	jne    40e623 <__swc_fn_3464c816_000050_ab8077df+0x143>
  40e5d2:	mov    rcx,rdi
  40e5d5:	mov    rdx,r12
  40e5d8:	mov    r8,r14
  40e5db:	call   40ac00 <__swc_fn_3464c816_000046_88f44774>
  40e5e0:	test   al,al
  40e5e2:	jne    40e623 <__swc_fn_3464c816_000050_ab8077df+0x143>
  40e5e4:	mov    rcx,r14
  40e5e7:	call   4073f0 <__swc_fn_3464c816_000009_d7e2bb25>
  40e5ec:	mov    rax,QWORD PTR [r14]
  40e5ef:	test   rax,rax
  40e5f2:	je     40e601 <__swc_fn_3464c816_000050_ab8077df+0x121>
  40e5f4:	mov    rcx,QWORD PTR [rax]
  40e5f7:	mov    QWORD PTR [r14],rcx
  40e5fa:	add    DWORD PTR [r14+0x28],0x1
  40e5ff:	jmp    40e620 <__swc_fn_3464c816_000050_ab8077df+0x140>
  40e601:	mov    rax,QWORD PTR [r14+0x18]
  40e605:	cmp    QWORD PTR [r14+0x20],rax
  40e609:	jae    40e61e <__swc_fn_3464c816_000050_ab8077df+0x13e>
  40e60b:	mov    rax,QWORD PTR [r14+0x20]
  40e60f:	mov    ecx,DWORD PTR [r14+0x2c]
  40e613:	add    QWORD PTR [r14+0x20],rcx
  40e617:	add    DWORD PTR [r14+0x28],0x1
  40e61c:	jmp    40e620 <__swc_fn_3464c816_000050_ab8077df+0x140>
  40e61e:	xor    eax,eax
  40e620:	mov    rsi,rax
  40e623:	test   rsi,rsi
  40e626:	je     40e641 <__swc_fn_3464c816_000050_ab8077df+0x161>
  40e628:	mov    QWORD PTR [r13+0x0],r14
  40e62c:	mov    rax,rsi
  40e62f:	add    rsp,0x1f8
  40e636:	pop    r15
  40e638:	pop    r14
  40e63a:	pop    r13
  40e63c:	pop    r12
  40e63e:	pop    rdi
  40e63f:	pop    rsi
  40e640:	ret
  40e641:	mov    r14,r15
  40e644:	jmp    40e530 <__swc_fn_3464c816_000050_ab8077df+0x50>
  40e649:	cs nop WORD PTR [rax+rax*1+0x0]
  40e653:	cs nop WORD PTR [rax+rax*1+0x0]
  40e65d:	nop    DWORD PTR [rax]
  40e660:	mov    rcx,rdi
  40e663:	mov    rdx,r12
  40e666:	mov    r8d,esi
  40e669:	call   4079e0 <__swc_fn_3464c816_000045_1fe0f4e2>
  40e66e:	mov    r14,rax
  40e671:	test   rax,rax
  40e674:	jne    40e68a <__swc_fn_3464c816_000050_ab8077df+0x1aa>
  40e676:	xor    eax,eax
  40e678:	add    rsp,0x1f8
  40e67f:	pop    r15
  40e681:	pop    r14
  40e683:	pop    r13
  40e685:	pop    r12
  40e687:	pop    rdi
  40e688:	pop    rsi
  40e689:	ret
  40e68a:	mov    QWORD PTR [r13+0x0],r14
  40e68e:	mov    rax,QWORD PTR [r14]
  40e691:	test   rax,rax
  40e694:	je     40e6a6 <__swc_fn_3464c816_000050_ab8077df+0x1c6>
  40e696:	mov    rcx,QWORD PTR [rax]
  40e699:	mov    QWORD PTR [r14],rcx
  40e69c:	add    DWORD PTR [r14+0x28],0x1
  40e6a1:	mov    r15,rax
  40e6a4:	jmp    40e6c6 <__swc_fn_3464c816_000050_ab8077df+0x1e6>
  40e6a6:	mov    rax,QWORD PTR [r14+0x18]
  40e6aa:	cmp    QWORD PTR [r14+0x20],rax
  40e6ae:	jae    40e6c3 <__swc_fn_3464c816_000050_ab8077df+0x1e3>
  40e6b0:	mov    r15,QWORD PTR [r14+0x20]
  40e6b4:	mov    eax,DWORD PTR [r14+0x2c]
  40e6b8:	add    QWORD PTR [r14+0x20],rax
  40e6bc:	add    DWORD PTR [r14+0x28],0x1
  40e6c1:	jmp    40e6c6 <__swc_fn_3464c816_000050_ab8077df+0x1e6>
  40e6c3:	xor    r15d,r15d
  40e6c6:	test   r15,r15
  40e6c9:	jne    40e70e <__swc_fn_3464c816_000050_ab8077df+0x22e>
  40e6cb:	mov    rcx,r14
  40e6ce:	call   407320 <__swc_fn_3464c816_000006_a23dca5f>
  40e6d3:	test   al,al
  40e6d5:	je     40e70e <__swc_fn_3464c816_000050_ab8077df+0x22e>
  40e6d7:	mov    rax,QWORD PTR [r14]
  40e6da:	test   rax,rax
  40e6dd:	je     40e6ec <__swc_fn_3464c816_000050_ab8077df+0x20c>
  40e6df:	mov    rcx,QWORD PTR [rax]
  40e6e2:	mov    QWORD PTR [r14],rcx
  40e6e5:	add    DWORD PTR [r14+0x28],0x1
  40e6ea:	jmp    40e70b <__swc_fn_3464c816_000050_ab8077df+0x22b>
  40e6ec:	mov    rax,QWORD PTR [r14+0x18]
  40e6f0:	cmp    QWORD PTR [r14+0x20],rax
  40e6f4:	jae    40e709 <__swc_fn_3464c816_000050_ab8077df+0x229>
  40e6f6:	mov    rax,QWORD PTR [r14+0x20]
  40e6fa:	mov    ecx,DWORD PTR [r14+0x2c]
  40e6fe:	add    QWORD PTR [r14+0x20],rcx
  40e702:	add    DWORD PTR [r14+0x28],0x1
  40e707:	jmp    40e70b <__swc_fn_3464c816_000050_ab8077df+0x22b>
  40e709:	xor    eax,eax
  40e70b:	mov    r15,rax
  40e70e:	test   r15,r15
  40e711:	je     40e660 <__swc_fn_3464c816_000050_ab8077df+0x180>
  40e717:	mov    rax,r15
  40e71a:	add    rsp,0x1f8
  40e721:	pop    r15
  40e723:	pop    r14
  40e725:	pop    r13
  40e727:	pop    r12
  40e729:	pop    rdi
  40e72a:	pop    rsi
  40e72b:	ret
  40e72c:	add    BYTE PTR [rax],al
	...

000000000040e730 <__swc_fn_3464c816_000053_82546d94>:
  40e730:	push   rsi
  40e731:	push   rdi
  40e732:	push   r12
  40e734:	mov    rsi,rdx
  40e737:	mov    rax,rdx
  40e73a:	shr    rax,0xc
  40e73e:	movabs rdx,0x9e3779b97f4a7c15
  40e748:	imul   rax,rdx
  40e74c:	shr    rax,0x20
  40e750:	lea    rax,[rax*8+0x0]
  40e758:	shr    rax,0x20
  40e75c:	lea    rax,[rax*8+0x0]
  40e764:	lea    rax,[rcx+rax*8+0x40]
  40e769:	xor    edx,edx
  40e76b:	test   dl,dl
  40e76d:	lea    rdi,[rcx+0x8]
  40e771:	cmove  rdi,rax
  40e775:	xor    edx,edx
  40e777:	test   dl,dl
  40e779:	lea    r12,[rcx+0x30]
  40e77d:	lea    rax,[rax+0x8]
  40e781:	cmove  r12,rax
  40e785:	mov    rcx,rdi
  40e788:	call   4098c0 <__swc_fn_3464c816_000135_e3032dc2>
  40e78d:	mov    QWORD PTR [rsi+0x30],0x0
  40e795:	mov    rax,QWORD PTR [r12]
  40e799:	mov    QWORD PTR [rsi+0x38],rax
  40e79d:	test   rax,rax
  40e7a0:	je     40e7aa <__swc_fn_3464c816_000053_82546d94+0x7a>
  40e7a2:	mov    rax,QWORD PTR [rsi+0x38]
  40e7a6:	mov    QWORD PTR [rax+0x30],rsi
  40e7aa:	mov    QWORD PTR [r12],rsi
  40e7ae:	mov    rcx,rdi
  40e7b1:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  40e7b6:	pop    r12
  40e7b8:	pop    rdi
  40e7b9:	pop    rsi
  40e7ba:	ret
  40e7bb:	add    BYTE PTR [rax],al
  40e7bd:	add    BYTE PTR [rax],al
	...

000000000040e7c0 <__swc_fn_3464c816_000056_38b21f11>:
  40e7c0:	lea    rax,[rdx+rdx*4]
  40e7c4:	lea    rax,[rcx+rax*8+0x268]
  40e7cc:	mov    rdx,QWORD PTR [rax+0x10]
  40e7d0:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e7d7:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e7df:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e7e6:	lea    rdx,[rdx+rdx*4]
  40e7ea:	lea    rdx,[rcx+rdx*8+0x268]
  40e7f2:	vmovups xmm0,XMMWORD PTR [rdx]
  40e7f6:	vmovups XMMWORD PTR [rax],xmm0
  40e7fa:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e7ff:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e804:	mov    rcx,QWORD PTR [rdx+0x20]
  40e808:	mov    QWORD PTR [rax+0x20],rcx
  40e80c:	ret
  40e80d:	add    BYTE PTR [rax],al
	...

000000000040e810 <__swc_fn_3464c816_000059_3ca3ac64>:
  40e810:	push   rsi
  40e811:	push   rdi
  40e812:	push   r12
  40e814:	push   r13
  40e816:	sub    rsp,0x8
  40e81a:	mov    rsi,r8
  40e81d:	mov    rdi,rcx
  40e820:	mov    r12,rdx
  40e823:	xor    r13d,r13d
  40e826:	cs nop WORD PTR [rax+rax*1+0x0]
  40e830:	mov    eax,DWORD PTR [r12+0x730]
  40e838:	cmp    r13d,eax
  40e83b:	jae    40e8a1 <__swc_fn_3464c816_000059_3ca3ac64+0x91>
  40e83d:	lea    rax,[r13+r13*4+0x0]
  40e842:	lea    rax,[r12+rax*8+0x738]
  40e84a:	mov    rdx,QWORD PTR [rax]
  40e84d:	mov    r8,QWORD PTR [rax+0x8]
  40e851:	mov    r9,QWORD PTR [rax+0x10]
  40e855:	cmp    QWORD PTR [rax+0x20],rsi
  40e859:	jb     40e860 <__swc_fn_3464c816_000059_3ca3ac64+0x50>
  40e85b:	inc    r13d
  40e85e:	jmp    40e830 <__swc_fn_3464c816_000059_3ca3ac64+0x20>
  40e860:	sub    DWORD PTR [r12+0x730],0x1
  40e869:	mov    ecx,DWORD PTR [r12+0x730]
  40e871:	lea    rcx,[rcx+rcx*4]
  40e875:	lea    rcx,[r12+rcx*8+0x738]
  40e87d:	vmovups xmm0,XMMWORD PTR [rcx]
  40e881:	vmovups XMMWORD PTR [rax],xmm0
  40e885:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e88a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e88f:	mov    rcx,QWORD PTR [rcx+0x20]
  40e893:	mov    QWORD PTR [rax+0x20],rcx
  40e897:	mov    rcx,rdi
  40e89a:	call   407750 <__swc_fn_3464c816_000039_40d1e569>
  40e89f:	jmp    40e830 <__swc_fn_3464c816_000059_3ca3ac64+0x20>
  40e8a1:	add    rsp,0x8
  40e8a5:	pop    r13
  40e8a7:	pop    r12
  40e8a9:	pop    rdi
  40e8aa:	pop    rsi
  40e8ab:	ret
  40e8ac:	add    BYTE PTR [rax],al
	...

000000000040e8b0 <__swc_fn_3464c816_000062_7e482c5f>:
  40e8b0:	push   rsi
  40e8b1:	push   rdi
  40e8b2:	push   r12
  40e8b4:	push   r13
  40e8b6:	push   r14
  40e8b8:	mov    rsi,rcx
  40e8bb:	mov    rdi,rdx
  40e8be:	mov    r12,QWORD PTR [rdi]
  40e8c1:	mov    r13,QWORD PTR [rdi+0x18]
  40e8c5:	mov    rax,r12
  40e8c8:	add    rax,QWORD PTR [rdi+0x8]
  40e8cc:	sub    rax,r13
  40e8cf:	cmp    r8,rax
  40e8d2:	jbe    40e8dd <__swc_fn_3464c816_000062_7e482c5f+0x2d>
  40e8d4:	pop    r14
  40e8d6:	pop    r13
  40e8d8:	pop    r12
  40e8da:	pop    rdi
  40e8db:	pop    rsi
  40e8dc:	ret
  40e8dd:	lea    rax,[r13+r8*1+0x0]
  40e8e2:	sub    rax,r12
  40e8e5:	mov    ecx,0x1000
  40e8ea:	test   ecx,ecx
  40e8ec:	mov    edx,0x8
  40e8f1:	cmove  ecx,edx
  40e8f4:	dec    rcx
  40e8f7:	mov    rdx,0xffffffffffffffff
  40e8fe:	sub    rdx,rcx
  40e901:	cmp    rax,rdx
  40e904:	jbe    40e90b <__swc_fn_3464c816_000062_7e482c5f+0x5b>
  40e906:	xor    r14d,r14d
  40e909:	jmp    40e916 <__swc_fn_3464c816_000062_7e482c5f+0x66>
  40e90b:	add    rax,rcx
  40e90e:	andn   rax,rcx,rax
  40e913:	mov    r14,rax
  40e916:	mov    rax,QWORD PTR [rdi+0x10]
  40e91a:	cmp    r14,rax
  40e91d:	ja     40e928 <__swc_fn_3464c816_000062_7e482c5f+0x78>
  40e91f:	pop    r14
  40e921:	pop    r13
  40e923:	pop    r12
  40e925:	pop    rdi
  40e926:	pop    rsi
  40e927:	ret
  40e928:	mov    rax,r12
  40e92b:	add    rax,QWORD PTR [rdi+0x10]
  40e92f:	mov    rdx,r14
  40e932:	sub    rdx,QWORD PTR [rdi+0x10]
  40e936:	mov    rcx,rax
  40e939:	call   4072a0 <__swc_fn_3464c816_000003_7ab4792e>
  40e93e:	test   al,al
  40e940:	jne    40e94b <__swc_fn_3464c816_000062_7e482c5f+0x9b>
  40e942:	pop    r14
  40e944:	pop    r13
  40e946:	pop    r12
  40e948:	pop    rdi
  40e949:	pop    rsi
  40e94a:	ret
  40e94b:	add    r12,r14
  40e94e:	sub    r12,r13
  40e951:	mov    rcx,r12
  40e954:	sub    rcx,QWORD PTR [rdi+0x28]
  40e958:	mov    rdx,QWORD PTR [rsi+0x250]
  40e95f:	nop
  40e960:	lea    r8,[rdx+rcx*1]
  40e964:	mov    rax,rdx
  40e967:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40e970:	cmp    rax,rdx
  40e973:	je     40e97a <__swc_fn_3464c816_000062_7e482c5f+0xca>
  40e975:	mov    rdx,rax
  40e978:	jmp    40e960 <__swc_fn_3464c816_000062_7e482c5f+0xb0>
  40e97a:	mov    QWORD PTR [rdi+0x10],r14
  40e97e:	mov    QWORD PTR [rdi+0x28],r12
  40e982:	pop    r14
  40e984:	pop    r13
  40e986:	pop    r12
  40e988:	pop    rdi
  40e989:	pop    rsi
  40e98a:	ret
  40e98b:	add    BYTE PTR [rax],al
  40e98d:	add    BYTE PTR [rax],al
	...

000000000040e990 <__swc_fn_3464c816_000065_f9f4b610>:
  40e990:	push   rbx
  40e991:	push   rsi
  40e992:	push   rdi
  40e993:	push   r12
  40e995:	push   r13
  40e997:	sub    rsp,0xe0
  40e99e:	mov    rbx,rdx
  40e9a1:	mov    rsi,rcx
  40e9a4:	cmp    DWORD PTR [rbx+0x58],0x0
  40e9a8:	je     40e9cc <__swc_fn_3464c816_000065_f9f4b610+0x3c>
  40e9aa:	mov    eax,DWORD PTR [rbx+0x58]
  40e9ad:	sub    eax,0x1
  40e9b0:	test   DWORD PTR [rbx+0x58],eax
  40e9b3:	je     40e9cc <__swc_fn_3464c816_000065_f9f4b610+0x3c>
  40e9b5:	mov    QWORD PTR [rbx+0x40],0x0
  40e9bd:	add    rsp,0xe0
  40e9c4:	pop    r13
  40e9c6:	pop    r12
  40e9c8:	pop    rdi
  40e9c9:	pop    rsi
  40e9ca:	pop    rbx
  40e9cb:	ret
  40e9cc:	mov    rax,QWORD PTR [rbx+0x40]
  40e9d0:	test   rax,rax
  40e9d3:	jne    40e9ef <__swc_fn_3464c816_000065_f9f4b610+0x5f>
  40e9d5:	mov    rcx,rsi
  40e9d8:	mov    rdx,rbx
  40e9db:	call   40b8b0 <__swc_fn_3464c816_000064_b0d63361>
  40e9e0:	add    rsp,0xe0
  40e9e7:	pop    r13
  40e9e9:	pop    r12
  40e9eb:	pop    rdi
  40e9ec:	pop    rsi
  40e9ed:	pop    rbx
  40e9ee:	ret
  40e9ef:	cmp    QWORD PTR [rbx+0x48],0x0
  40e9f4:	jne    40ea10 <__swc_fn_3464c816_000065_f9f4b610+0x80>
  40e9f6:	mov    rcx,rsi
  40e9f9:	mov    rdx,rbx
  40e9fc:	call   407f90 <__swc_fn_3464c816_000066_254b71af>
  40ea01:	add    rsp,0xe0
  40ea08:	pop    r13
  40ea0a:	pop    r12
  40ea0c:	pop    rdi
  40ea0d:	pop    rsi
  40ea0e:	pop    rbx
  40ea0f:	ret
  40ea10:	mov    rdi,QWORD PTR [rbx+0x40]
  40ea14:	lea    rax,[rip+0x15655]        # 424070 <__swc_bss_base_3464c816+0x30>
  40ea1b:	mov    rcx,rdi
  40ea1e:	sub    rcx,QWORD PTR [rax+0x8]
  40ea22:	mov    rax,QWORD PTR [rip+0x15657]        # 424080 <__swc_bss_base_3464c816+0x40>
  40ea29:	cmp    rcx,rax
  40ea2c:	jae    40ea58 <__swc_fn_3464c816_000065_f9f4b610+0xc8>
  40ea2e:	mov    rax,rdi
  40ea31:	and    rax,0xffffffffffc00000
  40ea38:	mov    rcx,rdi
  40ea3b:	shr    rcx,0x10
  40ea3f:	and    ecx,0x3f
  40ea42:	mov    edx,DWORD PTR [rax+0x28]
  40ea45:	shrx   ecx,ecx,edx
  40ea4a:	shl    rcx,0x4
  40ea4e:	lea    r12,[rax+rcx*8+0x80]
  40ea56:	jmp    40ea63 <__swc_fn_3464c816_000065_f9f4b610+0xd3>
  40ea58:	mov    rcx,rdi
  40ea5b:	call   40a930 <__swc_fn_3464c816_000022_3a2e2048>
  40ea60:	mov    r12,rax
  40ea63:	test   r12,r12
  40ea66:	je     40ea75 <__swc_fn_3464c816_000065_f9f4b610+0xe5>
  40ea68:	mov    eax,DWORD PTR [r12+0x2c]
  40ea6d:	mov    r9d,eax
  40ea70:	mov    r13,rax
  40ea73:	jmp    40eaf4 <__swc_fn_3464c816_000065_f9f4b610+0x164>
  40ea75:	mov    rcx,rsi
  40ea78:	mov    rdx,rdi
  40ea7b:	call   40af40 <__swc_fn_3464c816_000052_c7484fb0>
  40ea80:	mov    rcx,QWORD PTR [rax+0x28]
  40ea84:	mov    r9,rcx
  40ea87:	mov    rdx,QWORD PTR [rax+0x20]
  40ea8b:	mov    r13,rdx
  40ea8e:	cmp    QWORD PTR [rbx+0x48],rcx
  40ea92:	jbe    40eacb <__swc_fn_3464c816_000065_f9f4b610+0x13b>
  40ea94:	mov    ecx,DWORD PTR [rax+0x48]
  40ea97:	cmp    DWORD PTR [rbx+0x58],ecx
  40ea9a:	ja     40eacb <__swc_fn_3464c816_000065_f9f4b610+0x13b>
  40ea9c:	mov    rcx,rsi
  40ea9f:	mov    rdx,rax
  40eaa2:	mov    r8,QWORD PTR [rbx+0x48]
  40eaa6:	mov    QWORD PTR [rsp+0xc8],r9
  40eaae:	mov    QWORD PTR [rsp+0xd0],rax
  40eab6:	call   40e8b0 <__swc_fn_3464c816_000062_7e482c5f>
  40eabb:	mov    r9,QWORD PTR [rsp+0xc8]
  40eac3:	mov    rax,QWORD PTR [rsp+0xd0]
  40eacb:	mov    rcx,QWORD PTR [rax+0x28]
  40eacf:	cmp    QWORD PTR [rbx+0x48],rcx
  40ead3:	ja     40eaf4 <__swc_fn_3464c816_000065_f9f4b610+0x164>
  40ead5:	mov    ecx,DWORD PTR [rax+0x48]
  40ead8:	cmp    DWORD PTR [rbx+0x58],ecx
  40eadb:	ja     40eaf4 <__swc_fn_3464c816_000065_f9f4b610+0x164>
  40eadd:	mov    rcx,QWORD PTR [rbx+0x48]
  40eae1:	mov    QWORD PTR [rax+0x20],rcx
  40eae5:	add    rsp,0xe0
  40eaec:	pop    r13
  40eaee:	pop    r12
  40eaf0:	pop    rdi
  40eaf1:	pop    rsi
  40eaf2:	pop    rbx
  40eaf3:	ret
  40eaf4:	test   r12,r12
  40eaf7:	je     40eb29 <__swc_fn_3464c816_000065_f9f4b610+0x199>
  40eaf9:	cmp    QWORD PTR [rbx+0x48],r9
  40eafd:	ja     40eb29 <__swc_fn_3464c816_000065_f9f4b610+0x199>
  40eaff:	cmp    DWORD PTR [rbx+0x58],0x40
  40eb03:	ja     40eb29 <__swc_fn_3464c816_000065_f9f4b610+0x199>
  40eb05:	cmp    DWORD PTR [rbx+0x58],0x0
  40eb09:	je     40eb16 <__swc_fn_3464c816_000065_f9f4b610+0x186>
  40eb0b:	mov    ecx,DWORD PTR [rbx+0x58]
  40eb0e:	dec    rcx
  40eb11:	test   rdi,rcx
  40eb14:	jne    40eb29 <__swc_fn_3464c816_000065_f9f4b610+0x199>
  40eb16:	mov    QWORD PTR [rbx+0x40],rdi
  40eb1a:	add    rsp,0xe0
  40eb21:	pop    r13
  40eb23:	pop    r12
  40eb25:	pop    rdi
  40eb26:	pop    rsi
  40eb27:	pop    rbx
  40eb28:	ret
  40eb29:	vmovups xmm0,XMMWORD PTR [rbx]
  40eb2d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40eb33:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40eb38:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40eb3e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40eb43:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40eb49:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40eb4e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40eb54:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40eb59:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40eb5f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40eb64:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40eb6a:	mov    QWORD PTR [rsp+0x48],0x0
  40eb73:	mov    rcx,rsi
  40eb76:	lea    rdx,[rsp+0x8]
  40eb7b:	call   40b8b0 <__swc_fn_3464c816_000064_b0d63361>
  40eb80:	mov    rax,QWORD PTR [rsp+0x48]
  40eb85:	test   rax,rax
  40eb88:	jne    40eba1 <__swc_fn_3464c816_000065_f9f4b610+0x211>
  40eb8a:	mov    QWORD PTR [rbx+0x40],0x0
  40eb92:	add    rsp,0xe0
  40eb99:	pop    r13
  40eb9b:	pop    r12
  40eb9d:	pop    rdi
  40eb9e:	pop    rsi
  40eb9f:	pop    rbx
  40eba0:	ret
  40eba1:	mov    rax,QWORD PTR [rbx+0x48]
  40eba5:	cmp    r13,rax
  40eba8:	cmovbe rax,r13
  40ebac:	mov    rcx,QWORD PTR [rsp+0x48]
  40ebb1:	mov    rdx,rdi
  40ebb4:	mov    r8,rax
  40ebb7:	call   409100 <__swc_fn_3464c816_000105_6fd80914>
  40ebbc:	vmovups xmm0,XMMWORD PTR [rbx]
  40ebc0:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40ebc6:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40ebcb:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40ebd1:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40ebd6:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40ebdf:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40ebe4:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40ebed:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40ebf2:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40ebfb:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40ec00:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40ec09:	mov    QWORD PTR [rsp+0xa8],rdi
  40ec11:	mov    rcx,rsi
  40ec14:	lea    rdx,[rsp+0x68]
  40ec19:	call   407f90 <__swc_fn_3464c816_000066_254b71af>
  40ec1e:	mov    rax,QWORD PTR [rsp+0x48]
  40ec23:	mov    QWORD PTR [rbx+0x40],rax
  40ec27:	add    rsp,0xe0
  40ec2e:	pop    r13
  40ec30:	pop    r12
  40ec32:	pop    rdi
  40ec33:	pop    rsi
  40ec34:	pop    rbx
  40ec35:	ret
	...

000000000040ec40 <__swc_fn_3464c816_000068_7d4c42bf>:
  40ec40:	push   r12
  40ec42:	push   rdi
  40ec43:	push   rsi
  40ec44:	push   r13
  40ec46:	push   r14
  40ec48:	sub    rsp,0x190
  40ec4f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40ec58:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40ec61:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40ec6a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40ec73:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40ec7c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40ec85:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40ec8e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40ec97:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40eca0:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40eca9:	mov    r12,rcx
  40ecac:	lea    rax,[rip+0x1334d]        # 422000 <__swc_data_base_3464c816>
  40ecb3:	mov    rax,QWORD PTR [rax]
  40ecb6:	cmp    rax,0xffffffffffffffff
  40ecba:	je     40ecc9 <__swc_fn_3464c816_000068_7d4c42bf+0x89>
  40ecbc:	mov    eax,eax
  40ecbe:	mov    edi,eax
  40ecc0:	xor    eax,eax
  40ecc2:	call   407000 <pthread_getspecific@plt>
  40ecc7:	jmp    40eccb <__swc_fn_3464c816_000068_7d4c42bf+0x8b>
  40ecc9:	xor    eax,eax
  40eccb:	test   rax,rax
  40ecce:	jne    40ecdd <__swc_fn_3464c816_000068_7d4c42bf+0x9d>
  40ecd0:	call   40aa00 <__swc_fn_3464c816_000031_90860ff2>
  40ecd5:	mov    rcx,rax
  40ecd8:	call   410440 <__swc_fn_3464c816_000128_41c3251c>
  40ecdd:	test   rax,rax
  40ece0:	je     40ed06 <__swc_fn_3464c816_000068_7d4c42bf+0xc6>
  40ece2:	cmp    QWORD PTR [rax],r12
  40ece5:	jne    40ed06 <__swc_fn_3464c816_000068_7d4c42bf+0xc6>
  40ece7:	xor    ecx,ecx
  40ece9:	mov    QWORD PTR [rsp+0xc8],rax
  40ecf1:	call   407720 <__swc_fn_3464c816_000033_7ca1566d>
  40ecf6:	mov    rdx,QWORD PTR [rsp+0xc8]
  40ecfe:	mov    rcx,r12
  40ed01:	call   407840 <__swc_fn_3464c816_000042_bab03645>
  40ed06:	lea    rsi,[r12+0x10]
  40ed0b:	mov    rcx,rsi
  40ed0e:	call   4098c0 <__swc_fn_3464c816_000135_e3032dc2>
  40ed13:	mov    rdi,QWORD PTR [r12+0x20]
  40ed18:	test   rdi,rdi
  40ed1b:	je     40ed5e <__swc_fn_3464c816_000068_7d4c42bf+0x11e>
  40ed1d:	nop    DWORD PTR [rax]
  40ed20:	mov    rcx,r12
  40ed23:	mov    rdx,rdi
  40ed26:	call   40abc0 <__swc_fn_3464c816_000043_957e4917>
  40ed2b:	mov    rcx,r12
  40ed2e:	mov    rdx,rdi
  40ed31:	mov    r8,0xffffffffffffffff
  40ed38:	call   40e810 <__swc_fn_3464c816_000059_3ca3ac64>
  40ed3d:	mov    rcx,r12
  40ed40:	mov    rdx,rdi
  40ed43:	mov    r8d,0x9b8
  40ed49:	mov    r9d,0x9b8
  40ed4f:	call   407750 <__swc_fn_3464c816_000039_40d1e569>
  40ed54:	mov    rdi,QWORD PTR [r12+0x20]
  40ed59:	test   rdi,rdi
  40ed5c:	jne    40ed20 <__swc_fn_3464c816_000068_7d4c42bf+0xe0>
  40ed5e:	xor    eax,eax
  40ed60:	xchg   QWORD PTR [r12+0x2a80],rax
  40ed68:	test   rax,rax
  40ed6b:	je     40ed91 <__swc_fn_3464c816_000068_7d4c42bf+0x151>
  40ed6d:	cs nop WORD PTR [rax+rax*1+0x0]
  40ed77:	nop    WORD PTR [rax+rax*1+0x0]
  40ed80:	mov    rcx,rax
  40ed83:	mov    rax,QWORD PTR [rax+0x78]
  40ed87:	xor    edx,edx
  40ed89:	xchg   DWORD PTR [rcx+0x70],edx
  40ed8c:	test   rax,rax
  40ed8f:	jne    40ed80 <__swc_fn_3464c816_000068_7d4c42bf+0x140>
  40ed91:	mov    rax,QWORD PTR [r12+0x18]
  40ed96:	mov    rdi,rax
  40ed99:	test   rdi,rdi
  40ed9c:	je     40ee31 <__swc_fn_3464c816_000068_7d4c42bf+0x1f1>
  40eda2:	cs nop WORD PTR [rax+rax*1+0x0]
  40edac:	nop    DWORD PTR [rax+0x0]
  40edb0:	mov    rax,QWORD PTR [rdi+0x10]
  40edb4:	mov    r8d,DWORD PTR [rdi+0x2c]
  40edb8:	xor    r9d,r9d
  40edbb:	test   r8,r8
  40edbe:	jbe    40ee1d <__swc_fn_3464c816_000068_7d4c42bf+0x1dd>
  40edc0:	mov    ecx,r9d
  40edc3:	shl    rcx,0x4
  40edc7:	lea    rdx,[rdi+rcx*8+0x80]
  40edcf:	cmp    BYTE PTR [rdx+0x3b],0x0
  40edd3:	je     40ee14 <__swc_fn_3464c816_000068_7d4c42bf+0x1d4>
  40edd5:	mov    DWORD PTR [rdx+0x28],0x0
  40eddc:	mov    rcx,rdi
  40eddf:	mov    QWORD PTR [rsp+0xd0],rax
  40ede7:	mov    QWORD PTR [rsp+0xd8],r8
  40edef:	mov    QWORD PTR [rsp+0xe0],r9
  40edf7:	call   40df40 <__swc_fn_3464c816_000014_afb279e2>
  40edfc:	mov    rax,QWORD PTR [rsp+0xd0]
  40ee04:	mov    r8,QWORD PTR [rsp+0xd8]
  40ee0c:	mov    r9,QWORD PTR [rsp+0xe0]
  40ee14:	add    r9,0x1
  40ee18:	cmp    r9,r8
  40ee1b:	jb     40edc0 <__swc_fn_3464c816_000068_7d4c42bf+0x180>
  40ee1d:	mov    rcx,rdi
  40ee20:	mov    rdi,rax
  40ee23:	call   407630 <__swc_fn_3464c816_000021_491ac000>
  40ee28:	test   rdi,rdi
  40ee2b:	jne    40edb0 <__swc_fn_3464c816_000068_7d4c42bf+0x170>
  40ee31:	mov    QWORD PTR [r12+0x18],0x0
  40ee3a:	mov    QWORD PTR [r12+0x28],0x0
  40ee43:	mov    rcx,rsi
  40ee46:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  40ee4b:	mov    esi,0x8
  40ee50:	xor    edi,edi
  40ee52:	test   rsi,rsi
  40ee55:	je     40eeb2 <__swc_fn_3464c816_000068_7d4c42bf+0x272>
  40ee5b:	nop    DWORD PTR [rax+rax*1+0x0]
  40ee60:	lea    r13,[rdi*8+0x0]
  40ee68:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ee6d:	test   r14,r14
  40ee70:	je     40eea8 <__swc_fn_3464c816_000068_7d4c42bf+0x268>
  40ee72:	cs nop WORD PTR [rax+rax*1+0x0]
  40ee7c:	nop    DWORD PTR [rax+0x0]
  40ee80:	mov    rcx,r12
  40ee83:	mov    rdx,r14
  40ee86:	call   407df0 <__swc_fn_3464c816_000054_ae20ea33>
  40ee8b:	mov    rcx,r12
  40ee8e:	mov    rdx,QWORD PTR [r14]
  40ee91:	mov    r8,QWORD PTR [r14+0x8]
  40ee95:	mov    r9,QWORD PTR [r14+0x10]
  40ee99:	call   407750 <__swc_fn_3464c816_000039_40d1e569>
  40ee9e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40eea3:	test   r14,r14
  40eea6:	jne    40ee80 <__swc_fn_3464c816_000068_7d4c42bf+0x240>
  40eea8:	add    rdi,0x1
  40eeac:	sub    rsi,0x1
  40eeb0:	jne    40ee60 <__swc_fn_3464c816_000068_7d4c42bf+0x220>
  40eeb2:	mov    rcx,r12
  40eeb5:	call   407ec0 <__swc_fn_3464c816_000060_e6407a0a>
  40eeba:	lea    rcx,[r12+0x250]
  40eec2:	mov    rdx,QWORD PTR [rcx]
  40eec5:	mov    r8,QWORD PTR [r12+0x250]
  40eecd:	nop    DWORD PTR [rax]
  40eed0:	mov    r9,r8
  40eed3:	sub    r9,rdx
  40eed6:	mov    rax,r8
  40eed9:	lock cmpxchg QWORD PTR [rcx],r9
  40eede:	cmp    rax,r8
  40eee1:	je     40eee8 <__swc_fn_3464c816_000068_7d4c42bf+0x2a8>
  40eee3:	mov    r8,rax
  40eee6:	jmp    40eed0 <__swc_fn_3464c816_000068_7d4c42bf+0x290>
  40eee8:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40eef1:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40eefa:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40ef03:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40ef0c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40ef15:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40ef1e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40ef27:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40ef30:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40ef39:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40ef42:	add    rsp,0x190
  40ef49:	pop    r14
  40ef4b:	pop    r13
  40ef4d:	pop    rsi
  40ef4e:	pop    rdi
  40ef4f:	pop    r12
  40ef51:	ret
	...

000000000040ef60 <__swc_fn_3464c816_000071_0d1ef36f>:
  40ef60:	sub    rsp,0x8
  40ef64:	mov    QWORD PTR [rdx+0x40],0x0
  40ef6c:	call   40b8b0 <__swc_fn_3464c816_000064_b0d63361>
  40ef71:	add    rsp,0x8
  40ef75:	ret
	...

000000000040ef80 <__swc_fn_3464c816_000074_518516c2>:
  40ef80:	sub    rsp,0x8
  40ef84:	call   407f90 <__swc_fn_3464c816_000066_254b71af>
  40ef89:	add    rsp,0x8
  40ef8d:	ret
	...

000000000040ef90 <__swc_fn_3464c816_000077_8b8614a7>:
  40ef90:	push   rbx
  40ef91:	push   rsi
  40ef92:	push   rdi
  40ef93:	push   r12
  40ef95:	push   r13
  40ef97:	push   r14
  40ef99:	push   r15
  40ef9b:	sub    rsp,0x20
  40ef9f:	mov    rbx,r11
  40efa2:	mov    rsi,rcx
  40efa5:	mov    rdi,rdx
  40efa8:	mov    r12,r8
  40efab:	mov    r13,r9
  40efae:	mov    r14,r10
  40efb1:	mov    rcx,QWORD PTR [rip+0x17d88]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40efb8:	test   rcx,rcx
  40efbb:	jne    40efcd <__swc_fn_3464c816_000077_8b8614a7+0x3d>
  40efbd:	call   40a1d0 <__swc_fn_3464c816_000165_cf398896>
  40efc2:	lea    rcx,[rax+0x1]
  40efc6:	mov    QWORD PTR [rip+0x17d73],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40efcd:	dec    rcx
  40efd0:	call   411f00 <__swc_fn_3464c816_000167_fce60b2b>
  40efd5:	mov    r15,rax
  40efd8:	lea    r11,[rip+0x15261]        # 424240 <__swc_bss_base_3464c816+0x200>
  40efdf:	mov    rcx,r11
  40efe2:	call   407740 <__swc_fn_3464c816_000036_8d895ba1>
  40efe7:	test   al,al
  40efe9:	jne    40effa <__swc_fn_3464c816_000077_8b8614a7+0x6a>
  40efeb:	mov    rcx,r11
  40efee:	call   40aa60 <__swc_fn_3464c816_000034_25f19556>
  40eff3:	lea    r11,[rip+0x15246]        # 424240 <__swc_bss_base_3464c816+0x200>
  40effa:	mov    rcx,r11
  40effd:	mov    rdx,rsi
  40f000:	mov    r8,rdi
  40f003:	mov    r9,r12
  40f006:	mov    r10,r13
  40f009:	mov    rsi,r11
  40f00c:	mov    r11,r14
  40f00f:	call   40e2b0 <__swc_fn_3464c816_000035_95622a2b>
  40f014:	test   bl,bl
  40f016:	je     40f03d <__swc_fn_3464c816_000077_8b8614a7+0xad>
  40f018:	mov    QWORD PTR [rsp+0x8],rsi
  40f01d:	lea    rax,[rip+0x412c]        # 413150 <__swc_rdata_base_3464c816+0x40>
  40f024:	mov    QWORD PTR [rsp+0x10],rax
  40f029:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f02f:	vmovups XMMWORD PTR [r15],xmm0
  40f034:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40f03d:	mov    rax,rsi
  40f040:	add    rsp,0x20
  40f044:	pop    r15
  40f046:	pop    r14
  40f048:	pop    r13
  40f04a:	pop    r12
  40f04c:	pop    rdi
  40f04d:	pop    rsi
  40f04e:	pop    rbx
  40f04f:	ret

000000000040f050 <__swc_fn_3464c816_000080_c1514492>:
  40f050:	sub    rsp,0x8
  40f054:	mov    rax,rcx
  40f057:	test   rcx,rcx
  40f05a:	jne    40f061 <__swc_fn_3464c816_000080_c1514492+0x11>
  40f05c:	add    rsp,0x8
  40f060:	ret
  40f061:	lea    rcx,[rax-0x10]
  40f065:	mov    rax,QWORD PTR [rax-0x10]
  40f069:	mov    rdx,rax
  40f06c:	call   4100e0 <__swc_fn_3464c816_000113_49b378a9>
  40f071:	add    rsp,0x8
  40f075:	ret
	...

000000000040f080 <__swc_fn_3464c816_000083_31b501f2>:
  40f080:	sub    rsp,0x8
  40f084:	xor    r11d,r11d
  40f087:	call   408250 <__swc_fn_3464c816_000084_ddf2b8a1>
  40f08c:	add    rsp,0x8
  40f090:	ret
	...

000000000040f0a0 <__swc_fn_3464c816_000086_c45095aa>:
  40f0a0:	push   rsi
  40f0a1:	push   rdi
  40f0a2:	push   r12
  40f0a4:	push   r13
  40f0a6:	push   r14
  40f0a8:	push   r15
  40f0aa:	sub    rsp,0x68
  40f0ae:	mov    rsi,r9
  40f0b1:	mov    rdi,rcx
  40f0b4:	mov    r12,rdx
  40f0b7:	mov    r13,r8
  40f0ba:	cmp    r8,r9
  40f0bd:	jne    40f0e5 <__swc_fn_3464c816_000086_c45095aa+0x45>
  40f0bf:	mov    rcx,rdi
  40f0c2:	mov    rdx,r12
  40f0c5:	xor    r8d,r8d
  40f0c8:	call   4085a0 <__swc_fn_3464c816_000090_a2d50c23>
  40f0cd:	test   al,al
  40f0cf:	je     40f0e5 <__swc_fn_3464c816_000086_c45095aa+0x45>
  40f0d1:	mov    eax,0x1
  40f0d6:	add    rsp,0x68
  40f0da:	pop    r15
  40f0dc:	pop    r14
  40f0de:	pop    r13
  40f0e0:	pop    r12
  40f0e2:	pop    rdi
  40f0e3:	pop    rsi
  40f0e4:	ret
  40f0e5:	cmp    BYTE PTR [r12+0x2c],0xe
  40f0eb:	je     40f0fe <__swc_fn_3464c816_000086_c45095aa+0x5e>
  40f0ed:	xor    eax,eax
  40f0ef:	add    rsp,0x68
  40f0f3:	pop    r15
  40f0f5:	pop    r14
  40f0f7:	pop    r13
  40f0f9:	pop    r12
  40f0fb:	pop    rdi
  40f0fc:	pop    rsi
  40f0fd:	ret
  40f0fe:	mov    r14,QWORD PTR [r12+0x98]
  40f106:	mov    rax,QWORD PTR [r12+0xa0]
  40f10e:	mov    r12,rax
  40f111:	xor    r15d,r15d
  40f114:	test   r12,r12
  40f117:	je     40f17f <__swc_fn_3464c816_000086_c45095aa+0xdf>
  40f119:	nop    DWORD PTR [rax+0x0]
  40f120:	mov    QWORD PTR [rsp+0x58],r12
  40f125:	lea    r12,[r15*8+0x0]
  40f12d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40f132:	mov    rcx,rax
  40f135:	call   40c040 <__swc_fn_3464c816_000082_754dcd57>
  40f13a:	cmp    BYTE PTR [rax+0x2c],0xe
  40f13e:	jne    40f170 <__swc_fn_3464c816_000086_c45095aa+0xd0>
  40f140:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40f145:	lea    r8,[r13+rcx*1+0x0]
  40f14a:	mov    rcx,rdi
  40f14d:	mov    rdx,rax
  40f150:	mov    r9,rsi
  40f153:	call   40f0a0 <__swc_fn_3464c816_000086_c45095aa>
  40f158:	test   al,al
  40f15a:	je     40f170 <__swc_fn_3464c816_000086_c45095aa+0xd0>
  40f15c:	mov    eax,0x1
  40f161:	add    rsp,0x68
  40f165:	pop    r15
  40f167:	pop    r14
  40f169:	pop    r13
  40f16b:	pop    r12
  40f16d:	pop    rdi
  40f16e:	pop    rsi
  40f16f:	ret
  40f170:	add    r15,0x1
  40f174:	mov    r12,QWORD PTR [rsp+0x58]
  40f179:	sub    r12,0x1
  40f17d:	jne    40f120 <__swc_fn_3464c816_000086_c45095aa+0x80>
  40f17f:	xor    eax,eax
  40f181:	add    rsp,0x68
  40f185:	pop    r15
  40f187:	pop    r14
  40f189:	pop    r13
  40f18b:	pop    r12
  40f18d:	pop    rdi
  40f18e:	pop    rsi
  40f18f:	ret

000000000040f190 <__swc_fn_3464c816_000089_386582f3>:
  40f190:	push   rbp
  40f191:	push   rbx
  40f192:	push   rsi
  40f193:	push   rdi
  40f194:	push   r12
  40f196:	push   r13
  40f198:	push   r14
  40f19a:	push   r15
  40f19c:	sub    rsp,0x38
  40f1a0:	mov    rbp,rsp
  40f1a3:	mov    rbx,r11
  40f1a6:	mov    rsi,rdx
  40f1a9:	mov    rdi,r8
  40f1ac:	mov    r12,r9
  40f1af:	mov    QWORD PTR [rsp+0x18],r9
  40f1b4:	mov    r13,r10
  40f1b7:	movzx  r14d,BYTE PTR [rbp+0x80]
  40f1bf:	movzx  r15d,BYTE PTR [rbp+0x88]
  40f1c7:	test   r11,r11
  40f1ca:	je     40f1d0 <__swc_fn_3464c816_000089_386582f3+0x40>
  40f1cc:	xor    eax,eax
  40f1ce:	mov    BYTE PTR [rbx],al
  40f1d0:	test   r12,r12
  40f1d3:	je     40f1de <__swc_fn_3464c816_000089_386582f3+0x4e>
  40f1d5:	mov    QWORD PTR [r12+0x8],0x0
  40f1de:	test   rcx,rcx
  40f1e1:	je     40f1e8 <__swc_fn_3464c816_000089_386582f3+0x58>
  40f1e3:	test   rsi,rsi
  40f1e6:	jne    40f1fb <__swc_fn_3464c816_000089_386582f3+0x6b>
  40f1e8:	xor    eax,eax
  40f1ea:	add    rsp,0x38
  40f1ee:	pop    r15
  40f1f0:	pop    r14
  40f1f2:	pop    r13
  40f1f4:	pop    r12
  40f1f6:	pop    rdi
  40f1f7:	pop    rsi
  40f1f8:	pop    rbx
  40f1f9:	pop    rbp
  40f1fa:	ret
  40f1fb:	call   40c040 <__swc_fn_3464c816_000082_754dcd57>
  40f200:	mov    r12,rax
  40f203:	mov    al,r15b
  40f206:	test   r15b,r15b
  40f209:	jne    40f219 <__swc_fn_3464c816_000089_386582f3+0x89>
  40f20b:	mov    eax,DWORD PTR [r12+0x28]
  40f210:	and    eax,0x10000
  40f216:	setne  al
  40f219:	lea    r15,[rsp+0x8]
  40f21e:	mov    QWORD PTR [rsp+0x20],r15
  40f223:	rex mov BYTE PTR [rsp+0x8],al
  40f228:	test   DWORD PTR [rsi+0x28],0x400000
  40f22f:	je     40f267 <__swc_fn_3464c816_000089_386582f3+0xd7>
  40f231:	test   rsi,rsi
  40f234:	je     40f254 <__swc_fn_3464c816_000089_386582f3+0xc4>
  40f236:	mov    rax,QWORD PTR [rsi+0x38]
  40f23a:	cmp    QWORD PTR [rax+0x10],rsi
  40f23e:	jne    40f254 <__swc_fn_3464c816_000089_386582f3+0xc4>
  40f240:	rex mov al,BYTE PTR [rsp+0x8]
  40f245:	test   al,al
  40f247:	sete   al
  40f24a:	test   r14b,r14b
  40f24d:	sete   cl
  40f250:	test   al,cl
  40f252:	je     40f267 <__swc_fn_3464c816_000089_386582f3+0xd7>
  40f254:	xor    eax,eax
  40f256:	add    rsp,0x38
  40f25a:	pop    r15
  40f25c:	pop    r14
  40f25e:	pop    r13
  40f260:	pop    r12
  40f262:	pop    rdi
  40f263:	pop    rsi
  40f264:	pop    rbx
  40f265:	pop    rbp
  40f266:	ret
  40f267:	mov    r15,r12
  40f26a:	test   r14b,r14b
  40f26d:	jne    40f284 <__swc_fn_3464c816_000089_386582f3+0xf4>
  40f26f:	cmp    BYTE PTR [r12+0x2c],0x6
  40f275:	jne    40f284 <__swc_fn_3464c816_000089_386582f3+0xf4>
  40f277:	mov    rcx,QWORD PTR [r12+0x40]
  40f27c:	call   40c040 <__swc_fn_3464c816_000082_754dcd57>
  40f281:	mov    r15,rax
  40f284:	test   r14b,r14b
  40f287:	je     40f28d <__swc_fn_3464c816_000089_386582f3+0xfd>
  40f289:	mov    r15,QWORD PTR [r15+0x30]
  40f28d:	mov    rcx,rsi
  40f290:	call   40c040 <__swc_fn_3464c816_000082_754dcd57>
  40f295:	mov    rsi,rax
  40f298:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f29d:	je     40f2d4 <__swc_fn_3464c816_000089_386582f3+0x144>
  40f29f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f2a4:	je     40f2d4 <__swc_fn_3464c816_000089_386582f3+0x144>
  40f2a6:	mov    eax,DWORD PTR [rsi+0x28]
  40f2a9:	and    eax,0x10000
  40f2af:	je     40f2d4 <__swc_fn_3464c816_000089_386582f3+0x144>
  40f2b1:	rex mov al,BYTE PTR [rsp+0x8]
  40f2b6:	test   al,al
  40f2b8:	jne    40f2cd <__swc_fn_3464c816_000089_386582f3+0x13d>
  40f2ba:	xor    eax,eax
  40f2bc:	add    rsp,0x38
  40f2c0:	pop    r15
  40f2c2:	pop    r14
  40f2c4:	pop    r13
  40f2c6:	pop    r12
  40f2c8:	pop    rdi
  40f2c9:	pop    rsi
  40f2ca:	pop    rbx
  40f2cb:	pop    rbp
  40f2cc:	ret
  40f2cd:	mov    rax,QWORD PTR [rsi+0x30]
  40f2d1:	mov    rsi,rax
  40f2d4:	mov    r14b,r13b
  40f2d7:	test   rbx,rbx
  40f2da:	je     40f310 <__swc_fn_3464c816_000089_386582f3+0x180>
  40f2dc:	cmp    BYTE PTR [r12+0x2c],0x6
  40f2e2:	jne    40f310 <__swc_fn_3464c816_000089_386582f3+0x180>
  40f2e4:	lea    rdx,[rip+0x3e95]        # 413180 <__swc_rdata_base_3464c816+0x70>
  40f2eb:	mov    rcx,rsi
  40f2ee:	xor    r8d,r8d
  40f2f1:	call   4085a0 <__swc_fn_3464c816_000090_a2d50c23>
  40f2f6:	test   al,al
  40f2f8:	je     40f310 <__swc_fn_3464c816_000089_386582f3+0x180>
  40f2fa:	mov    BYTE PTR [rbx],0x1
  40f2fd:	xor    eax,eax
  40f2ff:	add    rsp,0x38
  40f303:	pop    r15
  40f305:	pop    r14
  40f307:	pop    r13
  40f309:	pop    r12
  40f30b:	pop    rdi
  40f30c:	pop    rsi
  40f30d:	pop    rbx
  40f30e:	pop    rbp
  40f30f:	ret
  40f310:	test   rdi,rdi
  40f313:	jne    40f32d <__swc_fn_3464c816_000089_386582f3+0x19d>
  40f315:	test   r13b,r13b
  40f318:	jne    40f32d <__swc_fn_3464c816_000089_386582f3+0x19d>
  40f31a:	xor    eax,eax
  40f31c:	add    rsp,0x38
  40f320:	pop    r15
  40f322:	pop    r14
  40f324:	pop    r13
  40f326:	pop    r12
  40f328:	pop    rdi
  40f329:	pop    rsi
  40f32a:	pop    rbx
  40f32b:	pop    rbp
  40f32c:	ret
  40f32d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f332:	jne    40f3e8 <__swc_fn_3464c816_000089_386582f3+0x258>
  40f338:	mov    rcx,r15
  40f33b:	mov    rdx,rsi
  40f33e:	xor    r8d,r8d
  40f341:	call   4085a0 <__swc_fn_3464c816_000090_a2d50c23>
  40f346:	test   al,al
  40f348:	jne    40f3e8 <__swc_fn_3464c816_000089_386582f3+0x258>
  40f34e:	test   DWORD PTR [rsi+0x28],0x10000
  40f355:	je     40f373 <__swc_fn_3464c816_000089_386582f3+0x1e3>
  40f357:	rex mov al,BYTE PTR [rsp+0x8]
  40f35c:	test   al,al
  40f35e:	jne    40f373 <__swc_fn_3464c816_000089_386582f3+0x1e3>
  40f360:	xor    eax,eax
  40f362:	add    rsp,0x38
  40f366:	pop    r15
  40f368:	pop    r14
  40f36a:	pop    r13
  40f36c:	pop    r12
  40f36e:	pop    rdi
  40f36f:	pop    rsi
  40f370:	pop    rbx
  40f371:	pop    rbp
  40f372:	ret
  40f373:	test   rdi,rdi
  40f376:	jne    40f38b <__swc_fn_3464c816_000089_386582f3+0x1fb>
  40f378:	xor    eax,eax
  40f37a:	add    rsp,0x38
  40f37e:	pop    r15
  40f380:	pop    r14
  40f382:	pop    r13
  40f384:	pop    r12
  40f386:	pop    rdi
  40f387:	pop    rsi
  40f388:	pop    rbx
  40f389:	pop    rbp
  40f38a:	ret
  40f38b:	mov    rcx,QWORD PTR [rsi+0x40]
  40f38f:	call   40c040 <__swc_fn_3464c816_000082_754dcd57>
  40f394:	mov    rsi,rax
  40f397:	mov    rax,QWORD PTR [rdi]
  40f39a:	mov    rdi,rax
  40f39d:	test   rax,rax
  40f3a0:	jne    40f3e3 <__swc_fn_3464c816_000089_386582f3+0x253>
  40f3a2:	test   rbx,rbx
  40f3a5:	je     40f3e3 <__swc_fn_3464c816_000089_386582f3+0x253>
  40f3a7:	mov    rcx,r15
  40f3aa:	mov    rdx,rsi
  40f3ad:	xor    r8d,r8d
  40f3b0:	call   4085a0 <__swc_fn_3464c816_000090_a2d50c23>
  40f3b5:	mov    rcx,rax
  40f3b8:	test   al,al
  40f3ba:	jne    40f3dc <__swc_fn_3464c816_000089_386582f3+0x24c>
  40f3bc:	mov    rcx,r15
  40f3bf:	mov    rdx,rsi
  40f3c2:	call   40c080 <__swc_fn_3464c816_000085_1edf7c76>
  40f3c7:	mov    rcx,rax
  40f3ca:	test   al,al
  40f3cc:	jne    40f3dc <__swc_fn_3464c816_000089_386582f3+0x24c>
  40f3ce:	mov    rcx,rsi
  40f3d1:	mov    rdx,r15
  40f3d4:	call   40c080 <__swc_fn_3464c816_000085_1edf7c76>
  40f3d9:	mov    rcx,rax
  40f3dc:	test   cl,cl
  40f3de:	setne  al
  40f3e1:	mov    BYTE PTR [rbx],al
  40f3e3:	xor    eax,eax
  40f3e5:	mov    r14b,al
  40f3e8:	test   rdi,rdi
  40f3eb:	jne    40f405 <__swc_fn_3464c816_000089_386582f3+0x275>
  40f3ed:	test   r14b,r14b
  40f3f0:	jne    40f405 <__swc_fn_3464c816_000089_386582f3+0x275>
  40f3f2:	xor    eax,eax
  40f3f4:	add    rsp,0x38
  40f3f8:	pop    r15
  40f3fa:	pop    r14
  40f3fc:	pop    r13
  40f3fe:	pop    r12
  40f400:	pop    rdi
  40f401:	pop    rsi
  40f402:	pop    rbx
  40f403:	pop    rbp
  40f404:	ret
  40f405:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f40a:	je     40f416 <__swc_fn_3464c816_000089_386582f3+0x286>
  40f40c:	mov    r12,QWORD PTR [rsp+0x18]
  40f411:	jmp    40f49e <__swc_fn_3464c816_000089_386582f3+0x30e>
  40f416:	mov    r12,QWORD PTR [rsp+0x18]
  40f41b:	test   r12,r12
  40f41e:	jne    40f432 <__swc_fn_3464c816_000089_386582f3+0x2a2>
  40f420:	mov    rcx,r15
  40f423:	mov    rdx,rsi
  40f426:	xor    r8d,r8d
  40f429:	call   4085a0 <__swc_fn_3464c816_000090_a2d50c23>
  40f42e:	test   al,al
  40f430:	jne    40f49e <__swc_fn_3464c816_000089_386582f3+0x30e>
  40f432:	test   DWORD PTR [rsi+0x28],0x10000
  40f439:	je     40f457 <__swc_fn_3464c816_000089_386582f3+0x2c7>
  40f43b:	rex mov al,BYTE PTR [rsp+0x8]
  40f440:	test   al,al
  40f442:	jne    40f457 <__swc_fn_3464c816_000089_386582f3+0x2c7>
  40f444:	xor    eax,eax
  40f446:	add    rsp,0x38
  40f44a:	pop    r15
  40f44c:	pop    r14
  40f44e:	pop    r13
  40f450:	pop    r12
  40f452:	pop    rdi
  40f453:	pop    rsi
  40f454:	pop    rbx
  40f455:	pop    rbp
  40f456:	ret
  40f457:	test   rdi,rdi
  40f45a:	jne    40f46f <__swc_fn_3464c816_000089_386582f3+0x2df>
  40f45c:	xor    eax,eax
  40f45e:	add    rsp,0x38
  40f462:	pop    r15
  40f464:	pop    r14
  40f466:	pop    r13
  40f468:	pop    r12
  40f46a:	pop    rdi
  40f46b:	pop    rsi
  40f46c:	pop    rbx
  40f46d:	pop    rbp
  40f46e:	ret
  40f46f:	cmp    QWORD PTR [rdi+0x8],0x0
  40f474:	jne    40f489 <__swc_fn_3464c816_000089_386582f3+0x2f9>
  40f476:	xor    eax,eax
  40f478:	add    rsp,0x38
  40f47c:	pop    r15
  40f47e:	pop    r14
  40f480:	pop    r13
  40f482:	pop    r12
  40f484:	pop    rdi
  40f485:	pop    rsi
  40f486:	pop    rbx
  40f487:	pop    rbp
  40f488:	ret
  40f489:	mov    rax,QWORD PTR [rdi+0x8]
  40f48d:	mov    rax,QWORD PTR [rax]
  40f490:	mov    rsi,rax
  40f493:	mov    rdi,QWORD PTR [rdi]
  40f496:	mov    eax,0x1
  40f49b:	mov    r14b,al
  40f49e:	test   rdi,rdi
  40f4a1:	mov    rbx,QWORD PTR [rsp+0x20]
  40f4a6:	jne    40f4f0 <__swc_fn_3464c816_000089_386582f3+0x360>
  40f4a8:	test   r14b,r14b
  40f4ab:	je     40f4dd <__swc_fn_3464c816_000089_386582f3+0x34d>
  40f4ad:	test   r12,r12
  40f4b0:	je     40f4dd <__swc_fn_3464c816_000089_386582f3+0x34d>
  40f4b2:	mov    rcx,r15
  40f4b5:	mov    rdx,rsi
  40f4b8:	xor    r8d,r8d
  40f4bb:	mov    r9,r12
  40f4be:	mov    rbx,QWORD PTR [rsp+0x20]
  40f4c3:	movzx  r10d,BYTE PTR [rbx]
  40f4c7:	call   40f080 <__swc_fn_3464c816_000083_31b501f2>
  40f4cc:	add    rsp,0x38
  40f4d0:	pop    r15
  40f4d2:	pop    r14
  40f4d4:	pop    r13
  40f4d6:	pop    r12
  40f4d8:	pop    rdi
  40f4d9:	pop    rsi
  40f4da:	pop    rbx
  40f4db:	pop    rbp
  40f4dc:	ret
  40f4dd:	xor    eax,eax
  40f4df:	add    rsp,0x38
  40f4e3:	pop    r15
  40f4e5:	pop    r14
  40f4e7:	pop    r13
  40f4e9:	pop    r12
  40f4eb:	pop    rdi
  40f4ec:	pop    rsi
  40f4ed:	pop    rbx
  40f4ee:	pop    rbp
  40f4ef:	ret
  40f4f0:	mov    r13,rsi
  40f4f3:	mov    QWORD PTR [rsp+0x28],rdi
  40f4f8:	cmp    BYTE PTR [r15+0x2c],0xe
  40f4fd:	sete   al
  40f500:	mov    r14b,al
  40f503:	jne    40f517 <__swc_fn_3464c816_000089_386582f3+0x387>
  40f505:	mov    rcx,rsi
  40f508:	mov    rdx,r15
  40f50b:	call   40c080 <__swc_fn_3464c816_000085_1edf7c76>
  40f510:	mov    r14b,al
  40f513:	test   al,al
  40f515:	jne    40f54c <__swc_fn_3464c816_000089_386582f3+0x3bc>
  40f517:	cmp    BYTE PTR [r15+0x2c],0x12
  40f51c:	je     40f54c <__swc_fn_3464c816_000089_386582f3+0x3bc>
  40f51e:	mov    rcx,r15
  40f521:	mov    rdx,rsi
  40f524:	mov    r8,rdi
  40f527:	mov    r9,r12
  40f52a:	mov    rax,rbx
  40f52d:	movzx  r10d,BYTE PTR [rax]
  40f531:	call   40f080 <__swc_fn_3464c816_000083_31b501f2>
  40f536:	test   rax,rax
  40f539:	je     40f54c <__swc_fn_3464c816_000089_386582f3+0x3bc>
  40f53b:	add    rsp,0x38
  40f53f:	pop    r15
  40f541:	pop    r14
  40f543:	pop    r13
  40f545:	pop    r12
  40f547:	pop    rdi
  40f548:	pop    rsi
  40f549:	pop    rbx
  40f54a:	pop    rbp
  40f54b:	ret
  40f54c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40f551:	jne    40f570 <__swc_fn_3464c816_000089_386582f3+0x3e0>
  40f553:	mov    rax,QWORD PTR [rsi+0xd8]
  40f55a:	test   rax,rax
  40f55d:	je     40f570 <__swc_fn_3464c816_000089_386582f3+0x3e0>
  40f55f:	add    rdi,QWORD PTR [rax+0x8]
  40f563:	mov    rax,QWORD PTR [rdi]
  40f566:	sub    rdi,QWORD PTR [rax+0x8]
  40f56a:	mov    rax,QWORD PTR [rax]
  40f56d:	mov    rsi,rax
  40f570:	test   r14b,r14b
  40f573:	je     40f59f <__swc_fn_3464c816_000089_386582f3+0x40f>
  40f575:	mov    rcx,r15
  40f578:	mov    rdx,rsi
  40f57b:	mov    r8,rdi
  40f57e:	mov    r9,r13
  40f581:	mov    r14,QWORD PTR [rsp+0x28]
  40f586:	mov    r10,r14
  40f589:	call   408480 <__swc_fn_3464c816_000087_ea575bb3>
  40f58e:	add    rsp,0x38
  40f592:	pop    r15
  40f594:	pop    r14
  40f596:	pop    r13
  40f598:	pop    r12
  40f59a:	pop    rdi
  40f59b:	pop    rsi
  40f59c:	pop    rbx
  40f59d:	pop    rbp
  40f59e:	ret
  40f59f:	mov    rcx,r15
  40f5a2:	mov    rdx,rsi
  40f5a5:	mov    r8,rdi
  40f5a8:	mov    r9,r12
  40f5ab:	movzx  r10d,BYTE PTR [rbx]
  40f5af:	call   40f080 <__swc_fn_3464c816_000083_31b501f2>
  40f5b4:	add    rsp,0x38
  40f5b8:	pop    r15
  40f5ba:	pop    r14
  40f5bc:	pop    r13
  40f5be:	pop    r12
  40f5c0:	pop    rdi
  40f5c1:	pop    rsi
  40f5c2:	pop    rbx
  40f5c3:	pop    rbp
  40f5c4:	ret
	...

000000000040f5d0 <__swc_fn_3464c816_000092_8252f8c0>:
  40f5d0:	push   rbx
  40f5d1:	push   rsi
  40f5d2:	sub    rsp,0x18
  40f5d6:	mov    rbx,rcx
  40f5d9:	mov    rcx,QWORD PTR [rip+0x17760]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40f5e0:	test   rcx,rcx
  40f5e3:	jne    40f5f5 <__swc_fn_3464c816_000092_8252f8c0+0x25>
  40f5e5:	call   40a1d0 <__swc_fn_3464c816_000165_cf398896>
  40f5ea:	lea    rcx,[rax+0x1]
  40f5ee:	mov    QWORD PTR [rip+0x1774b],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40f5f5:	dec    rcx
  40f5f8:	call   411f00 <__swc_fn_3464c816_000167_fce60b2b>
  40f5fd:	mov    rsi,rax
  40f600:	mov    rax,QWORD PTR [rsi+0x8]
  40f604:	test   rax,rax
  40f607:	jne    40f657 <__swc_fn_3464c816_000092_8252f8c0+0x87>
  40f609:	call   40c170 <__swc_fn_3464c816_000091_3d2f5a0d>
  40f60e:	test   al,al
  40f610:	jne    40f657 <__swc_fn_3464c816_000092_8252f8c0+0x87>
  40f612:	lea    rdx,[rip+0x14c27]        # 424240 <__swc_bss_base_3464c816+0x200>
  40f619:	mov    rcx,rdx
  40f61c:	call   407740 <__swc_fn_3464c816_000036_8d895ba1>
  40f621:	test   al,al
  40f623:	jne    40f634 <__swc_fn_3464c816_000092_8252f8c0+0x64>
  40f625:	mov    rcx,rdx
  40f628:	call   40aa60 <__swc_fn_3464c816_000034_25f19556>
  40f62d:	lea    rdx,[rip+0x14c0c]        # 424240 <__swc_bss_base_3464c816+0x200>
  40f634:	mov    QWORD PTR [rsp+0x8],rdx
  40f639:	lea    rax,[rip+0x3b10]        # 413150 <__swc_rdata_base_3464c816+0x40>
  40f640:	mov    QWORD PTR [rsp+0x10],rax
  40f645:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f64b:	vmovups XMMWORD PTR [rsi],xmm0
  40f64f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f657:	vmovups xmm0,XMMWORD PTR [rsi]
  40f65b:	vmovups XMMWORD PTR [rbx],xmm0
  40f65f:	mov    rax,rbx
  40f662:	add    rsp,0x18
  40f666:	pop    rsi
  40f667:	pop    rbx
  40f668:	ret
  40f669:	add    BYTE PTR [rax],al
  40f66b:	add    BYTE PTR [rax],al
  40f66d:	add    BYTE PTR [rax],al
	...

000000000040f670 <__swc_fn_3464c816_000095_337e587a>:
  40f670:	sub    rsp,0x8
  40f674:	call   409360 <__swc_fn_3464c816_000117_86a7fb9e>
  40f679:	add    rsp,0x8
  40f67d:	ret
	...

000000000040f680 <__swc_fn_3464c816_000098_00f01091>:
  40f680:	push   rbx
  40f681:	push   rsi
  40f682:	sub    rsp,0x28
  40f686:	mov    rbx,rcx
  40f689:	xor    esi,esi
  40f68b:	jmp    40f6a0 <__swc_fn_3464c816_000098_00f01091+0x20>
  40f68d:	nop    DWORD PTR [rax]
  40f690:	mov    QWORD PTR [rbx+0x28],rsi
  40f694:	mov    rsi,rbx
  40f697:	mov    rbx,rax
  40f69a:	nop    WORD PTR [rax+rax*1+0x0]
  40f6a0:	test   rbx,rbx
  40f6a3:	je     40f703 <__swc_fn_3464c816_000098_00f01091+0x83>
  40f6a5:	mov    rcx,rbx
  40f6a8:	mov    edx,0x1
  40f6ad:	call   408200 <__swc_fn_3464c816_000078_a120bd2b>
  40f6b2:	cmp    rax,0x1
  40f6b6:	jne    40f703 <__swc_fn_3464c816_000098_00f01091+0x83>
  40f6b8:	mov    r10,QWORD PTR [rbx+0x18]
  40f6bc:	mov    rcx,r10
  40f6bf:	mov    edx,0x1
  40f6c4:	call   408200 <__swc_fn_3464c816_000078_a120bd2b>
  40f6c9:	cmp    rax,0x1
  40f6cd:	jne    40f6dc <__swc_fn_3464c816_000098_00f01091+0x5c>
  40f6cf:	mov    rcx,r10
  40f6d2:	call   40c310 <__swc_fn_3464c816_000097_4c97e0db>
  40f6d7:	test   rax,rax
  40f6da:	jne    40f690 <__swc_fn_3464c816_000098_00f01091+0x10>
  40f6dc:	mov    rax,QWORD PTR [rbx+0x20]
  40f6e0:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f6e5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f6eb:	lea    rcx,[rsp+0x8]
  40f6f0:	mov    rdx,rbx
  40f6f3:	mov    r8d,0x30
  40f6f9:	mov    rbx,rax
  40f6fc:	call   408960 <__swc_fn_3464c816_000096_ad982b35>
  40f701:	jmp    40f6a0 <__swc_fn_3464c816_000098_00f01091+0x20>
  40f703:	test   rsi,rsi
  40f706:	jne    40f70f <__swc_fn_3464c816_000098_00f01091+0x8f>
  40f708:	add    rsp,0x28
  40f70c:	pop    rsi
  40f70d:	pop    rbx
  40f70e:	ret
  40f70f:	mov    rax,rsi
  40f712:	mov    rsi,QWORD PTR [rsi+0x28]
  40f716:	mov    rbx,QWORD PTR [rax+0x20]
  40f71a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f71f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f725:	lea    rcx,[rsp+0x18]
  40f72a:	mov    rdx,rax
  40f72d:	mov    r8d,0x30
  40f733:	call   408960 <__swc_fn_3464c816_000096_ad982b35>
  40f738:	jmp    40f6a0 <__swc_fn_3464c816_000098_00f01091+0x20>
  40f73d:	add    BYTE PTR [rax],al
	...

000000000040f740 <__swc_fn_3464c816_000101_eab3874f>:
  40f740:	push   rbx
  40f741:	push   rsi
  40f742:	push   rdi
  40f743:	push   r12
  40f745:	push   r13
  40f747:	sub    rsp,0x20
  40f74b:	mov    rbx,rcx
  40f74e:	lea    rsi,[rcx+0x6f8]
  40f755:	mov    edi,0x4
  40f75a:	mov    r12,rsi
  40f75d:	test   rdi,rdi
  40f760:	je     40f7aa <__swc_fn_3464c816_000101_eab3874f+0x6a>
  40f762:	cs nop WORD PTR [rax+rax*1+0x0]
  40f76c:	nop    DWORD PTR [rax+0x0]
  40f770:	mov    rcx,QWORD PTR [r12+0x10]
  40f775:	mov    QWORD PTR [r12+0x10],0x0
  40f77e:	vxorps xmm0,xmm0,xmm0
  40f782:	vmovups XMMWORD PTR [r12],xmm0
  40f788:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f78f:	mov    DWORD PTR [r12+0x20],0x0
  40f798:	call   4089c0 <__swc_fn_3464c816_000099_b4c6da83>
  40f79d:	add    r12,0x90
  40f7a4:	sub    rdi,0x1
  40f7a8:	jne    40f770 <__swc_fn_3464c816_000101_eab3874f+0x30>
  40f7aa:	mov    rax,QWORD PTR [rbx+0x938]
  40f7b1:	mov    rdi,rax
  40f7b4:	test   rdi,rdi
  40f7b7:	je     40f811 <__swc_fn_3464c816_000101_eab3874f+0xd1>
  40f7b9:	nop    DWORD PTR [rax+0x0]
  40f7c0:	mov    r12d,0x10
  40f7c6:	lea    r13,[rdi+0x18]
  40f7ca:	test   r12,r12
  40f7cd:	je     40f806 <__swc_fn_3464c816_000101_eab3874f+0xc6>
  40f7cf:	nop
  40f7d0:	mov    rcx,QWORD PTR [r13+0x10]
  40f7d4:	mov    QWORD PTR [r13+0x10],0x0
  40f7dc:	vxorps xmm0,xmm0,xmm0
  40f7e0:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f7e6:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f7ec:	mov    DWORD PTR [r13+0x20],0x0
  40f7f4:	call   4089c0 <__swc_fn_3464c816_000099_b4c6da83>
  40f7f9:	add    r13,0x90
  40f800:	sub    r12,0x1
  40f804:	jne    40f7d0 <__swc_fn_3464c816_000101_eab3874f+0x90>
  40f806:	mov    rax,QWORD PTR [rdi]
  40f809:	mov    rdi,rax
  40f80c:	test   rax,rax
  40f80f:	jne    40f7c0 <__swc_fn_3464c816_000101_eab3874f+0x80>
  40f811:	vxorps xmm0,xmm0,xmm0
  40f815:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f81d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f827:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f831:	mov    edi,0x4
  40f836:	mov    r12,rsi
  40f839:	lea    rsi,[rsi+0x38]
  40f83d:	test   rdi,rdi
  40f840:	je     40f86c <__swc_fn_3464c816_000101_eab3874f+0x12c>
  40f842:	cs nop WORD PTR [rax+rax*1+0x0]
  40f84c:	nop    DWORD PTR [rax+0x0]
  40f850:	mov    rcx,rsi
  40f853:	call   40d1a0 <__swc_fn_3464c816_000157_232ffa22>
  40f858:	add    rsi,0x90
  40f85f:	add    r12,0x90
  40f866:	sub    rdi,0x1
  40f86a:	jne    40f850 <__swc_fn_3464c816_000101_eab3874f+0x110>
  40f86c:	mov    rax,QWORD PTR [rbx+0x938]
  40f873:	mov    rdi,rax
  40f876:	mov    QWORD PTR [rbx+0x938],0x0
  40f881:	test   rdi,rdi
  40f884:	je     40f8f5 <__swc_fn_3464c816_000101_eab3874f+0x1b5>
  40f88a:	nop    WORD PTR [rax+rax*1+0x0]
  40f890:	mov    esi,0x10
  40f895:	lea    r12,[rdi+0x18]
  40f899:	lea    r13,[rdi+0x50]
  40f89d:	test   rsi,rsi
  40f8a0:	je     40f8cc <__swc_fn_3464c816_000101_eab3874f+0x18c>
  40f8a2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f8ac:	nop    DWORD PTR [rax+0x0]
  40f8b0:	mov    rcx,r13
  40f8b3:	call   40d1a0 <__swc_fn_3464c816_000157_232ffa22>
  40f8b8:	add    r13,0x90
  40f8bf:	add    r12,0x90
  40f8c6:	sub    rsi,0x1
  40f8ca:	jne    40f8b0 <__swc_fn_3464c816_000101_eab3874f+0x170>
  40f8cc:	mov    rax,QWORD PTR [rdi]
  40f8cf:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f8d4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f8da:	lea    rcx,[rsp+0x8]
  40f8df:	mov    rdx,rdi
  40f8e2:	mov    r8d,0x918
  40f8e8:	mov    rdi,rax
  40f8eb:	call   408960 <__swc_fn_3464c816_000096_ad982b35>
  40f8f0:	test   rdi,rdi
  40f8f3:	jne    40f890 <__swc_fn_3464c816_000101_eab3874f+0x150>
  40f8f5:	lea    rcx,[rbx+0x68]
  40f8f9:	call   40d1a0 <__swc_fn_3464c816_000157_232ffa22>
  40f8fe:	add    rsp,0x20
  40f902:	pop    r13
  40f904:	pop    r12
  40f906:	pop    rdi
  40f907:	pop    rsi
  40f908:	pop    rbx
  40f909:	ret
  40f90a:	add    BYTE PTR [rax],al
  40f90c:	add    BYTE PTR [rax],al
	...

000000000040f910 <__swc_fn_3464c816_000104_5589fdbd>:
  40f910:	xor    eax,eax
  40f912:	cs nop WORD PTR [rax+rax*1+0x0]
  40f91c:	nop    DWORD PTR [rax+0x0]
  40f920:	mov    r9,r8
  40f923:	sub    r9,rax
  40f926:	cmp    r9,0x40
  40f92a:	jb     40f968 <__swc_fn_3464c816_000104_5589fdbd+0x58>
  40f92c:	lea    r9,[rcx+rax*1]
  40f930:	lea    r10,[rdx+rax*1]
  40f934:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f93a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40f940:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40f946:	vmovups xmm3,XMMWORD PTR [r10]
  40f94b:	vmovups XMMWORD PTR [r9],xmm3
  40f950:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40f956:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40f95c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40f962:	lea    rax,[rax+0x40]
  40f966:	jmp    40f920 <__swc_fn_3464c816_000104_5589fdbd+0x10>
  40f968:	nop    DWORD PTR [rax+rax*1+0x0]
  40f970:	mov    r9,r8
  40f973:	sub    r9,rax
  40f976:	cmp    r9,0x10
  40f97a:	jb     40f994 <__swc_fn_3464c816_000104_5589fdbd+0x84>
  40f97c:	lea    r9,[rdx+rax*1]
  40f980:	lea    r10,[rcx+rax*1]
  40f984:	vmovups xmm0,XMMWORD PTR [r9]
  40f989:	vmovups XMMWORD PTR [r10],xmm0
  40f98e:	lea    rax,[rax+0x10]
  40f992:	jmp    40f970 <__swc_fn_3464c816_000104_5589fdbd+0x60>
  40f994:	cs nop WORD PTR [rax+rax*1+0x0]
  40f99e:	xchg   ax,ax
  40f9a0:	mov    r9,r8
  40f9a3:	sub    r9,rax
  40f9a6:	cmp    r9,0x8
  40f9aa:	jb     40f9bd <__swc_fn_3464c816_000104_5589fdbd+0xad>
  40f9ac:	lea    r9,[rcx+rax*1]
  40f9b0:	mov    r10,QWORD PTR [rdx+rax*1]
  40f9b4:	mov    QWORD PTR [r9],r10
  40f9b7:	lea    rax,[rax+0x8]
  40f9bb:	jmp    40f9a0 <__swc_fn_3464c816_000104_5589fdbd+0x90>
  40f9bd:	cmp    rax,r8
  40f9c0:	jae    40f9e0 <__swc_fn_3464c816_000104_5589fdbd+0xd0>
  40f9c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f9cc:	nop    DWORD PTR [rax+0x0]
  40f9d0:	mov    r9b,BYTE PTR [rdx+rax*1]
  40f9d4:	mov    BYTE PTR [rcx+rax*1],r9b
  40f9d8:	inc    rax
  40f9db:	cmp    rax,r8
  40f9de:	jb     40f9d0 <__swc_fn_3464c816_000104_5589fdbd+0xc0>
  40f9e0:	ret
	...

000000000040fa00 <__swc_fn_3464c816_000107_4796e893>:
  40fa00:	push   rbx
  40fa01:	push   r12
  40fa03:	push   rdi
  40fa04:	push   rsi
  40fa05:	push   r13
  40fa07:	push   r14
  40fa09:	push   r15
  40fa0b:	sub    rsp,0x170
  40fa12:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40fa1b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40fa24:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40fa2d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40fa36:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40fa3f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40fa48:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40fa51:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40fa5a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40fa63:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40fa6c:	mov    ebx,edx
  40fa6e:	mov    QWORD PTR [rsp+0xa8],rbx
  40fa76:	mov    r12d,ecx
  40fa79:	test   edx,edx
  40fa7b:	jne    40fa92 <__swc_fn_3464c816_000107_4796e893+0x92>
  40fa7d:	xor    eax,eax
  40fa7f:	add    rsp,0x170
  40fa86:	pop    r15
  40fa88:	pop    r14
  40fa8a:	pop    r13
  40fa8c:	pop    rsi
  40fa8d:	pop    rdi
  40fa8e:	pop    r12
  40fa90:	pop    rbx
  40fa91:	ret
  40fa92:	lea    rdi,[rip+0x3a17]        # 4134b0 <__swc_rdata_base_3464c816+0x3a0>
  40fa99:	mov    esi,0x90000
  40fa9e:	xor    eax,eax
  40faa0:	call   407090 <open@plt>
  40faa5:	mov    r13,rax
  40faa8:	mov    QWORD PTR [rsp+0xb0],rax
  40fab0:	test   eax,eax
  40fab2:	jge    40fabb <__swc_fn_3464c816_000107_4796e893+0xbb>
  40fab4:	xor    eax,eax
  40fab6:	jmp    40ffd6 <__swc_fn_3464c816_000107_4796e893+0x5d6>
  40fabb:	nop    DWORD PTR [rax+rax*1+0x0]
  40fac0:	movsxd rdi,r13d
  40fac3:	mov    esi,0x2
  40fac8:	xor    eax,eax
  40faca:	call   407120 <flock@plt>
  40facf:	test   eax,eax
  40fad1:	je     40faf0 <__swc_fn_3464c816_000107_4796e893+0xf0>
  40fad3:	xor    eax,eax
  40fad5:	call   407130 <__errno_location@plt>
  40fada:	cmp    DWORD PTR [rax],0x4
  40fadd:	je     40fac0 <__swc_fn_3464c816_000107_4796e893+0xc0>
  40fadf:	movsxd rdi,r13d
  40fae2:	xor    eax,eax
  40fae4:	call   4070b0 <close@plt>
  40fae9:	xor    eax,eax
  40faeb:	jmp    40ffd6 <__swc_fn_3464c816_000107_4796e893+0x5d6>
  40faf0:	lea    r14,[rsp+0x8]
  40faf5:	mov    QWORD PTR [rsp+0xb8],r14
  40fafd:	vxorps xmm0,xmm0,xmm0
  40fb01:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fb07:	mov    QWORD PTR [rsp+0x18],0x0
  40fb10:	mov    WORD PTR [rsp+0x20],0x0
  40fb17:	mov    DWORD PTR [r14],0x67617753
  40fb1e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40fb26:	xor    eax,eax
  40fb28:	call   407010 <getpid@plt>
  40fb2d:	mov    ecx,eax
  40fb2f:	mov    eax,0x1c
  40fb34:	shrx   eax,ecx,eax
  40fb39:	and    eax,0xf
  40fb3c:	mov    rdx,QWORD PTR [rip+0x398d]        # 4134d0 <__swc_rdata_base_3464c816+0x3c0>
  40fb43:	mov    al,BYTE PTR [rdx+rax*1]
  40fb46:	rex mov BYTE PTR [rsp+0x10],al
  40fb4b:	mov    eax,0x1c
  40fb50:	shrx   eax,r12d,eax
  40fb55:	and    eax,0xf
  40fb58:	mov    al,BYTE PTR [rdx+rax*1]
  40fb5b:	rex mov BYTE PTR [rsp+0x19],al
  40fb60:	mov    eax,0x18
  40fb65:	shrx   eax,ecx,eax
  40fb6a:	and    eax,0xf
  40fb6d:	mov    al,BYTE PTR [rdx+rax*1]
  40fb70:	rex mov BYTE PTR [rsp+0x11],al
  40fb75:	mov    eax,0x18
  40fb7a:	shrx   eax,r12d,eax
  40fb7f:	and    eax,0xf
  40fb82:	mov    al,BYTE PTR [rdx+rax*1]
  40fb85:	rex mov BYTE PTR [rsp+0x1a],al
  40fb8a:	mov    eax,0x14
  40fb8f:	shrx   eax,ecx,eax
  40fb94:	and    eax,0xf
  40fb97:	mov    al,BYTE PTR [rdx+rax*1]
  40fb9a:	rex mov BYTE PTR [rsp+0x12],al
  40fb9f:	mov    eax,0x14
  40fba4:	shrx   eax,r12d,eax
  40fba9:	and    eax,0xf
  40fbac:	mov    al,BYTE PTR [rdx+rax*1]
  40fbaf:	rex mov BYTE PTR [rsp+0x1b],al
  40fbb4:	mov    eax,0x10
  40fbb9:	shrx   eax,ecx,eax
  40fbbe:	and    eax,0xf
  40fbc1:	mov    al,BYTE PTR [rdx+rax*1]
  40fbc4:	rex mov BYTE PTR [rsp+0x13],al
  40fbc9:	mov    eax,0x10
  40fbce:	shrx   eax,r12d,eax
  40fbd3:	and    eax,0xf
  40fbd6:	mov    al,BYTE PTR [rdx+rax*1]
  40fbd9:	rex mov BYTE PTR [rsp+0x1c],al
  40fbde:	mov    eax,0xc
  40fbe3:	shrx   eax,ecx,eax
  40fbe8:	and    eax,0xf
  40fbeb:	mov    al,BYTE PTR [rdx+rax*1]
  40fbee:	rex mov BYTE PTR [rsp+0x14],al
  40fbf3:	mov    eax,0xc
  40fbf8:	shrx   eax,r12d,eax
  40fbfd:	and    eax,0xf
  40fc00:	mov    al,BYTE PTR [rdx+rax*1]
  40fc03:	rex mov BYTE PTR [rsp+0x1d],al
  40fc08:	mov    eax,0x8
  40fc0d:	shrx   eax,ecx,eax
  40fc12:	and    eax,0xf
  40fc15:	mov    al,BYTE PTR [rdx+rax*1]
  40fc18:	rex mov BYTE PTR [rsp+0x15],al
  40fc1d:	mov    eax,0x8
  40fc22:	shrx   eax,r12d,eax
  40fc27:	and    eax,0xf
  40fc2a:	mov    al,BYTE PTR [rdx+rax*1]
  40fc2d:	rex mov BYTE PTR [rsp+0x1e],al
  40fc32:	mov    eax,0x4
  40fc37:	shrx   eax,ecx,eax
  40fc3c:	and    eax,0xf
  40fc3f:	mov    al,BYTE PTR [rdx+rax*1]
  40fc42:	rex mov BYTE PTR [rsp+0x16],al
  40fc47:	mov    eax,0x4
  40fc4c:	shrx   eax,r12d,eax
  40fc51:	and    eax,0xf
  40fc54:	mov    al,BYTE PTR [rdx+rax*1]
  40fc57:	rex mov BYTE PTR [rsp+0x1f],al
  40fc5c:	xor    eax,eax
  40fc5e:	shrx   eax,ecx,eax
  40fc63:	and    eax,0xf
  40fc66:	mov    al,BYTE PTR [rdx+rax*1]
  40fc69:	rex mov BYTE PTR [rsp+0x17],al
  40fc6e:	xor    eax,eax
  40fc70:	shrx   eax,r12d,eax
  40fc75:	and    eax,0xf
  40fc78:	mov    al,BYTE PTR [rdx+rax*1]
  40fc7b:	rex mov BYTE PTR [rsp+0x20],al
  40fc80:	mov    BYTE PTR [r14+0x10],0x2e
  40fc85:	lea    r12,[rsp+0x22]
  40fc8a:	vxorps xmm0,xmm0,xmm0
  40fc8e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40fc94:	mov    DWORD PTR [r12],0x6d656d2f
  40fc9c:	mov    WORD PTR [r12+0x4],0x6466
  40fca4:	mov    BYTE PTR [r12+0x6],0x3a
  40fcaa:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40fcb0:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40fcb6:	mov    rax,QWORD PTR [rsp+0x18]
  40fcbb:	mov    QWORD PTR [rsp+0x39],rax
  40fcc0:	rex mov al,BYTE PTR [rsp+0x20]
  40fcc5:	rex mov BYTE PTR [rsp+0x41],al
  40fcca:	mov    DWORD PTR [r12+0x20],0x65642820
  40fcd3:	mov    DWORD PTR [r12+0x24],0x6574656c
  40fcdc:	mov    WORD PTR [r12+0x28],0x2964
  40fce4:	lea    rdi,[rip+0x37d0]        # 4134bb <__swc_rdata_base_3464c816+0x3ab>
  40fceb:	xor    eax,eax
  40fced:	call   407140 <opendir@plt>
  40fcf2:	mov    r15,rax
  40fcf5:	test   rax,rax
  40fcf8:	jne    40fd0b <__swc_fn_3464c816_000107_4796e893+0x30b>
  40fcfa:	movsxd rdi,r13d
  40fcfd:	xor    eax,eax
  40fcff:	call   4070b0 <close@plt>
  40fd04:	xor    eax,eax
  40fd06:	jmp    40ffd6 <__swc_fn_3464c816_000107_4796e893+0x5d6>
  40fd0b:	mov    rdi,r15
  40fd0e:	xor    eax,eax
  40fd10:	call   407150 <dirfd@plt>
  40fd15:	lea    r14,[rsp+0x54]
  40fd1a:	mov    DWORD PTR [rsp+0x54],eax
  40fd1e:	lea    rbx,[rsp+0x58]
  40fd23:	cs nop WORD PTR [rax+rax*1+0x0]
  40fd2d:	cs nop WORD PTR [rax+rax*1+0x0]
  40fd37:	nop    WORD PTR [rax+rax*1+0x0]
  40fd40:	mov    rdi,r15
  40fd43:	xor    eax,eax
  40fd45:	call   407160 <readdir@plt>
  40fd4a:	test   rax,rax
  40fd4d:	jne    40fd64 <__swc_fn_3464c816_000107_4796e893+0x364>
  40fd4f:	mov    r12,QWORD PTR [rsp+0xa8]
  40fd57:	mov    r13,QWORD PTR [rsp+0xb0]
  40fd5f:	jmp    40fefa <__swc_fn_3464c816_000107_4796e893+0x4fa>
  40fd64:	vxorps xmm0,xmm0,xmm0
  40fd68:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40fd6e:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40fd74:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40fd7a:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40fd83:	lea    r13,[rax+0x13]
  40fd87:	mov    rax,r14
  40fd8a:	movsxd rdi,DWORD PTR [rax]
  40fd8d:	mov    rsi,r13
  40fd90:	mov    rdx,rbx
  40fd93:	mov    ecx,0x40
  40fd98:	xor    eax,eax
  40fd9a:	call   407170 <readlinkat@plt>
  40fd9f:	cmp    rax,0x2a
  40fda3:	jne    40fd40 <__swc_fn_3464c816_000107_4796e893+0x340>
  40fda5:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40fdab:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40fdb1:	vptest xmm0,xmm0
  40fdb6:	jne    40fde6 <__swc_fn_3464c816_000107_4796e893+0x3e6>
  40fdb8:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40fdbe:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40fdc4:	vptest xmm0,xmm0
  40fdc9:	jne    40fde6 <__swc_fn_3464c816_000107_4796e893+0x3e6>
  40fdcb:	mov    rcx,QWORD PTR [rsp+0x42]
  40fdd0:	cmp    QWORD PTR [rsp+0x78],rcx
  40fdd5:	jne    40fde6 <__swc_fn_3464c816_000107_4796e893+0x3e6>
  40fdd7:	mov    cx,WORD PTR [rsp+0x4a]
  40fddc:	cmp    WORD PTR [rsp+0x80],cx
  40fde4:	je     40fe14 <__swc_fn_3464c816_000107_4796e893+0x414>
  40fde6:	mov    rax,rbx
  40fde9:	mov    rcx,r12
  40fdec:	nop    DWORD PTR [rax+0x0]
  40fdf0:	movzx  edx,BYTE PTR [rax]
  40fdf3:	movzx  r8d,BYTE PTR [rcx]
  40fdf7:	cmp    rdx,r8
  40fdfa:	jne    40fe06 <__swc_fn_3464c816_000107_4796e893+0x406>
  40fdfc:	add    rax,0x1
  40fe00:	add    rcx,0x1
  40fe04:	jmp    40fdf0 <__swc_fn_3464c816_000107_4796e893+0x3f0>
  40fe06:	mov    rax,rdx
  40fe09:	sub    rax,r8
  40fe0c:	test   eax,eax
  40fe0e:	jne    40fd40 <__swc_fn_3464c816_000107_4796e893+0x340>
  40fe14:	movsxd rdi,DWORD PTR [r14]
  40fe17:	mov    rsi,r13
  40fe1a:	mov    edx,0x80002
  40fe1f:	xor    eax,eax
  40fe21:	call   407180 <openat@plt>
  40fe26:	lea    rbx,[rsp+0x98]
  40fe2e:	mov    DWORD PTR [rsp+0x98],eax
  40fe35:	test   eax,eax
  40fe37:	mov    r13,QWORD PTR [rsp+0xb0]
  40fe3f:	jge    40fe64 <__swc_fn_3464c816_000107_4796e893+0x464>
  40fe41:	mov    rdi,r15
  40fe44:	xor    eax,eax
  40fe46:	call   407190 <closedir@plt>
  40fe4b:	mov    r13,QWORD PTR [rsp+0xb0]
  40fe53:	movsxd rdi,r13d
  40fe56:	xor    eax,eax
  40fe58:	call   4070b0 <close@plt>
  40fe5d:	xor    eax,eax
  40fe5f:	jmp    40ffd6 <__swc_fn_3464c816_000107_4796e893+0x5d6>
  40fe64:	mov    rax,rbx
  40fe67:	movsxd rdi,DWORD PTR [rax]
  40fe6a:	xor    esi,esi
  40fe6c:	mov    edx,0x2
  40fe71:	xor    eax,eax
  40fe73:	call   4070a0 <lseek@plt>
  40fe78:	mov    r12,QWORD PTR [rsp+0xa8]
  40fe80:	cmp    rax,r12
  40fe83:	je     40feaa <__swc_fn_3464c816_000107_4796e893+0x4aa>
  40fe85:	movsxd rdi,DWORD PTR [rbx]
  40fe88:	xor    eax,eax
  40fe8a:	call   4070b0 <close@plt>
  40fe8f:	mov    rdi,r15
  40fe92:	xor    eax,eax
  40fe94:	call   407190 <closedir@plt>
  40fe99:	movsxd rdi,r13d
  40fe9c:	xor    eax,eax
  40fe9e:	call   4070b0 <close@plt>
  40fea3:	xor    eax,eax
  40fea5:	jmp    40ffd6 <__swc_fn_3464c816_000107_4796e893+0x5d6>
  40feaa:	xor    edi,edi
  40feac:	mov    rsi,r12
  40feaf:	mov    edx,0x3
  40feb4:	mov    ecx,0x1
  40feb9:	mov    rax,rbx
  40febc:	movsxd r8,DWORD PTR [rax]
  40febf:	xor    r9d,r9d
  40fec2:	xor    eax,eax
  40fec4:	call   4070c0 <mmap@plt>
  40fec9:	xor    r12d,r12d
  40fecc:	cmp    rax,0xffffffffffffffff
  40fed0:	cmovne r12,rax
  40fed4:	movsxd rdi,DWORD PTR [rbx]
  40fed7:	xor    eax,eax
  40fed9:	call   4070b0 <close@plt>
  40fede:	mov    rdi,r15
  40fee1:	xor    eax,eax
  40fee3:	call   407190 <closedir@plt>
  40fee8:	movsxd rdi,r13d
  40feeb:	xor    eax,eax
  40feed:	call   4070b0 <close@plt>
  40fef2:	mov    rax,r12
  40fef5:	jmp    40ffd6 <__swc_fn_3464c816_000107_4796e893+0x5d6>
  40fefa:	mov    r14,QWORD PTR [rsp+0xb8]
  40ff02:	mov    rdi,r14
  40ff05:	mov    esi,0x1
  40ff0a:	xor    eax,eax
  40ff0c:	call   4071a0 <memfd_create@plt>
  40ff11:	lea    rbx,[rsp+0x9c]
  40ff19:	mov    DWORD PTR [rsp+0x9c],eax
  40ff20:	test   eax,eax
  40ff22:	jge    40ff3f <__swc_fn_3464c816_000107_4796e893+0x53f>
  40ff24:	mov    rdi,r15
  40ff27:	xor    eax,eax
  40ff29:	call   407190 <closedir@plt>
  40ff2e:	movsxd rdi,r13d
  40ff31:	xor    eax,eax
  40ff33:	call   4070b0 <close@plt>
  40ff38:	xor    eax,eax
  40ff3a:	jmp    40ffd6 <__swc_fn_3464c816_000107_4796e893+0x5d6>
  40ff3f:	mov    rax,rbx
  40ff42:	movsxd rdi,DWORD PTR [rax]
  40ff45:	mov    rsi,r12
  40ff48:	xor    eax,eax
  40ff4a:	call   4071b0 <ftruncate@plt>
  40ff4f:	test   eax,eax
  40ff51:	je     40ff75 <__swc_fn_3464c816_000107_4796e893+0x575>
  40ff53:	movsxd rdi,DWORD PTR [rbx]
  40ff56:	xor    eax,eax
  40ff58:	call   4070b0 <close@plt>
  40ff5d:	mov    rdi,r15
  40ff60:	xor    eax,eax
  40ff62:	call   407190 <closedir@plt>
  40ff67:	movsxd rdi,r13d
  40ff6a:	xor    eax,eax
  40ff6c:	call   4070b0 <close@plt>
  40ff71:	xor    eax,eax
  40ff73:	jmp    40ffd6 <__swc_fn_3464c816_000107_4796e893+0x5d6>
  40ff75:	xor    edi,edi
  40ff77:	mov    rsi,r12
  40ff7a:	mov    edx,0x3
  40ff7f:	mov    ecx,0x1
  40ff84:	mov    rax,rbx
  40ff87:	movsxd r8,DWORD PTR [rax]
  40ff8a:	xor    r9d,r9d
  40ff8d:	xor    eax,eax
  40ff8f:	call   4070c0 <mmap@plt>
  40ff94:	mov    r12,rax
  40ff97:	cmp    rax,0xffffffffffffffff
  40ff9b:	jne    40ffbf <__swc_fn_3464c816_000107_4796e893+0x5bf>
  40ff9d:	movsxd rdi,DWORD PTR [rbx]
  40ffa0:	xor    eax,eax
  40ffa2:	call   4070b0 <close@plt>
  40ffa7:	mov    rdi,r15
  40ffaa:	xor    eax,eax
  40ffac:	call   407190 <closedir@plt>
  40ffb1:	movsxd rdi,r13d
  40ffb4:	xor    eax,eax
  40ffb6:	call   4070b0 <close@plt>
  40ffbb:	xor    eax,eax
  40ffbd:	jmp    40ffd6 <__swc_fn_3464c816_000107_4796e893+0x5d6>
  40ffbf:	mov    rdi,r15
  40ffc2:	xor    eax,eax
  40ffc4:	call   407190 <closedir@plt>
  40ffc9:	movsxd rdi,r13d
  40ffcc:	xor    eax,eax
  40ffce:	call   4070b0 <close@plt>
  40ffd3:	mov    rax,r12
  40ffd6:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40ffdf:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40ffe8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40fff1:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40fffa:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  410003:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  41000c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  410015:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  41001e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  410027:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  410030:	add    rsp,0x170
  410037:	pop    r15
  410039:	pop    r14
  41003b:	pop    r13
  41003d:	pop    rsi
  41003e:	pop    rdi
  41003f:	pop    r12
  410041:	pop    rbx
  410042:	ret
	...

0000000000410050 <__swc_fn_3464c816_000110_a808fe76>:
  410050:	push   rsi
  410051:	push   rdi
  410052:	push   r12
  410054:	push   r13
  410056:	sub    rsp,0x8
  41005a:	mov    rsi,r8
  41005d:	mov    rdi,rcx
  410060:	mov    r12,rdx
  410063:	call   409120 <__swc_fn_3464c816_000108_84af7666>
  410068:	mov    r13,rax
  41006b:	test   rax,rax
  41006e:	jne    41007b <__swc_fn_3464c816_000110_a808fe76+0x2b>
  410070:	add    rsp,0x8
  410074:	pop    r13
  410076:	pop    r12
  410078:	pop    rdi
  410079:	pop    rsi
  41007a:	ret
  41007b:	mov    rcx,r13
  41007e:	call   40cd90 <__swc_fn_3464c816_000133_4b2af8da>
  410083:	mov    rax,QWORD PTR [r13+0x8]
  410087:	test   rax,rax
  41008a:	je     4100c9 <__swc_fn_3464c816_000110_a808fe76+0x79>
  41008c:	nop    DWORD PTR [rax+0x0]
  410090:	lea    rcx,[rax+0x1000]
  410097:	cmp    rdi,rcx
  41009a:	jne    4100c1 <__swc_fn_3464c816_000110_a808fe76+0x71>
  41009c:	cmp    r12,0x1000
  4100a3:	jb     4100c1 <__swc_fn_3464c816_000110_a808fe76+0x71>
  4100a5:	test   sil,sil
  4100a8:	setne  cl
  4100ab:	mov    BYTE PTR [rax+0x10],cl
  4100ae:	mov    rcx,r13
  4100b1:	call   4105c0 <__swc_fn_3464c816_000134_29412410>
  4100b6:	add    rsp,0x8
  4100ba:	pop    r13
  4100bc:	pop    r12
  4100be:	pop    rdi
  4100bf:	pop    rsi
  4100c0:	ret
  4100c1:	mov    rax,QWORD PTR [rax]
  4100c4:	test   rax,rax
  4100c7:	jne    410090 <__swc_fn_3464c816_000110_a808fe76+0x40>
  4100c9:	mov    rcx,r13
  4100cc:	call   4105c0 <__swc_fn_3464c816_000134_29412410>
  4100d1:	add    rsp,0x8
  4100d5:	pop    r13
  4100d7:	pop    r12
  4100d9:	pop    rdi
  4100da:	pop    rsi
  4100db:	ret
  4100dc:	add    BYTE PTR [rax],al
	...

00000000004100e0 <__swc_fn_3464c816_000113_49b378a9>:
  4100e0:	sub    rsp,0x8
  4100e4:	test   rcx,rcx
  4100e7:	jne    4100ee <__swc_fn_3464c816_000113_49b378a9+0xe>
  4100e9:	add    rsp,0x8
  4100ed:	ret
  4100ee:	call   40c8a0 <__swc_fn_3464c816_000115_1ba33335>
  4100f3:	add    rsp,0x8
  4100f7:	ret
	...

0000000000410100 <__swc_fn_3464c816_000116_035d76a1>:
  410100:	push   r12
  410102:	push   r13
  410104:	push   r14
  410106:	push   rdi
  410107:	push   rsi
  410108:	sub    rsp,0xc0
  41010f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410115:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  41011b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  410121:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410127:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  41012d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  410133:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410139:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  410142:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  41014b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  410154:	mov    r12,QWORD PTR [rcx]
  410157:	test   r12,r12
  41015a:	jne    41016c <__swc_fn_3464c816_000116_035d76a1+0x6c>
  41015c:	add    rsp,0xc0
  410163:	pop    rsi
  410164:	pop    rdi
  410165:	pop    r14
  410167:	pop    r13
  410169:	pop    r12
  41016b:	ret
  41016c:	xor    r13d,r13d
  41016f:	mov    r14,QWORD PTR [rcx+0x8]
  410173:	cs nop WORD PTR [rax+rax*1+0x0]
  41017d:	nop    DWORD PTR [rax]
  410180:	cmp    r13,r14
  410183:	jae    4101be <__swc_fn_3464c816_000116_035d76a1+0xbe>
  410185:	lea    rax,[r12+r13*1]
  410189:	mov    rcx,r14
  41018c:	sub    rcx,r13
  41018f:	mov    edi,0x1
  410194:	mov    rsi,rax
  410197:	mov    rdx,rcx
  41019a:	xor    eax,eax
  41019c:	call   4071c0 <write@plt>
  4101a1:	test   rax,rax
  4101a4:	jle    4101ab <__swc_fn_3464c816_000116_035d76a1+0xab>
  4101a6:	add    r13,rax
  4101a9:	jmp    410180 <__swc_fn_3464c816_000116_035d76a1+0x80>
  4101ab:	test   rax,rax
  4101ae:	je     4101bc <__swc_fn_3464c816_000116_035d76a1+0xbc>
  4101b0:	xor    eax,eax
  4101b2:	call   407130 <__errno_location@plt>
  4101b7:	cmp    DWORD PTR [rax],0x4
  4101ba:	je     410180 <__swc_fn_3464c816_000116_035d76a1+0x80>
  4101bc:	jmp    4101be <__swc_fn_3464c816_000116_035d76a1+0xbe>
  4101be:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4101c4:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4101ca:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4101d0:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4101d6:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4101dc:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4101e2:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4101e8:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4101f1:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4101fa:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410203:	add    rsp,0xc0
  41020a:	pop    rsi
  41020b:	pop    rdi
  41020c:	pop    r14
  41020e:	pop    r13
  410210:	pop    r12
  410212:	ret
	...

0000000000410220 <__swc_fn_3464c816_000119_9175a56a>:
  410220:	push   rbx
  410221:	push   r12
  410223:	push   rdi
  410224:	push   rsi
  410225:	sub    rsp,0x4a8
  41022c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  410235:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  41023e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  410247:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  410250:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  410259:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  410262:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  41026b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  410274:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  41027d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  410286:	mov    rbx,rdx
  410289:	mov    r12d,ecx
  41028c:	vxorps xmm0,xmm0,xmm0
  410290:	xor    eax,eax
  410292:	cs nop WORD PTR [rax+rax*1+0x0]
  41029c:	nop    DWORD PTR [rax+0x0]
  4102a0:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  4102a6:	add    rax,0x10
  4102aa:	cmp    rax,0x400
  4102b1:	jne    4102a0 <__swc_fn_3464c816_000119_9175a56a+0x80>
  4102b3:	lea    rdi,[rsp+0x8]
  4102b8:	mov    esi,0x80
  4102bd:	xor    eax,eax
  4102bf:	call   4071d0 <backtrace@plt>
  4102c4:	test   eax,eax
  4102c6:	jle    4102d5 <__swc_fn_3464c816_000119_9175a56a+0xb5>
  4102c8:	movsxd rax,eax
  4102cb:	lea    rcx,[r12+0x1]
  4102d0:	cmp    rcx,rax
  4102d3:	jb     4102d9 <__swc_fn_3464c816_000119_9175a56a+0xb9>
  4102d5:	xor    eax,eax
  4102d7:	jmp    41030a <__swc_fn_3464c816_000119_9175a56a+0xea>
  4102d9:	mov    rcx,QWORD PTR [rbx+0x8]
  4102dd:	sub    rax,r12
  4102e0:	lea    rsi,[rax-0x1]
  4102e4:	cmp    rcx,rsi
  4102e7:	cmovbe rsi,rcx
  4102eb:	lea    eax,[r12+0x1]
  4102f0:	lea    rax,[rsp+rax*8+0x8]
  4102f5:	mov    rcx,QWORD PTR [rbx]
  4102f8:	mov    rdx,rax
  4102fb:	lea    r8,[rsi*8+0x0]
  410303:	call   409100 <__swc_fn_3464c816_000105_6fd80914>
  410308:	mov    eax,esi
  41030a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  410313:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  41031c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  410325:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  41032e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  410337:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  410340:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  410349:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  410352:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  41035b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  410364:	add    rsp,0x4a8
  41036b:	pop    rsi
  41036c:	pop    rdi
  41036d:	pop    r12
  41036f:	pop    rbx
  410370:	ret
	...

0000000000410380 <__swc_fn_3464c816_000122_e09461fd>:
  410380:	mov    QWORD PTR [rcx],0x0
  410387:	ret
	...

0000000000410390 <__swc_fn_3464c816_000125_ce762363>:
  410390:	push   rdi
  410391:	push   rsi
  410392:	sub    rsp,0xa8
  410399:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41039f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4103a5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4103ab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4103b1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4103b7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4103bd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4103c3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4103c9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4103d2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4103db:	mov    edi,ecx
  4103dd:	mov    rsi,rdx
  4103e0:	xor    eax,eax
  4103e2:	call   407060 <pthread_setspecific@plt>
  4103e7:	test   eax,eax
  4103e9:	sete   al
  4103ec:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4103f2:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4103f8:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4103fe:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410404:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41040a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410410:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410416:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41041c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410425:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41042e:	add    rsp,0xa8
  410435:	pop    rsi
  410436:	pop    rdi
  410437:	ret
	...

0000000000410440 <__swc_fn_3464c816_000128_41c3251c>:
  410440:	push   rdi
  410441:	push   rsi
  410442:	sub    rsp,0xa8
  410449:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41044f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410455:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41045b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410461:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410467:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41046d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410473:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410479:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410482:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41048b:	test   rcx,rcx
  41048e:	je     4104a1 <__swc_fn_3464c816_000128_41c3251c+0x61>
  410490:	lea    rax,[rcx-0x1]
  410494:	mov    eax,eax
  410496:	mov    edi,eax
  410498:	xor    eax,eax
  41049a:	call   407000 <pthread_getspecific@plt>
  41049f:	jmp    4104a3 <__swc_fn_3464c816_000128_41c3251c+0x63>
  4104a1:	xor    eax,eax
  4104a3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4104a9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4104af:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4104b5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4104bb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4104c1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4104c7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4104cd:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4104d3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4104dc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4104e5:	add    rsp,0xa8
  4104ec:	pop    rsi
  4104ed:	pop    rdi
  4104ee:	ret
	...

00000000004104f0 <__swc_fn_3464c816_000131_944f555b>:
  4104f0:	push   rdi
  4104f1:	push   rsi
  4104f2:	sub    rsp,0xb8
  4104f9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4104ff:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410505:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41050b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410511:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410517:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41051d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410523:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41052c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410535:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41053e:	vxorps xmm0,xmm0,xmm0
  410542:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410548:	mov    edi,0x1
  41054d:	lea    rsi,[rsp+0x8]
  410552:	xor    eax,eax
  410554:	call   4070e0 <clock_gettime@plt>
  410559:	mov    rax,QWORD PTR [rsp+0x8]
  41055e:	imul   rax,rax,0x3b9aca00
  410565:	add    rax,QWORD PTR [rsp+0x10]
  41056a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410570:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410576:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  41057c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410582:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410588:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41058e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410594:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41059d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4105a6:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4105af:	add    rsp,0xb8
  4105b6:	pop    rsi
  4105b7:	pop    rdi
  4105b8:	ret
  4105b9:	add    BYTE PTR [rax],al
  4105bb:	add    BYTE PTR [rax],al
  4105bd:	add    BYTE PTR [rax],al
	...

00000000004105c0 <__swc_fn_3464c816_000134_29412410>:
  4105c0:	sub    rsp,0x8
  4105c4:	xor    eax,eax
  4105c6:	mov    DWORD PTR [rcx],eax
  4105c8:	mov    edx,0x7fffffff
  4105cd:	call   409800 <__swc_fn_3464c816_000132_f908e7f9>
  4105d2:	add    rsp,0x8
  4105d6:	ret
	...

00000000004105e0 <__swc_fn_3464c816_000137_a4ba10ed>:
  4105e0:	push   rdi
  4105e1:	push   rsi
  4105e2:	sub    rsp,0xb8
  4105e9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4105ef:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4105f5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4105fb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410601:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410607:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41060d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410613:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41061c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410625:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41062e:	mov    edi,0x1
  410633:	xor    eax,eax
  410635:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  41063a:	mov    eax,DWORD PTR [rax+0x14]
  41063d:	and    eax,0x20
  410640:	setne  al
  410643:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410649:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41064f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410655:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41065b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410661:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  410667:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41066d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  410676:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  41067f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410688:	add    rsp,0xb8
  41068f:	pop    rsi
  410690:	pop    rdi
  410691:	ret
	...

00000000004106a0 <__swc_fn_3464c816_000140_c6b99a56>:
  4106a0:	push   rsi
  4106a1:	push   rdi
  4106a2:	push   r12
  4106a4:	push   r13
  4106a6:	push   r14
  4106a8:	push   r15
  4106aa:	cmp    rdx,0x40
  4106ae:	jae    4106bd <__swc_fn_3464c816_000140_c6b99a56+0x1d>
  4106b0:	xor    eax,eax
  4106b2:	pop    r15
  4106b4:	pop    r14
  4106b6:	pop    r13
  4106b8:	pop    r12
  4106ba:	pop    rdi
  4106bb:	pop    rsi
  4106bc:	ret
  4106bd:	cmp    BYTE PTR [rcx],0x7f
  4106c0:	jne    410704 <__swc_fn_3464c816_000140_c6b99a56+0x64>
  4106c2:	movzx  eax,BYTE PTR [rcx+0x1]
  4106c6:	cmp    eax,0x45
  4106c9:	setne  al
  4106cc:	jne    410700 <__swc_fn_3464c816_000140_c6b99a56+0x60>
  4106ce:	movzx  eax,BYTE PTR [rcx+0x2]
  4106d2:	cmp    eax,0x4c
  4106d5:	setne  al
  4106d8:	jne    410700 <__swc_fn_3464c816_000140_c6b99a56+0x60>
  4106da:	movzx  eax,BYTE PTR [rcx+0x3]
  4106de:	cmp    eax,0x46
  4106e1:	setne  al
  4106e4:	jne    410700 <__swc_fn_3464c816_000140_c6b99a56+0x60>
  4106e6:	cmp    BYTE PTR [rcx+0x4],0x2
  4106ea:	setne  al
  4106ed:	jne    410700 <__swc_fn_3464c816_000140_c6b99a56+0x60>
  4106ef:	cmp    BYTE PTR [rcx+0x5],0x1
  4106f3:	setne  al
  4106f6:	jne    410700 <__swc_fn_3464c816_000140_c6b99a56+0x60>
  4106f8:	cmp    WORD PTR [rcx+0x12],0x3e
  4106fd:	setne  al
  410700:	test   al,al
  410702:	je     410711 <__swc_fn_3464c816_000140_c6b99a56+0x71>
  410704:	xor    eax,eax
  410706:	pop    r15
  410708:	pop    r14
  41070a:	pop    r13
  41070c:	pop    r12
  41070e:	pop    rdi
  41070f:	pop    rsi
  410710:	ret
  410711:	cmp    WORD PTR [rcx+0x3a],0x40
  410716:	jne    410731 <__swc_fn_3464c816_000140_c6b99a56+0x91>
  410718:	cmp    WORD PTR [rcx+0x3c],0x0
  41071d:	sete   al
  410720:	je     41072d <__swc_fn_3464c816_000140_c6b99a56+0x8d>
  410722:	mov    ax,WORD PTR [rcx+0x3c]
  410726:	cmp    WORD PTR [rcx+0x3e],ax
  41072a:	setae  al
  41072d:	test   al,al
  41072f:	je     41073e <__swc_fn_3464c816_000140_c6b99a56+0x9e>
  410731:	xor    eax,eax
  410733:	pop    r15
  410735:	pop    r14
  410737:	pop    r13
  410739:	pop    r12
  41073b:	pop    rdi
  41073c:	pop    rsi
  41073d:	ret
  41073e:	movzx  eax,WORD PTR [rcx+0x3c]
  410742:	shl    rax,0x6
  410746:	cmp    rax,rdx
  410749:	ja     410757 <__swc_fn_3464c816_000140_c6b99a56+0xb7>
  41074b:	mov    r9,rdx
  41074e:	sub    r9,rax
  410751:	cmp    QWORD PTR [rcx+0x28],r9
  410755:	jbe    410764 <__swc_fn_3464c816_000140_c6b99a56+0xc4>
  410757:	xor    eax,eax
  410759:	pop    r15
  41075b:	pop    r14
  41075d:	pop    r13
  41075f:	pop    r12
  410761:	pop    rdi
  410762:	pop    rsi
  410763:	ret
  410764:	mov    rax,QWORD PTR [rcx+0x28]
  410768:	add    rax,rcx
  41076b:	movzx  r9d,WORD PTR [rcx+0x3e]
  410770:	lea    r9,[r9*8+0x0]
  410778:	lea    r10,[rax+r9*8]
  41077c:	cmp    QWORD PTR [r10+0x20],rdx
  410780:	ja     4107a2 <__swc_fn_3464c816_000140_c6b99a56+0x102>
  410782:	mov    r11,rdx
  410785:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  41078a:	cmp    QWORD PTR [r10+0x18],r11
  41078e:	seta   r9b
  410792:	ja     41079d <__swc_fn_3464c816_000140_c6b99a56+0xfd>
  410794:	cmp    QWORD PTR [r10+0x20],0x9
  410799:	setb   r9b
  41079d:	test   r9b,r9b
  4107a0:	je     4107af <__swc_fn_3464c816_000140_c6b99a56+0x10f>
  4107a2:	xor    eax,eax
  4107a4:	pop    r15
  4107a6:	pop    r14
  4107a8:	pop    r13
  4107aa:	pop    r12
  4107ac:	pop    rdi
  4107ad:	pop    rsi
  4107ae:	ret
  4107af:	movzx  r9d,WORD PTR [rcx+0x3c]
  4107b4:	xor    r11d,r11d
  4107b7:	test   r9,r9
  4107ba:	jbe    4108b5 <__swc_fn_3464c816_000140_c6b99a56+0x215>
  4107c0:	mov    rsi,QWORD PTR [r10+0x20]
  4107c4:	sub    rsi,0x9
  4107c8:	cs nop WORD PTR [rax+rax*1+0x0]
  4107d2:	cs nop WORD PTR [rax+rax*1+0x0]
  4107dc:	nop    DWORD PTR [rax+0x0]
  4107e0:	movzx  edi,r11w
  4107e4:	lea    rdi,[rdi*8+0x0]
  4107ec:	lea    r12,[rax+rdi*8]
  4107f0:	rex mov edi,DWORD PTR [rax+rdi*8]
  4107f4:	cmp    rdi,rsi
  4107f7:	ja     4108a8 <__swc_fn_3464c816_000140_c6b99a56+0x208>
  4107fd:	mov    r13,QWORD PTR [r10+0x18]
  410801:	add    r13,rdi
  410804:	lea    rdi,[rcx+r13*1]
  410808:	lea    r13,[rip+0x2d21]        # 413530 <__swc_rdata_base_3464c816+0x420>
  41080f:	movabs r14,0x676264676177732e
  410819:	cmp    QWORD PTR [rdi],r14
  41081c:	jne    410825 <__swc_fn_3464c816_000140_c6b99a56+0x185>
  41081e:	rex cmp BYTE PTR [rdi+0x8],0x0
  410823:	je     410852 <__swc_fn_3464c816_000140_c6b99a56+0x1b2>
  410825:	cs nop WORD PTR [rax+rax*1+0x0]
  41082f:	nop
  410830:	movzx  r14d,BYTE PTR [rdi]
  410834:	movzx  r15d,BYTE PTR [r13+0x0]
  410839:	cmp    r14,r15
  41083c:	jne    410848 <__swc_fn_3464c816_000140_c6b99a56+0x1a8>
  41083e:	add    rdi,0x1
  410842:	add    r13,0x1
  410846:	jmp    410830 <__swc_fn_3464c816_000140_c6b99a56+0x190>
  410848:	mov    rdi,r14
  41084b:	sub    rdi,r15
  41084e:	test   edi,edi
  410850:	jne    4108a8 <__swc_fn_3464c816_000140_c6b99a56+0x208>
  410852:	cmp    DWORD PTR [r12+0x4],0x1
  410858:	jne    410880 <__swc_fn_3464c816_000140_c6b99a56+0x1e0>
  41085a:	cmp    QWORD PTR [r12+0x20],0x10
  410860:	setb   al
  410863:	jb     41087c <__swc_fn_3464c816_000140_c6b99a56+0x1dc>
  410865:	cmp    QWORD PTR [r12+0x20],rdx
  41086a:	seta   al
  41086d:	ja     41087c <__swc_fn_3464c816_000140_c6b99a56+0x1dc>
  41086f:	sub    rdx,QWORD PTR [r12+0x20]
  410874:	cmp    QWORD PTR [r12+0x18],rdx
  410879:	seta   al
  41087c:	test   al,al
  41087e:	je     41088d <__swc_fn_3464c816_000140_c6b99a56+0x1ed>
  410880:	xor    eax,eax
  410882:	pop    r15
  410884:	pop    r14
  410886:	pop    r13
  410888:	pop    r12
  41088a:	pop    rdi
  41088b:	pop    rsi
  41088c:	ret
  41088d:	mov    rax,QWORD PTR [r12+0x20]
  410892:	mov    QWORD PTR [r8],rax
  410895:	mov    rax,QWORD PTR [r12+0x18]
  41089a:	add    rax,rcx
  41089d:	pop    r15
  41089f:	pop    r14
  4108a1:	pop    r13
  4108a3:	pop    r12
  4108a5:	pop    rdi
  4108a6:	pop    rsi
  4108a7:	ret
  4108a8:	add    r11,0x1
  4108ac:	cmp    r11,r9
  4108af:	jb     4107e0 <__swc_fn_3464c816_000140_c6b99a56+0x140>
  4108b5:	xor    eax,eax
  4108b7:	pop    r15
  4108b9:	pop    r14
  4108bb:	pop    r13
  4108bd:	pop    r12
  4108bf:	pop    rdi
  4108c0:	pop    rsi
  4108c1:	ret
	...

00000000004108d0 <__swc_fn_3464c816_000143_81c0d993>:
  4108d0:	push   rdi
  4108d1:	push   rsi
  4108d2:	sub    rsp,0xa8
  4108d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4108df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4108e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4108eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4108f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4108f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4108fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410903:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410909:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410912:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41091b:	mov    rdi,rcx
  41091e:	xor    eax,eax
  410920:	call   4071f0 <free@plt>
  410925:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41092b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410931:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410937:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41093d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410943:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410949:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41094f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410955:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41095e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410967:	add    rsp,0xa8
  41096e:	pop    rsi
  41096f:	pop    rdi
  410970:	ret
	...

0000000000410980 <__swc_fn_3464c816_000146_43f4fdca>:
  410980:	push   rbx
  410981:	push   rsi
  410982:	push   rdi
  410983:	push   r12
  410985:	push   r13
  410987:	push   r15
  410989:	sub    rsp,0x4e8
  410990:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  410999:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  4109a2:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  4109ab:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  4109b4:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  4109bd:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  4109c6:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  4109cf:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  4109d8:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  4109e1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  4109ea:	mov    rbx,QWORD PTR [rcx]
  4109ed:	mov    rcx,QWORD PTR [rcx+0x8]
  4109f1:	mov    rsi,rcx
  4109f4:	xor    edi,edi
  4109f6:	vmovsd xmm6,QWORD PTR [rip+0x2b92]        # 413590 <__swc_rdata_base_3464c816+0x480>
  4109fe:	vmovsd xmm7,QWORD PTR [rip+0x2b93]        # 413599 <__swc_rdata_base_3464c816+0x489>
  410a06:	vmovsd xmm8,QWORD PTR [rip+0x2b94]        # 4135a2 <__swc_rdata_base_3464c816+0x492>
  410a0e:	vmovsd xmm9,QWORD PTR [rip+0x2b95]        # 4135ab <__swc_rdata_base_3464c816+0x49b>
  410a16:	vmovsd xmm10,QWORD PTR [rip+0x2b96]        # 4135b4 <__swc_rdata_base_3464c816+0x4a4>
  410a1e:	vmovups xmm11,xmm6
  410a22:	vmovsd QWORD PTR [rsp+0x418],xmm7
  410a2b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410a34:	vmovsd QWORD PTR [rsp+0x428],xmm9
  410a3d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410a46:	vmovsd xmm15,QWORD PTR [rip+0x2b6f]        # 4135bd <__swc_rdata_base_3464c816+0x4ad>
  410a4e:	vmovups xmm14,xmm15
  410a53:	vmovups xmm0,xmm9
  410a58:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410a61:	vmovups xmm13,xmm8
  410a66:	vmovsd QWORD PTR [rsp+0x440],xmm15
  410a6f:	test   rsi,rsi
  410a72:	je     411aa3 <__swc_fn_3464c816_000146_43f4fdca+0x1123>
  410a78:	cs nop WORD PTR [rax+rax*1+0x0]
  410a82:	cs nop WORD PTR [rax+rax*1+0x0]
  410a8c:	nop    DWORD PTR [rax+0x0]
  410a90:	lea    rcx,[rdi+rdi*1]
  410a94:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410a99:	vpshufd xmm3,xmm2,0xee
  410a9e:	vmovq  rcx,xmm3
  410aa3:	test   rcx,rcx
  410aa6:	je     410abc <__swc_fn_3464c816_000146_43f4fdca+0x13c>
  410aa8:	test   DWORD PTR [rcx+0x28],0x400000
  410aaf:	je     410abc <__swc_fn_3464c816_000146_43f4fdca+0x13c>
  410ab1:	mov    rdx,QWORD PTR [rcx+0x30]
  410ab5:	test   rdx,rdx
  410ab8:	cmovne rcx,rdx
  410abc:	test   DWORD PTR [rcx+0x28],0x1000
  410ac3:	je     410ae4 <__swc_fn_3464c816_000146_43f4fdca+0x164>
  410ac5:	mov    rdx,QWORD PTR [rcx+0x40]
  410ac9:	mov    rcx,rdx
  410acc:	vmovq  r8,xmm2
  410ad1:	mov    r8,QWORD PTR [r8]
  410ad4:	mov    QWORD PTR [rsp+0x60],r8
  410ad9:	mov    QWORD PTR [rsp+0x68],rdx
  410ade:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410ae4:	test   BYTE PTR [rcx+0x28],0x1
  410ae8:	jne    410af0 <__swc_fn_3464c816_000146_43f4fdca+0x170>
  410aea:	vmovups xmm12,xmm0
  410aee:	jmp    410b0a <__swc_fn_3464c816_000146_43f4fdca+0x18a>
  410af0:	vmovq  rax,xmm2
  410af5:	mov    rax,QWORD PTR [rax]
  410af8:	lea    rcx,[rax+0x10]
  410afc:	vmovups xmm12,xmm0
  410b00:	call   410100 <__swc_fn_3464c816_000116_035d76a1>
  410b05:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  410b0a:	test   DWORD PTR [rcx+0x28],0x400
  410b11:	je     410b72 <__swc_fn_3464c816_000146_43f4fdca+0x1f2>
  410b13:	vmovq  rax,xmm2
  410b18:	mov    rax,QWORD PTR [rax]
  410b1b:	xor    ecx,ecx
  410b1d:	test   rax,rax
  410b20:	je     410b50 <__swc_fn_3464c816_000146_43f4fdca+0x1d0>
  410b22:	mov    rdx,rax
  410b25:	mov    r8b,BYTE PTR [rdx]
  410b28:	test   r8b,r8b
  410b2b:	je     410b50 <__swc_fn_3464c816_000146_43f4fdca+0x1d0>
  410b2d:	cs nop WORD PTR [rax+rax*1+0x0]
  410b37:	nop    WORD PTR [rax+rax*1+0x0]
  410b40:	add    rdx,0x1
  410b44:	add    rcx,0x1
  410b48:	mov    r8b,BYTE PTR [rdx]
  410b4b:	test   r8b,r8b
  410b4e:	jne    410b40 <__swc_fn_3464c816_000146_43f4fdca+0x1c0>
  410b50:	mov    QWORD PTR [rsp+0x88],rax
  410b58:	mov    QWORD PTR [rsp+0x90],rcx
  410b60:	lea    rcx,[rsp+0x88]
  410b68:	call   410100 <__swc_fn_3464c816_000116_035d76a1>
  410b6d:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  410b72:	cmp    BYTE PTR [rcx+0x2c],0x6
  410b76:	jne    410b8d <__swc_fn_3464c816_000146_43f4fdca+0x20d>
  410b78:	vmovq  rax,xmm2
  410b7d:	mov    rax,QWORD PTR [rax]
  410b80:	mov    rcx,rax
  410b83:	call   409cd0 <__swc_fn_3464c816_000144_72996a5b>
  410b88:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  410b8d:	cmp    BYTE PTR [rcx+0x2c],0x1
  410b91:	jne    411a79 <__swc_fn_3464c816_000146_43f4fdca+0x10f9>
  410b97:	vmovq  rdx,xmm2
  410b9c:	mov    cl,BYTE PTR [rcx+0x40]
  410b9f:	cmp    cl,0x7
  410ba2:	jb     410be5 <__swc_fn_3464c816_000146_43f4fdca+0x265>
  410ba4:	je     410c58 <__swc_fn_3464c816_000146_43f4fdca+0x2d8>
  410baa:	cmp    cl,0x8
  410bad:	je     410c64 <__swc_fn_3464c816_000146_43f4fdca+0x2e4>
  410bb3:	cmp    cl,0x9
  410bb6:	je     410c7d <__swc_fn_3464c816_000146_43f4fdca+0x2fd>
  410bbc:	cmp    cl,0xa
  410bbf:	je     411364 <__swc_fn_3464c816_000146_43f4fdca+0x9e4>
  410bc5:	cmp    cl,0xb
  410bc8:	je     411a4b <__swc_fn_3464c816_000146_43f4fdca+0x10cb>
  410bce:	cmp    cl,0xc
  410bd1:	je     410c71 <__swc_fn_3464c816_000146_43f4fdca+0x2f1>
  410bd7:	cmp    cl,0xd
  410bda:	je     411a41 <__swc_fn_3464c816_000146_43f4fdca+0x10c1>
  410be0:	jmp    411a6b <__swc_fn_3464c816_000146_43f4fdca+0x10eb>
  410be5:	cmp    cl,0x1
  410be8:	je     410c08 <__swc_fn_3464c816_000146_43f4fdca+0x288>
  410bea:	cmp    cl,0x2
  410bed:	je     410c16 <__swc_fn_3464c816_000146_43f4fdca+0x296>
  410bef:	cmp    cl,0x3
  410bf2:	je     410c24 <__swc_fn_3464c816_000146_43f4fdca+0x2a4>
  410bf4:	cmp    cl,0x4
  410bf7:	je     410c31 <__swc_fn_3464c816_000146_43f4fdca+0x2b1>
  410bf9:	cmp    cl,0x5
  410bfc:	je     410c3e <__swc_fn_3464c816_000146_43f4fdca+0x2be>
  410bfe:	cmp    cl,0x6
  410c01:	je     410c4b <__swc_fn_3464c816_000146_43f4fdca+0x2cb>
  410c03:	jmp    411a6b <__swc_fn_3464c816_000146_43f4fdca+0x10eb>
  410c08:	movsx  rcx,BYTE PTR [rdx]
  410c0c:	call   40cf80 <__swc_fn_3464c816_000145_863755b5>
  410c11:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  410c16:	movsx  rcx,WORD PTR [rdx]
  410c1a:	call   40cf80 <__swc_fn_3464c816_000145_863755b5>
  410c1f:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  410c24:	movsxd rcx,DWORD PTR [rdx]
  410c27:	call   40cf80 <__swc_fn_3464c816_000145_863755b5>
  410c2c:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  410c31:	mov    rcx,QWORD PTR [rdx]
  410c34:	call   40cf80 <__swc_fn_3464c816_000145_863755b5>
  410c39:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  410c3e:	movzx  ecx,BYTE PTR [rdx]
  410c41:	call   409cd0 <__swc_fn_3464c816_000144_72996a5b>
  410c46:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  410c4b:	movzx  ecx,WORD PTR [rdx]
  410c4e:	call   409cd0 <__swc_fn_3464c816_000144_72996a5b>
  410c53:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  410c58:	mov    ecx,DWORD PTR [rdx]
  410c5a:	call   409cd0 <__swc_fn_3464c816_000144_72996a5b>
  410c5f:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  410c64:	mov    rcx,QWORD PTR [rdx]
  410c67:	call   409cd0 <__swc_fn_3464c816_000144_72996a5b>
  410c6c:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  410c71:	mov    ecx,DWORD PTR [rdx]
  410c73:	call   409cd0 <__swc_fn_3464c816_000144_72996a5b>
  410c78:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  410c7d:	lea    rcx,[rsp+0xa8]
  410c85:	vxorps xmm0,xmm0,xmm0
  410c89:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  410c92:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  410c9b:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  410ca4:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  410cad:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  410cb6:	vmovups XMMWORD PTR [rsp+0xf8],xmm0
  410cbf:	mov    DWORD PTR [rsp+0x108],0x0
  410cca:	vxorpd xmm0,xmm0,xmm0
  410cce:	vmovss xmm1,DWORD PTR [rdx]
  410cd2:	vcvtss2sd xmm0,xmm0,xmm1
  410cd6:	vmovsd xmm1,xmm1,xmm0
  410cda:	vcomisd xmm0,xmm0
  410cde:	setne  dl
  410ce1:	movzx  edx,dl
  410ce4:	setp   r8b
  410ce8:	movzx  r8d,r8b
  410cec:	or     edx,r8d
  410cef:	test   dl,dl
  410cf1:	je     410cfe <__swc_fn_3464c816_000146_43f4fdca+0x37e>
  410cf3:	mov    DWORD PTR [rcx],0x6e616e
  410cf9:	jmp    4112f8 <__swc_fn_3464c816_000146_43f4fdca+0x978>
  410cfe:	vcomisd xmm1,xmm6
  410d02:	ja     410d0a <__swc_fn_3464c816_000146_43f4fdca+0x38a>
  410d04:	vcomisd xmm7,xmm1
  410d08:	jbe    410d2e <__swc_fn_3464c816_000146_43f4fdca+0x3ae>
  410d0a:	vxorpd xmm0,xmm0,xmm0
  410d0e:	vcomisd xmm0,xmm1
  410d12:	jbe    410d23 <__swc_fn_3464c816_000146_43f4fdca+0x3a3>
  410d14:	mov    DWORD PTR [rcx],0x666e692d
  410d1a:	mov    BYTE PTR [rcx+0x4],0x0
  410d1e:	jmp    4112f8 <__swc_fn_3464c816_000146_43f4fdca+0x978>
  410d23:	mov    DWORD PTR [rcx],0x666e69
  410d29:	jmp    4112f8 <__swc_fn_3464c816_000146_43f4fdca+0x978>
  410d2e:	vcomisd xmm1,xmm8
  410d33:	jae    410d3f <__swc_fn_3464c816_000146_43f4fdca+0x3bf>
  410d35:	vcomisd xmm9,xmm1
  410d39:	jbe    4110be <__swc_fn_3464c816_000146_43f4fdca+0x73e>
  410d3f:	vmovups xmm0,xmm1
  410d43:	vxorpd xmm2,xmm2,xmm2
  410d47:	vcomisd xmm2,xmm1
  410d4b:	jbe    410d5b <__swc_fn_3464c816_000146_43f4fdca+0x3db>
  410d4d:	vmovsd xmm1,xmm1,xmm0
  410d51:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x27f7]        # 413550 <__swc_rdata_base_3464c816+0x440>
  410d59:	jmp    410d5f <__swc_fn_3464c816_000146_43f4fdca+0x3df>
  410d5b:	vmovsd xmm1,xmm1,xmm0
  410d5f:	xor    r8d,r8d
  410d62:	vcomisd xmm1,xmm15
  410d67:	jb     410d90 <__swc_fn_3464c816_000146_43f4fdca+0x410>
  410d69:	cs nop WORD PTR [rax+rax*1+0x0]
  410d73:	cs nop WORD PTR [rax+rax*1+0x0]
  410d7d:	nop    DWORD PTR [rax]
  410d80:	vdivsd xmm1,xmm1,xmm15
  410d85:	add    r8,0x1
  410d89:	vcomisd xmm1,xmm15
  410d8e:	jae    410d80 <__swc_fn_3464c816_000146_43f4fdca+0x400>
  410d90:	mov    r9,rcx
  410d93:	vxorpd xmm2,xmm2,xmm2
  410d97:	vcomisd xmm2,xmm0
  410d9b:	jbe    410da4 <__swc_fn_3464c816_000146_43f4fdca+0x424>
  410d9d:	mov    BYTE PTR [rcx],0x2d
  410da0:	lea    r9,[rcx+0x1]
  410da4:	vcvttsd2si rdx,xmm1
  410da9:	mov    r10b,dl
  410dac:	add    r10b,0x30
  410db0:	mov    BYTE PTR [r9],r10b
  410db3:	vxorpd xmm0,xmm0,xmm0
  410db7:	movzx  edx,dl
  410dba:	vcvtsi2sd xmm0,xmm0,rdx
  410dbf:	vsubsd xmm0,xmm1,xmm0
  410dc3:	vmulsd xmm1,xmm0,xmm15
  410dc8:	mov    BYTE PTR [r9+0x1],0x2e
  410dcd:	vcvttsd2si rdx,xmm1
  410dd2:	mov    r10b,dl
  410dd5:	add    r10b,0x30
  410dd9:	mov    BYTE PTR [r9+0x2],r10b
  410ddd:	vxorpd xmm0,xmm0,xmm0
  410de1:	movzx  edx,dl
  410de4:	vcvtsi2sd xmm0,xmm0,rdx
  410de9:	vsubsd xmm0,xmm1,xmm0
  410ded:	vmulsd xmm1,xmm0,xmm15
  410df2:	vcvttsd2si rdx,xmm1
  410df7:	mov    r10b,dl
  410dfa:	add    r10b,0x30
  410dfe:	mov    BYTE PTR [r9+0x3],r10b
  410e02:	vxorpd xmm0,xmm0,xmm0
  410e06:	movzx  edx,dl
  410e09:	vcvtsi2sd xmm0,xmm0,rdx
  410e0e:	vsubsd xmm0,xmm1,xmm0
  410e12:	vmulsd xmm1,xmm0,xmm15
  410e17:	vcvttsd2si rdx,xmm1
  410e1c:	mov    r10b,dl
  410e1f:	add    r10b,0x30
  410e23:	mov    BYTE PTR [r9+0x4],r10b
  410e27:	vxorpd xmm0,xmm0,xmm0
  410e2b:	movzx  edx,dl
  410e2e:	vcvtsi2sd xmm0,xmm0,rdx
  410e33:	vsubsd xmm0,xmm1,xmm0
  410e37:	vmulsd xmm1,xmm0,xmm15
  410e3c:	vcvttsd2si rdx,xmm1
  410e41:	mov    r10b,dl
  410e44:	add    r10b,0x30
  410e48:	mov    BYTE PTR [r9+0x5],r10b
  410e4c:	vxorpd xmm0,xmm0,xmm0
  410e50:	movzx  edx,dl
  410e53:	vcvtsi2sd xmm0,xmm0,rdx
  410e58:	vsubsd xmm0,xmm1,xmm0
  410e5c:	vmulsd xmm1,xmm0,xmm15
  410e61:	vcvttsd2si rdx,xmm1
  410e66:	mov    r10b,dl
  410e69:	add    r10b,0x30
  410e6d:	mov    BYTE PTR [r9+0x6],r10b
  410e71:	vxorpd xmm0,xmm0,xmm0
  410e75:	movzx  edx,dl
  410e78:	vcvtsi2sd xmm0,xmm0,rdx
  410e7d:	vsubsd xmm0,xmm1,xmm0
  410e81:	vmulsd xmm1,xmm0,xmm15
  410e86:	vcvttsd2si rdx,xmm1
  410e8b:	mov    r10b,dl
  410e8e:	add    r10b,0x30
  410e92:	mov    BYTE PTR [r9+0x7],r10b
  410e96:	vxorpd xmm0,xmm0,xmm0
  410e9a:	movzx  edx,dl
  410e9d:	vcvtsi2sd xmm0,xmm0,rdx
  410ea2:	vsubsd xmm0,xmm1,xmm0
  410ea6:	vmulsd xmm1,xmm0,xmm15
  410eab:	vcvttsd2si rdx,xmm1
  410eb0:	mov    r10b,dl
  410eb3:	add    r10b,0x30
  410eb7:	mov    BYTE PTR [r9+0x8],r10b
  410ebb:	vxorpd xmm0,xmm0,xmm0
  410ebf:	movzx  edx,dl
  410ec2:	vcvtsi2sd xmm0,xmm0,rdx
  410ec7:	vsubsd xmm0,xmm1,xmm0
  410ecb:	vmulsd xmm1,xmm0,xmm15
  410ed0:	vcvttsd2si rdx,xmm1
  410ed5:	mov    r10b,dl
  410ed8:	add    r10b,0x30
  410edc:	mov    BYTE PTR [r9+0x9],r10b
  410ee0:	vxorpd xmm0,xmm0,xmm0
  410ee4:	movzx  edx,dl
  410ee7:	vcvtsi2sd xmm0,xmm0,rdx
  410eec:	vsubsd xmm0,xmm1,xmm0
  410ef0:	vmulsd xmm1,xmm0,xmm15
  410ef5:	vcvttsd2si rdx,xmm1
  410efa:	mov    r10b,dl
  410efd:	add    r10b,0x30
  410f01:	mov    BYTE PTR [r9+0xa],r10b
  410f05:	vxorpd xmm0,xmm0,xmm0
  410f09:	movzx  edx,dl
  410f0c:	vcvtsi2sd xmm0,xmm0,rdx
  410f11:	vsubsd xmm0,xmm1,xmm0
  410f15:	vmulsd xmm1,xmm0,xmm15
  410f1a:	vcvttsd2si rdx,xmm1
  410f1f:	mov    r10b,dl
  410f22:	add    r10b,0x30
  410f26:	mov    BYTE PTR [r9+0xb],r10b
  410f2a:	lea    r10,[r9+0x4]
  410f2e:	vxorpd xmm0,xmm0,xmm0
  410f32:	movzx  edx,dl
  410f35:	vcvtsi2sd xmm0,xmm0,rdx
  410f3a:	vsubsd xmm0,xmm1,xmm0
  410f3e:	vmulsd xmm1,xmm0,xmm15
  410f43:	vcvttsd2si rdx,xmm1
  410f48:	mov    r11b,dl
  410f4b:	add    r11b,0x30
  410f4f:	mov    BYTE PTR [r9+0xc],r11b
  410f53:	vxorpd xmm0,xmm0,xmm0
  410f57:	movzx  edx,dl
  410f5a:	vcvtsi2sd xmm0,xmm0,rdx
  410f5f:	vsubsd xmm0,xmm1,xmm0
  410f63:	vmulsd xmm1,xmm0,xmm15
  410f68:	vcvttsd2si rdx,xmm1
  410f6d:	mov    r11b,dl
  410f70:	add    r11b,0x30
  410f74:	mov    BYTE PTR [r9+0xd],r11b
  410f78:	lea    r10,[r10+0x2]
  410f7c:	vxorpd xmm0,xmm0,xmm0
  410f80:	movzx  edx,dl
  410f83:	vcvtsi2sd xmm0,xmm0,rdx
  410f88:	vsubsd xmm0,xmm1,xmm0
  410f8c:	vmulsd xmm1,xmm0,xmm15
  410f91:	vcvttsd2si rdx,xmm1
  410f96:	mov    r11b,dl
  410f99:	add    r11b,0x30
  410f9d:	mov    BYTE PTR [r9+0xe],r11b
  410fa1:	vxorpd xmm0,xmm0,xmm0
  410fa5:	movzx  edx,dl
  410fa8:	vcvtsi2sd xmm0,xmm0,rdx
  410fad:	vsubsd xmm0,xmm1,xmm0
  410fb1:	vmulsd xmm1,xmm0,xmm15
  410fb6:	vcvttsd2si rdx,xmm1
  410fbb:	mov    r11b,dl
  410fbe:	add    r11b,0x30
  410fc2:	mov    BYTE PTR [r9+0xf],r11b
  410fc6:	lea    r10,[r10+0x2]
  410fca:	lea    r10,[r10+0x2]
  410fce:	lea    r10,[r10+0x2]
  410fd2:	lea    r10,[r10+0x2]
  410fd6:	lea    r10,[r10+0x2]
  410fda:	vxorpd xmm0,xmm0,xmm0
  410fde:	movzx  edx,dl
  410fe1:	vcvtsi2sd xmm0,xmm0,rdx
  410fe6:	vsubsd xmm0,xmm1,xmm0
  410fea:	vmulsd xmm1,xmm0,xmm15
  410fef:	vcvttsd2si rdx,xmm1
  410ff4:	mov    r11b,dl
  410ff7:	add    r11b,0x30
  410ffb:	mov    BYTE PTR [r9+0x10],r11b
  410fff:	vxorpd xmm0,xmm0,xmm0
  411003:	movzx  edx,dl
  411006:	vcvtsi2sd xmm0,xmm0,rdx
  41100b:	vsubsd xmm0,xmm1,xmm0
  41100f:	vmulsd xmm1,xmm0,xmm15
  411014:	vcvttsd2si rdx,xmm1
  411019:	add    dl,0x30
  41101c:	mov    BYTE PTR [r9+0x11],dl
  411020:	mov    BYTE PTR [r10+0x2],0x65
  411025:	lea    r9,[r10+0x3]
  411029:	test   r8,r8
  41102c:	jl     411035 <__swc_fn_3464c816_000146_43f4fdca+0x6b5>
  41102e:	mov    BYTE PTR [r9],0x2b
  411032:	inc    r9
  411035:	mov    r10,r9
  411038:	mov    rdx,r8
  41103b:	nop    DWORD PTR [rax+rax*1+0x0]
  411040:	mov    r11,rdx
  411043:	movabs rdx,0x6666666666666667
  41104d:	mov    rax,r11
  411050:	imul   rdx
  411053:	sar    rdx,0x2
  411057:	mov    r12,rdx
  41105a:	shr    rdx,0x3f
  41105e:	add    r12,rdx
  411061:	mov    rdx,r12
  411064:	imul   r13,r12,0xa
  411068:	sub    r11,r13
  41106b:	mov    r13,QWORD PTR [rip+0x24ce]        # 413540 <__swc_rdata_base_3464c816+0x430>
  411072:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411077:	mov    BYTE PTR [r10],r11b
  41107a:	lea    r11,[r10+0x1]
  41107e:	mov    r10,r11
  411081:	test   r12,r12
  411084:	jne    411040 <__swc_fn_3464c816_000146_43f4fdca+0x6c0>
  411086:	test   r8,r8
  411089:	jge    411093 <__swc_fn_3464c816_000146_43f4fdca+0x713>
  41108b:	mov    BYTE PTR [r11],0x2d
  41108f:	lea    r10,[r11+0x1]
  411093:	mov    BYTE PTR [r10],0x0
  411097:	sub    r10,0x1
  41109b:	nop    DWORD PTR [rax+rax*1+0x0]
  4110a0:	cmp    r9,r10
  4110a3:	jae    4112f8 <__swc_fn_3464c816_000146_43f4fdca+0x978>
  4110a9:	mov    al,BYTE PTR [r10]
  4110ac:	mov    dl,BYTE PTR [r9]
  4110af:	mov    BYTE PTR [r10],dl
  4110b2:	sub    r10,0x1
  4110b6:	mov    BYTE PTR [r9],al
  4110b9:	inc    r9
  4110bc:	jmp    4110a0 <__swc_fn_3464c816_000146_43f4fdca+0x720>
  4110be:	vcvttsd2si rdx,xmm1
  4110c3:	mov    r8,rdx
  4110c6:	vxorpd xmm0,xmm0,xmm0
  4110ca:	vcvtsi2sd xmm0,xmm0,rdx
  4110cf:	vsubsd xmm0,xmm1,xmm0
  4110d3:	mov    r9d,0x8
  4110d9:	vxorpd xmm2,xmm2,xmm2
  4110dd:	vcomisd xmm2,xmm0
  4110e1:	jbe    4110eb <__swc_fn_3464c816_000146_43f4fdca+0x76b>
  4110e3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2465]        # 413550 <__swc_rdata_base_3464c816+0x440>
  4110eb:	test   r9d,r9d
  4110ee:	je     4110fa <__swc_fn_3464c816_000146_43f4fdca+0x77a>
  4110f0:	vmulsd xmm0,xmm0,xmm14
  4110f5:	dec    r9d
  4110f8:	jne    4110f0 <__swc_fn_3464c816_000146_43f4fdca+0x770>
  4110fa:	vcvttsd2si r9,xmm0
  4110ff:	mov    r10,r9
  411102:	vxorpd xmm2,xmm2,xmm2
  411106:	vcvtsi2sd xmm2,xmm2,r9
  41110b:	vsubsd xmm0,xmm0,xmm2
  41110f:	vcomisd xmm0,xmm10
  411114:	lea    r9,[r9+0x1]
  411118:	cmova  r10,r9
  41111c:	cmp    r10,0x5f5e100
  411123:	jne    41113c <__swc_fn_3464c816_000146_43f4fdca+0x7bc>
  411125:	lea    r8,[rdx-0x1]
  411129:	vxorpd xmm0,xmm0,xmm0
  41112d:	vcomisd xmm0,xmm1
  411131:	lea    rdx,[rdx+0x1]
  411135:	cmovbe r8,rdx
  411139:	xor    r10d,r10d
  41113c:	mov    r9,rcx
  41113f:	test   r8,r8
  411142:	jne    411162 <__swc_fn_3464c816_000146_43f4fdca+0x7e2>
  411144:	vxorpd xmm0,xmm0,xmm0
  411148:	vcomisd xmm0,xmm1
  41114c:	jbe    411155 <__swc_fn_3464c816_000146_43f4fdca+0x7d5>
  41114e:	mov    BYTE PTR [rcx],0x2d
  411151:	lea    r9,[rcx+0x1]
  411155:	mov    BYTE PTR [r9],0x30
  411159:	add    r9,0x1
  41115d:	jmp    4111fb <__swc_fn_3464c816_000146_43f4fdca+0x87b>
  411162:	mov    r9,rcx
  411165:	mov    rdx,r8
  411168:	nop    DWORD PTR [rax+rax*1+0x0]
  411170:	mov    r11,rdx
  411173:	movabs rdx,0x6666666666666667
  41117d:	mov    r15,rax
  411180:	mov    rax,r11
  411183:	imul   rdx
  411186:	mov    r12,rdx
  411189:	mov    rax,r15
  41118c:	sar    r12,0x2
  411190:	mov    rdx,r12
  411193:	shr    rdx,0x3f
  411197:	add    r12,rdx
  41119a:	mov    rdx,r12
  41119d:	imul   r13,r12,0xa
  4111a1:	sub    r11,r13
  4111a4:	mov    r13,QWORD PTR [rip+0x2395]        # 413540 <__swc_rdata_base_3464c816+0x430>
  4111ab:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4111b0:	mov    BYTE PTR [r9],r11b
  4111b3:	lea    r11,[r9+0x1]
  4111b7:	mov    r9,r11
  4111ba:	test   r12,r12
  4111bd:	jne    411170 <__swc_fn_3464c816_000146_43f4fdca+0x7f0>
  4111bf:	test   r8,r8
  4111c2:	jge    4111cc <__swc_fn_3464c816_000146_43f4fdca+0x84c>
  4111c4:	mov    BYTE PTR [r11],0x2d
  4111c8:	lea    r9,[r11+0x1]
  4111cc:	mov    rdx,r9
  4111cf:	mov    BYTE PTR [r9],0x0
  4111d3:	sub    r9,0x1
  4111d7:	mov    r8,rcx
  4111da:	cmp    r8,r9
  4111dd:	jae    4111f8 <__swc_fn_3464c816_000146_43f4fdca+0x878>
  4111df:	nop
  4111e0:	mov    r11b,BYTE PTR [r9]
  4111e3:	mov    r12b,BYTE PTR [r8]
  4111e6:	mov    BYTE PTR [r9],r12b
  4111e9:	sub    r9,0x1
  4111ed:	mov    BYTE PTR [r8],r11b
  4111f0:	inc    r8
  4111f3:	cmp    r8,r9
  4111f6:	jb     4111e0 <__swc_fn_3464c816_000146_43f4fdca+0x860>
  4111f8:	mov    r9,rdx
  4111fb:	mov    BYTE PTR [r9],0x2e
  4111ff:	add    r9,0x1
  411203:	xor    r8d,r8d
  411206:	test   r10,r10
  411209:	je     41124f <__swc_fn_3464c816_000146_43f4fdca+0x8cf>
  41120b:	mov    r11d,0x989680
  411211:	cmp    r10,r11
  411214:	jge    41124f <__swc_fn_3464c816_000146_43f4fdca+0x8cf>
  411216:	cs nop WORD PTR [rax+rax*1+0x0]
  411220:	inc    r8d
  411223:	movabs rdx,0x6666666666666667
  41122d:	mov    r15,rax
  411230:	mov    rax,r11
  411233:	imul   rdx
  411236:	mov    r11,rdx
  411239:	mov    rax,r15
  41123c:	sar    r11,0x2
  411240:	mov    rdx,r11
  411243:	shr    rdx,0x3f
  411247:	add    r11,rdx
  41124a:	cmp    r10,r11
  41124d:	jl     411220 <__swc_fn_3464c816_000146_43f4fdca+0x8a0>
  41124f:	test   r8d,r8d
  411252:	je     41126d <__swc_fn_3464c816_000146_43f4fdca+0x8ed>
  411254:	cs nop WORD PTR [rax+rax*1+0x0]
  41125e:	xchg   ax,ax
  411260:	mov    BYTE PTR [r9],0x30
  411264:	add    r9,0x1
  411268:	dec    r8d
  41126b:	jne    411260 <__swc_fn_3464c816_000146_43f4fdca+0x8e0>
  41126d:	mov    r8,r9
  411270:	mov    rdx,r10
  411273:	cs nop WORD PTR [rax+rax*1+0x0]
  41127d:	nop    DWORD PTR [rax]
  411280:	mov    r11,rdx
  411283:	movabs rdx,0x6666666666666667
  41128d:	mov    rax,r11
  411290:	imul   rdx
  411293:	sar    rdx,0x2
  411297:	mov    r12,rdx
  41129a:	shr    rdx,0x3f
  41129e:	add    r12,rdx
  4112a1:	mov    rdx,r12
  4112a4:	imul   r13,r12,0xa
  4112a8:	sub    r11,r13
  4112ab:	mov    r13,QWORD PTR [rip+0x228e]        # 413540 <__swc_rdata_base_3464c816+0x430>
  4112b2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4112b7:	mov    BYTE PTR [r8],r11b
  4112ba:	lea    r11,[r8+0x1]
  4112be:	mov    r8,r11
  4112c1:	test   r12,r12
  4112c4:	jne    411280 <__swc_fn_3464c816_000146_43f4fdca+0x900>
  4112c6:	test   r10,r10
  4112c9:	jge    4112d3 <__swc_fn_3464c816_000146_43f4fdca+0x953>
  4112cb:	mov    BYTE PTR [r11],0x2d
  4112cf:	lea    r8,[r11+0x1]
  4112d3:	mov    BYTE PTR [r8],0x0
  4112d7:	sub    r8,0x1
  4112db:	cmp    r9,r8
  4112de:	jae    4112f8 <__swc_fn_3464c816_000146_43f4fdca+0x978>
  4112e0:	mov    al,BYTE PTR [r8]
  4112e3:	mov    dl,BYTE PTR [r9]
  4112e6:	mov    BYTE PTR [r8],dl
  4112e9:	sub    r8,0x1
  4112ed:	mov    BYTE PTR [r9],al
  4112f0:	inc    r9
  4112f3:	cmp    r9,r8
  4112f6:	jb     4112e0 <__swc_fn_3464c816_000146_43f4fdca+0x960>
  4112f8:	xor    eax,eax
  4112fa:	test   rcx,rcx
  4112fd:	je     411330 <__swc_fn_3464c816_000146_43f4fdca+0x9b0>
  4112ff:	mov    rdx,rcx
  411302:	mov    r8b,BYTE PTR [rdx]
  411305:	test   r8b,r8b
  411308:	je     411330 <__swc_fn_3464c816_000146_43f4fdca+0x9b0>
  41130a:	cs nop WORD PTR [rax+rax*1+0x0]
  411314:	cs nop WORD PTR [rax+rax*1+0x0]
  41131e:	xchg   ax,ax
  411320:	add    rdx,0x1
  411324:	add    rax,0x1
  411328:	mov    r8b,BYTE PTR [rdx]
  41132b:	test   r8b,r8b
  41132e:	jne    411320 <__swc_fn_3464c816_000146_43f4fdca+0x9a0>
  411330:	mov    QWORD PTR [rsp+0x240],rcx
  411338:	mov    QWORD PTR [rsp+0x248],rax
  411340:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  411349:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  411352:	lea    rcx,[rsp+0x250]
  41135a:	call   410100 <__swc_fn_3464c816_000116_035d76a1>
  41135f:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  411364:	lea    rcx,[rsp+0x260]
  41136c:	vxorps xmm0,xmm0,xmm0
  411370:	vmovups XMMWORD PTR [rsp+0x260],xmm0
  411379:	vmovups XMMWORD PTR [rsp+0x270],xmm0
  411382:	vmovups XMMWORD PTR [rsp+0x280],xmm0
  41138b:	vmovups XMMWORD PTR [rsp+0x290],xmm0
  411394:	vmovups XMMWORD PTR [rsp+0x2a0],xmm0
  41139d:	vmovups XMMWORD PTR [rsp+0x2b0],xmm0
  4113a6:	mov    DWORD PTR [rsp+0x2c0],0x0
  4113b1:	vmovsd xmm0,QWORD PTR [rdx]
  4113b5:	vcomisd xmm0,xmm0
  4113b9:	setne  dl
  4113bc:	movzx  edx,dl
  4113bf:	setp   r8b
  4113c3:	movzx  r8d,r8b
  4113c7:	or     edx,r8d
  4113ca:	test   dl,dl
  4113cc:	je     4113d9 <__swc_fn_3464c816_000146_43f4fdca+0xa59>
  4113ce:	mov    DWORD PTR [rcx],0x6e616e
  4113d4:	jmp    4119e8 <__swc_fn_3464c816_000146_43f4fdca+0x1068>
  4113d9:	vcomisd xmm0,xmm11
  4113de:	ja     4113ef <__swc_fn_3464c816_000146_43f4fdca+0xa6f>
  4113e0:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  4113e9:	vcomisd xmm6,xmm0
  4113ed:	jbe    411413 <__swc_fn_3464c816_000146_43f4fdca+0xa93>
  4113ef:	vxorpd xmm1,xmm1,xmm1
  4113f3:	vcomisd xmm1,xmm0
  4113f7:	jbe    411408 <__swc_fn_3464c816_000146_43f4fdca+0xa88>
  4113f9:	mov    DWORD PTR [rcx],0x666e692d
  4113ff:	mov    BYTE PTR [rcx+0x4],0x0
  411403:	jmp    4119e8 <__swc_fn_3464c816_000146_43f4fdca+0x1068>
  411408:	mov    DWORD PTR [rcx],0x666e69
  41140e:	jmp    4119e8 <__swc_fn_3464c816_000146_43f4fdca+0x1068>
  411413:	vcomisd xmm0,xmm13
  411418:	jae    411424 <__swc_fn_3464c816_000146_43f4fdca+0xaa4>
  41141a:	vcomisd xmm12,xmm0
  41141e:	jbe    41178e <__swc_fn_3464c816_000146_43f4fdca+0xe0e>
  411424:	vmovups xmm1,xmm0
  411428:	vxorpd xmm2,xmm2,xmm2
  41142c:	vcomisd xmm2,xmm0
  411430:	jbe    411440 <__swc_fn_3464c816_000146_43f4fdca+0xac0>
  411432:	vmovsd xmm0,xmm0,xmm1
  411436:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2112]        # 413550 <__swc_rdata_base_3464c816+0x440>
  41143e:	jmp    411444 <__swc_fn_3464c816_000146_43f4fdca+0xac4>
  411440:	vmovsd xmm0,xmm0,xmm1
  411444:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  41144d:	xor    r8d,r8d
  411450:	vcomisd xmm0,xmm6
  411454:	jb     41146e <__swc_fn_3464c816_000146_43f4fdca+0xaee>
  411456:	cs nop WORD PTR [rax+rax*1+0x0]
  411460:	vdivsd xmm0,xmm0,xmm6
  411464:	add    r8,0x1
  411468:	vcomisd xmm0,xmm6
  41146c:	jae    411460 <__swc_fn_3464c816_000146_43f4fdca+0xae0>
  41146e:	mov    r9,rcx
  411471:	vxorpd xmm2,xmm2,xmm2
  411475:	vcomisd xmm2,xmm1
  411479:	jbe    411482 <__swc_fn_3464c816_000146_43f4fdca+0xb02>
  41147b:	mov    BYTE PTR [rcx],0x2d
  41147e:	lea    r9,[rcx+0x1]
  411482:	vcvttsd2si rdx,xmm0
  411487:	mov    r10b,dl
  41148a:	add    r10b,0x30
  41148e:	mov    BYTE PTR [r9],r10b
  411491:	vxorpd xmm1,xmm1,xmm1
  411495:	movzx  edx,dl
  411498:	vcvtsi2sd xmm1,xmm1,rdx
  41149d:	vsubsd xmm0,xmm0,xmm1
  4114a1:	vmulsd xmm0,xmm0,xmm6
  4114a5:	mov    BYTE PTR [r9+0x1],0x2e
  4114aa:	vcvttsd2si rdx,xmm0
  4114af:	mov    r10b,dl
  4114b2:	add    r10b,0x30
  4114b6:	mov    BYTE PTR [r9+0x2],r10b
  4114ba:	vxorpd xmm1,xmm1,xmm1
  4114be:	movzx  edx,dl
  4114c1:	vcvtsi2sd xmm1,xmm1,rdx
  4114c6:	vsubsd xmm0,xmm0,xmm1
  4114ca:	vmulsd xmm0,xmm0,xmm6
  4114ce:	vcvttsd2si rdx,xmm0
  4114d3:	mov    r10b,dl
  4114d6:	add    r10b,0x30
  4114da:	mov    BYTE PTR [r9+0x3],r10b
  4114de:	vxorpd xmm1,xmm1,xmm1
  4114e2:	movzx  edx,dl
  4114e5:	vcvtsi2sd xmm1,xmm1,rdx
  4114ea:	vsubsd xmm0,xmm0,xmm1
  4114ee:	vmulsd xmm0,xmm0,xmm6
  4114f2:	vcvttsd2si rdx,xmm0
  4114f7:	mov    r10b,dl
  4114fa:	add    r10b,0x30
  4114fe:	mov    BYTE PTR [r9+0x4],r10b
  411502:	vxorpd xmm1,xmm1,xmm1
  411506:	movzx  edx,dl
  411509:	vcvtsi2sd xmm1,xmm1,rdx
  41150e:	vsubsd xmm0,xmm0,xmm1
  411512:	vmulsd xmm0,xmm0,xmm6
  411516:	vcvttsd2si rdx,xmm0
  41151b:	mov    r10b,dl
  41151e:	add    r10b,0x30
  411522:	mov    BYTE PTR [r9+0x5],r10b
  411526:	vxorpd xmm1,xmm1,xmm1
  41152a:	movzx  edx,dl
  41152d:	vcvtsi2sd xmm1,xmm1,rdx
  411532:	vsubsd xmm0,xmm0,xmm1
  411536:	vmulsd xmm0,xmm0,xmm6
  41153a:	vcvttsd2si rdx,xmm0
  41153f:	mov    r10b,dl
  411542:	add    r10b,0x30
  411546:	mov    BYTE PTR [r9+0x6],r10b
  41154a:	vxorpd xmm1,xmm1,xmm1
  41154e:	movzx  edx,dl
  411551:	vcvtsi2sd xmm1,xmm1,rdx
  411556:	vsubsd xmm0,xmm0,xmm1
  41155a:	vmulsd xmm0,xmm0,xmm6
  41155e:	vcvttsd2si rdx,xmm0
  411563:	mov    r10b,dl
  411566:	add    r10b,0x30
  41156a:	mov    BYTE PTR [r9+0x7],r10b
  41156e:	vxorpd xmm1,xmm1,xmm1
  411572:	movzx  edx,dl
  411575:	vcvtsi2sd xmm1,xmm1,rdx
  41157a:	vsubsd xmm0,xmm0,xmm1
  41157e:	vmulsd xmm0,xmm0,xmm6
  411582:	vcvttsd2si rdx,xmm0
  411587:	mov    r10b,dl
  41158a:	add    r10b,0x30
  41158e:	mov    BYTE PTR [r9+0x8],r10b
  411592:	vxorpd xmm1,xmm1,xmm1
  411596:	movzx  edx,dl
  411599:	vcvtsi2sd xmm1,xmm1,rdx
  41159e:	vsubsd xmm0,xmm0,xmm1
  4115a2:	vmulsd xmm0,xmm0,xmm6
  4115a6:	vcvttsd2si rdx,xmm0
  4115ab:	mov    r10b,dl
  4115ae:	add    r10b,0x30
  4115b2:	mov    BYTE PTR [r9+0x9],r10b
  4115b6:	vxorpd xmm1,xmm1,xmm1
  4115ba:	movzx  edx,dl
  4115bd:	vcvtsi2sd xmm1,xmm1,rdx
  4115c2:	vsubsd xmm0,xmm0,xmm1
  4115c6:	vmulsd xmm0,xmm0,xmm6
  4115ca:	vcvttsd2si rdx,xmm0
  4115cf:	mov    r10b,dl
  4115d2:	add    r10b,0x30
  4115d6:	mov    BYTE PTR [r9+0xa],r10b
  4115da:	vxorpd xmm1,xmm1,xmm1
  4115de:	movzx  edx,dl
  4115e1:	vcvtsi2sd xmm1,xmm1,rdx
  4115e6:	vsubsd xmm0,xmm0,xmm1
  4115ea:	vmulsd xmm0,xmm0,xmm6
  4115ee:	vcvttsd2si rdx,xmm0
  4115f3:	mov    r10b,dl
  4115f6:	add    r10b,0x30
  4115fa:	mov    BYTE PTR [r9+0xb],r10b
  4115fe:	lea    r10,[r9+0x4]
  411602:	vxorpd xmm1,xmm1,xmm1
  411606:	movzx  edx,dl
  411609:	vcvtsi2sd xmm1,xmm1,rdx
  41160e:	vsubsd xmm0,xmm0,xmm1
  411612:	vmulsd xmm0,xmm0,xmm6
  411616:	vcvttsd2si rdx,xmm0
  41161b:	mov    r11b,dl
  41161e:	add    r11b,0x30
  411622:	mov    BYTE PTR [r9+0xc],r11b
  411626:	vxorpd xmm1,xmm1,xmm1
  41162a:	movzx  edx,dl
  41162d:	vcvtsi2sd xmm1,xmm1,rdx
  411632:	vsubsd xmm0,xmm0,xmm1
  411636:	vmulsd xmm0,xmm0,xmm6
  41163a:	vcvttsd2si rdx,xmm0
  41163f:	mov    r11b,dl
  411642:	add    r11b,0x30
  411646:	mov    BYTE PTR [r9+0xd],r11b
  41164a:	lea    r10,[r10+0x2]
  41164e:	vxorpd xmm1,xmm1,xmm1
  411652:	movzx  edx,dl
  411655:	vcvtsi2sd xmm1,xmm1,rdx
  41165a:	vsubsd xmm0,xmm0,xmm1
  41165e:	vmulsd xmm0,xmm0,xmm6
  411662:	vcvttsd2si rdx,xmm0
  411667:	mov    r11b,dl
  41166a:	add    r11b,0x30
  41166e:	mov    BYTE PTR [r9+0xe],r11b
  411672:	vxorpd xmm1,xmm1,xmm1
  411676:	movzx  edx,dl
  411679:	vcvtsi2sd xmm1,xmm1,rdx
  41167e:	vsubsd xmm0,xmm0,xmm1
  411682:	vmulsd xmm0,xmm0,xmm6
  411686:	vcvttsd2si rdx,xmm0
  41168b:	mov    r11b,dl
  41168e:	add    r11b,0x30
  411692:	mov    BYTE PTR [r9+0xf],r11b
  411696:	lea    r10,[r10+0x2]
  41169a:	lea    r10,[r10+0x2]
  41169e:	lea    r10,[r10+0x2]
  4116a2:	lea    r10,[r10+0x2]
  4116a6:	lea    r10,[r10+0x2]
  4116aa:	vxorpd xmm1,xmm1,xmm1
  4116ae:	movzx  edx,dl
  4116b1:	vcvtsi2sd xmm1,xmm1,rdx
  4116b6:	vsubsd xmm0,xmm0,xmm1
  4116ba:	vmulsd xmm0,xmm0,xmm6
  4116be:	vcvttsd2si rdx,xmm0
  4116c3:	mov    r11b,dl
  4116c6:	add    r11b,0x30
  4116ca:	mov    BYTE PTR [r9+0x10],r11b
  4116ce:	vxorpd xmm1,xmm1,xmm1
  4116d2:	movzx  edx,dl
  4116d5:	vcvtsi2sd xmm1,xmm1,rdx
  4116da:	vsubsd xmm0,xmm0,xmm1
  4116de:	vmulsd xmm0,xmm0,xmm6
  4116e2:	vcvttsd2si rdx,xmm0
  4116e7:	add    dl,0x30
  4116ea:	mov    BYTE PTR [r9+0x11],dl
  4116ee:	mov    BYTE PTR [r10+0x2],0x65
  4116f3:	lea    r9,[r10+0x3]
  4116f7:	test   r8,r8
  4116fa:	jl     411703 <__swc_fn_3464c816_000146_43f4fdca+0xd83>
  4116fc:	mov    BYTE PTR [r9],0x2b
  411700:	inc    r9
  411703:	mov    r10,r9
  411706:	mov    rdx,r8
  411709:	nop    DWORD PTR [rax+0x0]
  411710:	mov    r11,rdx
  411713:	movabs rdx,0x6666666666666667
  41171d:	mov    rax,r11
  411720:	imul   rdx
  411723:	sar    rdx,0x2
  411727:	mov    r12,rdx
  41172a:	shr    rdx,0x3f
  41172e:	add    r12,rdx
  411731:	mov    rdx,r12
  411734:	imul   r13,r12,0xa
  411738:	sub    r11,r13
  41173b:	mov    r13,QWORD PTR [rip+0x1dfe]        # 413540 <__swc_rdata_base_3464c816+0x430>
  411742:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411747:	mov    BYTE PTR [r10],r11b
  41174a:	lea    r11,[r10+0x1]
  41174e:	mov    r10,r11
  411751:	test   r12,r12
  411754:	jne    411710 <__swc_fn_3464c816_000146_43f4fdca+0xd90>
  411756:	test   r8,r8
  411759:	jge    411763 <__swc_fn_3464c816_000146_43f4fdca+0xde3>
  41175b:	mov    BYTE PTR [r11],0x2d
  41175f:	lea    r10,[r11+0x1]
  411763:	mov    BYTE PTR [r10],0x0
  411767:	sub    r10,0x1
  41176b:	nop    DWORD PTR [rax+rax*1+0x0]
  411770:	cmp    r9,r10
  411773:	jae    4119e8 <__swc_fn_3464c816_000146_43f4fdca+0x1068>
  411779:	mov    al,BYTE PTR [r10]
  41177c:	mov    dl,BYTE PTR [r9]
  41177f:	mov    BYTE PTR [r10],dl
  411782:	sub    r10,0x1
  411786:	mov    BYTE PTR [r9],al
  411789:	inc    r9
  41178c:	jmp    411770 <__swc_fn_3464c816_000146_43f4fdca+0xdf0>
  41178e:	vcvttsd2si rdx,xmm0
  411793:	mov    r8,rdx
  411796:	vxorpd xmm1,xmm1,xmm1
  41179a:	vcvtsi2sd xmm1,xmm1,rdx
  41179f:	vsubsd xmm1,xmm0,xmm1
  4117a3:	mov    r9d,0x8
  4117a9:	vxorpd xmm2,xmm2,xmm2
  4117ad:	vcomisd xmm2,xmm1
  4117b1:	ja     4117be <__swc_fn_3464c816_000146_43f4fdca+0xe3e>
  4117b3:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  4117bc:	jmp    4117cf <__swc_fn_3464c816_000146_43f4fdca+0xe4f>
  4117be:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1d8a]        # 413550 <__swc_rdata_base_3464c816+0x440>
  4117c6:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  4117cf:	test   r9d,r9d
  4117d2:	je     4117e9 <__swc_fn_3464c816_000146_43f4fdca+0xe69>
  4117d4:	cs nop WORD PTR [rax+rax*1+0x0]
  4117de:	xchg   ax,ax
  4117e0:	vmulsd xmm1,xmm1,xmm6
  4117e4:	dec    r9d
  4117e7:	jne    4117e0 <__swc_fn_3464c816_000146_43f4fdca+0xe60>
  4117e9:	vcvttsd2si r9,xmm1
  4117ee:	mov    r10,r9
  4117f1:	vxorpd xmm2,xmm2,xmm2
  4117f5:	vcvtsi2sd xmm2,xmm2,r9
  4117fa:	vsubsd xmm1,xmm1,xmm2
  4117fe:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  411807:	vcomisd xmm1,xmm6
  41180b:	lea    r9,[r9+0x1]
  41180f:	cmova  r10,r9
  411813:	cmp    r10,0x5f5e100
  41181a:	jne    411833 <__swc_fn_3464c816_000146_43f4fdca+0xeb3>
  41181c:	lea    r8,[rdx-0x1]
  411820:	vxorpd xmm1,xmm1,xmm1
  411824:	vcomisd xmm1,xmm0
  411828:	lea    rdx,[rdx+0x1]
  41182c:	cmovbe r8,rdx
  411830:	xor    r10d,r10d
  411833:	mov    r9,rcx
  411836:	test   r8,r8
  411839:	jne    411859 <__swc_fn_3464c816_000146_43f4fdca+0xed9>
  41183b:	vxorpd xmm1,xmm1,xmm1
  41183f:	vcomisd xmm1,xmm0
  411843:	jbe    41184c <__swc_fn_3464c816_000146_43f4fdca+0xecc>
  411845:	mov    BYTE PTR [rcx],0x2d
  411848:	lea    r9,[rcx+0x1]
  41184c:	mov    BYTE PTR [r9],0x30
  411850:	add    r9,0x1
  411854:	jmp    4118eb <__swc_fn_3464c816_000146_43f4fdca+0xf6b>
  411859:	mov    r9,rcx
  41185c:	mov    rdx,r8
  41185f:	nop
  411860:	mov    r11,rdx
  411863:	movabs rdx,0x6666666666666667
  41186d:	mov    r15,rax
  411870:	mov    rax,r11
  411873:	imul   rdx
  411876:	mov    r12,rdx
  411879:	mov    rax,r15
  41187c:	sar    r12,0x2
  411880:	mov    rdx,r12
  411883:	shr    rdx,0x3f
  411887:	add    r12,rdx
  41188a:	mov    rdx,r12
  41188d:	imul   r13,r12,0xa
  411891:	sub    r11,r13
  411894:	mov    r13,QWORD PTR [rip+0x1ca5]        # 413540 <__swc_rdata_base_3464c816+0x430>
  41189b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4118a0:	mov    BYTE PTR [r9],r11b
  4118a3:	lea    r11,[r9+0x1]
  4118a7:	mov    r9,r11
  4118aa:	test   r12,r12
  4118ad:	jne    411860 <__swc_fn_3464c816_000146_43f4fdca+0xee0>
  4118af:	test   r8,r8
  4118b2:	jge    4118bc <__swc_fn_3464c816_000146_43f4fdca+0xf3c>
  4118b4:	mov    BYTE PTR [r11],0x2d
  4118b8:	lea    r9,[r11+0x1]
  4118bc:	mov    rdx,r9
  4118bf:	mov    BYTE PTR [r9],0x0
  4118c3:	sub    r9,0x1
  4118c7:	mov    r8,rcx
  4118ca:	cmp    r8,r9
  4118cd:	jae    4118e8 <__swc_fn_3464c816_000146_43f4fdca+0xf68>
  4118cf:	nop
  4118d0:	mov    r11b,BYTE PTR [r9]
  4118d3:	mov    r12b,BYTE PTR [r8]
  4118d6:	mov    BYTE PTR [r9],r12b
  4118d9:	sub    r9,0x1
  4118dd:	mov    BYTE PTR [r8],r11b
  4118e0:	inc    r8
  4118e3:	cmp    r8,r9
  4118e6:	jb     4118d0 <__swc_fn_3464c816_000146_43f4fdca+0xf50>
  4118e8:	mov    r9,rdx
  4118eb:	mov    BYTE PTR [r9],0x2e
  4118ef:	add    r9,0x1
  4118f3:	xor    r8d,r8d
  4118f6:	test   r10,r10
  4118f9:	je     41193f <__swc_fn_3464c816_000146_43f4fdca+0xfbf>
  4118fb:	mov    r11d,0x989680
  411901:	cmp    r10,r11
  411904:	jge    41193f <__swc_fn_3464c816_000146_43f4fdca+0xfbf>
  411906:	cs nop WORD PTR [rax+rax*1+0x0]
  411910:	inc    r8d
  411913:	movabs rdx,0x6666666666666667
  41191d:	mov    r15,rax
  411920:	mov    rax,r11
  411923:	imul   rdx
  411926:	mov    r11,rdx
  411929:	mov    rax,r15
  41192c:	sar    r11,0x2
  411930:	mov    rdx,r11
  411933:	shr    rdx,0x3f
  411937:	add    r11,rdx
  41193a:	cmp    r10,r11
  41193d:	jl     411910 <__swc_fn_3464c816_000146_43f4fdca+0xf90>
  41193f:	test   r8d,r8d
  411942:	je     41195d <__swc_fn_3464c816_000146_43f4fdca+0xfdd>
  411944:	cs nop WORD PTR [rax+rax*1+0x0]
  41194e:	xchg   ax,ax
  411950:	mov    BYTE PTR [r9],0x30
  411954:	add    r9,0x1
  411958:	dec    r8d
  41195b:	jne    411950 <__swc_fn_3464c816_000146_43f4fdca+0xfd0>
  41195d:	mov    r8,r9
  411960:	mov    rdx,r10
  411963:	cs nop WORD PTR [rax+rax*1+0x0]
  41196d:	nop    DWORD PTR [rax]
  411970:	mov    r11,rdx
  411973:	movabs rdx,0x6666666666666667
  41197d:	mov    rax,r11
  411980:	imul   rdx
  411983:	sar    rdx,0x2
  411987:	mov    r12,rdx
  41198a:	shr    rdx,0x3f
  41198e:	add    r12,rdx
  411991:	mov    rdx,r12
  411994:	imul   r13,r12,0xa
  411998:	sub    r11,r13
  41199b:	mov    r13,QWORD PTR [rip+0x1b9e]        # 413540 <__swc_rdata_base_3464c816+0x430>
  4119a2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4119a7:	mov    BYTE PTR [r8],r11b
  4119aa:	lea    r11,[r8+0x1]
  4119ae:	mov    r8,r11
  4119b1:	test   r12,r12
  4119b4:	jne    411970 <__swc_fn_3464c816_000146_43f4fdca+0xff0>
  4119b6:	test   r10,r10
  4119b9:	jge    4119c3 <__swc_fn_3464c816_000146_43f4fdca+0x1043>
  4119bb:	mov    BYTE PTR [r11],0x2d
  4119bf:	lea    r8,[r11+0x1]
  4119c3:	mov    BYTE PTR [r8],0x0
  4119c7:	sub    r8,0x1
  4119cb:	cmp    r9,r8
  4119ce:	jae    4119e8 <__swc_fn_3464c816_000146_43f4fdca+0x1068>
  4119d0:	mov    al,BYTE PTR [r8]
  4119d3:	mov    dl,BYTE PTR [r9]
  4119d6:	mov    BYTE PTR [r8],dl
  4119d9:	sub    r8,0x1
  4119dd:	mov    BYTE PTR [r9],al
  4119e0:	inc    r9
  4119e3:	cmp    r9,r8
  4119e6:	jb     4119d0 <__swc_fn_3464c816_000146_43f4fdca+0x1050>
  4119e8:	xor    eax,eax
  4119ea:	test   rcx,rcx
  4119ed:	je     411a10 <__swc_fn_3464c816_000146_43f4fdca+0x1090>
  4119ef:	mov    rdx,rcx
  4119f2:	mov    r8b,BYTE PTR [rdx]
  4119f5:	test   r8b,r8b
  4119f8:	je     411a10 <__swc_fn_3464c816_000146_43f4fdca+0x1090>
  4119fa:	nop    WORD PTR [rax+rax*1+0x0]
  411a00:	add    rdx,0x1
  411a04:	add    rax,0x1
  411a08:	mov    r8b,BYTE PTR [rdx]
  411a0b:	test   r8b,r8b
  411a0e:	jne    411a00 <__swc_fn_3464c816_000146_43f4fdca+0x1080>
  411a10:	mov    QWORD PTR [rsp+0x3f8],rcx
  411a18:	mov    QWORD PTR [rsp+0x400],rax
  411a20:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  411a29:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  411a32:	lea    rcx,[rsp+0x408]
  411a3a:	call   410100 <__swc_fn_3464c816_000116_035d76a1>
  411a3f:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  411a41:	mov    rcx,rdx
  411a44:	call   410100 <__swc_fn_3464c816_000116_035d76a1>
  411a49:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  411a4b:	mov    al,BYTE PTR [rdx]
  411a4d:	test   al,al
  411a4f:	je     411a5a <__swc_fn_3464c816_000146_43f4fdca+0x10da>
  411a51:	lea    rax,[rip+0x1b08]        # 413560 <__swc_rdata_base_3464c816+0x450>
  411a58:	jmp    411a61 <__swc_fn_3464c816_000146_43f4fdca+0x10e1>
  411a5a:	lea    rax,[rip+0x1b0f]        # 413570 <__swc_rdata_base_3464c816+0x460>
  411a61:	mov    rcx,rax
  411a64:	call   410100 <__swc_fn_3464c816_000116_035d76a1>
  411a69:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  411a6b:	lea    rcx,[rip+0x1b0e]        # 413580 <__swc_rdata_base_3464c816+0x470>
  411a72:	call   410100 <__swc_fn_3464c816_000116_035d76a1>
  411a77:	jmp    411a85 <__swc_fn_3464c816_000146_43f4fdca+0x1105>
  411a79:	lea    rcx,[rip+0x1b00]        # 413580 <__swc_rdata_base_3464c816+0x470>
  411a80:	call   410100 <__swc_fn_3464c816_000116_035d76a1>
  411a85:	add    rdi,0x1
  411a89:	sub    rsi,0x1
  411a8d:	vmovups xmm0,xmm12
  411a92:	vmovsd xmm6,QWORD PTR [rip+0x1af6]        # 413590 <__swc_rdata_base_3464c816+0x480>
  411a9a:	test   rsi,rsi
  411a9d:	jne    410a90 <__swc_fn_3464c816_000146_43f4fdca+0x110>
  411aa3:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  411aac:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411ab5:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  411abe:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411ac7:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411ad0:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411ad9:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411ae2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  411aeb:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411af4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  411afd:	add    rsp,0x4e8
  411b04:	pop    r15
  411b06:	pop    r13
  411b08:	pop    r12
  411b0a:	pop    rdi
  411b0b:	pop    rsi
  411b0c:	pop    rbx
  411b0d:	ret
	...

0000000000411b10 <__swc_fn_3464c816_000149_9e4bc402>:
  411b10:	vxorps xmm0,xmm0,xmm0
  411b14:	vmovups XMMWORD PTR [rcx],xmm0
  411b18:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411b1d:	ret
	...

0000000000411b20 <__swc_fn_3464c816_000152_9e4bc402>:
  411b20:	vxorps xmm0,xmm0,xmm0
  411b24:	vmovups XMMWORD PTR [rcx],xmm0
  411b28:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411b2d:	vxorps xmm0,xmm0,xmm0
  411b31:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411b36:	vmovups xmm0,XMMWORD PTR [rip+0x1b62]        # 4136a0 <__swc_rdata_base_3464c816+0x590>
  411b3e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411b43:	vxorps xmm0,xmm0,xmm0
  411b47:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411b4c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411b51:	vxorps xmm0,xmm0,xmm0
  411b55:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411b5a:	mov    QWORD PTR [rcx+0x70],0x0
  411b62:	ret
	...

0000000000411b70 <__swc_fn_3464c816_000155_9e4bc402>:
  411b70:	vxorps xmm0,xmm0,xmm0
  411b74:	vmovups XMMWORD PTR [rcx],xmm0
  411b78:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411b7d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411b82:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411b87:	ret
	...

0000000000411b90 <__swc_fn_3464c816_000158_b43b2f96>:
  411b90:	push   rsi
  411b91:	push   rdi
  411b92:	sub    rsp,0x8
  411b96:	mov    rsi,rcx
  411b99:	mov    rdi,QWORD PTR [rsi+0x50]
  411b9d:	test   rdi,rdi
  411ba0:	je     411ba7 <__swc_fn_3464c816_000158_b43b2f96+0x17>
  411ba2:	mov    rcx,rsi
  411ba5:	call   rdi
  411ba7:	mov    QWORD PTR [rsi+0x20],0x0
  411baf:	mov    rax,QWORD PTR [rsi+0x30]
  411bb3:	test   rax,rax
  411bb6:	je     411be4 <__swc_fn_3464c816_000158_b43b2f96+0x54>
  411bb8:	nop    DWORD PTR [rax+rax*1+0x0]
  411bc0:	mov    rdi,QWORD PTR [rax+0x8]
  411bc4:	mov    rcx,rsi
  411bc7:	mov    rdx,QWORD PTR [rax+0x10]
  411bcb:	mov    rax,QWORD PTR [rax+0x18]
  411bcf:	mov    r8,rax
  411bd2:	call   409ec0 <__swc_fn_3464c816_000156_2745c4a5>
  411bd7:	mov    QWORD PTR [rsi+0x30],rdi
  411bdb:	mov    rax,QWORD PTR [rsi+0x30]
  411bdf:	test   rax,rax
  411be2:	jne    411bc0 <__swc_fn_3464c816_000158_b43b2f96+0x30>
  411be4:	mov    QWORD PTR [rsi+0x38],0x0
  411bec:	add    rsp,0x8
  411bf0:	pop    rdi
  411bf1:	pop    rsi
  411bf2:	ret
	...

0000000000411c00 <__swc_fn_3464c816_000161_b5a9d657>:
  411c00:	push   rbx
  411c01:	push   rsi
  411c02:	push   rdi
  411c03:	push   r12
  411c05:	sub    rsp,0x188
  411c0c:	mov    rbx,rcx
  411c0f:	lea    rsi,[rip+0x1517a]        # 426d90 <__swc_bss_base_3464c816+0x2d50>
  411c16:	mov    rcx,rsi
  411c19:	call   4098c0 <__swc_fn_3464c816_000135_e3032dc2>
  411c1e:	mov    rax,QWORD PTR [rip+0x15173]        # 426d98 <__swc_bss_base_3464c816+0x2d58>
  411c25:	mov    rdi,rax
  411c28:	test   rdi,rdi
  411c2b:	je     411c59 <__swc_fn_3464c816_000161_b5a9d657+0x59>
  411c2d:	nop    DWORD PTR [rax]
  411c30:	cmp    QWORD PTR [rdi+0x8],rbx
  411c34:	jne    411c4e <__swc_fn_3464c816_000161_b5a9d657+0x4e>
  411c36:	mov    rcx,rsi
  411c39:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  411c3e:	mov    rax,rdi
  411c41:	add    rsp,0x188
  411c48:	pop    r12
  411c4a:	pop    rdi
  411c4b:	pop    rsi
  411c4c:	pop    rbx
  411c4d:	ret
  411c4e:	mov    rax,QWORD PTR [rdi]
  411c51:	mov    rdi,rax
  411c54:	test   rax,rax
  411c57:	jne    411c30 <__swc_fn_3464c816_000161_b5a9d657+0x30>
  411c59:	call   40cea0 <__swc_fn_3464c816_000139_7c02fe26>
  411c5e:	mov    rdi,rax
  411c61:	test   rax,rax
  411c64:	jne    411c7d <__swc_fn_3464c816_000161_b5a9d657+0x7d>
  411c66:	mov    rcx,rsi
  411c69:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  411c6e:	xor    eax,eax
  411c70:	add    rsp,0x188
  411c77:	pop    r12
  411c79:	pop    rdi
  411c7a:	pop    rsi
  411c7b:	pop    rbx
  411c7c:	ret
  411c7d:	lea    rax,[rsp+0x18]
  411c82:	mov    QWORD PTR [rax+0x10],0x0
  411c8a:	mov    QWORD PTR [rax+0x18],0x0
  411c92:	mov    DWORD PTR [rax+0x20],0x0
  411c99:	mov    BYTE PTR [rax+0x24],0x0
  411c9d:	mov    rax,QWORD PTR [rip+0x150f4]        # 426d98 <__swc_bss_base_3464c816+0x2d58>
  411ca4:	mov    QWORD PTR [rsp+0x18],rax
  411ca9:	mov    QWORD PTR [rsp+0x20],rbx
  411cae:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411cb4:	vmovups XMMWORD PTR [rdi],xmm0
  411cb8:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411cbe:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411cc3:	mov    rax,QWORD PTR [rsp+0x38]
  411cc8:	mov    QWORD PTR [rdi+0x20],rax
  411ccc:	mov    QWORD PTR [rip+0x150c5],rdi        # 426d98 <__swc_bss_base_3464c816+0x2d58>
  411cd3:	lea    rax,[rsp+0x40]
  411cd8:	mov    QWORD PTR [rax],0x0
  411cdf:	mov    rcx,rbx
  411ce2:	mov    rdx,rax
  411ce5:	call   4099a0 <__swc_fn_3464c816_000141_2ce79e3b>
  411cea:	mov    rbx,rax
  411ced:	test   rax,rax
  411cf0:	jne    411d0a <__swc_fn_3464c816_000161_b5a9d657+0x10a>
  411cf2:	mov    rcx,rsi
  411cf5:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  411cfa:	mov    rax,rdi
  411cfd:	add    rsp,0x188
  411d04:	pop    r12
  411d06:	pop    rdi
  411d07:	pop    rsi
  411d08:	pop    rbx
  411d09:	ret
  411d0a:	lea    r12,[rsp+0x50]
  411d0f:	mov    QWORD PTR [r12],0x0
  411d17:	mov    rcx,rbx
  411d1a:	mov    rdx,QWORD PTR [rsp+0x40]
  411d1f:	mov    r8,r12
  411d22:	call   40cf50 <__swc_fn_3464c816_000142_56e56812>
  411d27:	test   rax,rax
  411d2a:	jne    411d44 <__swc_fn_3464c816_000161_b5a9d657+0x144>
  411d2c:	mov    rcx,rsi
  411d2f:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  411d34:	mov    rax,rdi
  411d37:	add    rsp,0x188
  411d3e:	pop    r12
  411d40:	pop    rdi
  411d41:	pop    rsi
  411d42:	pop    rbx
  411d43:	ret
  411d44:	cmp    QWORD PTR [r12],0x10
  411d49:	jb     411e4c <__swc_fn_3464c816_000161_b5a9d657+0x24c>
  411d4f:	mov    ecx,DWORD PTR [rax]
  411d51:	cmp    ecx,0x42445753
  411d57:	jne    411e4c <__swc_fn_3464c816_000161_b5a9d657+0x24c>
  411d5d:	mov    ecx,DWORD PTR [rax+0x4]
  411d60:	cmp    ecx,0x1
  411d63:	jne    411e4c <__swc_fn_3464c816_000161_b5a9d657+0x24c>
  411d69:	mov    ecx,DWORD PTR [rax+0x8]
  411d6c:	mov    edx,DWORD PTR [rax+0xc]
  411d6f:	imul   r8,rcx,0x14
  411d73:	mov    r9,QWORD PTR [rsp+0x50]
  411d78:	sub    r9,0x10
  411d7c:	cmp    r8,r9
  411d7f:	ja     411e4c <__swc_fn_3464c816_000161_b5a9d657+0x24c>
  411d85:	lea    r8,[r8+0x10]
  411d89:	cmp    rdx,r8
  411d8c:	jb     411e4c <__swc_fn_3464c816_000161_b5a9d657+0x24c>
  411d92:	mov    r8,QWORD PTR [rsp+0x50]
  411d97:	cmp    rdx,r8
  411d9a:	ja     411e4c <__swc_fn_3464c816_000161_b5a9d657+0x24c>
  411da0:	xor    r8d,r8d
  411da3:	test   rcx,rcx
  411da6:	jbe    411e72 <__swc_fn_3464c816_000161_b5a9d657+0x272>
  411dac:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411db2:	cs nop WORD PTR [rax+rax*1+0x0]
  411dbc:	nop    DWORD PTR [rax+0x0]
  411dc0:	imul   r9,r8,0x14
  411dc4:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411dc9:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  411dce:	add    r10,r11
  411dd1:	movabs r11,0x100000000
  411ddb:	cmp    r10,r11
  411dde:	ja     411e4c <__swc_fn_3464c816_000161_b5a9d657+0x24c>
  411de0:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411de5:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  411dea:	test   r10d,r10d
  411ded:	setne  r11b
  411df1:	je     411e0b <__swc_fn_3464c816_000161_b5a9d657+0x20b>
  411df3:	cmp    r10d,edx
  411df6:	setb   r11b
  411dfa:	jb     411e0b <__swc_fn_3464c816_000161_b5a9d657+0x20b>
  411dfc:	vmovq  r11,xmm1
  411e01:	cmp    r10,r11
  411e04:	setae  r10b
  411e08:	mov    r11b,r10b
  411e0b:	mov    r10,r11
  411e0e:	test   r11b,r11b
  411e11:	jne    411e38 <__swc_fn_3464c816_000161_b5a9d657+0x238>
  411e13:	test   r9d,r9d
  411e16:	setne  r10b
  411e1a:	je     411e38 <__swc_fn_3464c816_000161_b5a9d657+0x238>
  411e1c:	cmp    r9d,edx
  411e1f:	setb   r10b
  411e23:	jb     411e38 <__swc_fn_3464c816_000161_b5a9d657+0x238>
  411e25:	vmovq  r10,xmm1
  411e2a:	cmp    r9,r10
  411e2d:	setae  r9b
  411e31:	movzx  r9d,r9b
  411e35:	mov    r10b,r9b
  411e38:	test   r10b,r10b
  411e3b:	jne    411e4c <__swc_fn_3464c816_000161_b5a9d657+0x24c>
  411e3d:	add    r8,0x1
  411e41:	cmp    r8,rcx
  411e44:	jb     411dc0 <__swc_fn_3464c816_000161_b5a9d657+0x1c0>
  411e4a:	jmp    411e72 <__swc_fn_3464c816_000161_b5a9d657+0x272>
  411e4c:	xor    ecx,ecx
  411e4e:	cmp    rax,rbx
  411e51:	cmovne rcx,rax
  411e55:	call   4108d0 <__swc_fn_3464c816_000143_81c0d993>
  411e5a:	mov    rcx,rsi
  411e5d:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  411e62:	mov    rax,rdi
  411e65:	add    rsp,0x188
  411e6c:	pop    r12
  411e6e:	pop    rdi
  411e6f:	pop    rsi
  411e70:	pop    rbx
  411e71:	ret
  411e72:	mov    QWORD PTR [rdi+0x10],rax
  411e76:	mov    rcx,QWORD PTR [rsp+0x50]
  411e7b:	mov    QWORD PTR [rdi+0x18],rcx
  411e7f:	mov    eax,DWORD PTR [rax+0x8]
  411e82:	mov    DWORD PTR [rdi+0x20],eax
  411e85:	rex mov BYTE PTR [rdi+0x24],0x1
  411e8a:	mov    rcx,rsi
  411e8d:	call   40ce90 <__swc_fn_3464c816_000136_3e875c27>
  411e92:	mov    rax,rdi
  411e95:	add    rsp,0x188
  411e9c:	pop    r12
  411e9e:	pop    rdi
  411e9f:	pop    rsi
  411ea0:	pop    rbx
  411ea1:	ret
	...

0000000000411eb0 <__swc_fn_3464c816_000164_1962e12a>:
  411eb0:	push   rsi
  411eb1:	push   rdi
  411eb2:	push   r12
  411eb4:	mov    rsi,rdx
  411eb7:	mov    rdi,rcx
  411eba:	mov    rcx,QWORD PTR [rip+0x14e7f]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  411ec1:	test   rcx,rcx
  411ec4:	jne    411ed6 <__swc_fn_3464c816_000164_1962e12a+0x26>
  411ec6:	call   40a1d0 <__swc_fn_3464c816_000165_cf398896>
  411ecb:	lea    rcx,[rax+0x1]
  411ecf:	mov    QWORD PTR [rip+0x14e6a],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  411ed6:	dec    rcx
  411ed9:	call   411f00 <__swc_fn_3464c816_000167_fce60b2b>
  411ede:	mov    r12,QWORD PTR [rax+0xbe0]
  411ee5:	test   r12,r12
  411ee8:	setne  al
  411eeb:	je     411ef6 <__swc_fn_3464c816_000164_1962e12a+0x46>
  411eed:	mov    rcx,rdi
  411ef0:	mov    rdx,rsi
  411ef3:	call   r12
  411ef6:	pop    r12
  411ef8:	pop    rdi
  411ef9:	pop    rsi
  411efa:	ret
  411efb:	add    BYTE PTR [rax],al
  411efd:	add    BYTE PTR [rax],al
	...

0000000000411f00 <__swc_fn_3464c816_000167_fce60b2b>:
  411f00:	push   r12
  411f02:	push   rdi
  411f03:	push   rsi
  411f04:	sub    rsp,0xd0
  411f0b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411f11:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411f17:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  411f1d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  411f23:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  411f29:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  411f2f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411f38:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  411f41:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  411f4a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  411f53:	mov    r12,rcx
  411f56:	mov    edi,ecx
  411f58:	xor    eax,eax
  411f5a:	call   407000 <pthread_getspecific@plt>
  411f5f:	test   rax,rax
  411f62:	je     411f66 <__swc_fn_3464c816_000167_fce60b2b+0x66>
  411f64:	jmp    411f6e <__swc_fn_3464c816_000167_fce60b2b+0x6e>
  411f66:	mov    rcx,r12
  411f69:	call   40a230 <__swc_fn_3464c816_000168_92b7d63c>
  411f6e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  411f74:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  411f7a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411f80:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411f86:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  411f8c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411f92:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  411f9b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411fa4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  411fad:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411fb6:	add    rsp,0xd0
  411fbd:	pop    rsi
  411fbe:	pop    rdi
  411fbf:	pop    r12
  411fc1:	ret
	...

0000000000411fd0 <__swc_fn_3464c816_000170_fa3003e2>:
  411fd0:	push   rsi
  411fd1:	sub    rsp,0x30
  411fd5:	lea    rsi,[rip+0x14dcc]        # 426da8 <__swc_bss_base_3464c816+0x2d68>
  411fdc:	mov    rax,QWORD PTR [rsi]
  411fdf:	test   rax,rax
  411fe2:	je     411fea <__swc_fn_3464c816_000170_fa3003e2+0x1a>
  411fe4:	add    rsp,0x30
  411fe8:	pop    rsi
  411fe9:	ret
  411fea:	mov    ecx,0x3
  411fef:	mov    edx,0x10
  411ff4:	call   40fa00 <__swc_fn_3464c816_000107_4796e893>
  411ff9:	test   rax,rax
  411ffc:	jne    41200d <__swc_fn_3464c816_000170_fa3003e2+0x3d>
  411ffe:	mov    QWORD PTR [rsp+0x18],rax
  412003:	call   40c9f0 <__swc_fn_3464c816_000118_7f430081>
  412008:	mov    rax,QWORD PTR [rsp+0x18]
  41200d:	mov    rcx,rax
  412010:	xchg   QWORD PTR [rsi],rcx
  412013:	add    rsp,0x30
  412017:	pop    rsi
  412018:	ret
  412019:	add    BYTE PTR [rax],al
  41201b:	add    BYTE PTR [rax],al
  41201d:	add    BYTE PTR [rax],al
	...

0000000000412020 <__swc_fn_3464c816_000173_f69b1f05>:
  412020:	push   rsi
  412021:	push   rdi
  412022:	sub    rsp,0x8
  412026:	mov    rsi,rdx
  412029:	mov    rdi,rcx
  41202c:	mov    rax,QWORD PTR [rsi+0x8]
  412030:	test   rax,rax
  412033:	je     41203d <__swc_fn_3464c816_000173_f69b1f05+0x1d>
  412035:	mov    rcx,QWORD PTR [rsi]
  412038:	mov    QWORD PTR [rax],rcx
  41203b:	jmp    412044 <__swc_fn_3464c816_000173_f69b1f05+0x24>
  41203d:	mov    rax,QWORD PTR [rsi]
  412040:	mov    QWORD PTR [rdi+0x8],rax
  412044:	mov    rax,QWORD PTR [rsi]
  412047:	test   rax,rax
  41204a:	je     412054 <__swc_fn_3464c816_000173_f69b1f05+0x34>
  41204c:	mov    rcx,QWORD PTR [rsi+0x8]
  412050:	mov    QWORD PTR [rax+0x8],rcx
  412054:	mov    rcx,rdi
  412057:	mov    rdx,QWORD PTR [rsi+0x10]
  41205b:	mov    r8,QWORD PTR [rsi+0x18]
  41205f:	mov    r9,0xffffffffffffffff
  412066:	call   40d5c0 <__swc_fn_3464c816_000172_97fbc432>
  41206b:	mov    QWORD PTR [rsi+0x18],0x0
  412073:	mov    rax,QWORD PTR [rdi+0x8]
  412077:	test   rax,rax
  41207a:	jne    41208c <__swc_fn_3464c816_000173_f69b1f05+0x6c>
  41207c:	call   411fd0 <__swc_fn_3464c816_000170_fa3003e2>
  412081:	xor    ecx,ecx
  412083:	mov    QWORD PTR [rax+0x8],rcx
  412087:	xor    ecx,ecx
  412089:	mov    QWORD PTR [rax],rcx
  41208c:	add    rsp,0x8
  412090:	pop    rdi
  412091:	pop    rsi
  412092:	ret
	...

00000000004120a0 <__swc_fn_3464c816_000176_2744b483>:
  4120a0:	push   rbx
  4120a1:	sub    rsp,0x70
  4120a5:	cmp    rcx,0xffffffffffffffef
  4120a9:	jbe    4120b3 <__swc_fn_3464c816_000176_2744b483+0x13>
  4120ab:	xor    eax,eax
  4120ad:	add    rsp,0x70
  4120b1:	pop    rbx
  4120b2:	ret
  4120b3:	vxorps xmm0,xmm0,xmm0
  4120b7:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4120bd:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4120c3:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  4120c9:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  4120cf:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  4120d5:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  4120db:	lea    rax,[rcx+0x10]
  4120df:	mov    QWORD PTR [rsp+0x50],rax
  4120e4:	mov    DWORD PTR [rsp+0x60],0x10
  4120ec:	mov    rcx,QWORD PTR [rip+0x14c4d]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  4120f3:	test   rcx,rcx
  4120f6:	jne    412108 <__swc_fn_3464c816_000176_2744b483+0x68>
  4120f8:	call   40a1d0 <__swc_fn_3464c816_000165_cf398896>
  4120fd:	lea    rcx,[rax+0x1]
  412101:	mov    QWORD PTR [rip+0x14c38],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  412108:	dec    rcx
  41210b:	call   411f00 <__swc_fn_3464c816_000167_fce60b2b>
  412110:	mov    rcx,QWORD PTR [rax]
  412113:	lea    rdx,[rsp+0x8]
  412118:	mov    rbx,QWORD PTR [rax+0x8]
  41211c:	mov    rbx,QWORD PTR [rbx+0x8]
  412120:	call   rbx
  412122:	mov    rax,QWORD PTR [rsp+0x48]
  412127:	test   rax,rax
  41212a:	jne    412134 <__swc_fn_3464c816_000176_2744b483+0x94>
  41212c:	xor    eax,eax
  41212e:	add    rsp,0x70
  412132:	pop    rbx
  412133:	ret
  412134:	mov    rcx,QWORD PTR [rsp+0x50]
  412139:	mov    QWORD PTR [rax],rcx
  41213c:	mov    QWORD PTR [rax+0x8],0x0
  412144:	lea    rax,[rax+0x10]
  412148:	add    rsp,0x70
  41214c:	pop    rbx
  41214d:	ret
