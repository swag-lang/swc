
/workspace/prompt2-20261115/session-combined-micro/base/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

00000000004121b0 <__swc_fn_4fa09e82_000179_6937fe70>:
  4121b0:	push   rsi
  4121b1:	push   rdi
  4121b2:	push   r12
  4121b4:	push   r13
  4121b6:	push   r14
  4121b8:	push   r15
  4121ba:	sub    rsp,0xd8
  4121c1:	mov    rsi,rdx
  4121c4:	mov    QWORD PTR [rsp+0x88],rdx
  4121cc:	mov    rdi,rcx
  4121cf:	cmp    rdi,rsi
  4121d2:	jge    4123e9 <__swc_fn_4fa09e82_000179_6937fe70+0x239>
  4121d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4121e0:	lea    rax,[rdi+rsi*1]
  4121e4:	mov    rcx,rax
  4121e7:	shr    rax,0x3f
  4121eb:	add    rcx,rax
  4121ee:	sar    rcx,1
  4121f1:	mov    rax,QWORD PTR [rip+0x14bb8]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  4121f8:	mov    r12,QWORD PTR [rax+rcx*8]
  4121fc:	mov    r13,rdi
  4121ff:	mov    QWORD PTR [rsp+0x90],rdi
  412207:	mov    r14,rsi
  41220a:	nop    WORD PTR [rax+rax*1+0x0]
  412210:	cmp    r13,r14
  412213:	jle    412220 <__swc_fn_4fa09e82_000179_6937fe70+0x70>
  412215:	mov    rax,r13
  412218:	mov    r13,r14
  41221b:	jmp    4123c5 <__swc_fn_4fa09e82_000179_6937fe70+0x215>
  412220:	mov    r15,QWORD PTR [rip+0x14b89]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  412227:	mov    rsi,QWORD PTR [rip+0x14b8a]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  41222e:	mov    QWORD PTR [rsp+0xa8],rsi
  412236:	mov    rdi,QWORD PTR [rsi+r12*8]
  41223a:	mov    QWORD PTR [rsp+0xa0],r14
  412242:	mov    r14,QWORD PTR [rip+0x14b77]        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  412249:	mov    rax,QWORD PTR [rip+0x14b78]        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  412250:	mov    QWORD PTR [rsp+0xb0],rax
  412258:	mov    r9,QWORD PTR [rip+0x14b71]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  41225f:	mov    QWORD PTR [rsp+0xb8],r9
  412267:	nop    WORD PTR [rax+rax*1+0x0]
  412270:	mov    r10,QWORD PTR [r15+r13*8]
  412274:	cmp    QWORD PTR [rsi+r10*8],rdi
  412278:	je     41227e <__swc_fn_4fa09e82_000179_6937fe70+0xce>
  41227a:	ja     4122b5 <__swc_fn_4fa09e82_000179_6937fe70+0x105>
  41227c:	jmp    4122d2 <__swc_fn_4fa09e82_000179_6937fe70+0x122>
  41227e:	mov    rcx,QWORD PTR [r14+r10*8]
  412282:	mov    r8,QWORD PTR [r14+r12*8]
  412286:	cmp    r8,rcx
  412289:	cmovae r8,rcx
  41228d:	mov    rcx,QWORD PTR [rax+r10*8]
  412291:	add    rcx,r9
  412294:	mov    rdx,QWORD PTR [rax+r12*8]
  412298:	add    rdx,r9
  41229b:	mov    rsi,r10
  41229e:	call   410f30 <__swc_fn_4fa09e82_000107_ed4b1681>
  4122a3:	test   eax,eax
  4122a5:	je     4122ab <__swc_fn_4fa09e82_000179_6937fe70+0xfb>
  4122a7:	jl     4122b5 <__swc_fn_4fa09e82_000179_6937fe70+0x105>
  4122a9:	jmp    4122d2 <__swc_fn_4fa09e82_000179_6937fe70+0x122>
  4122ab:	mov    rax,QWORD PTR [r14+r12*8]
  4122af:	cmp    QWORD PTR [r14+rsi*8],rax
  4122b3:	jae    4122d2 <__swc_fn_4fa09e82_000179_6937fe70+0x122>
  4122b5:	inc    r13
  4122b8:	mov    rsi,QWORD PTR [rsp+0xa8]
  4122c0:	mov    rax,QWORD PTR [rsp+0xb0]
  4122c8:	mov    r9,QWORD PTR [rsp+0xb8]
  4122d0:	jmp    412270 <__swc_fn_4fa09e82_000179_6937fe70+0xc0>
  4122d2:	mov    rsi,QWORD PTR [rip+0x14ad7]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  4122d9:	mov    QWORD PTR [rsp+0xc0],rsi
  4122e1:	mov    rdi,QWORD PTR [rip+0x14ad0]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  4122e8:	mov    r14,QWORD PTR [rip+0x14ad1]        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  4122ef:	mov    r15,QWORD PTR [rip+0x14ad2]        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  4122f6:	mov    QWORD PTR [rsp+0x98],r13
  4122fe:	mov    r13,QWORD PTR [rsp+0xa0]
  412306:	mov    rax,QWORD PTR [rip+0x14ac3]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  41230d:	mov    QWORD PTR [rsp+0xc8],rax
  412315:	cs nop WORD PTR [rax+rax*1+0x0]
  41231f:	nop
  412320:	mov    r9,QWORD PTR [rsi+r13*8]
  412324:	mov    rcx,QWORD PTR [rdi+r9*8]
  412328:	cmp    QWORD PTR [rdi+r12*8],rcx
  41232c:	je     412332 <__swc_fn_4fa09e82_000179_6937fe70+0x182>
  41232e:	ja     412369 <__swc_fn_4fa09e82_000179_6937fe70+0x1b9>
  412330:	jmp    41237e <__swc_fn_4fa09e82_000179_6937fe70+0x1ce>
  412332:	mov    rcx,QWORD PTR [r14+r12*8]
  412336:	mov    r8,QWORD PTR [r14+r9*8]
  41233a:	cmp    r8,rcx
  41233d:	cmovae r8,rcx
  412341:	mov    rcx,QWORD PTR [r15+r12*8]
  412345:	add    rcx,rax
  412348:	mov    rdx,QWORD PTR [r15+r9*8]
  41234c:	add    rdx,rax
  41234f:	mov    rsi,r9
  412352:	call   410f30 <__swc_fn_4fa09e82_000107_ed4b1681>
  412357:	test   eax,eax
  412359:	je     41235f <__swc_fn_4fa09e82_000179_6937fe70+0x1af>
  41235b:	jl     412369 <__swc_fn_4fa09e82_000179_6937fe70+0x1b9>
  41235d:	jmp    41237e <__swc_fn_4fa09e82_000179_6937fe70+0x1ce>
  41235f:	mov    rax,QWORD PTR [r14+rsi*8]
  412363:	cmp    QWORD PTR [r14+r12*8],rax
  412367:	jae    41237e <__swc_fn_4fa09e82_000179_6937fe70+0x1ce>
  412369:	dec    r13
  41236c:	mov    rsi,QWORD PTR [rsp+0xc0]
  412374:	mov    rax,QWORD PTR [rsp+0xc8]
  41237c:	jmp    412320 <__swc_fn_4fa09e82_000179_6937fe70+0x170>
  41237e:	mov    rax,QWORD PTR [rsp+0x98]
  412386:	cmp    rax,r13
  412389:	jle    412396 <__swc_fn_4fa09e82_000179_6937fe70+0x1e6>
  41238b:	mov    r14,r13
  41238e:	mov    r13,rax
  412391:	jmp    412210 <__swc_fn_4fa09e82_000179_6937fe70+0x60>
  412396:	mov    rcx,QWORD PTR [rip+0x14a13]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  41239d:	mov    rdx,QWORD PTR [rcx+rax*8]
  4123a1:	mov    r8,QWORD PTR [rcx+r13*8]
  4123a5:	mov    QWORD PTR [rcx+rax*8],r8
  4123a9:	mov    rcx,QWORD PTR [rip+0x14a00]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  4123b0:	mov    QWORD PTR [rcx+r13*8],rdx
  4123b4:	inc    rax
  4123b7:	dec    r13
  4123ba:	mov    r14,r13
  4123bd:	mov    r13,rax
  4123c0:	jmp    412210 <__swc_fn_4fa09e82_000179_6937fe70+0x60>
  4123c5:	mov    rcx,QWORD PTR [rsp+0x90]
  4123cd:	mov    rdx,r13
  4123d0:	mov    rdi,rax
  4123d3:	call   4121b0 <__swc_fn_4fa09e82_000179_6937fe70>
  4123d8:	mov    rsi,QWORD PTR [rsp+0x88]
  4123e0:	cmp    rdi,rsi
  4123e3:	jl     4121e0 <__swc_fn_4fa09e82_000179_6937fe70+0x30>
  4123e9:	add    rsp,0xd8
  4123f0:	pop    r15
  4123f2:	pop    r14
  4123f4:	pop    r13
  4123f6:	pop    r12
  4123f8:	pop    rdi
  4123f9:	pop    rsi
  4123fa:	ret
