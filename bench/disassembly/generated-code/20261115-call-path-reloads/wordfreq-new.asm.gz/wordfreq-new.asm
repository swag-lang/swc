
/workspace/prompt2-20261115/batch9-audited-micro/new/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc00a]        # 413010 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xc002]        # 413018 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xbffa]        # 413020 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xbff2]        # 413028 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfea]        # 413030 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfe2]        # 413038 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfda]        # 413040 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfd2]        # 413048 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfca]        # 413050 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfc2]        # 413058 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfba]        # 413060 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfb2]        # 413068 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfaa]        # 413070 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbfa2]        # 413078 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <madvise@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf9a]        # 413080 <madvise@GLIBC_2.2.5>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <pthread_key_delete@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf92]        # 413088 <pthread_key_delete@GLIBC_2.34>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <gettid@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf8a]        # 413090 <gettid@GLIBC_2.30>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <clock_gettime@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf82]        # 413098 <clock_gettime@GLIBC_2.17>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <flock@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf7a]        # 4130a0 <flock@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <__errno_location@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf72]        # 4130a8 <__errno_location@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <opendir@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf6a]        # 4130b0 <opendir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <dirfd@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf62]        # 4130b8 <dirfd@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readdir@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <readdir@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <readlinkat@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <readlinkat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <openat@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <openat@GLIBC_2.4>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <closedir@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <closedir@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <memfd_create@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <memfd_create@GLIBC_2.27>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <ftruncate@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <ftruncate@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <write@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <write@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <backtrace@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <backtrace@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_4fa09e82_000179_cf4ffedd+0xd00>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40d1a0 <__swc_fn_4fa09e82_000127_540bf7e8>
  40724e:	xor    ecx,ecx
  407250:	call   4092a0 <__swc_fn_4fa09e82_000099_4f209617>
  407255:	call   40a8c0 <__swc_fn_4fa09e82_000004_913db40c>
  40725a:	call   40c7f0 <__swc_fn_4fa09e82_000100_65137b72>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_4fa09e82_000000_e7f0b636>:
  407270:	push   rsi
  407271:	push   rdi
  407272:	push   r12
  407274:	mov    rsi,r8
  407277:	mov    rdi,rcx
  40727a:	mov    r12,rdx
  40727d:	lea    rcx,[rdx*8+0x0]
  407285:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40728a:	mov    QWORD PTR [rdi],rax
  40728d:	lea    rcx,[r12*8+0x0]
  407295:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40729a:	mov    QWORD PTR [rdi+0x8],rax
  40729e:	lea    rcx,[r12*8+0x0]
  4072a6:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  4072ab:	mov    QWORD PTR [rdi+0x10],rax
  4072af:	mov    rcx,r12
  4072b2:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  4072b7:	mov    QWORD PTR [rdi+0x18],rax
  4072bb:	mov    rcx,rax
  4072be:	xor    al,al
  4072c0:	mov    rdx,rax
  4072c3:	mov    r8,r12
  4072c6:	call   40fca0 <__swc_fn_4fa09e82_000110_a342ead8>
  4072cb:	mov    QWORD PTR [rdi+0x20],rsi
  4072cf:	lea    rax,[r12-0x1]
  4072d4:	mov    QWORD PTR [rdi+0x28],rax
  4072d8:	mov    QWORD PTR [rdi+0x30],0x0
  4072e0:	pop    r12
  4072e2:	pop    rdi
  4072e3:	pop    rsi
  4072e4:	ret
	...

00000000004072f0 <__swc_fn_4fa09e82_000003_6937fe70>:
  4072f0:	push   rsi
  4072f1:	push   rdi
  4072f2:	push   r12
  4072f4:	push   r13
  4072f6:	push   r14
  4072f8:	push   r15
  4072fa:	sub    rsp,0xd8
  407301:	mov    rsi,rdx
  407304:	mov    QWORD PTR [rsp+0x88],rdx
  40730c:	mov    rdi,rcx
  40730f:	cmp    rdi,rsi
  407312:	jge    407529 <__swc_fn_4fa09e82_000003_6937fe70+0x239>
  407318:	nop    DWORD PTR [rax+rax*1+0x0]
  407320:	lea    rax,[rdi+rsi*1]
  407324:	mov    rcx,rax
  407327:	shr    rax,0x3f
  40732b:	add    rcx,rax
  40732e:	sar    rcx,1
  407331:	mov    rax,QWORD PTR [rip+0x1cd10]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  407338:	mov    r12,QWORD PTR [rax+rcx*8]
  40733c:	mov    r13,rdi
  40733f:	mov    QWORD PTR [rsp+0x90],rdi
  407347:	mov    r14,rsi
  40734a:	nop    WORD PTR [rax+rax*1+0x0]
  407350:	cmp    r13,r14
  407353:	jle    407360 <__swc_fn_4fa09e82_000003_6937fe70+0x70>
  407355:	mov    rax,r13
  407358:	mov    r13,r14
  40735b:	jmp    407505 <__swc_fn_4fa09e82_000003_6937fe70+0x215>
  407360:	mov    r15,QWORD PTR [rip+0x1cce1]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  407367:	mov    rsi,QWORD PTR [rip+0x1cce2]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  40736e:	mov    QWORD PTR [rsp+0xa8],rsi
  407376:	mov    rdi,QWORD PTR [rsi+r12*8]
  40737a:	mov    QWORD PTR [rsp+0xa0],r14
  407382:	mov    r14,QWORD PTR [rip+0x1cccf]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  407389:	mov    rax,QWORD PTR [rip+0x1ccd0]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  407390:	mov    QWORD PTR [rsp+0xb0],rax
  407398:	mov    r9,QWORD PTR [rip+0x1ccc9]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40739f:	mov    QWORD PTR [rsp+0xb8],r9
  4073a7:	nop    WORD PTR [rax+rax*1+0x0]
  4073b0:	mov    r10,QWORD PTR [r15+r13*8]
  4073b4:	cmp    QWORD PTR [rsi+r10*8],rdi
  4073b8:	je     4073be <__swc_fn_4fa09e82_000003_6937fe70+0xce>
  4073ba:	ja     40740d <__swc_fn_4fa09e82_000003_6937fe70+0x11d>
  4073bc:	jmp    407412 <__swc_fn_4fa09e82_000003_6937fe70+0x122>
  4073be:	mov    rcx,QWORD PTR [r14+r10*8]
  4073c2:	mov    r8,QWORD PTR [r14+r12*8]
  4073c6:	cmp    r8,rcx
  4073c9:	cmovae r8,rcx
  4073cd:	mov    rcx,QWORD PTR [rax+r10*8]
  4073d1:	add    rcx,r9
  4073d4:	mov    rdx,QWORD PTR [rax+r12*8]
  4073d8:	add    rdx,r9
  4073db:	mov    rsi,r10
  4073de:	call   40cb70 <__swc_fn_4fa09e82_000112_3dc01326>
  4073e3:	test   eax,eax
  4073e5:	je     4073eb <__swc_fn_4fa09e82_000003_6937fe70+0xfb>
  4073e7:	jl     4073f5 <__swc_fn_4fa09e82_000003_6937fe70+0x105>
  4073e9:	jmp    407412 <__swc_fn_4fa09e82_000003_6937fe70+0x122>
  4073eb:	mov    rax,QWORD PTR [r14+r12*8]
  4073ef:	cmp    QWORD PTR [r14+rsi*8],rax
  4073f3:	jae    407412 <__swc_fn_4fa09e82_000003_6937fe70+0x122>
  4073f5:	mov    rsi,QWORD PTR [rsp+0xa8]
  4073fd:	mov    rax,QWORD PTR [rsp+0xb0]
  407405:	mov    r9,QWORD PTR [rsp+0xb8]
  40740d:	inc    r13
  407410:	jmp    4073b0 <__swc_fn_4fa09e82_000003_6937fe70+0xc0>
  407412:	mov    rsi,QWORD PTR [rip+0x1cc2f]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  407419:	mov    QWORD PTR [rsp+0xc0],rsi
  407421:	mov    rdi,QWORD PTR [rip+0x1cc28]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  407428:	mov    r14,QWORD PTR [rip+0x1cc29]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40742f:	mov    r15,QWORD PTR [rip+0x1cc2a]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  407436:	mov    QWORD PTR [rsp+0x98],r13
  40743e:	mov    r13,QWORD PTR [rsp+0xa0]
  407446:	mov    rax,QWORD PTR [rip+0x1cc1b]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40744d:	mov    QWORD PTR [rsp+0xc8],rax
  407455:	cs nop WORD PTR [rax+rax*1+0x0]
  40745f:	nop
  407460:	mov    r9,QWORD PTR [rsi+r13*8]
  407464:	mov    rcx,QWORD PTR [rdi+r9*8]
  407468:	cmp    QWORD PTR [rdi+r12*8],rcx
  40746c:	je     407472 <__swc_fn_4fa09e82_000003_6937fe70+0x182>
  40746e:	ja     4074b9 <__swc_fn_4fa09e82_000003_6937fe70+0x1c9>
  407470:	jmp    4074be <__swc_fn_4fa09e82_000003_6937fe70+0x1ce>
  407472:	mov    rcx,QWORD PTR [r14+r12*8]
  407476:	mov    r8,QWORD PTR [r14+r9*8]
  40747a:	cmp    r8,rcx
  40747d:	cmovae r8,rcx
  407481:	mov    rcx,QWORD PTR [r15+r12*8]
  407485:	add    rcx,rax
  407488:	mov    rdx,QWORD PTR [r15+r9*8]
  40748c:	add    rdx,rax
  40748f:	mov    rsi,r9
  407492:	call   40cb70 <__swc_fn_4fa09e82_000112_3dc01326>
  407497:	test   eax,eax
  407499:	je     40749f <__swc_fn_4fa09e82_000003_6937fe70+0x1af>
  40749b:	jl     4074a9 <__swc_fn_4fa09e82_000003_6937fe70+0x1b9>
  40749d:	jmp    4074be <__swc_fn_4fa09e82_000003_6937fe70+0x1ce>
  40749f:	mov    rax,QWORD PTR [r14+rsi*8]
  4074a3:	cmp    QWORD PTR [r14+r12*8],rax
  4074a7:	jae    4074be <__swc_fn_4fa09e82_000003_6937fe70+0x1ce>
  4074a9:	mov    rsi,QWORD PTR [rsp+0xc0]
  4074b1:	mov    rax,QWORD PTR [rsp+0xc8]
  4074b9:	dec    r13
  4074bc:	jmp    407460 <__swc_fn_4fa09e82_000003_6937fe70+0x170>
  4074be:	mov    rax,QWORD PTR [rsp+0x98]
  4074c6:	cmp    rax,r13
  4074c9:	jle    4074d6 <__swc_fn_4fa09e82_000003_6937fe70+0x1e6>
  4074cb:	mov    r14,r13
  4074ce:	mov    r13,rax
  4074d1:	jmp    407350 <__swc_fn_4fa09e82_000003_6937fe70+0x60>
  4074d6:	mov    rcx,QWORD PTR [rip+0x1cb6b]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4074dd:	mov    rdx,QWORD PTR [rcx+rax*8]
  4074e1:	mov    r8,QWORD PTR [rcx+r13*8]
  4074e5:	mov    QWORD PTR [rcx+rax*8],r8
  4074e9:	mov    rcx,QWORD PTR [rip+0x1cb58]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4074f0:	mov    QWORD PTR [rcx+r13*8],rdx
  4074f4:	inc    rax
  4074f7:	dec    r13
  4074fa:	mov    r14,r13
  4074fd:	mov    r13,rax
  407500:	jmp    407350 <__swc_fn_4fa09e82_000003_6937fe70+0x60>
  407505:	mov    rcx,QWORD PTR [rsp+0x90]
  40750d:	mov    rdx,r13
  407510:	mov    rdi,rax
  407513:	call   4072f0 <__swc_fn_4fa09e82_000003_6937fe70>
  407518:	mov    rsi,QWORD PTR [rsp+0x88]
  407520:	cmp    rdi,rsi
  407523:	jl     407320 <__swc_fn_4fa09e82_000003_6937fe70+0x30>
  407529:	add    rsp,0xd8
  407530:	pop    r15
  407532:	pop    r14
  407534:	pop    r13
  407536:	pop    r12
  407538:	pop    rdi
  407539:	pop    rsi
  40753a:	ret
  40753b:	add    BYTE PTR [rax],al
  40753d:	add    BYTE PTR [rax],al
	...

0000000000407540 <__swc_fn_4fa09e82_000006_9ee35b18>:
  407540:	vxorps xmm0,xmm0,xmm0
  407544:	xor    eax,eax
  407546:	cs nop WORD PTR [rax+rax*1+0x0]
  407550:	cs nop WORD PTR [rax+rax*1+0x0]
  40755a:	nop    WORD PTR [rax+rax*1+0x0]
  407560:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  407565:	add    rax,0x10
  407569:	cmp    rax,0x2080
  407570:	jne    407560 <__swc_fn_4fa09e82_000006_9ee35b18+0x20>
  407572:	ret
	...

0000000000407580 <__swc_fn_4fa09e82_000009_d64b2baa>:
  407580:	push   rsi
  407581:	push   rdi
  407582:	push   r12
  407584:	push   r13
  407586:	push   r14
  407588:	mov    rsi,rcx
  40758b:	mov    edi,r10d
  40758e:	mov    r12,rcx
  407591:	mov    r13,r9
  407594:	mov    ecx,DWORD PTR [rdx+0x28]
  407597:	shlx   r14d,r8d,ecx
  40759c:	mov    rcx,rdx
  40759f:	mov    edx,r8d
  4075a2:	call   40b090 <__swc_fn_4fa09e82_000016_9dea5065>
  4075a7:	mov    rcx,rax
  4075aa:	mov    eax,DWORD PTR [r12+0x3c]
  4075af:	xor    edx,edx
  4075b1:	div    rdi
  4075b4:	vxorps xmm0,xmm0,xmm0
  4075b8:	vmovdqu XMMWORD PTR [rsi],xmm0
  4075bc:	mov    QWORD PTR [r12+0x60],0x0
  4075c5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  4075ca:	mov    QWORD PTR [r12+0x10],rcx
  4075cf:	imul   rax,rdi
  4075d3:	lea    rdx,[rcx+rax*1]
  4075d7:	mov    QWORD PTR [r12+0x18],rdx
  4075dc:	mov    QWORD PTR [r12+0x20],rcx
  4075e1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  4075e6:	mov    DWORD PTR [r12+0x28],0x0
  4075ef:	mov    DWORD PTR [r12+0x68],0x0
  4075f8:	mov    BYTE PTR [r12+0x39],r13b
  4075fd:	mov    BYTE PTR [r12+0x3a],r14b
  407602:	mov    BYTE PTR [r12+0x3b],0x1
  407608:	mov    DWORD PTR [r12+0x6c],0x0
  407611:	mov    rcx,r12
  407614:	mov    edx,edi
  407616:	call   40aff0 <__swc_fn_4fa09e82_000010_065ed5b1>
  40761b:	pop    r14
  40761d:	pop    r13
  40761f:	pop    r12
  407621:	pop    rdi
  407622:	pop    rsi
  407623:	ret
	...

0000000000407630 <__swc_fn_4fa09e82_000012_c3647f66>:
  407630:	mov    r8d,0x1
  407636:	xor    eax,eax
  407638:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40763e:	test   eax,eax
  407640:	jne    407630 <__swc_fn_4fa09e82_000012_c3647f66>
  407642:	ret
	...

0000000000407650 <__swc_fn_4fa09e82_000015_524c1f23>:
  407650:	lea    r8,[rcx+0x60]
  407654:	mov    rax,QWORD PTR [r8]
  407657:	mov    r9,rax
  40765a:	nop    WORD PTR [rax+rax*1+0x0]
  407660:	mov    QWORD PTR [rdx],r9
  407663:	mov    rax,r9
  407666:	lock cmpxchg QWORD PTR [r8],rdx
  40766b:	cmp    rax,r9
  40766e:	jne    4076d7 <__swc_fn_4fa09e82_000015_524c1f23+0x87>
  407670:	mov    eax,DWORD PTR [rcx+0x6c]
  407673:	test   eax,eax
  407675:	je     4076d6 <__swc_fn_4fa09e82_000015_524c1f23+0x86>
  407677:	lea    rdx,[rcx+0x70]
  40767b:	mov    r9d,0x1
  407681:	xor    eax,eax
  407683:	lock cmpxchg DWORD PTR [rdx],r9d
  407688:	test   eax,eax
  40768a:	jne    4076d6 <__swc_fn_4fa09e82_000015_524c1f23+0x86>
  40768c:	mov    rax,rcx
  40768f:	and    rax,0xffffffffffc00000
  407696:	mov    rax,QWORD PTR [rax+0x8]
  40769a:	test   rax,rax
  40769d:	jne    4076a5 <__swc_fn_4fa09e82_000015_524c1f23+0x55>
  40769f:	xor    eax,eax
  4076a1:	xchg   DWORD PTR [rdx],eax
  4076a3:	jmp    4076d6 <__swc_fn_4fa09e82_000015_524c1f23+0x86>
  4076a5:	lea    rdx,[rax+0x2a80]
  4076ac:	mov    rax,QWORD PTR [rdx]
  4076af:	mov    r8,rax
  4076b2:	cs nop WORD PTR [rax+rax*1+0x0]
  4076bc:	nop    DWORD PTR [rax+0x0]
  4076c0:	mov    QWORD PTR [rcx+0x78],r8
  4076c4:	mov    rax,r8
  4076c7:	lock cmpxchg QWORD PTR [rdx],rcx
  4076cc:	cmp    rax,r8
  4076cf:	je     4076d6 <__swc_fn_4fa09e82_000015_524c1f23+0x86>
  4076d1:	mov    r8,rax
  4076d4:	jmp    4076c0 <__swc_fn_4fa09e82_000015_524c1f23+0x70>
  4076d6:	ret
  4076d7:	mov    r9,rax
  4076da:	jmp    407660 <__swc_fn_4fa09e82_000015_524c1f23+0x10>
	...

00000000004076e0 <__swc_fn_4fa09e82_000018_efc44797>:
  4076e0:	push   rsi
  4076e1:	push   rdi
  4076e2:	push   r12
  4076e4:	push   r13
  4076e6:	push   r14
  4076e8:	push   r15
  4076ea:	push   rbx
  4076eb:	sub    rsp,0x30
  4076ef:	mov    QWORD PTR [rsp+0x18],r8
  4076f4:	mov    rsi,rcx
  4076f7:	mov    rdi,rdx
  4076fa:	mov    rdx,QWORD PTR [rsi+0x40]
  4076fe:	xchg   ax,ax
  407700:	mov    rax,rdx
  407703:	not    rax
  407706:	and    rax,QWORD PTR [rsi+0x20]
  40770a:	test   rax,rax
  40770d:	jne    407721 <__swc_fn_4fa09e82_000018_efc44797+0x41>
  40770f:	xor    eax,eax
  407711:	add    rsp,0x30
  407715:	pop    rbx
  407716:	pop    r15
  407718:	pop    r14
  40771a:	pop    r13
  40771c:	pop    r12
  40771e:	pop    rdi
  40771f:	pop    rsi
  407720:	ret
  407721:	xor    ecx,ecx
  407723:	tzcnt  rcx,rax
  407728:	lea    r12,[rsp+0x8]
  40772d:	mov    DWORD PTR [rsp+0x8],ecx
  407731:	mov    r13d,0x1
  407737:	shl    r13,cl
  40773a:	mov    rcx,rdx
  40773d:	or     rcx,r13
  407740:	mov    rax,rdx
  407743:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  407749:	cmp    rax,rdx
  40774c:	je     407753 <__swc_fn_4fa09e82_000018_efc44797+0x73>
  40774e:	mov    rdx,rax
  407751:	jmp    407700 <__swc_fn_4fa09e82_000018_efc44797+0x20>
  407753:	mov    eax,DWORD PTR [r12]
  407757:	shl    rax,0x4
  40775b:	lea    r14,[rsi+rax*8+0x80]
  407763:	mov    rcx,rsi
  407766:	mov    rax,r12
  407769:	mov    edx,DWORD PTR [rax]
  40776b:	call   40b090 <__swc_fn_4fa09e82_000016_9dea5065>
  407770:	mov    r15,rax
  407773:	mov    rcx,rsi
  407776:	mov    rdx,r13
  407779:	call   40b1f0 <__swc_fn_4fa09e82_000022_fd2b165c>
  40777e:	test   al,al
  407780:	je     4077b8 <__swc_fn_4fa09e82_000018_efc44797+0xd8>
  407782:	mov    ecx,DWORD PTR [r14+0x3c]
  407786:	lea    rdx,[rip+0x1c8fb]        # 424088 <__swc_bss_base_4fa09e82+0x48>
  40778d:	mov    r8,QWORD PTR [rip+0x1c8f4]        # 424088 <__swc_bss_base_4fa09e82+0x48>
  407794:	cs nop WORD PTR [rax+rax*1+0x0]
  40779e:	xchg   ax,ax
  4077a0:	mov    r9,r8
  4077a3:	sub    r9,rcx
  4077a6:	mov    rax,r8
  4077a9:	lock cmpxchg QWORD PTR [rdx],r9
  4077ae:	cmp    rax,r8
  4077b1:	je     407819 <__swc_fn_4fa09e82_000018_efc44797+0x139>
  4077b3:	mov    r8,rax
  4077b6:	jmp    4077a0 <__swc_fn_4fa09e82_000018_efc44797+0xc0>
  4077b8:	mov    rcx,rsi
  4077bb:	mov    rax,r12
  4077be:	mov    edx,DWORD PTR [rax]
  4077c0:	call   40e020 <__swc_fn_4fa09e82_000017_9afb7cfb>
  4077c5:	mov    rcx,r15
  4077c8:	and    rcx,0xffffffffffff0000
  4077cf:	lea    rcx,[rcx+0x10000]
  4077d6:	mov    rbx,rax
  4077d9:	cmp    rax,rcx
  4077dc:	cmova  rbx,rcx
  4077e0:	mov    rax,rbx
  4077e3:	sub    rax,r15
  4077e6:	mov    rcx,r15
  4077e9:	mov    rdx,rax
  4077ec:	call   40de70 <__swc_fn_4fa09e82_000008_f7acedb0>
  4077f1:	test   al,al
  4077f3:	jne    407812 <__swc_fn_4fa09e82_000018_efc44797+0x132>
  4077f5:	mov    rcx,rsi
  4077f8:	mov    rdx,r13
  4077fb:	call   40e1d0 <__swc_fn_4fa09e82_000023_c8f5f27c>
  407800:	xor    eax,eax
  407802:	add    rsp,0x30
  407806:	pop    rbx
  407807:	pop    r15
  407809:	pop    r14
  40780b:	pop    r13
  40780d:	pop    r12
  40780f:	pop    rdi
  407810:	pop    rsi
  407811:	ret
  407812:	sub    rbx,r15
  407815:	mov    DWORD PTR [r14+0x3c],ebx
  407819:	mov    rcx,r14
  40781c:	mov    rdx,rsi
  40781f:	mov    r8d,DWORD PTR [r12]
  407823:	mov    r9d,edi
  407826:	mov    rbx,QWORD PTR [rsp+0x18]
  40782b:	mov    r10d,ebx
  40782e:	call   407580 <__swc_fn_4fa09e82_000009_d64b2baa>
  407833:	mov    rax,r14
  407836:	add    rsp,0x30
  40783a:	pop    rbx
  40783b:	pop    r15
  40783d:	pop    r14
  40783f:	pop    r13
  407841:	pop    r12
  407843:	pop    rdi
  407844:	pop    rsi
  407845:	ret
	...

0000000000407850 <__swc_fn_4fa09e82_000021_de02dbdf>:
  407850:	mov    r8,QWORD PTR [rcx+0x48]
  407854:	cs nop WORD PTR [rax+rax*1+0x0]
  40785e:	xchg   ax,ax
  407860:	mov    r9,r8
  407863:	or     r9,rdx
  407866:	mov    rax,r8
  407869:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40786f:	cmp    rax,r8
  407872:	jne    407875 <__swc_fn_4fa09e82_000021_de02dbdf+0x25>
  407874:	ret
  407875:	mov    r8,rax
  407878:	jmp    407860 <__swc_fn_4fa09e82_000021_de02dbdf+0x10>
  40787a:	add    BYTE PTR [rax],al
  40787c:	add    BYTE PTR [rax],al
	...

0000000000407880 <__swc_fn_4fa09e82_000024_2d0fcd2c>:
  407880:	push   rsi
  407881:	push   rdi
  407882:	push   r12
  407884:	mov    rsi,rcx
  407887:	xor    edi,edi
  407889:	lea    r12,[rip+0x1c808]        # 424098 <__swc_bss_base_4fa09e82+0x58>
  407890:	mov    eax,DWORD PTR [r12]
  407894:	xor    ecx,ecx
  407896:	test   rax,rax
  407899:	jbe    4078d4 <__swc_fn_4fa09e82_000024_2d0fcd2c+0x54>
  40789b:	nop    DWORD PTR [rax+rax*1+0x0]
  4078a0:	lea    rdx,[rip+0x1c7f9]        # 4240a0 <__swc_bss_base_4fa09e82+0x60>
  4078a7:	mov    r8d,ecx
  4078aa:	lea    r8,[r8+r8*2]
  4078ae:	lea    r8,[rdx+r8*8]
  4078b2:	mov    rdx,QWORD PTR [r8+0x10]
  4078b6:	add    rdx,0x400000
  4078bd:	cmp    rdx,0x40000000
  4078c4:	ja     4078cb <__swc_fn_4fa09e82_000024_2d0fcd2c+0x4b>
  4078c6:	mov    rdi,r8
  4078c9:	jmp    4078d4 <__swc_fn_4fa09e82_000024_2d0fcd2c+0x54>
  4078cb:	add    rcx,0x1
  4078cf:	cmp    rcx,rax
  4078d2:	jb     4078a0 <__swc_fn_4fa09e82_000024_2d0fcd2c+0x20>
  4078d4:	test   rdi,rdi
  4078d7:	jne    407963 <__swc_fn_4fa09e82_000024_2d0fcd2c+0xe3>
  4078dd:	cmp    DWORD PTR [r12],0x10
  4078e2:	jae    40794b <__swc_fn_4fa09e82_000024_2d0fcd2c+0xcb>
  4078e4:	mov    ecx,0x40400000
  4078e9:	call   40afb0 <__swc_fn_4fa09e82_000007_81d2e1e9>
  4078ee:	test   rax,rax
  4078f1:	je     40794b <__swc_fn_4fa09e82_000024_2d0fcd2c+0xcb>
  4078f3:	lea    rcx,[rip+0x1c7a6]        # 4240a0 <__swc_bss_base_4fa09e82+0x60>
  4078fa:	mov    edx,DWORD PTR [r12]
  4078fe:	lea    rdx,[rdx+rdx*2]
  407902:	lea    rdx,[rcx+rdx*8]
  407906:	mov    QWORD PTR [rdx],rax
  407909:	lea    rax,[rax+0x3fffff]
  407910:	and    rax,0xffffffffffc00000
  407917:	mov    QWORD PTR [rdx+0x8],rax
  40791b:	mov    QWORD PTR [rdx+0x10],0x0
  407923:	mov    edx,DWORD PTR [rip+0x1c76f]        # 424098 <__swc_bss_base_4fa09e82+0x58>
  407929:	nop    DWORD PTR [rax+0x0]
  407930:	lea    r9d,[rdx+0x1]
  407934:	mov    rax,rdx
  407937:	lock cmpxchg DWORD PTR [r12],r9d
  40793d:	mov    r8d,eax
  407940:	cmp    eax,edx
  407942:	je     407952 <__swc_fn_4fa09e82_000024_2d0fcd2c+0xd2>
  407944:	mov    rdx,r8
  407947:	jmp    407930 <__swc_fn_4fa09e82_000024_2d0fcd2c+0xb0>
  407949:	jmp    407952 <__swc_fn_4fa09e82_000024_2d0fcd2c+0xd2>
  40794b:	xor    eax,eax
  40794d:	pop    r12
  40794f:	pop    rdi
  407950:	pop    rsi
  407951:	ret
  407952:	mov    eax,DWORD PTR [rip+0x1c740]        # 424098 <__swc_bss_base_4fa09e82+0x58>
  407958:	sub    eax,0x1
  40795b:	lea    rdi,[rax+rax*2]
  40795f:	lea    rdi,[rcx+rdi*8]
  407963:	mov    r12,QWORD PTR [rdi+0x8]
  407967:	add    r12,QWORD PTR [rdi+0x10]
  40796b:	mov    rcx,r12
  40796e:	mov    edx,0x3000
  407973:	call   40de70 <__swc_fn_4fa09e82_000008_f7acedb0>
  407978:	test   al,al
  40797a:	jne    407983 <__swc_fn_4fa09e82_000024_2d0fcd2c+0x103>
  40797c:	xor    eax,eax
  40797e:	pop    r12
  407980:	pop    rdi
  407981:	pop    rsi
  407982:	ret
  407983:	vxorps xmm0,xmm0,xmm0
  407987:	xor    eax,eax
  407989:	cs nop WORD PTR [rax+rax*1+0x0]
  407993:	cs nop WORD PTR [rax+rax*1+0x0]
  40799d:	nop    DWORD PTR [rax]
  4079a0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  4079a6:	add    rax,0x10
  4079aa:	cmp    rax,0x3000
  4079b1:	jne    4079a0 <__swc_fn_4fa09e82_000024_2d0fcd2c+0x120>
  4079b3:	mov    DWORD PTR [r12+0x28],esi
  4079b8:	mov    eax,0x40
  4079bd:	mov    ecx,esi
  4079bf:	shr    eax,cl
  4079c1:	mov    DWORD PTR [r12+0x2c],eax
  4079c6:	cmp    DWORD PTR [r12+0x2c],0x40
  4079cc:	jb     4079d7 <__swc_fn_4fa09e82_000024_2d0fcd2c+0x157>
  4079ce:	mov    rax,0xffffffffffffffff
  4079d5:	jmp    4079e7 <__swc_fn_4fa09e82_000024_2d0fcd2c+0x167>
  4079d7:	mov    eax,0x1
  4079dc:	mov    ecx,DWORD PTR [r12+0x2c]
  4079e1:	shl    rax,cl
  4079e4:	dec    rax
  4079e7:	mov    QWORD PTR [r12+0x20],rax
  4079ec:	mov    DWORD PTR [r12],0x4e540001
  4079f4:	mov    DWORD PTR [r12+0x4],0x53474d45
  4079fd:	add    QWORD PTR [rdi+0x10],0x400000
  407a05:	mov    rax,r12
  407a08:	pop    r12
  407a0a:	pop    rdi
  407a0b:	pop    rsi
  407a0c:	ret
  407a0d:	add    BYTE PTR [rax],al
	...

0000000000407a10 <__swc_fn_4fa09e82_000027_bcdc5519>:
  407a10:	mov    eax,0x1
  407a15:	mov    edx,DWORD PTR [rip+0x1c67d]        # 424098 <__swc_bss_base_4fa09e82+0x58>
  407a1b:	cmp    eax,edx
  407a1d:	jae    407a6b <__swc_fn_4fa09e82_000027_bcdc5519+0x5b>
  407a1f:	nop
  407a20:	lea    r8,[rip+0x1c679]        # 4240a0 <__swc_bss_base_4fa09e82+0x60>
  407a27:	lea    r9,[rax+rax*2]
  407a2b:	lea    r9,[r8+r9*8]
  407a2f:	mov    r8,rcx
  407a32:	sub    r8,QWORD PTR [r9+0x8]
  407a36:	mov    r9,QWORD PTR [r9+0x10]
  407a3a:	cmp    r8,r9
  407a3d:	jae    407a65 <__swc_fn_4fa09e82_000027_bcdc5519+0x55>
  407a3f:	mov    rax,rcx
  407a42:	and    rax,0xffffffffffc00000
  407a49:	shr    rcx,0x10
  407a4d:	and    ecx,0x3f
  407a50:	mov    edx,DWORD PTR [rax+0x28]
  407a53:	shrx   ecx,ecx,edx
  407a58:	shl    rcx,0x4
  407a5c:	lea    rax,[rax+rcx*8+0x80]
  407a64:	ret
  407a65:	inc    eax
  407a67:	cmp    eax,edx
  407a69:	jb     407a20 <__swc_fn_4fa09e82_000027_bcdc5519+0x10>
  407a6b:	xor    eax,eax
  407a6d:	ret
	...

0000000000407a70 <__swc_fn_4fa09e82_000030_9798fb47>:
  407a70:	vxorps xmm0,xmm0,xmm0
  407a74:	vmovups XMMWORD PTR [rcx],xmm0
  407a78:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  407a7d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407a82:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407a87:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  407a8c:	mov    QWORD PTR [rcx+0x50],0x0
  407a94:	ret
	...

0000000000407aa0 <__swc_fn_4fa09e82_000033_9798fb47>:
  407aa0:	vxorps xmm0,xmm0,xmm0
  407aa4:	xor    eax,eax
  407aa6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ab0:	cs nop WORD PTR [rax+rax*1+0x0]
  407aba:	nop    WORD PTR [rax+rax*1+0x0]
  407ac0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  407ac5:	add    rax,0x10
  407ac9:	cmp    rax,0x9b0
  407ad0:	jne    407ac0 <__swc_fn_4fa09e82_000033_9798fb47+0x20>
  407ad2:	mov    QWORD PTR [rcx+0x9b0],0x0
  407add:	ret
	...

0000000000407ae0 <__swc_fn_4fa09e82_000036_cd1a4e8c>:
  407ae0:	push   rsi
  407ae1:	push   rdi
  407ae2:	sub    rsp,0x8
  407ae6:	lea    rsi,[rip+0x1a523]        # 422010 <__swc_data_base_4fa09e82+0x10>
  407aed:	mov    rax,QWORD PTR [rsi]
  407af0:	mov    ecx,0xffffffff
  407af5:	cmp    rax,rcx
  407af8:	je     407b01 <__swc_fn_4fa09e82_000036_cd1a4e8c+0x21>
  407afa:	add    rsp,0x8
  407afe:	pop    rdi
  407aff:	pop    rsi
  407b00:	ret
  407b01:	mov    rcx,QWORD PTR [rip+0xb500]        # 413008 <__swc_fn_4fa09e82_000179_cf4ffedd+0xd08>
  407b08:	call   409ad0 <__swc_fn_4fa09e82_000132_4a82cdf6>
  407b0d:	mov    rcx,rax
  407b10:	mov    eax,0xffffffff
  407b15:	lock cmpxchg QWORD PTR [rsi],rcx
  407b1a:	mov    rdi,rax
  407b1d:	mov    eax,0xffffffff
  407b22:	cmp    rdi,rax
  407b25:	je     407b36 <__swc_fn_4fa09e82_000036_cd1a4e8c+0x56>
  407b27:	call   40d330 <__swc_fn_4fa09e82_000133_a611b8c4>
  407b2c:	mov    rax,rdi
  407b2f:	add    rsp,0x8
  407b33:	pop    rdi
  407b34:	pop    rsi
  407b35:	ret
  407b36:	mov    rax,rcx
  407b39:	add    rsp,0x8
  407b3d:	pop    rdi
  407b3e:	pop    rsi
  407b3f:	ret

0000000000407b40 <__swc_fn_4fa09e82_000039_14f56618>:
  407b40:	sub    rsp,0x8
  407b44:	vxorps xmm0,xmm0,xmm0
  407b48:	xor    eax,eax
  407b4a:	cs nop WORD PTR [rax+rax*1+0x0]
  407b54:	cs nop WORD PTR [rax+rax*1+0x0]
  407b5e:	xchg   ax,ax
  407b60:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  407b65:	add    rax,0x10
  407b69:	cmp    rax,0x2b00
  407b70:	jne    407b60 <__swc_fn_4fa09e82_000039_14f56618+0x20>
  407b72:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  407b7c:	xor    al,al
  407b7e:	mov    rdx,rax
  407b81:	xor    al,al
  407b83:	mov    r8,rax
  407b86:	xor    al,al
  407b88:	mov    r9,rax
  407b8b:	xor    al,al
  407b8d:	mov    r10,rax
  407b90:	xor    al,al
  407b92:	mov    r11,rax
  407b95:	call   40b430 <__swc_fn_4fa09e82_000040_03f1bf9a>
  407b9a:	add    rsp,0x8
  407b9e:	ret
	...

0000000000407ba0 <__swc_fn_4fa09e82_000042_c90d80c1>:
  407ba0:	push   rsi
  407ba1:	push   rdi
  407ba2:	push   r12
  407ba4:	mov    rsi,r8
  407ba7:	mov    rdi,rdx
  407baa:	mov    rcx,rdx
  407bad:	call   40afb0 <__swc_fn_4fa09e82_000007_81d2e1e9>
  407bb2:	mov    r12,rax
  407bb5:	test   rax,rax
  407bb8:	jne    407bc1 <__swc_fn_4fa09e82_000042_c90d80c1+0x21>
  407bba:	xor    eax,eax
  407bbc:	pop    r12
  407bbe:	pop    rdi
  407bbf:	pop    rsi
  407bc0:	ret
  407bc1:	mov    rcx,r12
  407bc4:	mov    rdx,rsi
  407bc7:	call   40de70 <__swc_fn_4fa09e82_000008_f7acedb0>
  407bcc:	test   al,al
  407bce:	jne    407be2 <__swc_fn_4fa09e82_000042_c90d80c1+0x42>
  407bd0:	mov    rcx,r12
  407bd3:	mov    rdx,rdi
  407bd6:	call   410410 <__swc_fn_4fa09e82_000119_ed2d8fed>
  407bdb:	xor    eax,eax
  407bdd:	pop    r12
  407bdf:	pop    rdi
  407be0:	pop    rsi
  407be1:	ret
  407be2:	mov    rax,r12
  407be5:	pop    r12
  407be7:	pop    rdi
  407be8:	pop    rsi
  407be9:	ret
	...

0000000000407c00 <__swc_fn_4fa09e82_000045_a78ae66b>:
  407c00:	push   rsi
  407c01:	push   rdi
  407c02:	push   r12
  407c04:	mov    rsi,rcx
  407c07:	mov    edx,0x9b8
  407c0c:	call   40b4a0 <__swc_fn_4fa09e82_000043_facd3e17>
  407c11:	mov    rdi,rax
  407c14:	test   rax,rax
  407c17:	jne    407c20 <__swc_fn_4fa09e82_000045_a78ae66b+0x20>
  407c19:	xor    eax,eax
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	ret
  407c20:	vxorps xmm0,xmm0,xmm0
  407c24:	xor    eax,eax
  407c26:	cs nop WORD PTR [rax+rax*1+0x0]
  407c30:	cs nop WORD PTR [rax+rax*1+0x0]
  407c3a:	nop    WORD PTR [rax+rax*1+0x0]
  407c40:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  407c45:	add    rax,0x10
  407c49:	cmp    rax,0x9b0
  407c50:	jne    407c40 <__swc_fn_4fa09e82_000045_a78ae66b+0x40>
  407c52:	mov    QWORD PTR [rdi+0x9b0],0x0
  407c5d:	mov    QWORD PTR [rdi],rsi
  407c60:	call   40d3e0 <__swc_fn_4fa09e82_000136_a9c1c700>
  407c65:	mov    QWORD PTR [rdi+0x18],rax
  407c69:	lea    r12,[rsi+0x10]
  407c6d:	mov    rcx,r12
  407c70:	call   409d20 <__swc_fn_4fa09e82_000141_86bb0f90>
  407c75:	mov    rax,QWORD PTR [rsi+0x20]
  407c79:	mov    QWORD PTR [rdi+0x8],rax
  407c7d:	mov    rax,QWORD PTR [rsi+0x20]
  407c81:	test   rax,rax
  407c84:	je     407c8a <__swc_fn_4fa09e82_000045_a78ae66b+0x8a>
  407c86:	mov    QWORD PTR [rax+0x10],rdi
  407c8a:	mov    QWORD PTR [rsi+0x20],rdi
  407c8e:	mov    rcx,r12
  407c91:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  407c96:	mov    rax,rdi
  407c99:	pop    r12
  407c9b:	pop    rdi
  407c9c:	pop    rsi
  407c9d:	ret
	...

0000000000407ca0 <__swc_fn_4fa09e82_000048_6e7a8d58>:
  407ca0:	mov    rax,QWORD PTR [rdx+0x10]
  407ca4:	test   rax,rax
  407ca7:	je     407cb3 <__swc_fn_4fa09e82_000048_6e7a8d58+0x13>
  407ca9:	mov    rcx,QWORD PTR [rdx+0x8]
  407cad:	mov    QWORD PTR [rax+0x8],rcx
  407cb1:	jmp    407cbb <__swc_fn_4fa09e82_000048_6e7a8d58+0x1b>
  407cb3:	mov    rax,QWORD PTR [rdx+0x8]
  407cb7:	mov    QWORD PTR [rcx+0x20],rax
  407cbb:	mov    rax,QWORD PTR [rdx+0x8]
  407cbf:	test   rax,rax
  407cc2:	je     407ccc <__swc_fn_4fa09e82_000048_6e7a8d58+0x2c>
  407cc4:	mov    rcx,QWORD PTR [rdx+0x10]
  407cc8:	mov    QWORD PTR [rax+0x10],rcx
  407ccc:	vxorps xmm0,xmm0,xmm0
  407cd0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  407cd5:	ret
	...

0000000000407ce0 <__swc_fn_4fa09e82_000051_129b9bf4>:
  407ce0:	sub    rsp,0x8
  407ce4:	mov    r9,r8
  407ce7:	mov    r10,rdx
  407cea:	call   40b550 <__swc_fn_4fa09e82_000049_137687bb>
  407cef:	mov    eax,0x1
  407cf4:	xchg   DWORD PTR [r9+0x6c],eax
  407cf8:	mov    rax,QWORD PTR [r9+0x60]
  407cfc:	test   rax,rax
  407cff:	je     407d43 <__swc_fn_4fa09e82_000051_129b9bf4+0x63>
  407d01:	xor    eax,eax
  407d03:	xchg   DWORD PTR [r9+0x6c],eax
  407d07:	movzx  eax,BYTE PTR [r9+0x39]
  407d0c:	lea    rax,[rax+rax*4]
  407d10:	lea    rax,[r10+rax*8+0x28]
  407d15:	mov    QWORD PTR [r9+0x50],0x0
  407d1d:	mov    rcx,QWORD PTR [rax+0x8]
  407d21:	mov    QWORD PTR [r9+0x48],rcx
  407d25:	mov    rcx,QWORD PTR [rax+0x8]
  407d29:	test   rcx,rcx
  407d2c:	je     407d34 <__swc_fn_4fa09e82_000051_129b9bf4+0x54>
  407d2e:	mov    QWORD PTR [rcx+0x50],r9
  407d32:	jmp    407d38 <__swc_fn_4fa09e82_000051_129b9bf4+0x58>
  407d34:	mov    QWORD PTR [rax+0x10],r9
  407d38:	mov    QWORD PTR [rax+0x8],r9
  407d3c:	xor    eax,eax
  407d3e:	add    rsp,0x8
  407d42:	ret
  407d43:	movzx  eax,BYTE PTR [r9+0x39]
  407d48:	lea    rax,[rax+rax*4]
  407d4c:	lea    rax,[r10+rax*8+0x28]
  407d51:	mov    QWORD PTR [r9+0x50],0x0
  407d59:	mov    rcx,QWORD PTR [rax+0x18]
  407d5d:	mov    QWORD PTR [r9+0x48],rcx
  407d61:	mov    rcx,QWORD PTR [rax+0x18]
  407d65:	test   rcx,rcx
  407d68:	je     407d6e <__swc_fn_4fa09e82_000051_129b9bf4+0x8e>
  407d6a:	mov    QWORD PTR [rcx+0x50],r9
  407d6e:	mov    QWORD PTR [rax+0x18],r9
  407d72:	mov    eax,0x1
  407d77:	add    rsp,0x8
  407d7b:	ret
  407d7c:	add    BYTE PTR [rax],al
	...

0000000000407d80 <__swc_fn_4fa09e82_000054_3af34d7f>:
  407d80:	push   r12
  407d82:	push   r13
  407d84:	push   rdi
  407d85:	push   rsi
  407d86:	push   r14
  407d88:	push   r15
  407d8a:	sub    rsp,0x178
  407d91:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  407d9a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  407da3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  407dac:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  407db5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  407dbe:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  407dc7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  407dd0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  407dd9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  407de2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  407deb:	mov    r12,rcx
  407dee:	lea    rax,[rip+0x1c43b]        # 424230 <__swc_bss_base_4fa09e82+0x1f0>
  407df5:	mov    rcx,QWORD PTR [rax]
  407df8:	mov    r13,rcx
  407dfb:	test   rcx,rcx
  407dfe:	jne    407e0e <__swc_fn_4fa09e82_000054_3af34d7f+0x8e>
  407e00:	mov    r13d,0x1dcd6500
  407e06:	mov    ecx,0x1dcd6500
  407e0b:	xchg   QWORD PTR [rax],rcx
  407e0e:	lea    rax,[rip+0x1a1f3]        # 422008 <__swc_data_base_4fa09e82+0x8>
  407e15:	mov    rax,QWORD PTR [rax]
  407e18:	cmp    rax,0xffffffffffffffff
  407e1c:	je     407e2b <__swc_fn_4fa09e82_000054_3af34d7f+0xab>
  407e1e:	mov    eax,eax
  407e20:	mov    edi,eax
  407e22:	xor    eax,eax
  407e24:	call   407000 <pthread_getspecific@plt>
  407e29:	jmp    407e2d <__swc_fn_4fa09e82_000054_3af34d7f+0xad>
  407e2b:	xor    eax,eax
  407e2d:	test   rax,rax
  407e30:	jne    407e3f <__swc_fn_4fa09e82_000054_3af34d7f+0xbf>
  407e32:	call   407ae0 <__swc_fn_4fa09e82_000036_cd1a4e8c>
  407e37:	mov    rcx,rax
  407e3a:	call   410760 <__swc_fn_4fa09e82_000134_5f757033>
  407e3f:	test   rax,rax
  407e42:	je     407e54 <__swc_fn_4fa09e82_000054_3af34d7f+0xd4>
  407e44:	cmp    QWORD PTR [rax],r12
  407e47:	jne    407e54 <__swc_fn_4fa09e82_000054_3af34d7f+0xd4>
  407e49:	cmp    DWORD PTR [rax+0x20],0x0
  407e4d:	jne    407e54 <__swc_fn_4fa09e82_000054_3af34d7f+0xd4>
  407e4f:	mov    rsi,rax
  407e52:	jmp    407e56 <__swc_fn_4fa09e82_000054_3af34d7f+0xd6>
  407e54:	xor    esi,esi
  407e56:	lea    rdi,[r12+0x2a88]
  407e5e:	mov    r14,QWORD PTR [rdi]
  407e61:	test   r14,r14
  407e64:	jne    407eb3 <__swc_fn_4fa09e82_000054_3af34d7f+0x133>
  407e66:	lea    rax,[rip+0x1c21b]        # 424088 <__swc_bss_base_4fa09e82+0x48>
  407e6d:	mov    rax,QWORD PTR [rax]
  407e70:	test   rax,rax
  407e73:	setne  al
  407e76:	jne    407e9a <__swc_fn_4fa09e82_000054_3af34d7f+0x11a>
  407e78:	mov    rax,QWORD PTR [r12+0x2a70]
  407e80:	test   rax,rax
  407e83:	setne  al
  407e86:	jne    407e9a <__swc_fn_4fa09e82_000054_3af34d7f+0x11a>
  407e88:	test   rsi,rsi
  407e8b:	setne  al
  407e8e:	je     407e9a <__swc_fn_4fa09e82_000054_3af34d7f+0x11a>
  407e90:	cmp    DWORD PTR [rsi+0x730],0x0
  407e97:	setne  al
  407e9a:	test   al,al
  407e9c:	je     407eae <__swc_fn_4fa09e82_000054_3af34d7f+0x12e>
  407e9e:	call   410810 <__swc_fn_4fa09e82_000137_07d76562>
  407ea3:	lea    rcx,[rax+r13*1]
  407ea7:	xor    eax,eax
  407ea9:	lock cmpxchg QWORD PTR [rdi],rcx
  407eae:	jmp    407fb3 <__swc_fn_4fa09e82_000054_3af34d7f+0x233>
  407eb3:	call   410810 <__swc_fn_4fa09e82_000137_07d76562>
  407eb8:	mov    r15,rax
  407ebb:	cmp    rax,r14
  407ebe:	jb     407ecf <__swc_fn_4fa09e82_000054_3af34d7f+0x14f>
  407ec0:	xor    ecx,ecx
  407ec2:	mov    rax,r14
  407ec5:	lock cmpxchg QWORD PTR [rdi],rcx
  407eca:	cmp    rax,r14
  407ecd:	je     407ed4 <__swc_fn_4fa09e82_000054_3af34d7f+0x154>
  407ecf:	jmp    407fb3 <__swc_fn_4fa09e82_000054_3af34d7f+0x233>
  407ed4:	test   rsi,rsi
  407ed7:	je     407ef2 <__swc_fn_4fa09e82_000054_3af34d7f+0x172>
  407ed9:	cmp    r15,r13
  407edc:	jb     407ef2 <__swc_fn_4fa09e82_000054_3af34d7f+0x172>
  407ede:	mov    rax,r15
  407ee1:	sub    rax,r13
  407ee4:	mov    rcx,r12
  407ee7:	mov    rdx,rsi
  407eea:	mov    r8,rax
  407eed:	call   40b990 <__swc_fn_4fa09e82_000064_dea90857>
  407ef2:	lea    rsi,[r12+0x10]
  407ef7:	mov    rcx,rsi
  407efa:	call   409d20 <__swc_fn_4fa09e82_000141_86bb0f90>
  407eff:	mov    rax,QWORD PTR [r12+0x18]
  407f04:	mov    rdi,rax
  407f07:	test   rdi,rdi
  407f0a:	je     407f34 <__swc_fn_4fa09e82_000054_3af34d7f+0x1b4>
  407f0c:	cs nop WORD PTR [rax+rax*1+0x0]
  407f16:	cs nop WORD PTR [rax+rax*1+0x0]
  407f20:	mov    rcx,rdi
  407f23:	call   40e040 <__swc_fn_4fa09e82_000020_adca76cf>
  407f28:	mov    rax,QWORD PTR [rdi+0x10]
  407f2c:	mov    rdi,rax
  407f2f:	test   rax,rax
  407f32:	jne    407f20 <__swc_fn_4fa09e82_000054_3af34d7f+0x1a0>
  407f34:	mov    rcx,rsi
  407f37:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  407f3c:	mov    rcx,r12
  407f3f:	call   409d20 <__swc_fn_4fa09e82_000141_86bb0f90>
  407f44:	xor    esi,esi
  407f46:	cs nop WORD PTR [rax+rax*1+0x0]
  407f50:	mov    rax,QWORD PTR [r12+0x2a70]
  407f58:	cmp    rsi,rax
  407f5b:	jae    407fab <__swc_fn_4fa09e82_000054_3af34d7f+0x22b>
  407f5d:	lea    rax,[rsi+rsi*4]
  407f61:	lea    rax,[r12+rax*8+0x268]
  407f69:	mov    r8,QWORD PTR [rax]
  407f6c:	mov    r9,QWORD PTR [rax+0x8]
  407f70:	mov    r10,QWORD PTR [rax+0x10]
  407f74:	mov    rax,QWORD PTR [rax+0x20]
  407f78:	cmp    rax,r15
  407f7b:	jae    407f88 <__swc_fn_4fa09e82_000054_3af34d7f+0x208>
  407f7d:	mov    rcx,r15
  407f80:	sub    rcx,rax
  407f83:	cmp    rcx,r13
  407f86:	jae    407f8d <__swc_fn_4fa09e82_000054_3af34d7f+0x20d>
  407f88:	inc    rsi
  407f8b:	jmp    407f50 <__swc_fn_4fa09e82_000054_3af34d7f+0x1d0>
  407f8d:	mov    rcx,r12
  407f90:	mov    rdx,rsi
  407f93:	call   40b940 <__swc_fn_4fa09e82_000061_15c28ca7>
  407f98:	mov    rcx,r12
  407f9b:	mov    rdx,r8
  407f9e:	mov    r8,r9
  407fa1:	mov    r9,r10
  407fa4:	call   40e320 <__swc_fn_4fa09e82_000044_d3c2ab54>
  407fa9:	jmp    407f50 <__swc_fn_4fa09e82_000054_3af34d7f+0x1d0>
  407fab:	mov    rcx,r12
  407fae:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  407fb3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  407fbc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  407fc5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  407fce:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  407fd7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  407fe0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  407fe9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  407ff2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  407ffb:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  408004:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40800d:	add    rsp,0x178
  408014:	pop    r15
  408016:	pop    r14
  408018:	pop    rsi
  408019:	pop    rdi
  40801a:	pop    r13
  40801c:	pop    r12
  40801e:	ret
	...

0000000000408020 <__swc_fn_4fa09e82_000057_df0696cd>:
  408020:	lea    rax,[rdx-0x58]
  408024:	ret
	...

0000000000408030 <__swc_fn_4fa09e82_000060_2ca0cb05>:
  408030:	push   rsi
  408031:	push   rdi
  408032:	push   r12
  408034:	push   r13
  408036:	sub    rsp,0x68
  40803a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  408040:	mov    rsi,r9
  408043:	mov    rdi,rcx
  408046:	mov    r12,rdx
  408049:	mov    r13,r8
  40804c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  408054:	jne    408063 <__swc_fn_4fa09e82_000060_2ca0cb05+0x33>
  408056:	xor    eax,eax
  408058:	add    rsp,0x68
  40805c:	pop    r13
  40805e:	pop    r12
  408060:	pop    rdi
  408061:	pop    rsi
  408062:	ret
  408063:	mov    rcx,rdi
  408066:	call   409d20 <__swc_fn_4fa09e82_000141_86bb0f90>
  40806b:	movabs rax,0x7fffffffffffffff
  408075:	cmp    r12,rax
  408078:	mov    rax,0xffffffffffffffff
  40807f:	lea    rcx,[r12+r12*1]
  408083:	cmovbe rax,rcx
  408087:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40808e:	mov    rdx,rcx
  408091:	sub    rax,r12
  408094:	inc    rax
  408097:	xor    r8d,r8d
  40809a:	test   rcx,rcx
  40809d:	jbe    4080c8 <__swc_fn_4fa09e82_000060_2ca0cb05+0x98>
  40809f:	nop
  4080a0:	lea    r9,[r8+r8*4]
  4080a4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  4080ac:	sub    r9,r12
  4080af:	cmp    r9,rax
  4080b2:	jae    4080bf <__swc_fn_4fa09e82_000060_2ca0cb05+0x8f>
  4080b4:	mov    rdx,r8
  4080b7:	mov    rax,r9
  4080ba:	test   r9,r9
  4080bd:	je     4080c8 <__swc_fn_4fa09e82_000060_2ca0cb05+0x98>
  4080bf:	add    r8,0x1
  4080c3:	cmp    r8,rcx
  4080c6:	jb     4080a0 <__swc_fn_4fa09e82_000060_2ca0cb05+0x70>
  4080c8:	mov    rax,QWORD PTR [rdi+0x2a70]
  4080cf:	cmp    rdx,rax
  4080d2:	jne    4080ef <__swc_fn_4fa09e82_000060_2ca0cb05+0xbf>
  4080d4:	mov    rcx,rdi
  4080d7:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  4080dc:	xor    eax,eax
  4080de:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  4080e4:	add    rsp,0x68
  4080e8:	pop    r13
  4080ea:	pop    r12
  4080ec:	pop    rdi
  4080ed:	pop    rsi
  4080ee:	ret
  4080ef:	lea    rax,[rdx+rdx*4]
  4080f3:	lea    rax,[rdi+rax*8+0x268]
  4080fb:	vmovups xmm6,XMMWORD PTR [rax]
  4080ff:	mov    r8,QWORD PTR [rax+0x10]
  408103:	mov    rcx,rdi
  408106:	call   40b940 <__swc_fn_4fa09e82_000061_15c28ca7>
  40810b:	vpshufd xmm0,xmm6,0xee
  408110:	vmovsd QWORD PTR [r13+0x0],xmm0
  408116:	mov    QWORD PTR [rsi],r8
  408119:	mov    rcx,rdi
  40811c:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  408121:	vmovq  rax,xmm6
  408126:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40812c:	add    rsp,0x68
  408130:	pop    r13
  408132:	pop    r12
  408134:	pop    rdi
  408135:	pop    rsi
  408136:	ret
	...

0000000000408140 <__swc_fn_4fa09e82_000063_b304235a>:
  408140:	push   r12
  408142:	push   r13
  408144:	push   r14
  408146:	push   r15
  408148:	push   rdi
  408149:	push   rsi
  40814a:	sub    rsp,0x148
  408151:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40815a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  408163:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40816c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  408175:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40817e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  408187:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  408190:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  408199:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  4081a2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  4081ab:	mov    r12,r9
  4081ae:	mov    r13,rcx
  4081b1:	mov    r14,rdx
  4081b4:	mov    r15,r8
  4081b7:	test   rdx,rdx
  4081ba:	jne    4081ce <__swc_fn_4fa09e82_000063_b304235a+0x8e>
  4081bc:	add    rsp,0x148
  4081c3:	pop    rsi
  4081c4:	pop    rdi
  4081c5:	pop    r15
  4081c7:	pop    r14
  4081c9:	pop    r13
  4081cb:	pop    r12
  4081cd:	ret
  4081ce:	cmp    r12,0x200000
  4081d5:	ja     408267 <__swc_fn_4fa09e82_000063_b304235a+0x127>
  4081db:	lea    rax,[rip+0x19e26]        # 422008 <__swc_data_base_4fa09e82+0x8>
  4081e2:	mov    rax,QWORD PTR [rax]
  4081e5:	cmp    rax,0xffffffffffffffff
  4081e9:	je     4081f8 <__swc_fn_4fa09e82_000063_b304235a+0xb8>
  4081eb:	mov    eax,eax
  4081ed:	mov    edi,eax
  4081ef:	xor    eax,eax
  4081f1:	call   407000 <pthread_getspecific@plt>
  4081f6:	jmp    4081fa <__swc_fn_4fa09e82_000063_b304235a+0xba>
  4081f8:	xor    eax,eax
  4081fa:	test   rax,rax
  4081fd:	je     408204 <__swc_fn_4fa09e82_000063_b304235a+0xc4>
  4081ff:	mov    rsi,rax
  408202:	jmp    408214 <__swc_fn_4fa09e82_000063_b304235a+0xd4>
  408204:	call   407ae0 <__swc_fn_4fa09e82_000036_cd1a4e8c>
  408209:	mov    rcx,rax
  40820c:	call   410760 <__swc_fn_4fa09e82_000134_5f757033>
  408211:	mov    rsi,rax
  408214:	test   rsi,rsi
  408217:	je     408267 <__swc_fn_4fa09e82_000063_b304235a+0x127>
  408219:	cmp    QWORD PTR [rsi],r13
  40821c:	jne    408267 <__swc_fn_4fa09e82_000063_b304235a+0x127>
  40821e:	cmp    DWORD PTR [rsi+0x20],0x0
  408222:	jne    408267 <__swc_fn_4fa09e82_000063_b304235a+0x127>
  408224:	cmp    DWORD PTR [rsi+0x730],0x10
  40822b:	jae    408267 <__swc_fn_4fa09e82_000063_b304235a+0x127>
  40822d:	mov    eax,DWORD PTR [rsi+0x730]
  408233:	lea    rdi,[rax+rax*4]
  408237:	lea    rdi,[rsi+rdi*8+0x738]
  40823f:	mov    QWORD PTR [rdi],r14
  408242:	mov    QWORD PTR [rdi+0x8],r15
  408246:	mov    QWORD PTR [rdi+0x10],r12
  40824a:	mov    QWORD PTR [rdi+0x18],0x0
  408252:	call   410810 <__swc_fn_4fa09e82_000137_07d76562>
  408257:	mov    QWORD PTR [rdi+0x20],rax
  40825b:	add    DWORD PTR [rsi+0x730],0x1
  408262:	jmp    4083c6 <__swc_fn_4fa09e82_000063_b304235a+0x286>
  408267:	mov    rcx,r13
  40826a:	call   40ea50 <__swc_fn_4fa09e82_000062_ad030a10>
  40826f:	mov    rsi,rax
  408272:	cmp    r12,rax
  408275:	jbe    4082aa <__swc_fn_4fa09e82_000063_b304235a+0x16a>
  408277:	cmp    r12,0x10000000
  40827e:	seta   al
  408281:	ja     408290 <__swc_fn_4fa09e82_000063_b304235a+0x150>
  408283:	mov    rax,QWORD PTR [r13+0x2a70]
  40828a:	test   rax,rax
  40828d:	setne  al
  408290:	test   al,al
  408292:	je     4082aa <__swc_fn_4fa09e82_000063_b304235a+0x16a>
  408294:	mov    rcx,r13
  408297:	mov    rdx,r14
  40829a:	mov    r8,r15
  40829d:	mov    r9,r12
  4082a0:	call   40e320 <__swc_fn_4fa09e82_000044_d3c2ab54>
  4082a5:	jmp    4083c6 <__swc_fn_4fa09e82_000063_b304235a+0x286>
  4082aa:	call   410810 <__swc_fn_4fa09e82_000137_07d76562>
  4082af:	mov    rdi,rax
  4082b2:	mov    rcx,r13
  4082b5:	call   409d20 <__swc_fn_4fa09e82_000141_86bb0f90>
  4082ba:	cmp    QWORD PTR [r13+0x2a70],0x0
  4082c2:	je     40837a <__swc_fn_4fa09e82_000063_b304235a+0x23a>
  4082c8:	nop    DWORD PTR [rax+rax*1+0x0]
  4082d0:	cmp    QWORD PTR [r13+0x2a70],0x100
  4082db:	jae    4082f0 <__swc_fn_4fa09e82_000063_b304235a+0x1b0>
  4082dd:	mov    rax,QWORD PTR [r13+0x2a68]
  4082e4:	add    rax,r12
  4082e7:	cmp    rax,rsi
  4082ea:	jbe    40837a <__swc_fn_4fa09e82_000063_b304235a+0x23a>
  4082f0:	xor    eax,eax
  4082f2:	mov    rcx,QWORD PTR [r13+0x2a70]
  4082f9:	mov    edx,0x1
  4082fe:	cmp    rcx,0x1
  408302:	jbe    408339 <__swc_fn_4fa09e82_000063_b304235a+0x1f9>
  408304:	cs nop WORD PTR [rax+rax*1+0x0]
  40830e:	xchg   ax,ax
  408310:	lea    r8,[rdx+rdx*4]
  408314:	lea    r8,[r13+r8*8+0x268]
  40831c:	lea    r9,[rax+rax*4]
  408320:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  408328:	cmp    QWORD PTR [r8+0x18],r9
  40832c:	cmovb  rax,rdx
  408330:	add    rdx,0x1
  408334:	cmp    rdx,rcx
  408337:	jb     408310 <__swc_fn_4fa09e82_000063_b304235a+0x1d0>
  408339:	lea    rcx,[rax+rax*4]
  40833d:	lea    rcx,[r13+rcx*8+0x268]
  408345:	mov    r8,QWORD PTR [rcx]
  408348:	mov    r9,QWORD PTR [rcx+0x8]
  40834c:	mov    r10,QWORD PTR [rcx+0x10]
  408350:	mov    rcx,r13
  408353:	mov    rdx,rax
  408356:	call   40b940 <__swc_fn_4fa09e82_000061_15c28ca7>
  40835b:	mov    rcx,r13
  40835e:	mov    rdx,r8
  408361:	mov    r8,r9
  408364:	mov    r9,r10
  408367:	call   40e320 <__swc_fn_4fa09e82_000044_d3c2ab54>
  40836c:	cmp    QWORD PTR [r13+0x2a70],0x0
  408374:	jne    4082d0 <__swc_fn_4fa09e82_000063_b304235a+0x190>
  40837a:	add    QWORD PTR [r13+0x2a78],0x1
  408382:	mov    rax,QWORD PTR [r13+0x2a70]
  408389:	lea    rax,[rax+rax*4]
  40838d:	lea    rax,[r13+rax*8+0x268]
  408395:	mov    QWORD PTR [rax],r14
  408398:	mov    QWORD PTR [rax+0x8],r15
  40839c:	mov    QWORD PTR [rax+0x10],r12
  4083a0:	mov    rcx,QWORD PTR [r13+0x2a78]
  4083a7:	mov    QWORD PTR [rax+0x18],rcx
  4083ab:	mov    QWORD PTR [rax+0x20],rdi
  4083af:	add    QWORD PTR [r13+0x2a68],r12
  4083b6:	add    QWORD PTR [r13+0x2a70],0x1
  4083be:	mov    rcx,r13
  4083c1:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  4083c6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  4083cf:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  4083d8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  4083e1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  4083ea:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  4083f3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  4083fc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  408405:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40840e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  408417:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  408420:	add    rsp,0x148
  408427:	pop    rsi
  408428:	pop    rdi
  408429:	pop    r15
  40842b:	pop    r14
  40842d:	pop    r13
  40842f:	pop    r12
  408431:	ret
	...

0000000000408440 <__swc_fn_4fa09e82_000066_d9ee99ea>:
  408440:	push   rbx
  408441:	push   r12
  408443:	push   r13
  408445:	push   r14
  408447:	push   r15
  408449:	push   rdi
  40844a:	push   rsi
  40844b:	sub    rsp,0xf0
  408452:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  408458:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40845e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  408464:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40846a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  408473:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40847c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  408485:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40848e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  408497:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  4084a0:	mov    eax,r8d
  4084a3:	mov    rbx,rcx
  4084a6:	mov    r12,rdx
  4084a9:	mov    QWORD PTR [rsp+0x18],rdx
  4084ae:	mov    ecx,DWORD PTR [r12+0x58]
  4084b3:	mov    r13d,ecx
  4084b6:	cmp    ecx,0x10
  4084b9:	mov    ecx,0x10
  4084be:	cmovb  r13d,ecx
  4084c2:	test   r13d,r13d
  4084c5:	mov    rcx,r13
  4084c8:	mov    edx,0x8
  4084cd:	cmove  ecx,edx
  4084d0:	dec    rcx
  4084d3:	mov    rdx,0xffffffffffffffff
  4084da:	sub    rdx,rcx
  4084dd:	xor    r14d,r14d
  4084e0:	mov    r8,rcx
  4084e3:	not    r8
  4084e6:	lea    rcx,[rcx+0x58]
  4084ea:	and    rcx,r8
  4084ed:	cmp    rdx,0x58
  4084f1:	cmovae r14,rcx
  4084f5:	cmp    eax,0xffffffff
  4084f8:	jne    408501 <__swc_fn_4fa09e82_000066_d9ee99ea+0xc1>
  4084fa:	mov    r15,QWORD PTR [r12+0x48]
  4084ff:	jmp    408533 <__swc_fn_4fa09e82_000066_d9ee99ea+0xf3>
  408501:	test   eax,eax
  408503:	jne    40850c <__swc_fn_4fa09e82_000066_d9ee99ea+0xcc>
  408505:	mov    eax,0x8
  40850a:	jmp    408530 <__swc_fn_4fa09e82_000066_d9ee99ea+0xf0>
  40850c:	cmp    eax,0x8
  40850f:	ja     408517 <__swc_fn_4fa09e82_000066_d9ee99ea+0xd7>
  408511:	shl    rax,0x4
  408515:	jmp    408530 <__swc_fn_4fa09e82_000066_d9ee99ea+0xf0>
  408517:	lea    eax,[rax-0x9]
  40851a:	mov    ecx,eax
  40851c:	shr    ecx,0x2
  40851f:	and    eax,0x3
  408522:	lea    ecx,[rcx+0x7]
  408525:	lea    ecx,[rcx-0x2]
  408528:	lea    eax,[rax+0x5]
  40852b:	shlx   rax,rax,rcx
  408530:	mov    r15,rax
  408533:	lea    rax,[r14+r13*1]
  408537:	mov    rcx,0xffffffffffffffff
  40853e:	sub    rcx,rax
  408541:	cmp    r15,rcx
  408544:	jbe    408554 <__swc_fn_4fa09e82_000066_d9ee99ea+0x114>
  408546:	mov    QWORD PTR [r12+0x40],0x0
  40854f:	jmp    408926 <__swc_fn_4fa09e82_000066_d9ee99ea+0x4e6>
  408554:	mov    QWORD PTR [rsp+0x20],r13
  408559:	lea    r13,[rsp+0x8]
  40855e:	add    rax,r15
  408561:	mov    ecx,0x1000
  408566:	test   ecx,ecx
  408568:	mov    edx,0x8
  40856d:	cmove  ecx,edx
  408570:	dec    rcx
  408573:	mov    rdx,0xffffffffffffffff
  40857a:	sub    rdx,rcx
  40857d:	cmp    rax,rdx
  408580:	jbe    40858c <__swc_fn_4fa09e82_000066_d9ee99ea+0x14c>
  408582:	mov    QWORD PTR [r13+0x0],0x0
  40858a:	jmp    408599 <__swc_fn_4fa09e82_000066_d9ee99ea+0x159>
  40858c:	add    rax,rcx
  40858f:	andn   rax,rcx,rax
  408594:	mov    QWORD PTR [rsp+0x8],rax
  408599:	cmp    QWORD PTR [r13+0x0],0x0
  40859e:	jne    4085ae <__swc_fn_4fa09e82_000066_d9ee99ea+0x16e>
  4085a0:	mov    QWORD PTR [r12+0x40],0x0
  4085a9:	jmp    408926 <__swc_fn_4fa09e82_000066_d9ee99ea+0x4e6>
  4085ae:	mov    QWORD PTR [rsp+0x30],r15
  4085b3:	xor    r15d,r15d
  4085b6:	mov    QWORD PTR [rsp+0x38],0x0
  4085bf:	lea    r12,[rsp+0x10]
  4085c4:	mov    QWORD PTR [rsp+0x28],r14
  4085c9:	mov    r14,QWORD PTR [rsp+0x8]
  4085ce:	mov    QWORD PTR [rsp+0x10],r14
  4085d3:	cmp    r14,0x10000
  4085da:	ja     4085e1 <__swc_fn_4fa09e82_000066_d9ee99ea+0x1a1>
  4085dc:	mov    rax,r14
  4085df:	jmp    408632 <__swc_fn_4fa09e82_000066_d9ee99ea+0x1f2>
  4085e1:	xor    eax,eax
  4085e3:	lea    rcx,[r14-0x1]
  4085e7:	lzcnt  rax,rcx
  4085ec:	mov    ecx,0x3f
  4085f1:	sub    rcx,rax
  4085f4:	mov    eax,0x1
  4085f9:	lea    rcx,[rcx-0x3]
  4085fd:	shl    rax,cl
  408600:	mov    rcx,rax
  408603:	cmp    rax,0x1000
  40860a:	mov    eax,0x1000
  40860f:	cmovb  rcx,rax
  408613:	mov    rdx,0xffffffffffffffff
  40861a:	sub    rdx,rcx
  40861d:	mov    rax,r14
  408620:	lea    r8,[r14+rcx*1-0x1]
  408625:	neg    rcx
  408628:	and    r8,rcx
  40862b:	cmp    r14,rdx
  40862e:	cmovbe rax,r8
  408632:	mov    QWORD PTR [rsp+0x8],rax
  408637:	lea    rax,[rip+0x199ca]        # 422008 <__swc_data_base_4fa09e82+0x8>
  40863e:	mov    rax,QWORD PTR [rax]
  408641:	cmp    rax,0xffffffffffffffff
  408645:	je     408654 <__swc_fn_4fa09e82_000066_d9ee99ea+0x214>
  408647:	mov    eax,eax
  408649:	mov    edi,eax
  40864b:	xor    eax,eax
  40864d:	call   407000 <pthread_getspecific@plt>
  408652:	jmp    408656 <__swc_fn_4fa09e82_000066_d9ee99ea+0x216>
  408654:	xor    eax,eax
  408656:	test   rax,rax
  408659:	jne    408668 <__swc_fn_4fa09e82_000066_d9ee99ea+0x228>
  40865b:	call   407ae0 <__swc_fn_4fa09e82_000036_cd1a4e8c>
  408660:	mov    rcx,rax
  408663:	call   410760 <__swc_fn_4fa09e82_000134_5f757033>
  408668:	test   rax,rax
  40866b:	je     40875c <__swc_fn_4fa09e82_000066_d9ee99ea+0x31c>
  408671:	cmp    QWORD PTR [rax],rbx
  408674:	jne    40875c <__swc_fn_4fa09e82_000066_d9ee99ea+0x31c>
  40867a:	cmp    DWORD PTR [rax+0x20],0x0
  40867e:	jne    40875c <__swc_fn_4fa09e82_000066_d9ee99ea+0x31c>
  408684:	mov    rcx,QWORD PTR [rsp+0x8]
  408689:	movabs rdx,0x7fffffffffffffff
  408693:	cmp    rcx,rdx
  408696:	mov    rdx,0xffffffffffffffff
  40869d:	lea    r8,[rcx+rcx*1]
  4086a1:	cmovbe rdx,r8
  4086a5:	mov    r8d,DWORD PTR [rax+0x730]
  4086ac:	mov    r9d,r8d
  4086af:	sub    rdx,rcx
  4086b2:	inc    rdx
  4086b5:	xor    r10d,r10d
  4086b8:	test   r8,r8
  4086bb:	jbe    4086eb <__swc_fn_4fa09e82_000066_d9ee99ea+0x2ab>
  4086bd:	nop    DWORD PTR [rax]
  4086c0:	mov    r11d,r10d
  4086c3:	lea    r11,[r11+r11*4]
  4086c7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  4086cf:	sub    r11,rcx
  4086d2:	cmp    r11,rdx
  4086d5:	jae    4086e2 <__swc_fn_4fa09e82_000066_d9ee99ea+0x2a2>
  4086d7:	mov    r9d,r10d
  4086da:	mov    rdx,r11
  4086dd:	test   r11,r11
  4086e0:	je     4086eb <__swc_fn_4fa09e82_000066_d9ee99ea+0x2ab>
  4086e2:	add    r10,0x1
  4086e6:	cmp    r10,r8
  4086e9:	jb     4086c0 <__swc_fn_4fa09e82_000066_d9ee99ea+0x280>
  4086eb:	mov    ecx,DWORD PTR [rax+0x730]
  4086f1:	cmp    r9d,ecx
  4086f4:	jne    4086fa <__swc_fn_4fa09e82_000066_d9ee99ea+0x2ba>
  4086f6:	xor    eax,eax
  4086f8:	jmp    408759 <__swc_fn_4fa09e82_000066_d9ee99ea+0x319>
  4086fa:	lea    rcx,[r9+r9*4]
  4086fe:	lea    rcx,[rax+rcx*8+0x738]
  408706:	vmovups xmm0,XMMWORD PTR [rcx]
  40870a:	mov    rdx,QWORD PTR [rcx+0x10]
  40870e:	sub    DWORD PTR [rax+0x730],0x1
  408715:	mov    r8d,DWORD PTR [rax+0x730]
  40871c:	lea    r8,[r8+r8*4]
  408720:	lea    r8,[rax+r8*8+0x738]
  408728:	vmovups xmm1,XMMWORD PTR [r8]
  40872d:	vmovups XMMWORD PTR [rcx],xmm1
  408731:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  408737:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40873c:	mov    rax,QWORD PTR [r8+0x20]
  408740:	mov    QWORD PTR [rcx+0x20],rax
  408744:	vpshufd xmm1,xmm0,0xee
  408749:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40874f:	mov    QWORD PTR [rsp+0x10],rdx
  408754:	vmovq  rax,xmm0
  408759:	mov    r15,rax
  40875c:	test   r15,r15
  40875f:	jne    408777 <__swc_fn_4fa09e82_000066_d9ee99ea+0x337>
  408761:	mov    rcx,rbx
  408764:	mov    rdx,QWORD PTR [rsp+0x8]
  408769:	mov    r8,r13
  40876c:	mov    r9,r12
  40876f:	call   408030 <__swc_fn_4fa09e82_000060_2ca0cb05>
  408774:	mov    r15,rax
  408777:	test   r15,r15
  40877a:	je     4087bb <__swc_fn_4fa09e82_000066_d9ee99ea+0x37b>
  40877c:	cmp    QWORD PTR [r12],r14
  408780:	jae    4087bb <__swc_fn_4fa09e82_000066_d9ee99ea+0x37b>
  408782:	mov    rax,r15
  408785:	add    rax,QWORD PTR [r12]
  408789:	mov    rdx,r14
  40878c:	sub    rdx,QWORD PTR [r12]
  408790:	mov    rcx,rax
  408793:	call   40de70 <__swc_fn_4fa09e82_000008_f7acedb0>
  408798:	test   al,al
  40879a:	je     4087a3 <__swc_fn_4fa09e82_000066_d9ee99ea+0x363>
  40879c:	mov    QWORD PTR [rsp+0x10],r14
  4087a1:	jmp    4087bb <__swc_fn_4fa09e82_000066_d9ee99ea+0x37b>
  4087a3:	mov    rcx,rbx
  4087a6:	mov    rdx,r15
  4087a9:	mov    r8,QWORD PTR [rsp+0x8]
  4087ae:	mov    r9,QWORD PTR [rsp+0x10]
  4087b3:	call   408140 <__swc_fn_4fa09e82_000063_b304235a>
  4087b8:	xor    r15d,r15d
  4087bb:	test   r15,r15
  4087be:	jne    40883a <__swc_fn_4fa09e82_000066_d9ee99ea+0x3fa>
  4087c0:	cmp    r14,0x10000
  4087c7:	ja     4087ce <__swc_fn_4fa09e82_000066_d9ee99ea+0x38e>
  4087c9:	mov    rax,r14
  4087cc:	jmp    40881f <__swc_fn_4fa09e82_000066_d9ee99ea+0x3df>
  4087ce:	xor    eax,eax
  4087d0:	lea    rcx,[r14-0x1]
  4087d4:	lzcnt  rax,rcx
  4087d9:	mov    ecx,0x3f
  4087de:	sub    rcx,rax
  4087e1:	mov    eax,0x1
  4087e6:	lea    rcx,[rcx-0x3]
  4087ea:	shl    rax,cl
  4087ed:	mov    rcx,rax
  4087f0:	cmp    rax,0x1000
  4087f7:	mov    eax,0x1000
  4087fc:	cmovb  rcx,rax
  408800:	mov    rdx,0xffffffffffffffff
  408807:	sub    rdx,rcx
  40880a:	mov    rax,r14
  40880d:	lea    r8,[r14+rcx*1-0x1]
  408812:	neg    rcx
  408815:	and    r8,rcx
  408818:	cmp    r14,rdx
  40881b:	cmovbe rax,r8
  40881f:	mov    QWORD PTR [rsp+0x8],rax
  408824:	mov    QWORD PTR [rsp+0x10],r14
  408829:	mov    rcx,rbx
  40882c:	mov    rdx,rax
  40882f:	mov    r8,r14
  408832:	call   407ba0 <__swc_fn_4fa09e82_000042_c90d80c1>
  408837:	mov    r15,rax
  40883a:	test   r15,r15
  40883d:	jne    40884b <__swc_fn_4fa09e82_000066_d9ee99ea+0x40b>
  40883f:	mov    r13,QWORD PTR [rsp+0x20]
  408844:	mov    rsi,QWORD PTR [rsp+0x38]
  408849:	jmp    408887 <__swc_fn_4fa09e82_000066_d9ee99ea+0x447>
  40884b:	mov    rax,r15
  40884e:	add    rax,QWORD PTR [rsp+0x28]
  408853:	mov    r13,QWORD PTR [rsp+0x20]
  408858:	test   r13d,r13d
  40885b:	mov    rcx,r13
  40885e:	mov    edx,0x8
  408863:	cmove  ecx,edx
  408866:	dec    rcx
  408869:	mov    rdx,0xffffffffffffffff
  408870:	sub    rdx,rcx
  408873:	cmp    rax,rdx
  408876:	jbe    40887c <__swc_fn_4fa09e82_000066_d9ee99ea+0x43c>
  408878:	xor    eax,eax
  40887a:	jmp    408884 <__swc_fn_4fa09e82_000066_d9ee99ea+0x444>
  40887c:	add    rax,rcx
  40887f:	andn   rax,rcx,rax
  408884:	mov    rsi,rax
  408887:	mov    rax,QWORD PTR [rsp+0x8]
  40888c:	test   r15,r15
  40888f:	je     408898 <__swc_fn_4fa09e82_000066_d9ee99ea+0x458>
  408891:	mov    rdi,QWORD PTR [rsp+0x18]
  408896:	jmp    4088aa <__swc_fn_4fa09e82_000066_d9ee99ea+0x46a>
  408898:	mov    rdi,QWORD PTR [rsp+0x18]
  40889d:	mov    QWORD PTR [rdi+0x40],0x0
  4088a5:	jmp    408926 <__swc_fn_4fa09e82_000066_d9ee99ea+0x4e6>
  4088aa:	lea    rdx,[rsi-0x58]
  4088ae:	mov    QWORD PTR [rsi-0x58],r15
  4088b2:	mov    QWORD PTR [rsi-0x50],rax
  4088b6:	mov    rax,QWORD PTR [rsp+0x10]
  4088bb:	mov    QWORD PTR [rsi-0x48],rax
  4088bf:	mov    QWORD PTR [rsi-0x40],rsi
  4088c3:	mov    rax,QWORD PTR [rdi+0x48]
  4088c7:	mov    QWORD PTR [rsi-0x38],rax
  4088cb:	mov    rax,QWORD PTR [rsp+0x30]
  4088d0:	mov    QWORD PTR [rsi-0x30],rax
  4088d4:	mov    DWORD PTR [rsi-0x10],r13d
  4088d8:	mov    QWORD PTR [rsi-0x28],0x0
  4088e0:	mov    QWORD PTR [rsi-0x20],0x0
  4088e8:	add    r15,QWORD PTR [r12]
  4088ec:	sub    r15,rsi
  4088ef:	mov    QWORD PTR [rsi-0x30],r15
  4088f3:	mov    rcx,QWORD PTR [rbx+0x250]
  4088fa:	nop    WORD PTR [rax+rax*1+0x0]
  408900:	lea    r8,[rcx+r15*1]
  408904:	mov    rax,rcx
  408907:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  408910:	cmp    rax,rcx
  408913:	je     40891a <__swc_fn_4fa09e82_000066_d9ee99ea+0x4da>
  408915:	mov    rcx,rax
  408918:	jmp    408900 <__swc_fn_4fa09e82_000066_d9ee99ea+0x4c0>
  40891a:	mov    rcx,rbx
  40891d:	call   40b8b0 <__swc_fn_4fa09e82_000058_7e1dbcb0>
  408922:	mov    QWORD PTR [rdi+0x40],rsi
  408926:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40892c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  408932:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  408938:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40893e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  408947:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  408950:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  408959:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  408962:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40896b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  408974:	add    rsp,0xf0
  40897b:	pop    rsi
  40897c:	pop    rdi
  40897d:	pop    r15
  40897f:	pop    r14
  408981:	pop    r13
  408983:	pop    r12
  408985:	pop    rbx
  408986:	ret
	...

0000000000408990 <__swc_fn_4fa09e82_000069_f3aa21af>:
  408990:	push   rbx
  408991:	push   r12
  408993:	push   rdi
  408994:	push   rsi
  408995:	sub    rsp,0xb8
  40899c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4089a2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4089a8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4089ae:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4089b4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4089ba:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4089c0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4089c6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4089cf:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4089d8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4089e1:	mov    rbx,rdx
  4089e4:	mov    r12,rcx
  4089e7:	cmp    DWORD PTR [rbx+0x58],0x0
  4089eb:	je     408a05 <__swc_fn_4fa09e82_000069_f3aa21af+0x75>
  4089ed:	mov    eax,DWORD PTR [rbx+0x58]
  4089f0:	sub    eax,0x1
  4089f3:	test   DWORD PTR [rbx+0x58],eax
  4089f6:	je     408a05 <__swc_fn_4fa09e82_000069_f3aa21af+0x75>
  4089f8:	mov    QWORD PTR [rbx+0x40],0x0
  408a00:	jmp    408c17 <__swc_fn_4fa09e82_000069_f3aa21af+0x287>
  408a05:	cmp    QWORD PTR [rbx+0x48],0x0
  408a0a:	jne    408a19 <__swc_fn_4fa09e82_000069_f3aa21af+0x89>
  408a0c:	mov    QWORD PTR [rbx+0x40],0x0
  408a14:	jmp    408c17 <__swc_fn_4fa09e82_000069_f3aa21af+0x287>
  408a19:	lea    rax,[rsp+0x8]
  408a1e:	mov    rcx,QWORD PTR [rbx+0x48]
  408a22:	cmp    rcx,0x8
  408a26:	ja     408a30 <__swc_fn_4fa09e82_000069_f3aa21af+0xa0>
  408a28:	mov    DWORD PTR [rax],0x0
  408a2e:	jmp    408a8b <__swc_fn_4fa09e82_000069_f3aa21af+0xfb>
  408a30:	cmp    rcx,0x80
  408a37:	ja     408a47 <__swc_fn_4fa09e82_000069_f3aa21af+0xb7>
  408a39:	lea    rcx,[rcx+0xf]
  408a3d:	shr    rcx,0x4
  408a41:	mov    DWORD PTR [rsp+0x8],ecx
  408a45:	jmp    408a8b <__swc_fn_4fa09e82_000069_f3aa21af+0xfb>
  408a47:	cmp    rcx,0x10000
  408a4e:	jbe    408a58 <__swc_fn_4fa09e82_000069_f3aa21af+0xc8>
  408a50:	mov    DWORD PTR [rax],0xffffffff
  408a56:	jmp    408a8b <__swc_fn_4fa09e82_000069_f3aa21af+0xfb>
  408a58:	dec    rcx
  408a5b:	xor    edx,edx
  408a5d:	lzcnt  rdx,rcx
  408a62:	mov    r8d,0x3f
  408a68:	sub    r8d,edx
  408a6b:	lea    edx,[r8-0x2]
  408a6f:	shrx   rcx,rcx,rdx
  408a74:	and    ecx,0x3
  408a77:	lea    edx,[r8-0x7]
  408a7b:	lea    edx,[rdx*4+0x0]
  408a82:	lea    edx,[rdx+0x9]
  408a85:	add    edx,ecx
  408a87:	mov    DWORD PTR [rsp+0x8],edx
  408a8b:	cmp    DWORD PTR [rax],0x0
  408a8e:	jne    408a9e <__swc_fn_4fa09e82_000069_f3aa21af+0x10e>
  408a90:	cmp    DWORD PTR [rbx+0x58],0x8
  408a94:	jbe    408a9e <__swc_fn_4fa09e82_000069_f3aa21af+0x10e>
  408a96:	mov    DWORD PTR [rsp+0x8],0x1
  408a9e:	cmp    DWORD PTR [rbx+0x58],0x10
  408aa2:	jbe    408b21 <__swc_fn_4fa09e82_000069_f3aa21af+0x191>
  408aa8:	cmp    DWORD PTR [rbx+0x58],0x40
  408aac:	ja     408b21 <__swc_fn_4fa09e82_000069_f3aa21af+0x191>
  408aae:	cmp    DWORD PTR [rax],0xffffffff
  408ab1:	je     408b21 <__swc_fn_4fa09e82_000069_f3aa21af+0x191>
  408ab3:	mov    ecx,DWORD PTR [rsp+0x8]
  408ab7:	mov    edx,DWORD PTR [rbx+0x58]
  408aba:	dec    rdx
  408abd:	cmp    ecx,0x2d
  408ac0:	jae    408b18 <__swc_fn_4fa09e82_000069_f3aa21af+0x188>
  408ac2:	cs nop WORD PTR [rax+rax*1+0x0]
  408acc:	nop    DWORD PTR [rax+0x0]
  408ad0:	mov    r8d,ecx
  408ad3:	test   ecx,ecx
  408ad5:	jne    408adf <__swc_fn_4fa09e82_000069_f3aa21af+0x14f>
  408ad7:	mov    r8d,0x8
  408add:	jmp    408b0b <__swc_fn_4fa09e82_000069_f3aa21af+0x17b>
  408adf:	cmp    r8d,0x8
  408ae3:	ja     408aeb <__swc_fn_4fa09e82_000069_f3aa21af+0x15b>
  408ae5:	shl    r8,0x4
  408ae9:	jmp    408b0b <__swc_fn_4fa09e82_000069_f3aa21af+0x17b>
  408aeb:	lea    r8d,[r8-0x9]
  408aef:	mov    r9d,r8d
  408af2:	shr    r9d,0x2
  408af6:	and    r8d,0x3
  408afa:	lea    r9d,[r9+0x7]
  408afe:	lea    r9d,[r9-0x2]
  408b02:	lea    r8d,[r8+0x5]
  408b06:	shlx   r8,r8,r9
  408b0b:	test   r8,rdx
  408b0e:	je     408b1d <__swc_fn_4fa09e82_000069_f3aa21af+0x18d>
  408b10:	add    ecx,0x1
  408b13:	cmp    ecx,0x2d
  408b16:	jb     408ad0 <__swc_fn_4fa09e82_000069_f3aa21af+0x140>
  408b18:	mov    ecx,0xffffffff
  408b1d:	mov    DWORD PTR [rsp+0x8],ecx
  408b21:	mov    ecx,DWORD PTR [rsp+0x8]
  408b25:	cmp    ecx,0xffffffff
  408b28:	je     408b30 <__swc_fn_4fa09e82_000069_f3aa21af+0x1a0>
  408b2a:	cmp    DWORD PTR [rbx+0x58],0x40
  408b2e:	jbe    408b43 <__swc_fn_4fa09e82_000069_f3aa21af+0x1b3>
  408b30:	mov    rcx,r12
  408b33:	mov    rdx,rbx
  408b36:	mov    r8d,DWORD PTR [rax]
  408b39:	call   408440 <__swc_fn_4fa09e82_000066_d9ee99ea>
  408b3e:	jmp    408c17 <__swc_fn_4fa09e82_000069_f3aa21af+0x287>
  408b43:	lea    rax,[rip+0x194be]        # 422008 <__swc_data_base_4fa09e82+0x8>
  408b4a:	mov    rax,QWORD PTR [rax]
  408b4d:	cmp    rax,0xffffffffffffffff
  408b51:	je     408b60 <__swc_fn_4fa09e82_000069_f3aa21af+0x1d0>
  408b53:	mov    eax,eax
  408b55:	mov    edi,eax
  408b57:	xor    eax,eax
  408b59:	call   407000 <pthread_getspecific@plt>
  408b5e:	jmp    408b62 <__swc_fn_4fa09e82_000069_f3aa21af+0x1d2>
  408b60:	xor    eax,eax
  408b62:	test   rax,rax
  408b65:	jne    408b74 <__swc_fn_4fa09e82_000069_f3aa21af+0x1e4>
  408b67:	call   407ae0 <__swc_fn_4fa09e82_000036_cd1a4e8c>
  408b6c:	mov    rcx,rax
  408b6f:	call   410760 <__swc_fn_4fa09e82_000134_5f757033>
  408b74:	test   rax,rax
  408b77:	je     408b84 <__swc_fn_4fa09e82_000069_f3aa21af+0x1f4>
  408b79:	cmp    QWORD PTR [rax],r12
  408b7c:	jne    408b84 <__swc_fn_4fa09e82_000069_f3aa21af+0x1f4>
  408b7e:	cmp    DWORD PTR [rax+0x20],0x0
  408b82:	je     408b8f <__swc_fn_4fa09e82_000069_f3aa21af+0x1ff>
  408b84:	mov    rcx,r12
  408b87:	mov    rdx,rax
  408b8a:	call   40b4f0 <__swc_fn_4fa09e82_000046_d8bd27c3>
  408b8f:	test   rax,rax
  408b92:	jne    408b9e <__swc_fn_4fa09e82_000069_f3aa21af+0x20e>
  408b94:	mov    QWORD PTR [rbx+0x40],0x0
  408b9c:	jmp    408c17 <__swc_fn_4fa09e82_000069_f3aa21af+0x287>
  408b9e:	lea    r8,[rsp+0xc]
  408ba3:	mov    ecx,DWORD PTR [rsp+0x8]
  408ba7:	mov    DWORD PTR [rsp+0xc],ecx
  408bab:	mov    ecx,DWORD PTR [r8]
  408bae:	lea    rcx,[rcx+rcx*4]
  408bb2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  408bb7:	test   rcx,rcx
  408bba:	je     408bf3 <__swc_fn_4fa09e82_000069_f3aa21af+0x263>
  408bbc:	mov    rdx,QWORD PTR [rcx]
  408bbf:	test   rdx,rdx
  408bc2:	je     408bd0 <__swc_fn_4fa09e82_000069_f3aa21af+0x240>
  408bc4:	mov    r9,QWORD PTR [rdx]
  408bc7:	mov    QWORD PTR [rcx],r9
  408bca:	add    DWORD PTR [rcx+0x28],0x1
  408bce:	jmp    408bee <__swc_fn_4fa09e82_000069_f3aa21af+0x25e>
  408bd0:	mov    rdx,QWORD PTR [rcx+0x18]
  408bd4:	cmp    QWORD PTR [rcx+0x20],rdx
  408bd8:	jae    408bec <__swc_fn_4fa09e82_000069_f3aa21af+0x25c>
  408bda:	mov    rdx,QWORD PTR [rcx+0x20]
  408bde:	mov    r9d,DWORD PTR [rcx+0x2c]
  408be2:	add    QWORD PTR [rcx+0x20],r9
  408be6:	add    DWORD PTR [rcx+0x28],0x1
  408bea:	jmp    408bee <__swc_fn_4fa09e82_000069_f3aa21af+0x25e>
  408bec:	xor    edx,edx
  408bee:	test   rdx,rdx
  408bf1:	jne    408c04 <__swc_fn_4fa09e82_000069_f3aa21af+0x274>
  408bf3:	mov    rcx,r12
  408bf6:	mov    rdx,rax
  408bf9:	mov    r8d,DWORD PTR [r8]
  408bfc:	call   40b660 <__swc_fn_4fa09e82_000055_faa92dcc>
  408c01:	mov    rdx,rax
  408c04:	test   rdx,rdx
  408c07:	jne    408c13 <__swc_fn_4fa09e82_000069_f3aa21af+0x283>
  408c09:	mov    QWORD PTR [rbx+0x40],0x0
  408c11:	jmp    408c17 <__swc_fn_4fa09e82_000069_f3aa21af+0x287>
  408c13:	mov    QWORD PTR [rbx+0x40],rdx
  408c17:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  408c1d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  408c23:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  408c29:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  408c2f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  408c35:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  408c3b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  408c41:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  408c4a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  408c53:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  408c5c:	add    rsp,0xb8
  408c63:	pop    rsi
  408c64:	pop    rdi
  408c65:	pop    r12
  408c67:	pop    rbx
  408c68:	ret
  408c69:	add    BYTE PTR [rax],al
  408c6b:	add    BYTE PTR [rax],al
  408c6d:	add    BYTE PTR [rax],al
	...

0000000000408c70 <__swc_fn_4fa09e82_000072_b3d7b28e>:
  408c70:	ret
	...

0000000000408c80 <__swc_fn_4fa09e82_000075_042643a3>:
  408c80:	push   r12
  408c82:	push   r13
  408c84:	push   r14
  408c86:	push   rdi
  408c87:	push   rsi
  408c88:	sub    rsp,0x1a0
  408c8f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  408c98:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  408ca1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  408caa:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  408cb3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  408cbc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  408cc5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  408cce:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  408cd7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  408ce0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  408ce9:	mov    r12,rdx
  408cec:	mov    r13,rcx
  408cef:	mov    rax,QWORD PTR [r12+0x48]
  408cf4:	mov    ecx,DWORD PTR [r12+0x58]
  408cf9:	lea    rdx,[rax-0x1]
  408cfd:	cmp    rdx,0x10000
  408d04:	jae    408dfe <__swc_fn_4fa09e82_000075_042643a3+0x17e>
  408d0a:	cmp    rax,0x8
  408d0e:	ja     408d15 <__swc_fn_4fa09e82_000075_042643a3+0x95>
  408d10:	xor    r14d,r14d
  408d13:	jmp    408d67 <__swc_fn_4fa09e82_000075_042643a3+0xe7>
  408d15:	cmp    rax,0x80
  408d1c:	ja     408d28 <__swc_fn_4fa09e82_000075_042643a3+0xa8>
  408d1e:	lea    r14,[rax+0xf]
  408d22:	shr    r14,0x4
  408d26:	jmp    408d67 <__swc_fn_4fa09e82_000075_042643a3+0xe7>
  408d28:	cmp    rax,0x10000
  408d2f:	jbe    408d39 <__swc_fn_4fa09e82_000075_042643a3+0xb9>
  408d31:	mov    r14d,0xffffffff
  408d37:	jmp    408d67 <__swc_fn_4fa09e82_000075_042643a3+0xe7>
  408d39:	xor    eax,eax
  408d3b:	lzcnt  rax,rdx
  408d40:	mov    r8d,0x3f
  408d46:	sub    r8d,eax
  408d49:	lea    eax,[r8-0x2]
  408d4d:	shrx   rax,rdx,rax
  408d52:	and    eax,0x3
  408d55:	lea    edx,[r8-0x7]
  408d59:	lea    edx,[rdx*4+0x0]
  408d60:	lea    edx,[rdx+0x9]
  408d63:	lea    r14d,[rdx+rax*1]
  408d67:	cmp    ecx,0x8
  408d6a:	jbe    408d83 <__swc_fn_4fa09e82_000075_042643a3+0x103>
  408d6c:	cmp    ecx,0x10
  408d6f:	jne    408dfe <__swc_fn_4fa09e82_000075_042643a3+0x17e>
  408d75:	test   r14d,r14d
  408d78:	mov    eax,0x1
  408d7d:	cmove  r14d,eax
  408d81:	jmp    408d8a <__swc_fn_4fa09e82_000075_042643a3+0x10a>
  408d83:	lea    eax,[rcx-0x1]
  408d86:	test   eax,ecx
  408d88:	jne    408dfe <__swc_fn_4fa09e82_000075_042643a3+0x17e>
  408d8a:	lea    rax,[rip+0x19277]        # 422008 <__swc_data_base_4fa09e82+0x8>
  408d91:	mov    rax,QWORD PTR [rax]
  408d94:	cmp    rax,0xffffffffffffffff
  408d98:	je     408da7 <__swc_fn_4fa09e82_000075_042643a3+0x127>
  408d9a:	mov    eax,eax
  408d9c:	mov    edi,eax
  408d9e:	xor    eax,eax
  408da0:	call   407000 <pthread_getspecific@plt>
  408da5:	jmp    408da9 <__swc_fn_4fa09e82_000075_042643a3+0x129>
  408da7:	xor    eax,eax
  408da9:	test   rax,rax
  408dac:	je     408dfe <__swc_fn_4fa09e82_000075_042643a3+0x17e>
  408dae:	cmp    QWORD PTR [rax],r13
  408db1:	jne    408dfe <__swc_fn_4fa09e82_000075_042643a3+0x17e>
  408db3:	lea    rcx,[r14+r14*4]
  408db7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  408dbc:	test   rax,rax
  408dbf:	je     408dfe <__swc_fn_4fa09e82_000075_042643a3+0x17e>
  408dc1:	mov    rcx,QWORD PTR [rax]
  408dc4:	test   rcx,rcx
  408dc7:	je     408dd5 <__swc_fn_4fa09e82_000075_042643a3+0x155>
  408dc9:	mov    rdx,QWORD PTR [rcx]
  408dcc:	mov    QWORD PTR [rax],rdx
  408dcf:	add    DWORD PTR [rax+0x28],0x1
  408dd3:	jmp    408df2 <__swc_fn_4fa09e82_000075_042643a3+0x172>
  408dd5:	mov    rcx,QWORD PTR [rax+0x18]
  408dd9:	cmp    QWORD PTR [rax+0x20],rcx
  408ddd:	jae    408df0 <__swc_fn_4fa09e82_000075_042643a3+0x170>
  408ddf:	mov    rcx,QWORD PTR [rax+0x20]
  408de3:	mov    edx,DWORD PTR [rax+0x2c]
  408de6:	add    QWORD PTR [rax+0x20],rdx
  408dea:	add    DWORD PTR [rax+0x28],0x1
  408dee:	jmp    408df2 <__swc_fn_4fa09e82_000075_042643a3+0x172>
  408df0:	xor    ecx,ecx
  408df2:	test   rcx,rcx
  408df5:	je     408dfe <__swc_fn_4fa09e82_000075_042643a3+0x17e>
  408df7:	mov    QWORD PTR [r12+0x40],rcx
  408dfc:	jmp    408e09 <__swc_fn_4fa09e82_000075_042643a3+0x189>
  408dfe:	mov    rcx,r13
  408e01:	mov    rdx,r12
  408e04:	call   40c0e0 <__swc_fn_4fa09e82_000076_64d36d78>
  408e09:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  408e12:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  408e1b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  408e24:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  408e2d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  408e36:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  408e3f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  408e48:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  408e51:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  408e5a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  408e63:	add    rsp,0x1a0
  408e6a:	pop    rsi
  408e6b:	pop    rdi
  408e6c:	pop    r14
  408e6e:	pop    r13
  408e70:	pop    r12
  408e72:	ret
	...

0000000000408e80 <__swc_fn_4fa09e82_000078_7b195156>:
  408e80:	push   r12
  408e82:	push   r13
  408e84:	push   r14
  408e86:	push   r15
  408e88:	push   rdi
  408e89:	push   rsi
  408e8a:	sub    rsp,0x188
  408e91:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  408e9a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  408ea3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  408eac:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  408eb5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  408ebe:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  408ec7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  408ed0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  408ed9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  408ee2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  408eeb:	mov    r12,rdx
  408eee:	mov    r13,rcx
  408ef1:	mov    r14,QWORD PTR [r12+0x40]
  408ef6:	lea    rax,[rip+0x1b1a3]        # 4240a0 <__swc_bss_base_4fa09e82+0x60>
  408efd:	mov    rcx,r14
  408f00:	sub    rcx,QWORD PTR [rax+0x8]
  408f04:	mov    rax,QWORD PTR [rip+0x1b1a5]        # 4240b0 <__swc_bss_base_4fa09e82+0x70>
  408f0b:	cmp    rcx,rax
  408f0e:	jae    408f3a <__swc_fn_4fa09e82_000078_7b195156+0xba>
  408f10:	mov    rax,r14
  408f13:	and    rax,0xffffffffffc00000
  408f1a:	mov    rcx,r14
  408f1d:	shr    rcx,0x10
  408f21:	and    ecx,0x3f
  408f24:	mov    edx,DWORD PTR [rax+0x28]
  408f27:	shrx   ecx,ecx,edx
  408f2c:	shl    rcx,0x4
  408f30:	lea    r15,[rax+rcx*8+0x80]
  408f38:	jmp    408f45 <__swc_fn_4fa09e82_000078_7b195156+0xc5>
  408f3a:	mov    rcx,r14
  408f3d:	call   407a10 <__swc_fn_4fa09e82_000027_bcdc5519>
  408f42:	mov    r15,rax
  408f45:	test   r15,r15
  408f48:	je     408fef <__swc_fn_4fa09e82_000078_7b195156+0x16f>
  408f4e:	lea    rax,[rip+0x190b3]        # 422008 <__swc_data_base_4fa09e82+0x8>
  408f55:	mov    rax,QWORD PTR [rax]
  408f58:	cmp    rax,0xffffffffffffffff
  408f5c:	je     408f6b <__swc_fn_4fa09e82_000078_7b195156+0xeb>
  408f5e:	mov    eax,eax
  408f60:	mov    edi,eax
  408f62:	xor    eax,eax
  408f64:	call   407000 <pthread_getspecific@plt>
  408f69:	jmp    408f6d <__swc_fn_4fa09e82_000078_7b195156+0xed>
  408f6b:	xor    eax,eax
  408f6d:	mov    rcx,QWORD PTR [r15+0x40]
  408f71:	cmp    rcx,rax
  408f74:	jne    408fd4 <__swc_fn_4fa09e82_000078_7b195156+0x154>
  408f76:	test   rax,rax
  408f79:	je     408fef <__swc_fn_4fa09e82_000078_7b195156+0x16f>
  408f7b:	mov    ecx,DWORD PTR [r15+0x6c]
  408f7f:	test   ecx,ecx
  408f81:	je     408fa1 <__swc_fn_4fa09e82_000078_7b195156+0x121>
  408f83:	mov    rcx,r13
  408f86:	mov    rdx,rax
  408f89:	mov    r8,r15
  408f8c:	mov    QWORD PTR [rsp+0xd8],rax
  408f94:	call   40b5f0 <__swc_fn_4fa09e82_000052_e072b516>
  408f99:	mov    rax,QWORD PTR [rsp+0xd8]
  408fa1:	mov    rcx,QWORD PTR [r15]
  408fa4:	mov    QWORD PTR [r14],rcx
  408fa7:	mov    QWORD PTR [r15],r14
  408faa:	sub    DWORD PTR [r15+0x28],0x1
  408faf:	jne    408fe4 <__swc_fn_4fa09e82_000078_7b195156+0x164>
  408fb1:	movzx  ecx,BYTE PTR [r15+0x39]
  408fb6:	lea    rcx,[rcx+rcx*4]
  408fba:	lea    rcx,[rax+rcx*8+0x28]
  408fbf:	cmp    QWORD PTR [rcx],r15
  408fc2:	je     408fe4 <__swc_fn_4fa09e82_000078_7b195156+0x164>
  408fc4:	mov    rcx,r13
  408fc7:	mov    rdx,rax
  408fca:	mov    r8,r15
  408fcd:	call   40e940 <__swc_fn_4fa09e82_000056_2e3450f7>
  408fd2:	jmp    408fe4 <__swc_fn_4fa09e82_000078_7b195156+0x164>
  408fd4:	test   rcx,rcx
  408fd7:	je     408fef <__swc_fn_4fa09e82_000078_7b195156+0x16f>
  408fd9:	mov    rcx,r15
  408fdc:	mov    rdx,r14
  408fdf:	call   407650 <__swc_fn_4fa09e82_000015_524c1f23>
  408fe4:	mov    QWORD PTR [r12+0x40],0x0
  408fed:	jmp    408ffa <__swc_fn_4fa09e82_000078_7b195156+0x17a>
  408fef:	mov    rcx,r13
  408ff2:	mov    rdx,r12
  408ff5:	call   40c100 <__swc_fn_4fa09e82_000079_1966ae2e>
  408ffa:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  409003:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40900c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  409015:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40901e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  409027:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  409030:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  409039:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  409042:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40904b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  409054:	add    rsp,0x188
  40905b:	pop    rsi
  40905c:	pop    rdi
  40905d:	pop    r15
  40905f:	pop    r14
  409061:	pop    r13
  409063:	pop    r12
  409065:	ret
	...

0000000000409070 <__swc_fn_4fa09e82_000081_d2cd17e2>:
  409070:	sub    rsp,0x8
  409074:	mov    rax,rdx
  409077:	mov    rdx,QWORD PTR [rax+0x40]
  40907b:	mov    r8,rax
  40907e:	call   408c70 <__swc_fn_4fa09e82_000072_b3d7b28e>
  409083:	add    rsp,0x8
  409087:	ret
	...

0000000000409090 <__swc_fn_4fa09e82_000084_4a10c7e7>:
  409090:	push   rsi
  409091:	push   rdi
  409092:	sub    rsp,0x8
  409096:	cmp    rcx,0xffffffffffffffef
  40909a:	ja     4090c0 <__swc_fn_4fa09e82_000084_4a10c7e7+0x30>
  40909c:	xor    esi,esi
  40909e:	lea    rax,[rcx+0x100f]
  4090a5:	and    rax,0xfffffffffffff000
  4090ac:	lea    rcx,[rcx+0x10]
  4090b0:	cmp    rcx,0xfffffffffffff000
  4090b7:	cmovbe rsi,rax
  4090bb:	test   rsi,rsi
  4090be:	jne    4090c9 <__swc_fn_4fa09e82_000084_4a10c7e7+0x39>
  4090c0:	xor    eax,eax
  4090c2:	add    rsp,0x8
  4090c6:	pop    rdi
  4090c7:	pop    rsi
  4090c8:	ret
  4090c9:	mov    rcx,rsi
  4090cc:	call   40cd30 <__swc_fn_4fa09e82_000115_6b799b8d>
  4090d1:	mov    rdi,rax
  4090d4:	test   rax,rax
  4090d7:	jne    4090e2 <__swc_fn_4fa09e82_000084_4a10c7e7+0x52>
  4090d9:	xor    eax,eax
  4090db:	add    rsp,0x8
  4090df:	pop    rdi
  4090e0:	pop    rsi
  4090e1:	ret
  4090e2:	mov    rcx,rdi
  4090e5:	mov    rdx,rsi
  4090e8:	call   4096c0 <__swc_fn_4fa09e82_000117_36905703>
  4090ed:	test   al,al
  4090ef:	jne    409105 <__swc_fn_4fa09e82_000084_4a10c7e7+0x75>
  4090f1:	mov    rcx,rdi
  4090f4:	mov    rdx,rsi
  4090f7:	call   410410 <__swc_fn_4fa09e82_000119_ed2d8fed>
  4090fc:	xor    eax,eax
  4090fe:	add    rsp,0x8
  409102:	pop    rdi
  409103:	pop    rsi
  409104:	ret
  409105:	mov    QWORD PTR [rdi],rsi
  409108:	mov    QWORD PTR [rdi+0x8],0x0
  409110:	lea    rax,[rdi+0x10]
  409114:	add    rsp,0x8
  409118:	pop    rdi
  409119:	pop    rsi
  40911a:	ret
  40911b:	add    BYTE PTR [rax],al
  40911d:	add    BYTE PTR [rax],al
	...

0000000000409120 <__swc_fn_4fa09e82_000087_3953ef98>:
  409120:	sub    rsp,0x8
  409124:	cmp    BYTE PTR [rcx+0x2c],0x10
  409128:	jne    409133 <__swc_fn_4fa09e82_000087_3953ef98+0x13>
  40912a:	test   DWORD PTR [rcx+0x28],0x80
  409131:	je     40913b <__swc_fn_4fa09e82_000087_3953ef98+0x1b>
  409133:	mov    rax,rcx
  409136:	add    rsp,0x8
  40913a:	ret
  40913b:	mov    rcx,QWORD PTR [rcx+0x40]
  40913f:	call   409120 <__swc_fn_4fa09e82_000087_3953ef98>
  409144:	add    rsp,0x8
  409148:	ret
	...

0000000000409160 <__swc_fn_4fa09e82_000090_d182c4dc>:
  409160:	push   rsi
  409161:	push   rdi
  409162:	push   r12
  409164:	push   r13
  409166:	sub    rsp,0x8
  40916a:	mov    rsi,rdx
  40916d:	mov    rdi,rcx
  409170:	xor    r8d,r8d
  409173:	call   40f160 <__swc_fn_4fa09e82_000095_63c1827b>
  409178:	test   al,al
  40917a:	je     40918c <__swc_fn_4fa09e82_000090_d182c4dc+0x2c>
  40917c:	mov    eax,0x1
  409181:	add    rsp,0x8
  409185:	pop    r13
  409187:	pop    r12
  409189:	pop    rdi
  40918a:	pop    rsi
  40918b:	ret
  40918c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  409191:	je     4091a0 <__swc_fn_4fa09e82_000090_d182c4dc+0x40>
  409193:	xor    eax,eax
  409195:	add    rsp,0x8
  409199:	pop    r13
  40919b:	pop    r12
  40919d:	pop    rdi
  40919e:	pop    rsi
  40919f:	ret
  4091a0:	mov    r12,QWORD PTR [rsi+0x98]
  4091a7:	mov    rax,QWORD PTR [rsi+0xa0]
  4091ae:	mov    rsi,rax
  4091b1:	xor    r13d,r13d
  4091b4:	test   rsi,rsi
  4091b7:	je     409214 <__swc_fn_4fa09e82_000090_d182c4dc+0xb4>
  4091b9:	cs nop WORD PTR [rax+rax*1+0x0]
  4091c3:	cs nop WORD PTR [rax+rax*1+0x0]
  4091cd:	nop    DWORD PTR [rax]
  4091d0:	lea    rax,[r13*8+0x0]
  4091d8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  4091dd:	mov    rcx,rax
  4091e0:	call   409120 <__swc_fn_4fa09e82_000087_3953ef98>
  4091e5:	cmp    BYTE PTR [rax+0x2c],0xe
  4091e9:	jne    40920a <__swc_fn_4fa09e82_000090_d182c4dc+0xaa>
  4091eb:	mov    rcx,rdi
  4091ee:	mov    rdx,rax
  4091f1:	call   409160 <__swc_fn_4fa09e82_000090_d182c4dc>
  4091f6:	test   al,al
  4091f8:	je     40920a <__swc_fn_4fa09e82_000090_d182c4dc+0xaa>
  4091fa:	mov    eax,0x1
  4091ff:	add    rsp,0x8
  409203:	pop    r13
  409205:	pop    r12
  409207:	pop    rdi
  409208:	pop    rsi
  409209:	ret
  40920a:	add    r13,0x1
  40920e:	sub    rsi,0x1
  409212:	jne    4091d0 <__swc_fn_4fa09e82_000090_d182c4dc+0x70>
  409214:	xor    eax,eax
  409216:	add    rsp,0x8
  40921a:	pop    r13
  40921c:	pop    r12
  40921e:	pop    rdi
  40921f:	pop    rsi
  409220:	ret
	...

0000000000409230 <__swc_fn_4fa09e82_000093_14c65203>:
  409230:	sub    rsp,0x18
  409234:	vxorps xmm0,xmm0,xmm0
  409238:	vmovdqu XMMWORD PTR [rsp],xmm0
  40923d:	call   40c310 <__swc_fn_4fa09e82_000094_c2567a3b>
  409242:	add    rsp,0x18
  409246:	ret
	...

0000000000409250 <__swc_fn_4fa09e82_000096_ad13d15c>:
  409250:	sub    rsp,0x8
  409254:	mov    rcx,QWORD PTR [rip+0x1ade5]        # 424040 <__swc_bss_base_4fa09e82>
  40925b:	test   rcx,rcx
  40925e:	jne    409270 <__swc_fn_4fa09e82_000096_ad13d15c+0x20>
  409260:	call   40a620 <__swc_fn_4fa09e82_000171_994c8876>
  409265:	lea    rcx,[rax+0x1]
  409269:	mov    QWORD PTR [rip+0x1add0],rcx        # 424040 <__swc_bss_base_4fa09e82>
  409270:	dec    rcx
  409273:	call   4121e0 <__swc_fn_4fa09e82_000173_360af05d>
  409278:	mov    rax,QWORD PTR [rax+0xc0]
  40927f:	and    eax,0x1
  409282:	setne  al
  409285:	add    rsp,0x8
  409289:	ret
	...

00000000004092a0 <__swc_fn_4fa09e82_000099_4f209617>:
  4092a0:	push   rbx
  4092a1:	push   rsi
  4092a2:	push   rdi
  4092a3:	push   r12
  4092a5:	sub    rsp,0x28
  4092a9:	mov    rbx,rcx
  4092ac:	call   40f4c0 <__swc_fn_4fa09e82_000098_4185993f>
  4092b1:	mov    rcx,QWORD PTR [rip+0x1ad88]        # 424040 <__swc_bss_base_4fa09e82>
  4092b8:	test   rcx,rcx
  4092bb:	jne    4092cd <__swc_fn_4fa09e82_000099_4f209617+0x2d>
  4092bd:	call   40a620 <__swc_fn_4fa09e82_000171_994c8876>
  4092c2:	lea    rcx,[rax+0x1]
  4092c6:	mov    QWORD PTR [rip+0x1ad73],rcx        # 424040 <__swc_bss_base_4fa09e82>
  4092cd:	dec    rcx
  4092d0:	call   4121e0 <__swc_fn_4fa09e82_000173_360af05d>
  4092d5:	mov    rsi,rax
  4092d8:	lea    rcx,[rsp+0x8]
  4092dd:	call   40c750 <__swc_fn_4fa09e82_000097_93bfe675>
  4092e2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  4092e9:	mov    r12,QWORD PTR [rsi+0xbe8]
  4092f0:	lea    rcx,[rsi+0x10]
  4092f4:	call   40d890 <__swc_fn_4fa09e82_000163_13ead2ff>
  4092f9:	mov    rcx,rsi
  4092fc:	call   40c8c0 <__swc_fn_4fa09e82_000106_5a85fcf5>
  409301:	vxorps xmm0,xmm0,xmm0
  409305:	xor    eax,eax
  409307:	cs nop WORD PTR [rax+rax*1+0x0]
  409311:	cs nop WORD PTR [rax+rax*1+0x0]
  40931b:	nop    DWORD PTR [rax+rax*1+0x0]
  409320:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  409325:	add    rax,0x10
  409329:	cmp    rax,0xbf0
  409330:	jne    409320 <__swc_fn_4fa09e82_000099_4f209617+0x80>
  409332:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409338:	vmovups XMMWORD PTR [rsi],xmm0
  40933c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409342:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40934a:	mov    QWORD PTR [rsi+0x9c0],rdi
  409351:	mov    QWORD PTR [rsi+0xbe8],r12
  409358:	mov    rcx,QWORD PTR [rip+0x1ace1]        # 424040 <__swc_bss_base_4fa09e82>
  40935f:	test   rcx,rcx
  409362:	jne    409374 <__swc_fn_4fa09e82_000099_4f209617+0xd4>
  409364:	call   40a620 <__swc_fn_4fa09e82_000171_994c8876>
  409369:	lea    rcx,[rax+0x1]
  40936d:	mov    QWORD PTR [rip+0x1accc],rcx        # 424040 <__swc_bss_base_4fa09e82>
  409374:	dec    rcx
  409377:	call   4121e0 <__swc_fn_4fa09e82_000173_360af05d>
  40937c:	mov    rsi,rax
  40937f:	mov    QWORD PTR [rsi+0xc0],rbx
  409386:	and    ebx,0x1
  409389:	jne    40938d <__swc_fn_4fa09e82_000099_4f209617+0xed>
  40938b:	xor    eax,eax
  40938d:	test   rbx,rbx
  409390:	sete   al
  409393:	xor    cl,cl
  409395:	xor    dl,dl
  409397:	xor    r8b,r8b
  40939a:	xor    r9b,r9b
  40939d:	xor    r10b,r10b
  4093a0:	mov    r11,rax
  4093a3:	call   40c110 <__swc_fn_4fa09e82_000082_5cc7acfc>
  4093a8:	lea    rbx,[rsp+0x18]
  4093ad:	mov    rcx,rbx
  4093b0:	call   40c750 <__swc_fn_4fa09e82_000097_93bfe675>
  4093b5:	lea    rcx,[rsi+0x10]
  4093b9:	mov    edx,0x400000
  4093be:	mov    r8,rbx
  4093c1:	call   40a360 <__swc_fn_4fa09e82_000165_8a3d304f>
  4093c6:	lea    rcx,[rsi+0x68]
  4093ca:	mov    edx,0x4000
  4093cf:	mov    r8,rbx
  4093d2:	call   40a360 <__swc_fn_4fa09e82_000165_8a3d304f>
  4093d7:	add    rsp,0x28
  4093db:	pop    r12
  4093dd:	pop    rdi
  4093de:	pop    rsi
  4093df:	pop    rbx
  4093e0:	ret
	...

00000000004093f0 <__swc_fn_4fa09e82_000102_d0b19c14>:
  4093f0:	push   rbx
  4093f1:	push   rsi
  4093f2:	sub    rsp,0x18
  4093f6:	mov    rbx,rcx
  4093f9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4093fe:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409404:	mov    rsi,QWORD PTR [rbx+0x70]
  409408:	lea    rcx,[rcx+0x18]
  40940c:	call   40d890 <__swc_fn_4fa09e82_000163_13ead2ff>
  409411:	lea    rcx,[rsp+0x8]
  409416:	mov    rdx,rbx
  409419:	mov    r8d,0x78
  40941f:	call   40f520 <__swc_fn_4fa09e82_000101_d4bdcaa4>
  409424:	mov    rax,rsi
  409427:	add    rsp,0x18
  40942b:	pop    rsi
  40942c:	pop    rbx
  40942d:	ret
	...

0000000000409430 <__swc_fn_4fa09e82_000105_3c3b96fb>:
  409430:	push   rsi
  409431:	push   rdi
  409432:	sub    rsp,0x8
  409436:	cmp    QWORD PTR [rcx],0x0
  40943a:	jne    409443 <__swc_fn_4fa09e82_000105_3c3b96fb+0x13>
  40943c:	add    rsp,0x8
  409440:	pop    rdi
  409441:	pop    rsi
  409442:	ret
  409443:	mov    rsi,QWORD PTR [rcx]
  409446:	mov    rax,QWORD PTR [rcx+0x8]
  40944a:	test   rax,rax
  40944d:	je     409463 <__swc_fn_4fa09e82_000105_3c3b96fb+0x33>
  40944f:	test   DWORD PTR [rax+0x28],0x400000
  409456:	je     409463 <__swc_fn_4fa09e82_000105_3c3b96fb+0x33>
  409458:	mov    rcx,QWORD PTR [rax+0x30]
  40945c:	test   rcx,rcx
  40945f:	cmovne rax,rcx
  409463:	lea    rdx,[rip+0x9e8e]        # 4132f8 <__swc_rdata_base_4fa09e82+0x1e8>
  40946a:	lea    rcx,[rip+0x9f6f]        # 4133e0 <__swc_rdata_base_4fa09e82+0x2d0>
  409471:	mov    r8,rax
  409474:	xor    r9d,r9d
  409477:	xor    al,al
  409479:	mov    r10,rax
  40947c:	xor    r11d,r11d
  40947f:	call   409230 <__swc_fn_4fa09e82_000093_14c65203>
  409484:	test   rax,rax
  409487:	je     409497 <__swc_fn_4fa09e82_000105_3c3b96fb+0x67>
  409489:	mov    rdi,QWORD PTR [rax+0x48]
  40948d:	test   rdi,rdi
  409490:	je     409497 <__swc_fn_4fa09e82_000105_3c3b96fb+0x67>
  409492:	mov    rcx,rsi
  409495:	call   rdi
  409497:	add    rsp,0x8
  40949b:	pop    rdi
  40949c:	pop    rsi
  40949d:	ret
	...

00000000004094a0 <__swc_fn_4fa09e82_000108_90faaa26>:
  4094a0:	push   rbx
  4094a1:	push   rsi
  4094a2:	push   rdi
  4094a3:	sub    rsp,0x20
  4094a7:	mov    rbx,rdx
  4094aa:	mov    rsi,rcx
  4094ad:	mov    rcx,QWORD PTR [rip+0x1ab8c]        # 424040 <__swc_bss_base_4fa09e82>
  4094b4:	test   rcx,rcx
  4094b7:	jne    4094c9 <__swc_fn_4fa09e82_000108_90faaa26+0x29>
  4094b9:	call   40a620 <__swc_fn_4fa09e82_000171_994c8876>
  4094be:	lea    rcx,[rax+0x1]
  4094c2:	mov    QWORD PTR [rip+0x1ab77],rcx        # 424040 <__swc_bss_base_4fa09e82>
  4094c9:	dec    rcx
  4094cc:	call   4121e0 <__swc_fn_4fa09e82_000173_360af05d>
  4094d1:	mov    rdi,rax
  4094d4:	mov    rax,QWORD PTR [rdi+0xbd0]
  4094db:	xor    ecx,ecx
  4094dd:	test   rax,rax
  4094e0:	je     4094e5 <__swc_fn_4fa09e82_000108_90faaa26+0x45>
  4094e2:	mov    rcx,QWORD PTR [rax]
  4094e5:	call   40a750 <__swc_fn_4fa09e82_000180_718d7b54>
  4094ea:	lea    rax,[rsp+0x8]
  4094ef:	lea    rcx,[rdi+0x9c8]
  4094f6:	mov    QWORD PTR [rsp+0x8],rcx
  4094fb:	mov    QWORD PTR [rax+0x8],0x40
  409503:	xor    ecx,ecx
  409505:	mov    rdx,rax
  409508:	call   410540 <__swc_fn_4fa09e82_000125_4f256d58>
  40950d:	mov    DWORD PTR [rdi+0xbc8],eax
  409513:	mov    rdi,QWORD PTR [rdi+0x990]
  40951a:	test   rdi,rdi
  40951d:	je     409527 <__swc_fn_4fa09e82_000108_90faaa26+0x87>
  40951f:	mov    rcx,rsi
  409522:	mov    rdx,rbx
  409525:	call   rdi
  409527:	call   409250 <__swc_fn_4fa09e82_000096_ad13d15c>
  40952c:	test   al,al
  40952e:	je     40953e <__swc_fn_4fa09e82_000108_90faaa26+0x9e>
  409530:	mov    rcx,rsi
  409533:	mov    rdx,rbx
  409536:	xor    r8d,r8d
  409539:	call   409860 <__swc_fn_4fa09e82_000126_83db7238>
  40953e:	mov    rcx,rsi
  409541:	mov    rdx,rbx
  409544:	call   40f620 <__swc_fn_4fa09e82_000107_ffe51047>
  409549:	call   40d0e0 <__swc_fn_4fa09e82_000124_be2e2f68>
  40954e:	add    rsp,0x20
  409552:	pop    rdi
  409553:	pop    rsi
  409554:	pop    rbx
  409555:	ret
	...

0000000000409560 <__swc_fn_4fa09e82_000111_7c204aac>:
  409560:	sub    rsp,0x8
  409564:	test   r8,r8
  409567:	je     40956e <__swc_fn_4fa09e82_000111_7c204aac+0xe>
  409569:	call   40ca90 <__swc_fn_4fa09e82_000109_c51c3158>
  40956e:	add    rsp,0x8
  409572:	ret
	...

0000000000409580 <__swc_fn_4fa09e82_000114_126150d1>:
  409580:	push   rsi
  409581:	push   rdi
  409582:	push   r12
  409584:	push   r13
  409586:	sub    rsp,0xd8
  40958d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409593:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409599:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40959f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  4095a5:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  4095ab:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  4095b4:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  4095bd:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  4095c6:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  4095cf:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  4095d8:	xor    eax,eax
  4095da:	call   407010 <getpid@plt>
  4095df:	mov    rsi,rax
  4095e2:	lea    rdi,[rip+0x1d757]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  4095e9:	mov    r12,QWORD PTR [rdi]
  4095ec:	test   r12,r12
  4095ef:	je     4095fd <__swc_fn_4fa09e82_000114_126150d1+0x7d>
  4095f1:	cmp    DWORD PTR [r12+0x10],esi
  4095f6:	jne    4095fd <__swc_fn_4fa09e82_000114_126150d1+0x7d>
  4095f8:	mov    rax,r12
  4095fb:	jmp    409660 <__swc_fn_4fa09e82_000114_126150d1+0xe0>
  4095fd:	mov    ecx,0x4
  409602:	mov    edx,0x18
  409607:	call   40fd50 <__swc_fn_4fa09e82_000113_6814119b>
  40960c:	mov    rcx,rax
  40960f:	test   rax,rax
  409612:	jne    409618 <__swc_fn_4fa09e82_000114_126150d1+0x98>
  409614:	xor    eax,eax
  409616:	jmp    409660 <__swc_fn_4fa09e82_000114_126150d1+0xe0>
  409618:	mov    DWORD PTR [rcx+0x10],esi
  40961b:	mov    rax,r12
  40961e:	lock cmpxchg QWORD PTR [rdi],rcx
  409623:	mov    r13,rax
  409626:	cmp    rax,r12
  409629:	je     40963f <__swc_fn_4fa09e82_000114_126150d1+0xbf>
  40962b:	mov    rdi,rcx
  40962e:	mov    esi,0x18
  409633:	xor    eax,eax
  409635:	call   407020 <munmap@plt>
  40963a:	mov    rax,r13
  40963d:	jmp    409660 <__swc_fn_4fa09e82_000114_126150d1+0xe0>
  40963f:	test   r12,r12
  409642:	je     40965d <__swc_fn_4fa09e82_000114_126150d1+0xdd>
  409644:	mov    rdi,r12
  409647:	mov    esi,0x18
  40964c:	xor    eax,eax
  40964e:	mov    QWORD PTR [rsp+0x28],rcx
  409653:	call   407020 <munmap@plt>
  409658:	mov    rcx,QWORD PTR [rsp+0x28]
  40965d:	mov    rax,rcx
  409660:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  409666:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40966c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  409672:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  409678:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40967e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409687:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409690:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409699:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  4096a2:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  4096ab:	add    rsp,0xd8
  4096b2:	pop    r13
  4096b4:	pop    r12
  4096b6:	pop    rdi
  4096b7:	pop    rsi
  4096b8:	ret
  4096b9:	add    BYTE PTR [rax],al
  4096bb:	add    BYTE PTR [rax],al
  4096bd:	add    BYTE PTR [rax],al
	...

00000000004096c0 <__swc_fn_4fa09e82_000117_36905703>:
  4096c0:	push   rbx
  4096c1:	push   r12
  4096c3:	push   rdi
  4096c4:	push   rsi
  4096c5:	sub    rsp,0xa8
  4096cc:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4096d2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4096d8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4096de:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4096e4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4096ea:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4096f0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4096f6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4096fc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409705:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40970e:	mov    rbx,rdx
  409711:	mov    r12,rcx
  409714:	mov    rdi,rcx
  409717:	mov    rsi,rdx
  40971a:	mov    edx,0x3
  40971f:	xor    eax,eax
  409721:	call   407030 <mprotect@plt>
  409726:	test   eax,eax
  409728:	je     40972e <__swc_fn_4fa09e82_000117_36905703+0x6e>
  40972a:	xor    eax,eax
  40972c:	jmp    409743 <__swc_fn_4fa09e82_000117_36905703+0x83>
  40972e:	mov    rcx,r12
  409731:	mov    rdx,rbx
  409734:	mov    al,0x1
  409736:	mov    r8,rax
  409739:	call   410380 <__swc_fn_4fa09e82_000116_5f48311c>
  40973e:	mov    eax,0x1
  409743:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409749:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40974f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409755:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40975b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409761:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409767:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40976d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409773:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40977c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409785:	add    rsp,0xa8
  40978c:	pop    rsi
  40978d:	pop    rdi
  40978e:	pop    r12
  409790:	pop    rbx
  409791:	ret
	...

00000000004097a0 <__swc_fn_4fa09e82_000120_5208f471>:
  4097a0:	sub    rsp,0x8
  4097a4:	test   rcx,rcx
  4097a7:	jne    4097ae <__swc_fn_4fa09e82_000120_5208f471+0xe>
  4097a9:	add    rsp,0x8
  4097ad:	ret
  4097ae:	call   40cf90 <__swc_fn_4fa09e82_000121_d3318640>
  4097b3:	add    rsp,0x8
  4097b7:	ret
	...

00000000004097c0 <__swc_fn_4fa09e82_000123_0a5fa85a>:
  4097c0:	push   rdi
  4097c1:	push   rsi
  4097c2:	sub    rsp,0xa8
  4097c9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4097cf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4097d5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4097db:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4097e1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4097e7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4097ed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4097f3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4097f9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409802:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40980b:	xor    edi,edi
  40980d:	xor    eax,eax
  40980f:	call   407040 <exit@plt>
  409814:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40981a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409820:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409826:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40982c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409832:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409838:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40983e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409844:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40984d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409856:	add    rsp,0xa8
  40985d:	pop    rsi
  40985e:	pop    rdi
  40985f:	ret

0000000000409860 <__swc_fn_4fa09e82_000126_83db7238>:
  409860:	push   rbx
  409861:	push   rsi
  409862:	push   rdi
  409863:	push   r12
  409865:	sub    rsp,0x18
  409869:	mov    rbx,r8
  40986c:	mov    rsi,rcx
  40986f:	mov    rdi,rdx
  409872:	mov    rcx,QWORD PTR [rip+0x1a7c7]        # 424040 <__swc_bss_base_4fa09e82>
  409879:	test   rcx,rcx
  40987c:	jne    40988e <__swc_fn_4fa09e82_000126_83db7238+0x2e>
  40987e:	call   40a620 <__swc_fn_4fa09e82_000171_994c8876>
  409883:	lea    rcx,[rax+0x1]
  409887:	mov    QWORD PTR [rip+0x1a7b2],rcx        # 424040 <__swc_bss_base_4fa09e82>
  40988e:	dec    rcx
  409891:	call   4121e0 <__swc_fn_4fa09e82_000173_360af05d>
  409896:	mov    r12,rax
  409899:	cmp    ebx,0x3
  40989c:	jne    4098af <__swc_fn_4fa09e82_000126_83db7238+0x4f>
  40989e:	mov    rax,QWORD PTR [r12+0xbd0]
  4098a6:	test   rax,rax
  4098a9:	jne    4099ec <__swc_fn_4fa09e82_000126_83db7238+0x18c>
  4098af:	cmp    ebx,0x5
  4098b2:	jne    4098d6 <__swc_fn_4fa09e82_000126_83db7238+0x76>
  4098b4:	call   409250 <__swc_fn_4fa09e82_000096_ad13d15c>
  4098b9:	test   al,al
  4098bb:	jne    4098d6 <__swc_fn_4fa09e82_000126_83db7238+0x76>
  4098bd:	mov    rcx,rsi
  4098c0:	mov    rdx,rdi
  4098c3:	call   412190 <__swc_fn_4fa09e82_000170_3459066f>
  4098c8:	test   al,al
  4098ca:	je     4098d6 <__swc_fn_4fa09e82_000126_83db7238+0x76>
  4098cc:	add    rsp,0x18
  4098d0:	pop    r12
  4098d2:	pop    rdi
  4098d3:	pop    rsi
  4098d4:	pop    rbx
  4098d5:	ret
  4098d6:	call   409250 <__swc_fn_4fa09e82_000096_ad13d15c>
  4098db:	test   al,al
  4098dd:	jne    40994f <__swc_fn_4fa09e82_000126_83db7238+0xef>
  4098df:	vmovups xmm0,XMMWORD PTR [rsi]
  4098e3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4098e9:	mov    rax,QWORD PTR [rsp+0x8]
  4098ee:	test   rax,rax
  4098f1:	jne    409942 <__swc_fn_4fa09e82_000126_83db7238+0xe2>
  4098f3:	cmp    ebx,0x3
  4098f6:	je     409904 <__swc_fn_4fa09e82_000126_83db7238+0xa4>
  4098f8:	cmp    ebx,0x4
  4098fb:	je     409914 <__swc_fn_4fa09e82_000126_83db7238+0xb4>
  4098fd:	cmp    ebx,0x5
  409900:	je     409924 <__swc_fn_4fa09e82_000126_83db7238+0xc4>
  409902:	jmp    409934 <__swc_fn_4fa09e82_000126_83db7238+0xd4>
  409904:	vmovups xmm0,XMMWORD PTR [rip+0x9ca4]        # 4135b0 <__swc_rdata_base_4fa09e82+0x4a0>
  40990c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409912:	jmp    409942 <__swc_fn_4fa09e82_000126_83db7238+0xe2>
  409914:	vmovups xmm0,XMMWORD PTR [rip+0x9ca4]        # 4135c0 <__swc_rdata_base_4fa09e82+0x4b0>
  40991c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409922:	jmp    409942 <__swc_fn_4fa09e82_000126_83db7238+0xe2>
  409924:	vmovups xmm0,XMMWORD PTR [rip+0x9ca4]        # 4135d0 <__swc_rdata_base_4fa09e82+0x4c0>
  40992c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409932:	jmp    409942 <__swc_fn_4fa09e82_000126_83db7238+0xe2>
  409934:	vmovups xmm0,XMMWORD PTR [rip+0x9ca4]        # 4135e0 <__swc_rdata_base_4fa09e82+0x4d0>
  40993c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409942:	lea    rcx,[rsp+0x8]
  409947:	mov    rdx,rdi
  40994a:	call   4094a0 <__swc_fn_4fa09e82_000108_90faaa26>
  40994f:	vmovups xmm0,XMMWORD PTR [rdi]
  409953:	vmovups XMMWORD PTR [r12+0x940],xmm0
  40995d:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  409962:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40996c:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  409971:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40997b:	lea    rax,[r12+0x940]
  409983:	mov    QWORD PTR [r12+0x970],rax
  40998b:	mov    rax,QWORD PTR [rsi]
  40998e:	mov    QWORD PTR [r12+0x978],rax
  409996:	mov    rax,QWORD PTR [rsi+0x8]
  40999a:	mov    QWORD PTR [r12+0x980],rax
  4099a2:	movsxd rax,ebx
  4099a5:	mov    QWORD PTR [r12+0x988],rax
  4099ad:	cmp    ebx,0x5
  4099b0:	je     4099b9 <__swc_fn_4fa09e82_000126_83db7238+0x159>
  4099b2:	xor    ecx,ecx
  4099b4:	call   40a750 <__swc_fn_4fa09e82_000180_718d7b54>
  4099b9:	mov    rbx,QWORD PTR [r12+0xbe8]
  4099c1:	test   rbx,rbx
  4099c4:	je     4099d5 <__swc_fn_4fa09e82_000126_83db7238+0x175>
  4099c6:	mov    rcx,r12
  4099c9:	call   rbx
  4099cb:	add    rsp,0x18
  4099cf:	pop    r12
  4099d1:	pop    rdi
  4099d2:	pop    rsi
  4099d3:	pop    rbx
  4099d4:	ret
  4099d5:	mov    rcx,rsi
  4099d8:	call   410430 <__swc_fn_4fa09e82_000122_2648f149>
  4099dd:	call   40d0e0 <__swc_fn_4fa09e82_000124_be2e2f68>
  4099e2:	add    rsp,0x18
  4099e6:	pop    r12
  4099e8:	pop    rdi
  4099e9:	pop    rsi
  4099ea:	pop    rbx
  4099eb:	ret
  4099ec:	mov    rcx,rsi
  4099ef:	mov    rdx,rdi
  4099f2:	call   4094a0 <__swc_fn_4fa09e82_000108_90faaa26>
  4099f7:	jmp    4098af <__swc_fn_4fa09e82_000126_83db7238+0x4f>
  4099fc:	add    BYTE PTR [rax],al
	...

0000000000409a00 <__swc_fn_4fa09e82_000129_58f0f391>:
  409a00:	push   rdi
  409a01:	push   rsi
  409a02:	sub    rsp,0xb8
  409a09:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409a0f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409a15:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409a1b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409a21:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409a27:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409a2d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409a33:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409a3c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409a45:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409a4e:	mov    DWORD PTR [rsp+0x8],0x0
  409a56:	lea    rdi,[rsp+0x8]
  409a5b:	xor    esi,esi
  409a5d:	xor    eax,eax
  409a5f:	call   407050 <pthread_key_create@plt>
  409a64:	test   eax,eax
  409a66:	jne    409a6e <__swc_fn_4fa09e82_000129_58f0f391+0x6e>
  409a68:	mov    eax,DWORD PTR [rsp+0x8]
  409a6c:	jmp    409a75 <__swc_fn_4fa09e82_000129_58f0f391+0x75>
  409a6e:	mov    rax,0xffffffffffffffff
  409a75:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409a7b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409a81:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409a87:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409a8d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409a93:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409a99:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409a9f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409aa8:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409ab1:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409aba:	add    rsp,0xb8
  409ac1:	pop    rsi
  409ac2:	pop    rdi
  409ac3:	ret
	...

0000000000409ad0 <__swc_fn_4fa09e82_000132_4a82cdf6>:
  409ad0:	push   rdi
  409ad1:	push   rsi
  409ad2:	sub    rsp,0xb8
  409ad9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409adf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409ae5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409aeb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409af1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409af7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409afd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409b03:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409b0c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409b15:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409b1e:	mov    DWORD PTR [rsp+0x8],0x0
  409b26:	lea    rdi,[rsp+0x8]
  409b2b:	mov    rsi,rcx
  409b2e:	xor    eax,eax
  409b30:	call   407050 <pthread_key_create@plt>
  409b35:	test   eax,eax
  409b37:	jne    409b42 <__swc_fn_4fa09e82_000132_4a82cdf6+0x72>
  409b39:	mov    eax,DWORD PTR [rsp+0x8]
  409b3d:	inc    rax
  409b40:	jmp    409b44 <__swc_fn_4fa09e82_000132_4a82cdf6+0x74>
  409b42:	xor    eax,eax
  409b44:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409b4a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409b50:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409b56:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409b5c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409b62:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409b68:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409b6e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409b77:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409b80:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409b89:	add    rsp,0xb8
  409b90:	pop    rsi
  409b91:	pop    rdi
  409b92:	ret
	...

0000000000409ba0 <__swc_fn_4fa09e82_000135_ae5891af>:
  409ba0:	push   rdi
  409ba1:	push   rsi
  409ba2:	sub    rsp,0xa8
  409ba9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409baf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409bb5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409bbb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409bc1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409bc7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409bcd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409bd3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409bd9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409be2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409beb:	test   rcx,rcx
  409bee:	setne  al
  409bf1:	je     409c0a <__swc_fn_4fa09e82_000135_ae5891af+0x6a>
  409bf3:	lea    rax,[rcx-0x1]
  409bf7:	mov    eax,eax
  409bf9:	mov    edi,eax
  409bfb:	mov    rsi,rdx
  409bfe:	xor    eax,eax
  409c00:	call   407060 <pthread_setspecific@plt>
  409c05:	test   eax,eax
  409c07:	sete   al
  409c0a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409c10:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409c16:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409c1c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409c22:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409c28:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409c2e:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409c34:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409c3a:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409c43:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409c4c:	add    rsp,0xa8
  409c53:	pop    rsi
  409c54:	pop    rdi
  409c55:	ret
	...

0000000000409c60 <__swc_fn_4fa09e82_000138_865f5106>:
  409c60:	push   rdi
  409c61:	push   rsi
  409c62:	sub    rsp,0xa8
  409c69:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409c6f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409c75:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409c7b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409c81:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409c87:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409c8d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409c93:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409c99:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409ca2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409cab:	mov    rax,rdx
  409cae:	mov    QWORD PTR [rsp],0x0
  409cb6:	mov    edi,0xca
  409cbb:	mov    rsi,rcx
  409cbe:	mov    edx,0x81
  409cc3:	mov    eax,eax
  409cc5:	mov    ecx,eax
  409cc7:	xor    r8d,r8d
  409cca:	xor    r9d,r9d
  409ccd:	xor    eax,eax
  409ccf:	call   407070 <syscall@plt>
  409cd4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409cda:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409ce0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409ce6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409cec:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409cf2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409cf8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409cfe:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409d04:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409d0d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409d16:	add    rsp,0xa8
  409d1d:	pop    rsi
  409d1e:	pop    rdi
  409d1f:	ret

0000000000409d20 <__swc_fn_4fa09e82_000141_86bb0f90>:
  409d20:	sub    rsp,0x8
  409d24:	call   40d490 <__swc_fn_4fa09e82_000139_8c07c14b>
  409d29:	add    rsp,0x8
  409d2d:	ret
	...

0000000000409d30 <__swc_fn_4fa09e82_000144_be4c2719>:
  409d30:	push   rdi
  409d31:	push   rsi
  409d32:	sub    rsp,0xc8
  409d39:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  409d3f:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  409d45:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  409d4b:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  409d51:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  409d57:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  409d5d:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  409d66:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  409d6f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  409d78:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409d81:	vxorps xmm0,xmm0,xmm0
  409d85:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409d8b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409d91:	mov    rdi,rcx
  409d94:	lea    rsi,[rsp+0x8]
  409d99:	xor    eax,eax
  409d9b:	call   407080 <dladdr@plt>
  409da0:	xor    ecx,ecx
  409da2:	test   eax,eax
  409da4:	je     409dab <__swc_fn_4fa09e82_000144_be4c2719+0x7b>
  409da6:	mov    rcx,QWORD PTR [rsp+0x10]
  409dab:	mov    rax,rcx
  409dae:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409db4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  409dba:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409dc0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409dc6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  409dcc:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409dd2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  409ddb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409de4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  409ded:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409df6:	add    rsp,0xc8
  409dfd:	pop    rsi
  409dfe:	pop    rdi
  409dff:	ret

0000000000409e00 <__swc_fn_4fa09e82_000147_1534de9a>:
  409e00:	push   rbx
  409e01:	push   r12
  409e03:	push   r13
  409e05:	push   rdi
  409e06:	push   rsi
  409e07:	push   r14
  409e09:	push   r15
  409e0b:	sub    rsp,0x150
  409e12:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  409e1b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  409e24:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  409e2d:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  409e36:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  409e3f:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  409e48:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  409e51:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  409e5a:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  409e63:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  409e6c:	mov    rbx,rdx
  409e6f:	mov    QWORD PTR [rsp+0x98],rdx
  409e77:	mov    r12,rcx
  409e7a:	mov    QWORD PTR [rsp+0xa0],rcx
  409e82:	mov    QWORD PTR [rbx],0x0
  409e89:	lea    r13,[rip+0x1cee8]        # 426d78 <__swc_bss_base_4fa09e82+0x2d38>
  409e90:	mov    rcx,r13
  409e93:	call   409d20 <__swc_fn_4fa09e82_000141_86bb0f90>
  409e98:	mov    rax,QWORD PTR [rip+0x1cee1]        # 426d80 <__swc_bss_base_4fa09e82+0x2d40>
  409e9f:	test   rax,rax
  409ea2:	je     409ed9 <__swc_fn_4fa09e82_000147_1534de9a+0xd9>
  409ea4:	cs nop WORD PTR [rax+rax*1+0x0]
  409eae:	xchg   ax,ax
  409eb0:	cmp    QWORD PTR [rax+0x8],r12
  409eb4:	jne    409ed1 <__swc_fn_4fa09e82_000147_1534de9a+0xd1>
  409eb6:	mov    rcx,QWORD PTR [rax+0x18]
  409eba:	mov    QWORD PTR [rbx],rcx
  409ebd:	mov    rbx,QWORD PTR [rax+0x10]
  409ec1:	mov    rcx,r13
  409ec4:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  409ec9:	mov    rax,rbx
  409ecc:	jmp    40a0bb <__swc_fn_4fa09e82_000147_1534de9a+0x2bb>
  409ed1:	mov    rax,QWORD PTR [rax]
  409ed4:	test   rax,rax
  409ed7:	jne    409eb0 <__swc_fn_4fa09e82_000147_1534de9a+0xb0>
  409ed9:	vxorps xmm0,xmm0,xmm0
  409edd:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409ee3:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409ee9:	mov    rdi,r12
  409eec:	lea    rsi,[rsp+0x10]
  409ef1:	xor    eax,eax
  409ef3:	call   407080 <dladdr@plt>
  409ef8:	test   eax,eax
  409efa:	sete   al
  409efd:	je     409f0a <__swc_fn_4fa09e82_000147_1534de9a+0x10a>
  409eff:	mov    rax,QWORD PTR [rsp+0x10]
  409f04:	test   rax,rax
  409f07:	sete   al
  409f0a:	test   al,al
  409f0c:	je     409f1d <__swc_fn_4fa09e82_000147_1534de9a+0x11d>
  409f0e:	mov    rcx,r13
  409f11:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  409f16:	xor    eax,eax
  409f18:	jmp    40a0bb <__swc_fn_4fa09e82_000147_1534de9a+0x2bb>
  409f1d:	mov    rdi,QWORD PTR [rsp+0x10]
  409f22:	mov    esi,0x80000
  409f27:	xor    eax,eax
  409f29:	call   407090 <open@plt>
  409f2e:	lea    r14,[rsp+0x30]
  409f33:	mov    DWORD PTR [rsp+0x30],eax
  409f37:	cmp    DWORD PTR [r14],0x0
  409f3b:	jge    409f4c <__swc_fn_4fa09e82_000147_1534de9a+0x14c>
  409f3d:	mov    rcx,r13
  409f40:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  409f45:	xor    eax,eax
  409f47:	jmp    40a0bb <__swc_fn_4fa09e82_000147_1534de9a+0x2bb>
  409f4c:	mov    rax,r14
  409f4f:	movsxd rdi,DWORD PTR [rax]
  409f52:	xor    esi,esi
  409f54:	mov    edx,0x2
  409f59:	xor    eax,eax
  409f5b:	call   4070a0 <lseek@plt>
  409f60:	mov    r15,rax
  409f63:	test   rax,rax
  409f66:	jg     409f81 <__swc_fn_4fa09e82_000147_1534de9a+0x181>
  409f68:	movsxd rdi,DWORD PTR [r14]
  409f6b:	xor    eax,eax
  409f6d:	call   4070b0 <close@plt>
  409f72:	mov    rcx,r13
  409f75:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  409f7a:	xor    eax,eax
  409f7c:	jmp    40a0bb <__swc_fn_4fa09e82_000147_1534de9a+0x2bb>
  409f81:	xor    edi,edi
  409f83:	mov    rsi,r15
  409f86:	mov    edx,0x1
  409f8b:	mov    ecx,0x2
  409f90:	mov    rax,r14
  409f93:	movsxd r8,DWORD PTR [rax]
  409f96:	xor    r9d,r9d
  409f99:	xor    eax,eax
  409f9b:	call   4070c0 <mmap@plt>
  409fa0:	mov    rbx,rax
  409fa3:	test   rax,rax
  409fa6:	sete   al
  409fa9:	cmp    rbx,0xffffffffffffffff
  409fad:	sete   cl
  409fb0:	or     al,cl
  409fb2:	je     409fcd <__swc_fn_4fa09e82_000147_1534de9a+0x1cd>
  409fb4:	movsxd rdi,DWORD PTR [r14]
  409fb7:	xor    eax,eax
  409fb9:	call   4070b0 <close@plt>
  409fbe:	mov    rcx,r13
  409fc1:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  409fc6:	xor    eax,eax
  409fc8:	jmp    40a0bb <__swc_fn_4fa09e82_000147_1534de9a+0x2bb>
  409fcd:	lea    rax,[rsp+0x50]
  409fd2:	mov    QWORD PTR [rax],0x0
  409fd9:	mov    rcx,rbx
  409fdc:	mov    rdx,r15
  409fdf:	mov    r8,rax
  409fe2:	call   4109c0 <__swc_fn_4fa09e82_000146_d5d4d43f>
  409fe7:	mov    r12,rax
  409fea:	test   rax,rax
  409fed:	jne    40a015 <__swc_fn_4fa09e82_000147_1534de9a+0x215>
  409fef:	mov    rdi,rbx
  409ff2:	mov    rsi,r15
  409ff5:	xor    eax,eax
  409ff7:	call   407020 <munmap@plt>
  409ffc:	movsxd rdi,DWORD PTR [r14]
  409fff:	xor    eax,eax
  40a001:	call   4070b0 <close@plt>
  40a006:	mov    rcx,r13
  40a009:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40a00e:	xor    eax,eax
  40a010:	jmp    40a0bb <__swc_fn_4fa09e82_000147_1534de9a+0x2bb>
  40a015:	mov    edi,0x20
  40a01a:	xor    eax,eax
  40a01c:	call   4070d0 <malloc@plt>
  40a021:	test   rax,rax
  40a024:	jne    40a049 <__swc_fn_4fa09e82_000147_1534de9a+0x249>
  40a026:	mov    rdi,rbx
  40a029:	mov    rsi,r15
  40a02c:	xor    eax,eax
  40a02e:	call   407020 <munmap@plt>
  40a033:	movsxd rdi,DWORD PTR [r14]
  40a036:	xor    eax,eax
  40a038:	call   4070b0 <close@plt>
  40a03d:	mov    rcx,r13
  40a040:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40a045:	xor    eax,eax
  40a047:	jmp    40a0bb <__swc_fn_4fa09e82_000147_1534de9a+0x2bb>
  40a049:	mov    rcx,QWORD PTR [rip+0x1cd30]        # 426d80 <__swc_bss_base_4fa09e82+0x2d40>
  40a050:	mov    QWORD PTR [rsp+0x70],rcx
  40a055:	mov    rcx,QWORD PTR [rsp+0xa0]
  40a05d:	mov    QWORD PTR [rsp+0x78],rcx
  40a062:	mov    QWORD PTR [rsp+0x80],r12
  40a06a:	mov    rcx,QWORD PTR [rsp+0x50]
  40a06f:	mov    QWORD PTR [rsp+0x88],rcx
  40a077:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  40a07d:	vmovups XMMWORD PTR [rax],xmm0
  40a081:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  40a08a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40a08f:	mov    QWORD PTR [rip+0x1ccea],rax        # 426d80 <__swc_bss_base_4fa09e82+0x2d40>
  40a096:	mov    rax,QWORD PTR [rsp+0x50]
  40a09b:	mov    rbx,QWORD PTR [rsp+0x98]
  40a0a3:	mov    QWORD PTR [rbx],rax
  40a0a6:	movsxd rdi,DWORD PTR [r14]
  40a0a9:	xor    eax,eax
  40a0ab:	call   4070b0 <close@plt>
  40a0b0:	mov    rcx,r13
  40a0b3:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40a0b8:	mov    rax,r12
  40a0bb:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40a0c4:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40a0cd:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40a0d6:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40a0df:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40a0e8:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40a0f1:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40a0fa:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40a103:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40a10c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40a115:	add    rsp,0x150
  40a11c:	pop    r15
  40a11e:	pop    r14
  40a120:	pop    rsi
  40a121:	pop    rdi
  40a122:	pop    r13
  40a124:	pop    r12
  40a126:	pop    rbx
  40a127:	ret
	...

000000000040a130 <__swc_fn_4fa09e82_000150_43c96957>:
  40a130:	push   rbx
  40a131:	sub    rsp,0xe0
  40a138:	lea    rbx,[rsp+0x8]
  40a13d:	vxorps xmm0,xmm0,xmm0
  40a141:	vmovups YMMWORD PTR [rbx],ymm0
  40a145:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40a14a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40a14f:	vzeroupper
  40a152:	mov    DWORD PTR [rbx+0x60],0x0
  40a159:	mov    r8,rbx
  40a15c:	nop    DWORD PTR [rax+0x0]
  40a160:	mov    r9,rcx
  40a163:	movabs rcx,0xcccccccccccccccd
  40a16d:	mov    rax,r9
  40a170:	mul    rcx
  40a173:	mov    r10,rdx
  40a176:	shr    r10,0x3
  40a17a:	mov    rcx,r10
  40a17d:	imul   rdx,r10,0xa
  40a181:	sub    r9,rdx
  40a184:	mov    rdx,QWORD PTR [rip+0x9485]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  40a18b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  40a190:	mov    BYTE PTR [r8],dl
  40a193:	lea    rdx,[r8+0x1]
  40a197:	mov    r8,rdx
  40a19a:	test   r10,r10
  40a19d:	jne    40a160 <__swc_fn_4fa09e82_000150_43c96957+0x30>
  40a19f:	mov    BYTE PTR [rdx],0x0
  40a1a2:	sub    r8,0x1
  40a1a6:	mov    rax,rbx
  40a1a9:	cmp    rax,r8
  40a1ac:	jae    40a1c6 <__swc_fn_4fa09e82_000150_43c96957+0x96>
  40a1ae:	xchg   ax,ax
  40a1b0:	mov    cl,BYTE PTR [r8]
  40a1b3:	mov    dl,BYTE PTR [rax]
  40a1b5:	mov    BYTE PTR [r8],dl
  40a1b8:	sub    r8,0x1
  40a1bc:	mov    BYTE PTR [rax],cl
  40a1be:	inc    rax
  40a1c1:	cmp    rax,r8
  40a1c4:	jb     40a1b0 <__swc_fn_4fa09e82_000150_43c96957+0x80>
  40a1c6:	xor    eax,eax
  40a1c8:	test   rbx,rbx
  40a1cb:	je     40a1ee <__swc_fn_4fa09e82_000150_43c96957+0xbe>
  40a1cd:	mov    rcx,rbx
  40a1d0:	mov    dl,BYTE PTR [rcx]
  40a1d2:	test   dl,dl
  40a1d4:	je     40a1ee <__swc_fn_4fa09e82_000150_43c96957+0xbe>
  40a1d6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a1e0:	add    rcx,0x1
  40a1e4:	add    rax,0x1
  40a1e8:	mov    dl,BYTE PTR [rcx]
  40a1ea:	test   dl,dl
  40a1ec:	jne    40a1e0 <__swc_fn_4fa09e82_000150_43c96957+0xb0>
  40a1ee:	mov    QWORD PTR [rbx+0xa8],rbx
  40a1f5:	mov    QWORD PTR [rbx+0xb0],rax
  40a1fc:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40a204:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40a20c:	lea    rcx,[rbx+0xb8]
  40a213:	call   410430 <__swc_fn_4fa09e82_000122_2648f149>
  40a218:	add    rsp,0xe0
  40a21f:	pop    rbx
  40a220:	ret
	...

000000000040a230 <__swc_fn_4fa09e82_000153_6fb05988>:
  40a230:	sub    rsp,0x8
  40a234:	mov    rax,QWORD PTR [rcx+0x8]
  40a238:	mov    r8,QWORD PTR [rdx+0x8]
  40a23c:	cmp    rax,r8
  40a23f:	je     40a248 <__swc_fn_4fa09e82_000153_6fb05988+0x18>
  40a241:	xor    eax,eax
  40a243:	add    rsp,0x8
  40a247:	ret
  40a248:	test   rax,rax
  40a24b:	jne    40a25c <__swc_fn_4fa09e82_000153_6fb05988+0x2c>
  40a24d:	test   r8,r8
  40a250:	jne    40a25c <__swc_fn_4fa09e82_000153_6fb05988+0x2c>
  40a252:	mov    eax,0x1
  40a257:	add    rsp,0x8
  40a25b:	ret
  40a25c:	mov    rcx,QWORD PTR [rcx]
  40a25f:	mov    rdx,QWORD PTR [rdx]
  40a262:	test   rcx,rcx
  40a265:	sete   r8b
  40a269:	test   rdx,rdx
  40a26c:	sete   r9b
  40a270:	or     r8b,r9b
  40a273:	je     40a280 <__swc_fn_4fa09e82_000153_6fb05988+0x50>
  40a275:	cmp    rcx,rdx
  40a278:	sete   al
  40a27b:	add    rsp,0x8
  40a27f:	ret
  40a280:	cmp    rcx,rdx
  40a283:	jne    40a28f <__swc_fn_4fa09e82_000153_6fb05988+0x5f>
  40a285:	mov    eax,0x1
  40a28a:	add    rsp,0x8
  40a28e:	ret
  40a28f:	mov    r8,rax
  40a292:	call   40cb70 <__swc_fn_4fa09e82_000112_3dc01326>
  40a297:	test   eax,eax
  40a299:	sete   al
  40a29c:	add    rsp,0x8
  40a2a0:	ret
	...

000000000040a2b0 <__swc_fn_4fa09e82_000156_86f1d437>:
  40a2b0:	vxorps xmm0,xmm0,xmm0
  40a2b4:	vmovups XMMWORD PTR [rcx],xmm0
  40a2b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a2bd:	vxorps xmm0,xmm0,xmm0
  40a2c1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a2c6:	vmovups xmm0,XMMWORD PTR [rip+0x93fa]        # 4136c8 <__swc_rdata_base_4fa09e82+0x5b8>
  40a2ce:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a2d3:	ret
	...

000000000040a2e0 <__swc_fn_4fa09e82_000159_86f1d437>:
  40a2e0:	vxorps xmm0,xmm0,xmm0
  40a2e4:	vmovups XMMWORD PTR [rcx],xmm0
  40a2e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a2ed:	vxorps xmm0,xmm0,xmm0
  40a2f1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a2f6:	vmovups xmm0,XMMWORD PTR [rip+0x94ea]        # 4137e8 <__swc_rdata_base_4fa09e82+0x6d8>
  40a2fe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a303:	mov    QWORD PTR [rcx+0x40],0x0
  40a30b:	ret
  40a30c:	add    BYTE PTR [rax],al
	...

000000000040a310 <__swc_fn_4fa09e82_000162_47b270e1>:
  40a310:	push   rbx
  40a311:	sub    rsp,0x70
  40a315:	mov    rax,QWORD PTR [rcx]
  40a318:	mov    rbx,QWORD PTR [rcx+0x8]
  40a31c:	vxorps xmm0,xmm0,xmm0
  40a320:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40a326:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40a32c:	vzeroupper
  40a32f:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40a335:	mov    QWORD PTR [rsp+0x48],rdx
  40a33a:	mov    QWORD PTR [rsp+0x50],r8
  40a33f:	mov    rcx,rax
  40a342:	lea    rdx,[rsp+0x8]
  40a347:	mov    rbx,QWORD PTR [rbx+0x18]
  40a34b:	call   rbx
  40a34d:	add    rsp,0x70
  40a351:	pop    rbx
  40a352:	ret
	...

000000000040a360 <__swc_fn_4fa09e82_000165_8a3d304f>:
  40a360:	push   rbx
  40a361:	push   rsi
  40a362:	push   rdi
  40a363:	mov    rbx,r8
  40a366:	mov    rsi,rcx
  40a369:	mov    rdi,rdx
  40a36c:	call   40d890 <__swc_fn_4fa09e82_000163_13ead2ff>
  40a371:	vmovups xmm0,XMMWORD PTR [rbx]
  40a375:	vmovups XMMWORD PTR [rsi],xmm0
  40a379:	mov    QWORD PTR [rsi+0x18],rdi
  40a37d:	pop    rdi
  40a37e:	pop    rsi
  40a37f:	pop    rbx
  40a380:	ret
	...

000000000040a390 <__swc_fn_4fa09e82_000168_cc119975>:
  40a390:	push   rbx
  40a391:	push   rsi
  40a392:	push   rdi
  40a393:	push   r12
  40a395:	push   r13
  40a397:	sub    rsp,0x50
  40a39b:	mov    rbx,rcx
  40a39e:	mov    rsi,rdx
  40a3a1:	vmovups xmm0,XMMWORD PTR [rip+0x954f]        # 4138f8 <__swc_rdata_base_4fa09e82+0x7e8>
  40a3a9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a3af:	vmovups xmm0,XMMWORD PTR [rip+0x9551]        # 413908 <__swc_rdata_base_4fa09e82+0x7f8>
  40a3b7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a3bd:	vxorps xmm0,xmm0,xmm0
  40a3c1:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a3c7:	mov    rcx,rdx
  40a3ca:	call   409d30 <__swc_fn_4fa09e82_000144_be4c2719>
  40a3cf:	mov    rdi,rax
  40a3d2:	test   rax,rax
  40a3d5:	jne    40a406 <__swc_fn_4fa09e82_000168_cc119975+0x76>
  40a3d7:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a3dd:	vmovups XMMWORD PTR [rbx],xmm0
  40a3e1:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a3e7:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a3ec:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a3f2:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a3f7:	mov    rax,rbx
  40a3fa:	add    rsp,0x50
  40a3fe:	pop    r13
  40a400:	pop    r12
  40a402:	pop    rdi
  40a403:	pop    rsi
  40a404:	pop    rbx
  40a405:	ret
  40a406:	mov    rcx,rdi
  40a409:	call   411ee0 <__swc_fn_4fa09e82_000167_016ee66a>
  40a40e:	mov    r11,rax
  40a411:	test   rax,rax
  40a414:	je     40a41e <__swc_fn_4fa09e82_000168_cc119975+0x8e>
  40a416:	mov    al,BYTE PTR [r11+0x24]
  40a41a:	test   al,al
  40a41c:	jne    40a44d <__swc_fn_4fa09e82_000168_cc119975+0xbd>
  40a41e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a424:	vmovups XMMWORD PTR [rbx],xmm0
  40a428:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a42e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a433:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a439:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a43e:	mov    rax,rbx
  40a441:	add    rsp,0x50
  40a445:	pop    r13
  40a447:	pop    r12
  40a449:	pop    rdi
  40a44a:	pop    rsi
  40a44b:	pop    rbx
  40a44c:	ret
  40a44d:	sub    rsi,rdi
  40a450:	mov    eax,0xffffffff
  40a455:	cmp    rsi,rax
  40a458:	jbe    40a489 <__swc_fn_4fa09e82_000168_cc119975+0xf9>
  40a45a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a460:	vmovups XMMWORD PTR [rbx],xmm0
  40a464:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a46a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a46f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a475:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a47a:	mov    rax,rbx
  40a47d:	add    rsp,0x50
  40a481:	pop    r13
  40a483:	pop    r12
  40a485:	pop    rdi
  40a486:	pop    rsi
  40a487:	pop    rbx
  40a488:	ret
  40a489:	mov    rdi,QWORD PTR [r11+0x10]
  40a48d:	mov    eax,DWORD PTR [r11+0x20]
  40a491:	xor    ecx,ecx
  40a493:	test   rax,rax
  40a496:	jbe    40a5e8 <__swc_fn_4fa09e82_000168_cc119975+0x258>
  40a49c:	nop    DWORD PTR [rax+0x0]
  40a4a0:	mov    edx,ecx
  40a4a2:	imul   r12,rdx,0x14
  40a4a6:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a4ab:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a4b0:	mov    r9d,esi
  40a4b3:	cmp    r9,rdx
  40a4b6:	jb     40a5db <__swc_fn_4fa09e82_000168_cc119975+0x24b>
  40a4bc:	add    rdx,r8
  40a4bf:	mov    r8d,esi
  40a4c2:	cmp    r8,rdx
  40a4c5:	jae    40a5db <__swc_fn_4fa09e82_000168_cc119975+0x24b>
  40a4cb:	lea    rsi,[rsp+0x38]
  40a4d0:	mov    eax,DWORD PTR [rdi+0xc]
  40a4d3:	mov    DWORD PTR [rsp+0x38],eax
  40a4d7:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a4dc:	mov    rcx,rdi
  40a4df:	mov    rdx,QWORD PTR [r11+0x18]
  40a4e3:	mov    r8,rsi
  40a4e6:	mov    r8d,DWORD PTR [r8]
  40a4e9:	mov    r9,rax
  40a4ec:	lea    r10,[rsp+0x10]
  40a4f1:	call   40d8e0 <__swc_fn_4fa09e82_000166_72795826>
  40a4f6:	test   al,al
  40a4f8:	jne    40a52b <__swc_fn_4fa09e82_000168_cc119975+0x19b>
  40a4fa:	vmovups xmm0,XMMWORD PTR [rip+0x9426]        # 413928 <__swc_rdata_base_4fa09e82+0x818>
  40a502:	vmovups XMMWORD PTR [rbx],xmm0
  40a506:	vmovups xmm0,XMMWORD PTR [rip+0x942a]        # 413938 <__swc_rdata_base_4fa09e82+0x828>
  40a50e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a513:	vxorps xmm0,xmm0,xmm0
  40a517:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a51c:	mov    rax,rbx
  40a51f:	add    rsp,0x50
  40a523:	pop    r13
  40a525:	pop    r12
  40a527:	pop    rdi
  40a528:	pop    rsi
  40a529:	pop    rbx
  40a52a:	ret
  40a52b:	lea    r13,[rsp+0x3c]
  40a530:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a535:	mov    DWORD PTR [rsp+0x3c],eax
  40a539:	test   eax,eax
  40a53b:	je     40a58c <__swc_fn_4fa09e82_000168_cc119975+0x1fc>
  40a53d:	mov    rcx,rdi
  40a540:	mov    rdx,QWORD PTR [r11+0x18]
  40a544:	mov    r8d,DWORD PTR [rsi]
  40a547:	mov    rax,r13
  40a54a:	mov    r9d,DWORD PTR [rax]
  40a54d:	lea    r10,[rsp+0x20]
  40a552:	call   40d8e0 <__swc_fn_4fa09e82_000166_72795826>
  40a557:	test   al,al
  40a559:	jne    40a58c <__swc_fn_4fa09e82_000168_cc119975+0x1fc>
  40a55b:	vmovups xmm0,XMMWORD PTR [rip+0x93f5]        # 413958 <__swc_rdata_base_4fa09e82+0x848>
  40a563:	vmovups XMMWORD PTR [rbx],xmm0
  40a567:	vmovups xmm0,XMMWORD PTR [rip+0x93f9]        # 413968 <__swc_rdata_base_4fa09e82+0x858>
  40a56f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a574:	vxorps xmm0,xmm0,xmm0
  40a578:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a57d:	mov    rax,rbx
  40a580:	add    rsp,0x50
  40a584:	pop    r13
  40a586:	pop    r12
  40a588:	pop    rdi
  40a589:	pop    rsi
  40a58a:	pop    rbx
  40a58b:	ret
  40a58c:	mov    eax,0x1
  40a591:	rex mov BYTE PTR [rsp+0x8],al
  40a596:	cmp    DWORD PTR [r13+0x0],0x0
  40a59b:	je     40a5ac <__swc_fn_4fa09e82_000168_cc119975+0x21c>
  40a59d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a5a3:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a5a8:	mov    DWORD PTR [rsp+0x30],eax
  40a5ac:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a5b2:	vmovups XMMWORD PTR [rbx],xmm0
  40a5b6:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a5bc:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a5c1:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a5c7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a5cc:	mov    rax,rbx
  40a5cf:	add    rsp,0x50
  40a5d3:	pop    r13
  40a5d5:	pop    r12
  40a5d7:	pop    rdi
  40a5d8:	pop    rsi
  40a5d9:	pop    rbx
  40a5da:	ret
  40a5db:	add    rcx,0x1
  40a5df:	cmp    rcx,rax
  40a5e2:	jb     40a4a0 <__swc_fn_4fa09e82_000168_cc119975+0x110>
  40a5e8:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a5ee:	vmovups XMMWORD PTR [rbx],xmm0
  40a5f2:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a5f8:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a5fd:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a603:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a608:	mov    rax,rbx
  40a60b:	add    rsp,0x50
  40a60f:	pop    r13
  40a611:	pop    r12
  40a613:	pop    rdi
  40a614:	pop    rsi
  40a615:	pop    rbx
  40a616:	ret
	...

000000000040a620 <__swc_fn_4fa09e82_000171_994c8876>:
  40a620:	sub    rsp,0x48
  40a624:	call   409a00 <__swc_fn_4fa09e82_000129_58f0f391>
  40a629:	cmp    rax,0xffffffffffffffff
  40a62d:	je     40a634 <__swc_fn_4fa09e82_000171_994c8876+0x14>
  40a62f:	add    rsp,0x48
  40a633:	ret
  40a634:	lea    rcx,[rip+0x935d]        # 413998 <__swc_rdata_base_4fa09e82+0x888>
  40a63b:	vmovups xmm0,XMMWORD PTR [rip+0x9365]        # 4139a8 <__swc_rdata_base_4fa09e82+0x898>
  40a643:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a649:	vmovups xmm0,XMMWORD PTR [rip+0x9367]        # 4139b8 <__swc_rdata_base_4fa09e82+0x8a8>
  40a651:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a657:	vmovups xmm0,XMMWORD PTR [rip+0x9369]        # 4139c8 <__swc_rdata_base_4fa09e82+0x8b8>
  40a65f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a665:	lea    rdx,[rsp+0x8]
  40a66a:	mov    QWORD PTR [rsp+0x38],rax
  40a66f:	call   4094a0 <__swc_fn_4fa09e82_000108_90faaa26>
  40a674:	mov    rax,QWORD PTR [rsp+0x38]
  40a679:	jmp    40a62f <__swc_fn_4fa09e82_000171_994c8876+0xf>
  40a67b:	add    BYTE PTR [rax],al
  40a67d:	add    BYTE PTR [rax],al
	...

000000000040a680 <__swc_fn_4fa09e82_000174_cbeff767>:
  40a680:	push   rbx
  40a681:	push   rsi
  40a682:	sub    rsp,0x28
  40a686:	mov    rbx,rcx
  40a689:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a691:	mov    ecx,0xbf0
  40a696:	call   409090 <__swc_fn_4fa09e82_000084_4a10c7e7>
  40a69b:	mov    rsi,rax
  40a69e:	test   rax,rax
  40a6a1:	jne    40a6ac <__swc_fn_4fa09e82_000174_cbeff767+0x2c>
  40a6a3:	xor    eax,eax
  40a6a5:	add    rsp,0x28
  40a6a9:	pop    rsi
  40a6aa:	pop    rbx
  40a6ab:	ret
  40a6ac:	vxorps xmm0,xmm0,xmm0
  40a6b0:	xor    eax,eax
  40a6b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a6bc:	nop    DWORD PTR [rax+0x0]
  40a6c0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a6c5:	add    rax,0x10
  40a6c9:	cmp    rax,0xbf0
  40a6d0:	jne    40a6c0 <__swc_fn_4fa09e82_000174_cbeff767+0x40>
  40a6d2:	lea    rax,[rbx+0x1]
  40a6d6:	mov    QWORD PTR [rsi+0x9c0],rax
  40a6dd:	mov    rcx,rbx
  40a6e0:	mov    rdx,rsi
  40a6e3:	call   40dc40 <__swc_fn_4fa09e82_000172_646fdf20>
  40a6e8:	test   al,al
  40a6ea:	jne    40a6fd <__swc_fn_4fa09e82_000174_cbeff767+0x7d>
  40a6ec:	mov    rcx,rsi
  40a6ef:	call   40c1d0 <__swc_fn_4fa09e82_000085_cf82995a>
  40a6f4:	xor    eax,eax
  40a6f6:	add    rsp,0x28
  40a6fa:	pop    rsi
  40a6fb:	pop    rbx
  40a6fc:	ret
  40a6fd:	lea    rcx,[rsp+0x18]
  40a702:	call   40c750 <__swc_fn_4fa09e82_000097_93bfe675>
  40a707:	mov    rax,rsi
  40a70a:	add    rsp,0x28
  40a70e:	pop    rsi
  40a70f:	pop    rbx
  40a710:	ret
	...

000000000040a720 <__swc_fn_4fa09e82_000177_e09f8b62>:
  40a720:	xor    eax,eax
  40a722:	mov    edx,0x1
  40a727:	lock cmpxchg QWORD PTR [rcx],rdx
  40a72c:	test   rax,rax
  40a72f:	jne    40a732 <__swc_fn_4fa09e82_000177_e09f8b62+0x12>
  40a731:	ret
  40a732:	cs nop WORD PTR [rax+rax*1+0x0]
  40a73c:	nop    DWORD PTR [rax+0x0]
  40a740:	mov    rax,QWORD PTR [rcx]
  40a743:	test   rax,rax
  40a746:	je     40a720 <__swc_fn_4fa09e82_000177_e09f8b62>
  40a748:	jmp    40a740 <__swc_fn_4fa09e82_000177_e09f8b62+0x20>
  40a74a:	add    BYTE PTR [rax],al
  40a74c:	add    BYTE PTR [rax],al
	...

000000000040a750 <__swc_fn_4fa09e82_000180_718d7b54>:
  40a750:	push   rsi
  40a751:	push   rdi
  40a752:	sub    rsp,0x38
  40a756:	mov    rsi,rcx
  40a759:	call   40dc50 <__swc_fn_4fa09e82_000175_1e0ea8cf>
  40a75e:	mov    rdi,rax
  40a761:	call   40d3e0 <__swc_fn_4fa09e82_000136_a9c1c700>
  40a766:	mov    r8,rax
  40a769:	mov    rcx,rdi
  40a76c:	call   40a720 <__swc_fn_4fa09e82_000177_e09f8b62>
  40a771:	mov    rax,QWORD PTR [rdi+0x8]
  40a775:	test   rax,rax
  40a778:	je     40a7b5 <__swc_fn_4fa09e82_000180_718d7b54+0x65>
  40a77a:	nop    WORD PTR [rax+rax*1+0x0]
  40a780:	cmp    rax,rsi
  40a783:	je     40a7b5 <__swc_fn_4fa09e82_000180_718d7b54+0x65>
  40a785:	mov    r9,QWORD PTR [rax]
  40a788:	cmp    QWORD PTR [rax+0x20],r8
  40a78c:	jne    40a7ad <__swc_fn_4fa09e82_000180_718d7b54+0x5d>
  40a78e:	mov    rcx,rdi
  40a791:	mov    rdx,rax
  40a794:	mov    QWORD PTR [rsp+0x28],r8
  40a799:	mov    QWORD PTR [rsp+0x30],r9
  40a79e:	call   412300 <__swc_fn_4fa09e82_000179_cf4ffedd>
  40a7a3:	mov    r8,QWORD PTR [rsp+0x28]
  40a7a8:	mov    r9,QWORD PTR [rsp+0x30]
  40a7ad:	mov    rax,r9
  40a7b0:	test   r9,r9
  40a7b3:	jne    40a780 <__swc_fn_4fa09e82_000180_718d7b54+0x30>
  40a7b5:	xor    eax,eax
  40a7b7:	mov    QWORD PTR [rdi],rax
  40a7ba:	add    rsp,0x38
  40a7be:	pop    rdi
  40a7bf:	pop    rsi
  40a7c0:	ret
	...

000000000040a800 <__swc_fn_4fa09e82_000001_2744b483>:
  40a800:	push   rbx
  40a801:	sub    rsp,0x70
  40a805:	cmp    rcx,0xffffffffffffffef
  40a809:	jbe    40a813 <__swc_fn_4fa09e82_000001_2744b483+0x13>
  40a80b:	xor    eax,eax
  40a80d:	add    rsp,0x70
  40a811:	pop    rbx
  40a812:	ret
  40a813:	vxorps xmm0,xmm0,xmm0
  40a817:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40a81d:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40a823:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40a829:	vzeroupper
  40a82c:	lea    rax,[rcx+0x10]
  40a830:	mov    QWORD PTR [rsp+0x50],rax
  40a835:	mov    DWORD PTR [rsp+0x60],0x10
  40a83d:	mov    rcx,QWORD PTR [rip+0x197fc]        # 424040 <__swc_bss_base_4fa09e82>
  40a844:	test   rcx,rcx
  40a847:	jne    40a859 <__swc_fn_4fa09e82_000001_2744b483+0x59>
  40a849:	call   40a620 <__swc_fn_4fa09e82_000171_994c8876>
  40a84e:	lea    rcx,[rax+0x1]
  40a852:	mov    QWORD PTR [rip+0x197e7],rcx        # 424040 <__swc_bss_base_4fa09e82>
  40a859:	dec    rcx
  40a85c:	call   4121e0 <__swc_fn_4fa09e82_000173_360af05d>
  40a861:	mov    rcx,QWORD PTR [rax]
  40a864:	lea    rdx,[rsp+0x8]
  40a869:	mov    rbx,QWORD PTR [rax+0x8]
  40a86d:	mov    rbx,QWORD PTR [rbx+0x8]
  40a871:	call   rbx
  40a873:	mov    rax,QWORD PTR [rsp+0x48]
  40a878:	test   rax,rax
  40a87b:	jne    40a885 <__swc_fn_4fa09e82_000001_2744b483+0x85>
  40a87d:	xor    eax,eax
  40a87f:	add    rsp,0x70
  40a883:	pop    rbx
  40a884:	ret
  40a885:	mov    rcx,QWORD PTR [rsp+0x50]
  40a88a:	mov    QWORD PTR [rax],rcx
  40a88d:	mov    QWORD PTR [rax+0x8],0x0
  40a895:	lea    rax,[rax+0x10]
  40a899:	add    rsp,0x70
  40a89d:	pop    rbx
  40a89e:	ret
	...

000000000040a8c0 <__swc_fn_4fa09e82_000004_913db40c>:
  40a8c0:	push   rbp
  40a8c1:	push   rbx
  40a8c2:	push   rsi
  40a8c3:	push   rdi
  40a8c4:	push   r12
  40a8c6:	push   r15
  40a8c8:	push   r13
  40a8ca:	push   r14
  40a8cc:	sub    rsp,0x10
  40a8d0:	mov    rbp,rsp
  40a8d3:	vmovups XMMWORD PTR [rsp],xmm6
  40a8d8:	sub    rsp,0x50
  40a8dc:	mov    rbx,rsp
  40a8df:	sub    rsp,0x8
  40a8e3:	mov    ecx,0x13880
  40a8e8:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40a8ed:	mov    rsi,rax
  40a8f0:	mov    ecx,0x9c40
  40a8f5:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40a8fa:	mov    rdi,rax
  40a8fd:	mov    ecx,0x9c40
  40a902:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40a907:	mov    r12,rax
  40a90a:	xor    ecx,ecx
  40a90c:	xor    r8d,r8d
  40a90f:	cs nop WORD PTR [rax+rax*1+0x0]
  40a919:	nop    DWORD PTR [rax+0x0]
  40a920:	lea    r9,[r8+0x1]
  40a924:	mov    r10,r9
  40a927:	movabs rdx,0xaaaaaaaaaaaaaaab
  40a931:	mov    r15,rax
  40a934:	mov    rax,r8
  40a937:	mul    rdx
  40a93a:	mov    r11,rdx
  40a93d:	mov    rax,r15
  40a940:	shr    r11,0x2
  40a944:	imul   r11,r11,0x6
  40a948:	mov    rdx,r8
  40a94b:	sub    rdx,r11
  40a94e:	lea    r11,[rdx+0x3]
  40a952:	mov    QWORD PTR [rdi+r8*8],rcx
  40a956:	mov    QWORD PTR [r12+r8*8],r11
  40a95a:	xor    r8d,r8d
  40a95d:	test   r11,r11
  40a960:	jbe    40a9b4 <__swc_fn_4fa09e82_000004_913db40c+0xf4>
  40a962:	xor    r13d,r13d
  40a965:	cs nop WORD PTR [rax+rax*1+0x0]
  40a96f:	nop
  40a970:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40a97a:	mov    r15,rax
  40a97d:	mov    rax,r10
  40a980:	mul    rdx
  40a983:	mov    r14,rdx
  40a986:	mov    rax,r15
  40a989:	shr    r14,0x3
  40a98d:	imul   r14,r14,0x1a
  40a991:	sub    r10,r14
  40a994:	lea    r10,[r10+0x61]
  40a998:	mov    BYTE PTR [rsi+rcx*1],r10b
  40a99c:	inc    rcx
  40a99f:	shr    rdx,0x3
  40a9a3:	lea    r10,[rdx+r13*1]
  40a9a7:	add    r8,0x1
  40a9ab:	add    r13,0x7
  40a9af:	cmp    r8,r11
  40a9b2:	jb     40a970 <__swc_fn_4fa09e82_000004_913db40c+0xb0>
  40a9b4:	mov    r8,r9
  40a9b7:	cmp    r9,0x1388
  40a9be:	jb     40a920 <__swc_fn_4fa09e82_000004_913db40c+0x60>
  40a9c4:	mov    ecx,0x16e3600
  40a9c9:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40a9ce:	mov    QWORD PTR [rip+0x19693],rax        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40a9d5:	xor    ecx,ecx
  40a9d7:	xor    r8d,r8d
  40a9da:	nop    WORD PTR [rax+rax*1+0x0]
  40a9e0:	mov    r9,QWORD PTR [rip+0x17619]        # 422000 <__swc_data_base_4fa09e82>
  40a9e7:	imul   r9,r9,0x41a7
  40a9ee:	movabs rdx,0x200000005
  40a9f8:	mov    r11,rax
  40a9fb:	mov    rax,r9
  40a9fe:	mul    rdx
  40aa01:	mov    r10,rdx
  40aa04:	mov    rdx,r9
  40aa07:	sub    rdx,r10
  40aa0a:	shr    rdx,1
  40aa0d:	add    rdx,r10
  40aa10:	shr    rdx,0x1e
  40aa14:	imul   r10,rdx,0x7fffffff
  40aa1b:	sub    r9,r10
  40aa1e:	mov    QWORD PTR [rip+0x175db],r9        # 422000 <__swc_data_base_4fa09e82>
  40aa25:	movabs rdx,0x346dc5d63886594b
  40aa2f:	mov    rax,r9
  40aa32:	mul    rdx
  40aa35:	mov    rax,r11
  40aa38:	shr    rdx,0xa
  40aa3c:	imul   rdx,rdx,0x1388
  40aa43:	sub    r9,rdx
  40aa46:	mov    rdx,QWORD PTR [rdi+r9*8]
  40aa4a:	mov    r9,QWORD PTR [r12+r9*8]
  40aa4e:	xor    r10d,r10d
  40aa51:	test   r9,r9
  40aa54:	jbe    40aa74 <__swc_fn_4fa09e82_000004_913db40c+0x1b4>
  40aa56:	mov    r11,QWORD PTR [rip+0x1960b]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40aa5d:	add    rdx,rsi
  40aa60:	mov    r13b,BYTE PTR [rdx+r10*1]
  40aa64:	mov    BYTE PTR [r11+rcx*1],r13b
  40aa68:	inc    rcx
  40aa6b:	add    r10,0x1
  40aa6f:	cmp    r10,r9
  40aa72:	jb     40aa60 <__swc_fn_4fa09e82_000004_913db40c+0x1a0>
  40aa74:	lea    r9,[r8+0x1]
  40aa78:	movabs rdx,0xaaaaaaaaaaaaaaab
  40aa82:	mov    r11,rax
  40aa85:	mov    rax,r9
  40aa88:	mul    rdx
  40aa8b:	mov    r8,rdx
  40aa8e:	mov    rax,r11
  40aa91:	shr    r8,0x3
  40aa95:	imul   r8,r8,0xc
  40aa99:	mov    rdx,r9
  40aa9c:	sub    rdx,r8
  40aa9f:	jne    40aaae <__swc_fn_4fa09e82_000004_913db40c+0x1ee>
  40aaa1:	mov    rdx,QWORD PTR [rip+0x195c0]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40aaa8:	mov    BYTE PTR [rdx+rcx*1],0xa
  40aaac:	jmp    40aab9 <__swc_fn_4fa09e82_000004_913db40c+0x1f9>
  40aaae:	mov    rdx,QWORD PTR [rip+0x195b3]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40aab5:	mov    BYTE PTR [rdx+rcx*1],0x20
  40aab9:	lea    r13,[rcx+0x1]
  40aabd:	mov    r15,r13
  40aac0:	mov    rcx,r13
  40aac3:	mov    r8,r9
  40aac6:	cmp    r9,0x1e8480
  40aacd:	jb     40a9e0 <__swc_fn_4fa09e82_000004_913db40c+0x120>
  40aad3:	mov    QWORD PTR [rsp+0x48],r15
  40aad8:	call   40dd60 <__swc_fn_4fa09e82_000002_1ca87929>
  40aadd:	vmovups xmm6,xmm0
  40aae1:	mov    rsi,rbx
  40aae4:	mov    QWORD PTR [rsp+0x50],rsi
  40aae9:	vxorps xmm0,xmm0,xmm0
  40aaed:	vmovups XMMWORD PTR [rbx],xmm0
  40aaf1:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40aaf6:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40aafb:	mov    QWORD PTR [rbx+0x30],0x0
  40ab03:	mov    r8,QWORD PTR [rip+0x1955e]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40ab0a:	mov    rcx,rsi
  40ab0d:	mov    edx,0x4000
  40ab12:	call   407270 <__swc_fn_4fa09e82_000000_e7f0b636>
  40ab17:	xor    edi,edi
  40ab19:	xor    al,al
  40ab1b:	xor    r12d,r12d
  40ab1e:	cmp    r12,r13
  40ab21:	jae    40acaf <__swc_fn_4fa09e82_000004_913db40c+0x3ef>
  40ab27:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab31:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab3b:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab45:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab4f:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab59:	nop    DWORD PTR [rax+0x0]
  40ab60:	mov    rcx,QWORD PTR [rip+0x19501]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40ab67:	mov    cl,BYTE PTR [rcx+r12*1]
  40ab6b:	sub    cl,0x61
  40ab6e:	cmp    cl,0x19
  40ab71:	ja     40ab88 <__swc_fn_4fa09e82_000004_913db40c+0x2c8>
  40ab73:	test   al,al
  40ab75:	jne    40ac9e <__swc_fn_4fa09e82_000004_913db40c+0x3de>
  40ab7b:	mov    rdi,r12
  40ab7e:	mov    eax,0x1
  40ab83:	jmp    40ac9e <__swc_fn_4fa09e82_000004_913db40c+0x3de>
  40ab88:	test   al,al
  40ab8a:	je     40ac9e <__swc_fn_4fa09e82_000004_913db40c+0x3de>
  40ab90:	mov    r14,r12
  40ab93:	sub    r14,rdi
  40ab96:	mov    eax,0x811c9dc5
  40ab9b:	xor    ecx,ecx
  40ab9d:	test   r14,r14
  40aba0:	jbe    40ac12 <__swc_fn_4fa09e82_000004_913db40c+0x352>
  40aba6:	mov    rdx,QWORD PTR [rbx+0x20]
  40abaa:	add    rdx,rdi
  40abad:	cmp    r14,0x4
  40abb1:	jb     40ac00 <__swc_fn_4fa09e82_000004_913db40c+0x340>
  40abb7:	lea    r8,[r14-0x3]
  40abbb:	nop    DWORD PTR [rax+rax*1+0x0]
  40abc0:	xor    al,BYTE PTR [rdx+rcx*1]
  40abc3:	imul   eax,eax,0x1000193
  40abc9:	xor    al,BYTE PTR [rdx+rcx*1+0x1]
  40abcd:	imul   eax,eax,0x1000193
  40abd3:	xor    al,BYTE PTR [rdx+rcx*1+0x2]
  40abd7:	imul   eax,eax,0x1000193
  40abdd:	xor    al,BYTE PTR [rdx+rcx*1+0x3]
  40abe1:	imul   eax,eax,0x1000193
  40abe7:	add    rcx,0x4
  40abeb:	cmp    rcx,r8
  40abee:	jb     40abc0 <__swc_fn_4fa09e82_000004_913db40c+0x300>
  40abf0:	cmp    rcx,r14
  40abf3:	jae    40ac12 <__swc_fn_4fa09e82_000004_913db40c+0x352>
  40abf5:	cs nop WORD PTR [rax+rax*1+0x0]
  40abff:	nop
  40ac00:	xor    al,BYTE PTR [rdx+rcx*1]
  40ac03:	imul   eax,eax,0x1000193
  40ac09:	add    rcx,0x1
  40ac0d:	cmp    rcx,r14
  40ac10:	jb     40ac00 <__swc_fn_4fa09e82_000004_913db40c+0x340>
  40ac12:	and    rax,QWORD PTR [rbx+0x28]
  40ac16:	mov    r15,rax
  40ac19:	mov    rsi,QWORD PTR [rbx+0x18]
  40ac1d:	mov    r13,QWORD PTR [rbx+0x8]
  40ac21:	cmp    BYTE PTR [rsi+r15*1],0x0
  40ac26:	je     40ac66 <__swc_fn_4fa09e82_000004_913db40c+0x3a6>
  40ac28:	nop    DWORD PTR [rax+rax*1+0x0]
  40ac30:	cmp    QWORD PTR [r13+r15*8+0x0],r14
  40ac35:	jne    40ac58 <__swc_fn_4fa09e82_000004_913db40c+0x398>
  40ac37:	mov    rax,QWORD PTR [rbx]
  40ac3a:	mov    rax,QWORD PTR [rax+r15*8]
  40ac3e:	mov    rcx,QWORD PTR [rbx+0x20]
  40ac42:	add    rax,rcx
  40ac45:	lea    rdx,[rcx+rdi*1]
  40ac49:	mov    rcx,rax
  40ac4c:	mov    r8,r14
  40ac4f:	call   40cb70 <__swc_fn_4fa09e82_000112_3dc01326>
  40ac54:	test   eax,eax
  40ac56:	je     40ac66 <__swc_fn_4fa09e82_000004_913db40c+0x3a6>
  40ac58:	inc    r15
  40ac5b:	and    r15,QWORD PTR [rbx+0x28]
  40ac5f:	cmp    BYTE PTR [rsi+r15*1],0x0
  40ac64:	jne    40ac30 <__swc_fn_4fa09e82_000004_913db40c+0x370>
  40ac66:	cmp    BYTE PTR [rsi+r15*1],0x0
  40ac6b:	jne    40ac94 <__swc_fn_4fa09e82_000004_913db40c+0x3d4>
  40ac6d:	mov    BYTE PTR [rsi+r15*1],0x1
  40ac72:	mov    rax,QWORD PTR [rbx]
  40ac75:	mov    QWORD PTR [rax+r15*8],rdi
  40ac79:	mov    rax,QWORD PTR [rbx+0x8]
  40ac7d:	mov    QWORD PTR [rax+r15*8],r14
  40ac81:	mov    rax,QWORD PTR [rbx+0x10]
  40ac85:	mov    QWORD PTR [rax+r15*8],0x1
  40ac8d:	add    QWORD PTR [rbx+0x30],0x1
  40ac92:	jmp    40ac9c <__swc_fn_4fa09e82_000004_913db40c+0x3dc>
  40ac94:	mov    rax,QWORD PTR [rbx+0x10]
  40ac98:	inc    QWORD PTR [rax+r15*8]
  40ac9c:	xor    eax,eax
  40ac9e:	inc    r12
  40aca1:	mov    r13,QWORD PTR [rsp+0x48]
  40aca6:	cmp    r12,r13
  40aca9:	jb     40ab60 <__swc_fn_4fa09e82_000004_913db40c+0x2a0>
  40acaf:	test   al,al
  40acb1:	je     40addb <__swc_fn_4fa09e82_000004_913db40c+0x51b>
  40acb7:	mov    r13,QWORD PTR [rsp+0x48]
  40acbc:	sub    r13,rdi
  40acbf:	mov    eax,0x811c9dc5
  40acc4:	xor    ecx,ecx
  40acc6:	test   r13,r13
  40acc9:	jbe    40ad52 <__swc_fn_4fa09e82_000004_913db40c+0x492>
  40accf:	mov    rdx,QWORD PTR [rbx+0x20]
  40acd3:	add    rdx,rdi
  40acd6:	cmp    r13,0x4
  40acda:	jb     40ad40 <__swc_fn_4fa09e82_000004_913db40c+0x480>
  40ace0:	lea    r8,[r13-0x3]
  40ace4:	cs nop WORD PTR [rax+rax*1+0x0]
  40acee:	cs nop WORD PTR [rax+rax*1+0x0]
  40acf8:	nop    DWORD PTR [rax+rax*1+0x0]
  40ad00:	xor    al,BYTE PTR [rdx+rcx*1]
  40ad03:	imul   eax,eax,0x1000193
  40ad09:	xor    al,BYTE PTR [rdx+rcx*1+0x1]
  40ad0d:	imul   eax,eax,0x1000193
  40ad13:	xor    al,BYTE PTR [rdx+rcx*1+0x2]
  40ad17:	imul   eax,eax,0x1000193
  40ad1d:	xor    al,BYTE PTR [rdx+rcx*1+0x3]
  40ad21:	imul   eax,eax,0x1000193
  40ad27:	add    rcx,0x4
  40ad2b:	cmp    rcx,r8
  40ad2e:	jb     40ad00 <__swc_fn_4fa09e82_000004_913db40c+0x440>
  40ad30:	cmp    rcx,r13
  40ad33:	jae    40ad52 <__swc_fn_4fa09e82_000004_913db40c+0x492>
  40ad35:	cs nop WORD PTR [rax+rax*1+0x0]
  40ad3f:	nop
  40ad40:	xor    al,BYTE PTR [rdx+rcx*1]
  40ad43:	imul   eax,eax,0x1000193
  40ad49:	add    rcx,0x1
  40ad4d:	cmp    rcx,r13
  40ad50:	jb     40ad40 <__swc_fn_4fa09e82_000004_913db40c+0x480>
  40ad52:	mov    rsi,QWORD PTR [rsp+0x50]
  40ad57:	and    rax,QWORD PTR [rsi+0x28]
  40ad5b:	mov    r12,rax
  40ad5e:	mov    r14,QWORD PTR [rbx+0x18]
  40ad62:	mov    r15,QWORD PTR [rbx+0x8]
  40ad66:	cmp    BYTE PTR [r14+r12*1],0x0
  40ad6b:	je     40ada5 <__swc_fn_4fa09e82_000004_913db40c+0x4e5>
  40ad6d:	nop    DWORD PTR [rax]
  40ad70:	cmp    QWORD PTR [r15+r12*8],r13
  40ad74:	jne    40ad97 <__swc_fn_4fa09e82_000004_913db40c+0x4d7>
  40ad76:	mov    rax,QWORD PTR [rbx]
  40ad79:	mov    rax,QWORD PTR [rax+r12*8]
  40ad7d:	mov    rcx,QWORD PTR [rbx+0x20]
  40ad81:	add    rax,rcx
  40ad84:	lea    rdx,[rcx+rdi*1]
  40ad88:	mov    rcx,rax
  40ad8b:	mov    r8,r13
  40ad8e:	call   40cb70 <__swc_fn_4fa09e82_000112_3dc01326>
  40ad93:	test   eax,eax
  40ad95:	je     40ada5 <__swc_fn_4fa09e82_000004_913db40c+0x4e5>
  40ad97:	inc    r12
  40ad9a:	and    r12,QWORD PTR [rbx+0x28]
  40ad9e:	cmp    BYTE PTR [r14+r12*1],0x0
  40ada3:	jne    40ad70 <__swc_fn_4fa09e82_000004_913db40c+0x4b0>
  40ada5:	cmp    BYTE PTR [r14+r12*1],0x0
  40adaa:	jne    40add3 <__swc_fn_4fa09e82_000004_913db40c+0x513>
  40adac:	mov    BYTE PTR [r14+r12*1],0x1
  40adb1:	mov    rax,QWORD PTR [rbx]
  40adb4:	mov    QWORD PTR [rax+r12*8],rdi
  40adb8:	mov    rax,QWORD PTR [rbx+0x8]
  40adbc:	mov    QWORD PTR [rax+r12*8],r13
  40adc0:	mov    rax,QWORD PTR [rbx+0x10]
  40adc4:	mov    QWORD PTR [rax+r12*8],0x1
  40adcc:	add    QWORD PTR [rsi+0x30],0x1
  40add1:	jmp    40addb <__swc_fn_4fa09e82_000004_913db40c+0x51b>
  40add3:	mov    rax,QWORD PTR [rbx+0x10]
  40add7:	inc    QWORD PTR [rax+r12*8]
  40addb:	mov    rsi,QWORD PTR [rbx+0x30]
  40addf:	lea    rdi,[rsi*8+0x0]
  40ade7:	mov    rcx,rdi
  40adea:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40adef:	mov    QWORD PTR [rip+0x1925a],rax        # 424050 <__swc_bss_base_4fa09e82+0x10>
  40adf6:	mov    rcx,rdi
  40adf9:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40adfe:	mov    QWORD PTR [rip+0x1925b],rax        # 424060 <__swc_bss_base_4fa09e82+0x20>
  40ae05:	mov    rcx,rdi
  40ae08:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40ae0d:	mov    QWORD PTR [rip+0x19244],rax        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40ae14:	mov    rcx,rdi
  40ae17:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40ae1c:	mov    QWORD PTR [rip+0x19225],rax        # 424048 <__swc_bss_base_4fa09e82+0x8>
  40ae23:	xor    ecx,ecx
  40ae25:	xor    edx,edx
  40ae27:	mov    r8,QWORD PTR [rip+0x19222]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  40ae2e:	mov    r9,QWORD PTR [rip+0x1922b]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  40ae35:	mov    r10,QWORD PTR [rip+0x1921c]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40ae3c:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae46:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae50:	mov    r11,QWORD PTR [rbx+0x18]
  40ae54:	cmp    BYTE PTR [r11+rdx*1],0x0
  40ae59:	je     40ae85 <__swc_fn_4fa09e82_000004_913db40c+0x5c5>
  40ae5b:	mov    r11,QWORD PTR [rbx+0x10]
  40ae5f:	mov    r11,QWORD PTR [r11+rdx*8]
  40ae63:	mov    QWORD PTR [r8+rcx*8],r11
  40ae67:	mov    r11,QWORD PTR [rbx]
  40ae6a:	mov    r11,QWORD PTR [r11+rdx*8]
  40ae6e:	mov    QWORD PTR [r9+rcx*8],r11
  40ae72:	mov    r11,QWORD PTR [rbx+0x8]
  40ae76:	mov    r11,QWORD PTR [r11+rdx*8]
  40ae7a:	mov    QWORD PTR [r10+rcx*8],r11
  40ae7e:	mov    QWORD PTR [rax+rcx*8],rcx
  40ae82:	inc    rcx
  40ae85:	add    rdx,0x1
  40ae89:	cmp    rdx,0x4000
  40ae90:	jb     40ae50 <__swc_fn_4fa09e82_000004_913db40c+0x590>
  40ae92:	xor    ecx,ecx
  40ae94:	lea    rdx,[rsi-0x1]
  40ae98:	call   4072f0 <__swc_fn_4fa09e82_000003_6937fe70>
  40ae9d:	imul   rsi,rsi,0x7
  40aea1:	xor    eax,eax
  40aea3:	mov    rcx,QWORD PTR [rip+0x1919e]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  40aeaa:	mov    rdx,QWORD PTR [rip+0x1919f]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  40aeb1:	cs nop WORD PTR [rax+rax*1+0x0]
  40aebb:	nop    DWORD PTR [rax+rax*1+0x0]
  40aec0:	lea    r8,[rax+0x1]
  40aec4:	mov    rax,QWORD PTR [rcx+rax*8]
  40aec8:	mov    r9,r8
  40aecb:	imul   r9,QWORD PTR [rdx+rax*8]
  40aed0:	add    rsi,r9
  40aed3:	mov    rax,r8
  40aed6:	cmp    r8,0x14
  40aeda:	jb     40aec0 <__swc_fn_4fa09e82_000004_913db40c+0x600>
  40aedc:	call   40dd60 <__swc_fn_4fa09e82_000002_1ca87929>
  40aee1:	vsubsd xmm0,xmm0,xmm6
  40aee5:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x833b]        # 413228 <__swc_rdata_base_4fa09e82+0x118>
  40aeed:	lea    rax,[rip+0x822c]        # 413120 <__swc_rdata_base_4fa09e82+0x10>
  40aef4:	sub    rsp,0x88
  40aefb:	mov    rcx,rsp
  40aefe:	vmovups xmm1,XMMWORD PTR [rip+0x8302]        # 413208 <__swc_rdata_base_4fa09e82+0xf8>
  40af06:	vmovups XMMWORD PTR [rcx],xmm1
  40af0a:	mov    QWORD PTR [rcx+0x30],rsp
  40af0e:	lea    rdx,[rip+0x821b]        # 413130 <__swc_rdata_base_4fa09e82+0x20>
  40af15:	mov    QWORD PTR [rcx+0x38],rdx
  40af19:	mov    QWORD PTR [rcx+0x10],rsi
  40af1d:	lea    r8,[rsp+0x10]
  40af22:	mov    QWORD PTR [rcx+0x40],r8
  40af26:	lea    r8,[rip+0x824b]        # 413178 <__swc_rdata_base_4fa09e82+0x68>
  40af2d:	mov    QWORD PTR [rcx+0x48],r8
  40af31:	vmovups xmm1,XMMWORD PTR [rip+0x82df]        # 413218 <__swc_rdata_base_4fa09e82+0x108>
  40af39:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40af3e:	lea    r8,[rsp+0x18]
  40af43:	mov    QWORD PTR [rcx+0x50],r8
  40af47:	mov    QWORD PTR [rcx+0x58],rdx
  40af4b:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40af50:	lea    r8,[rcx+0x28]
  40af54:	mov    QWORD PTR [rcx+0x60],r8
  40af58:	lea    r8,[rip+0x8261]        # 4131c0 <__swc_rdata_base_4fa09e82+0xb0>
  40af5f:	mov    QWORD PTR [rcx+0x68],r8
  40af63:	mov    QWORD PTR [rcx+0x70],rax
  40af67:	mov    QWORD PTR [rcx+0x78],rdx
  40af6b:	lea    rax,[rcx+0x30]
  40af6f:	mov    QWORD PTR [rcx+0x80],rax
  40af76:	mov    QWORD PTR [rcx+0x88],0x5
  40af81:	lea    rcx,[rcx+0x80]
  40af88:	sub    rsp,0x8
  40af8c:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40af91:	add    rsp,0xe8
  40af98:	vmovups xmm6,XMMWORD PTR [rsp]
  40af9d:	add    rsp,0x10
  40afa1:	pop    r14
  40afa3:	pop    r13
  40afa5:	pop    r15
  40afa7:	pop    r12
  40afa9:	pop    rdi
  40afaa:	pop    rsi
  40afab:	pop    rbx
  40afac:	pop    rbp
  40afad:	ret
	...

000000000040afb0 <__swc_fn_4fa09e82_000007_81d2e1e9>:
  40afb0:	sub    rsp,0x8
  40afb4:	call   40cd30 <__swc_fn_4fa09e82_000115_6b799b8d>
  40afb9:	mov    rcx,rax
  40afbc:	test   rax,rax
  40afbf:	je     40afe6 <__swc_fn_4fa09e82_000007_81d2e1e9+0x36>
  40afc1:	lea    rdx,[rip+0x190a8]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40afc8:	mov    r8,QWORD PTR [rip+0x190a1]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40afcf:	nop
  40afd0:	lea    r9,[r8+0x1]
  40afd4:	mov    rax,r8
  40afd7:	lock cmpxchg QWORD PTR [rdx],r9
  40afdc:	cmp    rax,r8
  40afdf:	je     40afe6 <__swc_fn_4fa09e82_000007_81d2e1e9+0x36>
  40afe1:	mov    r8,rax
  40afe4:	jmp    40afd0 <__swc_fn_4fa09e82_000007_81d2e1e9+0x20>
  40afe6:	mov    rax,rcx
  40afe9:	add    rsp,0x8
  40afed:	ret
	...

000000000040aff0 <__swc_fn_4fa09e82_000010_065ed5b1>:
  40aff0:	mov    r8d,edx
  40aff3:	xor    eax,eax
  40aff5:	tzcnt  eax,edx
  40aff9:	shrx   r9d,edx,eax
  40affe:	mov    DWORD PTR [rcx+0x2c],edx
  40b001:	xor    eax,eax
  40b003:	tzcnt  eax,edx
  40b007:	mov    BYTE PTR [rcx+0x38],al
  40b00a:	mov    eax,0xffffffff
  40b00f:	xor    edx,edx
  40b011:	div    r8d
  40b014:	mov    DWORD PTR [rcx+0x34],eax
  40b017:	mov    eax,r9d
  40b01a:	mov    edx,r9d
  40b01d:	imul   edx,r9d
  40b021:	mov    r8d,0x2
  40b027:	sub    r8d,edx
  40b02a:	imul   eax,r8d
  40b02e:	mov    edx,r9d
  40b031:	imul   edx,eax
  40b034:	mov    r8d,0x2
  40b03a:	sub    r8d,edx
  40b03d:	imul   eax,r8d
  40b041:	mov    edx,r9d
  40b044:	imul   edx,eax
  40b047:	mov    r8d,0x2
  40b04d:	sub    r8d,edx
  40b050:	imul   eax,r8d
  40b054:	mov    edx,r9d
  40b057:	imul   edx,eax
  40b05a:	mov    r8d,0x2
  40b060:	sub    r8d,edx
  40b063:	imul   eax,r8d
  40b067:	imul   r9d,eax
  40b06b:	mov    edx,0x2
  40b070:	sub    edx,r9d
  40b073:	imul   eax,edx
  40b076:	mov    DWORD PTR [rcx+0x30],eax
  40b079:	ret
  40b07a:	add    BYTE PTR [rax],al
  40b07c:	add    BYTE PTR [rax],al
	...

000000000040b080 <__swc_fn_4fa09e82_000013_861b8b62>:
  40b080:	xor    eax,eax
  40b082:	mov    DWORD PTR [rcx+0x68],eax
  40b085:	ret
	...

000000000040b090 <__swc_fn_4fa09e82_000016_9dea5065>:
  40b090:	mov    eax,DWORD PTR [rcx+0x28]
  40b093:	shlx   eax,edx,eax
  40b098:	shl    rax,0x10
  40b09c:	lea    rdx,[rcx+rax*1]
  40b0a0:	lea    rax,[rcx+0x3000]
  40b0a7:	cmp    rdx,rax
  40b0aa:	cmovae rax,rdx
  40b0ae:	ret
	...

000000000040b0b0 <__swc_fn_4fa09e82_000019_283e2b5e>:
  40b0b0:	push   rsi
  40b0b1:	push   rdi
  40b0b2:	push   r12
  40b0b4:	push   r13
  40b0b6:	push   r14
  40b0b8:	mov    rsi,rdx
  40b0bb:	mov    rdi,rcx
  40b0be:	rex mov dl,BYTE PTR [rsi+0x3a]
  40b0c2:	mov    ecx,DWORD PTR [rdi+0x28]
  40b0c5:	shr    dl,cl
  40b0c7:	mov    r12d,0x1
  40b0cd:	mov    ecx,edx
  40b0cf:	shl    r12,cl
  40b0d2:	mov    r13d,DWORD PTR [rsi+0x3c]
  40b0d6:	rex mov BYTE PTR [rsi+0x3b],0x0
  40b0db:	mov    QWORD PTR [rsi+0x40],0x0
  40b0e3:	mov    QWORD PTR [rsi],0x0
  40b0ea:	mov    rax,QWORD PTR [rsi+0x10]
  40b0ee:	mov    QWORD PTR [rsi+0x20],rax
  40b0f2:	lea    r14,[rip+0x18f7f]        # 424078 <__swc_bss_base_4fa09e82+0x38>
  40b0f9:	mov    rax,QWORD PTR [r14]
  40b0fc:	shr    rax,0x2
  40b100:	mov    rcx,rax
  40b103:	cmp    rax,0x800000
  40b10a:	mov    eax,0x800000
  40b10f:	cmovb  rcx,rax
  40b113:	lea    r8,[rip+0x18f6e]        # 424088 <__swc_bss_base_4fa09e82+0x48>
  40b11a:	mov    rax,QWORD PTR [r8]
  40b11d:	mov    r9,rax
  40b120:	lea    r10,[r9+r13*1]
  40b124:	cmp    r10,rcx
  40b127:	ja     40b14b <__swc_fn_4fa09e82_000019_283e2b5e+0x9b>
  40b129:	mov    rax,r9
  40b12c:	lock cmpxchg QWORD PTR [r8],r10
  40b131:	cmp    rax,r9
  40b134:	je     40b13b <__swc_fn_4fa09e82_000019_283e2b5e+0x8b>
  40b136:	mov    r9,rax
  40b139:	jmp    40b120 <__swc_fn_4fa09e82_000019_283e2b5e+0x70>
  40b13b:	mov    rcx,rdi
  40b13e:	mov    rdx,r12
  40b141:	call   407850 <__swc_fn_4fa09e82_000021_de02dbdf>
  40b146:	jmp    40b1cd <__swc_fn_4fa09e82_000019_283e2b5e+0x11d>
  40b14b:	mov    rcx,rdi
  40b14e:	movzx  edx,dl
  40b151:	call   40b090 <__swc_fn_4fa09e82_000016_9dea5065>
  40b156:	test   r13,r13
  40b159:	je     40b1c6 <__swc_fn_4fa09e82_000019_283e2b5e+0x116>
  40b15f:	mov    rcx,rax
  40b162:	mov    rdx,r13
  40b165:	call   40ceb0 <__swc_fn_4fa09e82_000118_e9fc0224>
  40b16a:	mov    rcx,QWORD PTR [rip+0x18f07]        # 424078 <__swc_bss_base_4fa09e82+0x38>
  40b171:	cs nop WORD PTR [rax+rax*1+0x0]
  40b17b:	nop    DWORD PTR [rax+rax*1+0x0]
  40b180:	mov    rdx,rcx
  40b183:	sub    rdx,r13
  40b186:	mov    rax,rcx
  40b189:	lock cmpxchg QWORD PTR [r14],rdx
  40b18e:	cmp    rax,rcx
  40b191:	je     40b198 <__swc_fn_4fa09e82_000019_283e2b5e+0xe8>
  40b193:	mov    rcx,rax
  40b196:	jmp    40b180 <__swc_fn_4fa09e82_000019_283e2b5e+0xd0>
  40b198:	lea    rcx,[rip+0x18ef1]        # 424090 <__swc_bss_base_4fa09e82+0x50>
  40b19f:	mov    rdx,QWORD PTR [rip+0x18eea]        # 424090 <__swc_bss_base_4fa09e82+0x50>
  40b1a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40b1b0:	lea    r8,[rdx+0x1]
  40b1b4:	mov    rax,rdx
  40b1b7:	lock cmpxchg QWORD PTR [rcx],r8
  40b1bc:	cmp    rax,rdx
  40b1bf:	je     40b1c6 <__swc_fn_4fa09e82_000019_283e2b5e+0x116>
  40b1c1:	mov    rdx,rax
  40b1c4:	jmp    40b1b0 <__swc_fn_4fa09e82_000019_283e2b5e+0x100>
  40b1c6:	mov    DWORD PTR [rsi+0x3c],0x0
  40b1cd:	mov    rcx,rdi
  40b1d0:	mov    rdx,r12
  40b1d3:	call   40e1d0 <__swc_fn_4fa09e82_000023_c8f5f27c>
  40b1d8:	pop    r14
  40b1da:	pop    r13
  40b1dc:	pop    r12
  40b1de:	pop    rdi
  40b1df:	pop    rsi
  40b1e0:	ret
	...

000000000040b1f0 <__swc_fn_4fa09e82_000022_fd2b165c>:
  40b1f0:	mov    r8,QWORD PTR [rcx+0x48]
  40b1f4:	test   r8,rdx
  40b1f7:	je     40b228 <__swc_fn_4fa09e82_000022_fd2b165c+0x38>
  40b1f9:	nop    DWORD PTR [rax+0x0]
  40b200:	mov    rax,rdx
  40b203:	not    rax
  40b206:	mov    r9,r8
  40b209:	and    r9,rax
  40b20c:	mov    rax,r8
  40b20f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40b215:	cmp    rax,r8
  40b218:	jne    40b220 <__swc_fn_4fa09e82_000022_fd2b165c+0x30>
  40b21a:	mov    eax,0x1
  40b21f:	ret
  40b220:	mov    r8,rax
  40b223:	test   rax,rdx
  40b226:	jne    40b200 <__swc_fn_4fa09e82_000022_fd2b165c+0x10>
  40b228:	xor    eax,eax
  40b22a:	ret
  40b22b:	add    BYTE PTR [rax],al
  40b22d:	add    BYTE PTR [rax],al
	...

000000000040b230 <__swc_fn_4fa09e82_000025_2685aade>:
  40b230:	push   rsi
  40b231:	push   rdi
  40b232:	push   r12
  40b234:	push   r13
  40b236:	sub    rsp,0x8
  40b23a:	mov    rsi,rdx
  40b23d:	mov    rdi,rcx
  40b240:	lea    r12,[rip+0x18fd9]        # 424220 <__swc_bss_base_4fa09e82+0x1e0>
  40b247:	mov    rcx,r12
  40b24a:	call   409d20 <__swc_fn_4fa09e82_000141_86bb0f90>
  40b24f:	xor    eax,eax
  40b251:	mov    rcx,QWORD PTR [rip+0x18fd0]        # 424228 <__swc_bss_base_4fa09e82+0x1e8>
  40b258:	mov    r13,rcx
  40b25b:	test   r13,r13
  40b25e:	je     40b2ab <__swc_fn_4fa09e82_000025_2685aade+0x7b>
  40b260:	mov    rcx,QWORD PTR [r13+0x10]
  40b264:	cmp    DWORD PTR [r13+0x28],esi
  40b268:	jne    40b2a0 <__swc_fn_4fa09e82_000025_2685aade+0x70>
  40b26a:	test   rax,rax
  40b26d:	jne    40b278 <__swc_fn_4fa09e82_000025_2685aade+0x48>
  40b26f:	mov    QWORD PTR [rip+0x18fb2],rcx        # 424228 <__swc_bss_base_4fa09e82+0x1e8>
  40b276:	jmp    40b27c <__swc_fn_4fa09e82_000025_2685aade+0x4c>
  40b278:	mov    QWORD PTR [rax+0x10],rcx
  40b27c:	vxorps xmm0,xmm0,xmm0
  40b280:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40b286:	mov    QWORD PTR [r13+0x8],rdi
  40b28a:	mov    rcx,r12
  40b28d:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40b292:	mov    rax,r13
  40b295:	add    rsp,0x8
  40b299:	pop    r13
  40b29b:	pop    r12
  40b29d:	pop    rdi
  40b29e:	pop    rsi
  40b29f:	ret
  40b2a0:	mov    rax,r13
  40b2a3:	mov    r13,rcx
  40b2a6:	test   rcx,rcx
  40b2a9:	jne    40b260 <__swc_fn_4fa09e82_000025_2685aade+0x30>
  40b2ab:	mov    ecx,esi
  40b2ad:	call   407880 <__swc_fn_4fa09e82_000024_2d0fcd2c>
  40b2b2:	mov    rsi,rax
  40b2b5:	test   rax,rax
  40b2b8:	jne    40b2cf <__swc_fn_4fa09e82_000025_2685aade+0x9f>
  40b2ba:	mov    rcx,r12
  40b2bd:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40b2c2:	xor    eax,eax
  40b2c4:	add    rsp,0x8
  40b2c8:	pop    r13
  40b2ca:	pop    r12
  40b2cc:	pop    rdi
  40b2cd:	pop    rsi
  40b2ce:	ret
  40b2cf:	mov    QWORD PTR [rsi+0x8],rdi
  40b2d3:	mov    rcx,r12
  40b2d6:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40b2db:	mov    rax,rsi
  40b2de:	add    rsp,0x8
  40b2e2:	pop    r13
  40b2e4:	pop    r12
  40b2e6:	pop    rdi
  40b2e7:	pop    rsi
  40b2e8:	ret
	...

000000000040b300 <__swc_fn_4fa09e82_000028_9798fb47>:
  40b300:	vxorps xmm0,xmm0,xmm0
  40b304:	xor    eax,eax
  40b306:	cs nop WORD PTR [rax+rax*1+0x0]
  40b310:	cs nop WORD PTR [rax+rax*1+0x0]
  40b31a:	nop    WORD PTR [rax+rax*1+0x0]
  40b320:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40b325:	add    rax,0x10
  40b329:	cmp    rax,0x2b00
  40b330:	jne    40b320 <__swc_fn_4fa09e82_000028_9798fb47+0x20>
  40b332:	ret
	...

000000000040b340 <__swc_fn_4fa09e82_000031_9798fb47>:
  40b340:	vxorps xmm0,xmm0,xmm0
  40b344:	vmovups XMMWORD PTR [rcx],xmm0
  40b348:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b34d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b352:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b357:	ret
	...

000000000040b360 <__swc_fn_4fa09e82_000034_9798fb47>:
  40b360:	vxorps xmm0,xmm0,xmm0
  40b364:	vmovups XMMWORD PTR [rcx],xmm0
  40b368:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b36d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b372:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b377:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b37c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40b381:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40b386:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40b38b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40b393:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40b39b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40b3a3:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40b3ab:	mov    QWORD PTR [rcx+0xc0],0x0
  40b3b6:	ret
	...

000000000040b3c0 <__swc_fn_4fa09e82_000037_92d9bbff>:
  40b3c0:	push   rsi
  40b3c1:	push   rdi
  40b3c2:	sub    rsp,0x8
  40b3c6:	mov    rsi,rcx
  40b3c9:	lea    rdi,[rip+0x16c38]        # 422008 <__swc_data_base_4fa09e82+0x8>
  40b3d0:	mov    rax,QWORD PTR [rdi]
  40b3d3:	cmp    rax,0xffffffffffffffff
  40b3d7:	je     40b3de <__swc_fn_4fa09e82_000037_92d9bbff+0x1e>
  40b3d9:	mov    rdi,rax
  40b3dc:	jmp    40b40b <__swc_fn_4fa09e82_000037_92d9bbff+0x4b>
  40b3de:	call   409a00 <__swc_fn_4fa09e82_000129_58f0f391>
  40b3e3:	mov    rcx,rax
  40b3e6:	cmp    rax,0xffffffffffffffff
  40b3ea:	je     40b41c <__swc_fn_4fa09e82_000037_92d9bbff+0x5c>
  40b3ec:	mov    rax,0xffffffffffffffff
  40b3f3:	lock cmpxchg QWORD PTR [rdi],rcx
  40b3f8:	cmp    rax,0xffffffffffffffff
  40b3fc:	je     40b408 <__swc_fn_4fa09e82_000037_92d9bbff+0x48>
  40b3fe:	mov    rdi,rax
  40b401:	call   40d290 <__swc_fn_4fa09e82_000130_a481cb88>
  40b406:	jmp    40b40b <__swc_fn_4fa09e82_000037_92d9bbff+0x4b>
  40b408:	mov    rdi,rcx
  40b40b:	cmp    rdi,0xffffffffffffffff
  40b40f:	je     40b41c <__swc_fn_4fa09e82_000037_92d9bbff+0x5c>
  40b411:	mov    rcx,rdi
  40b414:	mov    rdx,rsi
  40b417:	call   4106b0 <__swc_fn_4fa09e82_000131_4bbe3f14>
  40b41c:	add    rsp,0x8
  40b420:	pop    rdi
  40b421:	pop    rsi
  40b422:	ret
	...

000000000040b430 <__swc_fn_4fa09e82_000040_03f1bf9a>:
  40b430:	sub    rsp,0x38
  40b434:	mov    rax,rdx
  40b437:	test   dl,dl
  40b439:	jne    40b451 <__swc_fn_4fa09e82_000040_03f1bf9a+0x21>
  40b43b:	mov    rax,r8
  40b43e:	test   r8b,r8b
  40b441:	cmove  eax,r9d
  40b445:	test   al,al
  40b447:	cmove  eax,r10d
  40b44b:	test   al,al
  40b44d:	cmove  eax,r11d
  40b451:	test   al,al
  40b453:	jne    40b45a <__swc_fn_4fa09e82_000040_03f1bf9a+0x2a>
  40b455:	add    rsp,0x38
  40b459:	ret
  40b45a:	lea    rcx,[rip+0x7dd7]        # 413238 <__swc_rdata_base_4fa09e82+0x128>
  40b461:	vmovups xmm0,XMMWORD PTR [rip+0x7ddf]        # 413248 <__swc_rdata_base_4fa09e82+0x138>
  40b469:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40b46f:	vmovups xmm0,XMMWORD PTR [rip+0x7de1]        # 413258 <__swc_rdata_base_4fa09e82+0x148>
  40b477:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40b47d:	vmovups xmm0,XMMWORD PTR [rip+0x7de3]        # 413268 <__swc_rdata_base_4fa09e82+0x158>
  40b485:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40b48b:	lea    rdx,[rsp+0x8]
  40b490:	call   4094a0 <__swc_fn_4fa09e82_000108_90faaa26>
  40b495:	jmp    40b455 <__swc_fn_4fa09e82_000040_03f1bf9a+0x25>
	...

000000000040b4a0 <__swc_fn_4fa09e82_000043_facd3e17>:
  40b4a0:	sub    rsp,0x8
  40b4a4:	mov    eax,0x1000
  40b4a9:	test   eax,eax
  40b4ab:	mov    r8d,0x8
  40b4b1:	cmove  eax,r8d
  40b4b5:	dec    rax
  40b4b8:	mov    r8,0xffffffffffffffff
  40b4bf:	sub    r8,rax
  40b4c2:	cmp    rdx,r8
  40b4c5:	ja     40b4d5 <__swc_fn_4fa09e82_000043_facd3e17+0x35>
  40b4c7:	add    rdx,rax
  40b4ca:	not    rax
  40b4cd:	mov    r8,rdx
  40b4d0:	and    r8,rax
  40b4d3:	jne    40b4dc <__swc_fn_4fa09e82_000043_facd3e17+0x3c>
  40b4d5:	xor    eax,eax
  40b4d7:	add    rsp,0x8
  40b4db:	ret
  40b4dc:	mov    rdx,r8
  40b4df:	call   407ba0 <__swc_fn_4fa09e82_000042_c90d80c1>
  40b4e4:	add    rsp,0x8
  40b4e8:	ret
  40b4e9:	add    BYTE PTR [rax],al
  40b4eb:	add    BYTE PTR [rax],al
  40b4ed:	add    BYTE PTR [rax],al
	...

000000000040b4f0 <__swc_fn_4fa09e82_000046_d8bd27c3>:
  40b4f0:	push   rsi
  40b4f1:	push   rdi
  40b4f2:	sub    rsp,0x8
  40b4f6:	mov    rsi,rdx
  40b4f9:	mov    rdi,rcx
  40b4fc:	test   rdx,rdx
  40b4ff:	je     40b51b <__swc_fn_4fa09e82_000046_d8bd27c3+0x2b>
  40b501:	xor    ecx,ecx
  40b503:	call   40e2f0 <__swc_fn_4fa09e82_000038_28d0e998>
  40b508:	mov    rax,QWORD PTR [rsi]
  40b50b:	test   rax,rax
  40b50e:	je     40b51b <__swc_fn_4fa09e82_000046_d8bd27c3+0x2b>
  40b510:	mov    rcx,rax
  40b513:	mov    rdx,rsi
  40b516:	call   40e400 <__swc_fn_4fa09e82_000047_b30433d0>
  40b51b:	mov    rcx,rdi
  40b51e:	call   407c00 <__swc_fn_4fa09e82_000045_a78ae66b>
  40b523:	mov    rsi,rax
  40b526:	test   rax,rax
  40b529:	jne    40b534 <__swc_fn_4fa09e82_000046_d8bd27c3+0x44>
  40b52b:	xor    eax,eax
  40b52d:	add    rsp,0x8
  40b531:	pop    rdi
  40b532:	pop    rsi
  40b533:	ret
  40b534:	mov    rcx,rsi
  40b537:	call   40e2f0 <__swc_fn_4fa09e82_000038_28d0e998>
  40b53c:	mov    rax,rsi
  40b53f:	add    rsp,0x8
  40b543:	pop    rdi
  40b544:	pop    rsi
  40b545:	ret
	...

000000000040b550 <__swc_fn_4fa09e82_000049_137687bb>:
  40b550:	movzx  eax,BYTE PTR [r8+0x39]
  40b555:	lea    rax,[rax+rax*4]
  40b559:	lea    rax,[rdx+rax*8+0x28]
  40b55e:	mov    ecx,DWORD PTR [r8+0x6c]
  40b562:	test   ecx,ecx
  40b564:	je     40b59d <__swc_fn_4fa09e82_000049_137687bb+0x4d>
  40b566:	mov    rcx,QWORD PTR [r8+0x50]
  40b56a:	test   rcx,rcx
  40b56d:	je     40b579 <__swc_fn_4fa09e82_000049_137687bb+0x29>
  40b56f:	mov    rax,QWORD PTR [r8+0x48]
  40b573:	mov    QWORD PTR [rcx+0x48],rax
  40b577:	jmp    40b581 <__swc_fn_4fa09e82_000049_137687bb+0x31>
  40b579:	mov    rcx,QWORD PTR [r8+0x48]
  40b57d:	mov    QWORD PTR [rax+0x18],rcx
  40b581:	mov    rax,QWORD PTR [r8+0x48]
  40b585:	test   rax,rax
  40b588:	je     40b592 <__swc_fn_4fa09e82_000049_137687bb+0x42>
  40b58a:	mov    rcx,QWORD PTR [r8+0x50]
  40b58e:	mov    QWORD PTR [rax+0x50],rcx
  40b592:	vxorps xmm0,xmm0,xmm0
  40b596:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40b59c:	ret
  40b59d:	mov    rcx,QWORD PTR [r8+0x50]
  40b5a1:	test   rcx,rcx
  40b5a4:	je     40b5b0 <__swc_fn_4fa09e82_000049_137687bb+0x60>
  40b5a6:	mov    rdx,QWORD PTR [r8+0x48]
  40b5aa:	mov    QWORD PTR [rcx+0x48],rdx
  40b5ae:	jmp    40b5b8 <__swc_fn_4fa09e82_000049_137687bb+0x68>
  40b5b0:	mov    rcx,QWORD PTR [r8+0x48]
  40b5b4:	mov    QWORD PTR [rax+0x8],rcx
  40b5b8:	mov    rcx,QWORD PTR [r8+0x48]
  40b5bc:	test   rcx,rcx
  40b5bf:	je     40b5cb <__swc_fn_4fa09e82_000049_137687bb+0x7b>
  40b5c1:	mov    rdx,QWORD PTR [r8+0x50]
  40b5c5:	mov    QWORD PTR [rcx+0x50],rdx
  40b5c9:	jmp    40b5d3 <__swc_fn_4fa09e82_000049_137687bb+0x83>
  40b5cb:	mov    rcx,QWORD PTR [r8+0x50]
  40b5cf:	mov    QWORD PTR [rax+0x10],rcx
  40b5d3:	cmp    QWORD PTR [rax],r8
  40b5d6:	jne    40b5df <__swc_fn_4fa09e82_000049_137687bb+0x8f>
  40b5d8:	mov    QWORD PTR [rax],0x0
  40b5df:	vxorps xmm0,xmm0,xmm0
  40b5e3:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40b5e9:	ret
  40b5ea:	add    BYTE PTR [rax],al
  40b5ec:	add    BYTE PTR [rax],al
	...

000000000040b5f0 <__swc_fn_4fa09e82_000052_e072b516>:
  40b5f0:	sub    rsp,0x8
  40b5f4:	mov    r9,r8
  40b5f7:	mov    r10,rdx
  40b5fa:	call   40b550 <__swc_fn_4fa09e82_000049_137687bb>
  40b5ff:	mov    DWORD PTR [r9+0x6c],0x0
  40b607:	movzx  eax,BYTE PTR [r9+0x39]
  40b60c:	lea    rax,[rax+rax*4]
  40b610:	lea    rax,[r10+rax*8+0x28]
  40b615:	mov    rcx,QWORD PTR [rax+0x10]
  40b619:	mov    QWORD PTR [r9+0x50],rcx
  40b61d:	mov    QWORD PTR [r9+0x48],0x0
  40b625:	mov    rcx,QWORD PTR [rax+0x10]
  40b629:	test   rcx,rcx
  40b62c:	je     40b634 <__swc_fn_4fa09e82_000052_e072b516+0x44>
  40b62e:	mov    QWORD PTR [rcx+0x48],r9
  40b632:	jmp    40b638 <__swc_fn_4fa09e82_000052_e072b516+0x48>
  40b634:	mov    QWORD PTR [rax+0x8],r9
  40b638:	mov    QWORD PTR [rax+0x10],r9
  40b63c:	add    rsp,0x8
  40b640:	ret
	...

000000000040b660 <__swc_fn_4fa09e82_000055_faa92dcc>:
  40b660:	push   rsi
  40b661:	push   rdi
  40b662:	push   r12
  40b664:	push   r13
  40b666:	push   r14
  40b668:	push   r15
  40b66a:	sub    rsp,0x1f8
  40b671:	mov    esi,r8d
  40b674:	mov    QWORD PTR [rsp+0x1e8],rsi
  40b67c:	mov    rdi,rcx
  40b67f:	mov    r12,rdx
  40b682:	lea    r13,[rsi+rsi*4]
  40b686:	lea    r13,[rdx+r13*8+0x28]
  40b68b:	call   40e860 <__swc_fn_4fa09e82_000053_d846b172>
  40b690:	add    DWORD PTR [r12+0x24],0x1
  40b696:	test   BYTE PTR [r12+0x24],0x3f
  40b69c:	jne    40b6a6 <__swc_fn_4fa09e82_000055_faa92dcc+0x46>
  40b69e:	mov    rcx,rdi
  40b6a1:	call   407d80 <__swc_fn_4fa09e82_000054_3af34d7f>
  40b6a6:	mov    rax,QWORD PTR [r13+0x8]
  40b6aa:	mov    r14,rax
  40b6ad:	nop    DWORD PTR [rax]
  40b6b0:	test   r14,r14
  40b6b3:	jne    40b6c2 <__swc_fn_4fa09e82_000055_faa92dcc+0x62>
  40b6b5:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40b6bd:	jmp    40b7c9 <__swc_fn_4fa09e82_000055_faa92dcc+0x169>
  40b6c2:	mov    r15,QWORD PTR [r14+0x48]
  40b6c6:	mov    rcx,r14
  40b6c9:	call   40dfc0 <__swc_fn_4fa09e82_000014_e4b0ddfc>
  40b6ce:	mov    rax,QWORD PTR [r14]
  40b6d1:	test   rax,rax
  40b6d4:	je     40b6e6 <__swc_fn_4fa09e82_000055_faa92dcc+0x86>
  40b6d6:	mov    rcx,QWORD PTR [rax]
  40b6d9:	mov    QWORD PTR [r14],rcx
  40b6dc:	add    DWORD PTR [r14+0x28],0x1
  40b6e1:	mov    rsi,rax
  40b6e4:	jmp    40b705 <__swc_fn_4fa09e82_000055_faa92dcc+0xa5>
  40b6e6:	mov    rax,QWORD PTR [r14+0x18]
  40b6ea:	cmp    QWORD PTR [r14+0x20],rax
  40b6ee:	jae    40b703 <__swc_fn_4fa09e82_000055_faa92dcc+0xa3>
  40b6f0:	mov    rsi,QWORD PTR [r14+0x20]
  40b6f4:	mov    eax,DWORD PTR [r14+0x2c]
  40b6f8:	add    QWORD PTR [r14+0x20],rax
  40b6fc:	add    DWORD PTR [r14+0x28],0x1
  40b701:	jmp    40b705 <__swc_fn_4fa09e82_000055_faa92dcc+0xa5>
  40b703:	xor    esi,esi
  40b705:	test   rsi,rsi
  40b708:	jne    40b74d <__swc_fn_4fa09e82_000055_faa92dcc+0xed>
  40b70a:	mov    rcx,r14
  40b70d:	call   40def0 <__swc_fn_4fa09e82_000011_24a20786>
  40b712:	test   al,al
  40b714:	je     40b74d <__swc_fn_4fa09e82_000055_faa92dcc+0xed>
  40b716:	mov    rax,QWORD PTR [r14]
  40b719:	test   rax,rax
  40b71c:	je     40b72b <__swc_fn_4fa09e82_000055_faa92dcc+0xcb>
  40b71e:	mov    rcx,QWORD PTR [rax]
  40b721:	mov    QWORD PTR [r14],rcx
  40b724:	add    DWORD PTR [r14+0x28],0x1
  40b729:	jmp    40b74a <__swc_fn_4fa09e82_000055_faa92dcc+0xea>
  40b72b:	mov    rax,QWORD PTR [r14+0x18]
  40b72f:	cmp    QWORD PTR [r14+0x20],rax
  40b733:	jae    40b748 <__swc_fn_4fa09e82_000055_faa92dcc+0xe8>
  40b735:	mov    rax,QWORD PTR [r14+0x20]
  40b739:	mov    ecx,DWORD PTR [r14+0x2c]
  40b73d:	add    QWORD PTR [r14+0x20],rcx
  40b741:	add    DWORD PTR [r14+0x28],0x1
  40b746:	jmp    40b74a <__swc_fn_4fa09e82_000055_faa92dcc+0xea>
  40b748:	xor    eax,eax
  40b74a:	mov    rsi,rax
  40b74d:	test   rsi,rsi
  40b750:	jne    40b7a3 <__swc_fn_4fa09e82_000055_faa92dcc+0x143>
  40b752:	mov    rcx,rdi
  40b755:	mov    rdx,r12
  40b758:	mov    r8,r14
  40b75b:	call   407ce0 <__swc_fn_4fa09e82_000051_129b9bf4>
  40b760:	test   al,al
  40b762:	jne    40b7a3 <__swc_fn_4fa09e82_000055_faa92dcc+0x143>
  40b764:	mov    rcx,r14
  40b767:	call   40dfc0 <__swc_fn_4fa09e82_000014_e4b0ddfc>
  40b76c:	mov    rax,QWORD PTR [r14]
  40b76f:	test   rax,rax
  40b772:	je     40b781 <__swc_fn_4fa09e82_000055_faa92dcc+0x121>
  40b774:	mov    rcx,QWORD PTR [rax]
  40b777:	mov    QWORD PTR [r14],rcx
  40b77a:	add    DWORD PTR [r14+0x28],0x1
  40b77f:	jmp    40b7a0 <__swc_fn_4fa09e82_000055_faa92dcc+0x140>
  40b781:	mov    rax,QWORD PTR [r14+0x18]
  40b785:	cmp    QWORD PTR [r14+0x20],rax
  40b789:	jae    40b79e <__swc_fn_4fa09e82_000055_faa92dcc+0x13e>
  40b78b:	mov    rax,QWORD PTR [r14+0x20]
  40b78f:	mov    ecx,DWORD PTR [r14+0x2c]
  40b793:	add    QWORD PTR [r14+0x20],rcx
  40b797:	add    DWORD PTR [r14+0x28],0x1
  40b79c:	jmp    40b7a0 <__swc_fn_4fa09e82_000055_faa92dcc+0x140>
  40b79e:	xor    eax,eax
  40b7a0:	mov    rsi,rax
  40b7a3:	test   rsi,rsi
  40b7a6:	je     40b7c1 <__swc_fn_4fa09e82_000055_faa92dcc+0x161>
  40b7a8:	mov    QWORD PTR [r13+0x0],r14
  40b7ac:	mov    rax,rsi
  40b7af:	add    rsp,0x1f8
  40b7b6:	pop    r15
  40b7b8:	pop    r14
  40b7ba:	pop    r13
  40b7bc:	pop    r12
  40b7be:	pop    rdi
  40b7bf:	pop    rsi
  40b7c0:	ret
  40b7c1:	mov    r14,r15
  40b7c4:	jmp    40b6b0 <__swc_fn_4fa09e82_000055_faa92dcc+0x50>
  40b7c9:	cs nop WORD PTR [rax+rax*1+0x0]
  40b7d3:	cs nop WORD PTR [rax+rax*1+0x0]
  40b7dd:	nop    DWORD PTR [rax]
  40b7e0:	mov    rcx,rdi
  40b7e3:	mov    rdx,r12
  40b7e6:	mov    r8d,esi
  40b7e9:	call   40e5a0 <__swc_fn_4fa09e82_000050_ad48ec88>
  40b7ee:	mov    r14,rax
  40b7f1:	test   rax,rax
  40b7f4:	jne    40b80a <__swc_fn_4fa09e82_000055_faa92dcc+0x1aa>
  40b7f6:	xor    eax,eax
  40b7f8:	add    rsp,0x1f8
  40b7ff:	pop    r15
  40b801:	pop    r14
  40b803:	pop    r13
  40b805:	pop    r12
  40b807:	pop    rdi
  40b808:	pop    rsi
  40b809:	ret
  40b80a:	mov    QWORD PTR [r13+0x0],r14
  40b80e:	mov    rax,QWORD PTR [r14]
  40b811:	test   rax,rax
  40b814:	je     40b826 <__swc_fn_4fa09e82_000055_faa92dcc+0x1c6>
  40b816:	mov    rcx,QWORD PTR [rax]
  40b819:	mov    QWORD PTR [r14],rcx
  40b81c:	add    DWORD PTR [r14+0x28],0x1
  40b821:	mov    r15,rax
  40b824:	jmp    40b846 <__swc_fn_4fa09e82_000055_faa92dcc+0x1e6>
  40b826:	mov    rax,QWORD PTR [r14+0x18]
  40b82a:	cmp    QWORD PTR [r14+0x20],rax
  40b82e:	jae    40b843 <__swc_fn_4fa09e82_000055_faa92dcc+0x1e3>
  40b830:	mov    r15,QWORD PTR [r14+0x20]
  40b834:	mov    eax,DWORD PTR [r14+0x2c]
  40b838:	add    QWORD PTR [r14+0x20],rax
  40b83c:	add    DWORD PTR [r14+0x28],0x1
  40b841:	jmp    40b846 <__swc_fn_4fa09e82_000055_faa92dcc+0x1e6>
  40b843:	xor    r15d,r15d
  40b846:	test   r15,r15
  40b849:	jne    40b88e <__swc_fn_4fa09e82_000055_faa92dcc+0x22e>
  40b84b:	mov    rcx,r14
  40b84e:	call   40def0 <__swc_fn_4fa09e82_000011_24a20786>
  40b853:	test   al,al
  40b855:	je     40b88e <__swc_fn_4fa09e82_000055_faa92dcc+0x22e>
  40b857:	mov    rax,QWORD PTR [r14]
  40b85a:	test   rax,rax
  40b85d:	je     40b86c <__swc_fn_4fa09e82_000055_faa92dcc+0x20c>
  40b85f:	mov    rcx,QWORD PTR [rax]
  40b862:	mov    QWORD PTR [r14],rcx
  40b865:	add    DWORD PTR [r14+0x28],0x1
  40b86a:	jmp    40b88b <__swc_fn_4fa09e82_000055_faa92dcc+0x22b>
  40b86c:	mov    rax,QWORD PTR [r14+0x18]
  40b870:	cmp    QWORD PTR [r14+0x20],rax
  40b874:	jae    40b889 <__swc_fn_4fa09e82_000055_faa92dcc+0x229>
  40b876:	mov    rax,QWORD PTR [r14+0x20]
  40b87a:	mov    ecx,DWORD PTR [r14+0x2c]
  40b87e:	add    QWORD PTR [r14+0x20],rcx
  40b882:	add    DWORD PTR [r14+0x28],0x1
  40b887:	jmp    40b88b <__swc_fn_4fa09e82_000055_faa92dcc+0x22b>
  40b889:	xor    eax,eax
  40b88b:	mov    r15,rax
  40b88e:	test   r15,r15
  40b891:	je     40b7e0 <__swc_fn_4fa09e82_000055_faa92dcc+0x180>
  40b897:	mov    rax,r15
  40b89a:	add    rsp,0x1f8
  40b8a1:	pop    r15
  40b8a3:	pop    r14
  40b8a5:	pop    r13
  40b8a7:	pop    r12
  40b8a9:	pop    rdi
  40b8aa:	pop    rsi
  40b8ab:	ret
  40b8ac:	add    BYTE PTR [rax],al
	...

000000000040b8b0 <__swc_fn_4fa09e82_000058_7e1dbcb0>:
  40b8b0:	push   rsi
  40b8b1:	push   rdi
  40b8b2:	push   r12
  40b8b4:	mov    rsi,rdx
  40b8b7:	mov    rax,rdx
  40b8ba:	shr    rax,0xc
  40b8be:	movabs rdx,0x9e3779b97f4a7c15
  40b8c8:	imul   rax,rdx
  40b8cc:	shr    rax,0x20
  40b8d0:	lea    rax,[rax*8+0x0]
  40b8d8:	shr    rax,0x20
  40b8dc:	lea    rax,[rax*8+0x0]
  40b8e4:	lea    rax,[rcx+rax*8+0x40]
  40b8e9:	xor    edx,edx
  40b8eb:	test   dl,dl
  40b8ed:	lea    rdi,[rcx+0x8]
  40b8f1:	cmove  rdi,rax
  40b8f5:	xor    edx,edx
  40b8f7:	test   dl,dl
  40b8f9:	lea    r12,[rcx+0x30]
  40b8fd:	lea    rax,[rax+0x8]
  40b901:	cmove  r12,rax
  40b905:	mov    rcx,rdi
  40b908:	call   409d20 <__swc_fn_4fa09e82_000141_86bb0f90>
  40b90d:	mov    QWORD PTR [rsi+0x30],0x0
  40b915:	mov    rax,QWORD PTR [r12]
  40b919:	mov    QWORD PTR [rsi+0x38],rax
  40b91d:	test   rax,rax
  40b920:	je     40b92a <__swc_fn_4fa09e82_000058_7e1dbcb0+0x7a>
  40b922:	mov    rax,QWORD PTR [rsi+0x38]
  40b926:	mov    QWORD PTR [rax+0x30],rsi
  40b92a:	mov    QWORD PTR [r12],rsi
  40b92e:	mov    rcx,rdi
  40b931:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40b936:	pop    r12
  40b938:	pop    rdi
  40b939:	pop    rsi
  40b93a:	ret
  40b93b:	add    BYTE PTR [rax],al
  40b93d:	add    BYTE PTR [rax],al
	...

000000000040b940 <__swc_fn_4fa09e82_000061_15c28ca7>:
  40b940:	lea    rax,[rdx+rdx*4]
  40b944:	lea    rax,[rcx+rax*8+0x268]
  40b94c:	mov    rdx,QWORD PTR [rax+0x10]
  40b950:	sub    QWORD PTR [rcx+0x2a68],rdx
  40b957:	sub    QWORD PTR [rcx+0x2a70],0x1
  40b95f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40b966:	lea    rdx,[rdx+rdx*4]
  40b96a:	lea    rdx,[rcx+rdx*8+0x268]
  40b972:	vmovups xmm0,XMMWORD PTR [rdx]
  40b976:	vmovups XMMWORD PTR [rax],xmm0
  40b97a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40b97f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40b984:	mov    rcx,QWORD PTR [rdx+0x20]
  40b988:	mov    QWORD PTR [rax+0x20],rcx
  40b98c:	ret
  40b98d:	add    BYTE PTR [rax],al
	...

000000000040b990 <__swc_fn_4fa09e82_000064_dea90857>:
  40b990:	push   rsi
  40b991:	push   rdi
  40b992:	push   r12
  40b994:	push   r13
  40b996:	sub    rsp,0x8
  40b99a:	mov    rsi,r8
  40b99d:	mov    rdi,rcx
  40b9a0:	mov    r12,rdx
  40b9a3:	xor    r13d,r13d
  40b9a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40b9b0:	mov    eax,DWORD PTR [r12+0x730]
  40b9b8:	cmp    r13d,eax
  40b9bb:	jae    40ba21 <__swc_fn_4fa09e82_000064_dea90857+0x91>
  40b9bd:	lea    rax,[r13+r13*4+0x0]
  40b9c2:	lea    rax,[r12+rax*8+0x738]
  40b9ca:	mov    rdx,QWORD PTR [rax]
  40b9cd:	mov    r8,QWORD PTR [rax+0x8]
  40b9d1:	mov    r9,QWORD PTR [rax+0x10]
  40b9d5:	cmp    QWORD PTR [rax+0x20],rsi
  40b9d9:	jb     40b9e0 <__swc_fn_4fa09e82_000064_dea90857+0x50>
  40b9db:	inc    r13d
  40b9de:	jmp    40b9b0 <__swc_fn_4fa09e82_000064_dea90857+0x20>
  40b9e0:	sub    DWORD PTR [r12+0x730],0x1
  40b9e9:	mov    ecx,DWORD PTR [r12+0x730]
  40b9f1:	lea    rcx,[rcx+rcx*4]
  40b9f5:	lea    rcx,[r12+rcx*8+0x738]
  40b9fd:	vmovups xmm0,XMMWORD PTR [rcx]
  40ba01:	vmovups XMMWORD PTR [rax],xmm0
  40ba05:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40ba0a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40ba0f:	mov    rcx,QWORD PTR [rcx+0x20]
  40ba13:	mov    QWORD PTR [rax+0x20],rcx
  40ba17:	mov    rcx,rdi
  40ba1a:	call   40e320 <__swc_fn_4fa09e82_000044_d3c2ab54>
  40ba1f:	jmp    40b9b0 <__swc_fn_4fa09e82_000064_dea90857+0x20>
  40ba21:	add    rsp,0x8
  40ba25:	pop    r13
  40ba27:	pop    r12
  40ba29:	pop    rdi
  40ba2a:	pop    rsi
  40ba2b:	ret
  40ba2c:	add    BYTE PTR [rax],al
	...

000000000040ba30 <__swc_fn_4fa09e82_000067_de167e8d>:
  40ba30:	push   rsi
  40ba31:	push   rdi
  40ba32:	push   r12
  40ba34:	push   r13
  40ba36:	push   r14
  40ba38:	mov    rsi,rcx
  40ba3b:	mov    rdi,rdx
  40ba3e:	mov    r12,QWORD PTR [rdi]
  40ba41:	mov    r13,QWORD PTR [rdi+0x18]
  40ba45:	mov    rax,r12
  40ba48:	add    rax,QWORD PTR [rdi+0x8]
  40ba4c:	sub    rax,r13
  40ba4f:	cmp    r8,rax
  40ba52:	jbe    40ba5d <__swc_fn_4fa09e82_000067_de167e8d+0x2d>
  40ba54:	pop    r14
  40ba56:	pop    r13
  40ba58:	pop    r12
  40ba5a:	pop    rdi
  40ba5b:	pop    rsi
  40ba5c:	ret
  40ba5d:	lea    rax,[r13+r8*1+0x0]
  40ba62:	sub    rax,r12
  40ba65:	mov    ecx,0x1000
  40ba6a:	test   ecx,ecx
  40ba6c:	mov    edx,0x8
  40ba71:	cmove  ecx,edx
  40ba74:	dec    rcx
  40ba77:	mov    rdx,0xffffffffffffffff
  40ba7e:	sub    rdx,rcx
  40ba81:	cmp    rax,rdx
  40ba84:	jbe    40ba8b <__swc_fn_4fa09e82_000067_de167e8d+0x5b>
  40ba86:	xor    r14d,r14d
  40ba89:	jmp    40ba96 <__swc_fn_4fa09e82_000067_de167e8d+0x66>
  40ba8b:	add    rax,rcx
  40ba8e:	andn   rax,rcx,rax
  40ba93:	mov    r14,rax
  40ba96:	mov    rax,QWORD PTR [rdi+0x10]
  40ba9a:	cmp    r14,rax
  40ba9d:	ja     40baa8 <__swc_fn_4fa09e82_000067_de167e8d+0x78>
  40ba9f:	pop    r14
  40baa1:	pop    r13
  40baa3:	pop    r12
  40baa5:	pop    rdi
  40baa6:	pop    rsi
  40baa7:	ret
  40baa8:	mov    rax,r12
  40baab:	add    rax,QWORD PTR [rdi+0x10]
  40baaf:	mov    rdx,r14
  40bab2:	sub    rdx,QWORD PTR [rdi+0x10]
  40bab6:	mov    rcx,rax
  40bab9:	call   40de70 <__swc_fn_4fa09e82_000008_f7acedb0>
  40babe:	test   al,al
  40bac0:	jne    40bacb <__swc_fn_4fa09e82_000067_de167e8d+0x9b>
  40bac2:	pop    r14
  40bac4:	pop    r13
  40bac6:	pop    r12
  40bac8:	pop    rdi
  40bac9:	pop    rsi
  40baca:	ret
  40bacb:	add    r12,r14
  40bace:	sub    r12,r13
  40bad1:	mov    rcx,r12
  40bad4:	sub    rcx,QWORD PTR [rdi+0x28]
  40bad8:	mov    rdx,QWORD PTR [rsi+0x250]
  40badf:	nop
  40bae0:	lea    r8,[rdx+rcx*1]
  40bae4:	mov    rax,rdx
  40bae7:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40baf0:	cmp    rax,rdx
  40baf3:	je     40bafa <__swc_fn_4fa09e82_000067_de167e8d+0xca>
  40baf5:	mov    rdx,rax
  40baf8:	jmp    40bae0 <__swc_fn_4fa09e82_000067_de167e8d+0xb0>
  40bafa:	mov    QWORD PTR [rdi+0x10],r14
  40bafe:	mov    QWORD PTR [rdi+0x28],r12
  40bb02:	pop    r14
  40bb04:	pop    r13
  40bb06:	pop    r12
  40bb08:	pop    rdi
  40bb09:	pop    rsi
  40bb0a:	ret
  40bb0b:	add    BYTE PTR [rax],al
  40bb0d:	add    BYTE PTR [rax],al
	...

000000000040bb10 <__swc_fn_4fa09e82_000070_7130736e>:
  40bb10:	push   rbx
  40bb11:	push   rsi
  40bb12:	push   rdi
  40bb13:	push   r12
  40bb15:	push   r13
  40bb17:	sub    rsp,0xe0
  40bb1e:	mov    rbx,rdx
  40bb21:	mov    rsi,rcx
  40bb24:	cmp    DWORD PTR [rbx+0x58],0x0
  40bb28:	je     40bb4c <__swc_fn_4fa09e82_000070_7130736e+0x3c>
  40bb2a:	mov    eax,DWORD PTR [rbx+0x58]
  40bb2d:	sub    eax,0x1
  40bb30:	test   DWORD PTR [rbx+0x58],eax
  40bb33:	je     40bb4c <__swc_fn_4fa09e82_000070_7130736e+0x3c>
  40bb35:	mov    QWORD PTR [rbx+0x40],0x0
  40bb3d:	add    rsp,0xe0
  40bb44:	pop    r13
  40bb46:	pop    r12
  40bb48:	pop    rdi
  40bb49:	pop    rsi
  40bb4a:	pop    rbx
  40bb4b:	ret
  40bb4c:	mov    rax,QWORD PTR [rbx+0x40]
  40bb50:	test   rax,rax
  40bb53:	jne    40bb6f <__swc_fn_4fa09e82_000070_7130736e+0x5f>
  40bb55:	mov    rcx,rsi
  40bb58:	mov    rdx,rbx
  40bb5b:	call   408990 <__swc_fn_4fa09e82_000069_f3aa21af>
  40bb60:	add    rsp,0xe0
  40bb67:	pop    r13
  40bb69:	pop    r12
  40bb6b:	pop    rdi
  40bb6c:	pop    rsi
  40bb6d:	pop    rbx
  40bb6e:	ret
  40bb6f:	cmp    QWORD PTR [rbx+0x48],0x0
  40bb74:	jne    40bb90 <__swc_fn_4fa09e82_000070_7130736e+0x80>
  40bb76:	mov    rcx,rsi
  40bb79:	mov    rdx,rbx
  40bb7c:	call   40eb50 <__swc_fn_4fa09e82_000071_97813b89>
  40bb81:	add    rsp,0xe0
  40bb88:	pop    r13
  40bb8a:	pop    r12
  40bb8c:	pop    rdi
  40bb8d:	pop    rsi
  40bb8e:	pop    rbx
  40bb8f:	ret
  40bb90:	mov    rdi,QWORD PTR [rbx+0x40]
  40bb94:	lea    rax,[rip+0x18505]        # 4240a0 <__swc_bss_base_4fa09e82+0x60>
  40bb9b:	mov    rcx,rdi
  40bb9e:	sub    rcx,QWORD PTR [rax+0x8]
  40bba2:	mov    rax,QWORD PTR [rip+0x18507]        # 4240b0 <__swc_bss_base_4fa09e82+0x70>
  40bba9:	cmp    rcx,rax
  40bbac:	jae    40bbd8 <__swc_fn_4fa09e82_000070_7130736e+0xc8>
  40bbae:	mov    rax,rdi
  40bbb1:	and    rax,0xffffffffffc00000
  40bbb8:	mov    rcx,rdi
  40bbbb:	shr    rcx,0x10
  40bbbf:	and    ecx,0x3f
  40bbc2:	mov    edx,DWORD PTR [rax+0x28]
  40bbc5:	shrx   ecx,ecx,edx
  40bbca:	shl    rcx,0x4
  40bbce:	lea    r12,[rax+rcx*8+0x80]
  40bbd6:	jmp    40bbe3 <__swc_fn_4fa09e82_000070_7130736e+0xd3>
  40bbd8:	mov    rcx,rdi
  40bbdb:	call   407a10 <__swc_fn_4fa09e82_000027_bcdc5519>
  40bbe0:	mov    r12,rax
  40bbe3:	test   r12,r12
  40bbe6:	je     40bbf5 <__swc_fn_4fa09e82_000070_7130736e+0xe5>
  40bbe8:	mov    eax,DWORD PTR [r12+0x2c]
  40bbed:	mov    r9d,eax
  40bbf0:	mov    r13,rax
  40bbf3:	jmp    40bc74 <__swc_fn_4fa09e82_000070_7130736e+0x164>
  40bbf5:	mov    rcx,rsi
  40bbf8:	mov    rdx,rdi
  40bbfb:	call   408020 <__swc_fn_4fa09e82_000057_df0696cd>
  40bc00:	mov    rcx,QWORD PTR [rax+0x28]
  40bc04:	mov    r9,rcx
  40bc07:	mov    rdx,QWORD PTR [rax+0x20]
  40bc0b:	mov    r13,rdx
  40bc0e:	cmp    QWORD PTR [rbx+0x48],rcx
  40bc12:	jbe    40bc4b <__swc_fn_4fa09e82_000070_7130736e+0x13b>
  40bc14:	mov    ecx,DWORD PTR [rax+0x48]
  40bc17:	cmp    DWORD PTR [rbx+0x58],ecx
  40bc1a:	ja     40bc4b <__swc_fn_4fa09e82_000070_7130736e+0x13b>
  40bc1c:	mov    rcx,rsi
  40bc1f:	mov    rdx,rax
  40bc22:	mov    r8,QWORD PTR [rbx+0x48]
  40bc26:	mov    QWORD PTR [rsp+0xc8],r9
  40bc2e:	mov    QWORD PTR [rsp+0xd0],rax
  40bc36:	call   40ba30 <__swc_fn_4fa09e82_000067_de167e8d>
  40bc3b:	mov    r9,QWORD PTR [rsp+0xc8]
  40bc43:	mov    rax,QWORD PTR [rsp+0xd0]
  40bc4b:	mov    rcx,QWORD PTR [rax+0x28]
  40bc4f:	cmp    QWORD PTR [rbx+0x48],rcx
  40bc53:	ja     40bc74 <__swc_fn_4fa09e82_000070_7130736e+0x164>
  40bc55:	mov    ecx,DWORD PTR [rax+0x48]
  40bc58:	cmp    DWORD PTR [rbx+0x58],ecx
  40bc5b:	ja     40bc74 <__swc_fn_4fa09e82_000070_7130736e+0x164>
  40bc5d:	mov    rcx,QWORD PTR [rbx+0x48]
  40bc61:	mov    QWORD PTR [rax+0x20],rcx
  40bc65:	add    rsp,0xe0
  40bc6c:	pop    r13
  40bc6e:	pop    r12
  40bc70:	pop    rdi
  40bc71:	pop    rsi
  40bc72:	pop    rbx
  40bc73:	ret
  40bc74:	test   r12,r12
  40bc77:	je     40bca9 <__swc_fn_4fa09e82_000070_7130736e+0x199>
  40bc79:	cmp    QWORD PTR [rbx+0x48],r9
  40bc7d:	ja     40bca9 <__swc_fn_4fa09e82_000070_7130736e+0x199>
  40bc7f:	cmp    DWORD PTR [rbx+0x58],0x40
  40bc83:	ja     40bca9 <__swc_fn_4fa09e82_000070_7130736e+0x199>
  40bc85:	cmp    DWORD PTR [rbx+0x58],0x0
  40bc89:	je     40bc96 <__swc_fn_4fa09e82_000070_7130736e+0x186>
  40bc8b:	mov    ecx,DWORD PTR [rbx+0x58]
  40bc8e:	dec    rcx
  40bc91:	test   rdi,rcx
  40bc94:	jne    40bca9 <__swc_fn_4fa09e82_000070_7130736e+0x199>
  40bc96:	mov    QWORD PTR [rbx+0x40],rdi
  40bc9a:	add    rsp,0xe0
  40bca1:	pop    r13
  40bca3:	pop    r12
  40bca5:	pop    rdi
  40bca6:	pop    rsi
  40bca7:	pop    rbx
  40bca8:	ret
  40bca9:	vmovups xmm0,XMMWORD PTR [rbx]
  40bcad:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40bcb3:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40bcb8:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40bcbe:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40bcc3:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40bcc9:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40bcce:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40bcd4:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40bcd9:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40bcdf:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40bce4:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40bcea:	mov    QWORD PTR [rsp+0x48],0x0
  40bcf3:	mov    rcx,rsi
  40bcf6:	lea    rdx,[rsp+0x8]
  40bcfb:	call   408990 <__swc_fn_4fa09e82_000069_f3aa21af>
  40bd00:	mov    rax,QWORD PTR [rsp+0x48]
  40bd05:	test   rax,rax
  40bd08:	jne    40bd21 <__swc_fn_4fa09e82_000070_7130736e+0x211>
  40bd0a:	mov    QWORD PTR [rbx+0x40],0x0
  40bd12:	add    rsp,0xe0
  40bd19:	pop    r13
  40bd1b:	pop    r12
  40bd1d:	pop    rdi
  40bd1e:	pop    rsi
  40bd1f:	pop    rbx
  40bd20:	ret
  40bd21:	mov    rax,QWORD PTR [rbx+0x48]
  40bd25:	cmp    r13,rax
  40bd28:	cmovbe rax,r13
  40bd2c:	mov    rcx,QWORD PTR [rsp+0x48]
  40bd31:	mov    rdx,rdi
  40bd34:	mov    r8,rax
  40bd37:	call   409560 <__swc_fn_4fa09e82_000111_7c204aac>
  40bd3c:	vmovups xmm0,XMMWORD PTR [rbx]
  40bd40:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40bd46:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40bd4b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40bd51:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40bd56:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40bd5f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40bd64:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40bd6d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40bd72:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40bd7b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40bd80:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40bd89:	mov    QWORD PTR [rsp+0xa8],rdi
  40bd91:	mov    rcx,rsi
  40bd94:	lea    rdx,[rsp+0x68]
  40bd99:	call   40eb50 <__swc_fn_4fa09e82_000071_97813b89>
  40bd9e:	mov    rax,QWORD PTR [rsp+0x48]
  40bda3:	mov    QWORD PTR [rbx+0x40],rax
  40bda7:	add    rsp,0xe0
  40bdae:	pop    r13
  40bdb0:	pop    r12
  40bdb2:	pop    rdi
  40bdb3:	pop    rsi
  40bdb4:	pop    rbx
  40bdb5:	ret
	...

000000000040bdc0 <__swc_fn_4fa09e82_000073_61e60aab>:
  40bdc0:	push   r12
  40bdc2:	push   rdi
  40bdc3:	push   rsi
  40bdc4:	push   r13
  40bdc6:	push   r14
  40bdc8:	sub    rsp,0x190
  40bdcf:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40bdd8:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40bde1:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40bdea:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40bdf3:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40bdfc:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40be05:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40be0e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40be17:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40be20:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40be29:	mov    r12,rcx
  40be2c:	lea    rax,[rip+0x161d5]        # 422008 <__swc_data_base_4fa09e82+0x8>
  40be33:	mov    rax,QWORD PTR [rax]
  40be36:	cmp    rax,0xffffffffffffffff
  40be3a:	je     40be49 <__swc_fn_4fa09e82_000073_61e60aab+0x89>
  40be3c:	mov    eax,eax
  40be3e:	mov    edi,eax
  40be40:	xor    eax,eax
  40be42:	call   407000 <pthread_getspecific@plt>
  40be47:	jmp    40be4b <__swc_fn_4fa09e82_000073_61e60aab+0x8b>
  40be49:	xor    eax,eax
  40be4b:	test   rax,rax
  40be4e:	jne    40be5d <__swc_fn_4fa09e82_000073_61e60aab+0x9d>
  40be50:	call   407ae0 <__swc_fn_4fa09e82_000036_cd1a4e8c>
  40be55:	mov    rcx,rax
  40be58:	call   410760 <__swc_fn_4fa09e82_000134_5f757033>
  40be5d:	test   rax,rax
  40be60:	je     40be86 <__swc_fn_4fa09e82_000073_61e60aab+0xc6>
  40be62:	cmp    QWORD PTR [rax],r12
  40be65:	jne    40be86 <__swc_fn_4fa09e82_000073_61e60aab+0xc6>
  40be67:	xor    ecx,ecx
  40be69:	mov    QWORD PTR [rsp+0xc8],rax
  40be71:	call   40e2f0 <__swc_fn_4fa09e82_000038_28d0e998>
  40be76:	mov    rdx,QWORD PTR [rsp+0xc8]
  40be7e:	mov    rcx,r12
  40be81:	call   40e400 <__swc_fn_4fa09e82_000047_b30433d0>
  40be86:	lea    rsi,[r12+0x10]
  40be8b:	mov    rcx,rsi
  40be8e:	call   409d20 <__swc_fn_4fa09e82_000141_86bb0f90>
  40be93:	mov    rdi,QWORD PTR [r12+0x20]
  40be98:	test   rdi,rdi
  40be9b:	je     40bede <__swc_fn_4fa09e82_000073_61e60aab+0x11e>
  40be9d:	nop    DWORD PTR [rax]
  40bea0:	mov    rcx,r12
  40bea3:	mov    rdx,rdi
  40bea6:	call   407ca0 <__swc_fn_4fa09e82_000048_6e7a8d58>
  40beab:	mov    rcx,r12
  40beae:	mov    rdx,rdi
  40beb1:	mov    r8,0xffffffffffffffff
  40beb8:	call   40b990 <__swc_fn_4fa09e82_000064_dea90857>
  40bebd:	mov    rcx,r12
  40bec0:	mov    rdx,rdi
  40bec3:	mov    r8d,0x9b8
  40bec9:	mov    r9d,0x9b8
  40becf:	call   40e320 <__swc_fn_4fa09e82_000044_d3c2ab54>
  40bed4:	mov    rdi,QWORD PTR [r12+0x20]
  40bed9:	test   rdi,rdi
  40bedc:	jne    40bea0 <__swc_fn_4fa09e82_000073_61e60aab+0xe0>
  40bede:	xor    eax,eax
  40bee0:	xchg   QWORD PTR [r12+0x2a80],rax
  40bee8:	test   rax,rax
  40beeb:	je     40bf11 <__swc_fn_4fa09e82_000073_61e60aab+0x151>
  40beed:	cs nop WORD PTR [rax+rax*1+0x0]
  40bef7:	nop    WORD PTR [rax+rax*1+0x0]
  40bf00:	mov    rcx,rax
  40bf03:	mov    rax,QWORD PTR [rax+0x78]
  40bf07:	xor    edx,edx
  40bf09:	xchg   DWORD PTR [rcx+0x70],edx
  40bf0c:	test   rax,rax
  40bf0f:	jne    40bf00 <__swc_fn_4fa09e82_000073_61e60aab+0x140>
  40bf11:	mov    rax,QWORD PTR [r12+0x18]
  40bf16:	mov    rdi,rax
  40bf19:	test   rdi,rdi
  40bf1c:	je     40bfb1 <__swc_fn_4fa09e82_000073_61e60aab+0x1f1>
  40bf22:	cs nop WORD PTR [rax+rax*1+0x0]
  40bf2c:	nop    DWORD PTR [rax+0x0]
  40bf30:	mov    rax,QWORD PTR [rdi+0x10]
  40bf34:	mov    r8d,DWORD PTR [rdi+0x2c]
  40bf38:	xor    r9d,r9d
  40bf3b:	test   r8,r8
  40bf3e:	jbe    40bf9d <__swc_fn_4fa09e82_000073_61e60aab+0x1dd>
  40bf40:	mov    ecx,r9d
  40bf43:	shl    rcx,0x4
  40bf47:	lea    rdx,[rdi+rcx*8+0x80]
  40bf4f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40bf53:	je     40bf94 <__swc_fn_4fa09e82_000073_61e60aab+0x1d4>
  40bf55:	mov    DWORD PTR [rdx+0x28],0x0
  40bf5c:	mov    rcx,rdi
  40bf5f:	mov    QWORD PTR [rsp+0xd0],rax
  40bf67:	mov    QWORD PTR [rsp+0xd8],r8
  40bf6f:	mov    QWORD PTR [rsp+0xe0],r9
  40bf77:	call   40b0b0 <__swc_fn_4fa09e82_000019_283e2b5e>
  40bf7c:	mov    rax,QWORD PTR [rsp+0xd0]
  40bf84:	mov    r8,QWORD PTR [rsp+0xd8]
  40bf8c:	mov    r9,QWORD PTR [rsp+0xe0]
  40bf94:	add    r9,0x1
  40bf98:	cmp    r9,r8
  40bf9b:	jb     40bf40 <__swc_fn_4fa09e82_000073_61e60aab+0x180>
  40bf9d:	mov    rcx,rdi
  40bfa0:	mov    rdi,rax
  40bfa3:	call   40e200 <__swc_fn_4fa09e82_000026_aa910677>
  40bfa8:	test   rdi,rdi
  40bfab:	jne    40bf30 <__swc_fn_4fa09e82_000073_61e60aab+0x170>
  40bfb1:	mov    QWORD PTR [r12+0x18],0x0
  40bfba:	mov    QWORD PTR [r12+0x28],0x0
  40bfc3:	mov    rcx,rsi
  40bfc6:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40bfcb:	mov    esi,0x8
  40bfd0:	xor    edi,edi
  40bfd2:	test   rsi,rsi
  40bfd5:	je     40c032 <__swc_fn_4fa09e82_000073_61e60aab+0x272>
  40bfdb:	nop    DWORD PTR [rax+rax*1+0x0]
  40bfe0:	lea    r13,[rdi*8+0x0]
  40bfe8:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40bfed:	test   r14,r14
  40bff0:	je     40c028 <__swc_fn_4fa09e82_000073_61e60aab+0x268>
  40bff2:	cs nop WORD PTR [rax+rax*1+0x0]
  40bffc:	nop    DWORD PTR [rax+0x0]
  40c000:	mov    rcx,r12
  40c003:	mov    rdx,r14
  40c006:	call   40e9b0 <__swc_fn_4fa09e82_000059_1bb23e77>
  40c00b:	mov    rcx,r12
  40c00e:	mov    rdx,QWORD PTR [r14]
  40c011:	mov    r8,QWORD PTR [r14+0x8]
  40c015:	mov    r9,QWORD PTR [r14+0x10]
  40c019:	call   40e320 <__swc_fn_4fa09e82_000044_d3c2ab54>
  40c01e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40c023:	test   r14,r14
  40c026:	jne    40c000 <__swc_fn_4fa09e82_000073_61e60aab+0x240>
  40c028:	add    rdi,0x1
  40c02c:	sub    rsi,0x1
  40c030:	jne    40bfe0 <__swc_fn_4fa09e82_000073_61e60aab+0x220>
  40c032:	mov    rcx,r12
  40c035:	call   40ea80 <__swc_fn_4fa09e82_000065_ffcd96eb>
  40c03a:	lea    rcx,[r12+0x250]
  40c042:	mov    rdx,QWORD PTR [rcx]
  40c045:	mov    r8,QWORD PTR [r12+0x250]
  40c04d:	nop    DWORD PTR [rax]
  40c050:	mov    r9,r8
  40c053:	sub    r9,rdx
  40c056:	mov    rax,r8
  40c059:	lock cmpxchg QWORD PTR [rcx],r9
  40c05e:	cmp    rax,r8
  40c061:	je     40c068 <__swc_fn_4fa09e82_000073_61e60aab+0x2a8>
  40c063:	mov    r8,rax
  40c066:	jmp    40c050 <__swc_fn_4fa09e82_000073_61e60aab+0x290>
  40c068:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40c071:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40c07a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40c083:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40c08c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40c095:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40c09e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40c0a7:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40c0b0:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40c0b9:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40c0c2:	add    rsp,0x190
  40c0c9:	pop    r14
  40c0cb:	pop    r13
  40c0cd:	pop    rsi
  40c0ce:	pop    rdi
  40c0cf:	pop    r12
  40c0d1:	ret
	...

000000000040c0e0 <__swc_fn_4fa09e82_000076_64d36d78>:
  40c0e0:	sub    rsp,0x8
  40c0e4:	mov    QWORD PTR [rdx+0x40],0x0
  40c0ec:	call   408990 <__swc_fn_4fa09e82_000069_f3aa21af>
  40c0f1:	add    rsp,0x8
  40c0f5:	ret
	...

000000000040c100 <__swc_fn_4fa09e82_000079_1966ae2e>:
  40c100:	sub    rsp,0x8
  40c104:	call   40eb50 <__swc_fn_4fa09e82_000071_97813b89>
  40c109:	add    rsp,0x8
  40c10d:	ret
	...

000000000040c110 <__swc_fn_4fa09e82_000082_5cc7acfc>:
  40c110:	push   rbx
  40c111:	push   rsi
  40c112:	push   rdi
  40c113:	push   r12
  40c115:	push   r13
  40c117:	push   r14
  40c119:	push   r15
  40c11b:	sub    rsp,0x20
  40c11f:	mov    rbx,r11
  40c122:	mov    rsi,rcx
  40c125:	mov    rdi,rdx
  40c128:	mov    r12,r8
  40c12b:	mov    r13,r9
  40c12e:	mov    r14,r10
  40c131:	mov    rcx,QWORD PTR [rip+0x17f08]        # 424040 <__swc_bss_base_4fa09e82>
  40c138:	test   rcx,rcx
  40c13b:	jne    40c14d <__swc_fn_4fa09e82_000082_5cc7acfc+0x3d>
  40c13d:	call   40a620 <__swc_fn_4fa09e82_000171_994c8876>
  40c142:	lea    rcx,[rax+0x1]
  40c146:	mov    QWORD PTR [rip+0x17ef3],rcx        # 424040 <__swc_bss_base_4fa09e82>
  40c14d:	dec    rcx
  40c150:	call   4121e0 <__swc_fn_4fa09e82_000173_360af05d>
  40c155:	mov    r15,rax
  40c158:	lea    r11,[rip+0x180e1]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  40c15f:	mov    rcx,r11
  40c162:	call   40e310 <__swc_fn_4fa09e82_000041_eb6108f2>
  40c167:	test   al,al
  40c169:	jne    40c17a <__swc_fn_4fa09e82_000082_5cc7acfc+0x6a>
  40c16b:	mov    rcx,r11
  40c16e:	call   407b40 <__swc_fn_4fa09e82_000039_14f56618>
  40c173:	lea    r11,[rip+0x180c6]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  40c17a:	mov    rcx,r11
  40c17d:	mov    rdx,rsi
  40c180:	mov    r8,rdi
  40c183:	mov    r9,r12
  40c186:	mov    r10,r13
  40c189:	mov    rsi,r11
  40c18c:	mov    r11,r14
  40c18f:	call   40b430 <__swc_fn_4fa09e82_000040_03f1bf9a>
  40c194:	test   bl,bl
  40c196:	je     40c1bd <__swc_fn_4fa09e82_000082_5cc7acfc+0xad>
  40c198:	mov    QWORD PTR [rsp+0x8],rsi
  40c19d:	lea    rax,[rip+0x70d4]        # 413278 <__swc_rdata_base_4fa09e82+0x168>
  40c1a4:	mov    QWORD PTR [rsp+0x10],rax
  40c1a9:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c1af:	vmovups XMMWORD PTR [r15],xmm0
  40c1b4:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40c1bd:	mov    rax,rsi
  40c1c0:	add    rsp,0x20
  40c1c4:	pop    r15
  40c1c6:	pop    r14
  40c1c8:	pop    r13
  40c1ca:	pop    r12
  40c1cc:	pop    rdi
  40c1cd:	pop    rsi
  40c1ce:	pop    rbx
  40c1cf:	ret

000000000040c1d0 <__swc_fn_4fa09e82_000085_cf82995a>:
  40c1d0:	sub    rsp,0x8
  40c1d4:	mov    rax,rcx
  40c1d7:	test   rcx,rcx
  40c1da:	jne    40c1e1 <__swc_fn_4fa09e82_000085_cf82995a+0x11>
  40c1dc:	add    rsp,0x8
  40c1e0:	ret
  40c1e1:	lea    rcx,[rax-0x10]
  40c1e5:	mov    rax,QWORD PTR [rax-0x10]
  40c1e9:	mov    rdx,rax
  40c1ec:	call   410410 <__swc_fn_4fa09e82_000119_ed2d8fed>
  40c1f1:	add    rsp,0x8
  40c1f5:	ret
	...

000000000040c200 <__swc_fn_4fa09e82_000088_ef55f6e4>:
  40c200:	sub    rsp,0x8
  40c204:	xor    r11d,r11d
  40c207:	call   40ee10 <__swc_fn_4fa09e82_000089_0d280354>
  40c20c:	add    rsp,0x8
  40c210:	ret
	...

000000000040c220 <__swc_fn_4fa09e82_000091_23214800>:
  40c220:	push   rsi
  40c221:	push   rdi
  40c222:	push   r12
  40c224:	push   r13
  40c226:	push   r14
  40c228:	push   r15
  40c22a:	sub    rsp,0x68
  40c22e:	mov    rsi,r9
  40c231:	mov    rdi,rcx
  40c234:	mov    r12,rdx
  40c237:	mov    r13,r8
  40c23a:	cmp    r8,r9
  40c23d:	jne    40c265 <__swc_fn_4fa09e82_000091_23214800+0x45>
  40c23f:	mov    rcx,rdi
  40c242:	mov    rdx,r12
  40c245:	xor    r8d,r8d
  40c248:	call   40f160 <__swc_fn_4fa09e82_000095_63c1827b>
  40c24d:	test   al,al
  40c24f:	je     40c265 <__swc_fn_4fa09e82_000091_23214800+0x45>
  40c251:	mov    eax,0x1
  40c256:	add    rsp,0x68
  40c25a:	pop    r15
  40c25c:	pop    r14
  40c25e:	pop    r13
  40c260:	pop    r12
  40c262:	pop    rdi
  40c263:	pop    rsi
  40c264:	ret
  40c265:	cmp    BYTE PTR [r12+0x2c],0xe
  40c26b:	je     40c27e <__swc_fn_4fa09e82_000091_23214800+0x5e>
  40c26d:	xor    eax,eax
  40c26f:	add    rsp,0x68
  40c273:	pop    r15
  40c275:	pop    r14
  40c277:	pop    r13
  40c279:	pop    r12
  40c27b:	pop    rdi
  40c27c:	pop    rsi
  40c27d:	ret
  40c27e:	mov    r14,QWORD PTR [r12+0x98]
  40c286:	mov    rax,QWORD PTR [r12+0xa0]
  40c28e:	mov    r12,rax
  40c291:	xor    r15d,r15d
  40c294:	test   r12,r12
  40c297:	je     40c2ff <__swc_fn_4fa09e82_000091_23214800+0xdf>
  40c299:	nop    DWORD PTR [rax+0x0]
  40c2a0:	mov    QWORD PTR [rsp+0x58],r12
  40c2a5:	lea    r12,[r15*8+0x0]
  40c2ad:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40c2b2:	mov    rcx,rax
  40c2b5:	call   409120 <__swc_fn_4fa09e82_000087_3953ef98>
  40c2ba:	cmp    BYTE PTR [rax+0x2c],0xe
  40c2be:	jne    40c2f0 <__swc_fn_4fa09e82_000091_23214800+0xd0>
  40c2c0:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40c2c5:	lea    r8,[r13+rcx*1+0x0]
  40c2ca:	mov    rcx,rdi
  40c2cd:	mov    rdx,rax
  40c2d0:	mov    r9,rsi
  40c2d3:	call   40c220 <__swc_fn_4fa09e82_000091_23214800>
  40c2d8:	test   al,al
  40c2da:	je     40c2f0 <__swc_fn_4fa09e82_000091_23214800+0xd0>
  40c2dc:	mov    eax,0x1
  40c2e1:	add    rsp,0x68
  40c2e5:	pop    r15
  40c2e7:	pop    r14
  40c2e9:	pop    r13
  40c2eb:	pop    r12
  40c2ed:	pop    rdi
  40c2ee:	pop    rsi
  40c2ef:	ret
  40c2f0:	add    r15,0x1
  40c2f4:	mov    r12,QWORD PTR [rsp+0x58]
  40c2f9:	sub    r12,0x1
  40c2fd:	jne    40c2a0 <__swc_fn_4fa09e82_000091_23214800+0x80>
  40c2ff:	xor    eax,eax
  40c301:	add    rsp,0x68
  40c305:	pop    r15
  40c307:	pop    r14
  40c309:	pop    r13
  40c30b:	pop    r12
  40c30d:	pop    rdi
  40c30e:	pop    rsi
  40c30f:	ret

000000000040c310 <__swc_fn_4fa09e82_000094_c2567a3b>:
  40c310:	push   rbp
  40c311:	push   rbx
  40c312:	push   rsi
  40c313:	push   rdi
  40c314:	push   r12
  40c316:	push   r13
  40c318:	push   r14
  40c31a:	push   r15
  40c31c:	sub    rsp,0x38
  40c320:	mov    rbp,rsp
  40c323:	mov    rbx,r11
  40c326:	mov    rsi,rdx
  40c329:	mov    rdi,r8
  40c32c:	mov    r12,r9
  40c32f:	mov    QWORD PTR [rsp+0x18],r9
  40c334:	mov    r13,r10
  40c337:	movzx  r14d,BYTE PTR [rbp+0x80]
  40c33f:	movzx  r15d,BYTE PTR [rbp+0x88]
  40c347:	test   r11,r11
  40c34a:	je     40c350 <__swc_fn_4fa09e82_000094_c2567a3b+0x40>
  40c34c:	xor    eax,eax
  40c34e:	mov    BYTE PTR [rbx],al
  40c350:	test   r12,r12
  40c353:	je     40c35e <__swc_fn_4fa09e82_000094_c2567a3b+0x4e>
  40c355:	mov    QWORD PTR [r12+0x8],0x0
  40c35e:	test   rcx,rcx
  40c361:	je     40c368 <__swc_fn_4fa09e82_000094_c2567a3b+0x58>
  40c363:	test   rsi,rsi
  40c366:	jne    40c37b <__swc_fn_4fa09e82_000094_c2567a3b+0x6b>
  40c368:	xor    eax,eax
  40c36a:	add    rsp,0x38
  40c36e:	pop    r15
  40c370:	pop    r14
  40c372:	pop    r13
  40c374:	pop    r12
  40c376:	pop    rdi
  40c377:	pop    rsi
  40c378:	pop    rbx
  40c379:	pop    rbp
  40c37a:	ret
  40c37b:	call   409120 <__swc_fn_4fa09e82_000087_3953ef98>
  40c380:	mov    r12,rax
  40c383:	mov    al,r15b
  40c386:	test   r15b,r15b
  40c389:	jne    40c399 <__swc_fn_4fa09e82_000094_c2567a3b+0x89>
  40c38b:	mov    eax,DWORD PTR [r12+0x28]
  40c390:	and    eax,0x10000
  40c396:	setne  al
  40c399:	lea    r15,[rsp+0x8]
  40c39e:	mov    QWORD PTR [rsp+0x20],r15
  40c3a3:	rex mov BYTE PTR [rsp+0x8],al
  40c3a8:	test   DWORD PTR [rsi+0x28],0x400000
  40c3af:	je     40c3e7 <__swc_fn_4fa09e82_000094_c2567a3b+0xd7>
  40c3b1:	test   rsi,rsi
  40c3b4:	je     40c3d4 <__swc_fn_4fa09e82_000094_c2567a3b+0xc4>
  40c3b6:	mov    rax,QWORD PTR [rsi+0x38]
  40c3ba:	cmp    QWORD PTR [rax+0x10],rsi
  40c3be:	jne    40c3d4 <__swc_fn_4fa09e82_000094_c2567a3b+0xc4>
  40c3c0:	rex mov al,BYTE PTR [rsp+0x8]
  40c3c5:	test   al,al
  40c3c7:	sete   al
  40c3ca:	test   r14b,r14b
  40c3cd:	sete   cl
  40c3d0:	test   al,cl
  40c3d2:	je     40c3e7 <__swc_fn_4fa09e82_000094_c2567a3b+0xd7>
  40c3d4:	xor    eax,eax
  40c3d6:	add    rsp,0x38
  40c3da:	pop    r15
  40c3dc:	pop    r14
  40c3de:	pop    r13
  40c3e0:	pop    r12
  40c3e2:	pop    rdi
  40c3e3:	pop    rsi
  40c3e4:	pop    rbx
  40c3e5:	pop    rbp
  40c3e6:	ret
  40c3e7:	mov    r15,r12
  40c3ea:	test   r14b,r14b
  40c3ed:	jne    40c404 <__swc_fn_4fa09e82_000094_c2567a3b+0xf4>
  40c3ef:	cmp    BYTE PTR [r12+0x2c],0x6
  40c3f5:	jne    40c404 <__swc_fn_4fa09e82_000094_c2567a3b+0xf4>
  40c3f7:	mov    rcx,QWORD PTR [r12+0x40]
  40c3fc:	call   409120 <__swc_fn_4fa09e82_000087_3953ef98>
  40c401:	mov    r15,rax
  40c404:	test   r14b,r14b
  40c407:	je     40c40d <__swc_fn_4fa09e82_000094_c2567a3b+0xfd>
  40c409:	mov    r15,QWORD PTR [r15+0x30]
  40c40d:	mov    rcx,rsi
  40c410:	call   409120 <__swc_fn_4fa09e82_000087_3953ef98>
  40c415:	mov    rsi,rax
  40c418:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40c41d:	je     40c454 <__swc_fn_4fa09e82_000094_c2567a3b+0x144>
  40c41f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40c424:	je     40c454 <__swc_fn_4fa09e82_000094_c2567a3b+0x144>
  40c426:	mov    eax,DWORD PTR [rsi+0x28]
  40c429:	and    eax,0x10000
  40c42f:	je     40c454 <__swc_fn_4fa09e82_000094_c2567a3b+0x144>
  40c431:	rex mov al,BYTE PTR [rsp+0x8]
  40c436:	test   al,al
  40c438:	jne    40c44d <__swc_fn_4fa09e82_000094_c2567a3b+0x13d>
  40c43a:	xor    eax,eax
  40c43c:	add    rsp,0x38
  40c440:	pop    r15
  40c442:	pop    r14
  40c444:	pop    r13
  40c446:	pop    r12
  40c448:	pop    rdi
  40c449:	pop    rsi
  40c44a:	pop    rbx
  40c44b:	pop    rbp
  40c44c:	ret
  40c44d:	mov    rax,QWORD PTR [rsi+0x30]
  40c451:	mov    rsi,rax
  40c454:	mov    r14b,r13b
  40c457:	test   rbx,rbx
  40c45a:	je     40c490 <__swc_fn_4fa09e82_000094_c2567a3b+0x180>
  40c45c:	cmp    BYTE PTR [r12+0x2c],0x6
  40c462:	jne    40c490 <__swc_fn_4fa09e82_000094_c2567a3b+0x180>
  40c464:	lea    rdx,[rip+0x6e3d]        # 4132a8 <__swc_rdata_base_4fa09e82+0x198>
  40c46b:	mov    rcx,rsi
  40c46e:	xor    r8d,r8d
  40c471:	call   40f160 <__swc_fn_4fa09e82_000095_63c1827b>
  40c476:	test   al,al
  40c478:	je     40c490 <__swc_fn_4fa09e82_000094_c2567a3b+0x180>
  40c47a:	mov    BYTE PTR [rbx],0x1
  40c47d:	xor    eax,eax
  40c47f:	add    rsp,0x38
  40c483:	pop    r15
  40c485:	pop    r14
  40c487:	pop    r13
  40c489:	pop    r12
  40c48b:	pop    rdi
  40c48c:	pop    rsi
  40c48d:	pop    rbx
  40c48e:	pop    rbp
  40c48f:	ret
  40c490:	test   rdi,rdi
  40c493:	jne    40c4ad <__swc_fn_4fa09e82_000094_c2567a3b+0x19d>
  40c495:	test   r13b,r13b
  40c498:	jne    40c4ad <__swc_fn_4fa09e82_000094_c2567a3b+0x19d>
  40c49a:	xor    eax,eax
  40c49c:	add    rsp,0x38
  40c4a0:	pop    r15
  40c4a2:	pop    r14
  40c4a4:	pop    r13
  40c4a6:	pop    r12
  40c4a8:	pop    rdi
  40c4a9:	pop    rsi
  40c4aa:	pop    rbx
  40c4ab:	pop    rbp
  40c4ac:	ret
  40c4ad:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40c4b2:	jne    40c568 <__swc_fn_4fa09e82_000094_c2567a3b+0x258>
  40c4b8:	mov    rcx,r15
  40c4bb:	mov    rdx,rsi
  40c4be:	xor    r8d,r8d
  40c4c1:	call   40f160 <__swc_fn_4fa09e82_000095_63c1827b>
  40c4c6:	test   al,al
  40c4c8:	jne    40c568 <__swc_fn_4fa09e82_000094_c2567a3b+0x258>
  40c4ce:	test   DWORD PTR [rsi+0x28],0x10000
  40c4d5:	je     40c4f3 <__swc_fn_4fa09e82_000094_c2567a3b+0x1e3>
  40c4d7:	rex mov al,BYTE PTR [rsp+0x8]
  40c4dc:	test   al,al
  40c4de:	jne    40c4f3 <__swc_fn_4fa09e82_000094_c2567a3b+0x1e3>
  40c4e0:	xor    eax,eax
  40c4e2:	add    rsp,0x38
  40c4e6:	pop    r15
  40c4e8:	pop    r14
  40c4ea:	pop    r13
  40c4ec:	pop    r12
  40c4ee:	pop    rdi
  40c4ef:	pop    rsi
  40c4f0:	pop    rbx
  40c4f1:	pop    rbp
  40c4f2:	ret
  40c4f3:	test   rdi,rdi
  40c4f6:	jne    40c50b <__swc_fn_4fa09e82_000094_c2567a3b+0x1fb>
  40c4f8:	xor    eax,eax
  40c4fa:	add    rsp,0x38
  40c4fe:	pop    r15
  40c500:	pop    r14
  40c502:	pop    r13
  40c504:	pop    r12
  40c506:	pop    rdi
  40c507:	pop    rsi
  40c508:	pop    rbx
  40c509:	pop    rbp
  40c50a:	ret
  40c50b:	mov    rcx,QWORD PTR [rsi+0x40]
  40c50f:	call   409120 <__swc_fn_4fa09e82_000087_3953ef98>
  40c514:	mov    rsi,rax
  40c517:	mov    rax,QWORD PTR [rdi]
  40c51a:	mov    rdi,rax
  40c51d:	test   rax,rax
  40c520:	jne    40c563 <__swc_fn_4fa09e82_000094_c2567a3b+0x253>
  40c522:	test   rbx,rbx
  40c525:	je     40c563 <__swc_fn_4fa09e82_000094_c2567a3b+0x253>
  40c527:	mov    rcx,r15
  40c52a:	mov    rdx,rsi
  40c52d:	xor    r8d,r8d
  40c530:	call   40f160 <__swc_fn_4fa09e82_000095_63c1827b>
  40c535:	mov    rcx,rax
  40c538:	test   al,al
  40c53a:	jne    40c55c <__swc_fn_4fa09e82_000094_c2567a3b+0x24c>
  40c53c:	mov    rcx,r15
  40c53f:	mov    rdx,rsi
  40c542:	call   409160 <__swc_fn_4fa09e82_000090_d182c4dc>
  40c547:	mov    rcx,rax
  40c54a:	test   al,al
  40c54c:	jne    40c55c <__swc_fn_4fa09e82_000094_c2567a3b+0x24c>
  40c54e:	mov    rcx,rsi
  40c551:	mov    rdx,r15
  40c554:	call   409160 <__swc_fn_4fa09e82_000090_d182c4dc>
  40c559:	mov    rcx,rax
  40c55c:	test   cl,cl
  40c55e:	setne  al
  40c561:	mov    BYTE PTR [rbx],al
  40c563:	xor    eax,eax
  40c565:	mov    r14b,al
  40c568:	test   rdi,rdi
  40c56b:	jne    40c585 <__swc_fn_4fa09e82_000094_c2567a3b+0x275>
  40c56d:	test   r14b,r14b
  40c570:	jne    40c585 <__swc_fn_4fa09e82_000094_c2567a3b+0x275>
  40c572:	xor    eax,eax
  40c574:	add    rsp,0x38
  40c578:	pop    r15
  40c57a:	pop    r14
  40c57c:	pop    r13
  40c57e:	pop    r12
  40c580:	pop    rdi
  40c581:	pop    rsi
  40c582:	pop    rbx
  40c583:	pop    rbp
  40c584:	ret
  40c585:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40c58a:	je     40c596 <__swc_fn_4fa09e82_000094_c2567a3b+0x286>
  40c58c:	mov    r12,QWORD PTR [rsp+0x18]
  40c591:	jmp    40c61e <__swc_fn_4fa09e82_000094_c2567a3b+0x30e>
  40c596:	mov    r12,QWORD PTR [rsp+0x18]
  40c59b:	test   r12,r12
  40c59e:	jne    40c5b2 <__swc_fn_4fa09e82_000094_c2567a3b+0x2a2>
  40c5a0:	mov    rcx,r15
  40c5a3:	mov    rdx,rsi
  40c5a6:	xor    r8d,r8d
  40c5a9:	call   40f160 <__swc_fn_4fa09e82_000095_63c1827b>
  40c5ae:	test   al,al
  40c5b0:	jne    40c61e <__swc_fn_4fa09e82_000094_c2567a3b+0x30e>
  40c5b2:	test   DWORD PTR [rsi+0x28],0x10000
  40c5b9:	je     40c5d7 <__swc_fn_4fa09e82_000094_c2567a3b+0x2c7>
  40c5bb:	rex mov al,BYTE PTR [rsp+0x8]
  40c5c0:	test   al,al
  40c5c2:	jne    40c5d7 <__swc_fn_4fa09e82_000094_c2567a3b+0x2c7>
  40c5c4:	xor    eax,eax
  40c5c6:	add    rsp,0x38
  40c5ca:	pop    r15
  40c5cc:	pop    r14
  40c5ce:	pop    r13
  40c5d0:	pop    r12
  40c5d2:	pop    rdi
  40c5d3:	pop    rsi
  40c5d4:	pop    rbx
  40c5d5:	pop    rbp
  40c5d6:	ret
  40c5d7:	test   rdi,rdi
  40c5da:	jne    40c5ef <__swc_fn_4fa09e82_000094_c2567a3b+0x2df>
  40c5dc:	xor    eax,eax
  40c5de:	add    rsp,0x38
  40c5e2:	pop    r15
  40c5e4:	pop    r14
  40c5e6:	pop    r13
  40c5e8:	pop    r12
  40c5ea:	pop    rdi
  40c5eb:	pop    rsi
  40c5ec:	pop    rbx
  40c5ed:	pop    rbp
  40c5ee:	ret
  40c5ef:	cmp    QWORD PTR [rdi+0x8],0x0
  40c5f4:	jne    40c609 <__swc_fn_4fa09e82_000094_c2567a3b+0x2f9>
  40c5f6:	xor    eax,eax
  40c5f8:	add    rsp,0x38
  40c5fc:	pop    r15
  40c5fe:	pop    r14
  40c600:	pop    r13
  40c602:	pop    r12
  40c604:	pop    rdi
  40c605:	pop    rsi
  40c606:	pop    rbx
  40c607:	pop    rbp
  40c608:	ret
  40c609:	mov    rax,QWORD PTR [rdi+0x8]
  40c60d:	mov    rax,QWORD PTR [rax]
  40c610:	mov    rsi,rax
  40c613:	mov    rdi,QWORD PTR [rdi]
  40c616:	mov    eax,0x1
  40c61b:	mov    r14b,al
  40c61e:	test   rdi,rdi
  40c621:	mov    rbx,QWORD PTR [rsp+0x20]
  40c626:	jne    40c670 <__swc_fn_4fa09e82_000094_c2567a3b+0x360>
  40c628:	test   r14b,r14b
  40c62b:	je     40c65d <__swc_fn_4fa09e82_000094_c2567a3b+0x34d>
  40c62d:	test   r12,r12
  40c630:	je     40c65d <__swc_fn_4fa09e82_000094_c2567a3b+0x34d>
  40c632:	mov    rcx,r15
  40c635:	mov    rdx,rsi
  40c638:	xor    r8d,r8d
  40c63b:	mov    r9,r12
  40c63e:	mov    rbx,QWORD PTR [rsp+0x20]
  40c643:	movzx  r10d,BYTE PTR [rbx]
  40c647:	call   40c200 <__swc_fn_4fa09e82_000088_ef55f6e4>
  40c64c:	add    rsp,0x38
  40c650:	pop    r15
  40c652:	pop    r14
  40c654:	pop    r13
  40c656:	pop    r12
  40c658:	pop    rdi
  40c659:	pop    rsi
  40c65a:	pop    rbx
  40c65b:	pop    rbp
  40c65c:	ret
  40c65d:	xor    eax,eax
  40c65f:	add    rsp,0x38
  40c663:	pop    r15
  40c665:	pop    r14
  40c667:	pop    r13
  40c669:	pop    r12
  40c66b:	pop    rdi
  40c66c:	pop    rsi
  40c66d:	pop    rbx
  40c66e:	pop    rbp
  40c66f:	ret
  40c670:	mov    r13,rsi
  40c673:	mov    QWORD PTR [rsp+0x28],rdi
  40c678:	cmp    BYTE PTR [r15+0x2c],0xe
  40c67d:	sete   al
  40c680:	mov    r14b,al
  40c683:	jne    40c697 <__swc_fn_4fa09e82_000094_c2567a3b+0x387>
  40c685:	mov    rcx,rsi
  40c688:	mov    rdx,r15
  40c68b:	call   409160 <__swc_fn_4fa09e82_000090_d182c4dc>
  40c690:	mov    r14b,al
  40c693:	test   al,al
  40c695:	jne    40c6cc <__swc_fn_4fa09e82_000094_c2567a3b+0x3bc>
  40c697:	cmp    BYTE PTR [r15+0x2c],0x12
  40c69c:	je     40c6cc <__swc_fn_4fa09e82_000094_c2567a3b+0x3bc>
  40c69e:	mov    rcx,r15
  40c6a1:	mov    rdx,rsi
  40c6a4:	mov    r8,rdi
  40c6a7:	mov    r9,r12
  40c6aa:	mov    rax,rbx
  40c6ad:	movzx  r10d,BYTE PTR [rax]
  40c6b1:	call   40c200 <__swc_fn_4fa09e82_000088_ef55f6e4>
  40c6b6:	test   rax,rax
  40c6b9:	je     40c6cc <__swc_fn_4fa09e82_000094_c2567a3b+0x3bc>
  40c6bb:	add    rsp,0x38
  40c6bf:	pop    r15
  40c6c1:	pop    r14
  40c6c3:	pop    r13
  40c6c5:	pop    r12
  40c6c7:	pop    rdi
  40c6c8:	pop    rsi
  40c6c9:	pop    rbx
  40c6ca:	pop    rbp
  40c6cb:	ret
  40c6cc:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c6d1:	jne    40c6f0 <__swc_fn_4fa09e82_000094_c2567a3b+0x3e0>
  40c6d3:	mov    rax,QWORD PTR [rsi+0xd8]
  40c6da:	test   rax,rax
  40c6dd:	je     40c6f0 <__swc_fn_4fa09e82_000094_c2567a3b+0x3e0>
  40c6df:	add    rdi,QWORD PTR [rax+0x8]
  40c6e3:	mov    rax,QWORD PTR [rdi]
  40c6e6:	sub    rdi,QWORD PTR [rax+0x8]
  40c6ea:	mov    rax,QWORD PTR [rax]
  40c6ed:	mov    rsi,rax
  40c6f0:	test   r14b,r14b
  40c6f3:	je     40c71f <__swc_fn_4fa09e82_000094_c2567a3b+0x40f>
  40c6f5:	mov    rcx,r15
  40c6f8:	mov    rdx,rsi
  40c6fb:	mov    r8,rdi
  40c6fe:	mov    r9,r13
  40c701:	mov    r14,QWORD PTR [rsp+0x28]
  40c706:	mov    r10,r14
  40c709:	call   40f040 <__swc_fn_4fa09e82_000092_c1c9085b>
  40c70e:	add    rsp,0x38
  40c712:	pop    r15
  40c714:	pop    r14
  40c716:	pop    r13
  40c718:	pop    r12
  40c71a:	pop    rdi
  40c71b:	pop    rsi
  40c71c:	pop    rbx
  40c71d:	pop    rbp
  40c71e:	ret
  40c71f:	mov    rcx,r15
  40c722:	mov    rdx,rsi
  40c725:	mov    r8,rdi
  40c728:	mov    r9,r12
  40c72b:	movzx  r10d,BYTE PTR [rbx]
  40c72f:	call   40c200 <__swc_fn_4fa09e82_000088_ef55f6e4>
  40c734:	add    rsp,0x38
  40c738:	pop    r15
  40c73a:	pop    r14
  40c73c:	pop    r13
  40c73e:	pop    r12
  40c740:	pop    rdi
  40c741:	pop    rsi
  40c742:	pop    rbx
  40c743:	pop    rbp
  40c744:	ret
	...

000000000040c750 <__swc_fn_4fa09e82_000097_93bfe675>:
  40c750:	push   rbx
  40c751:	push   rsi
  40c752:	sub    rsp,0x18
  40c756:	mov    rbx,rcx
  40c759:	mov    rcx,QWORD PTR [rip+0x178e0]        # 424040 <__swc_bss_base_4fa09e82>
  40c760:	test   rcx,rcx
  40c763:	jne    40c775 <__swc_fn_4fa09e82_000097_93bfe675+0x25>
  40c765:	call   40a620 <__swc_fn_4fa09e82_000171_994c8876>
  40c76a:	lea    rcx,[rax+0x1]
  40c76e:	mov    QWORD PTR [rip+0x178cb],rcx        # 424040 <__swc_bss_base_4fa09e82>
  40c775:	dec    rcx
  40c778:	call   4121e0 <__swc_fn_4fa09e82_000173_360af05d>
  40c77d:	mov    rsi,rax
  40c780:	mov    rax,QWORD PTR [rsi+0x8]
  40c784:	test   rax,rax
  40c787:	jne    40c7d7 <__swc_fn_4fa09e82_000097_93bfe675+0x87>
  40c789:	call   409250 <__swc_fn_4fa09e82_000096_ad13d15c>
  40c78e:	test   al,al
  40c790:	jne    40c7d7 <__swc_fn_4fa09e82_000097_93bfe675+0x87>
  40c792:	lea    rdx,[rip+0x17aa7]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  40c799:	mov    rcx,rdx
  40c79c:	call   40e310 <__swc_fn_4fa09e82_000041_eb6108f2>
  40c7a1:	test   al,al
  40c7a3:	jne    40c7b4 <__swc_fn_4fa09e82_000097_93bfe675+0x64>
  40c7a5:	mov    rcx,rdx
  40c7a8:	call   407b40 <__swc_fn_4fa09e82_000039_14f56618>
  40c7ad:	lea    rdx,[rip+0x17a8c]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  40c7b4:	mov    QWORD PTR [rsp+0x8],rdx
  40c7b9:	lea    rax,[rip+0x6ab8]        # 413278 <__swc_rdata_base_4fa09e82+0x168>
  40c7c0:	mov    QWORD PTR [rsp+0x10],rax
  40c7c5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c7cb:	vmovups XMMWORD PTR [rsi],xmm0
  40c7cf:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c7d7:	vmovups xmm0,XMMWORD PTR [rsi]
  40c7db:	vmovups XMMWORD PTR [rbx],xmm0
  40c7df:	mov    rax,rbx
  40c7e2:	add    rsp,0x18
  40c7e6:	pop    rsi
  40c7e7:	pop    rbx
  40c7e8:	ret
  40c7e9:	add    BYTE PTR [rax],al
  40c7eb:	add    BYTE PTR [rax],al
  40c7ed:	add    BYTE PTR [rax],al
	...

000000000040c7f0 <__swc_fn_4fa09e82_000100_65137b72>:
  40c7f0:	sub    rsp,0x8
  40c7f4:	call   4097c0 <__swc_fn_4fa09e82_000123_0a5fa85a>
  40c7f9:	add    rsp,0x8
  40c7fd:	ret
	...

000000000040c800 <__swc_fn_4fa09e82_000103_e34f54dc>:
  40c800:	push   rbx
  40c801:	push   rsi
  40c802:	sub    rsp,0x28
  40c806:	mov    rbx,rcx
  40c809:	xor    esi,esi
  40c80b:	jmp    40c820 <__swc_fn_4fa09e82_000103_e34f54dc+0x20>
  40c80d:	nop    DWORD PTR [rax]
  40c810:	mov    QWORD PTR [rbx+0x28],rsi
  40c814:	mov    rsi,rbx
  40c817:	mov    rbx,rax
  40c81a:	nop    WORD PTR [rax+rax*1+0x0]
  40c820:	test   rbx,rbx
  40c823:	je     40c883 <__swc_fn_4fa09e82_000103_e34f54dc+0x83>
  40c825:	mov    rcx,rbx
  40c828:	mov    edx,0x1
  40c82d:	call   40edc0 <__swc_fn_4fa09e82_000083_63a67586>
  40c832:	cmp    rax,0x1
  40c836:	jne    40c883 <__swc_fn_4fa09e82_000103_e34f54dc+0x83>
  40c838:	mov    r10,QWORD PTR [rbx+0x18]
  40c83c:	mov    rcx,r10
  40c83f:	mov    edx,0x1
  40c844:	call   40edc0 <__swc_fn_4fa09e82_000083_63a67586>
  40c849:	cmp    rax,0x1
  40c84d:	jne    40c85c <__swc_fn_4fa09e82_000103_e34f54dc+0x5c>
  40c84f:	mov    rcx,r10
  40c852:	call   4093f0 <__swc_fn_4fa09e82_000102_d0b19c14>
  40c857:	test   rax,rax
  40c85a:	jne    40c810 <__swc_fn_4fa09e82_000103_e34f54dc+0x10>
  40c85c:	mov    rax,QWORD PTR [rbx+0x20]
  40c860:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c865:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c86b:	lea    rcx,[rsp+0x8]
  40c870:	mov    rdx,rbx
  40c873:	mov    r8d,0x30
  40c879:	mov    rbx,rax
  40c87c:	call   40f520 <__swc_fn_4fa09e82_000101_d4bdcaa4>
  40c881:	jmp    40c820 <__swc_fn_4fa09e82_000103_e34f54dc+0x20>
  40c883:	test   rsi,rsi
  40c886:	jne    40c88f <__swc_fn_4fa09e82_000103_e34f54dc+0x8f>
  40c888:	add    rsp,0x28
  40c88c:	pop    rsi
  40c88d:	pop    rbx
  40c88e:	ret
  40c88f:	mov    rax,rsi
  40c892:	mov    rsi,QWORD PTR [rsi+0x28]
  40c896:	mov    rbx,QWORD PTR [rax+0x20]
  40c89a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40c89f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40c8a5:	lea    rcx,[rsp+0x18]
  40c8aa:	mov    rdx,rax
  40c8ad:	mov    r8d,0x30
  40c8b3:	call   40f520 <__swc_fn_4fa09e82_000101_d4bdcaa4>
  40c8b8:	jmp    40c820 <__swc_fn_4fa09e82_000103_e34f54dc+0x20>
  40c8bd:	add    BYTE PTR [rax],al
	...

000000000040c8c0 <__swc_fn_4fa09e82_000106_5a85fcf5>:
  40c8c0:	push   rbx
  40c8c1:	push   rsi
  40c8c2:	push   rdi
  40c8c3:	push   r12
  40c8c5:	push   r13
  40c8c7:	sub    rsp,0x20
  40c8cb:	mov    rbx,rcx
  40c8ce:	lea    rsi,[rcx+0x6f8]
  40c8d5:	mov    edi,0x4
  40c8da:	mov    r12,rsi
  40c8dd:	test   rdi,rdi
  40c8e0:	je     40c92a <__swc_fn_4fa09e82_000106_5a85fcf5+0x6a>
  40c8e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40c8ec:	nop    DWORD PTR [rax+0x0]
  40c8f0:	mov    rcx,QWORD PTR [r12+0x10]
  40c8f5:	mov    QWORD PTR [r12+0x10],0x0
  40c8fe:	vxorps xmm0,xmm0,xmm0
  40c902:	vmovups XMMWORD PTR [r12],xmm0
  40c908:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40c90f:	mov    DWORD PTR [r12+0x20],0x0
  40c918:	call   40f570 <__swc_fn_4fa09e82_000104_2fdd2c61>
  40c91d:	add    r12,0x90
  40c924:	sub    rdi,0x1
  40c928:	jne    40c8f0 <__swc_fn_4fa09e82_000106_5a85fcf5+0x30>
  40c92a:	mov    rax,QWORD PTR [rbx+0x938]
  40c931:	mov    rdi,rax
  40c934:	test   rdi,rdi
  40c937:	je     40c991 <__swc_fn_4fa09e82_000106_5a85fcf5+0xd1>
  40c939:	nop    DWORD PTR [rax+0x0]
  40c940:	mov    r12d,0x10
  40c946:	lea    r13,[rdi+0x18]
  40c94a:	test   r12,r12
  40c94d:	je     40c986 <__swc_fn_4fa09e82_000106_5a85fcf5+0xc6>
  40c94f:	nop
  40c950:	mov    rcx,QWORD PTR [r13+0x10]
  40c954:	mov    QWORD PTR [r13+0x10],0x0
  40c95c:	vxorps xmm0,xmm0,xmm0
  40c960:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40c966:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40c96c:	mov    DWORD PTR [r13+0x20],0x0
  40c974:	call   40f570 <__swc_fn_4fa09e82_000104_2fdd2c61>
  40c979:	add    r13,0x90
  40c980:	sub    r12,0x1
  40c984:	jne    40c950 <__swc_fn_4fa09e82_000106_5a85fcf5+0x90>
  40c986:	mov    rax,QWORD PTR [rdi]
  40c989:	mov    rdi,rax
  40c98c:	test   rax,rax
  40c98f:	jne    40c940 <__swc_fn_4fa09e82_000106_5a85fcf5+0x80>
  40c991:	vxorps xmm0,xmm0,xmm0
  40c995:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40c99d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40c9a7:	mov    DWORD PTR [rbx+0x9a8],0x0
  40c9b1:	mov    edi,0x4
  40c9b6:	mov    r12,rsi
  40c9b9:	lea    rsi,[rsi+0x38]
  40c9bd:	test   rdi,rdi
  40c9c0:	je     40c9ec <__swc_fn_4fa09e82_000106_5a85fcf5+0x12c>
  40c9c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40c9cc:	nop    DWORD PTR [rax+0x0]
  40c9d0:	mov    rcx,rsi
  40c9d3:	call   40d890 <__swc_fn_4fa09e82_000163_13ead2ff>
  40c9d8:	add    rsi,0x90
  40c9df:	add    r12,0x90
  40c9e6:	sub    rdi,0x1
  40c9ea:	jne    40c9d0 <__swc_fn_4fa09e82_000106_5a85fcf5+0x110>
  40c9ec:	mov    rax,QWORD PTR [rbx+0x938]
  40c9f3:	mov    rdi,rax
  40c9f6:	mov    QWORD PTR [rbx+0x938],0x0
  40ca01:	test   rdi,rdi
  40ca04:	je     40ca75 <__swc_fn_4fa09e82_000106_5a85fcf5+0x1b5>
  40ca0a:	nop    WORD PTR [rax+rax*1+0x0]
  40ca10:	mov    esi,0x10
  40ca15:	lea    r12,[rdi+0x18]
  40ca19:	lea    r13,[rdi+0x50]
  40ca1d:	test   rsi,rsi
  40ca20:	je     40ca4c <__swc_fn_4fa09e82_000106_5a85fcf5+0x18c>
  40ca22:	cs nop WORD PTR [rax+rax*1+0x0]
  40ca2c:	nop    DWORD PTR [rax+0x0]
  40ca30:	mov    rcx,r13
  40ca33:	call   40d890 <__swc_fn_4fa09e82_000163_13ead2ff>
  40ca38:	add    r13,0x90
  40ca3f:	add    r12,0x90
  40ca46:	sub    rsi,0x1
  40ca4a:	jne    40ca30 <__swc_fn_4fa09e82_000106_5a85fcf5+0x170>
  40ca4c:	mov    rax,QWORD PTR [rdi]
  40ca4f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40ca54:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ca5a:	lea    rcx,[rsp+0x8]
  40ca5f:	mov    rdx,rdi
  40ca62:	mov    r8d,0x918
  40ca68:	mov    rdi,rax
  40ca6b:	call   40f520 <__swc_fn_4fa09e82_000101_d4bdcaa4>
  40ca70:	test   rdi,rdi
  40ca73:	jne    40ca10 <__swc_fn_4fa09e82_000106_5a85fcf5+0x150>
  40ca75:	lea    rcx,[rbx+0x68]
  40ca79:	call   40d890 <__swc_fn_4fa09e82_000163_13ead2ff>
  40ca7e:	add    rsp,0x20
  40ca82:	pop    r13
  40ca84:	pop    r12
  40ca86:	pop    rdi
  40ca87:	pop    rsi
  40ca88:	pop    rbx
  40ca89:	ret
  40ca8a:	add    BYTE PTR [rax],al
  40ca8c:	add    BYTE PTR [rax],al
	...

000000000040ca90 <__swc_fn_4fa09e82_000109_c51c3158>:
  40ca90:	xor    eax,eax
  40ca92:	cs nop WORD PTR [rax+rax*1+0x0]
  40ca9c:	nop    DWORD PTR [rax+0x0]
  40caa0:	mov    r9,r8
  40caa3:	sub    r9,rax
  40caa6:	cmp    r9,0x40
  40caaa:	jb     40cae8 <__swc_fn_4fa09e82_000109_c51c3158+0x58>
  40caac:	lea    r9,[rcx+rax*1]
  40cab0:	lea    r10,[rdx+rax*1]
  40cab4:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40caba:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40cac0:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40cac6:	vmovups xmm3,XMMWORD PTR [r10]
  40cacb:	vmovups XMMWORD PTR [r9],xmm3
  40cad0:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40cad6:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40cadc:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40cae2:	lea    rax,[rax+0x40]
  40cae6:	jmp    40caa0 <__swc_fn_4fa09e82_000109_c51c3158+0x10>
  40cae8:	nop    DWORD PTR [rax+rax*1+0x0]
  40caf0:	mov    r9,r8
  40caf3:	sub    r9,rax
  40caf6:	cmp    r9,0x10
  40cafa:	jb     40cb14 <__swc_fn_4fa09e82_000109_c51c3158+0x84>
  40cafc:	lea    r9,[rdx+rax*1]
  40cb00:	lea    r10,[rcx+rax*1]
  40cb04:	vmovups xmm0,XMMWORD PTR [r9]
  40cb09:	vmovups XMMWORD PTR [r10],xmm0
  40cb0e:	lea    rax,[rax+0x10]
  40cb12:	jmp    40caf0 <__swc_fn_4fa09e82_000109_c51c3158+0x60>
  40cb14:	cs nop WORD PTR [rax+rax*1+0x0]
  40cb1e:	xchg   ax,ax
  40cb20:	mov    r9,r8
  40cb23:	sub    r9,rax
  40cb26:	cmp    r9,0x8
  40cb2a:	jb     40cb3d <__swc_fn_4fa09e82_000109_c51c3158+0xad>
  40cb2c:	lea    r9,[rcx+rax*1]
  40cb30:	mov    r10,QWORD PTR [rdx+rax*1]
  40cb34:	mov    QWORD PTR [r9],r10
  40cb37:	lea    rax,[rax+0x8]
  40cb3b:	jmp    40cb20 <__swc_fn_4fa09e82_000109_c51c3158+0x90>
  40cb3d:	cmp    rax,r8
  40cb40:	jae    40cb60 <__swc_fn_4fa09e82_000109_c51c3158+0xd0>
  40cb42:	cs nop WORD PTR [rax+rax*1+0x0]
  40cb4c:	nop    DWORD PTR [rax+0x0]
  40cb50:	mov    r9b,BYTE PTR [rdx+rax*1]
  40cb54:	mov    BYTE PTR [rcx+rax*1],r9b
  40cb58:	inc    rax
  40cb5b:	cmp    rax,r8
  40cb5e:	jb     40cb50 <__swc_fn_4fa09e82_000109_c51c3158+0xc0>
  40cb60:	ret
	...

000000000040cb70 <__swc_fn_4fa09e82_000112_3dc01326>:
  40cb70:	test   r8,r8
  40cb73:	jne    40cb78 <__swc_fn_4fa09e82_000112_3dc01326+0x8>
  40cb75:	xor    eax,eax
  40cb77:	ret
  40cb78:	xor    eax,eax
  40cb7a:	nop    WORD PTR [rax+rax*1+0x0]
  40cb80:	mov    r9,r8
  40cb83:	sub    r9,rax
  40cb86:	cmp    r9,0x10
  40cb8a:	jb     40cbd4 <__swc_fn_4fa09e82_000112_3dc01326+0x64>
  40cb8c:	lea    r9,[rcx+rax*1]
  40cb90:	lea    r10,[rdx+rax*1]
  40cb94:	vmovups xmm0,XMMWORD PTR [r10]
  40cb99:	vmovups xmm1,XMMWORD PTR [r9]
  40cb9e:	vpcmpeqb xmm0,xmm1,xmm0
  40cba2:	vpmovmskb r9d,xmm0
  40cba6:	cmp    r9d,0xffff
  40cbad:	je     40cbce <__swc_fn_4fa09e82_000112_3dc01326+0x5e>
  40cbaf:	not    r9d
  40cbb2:	xor    r8d,r8d
  40cbb5:	movzx  r9d,r9w
  40cbb9:	tzcnt  r8d,r9d
  40cbbe:	add    rax,r8
  40cbc1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cbc5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cbc9:	sub    ecx,eax
  40cbcb:	mov    eax,ecx
  40cbcd:	ret
  40cbce:	lea    rax,[rax+0x10]
  40cbd2:	jmp    40cb80 <__swc_fn_4fa09e82_000112_3dc01326+0x10>
  40cbd4:	cmp    r9,0x8
  40cbd8:	jb     40cc4b <__swc_fn_4fa09e82_000112_3dc01326+0xdb>
  40cbda:	lea    r9,[rcx+rax*1]
  40cbde:	lea    r10,[rdx+rax*1]
  40cbe2:	mov    r9,QWORD PTR [r9]
  40cbe5:	xor    r9,QWORD PTR [r10]
  40cbe8:	test   r9,r9
  40cbeb:	je     40cc09 <__swc_fn_4fa09e82_000112_3dc01326+0x99>
  40cbed:	xor    r8d,r8d
  40cbf0:	tzcnt  r8,r9
  40cbf5:	shr    r8,0x3
  40cbf9:	add    rax,r8
  40cbfc:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cc00:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cc04:	sub    ecx,eax
  40cc06:	mov    eax,ecx
  40cc08:	ret
  40cc09:	lea    rax,[rax+0x8]
  40cc0d:	cmp    rax,r8
  40cc10:	jne    40cc15 <__swc_fn_4fa09e82_000112_3dc01326+0xa5>
  40cc12:	xor    eax,eax
  40cc14:	ret
  40cc15:	lea    rax,[r8-0x8]
  40cc19:	lea    r8,[rcx+rax*1]
  40cc1d:	lea    r9,[rdx+rax*1]
  40cc21:	mov    r8,QWORD PTR [r8]
  40cc24:	xor    r8,QWORD PTR [r9]
  40cc27:	test   r8,r8
  40cc2a:	je     40cc48 <__swc_fn_4fa09e82_000112_3dc01326+0xd8>
  40cc2c:	xor    r9d,r9d
  40cc2f:	tzcnt  r9,r8
  40cc34:	shr    r9,0x3
  40cc38:	add    rax,r9
  40cc3b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cc3f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cc43:	sub    ecx,eax
  40cc45:	mov    eax,ecx
  40cc47:	ret
  40cc48:	xor    eax,eax
  40cc4a:	ret
  40cc4b:	cmp    r9,0x4
  40cc4f:	jb     40ccc2 <__swc_fn_4fa09e82_000112_3dc01326+0x152>
  40cc51:	lea    r9,[rcx+rax*1]
  40cc55:	lea    r10,[rdx+rax*1]
  40cc59:	mov    r9d,DWORD PTR [r9]
  40cc5c:	xor    r9d,DWORD PTR [r10]
  40cc5f:	test   r9d,r9d
  40cc62:	je     40cc80 <__swc_fn_4fa09e82_000112_3dc01326+0x110>
  40cc64:	xor    r8d,r8d
  40cc67:	tzcnt  r8,r9
  40cc6c:	shr    r8,0x3
  40cc70:	add    rax,r8
  40cc73:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cc77:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cc7b:	sub    ecx,eax
  40cc7d:	mov    eax,ecx
  40cc7f:	ret
  40cc80:	lea    rax,[rax+0x4]
  40cc84:	cmp    rax,r8
  40cc87:	jne    40cc8c <__swc_fn_4fa09e82_000112_3dc01326+0x11c>
  40cc89:	xor    eax,eax
  40cc8b:	ret
  40cc8c:	lea    rax,[r8-0x4]
  40cc90:	lea    r8,[rcx+rax*1]
  40cc94:	lea    r9,[rdx+rax*1]
  40cc98:	mov    r8d,DWORD PTR [r8]
  40cc9b:	xor    r8d,DWORD PTR [r9]
  40cc9e:	test   r8d,r8d
  40cca1:	je     40ccbf <__swc_fn_4fa09e82_000112_3dc01326+0x14f>
  40cca3:	xor    r9d,r9d
  40cca6:	tzcnt  r9,r8
  40ccab:	shr    r9,0x3
  40ccaf:	add    rax,r9
  40ccb2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40ccb6:	movzx  eax,BYTE PTR [rdx+rax*1]
  40ccba:	sub    ecx,eax
  40ccbc:	mov    eax,ecx
  40ccbe:	ret
  40ccbf:	xor    eax,eax
  40ccc1:	ret
  40ccc2:	cmp    r9,0x2
  40ccc6:	jb     40cd19 <__swc_fn_4fa09e82_000112_3dc01326+0x1a9>
  40ccc8:	lea    r9,[rcx+rax*1]
  40cccc:	lea    r10,[rdx+rax*1]
  40ccd0:	mov    r9w,WORD PTR [r9]
  40ccd4:	xor    r9w,WORD PTR [r10]
  40ccd8:	test   r9w,r9w
  40ccdc:	je     40ccfe <__swc_fn_4fa09e82_000112_3dc01326+0x18e>
  40ccde:	xor    r8d,r8d
  40cce1:	movzx  r9d,r9w
  40cce5:	tzcnt  r8,r9
  40ccea:	shr    r8,0x3
  40ccee:	add    rax,r8
  40ccf1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40ccf5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40ccf9:	sub    ecx,eax
  40ccfb:	mov    eax,ecx
  40ccfd:	ret
  40ccfe:	lea    rax,[rax+0x2]
  40cd02:	cmp    rax,r8
  40cd05:	jne    40cd0a <__swc_fn_4fa09e82_000112_3dc01326+0x19a>
  40cd07:	xor    eax,eax
  40cd09:	ret
  40cd0a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40cd10:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40cd16:	sub    eax,ecx
  40cd18:	ret
  40cd19:	test   r9,r9
  40cd1c:	je     40cd2b <__swc_fn_4fa09e82_000112_3dc01326+0x1bb>
  40cd1e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cd22:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cd26:	sub    ecx,eax
  40cd28:	mov    eax,ecx
  40cd2a:	ret
  40cd2b:	xor    eax,eax
  40cd2d:	ret
	...

000000000040cd30 <__swc_fn_4fa09e82_000115_6b799b8d>:
  40cd30:	push   r12
  40cd32:	push   r13
  40cd34:	push   r14
  40cd36:	push   rdi
  40cd37:	push   rsi
  40cd38:	push   r15
  40cd3a:	sub    rsp,0xd8
  40cd41:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40cd47:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40cd4d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40cd53:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40cd59:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40cd5f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40cd68:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40cd71:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40cd7a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40cd83:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40cd8c:	mov    r12,rcx
  40cd8f:	test   rcx,rcx
  40cd92:	je     40cdae <__swc_fn_4fa09e82_000115_6b799b8d+0x7e>
  40cd94:	mov    eax,r12d
  40cd97:	and    eax,0xfff
  40cd9d:	setne  al
  40cda0:	cmp    r12,0xffffffffffffefff
  40cda7:	seta   cl
  40cdaa:	or     al,cl
  40cdac:	je     40cdb5 <__swc_fn_4fa09e82_000115_6b799b8d+0x85>
  40cdae:	xor    eax,eax
  40cdb0:	jmp    40ce4b <__swc_fn_4fa09e82_000115_6b799b8d+0x11b>
  40cdb5:	call   409580 <__swc_fn_4fa09e82_000114_126150d1>
  40cdba:	mov    r13,rax
  40cdbd:	test   rax,rax
  40cdc0:	jne    40cdc9 <__swc_fn_4fa09e82_000115_6b799b8d+0x99>
  40cdc2:	xor    eax,eax
  40cdc4:	jmp    40ce4b <__swc_fn_4fa09e82_000115_6b799b8d+0x11b>
  40cdc9:	lea    r14,[r12+0x1000]
  40cdd1:	xor    edi,edi
  40cdd3:	mov    rsi,r14
  40cdd6:	xor    edx,edx
  40cdd8:	mov    ecx,0x22
  40cddd:	mov    eax,0xffffffff
  40cde2:	movsxd r8,eax
  40cde5:	xor    r9d,r9d
  40cde8:	xor    eax,eax
  40cdea:	call   4070c0 <mmap@plt>
  40cdef:	mov    r15,rax
  40cdf2:	cmp    rax,0xffffffffffffffff
  40cdf6:	jne    40cdfc <__swc_fn_4fa09e82_000115_6b799b8d+0xcc>
  40cdf8:	xor    eax,eax
  40cdfa:	jmp    40ce4b <__swc_fn_4fa09e82_000115_6b799b8d+0x11b>
  40cdfc:	mov    rdi,r15
  40cdff:	mov    esi,0x1000
  40ce04:	mov    edx,0x3
  40ce09:	xor    eax,eax
  40ce0b:	call   407030 <mprotect@plt>
  40ce10:	test   eax,eax
  40ce12:	je     40ce25 <__swc_fn_4fa09e82_000115_6b799b8d+0xf5>
  40ce14:	mov    rdi,r15
  40ce17:	mov    rsi,r14
  40ce1a:	xor    eax,eax
  40ce1c:	call   407020 <munmap@plt>
  40ce21:	xor    eax,eax
  40ce23:	jmp    40ce4b <__swc_fn_4fa09e82_000115_6b799b8d+0x11b>
  40ce25:	mov    QWORD PTR [r15+0x8],r12
  40ce29:	mov    rcx,r13
  40ce2c:	call   40d490 <__swc_fn_4fa09e82_000139_8c07c14b>
  40ce31:	mov    rax,QWORD PTR [r13+0x8]
  40ce35:	mov    QWORD PTR [r15],rax
  40ce38:	mov    QWORD PTR [r13+0x8],r15
  40ce3c:	mov    rcx,r13
  40ce3f:	call   4108e0 <__swc_fn_4fa09e82_000140_715e84ff>
  40ce44:	lea    rax,[r15+0x1000]
  40ce4b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40ce51:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40ce57:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40ce5d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40ce63:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40ce69:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40ce72:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40ce7b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40ce84:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40ce8d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40ce96:	add    rsp,0xd8
  40ce9d:	pop    r15
  40ce9f:	pop    rsi
  40cea0:	pop    rdi
  40cea1:	pop    r14
  40cea3:	pop    r13
  40cea5:	pop    r12
  40cea7:	ret
	...

000000000040ceb0 <__swc_fn_4fa09e82_000118_e9fc0224>:
  40ceb0:	push   rbx
  40ceb1:	push   r12
  40ceb3:	push   rdi
  40ceb4:	push   rsi
  40ceb5:	sub    rsp,0xa8
  40cebc:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cec2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cec8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cece:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40ced4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ceda:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cee0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cee6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ceec:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cef5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cefe:	mov    rbx,rdx
  40cf01:	mov    r12,rcx
  40cf04:	mov    rdi,rcx
  40cf07:	mov    rsi,rdx
  40cf0a:	xor    edx,edx
  40cf0c:	xor    eax,eax
  40cf0e:	call   407030 <mprotect@plt>
  40cf13:	test   eax,eax
  40cf15:	jne    40cf39 <__swc_fn_4fa09e82_000118_e9fc0224+0x89>
  40cf17:	mov    rcx,r12
  40cf1a:	mov    rdx,rbx
  40cf1d:	xor    al,al
  40cf1f:	mov    r8,rax
  40cf22:	call   410380 <__swc_fn_4fa09e82_000116_5f48311c>
  40cf27:	mov    rdi,r12
  40cf2a:	mov    rsi,rbx
  40cf2d:	mov    edx,0x4
  40cf32:	xor    eax,eax
  40cf34:	call   4070e0 <madvise@plt>
  40cf39:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cf3f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cf45:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cf4b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cf51:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cf57:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cf5d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cf63:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cf69:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cf72:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cf7b:	add    rsp,0xa8
  40cf82:	pop    rsi
  40cf83:	pop    rdi
  40cf84:	pop    r12
  40cf86:	pop    rbx
  40cf87:	ret
	...

000000000040cf90 <__swc_fn_4fa09e82_000121_d3318640>:
  40cf90:	push   rsi
  40cf91:	push   rdi
  40cf92:	push   r12
  40cf94:	push   r13
  40cf96:	push   r14
  40cf98:	sub    rsp,0xe0
  40cf9f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40cfa5:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40cfab:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40cfb1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40cfb7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40cfbd:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40cfc6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40cfcf:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40cfd8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40cfe1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40cfea:	mov    rsi,rdx
  40cfed:	mov    rdi,rcx
  40cff0:	call   409580 <__swc_fn_4fa09e82_000114_126150d1>
  40cff5:	mov    r12,rax
  40cff8:	test   rax,rax
  40cffb:	jne    40d002 <__swc_fn_4fa09e82_000121_d3318640+0x72>
  40cffd:	jmp    40d076 <__swc_fn_4fa09e82_000121_d3318640+0xe6>
  40d002:	mov    rcx,r12
  40d005:	call   40d490 <__swc_fn_4fa09e82_000139_8c07c14b>
  40d00a:	lea    r13,[r12+0x8]
  40d00f:	mov    rax,QWORD PTR [r13+0x0]
  40d013:	test   rax,rax
  40d016:	je     40d06e <__swc_fn_4fa09e82_000121_d3318640+0xde>
  40d018:	nop    DWORD PTR [rax+rax*1+0x0]
  40d020:	lea    rcx,[rax+0x1000]
  40d027:	cmp    rcx,rdi
  40d02a:	jne    40d062 <__swc_fn_4fa09e82_000121_d3318640+0xd2>
  40d02c:	cmp    QWORD PTR [rax+0x8],rsi
  40d030:	je     40d03c <__swc_fn_4fa09e82_000121_d3318640+0xac>
  40d032:	mov    rcx,r12
  40d035:	call   4108e0 <__swc_fn_4fa09e82_000140_715e84ff>
  40d03a:	jmp    40d076 <__swc_fn_4fa09e82_000121_d3318640+0xe6>
  40d03c:	mov    r14,QWORD PTR [rax]
  40d03f:	mov    rdi,rax
  40d042:	lea    rsi,[rsi+0x1000]
  40d049:	xor    eax,eax
  40d04b:	call   407020 <munmap@plt>
  40d050:	test   eax,eax
  40d052:	jne    40d058 <__swc_fn_4fa09e82_000121_d3318640+0xc8>
  40d054:	mov    QWORD PTR [r13+0x0],r14
  40d058:	mov    rcx,r12
  40d05b:	call   4108e0 <__swc_fn_4fa09e82_000140_715e84ff>
  40d060:	jmp    40d076 <__swc_fn_4fa09e82_000121_d3318640+0xe6>
  40d062:	mov    r13,rax
  40d065:	mov    rax,QWORD PTR [r13+0x0]
  40d069:	test   rax,rax
  40d06c:	jne    40d020 <__swc_fn_4fa09e82_000121_d3318640+0x90>
  40d06e:	mov    rcx,r12
  40d071:	call   4108e0 <__swc_fn_4fa09e82_000140_715e84ff>
  40d076:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40d07c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40d082:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40d088:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40d08e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40d094:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40d09d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40d0a6:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40d0af:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40d0b8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40d0c1:	add    rsp,0xe0
  40d0c8:	pop    r14
  40d0ca:	pop    r13
  40d0cc:	pop    r12
  40d0ce:	pop    rdi
  40d0cf:	pop    rsi
  40d0d0:	ret
	...

000000000040d0e0 <__swc_fn_4fa09e82_000124_be2e2f68>:
  40d0e0:	push   rdi
  40d0e1:	push   rsi
  40d0e2:	sub    rsp,0xa8
  40d0e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d0ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d0f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d0fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d101:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d107:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d10d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d113:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d119:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d122:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d12b:	mov    rdi,0xfffffffffffffd66
  40d132:	xor    eax,eax
  40d134:	call   407040 <exit@plt>
  40d139:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d13f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d145:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d14b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d151:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d157:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d15d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d163:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d169:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d172:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d17b:	add    rsp,0xa8
  40d182:	pop    rsi
  40d183:	pop    rdi
  40d184:	ret
	...

000000000040d1a0 <__swc_fn_4fa09e82_000127_540bf7e8>:
  40d1a0:	push   rbx
  40d1a1:	push   rsi
  40d1a2:	push   rdi
  40d1a3:	sub    rsp,0x30
  40d1a7:	mov    rbx,rdx
  40d1aa:	mov    esi,ecx
  40d1ac:	test   ecx,ecx
  40d1ae:	je     40d283 <__swc_fn_4fa09e82_000127_540bf7e8+0xe3>
  40d1b4:	mov    rcx,rsi
  40d1b7:	shl    rcx,0x4
  40d1bb:	call   409090 <__swc_fn_4fa09e82_000084_4a10c7e7>
  40d1c0:	test   rax,rax
  40d1c3:	je     40d272 <__swc_fn_4fa09e82_000127_540bf7e8+0xd2>
  40d1c9:	mov    rcx,rsi
  40d1cc:	xor    edx,edx
  40d1ce:	test   rsi,rsi
  40d1d1:	jbe    40d252 <__swc_fn_4fa09e82_000127_540bf7e8+0xb2>
  40d1d7:	nop    WORD PTR [rax+rax*1+0x0]
  40d1e0:	mov    r8d,edx
  40d1e3:	mov    r9,QWORD PTR [rbx+r8*8]
  40d1e7:	add    r8,r8
  40d1ea:	lea    r8,[rax+r8*8]
  40d1ee:	xor    r10d,r10d
  40d1f1:	test   r9,r9
  40d1f4:	je     40d230 <__swc_fn_4fa09e82_000127_540bf7e8+0x90>
  40d1f6:	mov    r11,r9
  40d1f9:	mov    dil,BYTE PTR [r11]
  40d1fc:	test   dil,dil
  40d1ff:	je     40d230 <__swc_fn_4fa09e82_000127_540bf7e8+0x90>
  40d201:	cs nop WORD PTR [rax+rax*1+0x0]
  40d20b:	cs nop WORD PTR [rax+rax*1+0x0]
  40d215:	cs nop WORD PTR [rax+rax*1+0x0]
  40d21f:	nop
  40d220:	add    r11,0x1
  40d224:	add    r10,0x1
  40d228:	mov    dil,BYTE PTR [r11]
  40d22b:	test   dil,dil
  40d22e:	jne    40d220 <__swc_fn_4fa09e82_000127_540bf7e8+0x80>
  40d230:	mov    QWORD PTR [rsp+0x18],r9
  40d235:	mov    QWORD PTR [rsp+0x20],r10
  40d23a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40d240:	vmovups XMMWORD PTR [r8],xmm0
  40d245:	add    rdx,0x1
  40d249:	cmp    rdx,rcx
  40d24c:	jb     40d1e0 <__swc_fn_4fa09e82_000127_540bf7e8+0x40>
  40d252:	lea    rcx,[rip+0x19aef]        # 426d48 <__swc_bss_base_4fa09e82+0x2d08>
  40d259:	mov    QWORD PTR [rsp+0x8],rax
  40d25e:	mov    esi,esi
  40d260:	mov    QWORD PTR [rsp+0x10],rsi
  40d265:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40d26b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d270:	jmp    40d283 <__swc_fn_4fa09e82_000127_540bf7e8+0xe3>
  40d272:	lea    rcx,[rip+0x6377]        # 4135f0 <__swc_rdata_base_4fa09e82+0x4e0>
  40d279:	call   410430 <__swc_fn_4fa09e82_000122_2648f149>
  40d27e:	call   40d0e0 <__swc_fn_4fa09e82_000124_be2e2f68>
  40d283:	add    rsp,0x30
  40d287:	pop    rdi
  40d288:	pop    rsi
  40d289:	pop    rbx
  40d28a:	ret
  40d28b:	add    BYTE PTR [rax],al
  40d28d:	add    BYTE PTR [rax],al
	...

000000000040d290 <__swc_fn_4fa09e82_000130_a481cb88>:
  40d290:	push   rdi
  40d291:	push   rsi
  40d292:	sub    rsp,0xa8
  40d299:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d29f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d2a5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d2ab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d2b1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d2b7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d2bd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d2c3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d2c9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d2d2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d2db:	mov    edi,ecx
  40d2dd:	xor    eax,eax
  40d2df:	call   4070f0 <pthread_key_delete@plt>
  40d2e4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d2ea:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d2f0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d2f6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d2fc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d302:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d308:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d30e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d314:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d31d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d326:	add    rsp,0xa8
  40d32d:	pop    rsi
  40d32e:	pop    rdi
  40d32f:	ret

000000000040d330 <__swc_fn_4fa09e82_000133_a611b8c4>:
  40d330:	push   rdi
  40d331:	push   rsi
  40d332:	sub    rsp,0xa8
  40d339:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d33f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d345:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d34b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d351:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d357:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d35d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d363:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d369:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d372:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d37b:	test   rcx,rcx
  40d37e:	je     40d38f <__swc_fn_4fa09e82_000133_a611b8c4+0x5f>
  40d380:	lea    rax,[rcx-0x1]
  40d384:	mov    eax,eax
  40d386:	mov    edi,eax
  40d388:	xor    eax,eax
  40d38a:	call   4070f0 <pthread_key_delete@plt>
  40d38f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d395:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d39b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d3a1:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d3a7:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d3ad:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d3b3:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d3b9:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d3bf:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d3c8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d3d1:	add    rsp,0xa8
  40d3d8:	pop    rsi
  40d3d9:	pop    rdi
  40d3da:	ret
  40d3db:	add    BYTE PTR [rax],al
  40d3dd:	add    BYTE PTR [rax],al
	...

000000000040d3e0 <__swc_fn_4fa09e82_000136_a9c1c700>:
  40d3e0:	push   rsi
  40d3e1:	push   rdi
  40d3e2:	sub    rsp,0xa8
  40d3e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d3ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d3f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d3fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d401:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d407:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d40d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d413:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d419:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d422:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d42b:	xor    eax,eax
  40d42d:	call   407100 <gettid@plt>
  40d432:	movsxd rax,eax
  40d435:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d43b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d441:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d447:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d44d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d453:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d459:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d45f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d465:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d46e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d477:	add    rsp,0xa8
  40d47e:	pop    rdi
  40d47f:	pop    rsi
  40d480:	ret
	...

000000000040d490 <__swc_fn_4fa09e82_000139_8c07c14b>:
  40d490:	push   rbx
  40d491:	push   rdi
  40d492:	push   rsi
  40d493:	sub    rsp,0xc0
  40d49a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d4a0:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d4a6:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d4ac:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d4b2:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d4b8:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d4be:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d4c4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d4cd:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d4d6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d4df:	mov    rbx,rcx
  40d4e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40d4ec:	nop    DWORD PTR [rax+0x0]
  40d4f0:	mov    edx,0x80000000
  40d4f5:	xor    eax,eax
  40d4f7:	lock cmpxchg DWORD PTR [rbx],edx
  40d4fb:	test   eax,eax
  40d4fd:	je     40d534 <__swc_fn_4fa09e82_000139_8c07c14b+0xa4>
  40d4ff:	mov    eax,DWORD PTR [rbx]
  40d501:	lea    rcx,[rsp+0x14]
  40d506:	mov    DWORD PTR [rsp+0x14],eax
  40d50a:	test   eax,eax
  40d50c:	je     40d4f0 <__swc_fn_4fa09e82_000139_8c07c14b+0x60>
  40d50e:	mov    QWORD PTR [rsp],0x0
  40d516:	mov    edi,0xca
  40d51b:	mov    rsi,rbx
  40d51e:	mov    edx,0x80
  40d523:	mov    ecx,DWORD PTR [rcx]
  40d525:	xor    r8d,r8d
  40d528:	xor    r9d,r9d
  40d52b:	xor    eax,eax
  40d52d:	call   407070 <syscall@plt>
  40d532:	jmp    40d4f0 <__swc_fn_4fa09e82_000139_8c07c14b+0x60>
  40d534:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d53a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d540:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d546:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d54c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d552:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d558:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d55e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d567:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d570:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d579:	add    rsp,0xc0
  40d580:	pop    rsi
  40d581:	pop    rdi
  40d582:	pop    rbx
  40d583:	ret
	...

000000000040d590 <__swc_fn_4fa09e82_000142_055b38a4>:
  40d590:	sub    rsp,0x8
  40d594:	call   4108e0 <__swc_fn_4fa09e82_000140_715e84ff>
  40d599:	add    rsp,0x8
  40d59d:	ret
	...

000000000040d5a0 <__swc_fn_4fa09e82_000145_d299b428>:
  40d5a0:	push   rdi
  40d5a1:	push   rsi
  40d5a2:	sub    rsp,0xa8
  40d5a9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d5af:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d5b5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d5bb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d5c1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d5c7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d5cd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d5d3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d5d9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d5e2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d5eb:	mov    edi,0x28
  40d5f0:	xor    eax,eax
  40d5f2:	call   4070d0 <malloc@plt>
  40d5f7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d5fd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d603:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d609:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d60f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d615:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d61b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d621:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d627:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d630:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d639:	add    rsp,0xa8
  40d640:	pop    rsi
  40d641:	pop    rdi
  40d642:	ret
	...

000000000040d650 <__swc_fn_4fa09e82_000148_162f363d>:
  40d650:	mov    QWORD PTR [r8],0x0
  40d657:	cmp    rdx,0x10
  40d65b:	jae    40d660 <__swc_fn_4fa09e82_000148_162f363d+0x10>
  40d65d:	xor    eax,eax
  40d65f:	ret
  40d660:	mov    eax,DWORD PTR [rcx]
  40d662:	cmp    eax,0x42445753
  40d668:	jne    40d672 <__swc_fn_4fa09e82_000148_162f363d+0x22>
  40d66a:	mov    eax,DWORD PTR [rcx+0x4]
  40d66d:	cmp    eax,0x1
  40d670:	je     40d675 <__swc_fn_4fa09e82_000148_162f363d+0x25>
  40d672:	xor    eax,eax
  40d674:	ret
  40d675:	mov    QWORD PTR [r8],rdx
  40d678:	mov    rax,rcx
  40d67b:	ret
  40d67c:	add    BYTE PTR [rax],al
	...

000000000040d680 <__swc_fn_4fa09e82_000151_2eb804cc>:
  40d680:	push   rbx
  40d681:	sub    rsp,0xe0
  40d688:	lea    rbx,[rsp+0x8]
  40d68d:	vxorps xmm0,xmm0,xmm0
  40d691:	vmovups YMMWORD PTR [rbx],ymm0
  40d695:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40d69a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40d69f:	vzeroupper
  40d6a2:	mov    DWORD PTR [rbx+0x60],0x0
  40d6a9:	mov    r8,rbx
  40d6ac:	mov    rdx,rcx
  40d6af:	nop
  40d6b0:	mov    r9,rdx
  40d6b3:	movabs rdx,0x6666666666666667
  40d6bd:	mov    rax,r9
  40d6c0:	imul   rdx
  40d6c3:	sar    rdx,0x2
  40d6c7:	mov    r10,rdx
  40d6ca:	shr    rdx,0x3f
  40d6ce:	add    r10,rdx
  40d6d1:	mov    rdx,r10
  40d6d4:	imul   r11,r10,0xa
  40d6d8:	sub    r9,r11
  40d6db:	mov    r11,QWORD PTR [rip+0x5f2e]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  40d6e2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40d6e7:	mov    BYTE PTR [r8],r9b
  40d6ea:	lea    r9,[r8+0x1]
  40d6ee:	mov    r8,r9
  40d6f1:	test   r10,r10
  40d6f4:	jne    40d6b0 <__swc_fn_4fa09e82_000151_2eb804cc+0x30>
  40d6f6:	test   rcx,rcx
  40d6f9:	jge    40d703 <__swc_fn_4fa09e82_000151_2eb804cc+0x83>
  40d6fb:	mov    BYTE PTR [r9],0x2d
  40d6ff:	add    r8,0x1
  40d703:	mov    BYTE PTR [r8],0x0
  40d707:	sub    r8,0x1
  40d70b:	mov    rax,rbx
  40d70e:	cmp    rax,r8
  40d711:	jae    40d736 <__swc_fn_4fa09e82_000151_2eb804cc+0xb6>
  40d713:	cs nop WORD PTR [rax+rax*1+0x0]
  40d71d:	nop    DWORD PTR [rax]
  40d720:	mov    cl,BYTE PTR [r8]
  40d723:	mov    dl,BYTE PTR [rax]
  40d725:	mov    BYTE PTR [r8],dl
  40d728:	sub    r8,0x1
  40d72c:	mov    BYTE PTR [rax],cl
  40d72e:	inc    rax
  40d731:	cmp    rax,r8
  40d734:	jb     40d720 <__swc_fn_4fa09e82_000151_2eb804cc+0xa0>
  40d736:	xor    eax,eax
  40d738:	test   rbx,rbx
  40d73b:	je     40d75e <__swc_fn_4fa09e82_000151_2eb804cc+0xde>
  40d73d:	mov    rcx,rbx
  40d740:	mov    dl,BYTE PTR [rcx]
  40d742:	test   dl,dl
  40d744:	je     40d75e <__swc_fn_4fa09e82_000151_2eb804cc+0xde>
  40d746:	cs nop WORD PTR [rax+rax*1+0x0]
  40d750:	add    rcx,0x1
  40d754:	add    rax,0x1
  40d758:	mov    dl,BYTE PTR [rcx]
  40d75a:	test   dl,dl
  40d75c:	jne    40d750 <__swc_fn_4fa09e82_000151_2eb804cc+0xd0>
  40d75e:	mov    QWORD PTR [rbx+0xa8],rbx
  40d765:	mov    QWORD PTR [rbx+0xb0],rax
  40d76c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d774:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d77c:	lea    rcx,[rbx+0xb8]
  40d783:	call   410430 <__swc_fn_4fa09e82_000122_2648f149>
  40d788:	add    rsp,0xe0
  40d78f:	pop    rbx
  40d790:	ret
	...

000000000040d7a0 <__swc_fn_4fa09e82_000154_86f1d437>:
  40d7a0:	vxorps xmm0,xmm0,xmm0
  40d7a4:	vmovups XMMWORD PTR [rcx],xmm0
  40d7a8:	mov    QWORD PTR [rcx+0x10],0x0
  40d7b0:	ret
	...

000000000040d7c0 <__swc_fn_4fa09e82_000157_86f1d437>:
  40d7c0:	vxorps xmm0,xmm0,xmm0
  40d7c4:	vmovups XMMWORD PTR [rcx],xmm0
  40d7c8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d7cd:	vxorps xmm0,xmm0,xmm0
  40d7d1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d7d6:	vmovups xmm0,XMMWORD PTR [rip+0x5f2a]        # 413708 <__swc_rdata_base_4fa09e82+0x5f8>
  40d7de:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d7e3:	vxorps xmm0,xmm0,xmm0
  40d7e7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d7ec:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d7f1:	mov    QWORD PTR [rcx+0x60],0x0
  40d7f9:	ret
  40d7fa:	add    BYTE PTR [rax],al
  40d7fc:	add    BYTE PTR [rax],al
	...

000000000040d800 <__swc_fn_4fa09e82_000160_86f1d437>:
  40d800:	vxorps xmm0,xmm0,xmm0
  40d804:	vmovups XMMWORD PTR [rcx],xmm0
  40d808:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d80d:	vxorps xmm0,xmm0,xmm0
  40d811:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d816:	vmovups xmm0,XMMWORD PTR [rip+0x6012]        # 413830 <__swc_rdata_base_4fa09e82+0x720>
  40d81e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d823:	vxorps xmm0,xmm0,xmm0
  40d827:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d82c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d831:	vxorps xmm0,xmm0,xmm0
  40d835:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d83a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d83f:	vxorps xmm0,xmm0,xmm0
  40d843:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d84b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d853:	vxorps xmm0,xmm0,xmm0
  40d857:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d85f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d867:	vxorps xmm0,xmm0,xmm0
  40d86b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d873:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d87b:	mov    QWORD PTR [rcx+0xe0],0x0
  40d886:	ret
	...

000000000040d890 <__swc_fn_4fa09e82_000163_13ead2ff>:
  40d890:	push   rbx
  40d891:	mov    rbx,rcx
  40d894:	call   411e70 <__swc_fn_4fa09e82_000164_e36363a8>
  40d899:	mov    rax,QWORD PTR [rbx+0x10]
  40d89d:	test   rax,rax
  40d8a0:	je     40d8b1 <__swc_fn_4fa09e82_000163_13ead2ff+0x21>
  40d8a2:	mov    rcx,rbx
  40d8a5:	mov    rdx,rax
  40d8a8:	mov    r8,QWORD PTR [rbx+0x18]
  40d8ac:	call   40a310 <__swc_fn_4fa09e82_000162_47b270e1>
  40d8b1:	vxorps xmm0,xmm0,xmm0
  40d8b5:	vmovups XMMWORD PTR [rbx],xmm0
  40d8b9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d8be:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d8c3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d8c8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d8cd:	mov    QWORD PTR [rbx+0x50],0x0
  40d8d5:	pop    rbx
  40d8d6:	ret
	...

000000000040d8e0 <__swc_fn_4fa09e82_000166_72795826>:
  40d8e0:	sub    rsp,0x10
  40d8e4:	mov    eax,r8d
  40d8e7:	mov    r8d,r9d
  40d8ea:	test   r9d,r9d
  40d8ed:	jne    40d906 <__swc_fn_4fa09e82_000166_72795826+0x26>
  40d8ef:	vmovups xmm0,XMMWORD PTR [rip+0x5ff1]        # 4138e8 <__swc_rdata_base_4fa09e82+0x7d8>
  40d8f7:	vmovups XMMWORD PTR [r10],xmm0
  40d8fc:	mov    eax,0x1
  40d901:	add    rsp,0x10
  40d905:	ret
  40d906:	mov    r9,r8
  40d909:	cmp    r8,rax
  40d90c:	jb     40d913 <__swc_fn_4fa09e82_000166_72795826+0x33>
  40d90e:	cmp    r9,rdx
  40d911:	jb     40d91a <__swc_fn_4fa09e82_000166_72795826+0x3a>
  40d913:	xor    eax,eax
  40d915:	add    rsp,0x10
  40d919:	ret
  40d91a:	xor    eax,eax
  40d91c:	lea    r8,[r9+rax*1]
  40d920:	cmp    r8,rdx
  40d923:	jae    40d953 <__swc_fn_4fa09e82_000166_72795826+0x73>
  40d925:	cs nop WORD PTR [rax+rax*1+0x0]
  40d92f:	cs nop WORD PTR [rax+rax*1+0x0]
  40d939:	nop    DWORD PTR [rax+0x0]
  40d940:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d945:	je     40d953 <__swc_fn_4fa09e82_000166_72795826+0x73>
  40d947:	inc    rax
  40d94a:	lea    r8,[r9+rax*1]
  40d94e:	cmp    r8,rdx
  40d951:	jb     40d940 <__swc_fn_4fa09e82_000166_72795826+0x60>
  40d953:	cmp    r8,rdx
  40d956:	jne    40d95f <__swc_fn_4fa09e82_000166_72795826+0x7f>
  40d958:	xor    eax,eax
  40d95a:	add    rsp,0x10
  40d95e:	ret
  40d95f:	add    rcx,r9
  40d962:	mov    QWORD PTR [rsp],rcx
  40d966:	mov    QWORD PTR [rsp+0x8],rax
  40d96b:	vmovups xmm0,XMMWORD PTR [rsp]
  40d970:	vmovups XMMWORD PTR [r10],xmm0
  40d975:	mov    eax,0x1
  40d97a:	add    rsp,0x10
  40d97e:	ret
	...

000000000040d980 <__swc_fn_4fa09e82_000169_bcc835b8>:
  40d980:	push   rbp
  40d981:	push   rbx
  40d982:	push   rsi
  40d983:	push   rdi
  40d984:	push   r12
  40d986:	push   r13
  40d988:	push   r14
  40d98a:	push   r15
  40d98c:	sub    rsp,0x10
  40d990:	mov    rbp,rsp
  40d993:	vmovups XMMWORD PTR [rsp],xmm6
  40d998:	sub    rsp,0x50
  40d99c:	mov    rbx,rsp
  40d99f:	mov    rsi,r8
  40d9a2:	mov    QWORD PTR [rsp+0x30],r8
  40d9a7:	mov    rdi,rcx
  40d9aa:	mov    QWORD PTR [rsp+0x38],rcx
  40d9af:	mov    r12,rdx
  40d9b2:	xor    r13b,r13b
  40d9b5:	mov    r14,QWORD PTR [rdi+0x8]
  40d9b9:	mov    QWORD PTR [rsp+0x40],r14
  40d9be:	xor    r15d,r15d
  40d9c1:	test   r14,r14
  40d9c4:	jbe    40dc1e <__swc_fn_4fa09e82_000169_bcc835b8+0x29e>
  40d9ca:	mov    r14,QWORD PTR [rdi]
  40d9cd:	mov    rax,QWORD PTR [rsp+0x40]
  40d9d2:	mov    QWORD PTR [rsp+0x48],r14
  40d9d7:	vmovups xmm6,XMMWORD PTR [rip+0x5b29]        # 413508 <__swc_rdata_base_4fa09e82+0x3f8>
  40d9df:	nop
  40d9e0:	cmp    QWORD PTR [r14+r15*8],0x0
  40d9e5:	jne    40d9ef <__swc_fn_4fa09e82_000169_bcc835b8+0x6f>
  40d9e7:	mov    r14,rax
  40d9ea:	jmp    40dbfe <__swc_fn_4fa09e82_000169_bcc835b8+0x27e>
  40d9ef:	mov    rcx,QWORD PTR [rdi]
  40d9f2:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d9f6:	mov    rdi,rbx
  40d9f9:	mov    rcx,rdi
  40d9fc:	sub    rsp,0x8
  40da00:	mov    r14,rax
  40da03:	call   40a390 <__swc_fn_4fa09e82_000168_cc119975>
  40da08:	add    rsp,0x8
  40da0c:	mov    al,BYTE PTR [rbx]
  40da0e:	test   al,al
  40da10:	je     40dbfe <__swc_fn_4fa09e82_000169_bcc835b8+0x27e>
  40da16:	mov    al,BYTE PTR [rbx+0x1]
  40da19:	test   al,al
  40da1b:	jne    40da26 <__swc_fn_4fa09e82_000169_bcc835b8+0xa6>
  40da1d:	test   sil,sil
  40da20:	je     40dbfe <__swc_fn_4fa09e82_000169_bcc835b8+0x27e>
  40da26:	test   r13b,r13b
  40da29:	jne    40dae7 <__swc_fn_4fa09e82_000169_bcc835b8+0x167>
  40da2f:	test   r12,r12
  40da32:	je     40dae7 <__swc_fn_4fa09e82_000169_bcc835b8+0x167>
  40da38:	mov    al,BYTE PTR [rbx+0x1]
  40da3b:	test   al,al
  40da3d:	je     40dbfe <__swc_fn_4fa09e82_000169_bcc835b8+0x27e>
  40da43:	mov    eax,DWORD PTR [rbx+0x28]
  40da46:	cmp    DWORD PTR [r12+0x20],eax
  40da4b:	jne    40dbfe <__swc_fn_4fa09e82_000169_bcc835b8+0x27e>
  40da51:	mov    rax,QWORD PTR [r12]
  40da55:	mov    rcx,QWORD PTR [r12+0x8]
  40da5a:	cmp    QWORD PTR [rbx+0x20],rcx
  40da5e:	jne    40dbfe <__swc_fn_4fa09e82_000169_bcc835b8+0x27e>
  40da64:	mov    cl,0x1
  40da66:	test   rax,rax
  40da69:	je     40dad2 <__swc_fn_4fa09e82_000169_bcc835b8+0x152>
  40da6f:	mov    rdx,QWORD PTR [rbx+0x20]
  40da73:	xor    r8d,r8d
  40da76:	test   rdx,rdx
  40da79:	jbe    40dad2 <__swc_fn_4fa09e82_000169_bcc835b8+0x152>
  40da7b:	mov    r9,QWORD PTR [rbx+0x18]
  40da7f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40da84:	cs nop WORD PTR [rax+rax*1+0x0]
  40da8e:	xchg   ax,ax
  40da90:	mov    r10b,BYTE PTR [rax+r8*1]
  40da94:	cmp    BYTE PTR [r9+r8*1],r10b
  40da98:	je     40dac9 <__swc_fn_4fa09e82_000169_bcc835b8+0x149>
  40da9a:	vmovq  r10,xmm0
  40da9f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40daa4:	jne    40daad <__swc_fn_4fa09e82_000169_bcc835b8+0x12d>
  40daa6:	cmp    BYTE PTR [rax+r8*1],0x2f
  40daab:	je     40dac9 <__swc_fn_4fa09e82_000169_bcc835b8+0x149>
  40daad:	vmovq  r10,xmm0
  40dab2:	cmp    BYTE PTR [r10+r8*1],0x2f
  40dab7:	jne    40dac0 <__swc_fn_4fa09e82_000169_bcc835b8+0x140>
  40dab9:	cmp    BYTE PTR [rax+r8*1],0x5c
  40dabe:	je     40dac9 <__swc_fn_4fa09e82_000169_bcc835b8+0x149>
  40dac0:	xor    eax,eax
  40dac2:	movzx  eax,al
  40dac5:	mov    cl,al
  40dac7:	jmp    40dad2 <__swc_fn_4fa09e82_000169_bcc835b8+0x152>
  40dac9:	add    r8,0x1
  40dacd:	cmp    r8,rdx
  40dad0:	jb     40da90 <__swc_fn_4fa09e82_000169_bcc835b8+0x110>
  40dad2:	test   cl,cl
  40dad4:	je     40dbfe <__swc_fn_4fa09e82_000169_bcc835b8+0x27e>
  40dada:	mov    eax,0x1
  40dadf:	mov    r13b,al
  40dae2:	jmp    40dbfe <__swc_fn_4fa09e82_000169_bcc835b8+0x27e>
  40dae7:	mov    r13b,0x1
  40daea:	sub    rsp,0x20
  40daee:	mov    rax,rsp
  40daf1:	lea    rcx,[rdi+0x8]
  40daf5:	mov    QWORD PTR [rax],rcx
  40daf8:	lea    rsi,[rip+0x5631]        # 413130 <__swc_rdata_base_4fa09e82+0x20>
  40daff:	mov    QWORD PTR [rax+0x8],rsi
  40db03:	mov    QWORD PTR [rax+0x10],rsp
  40db07:	mov    QWORD PTR [rax+0x18],0x1
  40db0f:	lea    rcx,[rsp+0x10]
  40db14:	sub    rsp,0x8
  40db18:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40db1d:	add    rsp,0x8
  40db21:	add    rsp,0x20
  40db25:	mov    al,BYTE PTR [rbx+0x1]
  40db28:	test   al,al
  40db2a:	je     40dbc7 <__swc_fn_4fa09e82_000169_bcc835b8+0x247>
  40db30:	lea    rax,[rip+0x5e51]        # 413988 <__swc_rdata_base_4fa09e82+0x878>
  40db37:	sub    rsp,0x20
  40db3b:	mov    rcx,rsp
  40db3e:	mov    QWORD PTR [rcx],rax
  40db41:	mov    QWORD PTR [rcx+0x8],rsi
  40db45:	mov    QWORD PTR [rcx+0x10],rsp
  40db49:	mov    QWORD PTR [rcx+0x18],0x1
  40db51:	lea    rcx,[rsp+0x10]
  40db56:	sub    rsp,0x8
  40db5a:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40db5f:	add    rsp,0x8
  40db63:	add    rsp,0x20
  40db67:	mov    eax,DWORD PTR [rbx+0x28]
  40db6a:	sub    rsp,0x60
  40db6e:	mov    rcx,rsp
  40db71:	lea    rdx,[rdi+0x18]
  40db75:	mov    QWORD PTR [rcx+0x18],rdx
  40db79:	mov    QWORD PTR [rcx+0x20],rsi
  40db7d:	vmovups XMMWORD PTR [rcx],xmm6
  40db81:	mov    QWORD PTR [rcx+0x28],rsp
  40db85:	mov    QWORD PTR [rcx+0x30],rsi
  40db89:	mov    DWORD PTR [rcx+0x10],eax
  40db8c:	lea    rax,[rsp+0x10]
  40db91:	mov    QWORD PTR [rcx+0x38],rax
  40db95:	lea    rax,[rip+0x5904]        # 4134a0 <__swc_rdata_base_4fa09e82+0x390>
  40db9c:	mov    QWORD PTR [rcx+0x40],rax
  40dba0:	lea    rax,[rsp+0x18]
  40dba5:	mov    QWORD PTR [rcx+0x48],rax
  40dba9:	mov    QWORD PTR [rcx+0x50],0x3
  40dbb1:	lea    rcx,[rsp+0x48]
  40dbb6:	sub    rsp,0x8
  40dbba:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40dbbf:	add    rsp,0x8
  40dbc3:	add    rsp,0x60
  40dbc7:	lea    rax,[rip+0x5552]        # 413120 <__swc_rdata_base_4fa09e82+0x10>
  40dbce:	sub    rsp,0x20
  40dbd2:	mov    rcx,rsp
  40dbd5:	mov    QWORD PTR [rcx],rax
  40dbd8:	mov    QWORD PTR [rcx+0x8],rsi
  40dbdc:	mov    QWORD PTR [rcx+0x10],rsp
  40dbe0:	mov    QWORD PTR [rcx+0x18],0x1
  40dbe8:	lea    rcx,[rsp+0x10]
  40dbed:	sub    rsp,0x8
  40dbf1:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40dbf6:	add    rsp,0x8
  40dbfa:	add    rsp,0x20
  40dbfe:	add    r15,0x1
  40dc02:	cmp    r15,r14
  40dc05:	jae    40dc1e <__swc_fn_4fa09e82_000169_bcc835b8+0x29e>
  40dc07:	mov    rsi,QWORD PTR [rsp+0x30]
  40dc0c:	mov    rdi,QWORD PTR [rsp+0x38]
  40dc11:	mov    rax,r14
  40dc14:	mov    r14,QWORD PTR [rsp+0x48]
  40dc19:	jmp    40d9e0 <__swc_fn_4fa09e82_000169_bcc835b8+0x60>
  40dc1e:	add    rsp,0x50
  40dc22:	vmovups xmm6,XMMWORD PTR [rsp]
  40dc27:	add    rsp,0x10
  40dc2b:	pop    r15
  40dc2d:	pop    r14
  40dc2f:	pop    r13
  40dc31:	pop    r12
  40dc33:	pop    rdi
  40dc34:	pop    rsi
  40dc35:	pop    rbx
  40dc36:	pop    rbp
  40dc37:	ret
	...

000000000040dc40 <__swc_fn_4fa09e82_000172_646fdf20>:
  40dc40:	sub    rsp,0x8
  40dc44:	call   4106b0 <__swc_fn_4fa09e82_000131_4bbe3f14>
  40dc49:	add    rsp,0x8
  40dc4d:	ret
	...

000000000040dc50 <__swc_fn_4fa09e82_000175_1e0ea8cf>:
  40dc50:	push   rsi
  40dc51:	sub    rsp,0x30
  40dc55:	lea    rsi,[rip+0x1913c]        # 426d98 <__swc_bss_base_4fa09e82+0x2d58>
  40dc5c:	mov    rax,QWORD PTR [rsi]
  40dc5f:	test   rax,rax
  40dc62:	je     40dc6a <__swc_fn_4fa09e82_000175_1e0ea8cf+0x1a>
  40dc64:	add    rsp,0x30
  40dc68:	pop    rsi
  40dc69:	ret
  40dc6a:	mov    ecx,0x2
  40dc6f:	mov    edx,0x8020
  40dc74:	call   40fd50 <__swc_fn_4fa09e82_000113_6814119b>
  40dc79:	test   rax,rax
  40dc7c:	jne    40dc8d <__swc_fn_4fa09e82_000175_1e0ea8cf+0x3d>
  40dc7e:	mov    QWORD PTR [rsp+0x18],rax
  40dc83:	call   40d0e0 <__swc_fn_4fa09e82_000124_be2e2f68>
  40dc88:	mov    rax,QWORD PTR [rsp+0x18]
  40dc8d:	mov    rcx,rax
  40dc90:	xchg   QWORD PTR [rsi],rcx
  40dc93:	add    rsp,0x30
  40dc97:	pop    rsi
  40dc98:	ret
  40dc99:	add    BYTE PTR [rax],al
  40dc9b:	add    BYTE PTR [rax],al
  40dc9d:	add    BYTE PTR [rax],al
	...

000000000040dca0 <__swc_fn_4fa09e82_000178_4de704de>:
  40dca0:	push   rsi
  40dca1:	test   r8,r8
  40dca4:	jne    40dca8 <__swc_fn_4fa09e82_000178_4de704de+0x8>
  40dca6:	pop    rsi
  40dca7:	ret
  40dca8:	lea    rax,[rcx+0x18]
  40dcac:	mov    r10,QWORD PTR [rax]
  40dcaf:	lea    r11,[r10+0x1]
  40dcb3:	mov    QWORD PTR [rax],r11
  40dcb6:	mov    r11,rdx
  40dcb9:	not    rdx
  40dcbc:	lea    rsi,[r8-0x1]
  40dcc0:	cmp    rsi,rdx
  40dcc3:	ja     40dce3 <__swc_fn_4fa09e82_000178_4de704de+0x43>
  40dcc5:	lea    rdx,[r11+r8*1]
  40dcc9:	dec    rdx
  40dccc:	shr    rdx,0x6
  40dcd0:	mov    r8,r11
  40dcd3:	shr    r8,0x6
  40dcd7:	mov    rsi,rdx
  40dcda:	sub    rsi,r8
  40dcdd:	cmp    rsi,0x8
  40dce1:	jb     40dcf9 <__swc_fn_4fa09e82_000178_4de704de+0x59>
  40dce3:	lea    rcx,[rcx+0x10]
  40dce7:	mov    rdx,QWORD PTR [rcx]
  40dcea:	add    rdx,r9
  40dced:	mov    QWORD PTR [rcx],rdx
  40dcf0:	lea    rcx,[r10+0x2]
  40dcf4:	mov    QWORD PTR [rax],rcx
  40dcf7:	pop    rsi
  40dcf8:	ret
  40dcf9:	shr    r11,0x6
  40dcfd:	nop    DWORD PTR [rax]
  40dd00:	cmp    r11,rdx
  40dd03:	ja     40dd43 <__swc_fn_4fa09e82_000178_4de704de+0xa3>
  40dd05:	jmp    40dd16 <__swc_fn_4fa09e82_000178_4de704de+0x76>
  40dd07:	nop    WORD PTR [rax+rax*1+0x0]
  40dd10:	add    r11,0x1
  40dd14:	jmp    40dd00 <__swc_fn_4fa09e82_000178_4de704de+0x60>
  40dd16:	mov    r8,r11
  40dd19:	shr    r8,0xc
  40dd1d:	mov    rsi,r11
  40dd20:	xor    rsi,r8
  40dd23:	mov    r8,r11
  40dd26:	shr    r8,0x18
  40dd2a:	xor    rsi,r8
  40dd2d:	and    esi,0xfff
  40dd33:	lea    r8,[rcx+rsi*8+0x20]
  40dd38:	mov    rsi,QWORD PTR [r8]
  40dd3b:	add    rsi,r9
  40dd3e:	mov    QWORD PTR [r8],rsi
  40dd41:	jmp    40dd10 <__swc_fn_4fa09e82_000178_4de704de+0x70>
  40dd43:	lea    rcx,[r10+0x2]
  40dd47:	mov    QWORD PTR [rax],rcx
  40dd4a:	pop    rsi
  40dd4b:	ret
	...

000000000040dd60 <__swc_fn_4fa09e82_000002_1ca87929>:
  40dd60:	push   rdi
  40dd61:	push   rsi
  40dd62:	sub    rsp,0xb8
  40dd69:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40dd6f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40dd75:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40dd7b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40dd81:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40dd87:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40dd8d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40dd93:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40dd9c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40dda5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ddae:	vxorps xmm0,xmm0,xmm0
  40ddb2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ddb8:	mov    edi,0x1
  40ddbd:	lea    rsi,[rsp+0x8]
  40ddc2:	xor    eax,eax
  40ddc4:	call   407110 <clock_gettime@plt>
  40ddc9:	vxorpd xmm0,xmm0,xmm0
  40ddcd:	mov    rax,QWORD PTR [rsp+0x8]
  40ddd2:	vcvtsi2sd xmm0,xmm0,rax
  40ddd7:	vxorpd xmm1,xmm1,xmm1
  40dddb:	mov    rax,QWORD PTR [rsp+0x10]
  40dde0:	vcvtsi2sd xmm1,xmm1,rax
  40dde5:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x5323]        # 413110 <__swc_rdata_base_4fa09e82>
  40dded:	vaddsd xmm0,xmm0,xmm1
  40ddf1:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ddf7:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ddfd:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40de03:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40de09:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40de0f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40de15:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40de1b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40de24:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40de2d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40de36:	add    rsp,0xb8
  40de3d:	pop    rsi
  40de3e:	pop    rdi
  40de3f:	ret

000000000040de40 <__swc_fn_4fa09e82_000005_9ee35b18>:
  40de40:	vxorps xmm0,xmm0,xmm0
  40de44:	vmovups XMMWORD PTR [rcx],xmm0
  40de48:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40de4d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40de52:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40de57:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40de5c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40de61:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40de66:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40de6b:	ret
  40de6c:	add    BYTE PTR [rax],al
	...

000000000040de70 <__swc_fn_4fa09e82_000008_f7acedb0>:
  40de70:	push   rsi
  40de71:	mov    rsi,rdx
  40de74:	test   rdx,rdx
  40de77:	jne    40de80 <__swc_fn_4fa09e82_000008_f7acedb0+0x10>
  40de79:	mov    eax,0x1
  40de7e:	pop    rsi
  40de7f:	ret
  40de80:	mov    rdx,rsi
  40de83:	call   4096c0 <__swc_fn_4fa09e82_000117_36905703>
  40de88:	test   al,al
  40de8a:	jne    40de90 <__swc_fn_4fa09e82_000008_f7acedb0+0x20>
  40de8c:	xor    eax,eax
  40de8e:	pop    rsi
  40de8f:	ret
  40de90:	lea    rcx,[rip+0x161e1]        # 424078 <__swc_bss_base_4fa09e82+0x38>
  40de97:	mov    rdx,QWORD PTR [rip+0x161da]        # 424078 <__swc_bss_base_4fa09e82+0x38>
  40de9e:	xchg   ax,ax
  40dea0:	lea    r8,[rdx+rsi*1]
  40dea4:	mov    rax,rdx
  40dea7:	lock cmpxchg QWORD PTR [rcx],r8
  40deac:	cmp    rax,rdx
  40deaf:	je     40deb6 <__swc_fn_4fa09e82_000008_f7acedb0+0x46>
  40deb1:	mov    rdx,rax
  40deb4:	jmp    40dea0 <__swc_fn_4fa09e82_000008_f7acedb0+0x30>
  40deb6:	lea    rcx,[rip+0x161c3]        # 424080 <__swc_bss_base_4fa09e82+0x40>
  40debd:	mov    rdx,QWORD PTR [rip+0x161bc]        # 424080 <__swc_bss_base_4fa09e82+0x40>
  40dec4:	cs nop WORD PTR [rax+rax*1+0x0]
  40dece:	xchg   ax,ax
  40ded0:	lea    r8,[rdx+0x1]
  40ded4:	mov    rax,rdx
  40ded7:	lock cmpxchg QWORD PTR [rcx],r8
  40dedc:	cmp    rax,rdx
  40dedf:	je     40dee6 <__swc_fn_4fa09e82_000008_f7acedb0+0x76>
  40dee1:	mov    rdx,rax
  40dee4:	jmp    40ded0 <__swc_fn_4fa09e82_000008_f7acedb0+0x60>
  40dee6:	mov    eax,0x1
  40deeb:	pop    rsi
  40deec:	ret
  40deed:	add    BYTE PTR [rax],al
	...

000000000040def0 <__swc_fn_4fa09e82_000011_24a20786>:
  40def0:	push   rbx
  40def1:	push   rsi
  40def2:	push   rdi
  40def3:	push   r12
  40def5:	sub    rsp,0x18
  40def9:	mov    rbx,rcx
  40defc:	mov    rsi,rcx
  40deff:	and    rsi,0xffffffffffc00000
  40df06:	movzx  eax,BYTE PTR [rbx+0x3a]
  40df0a:	mov    ecx,DWORD PTR [rsi+0x28]
  40df0d:	shrx   eax,eax,ecx
  40df12:	lea    rdi,[rsp+0x8]
  40df17:	mov    DWORD PTR [rsp+0x8],eax
  40df1b:	mov    rcx,rsi
  40df1e:	mov    rax,rdi
  40df21:	mov    edx,DWORD PTR [rax]
  40df23:	call   40b090 <__swc_fn_4fa09e82_000016_9dea5065>
  40df28:	mov    r12,rax
  40df2b:	mov    rcx,rsi
  40df2e:	mov    edx,DWORD PTR [rdi]
  40df30:	call   40e020 <__swc_fn_4fa09e82_000017_9afb7cfb>
  40df35:	mov    rcx,r12
  40df38:	mov    edx,DWORD PTR [rbx+0x3c]
  40df3b:	add    rcx,rdx
  40df3e:	cmp    rcx,rax
  40df41:	jb     40df4f <__swc_fn_4fa09e82_000011_24a20786+0x5f>
  40df43:	xor    eax,eax
  40df45:	add    rsp,0x18
  40df49:	pop    r12
  40df4b:	pop    rdi
  40df4c:	pop    rsi
  40df4d:	pop    rbx
  40df4e:	ret
  40df4f:	mov    rdx,QWORD PTR [rbx+0x20]
  40df53:	mov    r8d,DWORD PTR [rbx+0x2c]
  40df57:	add    rdx,r8
  40df5a:	lea    rsi,[rdx+0xffff]
  40df61:	and    rsi,0xffffffffffff0000
  40df68:	cmp    rax,rsi
  40df6b:	cmovbe rsi,rax
  40df6f:	mov    rax,rsi
  40df72:	sub    rax,rcx
  40df75:	mov    rdx,rax
  40df78:	call   40de70 <__swc_fn_4fa09e82_000008_f7acedb0>
  40df7d:	test   al,al
  40df7f:	jne    40df8d <__swc_fn_4fa09e82_000011_24a20786+0x9d>
  40df81:	xor    eax,eax
  40df83:	add    rsp,0x18
  40df87:	pop    r12
  40df89:	pop    rdi
  40df8a:	pop    rsi
  40df8b:	pop    rbx
  40df8c:	ret
  40df8d:	sub    rsi,r12
  40df90:	mov    DWORD PTR [rbx+0x3c],esi
  40df93:	mov    ecx,DWORD PTR [rbx+0x2c]
  40df96:	mov    rax,rsi
  40df99:	xor    edx,edx
  40df9b:	div    rcx
  40df9e:	imul   rax,rcx
  40dfa2:	add    r12,rax
  40dfa5:	mov    QWORD PTR [rbx+0x18],r12
  40dfa9:	mov    eax,0x1
  40dfae:	add    rsp,0x18
  40dfb2:	pop    r12
  40dfb4:	pop    rdi
  40dfb5:	pop    rsi
  40dfb6:	pop    rbx
  40dfb7:	ret
	...

000000000040dfc0 <__swc_fn_4fa09e82_000014_e4b0ddfc>:
  40dfc0:	sub    rsp,0x8
  40dfc4:	mov    rdx,rcx
  40dfc7:	lea    r9,[rcx+0x60]
  40dfcb:	mov    rax,QWORD PTR [r9]
  40dfce:	test   rax,rax
  40dfd1:	jne    40dfd8 <__swc_fn_4fa09e82_000014_e4b0ddfc+0x18>
  40dfd3:	add    rsp,0x8
  40dfd7:	ret
  40dfd8:	mov    rcx,rdx
  40dfdb:	call   407630 <__swc_fn_4fa09e82_000012_c3647f66>
  40dfe0:	xor    eax,eax
  40dfe2:	xchg   QWORD PTR [r9],rax
  40dfe5:	mov    r8,rax
  40dfe8:	mov    rcx,rdx
  40dfeb:	call   40b080 <__swc_fn_4fa09e82_000013_861b8b62>
  40dff0:	xor    eax,eax
  40dff2:	test   r8,r8
  40dff5:	je     40e016 <__swc_fn_4fa09e82_000014_e4b0ddfc+0x56>
  40dff7:	nop    WORD PTR [rax+rax*1+0x0]
  40e000:	mov    rcx,QWORD PTR [r8]
  40e003:	mov    r9,QWORD PTR [rdx]
  40e006:	mov    QWORD PTR [r8],r9
  40e009:	mov    QWORD PTR [rdx],r8
  40e00c:	mov    r8,rcx
  40e00f:	inc    eax
  40e011:	test   rcx,rcx
  40e014:	jne    40e000 <__swc_fn_4fa09e82_000014_e4b0ddfc+0x40>
  40e016:	sub    DWORD PTR [rdx+0x28],eax
  40e019:	add    rsp,0x8
  40e01d:	ret
	...

000000000040e020 <__swc_fn_4fa09e82_000017_9afb7cfb>:
  40e020:	lea    eax,[rdx+0x1]
  40e023:	mov    edx,DWORD PTR [rcx+0x28]
  40e026:	shlx   eax,eax,edx
  40e02b:	shl    rax,0x10
  40e02f:	add    rax,rcx
  40e032:	ret
	...

000000000040e040 <__swc_fn_4fa09e82_000020_adca76cf>:
  40e040:	push   rbx
  40e041:	push   rsi
  40e042:	push   rdi
  40e043:	push   r12
  40e045:	push   r13
  40e047:	push   r14
  40e049:	push   r15
  40e04b:	sub    rsp,0x30
  40e04f:	mov    rbx,rcx
  40e052:	lea    rsi,[rcx+0x48]
  40e056:	mov    QWORD PTR [rsp+0x18],rsi
  40e05b:	mov    rax,QWORD PTR [rsi]
  40e05e:	mov    rdi,rax
  40e061:	lea    r12,[rsp+0x8]
  40e066:	lea    r13,[rcx+0x40]
  40e06a:	nop    WORD PTR [rax+rax*1+0x0]
  40e070:	test   rdi,rdi
  40e073:	je     40e1b3 <__swc_fn_4fa09e82_000020_adca76cf+0x173>
  40e079:	xor    eax,eax
  40e07b:	tzcnt  rax,rdi
  40e080:	mov    DWORD PTR [rsp+0x8],eax
  40e084:	mov    r14d,0x1
  40e08a:	mov    ecx,eax
  40e08c:	shl    r14,cl
  40e08f:	andn   rdi,r14,rdi
  40e094:	mov    rcx,QWORD PTR [r13+0x0]
  40e098:	test   rcx,r14
  40e09b:	jne    40e070 <__swc_fn_4fa09e82_000020_adca76cf+0x30>
  40e09d:	mov    rdx,rcx
  40e0a0:	or     rdx,r14
  40e0a3:	mov    rax,rcx
  40e0a6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  40e0ac:	cmp    rax,rcx
  40e0af:	je     40e0b9 <__swc_fn_4fa09e82_000020_adca76cf+0x79>
  40e0b1:	mov    rax,QWORD PTR [rsi]
  40e0b4:	mov    rdi,rax
  40e0b7:	jmp    40e070 <__swc_fn_4fa09e82_000020_adca76cf+0x30>
  40e0b9:	mov    rcx,rbx
  40e0bc:	mov    rdx,r14
  40e0bf:	call   40b1f0 <__swc_fn_4fa09e82_000022_fd2b165c>
  40e0c4:	test   al,al
  40e0c6:	je     40e19e <__swc_fn_4fa09e82_000020_adca76cf+0x15e>
  40e0cc:	mov    eax,DWORD PTR [r12]
  40e0d0:	shl    rax,0x4
  40e0d4:	lea    r15,[rbx+rax*8+0x80]
  40e0dc:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  40e0e4:	lea    rcx,[rip+0x15f9d]        # 424088 <__swc_bss_base_4fa09e82+0x48>
  40e0eb:	mov    rdx,QWORD PTR [rip+0x15f96]        # 424088 <__swc_bss_base_4fa09e82+0x48>
  40e0f2:	cs nop WORD PTR [rax+rax*1+0x0]
  40e0fc:	nop    DWORD PTR [rax+0x0]
  40e100:	mov    r8,rdx
  40e103:	sub    r8,rsi
  40e106:	mov    rax,rdx
  40e109:	lock cmpxchg QWORD PTR [rcx],r8
  40e10e:	cmp    rax,rdx
  40e111:	je     40e118 <__swc_fn_4fa09e82_000020_adca76cf+0xd8>
  40e113:	mov    rdx,rax
  40e116:	jmp    40e100 <__swc_fn_4fa09e82_000020_adca76cf+0xc0>
  40e118:	mov    rcx,rbx
  40e11b:	mov    rax,r12
  40e11e:	mov    edx,DWORD PTR [rax]
  40e120:	call   40b090 <__swc_fn_4fa09e82_000016_9dea5065>
  40e125:	test   rsi,rsi
  40e128:	je     40e196 <__swc_fn_4fa09e82_000020_adca76cf+0x156>
  40e12e:	mov    rcx,rax
  40e131:	mov    rdx,rsi
  40e134:	call   40ceb0 <__swc_fn_4fa09e82_000118_e9fc0224>
  40e139:	lea    rcx,[rip+0x15f38]        # 424078 <__swc_bss_base_4fa09e82+0x38>
  40e140:	mov    rdx,QWORD PTR [rip+0x15f31]        # 424078 <__swc_bss_base_4fa09e82+0x38>
  40e147:	nop    WORD PTR [rax+rax*1+0x0]
  40e150:	mov    r8,rdx
  40e153:	sub    r8,rsi
  40e156:	mov    rax,rdx
  40e159:	lock cmpxchg QWORD PTR [rcx],r8
  40e15e:	cmp    rax,rdx
  40e161:	je     40e168 <__swc_fn_4fa09e82_000020_adca76cf+0x128>
  40e163:	mov    rdx,rax
  40e166:	jmp    40e150 <__swc_fn_4fa09e82_000020_adca76cf+0x110>
  40e168:	lea    rcx,[rip+0x15f21]        # 424090 <__swc_bss_base_4fa09e82+0x50>
  40e16f:	mov    rdx,QWORD PTR [rip+0x15f1a]        # 424090 <__swc_bss_base_4fa09e82+0x50>
  40e176:	cs nop WORD PTR [rax+rax*1+0x0]
  40e180:	lea    r8,[rdx+0x1]
  40e184:	mov    rax,rdx
  40e187:	lock cmpxchg QWORD PTR [rcx],r8
  40e18c:	cmp    rax,rdx
  40e18f:	je     40e196 <__swc_fn_4fa09e82_000020_adca76cf+0x156>
  40e191:	mov    rdx,rax
  40e194:	jmp    40e180 <__swc_fn_4fa09e82_000020_adca76cf+0x140>
  40e196:	mov    DWORD PTR [r15+0x3c],0x0
  40e19e:	mov    rcx,rbx
  40e1a1:	mov    rdx,r14
  40e1a4:	call   40e1d0 <__swc_fn_4fa09e82_000023_c8f5f27c>
  40e1a9:	mov    rsi,QWORD PTR [rsp+0x18]
  40e1ae:	jmp    40e070 <__swc_fn_4fa09e82_000020_adca76cf+0x30>
  40e1b3:	add    rsp,0x30
  40e1b7:	pop    r15
  40e1b9:	pop    r14
  40e1bb:	pop    r13
  40e1bd:	pop    r12
  40e1bf:	pop    rdi
  40e1c0:	pop    rsi
  40e1c1:	pop    rbx
  40e1c2:	ret
	...

000000000040e1d0 <__swc_fn_4fa09e82_000023_c8f5f27c>:
  40e1d0:	mov    r8,QWORD PTR [rcx+0x40]
  40e1d4:	cs nop WORD PTR [rax+rax*1+0x0]
  40e1de:	xchg   ax,ax
  40e1e0:	mov    rax,rdx
  40e1e3:	not    rax
  40e1e6:	mov    r9,r8
  40e1e9:	and    r9,rax
  40e1ec:	mov    rax,r8
  40e1ef:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  40e1f5:	cmp    rax,r8
  40e1f8:	jne    40e1fb <__swc_fn_4fa09e82_000023_c8f5f27c+0x2b>
  40e1fa:	ret
  40e1fb:	mov    r8,rax
  40e1fe:	jmp    40e1e0 <__swc_fn_4fa09e82_000023_c8f5f27c+0x10>

000000000040e200 <__swc_fn_4fa09e82_000026_aa910677>:
  40e200:	push   rsi
  40e201:	push   rdi
  40e202:	sub    rsp,0x8
  40e206:	mov    rsi,rcx
  40e209:	call   40e040 <__swc_fn_4fa09e82_000020_adca76cf>
  40e20e:	lea    rdi,[rip+0x1600b]        # 424220 <__swc_bss_base_4fa09e82+0x1e0>
  40e215:	mov    rcx,rdi
  40e218:	call   409d20 <__swc_fn_4fa09e82_000141_86bb0f90>
  40e21d:	mov    QWORD PTR [rsi+0x8],0x0
  40e225:	mov    QWORD PTR [rsi+0x18],0x0
  40e22d:	mov    rax,QWORD PTR [rip+0x15ff4]        # 424228 <__swc_bss_base_4fa09e82+0x1e8>
  40e234:	mov    QWORD PTR [rsi+0x10],rax
  40e238:	mov    QWORD PTR [rip+0x15fe9],rsi        # 424228 <__swc_bss_base_4fa09e82+0x1e8>
  40e23f:	mov    rcx,rdi
  40e242:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40e247:	add    rsp,0x8
  40e24b:	pop    rdi
  40e24c:	pop    rsi
  40e24d:	ret
	...

000000000040e250 <__swc_fn_4fa09e82_000029_9798fb47>:
  40e250:	vxorps xmm0,xmm0,xmm0
  40e254:	vmovups XMMWORD PTR [rcx],xmm0
  40e258:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e25d:	mov    QWORD PTR [rcx+0x20],0x0
  40e265:	ret
	...

000000000040e270 <__swc_fn_4fa09e82_000032_9798fb47>:
  40e270:	vxorps xmm0,xmm0,xmm0
  40e274:	vmovups XMMWORD PTR [rcx],xmm0
  40e278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e27d:	mov    QWORD PTR [rcx+0x20],0x0
  40e285:	ret
	...

000000000040e290 <__swc_fn_4fa09e82_000035_9128bcf9>:
  40e290:	push   r12
  40e292:	mov    r12,rdi
  40e295:	test   rdi,rdi
  40e298:	jne    40e29d <__swc_fn_4fa09e82_000035_9128bcf9+0xd>
  40e29a:	pop    r12
  40e29c:	ret
  40e29d:	lea    rax,[rip+0x13d64]        # 422008 <__swc_data_base_4fa09e82+0x8>
  40e2a4:	mov    rax,QWORD PTR [rax]
  40e2a7:	cmp    rax,0xffffffffffffffff
  40e2ab:	je     40e2ba <__swc_fn_4fa09e82_000035_9128bcf9+0x2a>
  40e2ad:	mov    eax,eax
  40e2af:	mov    edi,eax
  40e2b1:	xor    eax,eax
  40e2b3:	call   407000 <pthread_getspecific@plt>
  40e2b8:	jmp    40e2bc <__swc_fn_4fa09e82_000035_9128bcf9+0x2c>
  40e2ba:	xor    eax,eax
  40e2bc:	cmp    rax,r12
  40e2bf:	jne    40e2c8 <__swc_fn_4fa09e82_000035_9128bcf9+0x38>
  40e2c1:	xor    ecx,ecx
  40e2c3:	call   40b3c0 <__swc_fn_4fa09e82_000037_92d9bbff>
  40e2c8:	mov    rdx,QWORD PTR [r12]
  40e2cc:	test   rdx,rdx
  40e2cf:	je     40e2e8 <__swc_fn_4fa09e82_000035_9128bcf9+0x58>
  40e2d1:	mov    rcx,rdx
  40e2d4:	call   40e310 <__swc_fn_4fa09e82_000041_eb6108f2>
  40e2d9:	test   al,al
  40e2db:	je     40e2e8 <__swc_fn_4fa09e82_000035_9128bcf9+0x58>
  40e2dd:	mov    rcx,rdx
  40e2e0:	mov    rdx,r12
  40e2e3:	call   40e400 <__swc_fn_4fa09e82_000047_b30433d0>
  40e2e8:	pop    r12
  40e2ea:	ret
  40e2eb:	add    BYTE PTR [rax],al
  40e2ed:	add    BYTE PTR [rax],al
	...

000000000040e2f0 <__swc_fn_4fa09e82_000038_28d0e998>:
  40e2f0:	push   rsi
  40e2f1:	mov    rsi,rcx
  40e2f4:	call   407ae0 <__swc_fn_4fa09e82_000036_cd1a4e8c>
  40e2f9:	mov    rcx,rax
  40e2fc:	mov    rdx,rsi
  40e2ff:	call   409ba0 <__swc_fn_4fa09e82_000135_ae5891af>
  40e304:	mov    rcx,rsi
  40e307:	call   40b3c0 <__swc_fn_4fa09e82_000037_92d9bbff>
  40e30c:	pop    rsi
  40e30d:	ret
	...

000000000040e310 <__swc_fn_4fa09e82_000041_eb6108f2>:
  40e310:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40e31a:	sete   al
  40e31d:	ret
	...

000000000040e320 <__swc_fn_4fa09e82_000044_d3c2ab54>:
  40e320:	push   rsi
  40e321:	test   rdx,rdx
  40e324:	jne    40e328 <__swc_fn_4fa09e82_000044_d3c2ab54+0x8>
  40e326:	pop    rsi
  40e327:	ret
  40e328:	mov    rax,r8
  40e32b:	mov    ecx,0x1000
  40e330:	test   ecx,ecx
  40e332:	mov    r10d,0x8
  40e338:	cmove  ecx,r10d
  40e33c:	dec    rcx
  40e33f:	mov    r10,0xffffffffffffffff
  40e346:	sub    r10,rcx
  40e349:	cmp    r8,r10
  40e34c:	jbe    40e352 <__swc_fn_4fa09e82_000044_d3c2ab54+0x32>
  40e34e:	xor    eax,eax
  40e350:	jmp    40e35a <__swc_fn_4fa09e82_000044_d3c2ab54+0x3a>
  40e352:	add    rax,rcx
  40e355:	andn   rax,rcx,rax
  40e35a:	mov    ecx,0x1000
  40e35f:	test   ecx,ecx
  40e361:	mov    r8d,0x8
  40e367:	cmove  ecx,r8d
  40e36b:	dec    rcx
  40e36e:	mov    r8,0xffffffffffffffff
  40e375:	sub    r8,rcx
  40e378:	cmp    r9,r8
  40e37b:	jbe    40e381 <__swc_fn_4fa09e82_000044_d3c2ab54+0x61>
  40e37d:	xor    esi,esi
  40e37f:	jmp    40e38c <__swc_fn_4fa09e82_000044_d3c2ab54+0x6c>
  40e381:	add    r9,rcx
  40e384:	andn   r9,rcx,r9
  40e389:	mov    rsi,r9
  40e38c:	mov    rcx,rdx
  40e38f:	mov    rdx,rax
  40e392:	mov    r8,rsi
  40e395:	call   4097a0 <__swc_fn_4fa09e82_000120_5208f471>
  40e39a:	lea    rcx,[rip+0x15cd7]        # 424078 <__swc_bss_base_4fa09e82+0x38>
  40e3a1:	mov    rdx,QWORD PTR [rip+0x15cd0]        # 424078 <__swc_bss_base_4fa09e82+0x38>
  40e3a8:	nop    DWORD PTR [rax+rax*1+0x0]
  40e3b0:	mov    r8,rdx
  40e3b3:	sub    r8,rsi
  40e3b6:	mov    rax,rdx
  40e3b9:	lock cmpxchg QWORD PTR [rcx],r8
  40e3be:	cmp    rax,rdx
  40e3c1:	je     40e3c8 <__swc_fn_4fa09e82_000044_d3c2ab54+0xa8>
  40e3c3:	mov    rdx,rax
  40e3c6:	jmp    40e3b0 <__swc_fn_4fa09e82_000044_d3c2ab54+0x90>
  40e3c8:	lea    rcx,[rip+0x15cc1]        # 424090 <__swc_bss_base_4fa09e82+0x50>
  40e3cf:	mov    rdx,QWORD PTR [rip+0x15cba]        # 424090 <__swc_bss_base_4fa09e82+0x50>
  40e3d6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e3e0:	lea    r8,[rdx+0x1]
  40e3e4:	mov    rax,rdx
  40e3e7:	lock cmpxchg QWORD PTR [rcx],r8
  40e3ec:	cmp    rax,rdx
  40e3ef:	je     40e3f6 <__swc_fn_4fa09e82_000044_d3c2ab54+0xd6>
  40e3f1:	mov    rdx,rax
  40e3f4:	jmp    40e3e0 <__swc_fn_4fa09e82_000044_d3c2ab54+0xc0>
  40e3f6:	pop    rsi
  40e3f7:	ret
	...

000000000040e400 <__swc_fn_4fa09e82_000047_b30433d0>:
  40e400:	push   rbx
  40e401:	push   rsi
  40e402:	push   rdi
  40e403:	push   r12
  40e405:	push   r13
  40e407:	push   r14
  40e409:	push   r15
  40e40b:	sub    rsp,0x30
  40e40f:	mov    rbx,rdx
  40e412:	mov    QWORD PTR [rsp+0x18],rdx
  40e417:	mov    rsi,rcx
  40e41a:	mov    eax,0x1
  40e41f:	xchg   DWORD PTR [rbx+0x20],eax
  40e422:	test   eax,eax
  40e424:	je     40e436 <__swc_fn_4fa09e82_000047_b30433d0+0x36>
  40e426:	add    rsp,0x30
  40e42a:	pop    r15
  40e42c:	pop    r14
  40e42e:	pop    r13
  40e430:	pop    r12
  40e432:	pop    rdi
  40e433:	pop    rsi
  40e434:	pop    rbx
  40e435:	ret
  40e436:	mov    rcx,rsi
  40e439:	mov    rdx,rbx
  40e43c:	mov    r8,0xffffffffffffffff
  40e443:	call   40b990 <__swc_fn_4fa09e82_000064_dea90857>
  40e448:	lea    rdi,[rsi+0x10]
  40e44c:	mov    QWORD PTR [rsp+0x20],rdi
  40e451:	mov    rcx,rdi
  40e454:	call   409d20 <__swc_fn_4fa09e82_000141_86bb0f90>
  40e459:	xor    r12d,r12d
  40e45c:	cs nop WORD PTR [rax+rax*1+0x0]
  40e466:	cs nop WORD PTR [rax+rax*1+0x0]
  40e470:	mov    eax,r12d
  40e473:	lea    r13,[rax+rax*4]
  40e477:	lea    r13,[rbx+r13*8+0x28]
  40e47c:	mov    rax,QWORD PTR [r13+0x8]
  40e480:	mov    QWORD PTR [rsp+0x8],rax
  40e485:	mov    rax,QWORD PTR [r13+0x18]
  40e489:	mov    QWORD PTR [rsp+0x10],rax
  40e48e:	mov    r14d,0x2
  40e494:	xor    r15d,r15d
  40e497:	test   r14,r14
  40e49a:	je     40e517 <__swc_fn_4fa09e82_000047_b30433d0+0x117>
  40e4a0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  40e4a5:	mov    rdi,rax
  40e4a8:	test   rdi,rdi
  40e4ab:	je     40e509 <__swc_fn_4fa09e82_000047_b30433d0+0x109>
  40e4ad:	nop    DWORD PTR [rax]
  40e4b0:	mov    rbx,QWORD PTR [rdi+0x48]
  40e4b4:	mov    DWORD PTR [rdi+0x6c],0x0
  40e4bb:	mov    rcx,rdi
  40e4be:	call   40dfc0 <__swc_fn_4fa09e82_000014_e4b0ddfc>
  40e4c3:	cmp    DWORD PTR [rdi+0x28],0x0
  40e4c7:	jne    40e4e0 <__swc_fn_4fa09e82_000047_b30433d0+0xe0>
  40e4c9:	mov    rax,rdi
  40e4cc:	and    rax,0xffffffffffc00000
  40e4d3:	mov    rcx,rax
  40e4d6:	mov    rdx,rdi
  40e4d9:	call   40b0b0 <__swc_fn_4fa09e82_000019_283e2b5e>
  40e4de:	jmp    40e501 <__swc_fn_4fa09e82_000047_b30433d0+0x101>
  40e4e0:	mov    QWORD PTR [rdi+0x40],0x0
  40e4e8:	rex mov BYTE PTR [rdi+0x3b],0x2
  40e4ed:	mov    QWORD PTR [rdi+0x50],0x0
  40e4f5:	mov    rax,QWORD PTR [rsi+0x28]
  40e4f9:	mov    QWORD PTR [rdi+0x48],rax
  40e4fd:	mov    QWORD PTR [rsi+0x28],rdi
  40e501:	mov    rdi,rbx
  40e504:	test   rbx,rbx
  40e507:	jne    40e4b0 <__swc_fn_4fa09e82_000047_b30433d0+0xb0>
  40e509:	add    r15,0x1
  40e50d:	sub    r14,0x1
  40e511:	jne    40e4a0 <__swc_fn_4fa09e82_000047_b30433d0+0xa0>
  40e517:	vxorps xmm0,xmm0,xmm0
  40e51b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  40e521:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40e527:	mov    QWORD PTR [r13+0x20],0x0
  40e52f:	add    r12,0x1
  40e533:	cmp    r12,0x2d
  40e537:	mov    rbx,QWORD PTR [rsp+0x18]
  40e53c:	jb     40e470 <__swc_fn_4fa09e82_000047_b30433d0+0x70>
  40e542:	mov    rcx,rsi
  40e545:	mov    rbx,QWORD PTR [rsp+0x18]
  40e54a:	mov    rdx,rbx
  40e54d:	mov    rdi,QWORD PTR [rsp+0x20]
  40e552:	call   407ca0 <__swc_fn_4fa09e82_000048_6e7a8d58>
  40e557:	mov    rcx,rdi
  40e55a:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40e55f:	mov    rcx,rsi
  40e562:	mov    rdx,rbx
  40e565:	mov    r8d,0x9b8
  40e56b:	mov    r9d,0x9b8
  40e571:	call   40e320 <__swc_fn_4fa09e82_000044_d3c2ab54>
  40e576:	add    rsp,0x30
  40e57a:	pop    r15
  40e57c:	pop    r14
  40e57e:	pop    r13
  40e580:	pop    r12
  40e582:	pop    rdi
  40e583:	pop    rsi
  40e584:	pop    rbx
  40e585:	ret
	...

000000000040e5a0 <__swc_fn_4fa09e82_000050_ad48ec88>:
  40e5a0:	push   rbx
  40e5a1:	push   rsi
  40e5a2:	push   rdi
  40e5a3:	push   r12
  40e5a5:	push   r13
  40e5a7:	push   r14
  40e5a9:	push   r15
  40e5ab:	sub    rsp,0x30
  40e5af:	mov    ebx,r8d
  40e5b2:	mov    rsi,rcx
  40e5b5:	mov    rdi,rdx
  40e5b8:	test   r8d,r8d
  40e5bb:	jne    40e5c4 <__swc_fn_4fa09e82_000050_ad48ec88+0x24>
  40e5bd:	mov    eax,0x8
  40e5c2:	jmp    40e5eb <__swc_fn_4fa09e82_000050_ad48ec88+0x4b>
  40e5c4:	cmp    ebx,0x8
  40e5c7:	ja     40e5d2 <__swc_fn_4fa09e82_000050_ad48ec88+0x32>
  40e5c9:	mov    rax,rbx
  40e5cc:	shl    rax,0x4
  40e5d0:	jmp    40e5eb <__swc_fn_4fa09e82_000050_ad48ec88+0x4b>
  40e5d2:	lea    eax,[rbx-0x9]
  40e5d5:	mov    ecx,eax
  40e5d7:	shr    ecx,0x2
  40e5da:	and    eax,0x3
  40e5dd:	lea    ecx,[rcx+0x7]
  40e5e0:	lea    ecx,[rcx-0x2]
  40e5e3:	lea    eax,[rax+0x5]
  40e5e6:	shlx   rax,rax,rcx
  40e5eb:	lea    r12,[rsp+0x8]
  40e5f0:	mov    DWORD PTR [rsp+0x8],eax
  40e5f4:	lea    r13,[rsp+0xc]
  40e5f9:	mov    QWORD PTR [rsp+0x18],r13
  40e5fe:	xor    eax,eax
  40e600:	cmp    ebx,0x21
  40e603:	setae  al
  40e606:	lea    eax,[rax+rax*2]
  40e609:	mov    DWORD PTR [rsp+0xc],eax
  40e60d:	lea    r14,[rsi+0x10]
  40e611:	mov    rcx,r14
  40e614:	call   409d20 <__swc_fn_4fa09e82_000141_86bb0f90>
  40e619:	xor    eax,eax
  40e61b:	mov    rcx,QWORD PTR [rsi+0x28]
  40e61f:	mov    r15,rcx
  40e622:	test   r15,r15
  40e625:	je     40e6d6 <__swc_fn_4fa09e82_000050_ad48ec88+0x136>
  40e62b:	cs nop WORD PTR [rax+rax*1+0x0]
  40e635:	cs nop WORD PTR [rax+rax*1+0x0]
  40e63f:	nop
  40e640:	mov    rcx,QWORD PTR [r15+0x48]
  40e644:	movzx  edx,BYTE PTR [r15+0x39]
  40e649:	cmp    edx,ebx
  40e64b:	jne    40e6c7 <__swc_fn_4fa09e82_000050_ad48ec88+0x127>
  40e64d:	test   rax,rax
  40e650:	jne    40e658 <__swc_fn_4fa09e82_000050_ad48ec88+0xb8>
  40e652:	mov    QWORD PTR [rsi+0x28],rcx
  40e656:	jmp    40e65c <__swc_fn_4fa09e82_000050_ad48ec88+0xbc>
  40e658:	mov    QWORD PTR [rax+0x48],rcx
  40e65c:	vxorps xmm0,xmm0,xmm0
  40e660:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  40e666:	mov    BYTE PTR [r15+0x3b],0x1
  40e66b:	mov    QWORD PTR [r15+0x40],rdi
  40e66f:	mov    rcx,r15
  40e672:	call   40dfc0 <__swc_fn_4fa09e82_000014_e4b0ddfc>
  40e677:	movzx  eax,BYTE PTR [r15+0x39]
  40e67c:	lea    rax,[rax+rax*4]
  40e680:	lea    rax,[rdi+rax*8+0x28]
  40e685:	mov    rcx,QWORD PTR [rax+0x10]
  40e689:	mov    QWORD PTR [r15+0x50],rcx
  40e68d:	mov    QWORD PTR [r15+0x48],0x0
  40e695:	mov    rcx,QWORD PTR [rax+0x10]
  40e699:	test   rcx,rcx
  40e69c:	je     40e6a4 <__swc_fn_4fa09e82_000050_ad48ec88+0x104>
  40e69e:	mov    QWORD PTR [rcx+0x48],r15
  40e6a2:	jmp    40e6a8 <__swc_fn_4fa09e82_000050_ad48ec88+0x108>
  40e6a4:	mov    QWORD PTR [rax+0x8],r15
  40e6a8:	mov    QWORD PTR [rax+0x10],r15
  40e6ac:	mov    rcx,r14
  40e6af:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40e6b4:	mov    rax,r15
  40e6b7:	add    rsp,0x30
  40e6bb:	pop    r15
  40e6bd:	pop    r14
  40e6bf:	pop    r13
  40e6c1:	pop    r12
  40e6c3:	pop    rdi
  40e6c4:	pop    rsi
  40e6c5:	pop    rbx
  40e6c6:	ret
  40e6c7:	mov    rax,r15
  40e6ca:	mov    r15,rcx
  40e6cd:	test   rcx,rcx
  40e6d0:	jne    40e640 <__swc_fn_4fa09e82_000050_ad48ec88+0xa0>
  40e6d6:	mov    rax,QWORD PTR [rsi+0x18]
  40e6da:	mov    r15,rax
  40e6dd:	test   r15,r15
  40e6e0:	je     40e776 <__swc_fn_4fa09e82_000050_ad48ec88+0x1d6>
  40e6e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e6f0:	mov    eax,DWORD PTR [rsp+0xc]
  40e6f4:	cmp    DWORD PTR [r15+0x28],eax
  40e6f8:	jne    40e766 <__swc_fn_4fa09e82_000050_ad48ec88+0x1c6>
  40e6fa:	mov    rcx,r15
  40e6fd:	mov    edx,ebx
  40e6ff:	mov    rax,r12
  40e702:	mov    r8d,DWORD PTR [rax]
  40e705:	call   4076e0 <__swc_fn_4fa09e82_000018_efc44797>
  40e70a:	mov    r13,rax
  40e70d:	test   rax,rax
  40e710:	je     40e766 <__swc_fn_4fa09e82_000050_ad48ec88+0x1c6>
  40e712:	mov    QWORD PTR [r13+0x40],rdi
  40e716:	movzx  eax,BYTE PTR [r13+0x39]
  40e71b:	lea    rax,[rax+rax*4]
  40e71f:	lea    rax,[rdi+rax*8+0x28]
  40e724:	mov    rcx,QWORD PTR [rax+0x10]
  40e728:	mov    QWORD PTR [r13+0x50],rcx
  40e72c:	mov    QWORD PTR [r13+0x48],0x0
  40e734:	mov    rcx,QWORD PTR [rax+0x10]
  40e738:	test   rcx,rcx
  40e73b:	je     40e743 <__swc_fn_4fa09e82_000050_ad48ec88+0x1a3>
  40e73d:	mov    QWORD PTR [rcx+0x48],r13
  40e741:	jmp    40e747 <__swc_fn_4fa09e82_000050_ad48ec88+0x1a7>
  40e743:	mov    QWORD PTR [rax+0x8],r13
  40e747:	mov    QWORD PTR [rax+0x10],r13
  40e74b:	mov    rcx,r14
  40e74e:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40e753:	mov    rax,r13
  40e756:	add    rsp,0x30
  40e75a:	pop    r15
  40e75c:	pop    r14
  40e75e:	pop    r13
  40e760:	pop    r12
  40e762:	pop    rdi
  40e763:	pop    rsi
  40e764:	pop    rbx
  40e765:	ret
  40e766:	mov    rax,QWORD PTR [r15+0x10]
  40e76a:	mov    r15,rax
  40e76d:	test   rax,rax
  40e770:	jne    40e6f0 <__swc_fn_4fa09e82_000050_ad48ec88+0x150>
  40e776:	mov    rcx,rsi
  40e779:	mov    r13,QWORD PTR [rsp+0x18]
  40e77e:	mov    edx,DWORD PTR [r13+0x0]
  40e782:	call   40b230 <__swc_fn_4fa09e82_000025_2685aade>
  40e787:	mov    r13,rax
  40e78a:	test   rax,rax
  40e78d:	jne    40e7a9 <__swc_fn_4fa09e82_000050_ad48ec88+0x209>
  40e78f:	mov    rcx,r14
  40e792:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40e797:	xor    eax,eax
  40e799:	add    rsp,0x30
  40e79d:	pop    r15
  40e79f:	pop    r14
  40e7a1:	pop    r13
  40e7a3:	pop    r12
  40e7a5:	pop    rdi
  40e7a6:	pop    rsi
  40e7a7:	pop    rbx
  40e7a8:	ret
  40e7a9:	mov    rcx,r13
  40e7ac:	mov    edx,ebx
  40e7ae:	mov    r8d,DWORD PTR [r12]
  40e7b2:	call   4076e0 <__swc_fn_4fa09e82_000018_efc44797>
  40e7b7:	mov    rbx,rax
  40e7ba:	test   rax,rax
  40e7bd:	jne    40e7e1 <__swc_fn_4fa09e82_000050_ad48ec88+0x241>
  40e7bf:	mov    rcx,r13
  40e7c2:	call   40e200 <__swc_fn_4fa09e82_000026_aa910677>
  40e7c7:	mov    rcx,r14
  40e7ca:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40e7cf:	xor    eax,eax
  40e7d1:	add    rsp,0x30
  40e7d5:	pop    r15
  40e7d7:	pop    r14
  40e7d9:	pop    r13
  40e7db:	pop    r12
  40e7dd:	pop    rdi
  40e7de:	pop    rsi
  40e7df:	pop    rbx
  40e7e0:	ret
  40e7e1:	mov    rax,QWORD PTR [rsi+0x18]
  40e7e5:	mov    QWORD PTR [r13+0x10],rax
  40e7e9:	mov    rax,QWORD PTR [rsi+0x18]
  40e7ed:	test   rax,rax
  40e7f0:	je     40e7f6 <__swc_fn_4fa09e82_000050_ad48ec88+0x256>
  40e7f2:	mov    QWORD PTR [rax+0x18],r13
  40e7f6:	mov    QWORD PTR [rsi+0x18],r13
  40e7fa:	mov    QWORD PTR [rbx+0x40],rdi
  40e7fe:	movzx  eax,BYTE PTR [rbx+0x39]
  40e802:	lea    rax,[rax+rax*4]
  40e806:	lea    rax,[rdi+rax*8+0x28]
  40e80b:	mov    rcx,QWORD PTR [rax+0x10]
  40e80f:	mov    QWORD PTR [rbx+0x50],rcx
  40e813:	mov    QWORD PTR [rbx+0x48],0x0
  40e81b:	mov    rcx,QWORD PTR [rax+0x10]
  40e81f:	test   rcx,rcx
  40e822:	je     40e82a <__swc_fn_4fa09e82_000050_ad48ec88+0x28a>
  40e824:	mov    QWORD PTR [rcx+0x48],rbx
  40e828:	jmp    40e82e <__swc_fn_4fa09e82_000050_ad48ec88+0x28e>
  40e82a:	mov    QWORD PTR [rax+0x8],rbx
  40e82e:	mov    QWORD PTR [rax+0x10],rbx
  40e832:	mov    rcx,r14
  40e835:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40e83a:	mov    rax,rbx
  40e83d:	add    rsp,0x30
  40e841:	pop    r15
  40e843:	pop    r14
  40e845:	pop    r13
  40e847:	pop    r12
  40e849:	pop    rdi
  40e84a:	pop    rsi
  40e84b:	pop    rbx
  40e84c:	ret
	...

000000000040e860 <__swc_fn_4fa09e82_000053_d846b172>:
  40e860:	push   rsi
  40e861:	push   rdi
  40e862:	push   r12
  40e864:	mov    rsi,rdx
  40e867:	mov    rdi,rcx
  40e86a:	lea    rax,[rcx+0x2a80]
  40e871:	mov    rcx,QWORD PTR [rax]
  40e874:	test   rcx,rcx
  40e877:	jne    40e87e <__swc_fn_4fa09e82_000053_d846b172+0x1e>
  40e879:	pop    r12
  40e87b:	pop    rdi
  40e87c:	pop    rsi
  40e87d:	ret
  40e87e:	xor    ecx,ecx
  40e880:	xchg   QWORD PTR [rax],rcx
  40e883:	mov    r12,rcx
  40e886:	cs nop WORD PTR [rax+rax*1+0x0]
  40e890:	cs nop WORD PTR [rax+rax*1+0x0]
  40e89a:	nop    WORD PTR [rax+rax*1+0x0]
  40e8a0:	test   r12,r12
  40e8a3:	je     40e93a <__swc_fn_4fa09e82_000053_d846b172+0xda>
  40e8a9:	mov    r8,r12
  40e8ac:	mov    r12,QWORD PTR [r12+0x78]
  40e8b1:	lea    rcx,[r8+0x70]
  40e8b5:	xor    eax,eax
  40e8b7:	xchg   DWORD PTR [r8+0x70],eax
  40e8bb:	cmp    QWORD PTR [r8+0x40],rsi
  40e8bf:	jne    40e8d6 <__swc_fn_4fa09e82_000053_d846b172+0x76>
  40e8c1:	mov    eax,DWORD PTR [r8+0x6c]
  40e8c5:	test   eax,eax
  40e8c7:	je     40e8a0 <__swc_fn_4fa09e82_000053_d846b172+0x40>
  40e8c9:	mov    rcx,rdi
  40e8cc:	mov    rdx,rsi
  40e8cf:	call   40b5f0 <__swc_fn_4fa09e82_000052_e072b516>
  40e8d4:	jmp    40e8a0 <__swc_fn_4fa09e82_000053_d846b172+0x40>
  40e8d6:	mov    rax,QWORD PTR [r8+0x40]
  40e8da:	test   rax,rax
  40e8dd:	je     40e8a0 <__swc_fn_4fa09e82_000053_d846b172+0x40>
  40e8df:	mov    eax,DWORD PTR [r8+0x6c]
  40e8e3:	test   eax,eax
  40e8e5:	je     40e8a0 <__swc_fn_4fa09e82_000053_d846b172+0x40>
  40e8e7:	mov    r9d,0x1
  40e8ed:	xor    eax,eax
  40e8ef:	lock cmpxchg DWORD PTR [rcx],r9d
  40e8f4:	test   eax,eax
  40e8f6:	jne    40e8a0 <__swc_fn_4fa09e82_000053_d846b172+0x40>
  40e8f8:	mov    rax,r8
  40e8fb:	and    rax,0xffffffffffc00000
  40e902:	mov    rax,QWORD PTR [rax+0x8]
  40e906:	test   rax,rax
  40e909:	jne    40e911 <__swc_fn_4fa09e82_000053_d846b172+0xb1>
  40e90b:	xor    eax,eax
  40e90d:	xchg   DWORD PTR [rcx],eax
  40e90f:	jmp    40e8a0 <__swc_fn_4fa09e82_000053_d846b172+0x40>
  40e911:	lea    rcx,[rax+0x2a80]
  40e918:	mov    rax,QWORD PTR [rcx]
  40e91b:	mov    rdx,rax
  40e91e:	xchg   ax,ax
  40e920:	mov    QWORD PTR [r8+0x78],rdx
  40e924:	mov    rax,rdx
  40e927:	lock cmpxchg QWORD PTR [rcx],r8
  40e92c:	cmp    rax,rdx
  40e92f:	je     40e8a0 <__swc_fn_4fa09e82_000053_d846b172+0x40>
  40e935:	mov    rdx,rax
  40e938:	jmp    40e920 <__swc_fn_4fa09e82_000053_d846b172+0xc0>
  40e93a:	pop    r12
  40e93c:	pop    rdi
  40e93d:	pop    rsi
  40e93e:	ret
	...

000000000040e940 <__swc_fn_4fa09e82_000056_2e3450f7>:
  40e940:	sub    rsp,0x8
  40e944:	mov    r9,r8
  40e947:	movzx  eax,BYTE PTR [r9+0x39]
  40e94c:	lea    rax,[rax+rax*4]
  40e950:	lea    rax,[rdx+rax*8+0x28]
  40e955:	cmp    QWORD PTR [rax],r9
  40e958:	je     40e960 <__swc_fn_4fa09e82_000056_2e3450f7+0x20>
  40e95a:	cmp    QWORD PTR [rax+0x20],r9
  40e95e:	jne    40e965 <__swc_fn_4fa09e82_000056_2e3450f7+0x25>
  40e960:	add    rsp,0x8
  40e964:	ret
  40e965:	cmp    QWORD PTR [rax+0x20],0x0
  40e96a:	je     40e977 <__swc_fn_4fa09e82_000056_2e3450f7+0x37>
  40e96c:	mov    r8,QWORD PTR [rax+0x20]
  40e970:	cmp    DWORD PTR [r8+0x28],0x0
  40e975:	je     40e980 <__swc_fn_4fa09e82_000056_2e3450f7+0x40>
  40e977:	mov    QWORD PTR [rax+0x20],r9
  40e97b:	add    rsp,0x8
  40e97f:	ret
  40e980:	mov    r8,r9
  40e983:	call   40b550 <__swc_fn_4fa09e82_000049_137687bb>
  40e988:	mov    rax,r9
  40e98b:	and    rax,0xffffffffffc00000
  40e992:	mov    rcx,rax
  40e995:	mov    rdx,r9
  40e998:	call   40b0b0 <__swc_fn_4fa09e82_000019_283e2b5e>
  40e99d:	add    rsp,0x8
  40e9a1:	ret
	...

000000000040e9b0 <__swc_fn_4fa09e82_000059_1bb23e77>:
  40e9b0:	push   rsi
  40e9b1:	push   rdi
  40e9b2:	push   r12
  40e9b4:	mov    rsi,rdx
  40e9b7:	mov    rax,rdx
  40e9ba:	shr    rax,0xc
  40e9be:	movabs rdx,0x9e3779b97f4a7c15
  40e9c8:	imul   rax,rdx
  40e9cc:	shr    rax,0x20
  40e9d0:	lea    rax,[rax*8+0x0]
  40e9d8:	shr    rax,0x20
  40e9dc:	lea    rax,[rax*8+0x0]
  40e9e4:	lea    rax,[rcx+rax*8+0x40]
  40e9e9:	xor    edx,edx
  40e9eb:	test   dl,dl
  40e9ed:	lea    rdi,[rcx+0x8]
  40e9f1:	cmove  rdi,rax
  40e9f5:	xor    edx,edx
  40e9f7:	test   dl,dl
  40e9f9:	lea    r12,[rcx+0x30]
  40e9fd:	lea    rax,[rax+0x8]
  40ea01:	cmove  r12,rax
  40ea05:	mov    rcx,rdi
  40ea08:	call   409d20 <__swc_fn_4fa09e82_000141_86bb0f90>
  40ea0d:	mov    rax,QWORD PTR [rsi+0x30]
  40ea11:	test   rax,rax
  40ea14:	jne    40ea20 <__swc_fn_4fa09e82_000059_1bb23e77+0x70>
  40ea16:	mov    rax,QWORD PTR [rsi+0x38]
  40ea1a:	mov    QWORD PTR [r12],rax
  40ea1e:	jmp    40ea28 <__swc_fn_4fa09e82_000059_1bb23e77+0x78>
  40ea20:	mov    rcx,QWORD PTR [rsi+0x38]
  40ea24:	mov    QWORD PTR [rax+0x38],rcx
  40ea28:	mov    rax,QWORD PTR [rsi+0x38]
  40ea2c:	test   rax,rax
  40ea2f:	je     40ea39 <__swc_fn_4fa09e82_000059_1bb23e77+0x89>
  40ea31:	mov    rcx,QWORD PTR [rsi+0x30]
  40ea35:	mov    QWORD PTR [rax+0x30],rcx
  40ea39:	vxorps xmm0,xmm0,xmm0
  40ea3d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  40ea42:	mov    rcx,rdi
  40ea45:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40ea4a:	pop    r12
  40ea4c:	pop    rdi
  40ea4d:	pop    rsi
  40ea4e:	ret
	...

000000000040ea50 <__swc_fn_4fa09e82_000062_ad030a10>:
  40ea50:	mov    rax,QWORD PTR [rcx+0x250]
  40ea57:	mov    rcx,rax
  40ea5a:	cmp    rax,0x1000000
  40ea61:	mov    eax,0x1000000
  40ea66:	cmovb  rcx,rax
  40ea6a:	mov    rax,rcx
  40ea6d:	cmp    rcx,0x10000000
  40ea74:	mov    ecx,0x10000000
  40ea79:	cmova  rax,rcx
  40ea7d:	ret
	...

000000000040ea80 <__swc_fn_4fa09e82_000065_ffcd96eb>:
  40ea80:	push   rsi
  40ea81:	push   rdi
  40ea82:	push   r12
  40ea84:	mov    rsi,rcx
  40ea87:	mov    rdi,QWORD PTR [rsi+0x2a70]
  40ea8e:	xor    r12d,r12d
  40ea91:	test   rdi,rdi
  40ea94:	jbe    40eacb <__swc_fn_4fa09e82_000065_ffcd96eb+0x4b>
  40ea96:	cs nop WORD PTR [rax+rax*1+0x0]
  40eaa0:	lea    rax,[r12+r12*4]
  40eaa4:	lea    rax,[rsi+rax*8+0x268]
  40eaac:	mov    rcx,rsi
  40eaaf:	mov    rdx,QWORD PTR [rax]
  40eab2:	mov    r8,QWORD PTR [rax+0x8]
  40eab6:	mov    rax,QWORD PTR [rax+0x10]
  40eaba:	mov    r9,rax
  40eabd:	call   40e320 <__swc_fn_4fa09e82_000044_d3c2ab54>
  40eac2:	add    r12,0x1
  40eac6:	cmp    r12,rdi
  40eac9:	jb     40eaa0 <__swc_fn_4fa09e82_000065_ffcd96eb+0x20>
  40eacb:	vxorps xmm0,xmm0,xmm0
  40eacf:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  40ead7:	pop    r12
  40ead9:	pop    rdi
  40eada:	pop    rsi
  40eadb:	ret
  40eadc:	add    BYTE PTR [rax],al
	...

000000000040eae0 <__swc_fn_4fa09e82_000068_8c7d044b>:
  40eae0:	push   rsi
  40eae1:	push   rdi
  40eae2:	sub    rsp,0x8
  40eae6:	mov    rsi,rcx
  40eae9:	call   408020 <__swc_fn_4fa09e82_000057_df0696cd>
  40eaee:	mov    rdi,rax
  40eaf1:	mov    rcx,rsi
  40eaf4:	mov    rdx,rax
  40eaf7:	call   40e9b0 <__swc_fn_4fa09e82_000059_1bb23e77>
  40eafc:	mov    rcx,QWORD PTR [rdi+0x28]
  40eb00:	mov    rdx,QWORD PTR [rsi+0x250]
  40eb07:	nop    WORD PTR [rax+rax*1+0x0]
  40eb10:	mov    r8,rdx
  40eb13:	sub    r8,rcx
  40eb16:	mov    rax,rdx
  40eb19:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40eb22:	cmp    rax,rdx
  40eb25:	je     40eb2c <__swc_fn_4fa09e82_000068_8c7d044b+0x4c>
  40eb27:	mov    rdx,rax
  40eb2a:	jmp    40eb10 <__swc_fn_4fa09e82_000068_8c7d044b+0x30>
  40eb2c:	mov    rcx,rsi
  40eb2f:	mov    rdx,QWORD PTR [rdi]
  40eb32:	mov    r8,QWORD PTR [rdi+0x8]
  40eb36:	mov    r9,QWORD PTR [rdi+0x10]
  40eb3a:	call   408140 <__swc_fn_4fa09e82_000063_b304235a>
  40eb3f:	mov    rcx,rsi
  40eb42:	call   407d80 <__swc_fn_4fa09e82_000054_3af34d7f>
  40eb47:	add    rsp,0x8
  40eb4b:	pop    rdi
  40eb4c:	pop    rsi
  40eb4d:	ret
	...

000000000040eb50 <__swc_fn_4fa09e82_000071_97813b89>:
  40eb50:	push   r12
  40eb52:	push   r13
  40eb54:	push   r14
  40eb56:	push   rdi
  40eb57:	push   rsi
  40eb58:	sub    rsp,0x1b0
  40eb5f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  40eb68:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  40eb71:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  40eb7a:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  40eb83:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  40eb8c:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  40eb95:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  40eb9e:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  40eba7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  40ebb0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  40ebb9:	mov    r8,rdx
  40ebbc:	mov    r12,rcx
  40ebbf:	mov    r13,QWORD PTR [r8+0x40]
  40ebc3:	test   r13,r13
  40ebc6:	jne    40ebd8 <__swc_fn_4fa09e82_000071_97813b89+0x88>
  40ebc8:	add    rsp,0x1b0
  40ebcf:	pop    rsi
  40ebd0:	pop    rdi
  40ebd1:	pop    r14
  40ebd3:	pop    r13
  40ebd5:	pop    r12
  40ebd7:	ret
  40ebd8:	mov    QWORD PTR [r8+0x40],0x0
  40ebe0:	lea    rax,[rip+0x154b9]        # 4240a0 <__swc_bss_base_4fa09e82+0x60>
  40ebe7:	mov    rcx,r13
  40ebea:	sub    rcx,QWORD PTR [rax+0x8]
  40ebee:	mov    rax,QWORD PTR [rip+0x154bb]        # 4240b0 <__swc_bss_base_4fa09e82+0x70>
  40ebf5:	cmp    rcx,rax
  40ebf8:	jae    40ec24 <__swc_fn_4fa09e82_000071_97813b89+0xd4>
  40ebfa:	mov    rax,r13
  40ebfd:	and    rax,0xffffffffffc00000
  40ec04:	mov    rcx,r13
  40ec07:	shr    rcx,0x10
  40ec0b:	and    ecx,0x3f
  40ec0e:	mov    edx,DWORD PTR [rax+0x28]
  40ec11:	shrx   ecx,ecx,edx
  40ec16:	shl    rcx,0x4
  40ec1a:	lea    r14,[rax+rcx*8+0x80]
  40ec22:	jmp    40ec3f <__swc_fn_4fa09e82_000071_97813b89+0xef>
  40ec24:	mov    rcx,r13
  40ec27:	mov    QWORD PTR [rsp+0xf8],r8
  40ec2f:	call   407a10 <__swc_fn_4fa09e82_000027_bcdc5519>
  40ec34:	mov    r8,QWORD PTR [rsp+0xf8]
  40ec3c:	mov    r14,rax
  40ec3f:	test   r14,r14
  40ec42:	jne    40ec54 <__swc_fn_4fa09e82_000071_97813b89+0x104>
  40ec44:	mov    rcx,r12
  40ec47:	mov    rdx,r13
  40ec4a:	call   40eae0 <__swc_fn_4fa09e82_000068_8c7d044b>
  40ec4f:	jmp    40ece2 <__swc_fn_4fa09e82_000071_97813b89+0x192>
  40ec54:	lea    rax,[rip+0x133ad]        # 422008 <__swc_data_base_4fa09e82+0x8>
  40ec5b:	mov    rax,QWORD PTR [rax]
  40ec5e:	cmp    rax,0xffffffffffffffff
  40ec62:	je     40ec71 <__swc_fn_4fa09e82_000071_97813b89+0x121>
  40ec64:	mov    eax,eax
  40ec66:	mov    edi,eax
  40ec68:	xor    eax,eax
  40ec6a:	call   407000 <pthread_getspecific@plt>
  40ec6f:	jmp    40ec73 <__swc_fn_4fa09e82_000071_97813b89+0x123>
  40ec71:	xor    eax,eax
  40ec73:	test   rax,rax
  40ec76:	jne    40ec85 <__swc_fn_4fa09e82_000071_97813b89+0x135>
  40ec78:	call   407ae0 <__swc_fn_4fa09e82_000036_cd1a4e8c>
  40ec7d:	mov    rcx,rax
  40ec80:	call   410760 <__swc_fn_4fa09e82_000134_5f757033>
  40ec85:	test   rax,rax
  40ec88:	je     40ecd7 <__swc_fn_4fa09e82_000071_97813b89+0x187>
  40ec8a:	cmp    QWORD PTR [r14+0x40],rax
  40ec8e:	jne    40ecd7 <__swc_fn_4fa09e82_000071_97813b89+0x187>
  40ec90:	mov    ecx,DWORD PTR [r14+0x6c]
  40ec94:	test   ecx,ecx
  40ec96:	je     40ecb6 <__swc_fn_4fa09e82_000071_97813b89+0x166>
  40ec98:	mov    rcx,r12
  40ec9b:	mov    rdx,rax
  40ec9e:	mov    r8,r14
  40eca1:	mov    QWORD PTR [rsp+0x100],rax
  40eca9:	call   40b5f0 <__swc_fn_4fa09e82_000052_e072b516>
  40ecae:	mov    rax,QWORD PTR [rsp+0x100]
  40ecb6:	mov    rcx,QWORD PTR [r14]
  40ecb9:	mov    QWORD PTR [r13+0x0],rcx
  40ecbd:	mov    QWORD PTR [r14],r13
  40ecc0:	sub    DWORD PTR [r14+0x28],0x1
  40ecc5:	jne    40ece2 <__swc_fn_4fa09e82_000071_97813b89+0x192>
  40ecc7:	mov    rcx,r12
  40ecca:	mov    rdx,rax
  40eccd:	mov    r8,r14
  40ecd0:	call   40e940 <__swc_fn_4fa09e82_000056_2e3450f7>
  40ecd5:	jmp    40ece2 <__swc_fn_4fa09e82_000071_97813b89+0x192>
  40ecd7:	mov    rcx,r14
  40ecda:	mov    rdx,r13
  40ecdd:	call   407650 <__swc_fn_4fa09e82_000015_524c1f23>
  40ece2:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40eceb:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  40ecf4:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40ecfd:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  40ed06:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40ed0f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  40ed18:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  40ed21:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40ed2a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  40ed33:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40ed3c:	add    rsp,0x1b0
  40ed43:	pop    rsi
  40ed44:	pop    rdi
  40ed45:	pop    r14
  40ed47:	pop    r13
  40ed49:	pop    r12
  40ed4b:	ret
  40ed4c:	add    BYTE PTR [rax],al
	...

000000000040ed50 <__swc_fn_4fa09e82_000074_9c99bf04>:
  40ed50:	push   rsi
  40ed51:	mov    rsi,rcx
  40ed54:	call   40e310 <__swc_fn_4fa09e82_000041_eb6108f2>
  40ed59:	test   al,al
  40ed5b:	jne    40ed5f <__swc_fn_4fa09e82_000074_9c99bf04+0xf>
  40ed5d:	pop    rsi
  40ed5e:	ret
  40ed5f:	lea    rax,[rip+0x154da]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  40ed66:	cmp    rsi,rax
  40ed69:	jne    40ed6d <__swc_fn_4fa09e82_000074_9c99bf04+0x1d>
  40ed6b:	pop    rsi
  40ed6c:	ret
  40ed6d:	mov    rcx,rsi
  40ed70:	call   409d20 <__swc_fn_4fa09e82_000141_86bb0f90>
  40ed75:	mov    rcx,rsi
  40ed78:	call   40bdc0 <__swc_fn_4fa09e82_000073_61e60aab>
  40ed7d:	mov    rcx,rsi
  40ed80:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  40ed85:	pop    rsi
  40ed86:	ret
	...

000000000040ed90 <__swc_fn_4fa09e82_000077_15bd096c>:
  40ed90:	sub    rsp,0x8
  40ed94:	call   40bb10 <__swc_fn_4fa09e82_000070_7130736e>
  40ed99:	add    rsp,0x8
  40ed9d:	ret
	...

000000000040eda0 <__swc_fn_4fa09e82_000080_a5fd3362>:
  40eda0:	push   rsi
  40eda1:	mov    rsi,rdx
  40eda4:	call   40bdc0 <__swc_fn_4fa09e82_000073_61e60aab>
  40eda9:	mov    QWORD PTR [rsi+0x40],0x0
  40edb1:	pop    rsi
  40edb2:	ret
	...

000000000040edc0 <__swc_fn_4fa09e82_000083_63a67586>:
  40edc0:	mov    r8,rcx
  40edc3:	mov    rcx,QWORD PTR [rcx]
  40edc6:	cs nop WORD PTR [rax+rax*1+0x0]
  40edd0:	mov    r9,rcx
  40edd3:	sub    r9,rdx
  40edd6:	mov    rax,rcx
  40edd9:	lock cmpxchg QWORD PTR [r8],r9
  40edde:	cmp    rax,rcx
  40ede1:	je     40ede8 <__swc_fn_4fa09e82_000083_63a67586+0x28>
  40ede3:	mov    rcx,rax
  40ede6:	jmp    40edd0 <__swc_fn_4fa09e82_000083_63a67586+0x10>
  40ede8:	mov    rax,rcx
  40edeb:	ret
  40edec:	add    BYTE PTR [rax],al
	...

000000000040edf0 <__swc_fn_4fa09e82_000086_c618ff58>:
  40edf0:	vxorps xmm0,xmm0,xmm0
  40edf4:	vmovups XMMWORD PTR [rcx],xmm0
  40edf8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40edfd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ee02:	ret
	...

000000000040ee10 <__swc_fn_4fa09e82_000089_0d280354>:
  40ee10:	push   rsi
  40ee11:	push   rdi
  40ee12:	push   r12
  40ee14:	push   r13
  40ee16:	push   r15
  40ee18:	push   r14
  40ee1a:	push   rbx
  40ee1b:	sub    rsp,0x60
  40ee1f:	mov    QWORD PTR [rsp+0x28],r11
  40ee24:	mov    rsi,rcx
  40ee27:	mov    rdi,rdx
  40ee2a:	mov    QWORD PTR [rsp+0x30],rdx
  40ee2f:	mov    r12,r8
  40ee32:	mov    r13,r9
  40ee35:	mov    QWORD PTR [rsp+0x38],r10
  40ee3a:	xor    r8d,r8d
  40ee3d:	call   40f160 <__swc_fn_4fa09e82_000095_63c1827b>
  40ee42:	test   al,al
  40ee44:	je     40ee59 <__swc_fn_4fa09e82_000089_0d280354+0x49>
  40ee46:	mov    rax,r12
  40ee49:	add    rsp,0x60
  40ee4d:	pop    rbx
  40ee4e:	pop    r14
  40ee50:	pop    r15
  40ee52:	pop    r13
  40ee54:	pop    r12
  40ee56:	pop    rdi
  40ee57:	pop    rsi
  40ee58:	ret
  40ee59:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40ee5e:	je     40ee72 <__swc_fn_4fa09e82_000089_0d280354+0x62>
  40ee60:	xor    eax,eax
  40ee62:	add    rsp,0x60
  40ee66:	pop    rbx
  40ee67:	pop    r14
  40ee69:	pop    r15
  40ee6b:	pop    r13
  40ee6d:	pop    r12
  40ee6f:	pop    rdi
  40ee70:	pop    rsi
  40ee71:	ret
  40ee72:	mov    r15,rdi
  40ee75:	mov    QWORD PTR [rsp+0x40],rdi
  40ee7a:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40ee7f:	jne    40eeef <__swc_fn_4fa09e82_000089_0d280354+0xdf>
  40ee81:	mov    r14,QWORD PTR [r15+0xb8]
  40ee88:	mov    rax,QWORD PTR [r15+0xc0]
  40ee8f:	mov    r15,rax
  40ee92:	xor    edi,edi
  40ee94:	test   r15,r15
  40ee97:	je     40eeef <__swc_fn_4fa09e82_000089_0d280354+0xdf>
  40ee99:	nop    DWORD PTR [rax+0x0]
  40eea0:	lea    rbx,[rdi*8+0x0]
  40eea8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  40eead:	mov    rcx,rax
  40eeb0:	mov    rdx,rsi
  40eeb3:	xor    r8d,r8d
  40eeb6:	call   40f160 <__swc_fn_4fa09e82_000095_63c1827b>
  40eebb:	test   al,al
  40eebd:	je     40eee5 <__swc_fn_4fa09e82_000089_0d280354+0xd5>
  40eebf:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  40eec4:	test   rax,rax
  40eec7:	je     40eee5 <__swc_fn_4fa09e82_000089_0d280354+0xd5>
  40eec9:	test   r13,r13
  40eecc:	je     40eed2 <__swc_fn_4fa09e82_000089_0d280354+0xc2>
  40eece:	mov    QWORD PTR [r13+0x8],rax
  40eed2:	mov    rax,r12
  40eed5:	add    rsp,0x60
  40eed9:	pop    rbx
  40eeda:	pop    r14
  40eedc:	pop    r15
  40eede:	pop    r13
  40eee0:	pop    r12
  40eee2:	pop    rdi
  40eee3:	pop    rsi
  40eee4:	ret
  40eee5:	add    rdi,0x1
  40eee9:	sub    r15,0x1
  40eeed:	jne    40eea0 <__swc_fn_4fa09e82_000089_0d280354+0x90>
  40eeef:	test   r12,r12
  40eef2:	jne    40ef06 <__swc_fn_4fa09e82_000089_0d280354+0xf6>
  40eef4:	xor    eax,eax
  40eef6:	add    rsp,0x60
  40eefa:	pop    rbx
  40eefb:	pop    r14
  40eefd:	pop    r15
  40eeff:	pop    r13
  40ef01:	pop    r12
  40ef03:	pop    rdi
  40ef04:	pop    rsi
  40ef05:	ret
  40ef06:	mov    rbx,QWORD PTR [rsp+0x28]
  40ef0b:	mov    rdi,QWORD PTR [rsp+0x30]
  40ef10:	mov    rax,rbx
  40ef13:	test   rax,rax
  40ef16:	je     40ef46 <__swc_fn_4fa09e82_000089_0d280354+0x136>
  40ef18:	nop    DWORD PTR [rax+rax*1+0x0]
  40ef20:	cmp    QWORD PTR [rax+0x8],r12
  40ef24:	jne    40ef3d <__swc_fn_4fa09e82_000089_0d280354+0x12d>
  40ef26:	cmp    QWORD PTR [rax],rdi
  40ef29:	jne    40ef3d <__swc_fn_4fa09e82_000089_0d280354+0x12d>
  40ef2b:	xor    eax,eax
  40ef2d:	add    rsp,0x60
  40ef31:	pop    rbx
  40ef32:	pop    r14
  40ef34:	pop    r15
  40ef36:	pop    r13
  40ef38:	pop    r12
  40ef3a:	pop    rdi
  40ef3b:	pop    rsi
  40ef3c:	ret
  40ef3d:	mov    rax,QWORD PTR [rax+0x10]
  40ef41:	test   rax,rax
  40ef44:	jne    40ef20 <__swc_fn_4fa09e82_000089_0d280354+0x110>
  40ef46:	lea    r14,[rsp+0x8]
  40ef4b:	mov    QWORD PTR [rsp+0x48],r14
  40ef50:	mov    QWORD PTR [rsp+0x8],rdi
  40ef55:	mov    QWORD PTR [rsp+0x10],r12
  40ef5a:	mov    QWORD PTR [rsp+0x18],rbx
  40ef5f:	mov    r15,QWORD PTR [rsp+0x40]
  40ef64:	mov    rbx,QWORD PTR [r15+0x98]
  40ef6b:	mov    rax,QWORD PTR [r15+0xa0]
  40ef72:	mov    rdi,rax
  40ef75:	mov    r15,QWORD PTR [rsp+0x38]
  40ef7a:	xor    r14d,r14d
  40ef7d:	test   rdi,rdi
  40ef80:	je     40f02a <__swc_fn_4fa09e82_000089_0d280354+0x21a>
  40ef86:	cs nop WORD PTR [rax+rax*1+0x0]
  40ef90:	mov    QWORD PTR [rsp+0x50],rdi
  40ef95:	lea    rdi,[r14*8+0x0]
  40ef9d:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  40efa2:	mov    rcx,rax
  40efa5:	call   409120 <__swc_fn_4fa09e82_000087_3953ef98>
  40efaa:	test   DWORD PTR [rax+0x28],0x10000
  40efb1:	je     40efb8 <__swc_fn_4fa09e82_000089_0d280354+0x1a8>
  40efb3:	test   r15b,r15b
  40efb6:	je     40f011 <__swc_fn_4fa09e82_000089_0d280354+0x201>
  40efb8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  40efbc:	lea    rdi,[r12+rcx*1]
  40efc0:	cmp    BYTE PTR [rax+0x2c],0x6
  40efc4:	jne    40efd8 <__swc_fn_4fa09e82_000089_0d280354+0x1c8>
  40efc6:	mov    rax,QWORD PTR [rax+0x40]
  40efca:	mov    rcx,rax
  40efcd:	call   409120 <__swc_fn_4fa09e82_000087_3953ef98>
  40efd2:	mov    rcx,QWORD PTR [rdi]
  40efd5:	mov    rdi,rcx
  40efd8:	test   rdi,rdi
  40efdb:	je     40f011 <__swc_fn_4fa09e82_000089_0d280354+0x201>
  40efdd:	mov    rcx,rsi
  40efe0:	mov    rdx,rax
  40efe3:	mov    r8,rdi
  40efe6:	mov    r9,r13
  40efe9:	mov    al,r15b
  40efec:	mov    r10,rax
  40efef:	mov    rdi,QWORD PTR [rsp+0x48]
  40eff4:	mov    r11,rdi
  40eff7:	call   40ee10 <__swc_fn_4fa09e82_000089_0d280354>
  40effc:	test   rax,rax
  40efff:	je     40f011 <__swc_fn_4fa09e82_000089_0d280354+0x201>
  40f001:	add    rsp,0x60
  40f005:	pop    rbx
  40f006:	pop    r14
  40f008:	pop    r15
  40f00a:	pop    r13
  40f00c:	pop    r12
  40f00e:	pop    rdi
  40f00f:	pop    rsi
  40f010:	ret
  40f011:	add    r14,0x1
  40f015:	mov    rax,QWORD PTR [rsp+0x50]
  40f01a:	sub    rax,0x1
  40f01e:	mov    rdi,rax
  40f021:	test   rax,rax
  40f024:	jne    40ef90 <__swc_fn_4fa09e82_000089_0d280354+0x180>
  40f02a:	xor    eax,eax
  40f02c:	add    rsp,0x60
  40f030:	pop    rbx
  40f031:	pop    r14
  40f033:	pop    r15
  40f035:	pop    r13
  40f037:	pop    r12
  40f039:	pop    rdi
  40f03a:	pop    rsi
  40f03b:	ret
  40f03c:	add    BYTE PTR [rax],al
	...

000000000040f040 <__swc_fn_4fa09e82_000092_c1c9085b>:
  40f040:	push   rsi
  40f041:	push   rdi
  40f042:	push   r12
  40f044:	push   r13
  40f046:	push   r14
  40f048:	push   r15
  40f04a:	sub    rsp,0x78
  40f04e:	mov    rsi,r10
  40f051:	mov    QWORD PTR [rsp+0x68],r10
  40f056:	mov    rdi,rcx
  40f059:	mov    r12,rdx
  40f05c:	mov    r13,r8
  40f05f:	mov    r14,r9
  40f062:	xor    r8d,r8d
  40f065:	call   40f160 <__swc_fn_4fa09e82_000095_63c1827b>
  40f06a:	test   al,al
  40f06c:	je     40f095 <__swc_fn_4fa09e82_000092_c1c9085b+0x55>
  40f06e:	mov    rcx,r14
  40f071:	mov    rdx,r12
  40f074:	mov    r8,r13
  40f077:	mov    r9,rsi
  40f07a:	call   40c220 <__swc_fn_4fa09e82_000091_23214800>
  40f07f:	test   al,al
  40f081:	je     40f095 <__swc_fn_4fa09e82_000092_c1c9085b+0x55>
  40f083:	mov    rax,r13
  40f086:	add    rsp,0x78
  40f08a:	pop    r15
  40f08c:	pop    r14
  40f08e:	pop    r13
  40f090:	pop    r12
  40f092:	pop    rdi
  40f093:	pop    rsi
  40f094:	ret
  40f095:	cmp    BYTE PTR [r12+0x2c],0xe
  40f09b:	je     40f0ae <__swc_fn_4fa09e82_000092_c1c9085b+0x6e>
  40f09d:	xor    eax,eax
  40f09f:	add    rsp,0x78
  40f0a3:	pop    r15
  40f0a5:	pop    r14
  40f0a7:	pop    r13
  40f0a9:	pop    r12
  40f0ab:	pop    rdi
  40f0ac:	pop    rsi
  40f0ad:	ret
  40f0ae:	mov    r15,QWORD PTR [r12+0x98]
  40f0b6:	mov    rax,QWORD PTR [r12+0xa0]
  40f0be:	mov    r12,rax
  40f0c1:	xor    esi,esi
  40f0c3:	test   r12,r12
  40f0c6:	je     40f139 <__swc_fn_4fa09e82_000092_c1c9085b+0xf9>
  40f0c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40f0d0:	mov    QWORD PTR [rsp+0x70],r12
  40f0d5:	lea    r12,[rsi*8+0x0]
  40f0dd:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  40f0e2:	mov    rcx,rax
  40f0e5:	call   409120 <__swc_fn_4fa09e82_000087_3953ef98>
  40f0ea:	cmp    BYTE PTR [rax+0x2c],0xe
  40f0ee:	jne    40f124 <__swc_fn_4fa09e82_000092_c1c9085b+0xe4>
  40f0f0:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  40f0f5:	lea    r8,[r13+rcx*1+0x0]
  40f0fa:	mov    rcx,rdi
  40f0fd:	mov    rdx,rax
  40f100:	mov    r9,r14
  40f103:	mov    r12,QWORD PTR [rsp+0x68]
  40f108:	mov    r10,r12
  40f10b:	call   40f040 <__swc_fn_4fa09e82_000092_c1c9085b>
  40f110:	test   rax,rax
  40f113:	je     40f124 <__swc_fn_4fa09e82_000092_c1c9085b+0xe4>
  40f115:	add    rsp,0x78
  40f119:	pop    r15
  40f11b:	pop    r14
  40f11d:	pop    r13
  40f11f:	pop    r12
  40f121:	pop    rdi
  40f122:	pop    rsi
  40f123:	ret
  40f124:	add    rsi,0x1
  40f128:	mov    rax,QWORD PTR [rsp+0x70]
  40f12d:	sub    rax,0x1
  40f131:	mov    r12,rax
  40f134:	test   rax,rax
  40f137:	jne    40f0d0 <__swc_fn_4fa09e82_000092_c1c9085b+0x90>
  40f139:	xor    eax,eax
  40f13b:	add    rsp,0x78
  40f13f:	pop    r15
  40f141:	pop    r14
  40f143:	pop    r13
  40f145:	pop    r12
  40f147:	pop    rdi
  40f148:	pop    rsi
  40f149:	ret
	...

000000000040f160 <__swc_fn_4fa09e82_000095_63c1827b>:
  40f160:	push   rbx
  40f161:	push   rsi
  40f162:	push   rdi
  40f163:	push   r12
  40f165:	push   r13
  40f167:	push   r14
  40f169:	push   r15
  40f16b:	sub    rsp,0x120
  40f172:	mov    rbx,r8
  40f175:	mov    rsi,rdx
  40f178:	test   rcx,rcx
  40f17b:	jne    40f19a <__swc_fn_4fa09e82_000095_63c1827b+0x3a>
  40f17d:	test   rsi,rsi
  40f180:	jne    40f19a <__swc_fn_4fa09e82_000095_63c1827b+0x3a>
  40f182:	mov    eax,0x1
  40f187:	add    rsp,0x120
  40f18e:	pop    r15
  40f190:	pop    r14
  40f192:	pop    r13
  40f194:	pop    r12
  40f196:	pop    rdi
  40f197:	pop    rsi
  40f198:	pop    rbx
  40f199:	ret
  40f19a:	test   rcx,rcx
  40f19d:	je     40f1a4 <__swc_fn_4fa09e82_000095_63c1827b+0x44>
  40f19f:	test   rsi,rsi
  40f1a2:	jne    40f1b9 <__swc_fn_4fa09e82_000095_63c1827b+0x59>
  40f1a4:	xor    eax,eax
  40f1a6:	add    rsp,0x120
  40f1ad:	pop    r15
  40f1af:	pop    r14
  40f1b1:	pop    r13
  40f1b3:	pop    r12
  40f1b5:	pop    rdi
  40f1b6:	pop    rsi
  40f1b7:	pop    rbx
  40f1b8:	ret
  40f1b9:	call   409120 <__swc_fn_4fa09e82_000087_3953ef98>
  40f1be:	mov    rdi,rax
  40f1c1:	mov    rcx,rsi
  40f1c4:	call   409120 <__swc_fn_4fa09e82_000087_3953ef98>
  40f1c9:	test   bl,0x1
  40f1cc:	je     40f20a <__swc_fn_4fa09e82_000095_63c1827b+0xaa>
  40f1ce:	rex cmp BYTE PTR [rdi+0x2c],0x6
  40f1d3:	jne    40f20a <__swc_fn_4fa09e82_000095_63c1827b+0xaa>
  40f1d5:	mov    ecx,DWORD PTR [rdi+0x28]
  40f1d8:	test   ecx,0x1000
  40f1de:	je     40f20a <__swc_fn_4fa09e82_000095_63c1827b+0xaa>
  40f1e0:	test   ecx,0x10000
  40f1e6:	je     40f20a <__swc_fn_4fa09e82_000095_63c1827b+0xaa>
  40f1e8:	mov    rcx,QWORD PTR [rdi+0x40]
  40f1ec:	mov    rdx,rax
  40f1ef:	mov    r8d,ebx
  40f1f2:	call   40f160 <__swc_fn_4fa09e82_000095_63c1827b>
  40f1f7:	add    rsp,0x120
  40f1fe:	pop    r15
  40f200:	pop    r14
  40f202:	pop    r13
  40f204:	pop    r12
  40f206:	pop    rdi
  40f207:	pop    rsi
  40f208:	pop    rbx
  40f209:	ret
  40f20a:	mov    cl,BYTE PTR [rax+0x2c]
  40f20d:	rex cmp BYTE PTR [rdi+0x2c],cl
  40f211:	jne    40f21b <__swc_fn_4fa09e82_000095_63c1827b+0xbb>
  40f213:	mov    ecx,DWORD PTR [rax+0x20]
  40f216:	cmp    DWORD PTR [rdi+0x20],ecx
  40f219:	je     40f230 <__swc_fn_4fa09e82_000095_63c1827b+0xd0>
  40f21b:	xor    eax,eax
  40f21d:	add    rsp,0x120
  40f224:	pop    r15
  40f226:	pop    r14
  40f228:	pop    r13
  40f22a:	pop    r12
  40f22c:	pop    rdi
  40f22d:	pop    rsi
  40f22e:	pop    rbx
  40f22f:	ret
  40f230:	mov    ecx,DWORD PTR [rdi+0x28]
  40f233:	and    ecx,0xffb5ffff
  40f239:	mov    edx,DWORD PTR [rax+0x28]
  40f23c:	and    edx,0xffb5ffff
  40f242:	cmp    ecx,edx
  40f244:	je     40f25b <__swc_fn_4fa09e82_000095_63c1827b+0xfb>
  40f246:	xor    eax,eax
  40f248:	add    rsp,0x120
  40f24f:	pop    r15
  40f251:	pop    r14
  40f253:	pop    r13
  40f255:	pop    r12
  40f257:	pop    rdi
  40f258:	pop    rsi
  40f259:	pop    rbx
  40f25a:	ret
  40f25b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  40f260:	jne    40f2b5 <__swc_fn_4fa09e82_000095_63c1827b+0x155>
  40f262:	mov    cl,BYTE PTR [rax+0x40]
  40f265:	rex cmp BYTE PTR [rdi+0x40],cl
  40f269:	je     40f280 <__swc_fn_4fa09e82_000095_63c1827b+0x120>
  40f26b:	xor    eax,eax
  40f26d:	add    rsp,0x120
  40f274:	pop    r15
  40f276:	pop    r14
  40f278:	pop    r13
  40f27a:	pop    r12
  40f27c:	pop    rdi
  40f27d:	pop    rsi
  40f27e:	pop    rbx
  40f27f:	ret
  40f280:	rex cmp BYTE PTR [rdi+0x40],0xd
  40f285:	je     40f29d <__swc_fn_4fa09e82_000095_63c1827b+0x13d>
  40f287:	rex cmp BYTE PTR [rdi+0x40],0xf
  40f28c:	sete   cl
  40f28f:	je     40f299 <__swc_fn_4fa09e82_000095_63c1827b+0x139>
  40f291:	rex cmp BYTE PTR [rdi+0x40],0xe
  40f296:	sete   cl
  40f299:	test   cl,cl
  40f29b:	je     40f2b5 <__swc_fn_4fa09e82_000095_63c1827b+0x155>
  40f29d:	mov    eax,0x1
  40f2a2:	add    rsp,0x120
  40f2a9:	pop    r15
  40f2ab:	pop    r14
  40f2ad:	pop    r13
  40f2af:	pop    r12
  40f2b1:	pop    rdi
  40f2b2:	pop    rsi
  40f2b3:	pop    rbx
  40f2b4:	ret
  40f2b5:	test   DWORD PTR [rdi+0x28],0x200200
  40f2bc:	je     40f46f <__swc_fn_4fa09e82_000095_63c1827b+0x30f>
  40f2c2:	mov    rsi,QWORD PTR [rdi+0x88]
  40f2c9:	mov    rdi,QWORD PTR [rdi+0x90]
  40f2d0:	mov    r12,QWORD PTR [rax+0x88]
  40f2d7:	mov    rax,QWORD PTR [rax+0x90]
  40f2de:	cmp    rdi,rax
  40f2e1:	je     40f2f8 <__swc_fn_4fa09e82_000095_63c1827b+0x198>
  40f2e3:	xor    eax,eax
  40f2e5:	add    rsp,0x120
  40f2ec:	pop    r15
  40f2ee:	pop    r14
  40f2f0:	pop    r13
  40f2f2:	pop    r12
  40f2f4:	pop    rdi
  40f2f5:	pop    rsi
  40f2f6:	pop    rbx
  40f2f7:	ret
  40f2f8:	test   rsi,rsi
  40f2fb:	je     40f302 <__swc_fn_4fa09e82_000095_63c1827b+0x1a2>
  40f2fd:	test   r12,r12
  40f300:	jne    40f31a <__swc_fn_4fa09e82_000095_63c1827b+0x1ba>
  40f302:	mov    eax,0x1
  40f307:	add    rsp,0x120
  40f30e:	pop    r15
  40f310:	pop    r14
  40f312:	pop    r13
  40f314:	pop    r12
  40f316:	pop    rdi
  40f317:	pop    rsi
  40f318:	pop    rbx
  40f319:	ret
  40f31a:	xor    r13d,r13d
  40f31d:	test   rdi,rdi
  40f320:	jbe    40f457 <__swc_fn_4fa09e82_000095_63c1827b+0x2f7>
  40f326:	lea    r14,[rsp+0x78]
  40f32b:	lea    r15,[rsp+0xb8]
  40f333:	cs nop WORD PTR [rax+rax*1+0x0]
  40f33d:	cs nop WORD PTR [rax+rax*1+0x0]
  40f347:	nop    WORD PTR [rax+rax*1+0x0]
  40f350:	lea    rax,[r13*8+0x0]
  40f358:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40f35d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40f363:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  40f369:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40f372:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  40f378:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40f381:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  40f387:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40f390:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  40f396:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40f39f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  40f3a6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  40f3af:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  40f3b6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  40f3bf:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  40f3c6:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40f3cf:	xor    al,al
  40f3d1:	rex test BYTE PTR [rsp+0xb0],0x1
  40f3da:	je     40f3e1 <__swc_fn_4fa09e82_000095_63c1827b+0x281>
  40f3dc:	mov    eax,0x1
  40f3e1:	rex test BYTE PTR [rsp+0xf0],0x1
  40f3ea:	je     40f3f1 <__swc_fn_4fa09e82_000095_63c1827b+0x291>
  40f3ec:	mov    eax,0x1
  40f3f1:	test   al,al
  40f3f3:	jne    40f419 <__swc_fn_4fa09e82_000095_63c1827b+0x2b9>
  40f3f5:	mov    rcx,r14
  40f3f8:	mov    rdx,r15
  40f3fb:	call   40a230 <__swc_fn_4fa09e82_000153_6fb05988>
  40f400:	test   al,al
  40f402:	jne    40f419 <__swc_fn_4fa09e82_000095_63c1827b+0x2b9>
  40f404:	xor    eax,eax
  40f406:	add    rsp,0x120
  40f40d:	pop    r15
  40f40f:	pop    r14
  40f411:	pop    r13
  40f413:	pop    r12
  40f415:	pop    rdi
  40f416:	pop    rsi
  40f417:	pop    rbx
  40f418:	ret
  40f419:	mov    rcx,QWORD PTR [rsp+0x88]
  40f421:	mov    rdx,QWORD PTR [rsp+0xc8]
  40f429:	mov    r8d,ebx
  40f42c:	call   40f160 <__swc_fn_4fa09e82_000095_63c1827b>
  40f431:	test   al,al
  40f433:	jne    40f44a <__swc_fn_4fa09e82_000095_63c1827b+0x2ea>
  40f435:	xor    eax,eax
  40f437:	add    rsp,0x120
  40f43e:	pop    r15
  40f440:	pop    r14
  40f442:	pop    r13
  40f444:	pop    r12
  40f446:	pop    rdi
  40f447:	pop    rsi
  40f448:	pop    rbx
  40f449:	ret
  40f44a:	add    r13,0x1
  40f44e:	cmp    r13,rdi
  40f451:	jb     40f350 <__swc_fn_4fa09e82_000095_63c1827b+0x1f0>
  40f457:	mov    eax,0x1
  40f45c:	add    rsp,0x120
  40f463:	pop    r15
  40f465:	pop    r14
  40f467:	pop    r13
  40f469:	pop    r12
  40f46b:	pop    rdi
  40f46c:	pop    rsi
  40f46d:	pop    rbx
  40f46e:	ret
  40f46f:	test   bl,0x2
  40f472:	je     40f494 <__swc_fn_4fa09e82_000095_63c1827b+0x334>
  40f474:	lea    rcx,[rdi+0x10]
  40f478:	lea    rdx,[rax+0x10]
  40f47c:	call   40a230 <__swc_fn_4fa09e82_000153_6fb05988>
  40f481:	add    rsp,0x120
  40f488:	pop    r15
  40f48a:	pop    r14
  40f48c:	pop    r13
  40f48e:	pop    r12
  40f490:	pop    rdi
  40f491:	pop    rsi
  40f492:	pop    rbx
  40f493:	ret
  40f494:	mov    rcx,rdi
  40f497:	mov    rdx,rax
  40f49a:	call   40a230 <__swc_fn_4fa09e82_000153_6fb05988>
  40f49f:	add    rsp,0x120
  40f4a6:	pop    r15
  40f4a8:	pop    r14
  40f4aa:	pop    r13
  40f4ac:	pop    r12
  40f4ae:	pop    rdi
  40f4af:	pop    rsi
  40f4b0:	pop    rbx
  40f4b1:	ret
	...

000000000040f4c0 <__swc_fn_4fa09e82_000098_4185993f>:
  40f4c0:	push   rbx
  40f4c1:	mov    rbx,rcx
  40f4c4:	call   409250 <__swc_fn_4fa09e82_000096_ad13d15c>
  40f4c9:	movzx  r11d,al
  40f4cd:	mov    r8b,r11b
  40f4d0:	test   r8b,r8b
  40f4d3:	jne    40f4ed <__swc_fn_4fa09e82_000098_4185993f+0x2d>
  40f4d5:	mov    r11d,0x1
  40f4db:	mov    r10,rbx
  40f4de:	mov    r9,r11
  40f4e1:	and    r10,r11
  40f4e4:	test   r10,r10
  40f4e7:	setne  dl
  40f4ea:	mov    r8b,dl
  40f4ed:	mov    r10b,r8b
  40f4f0:	test   r10b,r10b
  40f4f3:	je     40f4f7 <__swc_fn_4fa09e82_000098_4185993f+0x37>
  40f4f5:	pop    rbx
  40f4f6:	ret
  40f4f7:	call   410900 <__swc_fn_4fa09e82_000143_519fdf94>
  40f4fc:	movzx  r10d,al
  40f500:	test   r10b,r10b
  40f503:	je     40f507 <__swc_fn_4fa09e82_000098_4185993f+0x47>
  40f505:	pop    rbx
  40f506:	ret
  40f507:	lea    r10,[rip+0x3dda]        # 4132e8 <__swc_rdata_base_4fa09e82+0x1d8>
  40f50e:	mov    rax,r10
  40f511:	mov    rcx,rax
  40f514:	call   410430 <__swc_fn_4fa09e82_000122_2648f149>
  40f519:	call   40d0e0 <__swc_fn_4fa09e82_000124_be2e2f68>
  40f51e:	pop    rbx
  40f51f:	ret

000000000040f520 <__swc_fn_4fa09e82_000101_d4bdcaa4>:
  40f520:	push   rbx
  40f521:	sub    rsp,0x70
  40f525:	vxorps xmm0,xmm0,xmm0
  40f529:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40f52f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40f535:	vzeroupper
  40f538:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40f53e:	mov    QWORD PTR [rsp+0x48],rdx
  40f543:	mov    rax,r8
  40f546:	cmp    r8,0x1
  40f54a:	mov    edx,0x1
  40f54f:	cmovb  rax,rdx
  40f553:	mov    QWORD PTR [rsp+0x50],rax
  40f558:	mov    rbx,QWORD PTR [rcx+0x8]
  40f55c:	mov    rbx,QWORD PTR [rbx+0x18]
  40f560:	mov    rcx,QWORD PTR [rcx]
  40f563:	lea    rdx,[rsp+0x8]
  40f568:	call   rbx
  40f56a:	add    rsp,0x70
  40f56e:	pop    rbx
  40f56f:	ret

000000000040f570 <__swc_fn_4fa09e82_000104_2fdd2c61>:
  40f570:	push   rbx
  40f571:	push   rsi
  40f572:	push   rdi
  40f573:	sub    rsp,0x30
  40f577:	mov    rbx,rcx
  40f57a:	test   rcx,rcx
  40f57d:	je     40f592 <__swc_fn_4fa09e82_000104_2fdd2c61+0x22>
  40f57f:	mov    rcx,rbx
  40f582:	mov    edx,0x1
  40f587:	call   40edc0 <__swc_fn_4fa09e82_000083_63a67586>
  40f58c:	cmp    rax,0x1
  40f590:	je     40f59a <__swc_fn_4fa09e82_000104_2fdd2c61+0x2a>
  40f592:	add    rsp,0x30
  40f596:	pop    rdi
  40f597:	pop    rsi
  40f598:	pop    rbx
  40f599:	ret
  40f59a:	lea    rsi,[rsp+0x8]
  40f59f:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f5a4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f5aa:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  40f5af:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f5b5:	mov    rax,QWORD PTR [rsp+0x20]
  40f5ba:	test   rax,rax
  40f5bd:	je     40f5d3 <__swc_fn_4fa09e82_000104_2fdd2c61+0x63>
  40f5bf:	test   DWORD PTR [rax+0x28],0x400000
  40f5c6:	je     40f5d3 <__swc_fn_4fa09e82_000104_2fdd2c61+0x63>
  40f5c8:	mov    rcx,QWORD PTR [rax+0x30]
  40f5cc:	test   rcx,rcx
  40f5cf:	cmovne rax,rcx
  40f5d3:	mov    edi,DWORD PTR [rax+0x20]
  40f5d6:	lea    rcx,[rsp+0x18]
  40f5db:	call   409430 <__swc_fn_4fa09e82_000105_3c3b96fb>
  40f5e0:	mov    rcx,rsi
  40f5e3:	mov    rdx,QWORD PTR [rsp+0x18]
  40f5e8:	mov    r8,rdi
  40f5eb:	call   40f520 <__swc_fn_4fa09e82_000101_d4bdcaa4>
  40f5f0:	mov    rcx,QWORD PTR [rbx+0x28]
  40f5f4:	call   40c800 <__swc_fn_4fa09e82_000103_e34f54dc>
  40f5f9:	mov    rcx,rsi
  40f5fc:	mov    rdx,rbx
  40f5ff:	mov    r8d,0x30
  40f605:	call   40f520 <__swc_fn_4fa09e82_000101_d4bdcaa4>
  40f60a:	add    rsp,0x30
  40f60e:	pop    rdi
  40f60f:	pop    rsi
  40f610:	pop    rbx
  40f611:	ret
	...

000000000040f620 <__swc_fn_4fa09e82_000107_ffe51047>:
  40f620:	push   rbp
  40f621:	push   rbx
  40f622:	push   rsi
  40f623:	push   rdi
  40f624:	push   r12
  40f626:	push   r13
  40f628:	push   r14
  40f62a:	push   r15
  40f62c:	sub    rsp,0x500
  40f633:	mov    rbp,rsp
  40f636:	mov    rbx,rsp
  40f639:	mov    rsi,rdx
  40f63c:	mov    rdi,rcx
  40f63f:	mov    rcx,QWORD PTR [rip+0x149fa]        # 424040 <__swc_bss_base_4fa09e82>
  40f646:	test   rcx,rcx
  40f649:	jne    40f663 <__swc_fn_4fa09e82_000107_ffe51047+0x43>
  40f64b:	sub    rsp,0x8
  40f64f:	call   40a620 <__swc_fn_4fa09e82_000171_994c8876>
  40f654:	add    rsp,0x8
  40f658:	lea    rcx,[rax+0x1]
  40f65c:	mov    QWORD PTR [rip+0x149dd],rcx        # 424040 <__swc_bss_base_4fa09e82>
  40f663:	dec    rcx
  40f666:	sub    rsp,0x8
  40f66a:	call   4121e0 <__swc_fn_4fa09e82_000173_360af05d>
  40f66f:	add    rsp,0x8
  40f673:	mov    r12,rax
  40f676:	mov    QWORD PTR [rsp+0x4f0],rax
  40f67e:	lea    rax,[rip+0x3da3]        # 413428 <__swc_rdata_base_4fa09e82+0x318>
  40f685:	sub    rsp,0x20
  40f689:	mov    rcx,rsp
  40f68c:	mov    QWORD PTR [rcx],rax
  40f68f:	lea    r13,[rip+0x3a9a]        # 413130 <__swc_rdata_base_4fa09e82+0x20>
  40f696:	mov    QWORD PTR [rcx+0x8],r13
  40f69a:	mov    QWORD PTR [rcx+0x10],rsp
  40f69e:	mov    QWORD PTR [rcx+0x18],0x1
  40f6a6:	lea    rcx,[rsp+0x10]
  40f6ab:	sub    rsp,0x8
  40f6af:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40f6b4:	add    rsp,0x8
  40f6b8:	add    rsp,0x20
  40f6bc:	lea    rax,[rip+0x3d75]        # 413438 <__swc_rdata_base_4fa09e82+0x328>
  40f6c3:	sub    rsp,0x20
  40f6c7:	mov    rcx,rsp
  40f6ca:	mov    QWORD PTR [rcx],rax
  40f6cd:	mov    QWORD PTR [rcx+0x8],r13
  40f6d1:	mov    QWORD PTR [rcx+0x10],rsp
  40f6d5:	mov    QWORD PTR [rcx+0x18],0x1
  40f6dd:	lea    rcx,[rsp+0x10]
  40f6e2:	sub    rsp,0x8
  40f6e6:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40f6eb:	add    rsp,0x8
  40f6ef:	add    rsp,0x20
  40f6f3:	lea    r14,[rip+0x3a26]        # 413120 <__swc_rdata_base_4fa09e82+0x10>
  40f6fa:	sub    rsp,0x50
  40f6fe:	mov    rax,rsp
  40f701:	vmovups xmm0,XMMWORD PTR [rip+0x3e67]        # 413570 <__swc_rdata_base_4fa09e82+0x460>
  40f709:	vmovups XMMWORD PTR [rax],xmm0
  40f70d:	mov    QWORD PTR [rax+0x10],rsp
  40f711:	mov    QWORD PTR [rax+0x18],r13
  40f715:	mov    QWORD PTR [rax+0x20],rdi
  40f719:	lea    rdi,[rip+0x3d28]        # 413448 <__swc_rdata_base_4fa09e82+0x338>
  40f720:	mov    QWORD PTR [rax+0x28],rdi
  40f724:	mov    QWORD PTR [rax+0x30],r14
  40f728:	mov    QWORD PTR [rax+0x38],r13
  40f72c:	lea    rcx,[rsp+0x10]
  40f731:	mov    QWORD PTR [rax+0x40],rcx
  40f735:	mov    QWORD PTR [rax+0x48],0x3
  40f73d:	lea    rcx,[rsp+0x40]
  40f742:	sub    rsp,0x8
  40f746:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40f74b:	add    rsp,0x8
  40f74f:	add    rsp,0x50
  40f753:	lea    rax,[rip+0x3d36]        # 413490 <__swc_rdata_base_4fa09e82+0x380>
  40f75a:	sub    rsp,0x20
  40f75e:	mov    rcx,rsp
  40f761:	mov    QWORD PTR [rcx],rax
  40f764:	mov    QWORD PTR [rcx+0x8],r13
  40f768:	mov    QWORD PTR [rcx+0x10],rsp
  40f76c:	mov    QWORD PTR [rcx+0x18],0x1
  40f774:	lea    rcx,[rsp+0x10]
  40f779:	sub    rsp,0x8
  40f77d:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40f782:	add    rsp,0x8
  40f786:	add    rsp,0x20
  40f78a:	mov    eax,DWORD PTR [rsi+0x20]
  40f78d:	mov    ecx,DWORD PTR [rsi+0x24]
  40f790:	sub    rsp,0xa0
  40f797:	mov    rdx,rsp
  40f79a:	mov    QWORD PTR [rdx+0x30],rsi
  40f79e:	mov    QWORD PTR [rdx+0x38],rdi
  40f7a2:	vmovups xmm0,XMMWORD PTR [rip+0x3d5e]        # 413508 <__swc_rdata_base_4fa09e82+0x3f8>
  40f7aa:	vmovups XMMWORD PTR [rdx],xmm0
  40f7ae:	mov    QWORD PTR [rdx+0x40],rsp
  40f7b2:	mov    QWORD PTR [rdx+0x48],r13
  40f7b6:	mov    DWORD PTR [rdx+0x10],eax
  40f7b9:	lea    rax,[rsp+0x10]
  40f7be:	mov    QWORD PTR [rdx+0x50],rax
  40f7c2:	lea    rax,[rip+0x3cd7]        # 4134a0 <__swc_rdata_base_4fa09e82+0x390>
  40f7c9:	mov    QWORD PTR [rdx+0x58],rax
  40f7cd:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  40f7d2:	lea    r8,[rsp+0x18]
  40f7d7:	mov    QWORD PTR [rdx+0x60],r8
  40f7db:	mov    QWORD PTR [rdx+0x68],r13
  40f7df:	mov    DWORD PTR [rdx+0x28],ecx
  40f7e2:	lea    rcx,[rdx+0x28]
  40f7e6:	mov    QWORD PTR [rdx+0x70],rcx
  40f7ea:	mov    QWORD PTR [rdx+0x78],rax
  40f7ee:	mov    QWORD PTR [rdx+0x80],r14
  40f7f5:	mov    QWORD PTR [rdx+0x88],r13
  40f7fc:	lea    rax,[rdx+0x30]
  40f800:	mov    QWORD PTR [rdx+0x90],rax
  40f807:	mov    QWORD PTR [rdx+0x98],0x6
  40f812:	lea    rcx,[rdx+0x90]
  40f819:	sub    rsp,0x8
  40f81d:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40f822:	add    rsp,0x8
  40f826:	add    rsp,0xa0
  40f82d:	sub    rsp,0x20
  40f831:	mov    rax,rsp
  40f834:	mov    QWORD PTR [rax],r14
  40f837:	mov    QWORD PTR [rax+0x8],r13
  40f83b:	mov    QWORD PTR [rax+0x10],rsp
  40f83f:	mov    QWORD PTR [rax+0x18],0x1
  40f847:	lea    rcx,[rsp+0x10]
  40f84c:	sub    rsp,0x8
  40f850:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40f855:	add    rsp,0x8
  40f859:	add    rsp,0x20
  40f85d:	mov    eax,DWORD PTR [r12+0x9ac]
  40f865:	test   eax,eax
  40f867:	je     40faa0 <__swc_fn_4fa09e82_000107_ffe51047+0x480>
  40f86d:	lea    rax,[rip+0x3c74]        # 4134e8 <__swc_rdata_base_4fa09e82+0x3d8>
  40f874:	sub    rsp,0x20
  40f878:	mov    rcx,rsp
  40f87b:	mov    QWORD PTR [rcx],rax
  40f87e:	mov    QWORD PTR [rcx+0x8],r13
  40f882:	mov    QWORD PTR [rcx+0x10],rsp
  40f886:	mov    QWORD PTR [rcx+0x18],0x1
  40f88e:	lea    rcx,[rsp+0x10]
  40f893:	sub    rsp,0x8
  40f897:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40f89c:	add    rsp,0x8
  40f8a0:	add    rsp,0x20
  40f8a4:	mov    eax,DWORD PTR [r12+0x9ac]
  40f8ac:	dec    eax
  40f8ae:	mov    esi,eax
  40f8b0:	test   esi,esi
  40f8b2:	jl     40fa70 <__swc_fn_4fa09e82_000107_ffe51047+0x450>
  40f8b8:	jmp    40f8c4 <__swc_fn_4fa09e82_000107_ffe51047+0x2a4>
  40f8ba:	nop    WORD PTR [rax+rax*1+0x0]
  40f8c0:	dec    esi
  40f8c2:	jmp    40f8b0 <__swc_fn_4fa09e82_000107_ffe51047+0x290>
  40f8c4:	lea    rax,[rip+0x3c2d]        # 4134f8 <__swc_rdata_base_4fa09e82+0x3e8>
  40f8cb:	sub    rsp,0x20
  40f8cf:	mov    rcx,rsp
  40f8d2:	mov    QWORD PTR [rcx],rax
  40f8d5:	mov    QWORD PTR [rcx+0x8],r13
  40f8d9:	mov    QWORD PTR [rcx+0x10],rsp
  40f8dd:	mov    QWORD PTR [rcx+0x18],0x1
  40f8e5:	lea    rcx,[rsp+0x10]
  40f8ea:	sub    rsp,0x8
  40f8ee:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40f8f3:	add    rsp,0x8
  40f8f7:	add    rsp,0x20
  40f8fb:	movsxd rax,esi
  40f8fe:	imul   r15,rax,0x30
  40f902:	add    r15,r12
  40f905:	add    r15,0xf8
  40f90c:	sub    rsp,0x20
  40f910:	mov    rax,rsp
  40f913:	mov    QWORD PTR [rax],r15
  40f916:	mov    QWORD PTR [rax+0x8],rdi
  40f91a:	mov    QWORD PTR [rax+0x10],rsp
  40f91e:	mov    QWORD PTR [rax+0x18],0x1
  40f926:	lea    rcx,[rsp+0x10]
  40f92b:	sub    rsp,0x8
  40f92f:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40f934:	add    rsp,0x8
  40f938:	add    rsp,0x20
  40f93c:	mov    QWORD PTR [rsp+0x4f8],rsi
  40f944:	lea    rsi,[rip+0x3bbd]        # 413508 <__swc_rdata_base_4fa09e82+0x3f8>
  40f94b:	sub    rsp,0x20
  40f94f:	mov    rax,rsp
  40f952:	mov    QWORD PTR [rax],rsi
  40f955:	mov    QWORD PTR [rax+0x8],r13
  40f959:	mov    QWORD PTR [rax+0x10],rsp
  40f95d:	mov    QWORD PTR [rax+0x18],0x1
  40f965:	lea    rcx,[rsp+0x10]
  40f96a:	sub    rsp,0x8
  40f96e:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40f973:	add    rsp,0x8
  40f977:	add    rsp,0x20
  40f97b:	sub    rsp,0x30
  40f97f:	mov    rax,rsp
  40f982:	mov    ecx,DWORD PTR [r15+0x20]
  40f986:	mov    QWORD PTR [rax],rcx
  40f989:	mov    QWORD PTR [rax+0x8],rsp
  40f98d:	lea    rdi,[rip+0x3b84]        # 413518 <__swc_rdata_base_4fa09e82+0x408>
  40f994:	mov    QWORD PTR [rax+0x10],rdi
  40f998:	lea    rcx,[rsp+0x8]
  40f99d:	mov    QWORD PTR [rax+0x18],rcx
  40f9a1:	mov    QWORD PTR [rax+0x20],0x1
  40f9a9:	lea    rcx,[rsp+0x18]
  40f9ae:	sub    rsp,0x8
  40f9b2:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40f9b7:	add    rsp,0x8
  40f9bb:	add    rsp,0x30
  40f9bf:	sub    rsp,0x20
  40f9c3:	mov    rax,rsp
  40f9c6:	mov    QWORD PTR [rax],rsi
  40f9c9:	mov    QWORD PTR [rax+0x8],r13
  40f9cd:	mov    QWORD PTR [rax+0x10],rsp
  40f9d1:	mov    QWORD PTR [rax+0x18],0x1
  40f9d9:	lea    rcx,[rsp+0x10]
  40f9de:	sub    rsp,0x8
  40f9e2:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40f9e7:	add    rsp,0x8
  40f9eb:	add    rsp,0x20
  40f9ef:	sub    rsp,0x30
  40f9f3:	mov    rax,rsp
  40f9f6:	mov    ecx,DWORD PTR [r15+0x24]
  40f9fa:	mov    QWORD PTR [rax],rcx
  40f9fd:	mov    QWORD PTR [rax+0x8],rsp
  40fa01:	mov    QWORD PTR [rax+0x10],rdi
  40fa05:	lea    rcx,[rsp+0x8]
  40fa0a:	mov    QWORD PTR [rax+0x18],rcx
  40fa0e:	mov    QWORD PTR [rax+0x20],0x1
  40fa16:	lea    rcx,[rsp+0x18]
  40fa1b:	sub    rsp,0x8
  40fa1f:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40fa24:	add    rsp,0x8
  40fa28:	add    rsp,0x30
  40fa2c:	sub    rsp,0x20
  40fa30:	mov    rax,rsp
  40fa33:	mov    QWORD PTR [rax],r14
  40fa36:	mov    QWORD PTR [rax+0x8],r13
  40fa3a:	mov    QWORD PTR [rax+0x10],rsp
  40fa3e:	mov    QWORD PTR [rax+0x18],0x1
  40fa46:	lea    rcx,[rsp+0x10]
  40fa4b:	sub    rsp,0x8
  40fa4f:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40fa54:	add    rsp,0x8
  40fa58:	add    rsp,0x20
  40fa5c:	lea    rdi,[rip+0x39e5]        # 413448 <__swc_rdata_base_4fa09e82+0x338>
  40fa63:	mov    rsi,QWORD PTR [rsp+0x4f8]
  40fa6b:	jmp    40f8c0 <__swc_fn_4fa09e82_000107_ffe51047+0x2a0>
  40fa70:	sub    rsp,0x20
  40fa74:	mov    rax,rsp
  40fa77:	mov    QWORD PTR [rax],r14
  40fa7a:	mov    QWORD PTR [rax+0x8],r13
  40fa7e:	mov    QWORD PTR [rax+0x10],rsp
  40fa82:	mov    QWORD PTR [rax+0x18],0x1
  40fa8a:	lea    rcx,[rsp+0x10]
  40fa8f:	sub    rsp,0x8
  40fa93:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40fa98:	add    rsp,0x8
  40fa9c:	add    rsp,0x20
  40faa0:	lea    rax,[rbx+0x28]
  40faa4:	mov    rcx,rax
  40faa7:	mov    QWORD PTR [rbx+0x28],0x0
  40faaf:	mov    QWORD PTR [rbx+0x30],0x0
  40fab7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  40fabc:	add    rcx,0x10
  40fac0:	mov    edx,0x1f
  40fac5:	cs nop WORD PTR [rax+rax*1+0x0]
  40facf:	nop
  40fad0:	vmovups XMMWORD PTR [rcx],xmm0
  40fad4:	add    rcx,0x10
  40fad8:	sub    rdx,0x1
  40fadc:	jne    40fad0 <__swc_fn_4fa09e82_000107_ffe51047+0x4b0>
  40fade:	lea    rsi,[rbx+0x228]
  40fae5:	xor    ecx,ecx
  40fae7:	cs nop WORD PTR [rax+rax*1+0x0]
  40faf1:	cs nop WORD PTR [rax+rax*1+0x0]
  40fafb:	nop    DWORD PTR [rax+rax*1+0x0]
  40fb00:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  40fb05:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  40fb0a:	add    rcx,0x10
  40fb0e:	cmp    rcx,0x200
  40fb15:	jne    40fb00 <__swc_fn_4fa09e82_000107_ffe51047+0x4e0>
  40fb17:	mov    eax,DWORD PTR [r12+0xbc8]
  40fb1f:	lea    rcx,[r12+0x9c8]
  40fb27:	mov    QWORD PTR [rbx+0x428],rcx
  40fb2e:	mov    QWORD PTR [rbx+0x430],rax
  40fb35:	lea    rdi,[rbx+0x438]
  40fb3c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  40fb44:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40fb4c:	mov    eax,DWORD PTR [r12+0xbc8]
  40fb54:	test   eax,eax
  40fb56:	jne    40fba3 <__swc_fn_4fa09e82_000107_ffe51047+0x583>
  40fb58:	lea    rax,[rbx+0x448]
  40fb5f:	mov    QWORD PTR [rbx+0x448],rsi
  40fb66:	mov    QWORD PTR [rax+0x8],0x40
  40fb6e:	mov    ecx,0x1
  40fb73:	mov    rdx,rax
  40fb76:	sub    rsp,0x8
  40fb7a:	call   410540 <__swc_fn_4fa09e82_000125_4f256d58>
  40fb7f:	add    rsp,0x8
  40fb83:	mov    QWORD PTR [rbx+0x460],rsi
  40fb8a:	mov    ecx,eax
  40fb8c:	mov    QWORD PTR [rbx+0x468],rcx
  40fb93:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  40fb9b:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40fba3:	mov    rsi,QWORD PTR [rbx+0x438]
  40fbaa:	mov    rax,QWORD PTR [rbx+0x440]
  40fbb1:	mov    r15,rax
  40fbb4:	xor    r12d,r12d
  40fbb7:	test   r15,r15
  40fbba:	je     40fc70 <__swc_fn_4fa09e82_000107_ffe51047+0x650>
  40fbc0:	mov    rax,QWORD PTR [rsi+r12*8]
  40fbc4:	test   rax,rax
  40fbc7:	je     40fbe6 <__swc_fn_4fa09e82_000107_ffe51047+0x5c6>
  40fbc9:	lea    rcx,[rbx+0x4b8]
  40fbd0:	mov    rdx,rax
  40fbd3:	sub    rsp,0x8
  40fbd7:	call   40a390 <__swc_fn_4fa09e82_000168_cc119975>
  40fbdc:	add    rsp,0x8
  40fbe0:	mov    al,BYTE PTR [rax]
  40fbe2:	test   al,al
  40fbe4:	jne    40fbf2 <__swc_fn_4fa09e82_000107_ffe51047+0x5d2>
  40fbe6:	add    r12,0x1
  40fbea:	sub    r15,0x1
  40fbee:	jne    40fbc0 <__swc_fn_4fa09e82_000107_ffe51047+0x5a0>
  40fbf0:	jmp    40fc70 <__swc_fn_4fa09e82_000107_ffe51047+0x650>
  40fbf2:	lea    rax,[rip+0x3967]        # 413560 <__swc_rdata_base_4fa09e82+0x450>
  40fbf9:	sub    rsp,0x20
  40fbfd:	mov    rcx,rsp
  40fc00:	mov    QWORD PTR [rcx],rax
  40fc03:	mov    QWORD PTR [rcx+0x8],r13
  40fc07:	mov    QWORD PTR [rcx+0x10],rsp
  40fc0b:	mov    QWORD PTR [rcx+0x18],0x1
  40fc13:	lea    rcx,[rsp+0x10]
  40fc18:	sub    rsp,0x8
  40fc1c:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40fc21:	add    rsp,0x8
  40fc25:	add    rsp,0x20
  40fc29:	mov    rcx,rdi
  40fc2c:	xor    edx,edx
  40fc2e:	mov    al,0x1
  40fc30:	mov    r8,rax
  40fc33:	sub    rsp,0x8
  40fc37:	call   40d980 <__swc_fn_4fa09e82_000169_bcc835b8>
  40fc3c:	add    rsp,0x8
  40fc40:	sub    rsp,0x20
  40fc44:	mov    rax,rsp
  40fc47:	mov    QWORD PTR [rax],r14
  40fc4a:	mov    QWORD PTR [rax+0x8],r13
  40fc4e:	mov    QWORD PTR [rax+0x10],rsp
  40fc52:	mov    QWORD PTR [rax+0x18],0x1
  40fc5a:	lea    rcx,[rsp+0x10]
  40fc5f:	sub    rsp,0x8
  40fc63:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40fc68:	add    rsp,0x8
  40fc6c:	add    rsp,0x20
  40fc70:	mov    r12,QWORD PTR [rsp+0x4f0]
  40fc78:	mov    DWORD PTR [r12+0xbc8],0x0
  40fc84:	add    rsp,0x500
  40fc8b:	pop    r15
  40fc8d:	pop    r14
  40fc8f:	pop    r13
  40fc91:	pop    r12
  40fc93:	pop    rdi
  40fc94:	pop    rsi
  40fc95:	pop    rbx
  40fc96:	pop    rbp
  40fc97:	ret
	...

000000000040fca0 <__swc_fn_4fa09e82_000110_a342ead8>:
  40fca0:	test   r8,r8
  40fca3:	jne    40fca6 <__swc_fn_4fa09e82_000110_a342ead8+0x6>
  40fca5:	ret
  40fca6:	xor    eax,eax
  40fca8:	movzx  r9d,dl
  40fcac:	movabs r10,0x101010101010101
  40fcb6:	imul   r9,r10
  40fcba:	vmovq  xmm0,r9
  40fcbf:	vpshufd xmm0,xmm0,0x44
  40fcc4:	cs nop WORD PTR [rax+rax*1+0x0]
  40fcce:	xchg   ax,ax
  40fcd0:	mov    r10,r8
  40fcd3:	sub    r10,rax
  40fcd6:	cmp    r10,0x40
  40fcda:	jb     40fcfd <__swc_fn_4fa09e82_000110_a342ead8+0x5d>
  40fcdc:	lea    r10,[rcx+rax*1]
  40fce0:	vmovups XMMWORD PTR [r10],xmm0
  40fce5:	vmovups XMMWORD PTR [r10+0x10],xmm0
  40fceb:	vmovups XMMWORD PTR [r10+0x20],xmm0
  40fcf1:	vmovups XMMWORD PTR [r10+0x30],xmm0
  40fcf7:	lea    rax,[rax+0x40]
  40fcfb:	jmp    40fcd0 <__swc_fn_4fa09e82_000110_a342ead8+0x30>
  40fcfd:	nop    DWORD PTR [rax]
  40fd00:	mov    r10,r8
  40fd03:	sub    r10,rax
  40fd06:	cmp    r10,0x10
  40fd0a:	jb     40fd1b <__swc_fn_4fa09e82_000110_a342ead8+0x7b>
  40fd0c:	lea    r10,[rcx+rax*1]
  40fd10:	vmovups XMMWORD PTR [r10],xmm0
  40fd15:	lea    rax,[rax+0x10]
  40fd19:	jmp    40fd00 <__swc_fn_4fa09e82_000110_a342ead8+0x60>
  40fd1b:	nop    DWORD PTR [rax+rax*1+0x0]
  40fd20:	mov    r10,r8
  40fd23:	sub    r10,rax
  40fd26:	cmp    r10,0x8
  40fd2a:	jb     40fd39 <__swc_fn_4fa09e82_000110_a342ead8+0x99>
  40fd2c:	lea    r10,[rcx+rax*1]
  40fd30:	mov    QWORD PTR [r10],r9
  40fd33:	lea    rax,[rax+0x8]
  40fd37:	jmp    40fd20 <__swc_fn_4fa09e82_000110_a342ead8+0x80>
  40fd39:	cmp    rax,r8
  40fd3c:	jae    40fd4b <__swc_fn_4fa09e82_000110_a342ead8+0xab>
  40fd3e:	xchg   ax,ax
  40fd40:	mov    BYTE PTR [rcx+rax*1],dl
  40fd43:	inc    rax
  40fd46:	cmp    rax,r8
  40fd49:	jb     40fd40 <__swc_fn_4fa09e82_000110_a342ead8+0xa0>
  40fd4b:	ret
  40fd4c:	add    BYTE PTR [rax],al
	...

000000000040fd50 <__swc_fn_4fa09e82_000113_6814119b>:
  40fd50:	push   rbx
  40fd51:	push   r12
  40fd53:	push   rdi
  40fd54:	push   rsi
  40fd55:	push   r13
  40fd57:	push   r14
  40fd59:	push   r15
  40fd5b:	sub    rsp,0x170
  40fd62:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40fd6b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40fd74:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40fd7d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40fd86:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40fd8f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40fd98:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40fda1:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40fdaa:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40fdb3:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40fdbc:	mov    ebx,edx
  40fdbe:	mov    QWORD PTR [rsp+0xa8],rbx
  40fdc6:	mov    r12d,ecx
  40fdc9:	test   edx,edx
  40fdcb:	jne    40fde2 <__swc_fn_4fa09e82_000113_6814119b+0x92>
  40fdcd:	xor    eax,eax
  40fdcf:	add    rsp,0x170
  40fdd6:	pop    r15
  40fdd8:	pop    r14
  40fdda:	pop    r13
  40fddc:	pop    rsi
  40fddd:	pop    rdi
  40fdde:	pop    r12
  40fde0:	pop    rbx
  40fde1:	ret
  40fde2:	lea    rdi,[rip+0x3797]        # 413580 <__swc_rdata_base_4fa09e82+0x470>
  40fde9:	mov    esi,0x90000
  40fdee:	xor    eax,eax
  40fdf0:	call   407090 <open@plt>
  40fdf5:	mov    r13,rax
  40fdf8:	mov    QWORD PTR [rsp+0xb0],rax
  40fe00:	test   eax,eax
  40fe02:	jge    40fe0b <__swc_fn_4fa09e82_000113_6814119b+0xbb>
  40fe04:	xor    eax,eax
  40fe06:	jmp    410306 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  40fe0b:	nop    DWORD PTR [rax+rax*1+0x0]
  40fe10:	movsxd rdi,r13d
  40fe13:	mov    esi,0x2
  40fe18:	xor    eax,eax
  40fe1a:	call   407120 <flock@plt>
  40fe1f:	test   eax,eax
  40fe21:	je     40fe40 <__swc_fn_4fa09e82_000113_6814119b+0xf0>
  40fe23:	xor    eax,eax
  40fe25:	call   407130 <__errno_location@plt>
  40fe2a:	cmp    DWORD PTR [rax],0x4
  40fe2d:	je     40fe10 <__swc_fn_4fa09e82_000113_6814119b+0xc0>
  40fe2f:	movsxd rdi,r13d
  40fe32:	xor    eax,eax
  40fe34:	call   4070b0 <close@plt>
  40fe39:	xor    eax,eax
  40fe3b:	jmp    410306 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  40fe40:	lea    r14,[rsp+0x8]
  40fe45:	mov    QWORD PTR [rsp+0xb8],r14
  40fe4d:	vxorps xmm0,xmm0,xmm0
  40fe51:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fe57:	mov    QWORD PTR [rsp+0x18],0x0
  40fe60:	mov    WORD PTR [rsp+0x20],0x0
  40fe67:	mov    DWORD PTR [r14],0x67617753
  40fe6e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40fe76:	xor    eax,eax
  40fe78:	call   407010 <getpid@plt>
  40fe7d:	mov    ecx,eax
  40fe7f:	mov    eax,0x1c
  40fe84:	shrx   eax,ecx,eax
  40fe89:	and    eax,0xf
  40fe8c:	mov    rdx,QWORD PTR [rip+0x370d]        # 4135a0 <__swc_rdata_base_4fa09e82+0x490>
  40fe93:	mov    al,BYTE PTR [rdx+rax*1]
  40fe96:	rex mov BYTE PTR [rsp+0x10],al
  40fe9b:	mov    eax,0x1c
  40fea0:	shrx   eax,r12d,eax
  40fea5:	and    eax,0xf
  40fea8:	mov    al,BYTE PTR [rdx+rax*1]
  40feab:	rex mov BYTE PTR [rsp+0x19],al
  40feb0:	mov    eax,0x18
  40feb5:	shrx   eax,ecx,eax
  40feba:	and    eax,0xf
  40febd:	mov    al,BYTE PTR [rdx+rax*1]
  40fec0:	rex mov BYTE PTR [rsp+0x11],al
  40fec5:	mov    eax,0x18
  40feca:	shrx   eax,r12d,eax
  40fecf:	and    eax,0xf
  40fed2:	mov    al,BYTE PTR [rdx+rax*1]
  40fed5:	rex mov BYTE PTR [rsp+0x1a],al
  40feda:	mov    eax,0x14
  40fedf:	shrx   eax,ecx,eax
  40fee4:	and    eax,0xf
  40fee7:	mov    al,BYTE PTR [rdx+rax*1]
  40feea:	rex mov BYTE PTR [rsp+0x12],al
  40feef:	mov    eax,0x14
  40fef4:	shrx   eax,r12d,eax
  40fef9:	and    eax,0xf
  40fefc:	mov    al,BYTE PTR [rdx+rax*1]
  40feff:	rex mov BYTE PTR [rsp+0x1b],al
  40ff04:	mov    eax,0x10
  40ff09:	shrx   eax,ecx,eax
  40ff0e:	and    eax,0xf
  40ff11:	mov    al,BYTE PTR [rdx+rax*1]
  40ff14:	rex mov BYTE PTR [rsp+0x13],al
  40ff19:	mov    eax,0x10
  40ff1e:	shrx   eax,r12d,eax
  40ff23:	and    eax,0xf
  40ff26:	mov    al,BYTE PTR [rdx+rax*1]
  40ff29:	rex mov BYTE PTR [rsp+0x1c],al
  40ff2e:	mov    eax,0xc
  40ff33:	shrx   eax,ecx,eax
  40ff38:	and    eax,0xf
  40ff3b:	mov    al,BYTE PTR [rdx+rax*1]
  40ff3e:	rex mov BYTE PTR [rsp+0x14],al
  40ff43:	mov    eax,0xc
  40ff48:	shrx   eax,r12d,eax
  40ff4d:	and    eax,0xf
  40ff50:	mov    al,BYTE PTR [rdx+rax*1]
  40ff53:	rex mov BYTE PTR [rsp+0x1d],al
  40ff58:	mov    eax,0x8
  40ff5d:	shrx   eax,ecx,eax
  40ff62:	and    eax,0xf
  40ff65:	mov    al,BYTE PTR [rdx+rax*1]
  40ff68:	rex mov BYTE PTR [rsp+0x15],al
  40ff6d:	mov    eax,0x8
  40ff72:	shrx   eax,r12d,eax
  40ff77:	and    eax,0xf
  40ff7a:	mov    al,BYTE PTR [rdx+rax*1]
  40ff7d:	rex mov BYTE PTR [rsp+0x1e],al
  40ff82:	mov    eax,0x4
  40ff87:	shrx   eax,ecx,eax
  40ff8c:	and    eax,0xf
  40ff8f:	mov    al,BYTE PTR [rdx+rax*1]
  40ff92:	rex mov BYTE PTR [rsp+0x16],al
  40ff97:	mov    eax,0x4
  40ff9c:	shrx   eax,r12d,eax
  40ffa1:	and    eax,0xf
  40ffa4:	mov    al,BYTE PTR [rdx+rax*1]
  40ffa7:	rex mov BYTE PTR [rsp+0x1f],al
  40ffac:	xor    eax,eax
  40ffae:	shrx   eax,ecx,eax
  40ffb3:	and    eax,0xf
  40ffb6:	mov    al,BYTE PTR [rdx+rax*1]
  40ffb9:	rex mov BYTE PTR [rsp+0x17],al
  40ffbe:	xor    eax,eax
  40ffc0:	shrx   eax,r12d,eax
  40ffc5:	and    eax,0xf
  40ffc8:	mov    al,BYTE PTR [rdx+rax*1]
  40ffcb:	rex mov BYTE PTR [rsp+0x20],al
  40ffd0:	mov    BYTE PTR [r14+0x10],0x2e
  40ffd5:	lea    r12,[rsp+0x22]
  40ffda:	vxorps xmm0,xmm0,xmm0
  40ffde:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40ffe4:	mov    DWORD PTR [r12],0x6d656d2f
  40ffec:	mov    WORD PTR [r12+0x4],0x6466
  40fff4:	mov    BYTE PTR [r12+0x6],0x3a
  40fffa:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  410000:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  410006:	mov    rax,QWORD PTR [rsp+0x18]
  41000b:	mov    QWORD PTR [rsp+0x39],rax
  410010:	rex mov al,BYTE PTR [rsp+0x20]
  410015:	rex mov BYTE PTR [rsp+0x41],al
  41001a:	mov    DWORD PTR [r12+0x20],0x65642820
  410023:	mov    DWORD PTR [r12+0x24],0x6574656c
  41002c:	mov    WORD PTR [r12+0x28],0x2964
  410034:	lea    rdi,[rip+0x3550]        # 41358b <__swc_rdata_base_4fa09e82+0x47b>
  41003b:	xor    eax,eax
  41003d:	call   407140 <opendir@plt>
  410042:	mov    r15,rax
  410045:	test   rax,rax
  410048:	jne    41005b <__swc_fn_4fa09e82_000113_6814119b+0x30b>
  41004a:	movsxd rdi,r13d
  41004d:	xor    eax,eax
  41004f:	call   4070b0 <close@plt>
  410054:	xor    eax,eax
  410056:	jmp    410306 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  41005b:	mov    rdi,r15
  41005e:	xor    eax,eax
  410060:	call   407150 <dirfd@plt>
  410065:	lea    r14,[rsp+0x54]
  41006a:	mov    DWORD PTR [rsp+0x54],eax
  41006e:	lea    rbx,[rsp+0x58]
  410073:	cs nop WORD PTR [rax+rax*1+0x0]
  41007d:	nop    DWORD PTR [rax]
  410080:	mov    rdi,r15
  410083:	xor    eax,eax
  410085:	call   407160 <readdir@plt>
  41008a:	test   rax,rax
  41008d:	jne    4100a4 <__swc_fn_4fa09e82_000113_6814119b+0x354>
  41008f:	mov    r12,QWORD PTR [rsp+0xa8]
  410097:	mov    r13,QWORD PTR [rsp+0xb0]
  41009f:	jmp    41022a <__swc_fn_4fa09e82_000113_6814119b+0x4da>
  4100a4:	vxorps xmm0,xmm0,xmm0
  4100a8:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  4100ae:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  4100b4:	vzeroupper
  4100b7:	lea    r13,[rax+0x13]
  4100bb:	mov    rax,r14
  4100be:	movsxd rdi,DWORD PTR [rax]
  4100c1:	mov    rsi,r13
  4100c4:	mov    rdx,rbx
  4100c7:	mov    ecx,0x40
  4100cc:	xor    eax,eax
  4100ce:	call   407170 <readlinkat@plt>
  4100d3:	cmp    rax,0x2a
  4100d7:	jne    410080 <__swc_fn_4fa09e82_000113_6814119b+0x330>
  4100d9:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  4100df:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  4100e5:	vptest xmm0,xmm0
  4100ea:	jne    41011a <__swc_fn_4fa09e82_000113_6814119b+0x3ca>
  4100ec:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  4100f2:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  4100f8:	vptest xmm0,xmm0
  4100fd:	jne    41011a <__swc_fn_4fa09e82_000113_6814119b+0x3ca>
  4100ff:	mov    rcx,QWORD PTR [rsp+0x42]
  410104:	cmp    QWORD PTR [rsp+0x78],rcx
  410109:	jne    41011a <__swc_fn_4fa09e82_000113_6814119b+0x3ca>
  41010b:	mov    cx,WORD PTR [rsp+0x4a]
  410110:	cmp    WORD PTR [rsp+0x80],cx
  410118:	je     410144 <__swc_fn_4fa09e82_000113_6814119b+0x3f4>
  41011a:	mov    rax,rbx
  41011d:	mov    rcx,r12
  410120:	movzx  edx,BYTE PTR [rax]
  410123:	movzx  r8d,BYTE PTR [rcx]
  410127:	cmp    rdx,r8
  41012a:	jne    410136 <__swc_fn_4fa09e82_000113_6814119b+0x3e6>
  41012c:	add    rax,0x1
  410130:	add    rcx,0x1
  410134:	jmp    410120 <__swc_fn_4fa09e82_000113_6814119b+0x3d0>
  410136:	mov    rax,rdx
  410139:	sub    rax,r8
  41013c:	test   eax,eax
  41013e:	jne    410080 <__swc_fn_4fa09e82_000113_6814119b+0x330>
  410144:	movsxd rdi,DWORD PTR [r14]
  410147:	mov    rsi,r13
  41014a:	mov    edx,0x80002
  41014f:	xor    eax,eax
  410151:	call   407180 <openat@plt>
  410156:	lea    rbx,[rsp+0x98]
  41015e:	mov    DWORD PTR [rsp+0x98],eax
  410165:	test   eax,eax
  410167:	mov    r13,QWORD PTR [rsp+0xb0]
  41016f:	jge    410194 <__swc_fn_4fa09e82_000113_6814119b+0x444>
  410171:	mov    rdi,r15
  410174:	xor    eax,eax
  410176:	call   407190 <closedir@plt>
  41017b:	mov    r13,QWORD PTR [rsp+0xb0]
  410183:	movsxd rdi,r13d
  410186:	xor    eax,eax
  410188:	call   4070b0 <close@plt>
  41018d:	xor    eax,eax
  41018f:	jmp    410306 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  410194:	mov    rax,rbx
  410197:	movsxd rdi,DWORD PTR [rax]
  41019a:	xor    esi,esi
  41019c:	mov    edx,0x2
  4101a1:	xor    eax,eax
  4101a3:	call   4070a0 <lseek@plt>
  4101a8:	mov    r12,QWORD PTR [rsp+0xa8]
  4101b0:	cmp    rax,r12
  4101b3:	je     4101da <__swc_fn_4fa09e82_000113_6814119b+0x48a>
  4101b5:	movsxd rdi,DWORD PTR [rbx]
  4101b8:	xor    eax,eax
  4101ba:	call   4070b0 <close@plt>
  4101bf:	mov    rdi,r15
  4101c2:	xor    eax,eax
  4101c4:	call   407190 <closedir@plt>
  4101c9:	movsxd rdi,r13d
  4101cc:	xor    eax,eax
  4101ce:	call   4070b0 <close@plt>
  4101d3:	xor    eax,eax
  4101d5:	jmp    410306 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  4101da:	xor    edi,edi
  4101dc:	mov    rsi,r12
  4101df:	mov    edx,0x3
  4101e4:	mov    ecx,0x1
  4101e9:	mov    rax,rbx
  4101ec:	movsxd r8,DWORD PTR [rax]
  4101ef:	xor    r9d,r9d
  4101f2:	xor    eax,eax
  4101f4:	call   4070c0 <mmap@plt>
  4101f9:	xor    r12d,r12d
  4101fc:	cmp    rax,0xffffffffffffffff
  410200:	cmovne r12,rax
  410204:	movsxd rdi,DWORD PTR [rbx]
  410207:	xor    eax,eax
  410209:	call   4070b0 <close@plt>
  41020e:	mov    rdi,r15
  410211:	xor    eax,eax
  410213:	call   407190 <closedir@plt>
  410218:	movsxd rdi,r13d
  41021b:	xor    eax,eax
  41021d:	call   4070b0 <close@plt>
  410222:	mov    rax,r12
  410225:	jmp    410306 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  41022a:	mov    r14,QWORD PTR [rsp+0xb8]
  410232:	mov    rdi,r14
  410235:	mov    esi,0x1
  41023a:	xor    eax,eax
  41023c:	call   4071a0 <memfd_create@plt>
  410241:	lea    rbx,[rsp+0x9c]
  410249:	mov    DWORD PTR [rsp+0x9c],eax
  410250:	test   eax,eax
  410252:	jge    41026f <__swc_fn_4fa09e82_000113_6814119b+0x51f>
  410254:	mov    rdi,r15
  410257:	xor    eax,eax
  410259:	call   407190 <closedir@plt>
  41025e:	movsxd rdi,r13d
  410261:	xor    eax,eax
  410263:	call   4070b0 <close@plt>
  410268:	xor    eax,eax
  41026a:	jmp    410306 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  41026f:	mov    rax,rbx
  410272:	movsxd rdi,DWORD PTR [rax]
  410275:	mov    rsi,r12
  410278:	xor    eax,eax
  41027a:	call   4071b0 <ftruncate@plt>
  41027f:	test   eax,eax
  410281:	je     4102a5 <__swc_fn_4fa09e82_000113_6814119b+0x555>
  410283:	movsxd rdi,DWORD PTR [rbx]
  410286:	xor    eax,eax
  410288:	call   4070b0 <close@plt>
  41028d:	mov    rdi,r15
  410290:	xor    eax,eax
  410292:	call   407190 <closedir@plt>
  410297:	movsxd rdi,r13d
  41029a:	xor    eax,eax
  41029c:	call   4070b0 <close@plt>
  4102a1:	xor    eax,eax
  4102a3:	jmp    410306 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  4102a5:	xor    edi,edi
  4102a7:	mov    rsi,r12
  4102aa:	mov    edx,0x3
  4102af:	mov    ecx,0x1
  4102b4:	mov    rax,rbx
  4102b7:	movsxd r8,DWORD PTR [rax]
  4102ba:	xor    r9d,r9d
  4102bd:	xor    eax,eax
  4102bf:	call   4070c0 <mmap@plt>
  4102c4:	mov    r12,rax
  4102c7:	cmp    rax,0xffffffffffffffff
  4102cb:	jne    4102ef <__swc_fn_4fa09e82_000113_6814119b+0x59f>
  4102cd:	movsxd rdi,DWORD PTR [rbx]
  4102d0:	xor    eax,eax
  4102d2:	call   4070b0 <close@plt>
  4102d7:	mov    rdi,r15
  4102da:	xor    eax,eax
  4102dc:	call   407190 <closedir@plt>
  4102e1:	movsxd rdi,r13d
  4102e4:	xor    eax,eax
  4102e6:	call   4070b0 <close@plt>
  4102eb:	xor    eax,eax
  4102ed:	jmp    410306 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  4102ef:	mov    rdi,r15
  4102f2:	xor    eax,eax
  4102f4:	call   407190 <closedir@plt>
  4102f9:	movsxd rdi,r13d
  4102fc:	xor    eax,eax
  4102fe:	call   4070b0 <close@plt>
  410303:	mov    rax,r12
  410306:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  41030f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  410318:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  410321:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  41032a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  410333:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  41033c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  410345:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  41034e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  410357:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  410360:	add    rsp,0x170
  410367:	pop    r15
  410369:	pop    r14
  41036b:	pop    r13
  41036d:	pop    rsi
  41036e:	pop    rdi
  41036f:	pop    r12
  410371:	pop    rbx
  410372:	ret
	...

0000000000410380 <__swc_fn_4fa09e82_000116_5f48311c>:
  410380:	push   rsi
  410381:	push   rdi
  410382:	push   r12
  410384:	push   r13
  410386:	sub    rsp,0x8
  41038a:	mov    rsi,r8
  41038d:	mov    rdi,rcx
  410390:	mov    r12,rdx
  410393:	call   409580 <__swc_fn_4fa09e82_000114_126150d1>
  410398:	mov    r13,rax
  41039b:	test   rax,rax
  41039e:	jne    4103ab <__swc_fn_4fa09e82_000116_5f48311c+0x2b>
  4103a0:	add    rsp,0x8
  4103a4:	pop    r13
  4103a6:	pop    r12
  4103a8:	pop    rdi
  4103a9:	pop    rsi
  4103aa:	ret
  4103ab:	mov    rcx,r13
  4103ae:	call   40d490 <__swc_fn_4fa09e82_000139_8c07c14b>
  4103b3:	mov    rax,QWORD PTR [r13+0x8]
  4103b7:	test   rax,rax
  4103ba:	je     4103f9 <__swc_fn_4fa09e82_000116_5f48311c+0x79>
  4103bc:	nop    DWORD PTR [rax+0x0]
  4103c0:	lea    rcx,[rax+0x1000]
  4103c7:	cmp    rdi,rcx
  4103ca:	jne    4103f1 <__swc_fn_4fa09e82_000116_5f48311c+0x71>
  4103cc:	cmp    r12,0x1000
  4103d3:	jb     4103f1 <__swc_fn_4fa09e82_000116_5f48311c+0x71>
  4103d5:	test   sil,sil
  4103d8:	setne  cl
  4103db:	mov    BYTE PTR [rax+0x10],cl
  4103de:	mov    rcx,r13
  4103e1:	call   4108e0 <__swc_fn_4fa09e82_000140_715e84ff>
  4103e6:	add    rsp,0x8
  4103ea:	pop    r13
  4103ec:	pop    r12
  4103ee:	pop    rdi
  4103ef:	pop    rsi
  4103f0:	ret
  4103f1:	mov    rax,QWORD PTR [rax]
  4103f4:	test   rax,rax
  4103f7:	jne    4103c0 <__swc_fn_4fa09e82_000116_5f48311c+0x40>
  4103f9:	mov    rcx,r13
  4103fc:	call   4108e0 <__swc_fn_4fa09e82_000140_715e84ff>
  410401:	add    rsp,0x8
  410405:	pop    r13
  410407:	pop    r12
  410409:	pop    rdi
  41040a:	pop    rsi
  41040b:	ret
  41040c:	add    BYTE PTR [rax],al
	...

0000000000410410 <__swc_fn_4fa09e82_000119_ed2d8fed>:
  410410:	sub    rsp,0x8
  410414:	test   rcx,rcx
  410417:	jne    41041e <__swc_fn_4fa09e82_000119_ed2d8fed+0xe>
  410419:	add    rsp,0x8
  41041d:	ret
  41041e:	call   40cf90 <__swc_fn_4fa09e82_000121_d3318640>
  410423:	add    rsp,0x8
  410427:	ret
	...

0000000000410430 <__swc_fn_4fa09e82_000122_2648f149>:
  410430:	push   r12
  410432:	push   r13
  410434:	push   r14
  410436:	push   rdi
  410437:	push   rsi
  410438:	sub    rsp,0xc0
  41043f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410445:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  41044b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  410451:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410457:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  41045d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  410463:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410469:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  410472:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  41047b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  410484:	mov    r12,QWORD PTR [rcx]
  410487:	test   r12,r12
  41048a:	jne    41049c <__swc_fn_4fa09e82_000122_2648f149+0x6c>
  41048c:	add    rsp,0xc0
  410493:	pop    rsi
  410494:	pop    rdi
  410495:	pop    r14
  410497:	pop    r13
  410499:	pop    r12
  41049b:	ret
  41049c:	xor    r13d,r13d
  41049f:	mov    r14,QWORD PTR [rcx+0x8]
  4104a3:	cs nop WORD PTR [rax+rax*1+0x0]
  4104ad:	nop    DWORD PTR [rax]
  4104b0:	cmp    r13,r14
  4104b3:	jae    4104eb <__swc_fn_4fa09e82_000122_2648f149+0xbb>
  4104b5:	lea    rax,[r12+r13*1]
  4104b9:	mov    rcx,r14
  4104bc:	sub    rcx,r13
  4104bf:	mov    edi,0x1
  4104c4:	mov    rsi,rax
  4104c7:	mov    rdx,rcx
  4104ca:	xor    eax,eax
  4104cc:	call   4071c0 <write@plt>
  4104d1:	test   rax,rax
  4104d4:	jle    4104db <__swc_fn_4fa09e82_000122_2648f149+0xab>
  4104d6:	add    r13,rax
  4104d9:	jmp    4104b0 <__swc_fn_4fa09e82_000122_2648f149+0x80>
  4104db:	je     4104e9 <__swc_fn_4fa09e82_000122_2648f149+0xb9>
  4104dd:	xor    eax,eax
  4104df:	call   407130 <__errno_location@plt>
  4104e4:	cmp    DWORD PTR [rax],0x4
  4104e7:	je     4104b0 <__swc_fn_4fa09e82_000122_2648f149+0x80>
  4104e9:	jmp    4104eb <__swc_fn_4fa09e82_000122_2648f149+0xbb>
  4104eb:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4104f1:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4104f7:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4104fd:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410503:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410509:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41050f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410515:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41051e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410527:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410530:	add    rsp,0xc0
  410537:	pop    rsi
  410538:	pop    rdi
  410539:	pop    r14
  41053b:	pop    r13
  41053d:	pop    r12
  41053f:	ret

0000000000410540 <__swc_fn_4fa09e82_000125_4f256d58>:
  410540:	push   rbx
  410541:	push   r12
  410543:	push   rdi
  410544:	push   rsi
  410545:	sub    rsp,0x4a8
  41054c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  410555:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  41055e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  410567:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  410570:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  410579:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  410582:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  41058b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  410594:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  41059d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  4105a6:	mov    rbx,rdx
  4105a9:	mov    r12d,ecx
  4105ac:	vxorps xmm0,xmm0,xmm0
  4105b0:	xor    eax,eax
  4105b2:	cs nop WORD PTR [rax+rax*1+0x0]
  4105bc:	nop    DWORD PTR [rax+0x0]
  4105c0:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  4105c6:	add    rax,0x10
  4105ca:	cmp    rax,0x400
  4105d1:	jne    4105c0 <__swc_fn_4fa09e82_000125_4f256d58+0x80>
  4105d3:	lea    rdi,[rsp+0x8]
  4105d8:	mov    esi,0x80
  4105dd:	xor    eax,eax
  4105df:	call   4071d0 <backtrace@plt>
  4105e4:	test   eax,eax
  4105e6:	jle    4105f5 <__swc_fn_4fa09e82_000125_4f256d58+0xb5>
  4105e8:	movsxd rax,eax
  4105eb:	lea    rcx,[r12+0x1]
  4105f0:	cmp    rcx,rax
  4105f3:	jb     4105f9 <__swc_fn_4fa09e82_000125_4f256d58+0xb9>
  4105f5:	xor    eax,eax
  4105f7:	jmp    41062a <__swc_fn_4fa09e82_000125_4f256d58+0xea>
  4105f9:	mov    rcx,QWORD PTR [rbx+0x8]
  4105fd:	sub    rax,r12
  410600:	lea    rsi,[rax-0x1]
  410604:	cmp    rcx,rsi
  410607:	cmovbe rsi,rcx
  41060b:	lea    eax,[r12+0x1]
  410610:	lea    rax,[rsp+rax*8+0x8]
  410615:	mov    rcx,QWORD PTR [rbx]
  410618:	mov    rdx,rax
  41061b:	lea    r8,[rsi*8+0x0]
  410623:	call   409560 <__swc_fn_4fa09e82_000111_7c204aac>
  410628:	mov    eax,esi
  41062a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  410633:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  41063c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  410645:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  41064e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  410657:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  410660:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  410669:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  410672:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  41067b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  410684:	add    rsp,0x4a8
  41068b:	pop    rsi
  41068c:	pop    rdi
  41068d:	pop    r12
  41068f:	pop    rbx
  410690:	ret
	...

00000000004106a0 <__swc_fn_4fa09e82_000128_fcd5a289>:
  4106a0:	mov    QWORD PTR [rcx],0x0
  4106a7:	ret
	...

00000000004106b0 <__swc_fn_4fa09e82_000131_4bbe3f14>:
  4106b0:	push   rdi
  4106b1:	push   rsi
  4106b2:	sub    rsp,0xa8
  4106b9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4106bf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4106c5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4106cb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4106d1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4106d7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4106dd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4106e3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4106e9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4106f2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4106fb:	mov    edi,ecx
  4106fd:	mov    rsi,rdx
  410700:	xor    eax,eax
  410702:	call   407060 <pthread_setspecific@plt>
  410707:	test   eax,eax
  410709:	sete   al
  41070c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410712:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410718:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41071e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410724:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41072a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410730:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410736:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41073c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410745:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41074e:	add    rsp,0xa8
  410755:	pop    rsi
  410756:	pop    rdi
  410757:	ret
	...

0000000000410760 <__swc_fn_4fa09e82_000134_5f757033>:
  410760:	push   rdi
  410761:	push   rsi
  410762:	sub    rsp,0xa8
  410769:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41076f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410775:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41077b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410781:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410787:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41078d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410793:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410799:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4107a2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4107ab:	test   rcx,rcx
  4107ae:	je     4107c1 <__swc_fn_4fa09e82_000134_5f757033+0x61>
  4107b0:	lea    rax,[rcx-0x1]
  4107b4:	mov    eax,eax
  4107b6:	mov    edi,eax
  4107b8:	xor    eax,eax
  4107ba:	call   407000 <pthread_getspecific@plt>
  4107bf:	jmp    4107c3 <__swc_fn_4fa09e82_000134_5f757033+0x63>
  4107c1:	xor    eax,eax
  4107c3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4107c9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4107cf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4107d5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4107db:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4107e1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4107e7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4107ed:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4107f3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4107fc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410805:	add    rsp,0xa8
  41080c:	pop    rsi
  41080d:	pop    rdi
  41080e:	ret
	...

0000000000410810 <__swc_fn_4fa09e82_000137_07d76562>:
  410810:	push   rdi
  410811:	push   rsi
  410812:	sub    rsp,0xb8
  410819:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41081f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410825:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41082b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410831:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410837:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41083d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410843:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41084c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410855:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41085e:	vxorps xmm0,xmm0,xmm0
  410862:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410868:	mov    edi,0x1
  41086d:	lea    rsi,[rsp+0x8]
  410872:	xor    eax,eax
  410874:	call   407110 <clock_gettime@plt>
  410879:	mov    rax,QWORD PTR [rsp+0x8]
  41087e:	imul   rax,rax,0x3b9aca00
  410885:	add    rax,QWORD PTR [rsp+0x10]
  41088a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410890:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410896:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  41089c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4108a2:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4108a8:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4108ae:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4108b4:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4108bd:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4108c6:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4108cf:	add    rsp,0xb8
  4108d6:	pop    rsi
  4108d7:	pop    rdi
  4108d8:	ret
  4108d9:	add    BYTE PTR [rax],al
  4108db:	add    BYTE PTR [rax],al
  4108dd:	add    BYTE PTR [rax],al
	...

00000000004108e0 <__swc_fn_4fa09e82_000140_715e84ff>:
  4108e0:	sub    rsp,0x8
  4108e4:	xor    eax,eax
  4108e6:	mov    DWORD PTR [rcx],eax
  4108e8:	mov    edx,0x7fffffff
  4108ed:	call   409c60 <__swc_fn_4fa09e82_000138_865f5106>
  4108f2:	add    rsp,0x8
  4108f6:	ret
	...

0000000000410900 <__swc_fn_4fa09e82_000143_519fdf94>:
  410900:	push   rdi
  410901:	push   rsi
  410902:	sub    rsp,0xb8
  410909:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41090f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410915:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41091b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410921:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410927:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41092d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410933:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41093c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410945:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41094e:	mov    edi,0x1
  410953:	xor    eax,eax
  410955:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  41095a:	mov    eax,DWORD PTR [rax+0x14]
  41095d:	and    eax,0x20
  410960:	setne  al
  410963:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410969:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41096f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410975:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41097b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410981:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  410987:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41098d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  410996:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  41099f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4109a8:	add    rsp,0xb8
  4109af:	pop    rsi
  4109b0:	pop    rdi
  4109b1:	ret
	...

00000000004109c0 <__swc_fn_4fa09e82_000146_d5d4d43f>:
  4109c0:	push   rsi
  4109c1:	push   rdi
  4109c2:	push   r12
  4109c4:	push   r13
  4109c6:	push   r14
  4109c8:	push   r15
  4109ca:	cmp    rdx,0x40
  4109ce:	jae    4109dd <__swc_fn_4fa09e82_000146_d5d4d43f+0x1d>
  4109d0:	xor    eax,eax
  4109d2:	pop    r15
  4109d4:	pop    r14
  4109d6:	pop    r13
  4109d8:	pop    r12
  4109da:	pop    rdi
  4109db:	pop    rsi
  4109dc:	ret
  4109dd:	cmp    BYTE PTR [rcx],0x7f
  4109e0:	jne    410a24 <__swc_fn_4fa09e82_000146_d5d4d43f+0x64>
  4109e2:	movzx  eax,BYTE PTR [rcx+0x1]
  4109e6:	cmp    eax,0x45
  4109e9:	setne  al
  4109ec:	jne    410a20 <__swc_fn_4fa09e82_000146_d5d4d43f+0x60>
  4109ee:	movzx  eax,BYTE PTR [rcx+0x2]
  4109f2:	cmp    eax,0x4c
  4109f5:	setne  al
  4109f8:	jne    410a20 <__swc_fn_4fa09e82_000146_d5d4d43f+0x60>
  4109fa:	movzx  eax,BYTE PTR [rcx+0x3]
  4109fe:	cmp    eax,0x46
  410a01:	setne  al
  410a04:	jne    410a20 <__swc_fn_4fa09e82_000146_d5d4d43f+0x60>
  410a06:	cmp    BYTE PTR [rcx+0x4],0x2
  410a0a:	setne  al
  410a0d:	jne    410a20 <__swc_fn_4fa09e82_000146_d5d4d43f+0x60>
  410a0f:	cmp    BYTE PTR [rcx+0x5],0x1
  410a13:	setne  al
  410a16:	jne    410a20 <__swc_fn_4fa09e82_000146_d5d4d43f+0x60>
  410a18:	cmp    WORD PTR [rcx+0x12],0x3e
  410a1d:	setne  al
  410a20:	test   al,al
  410a22:	je     410a31 <__swc_fn_4fa09e82_000146_d5d4d43f+0x71>
  410a24:	xor    eax,eax
  410a26:	pop    r15
  410a28:	pop    r14
  410a2a:	pop    r13
  410a2c:	pop    r12
  410a2e:	pop    rdi
  410a2f:	pop    rsi
  410a30:	ret
  410a31:	cmp    WORD PTR [rcx+0x3a],0x40
  410a36:	jne    410a51 <__swc_fn_4fa09e82_000146_d5d4d43f+0x91>
  410a38:	cmp    WORD PTR [rcx+0x3c],0x0
  410a3d:	sete   al
  410a40:	je     410a4d <__swc_fn_4fa09e82_000146_d5d4d43f+0x8d>
  410a42:	mov    ax,WORD PTR [rcx+0x3c]
  410a46:	cmp    WORD PTR [rcx+0x3e],ax
  410a4a:	setae  al
  410a4d:	test   al,al
  410a4f:	je     410a5e <__swc_fn_4fa09e82_000146_d5d4d43f+0x9e>
  410a51:	xor    eax,eax
  410a53:	pop    r15
  410a55:	pop    r14
  410a57:	pop    r13
  410a59:	pop    r12
  410a5b:	pop    rdi
  410a5c:	pop    rsi
  410a5d:	ret
  410a5e:	movzx  eax,WORD PTR [rcx+0x3c]
  410a62:	shl    rax,0x6
  410a66:	cmp    rax,rdx
  410a69:	ja     410a77 <__swc_fn_4fa09e82_000146_d5d4d43f+0xb7>
  410a6b:	mov    r9,rdx
  410a6e:	sub    r9,rax
  410a71:	cmp    QWORD PTR [rcx+0x28],r9
  410a75:	jbe    410a84 <__swc_fn_4fa09e82_000146_d5d4d43f+0xc4>
  410a77:	xor    eax,eax
  410a79:	pop    r15
  410a7b:	pop    r14
  410a7d:	pop    r13
  410a7f:	pop    r12
  410a81:	pop    rdi
  410a82:	pop    rsi
  410a83:	ret
  410a84:	mov    rax,QWORD PTR [rcx+0x28]
  410a88:	add    rax,rcx
  410a8b:	movzx  r9d,WORD PTR [rcx+0x3e]
  410a90:	lea    r9,[r9*8+0x0]
  410a98:	lea    r10,[rax+r9*8]
  410a9c:	cmp    QWORD PTR [r10+0x20],rdx
  410aa0:	ja     410ac2 <__swc_fn_4fa09e82_000146_d5d4d43f+0x102>
  410aa2:	mov    r11,rdx
  410aa5:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  410aaa:	cmp    QWORD PTR [r10+0x18],r11
  410aae:	seta   r9b
  410ab2:	ja     410abd <__swc_fn_4fa09e82_000146_d5d4d43f+0xfd>
  410ab4:	cmp    QWORD PTR [r10+0x20],0x9
  410ab9:	setb   r9b
  410abd:	test   r9b,r9b
  410ac0:	je     410acf <__swc_fn_4fa09e82_000146_d5d4d43f+0x10f>
  410ac2:	xor    eax,eax
  410ac4:	pop    r15
  410ac6:	pop    r14
  410ac8:	pop    r13
  410aca:	pop    r12
  410acc:	pop    rdi
  410acd:	pop    rsi
  410ace:	ret
  410acf:	movzx  r9d,WORD PTR [rcx+0x3c]
  410ad4:	xor    r11d,r11d
  410ad7:	test   r9,r9
  410ada:	jbe    410bd5 <__swc_fn_4fa09e82_000146_d5d4d43f+0x215>
  410ae0:	mov    rsi,QWORD PTR [r10+0x20]
  410ae4:	sub    rsi,0x9
  410ae8:	cs nop WORD PTR [rax+rax*1+0x0]
  410af2:	cs nop WORD PTR [rax+rax*1+0x0]
  410afc:	nop    DWORD PTR [rax+0x0]
  410b00:	movzx  edi,r11w
  410b04:	lea    rdi,[rdi*8+0x0]
  410b0c:	lea    r12,[rax+rdi*8]
  410b10:	rex mov edi,DWORD PTR [rax+rdi*8]
  410b14:	cmp    rdi,rsi
  410b17:	ja     410bc8 <__swc_fn_4fa09e82_000146_d5d4d43f+0x208>
  410b1d:	mov    r13,QWORD PTR [r10+0x18]
  410b21:	add    r13,rdi
  410b24:	lea    rdi,[rcx+r13*1]
  410b28:	lea    r13,[rip+0x2ad1]        # 413600 <__swc_rdata_base_4fa09e82+0x4f0>
  410b2f:	movabs r14,0x676264676177732e
  410b39:	cmp    QWORD PTR [rdi],r14
  410b3c:	jne    410b45 <__swc_fn_4fa09e82_000146_d5d4d43f+0x185>
  410b3e:	rex cmp BYTE PTR [rdi+0x8],0x0
  410b43:	je     410b72 <__swc_fn_4fa09e82_000146_d5d4d43f+0x1b2>
  410b45:	cs nop WORD PTR [rax+rax*1+0x0]
  410b4f:	nop
  410b50:	movzx  r14d,BYTE PTR [rdi]
  410b54:	movzx  r15d,BYTE PTR [r13+0x0]
  410b59:	cmp    r14,r15
  410b5c:	jne    410b68 <__swc_fn_4fa09e82_000146_d5d4d43f+0x1a8>
  410b5e:	add    rdi,0x1
  410b62:	add    r13,0x1
  410b66:	jmp    410b50 <__swc_fn_4fa09e82_000146_d5d4d43f+0x190>
  410b68:	mov    rdi,r14
  410b6b:	sub    rdi,r15
  410b6e:	test   edi,edi
  410b70:	jne    410bc8 <__swc_fn_4fa09e82_000146_d5d4d43f+0x208>
  410b72:	cmp    DWORD PTR [r12+0x4],0x1
  410b78:	jne    410ba0 <__swc_fn_4fa09e82_000146_d5d4d43f+0x1e0>
  410b7a:	cmp    QWORD PTR [r12+0x20],0x10
  410b80:	setb   al
  410b83:	jb     410b9c <__swc_fn_4fa09e82_000146_d5d4d43f+0x1dc>
  410b85:	cmp    QWORD PTR [r12+0x20],rdx
  410b8a:	seta   al
  410b8d:	ja     410b9c <__swc_fn_4fa09e82_000146_d5d4d43f+0x1dc>
  410b8f:	sub    rdx,QWORD PTR [r12+0x20]
  410b94:	cmp    QWORD PTR [r12+0x18],rdx
  410b99:	seta   al
  410b9c:	test   al,al
  410b9e:	je     410bad <__swc_fn_4fa09e82_000146_d5d4d43f+0x1ed>
  410ba0:	xor    eax,eax
  410ba2:	pop    r15
  410ba4:	pop    r14
  410ba6:	pop    r13
  410ba8:	pop    r12
  410baa:	pop    rdi
  410bab:	pop    rsi
  410bac:	ret
  410bad:	mov    rax,QWORD PTR [r12+0x20]
  410bb2:	mov    QWORD PTR [r8],rax
  410bb5:	mov    rax,QWORD PTR [r12+0x18]
  410bba:	add    rax,rcx
  410bbd:	pop    r15
  410bbf:	pop    r14
  410bc1:	pop    r13
  410bc3:	pop    r12
  410bc5:	pop    rdi
  410bc6:	pop    rsi
  410bc7:	ret
  410bc8:	add    r11,0x1
  410bcc:	cmp    r11,r9
  410bcf:	jb     410b00 <__swc_fn_4fa09e82_000146_d5d4d43f+0x140>
  410bd5:	xor    eax,eax
  410bd7:	pop    r15
  410bd9:	pop    r14
  410bdb:	pop    r13
  410bdd:	pop    r12
  410bdf:	pop    rdi
  410be0:	pop    rsi
  410be1:	ret
	...

0000000000410bf0 <__swc_fn_4fa09e82_000149_d7edc04f>:
  410bf0:	push   rdi
  410bf1:	push   rsi
  410bf2:	sub    rsp,0xa8
  410bf9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  410bff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410c05:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  410c0b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410c11:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410c17:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  410c1d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410c23:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410c29:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410c32:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  410c3b:	mov    rdi,rcx
  410c3e:	xor    eax,eax
  410c40:	call   4071f0 <free@plt>
  410c45:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410c4b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410c51:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410c57:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410c5d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410c63:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410c69:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410c6f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410c75:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410c7e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410c87:	add    rsp,0xa8
  410c8e:	pop    rsi
  410c8f:	pop    rdi
  410c90:	ret
	...

0000000000410ca0 <__swc_fn_4fa09e82_000152_6203dca2>:
  410ca0:	push   rbx
  410ca1:	push   rsi
  410ca2:	push   rdi
  410ca3:	push   r12
  410ca5:	push   r13
  410ca7:	push   r15
  410ca9:	sub    rsp,0x4e8
  410cb0:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  410cb9:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  410cc2:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  410ccb:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  410cd4:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  410cdd:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  410ce6:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  410cef:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  410cf8:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  410d01:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  410d0a:	mov    rbx,QWORD PTR [rcx]
  410d0d:	mov    rcx,QWORD PTR [rcx+0x8]
  410d11:	mov    rsi,rcx
  410d14:	xor    edi,edi
  410d16:	vmovsd xmm6,QWORD PTR [rip+0x2942]        # 413660 <__swc_rdata_base_4fa09e82+0x550>
  410d1e:	vmovsd xmm7,QWORD PTR [rip+0x2943]        # 413669 <__swc_rdata_base_4fa09e82+0x559>
  410d26:	vmovsd xmm8,QWORD PTR [rip+0x2944]        # 413672 <__swc_rdata_base_4fa09e82+0x562>
  410d2e:	vmovsd xmm9,QWORD PTR [rip+0x2945]        # 41367b <__swc_rdata_base_4fa09e82+0x56b>
  410d36:	vmovsd xmm10,QWORD PTR [rip+0x2946]        # 413684 <__swc_rdata_base_4fa09e82+0x574>
  410d3e:	vmovups xmm11,xmm6
  410d42:	vmovsd QWORD PTR [rsp+0x418],xmm7
  410d4b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410d54:	vmovsd QWORD PTR [rsp+0x428],xmm9
  410d5d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410d66:	vmovsd xmm15,QWORD PTR [rip+0x291f]        # 41368d <__swc_rdata_base_4fa09e82+0x57d>
  410d6e:	vmovups xmm14,xmm15
  410d73:	vmovups xmm0,xmm9
  410d78:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410d81:	vmovups xmm13,xmm8
  410d86:	vmovsd QWORD PTR [rsp+0x440],xmm15
  410d8f:	test   rsi,rsi
  410d92:	je     411d83 <__swc_fn_4fa09e82_000152_6203dca2+0x10e3>
  410d98:	cs nop WORD PTR [rax+rax*1+0x0]
  410da2:	cs nop WORD PTR [rax+rax*1+0x0]
  410dac:	nop    DWORD PTR [rax+0x0]
  410db0:	lea    rcx,[rdi+rdi*1]
  410db4:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410db9:	vpshufd xmm3,xmm2,0xee
  410dbe:	vmovq  rcx,xmm3
  410dc3:	test   rcx,rcx
  410dc6:	je     410ddc <__swc_fn_4fa09e82_000152_6203dca2+0x13c>
  410dc8:	test   DWORD PTR [rcx+0x28],0x400000
  410dcf:	je     410ddc <__swc_fn_4fa09e82_000152_6203dca2+0x13c>
  410dd1:	mov    rdx,QWORD PTR [rcx+0x30]
  410dd5:	test   rdx,rdx
  410dd8:	cmovne rcx,rdx
  410ddc:	test   DWORD PTR [rcx+0x28],0x1000
  410de3:	je     410e04 <__swc_fn_4fa09e82_000152_6203dca2+0x164>
  410de5:	mov    rdx,QWORD PTR [rcx+0x40]
  410de9:	mov    rcx,rdx
  410dec:	vmovq  r8,xmm2
  410df1:	mov    r8,QWORD PTR [r8]
  410df4:	mov    QWORD PTR [rsp+0x60],r8
  410df9:	mov    QWORD PTR [rsp+0x68],rdx
  410dfe:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410e04:	test   BYTE PTR [rcx+0x28],0x1
  410e08:	jne    410e10 <__swc_fn_4fa09e82_000152_6203dca2+0x170>
  410e0a:	vmovups xmm12,xmm0
  410e0e:	jmp    410e2a <__swc_fn_4fa09e82_000152_6203dca2+0x18a>
  410e10:	vmovq  rax,xmm2
  410e15:	mov    rax,QWORD PTR [rax]
  410e18:	lea    rcx,[rax+0x10]
  410e1c:	vmovups xmm12,xmm0
  410e20:	call   410430 <__swc_fn_4fa09e82_000122_2648f149>
  410e25:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410e2a:	test   DWORD PTR [rcx+0x28],0x400
  410e31:	je     410e92 <__swc_fn_4fa09e82_000152_6203dca2+0x1f2>
  410e33:	vmovq  rax,xmm2
  410e38:	mov    rax,QWORD PTR [rax]
  410e3b:	xor    ecx,ecx
  410e3d:	test   rax,rax
  410e40:	je     410e70 <__swc_fn_4fa09e82_000152_6203dca2+0x1d0>
  410e42:	mov    rdx,rax
  410e45:	mov    r8b,BYTE PTR [rdx]
  410e48:	test   r8b,r8b
  410e4b:	je     410e70 <__swc_fn_4fa09e82_000152_6203dca2+0x1d0>
  410e4d:	cs nop WORD PTR [rax+rax*1+0x0]
  410e57:	nop    WORD PTR [rax+rax*1+0x0]
  410e60:	add    rdx,0x1
  410e64:	add    rcx,0x1
  410e68:	mov    r8b,BYTE PTR [rdx]
  410e6b:	test   r8b,r8b
  410e6e:	jne    410e60 <__swc_fn_4fa09e82_000152_6203dca2+0x1c0>
  410e70:	mov    QWORD PTR [rsp+0x88],rax
  410e78:	mov    QWORD PTR [rsp+0x90],rcx
  410e80:	lea    rcx,[rsp+0x88]
  410e88:	call   410430 <__swc_fn_4fa09e82_000122_2648f149>
  410e8d:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410e92:	cmp    BYTE PTR [rcx+0x2c],0x6
  410e96:	jne    410ead <__swc_fn_4fa09e82_000152_6203dca2+0x20d>
  410e98:	vmovq  rax,xmm2
  410e9d:	mov    rax,QWORD PTR [rax]
  410ea0:	mov    rcx,rax
  410ea3:	call   40a130 <__swc_fn_4fa09e82_000150_43c96957>
  410ea8:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410ead:	cmp    BYTE PTR [rcx+0x2c],0x1
  410eb1:	jne    411d59 <__swc_fn_4fa09e82_000152_6203dca2+0x10b9>
  410eb7:	vmovq  rdx,xmm2
  410ebc:	mov    cl,BYTE PTR [rcx+0x40]
  410ebf:	cmp    cl,0x7
  410ec2:	jb     410f05 <__swc_fn_4fa09e82_000152_6203dca2+0x265>
  410ec4:	je     410f78 <__swc_fn_4fa09e82_000152_6203dca2+0x2d8>
  410eca:	cmp    cl,0x8
  410ecd:	je     410f84 <__swc_fn_4fa09e82_000152_6203dca2+0x2e4>
  410ed3:	cmp    cl,0x9
  410ed6:	je     410f9d <__swc_fn_4fa09e82_000152_6203dca2+0x2fd>
  410edc:	cmp    cl,0xa
  410edf:	je     411664 <__swc_fn_4fa09e82_000152_6203dca2+0x9c4>
  410ee5:	cmp    cl,0xb
  410ee8:	je     411d2b <__swc_fn_4fa09e82_000152_6203dca2+0x108b>
  410eee:	cmp    cl,0xc
  410ef1:	je     410f91 <__swc_fn_4fa09e82_000152_6203dca2+0x2f1>
  410ef7:	cmp    cl,0xd
  410efa:	je     411d21 <__swc_fn_4fa09e82_000152_6203dca2+0x1081>
  410f00:	jmp    411d4b <__swc_fn_4fa09e82_000152_6203dca2+0x10ab>
  410f05:	cmp    cl,0x1
  410f08:	je     410f28 <__swc_fn_4fa09e82_000152_6203dca2+0x288>
  410f0a:	cmp    cl,0x2
  410f0d:	je     410f36 <__swc_fn_4fa09e82_000152_6203dca2+0x296>
  410f0f:	cmp    cl,0x3
  410f12:	je     410f44 <__swc_fn_4fa09e82_000152_6203dca2+0x2a4>
  410f14:	cmp    cl,0x4
  410f17:	je     410f51 <__swc_fn_4fa09e82_000152_6203dca2+0x2b1>
  410f19:	cmp    cl,0x5
  410f1c:	je     410f5e <__swc_fn_4fa09e82_000152_6203dca2+0x2be>
  410f1e:	cmp    cl,0x6
  410f21:	je     410f6b <__swc_fn_4fa09e82_000152_6203dca2+0x2cb>
  410f23:	jmp    411d4b <__swc_fn_4fa09e82_000152_6203dca2+0x10ab>
  410f28:	movsx  rcx,BYTE PTR [rdx]
  410f2c:	call   40d680 <__swc_fn_4fa09e82_000151_2eb804cc>
  410f31:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410f36:	movsx  rcx,WORD PTR [rdx]
  410f3a:	call   40d680 <__swc_fn_4fa09e82_000151_2eb804cc>
  410f3f:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410f44:	movsxd rcx,DWORD PTR [rdx]
  410f47:	call   40d680 <__swc_fn_4fa09e82_000151_2eb804cc>
  410f4c:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410f51:	mov    rcx,QWORD PTR [rdx]
  410f54:	call   40d680 <__swc_fn_4fa09e82_000151_2eb804cc>
  410f59:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410f5e:	movzx  ecx,BYTE PTR [rdx]
  410f61:	call   40a130 <__swc_fn_4fa09e82_000150_43c96957>
  410f66:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410f6b:	movzx  ecx,WORD PTR [rdx]
  410f6e:	call   40a130 <__swc_fn_4fa09e82_000150_43c96957>
  410f73:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410f78:	mov    ecx,DWORD PTR [rdx]
  410f7a:	call   40a130 <__swc_fn_4fa09e82_000150_43c96957>
  410f7f:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410f84:	mov    rcx,QWORD PTR [rdx]
  410f87:	call   40a130 <__swc_fn_4fa09e82_000150_43c96957>
  410f8c:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410f91:	mov    ecx,DWORD PTR [rdx]
  410f93:	call   40a130 <__swc_fn_4fa09e82_000150_43c96957>
  410f98:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410f9d:	lea    rcx,[rsp+0xa8]
  410fa5:	vxorps xmm0,xmm0,xmm0
  410fa9:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  410fb2:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  410fbb:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  410fc4:	vzeroupper
  410fc7:	mov    DWORD PTR [rsp+0x108],0x0
  410fd2:	vxorpd xmm0,xmm0,xmm0
  410fd6:	vmovss xmm1,DWORD PTR [rdx]
  410fda:	vcvtss2sd xmm0,xmm0,xmm1
  410fde:	vmovsd xmm1,xmm1,xmm0
  410fe2:	vcomisd xmm0,xmm0
  410fe6:	setne  dl
  410fe9:	movzx  edx,dl
  410fec:	setp   r8b
  410ff0:	movzx  r8d,r8b
  410ff4:	or     edx,r8d
  410ff7:	test   dl,dl
  410ff9:	je     411006 <__swc_fn_4fa09e82_000152_6203dca2+0x366>
  410ffb:	mov    DWORD PTR [rcx],0x6e616e
  411001:	jmp    4115f8 <__swc_fn_4fa09e82_000152_6203dca2+0x958>
  411006:	vcomisd xmm1,xmm6
  41100a:	ja     411012 <__swc_fn_4fa09e82_000152_6203dca2+0x372>
  41100c:	vcomisd xmm7,xmm1
  411010:	jbe    411036 <__swc_fn_4fa09e82_000152_6203dca2+0x396>
  411012:	vxorpd xmm0,xmm0,xmm0
  411016:	vcomisd xmm0,xmm1
  41101a:	jbe    41102b <__swc_fn_4fa09e82_000152_6203dca2+0x38b>
  41101c:	mov    DWORD PTR [rcx],0x666e692d
  411022:	mov    BYTE PTR [rcx+0x4],0x0
  411026:	jmp    4115f8 <__swc_fn_4fa09e82_000152_6203dca2+0x958>
  41102b:	mov    DWORD PTR [rcx],0x666e69
  411031:	jmp    4115f8 <__swc_fn_4fa09e82_000152_6203dca2+0x958>
  411036:	vcomisd xmm1,xmm8
  41103b:	jae    411047 <__swc_fn_4fa09e82_000152_6203dca2+0x3a7>
  41103d:	vcomisd xmm9,xmm1
  411041:	jbe    4113be <__swc_fn_4fa09e82_000152_6203dca2+0x71e>
  411047:	vmovups xmm0,xmm1
  41104b:	vxorpd xmm2,xmm2,xmm2
  41104f:	vcomisd xmm2,xmm1
  411053:	jbe    411063 <__swc_fn_4fa09e82_000152_6203dca2+0x3c3>
  411055:	vmovsd xmm1,xmm1,xmm0
  411059:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x25bf]        # 413620 <__swc_rdata_base_4fa09e82+0x510>
  411061:	jmp    411067 <__swc_fn_4fa09e82_000152_6203dca2+0x3c7>
  411063:	vmovsd xmm1,xmm1,xmm0
  411067:	xor    r8d,r8d
  41106a:	vcomisd xmm1,xmm15
  41106f:	jb     411090 <__swc_fn_4fa09e82_000152_6203dca2+0x3f0>
  411071:	cs nop WORD PTR [rax+rax*1+0x0]
  41107b:	nop    DWORD PTR [rax+rax*1+0x0]
  411080:	vdivsd xmm1,xmm1,xmm15
  411085:	add    r8,0x1
  411089:	vcomisd xmm1,xmm15
  41108e:	jae    411080 <__swc_fn_4fa09e82_000152_6203dca2+0x3e0>
  411090:	mov    r9,rcx
  411093:	vxorpd xmm2,xmm2,xmm2
  411097:	vcomisd xmm2,xmm0
  41109b:	jbe    4110a4 <__swc_fn_4fa09e82_000152_6203dca2+0x404>
  41109d:	mov    BYTE PTR [rcx],0x2d
  4110a0:	lea    r9,[rcx+0x1]
  4110a4:	vcvttsd2si rdx,xmm1
  4110a9:	mov    r10b,dl
  4110ac:	add    r10b,0x30
  4110b0:	mov    BYTE PTR [r9],r10b
  4110b3:	vxorpd xmm0,xmm0,xmm0
  4110b7:	movzx  edx,dl
  4110ba:	vcvtsi2sd xmm0,xmm0,rdx
  4110bf:	vsubsd xmm0,xmm1,xmm0
  4110c3:	vmulsd xmm1,xmm0,xmm15
  4110c8:	mov    BYTE PTR [r9+0x1],0x2e
  4110cd:	vcvttsd2si rdx,xmm1
  4110d2:	mov    r10b,dl
  4110d5:	add    r10b,0x30
  4110d9:	mov    BYTE PTR [r9+0x2],r10b
  4110dd:	vxorpd xmm0,xmm0,xmm0
  4110e1:	movzx  edx,dl
  4110e4:	vcvtsi2sd xmm0,xmm0,rdx
  4110e9:	vsubsd xmm0,xmm1,xmm0
  4110ed:	vmulsd xmm1,xmm0,xmm15
  4110f2:	vcvttsd2si rdx,xmm1
  4110f7:	mov    r10b,dl
  4110fa:	add    r10b,0x30
  4110fe:	mov    BYTE PTR [r9+0x3],r10b
  411102:	vxorpd xmm0,xmm0,xmm0
  411106:	movzx  edx,dl
  411109:	vcvtsi2sd xmm0,xmm0,rdx
  41110e:	vsubsd xmm0,xmm1,xmm0
  411112:	vmulsd xmm1,xmm0,xmm15
  411117:	vcvttsd2si rdx,xmm1
  41111c:	mov    r10b,dl
  41111f:	add    r10b,0x30
  411123:	mov    BYTE PTR [r9+0x4],r10b
  411127:	vxorpd xmm0,xmm0,xmm0
  41112b:	movzx  edx,dl
  41112e:	vcvtsi2sd xmm0,xmm0,rdx
  411133:	vsubsd xmm0,xmm1,xmm0
  411137:	vmulsd xmm1,xmm0,xmm15
  41113c:	vcvttsd2si rdx,xmm1
  411141:	mov    r10b,dl
  411144:	add    r10b,0x30
  411148:	mov    BYTE PTR [r9+0x5],r10b
  41114c:	vxorpd xmm0,xmm0,xmm0
  411150:	movzx  edx,dl
  411153:	vcvtsi2sd xmm0,xmm0,rdx
  411158:	vsubsd xmm0,xmm1,xmm0
  41115c:	vmulsd xmm1,xmm0,xmm15
  411161:	vcvttsd2si rdx,xmm1
  411166:	mov    r10b,dl
  411169:	add    r10b,0x30
  41116d:	mov    BYTE PTR [r9+0x6],r10b
  411171:	vxorpd xmm0,xmm0,xmm0
  411175:	movzx  edx,dl
  411178:	vcvtsi2sd xmm0,xmm0,rdx
  41117d:	vsubsd xmm0,xmm1,xmm0
  411181:	vmulsd xmm1,xmm0,xmm15
  411186:	vcvttsd2si rdx,xmm1
  41118b:	mov    r10b,dl
  41118e:	add    r10b,0x30
  411192:	mov    BYTE PTR [r9+0x7],r10b
  411196:	vxorpd xmm0,xmm0,xmm0
  41119a:	movzx  edx,dl
  41119d:	vcvtsi2sd xmm0,xmm0,rdx
  4111a2:	vsubsd xmm0,xmm1,xmm0
  4111a6:	vmulsd xmm1,xmm0,xmm15
  4111ab:	vcvttsd2si rdx,xmm1
  4111b0:	mov    r10b,dl
  4111b3:	add    r10b,0x30
  4111b7:	mov    BYTE PTR [r9+0x8],r10b
  4111bb:	vxorpd xmm0,xmm0,xmm0
  4111bf:	movzx  edx,dl
  4111c2:	vcvtsi2sd xmm0,xmm0,rdx
  4111c7:	vsubsd xmm0,xmm1,xmm0
  4111cb:	vmulsd xmm1,xmm0,xmm15
  4111d0:	vcvttsd2si rdx,xmm1
  4111d5:	mov    r10b,dl
  4111d8:	add    r10b,0x30
  4111dc:	mov    BYTE PTR [r9+0x9],r10b
  4111e0:	vxorpd xmm0,xmm0,xmm0
  4111e4:	movzx  edx,dl
  4111e7:	vcvtsi2sd xmm0,xmm0,rdx
  4111ec:	vsubsd xmm0,xmm1,xmm0
  4111f0:	vmulsd xmm1,xmm0,xmm15
  4111f5:	vcvttsd2si rdx,xmm1
  4111fa:	mov    r10b,dl
  4111fd:	add    r10b,0x30
  411201:	mov    BYTE PTR [r9+0xa],r10b
  411205:	vxorpd xmm0,xmm0,xmm0
  411209:	movzx  edx,dl
  41120c:	vcvtsi2sd xmm0,xmm0,rdx
  411211:	vsubsd xmm0,xmm1,xmm0
  411215:	vmulsd xmm1,xmm0,xmm15
  41121a:	vcvttsd2si rdx,xmm1
  41121f:	mov    r10b,dl
  411222:	add    r10b,0x30
  411226:	mov    BYTE PTR [r9+0xb],r10b
  41122a:	lea    r10,[r9+0x4]
  41122e:	vxorpd xmm0,xmm0,xmm0
  411232:	movzx  edx,dl
  411235:	vcvtsi2sd xmm0,xmm0,rdx
  41123a:	vsubsd xmm0,xmm1,xmm0
  41123e:	vmulsd xmm1,xmm0,xmm15
  411243:	vcvttsd2si rdx,xmm1
  411248:	mov    r11b,dl
  41124b:	add    r11b,0x30
  41124f:	mov    BYTE PTR [r9+0xc],r11b
  411253:	vxorpd xmm0,xmm0,xmm0
  411257:	movzx  edx,dl
  41125a:	vcvtsi2sd xmm0,xmm0,rdx
  41125f:	vsubsd xmm0,xmm1,xmm0
  411263:	vmulsd xmm1,xmm0,xmm15
  411268:	vcvttsd2si rdx,xmm1
  41126d:	mov    r11b,dl
  411270:	add    r11b,0x30
  411274:	mov    BYTE PTR [r9+0xd],r11b
  411278:	lea    r10,[r10+0x2]
  41127c:	vxorpd xmm0,xmm0,xmm0
  411280:	movzx  edx,dl
  411283:	vcvtsi2sd xmm0,xmm0,rdx
  411288:	vsubsd xmm0,xmm1,xmm0
  41128c:	vmulsd xmm1,xmm0,xmm15
  411291:	vcvttsd2si rdx,xmm1
  411296:	mov    r11b,dl
  411299:	add    r11b,0x30
  41129d:	mov    BYTE PTR [r9+0xe],r11b
  4112a1:	vxorpd xmm0,xmm0,xmm0
  4112a5:	movzx  edx,dl
  4112a8:	vcvtsi2sd xmm0,xmm0,rdx
  4112ad:	vsubsd xmm0,xmm1,xmm0
  4112b1:	vmulsd xmm1,xmm0,xmm15
  4112b6:	vcvttsd2si rdx,xmm1
  4112bb:	mov    r11b,dl
  4112be:	add    r11b,0x30
  4112c2:	mov    BYTE PTR [r9+0xf],r11b
  4112c6:	lea    r10,[r10+0x2]
  4112ca:	lea    r10,[r10+0x2]
  4112ce:	lea    r10,[r10+0x2]
  4112d2:	lea    r10,[r10+0x2]
  4112d6:	lea    r10,[r10+0x2]
  4112da:	vxorpd xmm0,xmm0,xmm0
  4112de:	movzx  edx,dl
  4112e1:	vcvtsi2sd xmm0,xmm0,rdx
  4112e6:	vsubsd xmm0,xmm1,xmm0
  4112ea:	vmulsd xmm1,xmm0,xmm15
  4112ef:	vcvttsd2si rdx,xmm1
  4112f4:	mov    r11b,dl
  4112f7:	add    r11b,0x30
  4112fb:	mov    BYTE PTR [r9+0x10],r11b
  4112ff:	vxorpd xmm0,xmm0,xmm0
  411303:	movzx  edx,dl
  411306:	vcvtsi2sd xmm0,xmm0,rdx
  41130b:	vsubsd xmm0,xmm1,xmm0
  41130f:	vmulsd xmm1,xmm0,xmm15
  411314:	vcvttsd2si rdx,xmm1
  411319:	add    dl,0x30
  41131c:	mov    BYTE PTR [r9+0x11],dl
  411320:	mov    BYTE PTR [r10+0x2],0x65
  411325:	lea    r9,[r10+0x3]
  411329:	test   r8,r8
  41132c:	jl     411335 <__swc_fn_4fa09e82_000152_6203dca2+0x695>
  41132e:	mov    BYTE PTR [r9],0x2b
  411332:	inc    r9
  411335:	mov    r10,r9
  411338:	mov    rdx,r8
  41133b:	nop    DWORD PTR [rax+rax*1+0x0]
  411340:	mov    r11,rdx
  411343:	movabs rdx,0x6666666666666667
  41134d:	mov    rax,r11
  411350:	imul   rdx
  411353:	sar    rdx,0x2
  411357:	mov    r12,rdx
  41135a:	shr    rdx,0x3f
  41135e:	add    r12,rdx
  411361:	mov    rdx,r12
  411364:	imul   r13,r12,0xa
  411368:	sub    r11,r13
  41136b:	mov    r13,QWORD PTR [rip+0x229e]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  411372:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411377:	mov    BYTE PTR [r10],r11b
  41137a:	lea    r11,[r10+0x1]
  41137e:	mov    r10,r11
  411381:	test   r12,r12
  411384:	jne    411340 <__swc_fn_4fa09e82_000152_6203dca2+0x6a0>
  411386:	test   r8,r8
  411389:	jge    411393 <__swc_fn_4fa09e82_000152_6203dca2+0x6f3>
  41138b:	mov    BYTE PTR [r11],0x2d
  41138f:	lea    r10,[r11+0x1]
  411393:	mov    BYTE PTR [r10],0x0
  411397:	sub    r10,0x1
  41139b:	nop    DWORD PTR [rax+rax*1+0x0]
  4113a0:	cmp    r9,r10
  4113a3:	jae    4115f8 <__swc_fn_4fa09e82_000152_6203dca2+0x958>
  4113a9:	mov    al,BYTE PTR [r10]
  4113ac:	mov    dl,BYTE PTR [r9]
  4113af:	mov    BYTE PTR [r10],dl
  4113b2:	sub    r10,0x1
  4113b6:	mov    BYTE PTR [r9],al
  4113b9:	inc    r9
  4113bc:	jmp    4113a0 <__swc_fn_4fa09e82_000152_6203dca2+0x700>
  4113be:	vcvttsd2si rdx,xmm1
  4113c3:	mov    r8,rdx
  4113c6:	vxorpd xmm0,xmm0,xmm0
  4113ca:	vcvtsi2sd xmm0,xmm0,rdx
  4113cf:	vsubsd xmm0,xmm1,xmm0
  4113d3:	mov    r9d,0x8
  4113d9:	vxorpd xmm2,xmm2,xmm2
  4113dd:	vcomisd xmm2,xmm0
  4113e1:	jbe    4113eb <__swc_fn_4fa09e82_000152_6203dca2+0x74b>
  4113e3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2235]        # 413620 <__swc_rdata_base_4fa09e82+0x510>
  4113eb:	test   r9d,r9d
  4113ee:	je     4113fa <__swc_fn_4fa09e82_000152_6203dca2+0x75a>
  4113f0:	vmulsd xmm0,xmm0,xmm14
  4113f5:	dec    r9d
  4113f8:	jne    4113f0 <__swc_fn_4fa09e82_000152_6203dca2+0x750>
  4113fa:	vcvttsd2si r9,xmm0
  4113ff:	mov    r10,r9
  411402:	vxorpd xmm2,xmm2,xmm2
  411406:	vcvtsi2sd xmm2,xmm2,r9
  41140b:	vsubsd xmm0,xmm0,xmm2
  41140f:	vcomisd xmm0,xmm10
  411414:	lea    r9,[r9+0x1]
  411418:	cmova  r10,r9
  41141c:	cmp    r10,0x5f5e100
  411423:	jne    41143c <__swc_fn_4fa09e82_000152_6203dca2+0x79c>
  411425:	lea    r8,[rdx-0x1]
  411429:	vxorpd xmm0,xmm0,xmm0
  41142d:	vcomisd xmm0,xmm1
  411431:	lea    rdx,[rdx+0x1]
  411435:	cmovbe r8,rdx
  411439:	xor    r10d,r10d
  41143c:	mov    r9,rcx
  41143f:	test   r8,r8
  411442:	jne    411462 <__swc_fn_4fa09e82_000152_6203dca2+0x7c2>
  411444:	vxorpd xmm0,xmm0,xmm0
  411448:	vcomisd xmm0,xmm1
  41144c:	jbe    411455 <__swc_fn_4fa09e82_000152_6203dca2+0x7b5>
  41144e:	mov    BYTE PTR [rcx],0x2d
  411451:	lea    r9,[rcx+0x1]
  411455:	mov    BYTE PTR [r9],0x30
  411459:	add    r9,0x1
  41145d:	jmp    4114fb <__swc_fn_4fa09e82_000152_6203dca2+0x85b>
  411462:	mov    r9,rcx
  411465:	mov    rdx,r8
  411468:	nop    DWORD PTR [rax+rax*1+0x0]
  411470:	mov    r11,rdx
  411473:	movabs rdx,0x6666666666666667
  41147d:	mov    r15,rax
  411480:	mov    rax,r11
  411483:	imul   rdx
  411486:	mov    r12,rdx
  411489:	mov    rax,r15
  41148c:	sar    r12,0x2
  411490:	mov    rdx,r12
  411493:	shr    rdx,0x3f
  411497:	add    r12,rdx
  41149a:	mov    rdx,r12
  41149d:	imul   r13,r12,0xa
  4114a1:	sub    r11,r13
  4114a4:	mov    r13,QWORD PTR [rip+0x2165]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  4114ab:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4114b0:	mov    BYTE PTR [r9],r11b
  4114b3:	lea    r11,[r9+0x1]
  4114b7:	mov    r9,r11
  4114ba:	test   r12,r12
  4114bd:	jne    411470 <__swc_fn_4fa09e82_000152_6203dca2+0x7d0>
  4114bf:	test   r8,r8
  4114c2:	jge    4114cc <__swc_fn_4fa09e82_000152_6203dca2+0x82c>
  4114c4:	mov    BYTE PTR [r11],0x2d
  4114c8:	lea    r9,[r11+0x1]
  4114cc:	mov    rdx,r9
  4114cf:	mov    BYTE PTR [r9],0x0
  4114d3:	sub    r9,0x1
  4114d7:	mov    r8,rcx
  4114da:	cmp    r8,r9
  4114dd:	jae    4114f8 <__swc_fn_4fa09e82_000152_6203dca2+0x858>
  4114df:	nop
  4114e0:	mov    r11b,BYTE PTR [r9]
  4114e3:	mov    r12b,BYTE PTR [r8]
  4114e6:	mov    BYTE PTR [r9],r12b
  4114e9:	sub    r9,0x1
  4114ed:	mov    BYTE PTR [r8],r11b
  4114f0:	inc    r8
  4114f3:	cmp    r8,r9
  4114f6:	jb     4114e0 <__swc_fn_4fa09e82_000152_6203dca2+0x840>
  4114f8:	mov    r9,rdx
  4114fb:	mov    BYTE PTR [r9],0x2e
  4114ff:	add    r9,0x1
  411503:	xor    r8d,r8d
  411506:	test   r10,r10
  411509:	je     41154f <__swc_fn_4fa09e82_000152_6203dca2+0x8af>
  41150b:	mov    r11d,0x989680
  411511:	cmp    r10,r11
  411514:	jge    41154f <__swc_fn_4fa09e82_000152_6203dca2+0x8af>
  411516:	cs nop WORD PTR [rax+rax*1+0x0]
  411520:	inc    r8d
  411523:	movabs rdx,0x6666666666666667
  41152d:	mov    r15,rax
  411530:	mov    rax,r11
  411533:	imul   rdx
  411536:	mov    r11,rdx
  411539:	mov    rax,r15
  41153c:	sar    r11,0x2
  411540:	mov    rdx,r11
  411543:	shr    rdx,0x3f
  411547:	add    r11,rdx
  41154a:	cmp    r10,r11
  41154d:	jl     411520 <__swc_fn_4fa09e82_000152_6203dca2+0x880>
  41154f:	test   r8d,r8d
  411552:	je     41156d <__swc_fn_4fa09e82_000152_6203dca2+0x8cd>
  411554:	cs nop WORD PTR [rax+rax*1+0x0]
  41155e:	xchg   ax,ax
  411560:	mov    BYTE PTR [r9],0x30
  411564:	add    r9,0x1
  411568:	dec    r8d
  41156b:	jne    411560 <__swc_fn_4fa09e82_000152_6203dca2+0x8c0>
  41156d:	mov    r8,r9
  411570:	mov    rdx,r10
  411573:	cs nop WORD PTR [rax+rax*1+0x0]
  41157d:	nop    DWORD PTR [rax]
  411580:	mov    r11,rdx
  411583:	movabs rdx,0x6666666666666667
  41158d:	mov    rax,r11
  411590:	imul   rdx
  411593:	sar    rdx,0x2
  411597:	mov    r12,rdx
  41159a:	shr    rdx,0x3f
  41159e:	add    r12,rdx
  4115a1:	mov    rdx,r12
  4115a4:	imul   r13,r12,0xa
  4115a8:	sub    r11,r13
  4115ab:	mov    r13,QWORD PTR [rip+0x205e]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  4115b2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4115b7:	mov    BYTE PTR [r8],r11b
  4115ba:	lea    r11,[r8+0x1]
  4115be:	mov    r8,r11
  4115c1:	test   r12,r12
  4115c4:	jne    411580 <__swc_fn_4fa09e82_000152_6203dca2+0x8e0>
  4115c6:	test   r10,r10
  4115c9:	jge    4115d3 <__swc_fn_4fa09e82_000152_6203dca2+0x933>
  4115cb:	mov    BYTE PTR [r11],0x2d
  4115cf:	lea    r8,[r11+0x1]
  4115d3:	mov    BYTE PTR [r8],0x0
  4115d7:	sub    r8,0x1
  4115db:	cmp    r9,r8
  4115de:	jae    4115f8 <__swc_fn_4fa09e82_000152_6203dca2+0x958>
  4115e0:	mov    al,BYTE PTR [r8]
  4115e3:	mov    dl,BYTE PTR [r9]
  4115e6:	mov    BYTE PTR [r8],dl
  4115e9:	sub    r8,0x1
  4115ed:	mov    BYTE PTR [r9],al
  4115f0:	inc    r9
  4115f3:	cmp    r9,r8
  4115f6:	jb     4115e0 <__swc_fn_4fa09e82_000152_6203dca2+0x940>
  4115f8:	xor    eax,eax
  4115fa:	test   rcx,rcx
  4115fd:	je     411630 <__swc_fn_4fa09e82_000152_6203dca2+0x990>
  4115ff:	mov    rdx,rcx
  411602:	mov    r8b,BYTE PTR [rdx]
  411605:	test   r8b,r8b
  411608:	je     411630 <__swc_fn_4fa09e82_000152_6203dca2+0x990>
  41160a:	cs nop WORD PTR [rax+rax*1+0x0]
  411614:	cs nop WORD PTR [rax+rax*1+0x0]
  41161e:	xchg   ax,ax
  411620:	add    rdx,0x1
  411624:	add    rax,0x1
  411628:	mov    r8b,BYTE PTR [rdx]
  41162b:	test   r8b,r8b
  41162e:	jne    411620 <__swc_fn_4fa09e82_000152_6203dca2+0x980>
  411630:	mov    QWORD PTR [rsp+0x240],rcx
  411638:	mov    QWORD PTR [rsp+0x248],rax
  411640:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  411649:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  411652:	lea    rcx,[rsp+0x250]
  41165a:	call   410430 <__swc_fn_4fa09e82_000122_2648f149>
  41165f:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  411664:	lea    rcx,[rsp+0x260]
  41166c:	vxorps xmm0,xmm0,xmm0
  411670:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  411679:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  411682:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  41168b:	vzeroupper
  41168e:	mov    DWORD PTR [rsp+0x2c0],0x0
  411699:	vmovsd xmm0,QWORD PTR [rdx]
  41169d:	vcomisd xmm0,xmm0
  4116a1:	setne  dl
  4116a4:	movzx  edx,dl
  4116a7:	setp   r8b
  4116ab:	movzx  r8d,r8b
  4116af:	or     edx,r8d
  4116b2:	test   dl,dl
  4116b4:	je     4116c1 <__swc_fn_4fa09e82_000152_6203dca2+0xa21>
  4116b6:	mov    DWORD PTR [rcx],0x6e616e
  4116bc:	jmp    411cc8 <__swc_fn_4fa09e82_000152_6203dca2+0x1028>
  4116c1:	vcomisd xmm0,xmm11
  4116c6:	ja     4116d7 <__swc_fn_4fa09e82_000152_6203dca2+0xa37>
  4116c8:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  4116d1:	vcomisd xmm6,xmm0
  4116d5:	jbe    4116fb <__swc_fn_4fa09e82_000152_6203dca2+0xa5b>
  4116d7:	vxorpd xmm1,xmm1,xmm1
  4116db:	vcomisd xmm1,xmm0
  4116df:	jbe    4116f0 <__swc_fn_4fa09e82_000152_6203dca2+0xa50>
  4116e1:	mov    DWORD PTR [rcx],0x666e692d
  4116e7:	mov    BYTE PTR [rcx+0x4],0x0
  4116eb:	jmp    411cc8 <__swc_fn_4fa09e82_000152_6203dca2+0x1028>
  4116f0:	mov    DWORD PTR [rcx],0x666e69
  4116f6:	jmp    411cc8 <__swc_fn_4fa09e82_000152_6203dca2+0x1028>
  4116fb:	vcomisd xmm0,xmm13
  411700:	jae    41170c <__swc_fn_4fa09e82_000152_6203dca2+0xa6c>
  411702:	vcomisd xmm12,xmm0
  411706:	jbe    411a6e <__swc_fn_4fa09e82_000152_6203dca2+0xdce>
  41170c:	vmovups xmm1,xmm0
  411710:	vxorpd xmm2,xmm2,xmm2
  411714:	vcomisd xmm2,xmm0
  411718:	jbe    411728 <__swc_fn_4fa09e82_000152_6203dca2+0xa88>
  41171a:	vmovsd xmm0,xmm0,xmm1
  41171e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x1efa]        # 413620 <__swc_rdata_base_4fa09e82+0x510>
  411726:	jmp    41172c <__swc_fn_4fa09e82_000152_6203dca2+0xa8c>
  411728:	vmovsd xmm0,xmm0,xmm1
  41172c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  411735:	xor    r8d,r8d
  411738:	vcomisd xmm0,xmm6
  41173c:	jb     41174e <__swc_fn_4fa09e82_000152_6203dca2+0xaae>
  41173e:	xchg   ax,ax
  411740:	vdivsd xmm0,xmm0,xmm6
  411744:	add    r8,0x1
  411748:	vcomisd xmm0,xmm6
  41174c:	jae    411740 <__swc_fn_4fa09e82_000152_6203dca2+0xaa0>
  41174e:	mov    r9,rcx
  411751:	vxorpd xmm2,xmm2,xmm2
  411755:	vcomisd xmm2,xmm1
  411759:	jbe    411762 <__swc_fn_4fa09e82_000152_6203dca2+0xac2>
  41175b:	mov    BYTE PTR [rcx],0x2d
  41175e:	lea    r9,[rcx+0x1]
  411762:	vcvttsd2si rdx,xmm0
  411767:	mov    r10b,dl
  41176a:	add    r10b,0x30
  41176e:	mov    BYTE PTR [r9],r10b
  411771:	vxorpd xmm1,xmm1,xmm1
  411775:	movzx  edx,dl
  411778:	vcvtsi2sd xmm1,xmm1,rdx
  41177d:	vsubsd xmm0,xmm0,xmm1
  411781:	vmulsd xmm0,xmm0,xmm6
  411785:	mov    BYTE PTR [r9+0x1],0x2e
  41178a:	vcvttsd2si rdx,xmm0
  41178f:	mov    r10b,dl
  411792:	add    r10b,0x30
  411796:	mov    BYTE PTR [r9+0x2],r10b
  41179a:	vxorpd xmm1,xmm1,xmm1
  41179e:	movzx  edx,dl
  4117a1:	vcvtsi2sd xmm1,xmm1,rdx
  4117a6:	vsubsd xmm0,xmm0,xmm1
  4117aa:	vmulsd xmm0,xmm0,xmm6
  4117ae:	vcvttsd2si rdx,xmm0
  4117b3:	mov    r10b,dl
  4117b6:	add    r10b,0x30
  4117ba:	mov    BYTE PTR [r9+0x3],r10b
  4117be:	vxorpd xmm1,xmm1,xmm1
  4117c2:	movzx  edx,dl
  4117c5:	vcvtsi2sd xmm1,xmm1,rdx
  4117ca:	vsubsd xmm0,xmm0,xmm1
  4117ce:	vmulsd xmm0,xmm0,xmm6
  4117d2:	vcvttsd2si rdx,xmm0
  4117d7:	mov    r10b,dl
  4117da:	add    r10b,0x30
  4117de:	mov    BYTE PTR [r9+0x4],r10b
  4117e2:	vxorpd xmm1,xmm1,xmm1
  4117e6:	movzx  edx,dl
  4117e9:	vcvtsi2sd xmm1,xmm1,rdx
  4117ee:	vsubsd xmm0,xmm0,xmm1
  4117f2:	vmulsd xmm0,xmm0,xmm6
  4117f6:	vcvttsd2si rdx,xmm0
  4117fb:	mov    r10b,dl
  4117fe:	add    r10b,0x30
  411802:	mov    BYTE PTR [r9+0x5],r10b
  411806:	vxorpd xmm1,xmm1,xmm1
  41180a:	movzx  edx,dl
  41180d:	vcvtsi2sd xmm1,xmm1,rdx
  411812:	vsubsd xmm0,xmm0,xmm1
  411816:	vmulsd xmm0,xmm0,xmm6
  41181a:	vcvttsd2si rdx,xmm0
  41181f:	mov    r10b,dl
  411822:	add    r10b,0x30
  411826:	mov    BYTE PTR [r9+0x6],r10b
  41182a:	vxorpd xmm1,xmm1,xmm1
  41182e:	movzx  edx,dl
  411831:	vcvtsi2sd xmm1,xmm1,rdx
  411836:	vsubsd xmm0,xmm0,xmm1
  41183a:	vmulsd xmm0,xmm0,xmm6
  41183e:	vcvttsd2si rdx,xmm0
  411843:	mov    r10b,dl
  411846:	add    r10b,0x30
  41184a:	mov    BYTE PTR [r9+0x7],r10b
  41184e:	vxorpd xmm1,xmm1,xmm1
  411852:	movzx  edx,dl
  411855:	vcvtsi2sd xmm1,xmm1,rdx
  41185a:	vsubsd xmm0,xmm0,xmm1
  41185e:	vmulsd xmm0,xmm0,xmm6
  411862:	vcvttsd2si rdx,xmm0
  411867:	mov    r10b,dl
  41186a:	add    r10b,0x30
  41186e:	mov    BYTE PTR [r9+0x8],r10b
  411872:	vxorpd xmm1,xmm1,xmm1
  411876:	movzx  edx,dl
  411879:	vcvtsi2sd xmm1,xmm1,rdx
  41187e:	vsubsd xmm0,xmm0,xmm1
  411882:	vmulsd xmm0,xmm0,xmm6
  411886:	vcvttsd2si rdx,xmm0
  41188b:	mov    r10b,dl
  41188e:	add    r10b,0x30
  411892:	mov    BYTE PTR [r9+0x9],r10b
  411896:	vxorpd xmm1,xmm1,xmm1
  41189a:	movzx  edx,dl
  41189d:	vcvtsi2sd xmm1,xmm1,rdx
  4118a2:	vsubsd xmm0,xmm0,xmm1
  4118a6:	vmulsd xmm0,xmm0,xmm6
  4118aa:	vcvttsd2si rdx,xmm0
  4118af:	mov    r10b,dl
  4118b2:	add    r10b,0x30
  4118b6:	mov    BYTE PTR [r9+0xa],r10b
  4118ba:	vxorpd xmm1,xmm1,xmm1
  4118be:	movzx  edx,dl
  4118c1:	vcvtsi2sd xmm1,xmm1,rdx
  4118c6:	vsubsd xmm0,xmm0,xmm1
  4118ca:	vmulsd xmm0,xmm0,xmm6
  4118ce:	vcvttsd2si rdx,xmm0
  4118d3:	mov    r10b,dl
  4118d6:	add    r10b,0x30
  4118da:	mov    BYTE PTR [r9+0xb],r10b
  4118de:	lea    r10,[r9+0x4]
  4118e2:	vxorpd xmm1,xmm1,xmm1
  4118e6:	movzx  edx,dl
  4118e9:	vcvtsi2sd xmm1,xmm1,rdx
  4118ee:	vsubsd xmm0,xmm0,xmm1
  4118f2:	vmulsd xmm0,xmm0,xmm6
  4118f6:	vcvttsd2si rdx,xmm0
  4118fb:	mov    r11b,dl
  4118fe:	add    r11b,0x30
  411902:	mov    BYTE PTR [r9+0xc],r11b
  411906:	vxorpd xmm1,xmm1,xmm1
  41190a:	movzx  edx,dl
  41190d:	vcvtsi2sd xmm1,xmm1,rdx
  411912:	vsubsd xmm0,xmm0,xmm1
  411916:	vmulsd xmm0,xmm0,xmm6
  41191a:	vcvttsd2si rdx,xmm0
  41191f:	mov    r11b,dl
  411922:	add    r11b,0x30
  411926:	mov    BYTE PTR [r9+0xd],r11b
  41192a:	lea    r10,[r10+0x2]
  41192e:	vxorpd xmm1,xmm1,xmm1
  411932:	movzx  edx,dl
  411935:	vcvtsi2sd xmm1,xmm1,rdx
  41193a:	vsubsd xmm0,xmm0,xmm1
  41193e:	vmulsd xmm0,xmm0,xmm6
  411942:	vcvttsd2si rdx,xmm0
  411947:	mov    r11b,dl
  41194a:	add    r11b,0x30
  41194e:	mov    BYTE PTR [r9+0xe],r11b
  411952:	vxorpd xmm1,xmm1,xmm1
  411956:	movzx  edx,dl
  411959:	vcvtsi2sd xmm1,xmm1,rdx
  41195e:	vsubsd xmm0,xmm0,xmm1
  411962:	vmulsd xmm0,xmm0,xmm6
  411966:	vcvttsd2si rdx,xmm0
  41196b:	mov    r11b,dl
  41196e:	add    r11b,0x30
  411972:	mov    BYTE PTR [r9+0xf],r11b
  411976:	lea    r10,[r10+0x2]
  41197a:	lea    r10,[r10+0x2]
  41197e:	lea    r10,[r10+0x2]
  411982:	lea    r10,[r10+0x2]
  411986:	lea    r10,[r10+0x2]
  41198a:	vxorpd xmm1,xmm1,xmm1
  41198e:	movzx  edx,dl
  411991:	vcvtsi2sd xmm1,xmm1,rdx
  411996:	vsubsd xmm0,xmm0,xmm1
  41199a:	vmulsd xmm0,xmm0,xmm6
  41199e:	vcvttsd2si rdx,xmm0
  4119a3:	mov    r11b,dl
  4119a6:	add    r11b,0x30
  4119aa:	mov    BYTE PTR [r9+0x10],r11b
  4119ae:	vxorpd xmm1,xmm1,xmm1
  4119b2:	movzx  edx,dl
  4119b5:	vcvtsi2sd xmm1,xmm1,rdx
  4119ba:	vsubsd xmm0,xmm0,xmm1
  4119be:	vmulsd xmm0,xmm0,xmm6
  4119c2:	vcvttsd2si rdx,xmm0
  4119c7:	add    dl,0x30
  4119ca:	mov    BYTE PTR [r9+0x11],dl
  4119ce:	mov    BYTE PTR [r10+0x2],0x65
  4119d3:	lea    r9,[r10+0x3]
  4119d7:	test   r8,r8
  4119da:	jl     4119e3 <__swc_fn_4fa09e82_000152_6203dca2+0xd43>
  4119dc:	mov    BYTE PTR [r9],0x2b
  4119e0:	inc    r9
  4119e3:	mov    r10,r9
  4119e6:	mov    rdx,r8
  4119e9:	nop    DWORD PTR [rax+0x0]
  4119f0:	mov    r11,rdx
  4119f3:	movabs rdx,0x6666666666666667
  4119fd:	mov    rax,r11
  411a00:	imul   rdx
  411a03:	sar    rdx,0x2
  411a07:	mov    r12,rdx
  411a0a:	shr    rdx,0x3f
  411a0e:	add    r12,rdx
  411a11:	mov    rdx,r12
  411a14:	imul   r13,r12,0xa
  411a18:	sub    r11,r13
  411a1b:	mov    r13,QWORD PTR [rip+0x1bee]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  411a22:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411a27:	mov    BYTE PTR [r10],r11b
  411a2a:	lea    r11,[r10+0x1]
  411a2e:	mov    r10,r11
  411a31:	test   r12,r12
  411a34:	jne    4119f0 <__swc_fn_4fa09e82_000152_6203dca2+0xd50>
  411a36:	test   r8,r8
  411a39:	jge    411a43 <__swc_fn_4fa09e82_000152_6203dca2+0xda3>
  411a3b:	mov    BYTE PTR [r11],0x2d
  411a3f:	lea    r10,[r11+0x1]
  411a43:	mov    BYTE PTR [r10],0x0
  411a47:	sub    r10,0x1
  411a4b:	nop    DWORD PTR [rax+rax*1+0x0]
  411a50:	cmp    r9,r10
  411a53:	jae    411cc8 <__swc_fn_4fa09e82_000152_6203dca2+0x1028>
  411a59:	mov    al,BYTE PTR [r10]
  411a5c:	mov    dl,BYTE PTR [r9]
  411a5f:	mov    BYTE PTR [r10],dl
  411a62:	sub    r10,0x1
  411a66:	mov    BYTE PTR [r9],al
  411a69:	inc    r9
  411a6c:	jmp    411a50 <__swc_fn_4fa09e82_000152_6203dca2+0xdb0>
  411a6e:	vcvttsd2si rdx,xmm0
  411a73:	mov    r8,rdx
  411a76:	vxorpd xmm1,xmm1,xmm1
  411a7a:	vcvtsi2sd xmm1,xmm1,rdx
  411a7f:	vsubsd xmm1,xmm0,xmm1
  411a83:	mov    r9d,0x8
  411a89:	vxorpd xmm2,xmm2,xmm2
  411a8d:	vcomisd xmm2,xmm1
  411a91:	ja     411a9e <__swc_fn_4fa09e82_000152_6203dca2+0xdfe>
  411a93:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  411a9c:	jmp    411aaf <__swc_fn_4fa09e82_000152_6203dca2+0xe0f>
  411a9e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1b7a]        # 413620 <__swc_rdata_base_4fa09e82+0x510>
  411aa6:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  411aaf:	test   r9d,r9d
  411ab2:	je     411ac9 <__swc_fn_4fa09e82_000152_6203dca2+0xe29>
  411ab4:	cs nop WORD PTR [rax+rax*1+0x0]
  411abe:	xchg   ax,ax
  411ac0:	vmulsd xmm1,xmm1,xmm6
  411ac4:	dec    r9d
  411ac7:	jne    411ac0 <__swc_fn_4fa09e82_000152_6203dca2+0xe20>
  411ac9:	vcvttsd2si r9,xmm1
  411ace:	mov    r10,r9
  411ad1:	vxorpd xmm2,xmm2,xmm2
  411ad5:	vcvtsi2sd xmm2,xmm2,r9
  411ada:	vsubsd xmm1,xmm1,xmm2
  411ade:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  411ae7:	vcomisd xmm1,xmm6
  411aeb:	lea    r9,[r9+0x1]
  411aef:	cmova  r10,r9
  411af3:	cmp    r10,0x5f5e100
  411afa:	jne    411b13 <__swc_fn_4fa09e82_000152_6203dca2+0xe73>
  411afc:	lea    r8,[rdx-0x1]
  411b00:	vxorpd xmm1,xmm1,xmm1
  411b04:	vcomisd xmm1,xmm0
  411b08:	lea    rdx,[rdx+0x1]
  411b0c:	cmovbe r8,rdx
  411b10:	xor    r10d,r10d
  411b13:	mov    r9,rcx
  411b16:	test   r8,r8
  411b19:	jne    411b39 <__swc_fn_4fa09e82_000152_6203dca2+0xe99>
  411b1b:	vxorpd xmm1,xmm1,xmm1
  411b1f:	vcomisd xmm1,xmm0
  411b23:	jbe    411b2c <__swc_fn_4fa09e82_000152_6203dca2+0xe8c>
  411b25:	mov    BYTE PTR [rcx],0x2d
  411b28:	lea    r9,[rcx+0x1]
  411b2c:	mov    BYTE PTR [r9],0x30
  411b30:	add    r9,0x1
  411b34:	jmp    411bcb <__swc_fn_4fa09e82_000152_6203dca2+0xf2b>
  411b39:	mov    r9,rcx
  411b3c:	mov    rdx,r8
  411b3f:	nop
  411b40:	mov    r11,rdx
  411b43:	movabs rdx,0x6666666666666667
  411b4d:	mov    r15,rax
  411b50:	mov    rax,r11
  411b53:	imul   rdx
  411b56:	mov    r12,rdx
  411b59:	mov    rax,r15
  411b5c:	sar    r12,0x2
  411b60:	mov    rdx,r12
  411b63:	shr    rdx,0x3f
  411b67:	add    r12,rdx
  411b6a:	mov    rdx,r12
  411b6d:	imul   r13,r12,0xa
  411b71:	sub    r11,r13
  411b74:	mov    r13,QWORD PTR [rip+0x1a95]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  411b7b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411b80:	mov    BYTE PTR [r9],r11b
  411b83:	lea    r11,[r9+0x1]
  411b87:	mov    r9,r11
  411b8a:	test   r12,r12
  411b8d:	jne    411b40 <__swc_fn_4fa09e82_000152_6203dca2+0xea0>
  411b8f:	test   r8,r8
  411b92:	jge    411b9c <__swc_fn_4fa09e82_000152_6203dca2+0xefc>
  411b94:	mov    BYTE PTR [r11],0x2d
  411b98:	lea    r9,[r11+0x1]
  411b9c:	mov    rdx,r9
  411b9f:	mov    BYTE PTR [r9],0x0
  411ba3:	sub    r9,0x1
  411ba7:	mov    r8,rcx
  411baa:	cmp    r8,r9
  411bad:	jae    411bc8 <__swc_fn_4fa09e82_000152_6203dca2+0xf28>
  411baf:	nop
  411bb0:	mov    r11b,BYTE PTR [r9]
  411bb3:	mov    r12b,BYTE PTR [r8]
  411bb6:	mov    BYTE PTR [r9],r12b
  411bb9:	sub    r9,0x1
  411bbd:	mov    BYTE PTR [r8],r11b
  411bc0:	inc    r8
  411bc3:	cmp    r8,r9
  411bc6:	jb     411bb0 <__swc_fn_4fa09e82_000152_6203dca2+0xf10>
  411bc8:	mov    r9,rdx
  411bcb:	mov    BYTE PTR [r9],0x2e
  411bcf:	add    r9,0x1
  411bd3:	xor    r8d,r8d
  411bd6:	test   r10,r10
  411bd9:	je     411c1f <__swc_fn_4fa09e82_000152_6203dca2+0xf7f>
  411bdb:	mov    r11d,0x989680
  411be1:	cmp    r10,r11
  411be4:	jge    411c1f <__swc_fn_4fa09e82_000152_6203dca2+0xf7f>
  411be6:	cs nop WORD PTR [rax+rax*1+0x0]
  411bf0:	inc    r8d
  411bf3:	movabs rdx,0x6666666666666667
  411bfd:	mov    r15,rax
  411c00:	mov    rax,r11
  411c03:	imul   rdx
  411c06:	mov    r11,rdx
  411c09:	mov    rax,r15
  411c0c:	sar    r11,0x2
  411c10:	mov    rdx,r11
  411c13:	shr    rdx,0x3f
  411c17:	add    r11,rdx
  411c1a:	cmp    r10,r11
  411c1d:	jl     411bf0 <__swc_fn_4fa09e82_000152_6203dca2+0xf50>
  411c1f:	test   r8d,r8d
  411c22:	je     411c3d <__swc_fn_4fa09e82_000152_6203dca2+0xf9d>
  411c24:	cs nop WORD PTR [rax+rax*1+0x0]
  411c2e:	xchg   ax,ax
  411c30:	mov    BYTE PTR [r9],0x30
  411c34:	add    r9,0x1
  411c38:	dec    r8d
  411c3b:	jne    411c30 <__swc_fn_4fa09e82_000152_6203dca2+0xf90>
  411c3d:	mov    r8,r9
  411c40:	mov    rdx,r10
  411c43:	cs nop WORD PTR [rax+rax*1+0x0]
  411c4d:	nop    DWORD PTR [rax]
  411c50:	mov    r11,rdx
  411c53:	movabs rdx,0x6666666666666667
  411c5d:	mov    rax,r11
  411c60:	imul   rdx
  411c63:	sar    rdx,0x2
  411c67:	mov    r12,rdx
  411c6a:	shr    rdx,0x3f
  411c6e:	add    r12,rdx
  411c71:	mov    rdx,r12
  411c74:	imul   r13,r12,0xa
  411c78:	sub    r11,r13
  411c7b:	mov    r13,QWORD PTR [rip+0x198e]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  411c82:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411c87:	mov    BYTE PTR [r8],r11b
  411c8a:	lea    r11,[r8+0x1]
  411c8e:	mov    r8,r11
  411c91:	test   r12,r12
  411c94:	jne    411c50 <__swc_fn_4fa09e82_000152_6203dca2+0xfb0>
  411c96:	test   r10,r10
  411c99:	jge    411ca3 <__swc_fn_4fa09e82_000152_6203dca2+0x1003>
  411c9b:	mov    BYTE PTR [r11],0x2d
  411c9f:	lea    r8,[r11+0x1]
  411ca3:	mov    BYTE PTR [r8],0x0
  411ca7:	sub    r8,0x1
  411cab:	cmp    r9,r8
  411cae:	jae    411cc8 <__swc_fn_4fa09e82_000152_6203dca2+0x1028>
  411cb0:	mov    al,BYTE PTR [r8]
  411cb3:	mov    dl,BYTE PTR [r9]
  411cb6:	mov    BYTE PTR [r8],dl
  411cb9:	sub    r8,0x1
  411cbd:	mov    BYTE PTR [r9],al
  411cc0:	inc    r9
  411cc3:	cmp    r9,r8
  411cc6:	jb     411cb0 <__swc_fn_4fa09e82_000152_6203dca2+0x1010>
  411cc8:	xor    eax,eax
  411cca:	test   rcx,rcx
  411ccd:	je     411cf0 <__swc_fn_4fa09e82_000152_6203dca2+0x1050>
  411ccf:	mov    rdx,rcx
  411cd2:	mov    r8b,BYTE PTR [rdx]
  411cd5:	test   r8b,r8b
  411cd8:	je     411cf0 <__swc_fn_4fa09e82_000152_6203dca2+0x1050>
  411cda:	nop    WORD PTR [rax+rax*1+0x0]
  411ce0:	add    rdx,0x1
  411ce4:	add    rax,0x1
  411ce8:	mov    r8b,BYTE PTR [rdx]
  411ceb:	test   r8b,r8b
  411cee:	jne    411ce0 <__swc_fn_4fa09e82_000152_6203dca2+0x1040>
  411cf0:	mov    QWORD PTR [rsp+0x3f8],rcx
  411cf8:	mov    QWORD PTR [rsp+0x400],rax
  411d00:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  411d09:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  411d12:	lea    rcx,[rsp+0x408]
  411d1a:	call   410430 <__swc_fn_4fa09e82_000122_2648f149>
  411d1f:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  411d21:	mov    rcx,rdx
  411d24:	call   410430 <__swc_fn_4fa09e82_000122_2648f149>
  411d29:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  411d2b:	mov    al,BYTE PTR [rdx]
  411d2d:	test   al,al
  411d2f:	je     411d3a <__swc_fn_4fa09e82_000152_6203dca2+0x109a>
  411d31:	lea    rax,[rip+0x18f8]        # 413630 <__swc_rdata_base_4fa09e82+0x520>
  411d38:	jmp    411d41 <__swc_fn_4fa09e82_000152_6203dca2+0x10a1>
  411d3a:	lea    rax,[rip+0x18ff]        # 413640 <__swc_rdata_base_4fa09e82+0x530>
  411d41:	mov    rcx,rax
  411d44:	call   410430 <__swc_fn_4fa09e82_000122_2648f149>
  411d49:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  411d4b:	lea    rcx,[rip+0x18fe]        # 413650 <__swc_rdata_base_4fa09e82+0x540>
  411d52:	call   410430 <__swc_fn_4fa09e82_000122_2648f149>
  411d57:	jmp    411d65 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  411d59:	lea    rcx,[rip+0x18f0]        # 413650 <__swc_rdata_base_4fa09e82+0x540>
  411d60:	call   410430 <__swc_fn_4fa09e82_000122_2648f149>
  411d65:	add    rdi,0x1
  411d69:	sub    rsi,0x1
  411d6d:	vmovups xmm0,xmm12
  411d72:	vmovsd xmm6,QWORD PTR [rip+0x18e6]        # 413660 <__swc_rdata_base_4fa09e82+0x550>
  411d7a:	test   rsi,rsi
  411d7d:	jne    410db0 <__swc_fn_4fa09e82_000152_6203dca2+0x110>
  411d83:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  411d8c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411d95:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  411d9e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411da7:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411db0:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411db9:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411dc2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  411dcb:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411dd4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  411ddd:	add    rsp,0x4e8
  411de4:	pop    r15
  411de6:	pop    r13
  411de8:	pop    r12
  411dea:	pop    rdi
  411deb:	pop    rsi
  411dec:	pop    rbx
  411ded:	ret
	...

0000000000411df0 <__swc_fn_4fa09e82_000155_86f1d437>:
  411df0:	vxorps xmm0,xmm0,xmm0
  411df4:	vmovups XMMWORD PTR [rcx],xmm0
  411df8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411dfd:	ret
	...

0000000000411e00 <__swc_fn_4fa09e82_000158_86f1d437>:
  411e00:	vxorps xmm0,xmm0,xmm0
  411e04:	vmovups XMMWORD PTR [rcx],xmm0
  411e08:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411e0d:	vxorps xmm0,xmm0,xmm0
  411e11:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411e16:	vmovups xmm0,XMMWORD PTR [rip+0x1952]        # 413770 <__swc_rdata_base_4fa09e82+0x660>
  411e1e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411e23:	vxorps xmm0,xmm0,xmm0
  411e27:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411e2c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411e31:	vxorps xmm0,xmm0,xmm0
  411e35:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411e3a:	mov    QWORD PTR [rcx+0x70],0x0
  411e42:	ret
	...

0000000000411e50 <__swc_fn_4fa09e82_000161_86f1d437>:
  411e50:	vxorps xmm0,xmm0,xmm0
  411e54:	vmovups XMMWORD PTR [rcx],xmm0
  411e58:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411e5d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411e62:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411e67:	ret
	...

0000000000411e70 <__swc_fn_4fa09e82_000164_e36363a8>:
  411e70:	push   rsi
  411e71:	push   rdi
  411e72:	sub    rsp,0x8
  411e76:	mov    rsi,rcx
  411e79:	mov    rdi,QWORD PTR [rsi+0x50]
  411e7d:	test   rdi,rdi
  411e80:	je     411e87 <__swc_fn_4fa09e82_000164_e36363a8+0x17>
  411e82:	mov    rcx,rsi
  411e85:	call   rdi
  411e87:	mov    QWORD PTR [rsi+0x20],0x0
  411e8f:	mov    rax,QWORD PTR [rsi+0x30]
  411e93:	test   rax,rax
  411e96:	je     411ec4 <__swc_fn_4fa09e82_000164_e36363a8+0x54>
  411e98:	nop    DWORD PTR [rax+rax*1+0x0]
  411ea0:	mov    rdi,QWORD PTR [rax+0x8]
  411ea4:	mov    rcx,rsi
  411ea7:	mov    rdx,QWORD PTR [rax+0x10]
  411eab:	mov    rax,QWORD PTR [rax+0x18]
  411eaf:	mov    r8,rax
  411eb2:	call   40a310 <__swc_fn_4fa09e82_000162_47b270e1>
  411eb7:	mov    QWORD PTR [rsi+0x30],rdi
  411ebb:	mov    rax,QWORD PTR [rsi+0x30]
  411ebf:	test   rax,rax
  411ec2:	jne    411ea0 <__swc_fn_4fa09e82_000164_e36363a8+0x30>
  411ec4:	mov    QWORD PTR [rsi+0x38],0x0
  411ecc:	add    rsp,0x8
  411ed0:	pop    rdi
  411ed1:	pop    rsi
  411ed2:	ret
	...

0000000000411ee0 <__swc_fn_4fa09e82_000167_016ee66a>:
  411ee0:	push   rbx
  411ee1:	push   rsi
  411ee2:	push   rdi
  411ee3:	push   r12
  411ee5:	sub    rsp,0x188
  411eec:	mov    rbx,rcx
  411eef:	lea    rsi,[rip+0x14e92]        # 426d88 <__swc_bss_base_4fa09e82+0x2d48>
  411ef6:	mov    rcx,rsi
  411ef9:	call   409d20 <__swc_fn_4fa09e82_000141_86bb0f90>
  411efe:	mov    rax,QWORD PTR [rip+0x14e8b]        # 426d90 <__swc_bss_base_4fa09e82+0x2d50>
  411f05:	mov    rdi,rax
  411f08:	test   rdi,rdi
  411f0b:	je     411f39 <__swc_fn_4fa09e82_000167_016ee66a+0x59>
  411f0d:	nop    DWORD PTR [rax]
  411f10:	cmp    QWORD PTR [rdi+0x8],rbx
  411f14:	jne    411f2e <__swc_fn_4fa09e82_000167_016ee66a+0x4e>
  411f16:	mov    rcx,rsi
  411f19:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  411f1e:	mov    rax,rdi
  411f21:	add    rsp,0x188
  411f28:	pop    r12
  411f2a:	pop    rdi
  411f2b:	pop    rsi
  411f2c:	pop    rbx
  411f2d:	ret
  411f2e:	mov    rax,QWORD PTR [rdi]
  411f31:	mov    rdi,rax
  411f34:	test   rax,rax
  411f37:	jne    411f10 <__swc_fn_4fa09e82_000167_016ee66a+0x30>
  411f39:	call   40d5a0 <__swc_fn_4fa09e82_000145_d299b428>
  411f3e:	mov    rdi,rax
  411f41:	test   rax,rax
  411f44:	jne    411f5d <__swc_fn_4fa09e82_000167_016ee66a+0x7d>
  411f46:	mov    rcx,rsi
  411f49:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  411f4e:	xor    eax,eax
  411f50:	add    rsp,0x188
  411f57:	pop    r12
  411f59:	pop    rdi
  411f5a:	pop    rsi
  411f5b:	pop    rbx
  411f5c:	ret
  411f5d:	lea    rax,[rsp+0x18]
  411f62:	mov    QWORD PTR [rax+0x10],0x0
  411f6a:	mov    QWORD PTR [rax+0x18],0x0
  411f72:	mov    DWORD PTR [rax+0x20],0x0
  411f79:	mov    BYTE PTR [rax+0x24],0x0
  411f7d:	mov    rax,QWORD PTR [rip+0x14e0c]        # 426d90 <__swc_bss_base_4fa09e82+0x2d50>
  411f84:	mov    QWORD PTR [rsp+0x18],rax
  411f89:	mov    QWORD PTR [rsp+0x20],rbx
  411f8e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411f94:	vmovups XMMWORD PTR [rdi],xmm0
  411f98:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411f9e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411fa3:	mov    rax,QWORD PTR [rsp+0x38]
  411fa8:	mov    QWORD PTR [rdi+0x20],rax
  411fac:	mov    QWORD PTR [rip+0x14ddd],rdi        # 426d90 <__swc_bss_base_4fa09e82+0x2d50>
  411fb3:	lea    rax,[rsp+0x40]
  411fb8:	mov    QWORD PTR [rax],0x0
  411fbf:	mov    rcx,rbx
  411fc2:	mov    rdx,rax
  411fc5:	call   409e00 <__swc_fn_4fa09e82_000147_1534de9a>
  411fca:	mov    rbx,rax
  411fcd:	test   rax,rax
  411fd0:	jne    411fea <__swc_fn_4fa09e82_000167_016ee66a+0x10a>
  411fd2:	mov    rcx,rsi
  411fd5:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  411fda:	mov    rax,rdi
  411fdd:	add    rsp,0x188
  411fe4:	pop    r12
  411fe6:	pop    rdi
  411fe7:	pop    rsi
  411fe8:	pop    rbx
  411fe9:	ret
  411fea:	lea    r12,[rsp+0x50]
  411fef:	mov    QWORD PTR [r12],0x0
  411ff7:	mov    rcx,rbx
  411ffa:	mov    rdx,QWORD PTR [rsp+0x40]
  411fff:	mov    r8,r12
  412002:	call   40d650 <__swc_fn_4fa09e82_000148_162f363d>
  412007:	test   rax,rax
  41200a:	jne    412024 <__swc_fn_4fa09e82_000167_016ee66a+0x144>
  41200c:	mov    rcx,rsi
  41200f:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  412014:	mov    rax,rdi
  412017:	add    rsp,0x188
  41201e:	pop    r12
  412020:	pop    rdi
  412021:	pop    rsi
  412022:	pop    rbx
  412023:	ret
  412024:	cmp    QWORD PTR [r12],0x10
  412029:	jb     41212c <__swc_fn_4fa09e82_000167_016ee66a+0x24c>
  41202f:	mov    ecx,DWORD PTR [rax]
  412031:	cmp    ecx,0x42445753
  412037:	jne    41212c <__swc_fn_4fa09e82_000167_016ee66a+0x24c>
  41203d:	mov    ecx,DWORD PTR [rax+0x4]
  412040:	cmp    ecx,0x1
  412043:	jne    41212c <__swc_fn_4fa09e82_000167_016ee66a+0x24c>
  412049:	mov    ecx,DWORD PTR [rax+0x8]
  41204c:	mov    edx,DWORD PTR [rax+0xc]
  41204f:	imul   r8,rcx,0x14
  412053:	mov    r9,QWORD PTR [rsp+0x50]
  412058:	sub    r9,0x10
  41205c:	cmp    r8,r9
  41205f:	ja     41212c <__swc_fn_4fa09e82_000167_016ee66a+0x24c>
  412065:	lea    r8,[r8+0x10]
  412069:	cmp    rdx,r8
  41206c:	jb     41212c <__swc_fn_4fa09e82_000167_016ee66a+0x24c>
  412072:	mov    r8,QWORD PTR [rsp+0x50]
  412077:	cmp    rdx,r8
  41207a:	ja     41212c <__swc_fn_4fa09e82_000167_016ee66a+0x24c>
  412080:	xor    r8d,r8d
  412083:	test   rcx,rcx
  412086:	jbe    412152 <__swc_fn_4fa09e82_000167_016ee66a+0x272>
  41208c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  412092:	cs nop WORD PTR [rax+rax*1+0x0]
  41209c:	nop    DWORD PTR [rax+0x0]
  4120a0:	imul   r9,r8,0x14
  4120a4:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  4120a9:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  4120ae:	add    r10,r11
  4120b1:	movabs r11,0x100000000
  4120bb:	cmp    r10,r11
  4120be:	ja     41212c <__swc_fn_4fa09e82_000167_016ee66a+0x24c>
  4120c0:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  4120c5:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  4120ca:	test   r10d,r10d
  4120cd:	setne  r11b
  4120d1:	je     4120eb <__swc_fn_4fa09e82_000167_016ee66a+0x20b>
  4120d3:	cmp    r10d,edx
  4120d6:	setb   r11b
  4120da:	jb     4120eb <__swc_fn_4fa09e82_000167_016ee66a+0x20b>
  4120dc:	vmovq  r11,xmm1
  4120e1:	cmp    r10,r11
  4120e4:	setae  r10b
  4120e8:	mov    r11b,r10b
  4120eb:	mov    r10,r11
  4120ee:	test   r11b,r11b
  4120f1:	jne    412118 <__swc_fn_4fa09e82_000167_016ee66a+0x238>
  4120f3:	test   r9d,r9d
  4120f6:	setne  r10b
  4120fa:	je     412118 <__swc_fn_4fa09e82_000167_016ee66a+0x238>
  4120fc:	cmp    r9d,edx
  4120ff:	setb   r10b
  412103:	jb     412118 <__swc_fn_4fa09e82_000167_016ee66a+0x238>
  412105:	vmovq  r10,xmm1
  41210a:	cmp    r9,r10
  41210d:	setae  r9b
  412111:	movzx  r9d,r9b
  412115:	mov    r10b,r9b
  412118:	test   r10b,r10b
  41211b:	jne    41212c <__swc_fn_4fa09e82_000167_016ee66a+0x24c>
  41211d:	add    r8,0x1
  412121:	cmp    r8,rcx
  412124:	jb     4120a0 <__swc_fn_4fa09e82_000167_016ee66a+0x1c0>
  41212a:	jmp    412152 <__swc_fn_4fa09e82_000167_016ee66a+0x272>
  41212c:	xor    ecx,ecx
  41212e:	cmp    rax,rbx
  412131:	cmovne rcx,rax
  412135:	call   410bf0 <__swc_fn_4fa09e82_000149_d7edc04f>
  41213a:	mov    rcx,rsi
  41213d:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  412142:	mov    rax,rdi
  412145:	add    rsp,0x188
  41214c:	pop    r12
  41214e:	pop    rdi
  41214f:	pop    rsi
  412150:	pop    rbx
  412151:	ret
  412152:	mov    QWORD PTR [rdi+0x10],rax
  412156:	mov    rcx,QWORD PTR [rsp+0x50]
  41215b:	mov    QWORD PTR [rdi+0x18],rcx
  41215f:	mov    eax,DWORD PTR [rax+0x8]
  412162:	mov    DWORD PTR [rdi+0x20],eax
  412165:	rex mov BYTE PTR [rdi+0x24],0x1
  41216a:	mov    rcx,rsi
  41216d:	call   40d590 <__swc_fn_4fa09e82_000142_055b38a4>
  412172:	mov    rax,rdi
  412175:	add    rsp,0x188
  41217c:	pop    r12
  41217e:	pop    rdi
  41217f:	pop    rsi
  412180:	pop    rbx
  412181:	ret
	...

0000000000412190 <__swc_fn_4fa09e82_000170_3459066f>:
  412190:	push   rsi
  412191:	push   rdi
  412192:	push   r12
  412194:	mov    rsi,rdx
  412197:	mov    rdi,rcx
  41219a:	mov    rcx,QWORD PTR [rip+0x11e9f]        # 424040 <__swc_bss_base_4fa09e82>
  4121a1:	test   rcx,rcx
  4121a4:	jne    4121b6 <__swc_fn_4fa09e82_000170_3459066f+0x26>
  4121a6:	call   40a620 <__swc_fn_4fa09e82_000171_994c8876>
  4121ab:	lea    rcx,[rax+0x1]
  4121af:	mov    QWORD PTR [rip+0x11e8a],rcx        # 424040 <__swc_bss_base_4fa09e82>
  4121b6:	dec    rcx
  4121b9:	call   4121e0 <__swc_fn_4fa09e82_000173_360af05d>
  4121be:	mov    r12,QWORD PTR [rax+0xbe0]
  4121c5:	test   r12,r12
  4121c8:	setne  al
  4121cb:	je     4121d6 <__swc_fn_4fa09e82_000170_3459066f+0x46>
  4121cd:	mov    rcx,rdi
  4121d0:	mov    rdx,rsi
  4121d3:	call   r12
  4121d6:	pop    r12
  4121d8:	pop    rdi
  4121d9:	pop    rsi
  4121da:	ret
  4121db:	add    BYTE PTR [rax],al
  4121dd:	add    BYTE PTR [rax],al
	...

00000000004121e0 <__swc_fn_4fa09e82_000173_360af05d>:
  4121e0:	push   r12
  4121e2:	push   rdi
  4121e3:	push   rsi
  4121e4:	sub    rsp,0xd0
  4121eb:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4121f1:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4121f7:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4121fd:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  412203:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  412209:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  41220f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  412218:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  412221:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  41222a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  412233:	mov    r12,rcx
  412236:	mov    edi,ecx
  412238:	xor    eax,eax
  41223a:	call   407000 <pthread_getspecific@plt>
  41223f:	test   rax,rax
  412242:	je     412246 <__swc_fn_4fa09e82_000173_360af05d+0x66>
  412244:	jmp    41224e <__swc_fn_4fa09e82_000173_360af05d+0x6e>
  412246:	mov    rcx,r12
  412249:	call   40a680 <__swc_fn_4fa09e82_000174_cbeff767>
  41224e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  412254:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  41225a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  412260:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  412266:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  41226c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  412272:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  41227b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  412284:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  41228d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  412296:	add    rsp,0xd0
  41229d:	pop    rsi
  41229e:	pop    rdi
  41229f:	pop    r12
  4122a1:	ret
	...

00000000004122b0 <__swc_fn_4fa09e82_000176_5eac0ab4>:
  4122b0:	push   rsi
  4122b1:	sub    rsp,0x30
  4122b5:	lea    rsi,[rip+0x14ae4]        # 426da0 <__swc_bss_base_4fa09e82+0x2d60>
  4122bc:	mov    rax,QWORD PTR [rsi]
  4122bf:	test   rax,rax
  4122c2:	je     4122ca <__swc_fn_4fa09e82_000176_5eac0ab4+0x1a>
  4122c4:	add    rsp,0x30
  4122c8:	pop    rsi
  4122c9:	ret
  4122ca:	mov    ecx,0x3
  4122cf:	mov    edx,0x10
  4122d4:	call   40fd50 <__swc_fn_4fa09e82_000113_6814119b>
  4122d9:	test   rax,rax
  4122dc:	jne    4122ed <__swc_fn_4fa09e82_000176_5eac0ab4+0x3d>
  4122de:	mov    QWORD PTR [rsp+0x18],rax
  4122e3:	call   40d0e0 <__swc_fn_4fa09e82_000124_be2e2f68>
  4122e8:	mov    rax,QWORD PTR [rsp+0x18]
  4122ed:	mov    rcx,rax
  4122f0:	xchg   QWORD PTR [rsi],rcx
  4122f3:	add    rsp,0x30
  4122f7:	pop    rsi
  4122f8:	ret
  4122f9:	add    BYTE PTR [rax],al
  4122fb:	add    BYTE PTR [rax],al
  4122fd:	add    BYTE PTR [rax],al
	...

0000000000412300 <__swc_fn_4fa09e82_000179_cf4ffedd>:
  412300:	push   rsi
  412301:	push   rdi
  412302:	sub    rsp,0x8
  412306:	mov    rsi,rdx
  412309:	mov    rdi,rcx
  41230c:	mov    rax,QWORD PTR [rsi+0x8]
  412310:	test   rax,rax
  412313:	je     41231d <__swc_fn_4fa09e82_000179_cf4ffedd+0x1d>
  412315:	mov    rcx,QWORD PTR [rsi]
  412318:	mov    QWORD PTR [rax],rcx
  41231b:	jmp    412324 <__swc_fn_4fa09e82_000179_cf4ffedd+0x24>
  41231d:	mov    rax,QWORD PTR [rsi]
  412320:	mov    QWORD PTR [rdi+0x8],rax
  412324:	mov    rax,QWORD PTR [rsi]
  412327:	test   rax,rax
  41232a:	je     412334 <__swc_fn_4fa09e82_000179_cf4ffedd+0x34>
  41232c:	mov    rcx,QWORD PTR [rsi+0x8]
  412330:	mov    QWORD PTR [rax+0x8],rcx
  412334:	mov    rcx,rdi
  412337:	mov    rdx,QWORD PTR [rsi+0x10]
  41233b:	mov    r8,QWORD PTR [rsi+0x18]
  41233f:	mov    r9,0xffffffffffffffff
  412346:	call   40dca0 <__swc_fn_4fa09e82_000178_4de704de>
  41234b:	mov    QWORD PTR [rsi+0x18],0x0
  412353:	mov    rax,QWORD PTR [rdi+0x8]
  412357:	test   rax,rax
  41235a:	jne    41236c <__swc_fn_4fa09e82_000179_cf4ffedd+0x6c>
  41235c:	call   4122b0 <__swc_fn_4fa09e82_000176_5eac0ab4>
  412361:	xor    ecx,ecx
  412363:	mov    QWORD PTR [rax+0x8],rcx
  412367:	xor    ecx,ecx
  412369:	mov    QWORD PTR [rax],rcx
  41236c:	add    rsp,0x8
  412370:	pop    rdi
  412371:	pop    rsi
  412372:	ret
