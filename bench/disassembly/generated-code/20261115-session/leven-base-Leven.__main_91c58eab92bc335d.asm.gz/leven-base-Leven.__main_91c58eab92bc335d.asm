
/workspace/prompt2-20261115/session-combined-micro/base/leven/leven:     file format elf64-x86-64


Disassembly of section .text:

000000000040a380 <__swc_fn_fc36583a_000177_aa67484d>:
  40a380:	push   rbp
  40a381:	push   rbx
  40a382:	push   r15
  40a384:	push   rsi
  40a385:	push   rdi
  40a386:	push   r12
  40a388:	push   r14
  40a38a:	push   r13
  40a38c:	sub    rsp,0x10
  40a390:	mov    rbp,rsp
  40a393:	vmovups XMMWORD PTR [rsp],xmm6
  40a398:	sub    rsp,0x610
  40a39f:	mov    rbx,rsp
  40a3a2:	mov    ecx,0x17700
  40a3a7:	sub    rsp,0x8
  40a3ab:	call   40de50 <__swc_fn_fc36583a_000175_2744b483>
  40a3b0:	add    rsp,0x8
  40a3b4:	mov    QWORD PTR [rip+0x1c9f5],rax        # 426db0 <__swc_bss_base_fc36583a+0x2d70>
  40a3bb:	mov    ecx,0xbb80
  40a3c0:	sub    rsp,0x8
  40a3c4:	call   40de50 <__swc_fn_fc36583a_000175_2744b483>
  40a3c9:	add    rsp,0x8
  40a3cd:	mov    QWORD PTR [rip+0x1c9e4],rax        # 426db8 <__swc_bss_base_fc36583a+0x2d78>
  40a3d4:	mov    ecx,0xbb80
  40a3d9:	sub    rsp,0x8
  40a3dd:	call   40de50 <__swc_fn_fc36583a_000175_2744b483>
  40a3e2:	add    rsp,0x8
  40a3e6:	mov    QWORD PTR [rip+0x1c9d3],rax        # 426dc0 <__swc_bss_base_fc36583a+0x2d80>
  40a3ed:	xor    ecx,ecx
  40a3ef:	xor    r8d,r8d
  40a3f2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a3fc:	cs nop WORD PTR [rax+rax*1+0x0]
  40a406:	cs nop WORD PTR [rax+rax*1+0x0]
  40a410:	lea    r9,[r8+0x1]
  40a414:	mov    r10,r9
  40a417:	movabs rdx,0x2492492492492493
  40a421:	mov    r15,rax
  40a424:	mov    rax,r8
  40a427:	mul    rdx
  40a42a:	mov    r11,rdx
  40a42d:	mov    rax,r15
  40a430:	mov    rdx,r8
  40a433:	sub    rdx,r11
  40a436:	shr    rdx,1
  40a439:	add    rdx,r11
  40a43c:	shr    rdx,0x2
  40a440:	imul   r11,rdx,0x7
  40a444:	mov    rdx,r8
  40a447:	sub    rdx,r11
  40a44a:	lea    r11,[rdx+0x4]
  40a44e:	mov    rdx,QWORD PTR [rip+0x1c963]        # 426db8 <__swc_bss_base_fc36583a+0x2d78>
  40a455:	mov    QWORD PTR [rdx+r8*8],rcx
  40a459:	mov    rdx,QWORD PTR [rip+0x1c960]        # 426dc0 <__swc_bss_base_fc36583a+0x2d80>
  40a460:	mov    QWORD PTR [rdx+r8*8],r11
  40a464:	xor    r8d,r8d
  40a467:	test   r11,r11
  40a46a:	jbe    40a4d4 <__swc_fn_fc36583a_000177_aa67484d+0x154>
  40a470:	xor    esi,esi
  40a472:	mov    rdi,QWORD PTR [rip+0x1c937]        # 426db0 <__swc_bss_base_fc36583a+0x2d70>
  40a479:	cs nop WORD PTR [rax+rax*1+0x0]
  40a483:	cs nop WORD PTR [rax+rax*1+0x0]
  40a48d:	nop    DWORD PTR [rax]
  40a490:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40a49a:	mov    r15,rax
  40a49d:	mov    rax,r10
  40a4a0:	mul    rdx
  40a4a3:	mov    r12,rdx
  40a4a6:	mov    rax,r15
  40a4a9:	shr    r12,0x3
  40a4ad:	imul   r12,r12,0x1a
  40a4b1:	sub    r10,r12
  40a4b4:	lea    r10,[r10+0x61]
  40a4b8:	mov    BYTE PTR [rdi+rcx*1],r10b
  40a4bc:	inc    rcx
  40a4bf:	shr    rdx,0x3
  40a4c3:	lea    r10,[rdx+rsi*1]
  40a4c7:	add    r8,0x1
  40a4cb:	add    rsi,0x7
  40a4cf:	cmp    r8,r11
  40a4d2:	jb     40a490 <__swc_fn_fc36583a_000177_aa67484d+0x110>
  40a4d4:	mov    r8,r9
  40a4d7:	cmp    r9,0x1770
  40a4de:	jb     40a410 <__swc_fn_fc36583a_000177_aa67484d+0x90>
  40a4e4:	mov    ecx,0x500
  40a4e9:	sub    rsp,0x8
  40a4ed:	call   40de50 <__swc_fn_fc36583a_000175_2744b483>
  40a4f2:	add    rsp,0x8
  40a4f6:	mov    QWORD PTR [rip+0x1c8cb],rax        # 426dc8 <__swc_bss_base_fc36583a+0x2d88>
  40a4fd:	mov    ecx,0x140
  40a502:	sub    rsp,0x8
  40a506:	call   40de50 <__swc_fn_fc36583a_000175_2744b483>
  40a50b:	add    rsp,0x8
  40a50f:	mov    QWORD PTR [rip+0x1c8ba],rax        # 426dd0 <__swc_bss_base_fc36583a+0x2d90>
  40a516:	mov    ecx,0x140
  40a51b:	sub    rsp,0x8
  40a51f:	call   40de50 <__swc_fn_fc36583a_000175_2744b483>
  40a524:	add    rsp,0x8
  40a528:	mov    QWORD PTR [rip+0x1c8a9],rax        # 426dd8 <__swc_bss_base_fc36583a+0x2d98>
  40a52f:	xor    ecx,ecx
  40a531:	xor    r8d,r8d
  40a534:	lea    r9,[rbx+0x68]
  40a538:	vxorps xmm0,xmm0,xmm0
  40a53c:	cs nop WORD PTR [rax+rax*1+0x0]
  40a546:	cs nop WORD PTR [rax+rax*1+0x0]
  40a550:	vmovups XMMWORD PTR [rbx+0x68],xmm0
  40a555:	vmovups XMMWORD PTR [rbx+0x78],xmm0
  40a55a:	mov    r10,QWORD PTR [rip+0x17aaf]        # 422010 <__swc_data_base_fc36583a+0x10>
  40a561:	imul   r10,r10,0x41a7
  40a568:	movabs rdx,0x200000005
  40a572:	mov    r15,rax
  40a575:	mov    rax,r10
  40a578:	mul    rdx
  40a57b:	mov    r11,rdx
  40a57e:	mov    rdx,r10
  40a581:	sub    rdx,r11
  40a584:	shr    rdx,1
  40a587:	add    rdx,r11
  40a58a:	shr    rdx,0x1e
  40a58e:	imul   r11,rdx,0x7fffffff
  40a595:	sub    r10,r11
  40a598:	mov    QWORD PTR [rip+0x17a71],r10        # 422010 <__swc_data_base_fc36583a+0x10>
  40a59f:	movabs rdx,0xaec33e1f671529a5
  40a5a9:	mov    rax,r10
  40a5ac:	mul    rdx
  40a5af:	mov    rax,r15
  40a5b2:	shr    rdx,0xc
  40a5b6:	imul   rdx,rdx,0x1770
  40a5bd:	sub    r10,rdx
  40a5c0:	mov    rdx,QWORD PTR [rip+0x1c7f9]        # 426dc0 <__swc_bss_base_fc36583a+0x2d80>
  40a5c7:	mov    rdx,QWORD PTR [rdx+r10*8]
  40a5cb:	mov    r11,rdx
  40a5ce:	xor    esi,esi
  40a5d0:	test   rdx,rdx
  40a5d3:	jbe    40a608 <__swc_fn_fc36583a_000177_aa67484d+0x288>
  40a5d5:	mov    rdi,QWORD PTR [rip+0x1c7dc]        # 426db8 <__swc_bss_base_fc36583a+0x2d78>
  40a5dc:	mov    r12,QWORD PTR [rip+0x1c7cd]        # 426db0 <__swc_bss_base_fc36583a+0x2d70>
  40a5e3:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5ed:	nop    DWORD PTR [rax]
  40a5f0:	mov    r13,QWORD PTR [rdi+r10*8]
  40a5f4:	add    r13,rsi
  40a5f7:	mov    r13b,BYTE PTR [r12+r13*1]
  40a5fb:	mov    BYTE PTR [r9+rsi*1],r13b
  40a5ff:	add    rsi,0x1
  40a603:	cmp    rsi,rdx
  40a606:	jb     40a5f0 <__swc_fn_fc36583a_000177_aa67484d+0x270>
  40a608:	xor    r10d,r10d
  40a60b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a610:	mov    rsi,QWORD PTR [rip+0x179f9]        # 422010 <__swc_data_base_fc36583a+0x10>
  40a617:	imul   rsi,rsi,0x41a7
  40a61e:	movabs r12,0x200000005
  40a628:	mov    r14,rax
  40a62b:	mov    rax,rsi
  40a62e:	mul    r12
  40a631:	mov    r12,rsi
  40a634:	sub    r12,rdx
  40a637:	shr    r12,1
  40a63a:	add    r12,rdx
  40a63d:	shr    r12,0x1e
  40a641:	imul   rdi,r12,0x7fffffff
  40a648:	sub    rsi,rdi
  40a64b:	mov    QWORD PTR [rip+0x179be],rsi        # 422010 <__swc_data_base_fc36583a+0x10>
  40a652:	mov    rax,rsi
  40a655:	xor    edx,edx
  40a657:	div    r11
  40a65a:	mov    rax,rdx
  40a65d:	mov    r12,rax
  40a660:	imul   rsi,rsi,0x41a7
  40a667:	movabs rdx,0x200000005
  40a671:	mov    r15,r14
  40a674:	mov    rax,rsi
  40a677:	mul    rdx
  40a67a:	mov    rdi,rdx
  40a67d:	mov    rdx,rsi
  40a680:	sub    rdx,rdi
  40a683:	shr    rdx,1
  40a686:	add    rdx,rdi
  40a689:	shr    rdx,0x1e
  40a68d:	imul   rdi,rdx,0x7fffffff
  40a694:	sub    rsi,rdi
  40a697:	mov    QWORD PTR [rip+0x17972],rsi        # 422010 <__swc_data_base_fc36583a+0x10>
  40a69e:	movabs rdx,0xaaaaaaaaaaaaaaab
  40a6a8:	mov    rax,rsi
  40a6ab:	mul    rdx
  40a6ae:	shr    rdx,1
  40a6b1:	lea    rdx,[rdx+rdx*2]
  40a6b5:	mov    r13,rsi
  40a6b8:	sub    r13,rdx
  40a6bb:	imul   rsi,rsi,0x41a7
  40a6c2:	movabs rdx,0x200000005
  40a6cc:	mov    rax,rsi
  40a6cf:	mul    rdx
  40a6d2:	mov    rdi,rdx
  40a6d5:	mov    rdx,rsi
  40a6d8:	sub    rdx,rdi
  40a6db:	shr    rdx,1
  40a6de:	add    rdx,rdi
  40a6e1:	shr    rdx,0x1e
  40a6e5:	imul   rdi,rdx,0x7fffffff
  40a6ec:	sub    rsi,rdi
  40a6ef:	mov    QWORD PTR [rip+0x1791a],rsi        # 422010 <__swc_data_base_fc36583a+0x10>
  40a6f6:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40a700:	mov    rax,rsi
  40a703:	mul    rdx
  40a706:	mov    rax,r15
  40a709:	shr    rdx,0x3
  40a70d:	imul   rdx,rdx,0x1a
  40a711:	sub    rsi,rdx
  40a714:	lea    rdx,[rsi+0x61]
  40a718:	test   r13,r13
  40a71b:	jne    40a726 <__swc_fn_fc36583a_000177_aa67484d+0x3a6>
  40a71d:	mov    BYTE PTR [r9+r12*1],dl
  40a721:	jmp    40a799 <__swc_fn_fc36583a_000177_aa67484d+0x419>
  40a726:	cmp    r13,0x1
  40a72a:	jne    40a75a <__swc_fn_fc36583a_000177_aa67484d+0x3da>
  40a72c:	cmp    r11,0x2
  40a730:	jbe    40a799 <__swc_fn_fc36583a_000177_aa67484d+0x419>
  40a736:	lea    rdx,[r12+0x1]
  40a73b:	cmp    rdx,r11
  40a73e:	jae    40a754 <__swc_fn_fc36583a_000177_aa67484d+0x3d4>
  40a740:	mov    sil,BYTE PTR [r9+r12*1+0x1]
  40a745:	mov    BYTE PTR [r9+r12*1],sil
  40a749:	mov    r12,rdx
  40a74c:	inc    rdx
  40a74f:	cmp    rdx,r11
  40a752:	jb     40a740 <__swc_fn_fc36583a_000177_aa67484d+0x3c0>
  40a754:	sub    r11,0x1
  40a758:	jmp    40a799 <__swc_fn_fc36583a_000177_aa67484d+0x419>
  40a75a:	mov    rsi,r11
  40a75d:	cmp    rsi,r12
  40a760:	jbe    40a791 <__swc_fn_fc36583a_000177_aa67484d+0x411>
  40a762:	cs nop WORD PTR [rax+rax*1+0x0]
  40a76c:	cs nop WORD PTR [rax+rax*1+0x0]
  40a776:	cs nop WORD PTR [rax+rax*1+0x0]
  40a780:	mov    dil,BYTE PTR [r9+rsi*1-0x1]
  40a785:	mov    BYTE PTR [r9+rsi*1],dil
  40a789:	dec    rsi
  40a78c:	cmp    rsi,r12
  40a78f:	ja     40a780 <__swc_fn_fc36583a_000177_aa67484d+0x400>
  40a791:	mov    BYTE PTR [r9+r12*1],dl
  40a795:	add    r11,0x1
  40a799:	add    r10,0x1
  40a79d:	cmp    r10,0x2
  40a7a1:	jb     40a610 <__swc_fn_fc36583a_000177_aa67484d+0x290>
  40a7a7:	mov    rdx,QWORD PTR [rip+0x1c622]        # 426dd0 <__swc_bss_base_fc36583a+0x2d90>
  40a7ae:	mov    QWORD PTR [rdx+r8*8],rcx
  40a7b2:	mov    rdx,QWORD PTR [rip+0x1c61f]        # 426dd8 <__swc_bss_base_fc36583a+0x2d98>
  40a7b9:	mov    QWORD PTR [rdx+r8*8],r11
  40a7bd:	xor    edx,edx
  40a7bf:	test   r11,r11
  40a7c2:	jbe    40a7f4 <__swc_fn_fc36583a_000177_aa67484d+0x474>
  40a7c4:	mov    r10,QWORD PTR [rip+0x1c5fd]        # 426dc8 <__swc_bss_base_fc36583a+0x2d88>
  40a7cb:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7d5:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7df:	nop
  40a7e0:	mov    sil,BYTE PTR [r9+rdx*1]
  40a7e4:	mov    BYTE PTR [r10+rcx*1],sil
  40a7e8:	inc    rcx
  40a7eb:	add    rdx,0x1
  40a7ef:	cmp    rdx,r11
  40a7f2:	jb     40a7e0 <__swc_fn_fc36583a_000177_aa67484d+0x460>
  40a7f4:	add    r8,0x1
  40a7f8:	cmp    r8,0x28
  40a7fc:	jb     40a550 <__swc_fn_fc36583a_000177_aa67484d+0x1d0>
  40a802:	sub    rsp,0x8
  40a806:	call   412160 <__swc_fn_fc36583a_000176_1ca87929>
  40a80b:	add    rsp,0x8
  40a80f:	vmovups xmm6,xmm0
  40a813:	lea    rax,[rbx+0xf8]
  40a81a:	vxorps xmm0,xmm0,xmm0
  40a81e:	xor    ecx,ecx
  40a820:	vmovdqu XMMWORD PTR [rax+rcx*1],xmm0
  40a825:	add    rcx,0x10
  40a829:	cmp    rcx,0x200
  40a830:	jne    40a820 <__swc_fn_fc36583a_000177_aa67484d+0x4a0>
  40a832:	lea    rcx,[rbx+0x2f8]
  40a839:	vxorps xmm0,xmm0,xmm0
  40a83d:	xor    edx,edx
  40a83f:	nop
  40a840:	vmovdqu XMMWORD PTR [rcx+rdx*1],xmm0
  40a845:	add    rdx,0x10
  40a849:	cmp    rdx,0x200
  40a850:	jne    40a840 <__swc_fn_fc36583a_000177_aa67484d+0x4c0>
  40a852:	xor    edx,edx
  40a854:	mov    r8,QWORD PTR [rip+0x1c575]        # 426dd0 <__swc_bss_base_fc36583a+0x2d90>
  40a85b:	mov    QWORD PTR [rsp+0x5b0],r8
  40a863:	mov    r9,QWORD PTR [rip+0x1c56e]        # 426dd8 <__swc_bss_base_fc36583a+0x2d98>
  40a86a:	mov    QWORD PTR [rsp+0x5b8],r9
  40a872:	mov    r10,QWORD PTR [rip+0x1c53f]        # 426db8 <__swc_bss_base_fc36583a+0x2d78>
  40a879:	mov    QWORD PTR [rsp+0x5a0],0x0
  40a885:	mov    QWORD PTR [rsp+0x5c0],r10
  40a88d:	mov    r11,QWORD PTR [rip+0x1c52c]        # 426dc0 <__swc_bss_base_fc36583a+0x2d80>
  40a894:	mov    QWORD PTR [rsp+0x5c8],r11
  40a89c:	jmp    40a8d8 <__swc_fn_fc36583a_000177_aa67484d+0x558>
  40a89e:	cs nop WORD PTR [rax+rax*1+0x0]
  40a8a8:	nop    DWORD PTR [rax+rax*1+0x0]
  40a8b0:	mov    QWORD PTR [rsp+0x5a0],rsi
  40a8b8:	mov    r8,QWORD PTR [rsp+0x5b0]
  40a8c0:	mov    r9,QWORD PTR [rsp+0x5b8]
  40a8c8:	mov    r10,QWORD PTR [rsp+0x5c0]
  40a8d0:	mov    r11,QWORD PTR [rsp+0x5c8]
  40a8d8:	mov    rdi,QWORD PTR [r8+rdx*8]
  40a8dc:	mov    QWORD PTR [rsp+0x5d0],rdi
  40a8e4:	mov    r12,QWORD PTR [r9+rdx*8]
  40a8e8:	mov    QWORD PTR [rsp+0x5d8],r12
  40a8f0:	mov    r13d,0x40000000
  40a8f6:	mov    r14,0xffffffffffffffff
  40a8fd:	xor    r15d,r15d
  40a900:	mov    QWORD PTR [rsp+0x5a8],rdx
  40a908:	vmovq  xmm3,r13
  40a90d:	vmovq  xmm4,r14
  40a912:	vmovq  xmm5,r15
  40a917:	jmp    40a952 <__swc_fn_fc36583a_000177_aa67484d+0x5d2>
  40a919:	cs nop WORD PTR [rax+rax*1+0x0]
  40a923:	cs nop WORD PTR [rax+rax*1+0x0]
  40a92d:	nop    DWORD PTR [rax]
  40a930:	mov    r10,QWORD PTR [rsp+0x5c0]
  40a938:	mov    r11,QWORD PTR [rsp+0x5c8]
  40a940:	mov    rdi,QWORD PTR [rsp+0x5d0]
  40a948:	vmovq  xmm3,r13
  40a94d:	vmovq  xmm4,r14
  40a952:	mov    r8,QWORD PTR [r10+r15*8]
  40a956:	mov    QWORD PTR [rsp+0x5f8],r8
  40a95e:	mov    r9,QWORD PTR [r11+r15*8]
  40a962:	mov    rdx,r9
  40a965:	sub    rdx,r12
  40a968:	mov    rsi,r12
  40a96b:	sub    rsi,r9
  40a96e:	cmovbe rsi,rdx
  40a972:	cmp    rsi,0x3
  40a976:	jbe    40a987 <__swc_fn_fc36583a_000177_aa67484d+0x607>
  40a978:	vmovq  r13,xmm3
  40a97d:	vmovq  r14,xmm4
  40a982:	jmp    40ab0b <__swc_fn_fc36583a_000177_aa67484d+0x78b>
  40a987:	lea    rdx,[r9+0x1]
  40a98b:	xor    esi,esi
  40a98d:	test   rdx,rdx
  40a990:	jbe    40a9ad <__swc_fn_fc36583a_000177_aa67484d+0x62d>
  40a992:	cs nop WORD PTR [rax+rax*1+0x0]
  40a99c:	nop    DWORD PTR [rax+0x0]
  40a9a0:	mov    QWORD PTR [rax+rsi*8],rsi
  40a9a4:	add    rsi,0x1
  40a9a8:	cmp    rsi,rdx
  40a9ab:	jb     40a9a0 <__swc_fn_fc36583a_000177_aa67484d+0x620>
  40a9ad:	xor    esi,esi
  40a9af:	test   r12,r12
  40a9b2:	jbe    40aaed <__swc_fn_fc36583a_000177_aa67484d+0x76d>
  40a9b8:	mov    r10,QWORD PTR [rip+0x1c409]        # 426dc8 <__swc_bss_base_fc36583a+0x2d88>
  40a9bf:	add    r10,rdi
  40a9c2:	vmovsd xmm0,QWORD PTR [rsp+0x5d8]
  40a9cb:	vmovsd xmm1,QWORD PTR [rsp+0x5f8]
  40a9d4:	vmovq  xmm2,r10
  40a9d9:	nop    DWORD PTR [rax+0x0]
  40a9e0:	lea    r11,[rsi+0x1]
  40a9e4:	mov    QWORD PTR [rbx+0x2f8],r11
  40a9eb:	mov    sil,BYTE PTR [r10+rsi*1]
  40a9ef:	xor    edi,edi
  40a9f1:	test   r9,r9
  40a9f4:	jbe    40aa4d <__swc_fn_fc36583a_000177_aa67484d+0x6cd>
  40a9f6:	mov    r14,QWORD PTR [rip+0x1c3b3]        # 426db0 <__swc_bss_base_fc36583a+0x2d70>
  40a9fd:	add    r14,r8
  40aa00:	mov    r15,QWORD PTR [rbx+0xf8]
  40aa07:	mov    r13,r11
  40aa0a:	nop    WORD PTR [rax+rax*1+0x0]
  40aa10:	xor    r8d,r8d
  40aa13:	cmp    BYTE PTR [r14+rdi*1],sil
  40aa17:	setne  r8b
  40aa1b:	add    r8,r15
  40aa1e:	mov    r10,QWORD PTR [rax+rdi*8+0x8]
  40aa23:	mov    r15,r10
  40aa26:	add    r10,0x1
  40aa2a:	cmp    r10,r8
  40aa2d:	cmovb  r8,r10
  40aa31:	lea    r10,[r13+0x1]
  40aa35:	cmp    r10,r8
  40aa38:	cmovb  r8,r10
  40aa3c:	mov    QWORD PTR [rcx+rdi*8+0x8],r8
  40aa41:	mov    r13,r8
  40aa44:	add    rdi,0x1
  40aa48:	cmp    rdi,r9
  40aa4b:	jb     40aa10 <__swc_fn_fc36583a_000177_aa67484d+0x690>
  40aa4d:	xor    r8d,r8d
  40aa50:	test   rdx,rdx
  40aa53:	jbe    40aad1 <__swc_fn_fc36583a_000177_aa67484d+0x751>
  40aa59:	cmp    rdx,0x4
  40aa5d:	jb     40aac0 <__swc_fn_fc36583a_000177_aa67484d+0x740>
  40aa63:	lea    r10,[rdx-0x3]
  40aa67:	nop    WORD PTR [rax+rax*1+0x0]
  40aa70:	mov    rsi,QWORD PTR [rcx+r8*8]
  40aa74:	mov    QWORD PTR [rax+r8*8],rsi
  40aa78:	mov    rsi,QWORD PTR [rcx+r8*8+0x8]
  40aa7d:	mov    QWORD PTR [rax+r8*8+0x8],rsi
  40aa82:	mov    rsi,QWORD PTR [rcx+r8*8+0x10]
  40aa87:	mov    QWORD PTR [rax+r8*8+0x10],rsi
  40aa8c:	mov    rsi,QWORD PTR [rcx+r8*8+0x18]
  40aa91:	mov    QWORD PTR [rax+r8*8+0x18],rsi
  40aa96:	add    r8,0x4
  40aa9a:	cmp    r8,r10
  40aa9d:	jb     40aa70 <__swc_fn_fc36583a_000177_aa67484d+0x6f0>
  40aa9f:	cmp    r8,rdx
  40aaa2:	jae    40aad1 <__swc_fn_fc36583a_000177_aa67484d+0x751>
  40aaa4:	cs nop WORD PTR [rax+rax*1+0x0]
  40aaae:	cs nop WORD PTR [rax+rax*1+0x0]
  40aab8:	nop    DWORD PTR [rax+rax*1+0x0]
  40aac0:	mov    rsi,QWORD PTR [rcx+r8*8]
  40aac4:	mov    QWORD PTR [rax+r8*8],rsi
  40aac8:	add    r8,0x1
  40aacc:	cmp    r8,rdx
  40aacf:	jb     40aac0 <__swc_fn_fc36583a_000177_aa67484d+0x740>
  40aad1:	mov    rsi,r11
  40aad4:	vmovq  r12,xmm0
  40aad9:	cmp    r11,r12
  40aadc:	jae    40aaed <__swc_fn_fc36583a_000177_aa67484d+0x76d>
  40aade:	vmovq  r8,xmm1
  40aae3:	vmovq  r10,xmm2
  40aae8:	jmp    40a9e0 <__swc_fn_fc36583a_000177_aa67484d+0x660>
  40aaed:	mov    rdx,QWORD PTR [rax+r9*8]
  40aaf1:	vmovq  r13,xmm3
  40aaf6:	cmp    rdx,r13
  40aaf9:	cmovb  r13,rdx
  40aafd:	vmovq  r14,xmm4
  40ab02:	vmovq  r15,xmm5
  40ab07:	cmovb  r14,r15
  40ab0b:	add    r15,0x1
  40ab0f:	vmovq  xmm5,r15
  40ab14:	cmp    r15,0x1770
  40ab1b:	jb     40a930 <__swc_fn_fc36583a_000177_aa67484d+0x5b0>
  40ab21:	imul   r13,r13,0x1f
  40ab25:	add    r13,r14
  40ab28:	mov    rsi,QWORD PTR [rsp+0x5a0]
  40ab30:	add    rsi,r13
  40ab33:	mov    rdx,QWORD PTR [rsp+0x5a8]
  40ab3b:	add    rdx,0x1
  40ab3f:	cmp    rdx,0x28
  40ab43:	jb     40a8b0 <__swc_fn_fc36583a_000177_aa67484d+0x530>
  40ab49:	sub    rsp,0x8
  40ab4d:	call   412160 <__swc_fn_fc36583a_000176_1ca87929>
  40ab52:	add    rsp,0x8
  40ab56:	vsubsd xmm0,xmm0,xmm6
  40ab5a:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x8e66]        # 4139c8 <__swc_rdata_base_fc36583a+0x8b8>
  40ab62:	lea    rax,[rip+0x87ff]        # 413368 <__swc_rdata_base_fc36583a+0x258>
  40ab69:	sub    rsp,0x90
  40ab70:	mov    rcx,rsp
  40ab73:	vmovups xmm1,XMMWORD PTR [rip+0x8e2d]        # 4139a8 <__swc_rdata_base_fc36583a+0x898>
  40ab7b:	vmovups XMMWORD PTR [rcx],xmm1
  40ab7f:	mov    QWORD PTR [rcx+0x30],rsp
  40ab83:	lea    rdx,[rip+0x8786]        # 413310 <__swc_rdata_base_fc36583a+0x200>
  40ab8a:	mov    QWORD PTR [rcx+0x38],rdx
  40ab8e:	mov    QWORD PTR [rcx+0x10],rsi
  40ab92:	lea    r8,[rsp+0x10]
  40ab97:	mov    QWORD PTR [rcx+0x40],r8
  40ab9b:	lea    r8,[rip+0x8d76]        # 413918 <__swc_rdata_base_fc36583a+0x808>
  40aba2:	mov    QWORD PTR [rcx+0x48],r8
  40aba6:	vmovups xmm1,XMMWORD PTR [rip+0x8e0a]        # 4139b8 <__swc_rdata_base_fc36583a+0x8a8>
  40abae:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40abb3:	lea    r8,[rsp+0x18]
  40abb8:	mov    QWORD PTR [rcx+0x50],r8
  40abbc:	mov    QWORD PTR [rcx+0x58],rdx
  40abc0:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40abc5:	lea    r8,[rcx+0x28]
  40abc9:	mov    QWORD PTR [rcx+0x60],r8
  40abcd:	lea    r8,[rip+0x8d8c]        # 413960 <__swc_rdata_base_fc36583a+0x850>
  40abd4:	mov    QWORD PTR [rcx+0x68],r8
  40abd8:	mov    QWORD PTR [rcx+0x70],rax
  40abdc:	mov    QWORD PTR [rcx+0x78],rdx
  40abe0:	lea    rax,[rcx+0x30]
  40abe4:	mov    QWORD PTR [rcx+0x80],rax
  40abeb:	mov    QWORD PTR [rcx+0x88],0x5
  40abf6:	lea    rcx,[rcx+0x80]
  40abfd:	sub    rsp,0x8
  40ac01:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  40ac06:	add    rsp,0x6a8
  40ac0d:	vmovups xmm6,XMMWORD PTR [rsp]
  40ac12:	add    rsp,0x10
  40ac16:	pop    r13
  40ac18:	pop    r14
  40ac1a:	pop    r12
  40ac1c:	pop    rdi
  40ac1d:	pop    rsi
  40ac1e:	pop    r15
  40ac20:	pop    rbx
  40ac21:	pop    rbp
  40ac22:	ret
