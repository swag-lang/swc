
/workspace/prompt2-20261115/session-combined-micro/base/fannkuch/fannkuch:     file format elf64-x86-64


Disassembly of section .text:

000000000040d720 <__swc_fn_585f006d_000178_8d3f617b>:
  40d720:	push   rbp
  40d721:	push   rsi
  40d722:	push   rdi
  40d723:	push   r12
  40d725:	push   r13
  40d727:	push   r14
  40d729:	sub    rsp,0x10
  40d72d:	mov    rbp,rsp
  40d730:	vmovups XMMWORD PTR [rsp],xmm6
  40d735:	sub    rsp,0xc0
  40d73c:	mov    ecx,0x48
  40d741:	sub    rsp,0x8
  40d745:	call   40d670 <__swc_fn_585f006d_000175_2744b483>
  40d74a:	add    rsp,0x8
  40d74e:	mov    rsi,rax
  40d751:	mov    ecx,0x48
  40d756:	sub    rsp,0x8
  40d75a:	call   40d670 <__swc_fn_585f006d_000175_2744b483>
  40d75f:	add    rsp,0x8
  40d763:	mov    rdi,rax
  40d766:	mov    ecx,0x48
  40d76b:	sub    rsp,0x8
  40d76f:	call   40d670 <__swc_fn_585f006d_000175_2744b483>
  40d774:	add    rsp,0x8
  40d778:	mov    r12,rax
  40d77b:	sub    rsp,0x8
  40d77f:	call   40a380 <__swc_fn_585f006d_000177_1ca87929>
  40d784:	add    rsp,0x8
  40d788:	vmovups xmm6,xmm0
  40d78c:	mov    QWORD PTR [rdi],0x0
  40d793:	mov    QWORD PTR [rdi+0x8],0x1
  40d79b:	mov    QWORD PTR [rdi+0x10],0x2
  40d7a3:	mov    QWORD PTR [rdi+0x18],0x3
  40d7ab:	mov    QWORD PTR [rdi+0x20],0x4
  40d7b3:	mov    QWORD PTR [rdi+0x28],0x5
  40d7bb:	mov    QWORD PTR [rdi+0x30],0x6
  40d7c3:	mov    QWORD PTR [rdi+0x38],0x7
  40d7cb:	mov    QWORD PTR [rdi+0x40],0x8
  40d7d3:	xor    eax,eax
  40d7d5:	xor    ecx,ecx
  40d7d7:	xor    edx,edx
  40d7d9:	mov    r8d,0x9
  40d7df:	nop
  40d7e0:	cmp    r8,0x1
  40d7e4:	je     40d7fe <__swc_fn_585f006d_000178_8d3f617b+0xde>
  40d7e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40d7f0:	mov    QWORD PTR [r12+r8*8-0x8],r8
  40d7f5:	dec    r8
  40d7f8:	cmp    r8,0x1
  40d7fc:	jne    40d7f0 <__swc_fn_585f006d_000178_8d3f617b+0xd0>
  40d7fe:	mov    r9,QWORD PTR [rdi]
  40d801:	mov    QWORD PTR [rsi],r9
  40d804:	mov    r10,QWORD PTR [rdi+0x8]
  40d808:	mov    QWORD PTR [rsi+0x8],r10
  40d80c:	mov    r10,QWORD PTR [rdi+0x10]
  40d810:	mov    QWORD PTR [rsi+0x10],r10
  40d814:	mov    r10,QWORD PTR [rdi+0x18]
  40d818:	mov    QWORD PTR [rsi+0x18],r10
  40d81c:	mov    r10,QWORD PTR [rdi+0x20]
  40d820:	mov    QWORD PTR [rsi+0x20],r10
  40d824:	mov    r10,QWORD PTR [rdi+0x28]
  40d828:	mov    QWORD PTR [rsi+0x28],r10
  40d82c:	mov    r10,QWORD PTR [rdi+0x30]
  40d830:	mov    QWORD PTR [rsi+0x30],r10
  40d834:	mov    r10,QWORD PTR [rdi+0x38]
  40d838:	mov    QWORD PTR [rsi+0x38],r10
  40d83c:	mov    r10,QWORD PTR [rdi+0x40]
  40d840:	mov    QWORD PTR [rsi+0x40],r10
  40d844:	xor    r10d,r10d
  40d847:	test   r9,r9
  40d84a:	je     40d8fa <__swc_fn_585f006d_000178_8d3f617b+0x1da>
  40d850:	test   r9,r9
  40d853:	jle    40d8eb <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d859:	mov    r14,QWORD PTR [rsi+r9*8]
  40d85d:	mov    QWORD PTR [rsi],r14
  40d860:	mov    QWORD PTR [rsi+r9*8],r9
  40d864:	dec    r9
  40d867:	cmp    r9,0x1
  40d86b:	jle    40d8eb <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d871:	mov    r13,QWORD PTR [rsi+0x8]
  40d875:	mov    r14,QWORD PTR [rsi+r9*8]
  40d879:	mov    QWORD PTR [rsi+0x8],r14
  40d87d:	mov    QWORD PTR [rsi+r9*8],r13
  40d881:	dec    r9
  40d884:	cmp    r9,0x2
  40d888:	jle    40d8eb <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d88a:	mov    r13,QWORD PTR [rsi+0x10]
  40d88e:	mov    r14,QWORD PTR [rsi+r9*8]
  40d892:	mov    QWORD PTR [rsi+0x10],r14
  40d896:	mov    QWORD PTR [rsi+r9*8],r13
  40d89a:	dec    r9
  40d89d:	cmp    r9,0x3
  40d8a1:	jle    40d8eb <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d8a3:	mov    r13,QWORD PTR [rsi+0x18]
  40d8a7:	mov    r14,QWORD PTR [rsi+r9*8]
  40d8ab:	mov    QWORD PTR [rsi+0x18],r14
  40d8af:	mov    QWORD PTR [rsi+r9*8],r13
  40d8b3:	dec    r9
  40d8b6:	cmp    r9,0x4
  40d8ba:	jle    40d8eb <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d8bc:	mov    r11d,0x4
  40d8c2:	jmp    40d8d0 <__swc_fn_585f006d_000178_8d3f617b+0x1b0>
  40d8c4:	cmp    r11,r9
  40d8c7:	jge    40d8eb <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d8c9:	nop    DWORD PTR [rax+0x0]
  40d8d0:	mov    r13,QWORD PTR [rsi+r11*8]
  40d8d4:	mov    r14,QWORD PTR [rsi+r9*8]
  40d8d8:	mov    QWORD PTR [rsi+r11*8],r14
  40d8dc:	mov    QWORD PTR [rsi+r9*8],r13
  40d8e0:	inc    r11
  40d8e3:	dec    r9
  40d8e6:	cmp    r11,r9
  40d8e9:	jl     40d8d0 <__swc_fn_585f006d_000178_8d3f617b+0x1b0>
  40d8eb:	inc    r10
  40d8ee:	mov    r9,QWORD PTR [rsi]
  40d8f1:	test   r9,r9
  40d8f4:	jne    40d850 <__swc_fn_585f006d_000178_8d3f617b+0x130>
  40d8fa:	cmp    r10,rcx
  40d8fd:	cmovg  rcx,r10
  40d901:	test   dl,0x1
  40d904:	jne    40d90b <__swc_fn_585f006d_000178_8d3f617b+0x1eb>
  40d906:	add    rax,r10
  40d909:	jmp    40d90e <__swc_fn_585f006d_000178_8d3f617b+0x1ee>
  40d90b:	sub    rax,r10
  40d90e:	xchg   ax,ax
  40d910:	cmp    r8,0x9
  40d914:	je     40d96b <__swc_fn_585f006d_000178_8d3f617b+0x24b>
  40d916:	mov    r10,QWORD PTR [rdi]
  40d919:	xor    r11d,r11d
  40d91c:	test   r8,r8
  40d91f:	jle    40d952 <__swc_fn_585f006d_000178_8d3f617b+0x232>
  40d921:	cs nop WORD PTR [rax+rax*1+0x0]
  40d92b:	cs nop WORD PTR [rax+rax*1+0x0]
  40d935:	cs nop WORD PTR [rax+rax*1+0x0]
  40d93f:	nop
  40d940:	mov    r13,QWORD PTR [rdi+r11*8+0x8]
  40d945:	mov    QWORD PTR [rdi+r11*8],r13
  40d949:	add    r11,0x1
  40d94d:	cmp    r11,r8
  40d950:	jl     40d940 <__swc_fn_585f006d_000178_8d3f617b+0x220>
  40d952:	mov    QWORD PTR [rdi+r8*8],r10
  40d956:	dec    QWORD PTR [r12+r8*8]
  40d95a:	je     40d95e <__swc_fn_585f006d_000178_8d3f617b+0x23e>
  40d95c:	jns    40d963 <__swc_fn_585f006d_000178_8d3f617b+0x243>
  40d95e:	inc    r8
  40d961:	jmp    40d910 <__swc_fn_585f006d_000178_8d3f617b+0x1f0>
  40d963:	inc    rdx
  40d966:	jmp    40d7e0 <__swc_fn_585f006d_000178_8d3f617b+0xc0>
  40d96b:	imul   r13,rax,0x3e8
  40d972:	add    r13,rcx
  40d975:	sub    rsp,0x8
  40d979:	call   40a380 <__swc_fn_585f006d_000177_1ca87929>
  40d97e:	add    rsp,0x8
  40d982:	vsubsd xmm0,xmm0,xmm6
  40d986:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x503a]        # 4129c8 <__swc_rdata_base_585f006d+0x8b8>
  40d98e:	lea    rax,[rip+0x49d3]        # 412368 <__swc_rdata_base_585f006d+0x258>
  40d995:	sub    rsp,0x90
  40d99c:	mov    rcx,rsp
  40d99f:	vmovups xmm1,XMMWORD PTR [rip+0x5001]        # 4129a8 <__swc_rdata_base_585f006d+0x898>
  40d9a7:	vmovups XMMWORD PTR [rcx],xmm1
  40d9ab:	mov    QWORD PTR [rcx+0x30],rsp
  40d9af:	lea    rdx,[rip+0x495a]        # 412310 <__swc_rdata_base_585f006d+0x200>
  40d9b6:	mov    QWORD PTR [rcx+0x38],rdx
  40d9ba:	mov    QWORD PTR [rcx+0x10],r13
  40d9be:	lea    r8,[rsp+0x10]
  40d9c3:	mov    QWORD PTR [rcx+0x40],r8
  40d9c7:	lea    r8,[rip+0x4f4a]        # 412918 <__swc_rdata_base_585f006d+0x808>
  40d9ce:	mov    QWORD PTR [rcx+0x48],r8
  40d9d2:	vmovups xmm1,XMMWORD PTR [rip+0x4fde]        # 4129b8 <__swc_rdata_base_585f006d+0x8a8>
  40d9da:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40d9df:	lea    r8,[rsp+0x18]
  40d9e4:	mov    QWORD PTR [rcx+0x50],r8
  40d9e8:	mov    QWORD PTR [rcx+0x58],rdx
  40d9ec:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40d9f1:	lea    r8,[rcx+0x28]
  40d9f5:	mov    QWORD PTR [rcx+0x60],r8
  40d9f9:	lea    r8,[rip+0x4f60]        # 412960 <__swc_rdata_base_585f006d+0x850>
  40da00:	mov    QWORD PTR [rcx+0x68],r8
  40da04:	mov    QWORD PTR [rcx+0x70],rax
  40da08:	mov    QWORD PTR [rcx+0x78],rdx
  40da0c:	lea    rax,[rcx+0x30]
  40da10:	mov    QWORD PTR [rcx+0x80],rax
  40da17:	mov    QWORD PTR [rcx+0x88],0x5
  40da22:	lea    rcx,[rcx+0x80]
  40da29:	sub    rsp,0x8
  40da2d:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  40da32:	add    rsp,0x8
  40da36:	add    rsp,0x90
  40da3d:	mov    rcx,r12
  40da40:	sub    rsp,0x8
  40da44:	call   411d00 <__swc_fn_585f006d_000176_5d3d19bd>
  40da49:	add    rsp,0x8
  40da4d:	mov    rcx,rdi
  40da50:	sub    rsp,0x8
  40da54:	call   411d00 <__swc_fn_585f006d_000176_5d3d19bd>
  40da59:	add    rsp,0x8
  40da5d:	mov    rcx,rsi
  40da60:	sub    rsp,0x8
  40da64:	call   411d00 <__swc_fn_585f006d_000176_5d3d19bd>
  40da69:	add    rsp,0xc8
  40da70:	vmovups xmm6,XMMWORD PTR [rsp]
  40da75:	add    rsp,0x10
  40da79:	pop    r14
  40da7b:	pop    r13
  40da7d:	pop    r12
  40da7f:	pop    rdi
  40da80:	pop    rsi
  40da81:	pop    rbp
  40da82:	ret
