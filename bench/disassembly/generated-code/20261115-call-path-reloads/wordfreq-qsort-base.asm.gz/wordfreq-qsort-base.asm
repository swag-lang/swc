
/workspace/prompt2-20261115/batch9-audited-micro/base/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

0000000000412110 <__swc_fn_4fa09e82_000179_6937fe70>:
  412110:	push   rsi
  412111:	push   rdi
  412112:	push   r12
  412114:	push   r13
  412116:	push   r14
  412118:	push   r15
  41211a:	sub    rsp,0xd8
  412121:	mov    rsi,rdx
  412124:	mov    QWORD PTR [rsp+0x88],rdx
  41212c:	mov    rdi,rcx
  41212f:	cmp    rdi,rsi
  412132:	jge    412349 <__swc_fn_4fa09e82_000179_6937fe70+0x239>
  412138:	nop    DWORD PTR [rax+rax*1+0x0]
  412140:	lea    rax,[rdi+rsi*1]
  412144:	mov    rcx,rax
  412147:	shr    rax,0x3f
  41214b:	add    rcx,rax
  41214e:	sar    rcx,1
  412151:	mov    rax,QWORD PTR [rip+0x14c58]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  412158:	mov    r12,QWORD PTR [rax+rcx*8]
  41215c:	mov    r13,rdi
  41215f:	mov    QWORD PTR [rsp+0x90],rdi
  412167:	mov    r14,rsi
  41216a:	nop    WORD PTR [rax+rax*1+0x0]
  412170:	cmp    r13,r14
  412173:	jle    412180 <__swc_fn_4fa09e82_000179_6937fe70+0x70>
  412175:	mov    rax,r13
  412178:	mov    r13,r14
  41217b:	jmp    412325 <__swc_fn_4fa09e82_000179_6937fe70+0x215>
  412180:	mov    r15,QWORD PTR [rip+0x14c29]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  412187:	mov    rsi,QWORD PTR [rip+0x14c2a]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  41218e:	mov    QWORD PTR [rsp+0xa8],rsi
  412196:	mov    rdi,QWORD PTR [rsi+r12*8]
  41219a:	mov    QWORD PTR [rsp+0xa0],r14
  4121a2:	mov    r14,QWORD PTR [rip+0x14c17]        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  4121a9:	mov    rax,QWORD PTR [rip+0x14c18]        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  4121b0:	mov    QWORD PTR [rsp+0xb0],rax
  4121b8:	mov    r9,QWORD PTR [rip+0x14c11]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  4121bf:	mov    QWORD PTR [rsp+0xb8],r9
  4121c7:	nop    WORD PTR [rax+rax*1+0x0]
  4121d0:	mov    r10,QWORD PTR [r15+r13*8]
  4121d4:	cmp    QWORD PTR [rsi+r10*8],rdi
  4121d8:	je     4121de <__swc_fn_4fa09e82_000179_6937fe70+0xce>
  4121da:	ja     412215 <__swc_fn_4fa09e82_000179_6937fe70+0x105>
  4121dc:	jmp    412232 <__swc_fn_4fa09e82_000179_6937fe70+0x122>
  4121de:	mov    rcx,QWORD PTR [r14+r10*8]
  4121e2:	mov    r8,QWORD PTR [r14+r12*8]
  4121e6:	cmp    r8,rcx
  4121e9:	cmovae r8,rcx
  4121ed:	mov    rcx,QWORD PTR [rax+r10*8]
  4121f1:	add    rcx,r9
  4121f4:	mov    rdx,QWORD PTR [rax+r12*8]
  4121f8:	add    rdx,r9
  4121fb:	mov    rsi,r10
  4121fe:	call   410eb0 <__swc_fn_4fa09e82_000107_77a5d54a>
  412203:	test   eax,eax
  412205:	je     41220b <__swc_fn_4fa09e82_000179_6937fe70+0xfb>
  412207:	jl     412215 <__swc_fn_4fa09e82_000179_6937fe70+0x105>
  412209:	jmp    412232 <__swc_fn_4fa09e82_000179_6937fe70+0x122>
  41220b:	mov    rax,QWORD PTR [r14+r12*8]
  41220f:	cmp    QWORD PTR [r14+rsi*8],rax
  412213:	jae    412232 <__swc_fn_4fa09e82_000179_6937fe70+0x122>
  412215:	inc    r13
  412218:	mov    rsi,QWORD PTR [rsp+0xa8]
  412220:	mov    rax,QWORD PTR [rsp+0xb0]
  412228:	mov    r9,QWORD PTR [rsp+0xb8]
  412230:	jmp    4121d0 <__swc_fn_4fa09e82_000179_6937fe70+0xc0>
  412232:	mov    rsi,QWORD PTR [rip+0x14b77]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  412239:	mov    QWORD PTR [rsp+0xc0],rsi
  412241:	mov    rdi,QWORD PTR [rip+0x14b70]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  412248:	mov    r14,QWORD PTR [rip+0x14b71]        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  41224f:	mov    r15,QWORD PTR [rip+0x14b72]        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  412256:	mov    QWORD PTR [rsp+0x98],r13
  41225e:	mov    r13,QWORD PTR [rsp+0xa0]
  412266:	mov    rax,QWORD PTR [rip+0x14b63]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  41226d:	mov    QWORD PTR [rsp+0xc8],rax
  412275:	cs nop WORD PTR [rax+rax*1+0x0]
  41227f:	nop
  412280:	mov    r9,QWORD PTR [rsi+r13*8]
  412284:	mov    rcx,QWORD PTR [rdi+r9*8]
  412288:	cmp    QWORD PTR [rdi+r12*8],rcx
  41228c:	je     412292 <__swc_fn_4fa09e82_000179_6937fe70+0x182>
  41228e:	ja     4122c9 <__swc_fn_4fa09e82_000179_6937fe70+0x1b9>
  412290:	jmp    4122de <__swc_fn_4fa09e82_000179_6937fe70+0x1ce>
  412292:	mov    rcx,QWORD PTR [r14+r12*8]
  412296:	mov    r8,QWORD PTR [r14+r9*8]
  41229a:	cmp    r8,rcx
  41229d:	cmovae r8,rcx
  4122a1:	mov    rcx,QWORD PTR [r15+r12*8]
  4122a5:	add    rcx,rax
  4122a8:	mov    rdx,QWORD PTR [r15+r9*8]
  4122ac:	add    rdx,rax
  4122af:	mov    rsi,r9
  4122b2:	call   410eb0 <__swc_fn_4fa09e82_000107_77a5d54a>
  4122b7:	test   eax,eax
  4122b9:	je     4122bf <__swc_fn_4fa09e82_000179_6937fe70+0x1af>
  4122bb:	jl     4122c9 <__swc_fn_4fa09e82_000179_6937fe70+0x1b9>
  4122bd:	jmp    4122de <__swc_fn_4fa09e82_000179_6937fe70+0x1ce>
  4122bf:	mov    rax,QWORD PTR [r14+rsi*8]
  4122c3:	cmp    QWORD PTR [r14+r12*8],rax
  4122c7:	jae    4122de <__swc_fn_4fa09e82_000179_6937fe70+0x1ce>
  4122c9:	dec    r13
  4122cc:	mov    rsi,QWORD PTR [rsp+0xc0]
  4122d4:	mov    rax,QWORD PTR [rsp+0xc8]
  4122dc:	jmp    412280 <__swc_fn_4fa09e82_000179_6937fe70+0x170>
  4122de:	mov    rax,QWORD PTR [rsp+0x98]
  4122e6:	cmp    rax,r13
  4122e9:	jle    4122f6 <__swc_fn_4fa09e82_000179_6937fe70+0x1e6>
  4122eb:	mov    r14,r13
  4122ee:	mov    r13,rax
  4122f1:	jmp    412170 <__swc_fn_4fa09e82_000179_6937fe70+0x60>
  4122f6:	mov    rcx,QWORD PTR [rip+0x14ab3]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  4122fd:	mov    rdx,QWORD PTR [rcx+rax*8]
  412301:	mov    r8,QWORD PTR [rcx+r13*8]
  412305:	mov    QWORD PTR [rcx+rax*8],r8
  412309:	mov    rcx,QWORD PTR [rip+0x14aa0]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  412310:	mov    QWORD PTR [rcx+r13*8],rdx
  412314:	inc    rax
  412317:	dec    r13
  41231a:	mov    r14,r13
  41231d:	mov    r13,rax
  412320:	jmp    412170 <__swc_fn_4fa09e82_000179_6937fe70+0x60>
  412325:	mov    rcx,QWORD PTR [rsp+0x90]
  41232d:	mov    rdx,r13
  412330:	mov    rdi,rax
  412333:	call   412110 <__swc_fn_4fa09e82_000179_6937fe70>
  412338:	mov    rsi,QWORD PTR [rsp+0x88]
  412340:	cmp    rdi,rsi
  412343:	jl     412140 <__swc_fn_4fa09e82_000179_6937fe70+0x30>
  412349:	add    rsp,0xd8
  412350:	pop    r15
  412352:	pop    r14
  412354:	pop    r13
  412356:	pop    r12
  412358:	pop    rdi
  412359:	pop    rsi
  41235a:	ret
