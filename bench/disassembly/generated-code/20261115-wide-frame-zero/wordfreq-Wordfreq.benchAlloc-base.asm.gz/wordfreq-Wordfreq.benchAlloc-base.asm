
/workspace/prompt2-20261115/batch5-final-micro/base/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

000000000040b860 <__swc_fn_4fa09e82_000177_2744b483>:
  40b860:	push   rbx
  40b861:	sub    rsp,0x70
  40b865:	cmp    rcx,0xffffffffffffffef
  40b869:	jbe    40b873 <__swc_fn_4fa09e82_000177_2744b483+0x13>
  40b86b:	xor    eax,eax
  40b86d:	add    rsp,0x70
  40b871:	pop    rbx
  40b872:	ret
  40b873:	vxorps xmm0,xmm0,xmm0
  40b877:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40b87d:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40b883:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40b889:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40b88f:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40b895:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40b89b:	lea    rax,[rcx+0x10]
  40b89f:	mov    QWORD PTR [rsp+0x50],rax
  40b8a4:	mov    DWORD PTR [rsp+0x60],0x10
  40b8ac:	mov    rcx,QWORD PTR [rip+0x1b48d]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40b8b3:	test   rcx,rcx
  40b8b6:	jne    40b8c8 <__swc_fn_4fa09e82_000177_2744b483+0x68>
  40b8b8:	call   40f0f0 <__swc_fn_4fa09e82_000166_dc0404ce>
  40b8bd:	lea    rcx,[rax+0x1]
  40b8c1:	mov    QWORD PTR [rip+0x1b478],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40b8c8:	dec    rcx
  40b8cb:	call   40b6c0 <__swc_fn_4fa09e82_000168_3393d6f4>
  40b8d0:	mov    rcx,QWORD PTR [rax]
  40b8d3:	lea    rdx,[rsp+0x8]
  40b8d8:	mov    rbx,QWORD PTR [rax+0x8]
  40b8dc:	mov    rbx,QWORD PTR [rbx+0x8]
  40b8e0:	call   rbx
  40b8e2:	mov    rax,QWORD PTR [rsp+0x48]
  40b8e7:	test   rax,rax
  40b8ea:	jne    40b8f4 <__swc_fn_4fa09e82_000177_2744b483+0x94>
  40b8ec:	xor    eax,eax
  40b8ee:	add    rsp,0x70
  40b8f2:	pop    rbx
  40b8f3:	ret
  40b8f4:	mov    rcx,QWORD PTR [rsp+0x50]
  40b8f9:	mov    QWORD PTR [rax],rcx
  40b8fc:	mov    QWORD PTR [rax+0x8],0x0
  40b904:	lea    rax,[rax+0x10]
  40b908:	add    rsp,0x70
  40b90c:	pop    rbx
  40b90d:	ret
