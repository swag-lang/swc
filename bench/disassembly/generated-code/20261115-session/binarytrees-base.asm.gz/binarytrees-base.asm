
/workspace/prompt2-20261115/session-combined-micro/base/binarytrees/binarytrees:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xb002]        # 412008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xaffa]        # 412010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xaff2]        # 412018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xafea]        # 412020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xafe2]        # 412028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xafda]        # 412030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xafd2]        # 412038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xafca]        # 412040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xafc2]        # 412048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xafba]        # 412050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xafb2]        # 412058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xafaa]        # 412060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xafa2]        # 412068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xaf9a]        # 412070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <madvise@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xaf9a]        # 412080 <madvise@GLIBC_2.2.5>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <pthread_key_delete@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xaf92]        # 412088 <pthread_key_delete@GLIBC_2.34>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <gettid@plt>:
  407100:	jmp    QWORD PTR [rip+0xaf8a]        # 412090 <gettid@GLIBC_2.30>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <flock@plt>:
  407110:	jmp    QWORD PTR [rip+0xaf82]        # 412098 <flock@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <__errno_location@plt>:
  407120:	jmp    QWORD PTR [rip+0xaf7a]        # 4120a0 <__errno_location@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <opendir@plt>:
  407130:	jmp    QWORD PTR [rip+0xaf72]        # 4120a8 <opendir@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <dirfd@plt>:
  407140:	jmp    QWORD PTR [rip+0xaf6a]        # 4120b0 <dirfd@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <readdir@plt>:
  407150:	jmp    QWORD PTR [rip+0xaf62]        # 4120b8 <readdir@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readlinkat@plt>:
  407160:	jmp    QWORD PTR [rip+0xaf5a]        # 4120c0 <readlinkat@GLIBC_2.4>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <openat@plt>:
  407170:	jmp    QWORD PTR [rip+0xaf52]        # 4120c8 <openat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <closedir@plt>:
  407180:	jmp    QWORD PTR [rip+0xaf4a]        # 4120d0 <closedir@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <memfd_create@plt>:
  407190:	jmp    QWORD PTR [rip+0xaf42]        # 4120d8 <memfd_create@GLIBC_2.27>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <ftruncate@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xaf3a]        # 4120e0 <ftruncate@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <write@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xaf32]        # 4120e8 <write@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <backtrace@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xaf2a]        # 4120f0 <backtrace@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <clock_gettime@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xaf22]        # 4120f8 <clock_gettime@GLIBC_2.17>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xaf1a]        # 412100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xaf12]        # 412108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xaddf]        # 412000 <__swc_fn_7dafa2b1_000179_1ca87929+0x480>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40ca80 <__swc_fn_7dafa2b1_000121_12b4ed22>
  40724e:	xor    ecx,ecx
  407250:	call   40c1a0 <__swc_fn_7dafa2b1_000094_14db3cf9>
  407255:	call   40d720 <__swc_fn_7dafa2b1_000178_a6773dec>
  40725a:	call   40f110 <__swc_fn_7dafa2b1_000095_337e587a>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_7dafa2b1_000000_46f18a51>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_7dafa2b1_000003_7ab4792e>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_7dafa2b1_000003_7ab4792e+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409260 <__swc_fn_7dafa2b1_000111_b25e3a45>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_7dafa2b1_000003_7ab4792e+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1bd81]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1bd7a]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_7dafa2b1_000003_7ab4792e+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_7dafa2b1_000003_7ab4792e+0x30>
  4072e6:	lea    rcx,[rip+0x1bd63]        # 423050 <__swc_bss_base_7dafa2b1+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1bd5c]        # 423050 <__swc_bss_base_7dafa2b1+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_7dafa2b1_000003_7ab4792e+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_7dafa2b1_000003_7ab4792e+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_7dafa2b1_000006_a23dca5f>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40d9c0 <__swc_fn_7dafa2b1_000011_6493fbbc>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_7dafa2b1_000012_c7df5d22>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_7dafa2b1_000006_a23dca5f+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_7dafa2b1_000003_7ab4792e>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_7dafa2b1_000006_a23dca5f+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_7dafa2b1_000009_d7e2bb25>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_7dafa2b1_000009_d7e2bb25+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40a530 <__swc_fn_7dafa2b1_000007_614a4804>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40d9b0 <__swc_fn_7dafa2b1_000008_4e857afc>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_7dafa2b1_000009_d7e2bb25+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_7dafa2b1_000009_d7e2bb25+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_7dafa2b1_000012_c7df5d22>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_7dafa2b1_000015_07eb9884>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_7dafa2b1_000015_07eb9884+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_7dafa2b1_000015_07eb9884+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_7dafa2b1_000015_07eb9884+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_7dafa2b1_000015_07eb9884+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40db20 <__swc_fn_7dafa2b1_000017_4df2d1a0>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_7dafa2b1_000015_07eb9884+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1bb3d]        # 423058 <__swc_bss_base_7dafa2b1+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1bb36]        # 423058 <__swc_bss_base_7dafa2b1+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_7dafa2b1_000015_07eb9884+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_7dafa2b1_000015_07eb9884+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40d9c0 <__swc_fn_7dafa2b1_000011_6493fbbc>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_7dafa2b1_000015_07eb9884+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40c7a0 <__swc_fn_7dafa2b1_000112_759e9ceb>
  407569:	lea    rcx,[rip+0x1bad8]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1bad1]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_7dafa2b1_000015_07eb9884+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_7dafa2b1_000015_07eb9884+0x110>
  407598:	lea    rcx,[rip+0x1bac1]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1baba]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_7dafa2b1_000015_07eb9884+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_7dafa2b1_000015_07eb9884+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_7dafa2b1_000018_7d1e8a10>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_7dafa2b1_000015_07eb9884+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_7dafa2b1_000018_7d1e8a10>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_7dafa2b1_000018_7d1e8a10+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_7dafa2b1_000018_7d1e8a10+0x10>

0000000000407630 <__swc_fn_7dafa2b1_000021_491ac000>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_7dafa2b1_000015_07eb9884>
  40763e:	lea    rdi,[rip+0x1bbab]        # 4231f0 <__swc_bss_base_7dafa2b1+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1bb94]        # 4231f8 <__swc_bss_base_7dafa2b1+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1bb89],rsi        # 4231f8 <__swc_bss_base_7dafa2b1+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_7dafa2b1_000024_4aca8b9e>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_7dafa2b1_000027_4aca8b9e>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_7dafa2b1_000030_06a93956>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_7dafa2b1_000030_06a93956+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1992c]        # 421000 <__swc_data_base_7dafa2b1>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_7dafa2b1_000030_06a93956+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_7dafa2b1_000030_06a93956+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_7dafa2b1_000030_06a93956+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40dce0 <__swc_fn_7dafa2b1_000032_84881cd8>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_7dafa2b1_000030_06a93956+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_7dafa2b1_000036_8d895ba1>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_7dafa2b1_000030_06a93956+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_7dafa2b1_000042_bab03645>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_7dafa2b1_000033_7ca1566d>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40a9e0 <__swc_fn_7dafa2b1_000031_90860ff2>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409740 <__swc_fn_7dafa2b1_000129_74b163fe>
  407734:	mov    rcx,rsi
  407737:	call   40dce0 <__swc_fn_7dafa2b1_000032_84881cd8>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_7dafa2b1_000036_8d895ba1>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_7dafa2b1_000039_40d1e569>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_7dafa2b1_000039_40d1e569+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_7dafa2b1_000039_40d1e569+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_7dafa2b1_000039_40d1e569+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_7dafa2b1_000039_40d1e569+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_7dafa2b1_000039_40d1e569+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409340 <__swc_fn_7dafa2b1_000114_27d95464>
  4077ca:	lea    rcx,[rip+0x1b877]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1b870]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_7dafa2b1_000039_40d1e569+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_7dafa2b1_000039_40d1e569+0x90>
  4077f8:	lea    rcx,[rip+0x1b861]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1b85a]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_7dafa2b1_000039_40d1e569+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_7dafa2b1_000039_40d1e569+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_7dafa2b1_000042_bab03645>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_7dafa2b1_000042_bab03645+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e2b0 <__swc_fn_7dafa2b1_000059_3ca3ac64>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_7dafa2b1_000042_bab03645+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_7dafa2b1_000042_bab03645+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_7dafa2b1_000009_d7e2bb25>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_7dafa2b1_000042_bab03645+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40d9e0 <__swc_fn_7dafa2b1_000014_afb279e2>
  40791e:	jmp    407941 <__swc_fn_7dafa2b1_000042_bab03645+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_7dafa2b1_000042_bab03645+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_7dafa2b1_000042_bab03645+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_7dafa2b1_000042_bab03645+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40aba0 <__swc_fn_7dafa2b1_000043_957e4917>
  407997:	mov    rcx,rdi
  40799a:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_7dafa2b1_000039_40d1e569>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_7dafa2b1_000045_1fe0f4e2>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_7dafa2b1_000045_1fe0f4e2+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_7dafa2b1_000009_d7e2bb25>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40a5e0 <__swc_fn_7dafa2b1_000013_9ba72deb>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40db60 <__swc_fn_7dafa2b1_000020_a66e8b97>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40a5e0 <__swc_fn_7dafa2b1_000013_9ba72deb>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_7dafa2b1_000021_491ac000>
  407c07:	mov    rcx,r14
  407c0a:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_7dafa2b1_000045_1fe0f4e2+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_7dafa2b1_000048_c877e9d2>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_7dafa2b1_000048_c877e9d2+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_7dafa2b1_000048_c877e9d2+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_7dafa2b1_000048_c877e9d2+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_7dafa2b1_000048_c877e9d2+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40df10 <__swc_fn_7dafa2b1_000047_bc5ec610>
  407d14:	jmp    407ce0 <__swc_fn_7dafa2b1_000048_c877e9d2+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_7dafa2b1_000048_c877e9d2+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_7dafa2b1_000048_c877e9d2+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_7dafa2b1_000048_c877e9d2+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_7dafa2b1_000048_c877e9d2+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_7dafa2b1_000048_c877e9d2+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_7dafa2b1_000048_c877e9d2+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_7dafa2b1_000048_c877e9d2+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_7dafa2b1_000051_f7021588>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_7dafa2b1_000051_f7021588+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_7dafa2b1_000051_f7021588+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_7dafa2b1_000051_f7021588+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_7dafa2b1_000051_f7021588+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40de70 <__swc_fn_7dafa2b1_000044_9c2ade9b>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40d9e0 <__swc_fn_7dafa2b1_000014_afb279e2>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_7dafa2b1_000054_ae20ea33>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_7dafa2b1_000054_ae20ea33+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_7dafa2b1_000054_ae20ea33+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_7dafa2b1_000054_ae20ea33+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_7dafa2b1_000057_5b81d8b6>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_7dafa2b1_000060_e6407a0a>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_7dafa2b1_000060_e6407a0a+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_7dafa2b1_000039_40d1e569>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_7dafa2b1_000060_e6407a0a+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_7dafa2b1_000063_c8a062d6>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40af20 <__swc_fn_7dafa2b1_000052_c7484fb0>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_7dafa2b1_000054_ae20ea33>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_7dafa2b1_000063_c8a062d6+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_7dafa2b1_000063_c8a062d6+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40b040 <__swc_fn_7dafa2b1_000058_8bd8d1d5>
  407f7f:	mov    rcx,rsi
  407f82:	call   40ac80 <__swc_fn_7dafa2b1_000049_2ff013cc>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_7dafa2b1_000066_254b71af>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_7dafa2b1_000066_254b71af+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1b049]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1b04b]        # 423080 <__swc_bss_base_7dafa2b1+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_7dafa2b1_000066_254b71af+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_7dafa2b1_000066_254b71af+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40a910 <__swc_fn_7dafa2b1_000022_3a2e2048>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_7dafa2b1_000066_254b71af+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_7dafa2b1_000063_c8a062d6>
  40808f:	jmp    408122 <__swc_fn_7dafa2b1_000066_254b71af+0x192>
  408094:	lea    rax,[rip+0x18f65]        # 421000 <__swc_data_base_7dafa2b1>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_7dafa2b1_000066_254b71af+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_7dafa2b1_000066_254b71af+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_7dafa2b1_000066_254b71af+0x135>
  4080b8:	call   40a9e0 <__swc_fn_7dafa2b1_000031_90860ff2>
  4080bd:	mov    rcx,rax
  4080c0:	call   40fee0 <__swc_fn_7dafa2b1_000128_41c3251c>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_7dafa2b1_000066_254b71af+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_7dafa2b1_000066_254b71af+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_7dafa2b1_000066_254b71af+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40df10 <__swc_fn_7dafa2b1_000047_bc5ec610>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_7dafa2b1_000066_254b71af+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_7dafa2b1_000051_f7021588>
  408115:	jmp    408122 <__swc_fn_7dafa2b1_000066_254b71af+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40a550 <__swc_fn_7dafa2b1_000010_395bb04b>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_7dafa2b1_000069_e681a956>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_7dafa2b1_000036_8d895ba1>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_7dafa2b1_000069_e681a956+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1b09a]        # 423240 <__swc_bss_base_7dafa2b1+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_7dafa2b1_000069_e681a956+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40e6e0 <__swc_fn_7dafa2b1_000068_7d4c42bf>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_7dafa2b1_000072_bfa08900>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40e430 <__swc_fn_7dafa2b1_000065_f9f4b610>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_7dafa2b1_000075_524b0734>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40e6e0 <__swc_fn_7dafa2b1_000068_7d4c42bf>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_7dafa2b1_000078_a120bd2b>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_7dafa2b1_000078_a120bd2b+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_7dafa2b1_000078_a120bd2b+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_7dafa2b1_000081_c25a0e73>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_7dafa2b1_000084_ddf2b8a1>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_7dafa2b1_000090_a2d50c23>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_7dafa2b1_000084_ddf2b8a1+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_7dafa2b1_000084_ddf2b8a1+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_7dafa2b1_000084_ddf2b8a1+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_7dafa2b1_000084_ddf2b8a1+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_7dafa2b1_000090_a2d50c23>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_7dafa2b1_000084_ddf2b8a1+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_7dafa2b1_000084_ddf2b8a1+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_7dafa2b1_000084_ddf2b8a1+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_7dafa2b1_000084_ddf2b8a1+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_7dafa2b1_000084_ddf2b8a1+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_7dafa2b1_000084_ddf2b8a1+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_7dafa2b1_000084_ddf2b8a1+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_7dafa2b1_000084_ddf2b8a1+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_7dafa2b1_000084_ddf2b8a1+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_7dafa2b1_000084_ddf2b8a1+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40c020 <__swc_fn_7dafa2b1_000082_754dcd57>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_7dafa2b1_000084_ddf2b8a1+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_7dafa2b1_000084_ddf2b8a1+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_7dafa2b1_000084_ddf2b8a1+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40c020 <__swc_fn_7dafa2b1_000082_754dcd57>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_7dafa2b1_000084_ddf2b8a1+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_7dafa2b1_000084_ddf2b8a1>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_7dafa2b1_000084_ddf2b8a1+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_7dafa2b1_000084_ddf2b8a1+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_7dafa2b1_000087_ea575bb3>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_7dafa2b1_000090_a2d50c23>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_7dafa2b1_000087_ea575bb3+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40eb40 <__swc_fn_7dafa2b1_000086_c45095aa>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_7dafa2b1_000087_ea575bb3+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_7dafa2b1_000087_ea575bb3+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_7dafa2b1_000087_ea575bb3+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40c020 <__swc_fn_7dafa2b1_000082_754dcd57>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_7dafa2b1_000087_ea575bb3+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_7dafa2b1_000087_ea575bb3>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_7dafa2b1_000087_ea575bb3+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_7dafa2b1_000087_ea575bb3+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_7dafa2b1_000090_a2d50c23>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_7dafa2b1_000090_a2d50c23+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_7dafa2b1_000090_a2d50c23+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_7dafa2b1_000090_a2d50c23+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_7dafa2b1_000090_a2d50c23+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40c020 <__swc_fn_7dafa2b1_000082_754dcd57>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40c020 <__swc_fn_7dafa2b1_000082_754dcd57>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_7dafa2b1_000090_a2d50c23+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_7dafa2b1_000090_a2d50c23+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_7dafa2b1_000090_a2d50c23+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_7dafa2b1_000090_a2d50c23+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_7dafa2b1_000090_a2d50c23>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_7dafa2b1_000090_a2d50c23+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_7dafa2b1_000090_a2d50c23+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_7dafa2b1_000090_a2d50c23+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_7dafa2b1_000090_a2d50c23+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_7dafa2b1_000090_a2d50c23+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_7dafa2b1_000090_a2d50c23+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_7dafa2b1_000090_a2d50c23+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_7dafa2b1_000090_a2d50c23+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_7dafa2b1_000090_a2d50c23+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_7dafa2b1_000090_a2d50c23+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_7dafa2b1_000090_a2d50c23+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_7dafa2b1_000090_a2d50c23+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_7dafa2b1_000090_a2d50c23+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_7dafa2b1_000090_a2d50c23+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_7dafa2b1_000090_a2d50c23+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_7dafa2b1_000090_a2d50c23+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409de0 <__swc_fn_7dafa2b1_000147_32a497f3>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_7dafa2b1_000090_a2d50c23+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_7dafa2b1_000090_a2d50c23>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_7dafa2b1_000090_a2d50c23+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_7dafa2b1_000090_a2d50c23+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_7dafa2b1_000090_a2d50c23+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409de0 <__swc_fn_7dafa2b1_000147_32a497f3>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409de0 <__swc_fn_7dafa2b1_000147_32a497f3>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_7dafa2b1_000093_f8c16535>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c150 <__swc_fn_7dafa2b1_000091_3d2f5a0d>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_7dafa2b1_000093_f8c16535+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_7dafa2b1_000093_f8c16535+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   410080 <__swc_fn_7dafa2b1_000137_a4ba10ed>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_7dafa2b1_000093_f8c16535+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0x9872]        # 4121c0 <__swc_rdata_base_7dafa2b1+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   40fba0 <__swc_fn_7dafa2b1_000116_035d76a1>
  408959:	call   40c9d0 <__swc_fn_7dafa2b1_000118_7f430081>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_7dafa2b1_000096_ad982b35>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40896f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408975:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40897b:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  408981:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  408987:	mov    QWORD PTR [rsp+0x48],rdx
  40898c:	mov    rax,r8
  40898f:	cmp    r8,0x1
  408993:	mov    edx,0x1
  408998:	cmovb  rax,rdx
  40899c:	mov    QWORD PTR [rsp+0x50],rax
  4089a1:	mov    rbx,QWORD PTR [rcx+0x8]
  4089a5:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a9:	mov    rcx,QWORD PTR [rcx]
  4089ac:	lea    rdx,[rsp+0x8]
  4089b1:	call   rbx
  4089b3:	add    rsp,0x70
  4089b7:	pop    rbx
  4089b8:	ret
  4089b9:	add    BYTE PTR [rax],al
  4089bb:	add    BYTE PTR [rax],al
  4089bd:	add    BYTE PTR [rax],al
	...

00000000004089c0 <__swc_fn_7dafa2b1_000099_b4c6da83>:
  4089c0:	push   rbx
  4089c1:	push   rsi
  4089c2:	push   rdi
  4089c3:	sub    rsp,0x30
  4089c7:	mov    rbx,rcx
  4089ca:	test   rcx,rcx
  4089cd:	je     4089e2 <__swc_fn_7dafa2b1_000099_b4c6da83+0x22>
  4089cf:	mov    rcx,rbx
  4089d2:	mov    edx,0x1
  4089d7:	call   408200 <__swc_fn_7dafa2b1_000078_a120bd2b>
  4089dc:	cmp    rax,0x1
  4089e0:	je     4089ea <__swc_fn_7dafa2b1_000099_b4c6da83+0x2a>
  4089e2:	add    rsp,0x30
  4089e6:	pop    rdi
  4089e7:	pop    rsi
  4089e8:	pop    rbx
  4089e9:	ret
  4089ea:	lea    rsi,[rsp+0x8]
  4089ef:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089f4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089fa:	lea    rax,[rsp+0x18]
  4089ff:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  408a04:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408a0a:	mov    rcx,QWORD PTR [rsp+0x20]
  408a0f:	test   rcx,rcx
  408a12:	je     408a28 <__swc_fn_7dafa2b1_000099_b4c6da83+0x68>
  408a14:	test   DWORD PTR [rcx+0x28],0x400000
  408a1b:	je     408a28 <__swc_fn_7dafa2b1_000099_b4c6da83+0x68>
  408a1d:	mov    rdx,QWORD PTR [rcx+0x30]
  408a21:	test   rdx,rdx
  408a24:	cmovne rcx,rdx
  408a28:	mov    edi,DWORD PTR [rcx+0x20]
  408a2b:	mov    rcx,rax
  408a2e:	call   40c330 <__swc_fn_7dafa2b1_000100_3ed08774>
  408a33:	mov    rcx,rsi
  408a36:	mov    rdx,QWORD PTR [rsp+0x18]
  408a3b:	mov    r8,rdi
  408a3e:	call   408960 <__swc_fn_7dafa2b1_000096_ad982b35>
  408a43:	mov    rcx,QWORD PTR [rbx+0x28]
  408a47:	call   40f120 <__swc_fn_7dafa2b1_000098_00f01091>
  408a4c:	mov    rcx,rsi
  408a4f:	mov    rdx,rbx
  408a52:	mov    r8d,0x30
  408a58:	call   408960 <__swc_fn_7dafa2b1_000096_ad982b35>
  408a5d:	add    rsp,0x30
  408a61:	pop    rdi
  408a62:	pop    rsi
  408a63:	pop    rbx
  408a64:	ret
	...

0000000000408a80 <__swc_fn_7dafa2b1_000102_e9fdc18e>:
  408a80:	push   rbp
  408a81:	push   rbx
  408a82:	push   rsi
  408a83:	push   rdi
  408a84:	push   r12
  408a86:	push   r13
  408a88:	push   r14
  408a8a:	push   r15
  408a8c:	sub    rsp,0x500
  408a93:	mov    rbp,rsp
  408a96:	mov    rbx,rsp
  408a99:	mov    rsi,rdx
  408a9c:	mov    rdi,rcx
  408a9f:	mov    rcx,QWORD PTR [rip+0x1d29a]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  408aa6:	test   rcx,rcx
  408aa9:	jne    408ac3 <__swc_fn_7dafa2b1_000102_e9fdc18e+0x43>
  408aab:	sub    rsp,0x8
  408aaf:	call   40a1d0 <__swc_fn_7dafa2b1_000165_cf398896>
  408ab4:	add    rsp,0x8
  408ab8:	lea    rcx,[rax+0x1]
  408abc:	mov    QWORD PTR [rip+0x1d27d],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  408ac3:	dec    rcx
  408ac6:	sub    rsp,0x8
  408aca:	call   4119a0 <__swc_fn_7dafa2b1_000167_fce60b2b>
  408acf:	add    rsp,0x8
  408ad3:	mov    r12,rax
  408ad6:	mov    QWORD PTR [rsp+0x4f0],rax
  408ade:	lea    rax,[rip+0x981b]        # 412300 <__swc_rdata_base_7dafa2b1+0x1f0>
  408ae5:	sub    rsp,0x20
  408ae9:	mov    rcx,rsp
  408aec:	mov    QWORD PTR [rcx],rax
  408aef:	lea    r13,[rip+0x981a]        # 412310 <__swc_rdata_base_7dafa2b1+0x200>
  408af6:	mov    QWORD PTR [rcx+0x8],r13
  408afa:	mov    QWORD PTR [rcx+0x10],rsp
  408afe:	mov    QWORD PTR [rcx+0x18],0x1
  408b06:	lea    rcx,[rsp+0x10]
  408b0b:	sub    rsp,0x8
  408b0f:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  408b14:	add    rsp,0x8
  408b18:	add    rsp,0x20
  408b1c:	lea    rax,[rip+0x9835]        # 412358 <__swc_rdata_base_7dafa2b1+0x248>
  408b23:	sub    rsp,0x20
  408b27:	mov    rcx,rsp
  408b2a:	mov    QWORD PTR [rcx],rax
  408b2d:	mov    QWORD PTR [rcx+0x8],r13
  408b31:	mov    QWORD PTR [rcx+0x10],rsp
  408b35:	mov    QWORD PTR [rcx+0x18],0x1
  408b3d:	lea    rcx,[rsp+0x10]
  408b42:	sub    rsp,0x8
  408b46:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  408b4b:	add    rsp,0x8
  408b4f:	add    rsp,0x20
  408b53:	lea    r14,[rip+0x980e]        # 412368 <__swc_rdata_base_7dafa2b1+0x258>
  408b5a:	sub    rsp,0x50
  408b5e:	mov    rax,rsp
  408b61:	vmovups xmm0,XMMWORD PTR [rip+0x9937]        # 4124a0 <__swc_rdata_base_7dafa2b1+0x390>
  408b69:	vmovups XMMWORD PTR [rax],xmm0
  408b6d:	mov    QWORD PTR [rax+0x10],rsp
  408b71:	mov    QWORD PTR [rax+0x18],r13
  408b75:	mov    QWORD PTR [rax+0x20],rdi
  408b79:	lea    rdi,[rip+0x97f8]        # 412378 <__swc_rdata_base_7dafa2b1+0x268>
  408b80:	mov    QWORD PTR [rax+0x28],rdi
  408b84:	mov    QWORD PTR [rax+0x30],r14
  408b88:	mov    QWORD PTR [rax+0x38],r13
  408b8c:	lea    rcx,[rsp+0x10]
  408b91:	mov    QWORD PTR [rax+0x40],rcx
  408b95:	mov    QWORD PTR [rax+0x48],0x3
  408b9d:	lea    rcx,[rsp+0x40]
  408ba2:	sub    rsp,0x8
  408ba6:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  408bab:	add    rsp,0x8
  408baf:	add    rsp,0x50
  408bb3:	lea    rax,[rip+0x9806]        # 4123c0 <__swc_rdata_base_7dafa2b1+0x2b0>
  408bba:	sub    rsp,0x20
  408bbe:	mov    rcx,rsp
  408bc1:	mov    QWORD PTR [rcx],rax
  408bc4:	mov    QWORD PTR [rcx+0x8],r13
  408bc8:	mov    QWORD PTR [rcx+0x10],rsp
  408bcc:	mov    QWORD PTR [rcx+0x18],0x1
  408bd4:	lea    rcx,[rsp+0x10]
  408bd9:	sub    rsp,0x8
  408bdd:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  408be2:	add    rsp,0x8
  408be6:	add    rsp,0x20
  408bea:	mov    eax,DWORD PTR [rsi+0x20]
  408bed:	mov    ecx,DWORD PTR [rsi+0x24]
  408bf0:	sub    rsp,0xa0
  408bf7:	mov    rdx,rsp
  408bfa:	mov    QWORD PTR [rdx+0x30],rsi
  408bfe:	mov    QWORD PTR [rdx+0x38],rdi
  408c02:	vmovups xmm0,XMMWORD PTR [rip+0x982e]        # 412438 <__swc_rdata_base_7dafa2b1+0x328>
  408c0a:	vmovups XMMWORD PTR [rdx],xmm0
  408c0e:	mov    QWORD PTR [rdx+0x40],rsp
  408c12:	mov    QWORD PTR [rdx+0x48],r13
  408c16:	mov    DWORD PTR [rdx+0x10],eax
  408c19:	lea    rax,[rsp+0x10]
  408c1e:	mov    QWORD PTR [rdx+0x50],rax
  408c22:	lea    rax,[rip+0x97a7]        # 4123d0 <__swc_rdata_base_7dafa2b1+0x2c0>
  408c29:	mov    QWORD PTR [rdx+0x58],rax
  408c2d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c32:	lea    r8,[rsp+0x18]
  408c37:	mov    QWORD PTR [rdx+0x60],r8
  408c3b:	mov    QWORD PTR [rdx+0x68],r13
  408c3f:	mov    DWORD PTR [rdx+0x28],ecx
  408c42:	lea    rcx,[rdx+0x28]
  408c46:	mov    QWORD PTR [rdx+0x70],rcx
  408c4a:	mov    QWORD PTR [rdx+0x78],rax
  408c4e:	mov    QWORD PTR [rdx+0x80],r14
  408c55:	mov    QWORD PTR [rdx+0x88],r13
  408c5c:	lea    rax,[rdx+0x30]
  408c60:	mov    QWORD PTR [rdx+0x90],rax
  408c67:	mov    QWORD PTR [rdx+0x98],0x6
  408c72:	lea    rcx,[rdx+0x90]
  408c79:	sub    rsp,0x8
  408c7d:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  408c82:	add    rsp,0x8
  408c86:	add    rsp,0xa0
  408c8d:	sub    rsp,0x20
  408c91:	mov    rax,rsp
  408c94:	mov    QWORD PTR [rax],r14
  408c97:	mov    QWORD PTR [rax+0x8],r13
  408c9b:	mov    QWORD PTR [rax+0x10],rsp
  408c9f:	mov    QWORD PTR [rax+0x18],0x1
  408ca7:	lea    rcx,[rsp+0x10]
  408cac:	sub    rsp,0x8
  408cb0:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  408cb5:	add    rsp,0x8
  408cb9:	add    rsp,0x20
  408cbd:	mov    eax,DWORD PTR [r12+0x9ac]
  408cc5:	test   eax,eax
  408cc7:	je     408f00 <__swc_fn_7dafa2b1_000102_e9fdc18e+0x480>
  408ccd:	lea    rax,[rip+0x9744]        # 412418 <__swc_rdata_base_7dafa2b1+0x308>
  408cd4:	sub    rsp,0x20
  408cd8:	mov    rcx,rsp
  408cdb:	mov    QWORD PTR [rcx],rax
  408cde:	mov    QWORD PTR [rcx+0x8],r13
  408ce2:	mov    QWORD PTR [rcx+0x10],rsp
  408ce6:	mov    QWORD PTR [rcx+0x18],0x1
  408cee:	lea    rcx,[rsp+0x10]
  408cf3:	sub    rsp,0x8
  408cf7:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  408cfc:	add    rsp,0x8
  408d00:	add    rsp,0x20
  408d04:	mov    eax,DWORD PTR [r12+0x9ac]
  408d0c:	dec    eax
  408d0e:	mov    esi,eax
  408d10:	test   esi,esi
  408d12:	jl     408ed0 <__swc_fn_7dafa2b1_000102_e9fdc18e+0x450>
  408d18:	jmp    408d24 <__swc_fn_7dafa2b1_000102_e9fdc18e+0x2a4>
  408d1a:	nop    WORD PTR [rax+rax*1+0x0]
  408d20:	dec    esi
  408d22:	jmp    408d10 <__swc_fn_7dafa2b1_000102_e9fdc18e+0x290>
  408d24:	lea    rax,[rip+0x96fd]        # 412428 <__swc_rdata_base_7dafa2b1+0x318>
  408d2b:	sub    rsp,0x20
  408d2f:	mov    rcx,rsp
  408d32:	mov    QWORD PTR [rcx],rax
  408d35:	mov    QWORD PTR [rcx+0x8],r13
  408d39:	mov    QWORD PTR [rcx+0x10],rsp
  408d3d:	mov    QWORD PTR [rcx+0x18],0x1
  408d45:	lea    rcx,[rsp+0x10]
  408d4a:	sub    rsp,0x8
  408d4e:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  408d53:	add    rsp,0x8
  408d57:	add    rsp,0x20
  408d5b:	movsxd rax,esi
  408d5e:	imul   r15,rax,0x30
  408d62:	add    r15,r12
  408d65:	add    r15,0xf8
  408d6c:	sub    rsp,0x20
  408d70:	mov    rax,rsp
  408d73:	mov    QWORD PTR [rax],r15
  408d76:	mov    QWORD PTR [rax+0x8],rdi
  408d7a:	mov    QWORD PTR [rax+0x10],rsp
  408d7e:	mov    QWORD PTR [rax+0x18],0x1
  408d86:	lea    rcx,[rsp+0x10]
  408d8b:	sub    rsp,0x8
  408d8f:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  408d94:	add    rsp,0x8
  408d98:	add    rsp,0x20
  408d9c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408da4:	lea    rsi,[rip+0x968d]        # 412438 <__swc_rdata_base_7dafa2b1+0x328>
  408dab:	sub    rsp,0x20
  408daf:	mov    rax,rsp
  408db2:	mov    QWORD PTR [rax],rsi
  408db5:	mov    QWORD PTR [rax+0x8],r13
  408db9:	mov    QWORD PTR [rax+0x10],rsp
  408dbd:	mov    QWORD PTR [rax+0x18],0x1
  408dc5:	lea    rcx,[rsp+0x10]
  408dca:	sub    rsp,0x8
  408dce:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  408dd3:	add    rsp,0x8
  408dd7:	add    rsp,0x20
  408ddb:	sub    rsp,0x30
  408ddf:	mov    rax,rsp
  408de2:	mov    ecx,DWORD PTR [r15+0x20]
  408de6:	mov    QWORD PTR [rax],rcx
  408de9:	mov    QWORD PTR [rax+0x8],rsp
  408ded:	lea    rdi,[rip+0x9654]        # 412448 <__swc_rdata_base_7dafa2b1+0x338>
  408df4:	mov    QWORD PTR [rax+0x10],rdi
  408df8:	lea    rcx,[rsp+0x8]
  408dfd:	mov    QWORD PTR [rax+0x18],rcx
  408e01:	mov    QWORD PTR [rax+0x20],0x1
  408e09:	lea    rcx,[rsp+0x18]
  408e0e:	sub    rsp,0x8
  408e12:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  408e17:	add    rsp,0x8
  408e1b:	add    rsp,0x30
  408e1f:	sub    rsp,0x20
  408e23:	mov    rax,rsp
  408e26:	mov    QWORD PTR [rax],rsi
  408e29:	mov    QWORD PTR [rax+0x8],r13
  408e2d:	mov    QWORD PTR [rax+0x10],rsp
  408e31:	mov    QWORD PTR [rax+0x18],0x1
  408e39:	lea    rcx,[rsp+0x10]
  408e3e:	sub    rsp,0x8
  408e42:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  408e47:	add    rsp,0x8
  408e4b:	add    rsp,0x20
  408e4f:	sub    rsp,0x30
  408e53:	mov    rax,rsp
  408e56:	mov    ecx,DWORD PTR [r15+0x24]
  408e5a:	mov    QWORD PTR [rax],rcx
  408e5d:	mov    QWORD PTR [rax+0x8],rsp
  408e61:	mov    QWORD PTR [rax+0x10],rdi
  408e65:	lea    rcx,[rsp+0x8]
  408e6a:	mov    QWORD PTR [rax+0x18],rcx
  408e6e:	mov    QWORD PTR [rax+0x20],0x1
  408e76:	lea    rcx,[rsp+0x18]
  408e7b:	sub    rsp,0x8
  408e7f:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  408e84:	add    rsp,0x8
  408e88:	add    rsp,0x30
  408e8c:	sub    rsp,0x20
  408e90:	mov    rax,rsp
  408e93:	mov    QWORD PTR [rax],r14
  408e96:	mov    QWORD PTR [rax+0x8],r13
  408e9a:	mov    QWORD PTR [rax+0x10],rsp
  408e9e:	mov    QWORD PTR [rax+0x18],0x1
  408ea6:	lea    rcx,[rsp+0x10]
  408eab:	sub    rsp,0x8
  408eaf:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  408eb4:	add    rsp,0x8
  408eb8:	add    rsp,0x20
  408ebc:	lea    rdi,[rip+0x94b5]        # 412378 <__swc_rdata_base_7dafa2b1+0x268>
  408ec3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408ecb:	jmp    408d20 <__swc_fn_7dafa2b1_000102_e9fdc18e+0x2a0>
  408ed0:	sub    rsp,0x20
  408ed4:	mov    rax,rsp
  408ed7:	mov    QWORD PTR [rax],r14
  408eda:	mov    QWORD PTR [rax+0x8],r13
  408ede:	mov    QWORD PTR [rax+0x10],rsp
  408ee2:	mov    QWORD PTR [rax+0x18],0x1
  408eea:	lea    rcx,[rsp+0x10]
  408eef:	sub    rsp,0x8
  408ef3:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  408ef8:	add    rsp,0x8
  408efc:	add    rsp,0x20
  408f00:	lea    rax,[rbx+0x28]
  408f04:	mov    rcx,rax
  408f07:	mov    QWORD PTR [rbx+0x28],0x0
  408f0f:	mov    QWORD PTR [rbx+0x30],0x0
  408f17:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408f1c:	add    rcx,0x10
  408f20:	mov    edx,0x1f
  408f25:	cs nop WORD PTR [rax+rax*1+0x0]
  408f2f:	nop
  408f30:	vmovups XMMWORD PTR [rcx],xmm0
  408f34:	add    rcx,0x10
  408f38:	sub    rdx,0x1
  408f3c:	jne    408f30 <__swc_fn_7dafa2b1_000102_e9fdc18e+0x4b0>
  408f3e:	lea    rsi,[rbx+0x228]
  408f45:	xor    ecx,ecx
  408f47:	cs nop WORD PTR [rax+rax*1+0x0]
  408f51:	cs nop WORD PTR [rax+rax*1+0x0]
  408f5b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f60:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f65:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f6a:	add    rcx,0x10
  408f6e:	cmp    rcx,0x200
  408f75:	jne    408f60 <__swc_fn_7dafa2b1_000102_e9fdc18e+0x4e0>
  408f77:	mov    eax,DWORD PTR [r12+0xbc8]
  408f7f:	lea    rcx,[r12+0x9c8]
  408f87:	mov    QWORD PTR [rbx+0x428],rcx
  408f8e:	mov    QWORD PTR [rbx+0x430],rax
  408f95:	lea    rdi,[rbx+0x438]
  408f9c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408fa4:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fac:	mov    eax,DWORD PTR [r12+0xbc8]
  408fb4:	test   eax,eax
  408fb6:	jne    409003 <__swc_fn_7dafa2b1_000102_e9fdc18e+0x583>
  408fb8:	lea    rax,[rbx+0x448]
  408fbf:	mov    QWORD PTR [rbx+0x448],rsi
  408fc6:	mov    QWORD PTR [rax+0x8],0x40
  408fce:	mov    ecx,0x1
  408fd3:	mov    rdx,rax
  408fd6:	sub    rsp,0x8
  408fda:	call   40fcc0 <__swc_fn_7dafa2b1_000119_9175a56a>
  408fdf:	add    rsp,0x8
  408fe3:	mov    QWORD PTR [rbx+0x460],rsi
  408fea:	mov    ecx,eax
  408fec:	mov    QWORD PTR [rbx+0x468],rcx
  408ff3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408ffb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  409003:	mov    rsi,QWORD PTR [rbx+0x438]
  40900a:	mov    rax,QWORD PTR [rbx+0x440]
  409011:	mov    r15,rax
  409014:	xor    r12d,r12d
  409017:	test   r15,r15
  40901a:	je     4090d0 <__swc_fn_7dafa2b1_000102_e9fdc18e+0x650>
  409020:	mov    rax,QWORD PTR [rsi+r12*8]
  409024:	test   rax,rax
  409027:	je     409046 <__swc_fn_7dafa2b1_000102_e9fdc18e+0x5c6>
  409029:	lea    rcx,[rbx+0x4b8]
  409030:	mov    rdx,rax
  409033:	sub    rsp,0x8
  409037:	call   409f40 <__swc_fn_7dafa2b1_000162_60216e69>
  40903c:	add    rsp,0x8
  409040:	mov    al,BYTE PTR [rax]
  409042:	test   al,al
  409044:	jne    409052 <__swc_fn_7dafa2b1_000102_e9fdc18e+0x5d2>
  409046:	add    r12,0x1
  40904a:	sub    r15,0x1
  40904e:	jne    409020 <__swc_fn_7dafa2b1_000102_e9fdc18e+0x5a0>
  409050:	jmp    4090d0 <__swc_fn_7dafa2b1_000102_e9fdc18e+0x650>
  409052:	lea    rax,[rip+0x9437]        # 412490 <__swc_rdata_base_7dafa2b1+0x380>
  409059:	sub    rsp,0x20
  40905d:	mov    rcx,rsp
  409060:	mov    QWORD PTR [rcx],rax
  409063:	mov    QWORD PTR [rcx+0x8],r13
  409067:	mov    QWORD PTR [rcx+0x10],rsp
  40906b:	mov    QWORD PTR [rcx+0x18],0x1
  409073:	lea    rcx,[rsp+0x10]
  409078:	sub    rsp,0x8
  40907c:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  409081:	add    rsp,0x8
  409085:	add    rsp,0x20
  409089:	mov    rcx,rdi
  40908c:	xor    edx,edx
  40908e:	mov    al,0x1
  409090:	mov    r8,rax
  409093:	sub    rsp,0x8
  409097:	call   40d280 <__swc_fn_7dafa2b1_000163_8e41797b>
  40909c:	add    rsp,0x8
  4090a0:	sub    rsp,0x20
  4090a4:	mov    rax,rsp
  4090a7:	mov    QWORD PTR [rax],r14
  4090aa:	mov    QWORD PTR [rax+0x8],r13
  4090ae:	mov    QWORD PTR [rax+0x10],rsp
  4090b2:	mov    QWORD PTR [rax+0x18],0x1
  4090ba:	lea    rcx,[rsp+0x10]
  4090bf:	sub    rsp,0x8
  4090c3:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  4090c8:	add    rsp,0x8
  4090cc:	add    rsp,0x20
  4090d0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090d8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090e4:	add    rsp,0x500
  4090eb:	pop    r15
  4090ed:	pop    r14
  4090ef:	pop    r13
  4090f1:	pop    r12
  4090f3:	pop    rdi
  4090f4:	pop    rsi
  4090f5:	pop    rbx
  4090f6:	pop    rbp
  4090f7:	ret
	...

0000000000409100 <__swc_fn_7dafa2b1_000105_6fd80914>:
  409100:	sub    rsp,0x8
  409104:	test   r8,r8
  409107:	je     40910e <__swc_fn_7dafa2b1_000105_6fd80914+0xe>
  409109:	call   40f3b0 <__swc_fn_7dafa2b1_000104_5589fdbd>
  40910e:	add    rsp,0x8
  409112:	ret
	...

0000000000409120 <__swc_fn_7dafa2b1_000108_84af7666>:
  409120:	push   rsi
  409121:	push   rdi
  409122:	push   r12
  409124:	push   r13
  409126:	sub    rsp,0xd8
  40912d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409133:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409139:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40913f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409145:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40914b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409154:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40915d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409166:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40916f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409178:	xor    eax,eax
  40917a:	call   407010 <getpid@plt>
  40917f:	mov    rsi,rax
  409182:	lea    rdi,[rip+0x1cbbf]        # 425d48 <__swc_bss_base_7dafa2b1+0x2d08>
  409189:	mov    r12,QWORD PTR [rdi]
  40918c:	test   r12,r12
  40918f:	je     40919d <__swc_fn_7dafa2b1_000108_84af7666+0x7d>
  409191:	cmp    DWORD PTR [r12+0x10],esi
  409196:	jne    40919d <__swc_fn_7dafa2b1_000108_84af7666+0x7d>
  409198:	mov    rax,r12
  40919b:	jmp    409200 <__swc_fn_7dafa2b1_000108_84af7666+0xe0>
  40919d:	mov    ecx,0x4
  4091a2:	mov    edx,0x18
  4091a7:	call   40f4a0 <__swc_fn_7dafa2b1_000107_4796e893>
  4091ac:	mov    rcx,rax
  4091af:	test   rax,rax
  4091b2:	jne    4091b8 <__swc_fn_7dafa2b1_000108_84af7666+0x98>
  4091b4:	xor    eax,eax
  4091b6:	jmp    409200 <__swc_fn_7dafa2b1_000108_84af7666+0xe0>
  4091b8:	mov    DWORD PTR [rcx+0x10],esi
  4091bb:	mov    rax,r12
  4091be:	lock cmpxchg QWORD PTR [rdi],rcx
  4091c3:	mov    r13,rax
  4091c6:	cmp    rax,r12
  4091c9:	je     4091df <__swc_fn_7dafa2b1_000108_84af7666+0xbf>
  4091cb:	mov    rdi,rcx
  4091ce:	mov    esi,0x18
  4091d3:	xor    eax,eax
  4091d5:	call   407020 <munmap@plt>
  4091da:	mov    rax,r13
  4091dd:	jmp    409200 <__swc_fn_7dafa2b1_000108_84af7666+0xe0>
  4091df:	test   r12,r12
  4091e2:	je     4091fd <__swc_fn_7dafa2b1_000108_84af7666+0xdd>
  4091e4:	mov    rdi,r12
  4091e7:	mov    esi,0x18
  4091ec:	xor    eax,eax
  4091ee:	mov    QWORD PTR [rsp+0x28],rcx
  4091f3:	call   407020 <munmap@plt>
  4091f8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091fd:	mov    rax,rcx
  409200:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  409206:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40920c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  409212:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  409218:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40921e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409227:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409230:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409239:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409242:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40924b:	add    rsp,0xd8
  409252:	pop    r13
  409254:	pop    r12
  409256:	pop    rdi
  409257:	pop    rsi
  409258:	ret
  409259:	add    BYTE PTR [rax],al
  40925b:	add    BYTE PTR [rax],al
  40925d:	add    BYTE PTR [rax],al
	...

0000000000409260 <__swc_fn_7dafa2b1_000111_b25e3a45>:
  409260:	push   rbx
  409261:	push   r12
  409263:	push   rdi
  409264:	push   rsi
  409265:	sub    rsp,0xa8
  40926c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409272:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409278:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40927e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409284:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40928a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409290:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409296:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40929c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4092a5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4092ae:	mov    rbx,rdx
  4092b1:	mov    r12,rcx
  4092b4:	mov    rdi,rcx
  4092b7:	mov    rsi,rdx
  4092ba:	mov    edx,0x3
  4092bf:	xor    eax,eax
  4092c1:	call   407030 <mprotect@plt>
  4092c6:	test   eax,eax
  4092c8:	je     4092ce <__swc_fn_7dafa2b1_000111_b25e3a45+0x6e>
  4092ca:	xor    eax,eax
  4092cc:	jmp    4092e3 <__swc_fn_7dafa2b1_000111_b25e3a45+0x83>
  4092ce:	mov    rcx,r12
  4092d1:	mov    rdx,rbx
  4092d4:	mov    al,0x1
  4092d6:	mov    r8,rax
  4092d9:	call   40faf0 <__swc_fn_7dafa2b1_000110_a808fe76>
  4092de:	mov    eax,0x1
  4092e3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092e9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092ef:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092f5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092fb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409301:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409307:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40930d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409313:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40931c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409325:	add    rsp,0xa8
  40932c:	pop    rsi
  40932d:	pop    rdi
  40932e:	pop    r12
  409330:	pop    rbx
  409331:	ret
	...

0000000000409340 <__swc_fn_7dafa2b1_000114_27d95464>:
  409340:	sub    rsp,0x8
  409344:	test   rcx,rcx
  409347:	jne    40934e <__swc_fn_7dafa2b1_000114_27d95464+0xe>
  409349:	add    rsp,0x8
  40934d:	ret
  40934e:	call   40c880 <__swc_fn_7dafa2b1_000115_1ba33335>
  409353:	add    rsp,0x8
  409357:	ret
	...

0000000000409360 <__swc_fn_7dafa2b1_000117_86a7fb9e>:
  409360:	push   rdi
  409361:	push   rsi
  409362:	sub    rsp,0xa8
  409369:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40936f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409375:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40937b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409381:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409387:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40938d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409393:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409399:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4093a2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4093ab:	xor    edi,edi
  4093ad:	xor    eax,eax
  4093af:	call   407040 <exit@plt>
  4093b4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4093ba:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093c0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093c6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093cc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093d2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093d8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093de:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093e4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093ed:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093f6:	add    rsp,0xa8
  4093fd:	pop    rsi
  4093fe:	pop    rdi
  4093ff:	ret

0000000000409400 <__swc_fn_7dafa2b1_000120_ea68f292>:
  409400:	push   rbx
  409401:	push   rsi
  409402:	push   rdi
  409403:	push   r12
  409405:	sub    rsp,0x18
  409409:	mov    rbx,r8
  40940c:	mov    rsi,rcx
  40940f:	mov    rdi,rdx
  409412:	mov    rcx,QWORD PTR [rip+0x1c927]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  409419:	test   rcx,rcx
  40941c:	jne    40942e <__swc_fn_7dafa2b1_000120_ea68f292+0x2e>
  40941e:	call   40a1d0 <__swc_fn_7dafa2b1_000165_cf398896>
  409423:	lea    rcx,[rax+0x1]
  409427:	mov    QWORD PTR [rip+0x1c912],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40942e:	dec    rcx
  409431:	call   4119a0 <__swc_fn_7dafa2b1_000167_fce60b2b>
  409436:	mov    r12,rax
  409439:	cmp    ebx,0x3
  40943c:	jne    40944f <__swc_fn_7dafa2b1_000120_ea68f292+0x4f>
  40943e:	mov    rax,QWORD PTR [r12+0xbd0]
  409446:	test   rax,rax
  409449:	jne    40958f <__swc_fn_7dafa2b1_000120_ea68f292+0x18f>
  40944f:	cmp    ebx,0x5
  409452:	jne    409476 <__swc_fn_7dafa2b1_000120_ea68f292+0x76>
  409454:	call   40c150 <__swc_fn_7dafa2b1_000091_3d2f5a0d>
  409459:	test   al,al
  40945b:	jne    409476 <__swc_fn_7dafa2b1_000120_ea68f292+0x76>
  40945d:	mov    rcx,rsi
  409460:	mov    rdx,rdi
  409463:	call   411950 <__swc_fn_7dafa2b1_000164_1962e12a>
  409468:	test   al,al
  40946a:	je     409476 <__swc_fn_7dafa2b1_000120_ea68f292+0x76>
  40946c:	add    rsp,0x18
  409470:	pop    r12
  409472:	pop    rdi
  409473:	pop    rsi
  409474:	pop    rbx
  409475:	ret
  409476:	call   40c150 <__swc_fn_7dafa2b1_000091_3d2f5a0d>
  40947b:	test   al,al
  40947d:	jne    4094f2 <__swc_fn_7dafa2b1_000120_ea68f292+0xf2>
  40947f:	lea    rax,[rsp+0x8]
  409484:	vmovups xmm0,XMMWORD PTR [rsi]
  409488:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40948e:	mov    rcx,QWORD PTR [rsp+0x8]
  409493:	test   rcx,rcx
  409496:	jne    4094e7 <__swc_fn_7dafa2b1_000120_ea68f292+0xe7>
  409498:	cmp    ebx,0x3
  40949b:	je     4094a9 <__swc_fn_7dafa2b1_000120_ea68f292+0xa9>
  40949d:	cmp    ebx,0x4
  4094a0:	je     4094b9 <__swc_fn_7dafa2b1_000120_ea68f292+0xb9>
  4094a2:	cmp    ebx,0x5
  4094a5:	je     4094c9 <__swc_fn_7dafa2b1_000120_ea68f292+0xc9>
  4094a7:	jmp    4094d9 <__swc_fn_7dafa2b1_000120_ea68f292+0xd9>
  4094a9:	vmovups xmm0,XMMWORD PTR [rip+0x902f]        # 4124e0 <__swc_rdata_base_7dafa2b1+0x3d0>
  4094b1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b7:	jmp    4094e7 <__swc_fn_7dafa2b1_000120_ea68f292+0xe7>
  4094b9:	vmovups xmm0,XMMWORD PTR [rip+0x902f]        # 4124f0 <__swc_rdata_base_7dafa2b1+0x3e0>
  4094c1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c7:	jmp    4094e7 <__swc_fn_7dafa2b1_000120_ea68f292+0xe7>
  4094c9:	vmovups xmm0,XMMWORD PTR [rip+0x902f]        # 412500 <__swc_rdata_base_7dafa2b1+0x3f0>
  4094d1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094d7:	jmp    4094e7 <__swc_fn_7dafa2b1_000120_ea68f292+0xe7>
  4094d9:	vmovups xmm0,XMMWORD PTR [rip+0x902f]        # 412510 <__swc_rdata_base_7dafa2b1+0x400>
  4094e1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094e7:	mov    rcx,rax
  4094ea:	mov    rdx,rdi
  4094ed:	call   40c3a0 <__swc_fn_7dafa2b1_000103_67100064>
  4094f2:	vmovups xmm0,XMMWORD PTR [rdi]
  4094f6:	vmovups XMMWORD PTR [r12+0x940],xmm0
  409500:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  409505:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40950f:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  409514:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40951e:	lea    rax,[r12+0x940]
  409526:	mov    QWORD PTR [r12+0x970],rax
  40952e:	mov    rax,QWORD PTR [rsi]
  409531:	mov    QWORD PTR [r12+0x978],rax
  409539:	mov    rax,QWORD PTR [rsi+0x8]
  40953d:	mov    QWORD PTR [r12+0x980],rax
  409545:	movsxd rax,ebx
  409548:	mov    QWORD PTR [r12+0x988],rax
  409550:	cmp    ebx,0x5
  409553:	je     40955c <__swc_fn_7dafa2b1_000120_ea68f292+0x15c>
  409555:	xor    ecx,ecx
  409557:	call   40a300 <__swc_fn_7dafa2b1_000174_176517f9>
  40955c:	mov    rbx,QWORD PTR [r12+0xbe8]
  409564:	test   rbx,rbx
  409567:	je     409578 <__swc_fn_7dafa2b1_000120_ea68f292+0x178>
  409569:	mov    rcx,r12
  40956c:	call   rbx
  40956e:	add    rsp,0x18
  409572:	pop    r12
  409574:	pop    rdi
  409575:	pop    rsi
  409576:	pop    rbx
  409577:	ret
  409578:	mov    rcx,rsi
  40957b:	call   40fba0 <__swc_fn_7dafa2b1_000116_035d76a1>
  409580:	call   40c9d0 <__swc_fn_7dafa2b1_000118_7f430081>
  409585:	add    rsp,0x18
  409589:	pop    r12
  40958b:	pop    rdi
  40958c:	pop    rsi
  40958d:	pop    rbx
  40958e:	ret
  40958f:	mov    rcx,rsi
  409592:	mov    rdx,rdi
  409595:	call   40c3a0 <__swc_fn_7dafa2b1_000103_67100064>
  40959a:	jmp    40944f <__swc_fn_7dafa2b1_000120_ea68f292+0x4f>
	...

00000000004095a0 <__swc_fn_7dafa2b1_000123_9d2cbd72>:
  4095a0:	push   rdi
  4095a1:	push   rsi
  4095a2:	sub    rsp,0xb8
  4095a9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4095af:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4095b5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4095bb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095c1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095c7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095cd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095d3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095dc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095e5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ee:	mov    DWORD PTR [rsp+0x8],0x0
  4095f6:	lea    rdi,[rsp+0x8]
  4095fb:	xor    esi,esi
  4095fd:	xor    eax,eax
  4095ff:	call   407050 <pthread_key_create@plt>
  409604:	test   eax,eax
  409606:	jne    40960e <__swc_fn_7dafa2b1_000123_9d2cbd72+0x6e>
  409608:	mov    eax,DWORD PTR [rsp+0x8]
  40960c:	jmp    409615 <__swc_fn_7dafa2b1_000123_9d2cbd72+0x75>
  40960e:	mov    rax,0xffffffffffffffff
  409615:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40961b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409621:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409627:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40962d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409633:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409639:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40963f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409648:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409651:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40965a:	add    rsp,0xb8
  409661:	pop    rsi
  409662:	pop    rdi
  409663:	ret
	...

0000000000409670 <__swc_fn_7dafa2b1_000126_102fe7b9>:
  409670:	push   rdi
  409671:	push   rsi
  409672:	sub    rsp,0xb8
  409679:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40967f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409685:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40968b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409691:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409697:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40969d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4096a3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4096ac:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4096b5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4096be:	mov    DWORD PTR [rsp+0x8],0x0
  4096c6:	lea    rdi,[rsp+0x8]
  4096cb:	mov    rsi,rcx
  4096ce:	xor    eax,eax
  4096d0:	call   407050 <pthread_key_create@plt>
  4096d5:	test   eax,eax
  4096d7:	jne    4096e2 <__swc_fn_7dafa2b1_000126_102fe7b9+0x72>
  4096d9:	mov    eax,DWORD PTR [rsp+0x8]
  4096dd:	inc    rax
  4096e0:	jmp    4096e4 <__swc_fn_7dafa2b1_000126_102fe7b9+0x74>
  4096e2:	xor    eax,eax
  4096e4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ea:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096f0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096f6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096fc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409702:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409708:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40970e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409717:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409720:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409729:	add    rsp,0xb8
  409730:	pop    rsi
  409731:	pop    rdi
  409732:	ret
	...

0000000000409740 <__swc_fn_7dafa2b1_000129_74b163fe>:
  409740:	push   rdi
  409741:	push   rsi
  409742:	sub    rsp,0xa8
  409749:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40974f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409755:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40975b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409761:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409767:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40976d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409773:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409779:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409782:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40978b:	test   rcx,rcx
  40978e:	setne  al
  409791:	je     4097aa <__swc_fn_7dafa2b1_000129_74b163fe+0x6a>
  409793:	lea    rax,[rcx-0x1]
  409797:	mov    eax,eax
  409799:	mov    edi,eax
  40979b:	mov    rsi,rdx
  40979e:	xor    eax,eax
  4097a0:	call   407060 <pthread_setspecific@plt>
  4097a5:	test   eax,eax
  4097a7:	sete   al
  4097aa:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4097b0:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4097b6:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4097bc:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097c2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097c8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ce:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097d4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097da:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097e3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097ec:	add    rsp,0xa8
  4097f3:	pop    rsi
  4097f4:	pop    rdi
  4097f5:	ret
	...

0000000000409800 <__swc_fn_7dafa2b1_000132_f908e7f9>:
  409800:	push   rdi
  409801:	push   rsi
  409802:	sub    rsp,0xa8
  409809:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40980f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409815:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40981b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409821:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409827:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40982d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409833:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409839:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409842:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40984b:	mov    rax,rdx
  40984e:	mov    QWORD PTR [rsp],0x0
  409856:	mov    edi,0xca
  40985b:	mov    rsi,rcx
  40985e:	mov    edx,0x81
  409863:	mov    eax,eax
  409865:	mov    ecx,eax
  409867:	xor    r8d,r8d
  40986a:	xor    r9d,r9d
  40986d:	xor    eax,eax
  40986f:	call   407070 <syscall@plt>
  409874:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40987a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409880:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409886:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40988c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409892:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409898:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40989e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4098a4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4098ad:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4098b6:	add    rsp,0xa8
  4098bd:	pop    rsi
  4098be:	pop    rdi
  4098bf:	ret

00000000004098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>:
  4098c0:	sub    rsp,0x8
  4098c4:	call   40cd70 <__swc_fn_7dafa2b1_000133_4b2af8da>
  4098c9:	add    rsp,0x8
  4098cd:	ret
	...

00000000004098d0 <__swc_fn_7dafa2b1_000138_0c00232f>:
  4098d0:	push   rdi
  4098d1:	push   rsi
  4098d2:	sub    rsp,0xc8
  4098d9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098df:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098e5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098eb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098f1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098f7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098fd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  409906:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40990f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  409918:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409921:	vxorps xmm0,xmm0,xmm0
  409925:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40992b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409931:	mov    rdi,rcx
  409934:	lea    rsi,[rsp+0x8]
  409939:	xor    eax,eax
  40993b:	call   407080 <dladdr@plt>
  409940:	xor    ecx,ecx
  409942:	test   eax,eax
  409944:	je     40994b <__swc_fn_7dafa2b1_000138_0c00232f+0x7b>
  409946:	mov    rcx,QWORD PTR [rsp+0x10]
  40994b:	mov    rax,rcx
  40994e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409954:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40995a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409960:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409966:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40996c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409972:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40997b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409984:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40998d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409996:	add    rsp,0xc8
  40999d:	pop    rsi
  40999e:	pop    rdi
  40999f:	ret

00000000004099a0 <__swc_fn_7dafa2b1_000141_2ce79e3b>:
  4099a0:	push   rbx
  4099a1:	push   r12
  4099a3:	push   r13
  4099a5:	push   rdi
  4099a6:	push   rsi
  4099a7:	push   r14
  4099a9:	push   r15
  4099ab:	sub    rsp,0x150
  4099b2:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  4099bb:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099c4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099cd:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099d6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099df:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099e8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099f1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099fa:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  409a03:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  409a0c:	mov    rbx,rdx
  409a0f:	mov    QWORD PTR [rsp+0x98],rdx
  409a17:	mov    r12,rcx
  409a1a:	mov    QWORD PTR [rsp+0xa0],rcx
  409a22:	mov    QWORD PTR [rbx],0x0
  409a29:	lea    r13,[rip+0x1c350]        # 425d80 <__swc_bss_base_7dafa2b1+0x2d40>
  409a30:	mov    rcx,r13
  409a33:	call   4098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>
  409a38:	mov    rax,QWORD PTR [rip+0x1c349]        # 425d88 <__swc_bss_base_7dafa2b1+0x2d48>
  409a3f:	test   rax,rax
  409a42:	je     409a79 <__swc_fn_7dafa2b1_000141_2ce79e3b+0xd9>
  409a44:	cs nop WORD PTR [rax+rax*1+0x0]
  409a4e:	xchg   ax,ax
  409a50:	cmp    QWORD PTR [rax+0x8],r12
  409a54:	jne    409a71 <__swc_fn_7dafa2b1_000141_2ce79e3b+0xd1>
  409a56:	mov    rcx,QWORD PTR [rax+0x18]
  409a5a:	mov    QWORD PTR [rbx],rcx
  409a5d:	mov    rbx,QWORD PTR [rax+0x10]
  409a61:	mov    rcx,r13
  409a64:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  409a69:	mov    rax,rbx
  409a6c:	jmp    409c5b <__swc_fn_7dafa2b1_000141_2ce79e3b+0x2bb>
  409a71:	mov    rax,QWORD PTR [rax]
  409a74:	test   rax,rax
  409a77:	jne    409a50 <__swc_fn_7dafa2b1_000141_2ce79e3b+0xb0>
  409a79:	vxorps xmm0,xmm0,xmm0
  409a7d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a83:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a89:	mov    rdi,r12
  409a8c:	lea    rsi,[rsp+0x10]
  409a91:	xor    eax,eax
  409a93:	call   407080 <dladdr@plt>
  409a98:	test   eax,eax
  409a9a:	sete   al
  409a9d:	je     409aaa <__swc_fn_7dafa2b1_000141_2ce79e3b+0x10a>
  409a9f:	mov    rax,QWORD PTR [rsp+0x10]
  409aa4:	test   rax,rax
  409aa7:	sete   al
  409aaa:	test   al,al
  409aac:	je     409abd <__swc_fn_7dafa2b1_000141_2ce79e3b+0x11d>
  409aae:	mov    rcx,r13
  409ab1:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  409ab6:	xor    eax,eax
  409ab8:	jmp    409c5b <__swc_fn_7dafa2b1_000141_2ce79e3b+0x2bb>
  409abd:	mov    rdi,QWORD PTR [rsp+0x10]
  409ac2:	mov    esi,0x80000
  409ac7:	xor    eax,eax
  409ac9:	call   407090 <open@plt>
  409ace:	lea    r14,[rsp+0x30]
  409ad3:	mov    DWORD PTR [rsp+0x30],eax
  409ad7:	cmp    DWORD PTR [r14],0x0
  409adb:	jge    409aec <__swc_fn_7dafa2b1_000141_2ce79e3b+0x14c>
  409add:	mov    rcx,r13
  409ae0:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  409ae5:	xor    eax,eax
  409ae7:	jmp    409c5b <__swc_fn_7dafa2b1_000141_2ce79e3b+0x2bb>
  409aec:	mov    rax,r14
  409aef:	movsxd rdi,DWORD PTR [rax]
  409af2:	xor    esi,esi
  409af4:	mov    edx,0x2
  409af9:	xor    eax,eax
  409afb:	call   4070a0 <lseek@plt>
  409b00:	mov    r15,rax
  409b03:	test   rax,rax
  409b06:	jg     409b21 <__swc_fn_7dafa2b1_000141_2ce79e3b+0x181>
  409b08:	movsxd rdi,DWORD PTR [r14]
  409b0b:	xor    eax,eax
  409b0d:	call   4070b0 <close@plt>
  409b12:	mov    rcx,r13
  409b15:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  409b1a:	xor    eax,eax
  409b1c:	jmp    409c5b <__swc_fn_7dafa2b1_000141_2ce79e3b+0x2bb>
  409b21:	xor    edi,edi
  409b23:	mov    rsi,r15
  409b26:	mov    edx,0x1
  409b2b:	mov    ecx,0x2
  409b30:	mov    rax,r14
  409b33:	movsxd r8,DWORD PTR [rax]
  409b36:	xor    r9d,r9d
  409b39:	xor    eax,eax
  409b3b:	call   4070c0 <mmap@plt>
  409b40:	mov    rbx,rax
  409b43:	test   rax,rax
  409b46:	sete   al
  409b49:	cmp    rbx,0xffffffffffffffff
  409b4d:	sete   cl
  409b50:	or     al,cl
  409b52:	je     409b6d <__swc_fn_7dafa2b1_000141_2ce79e3b+0x1cd>
  409b54:	movsxd rdi,DWORD PTR [r14]
  409b57:	xor    eax,eax
  409b59:	call   4070b0 <close@plt>
  409b5e:	mov    rcx,r13
  409b61:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  409b66:	xor    eax,eax
  409b68:	jmp    409c5b <__swc_fn_7dafa2b1_000141_2ce79e3b+0x2bb>
  409b6d:	lea    rax,[rsp+0x50]
  409b72:	mov    QWORD PTR [rax],0x0
  409b79:	mov    rcx,rbx
  409b7c:	mov    rdx,r15
  409b7f:	mov    r8,rax
  409b82:	call   410140 <__swc_fn_7dafa2b1_000140_c6b99a56>
  409b87:	mov    r12,rax
  409b8a:	test   rax,rax
  409b8d:	jne    409bb5 <__swc_fn_7dafa2b1_000141_2ce79e3b+0x215>
  409b8f:	mov    rdi,rbx
  409b92:	mov    rsi,r15
  409b95:	xor    eax,eax
  409b97:	call   407020 <munmap@plt>
  409b9c:	movsxd rdi,DWORD PTR [r14]
  409b9f:	xor    eax,eax
  409ba1:	call   4070b0 <close@plt>
  409ba6:	mov    rcx,r13
  409ba9:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  409bae:	xor    eax,eax
  409bb0:	jmp    409c5b <__swc_fn_7dafa2b1_000141_2ce79e3b+0x2bb>
  409bb5:	mov    edi,0x20
  409bba:	xor    eax,eax
  409bbc:	call   4070d0 <malloc@plt>
  409bc1:	test   rax,rax
  409bc4:	jne    409be9 <__swc_fn_7dafa2b1_000141_2ce79e3b+0x249>
  409bc6:	mov    rdi,rbx
  409bc9:	mov    rsi,r15
  409bcc:	xor    eax,eax
  409bce:	call   407020 <munmap@plt>
  409bd3:	movsxd rdi,DWORD PTR [r14]
  409bd6:	xor    eax,eax
  409bd8:	call   4070b0 <close@plt>
  409bdd:	mov    rcx,r13
  409be0:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  409be5:	xor    eax,eax
  409be7:	jmp    409c5b <__swc_fn_7dafa2b1_000141_2ce79e3b+0x2bb>
  409be9:	mov    rcx,QWORD PTR [rip+0x1c198]        # 425d88 <__swc_bss_base_7dafa2b1+0x2d48>
  409bf0:	mov    QWORD PTR [rsp+0x70],rcx
  409bf5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bfd:	mov    QWORD PTR [rsp+0x78],rcx
  409c02:	mov    QWORD PTR [rsp+0x80],r12
  409c0a:	mov    rcx,QWORD PTR [rsp+0x50]
  409c0f:	mov    QWORD PTR [rsp+0x88],rcx
  409c17:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409c1d:	vmovups XMMWORD PTR [rax],xmm0
  409c21:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c2a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c2f:	mov    QWORD PTR [rip+0x1c152],rax        # 425d88 <__swc_bss_base_7dafa2b1+0x2d48>
  409c36:	mov    rax,QWORD PTR [rsp+0x50]
  409c3b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c43:	mov    QWORD PTR [rbx],rax
  409c46:	movsxd rdi,DWORD PTR [r14]
  409c49:	xor    eax,eax
  409c4b:	call   4070b0 <close@plt>
  409c50:	mov    rcx,r13
  409c53:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  409c58:	mov    rax,r12
  409c5b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c64:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c6d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c76:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c7f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c88:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c91:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c9a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409ca3:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409cac:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409cb5:	add    rsp,0x150
  409cbc:	pop    r15
  409cbe:	pop    r14
  409cc0:	pop    rsi
  409cc1:	pop    rdi
  409cc2:	pop    r13
  409cc4:	pop    r12
  409cc6:	pop    rbx
  409cc7:	ret
	...

0000000000409cd0 <__swc_fn_7dafa2b1_000144_72996a5b>:
  409cd0:	push   rbx
  409cd1:	sub    rsp,0xe0
  409cd8:	lea    rbx,[rsp+0x8]
  409cdd:	vxorps xmm0,xmm0,xmm0
  409ce1:	vmovups XMMWORD PTR [rbx],xmm0
  409ce5:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409cea:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409cef:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  409cf4:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  409cf9:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  409cfe:	mov    DWORD PTR [rbx+0x60],0x0
  409d05:	mov    r8,rbx
  409d08:	nop    DWORD PTR [rax+rax*1+0x0]
  409d10:	mov    r9,rcx
  409d13:	movabs rcx,0xcccccccccccccccd
  409d1d:	mov    rax,r9
  409d20:	mul    rcx
  409d23:	mov    r10,rdx
  409d26:	shr    r10,0x3
  409d2a:	mov    rcx,r10
  409d2d:	imul   rdx,r10,0xa
  409d31:	sub    r9,rdx
  409d34:	mov    rdx,QWORD PTR [rip+0x8805]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  409d3b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d40:	mov    BYTE PTR [r8],dl
  409d43:	lea    rdx,[r8+0x1]
  409d47:	mov    r8,rdx
  409d4a:	test   r10,r10
  409d4d:	jne    409d10 <__swc_fn_7dafa2b1_000144_72996a5b+0x40>
  409d4f:	mov    BYTE PTR [rdx],0x0
  409d52:	sub    r8,0x1
  409d56:	mov    rax,rbx
  409d59:	cmp    rax,r8
  409d5c:	jae    409d76 <__swc_fn_7dafa2b1_000144_72996a5b+0xa6>
  409d5e:	xchg   ax,ax
  409d60:	mov    cl,BYTE PTR [r8]
  409d63:	mov    dl,BYTE PTR [rax]
  409d65:	mov    BYTE PTR [r8],dl
  409d68:	sub    r8,0x1
  409d6c:	mov    BYTE PTR [rax],cl
  409d6e:	inc    rax
  409d71:	cmp    rax,r8
  409d74:	jb     409d60 <__swc_fn_7dafa2b1_000144_72996a5b+0x90>
  409d76:	xor    eax,eax
  409d78:	test   rbx,rbx
  409d7b:	je     409d9e <__swc_fn_7dafa2b1_000144_72996a5b+0xce>
  409d7d:	mov    rcx,rbx
  409d80:	mov    dl,BYTE PTR [rcx]
  409d82:	test   dl,dl
  409d84:	je     409d9e <__swc_fn_7dafa2b1_000144_72996a5b+0xce>
  409d86:	cs nop WORD PTR [rax+rax*1+0x0]
  409d90:	add    rcx,0x1
  409d94:	add    rax,0x1
  409d98:	mov    dl,BYTE PTR [rcx]
  409d9a:	test   dl,dl
  409d9c:	jne    409d90 <__swc_fn_7dafa2b1_000144_72996a5b+0xc0>
  409d9e:	mov    QWORD PTR [rbx+0xa8],rbx
  409da5:	mov    QWORD PTR [rbx+0xb0],rax
  409dac:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409db4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409dbc:	lea    rcx,[rbx+0xb8]
  409dc3:	call   40fba0 <__swc_fn_7dafa2b1_000116_035d76a1>
  409dc8:	add    rsp,0xe0
  409dcf:	pop    rbx
  409dd0:	ret
	...

0000000000409de0 <__swc_fn_7dafa2b1_000147_32a497f3>:
  409de0:	sub    rsp,0x8
  409de4:	mov    rax,QWORD PTR [rcx+0x8]
  409de8:	mov    r8,QWORD PTR [rdx+0x8]
  409dec:	cmp    rax,r8
  409def:	je     409df8 <__swc_fn_7dafa2b1_000147_32a497f3+0x18>
  409df1:	xor    eax,eax
  409df3:	add    rsp,0x8
  409df7:	ret
  409df8:	test   rax,rax
  409dfb:	jne    409e0c <__swc_fn_7dafa2b1_000147_32a497f3+0x2c>
  409dfd:	test   r8,r8
  409e00:	jne    409e0c <__swc_fn_7dafa2b1_000147_32a497f3+0x2c>
  409e02:	mov    eax,0x1
  409e07:	add    rsp,0x8
  409e0b:	ret
  409e0c:	mov    rcx,QWORD PTR [rcx]
  409e0f:	mov    rdx,QWORD PTR [rdx]
  409e12:	test   rcx,rcx
  409e15:	sete   r8b
  409e19:	test   rdx,rdx
  409e1c:	sete   r9b
  409e20:	or     r8b,r9b
  409e23:	je     409e30 <__swc_fn_7dafa2b1_000147_32a497f3+0x50>
  409e25:	cmp    rcx,rdx
  409e28:	sete   al
  409e2b:	add    rsp,0x8
  409e2f:	ret
  409e30:	cmp    rcx,rdx
  409e33:	jne    409e3f <__swc_fn_7dafa2b1_000147_32a497f3+0x5f>
  409e35:	mov    eax,0x1
  409e3a:	add    rsp,0x8
  409e3e:	ret
  409e3f:	mov    r8,rax
  409e42:	call   40c460 <__swc_fn_7dafa2b1_000106_ed4b1681>
  409e47:	test   eax,eax
  409e49:	sete   al
  409e4c:	add    rsp,0x8
  409e50:	ret
	...

0000000000409e60 <__swc_fn_7dafa2b1_000150_9e4bc402>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x877a]        # 4125f8 <__swc_rdata_base_7dafa2b1+0x4e8>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	ret
	...

0000000000409e90 <__swc_fn_7dafa2b1_000153_9e4bc402>:
  409e90:	vxorps xmm0,xmm0,xmm0
  409e94:	vmovups XMMWORD PTR [rcx],xmm0
  409e98:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e9d:	vxorps xmm0,xmm0,xmm0
  409ea1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409ea6:	vmovups xmm0,XMMWORD PTR [rip+0x886a]        # 412718 <__swc_rdata_base_7dafa2b1+0x608>
  409eae:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409eb3:	mov    QWORD PTR [rcx+0x40],0x0
  409ebb:	ret
  409ebc:	add    BYTE PTR [rax],al
	...

0000000000409ec0 <__swc_fn_7dafa2b1_000156_2745c4a5>:
  409ec0:	push   rbx
  409ec1:	sub    rsp,0x70
  409ec5:	mov    rax,QWORD PTR [rcx]
  409ec8:	mov    rbx,QWORD PTR [rcx+0x8]
  409ecc:	vxorps xmm0,xmm0,xmm0
  409ed0:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409ed6:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409edc:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409ee2:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  409ee8:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eee:	mov    QWORD PTR [rsp+0x48],rdx
  409ef3:	mov    QWORD PTR [rsp+0x50],r8
  409ef8:	mov    rcx,rax
  409efb:	lea    rdx,[rsp+0x8]
  409f00:	mov    rbx,QWORD PTR [rbx+0x18]
  409f04:	call   rbx
  409f06:	add    rsp,0x70
  409f0a:	pop    rbx
  409f0b:	ret
  409f0c:	add    BYTE PTR [rax],al
	...

0000000000409f10 <__swc_fn_7dafa2b1_000159_d8afac28>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	mov    rbx,r8
  409f16:	mov    rsi,rcx
  409f19:	mov    rdi,rdx
  409f1c:	call   40d180 <__swc_fn_7dafa2b1_000157_232ffa22>
  409f21:	vmovups xmm0,XMMWORD PTR [rbx]
  409f25:	vmovups XMMWORD PTR [rsi],xmm0
  409f29:	mov    QWORD PTR [rsi+0x18],rdi
  409f2d:	pop    rdi
  409f2e:	pop    rsi
  409f2f:	pop    rbx
  409f30:	ret
	...

0000000000409f40 <__swc_fn_7dafa2b1_000162_60216e69>:
  409f40:	push   rbx
  409f41:	push   rsi
  409f42:	push   rdi
  409f43:	push   r12
  409f45:	push   r13
  409f47:	sub    rsp,0x50
  409f4b:	mov    rbx,rcx
  409f4e:	mov    rsi,rdx
  409f51:	vmovups xmm0,XMMWORD PTR [rip+0x88cf]        # 412828 <__swc_rdata_base_7dafa2b1+0x718>
  409f59:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f5f:	vmovups xmm0,XMMWORD PTR [rip+0x88d1]        # 412838 <__swc_rdata_base_7dafa2b1+0x728>
  409f67:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f6d:	vxorps xmm0,xmm0,xmm0
  409f71:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f77:	mov    rcx,rdx
  409f7a:	call   4098d0 <__swc_fn_7dafa2b1_000138_0c00232f>
  409f7f:	mov    rdi,rax
  409f82:	test   rax,rax
  409f85:	jne    409fb6 <__swc_fn_7dafa2b1_000162_60216e69+0x76>
  409f87:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f8d:	vmovups XMMWORD PTR [rbx],xmm0
  409f91:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f97:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f9c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fa2:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fa7:	mov    rax,rbx
  409faa:	add    rsp,0x50
  409fae:	pop    r13
  409fb0:	pop    r12
  409fb2:	pop    rdi
  409fb3:	pop    rsi
  409fb4:	pop    rbx
  409fb5:	ret
  409fb6:	mov    rcx,rdi
  409fb9:	call   4116a0 <__swc_fn_7dafa2b1_000161_b5a9d657>
  409fbe:	mov    r11,rax
  409fc1:	test   rax,rax
  409fc4:	je     409fce <__swc_fn_7dafa2b1_000162_60216e69+0x8e>
  409fc6:	mov    al,BYTE PTR [r11+0x24]
  409fca:	test   al,al
  409fcc:	jne    409ffd <__swc_fn_7dafa2b1_000162_60216e69+0xbd>
  409fce:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fd4:	vmovups XMMWORD PTR [rbx],xmm0
  409fd8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fde:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fe3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fe9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fee:	mov    rax,rbx
  409ff1:	add    rsp,0x50
  409ff5:	pop    r13
  409ff7:	pop    r12
  409ff9:	pop    rdi
  409ffa:	pop    rsi
  409ffb:	pop    rbx
  409ffc:	ret
  409ffd:	sub    rsi,rdi
  40a000:	mov    eax,0xffffffff
  40a005:	cmp    rsi,rax
  40a008:	jbe    40a039 <__swc_fn_7dafa2b1_000162_60216e69+0xf9>
  40a00a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a010:	vmovups XMMWORD PTR [rbx],xmm0
  40a014:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a01a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a01f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a025:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a02a:	mov    rax,rbx
  40a02d:	add    rsp,0x50
  40a031:	pop    r13
  40a033:	pop    r12
  40a035:	pop    rdi
  40a036:	pop    rsi
  40a037:	pop    rbx
  40a038:	ret
  40a039:	mov    rdi,QWORD PTR [r11+0x10]
  40a03d:	mov    eax,DWORD PTR [r11+0x20]
  40a041:	xor    ecx,ecx
  40a043:	test   rax,rax
  40a046:	jbe    40a198 <__swc_fn_7dafa2b1_000162_60216e69+0x258>
  40a04c:	nop    DWORD PTR [rax+0x0]
  40a050:	mov    edx,ecx
  40a052:	imul   r12,rdx,0x14
  40a056:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a05b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a060:	mov    r9d,esi
  40a063:	cmp    r9,rdx
  40a066:	jb     40a18b <__swc_fn_7dafa2b1_000162_60216e69+0x24b>
  40a06c:	add    rdx,r8
  40a06f:	mov    r8d,esi
  40a072:	cmp    r8,rdx
  40a075:	jae    40a18b <__swc_fn_7dafa2b1_000162_60216e69+0x24b>
  40a07b:	lea    rsi,[rsp+0x38]
  40a080:	mov    eax,DWORD PTR [rdi+0xc]
  40a083:	mov    DWORD PTR [rsp+0x38],eax
  40a087:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a08c:	mov    rcx,rdi
  40a08f:	mov    rdx,QWORD PTR [r11+0x18]
  40a093:	mov    r8,rsi
  40a096:	mov    r8d,DWORD PTR [r8]
  40a099:	mov    r9,rax
  40a09c:	lea    r10,[rsp+0x10]
  40a0a1:	call   40d1e0 <__swc_fn_7dafa2b1_000160_01cbb887>
  40a0a6:	test   al,al
  40a0a8:	jne    40a0db <__swc_fn_7dafa2b1_000162_60216e69+0x19b>
  40a0aa:	vmovups xmm0,XMMWORD PTR [rip+0x87a6]        # 412858 <__swc_rdata_base_7dafa2b1+0x748>
  40a0b2:	vmovups XMMWORD PTR [rbx],xmm0
  40a0b6:	vmovups xmm0,XMMWORD PTR [rip+0x87aa]        # 412868 <__swc_rdata_base_7dafa2b1+0x758>
  40a0be:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0c3:	vxorps xmm0,xmm0,xmm0
  40a0c7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0cc:	mov    rax,rbx
  40a0cf:	add    rsp,0x50
  40a0d3:	pop    r13
  40a0d5:	pop    r12
  40a0d7:	pop    rdi
  40a0d8:	pop    rsi
  40a0d9:	pop    rbx
  40a0da:	ret
  40a0db:	lea    r13,[rsp+0x3c]
  40a0e0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0e5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0e9:	test   eax,eax
  40a0eb:	je     40a13c <__swc_fn_7dafa2b1_000162_60216e69+0x1fc>
  40a0ed:	mov    rcx,rdi
  40a0f0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0f4:	mov    r8d,DWORD PTR [rsi]
  40a0f7:	mov    rax,r13
  40a0fa:	mov    r9d,DWORD PTR [rax]
  40a0fd:	lea    r10,[rsp+0x20]
  40a102:	call   40d1e0 <__swc_fn_7dafa2b1_000160_01cbb887>
  40a107:	test   al,al
  40a109:	jne    40a13c <__swc_fn_7dafa2b1_000162_60216e69+0x1fc>
  40a10b:	vmovups xmm0,XMMWORD PTR [rip+0x8775]        # 412888 <__swc_rdata_base_7dafa2b1+0x778>
  40a113:	vmovups XMMWORD PTR [rbx],xmm0
  40a117:	vmovups xmm0,XMMWORD PTR [rip+0x8779]        # 412898 <__swc_rdata_base_7dafa2b1+0x788>
  40a11f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a124:	vxorps xmm0,xmm0,xmm0
  40a128:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a12d:	mov    rax,rbx
  40a130:	add    rsp,0x50
  40a134:	pop    r13
  40a136:	pop    r12
  40a138:	pop    rdi
  40a139:	pop    rsi
  40a13a:	pop    rbx
  40a13b:	ret
  40a13c:	mov    eax,0x1
  40a141:	rex mov BYTE PTR [rsp+0x8],al
  40a146:	cmp    DWORD PTR [r13+0x0],0x0
  40a14b:	je     40a15c <__swc_fn_7dafa2b1_000162_60216e69+0x21c>
  40a14d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a153:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a158:	mov    DWORD PTR [rsp+0x30],eax
  40a15c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a162:	vmovups XMMWORD PTR [rbx],xmm0
  40a166:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a16c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a171:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a177:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a17c:	mov    rax,rbx
  40a17f:	add    rsp,0x50
  40a183:	pop    r13
  40a185:	pop    r12
  40a187:	pop    rdi
  40a188:	pop    rsi
  40a189:	pop    rbx
  40a18a:	ret
  40a18b:	add    rcx,0x1
  40a18f:	cmp    rcx,rax
  40a192:	jb     40a050 <__swc_fn_7dafa2b1_000162_60216e69+0x110>
  40a198:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a19e:	vmovups XMMWORD PTR [rbx],xmm0
  40a1a2:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a1a8:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a1ad:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a1b3:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a1b8:	mov    rax,rbx
  40a1bb:	add    rsp,0x50
  40a1bf:	pop    r13
  40a1c1:	pop    r12
  40a1c3:	pop    rdi
  40a1c4:	pop    rsi
  40a1c5:	pop    rbx
  40a1c6:	ret
	...

000000000040a1d0 <__swc_fn_7dafa2b1_000165_cf398896>:
  40a1d0:	sub    rsp,0x48
  40a1d4:	call   4095a0 <__swc_fn_7dafa2b1_000123_9d2cbd72>
  40a1d9:	cmp    rax,0xffffffffffffffff
  40a1dd:	je     40a1e4 <__swc_fn_7dafa2b1_000165_cf398896+0x14>
  40a1df:	add    rsp,0x48
  40a1e3:	ret
  40a1e4:	lea    rcx,[rip+0x86dd]        # 4128c8 <__swc_rdata_base_7dafa2b1+0x7b8>
  40a1eb:	vmovups xmm0,XMMWORD PTR [rip+0x86e5]        # 4128d8 <__swc_rdata_base_7dafa2b1+0x7c8>
  40a1f3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1f9:	vmovups xmm0,XMMWORD PTR [rip+0x86e7]        # 4128e8 <__swc_rdata_base_7dafa2b1+0x7d8>
  40a201:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a207:	vmovups xmm0,XMMWORD PTR [rip+0x86e9]        # 4128f8 <__swc_rdata_base_7dafa2b1+0x7e8>
  40a20f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a215:	lea    rdx,[rsp+0x8]
  40a21a:	mov    QWORD PTR [rsp+0x38],rax
  40a21f:	call   40c3a0 <__swc_fn_7dafa2b1_000103_67100064>
  40a224:	mov    rax,QWORD PTR [rsp+0x38]
  40a229:	jmp    40a1df <__swc_fn_7dafa2b1_000165_cf398896+0xf>
  40a22b:	add    BYTE PTR [rax],al
  40a22d:	add    BYTE PTR [rax],al
	...

000000000040a230 <__swc_fn_7dafa2b1_000168_92b7d63c>:
  40a230:	push   rbx
  40a231:	push   rsi
  40a232:	sub    rsp,0x28
  40a236:	mov    rbx,rcx
  40a239:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a241:	mov    ecx,0xbf0
  40a246:	call   40bf90 <__swc_fn_7dafa2b1_000079_34776ded>
  40a24b:	mov    rsi,rax
  40a24e:	test   rax,rax
  40a251:	jne    40a25c <__swc_fn_7dafa2b1_000168_92b7d63c+0x2c>
  40a253:	xor    eax,eax
  40a255:	add    rsp,0x28
  40a259:	pop    rsi
  40a25a:	pop    rbx
  40a25b:	ret
  40a25c:	vxorps xmm0,xmm0,xmm0
  40a260:	xor    eax,eax
  40a262:	cs nop WORD PTR [rax+rax*1+0x0]
  40a26c:	nop    DWORD PTR [rax+0x0]
  40a270:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a275:	add    rax,0x10
  40a279:	cmp    rax,0xbf0
  40a280:	jne    40a270 <__swc_fn_7dafa2b1_000168_92b7d63c+0x40>
  40a282:	lea    rax,[rbx+0x1]
  40a286:	mov    QWORD PTR [rsi+0x9c0],rax
  40a28d:	mov    rcx,rbx
  40a290:	mov    rdx,rsi
  40a293:	call   40d540 <__swc_fn_7dafa2b1_000166_f6173642>
  40a298:	test   al,al
  40a29a:	jne    40a2ad <__swc_fn_7dafa2b1_000168_92b7d63c+0x7d>
  40a29c:	mov    rcx,rsi
  40a29f:	call   40eaf0 <__swc_fn_7dafa2b1_000080_c1514492>
  40a2a4:	xor    eax,eax
  40a2a6:	add    rsp,0x28
  40a2aa:	pop    rsi
  40a2ab:	pop    rbx
  40a2ac:	ret
  40a2ad:	lea    rcx,[rsp+0x18]
  40a2b2:	call   40f070 <__swc_fn_7dafa2b1_000092_8252f8c0>
  40a2b7:	mov    rax,rsi
  40a2ba:	add    rsp,0x28
  40a2be:	pop    rsi
  40a2bf:	pop    rbx
  40a2c0:	ret
	...

000000000040a2d0 <__swc_fn_7dafa2b1_000171_c0e8acb1>:
  40a2d0:	xor    eax,eax
  40a2d2:	mov    edx,0x1
  40a2d7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2dc:	test   rax,rax
  40a2df:	jne    40a2e2 <__swc_fn_7dafa2b1_000171_c0e8acb1+0x12>
  40a2e1:	ret
  40a2e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2ec:	nop    DWORD PTR [rax+0x0]
  40a2f0:	mov    rax,QWORD PTR [rcx]
  40a2f3:	test   rax,rax
  40a2f6:	je     40a2d0 <__swc_fn_7dafa2b1_000171_c0e8acb1>
  40a2f8:	jmp    40a2f0 <__swc_fn_7dafa2b1_000171_c0e8acb1+0x20>
  40a2fa:	add    BYTE PTR [rax],al
  40a2fc:	add    BYTE PTR [rax],al
	...

000000000040a300 <__swc_fn_7dafa2b1_000174_176517f9>:
  40a300:	push   rsi
  40a301:	push   rdi
  40a302:	sub    rsp,0x38
  40a306:	mov    rsi,rcx
  40a309:	call   40d550 <__swc_fn_7dafa2b1_000169_4579a84c>
  40a30e:	mov    rdi,rax
  40a311:	call   40ccc0 <__swc_fn_7dafa2b1_000130_c1196dfb>
  40a316:	mov    r8,rax
  40a319:	mov    rcx,rdi
  40a31c:	call   40a2d0 <__swc_fn_7dafa2b1_000171_c0e8acb1>
  40a321:	mov    rax,QWORD PTR [rdi+0x8]
  40a325:	test   rax,rax
  40a328:	je     40a365 <__swc_fn_7dafa2b1_000174_176517f9+0x65>
  40a32a:	nop    WORD PTR [rax+rax*1+0x0]
  40a330:	cmp    rax,rsi
  40a333:	je     40a365 <__swc_fn_7dafa2b1_000174_176517f9+0x65>
  40a335:	mov    r9,QWORD PTR [rax]
  40a338:	cmp    QWORD PTR [rax+0x20],r8
  40a33c:	jne    40a35d <__swc_fn_7dafa2b1_000174_176517f9+0x5d>
  40a33e:	mov    rcx,rdi
  40a341:	mov    rdx,rax
  40a344:	mov    QWORD PTR [rsp+0x28],r8
  40a349:	mov    QWORD PTR [rsp+0x30],r9
  40a34e:	call   411ac0 <__swc_fn_7dafa2b1_000173_f69b1f05>
  40a353:	mov    r8,QWORD PTR [rsp+0x28]
  40a358:	mov    r9,QWORD PTR [rsp+0x30]
  40a35d:	mov    rax,r9
  40a360:	test   r9,r9
  40a363:	jne    40a330 <__swc_fn_7dafa2b1_000174_176517f9+0x30>
  40a365:	xor    eax,eax
  40a367:	mov    QWORD PTR [rdi],rax
  40a36a:	add    rsp,0x38
  40a36e:	pop    rdi
  40a36f:	pop    rsi
  40a370:	ret
	...

000000000040a380 <__swc_fn_7dafa2b1_000177_6e6aee58>:
  40a380:	push   rbx
  40a381:	sub    rsp,0x80
  40a388:	mov    rax,rcx
  40a38b:	mov    rcx,QWORD PTR [rax]
  40a38e:	test   rcx,rcx
  40a391:	je     40a3b0 <__swc_fn_7dafa2b1_000177_6e6aee58+0x30>
  40a393:	mov    QWORD PTR [rsp+0x68],rax
  40a398:	call   40a380 <__swc_fn_7dafa2b1_000177_6e6aee58>
  40a39d:	mov    rax,QWORD PTR [rsp+0x68]
  40a3a2:	mov    rcx,QWORD PTR [rax+0x8]
  40a3a6:	call   40a380 <__swc_fn_7dafa2b1_000177_6e6aee58>
  40a3ab:	mov    rax,QWORD PTR [rsp+0x68]
  40a3b0:	test   rax,rax
  40a3b3:	je     40a422 <__swc_fn_7dafa2b1_000177_6e6aee58+0xa2>
  40a3b5:	lea    rbx,[rsp+0x8]
  40a3ba:	vxorps xmm0,xmm0,xmm0
  40a3be:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a3c4:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a3ca:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a3d0:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40a3d6:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40a3dc:	lea    rcx,[rax-0x10]
  40a3e0:	mov    QWORD PTR [rsp+0x48],rcx
  40a3e5:	mov    rax,QWORD PTR [rax-0x10]
  40a3e9:	mov    QWORD PTR [rsp+0x50],rax
  40a3ee:	mov    rcx,QWORD PTR [rip+0x1b94b]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40a3f5:	test   rcx,rcx
  40a3f8:	jne    40a40a <__swc_fn_7dafa2b1_000177_6e6aee58+0x8a>
  40a3fa:	call   40a1d0 <__swc_fn_7dafa2b1_000165_cf398896>
  40a3ff:	lea    rcx,[rax+0x1]
  40a403:	mov    QWORD PTR [rip+0x1b936],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40a40a:	dec    rcx
  40a40d:	call   4119a0 <__swc_fn_7dafa2b1_000167_fce60b2b>
  40a412:	mov    rcx,QWORD PTR [rax]
  40a415:	mov    rdx,rbx
  40a418:	mov    rbx,QWORD PTR [rax+0x8]
  40a41c:	mov    rbx,QWORD PTR [rbx+0x18]
  40a420:	call   rbx
  40a422:	add    rsp,0x80
  40a429:	pop    rbx
  40a42a:	ret
	...

000000000040a440 <__swc_fn_7dafa2b1_000001_46f18a51>:
  40a440:	vxorps xmm0,xmm0,xmm0
  40a444:	xor    eax,eax
  40a446:	cs nop WORD PTR [rax+rax*1+0x0]
  40a450:	cs nop WORD PTR [rax+rax*1+0x0]
  40a45a:	nop    WORD PTR [rax+rax*1+0x0]
  40a460:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a465:	add    rax,0x10
  40a469:	cmp    rax,0x2080
  40a470:	jne    40a460 <__swc_fn_7dafa2b1_000001_46f18a51+0x20>
  40a472:	ret
	...

000000000040a480 <__swc_fn_7dafa2b1_000004_1acc36a6>:
  40a480:	push   rsi
  40a481:	push   rdi
  40a482:	push   r12
  40a484:	push   r13
  40a486:	push   r14
  40a488:	mov    rsi,rcx
  40a48b:	mov    edi,r10d
  40a48e:	mov    r12,rcx
  40a491:	mov    r13,r9
  40a494:	mov    ecx,DWORD PTR [rdx+0x28]
  40a497:	shlx   r14d,r8d,ecx
  40a49c:	mov    rcx,rdx
  40a49f:	mov    edx,r8d
  40a4a2:	call   40d9c0 <__swc_fn_7dafa2b1_000011_6493fbbc>
  40a4a7:	mov    rcx,rax
  40a4aa:	mov    eax,DWORD PTR [r12+0x3c]
  40a4af:	xor    edx,edx
  40a4b1:	div    rdi
  40a4b4:	vxorps xmm0,xmm0,xmm0
  40a4b8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40a4bc:	mov    QWORD PTR [r12+0x60],0x0
  40a4c5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40a4ca:	mov    QWORD PTR [r12+0x10],rcx
  40a4cf:	imul   rax,rdi
  40a4d3:	lea    rdx,[rcx+rax*1]
  40a4d7:	mov    QWORD PTR [r12+0x18],rdx
  40a4dc:	mov    QWORD PTR [r12+0x20],rcx
  40a4e1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40a4e6:	mov    DWORD PTR [r12+0x28],0x0
  40a4ef:	mov    DWORD PTR [r12+0x68],0x0
  40a4f8:	mov    BYTE PTR [r12+0x39],r13b
  40a4fd:	mov    BYTE PTR [r12+0x3a],r14b
  40a502:	mov    BYTE PTR [r12+0x3b],0x1
  40a508:	mov    DWORD PTR [r12+0x6c],0x0
  40a511:	mov    rcx,r12
  40a514:	mov    edx,edi
  40a516:	call   40d920 <__swc_fn_7dafa2b1_000005_b2240b56>
  40a51b:	pop    r14
  40a51d:	pop    r13
  40a51f:	pop    r12
  40a521:	pop    rdi
  40a522:	pop    rsi
  40a523:	ret
	...

000000000040a530 <__swc_fn_7dafa2b1_000007_614a4804>:
  40a530:	mov    r8d,0x1
  40a536:	xor    eax,eax
  40a538:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40a53e:	test   eax,eax
  40a540:	jne    40a530 <__swc_fn_7dafa2b1_000007_614a4804>
  40a542:	ret
	...

000000000040a550 <__swc_fn_7dafa2b1_000010_395bb04b>:
  40a550:	lea    r8,[rcx+0x60]
  40a554:	mov    rax,QWORD PTR [r8]
  40a557:	mov    r9,rax
  40a55a:	nop    WORD PTR [rax+rax*1+0x0]
  40a560:	mov    QWORD PTR [rdx],r9
  40a563:	mov    rax,r9
  40a566:	lock cmpxchg QWORD PTR [r8],rdx
  40a56b:	cmp    rax,r9
  40a56e:	jne    40a5d7 <__swc_fn_7dafa2b1_000010_395bb04b+0x87>
  40a570:	mov    eax,DWORD PTR [rcx+0x6c]
  40a573:	test   eax,eax
  40a575:	je     40a5d6 <__swc_fn_7dafa2b1_000010_395bb04b+0x86>
  40a577:	lea    rdx,[rcx+0x70]
  40a57b:	mov    r9d,0x1
  40a581:	xor    eax,eax
  40a583:	lock cmpxchg DWORD PTR [rdx],r9d
  40a588:	test   eax,eax
  40a58a:	jne    40a5d6 <__swc_fn_7dafa2b1_000010_395bb04b+0x86>
  40a58c:	mov    rax,rcx
  40a58f:	and    rax,0xffffffffffc00000
  40a596:	mov    rax,QWORD PTR [rax+0x8]
  40a59a:	test   rax,rax
  40a59d:	jne    40a5a5 <__swc_fn_7dafa2b1_000010_395bb04b+0x55>
  40a59f:	xor    eax,eax
  40a5a1:	xchg   DWORD PTR [rdx],eax
  40a5a3:	jmp    40a5d6 <__swc_fn_7dafa2b1_000010_395bb04b+0x86>
  40a5a5:	lea    rdx,[rax+0x2a80]
  40a5ac:	mov    rax,QWORD PTR [rdx]
  40a5af:	mov    r8,rax
  40a5b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5bc:	nop    DWORD PTR [rax+0x0]
  40a5c0:	mov    QWORD PTR [rcx+0x78],r8
  40a5c4:	mov    rax,r8
  40a5c7:	lock cmpxchg QWORD PTR [rdx],rcx
  40a5cc:	cmp    rax,r8
  40a5cf:	je     40a5d6 <__swc_fn_7dafa2b1_000010_395bb04b+0x86>
  40a5d1:	mov    r8,rax
  40a5d4:	jmp    40a5c0 <__swc_fn_7dafa2b1_000010_395bb04b+0x70>
  40a5d6:	ret
  40a5d7:	mov    r9,rax
  40a5da:	jmp    40a560 <__swc_fn_7dafa2b1_000010_395bb04b+0x10>
	...

000000000040a5e0 <__swc_fn_7dafa2b1_000013_9ba72deb>:
  40a5e0:	push   rsi
  40a5e1:	push   rdi
  40a5e2:	push   r12
  40a5e4:	push   r13
  40a5e6:	push   r14
  40a5e8:	push   r15
  40a5ea:	push   rbx
  40a5eb:	sub    rsp,0x30
  40a5ef:	mov    QWORD PTR [rsp+0x18],r8
  40a5f4:	mov    rsi,rcx
  40a5f7:	mov    rdi,rdx
  40a5fa:	mov    rdx,QWORD PTR [rsi+0x40]
  40a5fe:	xchg   ax,ax
  40a600:	mov    rax,rdx
  40a603:	not    rax
  40a606:	and    rax,QWORD PTR [rsi+0x20]
  40a60a:	test   rax,rax
  40a60d:	jne    40a621 <__swc_fn_7dafa2b1_000013_9ba72deb+0x41>
  40a60f:	xor    eax,eax
  40a611:	add    rsp,0x30
  40a615:	pop    rbx
  40a616:	pop    r15
  40a618:	pop    r14
  40a61a:	pop    r13
  40a61c:	pop    r12
  40a61e:	pop    rdi
  40a61f:	pop    rsi
  40a620:	ret
  40a621:	xor    ecx,ecx
  40a623:	tzcnt  rcx,rax
  40a628:	lea    r12,[rsp+0x8]
  40a62d:	mov    DWORD PTR [rsp+0x8],ecx
  40a631:	mov    r13d,0x1
  40a637:	shl    r13,cl
  40a63a:	mov    rcx,rdx
  40a63d:	or     rcx,r13
  40a640:	mov    rax,rdx
  40a643:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40a649:	cmp    rax,rdx
  40a64c:	je     40a653 <__swc_fn_7dafa2b1_000013_9ba72deb+0x73>
  40a64e:	mov    rdx,rax
  40a651:	jmp    40a600 <__swc_fn_7dafa2b1_000013_9ba72deb+0x20>
  40a653:	mov    eax,DWORD PTR [r12]
  40a657:	shl    rax,0x4
  40a65b:	lea    r14,[rsi+rax*8+0x80]
  40a663:	mov    rcx,rsi
  40a666:	mov    rax,r12
  40a669:	mov    edx,DWORD PTR [rax]
  40a66b:	call   40d9c0 <__swc_fn_7dafa2b1_000011_6493fbbc>
  40a670:	mov    r15,rax
  40a673:	mov    rcx,rsi
  40a676:	mov    rdx,r13
  40a679:	call   40db20 <__swc_fn_7dafa2b1_000017_4df2d1a0>
  40a67e:	test   al,al
  40a680:	je     40a6b8 <__swc_fn_7dafa2b1_000013_9ba72deb+0xd8>
  40a682:	mov    ecx,DWORD PTR [r14+0x3c]
  40a686:	lea    rdx,[rip+0x189cb]        # 423058 <__swc_bss_base_7dafa2b1+0x18>
  40a68d:	mov    r8,QWORD PTR [rip+0x189c4]        # 423058 <__swc_bss_base_7dafa2b1+0x18>
  40a694:	cs nop WORD PTR [rax+rax*1+0x0]
  40a69e:	xchg   ax,ax
  40a6a0:	mov    r9,r8
  40a6a3:	sub    r9,rcx
  40a6a6:	mov    rax,r8
  40a6a9:	lock cmpxchg QWORD PTR [rdx],r9
  40a6ae:	cmp    rax,r8
  40a6b1:	je     40a719 <__swc_fn_7dafa2b1_000013_9ba72deb+0x139>
  40a6b3:	mov    r8,rax
  40a6b6:	jmp    40a6a0 <__swc_fn_7dafa2b1_000013_9ba72deb+0xc0>
  40a6b8:	mov    rcx,rsi
  40a6bb:	mov    rax,r12
  40a6be:	mov    edx,DWORD PTR [rax]
  40a6c0:	call   407450 <__swc_fn_7dafa2b1_000012_c7df5d22>
  40a6c5:	mov    rcx,r15
  40a6c8:	and    rcx,0xffffffffffff0000
  40a6cf:	lea    rcx,[rcx+0x10000]
  40a6d6:	mov    rbx,rax
  40a6d9:	cmp    rax,rcx
  40a6dc:	cmova  rbx,rcx
  40a6e0:	mov    rax,rbx
  40a6e3:	sub    rax,r15
  40a6e6:	mov    rcx,r15
  40a6e9:	mov    rdx,rax
  40a6ec:	call   4072a0 <__swc_fn_7dafa2b1_000003_7ab4792e>
  40a6f1:	test   al,al
  40a6f3:	jne    40a712 <__swc_fn_7dafa2b1_000013_9ba72deb+0x132>
  40a6f5:	mov    rcx,rsi
  40a6f8:	mov    rdx,r13
  40a6fb:	call   407600 <__swc_fn_7dafa2b1_000018_7d1e8a10>
  40a700:	xor    eax,eax
  40a702:	add    rsp,0x30
  40a706:	pop    rbx
  40a707:	pop    r15
  40a709:	pop    r14
  40a70b:	pop    r13
  40a70d:	pop    r12
  40a70f:	pop    rdi
  40a710:	pop    rsi
  40a711:	ret
  40a712:	sub    rbx,r15
  40a715:	mov    DWORD PTR [r14+0x3c],ebx
  40a719:	mov    rcx,r14
  40a71c:	mov    rdx,rsi
  40a71f:	mov    r8d,DWORD PTR [r12]
  40a723:	mov    r9d,edi
  40a726:	mov    rbx,QWORD PTR [rsp+0x18]
  40a72b:	mov    r10d,ebx
  40a72e:	call   40a480 <__swc_fn_7dafa2b1_000004_1acc36a6>
  40a733:	mov    rax,r14
  40a736:	add    rsp,0x30
  40a73a:	pop    rbx
  40a73b:	pop    r15
  40a73d:	pop    r14
  40a73f:	pop    r13
  40a741:	pop    r12
  40a743:	pop    rdi
  40a744:	pop    rsi
  40a745:	ret
	...

000000000040a750 <__swc_fn_7dafa2b1_000016_4b207b58>:
  40a750:	mov    r8,QWORD PTR [rcx+0x48]
  40a754:	cs nop WORD PTR [rax+rax*1+0x0]
  40a75e:	xchg   ax,ax
  40a760:	mov    r9,r8
  40a763:	or     r9,rdx
  40a766:	mov    rax,r8
  40a769:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40a76f:	cmp    rax,r8
  40a772:	jne    40a775 <__swc_fn_7dafa2b1_000016_4b207b58+0x25>
  40a774:	ret
  40a775:	mov    r8,rax
  40a778:	jmp    40a760 <__swc_fn_7dafa2b1_000016_4b207b58+0x10>
  40a77a:	add    BYTE PTR [rax],al
  40a77c:	add    BYTE PTR [rax],al
	...

000000000040a780 <__swc_fn_7dafa2b1_000019_2cc1532c>:
  40a780:	push   rsi
  40a781:	push   rdi
  40a782:	push   r12
  40a784:	mov    rsi,rcx
  40a787:	xor    edi,edi
  40a789:	lea    r12,[rip+0x188d8]        # 423068 <__swc_bss_base_7dafa2b1+0x28>
  40a790:	mov    eax,DWORD PTR [r12]
  40a794:	xor    ecx,ecx
  40a796:	test   rax,rax
  40a799:	jbe    40a7d4 <__swc_fn_7dafa2b1_000019_2cc1532c+0x54>
  40a79b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a7a0:	lea    rdx,[rip+0x188c9]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  40a7a7:	mov    r8d,ecx
  40a7aa:	lea    r8,[r8+r8*2]
  40a7ae:	lea    r8,[rdx+r8*8]
  40a7b2:	mov    rdx,QWORD PTR [r8+0x10]
  40a7b6:	add    rdx,0x400000
  40a7bd:	cmp    rdx,0x40000000
  40a7c4:	ja     40a7cb <__swc_fn_7dafa2b1_000019_2cc1532c+0x4b>
  40a7c6:	mov    rdi,r8
  40a7c9:	jmp    40a7d4 <__swc_fn_7dafa2b1_000019_2cc1532c+0x54>
  40a7cb:	add    rcx,0x1
  40a7cf:	cmp    rcx,rax
  40a7d2:	jb     40a7a0 <__swc_fn_7dafa2b1_000019_2cc1532c+0x20>
  40a7d4:	test   rdi,rdi
  40a7d7:	jne    40a863 <__swc_fn_7dafa2b1_000019_2cc1532c+0xe3>
  40a7dd:	cmp    DWORD PTR [r12],0x10
  40a7e2:	jae    40a84b <__swc_fn_7dafa2b1_000019_2cc1532c+0xcb>
  40a7e4:	mov    ecx,0x40400000
  40a7e9:	call   40d8e0 <__swc_fn_7dafa2b1_000002_884bb5c0>
  40a7ee:	test   rax,rax
  40a7f1:	je     40a84b <__swc_fn_7dafa2b1_000019_2cc1532c+0xcb>
  40a7f3:	lea    rcx,[rip+0x18876]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  40a7fa:	mov    edx,DWORD PTR [r12]
  40a7fe:	lea    rdx,[rdx+rdx*2]
  40a802:	lea    rdx,[rcx+rdx*8]
  40a806:	mov    QWORD PTR [rdx],rax
  40a809:	lea    rax,[rax+0x3fffff]
  40a810:	and    rax,0xffffffffffc00000
  40a817:	mov    QWORD PTR [rdx+0x8],rax
  40a81b:	mov    QWORD PTR [rdx+0x10],0x0
  40a823:	mov    edx,DWORD PTR [rip+0x1883f]        # 423068 <__swc_bss_base_7dafa2b1+0x28>
  40a829:	nop    DWORD PTR [rax+0x0]
  40a830:	lea    r9d,[rdx+0x1]
  40a834:	mov    rax,rdx
  40a837:	lock cmpxchg DWORD PTR [r12],r9d
  40a83d:	mov    r8d,eax
  40a840:	cmp    eax,edx
  40a842:	je     40a852 <__swc_fn_7dafa2b1_000019_2cc1532c+0xd2>
  40a844:	mov    rdx,r8
  40a847:	jmp    40a830 <__swc_fn_7dafa2b1_000019_2cc1532c+0xb0>
  40a849:	jmp    40a852 <__swc_fn_7dafa2b1_000019_2cc1532c+0xd2>
  40a84b:	xor    eax,eax
  40a84d:	pop    r12
  40a84f:	pop    rdi
  40a850:	pop    rsi
  40a851:	ret
  40a852:	mov    eax,DWORD PTR [rip+0x18810]        # 423068 <__swc_bss_base_7dafa2b1+0x28>
  40a858:	sub    eax,0x1
  40a85b:	lea    rdi,[rax+rax*2]
  40a85f:	lea    rdi,[rcx+rdi*8]
  40a863:	mov    r12,QWORD PTR [rdi+0x8]
  40a867:	add    r12,QWORD PTR [rdi+0x10]
  40a86b:	mov    rcx,r12
  40a86e:	mov    edx,0x3000
  40a873:	call   4072a0 <__swc_fn_7dafa2b1_000003_7ab4792e>
  40a878:	test   al,al
  40a87a:	jne    40a883 <__swc_fn_7dafa2b1_000019_2cc1532c+0x103>
  40a87c:	xor    eax,eax
  40a87e:	pop    r12
  40a880:	pop    rdi
  40a881:	pop    rsi
  40a882:	ret
  40a883:	vxorps xmm0,xmm0,xmm0
  40a887:	xor    eax,eax
  40a889:	cs nop WORD PTR [rax+rax*1+0x0]
  40a893:	cs nop WORD PTR [rax+rax*1+0x0]
  40a89d:	nop    DWORD PTR [rax]
  40a8a0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40a8a6:	add    rax,0x10
  40a8aa:	cmp    rax,0x3000
  40a8b1:	jne    40a8a0 <__swc_fn_7dafa2b1_000019_2cc1532c+0x120>
  40a8b3:	mov    DWORD PTR [r12+0x28],esi
  40a8b8:	mov    eax,0x40
  40a8bd:	mov    ecx,esi
  40a8bf:	shr    eax,cl
  40a8c1:	mov    DWORD PTR [r12+0x2c],eax
  40a8c6:	cmp    DWORD PTR [r12+0x2c],0x40
  40a8cc:	jb     40a8d7 <__swc_fn_7dafa2b1_000019_2cc1532c+0x157>
  40a8ce:	mov    rax,0xffffffffffffffff
  40a8d5:	jmp    40a8e7 <__swc_fn_7dafa2b1_000019_2cc1532c+0x167>
  40a8d7:	mov    eax,0x1
  40a8dc:	mov    ecx,DWORD PTR [r12+0x2c]
  40a8e1:	shl    rax,cl
  40a8e4:	dec    rax
  40a8e7:	mov    QWORD PTR [r12+0x20],rax
  40a8ec:	mov    DWORD PTR [r12],0x4e540001
  40a8f4:	mov    DWORD PTR [r12+0x4],0x53474d45
  40a8fd:	add    QWORD PTR [rdi+0x10],0x400000
  40a905:	mov    rax,r12
  40a908:	pop    r12
  40a90a:	pop    rdi
  40a90b:	pop    rsi
  40a90c:	ret
  40a90d:	add    BYTE PTR [rax],al
	...

000000000040a910 <__swc_fn_7dafa2b1_000022_3a2e2048>:
  40a910:	mov    eax,0x1
  40a915:	mov    edx,DWORD PTR [rip+0x1874d]        # 423068 <__swc_bss_base_7dafa2b1+0x28>
  40a91b:	cmp    eax,edx
  40a91d:	jae    40a96b <__swc_fn_7dafa2b1_000022_3a2e2048+0x5b>
  40a91f:	nop
  40a920:	lea    r8,[rip+0x18749]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  40a927:	lea    r9,[rax+rax*2]
  40a92b:	lea    r9,[r8+r9*8]
  40a92f:	mov    r8,rcx
  40a932:	sub    r8,QWORD PTR [r9+0x8]
  40a936:	mov    r9,QWORD PTR [r9+0x10]
  40a93a:	cmp    r8,r9
  40a93d:	jae    40a965 <__swc_fn_7dafa2b1_000022_3a2e2048+0x55>
  40a93f:	mov    rax,rcx
  40a942:	and    rax,0xffffffffffc00000
  40a949:	shr    rcx,0x10
  40a94d:	and    ecx,0x3f
  40a950:	mov    edx,DWORD PTR [rax+0x28]
  40a953:	shrx   ecx,ecx,edx
  40a958:	shl    rcx,0x4
  40a95c:	lea    rax,[rax+rcx*8+0x80]
  40a964:	ret
  40a965:	inc    eax
  40a967:	cmp    eax,edx
  40a969:	jb     40a920 <__swc_fn_7dafa2b1_000022_3a2e2048+0x10>
  40a96b:	xor    eax,eax
  40a96d:	ret
	...

000000000040a970 <__swc_fn_7dafa2b1_000025_4aca8b9e>:
  40a970:	vxorps xmm0,xmm0,xmm0
  40a974:	vmovups XMMWORD PTR [rcx],xmm0
  40a978:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a97d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a982:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a987:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a98c:	mov    QWORD PTR [rcx+0x50],0x0
  40a994:	ret
	...

000000000040a9a0 <__swc_fn_7dafa2b1_000028_4aca8b9e>:
  40a9a0:	vxorps xmm0,xmm0,xmm0
  40a9a4:	xor    eax,eax
  40a9a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9b0:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9ba:	nop    WORD PTR [rax+rax*1+0x0]
  40a9c0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a9c5:	add    rax,0x10
  40a9c9:	cmp    rax,0x9b0
  40a9d0:	jne    40a9c0 <__swc_fn_7dafa2b1_000028_4aca8b9e+0x20>
  40a9d2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40a9dd:	ret
	...

000000000040a9e0 <__swc_fn_7dafa2b1_000031_90860ff2>:
  40a9e0:	push   rsi
  40a9e1:	push   rdi
  40a9e2:	sub    rsp,0x8
  40a9e6:	lea    rsi,[rip+0x1661b]        # 421008 <__swc_data_base_7dafa2b1+0x8>
  40a9ed:	mov    rax,QWORD PTR [rsi]
  40a9f0:	mov    ecx,0xffffffff
  40a9f5:	cmp    rax,rcx
  40a9f8:	je     40aa01 <__swc_fn_7dafa2b1_000031_90860ff2+0x21>
  40a9fa:	add    rsp,0x8
  40a9fe:	pop    rdi
  40a9ff:	pop    rsi
  40aa00:	ret
  40aa01:	mov    rcx,QWORD PTR [rip+0x7670]        # 412078 <__swc_fn_7dafa2b1_000179_1ca87929+0x4f8>
  40aa08:	call   409670 <__swc_fn_7dafa2b1_000126_102fe7b9>
  40aa0d:	mov    rcx,rax
  40aa10:	mov    eax,0xffffffff
  40aa15:	lock cmpxchg QWORD PTR [rsi],rcx
  40aa1a:	mov    rdi,rax
  40aa1d:	mov    eax,0xffffffff
  40aa22:	cmp    rdi,rax
  40aa25:	je     40aa36 <__swc_fn_7dafa2b1_000031_90860ff2+0x56>
  40aa27:	call   40cc10 <__swc_fn_7dafa2b1_000127_8dffa290>
  40aa2c:	mov    rax,rdi
  40aa2f:	add    rsp,0x8
  40aa33:	pop    rdi
  40aa34:	pop    rsi
  40aa35:	ret
  40aa36:	mov    rax,rcx
  40aa39:	add    rsp,0x8
  40aa3d:	pop    rdi
  40aa3e:	pop    rsi
  40aa3f:	ret

000000000040aa40 <__swc_fn_7dafa2b1_000034_25f19556>:
  40aa40:	sub    rsp,0x8
  40aa44:	vxorps xmm0,xmm0,xmm0
  40aa48:	xor    eax,eax
  40aa4a:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa54:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa5e:	xchg   ax,ax
  40aa60:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40aa65:	add    rax,0x10
  40aa69:	cmp    rax,0x2b00
  40aa70:	jne    40aa60 <__swc_fn_7dafa2b1_000034_25f19556+0x20>
  40aa72:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40aa7c:	xor    al,al
  40aa7e:	mov    rdx,rax
  40aa81:	xor    al,al
  40aa83:	mov    r8,rax
  40aa86:	xor    al,al
  40aa88:	mov    r9,rax
  40aa8b:	xor    al,al
  40aa8d:	mov    r10,rax
  40aa90:	xor    al,al
  40aa92:	mov    r11,rax
  40aa95:	call   40dd50 <__swc_fn_7dafa2b1_000035_95622a2b>
  40aa9a:	add    rsp,0x8
  40aa9e:	ret
	...

000000000040aaa0 <__swc_fn_7dafa2b1_000037_b4982903>:
  40aaa0:	push   rsi
  40aaa1:	push   rdi
  40aaa2:	push   r12
  40aaa4:	mov    rsi,r8
  40aaa7:	mov    rdi,rdx
  40aaaa:	mov    rcx,rdx
  40aaad:	call   40d8e0 <__swc_fn_7dafa2b1_000002_884bb5c0>
  40aab2:	mov    r12,rax
  40aab5:	test   rax,rax
  40aab8:	jne    40aac1 <__swc_fn_7dafa2b1_000037_b4982903+0x21>
  40aaba:	xor    eax,eax
  40aabc:	pop    r12
  40aabe:	pop    rdi
  40aabf:	pop    rsi
  40aac0:	ret
  40aac1:	mov    rcx,r12
  40aac4:	mov    rdx,rsi
  40aac7:	call   4072a0 <__swc_fn_7dafa2b1_000003_7ab4792e>
  40aacc:	test   al,al
  40aace:	jne    40aae2 <__swc_fn_7dafa2b1_000037_b4982903+0x42>
  40aad0:	mov    rcx,r12
  40aad3:	mov    rdx,rdi
  40aad6:	call   40fb80 <__swc_fn_7dafa2b1_000113_49b378a9>
  40aadb:	xor    eax,eax
  40aadd:	pop    r12
  40aadf:	pop    rdi
  40aae0:	pop    rsi
  40aae1:	ret
  40aae2:	mov    rax,r12
  40aae5:	pop    r12
  40aae7:	pop    rdi
  40aae8:	pop    rsi
  40aae9:	ret
	...

000000000040ab00 <__swc_fn_7dafa2b1_000040_6895916d>:
  40ab00:	push   rsi
  40ab01:	push   rdi
  40ab02:	push   r12
  40ab04:	mov    rsi,rcx
  40ab07:	mov    edx,0x9b8
  40ab0c:	call   40ddc0 <__swc_fn_7dafa2b1_000038_788ceb38>
  40ab11:	mov    rdi,rax
  40ab14:	test   rax,rax
  40ab17:	jne    40ab20 <__swc_fn_7dafa2b1_000040_6895916d+0x20>
  40ab19:	xor    eax,eax
  40ab1b:	pop    r12
  40ab1d:	pop    rdi
  40ab1e:	pop    rsi
  40ab1f:	ret
  40ab20:	vxorps xmm0,xmm0,xmm0
  40ab24:	xor    eax,eax
  40ab26:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab30:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ab40:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40ab45:	add    rax,0x10
  40ab49:	cmp    rax,0x9b0
  40ab50:	jne    40ab40 <__swc_fn_7dafa2b1_000040_6895916d+0x40>
  40ab52:	mov    QWORD PTR [rdi+0x9b0],0x0
  40ab5d:	mov    QWORD PTR [rdi],rsi
  40ab60:	call   40ccc0 <__swc_fn_7dafa2b1_000130_c1196dfb>
  40ab65:	mov    QWORD PTR [rdi+0x18],rax
  40ab69:	lea    r12,[rsi+0x10]
  40ab6d:	mov    rcx,r12
  40ab70:	call   4098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>
  40ab75:	mov    rax,QWORD PTR [rsi+0x20]
  40ab79:	mov    QWORD PTR [rdi+0x8],rax
  40ab7d:	mov    rax,QWORD PTR [rsi+0x20]
  40ab81:	test   rax,rax
  40ab84:	je     40ab8a <__swc_fn_7dafa2b1_000040_6895916d+0x8a>
  40ab86:	mov    QWORD PTR [rax+0x10],rdi
  40ab8a:	mov    QWORD PTR [rsi+0x20],rdi
  40ab8e:	mov    rcx,r12
  40ab91:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  40ab96:	mov    rax,rdi
  40ab99:	pop    r12
  40ab9b:	pop    rdi
  40ab9c:	pop    rsi
  40ab9d:	ret
	...

000000000040aba0 <__swc_fn_7dafa2b1_000043_957e4917>:
  40aba0:	mov    rax,QWORD PTR [rdx+0x10]
  40aba4:	test   rax,rax
  40aba7:	je     40abb3 <__swc_fn_7dafa2b1_000043_957e4917+0x13>
  40aba9:	mov    rcx,QWORD PTR [rdx+0x8]
  40abad:	mov    QWORD PTR [rax+0x8],rcx
  40abb1:	jmp    40abbb <__swc_fn_7dafa2b1_000043_957e4917+0x1b>
  40abb3:	mov    rax,QWORD PTR [rdx+0x8]
  40abb7:	mov    QWORD PTR [rcx+0x20],rax
  40abbb:	mov    rax,QWORD PTR [rdx+0x8]
  40abbf:	test   rax,rax
  40abc2:	je     40abcc <__swc_fn_7dafa2b1_000043_957e4917+0x2c>
  40abc4:	mov    rcx,QWORD PTR [rdx+0x10]
  40abc8:	mov    QWORD PTR [rax+0x10],rcx
  40abcc:	vxorps xmm0,xmm0,xmm0
  40abd0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40abd5:	ret
	...

000000000040abe0 <__swc_fn_7dafa2b1_000046_88f44774>:
  40abe0:	sub    rsp,0x8
  40abe4:	mov    r9,r8
  40abe7:	mov    r10,rdx
  40abea:	call   40de70 <__swc_fn_7dafa2b1_000044_9c2ade9b>
  40abef:	mov    eax,0x1
  40abf4:	xchg   DWORD PTR [r9+0x6c],eax
  40abf8:	mov    rax,QWORD PTR [r9+0x60]
  40abfc:	test   rax,rax
  40abff:	je     40ac43 <__swc_fn_7dafa2b1_000046_88f44774+0x63>
  40ac01:	xor    eax,eax
  40ac03:	xchg   DWORD PTR [r9+0x6c],eax
  40ac07:	movzx  eax,BYTE PTR [r9+0x39]
  40ac0c:	lea    rax,[rax+rax*4]
  40ac10:	lea    rax,[r10+rax*8+0x28]
  40ac15:	mov    QWORD PTR [r9+0x50],0x0
  40ac1d:	mov    rcx,QWORD PTR [rax+0x8]
  40ac21:	mov    QWORD PTR [r9+0x48],rcx
  40ac25:	mov    rcx,QWORD PTR [rax+0x8]
  40ac29:	test   rcx,rcx
  40ac2c:	je     40ac34 <__swc_fn_7dafa2b1_000046_88f44774+0x54>
  40ac2e:	mov    QWORD PTR [rcx+0x50],r9
  40ac32:	jmp    40ac38 <__swc_fn_7dafa2b1_000046_88f44774+0x58>
  40ac34:	mov    QWORD PTR [rax+0x10],r9
  40ac38:	mov    QWORD PTR [rax+0x8],r9
  40ac3c:	xor    eax,eax
  40ac3e:	add    rsp,0x8
  40ac42:	ret
  40ac43:	movzx  eax,BYTE PTR [r9+0x39]
  40ac48:	lea    rax,[rax+rax*4]
  40ac4c:	lea    rax,[r10+rax*8+0x28]
  40ac51:	mov    QWORD PTR [r9+0x50],0x0
  40ac59:	mov    rcx,QWORD PTR [rax+0x18]
  40ac5d:	mov    QWORD PTR [r9+0x48],rcx
  40ac61:	mov    rcx,QWORD PTR [rax+0x18]
  40ac65:	test   rcx,rcx
  40ac68:	je     40ac6e <__swc_fn_7dafa2b1_000046_88f44774+0x8e>
  40ac6a:	mov    QWORD PTR [rcx+0x50],r9
  40ac6e:	mov    QWORD PTR [rax+0x18],r9
  40ac72:	mov    eax,0x1
  40ac77:	add    rsp,0x8
  40ac7b:	ret
  40ac7c:	add    BYTE PTR [rax],al
	...

000000000040ac80 <__swc_fn_7dafa2b1_000049_2ff013cc>:
  40ac80:	push   r12
  40ac82:	push   r13
  40ac84:	push   rdi
  40ac85:	push   rsi
  40ac86:	push   r14
  40ac88:	push   r15
  40ac8a:	sub    rsp,0x178
  40ac91:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40ac9a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40aca3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40acac:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40acb5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40acbe:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40acc7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40acd0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40acd9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40ace2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40aceb:	mov    r12,rcx
  40acee:	lea    rax,[rip+0x1850b]        # 423200 <__swc_bss_base_7dafa2b1+0x1c0>
  40acf5:	mov    rcx,QWORD PTR [rax]
  40acf8:	mov    r13,rcx
  40acfb:	test   rcx,rcx
  40acfe:	jne    40ad0e <__swc_fn_7dafa2b1_000049_2ff013cc+0x8e>
  40ad00:	mov    r13d,0x1dcd6500
  40ad06:	mov    ecx,0x1dcd6500
  40ad0b:	xchg   QWORD PTR [rax],rcx
  40ad0e:	lea    rax,[rip+0x162eb]        # 421000 <__swc_data_base_7dafa2b1>
  40ad15:	mov    rax,QWORD PTR [rax]
  40ad18:	cmp    rax,0xffffffffffffffff
  40ad1c:	je     40ad2b <__swc_fn_7dafa2b1_000049_2ff013cc+0xab>
  40ad1e:	mov    eax,eax
  40ad20:	mov    edi,eax
  40ad22:	xor    eax,eax
  40ad24:	call   407000 <pthread_getspecific@plt>
  40ad29:	jmp    40ad2d <__swc_fn_7dafa2b1_000049_2ff013cc+0xad>
  40ad2b:	xor    eax,eax
  40ad2d:	test   rax,rax
  40ad30:	jne    40ad3f <__swc_fn_7dafa2b1_000049_2ff013cc+0xbf>
  40ad32:	call   40a9e0 <__swc_fn_7dafa2b1_000031_90860ff2>
  40ad37:	mov    rcx,rax
  40ad3a:	call   40fee0 <__swc_fn_7dafa2b1_000128_41c3251c>
  40ad3f:	test   rax,rax
  40ad42:	je     40ad54 <__swc_fn_7dafa2b1_000049_2ff013cc+0xd4>
  40ad44:	cmp    QWORD PTR [rax],r12
  40ad47:	jne    40ad54 <__swc_fn_7dafa2b1_000049_2ff013cc+0xd4>
  40ad49:	cmp    DWORD PTR [rax+0x20],0x0
  40ad4d:	jne    40ad54 <__swc_fn_7dafa2b1_000049_2ff013cc+0xd4>
  40ad4f:	mov    rsi,rax
  40ad52:	jmp    40ad56 <__swc_fn_7dafa2b1_000049_2ff013cc+0xd6>
  40ad54:	xor    esi,esi
  40ad56:	lea    rdi,[r12+0x2a88]
  40ad5e:	mov    r14,QWORD PTR [rdi]
  40ad61:	test   r14,r14
  40ad64:	jne    40adb3 <__swc_fn_7dafa2b1_000049_2ff013cc+0x133>
  40ad66:	lea    rax,[rip+0x182eb]        # 423058 <__swc_bss_base_7dafa2b1+0x18>
  40ad6d:	mov    rax,QWORD PTR [rax]
  40ad70:	test   rax,rax
  40ad73:	setne  al
  40ad76:	jne    40ad9a <__swc_fn_7dafa2b1_000049_2ff013cc+0x11a>
  40ad78:	mov    rax,QWORD PTR [r12+0x2a70]
  40ad80:	test   rax,rax
  40ad83:	setne  al
  40ad86:	jne    40ad9a <__swc_fn_7dafa2b1_000049_2ff013cc+0x11a>
  40ad88:	test   rsi,rsi
  40ad8b:	setne  al
  40ad8e:	je     40ad9a <__swc_fn_7dafa2b1_000049_2ff013cc+0x11a>
  40ad90:	cmp    DWORD PTR [rsi+0x730],0x0
  40ad97:	setne  al
  40ad9a:	test   al,al
  40ad9c:	je     40adae <__swc_fn_7dafa2b1_000049_2ff013cc+0x12e>
  40ad9e:	call   40ff90 <__swc_fn_7dafa2b1_000131_944f555b>
  40ada3:	lea    rcx,[rax+r13*1]
  40ada7:	xor    eax,eax
  40ada9:	lock cmpxchg QWORD PTR [rdi],rcx
  40adae:	jmp    40aeb3 <__swc_fn_7dafa2b1_000049_2ff013cc+0x233>
  40adb3:	call   40ff90 <__swc_fn_7dafa2b1_000131_944f555b>
  40adb8:	mov    r15,rax
  40adbb:	cmp    rax,r14
  40adbe:	jb     40adcf <__swc_fn_7dafa2b1_000049_2ff013cc+0x14f>
  40adc0:	xor    ecx,ecx
  40adc2:	mov    rax,r14
  40adc5:	lock cmpxchg QWORD PTR [rdi],rcx
  40adca:	cmp    rax,r14
  40adcd:	je     40add4 <__swc_fn_7dafa2b1_000049_2ff013cc+0x154>
  40adcf:	jmp    40aeb3 <__swc_fn_7dafa2b1_000049_2ff013cc+0x233>
  40add4:	test   rsi,rsi
  40add7:	je     40adf2 <__swc_fn_7dafa2b1_000049_2ff013cc+0x172>
  40add9:	cmp    r15,r13
  40addc:	jb     40adf2 <__swc_fn_7dafa2b1_000049_2ff013cc+0x172>
  40adde:	mov    rax,r15
  40ade1:	sub    rax,r13
  40ade4:	mov    rcx,r12
  40ade7:	mov    rdx,rsi
  40adea:	mov    r8,rax
  40aded:	call   40e2b0 <__swc_fn_7dafa2b1_000059_3ca3ac64>
  40adf2:	lea    rsi,[r12+0x10]
  40adf7:	mov    rcx,rsi
  40adfa:	call   4098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>
  40adff:	mov    rax,QWORD PTR [r12+0x18]
  40ae04:	mov    rdi,rax
  40ae07:	test   rdi,rdi
  40ae0a:	je     40ae34 <__swc_fn_7dafa2b1_000049_2ff013cc+0x1b4>
  40ae0c:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae16:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae20:	mov    rcx,rdi
  40ae23:	call   407470 <__swc_fn_7dafa2b1_000015_07eb9884>
  40ae28:	mov    rax,QWORD PTR [rdi+0x10]
  40ae2c:	mov    rdi,rax
  40ae2f:	test   rax,rax
  40ae32:	jne    40ae20 <__swc_fn_7dafa2b1_000049_2ff013cc+0x1a0>
  40ae34:	mov    rcx,rsi
  40ae37:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  40ae3c:	mov    rcx,r12
  40ae3f:	call   4098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>
  40ae44:	xor    esi,esi
  40ae46:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae50:	mov    rax,QWORD PTR [r12+0x2a70]
  40ae58:	cmp    rsi,rax
  40ae5b:	jae    40aeab <__swc_fn_7dafa2b1_000049_2ff013cc+0x22b>
  40ae5d:	lea    rax,[rsi+rsi*4]
  40ae61:	lea    rax,[r12+rax*8+0x268]
  40ae69:	mov    r8,QWORD PTR [rax]
  40ae6c:	mov    r9,QWORD PTR [rax+0x8]
  40ae70:	mov    r10,QWORD PTR [rax+0x10]
  40ae74:	mov    rax,QWORD PTR [rax+0x20]
  40ae78:	cmp    rax,r15
  40ae7b:	jae    40ae88 <__swc_fn_7dafa2b1_000049_2ff013cc+0x208>
  40ae7d:	mov    rcx,r15
  40ae80:	sub    rcx,rax
  40ae83:	cmp    rcx,r13
  40ae86:	jae    40ae8d <__swc_fn_7dafa2b1_000049_2ff013cc+0x20d>
  40ae88:	inc    rsi
  40ae8b:	jmp    40ae50 <__swc_fn_7dafa2b1_000049_2ff013cc+0x1d0>
  40ae8d:	mov    rcx,r12
  40ae90:	mov    rdx,rsi
  40ae93:	call   40e260 <__swc_fn_7dafa2b1_000056_38b21f11>
  40ae98:	mov    rcx,r12
  40ae9b:	mov    rdx,r8
  40ae9e:	mov    r8,r9
  40aea1:	mov    r9,r10
  40aea4:	call   407750 <__swc_fn_7dafa2b1_000039_40d1e569>
  40aea9:	jmp    40ae50 <__swc_fn_7dafa2b1_000049_2ff013cc+0x1d0>
  40aeab:	mov    rcx,r12
  40aeae:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  40aeb3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40aebc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40aec5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40aece:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40aed7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40aee0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40aee9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40aef2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40aefb:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40af04:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40af0d:	add    rsp,0x178
  40af14:	pop    r15
  40af16:	pop    r14
  40af18:	pop    rsi
  40af19:	pop    rdi
  40af1a:	pop    r13
  40af1c:	pop    r12
  40af1e:	ret
	...

000000000040af20 <__swc_fn_7dafa2b1_000052_c7484fb0>:
  40af20:	lea    rax,[rdx-0x58]
  40af24:	ret
	...

000000000040af30 <__swc_fn_7dafa2b1_000055_81f7713d>:
  40af30:	push   rsi
  40af31:	push   rdi
  40af32:	push   r12
  40af34:	push   r13
  40af36:	sub    rsp,0x68
  40af3a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40af40:	mov    rsi,r9
  40af43:	mov    rdi,rcx
  40af46:	mov    r12,rdx
  40af49:	mov    r13,r8
  40af4c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40af54:	jne    40af63 <__swc_fn_7dafa2b1_000055_81f7713d+0x33>
  40af56:	xor    eax,eax
  40af58:	add    rsp,0x68
  40af5c:	pop    r13
  40af5e:	pop    r12
  40af60:	pop    rdi
  40af61:	pop    rsi
  40af62:	ret
  40af63:	mov    rcx,rdi
  40af66:	call   4098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>
  40af6b:	movabs rax,0x7fffffffffffffff
  40af75:	cmp    r12,rax
  40af78:	mov    rax,0xffffffffffffffff
  40af7f:	lea    rcx,[r12+r12*1]
  40af83:	cmovbe rax,rcx
  40af87:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40af8e:	mov    rdx,rcx
  40af91:	sub    rax,r12
  40af94:	inc    rax
  40af97:	xor    r8d,r8d
  40af9a:	test   rcx,rcx
  40af9d:	jbe    40afc8 <__swc_fn_7dafa2b1_000055_81f7713d+0x98>
  40af9f:	nop
  40afa0:	lea    r9,[r8+r8*4]
  40afa4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40afac:	sub    r9,r12
  40afaf:	cmp    r9,rax
  40afb2:	jae    40afbf <__swc_fn_7dafa2b1_000055_81f7713d+0x8f>
  40afb4:	mov    rdx,r8
  40afb7:	mov    rax,r9
  40afba:	test   r9,r9
  40afbd:	je     40afc8 <__swc_fn_7dafa2b1_000055_81f7713d+0x98>
  40afbf:	add    r8,0x1
  40afc3:	cmp    r8,rcx
  40afc6:	jb     40afa0 <__swc_fn_7dafa2b1_000055_81f7713d+0x70>
  40afc8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40afcf:	cmp    rdx,rax
  40afd2:	jne    40afef <__swc_fn_7dafa2b1_000055_81f7713d+0xbf>
  40afd4:	mov    rcx,rdi
  40afd7:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  40afdc:	xor    eax,eax
  40afde:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40afe4:	add    rsp,0x68
  40afe8:	pop    r13
  40afea:	pop    r12
  40afec:	pop    rdi
  40afed:	pop    rsi
  40afee:	ret
  40afef:	lea    rax,[rdx+rdx*4]
  40aff3:	lea    rax,[rdi+rax*8+0x268]
  40affb:	vmovups xmm6,XMMWORD PTR [rax]
  40afff:	mov    r8,QWORD PTR [rax+0x10]
  40b003:	mov    rcx,rdi
  40b006:	call   40e260 <__swc_fn_7dafa2b1_000056_38b21f11>
  40b00b:	vpshufd xmm0,xmm6,0xee
  40b010:	vmovsd QWORD PTR [r13+0x0],xmm0
  40b016:	mov    QWORD PTR [rsi],r8
  40b019:	mov    rcx,rdi
  40b01c:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  40b021:	vmovq  rax,xmm6
  40b026:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b02c:	add    rsp,0x68
  40b030:	pop    r13
  40b032:	pop    r12
  40b034:	pop    rdi
  40b035:	pop    rsi
  40b036:	ret
	...

000000000040b040 <__swc_fn_7dafa2b1_000058_8bd8d1d5>:
  40b040:	push   r12
  40b042:	push   r13
  40b044:	push   r14
  40b046:	push   r15
  40b048:	push   rdi
  40b049:	push   rsi
  40b04a:	sub    rsp,0x148
  40b051:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b05a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b063:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b06c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b075:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b07e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b087:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b090:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b099:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b0a2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b0ab:	mov    r12,r9
  40b0ae:	mov    r13,rcx
  40b0b1:	mov    r14,rdx
  40b0b4:	mov    r15,r8
  40b0b7:	test   rdx,rdx
  40b0ba:	jne    40b0ce <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x8e>
  40b0bc:	add    rsp,0x148
  40b0c3:	pop    rsi
  40b0c4:	pop    rdi
  40b0c5:	pop    r15
  40b0c7:	pop    r14
  40b0c9:	pop    r13
  40b0cb:	pop    r12
  40b0cd:	ret
  40b0ce:	cmp    r12,0x200000
  40b0d5:	ja     40b167 <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x127>
  40b0db:	lea    rax,[rip+0x15f1e]        # 421000 <__swc_data_base_7dafa2b1>
  40b0e2:	mov    rax,QWORD PTR [rax]
  40b0e5:	cmp    rax,0xffffffffffffffff
  40b0e9:	je     40b0f8 <__swc_fn_7dafa2b1_000058_8bd8d1d5+0xb8>
  40b0eb:	mov    eax,eax
  40b0ed:	mov    edi,eax
  40b0ef:	xor    eax,eax
  40b0f1:	call   407000 <pthread_getspecific@plt>
  40b0f6:	jmp    40b0fa <__swc_fn_7dafa2b1_000058_8bd8d1d5+0xba>
  40b0f8:	xor    eax,eax
  40b0fa:	test   rax,rax
  40b0fd:	je     40b104 <__swc_fn_7dafa2b1_000058_8bd8d1d5+0xc4>
  40b0ff:	mov    rsi,rax
  40b102:	jmp    40b114 <__swc_fn_7dafa2b1_000058_8bd8d1d5+0xd4>
  40b104:	call   40a9e0 <__swc_fn_7dafa2b1_000031_90860ff2>
  40b109:	mov    rcx,rax
  40b10c:	call   40fee0 <__swc_fn_7dafa2b1_000128_41c3251c>
  40b111:	mov    rsi,rax
  40b114:	test   rsi,rsi
  40b117:	je     40b167 <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x127>
  40b119:	cmp    QWORD PTR [rsi],r13
  40b11c:	jne    40b167 <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x127>
  40b11e:	cmp    DWORD PTR [rsi+0x20],0x0
  40b122:	jne    40b167 <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x127>
  40b124:	cmp    DWORD PTR [rsi+0x730],0x10
  40b12b:	jae    40b167 <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x127>
  40b12d:	mov    eax,DWORD PTR [rsi+0x730]
  40b133:	lea    rdi,[rax+rax*4]
  40b137:	lea    rdi,[rsi+rdi*8+0x738]
  40b13f:	mov    QWORD PTR [rdi],r14
  40b142:	mov    QWORD PTR [rdi+0x8],r15
  40b146:	mov    QWORD PTR [rdi+0x10],r12
  40b14a:	mov    QWORD PTR [rdi+0x18],0x0
  40b152:	call   40ff90 <__swc_fn_7dafa2b1_000131_944f555b>
  40b157:	mov    QWORD PTR [rdi+0x20],rax
  40b15b:	add    DWORD PTR [rsi+0x730],0x1
  40b162:	jmp    40b2c6 <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x286>
  40b167:	mov    rcx,r13
  40b16a:	call   407e90 <__swc_fn_7dafa2b1_000057_5b81d8b6>
  40b16f:	mov    rsi,rax
  40b172:	cmp    r12,rax
  40b175:	jbe    40b1aa <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x16a>
  40b177:	cmp    r12,0x10000000
  40b17e:	seta   al
  40b181:	ja     40b190 <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x150>
  40b183:	mov    rax,QWORD PTR [r13+0x2a70]
  40b18a:	test   rax,rax
  40b18d:	setne  al
  40b190:	test   al,al
  40b192:	je     40b1aa <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x16a>
  40b194:	mov    rcx,r13
  40b197:	mov    rdx,r14
  40b19a:	mov    r8,r15
  40b19d:	mov    r9,r12
  40b1a0:	call   407750 <__swc_fn_7dafa2b1_000039_40d1e569>
  40b1a5:	jmp    40b2c6 <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x286>
  40b1aa:	call   40ff90 <__swc_fn_7dafa2b1_000131_944f555b>
  40b1af:	mov    rdi,rax
  40b1b2:	mov    rcx,r13
  40b1b5:	call   4098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>
  40b1ba:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b1c2:	je     40b27a <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x23a>
  40b1c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b1d0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b1db:	jae    40b1f0 <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x1b0>
  40b1dd:	mov    rax,QWORD PTR [r13+0x2a68]
  40b1e4:	add    rax,r12
  40b1e7:	cmp    rax,rsi
  40b1ea:	jbe    40b27a <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x23a>
  40b1f0:	xor    eax,eax
  40b1f2:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b1f9:	mov    edx,0x1
  40b1fe:	cmp    rcx,0x1
  40b202:	jbe    40b239 <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x1f9>
  40b204:	cs nop WORD PTR [rax+rax*1+0x0]
  40b20e:	xchg   ax,ax
  40b210:	lea    r8,[rdx+rdx*4]
  40b214:	lea    r8,[r13+r8*8+0x268]
  40b21c:	lea    r9,[rax+rax*4]
  40b220:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b228:	cmp    QWORD PTR [r8+0x18],r9
  40b22c:	cmovb  rax,rdx
  40b230:	add    rdx,0x1
  40b234:	cmp    rdx,rcx
  40b237:	jb     40b210 <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x1d0>
  40b239:	lea    rcx,[rax+rax*4]
  40b23d:	lea    rcx,[r13+rcx*8+0x268]
  40b245:	mov    r8,QWORD PTR [rcx]
  40b248:	mov    r9,QWORD PTR [rcx+0x8]
  40b24c:	mov    r10,QWORD PTR [rcx+0x10]
  40b250:	mov    rcx,r13
  40b253:	mov    rdx,rax
  40b256:	call   40e260 <__swc_fn_7dafa2b1_000056_38b21f11>
  40b25b:	mov    rcx,r13
  40b25e:	mov    rdx,r8
  40b261:	mov    r8,r9
  40b264:	mov    r9,r10
  40b267:	call   407750 <__swc_fn_7dafa2b1_000039_40d1e569>
  40b26c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b274:	jne    40b1d0 <__swc_fn_7dafa2b1_000058_8bd8d1d5+0x190>
  40b27a:	add    QWORD PTR [r13+0x2a78],0x1
  40b282:	mov    rax,QWORD PTR [r13+0x2a70]
  40b289:	lea    rax,[rax+rax*4]
  40b28d:	lea    rax,[r13+rax*8+0x268]
  40b295:	mov    QWORD PTR [rax],r14
  40b298:	mov    QWORD PTR [rax+0x8],r15
  40b29c:	mov    QWORD PTR [rax+0x10],r12
  40b2a0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40b2a7:	mov    QWORD PTR [rax+0x18],rcx
  40b2ab:	mov    QWORD PTR [rax+0x20],rdi
  40b2af:	add    QWORD PTR [r13+0x2a68],r12
  40b2b6:	add    QWORD PTR [r13+0x2a70],0x1
  40b2be:	mov    rcx,r13
  40b2c1:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  40b2c6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40b2cf:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40b2d8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40b2e1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40b2ea:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40b2f3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40b2fc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40b305:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40b30e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40b317:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40b320:	add    rsp,0x148
  40b327:	pop    rsi
  40b328:	pop    rdi
  40b329:	pop    r15
  40b32b:	pop    r14
  40b32d:	pop    r13
  40b32f:	pop    r12
  40b331:	ret
	...

000000000040b340 <__swc_fn_7dafa2b1_000061_0a7f67d9>:
  40b340:	push   rbx
  40b341:	push   r12
  40b343:	push   r13
  40b345:	push   r14
  40b347:	push   r15
  40b349:	push   rdi
  40b34a:	push   rsi
  40b34b:	sub    rsp,0xf0
  40b352:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40b358:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40b35e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40b364:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40b36a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40b373:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40b37c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40b385:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40b38e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40b397:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40b3a0:	mov    eax,r8d
  40b3a3:	mov    rbx,rcx
  40b3a6:	mov    r12,rdx
  40b3a9:	mov    QWORD PTR [rsp+0x18],rdx
  40b3ae:	mov    ecx,DWORD PTR [r12+0x58]
  40b3b3:	mov    r13d,ecx
  40b3b6:	cmp    ecx,0x10
  40b3b9:	mov    ecx,0x10
  40b3be:	cmovb  r13d,ecx
  40b3c2:	test   r13d,r13d
  40b3c5:	mov    rcx,r13
  40b3c8:	mov    edx,0x8
  40b3cd:	cmove  ecx,edx
  40b3d0:	dec    rcx
  40b3d3:	mov    rdx,0xffffffffffffffff
  40b3da:	sub    rdx,rcx
  40b3dd:	xor    r14d,r14d
  40b3e0:	mov    r8,rcx
  40b3e3:	not    r8
  40b3e6:	lea    rcx,[rcx+0x58]
  40b3ea:	and    rcx,r8
  40b3ed:	cmp    rdx,0x58
  40b3f1:	cmovae r14,rcx
  40b3f5:	cmp    eax,0xffffffff
  40b3f8:	jne    40b401 <__swc_fn_7dafa2b1_000061_0a7f67d9+0xc1>
  40b3fa:	mov    r15,QWORD PTR [r12+0x48]
  40b3ff:	jmp    40b433 <__swc_fn_7dafa2b1_000061_0a7f67d9+0xf3>
  40b401:	test   eax,eax
  40b403:	jne    40b40c <__swc_fn_7dafa2b1_000061_0a7f67d9+0xcc>
  40b405:	mov    eax,0x8
  40b40a:	jmp    40b430 <__swc_fn_7dafa2b1_000061_0a7f67d9+0xf0>
  40b40c:	cmp    eax,0x8
  40b40f:	ja     40b417 <__swc_fn_7dafa2b1_000061_0a7f67d9+0xd7>
  40b411:	shl    rax,0x4
  40b415:	jmp    40b430 <__swc_fn_7dafa2b1_000061_0a7f67d9+0xf0>
  40b417:	lea    eax,[rax-0x9]
  40b41a:	mov    ecx,eax
  40b41c:	shr    ecx,0x2
  40b41f:	and    eax,0x3
  40b422:	lea    ecx,[rcx+0x7]
  40b425:	lea    ecx,[rcx-0x2]
  40b428:	lea    eax,[rax+0x5]
  40b42b:	shlx   rax,rax,rcx
  40b430:	mov    r15,rax
  40b433:	lea    rax,[r14+r13*1]
  40b437:	mov    rcx,0xffffffffffffffff
  40b43e:	sub    rcx,rax
  40b441:	cmp    r15,rcx
  40b444:	jbe    40b454 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x114>
  40b446:	mov    QWORD PTR [r12+0x40],0x0
  40b44f:	jmp    40b826 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x4e6>
  40b454:	mov    QWORD PTR [rsp+0x20],r13
  40b459:	lea    r13,[rsp+0x8]
  40b45e:	add    rax,r15
  40b461:	mov    ecx,0x1000
  40b466:	test   ecx,ecx
  40b468:	mov    edx,0x8
  40b46d:	cmove  ecx,edx
  40b470:	dec    rcx
  40b473:	mov    rdx,0xffffffffffffffff
  40b47a:	sub    rdx,rcx
  40b47d:	cmp    rax,rdx
  40b480:	jbe    40b48c <__swc_fn_7dafa2b1_000061_0a7f67d9+0x14c>
  40b482:	mov    QWORD PTR [r13+0x0],0x0
  40b48a:	jmp    40b499 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x159>
  40b48c:	add    rax,rcx
  40b48f:	andn   rax,rcx,rax
  40b494:	mov    QWORD PTR [rsp+0x8],rax
  40b499:	cmp    QWORD PTR [r13+0x0],0x0
  40b49e:	jne    40b4ae <__swc_fn_7dafa2b1_000061_0a7f67d9+0x16e>
  40b4a0:	mov    QWORD PTR [r12+0x40],0x0
  40b4a9:	jmp    40b826 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x4e6>
  40b4ae:	mov    QWORD PTR [rsp+0x30],r15
  40b4b3:	xor    r15d,r15d
  40b4b6:	mov    QWORD PTR [rsp+0x38],0x0
  40b4bf:	lea    r12,[rsp+0x10]
  40b4c4:	mov    QWORD PTR [rsp+0x28],r14
  40b4c9:	mov    r14,QWORD PTR [rsp+0x8]
  40b4ce:	mov    QWORD PTR [rsp+0x10],r14
  40b4d3:	cmp    r14,0x10000
  40b4da:	ja     40b4e1 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x1a1>
  40b4dc:	mov    rax,r14
  40b4df:	jmp    40b532 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x1f2>
  40b4e1:	xor    eax,eax
  40b4e3:	lea    rcx,[r14-0x1]
  40b4e7:	lzcnt  rax,rcx
  40b4ec:	mov    ecx,0x3f
  40b4f1:	sub    rcx,rax
  40b4f4:	mov    eax,0x1
  40b4f9:	lea    rcx,[rcx-0x3]
  40b4fd:	shl    rax,cl
  40b500:	mov    rcx,rax
  40b503:	cmp    rax,0x1000
  40b50a:	mov    eax,0x1000
  40b50f:	cmovb  rcx,rax
  40b513:	mov    rdx,0xffffffffffffffff
  40b51a:	sub    rdx,rcx
  40b51d:	mov    rax,r14
  40b520:	lea    r8,[r14+rcx*1-0x1]
  40b525:	neg    rcx
  40b528:	and    r8,rcx
  40b52b:	cmp    r14,rdx
  40b52e:	cmovbe rax,r8
  40b532:	mov    QWORD PTR [rsp+0x8],rax
  40b537:	lea    rax,[rip+0x15ac2]        # 421000 <__swc_data_base_7dafa2b1>
  40b53e:	mov    rax,QWORD PTR [rax]
  40b541:	cmp    rax,0xffffffffffffffff
  40b545:	je     40b554 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x214>
  40b547:	mov    eax,eax
  40b549:	mov    edi,eax
  40b54b:	xor    eax,eax
  40b54d:	call   407000 <pthread_getspecific@plt>
  40b552:	jmp    40b556 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x216>
  40b554:	xor    eax,eax
  40b556:	test   rax,rax
  40b559:	jne    40b568 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x228>
  40b55b:	call   40a9e0 <__swc_fn_7dafa2b1_000031_90860ff2>
  40b560:	mov    rcx,rax
  40b563:	call   40fee0 <__swc_fn_7dafa2b1_000128_41c3251c>
  40b568:	test   rax,rax
  40b56b:	je     40b65c <__swc_fn_7dafa2b1_000061_0a7f67d9+0x31c>
  40b571:	cmp    QWORD PTR [rax],rbx
  40b574:	jne    40b65c <__swc_fn_7dafa2b1_000061_0a7f67d9+0x31c>
  40b57a:	cmp    DWORD PTR [rax+0x20],0x0
  40b57e:	jne    40b65c <__swc_fn_7dafa2b1_000061_0a7f67d9+0x31c>
  40b584:	mov    rcx,QWORD PTR [rsp+0x8]
  40b589:	movabs rdx,0x7fffffffffffffff
  40b593:	cmp    rcx,rdx
  40b596:	mov    rdx,0xffffffffffffffff
  40b59d:	lea    r8,[rcx+rcx*1]
  40b5a1:	cmovbe rdx,r8
  40b5a5:	mov    r8d,DWORD PTR [rax+0x730]
  40b5ac:	mov    r9d,r8d
  40b5af:	sub    rdx,rcx
  40b5b2:	inc    rdx
  40b5b5:	xor    r10d,r10d
  40b5b8:	test   r8,r8
  40b5bb:	jbe    40b5eb <__swc_fn_7dafa2b1_000061_0a7f67d9+0x2ab>
  40b5bd:	nop    DWORD PTR [rax]
  40b5c0:	mov    r11d,r10d
  40b5c3:	lea    r11,[r11+r11*4]
  40b5c7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40b5cf:	sub    r11,rcx
  40b5d2:	cmp    r11,rdx
  40b5d5:	jae    40b5e2 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x2a2>
  40b5d7:	mov    r9d,r10d
  40b5da:	mov    rdx,r11
  40b5dd:	test   r11,r11
  40b5e0:	je     40b5eb <__swc_fn_7dafa2b1_000061_0a7f67d9+0x2ab>
  40b5e2:	add    r10,0x1
  40b5e6:	cmp    r10,r8
  40b5e9:	jb     40b5c0 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x280>
  40b5eb:	mov    ecx,DWORD PTR [rax+0x730]
  40b5f1:	cmp    r9d,ecx
  40b5f4:	jne    40b5fa <__swc_fn_7dafa2b1_000061_0a7f67d9+0x2ba>
  40b5f6:	xor    eax,eax
  40b5f8:	jmp    40b659 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x319>
  40b5fa:	lea    rcx,[r9+r9*4]
  40b5fe:	lea    rcx,[rax+rcx*8+0x738]
  40b606:	vmovups xmm0,XMMWORD PTR [rcx]
  40b60a:	mov    rdx,QWORD PTR [rcx+0x10]
  40b60e:	sub    DWORD PTR [rax+0x730],0x1
  40b615:	mov    r8d,DWORD PTR [rax+0x730]
  40b61c:	lea    r8,[r8+r8*4]
  40b620:	lea    r8,[rax+r8*8+0x738]
  40b628:	vmovups xmm1,XMMWORD PTR [r8]
  40b62d:	vmovups XMMWORD PTR [rcx],xmm1
  40b631:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40b637:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40b63c:	mov    rax,QWORD PTR [r8+0x20]
  40b640:	mov    QWORD PTR [rcx+0x20],rax
  40b644:	vpshufd xmm1,xmm0,0xee
  40b649:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40b64f:	mov    QWORD PTR [rsp+0x10],rdx
  40b654:	vmovq  rax,xmm0
  40b659:	mov    r15,rax
  40b65c:	test   r15,r15
  40b65f:	jne    40b677 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x337>
  40b661:	mov    rcx,rbx
  40b664:	mov    rdx,QWORD PTR [rsp+0x8]
  40b669:	mov    r8,r13
  40b66c:	mov    r9,r12
  40b66f:	call   40af30 <__swc_fn_7dafa2b1_000055_81f7713d>
  40b674:	mov    r15,rax
  40b677:	test   r15,r15
  40b67a:	je     40b6bb <__swc_fn_7dafa2b1_000061_0a7f67d9+0x37b>
  40b67c:	cmp    QWORD PTR [r12],r14
  40b680:	jae    40b6bb <__swc_fn_7dafa2b1_000061_0a7f67d9+0x37b>
  40b682:	mov    rax,r15
  40b685:	add    rax,QWORD PTR [r12]
  40b689:	mov    rdx,r14
  40b68c:	sub    rdx,QWORD PTR [r12]
  40b690:	mov    rcx,rax
  40b693:	call   4072a0 <__swc_fn_7dafa2b1_000003_7ab4792e>
  40b698:	test   al,al
  40b69a:	je     40b6a3 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x363>
  40b69c:	mov    QWORD PTR [rsp+0x10],r14
  40b6a1:	jmp    40b6bb <__swc_fn_7dafa2b1_000061_0a7f67d9+0x37b>
  40b6a3:	mov    rcx,rbx
  40b6a6:	mov    rdx,r15
  40b6a9:	mov    r8,QWORD PTR [rsp+0x8]
  40b6ae:	mov    r9,QWORD PTR [rsp+0x10]
  40b6b3:	call   40b040 <__swc_fn_7dafa2b1_000058_8bd8d1d5>
  40b6b8:	xor    r15d,r15d
  40b6bb:	test   r15,r15
  40b6be:	jne    40b73a <__swc_fn_7dafa2b1_000061_0a7f67d9+0x3fa>
  40b6c0:	cmp    r14,0x10000
  40b6c7:	ja     40b6ce <__swc_fn_7dafa2b1_000061_0a7f67d9+0x38e>
  40b6c9:	mov    rax,r14
  40b6cc:	jmp    40b71f <__swc_fn_7dafa2b1_000061_0a7f67d9+0x3df>
  40b6ce:	xor    eax,eax
  40b6d0:	lea    rcx,[r14-0x1]
  40b6d4:	lzcnt  rax,rcx
  40b6d9:	mov    ecx,0x3f
  40b6de:	sub    rcx,rax
  40b6e1:	mov    eax,0x1
  40b6e6:	lea    rcx,[rcx-0x3]
  40b6ea:	shl    rax,cl
  40b6ed:	mov    rcx,rax
  40b6f0:	cmp    rax,0x1000
  40b6f7:	mov    eax,0x1000
  40b6fc:	cmovb  rcx,rax
  40b700:	mov    rdx,0xffffffffffffffff
  40b707:	sub    rdx,rcx
  40b70a:	mov    rax,r14
  40b70d:	lea    r8,[r14+rcx*1-0x1]
  40b712:	neg    rcx
  40b715:	and    r8,rcx
  40b718:	cmp    r14,rdx
  40b71b:	cmovbe rax,r8
  40b71f:	mov    QWORD PTR [rsp+0x8],rax
  40b724:	mov    QWORD PTR [rsp+0x10],r14
  40b729:	mov    rcx,rbx
  40b72c:	mov    rdx,rax
  40b72f:	mov    r8,r14
  40b732:	call   40aaa0 <__swc_fn_7dafa2b1_000037_b4982903>
  40b737:	mov    r15,rax
  40b73a:	test   r15,r15
  40b73d:	jne    40b74b <__swc_fn_7dafa2b1_000061_0a7f67d9+0x40b>
  40b73f:	mov    r13,QWORD PTR [rsp+0x20]
  40b744:	mov    rsi,QWORD PTR [rsp+0x38]
  40b749:	jmp    40b787 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x447>
  40b74b:	mov    rax,r15
  40b74e:	add    rax,QWORD PTR [rsp+0x28]
  40b753:	mov    r13,QWORD PTR [rsp+0x20]
  40b758:	test   r13d,r13d
  40b75b:	mov    rcx,r13
  40b75e:	mov    edx,0x8
  40b763:	cmove  ecx,edx
  40b766:	dec    rcx
  40b769:	mov    rdx,0xffffffffffffffff
  40b770:	sub    rdx,rcx
  40b773:	cmp    rax,rdx
  40b776:	jbe    40b77c <__swc_fn_7dafa2b1_000061_0a7f67d9+0x43c>
  40b778:	xor    eax,eax
  40b77a:	jmp    40b784 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x444>
  40b77c:	add    rax,rcx
  40b77f:	andn   rax,rcx,rax
  40b784:	mov    rsi,rax
  40b787:	mov    rax,QWORD PTR [rsp+0x8]
  40b78c:	test   r15,r15
  40b78f:	je     40b798 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x458>
  40b791:	mov    rdi,QWORD PTR [rsp+0x18]
  40b796:	jmp    40b7aa <__swc_fn_7dafa2b1_000061_0a7f67d9+0x46a>
  40b798:	mov    rdi,QWORD PTR [rsp+0x18]
  40b79d:	mov    QWORD PTR [rdi+0x40],0x0
  40b7a5:	jmp    40b826 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x4e6>
  40b7aa:	lea    rdx,[rsi-0x58]
  40b7ae:	mov    QWORD PTR [rsi-0x58],r15
  40b7b2:	mov    QWORD PTR [rsi-0x50],rax
  40b7b6:	mov    rax,QWORD PTR [rsp+0x10]
  40b7bb:	mov    QWORD PTR [rsi-0x48],rax
  40b7bf:	mov    QWORD PTR [rsi-0x40],rsi
  40b7c3:	mov    rax,QWORD PTR [rdi+0x48]
  40b7c7:	mov    QWORD PTR [rsi-0x38],rax
  40b7cb:	mov    rax,QWORD PTR [rsp+0x30]
  40b7d0:	mov    QWORD PTR [rsi-0x30],rax
  40b7d4:	mov    DWORD PTR [rsi-0x10],r13d
  40b7d8:	mov    QWORD PTR [rsi-0x28],0x0
  40b7e0:	mov    QWORD PTR [rsi-0x20],0x0
  40b7e8:	add    r15,QWORD PTR [r12]
  40b7ec:	sub    r15,rsi
  40b7ef:	mov    QWORD PTR [rsi-0x30],r15
  40b7f3:	mov    rcx,QWORD PTR [rbx+0x250]
  40b7fa:	nop    WORD PTR [rax+rax*1+0x0]
  40b800:	lea    r8,[rcx+r15*1]
  40b804:	mov    rax,rcx
  40b807:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40b810:	cmp    rax,rcx
  40b813:	je     40b81a <__swc_fn_7dafa2b1_000061_0a7f67d9+0x4da>
  40b815:	mov    rcx,rax
  40b818:	jmp    40b800 <__swc_fn_7dafa2b1_000061_0a7f67d9+0x4c0>
  40b81a:	mov    rcx,rbx
  40b81d:	call   40e1d0 <__swc_fn_7dafa2b1_000053_82546d94>
  40b822:	mov    QWORD PTR [rdi+0x40],rsi
  40b826:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40b82c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40b832:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40b838:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40b83e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40b847:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40b850:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40b859:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40b862:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40b86b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40b874:	add    rsp,0xf0
  40b87b:	pop    rsi
  40b87c:	pop    rdi
  40b87d:	pop    r15
  40b87f:	pop    r14
  40b881:	pop    r13
  40b883:	pop    r12
  40b885:	pop    rbx
  40b886:	ret
	...

000000000040b890 <__swc_fn_7dafa2b1_000064_b0d63361>:
  40b890:	push   rbx
  40b891:	push   r12
  40b893:	push   rdi
  40b894:	push   rsi
  40b895:	sub    rsp,0xb8
  40b89c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40b8a2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40b8a8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40b8ae:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40b8b4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40b8ba:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40b8c0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40b8c6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40b8cf:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40b8d8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40b8e1:	mov    rbx,rdx
  40b8e4:	mov    r12,rcx
  40b8e7:	cmp    DWORD PTR [rbx+0x58],0x0
  40b8eb:	je     40b905 <__swc_fn_7dafa2b1_000064_b0d63361+0x75>
  40b8ed:	mov    eax,DWORD PTR [rbx+0x58]
  40b8f0:	sub    eax,0x1
  40b8f3:	test   DWORD PTR [rbx+0x58],eax
  40b8f6:	je     40b905 <__swc_fn_7dafa2b1_000064_b0d63361+0x75>
  40b8f8:	mov    QWORD PTR [rbx+0x40],0x0
  40b900:	jmp    40bb17 <__swc_fn_7dafa2b1_000064_b0d63361+0x287>
  40b905:	cmp    QWORD PTR [rbx+0x48],0x0
  40b90a:	jne    40b919 <__swc_fn_7dafa2b1_000064_b0d63361+0x89>
  40b90c:	mov    QWORD PTR [rbx+0x40],0x0
  40b914:	jmp    40bb17 <__swc_fn_7dafa2b1_000064_b0d63361+0x287>
  40b919:	lea    rax,[rsp+0x8]
  40b91e:	mov    rcx,QWORD PTR [rbx+0x48]
  40b922:	cmp    rcx,0x8
  40b926:	ja     40b930 <__swc_fn_7dafa2b1_000064_b0d63361+0xa0>
  40b928:	mov    DWORD PTR [rax],0x0
  40b92e:	jmp    40b98b <__swc_fn_7dafa2b1_000064_b0d63361+0xfb>
  40b930:	cmp    rcx,0x80
  40b937:	ja     40b947 <__swc_fn_7dafa2b1_000064_b0d63361+0xb7>
  40b939:	lea    rcx,[rcx+0xf]
  40b93d:	shr    rcx,0x4
  40b941:	mov    DWORD PTR [rsp+0x8],ecx
  40b945:	jmp    40b98b <__swc_fn_7dafa2b1_000064_b0d63361+0xfb>
  40b947:	cmp    rcx,0x10000
  40b94e:	jbe    40b958 <__swc_fn_7dafa2b1_000064_b0d63361+0xc8>
  40b950:	mov    DWORD PTR [rax],0xffffffff
  40b956:	jmp    40b98b <__swc_fn_7dafa2b1_000064_b0d63361+0xfb>
  40b958:	dec    rcx
  40b95b:	xor    edx,edx
  40b95d:	lzcnt  rdx,rcx
  40b962:	mov    r8d,0x3f
  40b968:	sub    r8d,edx
  40b96b:	lea    edx,[r8-0x2]
  40b96f:	shrx   rcx,rcx,rdx
  40b974:	and    ecx,0x3
  40b977:	lea    edx,[r8-0x7]
  40b97b:	lea    edx,[rdx*4+0x0]
  40b982:	lea    edx,[rdx+0x9]
  40b985:	add    edx,ecx
  40b987:	mov    DWORD PTR [rsp+0x8],edx
  40b98b:	cmp    DWORD PTR [rax],0x0
  40b98e:	jne    40b99e <__swc_fn_7dafa2b1_000064_b0d63361+0x10e>
  40b990:	cmp    DWORD PTR [rbx+0x58],0x8
  40b994:	jbe    40b99e <__swc_fn_7dafa2b1_000064_b0d63361+0x10e>
  40b996:	mov    DWORD PTR [rsp+0x8],0x1
  40b99e:	cmp    DWORD PTR [rbx+0x58],0x10
  40b9a2:	jbe    40ba21 <__swc_fn_7dafa2b1_000064_b0d63361+0x191>
  40b9a8:	cmp    DWORD PTR [rbx+0x58],0x40
  40b9ac:	ja     40ba21 <__swc_fn_7dafa2b1_000064_b0d63361+0x191>
  40b9ae:	cmp    DWORD PTR [rax],0xffffffff
  40b9b1:	je     40ba21 <__swc_fn_7dafa2b1_000064_b0d63361+0x191>
  40b9b3:	mov    ecx,DWORD PTR [rsp+0x8]
  40b9b7:	mov    edx,DWORD PTR [rbx+0x58]
  40b9ba:	dec    rdx
  40b9bd:	cmp    ecx,0x2d
  40b9c0:	jae    40ba18 <__swc_fn_7dafa2b1_000064_b0d63361+0x188>
  40b9c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b9cc:	nop    DWORD PTR [rax+0x0]
  40b9d0:	mov    r8d,ecx
  40b9d3:	test   ecx,ecx
  40b9d5:	jne    40b9df <__swc_fn_7dafa2b1_000064_b0d63361+0x14f>
  40b9d7:	mov    r8d,0x8
  40b9dd:	jmp    40ba0b <__swc_fn_7dafa2b1_000064_b0d63361+0x17b>
  40b9df:	cmp    r8d,0x8
  40b9e3:	ja     40b9eb <__swc_fn_7dafa2b1_000064_b0d63361+0x15b>
  40b9e5:	shl    r8,0x4
  40b9e9:	jmp    40ba0b <__swc_fn_7dafa2b1_000064_b0d63361+0x17b>
  40b9eb:	lea    r8d,[r8-0x9]
  40b9ef:	mov    r9d,r8d
  40b9f2:	shr    r9d,0x2
  40b9f6:	and    r8d,0x3
  40b9fa:	lea    r9d,[r9+0x7]
  40b9fe:	lea    r9d,[r9-0x2]
  40ba02:	lea    r8d,[r8+0x5]
  40ba06:	shlx   r8,r8,r9
  40ba0b:	test   r8,rdx
  40ba0e:	je     40ba1d <__swc_fn_7dafa2b1_000064_b0d63361+0x18d>
  40ba10:	add    ecx,0x1
  40ba13:	cmp    ecx,0x2d
  40ba16:	jb     40b9d0 <__swc_fn_7dafa2b1_000064_b0d63361+0x140>
  40ba18:	mov    ecx,0xffffffff
  40ba1d:	mov    DWORD PTR [rsp+0x8],ecx
  40ba21:	mov    ecx,DWORD PTR [rsp+0x8]
  40ba25:	cmp    ecx,0xffffffff
  40ba28:	je     40ba30 <__swc_fn_7dafa2b1_000064_b0d63361+0x1a0>
  40ba2a:	cmp    DWORD PTR [rbx+0x58],0x40
  40ba2e:	jbe    40ba43 <__swc_fn_7dafa2b1_000064_b0d63361+0x1b3>
  40ba30:	mov    rcx,r12
  40ba33:	mov    rdx,rbx
  40ba36:	mov    r8d,DWORD PTR [rax]
  40ba39:	call   40b340 <__swc_fn_7dafa2b1_000061_0a7f67d9>
  40ba3e:	jmp    40bb17 <__swc_fn_7dafa2b1_000064_b0d63361+0x287>
  40ba43:	lea    rax,[rip+0x155b6]        # 421000 <__swc_data_base_7dafa2b1>
  40ba4a:	mov    rax,QWORD PTR [rax]
  40ba4d:	cmp    rax,0xffffffffffffffff
  40ba51:	je     40ba60 <__swc_fn_7dafa2b1_000064_b0d63361+0x1d0>
  40ba53:	mov    eax,eax
  40ba55:	mov    edi,eax
  40ba57:	xor    eax,eax
  40ba59:	call   407000 <pthread_getspecific@plt>
  40ba5e:	jmp    40ba62 <__swc_fn_7dafa2b1_000064_b0d63361+0x1d2>
  40ba60:	xor    eax,eax
  40ba62:	test   rax,rax
  40ba65:	jne    40ba74 <__swc_fn_7dafa2b1_000064_b0d63361+0x1e4>
  40ba67:	call   40a9e0 <__swc_fn_7dafa2b1_000031_90860ff2>
  40ba6c:	mov    rcx,rax
  40ba6f:	call   40fee0 <__swc_fn_7dafa2b1_000128_41c3251c>
  40ba74:	test   rax,rax
  40ba77:	je     40ba84 <__swc_fn_7dafa2b1_000064_b0d63361+0x1f4>
  40ba79:	cmp    QWORD PTR [rax],r12
  40ba7c:	jne    40ba84 <__swc_fn_7dafa2b1_000064_b0d63361+0x1f4>
  40ba7e:	cmp    DWORD PTR [rax+0x20],0x0
  40ba82:	je     40ba8f <__swc_fn_7dafa2b1_000064_b0d63361+0x1ff>
  40ba84:	mov    rcx,r12
  40ba87:	mov    rdx,rax
  40ba8a:	call   40de10 <__swc_fn_7dafa2b1_000041_414cc921>
  40ba8f:	test   rax,rax
  40ba92:	jne    40ba9e <__swc_fn_7dafa2b1_000064_b0d63361+0x20e>
  40ba94:	mov    QWORD PTR [rbx+0x40],0x0
  40ba9c:	jmp    40bb17 <__swc_fn_7dafa2b1_000064_b0d63361+0x287>
  40ba9e:	lea    r8,[rsp+0xc]
  40baa3:	mov    ecx,DWORD PTR [rsp+0x8]
  40baa7:	mov    DWORD PTR [rsp+0xc],ecx
  40baab:	mov    ecx,DWORD PTR [r8]
  40baae:	lea    rcx,[rcx+rcx*4]
  40bab2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40bab7:	test   rcx,rcx
  40baba:	je     40baf3 <__swc_fn_7dafa2b1_000064_b0d63361+0x263>
  40babc:	mov    rdx,QWORD PTR [rcx]
  40babf:	test   rdx,rdx
  40bac2:	je     40bad0 <__swc_fn_7dafa2b1_000064_b0d63361+0x240>
  40bac4:	mov    r9,QWORD PTR [rdx]
  40bac7:	mov    QWORD PTR [rcx],r9
  40baca:	add    DWORD PTR [rcx+0x28],0x1
  40bace:	jmp    40baee <__swc_fn_7dafa2b1_000064_b0d63361+0x25e>
  40bad0:	mov    rdx,QWORD PTR [rcx+0x18]
  40bad4:	cmp    QWORD PTR [rcx+0x20],rdx
  40bad8:	jae    40baec <__swc_fn_7dafa2b1_000064_b0d63361+0x25c>
  40bada:	mov    rdx,QWORD PTR [rcx+0x20]
  40bade:	mov    r9d,DWORD PTR [rcx+0x2c]
  40bae2:	add    QWORD PTR [rcx+0x20],r9
  40bae6:	add    DWORD PTR [rcx+0x28],0x1
  40baea:	jmp    40baee <__swc_fn_7dafa2b1_000064_b0d63361+0x25e>
  40baec:	xor    edx,edx
  40baee:	test   rdx,rdx
  40baf1:	jne    40bb04 <__swc_fn_7dafa2b1_000064_b0d63361+0x274>
  40baf3:	mov    rcx,r12
  40baf6:	mov    rdx,rax
  40baf9:	mov    r8d,DWORD PTR [r8]
  40bafc:	call   40df80 <__swc_fn_7dafa2b1_000050_ab8077df>
  40bb01:	mov    rdx,rax
  40bb04:	test   rdx,rdx
  40bb07:	jne    40bb13 <__swc_fn_7dafa2b1_000064_b0d63361+0x283>
  40bb09:	mov    QWORD PTR [rbx+0x40],0x0
  40bb11:	jmp    40bb17 <__swc_fn_7dafa2b1_000064_b0d63361+0x287>
  40bb13:	mov    QWORD PTR [rbx+0x40],rdx
  40bb17:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40bb1d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40bb23:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40bb29:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40bb2f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40bb35:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40bb3b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40bb41:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40bb4a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40bb53:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40bb5c:	add    rsp,0xb8
  40bb63:	pop    rsi
  40bb64:	pop    rdi
  40bb65:	pop    r12
  40bb67:	pop    rbx
  40bb68:	ret
  40bb69:	add    BYTE PTR [rax],al
  40bb6b:	add    BYTE PTR [rax],al
  40bb6d:	add    BYTE PTR [rax],al
	...

000000000040bb70 <__swc_fn_7dafa2b1_000067_94a51053>:
  40bb70:	ret
	...

000000000040bb80 <__swc_fn_7dafa2b1_000070_3181d86c>:
  40bb80:	push   r12
  40bb82:	push   r13
  40bb84:	push   r14
  40bb86:	push   rdi
  40bb87:	push   rsi
  40bb88:	sub    rsp,0x1a0
  40bb8f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40bb98:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40bba1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40bbaa:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40bbb3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40bbbc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40bbc5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40bbce:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40bbd7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40bbe0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40bbe9:	mov    r12,rdx
  40bbec:	mov    r13,rcx
  40bbef:	mov    rax,QWORD PTR [r12+0x48]
  40bbf4:	mov    ecx,DWORD PTR [r12+0x58]
  40bbf9:	lea    rdx,[rax-0x1]
  40bbfd:	cmp    rdx,0x10000
  40bc04:	jae    40bcfe <__swc_fn_7dafa2b1_000070_3181d86c+0x17e>
  40bc0a:	cmp    rax,0x8
  40bc0e:	ja     40bc15 <__swc_fn_7dafa2b1_000070_3181d86c+0x95>
  40bc10:	xor    r14d,r14d
  40bc13:	jmp    40bc67 <__swc_fn_7dafa2b1_000070_3181d86c+0xe7>
  40bc15:	cmp    rax,0x80
  40bc1c:	ja     40bc28 <__swc_fn_7dafa2b1_000070_3181d86c+0xa8>
  40bc1e:	lea    r14,[rax+0xf]
  40bc22:	shr    r14,0x4
  40bc26:	jmp    40bc67 <__swc_fn_7dafa2b1_000070_3181d86c+0xe7>
  40bc28:	cmp    rax,0x10000
  40bc2f:	jbe    40bc39 <__swc_fn_7dafa2b1_000070_3181d86c+0xb9>
  40bc31:	mov    r14d,0xffffffff
  40bc37:	jmp    40bc67 <__swc_fn_7dafa2b1_000070_3181d86c+0xe7>
  40bc39:	xor    eax,eax
  40bc3b:	lzcnt  rax,rdx
  40bc40:	mov    r8d,0x3f
  40bc46:	sub    r8d,eax
  40bc49:	lea    eax,[r8-0x2]
  40bc4d:	shrx   rax,rdx,rax
  40bc52:	and    eax,0x3
  40bc55:	lea    edx,[r8-0x7]
  40bc59:	lea    edx,[rdx*4+0x0]
  40bc60:	lea    edx,[rdx+0x9]
  40bc63:	lea    r14d,[rdx+rax*1]
  40bc67:	cmp    ecx,0x8
  40bc6a:	jbe    40bc83 <__swc_fn_7dafa2b1_000070_3181d86c+0x103>
  40bc6c:	cmp    ecx,0x10
  40bc6f:	jne    40bcfe <__swc_fn_7dafa2b1_000070_3181d86c+0x17e>
  40bc75:	test   r14d,r14d
  40bc78:	mov    eax,0x1
  40bc7d:	cmove  r14d,eax
  40bc81:	jmp    40bc8a <__swc_fn_7dafa2b1_000070_3181d86c+0x10a>
  40bc83:	lea    eax,[rcx-0x1]
  40bc86:	test   eax,ecx
  40bc88:	jne    40bcfe <__swc_fn_7dafa2b1_000070_3181d86c+0x17e>
  40bc8a:	lea    rax,[rip+0x1536f]        # 421000 <__swc_data_base_7dafa2b1>
  40bc91:	mov    rax,QWORD PTR [rax]
  40bc94:	cmp    rax,0xffffffffffffffff
  40bc98:	je     40bca7 <__swc_fn_7dafa2b1_000070_3181d86c+0x127>
  40bc9a:	mov    eax,eax
  40bc9c:	mov    edi,eax
  40bc9e:	xor    eax,eax
  40bca0:	call   407000 <pthread_getspecific@plt>
  40bca5:	jmp    40bca9 <__swc_fn_7dafa2b1_000070_3181d86c+0x129>
  40bca7:	xor    eax,eax
  40bca9:	test   rax,rax
  40bcac:	je     40bcfe <__swc_fn_7dafa2b1_000070_3181d86c+0x17e>
  40bcae:	cmp    QWORD PTR [rax],r13
  40bcb1:	jne    40bcfe <__swc_fn_7dafa2b1_000070_3181d86c+0x17e>
  40bcb3:	lea    rcx,[r14+r14*4]
  40bcb7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40bcbc:	test   rax,rax
  40bcbf:	je     40bcfe <__swc_fn_7dafa2b1_000070_3181d86c+0x17e>
  40bcc1:	mov    rcx,QWORD PTR [rax]
  40bcc4:	test   rcx,rcx
  40bcc7:	je     40bcd5 <__swc_fn_7dafa2b1_000070_3181d86c+0x155>
  40bcc9:	mov    rdx,QWORD PTR [rcx]
  40bccc:	mov    QWORD PTR [rax],rdx
  40bccf:	add    DWORD PTR [rax+0x28],0x1
  40bcd3:	jmp    40bcf2 <__swc_fn_7dafa2b1_000070_3181d86c+0x172>
  40bcd5:	mov    rcx,QWORD PTR [rax+0x18]
  40bcd9:	cmp    QWORD PTR [rax+0x20],rcx
  40bcdd:	jae    40bcf0 <__swc_fn_7dafa2b1_000070_3181d86c+0x170>
  40bcdf:	mov    rcx,QWORD PTR [rax+0x20]
  40bce3:	mov    edx,DWORD PTR [rax+0x2c]
  40bce6:	add    QWORD PTR [rax+0x20],rdx
  40bcea:	add    DWORD PTR [rax+0x28],0x1
  40bcee:	jmp    40bcf2 <__swc_fn_7dafa2b1_000070_3181d86c+0x172>
  40bcf0:	xor    ecx,ecx
  40bcf2:	test   rcx,rcx
  40bcf5:	je     40bcfe <__swc_fn_7dafa2b1_000070_3181d86c+0x17e>
  40bcf7:	mov    QWORD PTR [r12+0x40],rcx
  40bcfc:	jmp    40bd09 <__swc_fn_7dafa2b1_000070_3181d86c+0x189>
  40bcfe:	mov    rcx,r13
  40bd01:	mov    rdx,r12
  40bd04:	call   40ea00 <__swc_fn_7dafa2b1_000071_0d1ef36f>
  40bd09:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40bd12:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40bd1b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40bd24:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40bd2d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40bd36:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40bd3f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40bd48:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40bd51:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40bd5a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40bd63:	add    rsp,0x1a0
  40bd6a:	pop    rsi
  40bd6b:	pop    rdi
  40bd6c:	pop    r14
  40bd6e:	pop    r13
  40bd70:	pop    r12
  40bd72:	ret
	...

000000000040bd80 <__swc_fn_7dafa2b1_000073_c6c71bf7>:
  40bd80:	push   r12
  40bd82:	push   r13
  40bd84:	push   r14
  40bd86:	push   r15
  40bd88:	push   rdi
  40bd89:	push   rsi
  40bd8a:	sub    rsp,0x188
  40bd91:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40bd9a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40bda3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40bdac:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40bdb5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40bdbe:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40bdc7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40bdd0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40bdd9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40bde2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40bdeb:	mov    r12,rdx
  40bdee:	mov    r13,rcx
  40bdf1:	mov    r14,QWORD PTR [r12+0x40]
  40bdf6:	lea    rax,[rip+0x17273]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  40bdfd:	mov    rcx,r14
  40be00:	sub    rcx,QWORD PTR [rax+0x8]
  40be04:	mov    rax,QWORD PTR [rip+0x17275]        # 423080 <__swc_bss_base_7dafa2b1+0x40>
  40be0b:	cmp    rcx,rax
  40be0e:	jae    40be3a <__swc_fn_7dafa2b1_000073_c6c71bf7+0xba>
  40be10:	mov    rax,r14
  40be13:	and    rax,0xffffffffffc00000
  40be1a:	mov    rcx,r14
  40be1d:	shr    rcx,0x10
  40be21:	and    ecx,0x3f
  40be24:	mov    edx,DWORD PTR [rax+0x28]
  40be27:	shrx   ecx,ecx,edx
  40be2c:	shl    rcx,0x4
  40be30:	lea    r15,[rax+rcx*8+0x80]
  40be38:	jmp    40be45 <__swc_fn_7dafa2b1_000073_c6c71bf7+0xc5>
  40be3a:	mov    rcx,r14
  40be3d:	call   40a910 <__swc_fn_7dafa2b1_000022_3a2e2048>
  40be42:	mov    r15,rax
  40be45:	test   r15,r15
  40be48:	je     40beef <__swc_fn_7dafa2b1_000073_c6c71bf7+0x16f>
  40be4e:	lea    rax,[rip+0x151ab]        # 421000 <__swc_data_base_7dafa2b1>
  40be55:	mov    rax,QWORD PTR [rax]
  40be58:	cmp    rax,0xffffffffffffffff
  40be5c:	je     40be6b <__swc_fn_7dafa2b1_000073_c6c71bf7+0xeb>
  40be5e:	mov    eax,eax
  40be60:	mov    edi,eax
  40be62:	xor    eax,eax
  40be64:	call   407000 <pthread_getspecific@plt>
  40be69:	jmp    40be6d <__swc_fn_7dafa2b1_000073_c6c71bf7+0xed>
  40be6b:	xor    eax,eax
  40be6d:	mov    rcx,QWORD PTR [r15+0x40]
  40be71:	cmp    rcx,rax
  40be74:	jne    40bed4 <__swc_fn_7dafa2b1_000073_c6c71bf7+0x154>
  40be76:	test   rax,rax
  40be79:	je     40beef <__swc_fn_7dafa2b1_000073_c6c71bf7+0x16f>
  40be7b:	mov    ecx,DWORD PTR [r15+0x6c]
  40be7f:	test   ecx,ecx
  40be81:	je     40bea1 <__swc_fn_7dafa2b1_000073_c6c71bf7+0x121>
  40be83:	mov    rcx,r13
  40be86:	mov    rdx,rax
  40be89:	mov    r8,r15
  40be8c:	mov    QWORD PTR [rsp+0xd8],rax
  40be94:	call   40df10 <__swc_fn_7dafa2b1_000047_bc5ec610>
  40be99:	mov    rax,QWORD PTR [rsp+0xd8]
  40bea1:	mov    rcx,QWORD PTR [r15]
  40bea4:	mov    QWORD PTR [r14],rcx
  40bea7:	mov    QWORD PTR [r15],r14
  40beaa:	sub    DWORD PTR [r15+0x28],0x1
  40beaf:	jne    40bee4 <__swc_fn_7dafa2b1_000073_c6c71bf7+0x164>
  40beb1:	movzx  ecx,BYTE PTR [r15+0x39]
  40beb6:	lea    rcx,[rcx+rcx*4]
  40beba:	lea    rcx,[rax+rcx*8+0x28]
  40bebf:	cmp    QWORD PTR [rcx],r15
  40bec2:	je     40bee4 <__swc_fn_7dafa2b1_000073_c6c71bf7+0x164>
  40bec4:	mov    rcx,r13
  40bec7:	mov    rdx,rax
  40beca:	mov    r8,r15
  40becd:	call   407d80 <__swc_fn_7dafa2b1_000051_f7021588>
  40bed2:	jmp    40bee4 <__swc_fn_7dafa2b1_000073_c6c71bf7+0x164>
  40bed4:	test   rcx,rcx
  40bed7:	je     40beef <__swc_fn_7dafa2b1_000073_c6c71bf7+0x16f>
  40bed9:	mov    rcx,r15
  40bedc:	mov    rdx,r14
  40bedf:	call   40a550 <__swc_fn_7dafa2b1_000010_395bb04b>
  40bee4:	mov    QWORD PTR [r12+0x40],0x0
  40beed:	jmp    40befa <__swc_fn_7dafa2b1_000073_c6c71bf7+0x17a>
  40beef:	mov    rcx,r13
  40bef2:	mov    rdx,r12
  40bef5:	call   40ea20 <__swc_fn_7dafa2b1_000074_518516c2>
  40befa:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40bf03:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40bf0c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40bf15:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40bf1e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40bf27:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40bf30:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40bf39:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40bf42:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40bf4b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40bf54:	add    rsp,0x188
  40bf5b:	pop    rsi
  40bf5c:	pop    rdi
  40bf5d:	pop    r15
  40bf5f:	pop    r14
  40bf61:	pop    r13
  40bf63:	pop    r12
  40bf65:	ret
	...

000000000040bf70 <__swc_fn_7dafa2b1_000076_9f0c6acf>:
  40bf70:	sub    rsp,0x8
  40bf74:	mov    rax,rdx
  40bf77:	mov    rdx,QWORD PTR [rax+0x40]
  40bf7b:	mov    r8,rax
  40bf7e:	call   40bb70 <__swc_fn_7dafa2b1_000067_94a51053>
  40bf83:	add    rsp,0x8
  40bf87:	ret
	...

000000000040bf90 <__swc_fn_7dafa2b1_000079_34776ded>:
  40bf90:	push   rsi
  40bf91:	push   rdi
  40bf92:	sub    rsp,0x8
  40bf96:	cmp    rcx,0xffffffffffffffef
  40bf9a:	ja     40bfc0 <__swc_fn_7dafa2b1_000079_34776ded+0x30>
  40bf9c:	xor    esi,esi
  40bf9e:	lea    rax,[rcx+0x100f]
  40bfa5:	and    rax,0xfffffffffffff000
  40bfac:	lea    rcx,[rcx+0x10]
  40bfb0:	cmp    rcx,0xfffffffffffff000
  40bfb7:	cmovbe rsi,rax
  40bfbb:	test   rsi,rsi
  40bfbe:	jne    40bfc9 <__swc_fn_7dafa2b1_000079_34776ded+0x39>
  40bfc0:	xor    eax,eax
  40bfc2:	add    rsp,0x8
  40bfc6:	pop    rdi
  40bfc7:	pop    rsi
  40bfc8:	ret
  40bfc9:	mov    rcx,rsi
  40bfcc:	call   40c620 <__swc_fn_7dafa2b1_000109_8d425bd3>
  40bfd1:	mov    rdi,rax
  40bfd4:	test   rax,rax
  40bfd7:	jne    40bfe2 <__swc_fn_7dafa2b1_000079_34776ded+0x52>
  40bfd9:	xor    eax,eax
  40bfdb:	add    rsp,0x8
  40bfdf:	pop    rdi
  40bfe0:	pop    rsi
  40bfe1:	ret
  40bfe2:	mov    rcx,rdi
  40bfe5:	mov    rdx,rsi
  40bfe8:	call   409260 <__swc_fn_7dafa2b1_000111_b25e3a45>
  40bfed:	test   al,al
  40bfef:	jne    40c005 <__swc_fn_7dafa2b1_000079_34776ded+0x75>
  40bff1:	mov    rcx,rdi
  40bff4:	mov    rdx,rsi
  40bff7:	call   40fb80 <__swc_fn_7dafa2b1_000113_49b378a9>
  40bffc:	xor    eax,eax
  40bffe:	add    rsp,0x8
  40c002:	pop    rdi
  40c003:	pop    rsi
  40c004:	ret
  40c005:	mov    QWORD PTR [rdi],rsi
  40c008:	mov    QWORD PTR [rdi+0x8],0x0
  40c010:	lea    rax,[rdi+0x10]
  40c014:	add    rsp,0x8
  40c018:	pop    rdi
  40c019:	pop    rsi
  40c01a:	ret
  40c01b:	add    BYTE PTR [rax],al
  40c01d:	add    BYTE PTR [rax],al
	...

000000000040c020 <__swc_fn_7dafa2b1_000082_754dcd57>:
  40c020:	sub    rsp,0x8
  40c024:	cmp    BYTE PTR [rcx+0x2c],0x10
  40c028:	jne    40c033 <__swc_fn_7dafa2b1_000082_754dcd57+0x13>
  40c02a:	test   DWORD PTR [rcx+0x28],0x80
  40c031:	je     40c03b <__swc_fn_7dafa2b1_000082_754dcd57+0x1b>
  40c033:	mov    rax,rcx
  40c036:	add    rsp,0x8
  40c03a:	ret
  40c03b:	mov    rcx,QWORD PTR [rcx+0x40]
  40c03f:	call   40c020 <__swc_fn_7dafa2b1_000082_754dcd57>
  40c044:	add    rsp,0x8
  40c048:	ret
	...

000000000040c060 <__swc_fn_7dafa2b1_000085_1edf7c76>:
  40c060:	push   rsi
  40c061:	push   rdi
  40c062:	push   r12
  40c064:	push   r13
  40c066:	sub    rsp,0x8
  40c06a:	mov    rsi,rdx
  40c06d:	mov    rdi,rcx
  40c070:	xor    r8d,r8d
  40c073:	call   4085a0 <__swc_fn_7dafa2b1_000090_a2d50c23>
  40c078:	test   al,al
  40c07a:	je     40c08c <__swc_fn_7dafa2b1_000085_1edf7c76+0x2c>
  40c07c:	mov    eax,0x1
  40c081:	add    rsp,0x8
  40c085:	pop    r13
  40c087:	pop    r12
  40c089:	pop    rdi
  40c08a:	pop    rsi
  40c08b:	ret
  40c08c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c091:	je     40c0a0 <__swc_fn_7dafa2b1_000085_1edf7c76+0x40>
  40c093:	xor    eax,eax
  40c095:	add    rsp,0x8
  40c099:	pop    r13
  40c09b:	pop    r12
  40c09d:	pop    rdi
  40c09e:	pop    rsi
  40c09f:	ret
  40c0a0:	mov    r12,QWORD PTR [rsi+0x98]
  40c0a7:	mov    rax,QWORD PTR [rsi+0xa0]
  40c0ae:	mov    rsi,rax
  40c0b1:	xor    r13d,r13d
  40c0b4:	test   rsi,rsi
  40c0b7:	je     40c114 <__swc_fn_7dafa2b1_000085_1edf7c76+0xb4>
  40c0b9:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0c3:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0cd:	nop    DWORD PTR [rax]
  40c0d0:	lea    rax,[r13*8+0x0]
  40c0d8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c0dd:	mov    rcx,rax
  40c0e0:	call   40c020 <__swc_fn_7dafa2b1_000082_754dcd57>
  40c0e5:	cmp    BYTE PTR [rax+0x2c],0xe
  40c0e9:	jne    40c10a <__swc_fn_7dafa2b1_000085_1edf7c76+0xaa>
  40c0eb:	mov    rcx,rdi
  40c0ee:	mov    rdx,rax
  40c0f1:	call   40c060 <__swc_fn_7dafa2b1_000085_1edf7c76>
  40c0f6:	test   al,al
  40c0f8:	je     40c10a <__swc_fn_7dafa2b1_000085_1edf7c76+0xaa>
  40c0fa:	mov    eax,0x1
  40c0ff:	add    rsp,0x8
  40c103:	pop    r13
  40c105:	pop    r12
  40c107:	pop    rdi
  40c108:	pop    rsi
  40c109:	ret
  40c10a:	add    r13,0x1
  40c10e:	sub    rsi,0x1
  40c112:	jne    40c0d0 <__swc_fn_7dafa2b1_000085_1edf7c76+0x70>
  40c114:	xor    eax,eax
  40c116:	add    rsp,0x8
  40c11a:	pop    r13
  40c11c:	pop    r12
  40c11e:	pop    rdi
  40c11f:	pop    rsi
  40c120:	ret
	...

000000000040c130 <__swc_fn_7dafa2b1_000088_fcb34f6a>:
  40c130:	sub    rsp,0x18
  40c134:	vxorps xmm0,xmm0,xmm0
  40c138:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c13d:	call   40ec30 <__swc_fn_7dafa2b1_000089_386582f3>
  40c142:	add    rsp,0x18
  40c146:	ret
	...

000000000040c150 <__swc_fn_7dafa2b1_000091_3d2f5a0d>:
  40c150:	sub    rsp,0x8
  40c154:	mov    rcx,QWORD PTR [rip+0x19be5]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c15b:	test   rcx,rcx
  40c15e:	jne    40c170 <__swc_fn_7dafa2b1_000091_3d2f5a0d+0x20>
  40c160:	call   40a1d0 <__swc_fn_7dafa2b1_000165_cf398896>
  40c165:	lea    rcx,[rax+0x1]
  40c169:	mov    QWORD PTR [rip+0x19bd0],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c170:	dec    rcx
  40c173:	call   4119a0 <__swc_fn_7dafa2b1_000167_fce60b2b>
  40c178:	mov    rax,QWORD PTR [rax+0xc0]
  40c17f:	and    eax,0x1
  40c182:	setne  al
  40c185:	add    rsp,0x8
  40c189:	ret
	...

000000000040c1a0 <__swc_fn_7dafa2b1_000094_14db3cf9>:
  40c1a0:	push   rbx
  40c1a1:	push   rsi
  40c1a2:	push   rdi
  40c1a3:	push   r12
  40c1a5:	sub    rsp,0x28
  40c1a9:	mov    rbx,rcx
  40c1ac:	call   408900 <__swc_fn_7dafa2b1_000093_f8c16535>
  40c1b1:	mov    rcx,QWORD PTR [rip+0x19b88]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c1b8:	test   rcx,rcx
  40c1bb:	jne    40c1cd <__swc_fn_7dafa2b1_000094_14db3cf9+0x2d>
  40c1bd:	call   40a1d0 <__swc_fn_7dafa2b1_000165_cf398896>
  40c1c2:	lea    rcx,[rax+0x1]
  40c1c6:	mov    QWORD PTR [rip+0x19b73],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c1cd:	dec    rcx
  40c1d0:	call   4119a0 <__swc_fn_7dafa2b1_000167_fce60b2b>
  40c1d5:	mov    rsi,rax
  40c1d8:	lea    rcx,[rsp+0x8]
  40c1dd:	call   40f070 <__swc_fn_7dafa2b1_000092_8252f8c0>
  40c1e2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c1e9:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c1f0:	lea    rcx,[rsi+0x10]
  40c1f4:	call   40d180 <__swc_fn_7dafa2b1_000157_232ffa22>
  40c1f9:	mov    rcx,rsi
  40c1fc:	call   40f1e0 <__swc_fn_7dafa2b1_000101_eab3874f>
  40c201:	vxorps xmm0,xmm0,xmm0
  40c205:	xor    eax,eax
  40c207:	cs nop WORD PTR [rax+rax*1+0x0]
  40c211:	cs nop WORD PTR [rax+rax*1+0x0]
  40c21b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c220:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c225:	add    rax,0x10
  40c229:	cmp    rax,0xbf0
  40c230:	jne    40c220 <__swc_fn_7dafa2b1_000094_14db3cf9+0x80>
  40c232:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c238:	vmovups XMMWORD PTR [rsi],xmm0
  40c23c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c242:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c24a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c251:	mov    QWORD PTR [rsi+0xbe8],r12
  40c258:	mov    rcx,QWORD PTR [rip+0x19ae1]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c25f:	test   rcx,rcx
  40c262:	jne    40c274 <__swc_fn_7dafa2b1_000094_14db3cf9+0xd4>
  40c264:	call   40a1d0 <__swc_fn_7dafa2b1_000165_cf398896>
  40c269:	lea    rcx,[rax+0x1]
  40c26d:	mov    QWORD PTR [rip+0x19acc],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c274:	dec    rcx
  40c277:	call   4119a0 <__swc_fn_7dafa2b1_000167_fce60b2b>
  40c27c:	mov    rsi,rax
  40c27f:	mov    QWORD PTR [rsi+0xc0],rbx
  40c286:	and    ebx,0x1
  40c289:	jne    40c28d <__swc_fn_7dafa2b1_000094_14db3cf9+0xed>
  40c28b:	xor    eax,eax
  40c28d:	test   rbx,rbx
  40c290:	sete   al
  40c293:	xor    cl,cl
  40c295:	xor    dl,dl
  40c297:	xor    r8b,r8b
  40c29a:	xor    r9b,r9b
  40c29d:	xor    r10b,r10b
  40c2a0:	mov    r11,rax
  40c2a3:	call   40ea30 <__swc_fn_7dafa2b1_000077_8b8614a7>
  40c2a8:	lea    rbx,[rsp+0x18]
  40c2ad:	mov    rcx,rbx
  40c2b0:	call   40f070 <__swc_fn_7dafa2b1_000092_8252f8c0>
  40c2b5:	lea    rcx,[rsi+0x10]
  40c2b9:	mov    edx,0x400000
  40c2be:	mov    r8,rbx
  40c2c1:	call   409f10 <__swc_fn_7dafa2b1_000159_d8afac28>
  40c2c6:	lea    rcx,[rsi+0x68]
  40c2ca:	mov    edx,0x4000
  40c2cf:	mov    r8,rbx
  40c2d2:	call   409f10 <__swc_fn_7dafa2b1_000159_d8afac28>
  40c2d7:	add    rsp,0x28
  40c2db:	pop    r12
  40c2dd:	pop    rdi
  40c2de:	pop    rsi
  40c2df:	pop    rbx
  40c2e0:	ret
	...

000000000040c2f0 <__swc_fn_7dafa2b1_000097_4c97e0db>:
  40c2f0:	push   rbx
  40c2f1:	push   rsi
  40c2f2:	sub    rsp,0x18
  40c2f6:	mov    rbx,rcx
  40c2f9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c2fe:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c304:	mov    rsi,QWORD PTR [rbx+0x70]
  40c308:	lea    rcx,[rcx+0x18]
  40c30c:	call   40d180 <__swc_fn_7dafa2b1_000157_232ffa22>
  40c311:	lea    rcx,[rsp+0x8]
  40c316:	mov    rdx,rbx
  40c319:	mov    r8d,0x78
  40c31f:	call   408960 <__swc_fn_7dafa2b1_000096_ad982b35>
  40c324:	mov    rax,rsi
  40c327:	add    rsp,0x18
  40c32b:	pop    rsi
  40c32c:	pop    rbx
  40c32d:	ret
	...

000000000040c330 <__swc_fn_7dafa2b1_000100_3ed08774>:
  40c330:	push   rsi
  40c331:	push   rdi
  40c332:	sub    rsp,0x8
  40c336:	cmp    QWORD PTR [rcx],0x0
  40c33a:	jne    40c343 <__swc_fn_7dafa2b1_000100_3ed08774+0x13>
  40c33c:	add    rsp,0x8
  40c340:	pop    rdi
  40c341:	pop    rsi
  40c342:	ret
  40c343:	mov    rsi,QWORD PTR [rcx]
  40c346:	mov    rax,QWORD PTR [rcx+0x8]
  40c34a:	test   rax,rax
  40c34d:	je     40c363 <__swc_fn_7dafa2b1_000100_3ed08774+0x33>
  40c34f:	test   DWORD PTR [rax+0x28],0x400000
  40c356:	je     40c363 <__swc_fn_7dafa2b1_000100_3ed08774+0x33>
  40c358:	mov    rcx,QWORD PTR [rax+0x30]
  40c35c:	test   rcx,rcx
  40c35f:	cmovne rax,rcx
  40c363:	lea    rdx,[rip+0x5e66]        # 4121d0 <__swc_rdata_base_7dafa2b1+0xc0>
  40c36a:	lea    rcx,[rip+0x5f47]        # 4122b8 <__swc_rdata_base_7dafa2b1+0x1a8>
  40c371:	mov    r8,rax
  40c374:	xor    r9d,r9d
  40c377:	xor    al,al
  40c379:	mov    r10,rax
  40c37c:	xor    r11d,r11d
  40c37f:	call   40c130 <__swc_fn_7dafa2b1_000088_fcb34f6a>
  40c384:	test   rax,rax
  40c387:	je     40c397 <__swc_fn_7dafa2b1_000100_3ed08774+0x67>
  40c389:	mov    rdi,QWORD PTR [rax+0x48]
  40c38d:	test   rdi,rdi
  40c390:	je     40c397 <__swc_fn_7dafa2b1_000100_3ed08774+0x67>
  40c392:	mov    rcx,rsi
  40c395:	call   rdi
  40c397:	add    rsp,0x8
  40c39b:	pop    rdi
  40c39c:	pop    rsi
  40c39d:	ret
	...

000000000040c3a0 <__swc_fn_7dafa2b1_000103_67100064>:
  40c3a0:	push   rbx
  40c3a1:	push   rsi
  40c3a2:	push   rdi
  40c3a3:	sub    rsp,0x20
  40c3a7:	mov    rbx,rdx
  40c3aa:	mov    rsi,rcx
  40c3ad:	mov    rcx,QWORD PTR [rip+0x1998c]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c3b4:	test   rcx,rcx
  40c3b7:	jne    40c3c9 <__swc_fn_7dafa2b1_000103_67100064+0x29>
  40c3b9:	call   40a1d0 <__swc_fn_7dafa2b1_000165_cf398896>
  40c3be:	lea    rcx,[rax+0x1]
  40c3c2:	mov    QWORD PTR [rip+0x19977],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c3c9:	dec    rcx
  40c3cc:	call   4119a0 <__swc_fn_7dafa2b1_000167_fce60b2b>
  40c3d1:	mov    rdi,rax
  40c3d4:	mov    rax,QWORD PTR [rdi+0xbd0]
  40c3db:	xor    ecx,ecx
  40c3dd:	test   rax,rax
  40c3e0:	je     40c3e5 <__swc_fn_7dafa2b1_000103_67100064+0x45>
  40c3e2:	mov    rcx,QWORD PTR [rax]
  40c3e5:	call   40a300 <__swc_fn_7dafa2b1_000174_176517f9>
  40c3ea:	lea    rax,[rsp+0x8]
  40c3ef:	lea    rcx,[rdi+0x9c8]
  40c3f6:	mov    QWORD PTR [rsp+0x8],rcx
  40c3fb:	mov    QWORD PTR [rax+0x8],0x40
  40c403:	xor    ecx,ecx
  40c405:	mov    rdx,rax
  40c408:	call   40fcc0 <__swc_fn_7dafa2b1_000119_9175a56a>
  40c40d:	mov    DWORD PTR [rdi+0xbc8],eax
  40c413:	mov    rdi,QWORD PTR [rdi+0x990]
  40c41a:	test   rdi,rdi
  40c41d:	je     40c427 <__swc_fn_7dafa2b1_000103_67100064+0x87>
  40c41f:	mov    rcx,rsi
  40c422:	mov    rdx,rbx
  40c425:	call   rdi
  40c427:	call   40c150 <__swc_fn_7dafa2b1_000091_3d2f5a0d>
  40c42c:	test   al,al
  40c42e:	je     40c43e <__swc_fn_7dafa2b1_000103_67100064+0x9e>
  40c430:	mov    rcx,rsi
  40c433:	mov    rdx,rbx
  40c436:	xor    r8d,r8d
  40c439:	call   409400 <__swc_fn_7dafa2b1_000120_ea68f292>
  40c43e:	mov    rcx,rsi
  40c441:	mov    rdx,rbx
  40c444:	call   408a80 <__swc_fn_7dafa2b1_000102_e9fdc18e>
  40c449:	call   40c9d0 <__swc_fn_7dafa2b1_000118_7f430081>
  40c44e:	add    rsp,0x20
  40c452:	pop    rdi
  40c453:	pop    rsi
  40c454:	pop    rbx
  40c455:	ret
	...

000000000040c460 <__swc_fn_7dafa2b1_000106_ed4b1681>:
  40c460:	test   r8,r8
  40c463:	jne    40c468 <__swc_fn_7dafa2b1_000106_ed4b1681+0x8>
  40c465:	xor    eax,eax
  40c467:	ret
  40c468:	xor    eax,eax
  40c46a:	nop    WORD PTR [rax+rax*1+0x0]
  40c470:	mov    r9,r8
  40c473:	sub    r9,rax
  40c476:	cmp    r9,0x10
  40c47a:	jb     40c4c4 <__swc_fn_7dafa2b1_000106_ed4b1681+0x64>
  40c47c:	lea    r9,[rcx+rax*1]
  40c480:	lea    r10,[rdx+rax*1]
  40c484:	vmovups xmm0,XMMWORD PTR [r10]
  40c489:	vmovups xmm1,XMMWORD PTR [r9]
  40c48e:	vpcmpeqb xmm0,xmm1,xmm0
  40c492:	vpmovmskb r9d,xmm0
  40c496:	cmp    r9d,0xffff
  40c49d:	je     40c4be <__swc_fn_7dafa2b1_000106_ed4b1681+0x5e>
  40c49f:	not    r9d
  40c4a2:	xor    r8d,r8d
  40c4a5:	movzx  r9d,r9w
  40c4a9:	tzcnt  r8d,r9d
  40c4ae:	add    rax,r8
  40c4b1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4b5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4b9:	sub    ecx,eax
  40c4bb:	mov    eax,ecx
  40c4bd:	ret
  40c4be:	lea    rax,[rax+0x10]
  40c4c2:	jmp    40c470 <__swc_fn_7dafa2b1_000106_ed4b1681+0x10>
  40c4c4:	cmp    r9,0x8
  40c4c8:	jb     40c53b <__swc_fn_7dafa2b1_000106_ed4b1681+0xdb>
  40c4ca:	lea    r9,[rcx+rax*1]
  40c4ce:	lea    r10,[rdx+rax*1]
  40c4d2:	mov    r9,QWORD PTR [r9]
  40c4d5:	xor    r9,QWORD PTR [r10]
  40c4d8:	test   r9,r9
  40c4db:	je     40c4f9 <__swc_fn_7dafa2b1_000106_ed4b1681+0x99>
  40c4dd:	xor    r8d,r8d
  40c4e0:	tzcnt  r8,r9
  40c4e5:	shr    r8,0x3
  40c4e9:	add    rax,r8
  40c4ec:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4f0:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4f4:	sub    ecx,eax
  40c4f6:	mov    eax,ecx
  40c4f8:	ret
  40c4f9:	lea    rax,[rax+0x8]
  40c4fd:	cmp    rax,r8
  40c500:	jne    40c505 <__swc_fn_7dafa2b1_000106_ed4b1681+0xa5>
  40c502:	xor    eax,eax
  40c504:	ret
  40c505:	lea    rax,[r8-0x8]
  40c509:	lea    r8,[rcx+rax*1]
  40c50d:	lea    r9,[rdx+rax*1]
  40c511:	mov    r8,QWORD PTR [r8]
  40c514:	xor    r8,QWORD PTR [r9]
  40c517:	test   r8,r8
  40c51a:	je     40c538 <__swc_fn_7dafa2b1_000106_ed4b1681+0xd8>
  40c51c:	xor    r9d,r9d
  40c51f:	tzcnt  r9,r8
  40c524:	shr    r9,0x3
  40c528:	add    rax,r9
  40c52b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c52f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c533:	sub    ecx,eax
  40c535:	mov    eax,ecx
  40c537:	ret
  40c538:	xor    eax,eax
  40c53a:	ret
  40c53b:	cmp    r9,0x4
  40c53f:	jb     40c5b2 <__swc_fn_7dafa2b1_000106_ed4b1681+0x152>
  40c541:	lea    r9,[rcx+rax*1]
  40c545:	lea    r10,[rdx+rax*1]
  40c549:	mov    r9d,DWORD PTR [r9]
  40c54c:	xor    r9d,DWORD PTR [r10]
  40c54f:	test   r9d,r9d
  40c552:	je     40c570 <__swc_fn_7dafa2b1_000106_ed4b1681+0x110>
  40c554:	xor    r8d,r8d
  40c557:	tzcnt  r8,r9
  40c55c:	shr    r8,0x3
  40c560:	add    rax,r8
  40c563:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c567:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c56b:	sub    ecx,eax
  40c56d:	mov    eax,ecx
  40c56f:	ret
  40c570:	lea    rax,[rax+0x4]
  40c574:	cmp    rax,r8
  40c577:	jne    40c57c <__swc_fn_7dafa2b1_000106_ed4b1681+0x11c>
  40c579:	xor    eax,eax
  40c57b:	ret
  40c57c:	lea    rax,[r8-0x4]
  40c580:	lea    r8,[rcx+rax*1]
  40c584:	lea    r9,[rdx+rax*1]
  40c588:	mov    r8d,DWORD PTR [r8]
  40c58b:	xor    r8d,DWORD PTR [r9]
  40c58e:	test   r8d,r8d
  40c591:	je     40c5af <__swc_fn_7dafa2b1_000106_ed4b1681+0x14f>
  40c593:	xor    r9d,r9d
  40c596:	tzcnt  r9,r8
  40c59b:	shr    r9,0x3
  40c59f:	add    rax,r9
  40c5a2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5a6:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5aa:	sub    ecx,eax
  40c5ac:	mov    eax,ecx
  40c5ae:	ret
  40c5af:	xor    eax,eax
  40c5b1:	ret
  40c5b2:	cmp    r9,0x2
  40c5b6:	jb     40c609 <__swc_fn_7dafa2b1_000106_ed4b1681+0x1a9>
  40c5b8:	lea    r9,[rcx+rax*1]
  40c5bc:	lea    r10,[rdx+rax*1]
  40c5c0:	mov    r9w,WORD PTR [r9]
  40c5c4:	xor    r9w,WORD PTR [r10]
  40c5c8:	test   r9w,r9w
  40c5cc:	je     40c5ee <__swc_fn_7dafa2b1_000106_ed4b1681+0x18e>
  40c5ce:	xor    r8d,r8d
  40c5d1:	movzx  r9d,r9w
  40c5d5:	tzcnt  r8,r9
  40c5da:	shr    r8,0x3
  40c5de:	add    rax,r8
  40c5e1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5e5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5e9:	sub    ecx,eax
  40c5eb:	mov    eax,ecx
  40c5ed:	ret
  40c5ee:	lea    rax,[rax+0x2]
  40c5f2:	cmp    rax,r8
  40c5f5:	jne    40c5fa <__swc_fn_7dafa2b1_000106_ed4b1681+0x19a>
  40c5f7:	xor    eax,eax
  40c5f9:	ret
  40c5fa:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40c600:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40c606:	sub    eax,ecx
  40c608:	ret
  40c609:	test   r9,r9
  40c60c:	je     40c61b <__swc_fn_7dafa2b1_000106_ed4b1681+0x1bb>
  40c60e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c612:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c616:	sub    ecx,eax
  40c618:	mov    eax,ecx
  40c61a:	ret
  40c61b:	xor    eax,eax
  40c61d:	ret
	...

000000000040c620 <__swc_fn_7dafa2b1_000109_8d425bd3>:
  40c620:	push   r12
  40c622:	push   r13
  40c624:	push   r14
  40c626:	push   rdi
  40c627:	push   rsi
  40c628:	push   r15
  40c62a:	sub    rsp,0xd8
  40c631:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c637:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c63d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c643:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c649:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c64f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c658:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c661:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c66a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c673:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c67c:	mov    r12,rcx
  40c67f:	test   rcx,rcx
  40c682:	je     40c69e <__swc_fn_7dafa2b1_000109_8d425bd3+0x7e>
  40c684:	mov    eax,r12d
  40c687:	and    eax,0xfff
  40c68d:	setne  al
  40c690:	cmp    r12,0xffffffffffffefff
  40c697:	seta   cl
  40c69a:	or     al,cl
  40c69c:	je     40c6a5 <__swc_fn_7dafa2b1_000109_8d425bd3+0x85>
  40c69e:	xor    eax,eax
  40c6a0:	jmp    40c73b <__swc_fn_7dafa2b1_000109_8d425bd3+0x11b>
  40c6a5:	call   409120 <__swc_fn_7dafa2b1_000108_84af7666>
  40c6aa:	mov    r13,rax
  40c6ad:	test   rax,rax
  40c6b0:	jne    40c6b9 <__swc_fn_7dafa2b1_000109_8d425bd3+0x99>
  40c6b2:	xor    eax,eax
  40c6b4:	jmp    40c73b <__swc_fn_7dafa2b1_000109_8d425bd3+0x11b>
  40c6b9:	lea    r14,[r12+0x1000]
  40c6c1:	xor    edi,edi
  40c6c3:	mov    rsi,r14
  40c6c6:	xor    edx,edx
  40c6c8:	mov    ecx,0x22
  40c6cd:	mov    eax,0xffffffff
  40c6d2:	movsxd r8,eax
  40c6d5:	xor    r9d,r9d
  40c6d8:	xor    eax,eax
  40c6da:	call   4070c0 <mmap@plt>
  40c6df:	mov    r15,rax
  40c6e2:	cmp    rax,0xffffffffffffffff
  40c6e6:	jne    40c6ec <__swc_fn_7dafa2b1_000109_8d425bd3+0xcc>
  40c6e8:	xor    eax,eax
  40c6ea:	jmp    40c73b <__swc_fn_7dafa2b1_000109_8d425bd3+0x11b>
  40c6ec:	mov    rdi,r15
  40c6ef:	mov    esi,0x1000
  40c6f4:	mov    edx,0x3
  40c6f9:	xor    eax,eax
  40c6fb:	call   407030 <mprotect@plt>
  40c700:	test   eax,eax
  40c702:	je     40c715 <__swc_fn_7dafa2b1_000109_8d425bd3+0xf5>
  40c704:	mov    rdi,r15
  40c707:	mov    rsi,r14
  40c70a:	xor    eax,eax
  40c70c:	call   407020 <munmap@plt>
  40c711:	xor    eax,eax
  40c713:	jmp    40c73b <__swc_fn_7dafa2b1_000109_8d425bd3+0x11b>
  40c715:	mov    QWORD PTR [r15+0x8],r12
  40c719:	mov    rcx,r13
  40c71c:	call   40cd70 <__swc_fn_7dafa2b1_000133_4b2af8da>
  40c721:	mov    rax,QWORD PTR [r13+0x8]
  40c725:	mov    QWORD PTR [r15],rax
  40c728:	mov    QWORD PTR [r13+0x8],r15
  40c72c:	mov    rcx,r13
  40c72f:	call   410060 <__swc_fn_7dafa2b1_000134_29412410>
  40c734:	lea    rax,[r15+0x1000]
  40c73b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c741:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c747:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c74d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c753:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c759:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c762:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c76b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c774:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c77d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c786:	add    rsp,0xd8
  40c78d:	pop    r15
  40c78f:	pop    rsi
  40c790:	pop    rdi
  40c791:	pop    r14
  40c793:	pop    r13
  40c795:	pop    r12
  40c797:	ret
	...

000000000040c7a0 <__swc_fn_7dafa2b1_000112_759e9ceb>:
  40c7a0:	push   rbx
  40c7a1:	push   r12
  40c7a3:	push   rdi
  40c7a4:	push   rsi
  40c7a5:	sub    rsp,0xa8
  40c7ac:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c7b2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c7b8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c7be:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c7c4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c7ca:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c7d0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c7d6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c7dc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c7e5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c7ee:	mov    rbx,rdx
  40c7f1:	mov    r12,rcx
  40c7f4:	mov    rdi,rcx
  40c7f7:	mov    rsi,rdx
  40c7fa:	xor    edx,edx
  40c7fc:	xor    eax,eax
  40c7fe:	call   407030 <mprotect@plt>
  40c803:	test   eax,eax
  40c805:	jne    40c829 <__swc_fn_7dafa2b1_000112_759e9ceb+0x89>
  40c807:	mov    rcx,r12
  40c80a:	mov    rdx,rbx
  40c80d:	xor    al,al
  40c80f:	mov    r8,rax
  40c812:	call   40faf0 <__swc_fn_7dafa2b1_000110_a808fe76>
  40c817:	mov    rdi,r12
  40c81a:	mov    rsi,rbx
  40c81d:	mov    edx,0x4
  40c822:	xor    eax,eax
  40c824:	call   4070e0 <madvise@plt>
  40c829:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c82f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c835:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c83b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40c841:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40c847:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40c84d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40c853:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40c859:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40c862:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40c86b:	add    rsp,0xa8
  40c872:	pop    rsi
  40c873:	pop    rdi
  40c874:	pop    r12
  40c876:	pop    rbx
  40c877:	ret
	...

000000000040c880 <__swc_fn_7dafa2b1_000115_1ba33335>:
  40c880:	push   rsi
  40c881:	push   rdi
  40c882:	push   r12
  40c884:	push   r13
  40c886:	push   r14
  40c888:	sub    rsp,0xe0
  40c88f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c895:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c89b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c8a1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c8a7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c8ad:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c8b6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c8bf:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c8c8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c8d1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c8da:	mov    rsi,rdx
  40c8dd:	mov    rdi,rcx
  40c8e0:	call   409120 <__swc_fn_7dafa2b1_000108_84af7666>
  40c8e5:	mov    r12,rax
  40c8e8:	test   rax,rax
  40c8eb:	jne    40c8f2 <__swc_fn_7dafa2b1_000115_1ba33335+0x72>
  40c8ed:	jmp    40c966 <__swc_fn_7dafa2b1_000115_1ba33335+0xe6>
  40c8f2:	mov    rcx,r12
  40c8f5:	call   40cd70 <__swc_fn_7dafa2b1_000133_4b2af8da>
  40c8fa:	lea    r13,[r12+0x8]
  40c8ff:	mov    rax,QWORD PTR [r13+0x0]
  40c903:	test   rax,rax
  40c906:	je     40c95e <__swc_fn_7dafa2b1_000115_1ba33335+0xde>
  40c908:	nop    DWORD PTR [rax+rax*1+0x0]
  40c910:	lea    rcx,[rax+0x1000]
  40c917:	cmp    rcx,rdi
  40c91a:	jne    40c952 <__swc_fn_7dafa2b1_000115_1ba33335+0xd2>
  40c91c:	cmp    QWORD PTR [rax+0x8],rsi
  40c920:	je     40c92c <__swc_fn_7dafa2b1_000115_1ba33335+0xac>
  40c922:	mov    rcx,r12
  40c925:	call   410060 <__swc_fn_7dafa2b1_000134_29412410>
  40c92a:	jmp    40c966 <__swc_fn_7dafa2b1_000115_1ba33335+0xe6>
  40c92c:	mov    r14,QWORD PTR [rax]
  40c92f:	mov    rdi,rax
  40c932:	lea    rsi,[rsi+0x1000]
  40c939:	xor    eax,eax
  40c93b:	call   407020 <munmap@plt>
  40c940:	test   eax,eax
  40c942:	jne    40c948 <__swc_fn_7dafa2b1_000115_1ba33335+0xc8>
  40c944:	mov    QWORD PTR [r13+0x0],r14
  40c948:	mov    rcx,r12
  40c94b:	call   410060 <__swc_fn_7dafa2b1_000134_29412410>
  40c950:	jmp    40c966 <__swc_fn_7dafa2b1_000115_1ba33335+0xe6>
  40c952:	mov    r13,rax
  40c955:	mov    rax,QWORD PTR [r13+0x0]
  40c959:	test   rax,rax
  40c95c:	jne    40c910 <__swc_fn_7dafa2b1_000115_1ba33335+0x90>
  40c95e:	mov    rcx,r12
  40c961:	call   410060 <__swc_fn_7dafa2b1_000134_29412410>
  40c966:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c96c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c972:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c978:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c97e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c984:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c98d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c996:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c99f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c9a8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c9b1:	add    rsp,0xe0
  40c9b8:	pop    r14
  40c9ba:	pop    r13
  40c9bc:	pop    r12
  40c9be:	pop    rdi
  40c9bf:	pop    rsi
  40c9c0:	ret
	...

000000000040c9d0 <__swc_fn_7dafa2b1_000118_7f430081>:
  40c9d0:	push   rdi
  40c9d1:	push   rsi
  40c9d2:	sub    rsp,0xa8
  40c9d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c9df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c9e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c9eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c9f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c9f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c9fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ca03:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ca09:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ca12:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ca1b:	mov    rdi,0xfffffffffffffd66
  40ca22:	xor    eax,eax
  40ca24:	call   407040 <exit@plt>
  40ca29:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ca2f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ca35:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ca3b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ca41:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ca47:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ca4d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ca53:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ca59:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ca62:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ca6b:	add    rsp,0xa8
  40ca72:	pop    rsi
  40ca73:	pop    rdi
  40ca74:	ret
	...

000000000040ca80 <__swc_fn_7dafa2b1_000121_12b4ed22>:
  40ca80:	push   rbx
  40ca81:	push   rsi
  40ca82:	push   rdi
  40ca83:	sub    rsp,0x30
  40ca87:	mov    rbx,rdx
  40ca8a:	mov    esi,ecx
  40ca8c:	test   ecx,ecx
  40ca8e:	je     40cb63 <__swc_fn_7dafa2b1_000121_12b4ed22+0xe3>
  40ca94:	mov    rcx,rsi
  40ca97:	shl    rcx,0x4
  40ca9b:	call   40bf90 <__swc_fn_7dafa2b1_000079_34776ded>
  40caa0:	test   rax,rax
  40caa3:	je     40cb52 <__swc_fn_7dafa2b1_000121_12b4ed22+0xd2>
  40caa9:	mov    rcx,rsi
  40caac:	xor    edx,edx
  40caae:	test   rsi,rsi
  40cab1:	jbe    40cb32 <__swc_fn_7dafa2b1_000121_12b4ed22+0xb2>
  40cab7:	nop    WORD PTR [rax+rax*1+0x0]
  40cac0:	mov    r8d,edx
  40cac3:	mov    r9,QWORD PTR [rbx+r8*8]
  40cac7:	add    r8,r8
  40caca:	lea    r8,[rax+r8*8]
  40cace:	xor    r10d,r10d
  40cad1:	test   r9,r9
  40cad4:	je     40cb10 <__swc_fn_7dafa2b1_000121_12b4ed22+0x90>
  40cad6:	mov    r11,r9
  40cad9:	mov    dil,BYTE PTR [r11]
  40cadc:	test   dil,dil
  40cadf:	je     40cb10 <__swc_fn_7dafa2b1_000121_12b4ed22+0x90>
  40cae1:	cs nop WORD PTR [rax+rax*1+0x0]
  40caeb:	cs nop WORD PTR [rax+rax*1+0x0]
  40caf5:	cs nop WORD PTR [rax+rax*1+0x0]
  40caff:	nop
  40cb00:	add    r11,0x1
  40cb04:	add    r10,0x1
  40cb08:	mov    dil,BYTE PTR [r11]
  40cb0b:	test   dil,dil
  40cb0e:	jne    40cb00 <__swc_fn_7dafa2b1_000121_12b4ed22+0x80>
  40cb10:	mov    QWORD PTR [rsp+0x18],r9
  40cb15:	mov    QWORD PTR [rsp+0x20],r10
  40cb1a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40cb20:	vmovups XMMWORD PTR [r8],xmm0
  40cb25:	add    rdx,0x1
  40cb29:	cmp    rdx,rcx
  40cb2c:	jb     40cac0 <__swc_fn_7dafa2b1_000121_12b4ed22+0x40>
  40cb32:	lea    rcx,[rip+0x19217]        # 425d50 <__swc_bss_base_7dafa2b1+0x2d10>
  40cb39:	mov    QWORD PTR [rsp+0x8],rax
  40cb3e:	mov    esi,esi
  40cb40:	mov    QWORD PTR [rsp+0x10],rsi
  40cb45:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40cb4b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cb50:	jmp    40cb63 <__swc_fn_7dafa2b1_000121_12b4ed22+0xe3>
  40cb52:	lea    rcx,[rip+0x59c7]        # 412520 <__swc_rdata_base_7dafa2b1+0x410>
  40cb59:	call   40fba0 <__swc_fn_7dafa2b1_000116_035d76a1>
  40cb5e:	call   40c9d0 <__swc_fn_7dafa2b1_000118_7f430081>
  40cb63:	add    rsp,0x30
  40cb67:	pop    rdi
  40cb68:	pop    rsi
  40cb69:	pop    rbx
  40cb6a:	ret
  40cb6b:	add    BYTE PTR [rax],al
  40cb6d:	add    BYTE PTR [rax],al
	...

000000000040cb70 <__swc_fn_7dafa2b1_000124_667fbf24>:
  40cb70:	push   rdi
  40cb71:	push   rsi
  40cb72:	sub    rsp,0xa8
  40cb79:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cb7f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cb85:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cb8b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cb91:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cb97:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cb9d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cba3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cba9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cbb2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cbbb:	mov    edi,ecx
  40cbbd:	xor    eax,eax
  40cbbf:	call   4070f0 <pthread_key_delete@plt>
  40cbc4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cbca:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cbd0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cbd6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cbdc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cbe2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cbe8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cbee:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cbf4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cbfd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cc06:	add    rsp,0xa8
  40cc0d:	pop    rsi
  40cc0e:	pop    rdi
  40cc0f:	ret

000000000040cc10 <__swc_fn_7dafa2b1_000127_8dffa290>:
  40cc10:	push   rdi
  40cc11:	push   rsi
  40cc12:	sub    rsp,0xa8
  40cc19:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cc1f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cc25:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cc2b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cc31:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cc37:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cc3d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cc43:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cc49:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cc52:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cc5b:	test   rcx,rcx
  40cc5e:	je     40cc6f <__swc_fn_7dafa2b1_000127_8dffa290+0x5f>
  40cc60:	lea    rax,[rcx-0x1]
  40cc64:	mov    eax,eax
  40cc66:	mov    edi,eax
  40cc68:	xor    eax,eax
  40cc6a:	call   4070f0 <pthread_key_delete@plt>
  40cc6f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cc75:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cc7b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cc81:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cc87:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cc8d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cc93:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cc99:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cc9f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cca8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ccb1:	add    rsp,0xa8
  40ccb8:	pop    rsi
  40ccb9:	pop    rdi
  40ccba:	ret
  40ccbb:	add    BYTE PTR [rax],al
  40ccbd:	add    BYTE PTR [rax],al
	...

000000000040ccc0 <__swc_fn_7dafa2b1_000130_c1196dfb>:
  40ccc0:	push   rsi
  40ccc1:	push   rdi
  40ccc2:	sub    rsp,0xa8
  40ccc9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cccf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ccd5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ccdb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cce1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cce7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cced:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ccf3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ccf9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cd02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cd0b:	xor    eax,eax
  40cd0d:	call   407100 <gettid@plt>
  40cd12:	movsxd rax,eax
  40cd15:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cd1b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cd21:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cd27:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cd2d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cd33:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cd39:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cd3f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cd45:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cd4e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cd57:	add    rsp,0xa8
  40cd5e:	pop    rdi
  40cd5f:	pop    rsi
  40cd60:	ret
	...

000000000040cd70 <__swc_fn_7dafa2b1_000133_4b2af8da>:
  40cd70:	push   rbx
  40cd71:	push   rdi
  40cd72:	push   rsi
  40cd73:	sub    rsp,0xc0
  40cd7a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40cd80:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40cd86:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cd8c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40cd92:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40cd98:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cd9e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cda4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cdad:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40cdb6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cdbf:	mov    rbx,rcx
  40cdc2:	cs nop WORD PTR [rax+rax*1+0x0]
  40cdcc:	nop    DWORD PTR [rax+0x0]
  40cdd0:	mov    edx,0x80000000
  40cdd5:	xor    eax,eax
  40cdd7:	lock cmpxchg DWORD PTR [rbx],edx
  40cddb:	test   eax,eax
  40cddd:	je     40ce14 <__swc_fn_7dafa2b1_000133_4b2af8da+0xa4>
  40cddf:	mov    eax,DWORD PTR [rbx]
  40cde1:	lea    rcx,[rsp+0x14]
  40cde6:	mov    DWORD PTR [rsp+0x14],eax
  40cdea:	test   eax,eax
  40cdec:	je     40cdd0 <__swc_fn_7dafa2b1_000133_4b2af8da+0x60>
  40cdee:	mov    QWORD PTR [rsp],0x0
  40cdf6:	mov    edi,0xca
  40cdfb:	mov    rsi,rbx
  40cdfe:	mov    edx,0x80
  40ce03:	mov    ecx,DWORD PTR [rcx]
  40ce05:	xor    r8d,r8d
  40ce08:	xor    r9d,r9d
  40ce0b:	xor    eax,eax
  40ce0d:	call   407070 <syscall@plt>
  40ce12:	jmp    40cdd0 <__swc_fn_7dafa2b1_000133_4b2af8da+0x60>
  40ce14:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ce1a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ce20:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ce26:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ce2c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ce32:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ce38:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ce3e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ce47:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ce50:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ce59:	add    rsp,0xc0
  40ce60:	pop    rsi
  40ce61:	pop    rdi
  40ce62:	pop    rbx
  40ce63:	ret
	...

000000000040ce70 <__swc_fn_7dafa2b1_000136_3e875c27>:
  40ce70:	sub    rsp,0x8
  40ce74:	call   410060 <__swc_fn_7dafa2b1_000134_29412410>
  40ce79:	add    rsp,0x8
  40ce7d:	ret
	...

000000000040ce80 <__swc_fn_7dafa2b1_000139_7c02fe26>:
  40ce80:	push   rdi
  40ce81:	push   rsi
  40ce82:	sub    rsp,0xa8
  40ce89:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ce8f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ce95:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ce9b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cea1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cea7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cead:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ceb3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ceb9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cec2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cecb:	mov    edi,0x28
  40ced0:	xor    eax,eax
  40ced2:	call   4070d0 <malloc@plt>
  40ced7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cedd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cee3:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cee9:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ceef:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cef5:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cefb:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cf01:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cf07:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cf10:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cf19:	add    rsp,0xa8
  40cf20:	pop    rsi
  40cf21:	pop    rdi
  40cf22:	ret
	...

000000000040cf30 <__swc_fn_7dafa2b1_000142_56e56812>:
  40cf30:	mov    QWORD PTR [r8],0x0
  40cf37:	cmp    rdx,0x10
  40cf3b:	jae    40cf40 <__swc_fn_7dafa2b1_000142_56e56812+0x10>
  40cf3d:	xor    eax,eax
  40cf3f:	ret
  40cf40:	mov    eax,DWORD PTR [rcx]
  40cf42:	cmp    eax,0x42445753
  40cf48:	jne    40cf52 <__swc_fn_7dafa2b1_000142_56e56812+0x22>
  40cf4a:	mov    eax,DWORD PTR [rcx+0x4]
  40cf4d:	cmp    eax,0x1
  40cf50:	je     40cf55 <__swc_fn_7dafa2b1_000142_56e56812+0x25>
  40cf52:	xor    eax,eax
  40cf54:	ret
  40cf55:	mov    QWORD PTR [r8],rdx
  40cf58:	mov    rax,rcx
  40cf5b:	ret
  40cf5c:	add    BYTE PTR [rax],al
	...

000000000040cf60 <__swc_fn_7dafa2b1_000145_863755b5>:
  40cf60:	push   rbx
  40cf61:	sub    rsp,0xe0
  40cf68:	lea    rbx,[rsp+0x8]
  40cf6d:	vxorps xmm0,xmm0,xmm0
  40cf71:	vmovups XMMWORD PTR [rbx],xmm0
  40cf75:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40cf7a:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40cf7f:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40cf84:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40cf89:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  40cf8e:	mov    DWORD PTR [rbx+0x60],0x0
  40cf95:	mov    r8,rbx
  40cf98:	mov    rdx,rcx
  40cf9b:	nop    DWORD PTR [rax+rax*1+0x0]
  40cfa0:	mov    r9,rdx
  40cfa3:	movabs rdx,0x6666666666666667
  40cfad:	mov    rax,r9
  40cfb0:	imul   rdx
  40cfb3:	sar    rdx,0x2
  40cfb7:	mov    r10,rdx
  40cfba:	shr    rdx,0x3f
  40cfbe:	add    r10,rdx
  40cfc1:	mov    rdx,r10
  40cfc4:	imul   r11,r10,0xa
  40cfc8:	sub    r9,r11
  40cfcb:	mov    r11,QWORD PTR [rip+0x556e]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  40cfd2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40cfd7:	mov    BYTE PTR [r8],r9b
  40cfda:	lea    r9,[r8+0x1]
  40cfde:	mov    r8,r9
  40cfe1:	test   r10,r10
  40cfe4:	jne    40cfa0 <__swc_fn_7dafa2b1_000145_863755b5+0x40>
  40cfe6:	test   rcx,rcx
  40cfe9:	jge    40cff3 <__swc_fn_7dafa2b1_000145_863755b5+0x93>
  40cfeb:	mov    BYTE PTR [r9],0x2d
  40cfef:	add    r8,0x1
  40cff3:	mov    BYTE PTR [r8],0x0
  40cff7:	sub    r8,0x1
  40cffb:	mov    rax,rbx
  40cffe:	cmp    rax,r8
  40d001:	jae    40d026 <__swc_fn_7dafa2b1_000145_863755b5+0xc6>
  40d003:	cs nop WORD PTR [rax+rax*1+0x0]
  40d00d:	nop    DWORD PTR [rax]
  40d010:	mov    cl,BYTE PTR [r8]
  40d013:	mov    dl,BYTE PTR [rax]
  40d015:	mov    BYTE PTR [r8],dl
  40d018:	sub    r8,0x1
  40d01c:	mov    BYTE PTR [rax],cl
  40d01e:	inc    rax
  40d021:	cmp    rax,r8
  40d024:	jb     40d010 <__swc_fn_7dafa2b1_000145_863755b5+0xb0>
  40d026:	xor    eax,eax
  40d028:	test   rbx,rbx
  40d02b:	je     40d04e <__swc_fn_7dafa2b1_000145_863755b5+0xee>
  40d02d:	mov    rcx,rbx
  40d030:	mov    dl,BYTE PTR [rcx]
  40d032:	test   dl,dl
  40d034:	je     40d04e <__swc_fn_7dafa2b1_000145_863755b5+0xee>
  40d036:	cs nop WORD PTR [rax+rax*1+0x0]
  40d040:	add    rcx,0x1
  40d044:	add    rax,0x1
  40d048:	mov    dl,BYTE PTR [rcx]
  40d04a:	test   dl,dl
  40d04c:	jne    40d040 <__swc_fn_7dafa2b1_000145_863755b5+0xe0>
  40d04e:	mov    QWORD PTR [rbx+0xa8],rbx
  40d055:	mov    QWORD PTR [rbx+0xb0],rax
  40d05c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d064:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d06c:	lea    rcx,[rbx+0xb8]
  40d073:	call   40fba0 <__swc_fn_7dafa2b1_000116_035d76a1>
  40d078:	add    rsp,0xe0
  40d07f:	pop    rbx
  40d080:	ret
	...

000000000040d090 <__swc_fn_7dafa2b1_000148_9e4bc402>:
  40d090:	vxorps xmm0,xmm0,xmm0
  40d094:	vmovups XMMWORD PTR [rcx],xmm0
  40d098:	mov    QWORD PTR [rcx+0x10],0x0
  40d0a0:	ret
	...

000000000040d0b0 <__swc_fn_7dafa2b1_000151_9e4bc402>:
  40d0b0:	vxorps xmm0,xmm0,xmm0
  40d0b4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0bd:	vxorps xmm0,xmm0,xmm0
  40d0c1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0c6:	vmovups xmm0,XMMWORD PTR [rip+0x556a]        # 412638 <__swc_rdata_base_7dafa2b1+0x528>
  40d0ce:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d0d3:	vxorps xmm0,xmm0,xmm0
  40d0d7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d0dc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d0e1:	mov    QWORD PTR [rcx+0x60],0x0
  40d0e9:	ret
  40d0ea:	add    BYTE PTR [rax],al
  40d0ec:	add    BYTE PTR [rax],al
	...

000000000040d0f0 <__swc_fn_7dafa2b1_000154_9e4bc402>:
  40d0f0:	vxorps xmm0,xmm0,xmm0
  40d0f4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0f8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0fd:	vxorps xmm0,xmm0,xmm0
  40d101:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d106:	vmovups xmm0,XMMWORD PTR [rip+0x5652]        # 412760 <__swc_rdata_base_7dafa2b1+0x650>
  40d10e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d113:	vxorps xmm0,xmm0,xmm0
  40d117:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d11c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d121:	vxorps xmm0,xmm0,xmm0
  40d125:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d12a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d12f:	vxorps xmm0,xmm0,xmm0
  40d133:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d13b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d143:	vxorps xmm0,xmm0,xmm0
  40d147:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d14f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d157:	vxorps xmm0,xmm0,xmm0
  40d15b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d163:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d16b:	mov    QWORD PTR [rcx+0xe0],0x0
  40d176:	ret
	...

000000000040d180 <__swc_fn_7dafa2b1_000157_232ffa22>:
  40d180:	push   rbx
  40d181:	mov    rbx,rcx
  40d184:	call   411630 <__swc_fn_7dafa2b1_000158_b43b2f96>
  40d189:	mov    rax,QWORD PTR [rbx+0x10]
  40d18d:	test   rax,rax
  40d190:	je     40d1a1 <__swc_fn_7dafa2b1_000157_232ffa22+0x21>
  40d192:	mov    rcx,rbx
  40d195:	mov    rdx,rax
  40d198:	mov    r8,QWORD PTR [rbx+0x18]
  40d19c:	call   409ec0 <__swc_fn_7dafa2b1_000156_2745c4a5>
  40d1a1:	vxorps xmm0,xmm0,xmm0
  40d1a5:	vmovups XMMWORD PTR [rbx],xmm0
  40d1a9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d1ae:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d1b3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d1b8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d1bd:	mov    QWORD PTR [rbx+0x50],0x0
  40d1c5:	pop    rbx
  40d1c6:	ret
	...

000000000040d1e0 <__swc_fn_7dafa2b1_000160_01cbb887>:
  40d1e0:	sub    rsp,0x10
  40d1e4:	mov    eax,r8d
  40d1e7:	mov    r8d,r9d
  40d1ea:	test   r9d,r9d
  40d1ed:	jne    40d206 <__swc_fn_7dafa2b1_000160_01cbb887+0x26>
  40d1ef:	vmovups xmm0,XMMWORD PTR [rip+0x5621]        # 412818 <__swc_rdata_base_7dafa2b1+0x708>
  40d1f7:	vmovups XMMWORD PTR [r10],xmm0
  40d1fc:	mov    eax,0x1
  40d201:	add    rsp,0x10
  40d205:	ret
  40d206:	mov    r9,r8
  40d209:	cmp    r8,rax
  40d20c:	jb     40d213 <__swc_fn_7dafa2b1_000160_01cbb887+0x33>
  40d20e:	cmp    r9,rdx
  40d211:	jb     40d21a <__swc_fn_7dafa2b1_000160_01cbb887+0x3a>
  40d213:	xor    eax,eax
  40d215:	add    rsp,0x10
  40d219:	ret
  40d21a:	xor    eax,eax
  40d21c:	lea    r8,[r9+rax*1]
  40d220:	cmp    r8,rdx
  40d223:	jae    40d253 <__swc_fn_7dafa2b1_000160_01cbb887+0x73>
  40d225:	cs nop WORD PTR [rax+rax*1+0x0]
  40d22f:	cs nop WORD PTR [rax+rax*1+0x0]
  40d239:	nop    DWORD PTR [rax+0x0]
  40d240:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d245:	je     40d253 <__swc_fn_7dafa2b1_000160_01cbb887+0x73>
  40d247:	inc    rax
  40d24a:	lea    r8,[r9+rax*1]
  40d24e:	cmp    r8,rdx
  40d251:	jb     40d240 <__swc_fn_7dafa2b1_000160_01cbb887+0x60>
  40d253:	cmp    r8,rdx
  40d256:	jne    40d25f <__swc_fn_7dafa2b1_000160_01cbb887+0x7f>
  40d258:	xor    eax,eax
  40d25a:	add    rsp,0x10
  40d25e:	ret
  40d25f:	add    rcx,r9
  40d262:	mov    QWORD PTR [rsp],rcx
  40d266:	mov    QWORD PTR [rsp+0x8],rax
  40d26b:	vmovups xmm0,XMMWORD PTR [rsp]
  40d270:	vmovups XMMWORD PTR [r10],xmm0
  40d275:	mov    eax,0x1
  40d27a:	add    rsp,0x10
  40d27e:	ret
	...

000000000040d280 <__swc_fn_7dafa2b1_000163_8e41797b>:
  40d280:	push   rbp
  40d281:	push   rbx
  40d282:	push   rsi
  40d283:	push   rdi
  40d284:	push   r12
  40d286:	push   r13
  40d288:	push   r14
  40d28a:	push   r15
  40d28c:	sub    rsp,0x10
  40d290:	mov    rbp,rsp
  40d293:	vmovups XMMWORD PTR [rsp],xmm6
  40d298:	sub    rsp,0x50
  40d29c:	mov    rbx,rsp
  40d29f:	mov    rsi,r8
  40d2a2:	mov    QWORD PTR [rsp+0x30],r8
  40d2a7:	mov    rdi,rcx
  40d2aa:	mov    QWORD PTR [rsp+0x38],rcx
  40d2af:	mov    r12,rdx
  40d2b2:	xor    r13b,r13b
  40d2b5:	mov    r14,QWORD PTR [rdi+0x8]
  40d2b9:	mov    QWORD PTR [rsp+0x40],r14
  40d2be:	xor    r15d,r15d
  40d2c1:	test   r14,r14
  40d2c4:	jbe    40d51e <__swc_fn_7dafa2b1_000163_8e41797b+0x29e>
  40d2ca:	mov    r14,QWORD PTR [rdi]
  40d2cd:	mov    rax,QWORD PTR [rsp+0x40]
  40d2d2:	mov    QWORD PTR [rsp+0x48],r14
  40d2d7:	vmovups xmm6,XMMWORD PTR [rip+0x5159]        # 412438 <__swc_rdata_base_7dafa2b1+0x328>
  40d2df:	nop
  40d2e0:	cmp    QWORD PTR [r14+r15*8],0x0
  40d2e5:	jne    40d2ef <__swc_fn_7dafa2b1_000163_8e41797b+0x6f>
  40d2e7:	mov    r14,rax
  40d2ea:	jmp    40d4fe <__swc_fn_7dafa2b1_000163_8e41797b+0x27e>
  40d2ef:	mov    rcx,QWORD PTR [rdi]
  40d2f2:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d2f6:	mov    rdi,rbx
  40d2f9:	mov    rcx,rdi
  40d2fc:	sub    rsp,0x8
  40d300:	mov    r14,rax
  40d303:	call   409f40 <__swc_fn_7dafa2b1_000162_60216e69>
  40d308:	add    rsp,0x8
  40d30c:	mov    al,BYTE PTR [rbx]
  40d30e:	test   al,al
  40d310:	je     40d4fe <__swc_fn_7dafa2b1_000163_8e41797b+0x27e>
  40d316:	mov    al,BYTE PTR [rbx+0x1]
  40d319:	test   al,al
  40d31b:	jne    40d326 <__swc_fn_7dafa2b1_000163_8e41797b+0xa6>
  40d31d:	test   sil,sil
  40d320:	je     40d4fe <__swc_fn_7dafa2b1_000163_8e41797b+0x27e>
  40d326:	test   r13b,r13b
  40d329:	jne    40d3e7 <__swc_fn_7dafa2b1_000163_8e41797b+0x167>
  40d32f:	test   r12,r12
  40d332:	je     40d3e7 <__swc_fn_7dafa2b1_000163_8e41797b+0x167>
  40d338:	mov    al,BYTE PTR [rbx+0x1]
  40d33b:	test   al,al
  40d33d:	je     40d4fe <__swc_fn_7dafa2b1_000163_8e41797b+0x27e>
  40d343:	mov    eax,DWORD PTR [rbx+0x28]
  40d346:	cmp    DWORD PTR [r12+0x20],eax
  40d34b:	jne    40d4fe <__swc_fn_7dafa2b1_000163_8e41797b+0x27e>
  40d351:	mov    rax,QWORD PTR [r12]
  40d355:	mov    rcx,QWORD PTR [r12+0x8]
  40d35a:	cmp    QWORD PTR [rbx+0x20],rcx
  40d35e:	jne    40d4fe <__swc_fn_7dafa2b1_000163_8e41797b+0x27e>
  40d364:	mov    cl,0x1
  40d366:	test   rax,rax
  40d369:	je     40d3d2 <__swc_fn_7dafa2b1_000163_8e41797b+0x152>
  40d36f:	mov    rdx,QWORD PTR [rbx+0x20]
  40d373:	xor    r8d,r8d
  40d376:	test   rdx,rdx
  40d379:	jbe    40d3d2 <__swc_fn_7dafa2b1_000163_8e41797b+0x152>
  40d37b:	mov    r9,QWORD PTR [rbx+0x18]
  40d37f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40d384:	cs nop WORD PTR [rax+rax*1+0x0]
  40d38e:	xchg   ax,ax
  40d390:	mov    r10b,BYTE PTR [rax+r8*1]
  40d394:	cmp    BYTE PTR [r9+r8*1],r10b
  40d398:	je     40d3c9 <__swc_fn_7dafa2b1_000163_8e41797b+0x149>
  40d39a:	vmovq  r10,xmm0
  40d39f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40d3a4:	jne    40d3ad <__swc_fn_7dafa2b1_000163_8e41797b+0x12d>
  40d3a6:	cmp    BYTE PTR [rax+r8*1],0x2f
  40d3ab:	je     40d3c9 <__swc_fn_7dafa2b1_000163_8e41797b+0x149>
  40d3ad:	vmovq  r10,xmm0
  40d3b2:	cmp    BYTE PTR [r10+r8*1],0x2f
  40d3b7:	jne    40d3c0 <__swc_fn_7dafa2b1_000163_8e41797b+0x140>
  40d3b9:	cmp    BYTE PTR [rax+r8*1],0x5c
  40d3be:	je     40d3c9 <__swc_fn_7dafa2b1_000163_8e41797b+0x149>
  40d3c0:	xor    eax,eax
  40d3c2:	movzx  eax,al
  40d3c5:	mov    cl,al
  40d3c7:	jmp    40d3d2 <__swc_fn_7dafa2b1_000163_8e41797b+0x152>
  40d3c9:	add    r8,0x1
  40d3cd:	cmp    r8,rdx
  40d3d0:	jb     40d390 <__swc_fn_7dafa2b1_000163_8e41797b+0x110>
  40d3d2:	test   cl,cl
  40d3d4:	je     40d4fe <__swc_fn_7dafa2b1_000163_8e41797b+0x27e>
  40d3da:	mov    eax,0x1
  40d3df:	mov    r13b,al
  40d3e2:	jmp    40d4fe <__swc_fn_7dafa2b1_000163_8e41797b+0x27e>
  40d3e7:	mov    r13b,0x1
  40d3ea:	sub    rsp,0x20
  40d3ee:	mov    rax,rsp
  40d3f1:	lea    rcx,[rdi+0x8]
  40d3f5:	mov    QWORD PTR [rax],rcx
  40d3f8:	lea    rsi,[rip+0x4f11]        # 412310 <__swc_rdata_base_7dafa2b1+0x200>
  40d3ff:	mov    QWORD PTR [rax+0x8],rsi
  40d403:	mov    QWORD PTR [rax+0x10],rsp
  40d407:	mov    QWORD PTR [rax+0x18],0x1
  40d40f:	lea    rcx,[rsp+0x10]
  40d414:	sub    rsp,0x8
  40d418:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  40d41d:	add    rsp,0x8
  40d421:	add    rsp,0x20
  40d425:	mov    al,BYTE PTR [rbx+0x1]
  40d428:	test   al,al
  40d42a:	je     40d4c7 <__swc_fn_7dafa2b1_000163_8e41797b+0x247>
  40d430:	lea    rax,[rip+0x5481]        # 4128b8 <__swc_rdata_base_7dafa2b1+0x7a8>
  40d437:	sub    rsp,0x20
  40d43b:	mov    rcx,rsp
  40d43e:	mov    QWORD PTR [rcx],rax
  40d441:	mov    QWORD PTR [rcx+0x8],rsi
  40d445:	mov    QWORD PTR [rcx+0x10],rsp
  40d449:	mov    QWORD PTR [rcx+0x18],0x1
  40d451:	lea    rcx,[rsp+0x10]
  40d456:	sub    rsp,0x8
  40d45a:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  40d45f:	add    rsp,0x8
  40d463:	add    rsp,0x20
  40d467:	mov    eax,DWORD PTR [rbx+0x28]
  40d46a:	sub    rsp,0x60
  40d46e:	mov    rcx,rsp
  40d471:	lea    rdx,[rdi+0x18]
  40d475:	mov    QWORD PTR [rcx+0x18],rdx
  40d479:	mov    QWORD PTR [rcx+0x20],rsi
  40d47d:	vmovups XMMWORD PTR [rcx],xmm6
  40d481:	mov    QWORD PTR [rcx+0x28],rsp
  40d485:	mov    QWORD PTR [rcx+0x30],rsi
  40d489:	mov    DWORD PTR [rcx+0x10],eax
  40d48c:	lea    rax,[rsp+0x10]
  40d491:	mov    QWORD PTR [rcx+0x38],rax
  40d495:	lea    rax,[rip+0x4f34]        # 4123d0 <__swc_rdata_base_7dafa2b1+0x2c0>
  40d49c:	mov    QWORD PTR [rcx+0x40],rax
  40d4a0:	lea    rax,[rsp+0x18]
  40d4a5:	mov    QWORD PTR [rcx+0x48],rax
  40d4a9:	mov    QWORD PTR [rcx+0x50],0x3
  40d4b1:	lea    rcx,[rsp+0x48]
  40d4b6:	sub    rsp,0x8
  40d4ba:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  40d4bf:	add    rsp,0x8
  40d4c3:	add    rsp,0x60
  40d4c7:	lea    rax,[rip+0x4e9a]        # 412368 <__swc_rdata_base_7dafa2b1+0x258>
  40d4ce:	sub    rsp,0x20
  40d4d2:	mov    rcx,rsp
  40d4d5:	mov    QWORD PTR [rcx],rax
  40d4d8:	mov    QWORD PTR [rcx+0x8],rsi
  40d4dc:	mov    QWORD PTR [rcx+0x10],rsp
  40d4e0:	mov    QWORD PTR [rcx+0x18],0x1
  40d4e8:	lea    rcx,[rsp+0x10]
  40d4ed:	sub    rsp,0x8
  40d4f1:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  40d4f6:	add    rsp,0x8
  40d4fa:	add    rsp,0x20
  40d4fe:	add    r15,0x1
  40d502:	cmp    r15,r14
  40d505:	jae    40d51e <__swc_fn_7dafa2b1_000163_8e41797b+0x29e>
  40d507:	mov    rsi,QWORD PTR [rsp+0x30]
  40d50c:	mov    rdi,QWORD PTR [rsp+0x38]
  40d511:	mov    rax,r14
  40d514:	mov    r14,QWORD PTR [rsp+0x48]
  40d519:	jmp    40d2e0 <__swc_fn_7dafa2b1_000163_8e41797b+0x60>
  40d51e:	add    rsp,0x50
  40d522:	vmovups xmm6,XMMWORD PTR [rsp]
  40d527:	add    rsp,0x10
  40d52b:	pop    r15
  40d52d:	pop    r14
  40d52f:	pop    r13
  40d531:	pop    r12
  40d533:	pop    rdi
  40d534:	pop    rsi
  40d535:	pop    rbx
  40d536:	pop    rbp
  40d537:	ret
	...

000000000040d540 <__swc_fn_7dafa2b1_000166_f6173642>:
  40d540:	sub    rsp,0x8
  40d544:	call   40fe30 <__swc_fn_7dafa2b1_000125_ce762363>
  40d549:	add    rsp,0x8
  40d54d:	ret
	...

000000000040d550 <__swc_fn_7dafa2b1_000169_4579a84c>:
  40d550:	push   rsi
  40d551:	sub    rsp,0x30
  40d555:	lea    rsi,[rip+0x18844]        # 425da0 <__swc_bss_base_7dafa2b1+0x2d60>
  40d55c:	mov    rax,QWORD PTR [rsi]
  40d55f:	test   rax,rax
  40d562:	je     40d56a <__swc_fn_7dafa2b1_000169_4579a84c+0x1a>
  40d564:	add    rsp,0x30
  40d568:	pop    rsi
  40d569:	ret
  40d56a:	mov    ecx,0x2
  40d56f:	mov    edx,0x8020
  40d574:	call   40f4a0 <__swc_fn_7dafa2b1_000107_4796e893>
  40d579:	test   rax,rax
  40d57c:	jne    40d58d <__swc_fn_7dafa2b1_000169_4579a84c+0x3d>
  40d57e:	mov    QWORD PTR [rsp+0x18],rax
  40d583:	call   40c9d0 <__swc_fn_7dafa2b1_000118_7f430081>
  40d588:	mov    rax,QWORD PTR [rsp+0x18]
  40d58d:	mov    rcx,rax
  40d590:	xchg   QWORD PTR [rsi],rcx
  40d593:	add    rsp,0x30
  40d597:	pop    rsi
  40d598:	ret
  40d599:	add    BYTE PTR [rax],al
  40d59b:	add    BYTE PTR [rax],al
  40d59d:	add    BYTE PTR [rax],al
	...

000000000040d5a0 <__swc_fn_7dafa2b1_000172_97fbc432>:
  40d5a0:	push   rsi
  40d5a1:	test   r8,r8
  40d5a4:	jne    40d5a8 <__swc_fn_7dafa2b1_000172_97fbc432+0x8>
  40d5a6:	pop    rsi
  40d5a7:	ret
  40d5a8:	lea    rax,[rcx+0x18]
  40d5ac:	mov    r10,QWORD PTR [rax]
  40d5af:	lea    r11,[r10+0x1]
  40d5b3:	mov    QWORD PTR [rax],r11
  40d5b6:	mov    r11,rdx
  40d5b9:	not    rdx
  40d5bc:	lea    rsi,[r8-0x1]
  40d5c0:	cmp    rsi,rdx
  40d5c3:	ja     40d5e3 <__swc_fn_7dafa2b1_000172_97fbc432+0x43>
  40d5c5:	lea    rdx,[r11+r8*1]
  40d5c9:	dec    rdx
  40d5cc:	shr    rdx,0x6
  40d5d0:	mov    r8,r11
  40d5d3:	shr    r8,0x6
  40d5d7:	mov    rsi,rdx
  40d5da:	sub    rsi,r8
  40d5dd:	cmp    rsi,0x8
  40d5e1:	jb     40d5f9 <__swc_fn_7dafa2b1_000172_97fbc432+0x59>
  40d5e3:	lea    rcx,[rcx+0x10]
  40d5e7:	mov    rdx,QWORD PTR [rcx]
  40d5ea:	add    rdx,r9
  40d5ed:	mov    QWORD PTR [rcx],rdx
  40d5f0:	lea    rcx,[r10+0x2]
  40d5f4:	mov    QWORD PTR [rax],rcx
  40d5f7:	pop    rsi
  40d5f8:	ret
  40d5f9:	shr    r11,0x6
  40d5fd:	nop    DWORD PTR [rax]
  40d600:	cmp    r11,rdx
  40d603:	ja     40d643 <__swc_fn_7dafa2b1_000172_97fbc432+0xa3>
  40d605:	jmp    40d616 <__swc_fn_7dafa2b1_000172_97fbc432+0x76>
  40d607:	nop    WORD PTR [rax+rax*1+0x0]
  40d610:	add    r11,0x1
  40d614:	jmp    40d600 <__swc_fn_7dafa2b1_000172_97fbc432+0x60>
  40d616:	mov    r8,r11
  40d619:	shr    r8,0xc
  40d61d:	mov    rsi,r11
  40d620:	xor    rsi,r8
  40d623:	mov    r8,r11
  40d626:	shr    r8,0x18
  40d62a:	xor    rsi,r8
  40d62d:	and    esi,0xfff
  40d633:	lea    r8,[rcx+rsi*8+0x20]
  40d638:	mov    rsi,QWORD PTR [r8]
  40d63b:	add    rsi,r9
  40d63e:	mov    QWORD PTR [r8],rsi
  40d641:	jmp    40d610 <__swc_fn_7dafa2b1_000172_97fbc432+0x70>
  40d643:	lea    rcx,[r10+0x2]
  40d647:	mov    QWORD PTR [rax],rcx
  40d64a:	pop    rsi
  40d64b:	ret
  40d64c:	add    BYTE PTR [rax],al
	...

000000000040d650 <__swc_fn_7dafa2b1_000175_82999b37>:
  40d650:	push   rbx
  40d651:	push   rsi
  40d652:	sub    rsp,0x68
  40d656:	mov    rbx,rcx
  40d659:	lea    rsi,[rsp+0x8]
  40d65e:	vxorps xmm0,xmm0,xmm0
  40d662:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d668:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40d66e:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40d674:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40d67a:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40d680:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40d686:	mov    QWORD PTR [rsp+0x50],0x20
  40d68f:	mov    DWORD PTR [rsp+0x60],0x10
  40d697:	mov    rcx,QWORD PTR [rip+0x186a2]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40d69e:	test   rcx,rcx
  40d6a1:	jne    40d6b3 <__swc_fn_7dafa2b1_000175_82999b37+0x63>
  40d6a3:	call   40a1d0 <__swc_fn_7dafa2b1_000165_cf398896>
  40d6a8:	lea    rcx,[rax+0x1]
  40d6ac:	mov    QWORD PTR [rip+0x1868d],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40d6b3:	dec    rcx
  40d6b6:	call   4119a0 <__swc_fn_7dafa2b1_000167_fce60b2b>
  40d6bb:	mov    rcx,QWORD PTR [rax]
  40d6be:	mov    rdx,rsi
  40d6c1:	mov    rsi,QWORD PTR [rax+0x8]
  40d6c5:	mov    rsi,QWORD PTR [rsi+0x8]
  40d6c9:	call   rsi
  40d6cb:	mov    rax,QWORD PTR [rsp+0x48]
  40d6d0:	test   rax,rax
  40d6d3:	jne    40d6d9 <__swc_fn_7dafa2b1_000175_82999b37+0x89>
  40d6d5:	xor    esi,esi
  40d6d7:	jmp    40d6ed <__swc_fn_7dafa2b1_000175_82999b37+0x9d>
  40d6d9:	mov    rcx,QWORD PTR [rsp+0x50]
  40d6de:	mov    QWORD PTR [rax],rcx
  40d6e1:	mov    QWORD PTR [rax+0x8],0x0
  40d6e9:	lea    rsi,[rax+0x10]
  40d6ed:	test   ebx,ebx
  40d6ef:	jle    40d70a <__swc_fn_7dafa2b1_000175_82999b37+0xba>
  40d6f1:	dec    ebx
  40d6f3:	mov    ecx,ebx
  40d6f5:	call   40d650 <__swc_fn_7dafa2b1_000175_82999b37>
  40d6fa:	mov    QWORD PTR [rsi],rax
  40d6fd:	mov    ecx,ebx
  40d6ff:	call   40d650 <__swc_fn_7dafa2b1_000175_82999b37>
  40d704:	mov    QWORD PTR [rsi+0x8],rax
  40d708:	jmp    40d712 <__swc_fn_7dafa2b1_000175_82999b37+0xc2>
  40d70a:	vxorps xmm0,xmm0,xmm0
  40d70e:	vmovdqu XMMWORD PTR [rsi],xmm0
  40d712:	mov    rax,rsi
  40d715:	add    rsp,0x68
  40d719:	pop    rsi
  40d71a:	pop    rbx
  40d71b:	ret
  40d71c:	add    BYTE PTR [rax],al
	...

000000000040d720 <__swc_fn_7dafa2b1_000178_a6773dec>:
  40d720:	push   rbp
  40d721:	push   rbx
  40d722:	push   rsi
  40d723:	push   rdi
  40d724:	push   r12
  40d726:	push   r13
  40d728:	push   r14
  40d72a:	push   r15
  40d72c:	sub    rsp,0x10
  40d730:	mov    rbp,rsp
  40d733:	vmovups XMMWORD PTR [rsp],xmm6
  40d738:	sub    rsp,0x10
  40d73c:	mov    rbx,rsp
  40d73f:	sub    rsp,0x8
  40d743:	call   411b80 <__swc_fn_7dafa2b1_000179_1ca87929>
  40d748:	vmovups xmm6,xmm0
  40d74c:	mov    ecx,0xd
  40d751:	call   40d650 <__swc_fn_7dafa2b1_000175_82999b37>
  40d756:	mov    rsi,rax
  40d759:	mov    rcx,rax
  40d75c:	call   411b40 <__swc_fn_7dafa2b1_000176_cb8588f1>
  40d761:	mov    rdi,rax
  40d764:	mov    rcx,rsi
  40d767:	call   40a380 <__swc_fn_7dafa2b1_000177_6e6aee58>
  40d76c:	mov    ecx,0xc
  40d771:	call   40d650 <__swc_fn_7dafa2b1_000175_82999b37>
  40d776:	mov    rsi,rax
  40d779:	mov    r12,rbx
  40d77c:	mov    DWORD PTR [rbx],0x4
  40d782:	mov    eax,DWORD PTR [rbx]
  40d784:	cmp    eax,0xc
  40d787:	jg     40d7e6 <__swc_fn_7dafa2b1_000178_a6773dec+0xc6>
  40d789:	nop    DWORD PTR [rax+0x0]
  40d790:	mov    eax,0xc
  40d795:	sub    eax,DWORD PTR [rbx]
  40d797:	mov    r13d,0x1
  40d79d:	lea    ecx,[rax+0x4]
  40d7a0:	shl    r13,cl
  40d7a3:	xor    r14d,r14d
  40d7a6:	test   r13,r13
  40d7a9:	jbe    40d7da <__swc_fn_7dafa2b1_000178_a6773dec+0xba>
  40d7ab:	nop    DWORD PTR [rax+rax*1+0x0]
  40d7b0:	mov    rax,r12
  40d7b3:	movsxd rcx,DWORD PTR [rax]
  40d7b6:	call   40d650 <__swc_fn_7dafa2b1_000175_82999b37>
  40d7bb:	mov    r15,rax
  40d7be:	mov    rcx,rax
  40d7c1:	call   411b40 <__swc_fn_7dafa2b1_000176_cb8588f1>
  40d7c6:	add    rdi,rax
  40d7c9:	mov    rcx,r15
  40d7cc:	call   40a380 <__swc_fn_7dafa2b1_000177_6e6aee58>
  40d7d1:	add    r14,0x1
  40d7d5:	cmp    r14,r13
  40d7d8:	jb     40d7b0 <__swc_fn_7dafa2b1_000178_a6773dec+0x90>
  40d7da:	mov    eax,DWORD PTR [rbx]
  40d7dc:	add    eax,0x2
  40d7df:	mov    DWORD PTR [rbx],eax
  40d7e1:	cmp    eax,0xc
  40d7e4:	jle    40d790 <__swc_fn_7dafa2b1_000178_a6773dec+0x70>
  40d7e6:	mov    rcx,rsi
  40d7e9:	call   411b40 <__swc_fn_7dafa2b1_000176_cb8588f1>
  40d7ee:	add    rdi,rax
  40d7f1:	mov    rcx,rsi
  40d7f4:	call   40a380 <__swc_fn_7dafa2b1_000177_6e6aee58>
  40d7f9:	call   411b80 <__swc_fn_7dafa2b1_000179_1ca87929>
  40d7fe:	vsubsd xmm0,xmm0,xmm6
  40d802:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x51ae]        # 4129b8 <__swc_rdata_base_7dafa2b1+0x8a8>
  40d80a:	lea    rax,[rip+0x4b57]        # 412368 <__swc_rdata_base_7dafa2b1+0x258>
  40d811:	sub    rsp,0x88
  40d818:	mov    rcx,rsp
  40d81b:	vmovups xmm1,XMMWORD PTR [rip+0x5175]        # 412998 <__swc_rdata_base_7dafa2b1+0x888>
  40d823:	vmovups XMMWORD PTR [rcx],xmm1
  40d827:	mov    QWORD PTR [rcx+0x30],rsp
  40d82b:	lea    rdx,[rip+0x4ade]        # 412310 <__swc_rdata_base_7dafa2b1+0x200>
  40d832:	mov    QWORD PTR [rcx+0x38],rdx
  40d836:	mov    QWORD PTR [rcx+0x10],rdi
  40d83a:	lea    r8,[rsp+0x10]
  40d83f:	mov    QWORD PTR [rcx+0x40],r8
  40d843:	lea    r8,[rip+0x50be]        # 412908 <__swc_rdata_base_7dafa2b1+0x7f8>
  40d84a:	mov    QWORD PTR [rcx+0x48],r8
  40d84e:	vmovups xmm1,XMMWORD PTR [rip+0x5152]        # 4129a8 <__swc_rdata_base_7dafa2b1+0x898>
  40d856:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40d85b:	lea    r8,[rsp+0x18]
  40d860:	mov    QWORD PTR [rcx+0x50],r8
  40d864:	mov    QWORD PTR [rcx+0x58],rdx
  40d868:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40d86d:	lea    r8,[rcx+0x28]
  40d871:	mov    QWORD PTR [rcx+0x60],r8
  40d875:	lea    r8,[rip+0x50d4]        # 412950 <__swc_rdata_base_7dafa2b1+0x840>
  40d87c:	mov    QWORD PTR [rcx+0x68],r8
  40d880:	mov    QWORD PTR [rcx+0x70],rax
  40d884:	mov    QWORD PTR [rcx+0x78],rdx
  40d888:	lea    rax,[rcx+0x30]
  40d88c:	mov    QWORD PTR [rcx+0x80],rax
  40d893:	mov    QWORD PTR [rcx+0x88],0x5
  40d89e:	lea    rcx,[rcx+0x80]
  40d8a5:	sub    rsp,0x8
  40d8a9:	call   410420 <__swc_fn_7dafa2b1_000146_43f4fdca>
  40d8ae:	add    rsp,0xa8
  40d8b5:	vmovups xmm6,XMMWORD PTR [rsp]
  40d8ba:	add    rsp,0x10
  40d8be:	pop    r15
  40d8c0:	pop    r14
  40d8c2:	pop    r13
  40d8c4:	pop    r12
  40d8c6:	pop    rdi
  40d8c7:	pop    rsi
  40d8c8:	pop    rbx
  40d8c9:	pop    rbp
  40d8ca:	ret
	...

000000000040d8e0 <__swc_fn_7dafa2b1_000002_884bb5c0>:
  40d8e0:	sub    rsp,0x8
  40d8e4:	call   40c620 <__swc_fn_7dafa2b1_000109_8d425bd3>
  40d8e9:	mov    rcx,rax
  40d8ec:	test   rax,rax
  40d8ef:	je     40d916 <__swc_fn_7dafa2b1_000002_884bb5c0+0x36>
  40d8f1:	lea    rdx,[rip+0x15748]        # 423040 <__swc_bss_base_7dafa2b1>
  40d8f8:	mov    r8,QWORD PTR [rip+0x15741]        # 423040 <__swc_bss_base_7dafa2b1>
  40d8ff:	nop
  40d900:	lea    r9,[r8+0x1]
  40d904:	mov    rax,r8
  40d907:	lock cmpxchg QWORD PTR [rdx],r9
  40d90c:	cmp    rax,r8
  40d90f:	je     40d916 <__swc_fn_7dafa2b1_000002_884bb5c0+0x36>
  40d911:	mov    r8,rax
  40d914:	jmp    40d900 <__swc_fn_7dafa2b1_000002_884bb5c0+0x20>
  40d916:	mov    rax,rcx
  40d919:	add    rsp,0x8
  40d91d:	ret
	...

000000000040d920 <__swc_fn_7dafa2b1_000005_b2240b56>:
  40d920:	mov    r8d,edx
  40d923:	xor    eax,eax
  40d925:	tzcnt  eax,edx
  40d929:	shrx   r9d,edx,eax
  40d92e:	mov    DWORD PTR [rcx+0x2c],edx
  40d931:	xor    eax,eax
  40d933:	tzcnt  eax,edx
  40d937:	mov    BYTE PTR [rcx+0x38],al
  40d93a:	mov    eax,0xffffffff
  40d93f:	xor    edx,edx
  40d941:	div    r8d
  40d944:	mov    DWORD PTR [rcx+0x34],eax
  40d947:	mov    eax,r9d
  40d94a:	mov    edx,r9d
  40d94d:	imul   edx,r9d
  40d951:	mov    r8d,0x2
  40d957:	sub    r8d,edx
  40d95a:	imul   eax,r8d
  40d95e:	mov    edx,r9d
  40d961:	imul   edx,eax
  40d964:	mov    r8d,0x2
  40d96a:	sub    r8d,edx
  40d96d:	imul   eax,r8d
  40d971:	mov    edx,r9d
  40d974:	imul   edx,eax
  40d977:	mov    r8d,0x2
  40d97d:	sub    r8d,edx
  40d980:	imul   eax,r8d
  40d984:	mov    edx,r9d
  40d987:	imul   edx,eax
  40d98a:	mov    r8d,0x2
  40d990:	sub    r8d,edx
  40d993:	imul   eax,r8d
  40d997:	imul   r9d,eax
  40d99b:	mov    edx,0x2
  40d9a0:	sub    edx,r9d
  40d9a3:	imul   eax,edx
  40d9a6:	mov    DWORD PTR [rcx+0x30],eax
  40d9a9:	ret
  40d9aa:	add    BYTE PTR [rax],al
  40d9ac:	add    BYTE PTR [rax],al
	...

000000000040d9b0 <__swc_fn_7dafa2b1_000008_4e857afc>:
  40d9b0:	xor    eax,eax
  40d9b2:	mov    DWORD PTR [rcx+0x68],eax
  40d9b5:	ret
	...

000000000040d9c0 <__swc_fn_7dafa2b1_000011_6493fbbc>:
  40d9c0:	mov    eax,DWORD PTR [rcx+0x28]
  40d9c3:	shlx   eax,edx,eax
  40d9c8:	shl    rax,0x10
  40d9cc:	lea    rdx,[rcx+rax*1]
  40d9d0:	lea    rax,[rcx+0x3000]
  40d9d7:	cmp    rdx,rax
  40d9da:	cmovae rax,rdx
  40d9de:	ret
	...

000000000040d9e0 <__swc_fn_7dafa2b1_000014_afb279e2>:
  40d9e0:	push   rsi
  40d9e1:	push   rdi
  40d9e2:	push   r12
  40d9e4:	push   r13
  40d9e6:	push   r14
  40d9e8:	mov    rsi,rdx
  40d9eb:	mov    rdi,rcx
  40d9ee:	rex mov dl,BYTE PTR [rsi+0x3a]
  40d9f2:	mov    ecx,DWORD PTR [rdi+0x28]
  40d9f5:	shr    dl,cl
  40d9f7:	mov    r12d,0x1
  40d9fd:	mov    ecx,edx
  40d9ff:	shl    r12,cl
  40da02:	mov    r13d,DWORD PTR [rsi+0x3c]
  40da06:	rex mov BYTE PTR [rsi+0x3b],0x0
  40da0b:	mov    QWORD PTR [rsi+0x40],0x0
  40da13:	mov    QWORD PTR [rsi],0x0
  40da1a:	mov    rax,QWORD PTR [rsi+0x10]
  40da1e:	mov    QWORD PTR [rsi+0x20],rax
  40da22:	lea    r14,[rip+0x1561f]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  40da29:	mov    rax,QWORD PTR [r14]
  40da2c:	shr    rax,0x2
  40da30:	mov    rcx,rax
  40da33:	cmp    rax,0x800000
  40da3a:	mov    eax,0x800000
  40da3f:	cmovb  rcx,rax
  40da43:	lea    r8,[rip+0x1560e]        # 423058 <__swc_bss_base_7dafa2b1+0x18>
  40da4a:	mov    rax,QWORD PTR [r8]
  40da4d:	mov    r9,rax
  40da50:	lea    r10,[r9+r13*1]
  40da54:	cmp    r10,rcx
  40da57:	ja     40da7b <__swc_fn_7dafa2b1_000014_afb279e2+0x9b>
  40da59:	mov    rax,r9
  40da5c:	lock cmpxchg QWORD PTR [r8],r10
  40da61:	cmp    rax,r9
  40da64:	je     40da6b <__swc_fn_7dafa2b1_000014_afb279e2+0x8b>
  40da66:	mov    r9,rax
  40da69:	jmp    40da50 <__swc_fn_7dafa2b1_000014_afb279e2+0x70>
  40da6b:	mov    rcx,rdi
  40da6e:	mov    rdx,r12
  40da71:	call   40a750 <__swc_fn_7dafa2b1_000016_4b207b58>
  40da76:	jmp    40dafd <__swc_fn_7dafa2b1_000014_afb279e2+0x11d>
  40da7b:	mov    rcx,rdi
  40da7e:	movzx  edx,dl
  40da81:	call   40d9c0 <__swc_fn_7dafa2b1_000011_6493fbbc>
  40da86:	test   r13,r13
  40da89:	je     40daf6 <__swc_fn_7dafa2b1_000014_afb279e2+0x116>
  40da8f:	mov    rcx,rax
  40da92:	mov    rdx,r13
  40da95:	call   40c7a0 <__swc_fn_7dafa2b1_000112_759e9ceb>
  40da9a:	mov    rcx,QWORD PTR [rip+0x155a7]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  40daa1:	cs nop WORD PTR [rax+rax*1+0x0]
  40daab:	nop    DWORD PTR [rax+rax*1+0x0]
  40dab0:	mov    rdx,rcx
  40dab3:	sub    rdx,r13
  40dab6:	mov    rax,rcx
  40dab9:	lock cmpxchg QWORD PTR [r14],rdx
  40dabe:	cmp    rax,rcx
  40dac1:	je     40dac8 <__swc_fn_7dafa2b1_000014_afb279e2+0xe8>
  40dac3:	mov    rcx,rax
  40dac6:	jmp    40dab0 <__swc_fn_7dafa2b1_000014_afb279e2+0xd0>
  40dac8:	lea    rcx,[rip+0x15591]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  40dacf:	mov    rdx,QWORD PTR [rip+0x1558a]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  40dad6:	cs nop WORD PTR [rax+rax*1+0x0]
  40dae0:	lea    r8,[rdx+0x1]
  40dae4:	mov    rax,rdx
  40dae7:	lock cmpxchg QWORD PTR [rcx],r8
  40daec:	cmp    rax,rdx
  40daef:	je     40daf6 <__swc_fn_7dafa2b1_000014_afb279e2+0x116>
  40daf1:	mov    rdx,rax
  40daf4:	jmp    40dae0 <__swc_fn_7dafa2b1_000014_afb279e2+0x100>
  40daf6:	mov    DWORD PTR [rsi+0x3c],0x0
  40dafd:	mov    rcx,rdi
  40db00:	mov    rdx,r12
  40db03:	call   407600 <__swc_fn_7dafa2b1_000018_7d1e8a10>
  40db08:	pop    r14
  40db0a:	pop    r13
  40db0c:	pop    r12
  40db0e:	pop    rdi
  40db0f:	pop    rsi
  40db10:	ret
	...

000000000040db20 <__swc_fn_7dafa2b1_000017_4df2d1a0>:
  40db20:	mov    r8,QWORD PTR [rcx+0x48]
  40db24:	test   r8,rdx
  40db27:	je     40db58 <__swc_fn_7dafa2b1_000017_4df2d1a0+0x38>
  40db29:	nop    DWORD PTR [rax+0x0]
  40db30:	mov    rax,rdx
  40db33:	not    rax
  40db36:	mov    r9,r8
  40db39:	and    r9,rax
  40db3c:	mov    rax,r8
  40db3f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40db45:	cmp    rax,r8
  40db48:	jne    40db50 <__swc_fn_7dafa2b1_000017_4df2d1a0+0x30>
  40db4a:	mov    eax,0x1
  40db4f:	ret
  40db50:	mov    r8,rax
  40db53:	test   rax,rdx
  40db56:	jne    40db30 <__swc_fn_7dafa2b1_000017_4df2d1a0+0x10>
  40db58:	xor    eax,eax
  40db5a:	ret
  40db5b:	add    BYTE PTR [rax],al
  40db5d:	add    BYTE PTR [rax],al
	...

000000000040db60 <__swc_fn_7dafa2b1_000020_a66e8b97>:
  40db60:	push   rsi
  40db61:	push   rdi
  40db62:	push   r12
  40db64:	push   r13
  40db66:	sub    rsp,0x8
  40db6a:	mov    rsi,rdx
  40db6d:	mov    rdi,rcx
  40db70:	lea    r12,[rip+0x15679]        # 4231f0 <__swc_bss_base_7dafa2b1+0x1b0>
  40db77:	mov    rcx,r12
  40db7a:	call   4098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>
  40db7f:	xor    eax,eax
  40db81:	mov    rcx,QWORD PTR [rip+0x15670]        # 4231f8 <__swc_bss_base_7dafa2b1+0x1b8>
  40db88:	mov    r13,rcx
  40db8b:	test   r13,r13
  40db8e:	je     40dbdb <__swc_fn_7dafa2b1_000020_a66e8b97+0x7b>
  40db90:	mov    rcx,QWORD PTR [r13+0x10]
  40db94:	cmp    DWORD PTR [r13+0x28],esi
  40db98:	jne    40dbd0 <__swc_fn_7dafa2b1_000020_a66e8b97+0x70>
  40db9a:	test   rax,rax
  40db9d:	jne    40dba8 <__swc_fn_7dafa2b1_000020_a66e8b97+0x48>
  40db9f:	mov    QWORD PTR [rip+0x15652],rcx        # 4231f8 <__swc_bss_base_7dafa2b1+0x1b8>
  40dba6:	jmp    40dbac <__swc_fn_7dafa2b1_000020_a66e8b97+0x4c>
  40dba8:	mov    QWORD PTR [rax+0x10],rcx
  40dbac:	vxorps xmm0,xmm0,xmm0
  40dbb0:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40dbb6:	mov    QWORD PTR [r13+0x8],rdi
  40dbba:	mov    rcx,r12
  40dbbd:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  40dbc2:	mov    rax,r13
  40dbc5:	add    rsp,0x8
  40dbc9:	pop    r13
  40dbcb:	pop    r12
  40dbcd:	pop    rdi
  40dbce:	pop    rsi
  40dbcf:	ret
  40dbd0:	mov    rax,r13
  40dbd3:	mov    r13,rcx
  40dbd6:	test   rcx,rcx
  40dbd9:	jne    40db90 <__swc_fn_7dafa2b1_000020_a66e8b97+0x30>
  40dbdb:	mov    ecx,esi
  40dbdd:	call   40a780 <__swc_fn_7dafa2b1_000019_2cc1532c>
  40dbe2:	mov    rsi,rax
  40dbe5:	test   rax,rax
  40dbe8:	jne    40dbff <__swc_fn_7dafa2b1_000020_a66e8b97+0x9f>
  40dbea:	mov    rcx,r12
  40dbed:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  40dbf2:	xor    eax,eax
  40dbf4:	add    rsp,0x8
  40dbf8:	pop    r13
  40dbfa:	pop    r12
  40dbfc:	pop    rdi
  40dbfd:	pop    rsi
  40dbfe:	ret
  40dbff:	mov    QWORD PTR [rsi+0x8],rdi
  40dc03:	mov    rcx,r12
  40dc06:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  40dc0b:	mov    rax,rsi
  40dc0e:	add    rsp,0x8
  40dc12:	pop    r13
  40dc14:	pop    r12
  40dc16:	pop    rdi
  40dc17:	pop    rsi
  40dc18:	ret
  40dc19:	add    BYTE PTR [rax],al
  40dc1b:	add    BYTE PTR [rax],al
  40dc1d:	add    BYTE PTR [rax],al
	...

000000000040dc20 <__swc_fn_7dafa2b1_000023_4aca8b9e>:
  40dc20:	vxorps xmm0,xmm0,xmm0
  40dc24:	xor    eax,eax
  40dc26:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc30:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc3a:	nop    WORD PTR [rax+rax*1+0x0]
  40dc40:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40dc45:	add    rax,0x10
  40dc49:	cmp    rax,0x2b00
  40dc50:	jne    40dc40 <__swc_fn_7dafa2b1_000023_4aca8b9e+0x20>
  40dc52:	ret
	...

000000000040dc60 <__swc_fn_7dafa2b1_000026_4aca8b9e>:
  40dc60:	vxorps xmm0,xmm0,xmm0
  40dc64:	vmovups XMMWORD PTR [rcx],xmm0
  40dc68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40dc6d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40dc72:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40dc77:	ret
	...

000000000040dc80 <__swc_fn_7dafa2b1_000029_4aca8b9e>:
  40dc80:	vxorps xmm0,xmm0,xmm0
  40dc84:	vmovups XMMWORD PTR [rcx],xmm0
  40dc88:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40dc8d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40dc92:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40dc97:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40dc9c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40dca1:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40dca6:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40dcab:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40dcb3:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40dcbb:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40dcc3:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40dccb:	mov    QWORD PTR [rcx+0xc0],0x0
  40dcd6:	ret
	...

000000000040dce0 <__swc_fn_7dafa2b1_000032_84881cd8>:
  40dce0:	push   rsi
  40dce1:	push   rdi
  40dce2:	sub    rsp,0x8
  40dce6:	mov    rsi,rcx
  40dce9:	lea    rdi,[rip+0x13310]        # 421000 <__swc_data_base_7dafa2b1>
  40dcf0:	mov    rax,QWORD PTR [rdi]
  40dcf3:	cmp    rax,0xffffffffffffffff
  40dcf7:	je     40dcfe <__swc_fn_7dafa2b1_000032_84881cd8+0x1e>
  40dcf9:	mov    rdi,rax
  40dcfc:	jmp    40dd2b <__swc_fn_7dafa2b1_000032_84881cd8+0x4b>
  40dcfe:	call   4095a0 <__swc_fn_7dafa2b1_000123_9d2cbd72>
  40dd03:	mov    rcx,rax
  40dd06:	cmp    rax,0xffffffffffffffff
  40dd0a:	je     40dd3c <__swc_fn_7dafa2b1_000032_84881cd8+0x5c>
  40dd0c:	mov    rax,0xffffffffffffffff
  40dd13:	lock cmpxchg QWORD PTR [rdi],rcx
  40dd18:	cmp    rax,0xffffffffffffffff
  40dd1c:	je     40dd28 <__swc_fn_7dafa2b1_000032_84881cd8+0x48>
  40dd1e:	mov    rdi,rax
  40dd21:	call   40cb70 <__swc_fn_7dafa2b1_000124_667fbf24>
  40dd26:	jmp    40dd2b <__swc_fn_7dafa2b1_000032_84881cd8+0x4b>
  40dd28:	mov    rdi,rcx
  40dd2b:	cmp    rdi,0xffffffffffffffff
  40dd2f:	je     40dd3c <__swc_fn_7dafa2b1_000032_84881cd8+0x5c>
  40dd31:	mov    rcx,rdi
  40dd34:	mov    rdx,rsi
  40dd37:	call   40fe30 <__swc_fn_7dafa2b1_000125_ce762363>
  40dd3c:	add    rsp,0x8
  40dd40:	pop    rdi
  40dd41:	pop    rsi
  40dd42:	ret
	...

000000000040dd50 <__swc_fn_7dafa2b1_000035_95622a2b>:
  40dd50:	sub    rsp,0x38
  40dd54:	mov    rax,rdx
  40dd57:	test   dl,dl
  40dd59:	jne    40dd71 <__swc_fn_7dafa2b1_000035_95622a2b+0x21>
  40dd5b:	mov    rax,r8
  40dd5e:	test   r8b,r8b
  40dd61:	cmove  eax,r9d
  40dd65:	test   al,al
  40dd67:	cmove  eax,r10d
  40dd6b:	test   al,al
  40dd6d:	cmove  eax,r11d
  40dd71:	test   al,al
  40dd73:	jne    40dd7a <__swc_fn_7dafa2b1_000035_95622a2b+0x2a>
  40dd75:	add    rsp,0x38
  40dd79:	ret
  40dd7a:	lea    rcx,[rip+0x438f]        # 412110 <__swc_rdata_base_7dafa2b1>
  40dd81:	vmovups xmm0,XMMWORD PTR [rip+0x4397]        # 412120 <__swc_rdata_base_7dafa2b1+0x10>
  40dd89:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dd8f:	vmovups xmm0,XMMWORD PTR [rip+0x4399]        # 412130 <__swc_rdata_base_7dafa2b1+0x20>
  40dd97:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40dd9d:	vmovups xmm0,XMMWORD PTR [rip+0x439b]        # 412140 <__swc_rdata_base_7dafa2b1+0x30>
  40dda5:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ddab:	lea    rdx,[rsp+0x8]
  40ddb0:	call   40c3a0 <__swc_fn_7dafa2b1_000103_67100064>
  40ddb5:	jmp    40dd75 <__swc_fn_7dafa2b1_000035_95622a2b+0x25>
	...

000000000040ddc0 <__swc_fn_7dafa2b1_000038_788ceb38>:
  40ddc0:	sub    rsp,0x8
  40ddc4:	mov    eax,0x1000
  40ddc9:	test   eax,eax
  40ddcb:	mov    r8d,0x8
  40ddd1:	cmove  eax,r8d
  40ddd5:	dec    rax
  40ddd8:	mov    r8,0xffffffffffffffff
  40dddf:	sub    r8,rax
  40dde2:	cmp    rdx,r8
  40dde5:	ja     40ddf5 <__swc_fn_7dafa2b1_000038_788ceb38+0x35>
  40dde7:	add    rdx,rax
  40ddea:	not    rax
  40dded:	mov    r8,rdx
  40ddf0:	and    r8,rax
  40ddf3:	jne    40ddfc <__swc_fn_7dafa2b1_000038_788ceb38+0x3c>
  40ddf5:	xor    eax,eax
  40ddf7:	add    rsp,0x8
  40ddfb:	ret
  40ddfc:	mov    rdx,r8
  40ddff:	call   40aaa0 <__swc_fn_7dafa2b1_000037_b4982903>
  40de04:	add    rsp,0x8
  40de08:	ret
  40de09:	add    BYTE PTR [rax],al
  40de0b:	add    BYTE PTR [rax],al
  40de0d:	add    BYTE PTR [rax],al
	...

000000000040de10 <__swc_fn_7dafa2b1_000041_414cc921>:
  40de10:	push   rsi
  40de11:	push   rdi
  40de12:	sub    rsp,0x8
  40de16:	mov    rsi,rdx
  40de19:	mov    rdi,rcx
  40de1c:	test   rdx,rdx
  40de1f:	je     40de3b <__swc_fn_7dafa2b1_000041_414cc921+0x2b>
  40de21:	xor    ecx,ecx
  40de23:	call   407720 <__swc_fn_7dafa2b1_000033_7ca1566d>
  40de28:	mov    rax,QWORD PTR [rsi]
  40de2b:	test   rax,rax
  40de2e:	je     40de3b <__swc_fn_7dafa2b1_000041_414cc921+0x2b>
  40de30:	mov    rcx,rax
  40de33:	mov    rdx,rsi
  40de36:	call   407840 <__swc_fn_7dafa2b1_000042_bab03645>
  40de3b:	mov    rcx,rdi
  40de3e:	call   40ab00 <__swc_fn_7dafa2b1_000040_6895916d>
  40de43:	mov    rsi,rax
  40de46:	test   rax,rax
  40de49:	jne    40de54 <__swc_fn_7dafa2b1_000041_414cc921+0x44>
  40de4b:	xor    eax,eax
  40de4d:	add    rsp,0x8
  40de51:	pop    rdi
  40de52:	pop    rsi
  40de53:	ret
  40de54:	mov    rcx,rsi
  40de57:	call   407720 <__swc_fn_7dafa2b1_000033_7ca1566d>
  40de5c:	mov    rax,rsi
  40de5f:	add    rsp,0x8
  40de63:	pop    rdi
  40de64:	pop    rsi
  40de65:	ret
	...

000000000040de70 <__swc_fn_7dafa2b1_000044_9c2ade9b>:
  40de70:	movzx  eax,BYTE PTR [r8+0x39]
  40de75:	lea    rax,[rax+rax*4]
  40de79:	lea    rax,[rdx+rax*8+0x28]
  40de7e:	mov    ecx,DWORD PTR [r8+0x6c]
  40de82:	test   ecx,ecx
  40de84:	je     40debd <__swc_fn_7dafa2b1_000044_9c2ade9b+0x4d>
  40de86:	mov    rcx,QWORD PTR [r8+0x50]
  40de8a:	test   rcx,rcx
  40de8d:	je     40de99 <__swc_fn_7dafa2b1_000044_9c2ade9b+0x29>
  40de8f:	mov    rax,QWORD PTR [r8+0x48]
  40de93:	mov    QWORD PTR [rcx+0x48],rax
  40de97:	jmp    40dea1 <__swc_fn_7dafa2b1_000044_9c2ade9b+0x31>
  40de99:	mov    rcx,QWORD PTR [r8+0x48]
  40de9d:	mov    QWORD PTR [rax+0x18],rcx
  40dea1:	mov    rax,QWORD PTR [r8+0x48]
  40dea5:	test   rax,rax
  40dea8:	je     40deb2 <__swc_fn_7dafa2b1_000044_9c2ade9b+0x42>
  40deaa:	mov    rcx,QWORD PTR [r8+0x50]
  40deae:	mov    QWORD PTR [rax+0x50],rcx
  40deb2:	vxorps xmm0,xmm0,xmm0
  40deb6:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40debc:	ret
  40debd:	mov    rcx,QWORD PTR [r8+0x50]
  40dec1:	test   rcx,rcx
  40dec4:	je     40ded0 <__swc_fn_7dafa2b1_000044_9c2ade9b+0x60>
  40dec6:	mov    rdx,QWORD PTR [r8+0x48]
  40deca:	mov    QWORD PTR [rcx+0x48],rdx
  40dece:	jmp    40ded8 <__swc_fn_7dafa2b1_000044_9c2ade9b+0x68>
  40ded0:	mov    rcx,QWORD PTR [r8+0x48]
  40ded4:	mov    QWORD PTR [rax+0x8],rcx
  40ded8:	mov    rcx,QWORD PTR [r8+0x48]
  40dedc:	test   rcx,rcx
  40dedf:	je     40deeb <__swc_fn_7dafa2b1_000044_9c2ade9b+0x7b>
  40dee1:	mov    rdx,QWORD PTR [r8+0x50]
  40dee5:	mov    QWORD PTR [rcx+0x50],rdx
  40dee9:	jmp    40def3 <__swc_fn_7dafa2b1_000044_9c2ade9b+0x83>
  40deeb:	mov    rcx,QWORD PTR [r8+0x50]
  40deef:	mov    QWORD PTR [rax+0x10],rcx
  40def3:	cmp    QWORD PTR [rax],r8
  40def6:	jne    40deff <__swc_fn_7dafa2b1_000044_9c2ade9b+0x8f>
  40def8:	mov    QWORD PTR [rax],0x0
  40deff:	vxorps xmm0,xmm0,xmm0
  40df03:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40df09:	ret
  40df0a:	add    BYTE PTR [rax],al
  40df0c:	add    BYTE PTR [rax],al
	...

000000000040df10 <__swc_fn_7dafa2b1_000047_bc5ec610>:
  40df10:	sub    rsp,0x8
  40df14:	mov    r9,r8
  40df17:	mov    r10,rdx
  40df1a:	call   40de70 <__swc_fn_7dafa2b1_000044_9c2ade9b>
  40df1f:	mov    DWORD PTR [r9+0x6c],0x0
  40df27:	movzx  eax,BYTE PTR [r9+0x39]
  40df2c:	lea    rax,[rax+rax*4]
  40df30:	lea    rax,[r10+rax*8+0x28]
  40df35:	mov    rcx,QWORD PTR [rax+0x10]
  40df39:	mov    QWORD PTR [r9+0x50],rcx
  40df3d:	mov    QWORD PTR [r9+0x48],0x0
  40df45:	mov    rcx,QWORD PTR [rax+0x10]
  40df49:	test   rcx,rcx
  40df4c:	je     40df54 <__swc_fn_7dafa2b1_000047_bc5ec610+0x44>
  40df4e:	mov    QWORD PTR [rcx+0x48],r9
  40df52:	jmp    40df58 <__swc_fn_7dafa2b1_000047_bc5ec610+0x48>
  40df54:	mov    QWORD PTR [rax+0x8],r9
  40df58:	mov    QWORD PTR [rax+0x10],r9
  40df5c:	add    rsp,0x8
  40df60:	ret
	...

000000000040df80 <__swc_fn_7dafa2b1_000050_ab8077df>:
  40df80:	push   rsi
  40df81:	push   rdi
  40df82:	push   r12
  40df84:	push   r13
  40df86:	push   r14
  40df88:	push   r15
  40df8a:	sub    rsp,0x1f8
  40df91:	mov    esi,r8d
  40df94:	mov    QWORD PTR [rsp+0x1e8],rsi
  40df9c:	mov    rdi,rcx
  40df9f:	mov    r12,rdx
  40dfa2:	lea    r13,[rsi+rsi*4]
  40dfa6:	lea    r13,[rdx+r13*8+0x28]
  40dfab:	call   407ca0 <__swc_fn_7dafa2b1_000048_c877e9d2>
  40dfb0:	add    DWORD PTR [r12+0x24],0x1
  40dfb6:	test   BYTE PTR [r12+0x24],0x3f
  40dfbc:	jne    40dfc6 <__swc_fn_7dafa2b1_000050_ab8077df+0x46>
  40dfbe:	mov    rcx,rdi
  40dfc1:	call   40ac80 <__swc_fn_7dafa2b1_000049_2ff013cc>
  40dfc6:	mov    rax,QWORD PTR [r13+0x8]
  40dfca:	mov    r14,rax
  40dfcd:	nop    DWORD PTR [rax]
  40dfd0:	test   r14,r14
  40dfd3:	jne    40dfe2 <__swc_fn_7dafa2b1_000050_ab8077df+0x62>
  40dfd5:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40dfdd:	jmp    40e0e9 <__swc_fn_7dafa2b1_000050_ab8077df+0x169>
  40dfe2:	mov    r15,QWORD PTR [r14+0x48]
  40dfe6:	mov    rcx,r14
  40dfe9:	call   4073f0 <__swc_fn_7dafa2b1_000009_d7e2bb25>
  40dfee:	mov    rax,QWORD PTR [r14]
  40dff1:	test   rax,rax
  40dff4:	je     40e006 <__swc_fn_7dafa2b1_000050_ab8077df+0x86>
  40dff6:	mov    rcx,QWORD PTR [rax]
  40dff9:	mov    QWORD PTR [r14],rcx
  40dffc:	add    DWORD PTR [r14+0x28],0x1
  40e001:	mov    rsi,rax
  40e004:	jmp    40e025 <__swc_fn_7dafa2b1_000050_ab8077df+0xa5>
  40e006:	mov    rax,QWORD PTR [r14+0x18]
  40e00a:	cmp    QWORD PTR [r14+0x20],rax
  40e00e:	jae    40e023 <__swc_fn_7dafa2b1_000050_ab8077df+0xa3>
  40e010:	mov    rsi,QWORD PTR [r14+0x20]
  40e014:	mov    eax,DWORD PTR [r14+0x2c]
  40e018:	add    QWORD PTR [r14+0x20],rax
  40e01c:	add    DWORD PTR [r14+0x28],0x1
  40e021:	jmp    40e025 <__swc_fn_7dafa2b1_000050_ab8077df+0xa5>
  40e023:	xor    esi,esi
  40e025:	test   rsi,rsi
  40e028:	jne    40e06d <__swc_fn_7dafa2b1_000050_ab8077df+0xed>
  40e02a:	mov    rcx,r14
  40e02d:	call   407320 <__swc_fn_7dafa2b1_000006_a23dca5f>
  40e032:	test   al,al
  40e034:	je     40e06d <__swc_fn_7dafa2b1_000050_ab8077df+0xed>
  40e036:	mov    rax,QWORD PTR [r14]
  40e039:	test   rax,rax
  40e03c:	je     40e04b <__swc_fn_7dafa2b1_000050_ab8077df+0xcb>
  40e03e:	mov    rcx,QWORD PTR [rax]
  40e041:	mov    QWORD PTR [r14],rcx
  40e044:	add    DWORD PTR [r14+0x28],0x1
  40e049:	jmp    40e06a <__swc_fn_7dafa2b1_000050_ab8077df+0xea>
  40e04b:	mov    rax,QWORD PTR [r14+0x18]
  40e04f:	cmp    QWORD PTR [r14+0x20],rax
  40e053:	jae    40e068 <__swc_fn_7dafa2b1_000050_ab8077df+0xe8>
  40e055:	mov    rax,QWORD PTR [r14+0x20]
  40e059:	mov    ecx,DWORD PTR [r14+0x2c]
  40e05d:	add    QWORD PTR [r14+0x20],rcx
  40e061:	add    DWORD PTR [r14+0x28],0x1
  40e066:	jmp    40e06a <__swc_fn_7dafa2b1_000050_ab8077df+0xea>
  40e068:	xor    eax,eax
  40e06a:	mov    rsi,rax
  40e06d:	test   rsi,rsi
  40e070:	jne    40e0c3 <__swc_fn_7dafa2b1_000050_ab8077df+0x143>
  40e072:	mov    rcx,rdi
  40e075:	mov    rdx,r12
  40e078:	mov    r8,r14
  40e07b:	call   40abe0 <__swc_fn_7dafa2b1_000046_88f44774>
  40e080:	test   al,al
  40e082:	jne    40e0c3 <__swc_fn_7dafa2b1_000050_ab8077df+0x143>
  40e084:	mov    rcx,r14
  40e087:	call   4073f0 <__swc_fn_7dafa2b1_000009_d7e2bb25>
  40e08c:	mov    rax,QWORD PTR [r14]
  40e08f:	test   rax,rax
  40e092:	je     40e0a1 <__swc_fn_7dafa2b1_000050_ab8077df+0x121>
  40e094:	mov    rcx,QWORD PTR [rax]
  40e097:	mov    QWORD PTR [r14],rcx
  40e09a:	add    DWORD PTR [r14+0x28],0x1
  40e09f:	jmp    40e0c0 <__swc_fn_7dafa2b1_000050_ab8077df+0x140>
  40e0a1:	mov    rax,QWORD PTR [r14+0x18]
  40e0a5:	cmp    QWORD PTR [r14+0x20],rax
  40e0a9:	jae    40e0be <__swc_fn_7dafa2b1_000050_ab8077df+0x13e>
  40e0ab:	mov    rax,QWORD PTR [r14+0x20]
  40e0af:	mov    ecx,DWORD PTR [r14+0x2c]
  40e0b3:	add    QWORD PTR [r14+0x20],rcx
  40e0b7:	add    DWORD PTR [r14+0x28],0x1
  40e0bc:	jmp    40e0c0 <__swc_fn_7dafa2b1_000050_ab8077df+0x140>
  40e0be:	xor    eax,eax
  40e0c0:	mov    rsi,rax
  40e0c3:	test   rsi,rsi
  40e0c6:	je     40e0e1 <__swc_fn_7dafa2b1_000050_ab8077df+0x161>
  40e0c8:	mov    QWORD PTR [r13+0x0],r14
  40e0cc:	mov    rax,rsi
  40e0cf:	add    rsp,0x1f8
  40e0d6:	pop    r15
  40e0d8:	pop    r14
  40e0da:	pop    r13
  40e0dc:	pop    r12
  40e0de:	pop    rdi
  40e0df:	pop    rsi
  40e0e0:	ret
  40e0e1:	mov    r14,r15
  40e0e4:	jmp    40dfd0 <__swc_fn_7dafa2b1_000050_ab8077df+0x50>
  40e0e9:	cs nop WORD PTR [rax+rax*1+0x0]
  40e0f3:	cs nop WORD PTR [rax+rax*1+0x0]
  40e0fd:	nop    DWORD PTR [rax]
  40e100:	mov    rcx,rdi
  40e103:	mov    rdx,r12
  40e106:	mov    r8d,esi
  40e109:	call   4079e0 <__swc_fn_7dafa2b1_000045_1fe0f4e2>
  40e10e:	mov    r14,rax
  40e111:	test   rax,rax
  40e114:	jne    40e12a <__swc_fn_7dafa2b1_000050_ab8077df+0x1aa>
  40e116:	xor    eax,eax
  40e118:	add    rsp,0x1f8
  40e11f:	pop    r15
  40e121:	pop    r14
  40e123:	pop    r13
  40e125:	pop    r12
  40e127:	pop    rdi
  40e128:	pop    rsi
  40e129:	ret
  40e12a:	mov    QWORD PTR [r13+0x0],r14
  40e12e:	mov    rax,QWORD PTR [r14]
  40e131:	test   rax,rax
  40e134:	je     40e146 <__swc_fn_7dafa2b1_000050_ab8077df+0x1c6>
  40e136:	mov    rcx,QWORD PTR [rax]
  40e139:	mov    QWORD PTR [r14],rcx
  40e13c:	add    DWORD PTR [r14+0x28],0x1
  40e141:	mov    r15,rax
  40e144:	jmp    40e166 <__swc_fn_7dafa2b1_000050_ab8077df+0x1e6>
  40e146:	mov    rax,QWORD PTR [r14+0x18]
  40e14a:	cmp    QWORD PTR [r14+0x20],rax
  40e14e:	jae    40e163 <__swc_fn_7dafa2b1_000050_ab8077df+0x1e3>
  40e150:	mov    r15,QWORD PTR [r14+0x20]
  40e154:	mov    eax,DWORD PTR [r14+0x2c]
  40e158:	add    QWORD PTR [r14+0x20],rax
  40e15c:	add    DWORD PTR [r14+0x28],0x1
  40e161:	jmp    40e166 <__swc_fn_7dafa2b1_000050_ab8077df+0x1e6>
  40e163:	xor    r15d,r15d
  40e166:	test   r15,r15
  40e169:	jne    40e1ae <__swc_fn_7dafa2b1_000050_ab8077df+0x22e>
  40e16b:	mov    rcx,r14
  40e16e:	call   407320 <__swc_fn_7dafa2b1_000006_a23dca5f>
  40e173:	test   al,al
  40e175:	je     40e1ae <__swc_fn_7dafa2b1_000050_ab8077df+0x22e>
  40e177:	mov    rax,QWORD PTR [r14]
  40e17a:	test   rax,rax
  40e17d:	je     40e18c <__swc_fn_7dafa2b1_000050_ab8077df+0x20c>
  40e17f:	mov    rcx,QWORD PTR [rax]
  40e182:	mov    QWORD PTR [r14],rcx
  40e185:	add    DWORD PTR [r14+0x28],0x1
  40e18a:	jmp    40e1ab <__swc_fn_7dafa2b1_000050_ab8077df+0x22b>
  40e18c:	mov    rax,QWORD PTR [r14+0x18]
  40e190:	cmp    QWORD PTR [r14+0x20],rax
  40e194:	jae    40e1a9 <__swc_fn_7dafa2b1_000050_ab8077df+0x229>
  40e196:	mov    rax,QWORD PTR [r14+0x20]
  40e19a:	mov    ecx,DWORD PTR [r14+0x2c]
  40e19e:	add    QWORD PTR [r14+0x20],rcx
  40e1a2:	add    DWORD PTR [r14+0x28],0x1
  40e1a7:	jmp    40e1ab <__swc_fn_7dafa2b1_000050_ab8077df+0x22b>
  40e1a9:	xor    eax,eax
  40e1ab:	mov    r15,rax
  40e1ae:	test   r15,r15
  40e1b1:	je     40e100 <__swc_fn_7dafa2b1_000050_ab8077df+0x180>
  40e1b7:	mov    rax,r15
  40e1ba:	add    rsp,0x1f8
  40e1c1:	pop    r15
  40e1c3:	pop    r14
  40e1c5:	pop    r13
  40e1c7:	pop    r12
  40e1c9:	pop    rdi
  40e1ca:	pop    rsi
  40e1cb:	ret
  40e1cc:	add    BYTE PTR [rax],al
	...

000000000040e1d0 <__swc_fn_7dafa2b1_000053_82546d94>:
  40e1d0:	push   rsi
  40e1d1:	push   rdi
  40e1d2:	push   r12
  40e1d4:	mov    rsi,rdx
  40e1d7:	mov    rax,rdx
  40e1da:	shr    rax,0xc
  40e1de:	movabs rdx,0x9e3779b97f4a7c15
  40e1e8:	imul   rax,rdx
  40e1ec:	shr    rax,0x20
  40e1f0:	lea    rax,[rax*8+0x0]
  40e1f8:	shr    rax,0x20
  40e1fc:	lea    rax,[rax*8+0x0]
  40e204:	lea    rax,[rcx+rax*8+0x40]
  40e209:	xor    edx,edx
  40e20b:	test   dl,dl
  40e20d:	lea    rdi,[rcx+0x8]
  40e211:	cmove  rdi,rax
  40e215:	xor    edx,edx
  40e217:	test   dl,dl
  40e219:	lea    r12,[rcx+0x30]
  40e21d:	lea    rax,[rax+0x8]
  40e221:	cmove  r12,rax
  40e225:	mov    rcx,rdi
  40e228:	call   4098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>
  40e22d:	mov    QWORD PTR [rsi+0x30],0x0
  40e235:	mov    rax,QWORD PTR [r12]
  40e239:	mov    QWORD PTR [rsi+0x38],rax
  40e23d:	test   rax,rax
  40e240:	je     40e24a <__swc_fn_7dafa2b1_000053_82546d94+0x7a>
  40e242:	mov    rax,QWORD PTR [rsi+0x38]
  40e246:	mov    QWORD PTR [rax+0x30],rsi
  40e24a:	mov    QWORD PTR [r12],rsi
  40e24e:	mov    rcx,rdi
  40e251:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  40e256:	pop    r12
  40e258:	pop    rdi
  40e259:	pop    rsi
  40e25a:	ret
  40e25b:	add    BYTE PTR [rax],al
  40e25d:	add    BYTE PTR [rax],al
	...

000000000040e260 <__swc_fn_7dafa2b1_000056_38b21f11>:
  40e260:	lea    rax,[rdx+rdx*4]
  40e264:	lea    rax,[rcx+rax*8+0x268]
  40e26c:	mov    rdx,QWORD PTR [rax+0x10]
  40e270:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e277:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e27f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e286:	lea    rdx,[rdx+rdx*4]
  40e28a:	lea    rdx,[rcx+rdx*8+0x268]
  40e292:	vmovups xmm0,XMMWORD PTR [rdx]
  40e296:	vmovups XMMWORD PTR [rax],xmm0
  40e29a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e29f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e2a4:	mov    rcx,QWORD PTR [rdx+0x20]
  40e2a8:	mov    QWORD PTR [rax+0x20],rcx
  40e2ac:	ret
  40e2ad:	add    BYTE PTR [rax],al
	...

000000000040e2b0 <__swc_fn_7dafa2b1_000059_3ca3ac64>:
  40e2b0:	push   rsi
  40e2b1:	push   rdi
  40e2b2:	push   r12
  40e2b4:	push   r13
  40e2b6:	sub    rsp,0x8
  40e2ba:	mov    rsi,r8
  40e2bd:	mov    rdi,rcx
  40e2c0:	mov    r12,rdx
  40e2c3:	xor    r13d,r13d
  40e2c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e2d0:	mov    eax,DWORD PTR [r12+0x730]
  40e2d8:	cmp    r13d,eax
  40e2db:	jae    40e341 <__swc_fn_7dafa2b1_000059_3ca3ac64+0x91>
  40e2dd:	lea    rax,[r13+r13*4+0x0]
  40e2e2:	lea    rax,[r12+rax*8+0x738]
  40e2ea:	mov    rdx,QWORD PTR [rax]
  40e2ed:	mov    r8,QWORD PTR [rax+0x8]
  40e2f1:	mov    r9,QWORD PTR [rax+0x10]
  40e2f5:	cmp    QWORD PTR [rax+0x20],rsi
  40e2f9:	jb     40e300 <__swc_fn_7dafa2b1_000059_3ca3ac64+0x50>
  40e2fb:	inc    r13d
  40e2fe:	jmp    40e2d0 <__swc_fn_7dafa2b1_000059_3ca3ac64+0x20>
  40e300:	sub    DWORD PTR [r12+0x730],0x1
  40e309:	mov    ecx,DWORD PTR [r12+0x730]
  40e311:	lea    rcx,[rcx+rcx*4]
  40e315:	lea    rcx,[r12+rcx*8+0x738]
  40e31d:	vmovups xmm0,XMMWORD PTR [rcx]
  40e321:	vmovups XMMWORD PTR [rax],xmm0
  40e325:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e32a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e32f:	mov    rcx,QWORD PTR [rcx+0x20]
  40e333:	mov    QWORD PTR [rax+0x20],rcx
  40e337:	mov    rcx,rdi
  40e33a:	call   407750 <__swc_fn_7dafa2b1_000039_40d1e569>
  40e33f:	jmp    40e2d0 <__swc_fn_7dafa2b1_000059_3ca3ac64+0x20>
  40e341:	add    rsp,0x8
  40e345:	pop    r13
  40e347:	pop    r12
  40e349:	pop    rdi
  40e34a:	pop    rsi
  40e34b:	ret
  40e34c:	add    BYTE PTR [rax],al
	...

000000000040e350 <__swc_fn_7dafa2b1_000062_7e482c5f>:
  40e350:	push   rsi
  40e351:	push   rdi
  40e352:	push   r12
  40e354:	push   r13
  40e356:	push   r14
  40e358:	mov    rsi,rcx
  40e35b:	mov    rdi,rdx
  40e35e:	mov    r12,QWORD PTR [rdi]
  40e361:	mov    r13,QWORD PTR [rdi+0x18]
  40e365:	mov    rax,r12
  40e368:	add    rax,QWORD PTR [rdi+0x8]
  40e36c:	sub    rax,r13
  40e36f:	cmp    r8,rax
  40e372:	jbe    40e37d <__swc_fn_7dafa2b1_000062_7e482c5f+0x2d>
  40e374:	pop    r14
  40e376:	pop    r13
  40e378:	pop    r12
  40e37a:	pop    rdi
  40e37b:	pop    rsi
  40e37c:	ret
  40e37d:	lea    rax,[r13+r8*1+0x0]
  40e382:	sub    rax,r12
  40e385:	mov    ecx,0x1000
  40e38a:	test   ecx,ecx
  40e38c:	mov    edx,0x8
  40e391:	cmove  ecx,edx
  40e394:	dec    rcx
  40e397:	mov    rdx,0xffffffffffffffff
  40e39e:	sub    rdx,rcx
  40e3a1:	cmp    rax,rdx
  40e3a4:	jbe    40e3ab <__swc_fn_7dafa2b1_000062_7e482c5f+0x5b>
  40e3a6:	xor    r14d,r14d
  40e3a9:	jmp    40e3b6 <__swc_fn_7dafa2b1_000062_7e482c5f+0x66>
  40e3ab:	add    rax,rcx
  40e3ae:	andn   rax,rcx,rax
  40e3b3:	mov    r14,rax
  40e3b6:	mov    rax,QWORD PTR [rdi+0x10]
  40e3ba:	cmp    r14,rax
  40e3bd:	ja     40e3c8 <__swc_fn_7dafa2b1_000062_7e482c5f+0x78>
  40e3bf:	pop    r14
  40e3c1:	pop    r13
  40e3c3:	pop    r12
  40e3c5:	pop    rdi
  40e3c6:	pop    rsi
  40e3c7:	ret
  40e3c8:	mov    rax,r12
  40e3cb:	add    rax,QWORD PTR [rdi+0x10]
  40e3cf:	mov    rdx,r14
  40e3d2:	sub    rdx,QWORD PTR [rdi+0x10]
  40e3d6:	mov    rcx,rax
  40e3d9:	call   4072a0 <__swc_fn_7dafa2b1_000003_7ab4792e>
  40e3de:	test   al,al
  40e3e0:	jne    40e3eb <__swc_fn_7dafa2b1_000062_7e482c5f+0x9b>
  40e3e2:	pop    r14
  40e3e4:	pop    r13
  40e3e6:	pop    r12
  40e3e8:	pop    rdi
  40e3e9:	pop    rsi
  40e3ea:	ret
  40e3eb:	add    r12,r14
  40e3ee:	sub    r12,r13
  40e3f1:	mov    rcx,r12
  40e3f4:	sub    rcx,QWORD PTR [rdi+0x28]
  40e3f8:	mov    rdx,QWORD PTR [rsi+0x250]
  40e3ff:	nop
  40e400:	lea    r8,[rdx+rcx*1]
  40e404:	mov    rax,rdx
  40e407:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40e410:	cmp    rax,rdx
  40e413:	je     40e41a <__swc_fn_7dafa2b1_000062_7e482c5f+0xca>
  40e415:	mov    rdx,rax
  40e418:	jmp    40e400 <__swc_fn_7dafa2b1_000062_7e482c5f+0xb0>
  40e41a:	mov    QWORD PTR [rdi+0x10],r14
  40e41e:	mov    QWORD PTR [rdi+0x28],r12
  40e422:	pop    r14
  40e424:	pop    r13
  40e426:	pop    r12
  40e428:	pop    rdi
  40e429:	pop    rsi
  40e42a:	ret
  40e42b:	add    BYTE PTR [rax],al
  40e42d:	add    BYTE PTR [rax],al
	...

000000000040e430 <__swc_fn_7dafa2b1_000065_f9f4b610>:
  40e430:	push   rbx
  40e431:	push   rsi
  40e432:	push   rdi
  40e433:	push   r12
  40e435:	push   r13
  40e437:	sub    rsp,0xe0
  40e43e:	mov    rbx,rdx
  40e441:	mov    rsi,rcx
  40e444:	cmp    DWORD PTR [rbx+0x58],0x0
  40e448:	je     40e46c <__swc_fn_7dafa2b1_000065_f9f4b610+0x3c>
  40e44a:	mov    eax,DWORD PTR [rbx+0x58]
  40e44d:	sub    eax,0x1
  40e450:	test   DWORD PTR [rbx+0x58],eax
  40e453:	je     40e46c <__swc_fn_7dafa2b1_000065_f9f4b610+0x3c>
  40e455:	mov    QWORD PTR [rbx+0x40],0x0
  40e45d:	add    rsp,0xe0
  40e464:	pop    r13
  40e466:	pop    r12
  40e468:	pop    rdi
  40e469:	pop    rsi
  40e46a:	pop    rbx
  40e46b:	ret
  40e46c:	mov    rax,QWORD PTR [rbx+0x40]
  40e470:	test   rax,rax
  40e473:	jne    40e48f <__swc_fn_7dafa2b1_000065_f9f4b610+0x5f>
  40e475:	mov    rcx,rsi
  40e478:	mov    rdx,rbx
  40e47b:	call   40b890 <__swc_fn_7dafa2b1_000064_b0d63361>
  40e480:	add    rsp,0xe0
  40e487:	pop    r13
  40e489:	pop    r12
  40e48b:	pop    rdi
  40e48c:	pop    rsi
  40e48d:	pop    rbx
  40e48e:	ret
  40e48f:	cmp    QWORD PTR [rbx+0x48],0x0
  40e494:	jne    40e4b0 <__swc_fn_7dafa2b1_000065_f9f4b610+0x80>
  40e496:	mov    rcx,rsi
  40e499:	mov    rdx,rbx
  40e49c:	call   407f90 <__swc_fn_7dafa2b1_000066_254b71af>
  40e4a1:	add    rsp,0xe0
  40e4a8:	pop    r13
  40e4aa:	pop    r12
  40e4ac:	pop    rdi
  40e4ad:	pop    rsi
  40e4ae:	pop    rbx
  40e4af:	ret
  40e4b0:	mov    rdi,QWORD PTR [rbx+0x40]
  40e4b4:	lea    rax,[rip+0x14bb5]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  40e4bb:	mov    rcx,rdi
  40e4be:	sub    rcx,QWORD PTR [rax+0x8]
  40e4c2:	mov    rax,QWORD PTR [rip+0x14bb7]        # 423080 <__swc_bss_base_7dafa2b1+0x40>
  40e4c9:	cmp    rcx,rax
  40e4cc:	jae    40e4f8 <__swc_fn_7dafa2b1_000065_f9f4b610+0xc8>
  40e4ce:	mov    rax,rdi
  40e4d1:	and    rax,0xffffffffffc00000
  40e4d8:	mov    rcx,rdi
  40e4db:	shr    rcx,0x10
  40e4df:	and    ecx,0x3f
  40e4e2:	mov    edx,DWORD PTR [rax+0x28]
  40e4e5:	shrx   ecx,ecx,edx
  40e4ea:	shl    rcx,0x4
  40e4ee:	lea    r12,[rax+rcx*8+0x80]
  40e4f6:	jmp    40e503 <__swc_fn_7dafa2b1_000065_f9f4b610+0xd3>
  40e4f8:	mov    rcx,rdi
  40e4fb:	call   40a910 <__swc_fn_7dafa2b1_000022_3a2e2048>
  40e500:	mov    r12,rax
  40e503:	test   r12,r12
  40e506:	je     40e515 <__swc_fn_7dafa2b1_000065_f9f4b610+0xe5>
  40e508:	mov    eax,DWORD PTR [r12+0x2c]
  40e50d:	mov    r9d,eax
  40e510:	mov    r13,rax
  40e513:	jmp    40e594 <__swc_fn_7dafa2b1_000065_f9f4b610+0x164>
  40e515:	mov    rcx,rsi
  40e518:	mov    rdx,rdi
  40e51b:	call   40af20 <__swc_fn_7dafa2b1_000052_c7484fb0>
  40e520:	mov    rcx,QWORD PTR [rax+0x28]
  40e524:	mov    r9,rcx
  40e527:	mov    rdx,QWORD PTR [rax+0x20]
  40e52b:	mov    r13,rdx
  40e52e:	cmp    QWORD PTR [rbx+0x48],rcx
  40e532:	jbe    40e56b <__swc_fn_7dafa2b1_000065_f9f4b610+0x13b>
  40e534:	mov    ecx,DWORD PTR [rax+0x48]
  40e537:	cmp    DWORD PTR [rbx+0x58],ecx
  40e53a:	ja     40e56b <__swc_fn_7dafa2b1_000065_f9f4b610+0x13b>
  40e53c:	mov    rcx,rsi
  40e53f:	mov    rdx,rax
  40e542:	mov    r8,QWORD PTR [rbx+0x48]
  40e546:	mov    QWORD PTR [rsp+0xc8],r9
  40e54e:	mov    QWORD PTR [rsp+0xd0],rax
  40e556:	call   40e350 <__swc_fn_7dafa2b1_000062_7e482c5f>
  40e55b:	mov    r9,QWORD PTR [rsp+0xc8]
  40e563:	mov    rax,QWORD PTR [rsp+0xd0]
  40e56b:	mov    rcx,QWORD PTR [rax+0x28]
  40e56f:	cmp    QWORD PTR [rbx+0x48],rcx
  40e573:	ja     40e594 <__swc_fn_7dafa2b1_000065_f9f4b610+0x164>
  40e575:	mov    ecx,DWORD PTR [rax+0x48]
  40e578:	cmp    DWORD PTR [rbx+0x58],ecx
  40e57b:	ja     40e594 <__swc_fn_7dafa2b1_000065_f9f4b610+0x164>
  40e57d:	mov    rcx,QWORD PTR [rbx+0x48]
  40e581:	mov    QWORD PTR [rax+0x20],rcx
  40e585:	add    rsp,0xe0
  40e58c:	pop    r13
  40e58e:	pop    r12
  40e590:	pop    rdi
  40e591:	pop    rsi
  40e592:	pop    rbx
  40e593:	ret
  40e594:	test   r12,r12
  40e597:	je     40e5c9 <__swc_fn_7dafa2b1_000065_f9f4b610+0x199>
  40e599:	cmp    QWORD PTR [rbx+0x48],r9
  40e59d:	ja     40e5c9 <__swc_fn_7dafa2b1_000065_f9f4b610+0x199>
  40e59f:	cmp    DWORD PTR [rbx+0x58],0x40
  40e5a3:	ja     40e5c9 <__swc_fn_7dafa2b1_000065_f9f4b610+0x199>
  40e5a5:	cmp    DWORD PTR [rbx+0x58],0x0
  40e5a9:	je     40e5b6 <__swc_fn_7dafa2b1_000065_f9f4b610+0x186>
  40e5ab:	mov    ecx,DWORD PTR [rbx+0x58]
  40e5ae:	dec    rcx
  40e5b1:	test   rdi,rcx
  40e5b4:	jne    40e5c9 <__swc_fn_7dafa2b1_000065_f9f4b610+0x199>
  40e5b6:	mov    QWORD PTR [rbx+0x40],rdi
  40e5ba:	add    rsp,0xe0
  40e5c1:	pop    r13
  40e5c3:	pop    r12
  40e5c5:	pop    rdi
  40e5c6:	pop    rsi
  40e5c7:	pop    rbx
  40e5c8:	ret
  40e5c9:	vmovups xmm0,XMMWORD PTR [rbx]
  40e5cd:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e5d3:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e5d8:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e5de:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e5e3:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e5e9:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e5ee:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40e5f4:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e5f9:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40e5ff:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e604:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40e60a:	mov    QWORD PTR [rsp+0x48],0x0
  40e613:	mov    rcx,rsi
  40e616:	lea    rdx,[rsp+0x8]
  40e61b:	call   40b890 <__swc_fn_7dafa2b1_000064_b0d63361>
  40e620:	mov    rax,QWORD PTR [rsp+0x48]
  40e625:	test   rax,rax
  40e628:	jne    40e641 <__swc_fn_7dafa2b1_000065_f9f4b610+0x211>
  40e62a:	mov    QWORD PTR [rbx+0x40],0x0
  40e632:	add    rsp,0xe0
  40e639:	pop    r13
  40e63b:	pop    r12
  40e63d:	pop    rdi
  40e63e:	pop    rsi
  40e63f:	pop    rbx
  40e640:	ret
  40e641:	mov    rax,QWORD PTR [rbx+0x48]
  40e645:	cmp    r13,rax
  40e648:	cmovbe rax,r13
  40e64c:	mov    rcx,QWORD PTR [rsp+0x48]
  40e651:	mov    rdx,rdi
  40e654:	mov    r8,rax
  40e657:	call   409100 <__swc_fn_7dafa2b1_000105_6fd80914>
  40e65c:	vmovups xmm0,XMMWORD PTR [rbx]
  40e660:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40e666:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e66b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40e671:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e676:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40e67f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e684:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40e68d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e692:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40e69b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e6a0:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40e6a9:	mov    QWORD PTR [rsp+0xa8],rdi
  40e6b1:	mov    rcx,rsi
  40e6b4:	lea    rdx,[rsp+0x68]
  40e6b9:	call   407f90 <__swc_fn_7dafa2b1_000066_254b71af>
  40e6be:	mov    rax,QWORD PTR [rsp+0x48]
  40e6c3:	mov    QWORD PTR [rbx+0x40],rax
  40e6c7:	add    rsp,0xe0
  40e6ce:	pop    r13
  40e6d0:	pop    r12
  40e6d2:	pop    rdi
  40e6d3:	pop    rsi
  40e6d4:	pop    rbx
  40e6d5:	ret
	...

000000000040e6e0 <__swc_fn_7dafa2b1_000068_7d4c42bf>:
  40e6e0:	push   r12
  40e6e2:	push   rdi
  40e6e3:	push   rsi
  40e6e4:	push   r13
  40e6e6:	push   r14
  40e6e8:	sub    rsp,0x190
  40e6ef:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40e6f8:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40e701:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40e70a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40e713:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40e71c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40e725:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40e72e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40e737:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40e740:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40e749:	mov    r12,rcx
  40e74c:	lea    rax,[rip+0x128ad]        # 421000 <__swc_data_base_7dafa2b1>
  40e753:	mov    rax,QWORD PTR [rax]
  40e756:	cmp    rax,0xffffffffffffffff
  40e75a:	je     40e769 <__swc_fn_7dafa2b1_000068_7d4c42bf+0x89>
  40e75c:	mov    eax,eax
  40e75e:	mov    edi,eax
  40e760:	xor    eax,eax
  40e762:	call   407000 <pthread_getspecific@plt>
  40e767:	jmp    40e76b <__swc_fn_7dafa2b1_000068_7d4c42bf+0x8b>
  40e769:	xor    eax,eax
  40e76b:	test   rax,rax
  40e76e:	jne    40e77d <__swc_fn_7dafa2b1_000068_7d4c42bf+0x9d>
  40e770:	call   40a9e0 <__swc_fn_7dafa2b1_000031_90860ff2>
  40e775:	mov    rcx,rax
  40e778:	call   40fee0 <__swc_fn_7dafa2b1_000128_41c3251c>
  40e77d:	test   rax,rax
  40e780:	je     40e7a6 <__swc_fn_7dafa2b1_000068_7d4c42bf+0xc6>
  40e782:	cmp    QWORD PTR [rax],r12
  40e785:	jne    40e7a6 <__swc_fn_7dafa2b1_000068_7d4c42bf+0xc6>
  40e787:	xor    ecx,ecx
  40e789:	mov    QWORD PTR [rsp+0xc8],rax
  40e791:	call   407720 <__swc_fn_7dafa2b1_000033_7ca1566d>
  40e796:	mov    rdx,QWORD PTR [rsp+0xc8]
  40e79e:	mov    rcx,r12
  40e7a1:	call   407840 <__swc_fn_7dafa2b1_000042_bab03645>
  40e7a6:	lea    rsi,[r12+0x10]
  40e7ab:	mov    rcx,rsi
  40e7ae:	call   4098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>
  40e7b3:	mov    rdi,QWORD PTR [r12+0x20]
  40e7b8:	test   rdi,rdi
  40e7bb:	je     40e7fe <__swc_fn_7dafa2b1_000068_7d4c42bf+0x11e>
  40e7bd:	nop    DWORD PTR [rax]
  40e7c0:	mov    rcx,r12
  40e7c3:	mov    rdx,rdi
  40e7c6:	call   40aba0 <__swc_fn_7dafa2b1_000043_957e4917>
  40e7cb:	mov    rcx,r12
  40e7ce:	mov    rdx,rdi
  40e7d1:	mov    r8,0xffffffffffffffff
  40e7d8:	call   40e2b0 <__swc_fn_7dafa2b1_000059_3ca3ac64>
  40e7dd:	mov    rcx,r12
  40e7e0:	mov    rdx,rdi
  40e7e3:	mov    r8d,0x9b8
  40e7e9:	mov    r9d,0x9b8
  40e7ef:	call   407750 <__swc_fn_7dafa2b1_000039_40d1e569>
  40e7f4:	mov    rdi,QWORD PTR [r12+0x20]
  40e7f9:	test   rdi,rdi
  40e7fc:	jne    40e7c0 <__swc_fn_7dafa2b1_000068_7d4c42bf+0xe0>
  40e7fe:	xor    eax,eax
  40e800:	xchg   QWORD PTR [r12+0x2a80],rax
  40e808:	test   rax,rax
  40e80b:	je     40e831 <__swc_fn_7dafa2b1_000068_7d4c42bf+0x151>
  40e80d:	cs nop WORD PTR [rax+rax*1+0x0]
  40e817:	nop    WORD PTR [rax+rax*1+0x0]
  40e820:	mov    rcx,rax
  40e823:	mov    rax,QWORD PTR [rax+0x78]
  40e827:	xor    edx,edx
  40e829:	xchg   DWORD PTR [rcx+0x70],edx
  40e82c:	test   rax,rax
  40e82f:	jne    40e820 <__swc_fn_7dafa2b1_000068_7d4c42bf+0x140>
  40e831:	mov    rax,QWORD PTR [r12+0x18]
  40e836:	mov    rdi,rax
  40e839:	test   rdi,rdi
  40e83c:	je     40e8d1 <__swc_fn_7dafa2b1_000068_7d4c42bf+0x1f1>
  40e842:	cs nop WORD PTR [rax+rax*1+0x0]
  40e84c:	nop    DWORD PTR [rax+0x0]
  40e850:	mov    rax,QWORD PTR [rdi+0x10]
  40e854:	mov    r8d,DWORD PTR [rdi+0x2c]
  40e858:	xor    r9d,r9d
  40e85b:	test   r8,r8
  40e85e:	jbe    40e8bd <__swc_fn_7dafa2b1_000068_7d4c42bf+0x1dd>
  40e860:	mov    ecx,r9d
  40e863:	shl    rcx,0x4
  40e867:	lea    rdx,[rdi+rcx*8+0x80]
  40e86f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40e873:	je     40e8b4 <__swc_fn_7dafa2b1_000068_7d4c42bf+0x1d4>
  40e875:	mov    DWORD PTR [rdx+0x28],0x0
  40e87c:	mov    rcx,rdi
  40e87f:	mov    QWORD PTR [rsp+0xd0],rax
  40e887:	mov    QWORD PTR [rsp+0xd8],r8
  40e88f:	mov    QWORD PTR [rsp+0xe0],r9
  40e897:	call   40d9e0 <__swc_fn_7dafa2b1_000014_afb279e2>
  40e89c:	mov    rax,QWORD PTR [rsp+0xd0]
  40e8a4:	mov    r8,QWORD PTR [rsp+0xd8]
  40e8ac:	mov    r9,QWORD PTR [rsp+0xe0]
  40e8b4:	add    r9,0x1
  40e8b8:	cmp    r9,r8
  40e8bb:	jb     40e860 <__swc_fn_7dafa2b1_000068_7d4c42bf+0x180>
  40e8bd:	mov    rcx,rdi
  40e8c0:	mov    rdi,rax
  40e8c3:	call   407630 <__swc_fn_7dafa2b1_000021_491ac000>
  40e8c8:	test   rdi,rdi
  40e8cb:	jne    40e850 <__swc_fn_7dafa2b1_000068_7d4c42bf+0x170>
  40e8d1:	mov    QWORD PTR [r12+0x18],0x0
  40e8da:	mov    QWORD PTR [r12+0x28],0x0
  40e8e3:	mov    rcx,rsi
  40e8e6:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  40e8eb:	mov    esi,0x8
  40e8f0:	xor    edi,edi
  40e8f2:	test   rsi,rsi
  40e8f5:	je     40e952 <__swc_fn_7dafa2b1_000068_7d4c42bf+0x272>
  40e8fb:	nop    DWORD PTR [rax+rax*1+0x0]
  40e900:	lea    r13,[rdi*8+0x0]
  40e908:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40e90d:	test   r14,r14
  40e910:	je     40e948 <__swc_fn_7dafa2b1_000068_7d4c42bf+0x268>
  40e912:	cs nop WORD PTR [rax+rax*1+0x0]
  40e91c:	nop    DWORD PTR [rax+0x0]
  40e920:	mov    rcx,r12
  40e923:	mov    rdx,r14
  40e926:	call   407df0 <__swc_fn_7dafa2b1_000054_ae20ea33>
  40e92b:	mov    rcx,r12
  40e92e:	mov    rdx,QWORD PTR [r14]
  40e931:	mov    r8,QWORD PTR [r14+0x8]
  40e935:	mov    r9,QWORD PTR [r14+0x10]
  40e939:	call   407750 <__swc_fn_7dafa2b1_000039_40d1e569>
  40e93e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40e943:	test   r14,r14
  40e946:	jne    40e920 <__swc_fn_7dafa2b1_000068_7d4c42bf+0x240>
  40e948:	add    rdi,0x1
  40e94c:	sub    rsi,0x1
  40e950:	jne    40e900 <__swc_fn_7dafa2b1_000068_7d4c42bf+0x220>
  40e952:	mov    rcx,r12
  40e955:	call   407ec0 <__swc_fn_7dafa2b1_000060_e6407a0a>
  40e95a:	lea    rcx,[r12+0x250]
  40e962:	mov    rdx,QWORD PTR [rcx]
  40e965:	mov    r8,QWORD PTR [r12+0x250]
  40e96d:	nop    DWORD PTR [rax]
  40e970:	mov    r9,r8
  40e973:	sub    r9,rdx
  40e976:	mov    rax,r8
  40e979:	lock cmpxchg QWORD PTR [rcx],r9
  40e97e:	cmp    rax,r8
  40e981:	je     40e988 <__swc_fn_7dafa2b1_000068_7d4c42bf+0x2a8>
  40e983:	mov    r8,rax
  40e986:	jmp    40e970 <__swc_fn_7dafa2b1_000068_7d4c42bf+0x290>
  40e988:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40e991:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40e99a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40e9a3:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40e9ac:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40e9b5:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40e9be:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40e9c7:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40e9d0:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40e9d9:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40e9e2:	add    rsp,0x190
  40e9e9:	pop    r14
  40e9eb:	pop    r13
  40e9ed:	pop    rsi
  40e9ee:	pop    rdi
  40e9ef:	pop    r12
  40e9f1:	ret
	...

000000000040ea00 <__swc_fn_7dafa2b1_000071_0d1ef36f>:
  40ea00:	sub    rsp,0x8
  40ea04:	mov    QWORD PTR [rdx+0x40],0x0
  40ea0c:	call   40b890 <__swc_fn_7dafa2b1_000064_b0d63361>
  40ea11:	add    rsp,0x8
  40ea15:	ret
	...

000000000040ea20 <__swc_fn_7dafa2b1_000074_518516c2>:
  40ea20:	sub    rsp,0x8
  40ea24:	call   407f90 <__swc_fn_7dafa2b1_000066_254b71af>
  40ea29:	add    rsp,0x8
  40ea2d:	ret
	...

000000000040ea30 <__swc_fn_7dafa2b1_000077_8b8614a7>:
  40ea30:	push   rbx
  40ea31:	push   rsi
  40ea32:	push   rdi
  40ea33:	push   r12
  40ea35:	push   r13
  40ea37:	push   r14
  40ea39:	push   r15
  40ea3b:	sub    rsp,0x20
  40ea3f:	mov    rbx,r11
  40ea42:	mov    rsi,rcx
  40ea45:	mov    rdi,rdx
  40ea48:	mov    r12,r8
  40ea4b:	mov    r13,r9
  40ea4e:	mov    r14,r10
  40ea51:	mov    rcx,QWORD PTR [rip+0x172e8]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40ea58:	test   rcx,rcx
  40ea5b:	jne    40ea6d <__swc_fn_7dafa2b1_000077_8b8614a7+0x3d>
  40ea5d:	call   40a1d0 <__swc_fn_7dafa2b1_000165_cf398896>
  40ea62:	lea    rcx,[rax+0x1]
  40ea66:	mov    QWORD PTR [rip+0x172d3],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40ea6d:	dec    rcx
  40ea70:	call   4119a0 <__swc_fn_7dafa2b1_000167_fce60b2b>
  40ea75:	mov    r15,rax
  40ea78:	lea    r11,[rip+0x147c1]        # 423240 <__swc_bss_base_7dafa2b1+0x200>
  40ea7f:	mov    rcx,r11
  40ea82:	call   407740 <__swc_fn_7dafa2b1_000036_8d895ba1>
  40ea87:	test   al,al
  40ea89:	jne    40ea9a <__swc_fn_7dafa2b1_000077_8b8614a7+0x6a>
  40ea8b:	mov    rcx,r11
  40ea8e:	call   40aa40 <__swc_fn_7dafa2b1_000034_25f19556>
  40ea93:	lea    r11,[rip+0x147a6]        # 423240 <__swc_bss_base_7dafa2b1+0x200>
  40ea9a:	mov    rcx,r11
  40ea9d:	mov    rdx,rsi
  40eaa0:	mov    r8,rdi
  40eaa3:	mov    r9,r12
  40eaa6:	mov    r10,r13
  40eaa9:	mov    rsi,r11
  40eaac:	mov    r11,r14
  40eaaf:	call   40dd50 <__swc_fn_7dafa2b1_000035_95622a2b>
  40eab4:	test   bl,bl
  40eab6:	je     40eadd <__swc_fn_7dafa2b1_000077_8b8614a7+0xad>
  40eab8:	mov    QWORD PTR [rsp+0x8],rsi
  40eabd:	lea    rax,[rip+0x368c]        # 412150 <__swc_rdata_base_7dafa2b1+0x40>
  40eac4:	mov    QWORD PTR [rsp+0x10],rax
  40eac9:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40eacf:	vmovups XMMWORD PTR [r15],xmm0
  40ead4:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40eadd:	mov    rax,rsi
  40eae0:	add    rsp,0x20
  40eae4:	pop    r15
  40eae6:	pop    r14
  40eae8:	pop    r13
  40eaea:	pop    r12
  40eaec:	pop    rdi
  40eaed:	pop    rsi
  40eaee:	pop    rbx
  40eaef:	ret

000000000040eaf0 <__swc_fn_7dafa2b1_000080_c1514492>:
  40eaf0:	sub    rsp,0x8
  40eaf4:	mov    rax,rcx
  40eaf7:	test   rcx,rcx
  40eafa:	jne    40eb01 <__swc_fn_7dafa2b1_000080_c1514492+0x11>
  40eafc:	add    rsp,0x8
  40eb00:	ret
  40eb01:	lea    rcx,[rax-0x10]
  40eb05:	mov    rax,QWORD PTR [rax-0x10]
  40eb09:	mov    rdx,rax
  40eb0c:	call   40fb80 <__swc_fn_7dafa2b1_000113_49b378a9>
  40eb11:	add    rsp,0x8
  40eb15:	ret
	...

000000000040eb20 <__swc_fn_7dafa2b1_000083_31b501f2>:
  40eb20:	sub    rsp,0x8
  40eb24:	xor    r11d,r11d
  40eb27:	call   408250 <__swc_fn_7dafa2b1_000084_ddf2b8a1>
  40eb2c:	add    rsp,0x8
  40eb30:	ret
	...

000000000040eb40 <__swc_fn_7dafa2b1_000086_c45095aa>:
  40eb40:	push   rsi
  40eb41:	push   rdi
  40eb42:	push   r12
  40eb44:	push   r13
  40eb46:	push   r14
  40eb48:	push   r15
  40eb4a:	sub    rsp,0x68
  40eb4e:	mov    rsi,r9
  40eb51:	mov    rdi,rcx
  40eb54:	mov    r12,rdx
  40eb57:	mov    r13,r8
  40eb5a:	cmp    r8,r9
  40eb5d:	jne    40eb85 <__swc_fn_7dafa2b1_000086_c45095aa+0x45>
  40eb5f:	mov    rcx,rdi
  40eb62:	mov    rdx,r12
  40eb65:	xor    r8d,r8d
  40eb68:	call   4085a0 <__swc_fn_7dafa2b1_000090_a2d50c23>
  40eb6d:	test   al,al
  40eb6f:	je     40eb85 <__swc_fn_7dafa2b1_000086_c45095aa+0x45>
  40eb71:	mov    eax,0x1
  40eb76:	add    rsp,0x68
  40eb7a:	pop    r15
  40eb7c:	pop    r14
  40eb7e:	pop    r13
  40eb80:	pop    r12
  40eb82:	pop    rdi
  40eb83:	pop    rsi
  40eb84:	ret
  40eb85:	cmp    BYTE PTR [r12+0x2c],0xe
  40eb8b:	je     40eb9e <__swc_fn_7dafa2b1_000086_c45095aa+0x5e>
  40eb8d:	xor    eax,eax
  40eb8f:	add    rsp,0x68
  40eb93:	pop    r15
  40eb95:	pop    r14
  40eb97:	pop    r13
  40eb99:	pop    r12
  40eb9b:	pop    rdi
  40eb9c:	pop    rsi
  40eb9d:	ret
  40eb9e:	mov    r14,QWORD PTR [r12+0x98]
  40eba6:	mov    rax,QWORD PTR [r12+0xa0]
  40ebae:	mov    r12,rax
  40ebb1:	xor    r15d,r15d
  40ebb4:	test   r12,r12
  40ebb7:	je     40ec1f <__swc_fn_7dafa2b1_000086_c45095aa+0xdf>
  40ebb9:	nop    DWORD PTR [rax+0x0]
  40ebc0:	mov    QWORD PTR [rsp+0x58],r12
  40ebc5:	lea    r12,[r15*8+0x0]
  40ebcd:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40ebd2:	mov    rcx,rax
  40ebd5:	call   40c020 <__swc_fn_7dafa2b1_000082_754dcd57>
  40ebda:	cmp    BYTE PTR [rax+0x2c],0xe
  40ebde:	jne    40ec10 <__swc_fn_7dafa2b1_000086_c45095aa+0xd0>
  40ebe0:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40ebe5:	lea    r8,[r13+rcx*1+0x0]
  40ebea:	mov    rcx,rdi
  40ebed:	mov    rdx,rax
  40ebf0:	mov    r9,rsi
  40ebf3:	call   40eb40 <__swc_fn_7dafa2b1_000086_c45095aa>
  40ebf8:	test   al,al
  40ebfa:	je     40ec10 <__swc_fn_7dafa2b1_000086_c45095aa+0xd0>
  40ebfc:	mov    eax,0x1
  40ec01:	add    rsp,0x68
  40ec05:	pop    r15
  40ec07:	pop    r14
  40ec09:	pop    r13
  40ec0b:	pop    r12
  40ec0d:	pop    rdi
  40ec0e:	pop    rsi
  40ec0f:	ret
  40ec10:	add    r15,0x1
  40ec14:	mov    r12,QWORD PTR [rsp+0x58]
  40ec19:	sub    r12,0x1
  40ec1d:	jne    40ebc0 <__swc_fn_7dafa2b1_000086_c45095aa+0x80>
  40ec1f:	xor    eax,eax
  40ec21:	add    rsp,0x68
  40ec25:	pop    r15
  40ec27:	pop    r14
  40ec29:	pop    r13
  40ec2b:	pop    r12
  40ec2d:	pop    rdi
  40ec2e:	pop    rsi
  40ec2f:	ret

000000000040ec30 <__swc_fn_7dafa2b1_000089_386582f3>:
  40ec30:	push   rbp
  40ec31:	push   rbx
  40ec32:	push   rsi
  40ec33:	push   rdi
  40ec34:	push   r12
  40ec36:	push   r13
  40ec38:	push   r14
  40ec3a:	push   r15
  40ec3c:	sub    rsp,0x38
  40ec40:	mov    rbp,rsp
  40ec43:	mov    rbx,r11
  40ec46:	mov    rsi,rdx
  40ec49:	mov    rdi,r8
  40ec4c:	mov    r12,r9
  40ec4f:	mov    QWORD PTR [rsp+0x18],r9
  40ec54:	mov    r13,r10
  40ec57:	movzx  r14d,BYTE PTR [rbp+0x80]
  40ec5f:	movzx  r15d,BYTE PTR [rbp+0x88]
  40ec67:	test   r11,r11
  40ec6a:	je     40ec70 <__swc_fn_7dafa2b1_000089_386582f3+0x40>
  40ec6c:	xor    eax,eax
  40ec6e:	mov    BYTE PTR [rbx],al
  40ec70:	test   r12,r12
  40ec73:	je     40ec7e <__swc_fn_7dafa2b1_000089_386582f3+0x4e>
  40ec75:	mov    QWORD PTR [r12+0x8],0x0
  40ec7e:	test   rcx,rcx
  40ec81:	je     40ec88 <__swc_fn_7dafa2b1_000089_386582f3+0x58>
  40ec83:	test   rsi,rsi
  40ec86:	jne    40ec9b <__swc_fn_7dafa2b1_000089_386582f3+0x6b>
  40ec88:	xor    eax,eax
  40ec8a:	add    rsp,0x38
  40ec8e:	pop    r15
  40ec90:	pop    r14
  40ec92:	pop    r13
  40ec94:	pop    r12
  40ec96:	pop    rdi
  40ec97:	pop    rsi
  40ec98:	pop    rbx
  40ec99:	pop    rbp
  40ec9a:	ret
  40ec9b:	call   40c020 <__swc_fn_7dafa2b1_000082_754dcd57>
  40eca0:	mov    r12,rax
  40eca3:	mov    al,r15b
  40eca6:	test   r15b,r15b
  40eca9:	jne    40ecb9 <__swc_fn_7dafa2b1_000089_386582f3+0x89>
  40ecab:	mov    eax,DWORD PTR [r12+0x28]
  40ecb0:	and    eax,0x10000
  40ecb6:	setne  al
  40ecb9:	lea    r15,[rsp+0x8]
  40ecbe:	mov    QWORD PTR [rsp+0x20],r15
  40ecc3:	rex mov BYTE PTR [rsp+0x8],al
  40ecc8:	test   DWORD PTR [rsi+0x28],0x400000
  40eccf:	je     40ed07 <__swc_fn_7dafa2b1_000089_386582f3+0xd7>
  40ecd1:	test   rsi,rsi
  40ecd4:	je     40ecf4 <__swc_fn_7dafa2b1_000089_386582f3+0xc4>
  40ecd6:	mov    rax,QWORD PTR [rsi+0x38]
  40ecda:	cmp    QWORD PTR [rax+0x10],rsi
  40ecde:	jne    40ecf4 <__swc_fn_7dafa2b1_000089_386582f3+0xc4>
  40ece0:	rex mov al,BYTE PTR [rsp+0x8]
  40ece5:	test   al,al
  40ece7:	sete   al
  40ecea:	test   r14b,r14b
  40eced:	sete   cl
  40ecf0:	test   al,cl
  40ecf2:	je     40ed07 <__swc_fn_7dafa2b1_000089_386582f3+0xd7>
  40ecf4:	xor    eax,eax
  40ecf6:	add    rsp,0x38
  40ecfa:	pop    r15
  40ecfc:	pop    r14
  40ecfe:	pop    r13
  40ed00:	pop    r12
  40ed02:	pop    rdi
  40ed03:	pop    rsi
  40ed04:	pop    rbx
  40ed05:	pop    rbp
  40ed06:	ret
  40ed07:	mov    r15,r12
  40ed0a:	test   r14b,r14b
  40ed0d:	jne    40ed24 <__swc_fn_7dafa2b1_000089_386582f3+0xf4>
  40ed0f:	cmp    BYTE PTR [r12+0x2c],0x6
  40ed15:	jne    40ed24 <__swc_fn_7dafa2b1_000089_386582f3+0xf4>
  40ed17:	mov    rcx,QWORD PTR [r12+0x40]
  40ed1c:	call   40c020 <__swc_fn_7dafa2b1_000082_754dcd57>
  40ed21:	mov    r15,rax
  40ed24:	test   r14b,r14b
  40ed27:	je     40ed2d <__swc_fn_7dafa2b1_000089_386582f3+0xfd>
  40ed29:	mov    r15,QWORD PTR [r15+0x30]
  40ed2d:	mov    rcx,rsi
  40ed30:	call   40c020 <__swc_fn_7dafa2b1_000082_754dcd57>
  40ed35:	mov    rsi,rax
  40ed38:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40ed3d:	je     40ed74 <__swc_fn_7dafa2b1_000089_386582f3+0x144>
  40ed3f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40ed44:	je     40ed74 <__swc_fn_7dafa2b1_000089_386582f3+0x144>
  40ed46:	mov    eax,DWORD PTR [rsi+0x28]
  40ed49:	and    eax,0x10000
  40ed4f:	je     40ed74 <__swc_fn_7dafa2b1_000089_386582f3+0x144>
  40ed51:	rex mov al,BYTE PTR [rsp+0x8]
  40ed56:	test   al,al
  40ed58:	jne    40ed6d <__swc_fn_7dafa2b1_000089_386582f3+0x13d>
  40ed5a:	xor    eax,eax
  40ed5c:	add    rsp,0x38
  40ed60:	pop    r15
  40ed62:	pop    r14
  40ed64:	pop    r13
  40ed66:	pop    r12
  40ed68:	pop    rdi
  40ed69:	pop    rsi
  40ed6a:	pop    rbx
  40ed6b:	pop    rbp
  40ed6c:	ret
  40ed6d:	mov    rax,QWORD PTR [rsi+0x30]
  40ed71:	mov    rsi,rax
  40ed74:	mov    r14b,r13b
  40ed77:	test   rbx,rbx
  40ed7a:	je     40edb0 <__swc_fn_7dafa2b1_000089_386582f3+0x180>
  40ed7c:	cmp    BYTE PTR [r12+0x2c],0x6
  40ed82:	jne    40edb0 <__swc_fn_7dafa2b1_000089_386582f3+0x180>
  40ed84:	lea    rdx,[rip+0x33f5]        # 412180 <__swc_rdata_base_7dafa2b1+0x70>
  40ed8b:	mov    rcx,rsi
  40ed8e:	xor    r8d,r8d
  40ed91:	call   4085a0 <__swc_fn_7dafa2b1_000090_a2d50c23>
  40ed96:	test   al,al
  40ed98:	je     40edb0 <__swc_fn_7dafa2b1_000089_386582f3+0x180>
  40ed9a:	mov    BYTE PTR [rbx],0x1
  40ed9d:	xor    eax,eax
  40ed9f:	add    rsp,0x38
  40eda3:	pop    r15
  40eda5:	pop    r14
  40eda7:	pop    r13
  40eda9:	pop    r12
  40edab:	pop    rdi
  40edac:	pop    rsi
  40edad:	pop    rbx
  40edae:	pop    rbp
  40edaf:	ret
  40edb0:	test   rdi,rdi
  40edb3:	jne    40edcd <__swc_fn_7dafa2b1_000089_386582f3+0x19d>
  40edb5:	test   r13b,r13b
  40edb8:	jne    40edcd <__swc_fn_7dafa2b1_000089_386582f3+0x19d>
  40edba:	xor    eax,eax
  40edbc:	add    rsp,0x38
  40edc0:	pop    r15
  40edc2:	pop    r14
  40edc4:	pop    r13
  40edc6:	pop    r12
  40edc8:	pop    rdi
  40edc9:	pop    rsi
  40edca:	pop    rbx
  40edcb:	pop    rbp
  40edcc:	ret
  40edcd:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40edd2:	jne    40ee88 <__swc_fn_7dafa2b1_000089_386582f3+0x258>
  40edd8:	mov    rcx,r15
  40eddb:	mov    rdx,rsi
  40edde:	xor    r8d,r8d
  40ede1:	call   4085a0 <__swc_fn_7dafa2b1_000090_a2d50c23>
  40ede6:	test   al,al
  40ede8:	jne    40ee88 <__swc_fn_7dafa2b1_000089_386582f3+0x258>
  40edee:	test   DWORD PTR [rsi+0x28],0x10000
  40edf5:	je     40ee13 <__swc_fn_7dafa2b1_000089_386582f3+0x1e3>
  40edf7:	rex mov al,BYTE PTR [rsp+0x8]
  40edfc:	test   al,al
  40edfe:	jne    40ee13 <__swc_fn_7dafa2b1_000089_386582f3+0x1e3>
  40ee00:	xor    eax,eax
  40ee02:	add    rsp,0x38
  40ee06:	pop    r15
  40ee08:	pop    r14
  40ee0a:	pop    r13
  40ee0c:	pop    r12
  40ee0e:	pop    rdi
  40ee0f:	pop    rsi
  40ee10:	pop    rbx
  40ee11:	pop    rbp
  40ee12:	ret
  40ee13:	test   rdi,rdi
  40ee16:	jne    40ee2b <__swc_fn_7dafa2b1_000089_386582f3+0x1fb>
  40ee18:	xor    eax,eax
  40ee1a:	add    rsp,0x38
  40ee1e:	pop    r15
  40ee20:	pop    r14
  40ee22:	pop    r13
  40ee24:	pop    r12
  40ee26:	pop    rdi
  40ee27:	pop    rsi
  40ee28:	pop    rbx
  40ee29:	pop    rbp
  40ee2a:	ret
  40ee2b:	mov    rcx,QWORD PTR [rsi+0x40]
  40ee2f:	call   40c020 <__swc_fn_7dafa2b1_000082_754dcd57>
  40ee34:	mov    rsi,rax
  40ee37:	mov    rax,QWORD PTR [rdi]
  40ee3a:	mov    rdi,rax
  40ee3d:	test   rax,rax
  40ee40:	jne    40ee83 <__swc_fn_7dafa2b1_000089_386582f3+0x253>
  40ee42:	test   rbx,rbx
  40ee45:	je     40ee83 <__swc_fn_7dafa2b1_000089_386582f3+0x253>
  40ee47:	mov    rcx,r15
  40ee4a:	mov    rdx,rsi
  40ee4d:	xor    r8d,r8d
  40ee50:	call   4085a0 <__swc_fn_7dafa2b1_000090_a2d50c23>
  40ee55:	mov    rcx,rax
  40ee58:	test   al,al
  40ee5a:	jne    40ee7c <__swc_fn_7dafa2b1_000089_386582f3+0x24c>
  40ee5c:	mov    rcx,r15
  40ee5f:	mov    rdx,rsi
  40ee62:	call   40c060 <__swc_fn_7dafa2b1_000085_1edf7c76>
  40ee67:	mov    rcx,rax
  40ee6a:	test   al,al
  40ee6c:	jne    40ee7c <__swc_fn_7dafa2b1_000089_386582f3+0x24c>
  40ee6e:	mov    rcx,rsi
  40ee71:	mov    rdx,r15
  40ee74:	call   40c060 <__swc_fn_7dafa2b1_000085_1edf7c76>
  40ee79:	mov    rcx,rax
  40ee7c:	test   cl,cl
  40ee7e:	setne  al
  40ee81:	mov    BYTE PTR [rbx],al
  40ee83:	xor    eax,eax
  40ee85:	mov    r14b,al
  40ee88:	test   rdi,rdi
  40ee8b:	jne    40eea5 <__swc_fn_7dafa2b1_000089_386582f3+0x275>
  40ee8d:	test   r14b,r14b
  40ee90:	jne    40eea5 <__swc_fn_7dafa2b1_000089_386582f3+0x275>
  40ee92:	xor    eax,eax
  40ee94:	add    rsp,0x38
  40ee98:	pop    r15
  40ee9a:	pop    r14
  40ee9c:	pop    r13
  40ee9e:	pop    r12
  40eea0:	pop    rdi
  40eea1:	pop    rsi
  40eea2:	pop    rbx
  40eea3:	pop    rbp
  40eea4:	ret
  40eea5:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40eeaa:	je     40eeb6 <__swc_fn_7dafa2b1_000089_386582f3+0x286>
  40eeac:	mov    r12,QWORD PTR [rsp+0x18]
  40eeb1:	jmp    40ef3e <__swc_fn_7dafa2b1_000089_386582f3+0x30e>
  40eeb6:	mov    r12,QWORD PTR [rsp+0x18]
  40eebb:	test   r12,r12
  40eebe:	jne    40eed2 <__swc_fn_7dafa2b1_000089_386582f3+0x2a2>
  40eec0:	mov    rcx,r15
  40eec3:	mov    rdx,rsi
  40eec6:	xor    r8d,r8d
  40eec9:	call   4085a0 <__swc_fn_7dafa2b1_000090_a2d50c23>
  40eece:	test   al,al
  40eed0:	jne    40ef3e <__swc_fn_7dafa2b1_000089_386582f3+0x30e>
  40eed2:	test   DWORD PTR [rsi+0x28],0x10000
  40eed9:	je     40eef7 <__swc_fn_7dafa2b1_000089_386582f3+0x2c7>
  40eedb:	rex mov al,BYTE PTR [rsp+0x8]
  40eee0:	test   al,al
  40eee2:	jne    40eef7 <__swc_fn_7dafa2b1_000089_386582f3+0x2c7>
  40eee4:	xor    eax,eax
  40eee6:	add    rsp,0x38
  40eeea:	pop    r15
  40eeec:	pop    r14
  40eeee:	pop    r13
  40eef0:	pop    r12
  40eef2:	pop    rdi
  40eef3:	pop    rsi
  40eef4:	pop    rbx
  40eef5:	pop    rbp
  40eef6:	ret
  40eef7:	test   rdi,rdi
  40eefa:	jne    40ef0f <__swc_fn_7dafa2b1_000089_386582f3+0x2df>
  40eefc:	xor    eax,eax
  40eefe:	add    rsp,0x38
  40ef02:	pop    r15
  40ef04:	pop    r14
  40ef06:	pop    r13
  40ef08:	pop    r12
  40ef0a:	pop    rdi
  40ef0b:	pop    rsi
  40ef0c:	pop    rbx
  40ef0d:	pop    rbp
  40ef0e:	ret
  40ef0f:	cmp    QWORD PTR [rdi+0x8],0x0
  40ef14:	jne    40ef29 <__swc_fn_7dafa2b1_000089_386582f3+0x2f9>
  40ef16:	xor    eax,eax
  40ef18:	add    rsp,0x38
  40ef1c:	pop    r15
  40ef1e:	pop    r14
  40ef20:	pop    r13
  40ef22:	pop    r12
  40ef24:	pop    rdi
  40ef25:	pop    rsi
  40ef26:	pop    rbx
  40ef27:	pop    rbp
  40ef28:	ret
  40ef29:	mov    rax,QWORD PTR [rdi+0x8]
  40ef2d:	mov    rax,QWORD PTR [rax]
  40ef30:	mov    rsi,rax
  40ef33:	mov    rdi,QWORD PTR [rdi]
  40ef36:	mov    eax,0x1
  40ef3b:	mov    r14b,al
  40ef3e:	test   rdi,rdi
  40ef41:	mov    rbx,QWORD PTR [rsp+0x20]
  40ef46:	jne    40ef90 <__swc_fn_7dafa2b1_000089_386582f3+0x360>
  40ef48:	test   r14b,r14b
  40ef4b:	je     40ef7d <__swc_fn_7dafa2b1_000089_386582f3+0x34d>
  40ef4d:	test   r12,r12
  40ef50:	je     40ef7d <__swc_fn_7dafa2b1_000089_386582f3+0x34d>
  40ef52:	mov    rcx,r15
  40ef55:	mov    rdx,rsi
  40ef58:	xor    r8d,r8d
  40ef5b:	mov    r9,r12
  40ef5e:	mov    rbx,QWORD PTR [rsp+0x20]
  40ef63:	movzx  r10d,BYTE PTR [rbx]
  40ef67:	call   40eb20 <__swc_fn_7dafa2b1_000083_31b501f2>
  40ef6c:	add    rsp,0x38
  40ef70:	pop    r15
  40ef72:	pop    r14
  40ef74:	pop    r13
  40ef76:	pop    r12
  40ef78:	pop    rdi
  40ef79:	pop    rsi
  40ef7a:	pop    rbx
  40ef7b:	pop    rbp
  40ef7c:	ret
  40ef7d:	xor    eax,eax
  40ef7f:	add    rsp,0x38
  40ef83:	pop    r15
  40ef85:	pop    r14
  40ef87:	pop    r13
  40ef89:	pop    r12
  40ef8b:	pop    rdi
  40ef8c:	pop    rsi
  40ef8d:	pop    rbx
  40ef8e:	pop    rbp
  40ef8f:	ret
  40ef90:	mov    r13,rsi
  40ef93:	mov    QWORD PTR [rsp+0x28],rdi
  40ef98:	cmp    BYTE PTR [r15+0x2c],0xe
  40ef9d:	sete   al
  40efa0:	mov    r14b,al
  40efa3:	jne    40efb7 <__swc_fn_7dafa2b1_000089_386582f3+0x387>
  40efa5:	mov    rcx,rsi
  40efa8:	mov    rdx,r15
  40efab:	call   40c060 <__swc_fn_7dafa2b1_000085_1edf7c76>
  40efb0:	mov    r14b,al
  40efb3:	test   al,al
  40efb5:	jne    40efec <__swc_fn_7dafa2b1_000089_386582f3+0x3bc>
  40efb7:	cmp    BYTE PTR [r15+0x2c],0x12
  40efbc:	je     40efec <__swc_fn_7dafa2b1_000089_386582f3+0x3bc>
  40efbe:	mov    rcx,r15
  40efc1:	mov    rdx,rsi
  40efc4:	mov    r8,rdi
  40efc7:	mov    r9,r12
  40efca:	mov    rax,rbx
  40efcd:	movzx  r10d,BYTE PTR [rax]
  40efd1:	call   40eb20 <__swc_fn_7dafa2b1_000083_31b501f2>
  40efd6:	test   rax,rax
  40efd9:	je     40efec <__swc_fn_7dafa2b1_000089_386582f3+0x3bc>
  40efdb:	add    rsp,0x38
  40efdf:	pop    r15
  40efe1:	pop    r14
  40efe3:	pop    r13
  40efe5:	pop    r12
  40efe7:	pop    rdi
  40efe8:	pop    rsi
  40efe9:	pop    rbx
  40efea:	pop    rbp
  40efeb:	ret
  40efec:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40eff1:	jne    40f010 <__swc_fn_7dafa2b1_000089_386582f3+0x3e0>
  40eff3:	mov    rax,QWORD PTR [rsi+0xd8]
  40effa:	test   rax,rax
  40effd:	je     40f010 <__swc_fn_7dafa2b1_000089_386582f3+0x3e0>
  40efff:	add    rdi,QWORD PTR [rax+0x8]
  40f003:	mov    rax,QWORD PTR [rdi]
  40f006:	sub    rdi,QWORD PTR [rax+0x8]
  40f00a:	mov    rax,QWORD PTR [rax]
  40f00d:	mov    rsi,rax
  40f010:	test   r14b,r14b
  40f013:	je     40f03f <__swc_fn_7dafa2b1_000089_386582f3+0x40f>
  40f015:	mov    rcx,r15
  40f018:	mov    rdx,rsi
  40f01b:	mov    r8,rdi
  40f01e:	mov    r9,r13
  40f021:	mov    r14,QWORD PTR [rsp+0x28]
  40f026:	mov    r10,r14
  40f029:	call   408480 <__swc_fn_7dafa2b1_000087_ea575bb3>
  40f02e:	add    rsp,0x38
  40f032:	pop    r15
  40f034:	pop    r14
  40f036:	pop    r13
  40f038:	pop    r12
  40f03a:	pop    rdi
  40f03b:	pop    rsi
  40f03c:	pop    rbx
  40f03d:	pop    rbp
  40f03e:	ret
  40f03f:	mov    rcx,r15
  40f042:	mov    rdx,rsi
  40f045:	mov    r8,rdi
  40f048:	mov    r9,r12
  40f04b:	movzx  r10d,BYTE PTR [rbx]
  40f04f:	call   40eb20 <__swc_fn_7dafa2b1_000083_31b501f2>
  40f054:	add    rsp,0x38
  40f058:	pop    r15
  40f05a:	pop    r14
  40f05c:	pop    r13
  40f05e:	pop    r12
  40f060:	pop    rdi
  40f061:	pop    rsi
  40f062:	pop    rbx
  40f063:	pop    rbp
  40f064:	ret
	...

000000000040f070 <__swc_fn_7dafa2b1_000092_8252f8c0>:
  40f070:	push   rbx
  40f071:	push   rsi
  40f072:	sub    rsp,0x18
  40f076:	mov    rbx,rcx
  40f079:	mov    rcx,QWORD PTR [rip+0x16cc0]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40f080:	test   rcx,rcx
  40f083:	jne    40f095 <__swc_fn_7dafa2b1_000092_8252f8c0+0x25>
  40f085:	call   40a1d0 <__swc_fn_7dafa2b1_000165_cf398896>
  40f08a:	lea    rcx,[rax+0x1]
  40f08e:	mov    QWORD PTR [rip+0x16cab],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40f095:	dec    rcx
  40f098:	call   4119a0 <__swc_fn_7dafa2b1_000167_fce60b2b>
  40f09d:	mov    rsi,rax
  40f0a0:	mov    rax,QWORD PTR [rsi+0x8]
  40f0a4:	test   rax,rax
  40f0a7:	jne    40f0f7 <__swc_fn_7dafa2b1_000092_8252f8c0+0x87>
  40f0a9:	call   40c150 <__swc_fn_7dafa2b1_000091_3d2f5a0d>
  40f0ae:	test   al,al
  40f0b0:	jne    40f0f7 <__swc_fn_7dafa2b1_000092_8252f8c0+0x87>
  40f0b2:	lea    rdx,[rip+0x14187]        # 423240 <__swc_bss_base_7dafa2b1+0x200>
  40f0b9:	mov    rcx,rdx
  40f0bc:	call   407740 <__swc_fn_7dafa2b1_000036_8d895ba1>
  40f0c1:	test   al,al
  40f0c3:	jne    40f0d4 <__swc_fn_7dafa2b1_000092_8252f8c0+0x64>
  40f0c5:	mov    rcx,rdx
  40f0c8:	call   40aa40 <__swc_fn_7dafa2b1_000034_25f19556>
  40f0cd:	lea    rdx,[rip+0x1416c]        # 423240 <__swc_bss_base_7dafa2b1+0x200>
  40f0d4:	mov    QWORD PTR [rsp+0x8],rdx
  40f0d9:	lea    rax,[rip+0x3070]        # 412150 <__swc_rdata_base_7dafa2b1+0x40>
  40f0e0:	mov    QWORD PTR [rsp+0x10],rax
  40f0e5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f0eb:	vmovups XMMWORD PTR [rsi],xmm0
  40f0ef:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f0f7:	vmovups xmm0,XMMWORD PTR [rsi]
  40f0fb:	vmovups XMMWORD PTR [rbx],xmm0
  40f0ff:	mov    rax,rbx
  40f102:	add    rsp,0x18
  40f106:	pop    rsi
  40f107:	pop    rbx
  40f108:	ret
  40f109:	add    BYTE PTR [rax],al
  40f10b:	add    BYTE PTR [rax],al
  40f10d:	add    BYTE PTR [rax],al
	...

000000000040f110 <__swc_fn_7dafa2b1_000095_337e587a>:
  40f110:	sub    rsp,0x8
  40f114:	call   409360 <__swc_fn_7dafa2b1_000117_86a7fb9e>
  40f119:	add    rsp,0x8
  40f11d:	ret
	...

000000000040f120 <__swc_fn_7dafa2b1_000098_00f01091>:
  40f120:	push   rbx
  40f121:	push   rsi
  40f122:	sub    rsp,0x28
  40f126:	mov    rbx,rcx
  40f129:	xor    esi,esi
  40f12b:	jmp    40f140 <__swc_fn_7dafa2b1_000098_00f01091+0x20>
  40f12d:	nop    DWORD PTR [rax]
  40f130:	mov    QWORD PTR [rbx+0x28],rsi
  40f134:	mov    rsi,rbx
  40f137:	mov    rbx,rax
  40f13a:	nop    WORD PTR [rax+rax*1+0x0]
  40f140:	test   rbx,rbx
  40f143:	je     40f1a3 <__swc_fn_7dafa2b1_000098_00f01091+0x83>
  40f145:	mov    rcx,rbx
  40f148:	mov    edx,0x1
  40f14d:	call   408200 <__swc_fn_7dafa2b1_000078_a120bd2b>
  40f152:	cmp    rax,0x1
  40f156:	jne    40f1a3 <__swc_fn_7dafa2b1_000098_00f01091+0x83>
  40f158:	mov    r10,QWORD PTR [rbx+0x18]
  40f15c:	mov    rcx,r10
  40f15f:	mov    edx,0x1
  40f164:	call   408200 <__swc_fn_7dafa2b1_000078_a120bd2b>
  40f169:	cmp    rax,0x1
  40f16d:	jne    40f17c <__swc_fn_7dafa2b1_000098_00f01091+0x5c>
  40f16f:	mov    rcx,r10
  40f172:	call   40c2f0 <__swc_fn_7dafa2b1_000097_4c97e0db>
  40f177:	test   rax,rax
  40f17a:	jne    40f130 <__swc_fn_7dafa2b1_000098_00f01091+0x10>
  40f17c:	mov    rax,QWORD PTR [rbx+0x20]
  40f180:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f185:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f18b:	lea    rcx,[rsp+0x8]
  40f190:	mov    rdx,rbx
  40f193:	mov    r8d,0x30
  40f199:	mov    rbx,rax
  40f19c:	call   408960 <__swc_fn_7dafa2b1_000096_ad982b35>
  40f1a1:	jmp    40f140 <__swc_fn_7dafa2b1_000098_00f01091+0x20>
  40f1a3:	test   rsi,rsi
  40f1a6:	jne    40f1af <__swc_fn_7dafa2b1_000098_00f01091+0x8f>
  40f1a8:	add    rsp,0x28
  40f1ac:	pop    rsi
  40f1ad:	pop    rbx
  40f1ae:	ret
  40f1af:	mov    rax,rsi
  40f1b2:	mov    rsi,QWORD PTR [rsi+0x28]
  40f1b6:	mov    rbx,QWORD PTR [rax+0x20]
  40f1ba:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f1bf:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f1c5:	lea    rcx,[rsp+0x18]
  40f1ca:	mov    rdx,rax
  40f1cd:	mov    r8d,0x30
  40f1d3:	call   408960 <__swc_fn_7dafa2b1_000096_ad982b35>
  40f1d8:	jmp    40f140 <__swc_fn_7dafa2b1_000098_00f01091+0x20>
  40f1dd:	add    BYTE PTR [rax],al
	...

000000000040f1e0 <__swc_fn_7dafa2b1_000101_eab3874f>:
  40f1e0:	push   rbx
  40f1e1:	push   rsi
  40f1e2:	push   rdi
  40f1e3:	push   r12
  40f1e5:	push   r13
  40f1e7:	sub    rsp,0x20
  40f1eb:	mov    rbx,rcx
  40f1ee:	lea    rsi,[rcx+0x6f8]
  40f1f5:	mov    edi,0x4
  40f1fa:	mov    r12,rsi
  40f1fd:	test   rdi,rdi
  40f200:	je     40f24a <__swc_fn_7dafa2b1_000101_eab3874f+0x6a>
  40f202:	cs nop WORD PTR [rax+rax*1+0x0]
  40f20c:	nop    DWORD PTR [rax+0x0]
  40f210:	mov    rcx,QWORD PTR [r12+0x10]
  40f215:	mov    QWORD PTR [r12+0x10],0x0
  40f21e:	vxorps xmm0,xmm0,xmm0
  40f222:	vmovups XMMWORD PTR [r12],xmm0
  40f228:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f22f:	mov    DWORD PTR [r12+0x20],0x0
  40f238:	call   4089c0 <__swc_fn_7dafa2b1_000099_b4c6da83>
  40f23d:	add    r12,0x90
  40f244:	sub    rdi,0x1
  40f248:	jne    40f210 <__swc_fn_7dafa2b1_000101_eab3874f+0x30>
  40f24a:	mov    rax,QWORD PTR [rbx+0x938]
  40f251:	mov    rdi,rax
  40f254:	test   rdi,rdi
  40f257:	je     40f2b1 <__swc_fn_7dafa2b1_000101_eab3874f+0xd1>
  40f259:	nop    DWORD PTR [rax+0x0]
  40f260:	mov    r12d,0x10
  40f266:	lea    r13,[rdi+0x18]
  40f26a:	test   r12,r12
  40f26d:	je     40f2a6 <__swc_fn_7dafa2b1_000101_eab3874f+0xc6>
  40f26f:	nop
  40f270:	mov    rcx,QWORD PTR [r13+0x10]
  40f274:	mov    QWORD PTR [r13+0x10],0x0
  40f27c:	vxorps xmm0,xmm0,xmm0
  40f280:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f286:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f28c:	mov    DWORD PTR [r13+0x20],0x0
  40f294:	call   4089c0 <__swc_fn_7dafa2b1_000099_b4c6da83>
  40f299:	add    r13,0x90
  40f2a0:	sub    r12,0x1
  40f2a4:	jne    40f270 <__swc_fn_7dafa2b1_000101_eab3874f+0x90>
  40f2a6:	mov    rax,QWORD PTR [rdi]
  40f2a9:	mov    rdi,rax
  40f2ac:	test   rax,rax
  40f2af:	jne    40f260 <__swc_fn_7dafa2b1_000101_eab3874f+0x80>
  40f2b1:	vxorps xmm0,xmm0,xmm0
  40f2b5:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f2bd:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f2c7:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f2d1:	mov    edi,0x4
  40f2d6:	mov    r12,rsi
  40f2d9:	lea    rsi,[rsi+0x38]
  40f2dd:	test   rdi,rdi
  40f2e0:	je     40f30c <__swc_fn_7dafa2b1_000101_eab3874f+0x12c>
  40f2e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f2ec:	nop    DWORD PTR [rax+0x0]
  40f2f0:	mov    rcx,rsi
  40f2f3:	call   40d180 <__swc_fn_7dafa2b1_000157_232ffa22>
  40f2f8:	add    rsi,0x90
  40f2ff:	add    r12,0x90
  40f306:	sub    rdi,0x1
  40f30a:	jne    40f2f0 <__swc_fn_7dafa2b1_000101_eab3874f+0x110>
  40f30c:	mov    rax,QWORD PTR [rbx+0x938]
  40f313:	mov    rdi,rax
  40f316:	mov    QWORD PTR [rbx+0x938],0x0
  40f321:	test   rdi,rdi
  40f324:	je     40f395 <__swc_fn_7dafa2b1_000101_eab3874f+0x1b5>
  40f32a:	nop    WORD PTR [rax+rax*1+0x0]
  40f330:	mov    esi,0x10
  40f335:	lea    r12,[rdi+0x18]
  40f339:	lea    r13,[rdi+0x50]
  40f33d:	test   rsi,rsi
  40f340:	je     40f36c <__swc_fn_7dafa2b1_000101_eab3874f+0x18c>
  40f342:	cs nop WORD PTR [rax+rax*1+0x0]
  40f34c:	nop    DWORD PTR [rax+0x0]
  40f350:	mov    rcx,r13
  40f353:	call   40d180 <__swc_fn_7dafa2b1_000157_232ffa22>
  40f358:	add    r13,0x90
  40f35f:	add    r12,0x90
  40f366:	sub    rsi,0x1
  40f36a:	jne    40f350 <__swc_fn_7dafa2b1_000101_eab3874f+0x170>
  40f36c:	mov    rax,QWORD PTR [rdi]
  40f36f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f374:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f37a:	lea    rcx,[rsp+0x8]
  40f37f:	mov    rdx,rdi
  40f382:	mov    r8d,0x918
  40f388:	mov    rdi,rax
  40f38b:	call   408960 <__swc_fn_7dafa2b1_000096_ad982b35>
  40f390:	test   rdi,rdi
  40f393:	jne    40f330 <__swc_fn_7dafa2b1_000101_eab3874f+0x150>
  40f395:	lea    rcx,[rbx+0x68]
  40f399:	call   40d180 <__swc_fn_7dafa2b1_000157_232ffa22>
  40f39e:	add    rsp,0x20
  40f3a2:	pop    r13
  40f3a4:	pop    r12
  40f3a6:	pop    rdi
  40f3a7:	pop    rsi
  40f3a8:	pop    rbx
  40f3a9:	ret
  40f3aa:	add    BYTE PTR [rax],al
  40f3ac:	add    BYTE PTR [rax],al
	...

000000000040f3b0 <__swc_fn_7dafa2b1_000104_5589fdbd>:
  40f3b0:	xor    eax,eax
  40f3b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f3bc:	nop    DWORD PTR [rax+0x0]
  40f3c0:	mov    r9,r8
  40f3c3:	sub    r9,rax
  40f3c6:	cmp    r9,0x40
  40f3ca:	jb     40f408 <__swc_fn_7dafa2b1_000104_5589fdbd+0x58>
  40f3cc:	lea    r9,[rcx+rax*1]
  40f3d0:	lea    r10,[rdx+rax*1]
  40f3d4:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f3da:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40f3e0:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40f3e6:	vmovups xmm3,XMMWORD PTR [r10]
  40f3eb:	vmovups XMMWORD PTR [r9],xmm3
  40f3f0:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40f3f6:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40f3fc:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40f402:	lea    rax,[rax+0x40]
  40f406:	jmp    40f3c0 <__swc_fn_7dafa2b1_000104_5589fdbd+0x10>
  40f408:	nop    DWORD PTR [rax+rax*1+0x0]
  40f410:	mov    r9,r8
  40f413:	sub    r9,rax
  40f416:	cmp    r9,0x10
  40f41a:	jb     40f434 <__swc_fn_7dafa2b1_000104_5589fdbd+0x84>
  40f41c:	lea    r9,[rdx+rax*1]
  40f420:	lea    r10,[rcx+rax*1]
  40f424:	vmovups xmm0,XMMWORD PTR [r9]
  40f429:	vmovups XMMWORD PTR [r10],xmm0
  40f42e:	lea    rax,[rax+0x10]
  40f432:	jmp    40f410 <__swc_fn_7dafa2b1_000104_5589fdbd+0x60>
  40f434:	cs nop WORD PTR [rax+rax*1+0x0]
  40f43e:	xchg   ax,ax
  40f440:	mov    r9,r8
  40f443:	sub    r9,rax
  40f446:	cmp    r9,0x8
  40f44a:	jb     40f45d <__swc_fn_7dafa2b1_000104_5589fdbd+0xad>
  40f44c:	lea    r9,[rcx+rax*1]
  40f450:	mov    r10,QWORD PTR [rdx+rax*1]
  40f454:	mov    QWORD PTR [r9],r10
  40f457:	lea    rax,[rax+0x8]
  40f45b:	jmp    40f440 <__swc_fn_7dafa2b1_000104_5589fdbd+0x90>
  40f45d:	cmp    rax,r8
  40f460:	jae    40f480 <__swc_fn_7dafa2b1_000104_5589fdbd+0xd0>
  40f462:	cs nop WORD PTR [rax+rax*1+0x0]
  40f46c:	nop    DWORD PTR [rax+0x0]
  40f470:	mov    r9b,BYTE PTR [rdx+rax*1]
  40f474:	mov    BYTE PTR [rcx+rax*1],r9b
  40f478:	inc    rax
  40f47b:	cmp    rax,r8
  40f47e:	jb     40f470 <__swc_fn_7dafa2b1_000104_5589fdbd+0xc0>
  40f480:	ret
	...

000000000040f4a0 <__swc_fn_7dafa2b1_000107_4796e893>:
  40f4a0:	push   rbx
  40f4a1:	push   r12
  40f4a3:	push   rdi
  40f4a4:	push   rsi
  40f4a5:	push   r13
  40f4a7:	push   r14
  40f4a9:	push   r15
  40f4ab:	sub    rsp,0x170
  40f4b2:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40f4bb:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40f4c4:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40f4cd:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40f4d6:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40f4df:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40f4e8:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40f4f1:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40f4fa:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40f503:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40f50c:	mov    ebx,edx
  40f50e:	mov    QWORD PTR [rsp+0xa8],rbx
  40f516:	mov    r12d,ecx
  40f519:	test   edx,edx
  40f51b:	jne    40f532 <__swc_fn_7dafa2b1_000107_4796e893+0x92>
  40f51d:	xor    eax,eax
  40f51f:	add    rsp,0x170
  40f526:	pop    r15
  40f528:	pop    r14
  40f52a:	pop    r13
  40f52c:	pop    rsi
  40f52d:	pop    rdi
  40f52e:	pop    r12
  40f530:	pop    rbx
  40f531:	ret
  40f532:	lea    rdi,[rip+0x2f77]        # 4124b0 <__swc_rdata_base_7dafa2b1+0x3a0>
  40f539:	mov    esi,0x90000
  40f53e:	xor    eax,eax
  40f540:	call   407090 <open@plt>
  40f545:	mov    r13,rax
  40f548:	mov    QWORD PTR [rsp+0xb0],rax
  40f550:	test   eax,eax
  40f552:	jge    40f55b <__swc_fn_7dafa2b1_000107_4796e893+0xbb>
  40f554:	xor    eax,eax
  40f556:	jmp    40fa76 <__swc_fn_7dafa2b1_000107_4796e893+0x5d6>
  40f55b:	nop    DWORD PTR [rax+rax*1+0x0]
  40f560:	movsxd rdi,r13d
  40f563:	mov    esi,0x2
  40f568:	xor    eax,eax
  40f56a:	call   407110 <flock@plt>
  40f56f:	test   eax,eax
  40f571:	je     40f590 <__swc_fn_7dafa2b1_000107_4796e893+0xf0>
  40f573:	xor    eax,eax
  40f575:	call   407120 <__errno_location@plt>
  40f57a:	cmp    DWORD PTR [rax],0x4
  40f57d:	je     40f560 <__swc_fn_7dafa2b1_000107_4796e893+0xc0>
  40f57f:	movsxd rdi,r13d
  40f582:	xor    eax,eax
  40f584:	call   4070b0 <close@plt>
  40f589:	xor    eax,eax
  40f58b:	jmp    40fa76 <__swc_fn_7dafa2b1_000107_4796e893+0x5d6>
  40f590:	lea    r14,[rsp+0x8]
  40f595:	mov    QWORD PTR [rsp+0xb8],r14
  40f59d:	vxorps xmm0,xmm0,xmm0
  40f5a1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f5a7:	mov    QWORD PTR [rsp+0x18],0x0
  40f5b0:	mov    WORD PTR [rsp+0x20],0x0
  40f5b7:	mov    DWORD PTR [r14],0x67617753
  40f5be:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40f5c6:	xor    eax,eax
  40f5c8:	call   407010 <getpid@plt>
  40f5cd:	mov    ecx,eax
  40f5cf:	mov    eax,0x1c
  40f5d4:	shrx   eax,ecx,eax
  40f5d9:	and    eax,0xf
  40f5dc:	mov    rdx,QWORD PTR [rip+0x2eed]        # 4124d0 <__swc_rdata_base_7dafa2b1+0x3c0>
  40f5e3:	mov    al,BYTE PTR [rdx+rax*1]
  40f5e6:	rex mov BYTE PTR [rsp+0x10],al
  40f5eb:	mov    eax,0x1c
  40f5f0:	shrx   eax,r12d,eax
  40f5f5:	and    eax,0xf
  40f5f8:	mov    al,BYTE PTR [rdx+rax*1]
  40f5fb:	rex mov BYTE PTR [rsp+0x19],al
  40f600:	mov    eax,0x18
  40f605:	shrx   eax,ecx,eax
  40f60a:	and    eax,0xf
  40f60d:	mov    al,BYTE PTR [rdx+rax*1]
  40f610:	rex mov BYTE PTR [rsp+0x11],al
  40f615:	mov    eax,0x18
  40f61a:	shrx   eax,r12d,eax
  40f61f:	and    eax,0xf
  40f622:	mov    al,BYTE PTR [rdx+rax*1]
  40f625:	rex mov BYTE PTR [rsp+0x1a],al
  40f62a:	mov    eax,0x14
  40f62f:	shrx   eax,ecx,eax
  40f634:	and    eax,0xf
  40f637:	mov    al,BYTE PTR [rdx+rax*1]
  40f63a:	rex mov BYTE PTR [rsp+0x12],al
  40f63f:	mov    eax,0x14
  40f644:	shrx   eax,r12d,eax
  40f649:	and    eax,0xf
  40f64c:	mov    al,BYTE PTR [rdx+rax*1]
  40f64f:	rex mov BYTE PTR [rsp+0x1b],al
  40f654:	mov    eax,0x10
  40f659:	shrx   eax,ecx,eax
  40f65e:	and    eax,0xf
  40f661:	mov    al,BYTE PTR [rdx+rax*1]
  40f664:	rex mov BYTE PTR [rsp+0x13],al
  40f669:	mov    eax,0x10
  40f66e:	shrx   eax,r12d,eax
  40f673:	and    eax,0xf
  40f676:	mov    al,BYTE PTR [rdx+rax*1]
  40f679:	rex mov BYTE PTR [rsp+0x1c],al
  40f67e:	mov    eax,0xc
  40f683:	shrx   eax,ecx,eax
  40f688:	and    eax,0xf
  40f68b:	mov    al,BYTE PTR [rdx+rax*1]
  40f68e:	rex mov BYTE PTR [rsp+0x14],al
  40f693:	mov    eax,0xc
  40f698:	shrx   eax,r12d,eax
  40f69d:	and    eax,0xf
  40f6a0:	mov    al,BYTE PTR [rdx+rax*1]
  40f6a3:	rex mov BYTE PTR [rsp+0x1d],al
  40f6a8:	mov    eax,0x8
  40f6ad:	shrx   eax,ecx,eax
  40f6b2:	and    eax,0xf
  40f6b5:	mov    al,BYTE PTR [rdx+rax*1]
  40f6b8:	rex mov BYTE PTR [rsp+0x15],al
  40f6bd:	mov    eax,0x8
  40f6c2:	shrx   eax,r12d,eax
  40f6c7:	and    eax,0xf
  40f6ca:	mov    al,BYTE PTR [rdx+rax*1]
  40f6cd:	rex mov BYTE PTR [rsp+0x1e],al
  40f6d2:	mov    eax,0x4
  40f6d7:	shrx   eax,ecx,eax
  40f6dc:	and    eax,0xf
  40f6df:	mov    al,BYTE PTR [rdx+rax*1]
  40f6e2:	rex mov BYTE PTR [rsp+0x16],al
  40f6e7:	mov    eax,0x4
  40f6ec:	shrx   eax,r12d,eax
  40f6f1:	and    eax,0xf
  40f6f4:	mov    al,BYTE PTR [rdx+rax*1]
  40f6f7:	rex mov BYTE PTR [rsp+0x1f],al
  40f6fc:	xor    eax,eax
  40f6fe:	shrx   eax,ecx,eax
  40f703:	and    eax,0xf
  40f706:	mov    al,BYTE PTR [rdx+rax*1]
  40f709:	rex mov BYTE PTR [rsp+0x17],al
  40f70e:	xor    eax,eax
  40f710:	shrx   eax,r12d,eax
  40f715:	and    eax,0xf
  40f718:	mov    al,BYTE PTR [rdx+rax*1]
  40f71b:	rex mov BYTE PTR [rsp+0x20],al
  40f720:	mov    BYTE PTR [r14+0x10],0x2e
  40f725:	lea    r12,[rsp+0x22]
  40f72a:	vxorps xmm0,xmm0,xmm0
  40f72e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40f734:	mov    DWORD PTR [r12],0x6d656d2f
  40f73c:	mov    WORD PTR [r12+0x4],0x6466
  40f744:	mov    BYTE PTR [r12+0x6],0x3a
  40f74a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f750:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40f756:	mov    rax,QWORD PTR [rsp+0x18]
  40f75b:	mov    QWORD PTR [rsp+0x39],rax
  40f760:	rex mov al,BYTE PTR [rsp+0x20]
  40f765:	rex mov BYTE PTR [rsp+0x41],al
  40f76a:	mov    DWORD PTR [r12+0x20],0x65642820
  40f773:	mov    DWORD PTR [r12+0x24],0x6574656c
  40f77c:	mov    WORD PTR [r12+0x28],0x2964
  40f784:	lea    rdi,[rip+0x2d30]        # 4124bb <__swc_rdata_base_7dafa2b1+0x3ab>
  40f78b:	xor    eax,eax
  40f78d:	call   407130 <opendir@plt>
  40f792:	mov    r15,rax
  40f795:	test   rax,rax
  40f798:	jne    40f7ab <__swc_fn_7dafa2b1_000107_4796e893+0x30b>
  40f79a:	movsxd rdi,r13d
  40f79d:	xor    eax,eax
  40f79f:	call   4070b0 <close@plt>
  40f7a4:	xor    eax,eax
  40f7a6:	jmp    40fa76 <__swc_fn_7dafa2b1_000107_4796e893+0x5d6>
  40f7ab:	mov    rdi,r15
  40f7ae:	xor    eax,eax
  40f7b0:	call   407140 <dirfd@plt>
  40f7b5:	lea    r14,[rsp+0x54]
  40f7ba:	mov    DWORD PTR [rsp+0x54],eax
  40f7be:	lea    rbx,[rsp+0x58]
  40f7c3:	cs nop WORD PTR [rax+rax*1+0x0]
  40f7cd:	cs nop WORD PTR [rax+rax*1+0x0]
  40f7d7:	nop    WORD PTR [rax+rax*1+0x0]
  40f7e0:	mov    rdi,r15
  40f7e3:	xor    eax,eax
  40f7e5:	call   407150 <readdir@plt>
  40f7ea:	test   rax,rax
  40f7ed:	jne    40f804 <__swc_fn_7dafa2b1_000107_4796e893+0x364>
  40f7ef:	mov    r12,QWORD PTR [rsp+0xa8]
  40f7f7:	mov    r13,QWORD PTR [rsp+0xb0]
  40f7ff:	jmp    40f99a <__swc_fn_7dafa2b1_000107_4796e893+0x4fa>
  40f804:	vxorps xmm0,xmm0,xmm0
  40f808:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40f80e:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40f814:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40f81a:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40f823:	lea    r13,[rax+0x13]
  40f827:	mov    rax,r14
  40f82a:	movsxd rdi,DWORD PTR [rax]
  40f82d:	mov    rsi,r13
  40f830:	mov    rdx,rbx
  40f833:	mov    ecx,0x40
  40f838:	xor    eax,eax
  40f83a:	call   407160 <readlinkat@plt>
  40f83f:	cmp    rax,0x2a
  40f843:	jne    40f7e0 <__swc_fn_7dafa2b1_000107_4796e893+0x340>
  40f845:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40f84b:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40f851:	vptest xmm0,xmm0
  40f856:	jne    40f886 <__swc_fn_7dafa2b1_000107_4796e893+0x3e6>
  40f858:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40f85e:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40f864:	vptest xmm0,xmm0
  40f869:	jne    40f886 <__swc_fn_7dafa2b1_000107_4796e893+0x3e6>
  40f86b:	mov    rcx,QWORD PTR [rsp+0x42]
  40f870:	cmp    QWORD PTR [rsp+0x78],rcx
  40f875:	jne    40f886 <__swc_fn_7dafa2b1_000107_4796e893+0x3e6>
  40f877:	mov    cx,WORD PTR [rsp+0x4a]
  40f87c:	cmp    WORD PTR [rsp+0x80],cx
  40f884:	je     40f8b4 <__swc_fn_7dafa2b1_000107_4796e893+0x414>
  40f886:	mov    rax,rbx
  40f889:	mov    rcx,r12
  40f88c:	nop    DWORD PTR [rax+0x0]
  40f890:	movzx  edx,BYTE PTR [rax]
  40f893:	movzx  r8d,BYTE PTR [rcx]
  40f897:	cmp    rdx,r8
  40f89a:	jne    40f8a6 <__swc_fn_7dafa2b1_000107_4796e893+0x406>
  40f89c:	add    rax,0x1
  40f8a0:	add    rcx,0x1
  40f8a4:	jmp    40f890 <__swc_fn_7dafa2b1_000107_4796e893+0x3f0>
  40f8a6:	mov    rax,rdx
  40f8a9:	sub    rax,r8
  40f8ac:	test   eax,eax
  40f8ae:	jne    40f7e0 <__swc_fn_7dafa2b1_000107_4796e893+0x340>
  40f8b4:	movsxd rdi,DWORD PTR [r14]
  40f8b7:	mov    rsi,r13
  40f8ba:	mov    edx,0x80002
  40f8bf:	xor    eax,eax
  40f8c1:	call   407170 <openat@plt>
  40f8c6:	lea    rbx,[rsp+0x98]
  40f8ce:	mov    DWORD PTR [rsp+0x98],eax
  40f8d5:	test   eax,eax
  40f8d7:	mov    r13,QWORD PTR [rsp+0xb0]
  40f8df:	jge    40f904 <__swc_fn_7dafa2b1_000107_4796e893+0x464>
  40f8e1:	mov    rdi,r15
  40f8e4:	xor    eax,eax
  40f8e6:	call   407180 <closedir@plt>
  40f8eb:	mov    r13,QWORD PTR [rsp+0xb0]
  40f8f3:	movsxd rdi,r13d
  40f8f6:	xor    eax,eax
  40f8f8:	call   4070b0 <close@plt>
  40f8fd:	xor    eax,eax
  40f8ff:	jmp    40fa76 <__swc_fn_7dafa2b1_000107_4796e893+0x5d6>
  40f904:	mov    rax,rbx
  40f907:	movsxd rdi,DWORD PTR [rax]
  40f90a:	xor    esi,esi
  40f90c:	mov    edx,0x2
  40f911:	xor    eax,eax
  40f913:	call   4070a0 <lseek@plt>
  40f918:	mov    r12,QWORD PTR [rsp+0xa8]
  40f920:	cmp    rax,r12
  40f923:	je     40f94a <__swc_fn_7dafa2b1_000107_4796e893+0x4aa>
  40f925:	movsxd rdi,DWORD PTR [rbx]
  40f928:	xor    eax,eax
  40f92a:	call   4070b0 <close@plt>
  40f92f:	mov    rdi,r15
  40f932:	xor    eax,eax
  40f934:	call   407180 <closedir@plt>
  40f939:	movsxd rdi,r13d
  40f93c:	xor    eax,eax
  40f93e:	call   4070b0 <close@plt>
  40f943:	xor    eax,eax
  40f945:	jmp    40fa76 <__swc_fn_7dafa2b1_000107_4796e893+0x5d6>
  40f94a:	xor    edi,edi
  40f94c:	mov    rsi,r12
  40f94f:	mov    edx,0x3
  40f954:	mov    ecx,0x1
  40f959:	mov    rax,rbx
  40f95c:	movsxd r8,DWORD PTR [rax]
  40f95f:	xor    r9d,r9d
  40f962:	xor    eax,eax
  40f964:	call   4070c0 <mmap@plt>
  40f969:	xor    r12d,r12d
  40f96c:	cmp    rax,0xffffffffffffffff
  40f970:	cmovne r12,rax
  40f974:	movsxd rdi,DWORD PTR [rbx]
  40f977:	xor    eax,eax
  40f979:	call   4070b0 <close@plt>
  40f97e:	mov    rdi,r15
  40f981:	xor    eax,eax
  40f983:	call   407180 <closedir@plt>
  40f988:	movsxd rdi,r13d
  40f98b:	xor    eax,eax
  40f98d:	call   4070b0 <close@plt>
  40f992:	mov    rax,r12
  40f995:	jmp    40fa76 <__swc_fn_7dafa2b1_000107_4796e893+0x5d6>
  40f99a:	mov    r14,QWORD PTR [rsp+0xb8]
  40f9a2:	mov    rdi,r14
  40f9a5:	mov    esi,0x1
  40f9aa:	xor    eax,eax
  40f9ac:	call   407190 <memfd_create@plt>
  40f9b1:	lea    rbx,[rsp+0x9c]
  40f9b9:	mov    DWORD PTR [rsp+0x9c],eax
  40f9c0:	test   eax,eax
  40f9c2:	jge    40f9df <__swc_fn_7dafa2b1_000107_4796e893+0x53f>
  40f9c4:	mov    rdi,r15
  40f9c7:	xor    eax,eax
  40f9c9:	call   407180 <closedir@plt>
  40f9ce:	movsxd rdi,r13d
  40f9d1:	xor    eax,eax
  40f9d3:	call   4070b0 <close@plt>
  40f9d8:	xor    eax,eax
  40f9da:	jmp    40fa76 <__swc_fn_7dafa2b1_000107_4796e893+0x5d6>
  40f9df:	mov    rax,rbx
  40f9e2:	movsxd rdi,DWORD PTR [rax]
  40f9e5:	mov    rsi,r12
  40f9e8:	xor    eax,eax
  40f9ea:	call   4071a0 <ftruncate@plt>
  40f9ef:	test   eax,eax
  40f9f1:	je     40fa15 <__swc_fn_7dafa2b1_000107_4796e893+0x575>
  40f9f3:	movsxd rdi,DWORD PTR [rbx]
  40f9f6:	xor    eax,eax
  40f9f8:	call   4070b0 <close@plt>
  40f9fd:	mov    rdi,r15
  40fa00:	xor    eax,eax
  40fa02:	call   407180 <closedir@plt>
  40fa07:	movsxd rdi,r13d
  40fa0a:	xor    eax,eax
  40fa0c:	call   4070b0 <close@plt>
  40fa11:	xor    eax,eax
  40fa13:	jmp    40fa76 <__swc_fn_7dafa2b1_000107_4796e893+0x5d6>
  40fa15:	xor    edi,edi
  40fa17:	mov    rsi,r12
  40fa1a:	mov    edx,0x3
  40fa1f:	mov    ecx,0x1
  40fa24:	mov    rax,rbx
  40fa27:	movsxd r8,DWORD PTR [rax]
  40fa2a:	xor    r9d,r9d
  40fa2d:	xor    eax,eax
  40fa2f:	call   4070c0 <mmap@plt>
  40fa34:	mov    r12,rax
  40fa37:	cmp    rax,0xffffffffffffffff
  40fa3b:	jne    40fa5f <__swc_fn_7dafa2b1_000107_4796e893+0x5bf>
  40fa3d:	movsxd rdi,DWORD PTR [rbx]
  40fa40:	xor    eax,eax
  40fa42:	call   4070b0 <close@plt>
  40fa47:	mov    rdi,r15
  40fa4a:	xor    eax,eax
  40fa4c:	call   407180 <closedir@plt>
  40fa51:	movsxd rdi,r13d
  40fa54:	xor    eax,eax
  40fa56:	call   4070b0 <close@plt>
  40fa5b:	xor    eax,eax
  40fa5d:	jmp    40fa76 <__swc_fn_7dafa2b1_000107_4796e893+0x5d6>
  40fa5f:	mov    rdi,r15
  40fa62:	xor    eax,eax
  40fa64:	call   407180 <closedir@plt>
  40fa69:	movsxd rdi,r13d
  40fa6c:	xor    eax,eax
  40fa6e:	call   4070b0 <close@plt>
  40fa73:	mov    rax,r12
  40fa76:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40fa7f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40fa88:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40fa91:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40fa9a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40faa3:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40faac:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40fab5:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40fabe:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40fac7:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40fad0:	add    rsp,0x170
  40fad7:	pop    r15
  40fad9:	pop    r14
  40fadb:	pop    r13
  40fadd:	pop    rsi
  40fade:	pop    rdi
  40fadf:	pop    r12
  40fae1:	pop    rbx
  40fae2:	ret
	...

000000000040faf0 <__swc_fn_7dafa2b1_000110_a808fe76>:
  40faf0:	push   rsi
  40faf1:	push   rdi
  40faf2:	push   r12
  40faf4:	push   r13
  40faf6:	sub    rsp,0x8
  40fafa:	mov    rsi,r8
  40fafd:	mov    rdi,rcx
  40fb00:	mov    r12,rdx
  40fb03:	call   409120 <__swc_fn_7dafa2b1_000108_84af7666>
  40fb08:	mov    r13,rax
  40fb0b:	test   rax,rax
  40fb0e:	jne    40fb1b <__swc_fn_7dafa2b1_000110_a808fe76+0x2b>
  40fb10:	add    rsp,0x8
  40fb14:	pop    r13
  40fb16:	pop    r12
  40fb18:	pop    rdi
  40fb19:	pop    rsi
  40fb1a:	ret
  40fb1b:	mov    rcx,r13
  40fb1e:	call   40cd70 <__swc_fn_7dafa2b1_000133_4b2af8da>
  40fb23:	mov    rax,QWORD PTR [r13+0x8]
  40fb27:	test   rax,rax
  40fb2a:	je     40fb69 <__swc_fn_7dafa2b1_000110_a808fe76+0x79>
  40fb2c:	nop    DWORD PTR [rax+0x0]
  40fb30:	lea    rcx,[rax+0x1000]
  40fb37:	cmp    rdi,rcx
  40fb3a:	jne    40fb61 <__swc_fn_7dafa2b1_000110_a808fe76+0x71>
  40fb3c:	cmp    r12,0x1000
  40fb43:	jb     40fb61 <__swc_fn_7dafa2b1_000110_a808fe76+0x71>
  40fb45:	test   sil,sil
  40fb48:	setne  cl
  40fb4b:	mov    BYTE PTR [rax+0x10],cl
  40fb4e:	mov    rcx,r13
  40fb51:	call   410060 <__swc_fn_7dafa2b1_000134_29412410>
  40fb56:	add    rsp,0x8
  40fb5a:	pop    r13
  40fb5c:	pop    r12
  40fb5e:	pop    rdi
  40fb5f:	pop    rsi
  40fb60:	ret
  40fb61:	mov    rax,QWORD PTR [rax]
  40fb64:	test   rax,rax
  40fb67:	jne    40fb30 <__swc_fn_7dafa2b1_000110_a808fe76+0x40>
  40fb69:	mov    rcx,r13
  40fb6c:	call   410060 <__swc_fn_7dafa2b1_000134_29412410>
  40fb71:	add    rsp,0x8
  40fb75:	pop    r13
  40fb77:	pop    r12
  40fb79:	pop    rdi
  40fb7a:	pop    rsi
  40fb7b:	ret
  40fb7c:	add    BYTE PTR [rax],al
	...

000000000040fb80 <__swc_fn_7dafa2b1_000113_49b378a9>:
  40fb80:	sub    rsp,0x8
  40fb84:	test   rcx,rcx
  40fb87:	jne    40fb8e <__swc_fn_7dafa2b1_000113_49b378a9+0xe>
  40fb89:	add    rsp,0x8
  40fb8d:	ret
  40fb8e:	call   40c880 <__swc_fn_7dafa2b1_000115_1ba33335>
  40fb93:	add    rsp,0x8
  40fb97:	ret
	...

000000000040fba0 <__swc_fn_7dafa2b1_000116_035d76a1>:
  40fba0:	push   r12
  40fba2:	push   r13
  40fba4:	push   r14
  40fba6:	push   rdi
  40fba7:	push   rsi
  40fba8:	sub    rsp,0xc0
  40fbaf:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40fbb5:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40fbbb:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40fbc1:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40fbc7:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40fbcd:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40fbd3:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40fbd9:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40fbe2:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40fbeb:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40fbf4:	mov    r12,QWORD PTR [rcx]
  40fbf7:	test   r12,r12
  40fbfa:	jne    40fc0c <__swc_fn_7dafa2b1_000116_035d76a1+0x6c>
  40fbfc:	add    rsp,0xc0
  40fc03:	pop    rsi
  40fc04:	pop    rdi
  40fc05:	pop    r14
  40fc07:	pop    r13
  40fc09:	pop    r12
  40fc0b:	ret
  40fc0c:	xor    r13d,r13d
  40fc0f:	mov    r14,QWORD PTR [rcx+0x8]
  40fc13:	cs nop WORD PTR [rax+rax*1+0x0]
  40fc1d:	nop    DWORD PTR [rax]
  40fc20:	cmp    r13,r14
  40fc23:	jae    40fc5e <__swc_fn_7dafa2b1_000116_035d76a1+0xbe>
  40fc25:	lea    rax,[r12+r13*1]
  40fc29:	mov    rcx,r14
  40fc2c:	sub    rcx,r13
  40fc2f:	mov    edi,0x1
  40fc34:	mov    rsi,rax
  40fc37:	mov    rdx,rcx
  40fc3a:	xor    eax,eax
  40fc3c:	call   4071b0 <write@plt>
  40fc41:	test   rax,rax
  40fc44:	jle    40fc4b <__swc_fn_7dafa2b1_000116_035d76a1+0xab>
  40fc46:	add    r13,rax
  40fc49:	jmp    40fc20 <__swc_fn_7dafa2b1_000116_035d76a1+0x80>
  40fc4b:	test   rax,rax
  40fc4e:	je     40fc5c <__swc_fn_7dafa2b1_000116_035d76a1+0xbc>
  40fc50:	xor    eax,eax
  40fc52:	call   407120 <__errno_location@plt>
  40fc57:	cmp    DWORD PTR [rax],0x4
  40fc5a:	je     40fc20 <__swc_fn_7dafa2b1_000116_035d76a1+0x80>
  40fc5c:	jmp    40fc5e <__swc_fn_7dafa2b1_000116_035d76a1+0xbe>
  40fc5e:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40fc64:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40fc6a:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40fc70:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40fc76:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40fc7c:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40fc82:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40fc88:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40fc91:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40fc9a:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40fca3:	add    rsp,0xc0
  40fcaa:	pop    rsi
  40fcab:	pop    rdi
  40fcac:	pop    r14
  40fcae:	pop    r13
  40fcb0:	pop    r12
  40fcb2:	ret
	...

000000000040fcc0 <__swc_fn_7dafa2b1_000119_9175a56a>:
  40fcc0:	push   rbx
  40fcc1:	push   r12
  40fcc3:	push   rdi
  40fcc4:	push   rsi
  40fcc5:	sub    rsp,0x4a8
  40fccc:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  40fcd5:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  40fcde:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  40fce7:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  40fcf0:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  40fcf9:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  40fd02:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  40fd0b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  40fd14:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  40fd1d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  40fd26:	mov    rbx,rdx
  40fd29:	mov    r12d,ecx
  40fd2c:	vxorps xmm0,xmm0,xmm0
  40fd30:	xor    eax,eax
  40fd32:	cs nop WORD PTR [rax+rax*1+0x0]
  40fd3c:	nop    DWORD PTR [rax+0x0]
  40fd40:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  40fd46:	add    rax,0x10
  40fd4a:	cmp    rax,0x400
  40fd51:	jne    40fd40 <__swc_fn_7dafa2b1_000119_9175a56a+0x80>
  40fd53:	lea    rdi,[rsp+0x8]
  40fd58:	mov    esi,0x80
  40fd5d:	xor    eax,eax
  40fd5f:	call   4071c0 <backtrace@plt>
  40fd64:	test   eax,eax
  40fd66:	jle    40fd75 <__swc_fn_7dafa2b1_000119_9175a56a+0xb5>
  40fd68:	movsxd rax,eax
  40fd6b:	lea    rcx,[r12+0x1]
  40fd70:	cmp    rcx,rax
  40fd73:	jb     40fd79 <__swc_fn_7dafa2b1_000119_9175a56a+0xb9>
  40fd75:	xor    eax,eax
  40fd77:	jmp    40fdaa <__swc_fn_7dafa2b1_000119_9175a56a+0xea>
  40fd79:	mov    rcx,QWORD PTR [rbx+0x8]
  40fd7d:	sub    rax,r12
  40fd80:	lea    rsi,[rax-0x1]
  40fd84:	cmp    rcx,rsi
  40fd87:	cmovbe rsi,rcx
  40fd8b:	lea    eax,[r12+0x1]
  40fd90:	lea    rax,[rsp+rax*8+0x8]
  40fd95:	mov    rcx,QWORD PTR [rbx]
  40fd98:	mov    rdx,rax
  40fd9b:	lea    r8,[rsi*8+0x0]
  40fda3:	call   409100 <__swc_fn_7dafa2b1_000105_6fd80914>
  40fda8:	mov    eax,esi
  40fdaa:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  40fdb3:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  40fdbc:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  40fdc5:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  40fdce:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  40fdd7:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  40fde0:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  40fde9:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  40fdf2:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  40fdfb:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  40fe04:	add    rsp,0x4a8
  40fe0b:	pop    rsi
  40fe0c:	pop    rdi
  40fe0d:	pop    r12
  40fe0f:	pop    rbx
  40fe10:	ret
	...

000000000040fe20 <__swc_fn_7dafa2b1_000122_e09461fd>:
  40fe20:	mov    QWORD PTR [rcx],0x0
  40fe27:	ret
	...

000000000040fe30 <__swc_fn_7dafa2b1_000125_ce762363>:
  40fe30:	push   rdi
  40fe31:	push   rsi
  40fe32:	sub    rsp,0xa8
  40fe39:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40fe3f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40fe45:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40fe4b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40fe51:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40fe57:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40fe5d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40fe63:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40fe69:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40fe72:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40fe7b:	mov    edi,ecx
  40fe7d:	mov    rsi,rdx
  40fe80:	xor    eax,eax
  40fe82:	call   407060 <pthread_setspecific@plt>
  40fe87:	test   eax,eax
  40fe89:	sete   al
  40fe8c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40fe92:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40fe98:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40fe9e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40fea4:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40feaa:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40feb0:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40feb6:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40febc:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40fec5:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40fece:	add    rsp,0xa8
  40fed5:	pop    rsi
  40fed6:	pop    rdi
  40fed7:	ret
	...

000000000040fee0 <__swc_fn_7dafa2b1_000128_41c3251c>:
  40fee0:	push   rdi
  40fee1:	push   rsi
  40fee2:	sub    rsp,0xa8
  40fee9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40feef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40fef5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40fefb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40ff01:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ff07:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40ff0d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ff13:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ff19:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ff22:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ff2b:	test   rcx,rcx
  40ff2e:	je     40ff41 <__swc_fn_7dafa2b1_000128_41c3251c+0x61>
  40ff30:	lea    rax,[rcx-0x1]
  40ff34:	mov    eax,eax
  40ff36:	mov    edi,eax
  40ff38:	xor    eax,eax
  40ff3a:	call   407000 <pthread_getspecific@plt>
  40ff3f:	jmp    40ff43 <__swc_fn_7dafa2b1_000128_41c3251c+0x63>
  40ff41:	xor    eax,eax
  40ff43:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ff49:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ff4f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ff55:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ff5b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ff61:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ff67:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ff6d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ff73:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ff7c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ff85:	add    rsp,0xa8
  40ff8c:	pop    rsi
  40ff8d:	pop    rdi
  40ff8e:	ret
	...

000000000040ff90 <__swc_fn_7dafa2b1_000131_944f555b>:
  40ff90:	push   rdi
  40ff91:	push   rsi
  40ff92:	sub    rsp,0xb8
  40ff99:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ff9f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40ffa5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40ffab:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ffb1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ffb7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ffbd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40ffc3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40ffcc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ffd5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ffde:	vxorps xmm0,xmm0,xmm0
  40ffe2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ffe8:	mov    edi,0x1
  40ffed:	lea    rsi,[rsp+0x8]
  40fff2:	xor    eax,eax
  40fff4:	call   4071d0 <clock_gettime@plt>
  40fff9:	mov    rax,QWORD PTR [rsp+0x8]
  40fffe:	imul   rax,rax,0x3b9aca00
  410005:	add    rax,QWORD PTR [rsp+0x10]
  41000a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410010:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410016:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  41001c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410022:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410028:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41002e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410034:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41003d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410046:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  41004f:	add    rsp,0xb8
  410056:	pop    rsi
  410057:	pop    rdi
  410058:	ret
  410059:	add    BYTE PTR [rax],al
  41005b:	add    BYTE PTR [rax],al
  41005d:	add    BYTE PTR [rax],al
	...

0000000000410060 <__swc_fn_7dafa2b1_000134_29412410>:
  410060:	sub    rsp,0x8
  410064:	xor    eax,eax
  410066:	mov    DWORD PTR [rcx],eax
  410068:	mov    edx,0x7fffffff
  41006d:	call   409800 <__swc_fn_7dafa2b1_000132_f908e7f9>
  410072:	add    rsp,0x8
  410076:	ret
	...

0000000000410080 <__swc_fn_7dafa2b1_000137_a4ba10ed>:
  410080:	push   rdi
  410081:	push   rsi
  410082:	sub    rsp,0xb8
  410089:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41008f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410095:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41009b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4100a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4100a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4100ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4100b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4100bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4100c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4100ce:	mov    edi,0x1
  4100d3:	xor    eax,eax
  4100d5:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  4100da:	mov    eax,DWORD PTR [rax+0x14]
  4100dd:	and    eax,0x20
  4100e0:	setne  al
  4100e3:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4100e9:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4100ef:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4100f5:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4100fb:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410101:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  410107:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41010d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  410116:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  41011f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410128:	add    rsp,0xb8
  41012f:	pop    rsi
  410130:	pop    rdi
  410131:	ret
	...

0000000000410140 <__swc_fn_7dafa2b1_000140_c6b99a56>:
  410140:	push   rsi
  410141:	push   rdi
  410142:	push   r12
  410144:	push   r13
  410146:	push   r14
  410148:	push   r15
  41014a:	cmp    rdx,0x40
  41014e:	jae    41015d <__swc_fn_7dafa2b1_000140_c6b99a56+0x1d>
  410150:	xor    eax,eax
  410152:	pop    r15
  410154:	pop    r14
  410156:	pop    r13
  410158:	pop    r12
  41015a:	pop    rdi
  41015b:	pop    rsi
  41015c:	ret
  41015d:	cmp    BYTE PTR [rcx],0x7f
  410160:	jne    4101a4 <__swc_fn_7dafa2b1_000140_c6b99a56+0x64>
  410162:	movzx  eax,BYTE PTR [rcx+0x1]
  410166:	cmp    eax,0x45
  410169:	setne  al
  41016c:	jne    4101a0 <__swc_fn_7dafa2b1_000140_c6b99a56+0x60>
  41016e:	movzx  eax,BYTE PTR [rcx+0x2]
  410172:	cmp    eax,0x4c
  410175:	setne  al
  410178:	jne    4101a0 <__swc_fn_7dafa2b1_000140_c6b99a56+0x60>
  41017a:	movzx  eax,BYTE PTR [rcx+0x3]
  41017e:	cmp    eax,0x46
  410181:	setne  al
  410184:	jne    4101a0 <__swc_fn_7dafa2b1_000140_c6b99a56+0x60>
  410186:	cmp    BYTE PTR [rcx+0x4],0x2
  41018a:	setne  al
  41018d:	jne    4101a0 <__swc_fn_7dafa2b1_000140_c6b99a56+0x60>
  41018f:	cmp    BYTE PTR [rcx+0x5],0x1
  410193:	setne  al
  410196:	jne    4101a0 <__swc_fn_7dafa2b1_000140_c6b99a56+0x60>
  410198:	cmp    WORD PTR [rcx+0x12],0x3e
  41019d:	setne  al
  4101a0:	test   al,al
  4101a2:	je     4101b1 <__swc_fn_7dafa2b1_000140_c6b99a56+0x71>
  4101a4:	xor    eax,eax
  4101a6:	pop    r15
  4101a8:	pop    r14
  4101aa:	pop    r13
  4101ac:	pop    r12
  4101ae:	pop    rdi
  4101af:	pop    rsi
  4101b0:	ret
  4101b1:	cmp    WORD PTR [rcx+0x3a],0x40
  4101b6:	jne    4101d1 <__swc_fn_7dafa2b1_000140_c6b99a56+0x91>
  4101b8:	cmp    WORD PTR [rcx+0x3c],0x0
  4101bd:	sete   al
  4101c0:	je     4101cd <__swc_fn_7dafa2b1_000140_c6b99a56+0x8d>
  4101c2:	mov    ax,WORD PTR [rcx+0x3c]
  4101c6:	cmp    WORD PTR [rcx+0x3e],ax
  4101ca:	setae  al
  4101cd:	test   al,al
  4101cf:	je     4101de <__swc_fn_7dafa2b1_000140_c6b99a56+0x9e>
  4101d1:	xor    eax,eax
  4101d3:	pop    r15
  4101d5:	pop    r14
  4101d7:	pop    r13
  4101d9:	pop    r12
  4101db:	pop    rdi
  4101dc:	pop    rsi
  4101dd:	ret
  4101de:	movzx  eax,WORD PTR [rcx+0x3c]
  4101e2:	shl    rax,0x6
  4101e6:	cmp    rax,rdx
  4101e9:	ja     4101f7 <__swc_fn_7dafa2b1_000140_c6b99a56+0xb7>
  4101eb:	mov    r9,rdx
  4101ee:	sub    r9,rax
  4101f1:	cmp    QWORD PTR [rcx+0x28],r9
  4101f5:	jbe    410204 <__swc_fn_7dafa2b1_000140_c6b99a56+0xc4>
  4101f7:	xor    eax,eax
  4101f9:	pop    r15
  4101fb:	pop    r14
  4101fd:	pop    r13
  4101ff:	pop    r12
  410201:	pop    rdi
  410202:	pop    rsi
  410203:	ret
  410204:	mov    rax,QWORD PTR [rcx+0x28]
  410208:	add    rax,rcx
  41020b:	movzx  r9d,WORD PTR [rcx+0x3e]
  410210:	lea    r9,[r9*8+0x0]
  410218:	lea    r10,[rax+r9*8]
  41021c:	cmp    QWORD PTR [r10+0x20],rdx
  410220:	ja     410242 <__swc_fn_7dafa2b1_000140_c6b99a56+0x102>
  410222:	mov    r11,rdx
  410225:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  41022a:	cmp    QWORD PTR [r10+0x18],r11
  41022e:	seta   r9b
  410232:	ja     41023d <__swc_fn_7dafa2b1_000140_c6b99a56+0xfd>
  410234:	cmp    QWORD PTR [r10+0x20],0x9
  410239:	setb   r9b
  41023d:	test   r9b,r9b
  410240:	je     41024f <__swc_fn_7dafa2b1_000140_c6b99a56+0x10f>
  410242:	xor    eax,eax
  410244:	pop    r15
  410246:	pop    r14
  410248:	pop    r13
  41024a:	pop    r12
  41024c:	pop    rdi
  41024d:	pop    rsi
  41024e:	ret
  41024f:	movzx  r9d,WORD PTR [rcx+0x3c]
  410254:	xor    r11d,r11d
  410257:	test   r9,r9
  41025a:	jbe    410355 <__swc_fn_7dafa2b1_000140_c6b99a56+0x215>
  410260:	mov    rsi,QWORD PTR [r10+0x20]
  410264:	sub    rsi,0x9
  410268:	cs nop WORD PTR [rax+rax*1+0x0]
  410272:	cs nop WORD PTR [rax+rax*1+0x0]
  41027c:	nop    DWORD PTR [rax+0x0]
  410280:	movzx  edi,r11w
  410284:	lea    rdi,[rdi*8+0x0]
  41028c:	lea    r12,[rax+rdi*8]
  410290:	rex mov edi,DWORD PTR [rax+rdi*8]
  410294:	cmp    rdi,rsi
  410297:	ja     410348 <__swc_fn_7dafa2b1_000140_c6b99a56+0x208>
  41029d:	mov    r13,QWORD PTR [r10+0x18]
  4102a1:	add    r13,rdi
  4102a4:	lea    rdi,[rcx+r13*1]
  4102a8:	lea    r13,[rip+0x2281]        # 412530 <__swc_rdata_base_7dafa2b1+0x420>
  4102af:	movabs r14,0x676264676177732e
  4102b9:	cmp    QWORD PTR [rdi],r14
  4102bc:	jne    4102c5 <__swc_fn_7dafa2b1_000140_c6b99a56+0x185>
  4102be:	rex cmp BYTE PTR [rdi+0x8],0x0
  4102c3:	je     4102f2 <__swc_fn_7dafa2b1_000140_c6b99a56+0x1b2>
  4102c5:	cs nop WORD PTR [rax+rax*1+0x0]
  4102cf:	nop
  4102d0:	movzx  r14d,BYTE PTR [rdi]
  4102d4:	movzx  r15d,BYTE PTR [r13+0x0]
  4102d9:	cmp    r14,r15
  4102dc:	jne    4102e8 <__swc_fn_7dafa2b1_000140_c6b99a56+0x1a8>
  4102de:	add    rdi,0x1
  4102e2:	add    r13,0x1
  4102e6:	jmp    4102d0 <__swc_fn_7dafa2b1_000140_c6b99a56+0x190>
  4102e8:	mov    rdi,r14
  4102eb:	sub    rdi,r15
  4102ee:	test   edi,edi
  4102f0:	jne    410348 <__swc_fn_7dafa2b1_000140_c6b99a56+0x208>
  4102f2:	cmp    DWORD PTR [r12+0x4],0x1
  4102f8:	jne    410320 <__swc_fn_7dafa2b1_000140_c6b99a56+0x1e0>
  4102fa:	cmp    QWORD PTR [r12+0x20],0x10
  410300:	setb   al
  410303:	jb     41031c <__swc_fn_7dafa2b1_000140_c6b99a56+0x1dc>
  410305:	cmp    QWORD PTR [r12+0x20],rdx
  41030a:	seta   al
  41030d:	ja     41031c <__swc_fn_7dafa2b1_000140_c6b99a56+0x1dc>
  41030f:	sub    rdx,QWORD PTR [r12+0x20]
  410314:	cmp    QWORD PTR [r12+0x18],rdx
  410319:	seta   al
  41031c:	test   al,al
  41031e:	je     41032d <__swc_fn_7dafa2b1_000140_c6b99a56+0x1ed>
  410320:	xor    eax,eax
  410322:	pop    r15
  410324:	pop    r14
  410326:	pop    r13
  410328:	pop    r12
  41032a:	pop    rdi
  41032b:	pop    rsi
  41032c:	ret
  41032d:	mov    rax,QWORD PTR [r12+0x20]
  410332:	mov    QWORD PTR [r8],rax
  410335:	mov    rax,QWORD PTR [r12+0x18]
  41033a:	add    rax,rcx
  41033d:	pop    r15
  41033f:	pop    r14
  410341:	pop    r13
  410343:	pop    r12
  410345:	pop    rdi
  410346:	pop    rsi
  410347:	ret
  410348:	add    r11,0x1
  41034c:	cmp    r11,r9
  41034f:	jb     410280 <__swc_fn_7dafa2b1_000140_c6b99a56+0x140>
  410355:	xor    eax,eax
  410357:	pop    r15
  410359:	pop    r14
  41035b:	pop    r13
  41035d:	pop    r12
  41035f:	pop    rdi
  410360:	pop    rsi
  410361:	ret
	...

0000000000410370 <__swc_fn_7dafa2b1_000143_81c0d993>:
  410370:	push   rdi
  410371:	push   rsi
  410372:	sub    rsp,0xa8
  410379:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41037f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410385:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41038b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410391:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410397:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41039d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4103a3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4103a9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4103b2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4103bb:	mov    rdi,rcx
  4103be:	xor    eax,eax
  4103c0:	call   4071f0 <free@plt>
  4103c5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4103cb:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4103d1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4103d7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4103dd:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4103e3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4103e9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4103ef:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4103f5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4103fe:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410407:	add    rsp,0xa8
  41040e:	pop    rsi
  41040f:	pop    rdi
  410410:	ret
	...

0000000000410420 <__swc_fn_7dafa2b1_000146_43f4fdca>:
  410420:	push   rbx
  410421:	push   rsi
  410422:	push   rdi
  410423:	push   r12
  410425:	push   r13
  410427:	push   r15
  410429:	sub    rsp,0x4e8
  410430:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  410439:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  410442:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  41044b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  410454:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  41045d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  410466:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  41046f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  410478:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  410481:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  41048a:	mov    rbx,QWORD PTR [rcx]
  41048d:	mov    rcx,QWORD PTR [rcx+0x8]
  410491:	mov    rsi,rcx
  410494:	xor    edi,edi
  410496:	vmovsd xmm6,QWORD PTR [rip+0x20f2]        # 412590 <__swc_rdata_base_7dafa2b1+0x480>
  41049e:	vmovsd xmm7,QWORD PTR [rip+0x20f3]        # 412599 <__swc_rdata_base_7dafa2b1+0x489>
  4104a6:	vmovsd xmm8,QWORD PTR [rip+0x20f4]        # 4125a2 <__swc_rdata_base_7dafa2b1+0x492>
  4104ae:	vmovsd xmm9,QWORD PTR [rip+0x20f5]        # 4125ab <__swc_rdata_base_7dafa2b1+0x49b>
  4104b6:	vmovsd xmm10,QWORD PTR [rip+0x20f6]        # 4125b4 <__swc_rdata_base_7dafa2b1+0x4a4>
  4104be:	vmovups xmm11,xmm6
  4104c2:	vmovsd QWORD PTR [rsp+0x418],xmm7
  4104cb:	vmovsd QWORD PTR [rsp+0x420],xmm8
  4104d4:	vmovsd QWORD PTR [rsp+0x428],xmm9
  4104dd:	vmovsd QWORD PTR [rsp+0x430],xmm10
  4104e6:	vmovsd xmm15,QWORD PTR [rip+0x20cf]        # 4125bd <__swc_rdata_base_7dafa2b1+0x4ad>
  4104ee:	vmovups xmm14,xmm15
  4104f3:	vmovups xmm0,xmm9
  4104f8:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410501:	vmovups xmm13,xmm8
  410506:	vmovsd QWORD PTR [rsp+0x440],xmm15
  41050f:	test   rsi,rsi
  410512:	je     411543 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1123>
  410518:	cs nop WORD PTR [rax+rax*1+0x0]
  410522:	cs nop WORD PTR [rax+rax*1+0x0]
  41052c:	nop    DWORD PTR [rax+0x0]
  410530:	lea    rcx,[rdi+rdi*1]
  410534:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410539:	vpshufd xmm3,xmm2,0xee
  41053e:	vmovq  rcx,xmm3
  410543:	test   rcx,rcx
  410546:	je     41055c <__swc_fn_7dafa2b1_000146_43f4fdca+0x13c>
  410548:	test   DWORD PTR [rcx+0x28],0x400000
  41054f:	je     41055c <__swc_fn_7dafa2b1_000146_43f4fdca+0x13c>
  410551:	mov    rdx,QWORD PTR [rcx+0x30]
  410555:	test   rdx,rdx
  410558:	cmovne rcx,rdx
  41055c:	test   DWORD PTR [rcx+0x28],0x1000
  410563:	je     410584 <__swc_fn_7dafa2b1_000146_43f4fdca+0x164>
  410565:	mov    rdx,QWORD PTR [rcx+0x40]
  410569:	mov    rcx,rdx
  41056c:	vmovq  r8,xmm2
  410571:	mov    r8,QWORD PTR [r8]
  410574:	mov    QWORD PTR [rsp+0x60],r8
  410579:	mov    QWORD PTR [rsp+0x68],rdx
  41057e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410584:	test   BYTE PTR [rcx+0x28],0x1
  410588:	jne    410590 <__swc_fn_7dafa2b1_000146_43f4fdca+0x170>
  41058a:	vmovups xmm12,xmm0
  41058e:	jmp    4105aa <__swc_fn_7dafa2b1_000146_43f4fdca+0x18a>
  410590:	vmovq  rax,xmm2
  410595:	mov    rax,QWORD PTR [rax]
  410598:	lea    rcx,[rax+0x10]
  41059c:	vmovups xmm12,xmm0
  4105a0:	call   40fba0 <__swc_fn_7dafa2b1_000116_035d76a1>
  4105a5:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  4105aa:	test   DWORD PTR [rcx+0x28],0x400
  4105b1:	je     410612 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1f2>
  4105b3:	vmovq  rax,xmm2
  4105b8:	mov    rax,QWORD PTR [rax]
  4105bb:	xor    ecx,ecx
  4105bd:	test   rax,rax
  4105c0:	je     4105f0 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1d0>
  4105c2:	mov    rdx,rax
  4105c5:	mov    r8b,BYTE PTR [rdx]
  4105c8:	test   r8b,r8b
  4105cb:	je     4105f0 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1d0>
  4105cd:	cs nop WORD PTR [rax+rax*1+0x0]
  4105d7:	nop    WORD PTR [rax+rax*1+0x0]
  4105e0:	add    rdx,0x1
  4105e4:	add    rcx,0x1
  4105e8:	mov    r8b,BYTE PTR [rdx]
  4105eb:	test   r8b,r8b
  4105ee:	jne    4105e0 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1c0>
  4105f0:	mov    QWORD PTR [rsp+0x88],rax
  4105f8:	mov    QWORD PTR [rsp+0x90],rcx
  410600:	lea    rcx,[rsp+0x88]
  410608:	call   40fba0 <__swc_fn_7dafa2b1_000116_035d76a1>
  41060d:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  410612:	cmp    BYTE PTR [rcx+0x2c],0x6
  410616:	jne    41062d <__swc_fn_7dafa2b1_000146_43f4fdca+0x20d>
  410618:	vmovq  rax,xmm2
  41061d:	mov    rax,QWORD PTR [rax]
  410620:	mov    rcx,rax
  410623:	call   409cd0 <__swc_fn_7dafa2b1_000144_72996a5b>
  410628:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  41062d:	cmp    BYTE PTR [rcx+0x2c],0x1
  410631:	jne    411519 <__swc_fn_7dafa2b1_000146_43f4fdca+0x10f9>
  410637:	vmovq  rdx,xmm2
  41063c:	mov    cl,BYTE PTR [rcx+0x40]
  41063f:	cmp    cl,0x7
  410642:	jb     410685 <__swc_fn_7dafa2b1_000146_43f4fdca+0x265>
  410644:	je     4106f8 <__swc_fn_7dafa2b1_000146_43f4fdca+0x2d8>
  41064a:	cmp    cl,0x8
  41064d:	je     410704 <__swc_fn_7dafa2b1_000146_43f4fdca+0x2e4>
  410653:	cmp    cl,0x9
  410656:	je     41071d <__swc_fn_7dafa2b1_000146_43f4fdca+0x2fd>
  41065c:	cmp    cl,0xa
  41065f:	je     410e04 <__swc_fn_7dafa2b1_000146_43f4fdca+0x9e4>
  410665:	cmp    cl,0xb
  410668:	je     4114eb <__swc_fn_7dafa2b1_000146_43f4fdca+0x10cb>
  41066e:	cmp    cl,0xc
  410671:	je     410711 <__swc_fn_7dafa2b1_000146_43f4fdca+0x2f1>
  410677:	cmp    cl,0xd
  41067a:	je     4114e1 <__swc_fn_7dafa2b1_000146_43f4fdca+0x10c1>
  410680:	jmp    41150b <__swc_fn_7dafa2b1_000146_43f4fdca+0x10eb>
  410685:	cmp    cl,0x1
  410688:	je     4106a8 <__swc_fn_7dafa2b1_000146_43f4fdca+0x288>
  41068a:	cmp    cl,0x2
  41068d:	je     4106b6 <__swc_fn_7dafa2b1_000146_43f4fdca+0x296>
  41068f:	cmp    cl,0x3
  410692:	je     4106c4 <__swc_fn_7dafa2b1_000146_43f4fdca+0x2a4>
  410694:	cmp    cl,0x4
  410697:	je     4106d1 <__swc_fn_7dafa2b1_000146_43f4fdca+0x2b1>
  410699:	cmp    cl,0x5
  41069c:	je     4106de <__swc_fn_7dafa2b1_000146_43f4fdca+0x2be>
  41069e:	cmp    cl,0x6
  4106a1:	je     4106eb <__swc_fn_7dafa2b1_000146_43f4fdca+0x2cb>
  4106a3:	jmp    41150b <__swc_fn_7dafa2b1_000146_43f4fdca+0x10eb>
  4106a8:	movsx  rcx,BYTE PTR [rdx]
  4106ac:	call   40cf60 <__swc_fn_7dafa2b1_000145_863755b5>
  4106b1:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  4106b6:	movsx  rcx,WORD PTR [rdx]
  4106ba:	call   40cf60 <__swc_fn_7dafa2b1_000145_863755b5>
  4106bf:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  4106c4:	movsxd rcx,DWORD PTR [rdx]
  4106c7:	call   40cf60 <__swc_fn_7dafa2b1_000145_863755b5>
  4106cc:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  4106d1:	mov    rcx,QWORD PTR [rdx]
  4106d4:	call   40cf60 <__swc_fn_7dafa2b1_000145_863755b5>
  4106d9:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  4106de:	movzx  ecx,BYTE PTR [rdx]
  4106e1:	call   409cd0 <__swc_fn_7dafa2b1_000144_72996a5b>
  4106e6:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  4106eb:	movzx  ecx,WORD PTR [rdx]
  4106ee:	call   409cd0 <__swc_fn_7dafa2b1_000144_72996a5b>
  4106f3:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  4106f8:	mov    ecx,DWORD PTR [rdx]
  4106fa:	call   409cd0 <__swc_fn_7dafa2b1_000144_72996a5b>
  4106ff:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  410704:	mov    rcx,QWORD PTR [rdx]
  410707:	call   409cd0 <__swc_fn_7dafa2b1_000144_72996a5b>
  41070c:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  410711:	mov    ecx,DWORD PTR [rdx]
  410713:	call   409cd0 <__swc_fn_7dafa2b1_000144_72996a5b>
  410718:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  41071d:	lea    rcx,[rsp+0xa8]
  410725:	vxorps xmm0,xmm0,xmm0
  410729:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  410732:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  41073b:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  410744:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  41074d:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  410756:	vmovups XMMWORD PTR [rsp+0xf8],xmm0
  41075f:	mov    DWORD PTR [rsp+0x108],0x0
  41076a:	vxorpd xmm0,xmm0,xmm0
  41076e:	vmovss xmm1,DWORD PTR [rdx]
  410772:	vcvtss2sd xmm0,xmm0,xmm1
  410776:	vmovsd xmm1,xmm1,xmm0
  41077a:	vcomisd xmm0,xmm0
  41077e:	setne  dl
  410781:	movzx  edx,dl
  410784:	setp   r8b
  410788:	movzx  r8d,r8b
  41078c:	or     edx,r8d
  41078f:	test   dl,dl
  410791:	je     41079e <__swc_fn_7dafa2b1_000146_43f4fdca+0x37e>
  410793:	mov    DWORD PTR [rcx],0x6e616e
  410799:	jmp    410d98 <__swc_fn_7dafa2b1_000146_43f4fdca+0x978>
  41079e:	vcomisd xmm1,xmm6
  4107a2:	ja     4107aa <__swc_fn_7dafa2b1_000146_43f4fdca+0x38a>
  4107a4:	vcomisd xmm7,xmm1
  4107a8:	jbe    4107ce <__swc_fn_7dafa2b1_000146_43f4fdca+0x3ae>
  4107aa:	vxorpd xmm0,xmm0,xmm0
  4107ae:	vcomisd xmm0,xmm1
  4107b2:	jbe    4107c3 <__swc_fn_7dafa2b1_000146_43f4fdca+0x3a3>
  4107b4:	mov    DWORD PTR [rcx],0x666e692d
  4107ba:	mov    BYTE PTR [rcx+0x4],0x0
  4107be:	jmp    410d98 <__swc_fn_7dafa2b1_000146_43f4fdca+0x978>
  4107c3:	mov    DWORD PTR [rcx],0x666e69
  4107c9:	jmp    410d98 <__swc_fn_7dafa2b1_000146_43f4fdca+0x978>
  4107ce:	vcomisd xmm1,xmm8
  4107d3:	jae    4107df <__swc_fn_7dafa2b1_000146_43f4fdca+0x3bf>
  4107d5:	vcomisd xmm9,xmm1
  4107d9:	jbe    410b5e <__swc_fn_7dafa2b1_000146_43f4fdca+0x73e>
  4107df:	vmovups xmm0,xmm1
  4107e3:	vxorpd xmm2,xmm2,xmm2
  4107e7:	vcomisd xmm2,xmm1
  4107eb:	jbe    4107fb <__swc_fn_7dafa2b1_000146_43f4fdca+0x3db>
  4107ed:	vmovsd xmm1,xmm1,xmm0
  4107f1:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1d57]        # 412550 <__swc_rdata_base_7dafa2b1+0x440>
  4107f9:	jmp    4107ff <__swc_fn_7dafa2b1_000146_43f4fdca+0x3df>
  4107fb:	vmovsd xmm1,xmm1,xmm0
  4107ff:	xor    r8d,r8d
  410802:	vcomisd xmm1,xmm15
  410807:	jb     410830 <__swc_fn_7dafa2b1_000146_43f4fdca+0x410>
  410809:	cs nop WORD PTR [rax+rax*1+0x0]
  410813:	cs nop WORD PTR [rax+rax*1+0x0]
  41081d:	nop    DWORD PTR [rax]
  410820:	vdivsd xmm1,xmm1,xmm15
  410825:	add    r8,0x1
  410829:	vcomisd xmm1,xmm15
  41082e:	jae    410820 <__swc_fn_7dafa2b1_000146_43f4fdca+0x400>
  410830:	mov    r9,rcx
  410833:	vxorpd xmm2,xmm2,xmm2
  410837:	vcomisd xmm2,xmm0
  41083b:	jbe    410844 <__swc_fn_7dafa2b1_000146_43f4fdca+0x424>
  41083d:	mov    BYTE PTR [rcx],0x2d
  410840:	lea    r9,[rcx+0x1]
  410844:	vcvttsd2si rdx,xmm1
  410849:	mov    r10b,dl
  41084c:	add    r10b,0x30
  410850:	mov    BYTE PTR [r9],r10b
  410853:	vxorpd xmm0,xmm0,xmm0
  410857:	movzx  edx,dl
  41085a:	vcvtsi2sd xmm0,xmm0,rdx
  41085f:	vsubsd xmm0,xmm1,xmm0
  410863:	vmulsd xmm1,xmm0,xmm15
  410868:	mov    BYTE PTR [r9+0x1],0x2e
  41086d:	vcvttsd2si rdx,xmm1
  410872:	mov    r10b,dl
  410875:	add    r10b,0x30
  410879:	mov    BYTE PTR [r9+0x2],r10b
  41087d:	vxorpd xmm0,xmm0,xmm0
  410881:	movzx  edx,dl
  410884:	vcvtsi2sd xmm0,xmm0,rdx
  410889:	vsubsd xmm0,xmm1,xmm0
  41088d:	vmulsd xmm1,xmm0,xmm15
  410892:	vcvttsd2si rdx,xmm1
  410897:	mov    r10b,dl
  41089a:	add    r10b,0x30
  41089e:	mov    BYTE PTR [r9+0x3],r10b
  4108a2:	vxorpd xmm0,xmm0,xmm0
  4108a6:	movzx  edx,dl
  4108a9:	vcvtsi2sd xmm0,xmm0,rdx
  4108ae:	vsubsd xmm0,xmm1,xmm0
  4108b2:	vmulsd xmm1,xmm0,xmm15
  4108b7:	vcvttsd2si rdx,xmm1
  4108bc:	mov    r10b,dl
  4108bf:	add    r10b,0x30
  4108c3:	mov    BYTE PTR [r9+0x4],r10b
  4108c7:	vxorpd xmm0,xmm0,xmm0
  4108cb:	movzx  edx,dl
  4108ce:	vcvtsi2sd xmm0,xmm0,rdx
  4108d3:	vsubsd xmm0,xmm1,xmm0
  4108d7:	vmulsd xmm1,xmm0,xmm15
  4108dc:	vcvttsd2si rdx,xmm1
  4108e1:	mov    r10b,dl
  4108e4:	add    r10b,0x30
  4108e8:	mov    BYTE PTR [r9+0x5],r10b
  4108ec:	vxorpd xmm0,xmm0,xmm0
  4108f0:	movzx  edx,dl
  4108f3:	vcvtsi2sd xmm0,xmm0,rdx
  4108f8:	vsubsd xmm0,xmm1,xmm0
  4108fc:	vmulsd xmm1,xmm0,xmm15
  410901:	vcvttsd2si rdx,xmm1
  410906:	mov    r10b,dl
  410909:	add    r10b,0x30
  41090d:	mov    BYTE PTR [r9+0x6],r10b
  410911:	vxorpd xmm0,xmm0,xmm0
  410915:	movzx  edx,dl
  410918:	vcvtsi2sd xmm0,xmm0,rdx
  41091d:	vsubsd xmm0,xmm1,xmm0
  410921:	vmulsd xmm1,xmm0,xmm15
  410926:	vcvttsd2si rdx,xmm1
  41092b:	mov    r10b,dl
  41092e:	add    r10b,0x30
  410932:	mov    BYTE PTR [r9+0x7],r10b
  410936:	vxorpd xmm0,xmm0,xmm0
  41093a:	movzx  edx,dl
  41093d:	vcvtsi2sd xmm0,xmm0,rdx
  410942:	vsubsd xmm0,xmm1,xmm0
  410946:	vmulsd xmm1,xmm0,xmm15
  41094b:	vcvttsd2si rdx,xmm1
  410950:	mov    r10b,dl
  410953:	add    r10b,0x30
  410957:	mov    BYTE PTR [r9+0x8],r10b
  41095b:	vxorpd xmm0,xmm0,xmm0
  41095f:	movzx  edx,dl
  410962:	vcvtsi2sd xmm0,xmm0,rdx
  410967:	vsubsd xmm0,xmm1,xmm0
  41096b:	vmulsd xmm1,xmm0,xmm15
  410970:	vcvttsd2si rdx,xmm1
  410975:	mov    r10b,dl
  410978:	add    r10b,0x30
  41097c:	mov    BYTE PTR [r9+0x9],r10b
  410980:	vxorpd xmm0,xmm0,xmm0
  410984:	movzx  edx,dl
  410987:	vcvtsi2sd xmm0,xmm0,rdx
  41098c:	vsubsd xmm0,xmm1,xmm0
  410990:	vmulsd xmm1,xmm0,xmm15
  410995:	vcvttsd2si rdx,xmm1
  41099a:	mov    r10b,dl
  41099d:	add    r10b,0x30
  4109a1:	mov    BYTE PTR [r9+0xa],r10b
  4109a5:	vxorpd xmm0,xmm0,xmm0
  4109a9:	movzx  edx,dl
  4109ac:	vcvtsi2sd xmm0,xmm0,rdx
  4109b1:	vsubsd xmm0,xmm1,xmm0
  4109b5:	vmulsd xmm1,xmm0,xmm15
  4109ba:	vcvttsd2si rdx,xmm1
  4109bf:	mov    r10b,dl
  4109c2:	add    r10b,0x30
  4109c6:	mov    BYTE PTR [r9+0xb],r10b
  4109ca:	lea    r10,[r9+0x4]
  4109ce:	vxorpd xmm0,xmm0,xmm0
  4109d2:	movzx  edx,dl
  4109d5:	vcvtsi2sd xmm0,xmm0,rdx
  4109da:	vsubsd xmm0,xmm1,xmm0
  4109de:	vmulsd xmm1,xmm0,xmm15
  4109e3:	vcvttsd2si rdx,xmm1
  4109e8:	mov    r11b,dl
  4109eb:	add    r11b,0x30
  4109ef:	mov    BYTE PTR [r9+0xc],r11b
  4109f3:	vxorpd xmm0,xmm0,xmm0
  4109f7:	movzx  edx,dl
  4109fa:	vcvtsi2sd xmm0,xmm0,rdx
  4109ff:	vsubsd xmm0,xmm1,xmm0
  410a03:	vmulsd xmm1,xmm0,xmm15
  410a08:	vcvttsd2si rdx,xmm1
  410a0d:	mov    r11b,dl
  410a10:	add    r11b,0x30
  410a14:	mov    BYTE PTR [r9+0xd],r11b
  410a18:	lea    r10,[r10+0x2]
  410a1c:	vxorpd xmm0,xmm0,xmm0
  410a20:	movzx  edx,dl
  410a23:	vcvtsi2sd xmm0,xmm0,rdx
  410a28:	vsubsd xmm0,xmm1,xmm0
  410a2c:	vmulsd xmm1,xmm0,xmm15
  410a31:	vcvttsd2si rdx,xmm1
  410a36:	mov    r11b,dl
  410a39:	add    r11b,0x30
  410a3d:	mov    BYTE PTR [r9+0xe],r11b
  410a41:	vxorpd xmm0,xmm0,xmm0
  410a45:	movzx  edx,dl
  410a48:	vcvtsi2sd xmm0,xmm0,rdx
  410a4d:	vsubsd xmm0,xmm1,xmm0
  410a51:	vmulsd xmm1,xmm0,xmm15
  410a56:	vcvttsd2si rdx,xmm1
  410a5b:	mov    r11b,dl
  410a5e:	add    r11b,0x30
  410a62:	mov    BYTE PTR [r9+0xf],r11b
  410a66:	lea    r10,[r10+0x2]
  410a6a:	lea    r10,[r10+0x2]
  410a6e:	lea    r10,[r10+0x2]
  410a72:	lea    r10,[r10+0x2]
  410a76:	lea    r10,[r10+0x2]
  410a7a:	vxorpd xmm0,xmm0,xmm0
  410a7e:	movzx  edx,dl
  410a81:	vcvtsi2sd xmm0,xmm0,rdx
  410a86:	vsubsd xmm0,xmm1,xmm0
  410a8a:	vmulsd xmm1,xmm0,xmm15
  410a8f:	vcvttsd2si rdx,xmm1
  410a94:	mov    r11b,dl
  410a97:	add    r11b,0x30
  410a9b:	mov    BYTE PTR [r9+0x10],r11b
  410a9f:	vxorpd xmm0,xmm0,xmm0
  410aa3:	movzx  edx,dl
  410aa6:	vcvtsi2sd xmm0,xmm0,rdx
  410aab:	vsubsd xmm0,xmm1,xmm0
  410aaf:	vmulsd xmm1,xmm0,xmm15
  410ab4:	vcvttsd2si rdx,xmm1
  410ab9:	add    dl,0x30
  410abc:	mov    BYTE PTR [r9+0x11],dl
  410ac0:	mov    BYTE PTR [r10+0x2],0x65
  410ac5:	lea    r9,[r10+0x3]
  410ac9:	test   r8,r8
  410acc:	jl     410ad5 <__swc_fn_7dafa2b1_000146_43f4fdca+0x6b5>
  410ace:	mov    BYTE PTR [r9],0x2b
  410ad2:	inc    r9
  410ad5:	mov    r10,r9
  410ad8:	mov    rdx,r8
  410adb:	nop    DWORD PTR [rax+rax*1+0x0]
  410ae0:	mov    r11,rdx
  410ae3:	movabs rdx,0x6666666666666667
  410aed:	mov    rax,r11
  410af0:	imul   rdx
  410af3:	sar    rdx,0x2
  410af7:	mov    r12,rdx
  410afa:	shr    rdx,0x3f
  410afe:	add    r12,rdx
  410b01:	mov    rdx,r12
  410b04:	imul   r13,r12,0xa
  410b08:	sub    r11,r13
  410b0b:	mov    r13,QWORD PTR [rip+0x1a2e]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  410b12:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410b17:	mov    BYTE PTR [r10],r11b
  410b1a:	lea    r11,[r10+0x1]
  410b1e:	mov    r10,r11
  410b21:	test   r12,r12
  410b24:	jne    410ae0 <__swc_fn_7dafa2b1_000146_43f4fdca+0x6c0>
  410b26:	test   r8,r8
  410b29:	jge    410b33 <__swc_fn_7dafa2b1_000146_43f4fdca+0x713>
  410b2b:	mov    BYTE PTR [r11],0x2d
  410b2f:	lea    r10,[r11+0x1]
  410b33:	mov    BYTE PTR [r10],0x0
  410b37:	sub    r10,0x1
  410b3b:	nop    DWORD PTR [rax+rax*1+0x0]
  410b40:	cmp    r9,r10
  410b43:	jae    410d98 <__swc_fn_7dafa2b1_000146_43f4fdca+0x978>
  410b49:	mov    al,BYTE PTR [r10]
  410b4c:	mov    dl,BYTE PTR [r9]
  410b4f:	mov    BYTE PTR [r10],dl
  410b52:	sub    r10,0x1
  410b56:	mov    BYTE PTR [r9],al
  410b59:	inc    r9
  410b5c:	jmp    410b40 <__swc_fn_7dafa2b1_000146_43f4fdca+0x720>
  410b5e:	vcvttsd2si rdx,xmm1
  410b63:	mov    r8,rdx
  410b66:	vxorpd xmm0,xmm0,xmm0
  410b6a:	vcvtsi2sd xmm0,xmm0,rdx
  410b6f:	vsubsd xmm0,xmm1,xmm0
  410b73:	mov    r9d,0x8
  410b79:	vxorpd xmm2,xmm2,xmm2
  410b7d:	vcomisd xmm2,xmm0
  410b81:	jbe    410b8b <__swc_fn_7dafa2b1_000146_43f4fdca+0x76b>
  410b83:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x19c5]        # 412550 <__swc_rdata_base_7dafa2b1+0x440>
  410b8b:	test   r9d,r9d
  410b8e:	je     410b9a <__swc_fn_7dafa2b1_000146_43f4fdca+0x77a>
  410b90:	vmulsd xmm0,xmm0,xmm14
  410b95:	dec    r9d
  410b98:	jne    410b90 <__swc_fn_7dafa2b1_000146_43f4fdca+0x770>
  410b9a:	vcvttsd2si r9,xmm0
  410b9f:	mov    r10,r9
  410ba2:	vxorpd xmm2,xmm2,xmm2
  410ba6:	vcvtsi2sd xmm2,xmm2,r9
  410bab:	vsubsd xmm0,xmm0,xmm2
  410baf:	vcomisd xmm0,xmm10
  410bb4:	lea    r9,[r9+0x1]
  410bb8:	cmova  r10,r9
  410bbc:	cmp    r10,0x5f5e100
  410bc3:	jne    410bdc <__swc_fn_7dafa2b1_000146_43f4fdca+0x7bc>
  410bc5:	lea    r8,[rdx-0x1]
  410bc9:	vxorpd xmm0,xmm0,xmm0
  410bcd:	vcomisd xmm0,xmm1
  410bd1:	lea    rdx,[rdx+0x1]
  410bd5:	cmovbe r8,rdx
  410bd9:	xor    r10d,r10d
  410bdc:	mov    r9,rcx
  410bdf:	test   r8,r8
  410be2:	jne    410c02 <__swc_fn_7dafa2b1_000146_43f4fdca+0x7e2>
  410be4:	vxorpd xmm0,xmm0,xmm0
  410be8:	vcomisd xmm0,xmm1
  410bec:	jbe    410bf5 <__swc_fn_7dafa2b1_000146_43f4fdca+0x7d5>
  410bee:	mov    BYTE PTR [rcx],0x2d
  410bf1:	lea    r9,[rcx+0x1]
  410bf5:	mov    BYTE PTR [r9],0x30
  410bf9:	add    r9,0x1
  410bfd:	jmp    410c9b <__swc_fn_7dafa2b1_000146_43f4fdca+0x87b>
  410c02:	mov    r9,rcx
  410c05:	mov    rdx,r8
  410c08:	nop    DWORD PTR [rax+rax*1+0x0]
  410c10:	mov    r11,rdx
  410c13:	movabs rdx,0x6666666666666667
  410c1d:	mov    r15,rax
  410c20:	mov    rax,r11
  410c23:	imul   rdx
  410c26:	mov    r12,rdx
  410c29:	mov    rax,r15
  410c2c:	sar    r12,0x2
  410c30:	mov    rdx,r12
  410c33:	shr    rdx,0x3f
  410c37:	add    r12,rdx
  410c3a:	mov    rdx,r12
  410c3d:	imul   r13,r12,0xa
  410c41:	sub    r11,r13
  410c44:	mov    r13,QWORD PTR [rip+0x18f5]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  410c4b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410c50:	mov    BYTE PTR [r9],r11b
  410c53:	lea    r11,[r9+0x1]
  410c57:	mov    r9,r11
  410c5a:	test   r12,r12
  410c5d:	jne    410c10 <__swc_fn_7dafa2b1_000146_43f4fdca+0x7f0>
  410c5f:	test   r8,r8
  410c62:	jge    410c6c <__swc_fn_7dafa2b1_000146_43f4fdca+0x84c>
  410c64:	mov    BYTE PTR [r11],0x2d
  410c68:	lea    r9,[r11+0x1]
  410c6c:	mov    rdx,r9
  410c6f:	mov    BYTE PTR [r9],0x0
  410c73:	sub    r9,0x1
  410c77:	mov    r8,rcx
  410c7a:	cmp    r8,r9
  410c7d:	jae    410c98 <__swc_fn_7dafa2b1_000146_43f4fdca+0x878>
  410c7f:	nop
  410c80:	mov    r11b,BYTE PTR [r9]
  410c83:	mov    r12b,BYTE PTR [r8]
  410c86:	mov    BYTE PTR [r9],r12b
  410c89:	sub    r9,0x1
  410c8d:	mov    BYTE PTR [r8],r11b
  410c90:	inc    r8
  410c93:	cmp    r8,r9
  410c96:	jb     410c80 <__swc_fn_7dafa2b1_000146_43f4fdca+0x860>
  410c98:	mov    r9,rdx
  410c9b:	mov    BYTE PTR [r9],0x2e
  410c9f:	add    r9,0x1
  410ca3:	xor    r8d,r8d
  410ca6:	test   r10,r10
  410ca9:	je     410cef <__swc_fn_7dafa2b1_000146_43f4fdca+0x8cf>
  410cab:	mov    r11d,0x989680
  410cb1:	cmp    r10,r11
  410cb4:	jge    410cef <__swc_fn_7dafa2b1_000146_43f4fdca+0x8cf>
  410cb6:	cs nop WORD PTR [rax+rax*1+0x0]
  410cc0:	inc    r8d
  410cc3:	movabs rdx,0x6666666666666667
  410ccd:	mov    r15,rax
  410cd0:	mov    rax,r11
  410cd3:	imul   rdx
  410cd6:	mov    r11,rdx
  410cd9:	mov    rax,r15
  410cdc:	sar    r11,0x2
  410ce0:	mov    rdx,r11
  410ce3:	shr    rdx,0x3f
  410ce7:	add    r11,rdx
  410cea:	cmp    r10,r11
  410ced:	jl     410cc0 <__swc_fn_7dafa2b1_000146_43f4fdca+0x8a0>
  410cef:	test   r8d,r8d
  410cf2:	je     410d0d <__swc_fn_7dafa2b1_000146_43f4fdca+0x8ed>
  410cf4:	cs nop WORD PTR [rax+rax*1+0x0]
  410cfe:	xchg   ax,ax
  410d00:	mov    BYTE PTR [r9],0x30
  410d04:	add    r9,0x1
  410d08:	dec    r8d
  410d0b:	jne    410d00 <__swc_fn_7dafa2b1_000146_43f4fdca+0x8e0>
  410d0d:	mov    r8,r9
  410d10:	mov    rdx,r10
  410d13:	cs nop WORD PTR [rax+rax*1+0x0]
  410d1d:	nop    DWORD PTR [rax]
  410d20:	mov    r11,rdx
  410d23:	movabs rdx,0x6666666666666667
  410d2d:	mov    rax,r11
  410d30:	imul   rdx
  410d33:	sar    rdx,0x2
  410d37:	mov    r12,rdx
  410d3a:	shr    rdx,0x3f
  410d3e:	add    r12,rdx
  410d41:	mov    rdx,r12
  410d44:	imul   r13,r12,0xa
  410d48:	sub    r11,r13
  410d4b:	mov    r13,QWORD PTR [rip+0x17ee]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  410d52:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410d57:	mov    BYTE PTR [r8],r11b
  410d5a:	lea    r11,[r8+0x1]
  410d5e:	mov    r8,r11
  410d61:	test   r12,r12
  410d64:	jne    410d20 <__swc_fn_7dafa2b1_000146_43f4fdca+0x900>
  410d66:	test   r10,r10
  410d69:	jge    410d73 <__swc_fn_7dafa2b1_000146_43f4fdca+0x953>
  410d6b:	mov    BYTE PTR [r11],0x2d
  410d6f:	lea    r8,[r11+0x1]
  410d73:	mov    BYTE PTR [r8],0x0
  410d77:	sub    r8,0x1
  410d7b:	cmp    r9,r8
  410d7e:	jae    410d98 <__swc_fn_7dafa2b1_000146_43f4fdca+0x978>
  410d80:	mov    al,BYTE PTR [r8]
  410d83:	mov    dl,BYTE PTR [r9]
  410d86:	mov    BYTE PTR [r8],dl
  410d89:	sub    r8,0x1
  410d8d:	mov    BYTE PTR [r9],al
  410d90:	inc    r9
  410d93:	cmp    r9,r8
  410d96:	jb     410d80 <__swc_fn_7dafa2b1_000146_43f4fdca+0x960>
  410d98:	xor    eax,eax
  410d9a:	test   rcx,rcx
  410d9d:	je     410dd0 <__swc_fn_7dafa2b1_000146_43f4fdca+0x9b0>
  410d9f:	mov    rdx,rcx
  410da2:	mov    r8b,BYTE PTR [rdx]
  410da5:	test   r8b,r8b
  410da8:	je     410dd0 <__swc_fn_7dafa2b1_000146_43f4fdca+0x9b0>
  410daa:	cs nop WORD PTR [rax+rax*1+0x0]
  410db4:	cs nop WORD PTR [rax+rax*1+0x0]
  410dbe:	xchg   ax,ax
  410dc0:	add    rdx,0x1
  410dc4:	add    rax,0x1
  410dc8:	mov    r8b,BYTE PTR [rdx]
  410dcb:	test   r8b,r8b
  410dce:	jne    410dc0 <__swc_fn_7dafa2b1_000146_43f4fdca+0x9a0>
  410dd0:	mov    QWORD PTR [rsp+0x240],rcx
  410dd8:	mov    QWORD PTR [rsp+0x248],rax
  410de0:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  410de9:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  410df2:	lea    rcx,[rsp+0x250]
  410dfa:	call   40fba0 <__swc_fn_7dafa2b1_000116_035d76a1>
  410dff:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  410e04:	lea    rcx,[rsp+0x260]
  410e0c:	vxorps xmm0,xmm0,xmm0
  410e10:	vmovups XMMWORD PTR [rsp+0x260],xmm0
  410e19:	vmovups XMMWORD PTR [rsp+0x270],xmm0
  410e22:	vmovups XMMWORD PTR [rsp+0x280],xmm0
  410e2b:	vmovups XMMWORD PTR [rsp+0x290],xmm0
  410e34:	vmovups XMMWORD PTR [rsp+0x2a0],xmm0
  410e3d:	vmovups XMMWORD PTR [rsp+0x2b0],xmm0
  410e46:	mov    DWORD PTR [rsp+0x2c0],0x0
  410e51:	vmovsd xmm0,QWORD PTR [rdx]
  410e55:	vcomisd xmm0,xmm0
  410e59:	setne  dl
  410e5c:	movzx  edx,dl
  410e5f:	setp   r8b
  410e63:	movzx  r8d,r8b
  410e67:	or     edx,r8d
  410e6a:	test   dl,dl
  410e6c:	je     410e79 <__swc_fn_7dafa2b1_000146_43f4fdca+0xa59>
  410e6e:	mov    DWORD PTR [rcx],0x6e616e
  410e74:	jmp    411488 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1068>
  410e79:	vcomisd xmm0,xmm11
  410e7e:	ja     410e8f <__swc_fn_7dafa2b1_000146_43f4fdca+0xa6f>
  410e80:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  410e89:	vcomisd xmm6,xmm0
  410e8d:	jbe    410eb3 <__swc_fn_7dafa2b1_000146_43f4fdca+0xa93>
  410e8f:	vxorpd xmm1,xmm1,xmm1
  410e93:	vcomisd xmm1,xmm0
  410e97:	jbe    410ea8 <__swc_fn_7dafa2b1_000146_43f4fdca+0xa88>
  410e99:	mov    DWORD PTR [rcx],0x666e692d
  410e9f:	mov    BYTE PTR [rcx+0x4],0x0
  410ea3:	jmp    411488 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1068>
  410ea8:	mov    DWORD PTR [rcx],0x666e69
  410eae:	jmp    411488 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1068>
  410eb3:	vcomisd xmm0,xmm13
  410eb8:	jae    410ec4 <__swc_fn_7dafa2b1_000146_43f4fdca+0xaa4>
  410eba:	vcomisd xmm12,xmm0
  410ebe:	jbe    41122e <__swc_fn_7dafa2b1_000146_43f4fdca+0xe0e>
  410ec4:	vmovups xmm1,xmm0
  410ec8:	vxorpd xmm2,xmm2,xmm2
  410ecc:	vcomisd xmm2,xmm0
  410ed0:	jbe    410ee0 <__swc_fn_7dafa2b1_000146_43f4fdca+0xac0>
  410ed2:	vmovsd xmm0,xmm0,xmm1
  410ed6:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x1672]        # 412550 <__swc_rdata_base_7dafa2b1+0x440>
  410ede:	jmp    410ee4 <__swc_fn_7dafa2b1_000146_43f4fdca+0xac4>
  410ee0:	vmovsd xmm0,xmm0,xmm1
  410ee4:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  410eed:	xor    r8d,r8d
  410ef0:	vcomisd xmm0,xmm6
  410ef4:	jb     410f0e <__swc_fn_7dafa2b1_000146_43f4fdca+0xaee>
  410ef6:	cs nop WORD PTR [rax+rax*1+0x0]
  410f00:	vdivsd xmm0,xmm0,xmm6
  410f04:	add    r8,0x1
  410f08:	vcomisd xmm0,xmm6
  410f0c:	jae    410f00 <__swc_fn_7dafa2b1_000146_43f4fdca+0xae0>
  410f0e:	mov    r9,rcx
  410f11:	vxorpd xmm2,xmm2,xmm2
  410f15:	vcomisd xmm2,xmm1
  410f19:	jbe    410f22 <__swc_fn_7dafa2b1_000146_43f4fdca+0xb02>
  410f1b:	mov    BYTE PTR [rcx],0x2d
  410f1e:	lea    r9,[rcx+0x1]
  410f22:	vcvttsd2si rdx,xmm0
  410f27:	mov    r10b,dl
  410f2a:	add    r10b,0x30
  410f2e:	mov    BYTE PTR [r9],r10b
  410f31:	vxorpd xmm1,xmm1,xmm1
  410f35:	movzx  edx,dl
  410f38:	vcvtsi2sd xmm1,xmm1,rdx
  410f3d:	vsubsd xmm0,xmm0,xmm1
  410f41:	vmulsd xmm0,xmm0,xmm6
  410f45:	mov    BYTE PTR [r9+0x1],0x2e
  410f4a:	vcvttsd2si rdx,xmm0
  410f4f:	mov    r10b,dl
  410f52:	add    r10b,0x30
  410f56:	mov    BYTE PTR [r9+0x2],r10b
  410f5a:	vxorpd xmm1,xmm1,xmm1
  410f5e:	movzx  edx,dl
  410f61:	vcvtsi2sd xmm1,xmm1,rdx
  410f66:	vsubsd xmm0,xmm0,xmm1
  410f6a:	vmulsd xmm0,xmm0,xmm6
  410f6e:	vcvttsd2si rdx,xmm0
  410f73:	mov    r10b,dl
  410f76:	add    r10b,0x30
  410f7a:	mov    BYTE PTR [r9+0x3],r10b
  410f7e:	vxorpd xmm1,xmm1,xmm1
  410f82:	movzx  edx,dl
  410f85:	vcvtsi2sd xmm1,xmm1,rdx
  410f8a:	vsubsd xmm0,xmm0,xmm1
  410f8e:	vmulsd xmm0,xmm0,xmm6
  410f92:	vcvttsd2si rdx,xmm0
  410f97:	mov    r10b,dl
  410f9a:	add    r10b,0x30
  410f9e:	mov    BYTE PTR [r9+0x4],r10b
  410fa2:	vxorpd xmm1,xmm1,xmm1
  410fa6:	movzx  edx,dl
  410fa9:	vcvtsi2sd xmm1,xmm1,rdx
  410fae:	vsubsd xmm0,xmm0,xmm1
  410fb2:	vmulsd xmm0,xmm0,xmm6
  410fb6:	vcvttsd2si rdx,xmm0
  410fbb:	mov    r10b,dl
  410fbe:	add    r10b,0x30
  410fc2:	mov    BYTE PTR [r9+0x5],r10b
  410fc6:	vxorpd xmm1,xmm1,xmm1
  410fca:	movzx  edx,dl
  410fcd:	vcvtsi2sd xmm1,xmm1,rdx
  410fd2:	vsubsd xmm0,xmm0,xmm1
  410fd6:	vmulsd xmm0,xmm0,xmm6
  410fda:	vcvttsd2si rdx,xmm0
  410fdf:	mov    r10b,dl
  410fe2:	add    r10b,0x30
  410fe6:	mov    BYTE PTR [r9+0x6],r10b
  410fea:	vxorpd xmm1,xmm1,xmm1
  410fee:	movzx  edx,dl
  410ff1:	vcvtsi2sd xmm1,xmm1,rdx
  410ff6:	vsubsd xmm0,xmm0,xmm1
  410ffa:	vmulsd xmm0,xmm0,xmm6
  410ffe:	vcvttsd2si rdx,xmm0
  411003:	mov    r10b,dl
  411006:	add    r10b,0x30
  41100a:	mov    BYTE PTR [r9+0x7],r10b
  41100e:	vxorpd xmm1,xmm1,xmm1
  411012:	movzx  edx,dl
  411015:	vcvtsi2sd xmm1,xmm1,rdx
  41101a:	vsubsd xmm0,xmm0,xmm1
  41101e:	vmulsd xmm0,xmm0,xmm6
  411022:	vcvttsd2si rdx,xmm0
  411027:	mov    r10b,dl
  41102a:	add    r10b,0x30
  41102e:	mov    BYTE PTR [r9+0x8],r10b
  411032:	vxorpd xmm1,xmm1,xmm1
  411036:	movzx  edx,dl
  411039:	vcvtsi2sd xmm1,xmm1,rdx
  41103e:	vsubsd xmm0,xmm0,xmm1
  411042:	vmulsd xmm0,xmm0,xmm6
  411046:	vcvttsd2si rdx,xmm0
  41104b:	mov    r10b,dl
  41104e:	add    r10b,0x30
  411052:	mov    BYTE PTR [r9+0x9],r10b
  411056:	vxorpd xmm1,xmm1,xmm1
  41105a:	movzx  edx,dl
  41105d:	vcvtsi2sd xmm1,xmm1,rdx
  411062:	vsubsd xmm0,xmm0,xmm1
  411066:	vmulsd xmm0,xmm0,xmm6
  41106a:	vcvttsd2si rdx,xmm0
  41106f:	mov    r10b,dl
  411072:	add    r10b,0x30
  411076:	mov    BYTE PTR [r9+0xa],r10b
  41107a:	vxorpd xmm1,xmm1,xmm1
  41107e:	movzx  edx,dl
  411081:	vcvtsi2sd xmm1,xmm1,rdx
  411086:	vsubsd xmm0,xmm0,xmm1
  41108a:	vmulsd xmm0,xmm0,xmm6
  41108e:	vcvttsd2si rdx,xmm0
  411093:	mov    r10b,dl
  411096:	add    r10b,0x30
  41109a:	mov    BYTE PTR [r9+0xb],r10b
  41109e:	lea    r10,[r9+0x4]
  4110a2:	vxorpd xmm1,xmm1,xmm1
  4110a6:	movzx  edx,dl
  4110a9:	vcvtsi2sd xmm1,xmm1,rdx
  4110ae:	vsubsd xmm0,xmm0,xmm1
  4110b2:	vmulsd xmm0,xmm0,xmm6
  4110b6:	vcvttsd2si rdx,xmm0
  4110bb:	mov    r11b,dl
  4110be:	add    r11b,0x30
  4110c2:	mov    BYTE PTR [r9+0xc],r11b
  4110c6:	vxorpd xmm1,xmm1,xmm1
  4110ca:	movzx  edx,dl
  4110cd:	vcvtsi2sd xmm1,xmm1,rdx
  4110d2:	vsubsd xmm0,xmm0,xmm1
  4110d6:	vmulsd xmm0,xmm0,xmm6
  4110da:	vcvttsd2si rdx,xmm0
  4110df:	mov    r11b,dl
  4110e2:	add    r11b,0x30
  4110e6:	mov    BYTE PTR [r9+0xd],r11b
  4110ea:	lea    r10,[r10+0x2]
  4110ee:	vxorpd xmm1,xmm1,xmm1
  4110f2:	movzx  edx,dl
  4110f5:	vcvtsi2sd xmm1,xmm1,rdx
  4110fa:	vsubsd xmm0,xmm0,xmm1
  4110fe:	vmulsd xmm0,xmm0,xmm6
  411102:	vcvttsd2si rdx,xmm0
  411107:	mov    r11b,dl
  41110a:	add    r11b,0x30
  41110e:	mov    BYTE PTR [r9+0xe],r11b
  411112:	vxorpd xmm1,xmm1,xmm1
  411116:	movzx  edx,dl
  411119:	vcvtsi2sd xmm1,xmm1,rdx
  41111e:	vsubsd xmm0,xmm0,xmm1
  411122:	vmulsd xmm0,xmm0,xmm6
  411126:	vcvttsd2si rdx,xmm0
  41112b:	mov    r11b,dl
  41112e:	add    r11b,0x30
  411132:	mov    BYTE PTR [r9+0xf],r11b
  411136:	lea    r10,[r10+0x2]
  41113a:	lea    r10,[r10+0x2]
  41113e:	lea    r10,[r10+0x2]
  411142:	lea    r10,[r10+0x2]
  411146:	lea    r10,[r10+0x2]
  41114a:	vxorpd xmm1,xmm1,xmm1
  41114e:	movzx  edx,dl
  411151:	vcvtsi2sd xmm1,xmm1,rdx
  411156:	vsubsd xmm0,xmm0,xmm1
  41115a:	vmulsd xmm0,xmm0,xmm6
  41115e:	vcvttsd2si rdx,xmm0
  411163:	mov    r11b,dl
  411166:	add    r11b,0x30
  41116a:	mov    BYTE PTR [r9+0x10],r11b
  41116e:	vxorpd xmm1,xmm1,xmm1
  411172:	movzx  edx,dl
  411175:	vcvtsi2sd xmm1,xmm1,rdx
  41117a:	vsubsd xmm0,xmm0,xmm1
  41117e:	vmulsd xmm0,xmm0,xmm6
  411182:	vcvttsd2si rdx,xmm0
  411187:	add    dl,0x30
  41118a:	mov    BYTE PTR [r9+0x11],dl
  41118e:	mov    BYTE PTR [r10+0x2],0x65
  411193:	lea    r9,[r10+0x3]
  411197:	test   r8,r8
  41119a:	jl     4111a3 <__swc_fn_7dafa2b1_000146_43f4fdca+0xd83>
  41119c:	mov    BYTE PTR [r9],0x2b
  4111a0:	inc    r9
  4111a3:	mov    r10,r9
  4111a6:	mov    rdx,r8
  4111a9:	nop    DWORD PTR [rax+0x0]
  4111b0:	mov    r11,rdx
  4111b3:	movabs rdx,0x6666666666666667
  4111bd:	mov    rax,r11
  4111c0:	imul   rdx
  4111c3:	sar    rdx,0x2
  4111c7:	mov    r12,rdx
  4111ca:	shr    rdx,0x3f
  4111ce:	add    r12,rdx
  4111d1:	mov    rdx,r12
  4111d4:	imul   r13,r12,0xa
  4111d8:	sub    r11,r13
  4111db:	mov    r13,QWORD PTR [rip+0x135e]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  4111e2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4111e7:	mov    BYTE PTR [r10],r11b
  4111ea:	lea    r11,[r10+0x1]
  4111ee:	mov    r10,r11
  4111f1:	test   r12,r12
  4111f4:	jne    4111b0 <__swc_fn_7dafa2b1_000146_43f4fdca+0xd90>
  4111f6:	test   r8,r8
  4111f9:	jge    411203 <__swc_fn_7dafa2b1_000146_43f4fdca+0xde3>
  4111fb:	mov    BYTE PTR [r11],0x2d
  4111ff:	lea    r10,[r11+0x1]
  411203:	mov    BYTE PTR [r10],0x0
  411207:	sub    r10,0x1
  41120b:	nop    DWORD PTR [rax+rax*1+0x0]
  411210:	cmp    r9,r10
  411213:	jae    411488 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1068>
  411219:	mov    al,BYTE PTR [r10]
  41121c:	mov    dl,BYTE PTR [r9]
  41121f:	mov    BYTE PTR [r10],dl
  411222:	sub    r10,0x1
  411226:	mov    BYTE PTR [r9],al
  411229:	inc    r9
  41122c:	jmp    411210 <__swc_fn_7dafa2b1_000146_43f4fdca+0xdf0>
  41122e:	vcvttsd2si rdx,xmm0
  411233:	mov    r8,rdx
  411236:	vxorpd xmm1,xmm1,xmm1
  41123a:	vcvtsi2sd xmm1,xmm1,rdx
  41123f:	vsubsd xmm1,xmm0,xmm1
  411243:	mov    r9d,0x8
  411249:	vxorpd xmm2,xmm2,xmm2
  41124d:	vcomisd xmm2,xmm1
  411251:	ja     41125e <__swc_fn_7dafa2b1_000146_43f4fdca+0xe3e>
  411253:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41125c:	jmp    41126f <__swc_fn_7dafa2b1_000146_43f4fdca+0xe4f>
  41125e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x12ea]        # 412550 <__swc_rdata_base_7dafa2b1+0x440>
  411266:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41126f:	test   r9d,r9d
  411272:	je     411289 <__swc_fn_7dafa2b1_000146_43f4fdca+0xe69>
  411274:	cs nop WORD PTR [rax+rax*1+0x0]
  41127e:	xchg   ax,ax
  411280:	vmulsd xmm1,xmm1,xmm6
  411284:	dec    r9d
  411287:	jne    411280 <__swc_fn_7dafa2b1_000146_43f4fdca+0xe60>
  411289:	vcvttsd2si r9,xmm1
  41128e:	mov    r10,r9
  411291:	vxorpd xmm2,xmm2,xmm2
  411295:	vcvtsi2sd xmm2,xmm2,r9
  41129a:	vsubsd xmm1,xmm1,xmm2
  41129e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  4112a7:	vcomisd xmm1,xmm6
  4112ab:	lea    r9,[r9+0x1]
  4112af:	cmova  r10,r9
  4112b3:	cmp    r10,0x5f5e100
  4112ba:	jne    4112d3 <__swc_fn_7dafa2b1_000146_43f4fdca+0xeb3>
  4112bc:	lea    r8,[rdx-0x1]
  4112c0:	vxorpd xmm1,xmm1,xmm1
  4112c4:	vcomisd xmm1,xmm0
  4112c8:	lea    rdx,[rdx+0x1]
  4112cc:	cmovbe r8,rdx
  4112d0:	xor    r10d,r10d
  4112d3:	mov    r9,rcx
  4112d6:	test   r8,r8
  4112d9:	jne    4112f9 <__swc_fn_7dafa2b1_000146_43f4fdca+0xed9>
  4112db:	vxorpd xmm1,xmm1,xmm1
  4112df:	vcomisd xmm1,xmm0
  4112e3:	jbe    4112ec <__swc_fn_7dafa2b1_000146_43f4fdca+0xecc>
  4112e5:	mov    BYTE PTR [rcx],0x2d
  4112e8:	lea    r9,[rcx+0x1]
  4112ec:	mov    BYTE PTR [r9],0x30
  4112f0:	add    r9,0x1
  4112f4:	jmp    41138b <__swc_fn_7dafa2b1_000146_43f4fdca+0xf6b>
  4112f9:	mov    r9,rcx
  4112fc:	mov    rdx,r8
  4112ff:	nop
  411300:	mov    r11,rdx
  411303:	movabs rdx,0x6666666666666667
  41130d:	mov    r15,rax
  411310:	mov    rax,r11
  411313:	imul   rdx
  411316:	mov    r12,rdx
  411319:	mov    rax,r15
  41131c:	sar    r12,0x2
  411320:	mov    rdx,r12
  411323:	shr    rdx,0x3f
  411327:	add    r12,rdx
  41132a:	mov    rdx,r12
  41132d:	imul   r13,r12,0xa
  411331:	sub    r11,r13
  411334:	mov    r13,QWORD PTR [rip+0x1205]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  41133b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411340:	mov    BYTE PTR [r9],r11b
  411343:	lea    r11,[r9+0x1]
  411347:	mov    r9,r11
  41134a:	test   r12,r12
  41134d:	jne    411300 <__swc_fn_7dafa2b1_000146_43f4fdca+0xee0>
  41134f:	test   r8,r8
  411352:	jge    41135c <__swc_fn_7dafa2b1_000146_43f4fdca+0xf3c>
  411354:	mov    BYTE PTR [r11],0x2d
  411358:	lea    r9,[r11+0x1]
  41135c:	mov    rdx,r9
  41135f:	mov    BYTE PTR [r9],0x0
  411363:	sub    r9,0x1
  411367:	mov    r8,rcx
  41136a:	cmp    r8,r9
  41136d:	jae    411388 <__swc_fn_7dafa2b1_000146_43f4fdca+0xf68>
  41136f:	nop
  411370:	mov    r11b,BYTE PTR [r9]
  411373:	mov    r12b,BYTE PTR [r8]
  411376:	mov    BYTE PTR [r9],r12b
  411379:	sub    r9,0x1
  41137d:	mov    BYTE PTR [r8],r11b
  411380:	inc    r8
  411383:	cmp    r8,r9
  411386:	jb     411370 <__swc_fn_7dafa2b1_000146_43f4fdca+0xf50>
  411388:	mov    r9,rdx
  41138b:	mov    BYTE PTR [r9],0x2e
  41138f:	add    r9,0x1
  411393:	xor    r8d,r8d
  411396:	test   r10,r10
  411399:	je     4113df <__swc_fn_7dafa2b1_000146_43f4fdca+0xfbf>
  41139b:	mov    r11d,0x989680
  4113a1:	cmp    r10,r11
  4113a4:	jge    4113df <__swc_fn_7dafa2b1_000146_43f4fdca+0xfbf>
  4113a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4113b0:	inc    r8d
  4113b3:	movabs rdx,0x6666666666666667
  4113bd:	mov    r15,rax
  4113c0:	mov    rax,r11
  4113c3:	imul   rdx
  4113c6:	mov    r11,rdx
  4113c9:	mov    rax,r15
  4113cc:	sar    r11,0x2
  4113d0:	mov    rdx,r11
  4113d3:	shr    rdx,0x3f
  4113d7:	add    r11,rdx
  4113da:	cmp    r10,r11
  4113dd:	jl     4113b0 <__swc_fn_7dafa2b1_000146_43f4fdca+0xf90>
  4113df:	test   r8d,r8d
  4113e2:	je     4113fd <__swc_fn_7dafa2b1_000146_43f4fdca+0xfdd>
  4113e4:	cs nop WORD PTR [rax+rax*1+0x0]
  4113ee:	xchg   ax,ax
  4113f0:	mov    BYTE PTR [r9],0x30
  4113f4:	add    r9,0x1
  4113f8:	dec    r8d
  4113fb:	jne    4113f0 <__swc_fn_7dafa2b1_000146_43f4fdca+0xfd0>
  4113fd:	mov    r8,r9
  411400:	mov    rdx,r10
  411403:	cs nop WORD PTR [rax+rax*1+0x0]
  41140d:	nop    DWORD PTR [rax]
  411410:	mov    r11,rdx
  411413:	movabs rdx,0x6666666666666667
  41141d:	mov    rax,r11
  411420:	imul   rdx
  411423:	sar    rdx,0x2
  411427:	mov    r12,rdx
  41142a:	shr    rdx,0x3f
  41142e:	add    r12,rdx
  411431:	mov    rdx,r12
  411434:	imul   r13,r12,0xa
  411438:	sub    r11,r13
  41143b:	mov    r13,QWORD PTR [rip+0x10fe]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  411442:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411447:	mov    BYTE PTR [r8],r11b
  41144a:	lea    r11,[r8+0x1]
  41144e:	mov    r8,r11
  411451:	test   r12,r12
  411454:	jne    411410 <__swc_fn_7dafa2b1_000146_43f4fdca+0xff0>
  411456:	test   r10,r10
  411459:	jge    411463 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1043>
  41145b:	mov    BYTE PTR [r11],0x2d
  41145f:	lea    r8,[r11+0x1]
  411463:	mov    BYTE PTR [r8],0x0
  411467:	sub    r8,0x1
  41146b:	cmp    r9,r8
  41146e:	jae    411488 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1068>
  411470:	mov    al,BYTE PTR [r8]
  411473:	mov    dl,BYTE PTR [r9]
  411476:	mov    BYTE PTR [r8],dl
  411479:	sub    r8,0x1
  41147d:	mov    BYTE PTR [r9],al
  411480:	inc    r9
  411483:	cmp    r9,r8
  411486:	jb     411470 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1050>
  411488:	xor    eax,eax
  41148a:	test   rcx,rcx
  41148d:	je     4114b0 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1090>
  41148f:	mov    rdx,rcx
  411492:	mov    r8b,BYTE PTR [rdx]
  411495:	test   r8b,r8b
  411498:	je     4114b0 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1090>
  41149a:	nop    WORD PTR [rax+rax*1+0x0]
  4114a0:	add    rdx,0x1
  4114a4:	add    rax,0x1
  4114a8:	mov    r8b,BYTE PTR [rdx]
  4114ab:	test   r8b,r8b
  4114ae:	jne    4114a0 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1080>
  4114b0:	mov    QWORD PTR [rsp+0x3f8],rcx
  4114b8:	mov    QWORD PTR [rsp+0x400],rax
  4114c0:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  4114c9:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  4114d2:	lea    rcx,[rsp+0x408]
  4114da:	call   40fba0 <__swc_fn_7dafa2b1_000116_035d76a1>
  4114df:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  4114e1:	mov    rcx,rdx
  4114e4:	call   40fba0 <__swc_fn_7dafa2b1_000116_035d76a1>
  4114e9:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  4114eb:	mov    al,BYTE PTR [rdx]
  4114ed:	test   al,al
  4114ef:	je     4114fa <__swc_fn_7dafa2b1_000146_43f4fdca+0x10da>
  4114f1:	lea    rax,[rip+0x1068]        # 412560 <__swc_rdata_base_7dafa2b1+0x450>
  4114f8:	jmp    411501 <__swc_fn_7dafa2b1_000146_43f4fdca+0x10e1>
  4114fa:	lea    rax,[rip+0x106f]        # 412570 <__swc_rdata_base_7dafa2b1+0x460>
  411501:	mov    rcx,rax
  411504:	call   40fba0 <__swc_fn_7dafa2b1_000116_035d76a1>
  411509:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  41150b:	lea    rcx,[rip+0x106e]        # 412580 <__swc_rdata_base_7dafa2b1+0x470>
  411512:	call   40fba0 <__swc_fn_7dafa2b1_000116_035d76a1>
  411517:	jmp    411525 <__swc_fn_7dafa2b1_000146_43f4fdca+0x1105>
  411519:	lea    rcx,[rip+0x1060]        # 412580 <__swc_rdata_base_7dafa2b1+0x470>
  411520:	call   40fba0 <__swc_fn_7dafa2b1_000116_035d76a1>
  411525:	add    rdi,0x1
  411529:	sub    rsi,0x1
  41152d:	vmovups xmm0,xmm12
  411532:	vmovsd xmm6,QWORD PTR [rip+0x1056]        # 412590 <__swc_rdata_base_7dafa2b1+0x480>
  41153a:	test   rsi,rsi
  41153d:	jne    410530 <__swc_fn_7dafa2b1_000146_43f4fdca+0x110>
  411543:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  41154c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411555:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  41155e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411567:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411570:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411579:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411582:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  41158b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411594:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  41159d:	add    rsp,0x4e8
  4115a4:	pop    r15
  4115a6:	pop    r13
  4115a8:	pop    r12
  4115aa:	pop    rdi
  4115ab:	pop    rsi
  4115ac:	pop    rbx
  4115ad:	ret
	...

00000000004115b0 <__swc_fn_7dafa2b1_000149_9e4bc402>:
  4115b0:	vxorps xmm0,xmm0,xmm0
  4115b4:	vmovups XMMWORD PTR [rcx],xmm0
  4115b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4115bd:	ret
	...

00000000004115c0 <__swc_fn_7dafa2b1_000152_9e4bc402>:
  4115c0:	vxorps xmm0,xmm0,xmm0
  4115c4:	vmovups XMMWORD PTR [rcx],xmm0
  4115c8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4115cd:	vxorps xmm0,xmm0,xmm0
  4115d1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4115d6:	vmovups xmm0,XMMWORD PTR [rip+0x10c2]        # 4126a0 <__swc_rdata_base_7dafa2b1+0x590>
  4115de:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4115e3:	vxorps xmm0,xmm0,xmm0
  4115e7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  4115ec:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  4115f1:	vxorps xmm0,xmm0,xmm0
  4115f5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  4115fa:	mov    QWORD PTR [rcx+0x70],0x0
  411602:	ret
	...

0000000000411610 <__swc_fn_7dafa2b1_000155_9e4bc402>:
  411610:	vxorps xmm0,xmm0,xmm0
  411614:	vmovups XMMWORD PTR [rcx],xmm0
  411618:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41161d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411622:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411627:	ret
	...

0000000000411630 <__swc_fn_7dafa2b1_000158_b43b2f96>:
  411630:	push   rsi
  411631:	push   rdi
  411632:	sub    rsp,0x8
  411636:	mov    rsi,rcx
  411639:	mov    rdi,QWORD PTR [rsi+0x50]
  41163d:	test   rdi,rdi
  411640:	je     411647 <__swc_fn_7dafa2b1_000158_b43b2f96+0x17>
  411642:	mov    rcx,rsi
  411645:	call   rdi
  411647:	mov    QWORD PTR [rsi+0x20],0x0
  41164f:	mov    rax,QWORD PTR [rsi+0x30]
  411653:	test   rax,rax
  411656:	je     411684 <__swc_fn_7dafa2b1_000158_b43b2f96+0x54>
  411658:	nop    DWORD PTR [rax+rax*1+0x0]
  411660:	mov    rdi,QWORD PTR [rax+0x8]
  411664:	mov    rcx,rsi
  411667:	mov    rdx,QWORD PTR [rax+0x10]
  41166b:	mov    rax,QWORD PTR [rax+0x18]
  41166f:	mov    r8,rax
  411672:	call   409ec0 <__swc_fn_7dafa2b1_000156_2745c4a5>
  411677:	mov    QWORD PTR [rsi+0x30],rdi
  41167b:	mov    rax,QWORD PTR [rsi+0x30]
  41167f:	test   rax,rax
  411682:	jne    411660 <__swc_fn_7dafa2b1_000158_b43b2f96+0x30>
  411684:	mov    QWORD PTR [rsi+0x38],0x0
  41168c:	add    rsp,0x8
  411690:	pop    rdi
  411691:	pop    rsi
  411692:	ret
	...

00000000004116a0 <__swc_fn_7dafa2b1_000161_b5a9d657>:
  4116a0:	push   rbx
  4116a1:	push   rsi
  4116a2:	push   rdi
  4116a3:	push   r12
  4116a5:	sub    rsp,0x188
  4116ac:	mov    rbx,rcx
  4116af:	lea    rsi,[rip+0x146da]        # 425d90 <__swc_bss_base_7dafa2b1+0x2d50>
  4116b6:	mov    rcx,rsi
  4116b9:	call   4098c0 <__swc_fn_7dafa2b1_000135_e3032dc2>
  4116be:	mov    rax,QWORD PTR [rip+0x146d3]        # 425d98 <__swc_bss_base_7dafa2b1+0x2d58>
  4116c5:	mov    rdi,rax
  4116c8:	test   rdi,rdi
  4116cb:	je     4116f9 <__swc_fn_7dafa2b1_000161_b5a9d657+0x59>
  4116cd:	nop    DWORD PTR [rax]
  4116d0:	cmp    QWORD PTR [rdi+0x8],rbx
  4116d4:	jne    4116ee <__swc_fn_7dafa2b1_000161_b5a9d657+0x4e>
  4116d6:	mov    rcx,rsi
  4116d9:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  4116de:	mov    rax,rdi
  4116e1:	add    rsp,0x188
  4116e8:	pop    r12
  4116ea:	pop    rdi
  4116eb:	pop    rsi
  4116ec:	pop    rbx
  4116ed:	ret
  4116ee:	mov    rax,QWORD PTR [rdi]
  4116f1:	mov    rdi,rax
  4116f4:	test   rax,rax
  4116f7:	jne    4116d0 <__swc_fn_7dafa2b1_000161_b5a9d657+0x30>
  4116f9:	call   40ce80 <__swc_fn_7dafa2b1_000139_7c02fe26>
  4116fe:	mov    rdi,rax
  411701:	test   rax,rax
  411704:	jne    41171d <__swc_fn_7dafa2b1_000161_b5a9d657+0x7d>
  411706:	mov    rcx,rsi
  411709:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  41170e:	xor    eax,eax
  411710:	add    rsp,0x188
  411717:	pop    r12
  411719:	pop    rdi
  41171a:	pop    rsi
  41171b:	pop    rbx
  41171c:	ret
  41171d:	lea    rax,[rsp+0x18]
  411722:	mov    QWORD PTR [rax+0x10],0x0
  41172a:	mov    QWORD PTR [rax+0x18],0x0
  411732:	mov    DWORD PTR [rax+0x20],0x0
  411739:	mov    BYTE PTR [rax+0x24],0x0
  41173d:	mov    rax,QWORD PTR [rip+0x14654]        # 425d98 <__swc_bss_base_7dafa2b1+0x2d58>
  411744:	mov    QWORD PTR [rsp+0x18],rax
  411749:	mov    QWORD PTR [rsp+0x20],rbx
  41174e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411754:	vmovups XMMWORD PTR [rdi],xmm0
  411758:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  41175e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411763:	mov    rax,QWORD PTR [rsp+0x38]
  411768:	mov    QWORD PTR [rdi+0x20],rax
  41176c:	mov    QWORD PTR [rip+0x14625],rdi        # 425d98 <__swc_bss_base_7dafa2b1+0x2d58>
  411773:	lea    rax,[rsp+0x40]
  411778:	mov    QWORD PTR [rax],0x0
  41177f:	mov    rcx,rbx
  411782:	mov    rdx,rax
  411785:	call   4099a0 <__swc_fn_7dafa2b1_000141_2ce79e3b>
  41178a:	mov    rbx,rax
  41178d:	test   rax,rax
  411790:	jne    4117aa <__swc_fn_7dafa2b1_000161_b5a9d657+0x10a>
  411792:	mov    rcx,rsi
  411795:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  41179a:	mov    rax,rdi
  41179d:	add    rsp,0x188
  4117a4:	pop    r12
  4117a6:	pop    rdi
  4117a7:	pop    rsi
  4117a8:	pop    rbx
  4117a9:	ret
  4117aa:	lea    r12,[rsp+0x50]
  4117af:	mov    QWORD PTR [r12],0x0
  4117b7:	mov    rcx,rbx
  4117ba:	mov    rdx,QWORD PTR [rsp+0x40]
  4117bf:	mov    r8,r12
  4117c2:	call   40cf30 <__swc_fn_7dafa2b1_000142_56e56812>
  4117c7:	test   rax,rax
  4117ca:	jne    4117e4 <__swc_fn_7dafa2b1_000161_b5a9d657+0x144>
  4117cc:	mov    rcx,rsi
  4117cf:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  4117d4:	mov    rax,rdi
  4117d7:	add    rsp,0x188
  4117de:	pop    r12
  4117e0:	pop    rdi
  4117e1:	pop    rsi
  4117e2:	pop    rbx
  4117e3:	ret
  4117e4:	cmp    QWORD PTR [r12],0x10
  4117e9:	jb     4118ec <__swc_fn_7dafa2b1_000161_b5a9d657+0x24c>
  4117ef:	mov    ecx,DWORD PTR [rax]
  4117f1:	cmp    ecx,0x42445753
  4117f7:	jne    4118ec <__swc_fn_7dafa2b1_000161_b5a9d657+0x24c>
  4117fd:	mov    ecx,DWORD PTR [rax+0x4]
  411800:	cmp    ecx,0x1
  411803:	jne    4118ec <__swc_fn_7dafa2b1_000161_b5a9d657+0x24c>
  411809:	mov    ecx,DWORD PTR [rax+0x8]
  41180c:	mov    edx,DWORD PTR [rax+0xc]
  41180f:	imul   r8,rcx,0x14
  411813:	mov    r9,QWORD PTR [rsp+0x50]
  411818:	sub    r9,0x10
  41181c:	cmp    r8,r9
  41181f:	ja     4118ec <__swc_fn_7dafa2b1_000161_b5a9d657+0x24c>
  411825:	lea    r8,[r8+0x10]
  411829:	cmp    rdx,r8
  41182c:	jb     4118ec <__swc_fn_7dafa2b1_000161_b5a9d657+0x24c>
  411832:	mov    r8,QWORD PTR [rsp+0x50]
  411837:	cmp    rdx,r8
  41183a:	ja     4118ec <__swc_fn_7dafa2b1_000161_b5a9d657+0x24c>
  411840:	xor    r8d,r8d
  411843:	test   rcx,rcx
  411846:	jbe    411912 <__swc_fn_7dafa2b1_000161_b5a9d657+0x272>
  41184c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411852:	cs nop WORD PTR [rax+rax*1+0x0]
  41185c:	nop    DWORD PTR [rax+0x0]
  411860:	imul   r9,r8,0x14
  411864:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411869:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  41186e:	add    r10,r11
  411871:	movabs r11,0x100000000
  41187b:	cmp    r10,r11
  41187e:	ja     4118ec <__swc_fn_7dafa2b1_000161_b5a9d657+0x24c>
  411880:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411885:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  41188a:	test   r10d,r10d
  41188d:	setne  r11b
  411891:	je     4118ab <__swc_fn_7dafa2b1_000161_b5a9d657+0x20b>
  411893:	cmp    r10d,edx
  411896:	setb   r11b
  41189a:	jb     4118ab <__swc_fn_7dafa2b1_000161_b5a9d657+0x20b>
  41189c:	vmovq  r11,xmm1
  4118a1:	cmp    r10,r11
  4118a4:	setae  r10b
  4118a8:	mov    r11b,r10b
  4118ab:	mov    r10,r11
  4118ae:	test   r11b,r11b
  4118b1:	jne    4118d8 <__swc_fn_7dafa2b1_000161_b5a9d657+0x238>
  4118b3:	test   r9d,r9d
  4118b6:	setne  r10b
  4118ba:	je     4118d8 <__swc_fn_7dafa2b1_000161_b5a9d657+0x238>
  4118bc:	cmp    r9d,edx
  4118bf:	setb   r10b
  4118c3:	jb     4118d8 <__swc_fn_7dafa2b1_000161_b5a9d657+0x238>
  4118c5:	vmovq  r10,xmm1
  4118ca:	cmp    r9,r10
  4118cd:	setae  r9b
  4118d1:	movzx  r9d,r9b
  4118d5:	mov    r10b,r9b
  4118d8:	test   r10b,r10b
  4118db:	jne    4118ec <__swc_fn_7dafa2b1_000161_b5a9d657+0x24c>
  4118dd:	add    r8,0x1
  4118e1:	cmp    r8,rcx
  4118e4:	jb     411860 <__swc_fn_7dafa2b1_000161_b5a9d657+0x1c0>
  4118ea:	jmp    411912 <__swc_fn_7dafa2b1_000161_b5a9d657+0x272>
  4118ec:	xor    ecx,ecx
  4118ee:	cmp    rax,rbx
  4118f1:	cmovne rcx,rax
  4118f5:	call   410370 <__swc_fn_7dafa2b1_000143_81c0d993>
  4118fa:	mov    rcx,rsi
  4118fd:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  411902:	mov    rax,rdi
  411905:	add    rsp,0x188
  41190c:	pop    r12
  41190e:	pop    rdi
  41190f:	pop    rsi
  411910:	pop    rbx
  411911:	ret
  411912:	mov    QWORD PTR [rdi+0x10],rax
  411916:	mov    rcx,QWORD PTR [rsp+0x50]
  41191b:	mov    QWORD PTR [rdi+0x18],rcx
  41191f:	mov    eax,DWORD PTR [rax+0x8]
  411922:	mov    DWORD PTR [rdi+0x20],eax
  411925:	rex mov BYTE PTR [rdi+0x24],0x1
  41192a:	mov    rcx,rsi
  41192d:	call   40ce70 <__swc_fn_7dafa2b1_000136_3e875c27>
  411932:	mov    rax,rdi
  411935:	add    rsp,0x188
  41193c:	pop    r12
  41193e:	pop    rdi
  41193f:	pop    rsi
  411940:	pop    rbx
  411941:	ret
	...

0000000000411950 <__swc_fn_7dafa2b1_000164_1962e12a>:
  411950:	push   rsi
  411951:	push   rdi
  411952:	push   r12
  411954:	mov    rsi,rdx
  411957:	mov    rdi,rcx
  41195a:	mov    rcx,QWORD PTR [rip+0x143df]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  411961:	test   rcx,rcx
  411964:	jne    411976 <__swc_fn_7dafa2b1_000164_1962e12a+0x26>
  411966:	call   40a1d0 <__swc_fn_7dafa2b1_000165_cf398896>
  41196b:	lea    rcx,[rax+0x1]
  41196f:	mov    QWORD PTR [rip+0x143ca],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  411976:	dec    rcx
  411979:	call   4119a0 <__swc_fn_7dafa2b1_000167_fce60b2b>
  41197e:	mov    r12,QWORD PTR [rax+0xbe0]
  411985:	test   r12,r12
  411988:	setne  al
  41198b:	je     411996 <__swc_fn_7dafa2b1_000164_1962e12a+0x46>
  41198d:	mov    rcx,rdi
  411990:	mov    rdx,rsi
  411993:	call   r12
  411996:	pop    r12
  411998:	pop    rdi
  411999:	pop    rsi
  41199a:	ret
  41199b:	add    BYTE PTR [rax],al
  41199d:	add    BYTE PTR [rax],al
	...

00000000004119a0 <__swc_fn_7dafa2b1_000167_fce60b2b>:
  4119a0:	push   r12
  4119a2:	push   rdi
  4119a3:	push   rsi
  4119a4:	sub    rsp,0xd0
  4119ab:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4119b1:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4119b7:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4119bd:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4119c3:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4119c9:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4119cf:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  4119d8:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  4119e1:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  4119ea:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  4119f3:	mov    r12,rcx
  4119f6:	mov    edi,ecx
  4119f8:	xor    eax,eax
  4119fa:	call   407000 <pthread_getspecific@plt>
  4119ff:	test   rax,rax
  411a02:	je     411a06 <__swc_fn_7dafa2b1_000167_fce60b2b+0x66>
  411a04:	jmp    411a0e <__swc_fn_7dafa2b1_000167_fce60b2b+0x6e>
  411a06:	mov    rcx,r12
  411a09:	call   40a230 <__swc_fn_7dafa2b1_000168_92b7d63c>
  411a0e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  411a14:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  411a1a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411a20:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411a26:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  411a2c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411a32:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  411a3b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411a44:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  411a4d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411a56:	add    rsp,0xd0
  411a5d:	pop    rsi
  411a5e:	pop    rdi
  411a5f:	pop    r12
  411a61:	ret
	...

0000000000411a70 <__swc_fn_7dafa2b1_000170_fa3003e2>:
  411a70:	push   rsi
  411a71:	sub    rsp,0x30
  411a75:	lea    rsi,[rip+0x1432c]        # 425da8 <__swc_bss_base_7dafa2b1+0x2d68>
  411a7c:	mov    rax,QWORD PTR [rsi]
  411a7f:	test   rax,rax
  411a82:	je     411a8a <__swc_fn_7dafa2b1_000170_fa3003e2+0x1a>
  411a84:	add    rsp,0x30
  411a88:	pop    rsi
  411a89:	ret
  411a8a:	mov    ecx,0x3
  411a8f:	mov    edx,0x10
  411a94:	call   40f4a0 <__swc_fn_7dafa2b1_000107_4796e893>
  411a99:	test   rax,rax
  411a9c:	jne    411aad <__swc_fn_7dafa2b1_000170_fa3003e2+0x3d>
  411a9e:	mov    QWORD PTR [rsp+0x18],rax
  411aa3:	call   40c9d0 <__swc_fn_7dafa2b1_000118_7f430081>
  411aa8:	mov    rax,QWORD PTR [rsp+0x18]
  411aad:	mov    rcx,rax
  411ab0:	xchg   QWORD PTR [rsi],rcx
  411ab3:	add    rsp,0x30
  411ab7:	pop    rsi
  411ab8:	ret
  411ab9:	add    BYTE PTR [rax],al
  411abb:	add    BYTE PTR [rax],al
  411abd:	add    BYTE PTR [rax],al
	...

0000000000411ac0 <__swc_fn_7dafa2b1_000173_f69b1f05>:
  411ac0:	push   rsi
  411ac1:	push   rdi
  411ac2:	sub    rsp,0x8
  411ac6:	mov    rsi,rdx
  411ac9:	mov    rdi,rcx
  411acc:	mov    rax,QWORD PTR [rsi+0x8]
  411ad0:	test   rax,rax
  411ad3:	je     411add <__swc_fn_7dafa2b1_000173_f69b1f05+0x1d>
  411ad5:	mov    rcx,QWORD PTR [rsi]
  411ad8:	mov    QWORD PTR [rax],rcx
  411adb:	jmp    411ae4 <__swc_fn_7dafa2b1_000173_f69b1f05+0x24>
  411add:	mov    rax,QWORD PTR [rsi]
  411ae0:	mov    QWORD PTR [rdi+0x8],rax
  411ae4:	mov    rax,QWORD PTR [rsi]
  411ae7:	test   rax,rax
  411aea:	je     411af4 <__swc_fn_7dafa2b1_000173_f69b1f05+0x34>
  411aec:	mov    rcx,QWORD PTR [rsi+0x8]
  411af0:	mov    QWORD PTR [rax+0x8],rcx
  411af4:	mov    rcx,rdi
  411af7:	mov    rdx,QWORD PTR [rsi+0x10]
  411afb:	mov    r8,QWORD PTR [rsi+0x18]
  411aff:	mov    r9,0xffffffffffffffff
  411b06:	call   40d5a0 <__swc_fn_7dafa2b1_000172_97fbc432>
  411b0b:	mov    QWORD PTR [rsi+0x18],0x0
  411b13:	mov    rax,QWORD PTR [rdi+0x8]
  411b17:	test   rax,rax
  411b1a:	jne    411b2c <__swc_fn_7dafa2b1_000173_f69b1f05+0x6c>
  411b1c:	call   411a70 <__swc_fn_7dafa2b1_000170_fa3003e2>
  411b21:	xor    ecx,ecx
  411b23:	mov    QWORD PTR [rax+0x8],rcx
  411b27:	xor    ecx,ecx
  411b29:	mov    QWORD PTR [rax],rcx
  411b2c:	add    rsp,0x8
  411b30:	pop    rdi
  411b31:	pop    rsi
  411b32:	ret
	...

0000000000411b40 <__swc_fn_7dafa2b1_000176_cb8588f1>:
  411b40:	push   rsi
  411b41:	push   rdi
  411b42:	sub    rsp,0x8
  411b46:	mov    rax,QWORD PTR [rcx]
  411b49:	test   rax,rax
  411b4c:	jne    411b5a <__swc_fn_7dafa2b1_000176_cb8588f1+0x1a>
  411b4e:	mov    eax,0x1
  411b53:	add    rsp,0x8
  411b57:	pop    rdi
  411b58:	pop    rsi
  411b59:	ret
  411b5a:	mov    rsi,QWORD PTR [rcx+0x8]
  411b5e:	mov    rcx,rax
  411b61:	call   411b40 <__swc_fn_7dafa2b1_000176_cb8588f1>
  411b66:	mov    rdi,rax
  411b69:	mov    rcx,rsi
  411b6c:	call   411b40 <__swc_fn_7dafa2b1_000176_cb8588f1>
  411b71:	lea    rax,[rdi+rax*1+0x1]
  411b76:	add    rsp,0x8
  411b7a:	pop    rdi
  411b7b:	pop    rsi
  411b7c:	ret
  411b7d:	add    BYTE PTR [rax],al
	...

0000000000411b80 <__swc_fn_7dafa2b1_000179_1ca87929>:
  411b80:	push   rdi
  411b81:	push   rsi
  411b82:	sub    rsp,0xb8
  411b89:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  411b8f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  411b95:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  411b9b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  411ba1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  411ba7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  411bad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  411bb3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  411bbc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  411bc5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  411bce:	vxorps xmm0,xmm0,xmm0
  411bd2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411bd8:	mov    edi,0x1
  411bdd:	lea    rsi,[rsp+0x8]
  411be2:	xor    eax,eax
  411be4:	call   4071d0 <clock_gettime@plt>
  411be9:	vxorpd xmm0,xmm0,xmm0
  411bed:	mov    rax,QWORD PTR [rsp+0x8]
  411bf2:	vcvtsi2sd xmm0,xmm0,rax
  411bf7:	vxorpd xmm1,xmm1,xmm1
  411bfb:	mov    rax,QWORD PTR [rsp+0x10]
  411c00:	vcvtsi2sd xmm1,xmm1,rax
  411c05:	vdivsd xmm1,xmm1,QWORD PTR [rip+0xdb4]        # 4129c1 <__swc_rdata_base_7dafa2b1+0x8b1>
  411c0d:	vaddsd xmm0,xmm0,xmm1
  411c11:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  411c17:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411c1d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411c23:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  411c29:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411c2f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411c35:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  411c3b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  411c44:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  411c4d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  411c56:	add    rsp,0xb8
  411c5d:	pop    rsi
  411c5e:	pop    rdi
  411c5f:	ret
