
/workspace/prompt2-20261115/batch7-placement-micro/base/csvagg/csvagg:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <open@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <open@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <flock@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <flock@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <__errno_location@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <__errno_location@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <close@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <close@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <getpid@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <getpid@GLIBC_2.2.5>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <opendir@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <opendir@GLIBC_2.2.5>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <dirfd@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <dirfd@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <readdir@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <readdir@GLIBC_2.2.5>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <readlinkat@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <readlinkat@GLIBC_2.4>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <openat@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <openat@GLIBC_2.4>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <closedir@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <closedir@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <lseek@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <lseek@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <mmap@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <mmap@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <memfd_create@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <memfd_create@GLIBC_2.27>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <ftruncate@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf8a]        # 413080 <ftruncate@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <write@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf82]        # 413088 <write@GLIBC_2.2.5>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <backtrace@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf7a]        # 413090 <backtrace@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <pthread_setspecific@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf72]        # 413098 <pthread_setspecific@GLIBC_2.34>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <clock_gettime@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf6a]        # 4130a0 <clock_gettime@GLIBC_2.17>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <__x86_get_cpuid_feature_leaf@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf62]        # 4130a8 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <free@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf5a]        # 4130b0 <free@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <munmap@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <munmap@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <mprotect@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <mprotect@GLIBC_2.2.5>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <exit@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <exit@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <pthread_key_create@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <pthread_key_create@GLIBC_2.34>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <syscall@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <syscall@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <dladdr@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <dladdr@GLIBC_2.34>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <malloc@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <malloc@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <madvise@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <madvise@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <pthread_key_delete@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <pthread_key_delete@GLIBC_2.34>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <gettid@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <gettid@GLIBC_2.30>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_e121059d_000179_68d30882+0x1600>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   410dc0 <__swc_fn_e121059d_000122_1c5e75b6>
  40724e:	xor    ecx,ecx
  407250:	call   40d5c0 <__swc_fn_e121059d_000094_383a814c>
  407255:	call   411a00 <__swc_fn_e121059d_000179_68d30882>
  40725a:	call   410410 <__swc_fn_e121059d_000095_8cc4b392>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_e121059d_000000_0e26756e>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_e121059d_000003_81215399>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_e121059d_000003_81215399+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   40d9e0 <__swc_fn_e121059d_000112_f9e19033>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_e121059d_000003_81215399+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_e121059d+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_e121059d+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_e121059d_000003_81215399+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_e121059d_000003_81215399+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_e121059d+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_e121059d+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_e121059d_000003_81215399+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_e121059d_000003_81215399+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_e121059d_000006_7b253ae1>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40ecc0 <__swc_fn_e121059d_000011_71c91685>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_e121059d_000012_be38a1a2>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_e121059d_000006_7b253ae1+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_e121059d_000003_81215399>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_e121059d_000006_7b253ae1+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_e121059d_000009_4c3ebf16>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_e121059d_000009_4c3ebf16+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40b950 <__swc_fn_e121059d_000007_a7bfb091>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40ecb0 <__swc_fn_e121059d_000008_b2f73e0d>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_e121059d_000009_4c3ebf16+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_e121059d_000009_4c3ebf16+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_e121059d_000012_be38a1a2>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_e121059d_000015_96cb1311>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_e121059d_000015_96cb1311+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_e121059d_000015_96cb1311+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_e121059d_000015_96cb1311+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_e121059d_000015_96cb1311+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40ee20 <__swc_fn_e121059d_000017_f003fc47>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_e121059d_000015_96cb1311+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_e121059d+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_e121059d+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_e121059d_000015_96cb1311+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_e121059d_000015_96cb1311+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40ecc0 <__swc_fn_e121059d_000011_71c91685>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_e121059d_000015_96cb1311+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   410ad0 <__swc_fn_e121059d_000113_2f7f9346>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_e121059d+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_e121059d+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_e121059d_000015_96cb1311+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_e121059d_000015_96cb1311+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_e121059d+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_e121059d+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_e121059d_000015_96cb1311+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_e121059d_000015_96cb1311+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_e121059d_000018_77ece227>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_e121059d_000015_96cb1311+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_e121059d_000018_77ece227>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_e121059d_000018_77ece227+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_e121059d_000018_77ece227+0x10>

0000000000407630 <__swc_fn_e121059d_000021_9cf87641>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_e121059d_000015_96cb1311>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_e121059d+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   40e040 <__swc_fn_e121059d_000136_db32cc57>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_e121059d+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_e121059d+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_e121059d_000024_e876734d>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_e121059d_000027_e876734d>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_e121059d_000030_650caec0>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_e121059d_000030_650caec0+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_e121059d>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_e121059d_000030_650caec0+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_e121059d_000030_650caec0+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_e121059d_000030_650caec0+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40efe0 <__swc_fn_e121059d_000032_f1940e30>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_e121059d_000030_650caec0+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_e121059d_000036_290a131c>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_e121059d_000030_650caec0+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_e121059d_000042_0573444d>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_e121059d_000033_d15eb4ea>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40be00 <__swc_fn_e121059d_000031_3c3e930e>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   40dec0 <__swc_fn_e121059d_000130_bc477461>
  407734:	mov    rcx,rsi
  407737:	call   40efe0 <__swc_fn_e121059d_000032_f1940e30>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_e121059d_000036_290a131c>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_e121059d_000039_9ae4348f>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_e121059d_000039_9ae4348f+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_e121059d_000039_9ae4348f+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_e121059d_000039_9ae4348f+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_e121059d_000039_9ae4348f+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_e121059d_000039_9ae4348f+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   40dac0 <__swc_fn_e121059d_000115_cc486df9>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_e121059d+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_e121059d+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_e121059d_000039_9ae4348f+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_e121059d_000039_9ae4348f+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_e121059d+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_e121059d+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_e121059d_000039_9ae4348f+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_e121059d_000039_9ae4348f+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_e121059d_000042_0573444d>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_e121059d_000042_0573444d+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40f5b0 <__swc_fn_e121059d_000059_ee6a254c>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   40e040 <__swc_fn_e121059d_000136_db32cc57>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_e121059d_000042_0573444d+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_e121059d_000042_0573444d+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_e121059d_000009_4c3ebf16>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_e121059d_000042_0573444d+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40ece0 <__swc_fn_e121059d_000014_be17798c>
  40791e:	jmp    407941 <__swc_fn_e121059d_000042_0573444d+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_e121059d_000042_0573444d+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_e121059d_000042_0573444d+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_e121059d_000042_0573444d+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40bfc0 <__swc_fn_e121059d_000043_47ff6d9b>
  407997:	mov    rcx,rdi
  40799a:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_e121059d_000039_9ae4348f>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_e121059d_000045_bb688d37>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_e121059d_000045_bb688d37+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_e121059d_000045_bb688d37+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_e121059d_000045_bb688d37+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_e121059d_000045_bb688d37+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   40e040 <__swc_fn_e121059d_000136_db32cc57>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_e121059d_000045_bb688d37+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_e121059d_000045_bb688d37+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_e121059d_000045_bb688d37+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_e121059d_000045_bb688d37+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_e121059d_000009_4c3ebf16>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_e121059d_000045_bb688d37+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_e121059d_000045_bb688d37+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_e121059d_000045_bb688d37+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_e121059d_000045_bb688d37+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_e121059d_000045_bb688d37+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40ba00 <__swc_fn_e121059d_000013_7b85dbab>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_e121059d_000045_bb688d37+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_e121059d_000045_bb688d37+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_e121059d_000045_bb688d37+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_e121059d_000045_bb688d37+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40ee60 <__swc_fn_e121059d_000020_4285d9c5>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_e121059d_000045_bb688d37+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40ba00 <__swc_fn_e121059d_000013_7b85dbab>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_e121059d_000045_bb688d37+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_e121059d_000021_9cf87641>
  407c07:	mov    rcx,r14
  407c0a:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_e121059d_000045_bb688d37+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_e121059d_000045_bb688d37+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_e121059d_000045_bb688d37+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_e121059d_000048_8e68f77b>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_e121059d_000048_8e68f77b+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_e121059d_000048_8e68f77b+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_e121059d_000048_8e68f77b+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_e121059d_000048_8e68f77b+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40f210 <__swc_fn_e121059d_000047_e7fd8d42>
  407d14:	jmp    407ce0 <__swc_fn_e121059d_000048_8e68f77b+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_e121059d_000048_8e68f77b+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_e121059d_000048_8e68f77b+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_e121059d_000048_8e68f77b+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_e121059d_000048_8e68f77b+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_e121059d_000048_8e68f77b+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_e121059d_000048_8e68f77b+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_e121059d_000048_8e68f77b+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_e121059d_000051_27d2a35f>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_e121059d_000051_27d2a35f+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_e121059d_000051_27d2a35f+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_e121059d_000051_27d2a35f+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_e121059d_000051_27d2a35f+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40f170 <__swc_fn_e121059d_000044_fe6bbfdb>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40ece0 <__swc_fn_e121059d_000014_be17798c>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_e121059d_000054_e8e85c01>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   40e040 <__swc_fn_e121059d_000136_db32cc57>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_e121059d_000054_e8e85c01+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_e121059d_000054_e8e85c01+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_e121059d_000054_e8e85c01+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_e121059d_000057_01c75a1d>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_e121059d_000060_6818d0d1>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_e121059d_000060_6818d0d1+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_e121059d_000039_9ae4348f>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_e121059d_000060_6818d0d1+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_e121059d_000063_db6d2425>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40c340 <__swc_fn_e121059d_000052_92b016ae>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_e121059d_000054_e8e85c01>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_e121059d_000063_db6d2425+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_e121059d_000063_db6d2425+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40c460 <__swc_fn_e121059d_000058_01964a17>
  407f7f:	mov    rcx,rsi
  407f82:	call   40c0a0 <__swc_fn_e121059d_000049_f6a485a2>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_e121059d_000066_918d3875>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_e121059d_000066_918d3875+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_e121059d+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_e121059d+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_e121059d_000066_918d3875+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_e121059d_000066_918d3875+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40bd30 <__swc_fn_e121059d_000022_53fc00d2>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_e121059d_000066_918d3875+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_e121059d_000063_db6d2425>
  40808f:	jmp    408122 <__swc_fn_e121059d_000066_918d3875+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_e121059d>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_e121059d_000066_918d3875+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_e121059d_000066_918d3875+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_e121059d_000066_918d3875+0x135>
  4080b8:	call   40be00 <__swc_fn_e121059d_000031_3c3e930e>
  4080bd:	mov    rcx,rax
  4080c0:	call   409ba0 <__swc_fn_e121059d_000129_8d8a7dd2>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_e121059d_000066_918d3875+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_e121059d_000066_918d3875+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_e121059d_000066_918d3875+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40f210 <__swc_fn_e121059d_000047_e7fd8d42>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_e121059d_000066_918d3875+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_e121059d_000051_27d2a35f>
  408115:	jmp    408122 <__swc_fn_e121059d_000066_918d3875+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40b970 <__swc_fn_e121059d_000010_0569f799>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_e121059d_000069_34b04ef2>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_e121059d_000036_290a131c>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_e121059d_000069_34b04ef2+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_e121059d+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_e121059d_000069_34b04ef2+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   40e040 <__swc_fn_e121059d_000136_db32cc57>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40f9e0 <__swc_fn_e121059d_000068_f501e74b>
  4081bd:	mov    rcx,rsi
  4081c0:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_e121059d_000072_bf7b5562>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40f730 <__swc_fn_e121059d_000065_0b20477c>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_e121059d_000075_41334281>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40f9e0 <__swc_fn_e121059d_000068_f501e74b>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_e121059d_000078_140918ec>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_e121059d_000078_140918ec+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_e121059d_000078_140918ec+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_e121059d_000081_f4f506c7>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_e121059d_000084_5ed30bd6>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_e121059d_000090_14cf59b2>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_e121059d_000084_5ed30bd6+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_e121059d_000084_5ed30bd6+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_e121059d_000084_5ed30bd6+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_e121059d_000084_5ed30bd6+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_e121059d_000090_14cf59b2>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_e121059d_000084_5ed30bd6+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_e121059d_000084_5ed30bd6+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_e121059d_000084_5ed30bd6+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_e121059d_000084_5ed30bd6+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_e121059d_000084_5ed30bd6+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_e121059d_000084_5ed30bd6+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_e121059d_000084_5ed30bd6+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_e121059d_000084_5ed30bd6+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_e121059d_000084_5ed30bd6+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_e121059d_000084_5ed30bd6+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40d440 <__swc_fn_e121059d_000082_ff7d1455>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_e121059d_000084_5ed30bd6+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_e121059d_000084_5ed30bd6+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_e121059d_000084_5ed30bd6+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40d440 <__swc_fn_e121059d_000082_ff7d1455>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_e121059d_000084_5ed30bd6+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_e121059d_000084_5ed30bd6>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_e121059d_000084_5ed30bd6+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_e121059d_000084_5ed30bd6+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_e121059d_000087_693f118e>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_e121059d_000090_14cf59b2>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_e121059d_000087_693f118e+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40fe40 <__swc_fn_e121059d_000086_d9243de4>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_e121059d_000087_693f118e+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_e121059d_000087_693f118e+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_e121059d_000087_693f118e+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40d440 <__swc_fn_e121059d_000082_ff7d1455>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_e121059d_000087_693f118e+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_e121059d_000087_693f118e>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_e121059d_000087_693f118e+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_e121059d_000087_693f118e+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_e121059d_000090_14cf59b2>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_e121059d_000090_14cf59b2+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_e121059d_000090_14cf59b2+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_e121059d_000090_14cf59b2+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_e121059d_000090_14cf59b2+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40d440 <__swc_fn_e121059d_000082_ff7d1455>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40d440 <__swc_fn_e121059d_000082_ff7d1455>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_e121059d_000090_14cf59b2+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_e121059d_000090_14cf59b2+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_e121059d_000090_14cf59b2+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_e121059d_000090_14cf59b2+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_e121059d_000090_14cf59b2>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_e121059d_000090_14cf59b2+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_e121059d_000090_14cf59b2+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_e121059d_000090_14cf59b2+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_e121059d_000090_14cf59b2+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_e121059d_000090_14cf59b2+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_e121059d_000090_14cf59b2+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_e121059d_000090_14cf59b2+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_e121059d_000090_14cf59b2+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_e121059d_000090_14cf59b2+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_e121059d_000090_14cf59b2+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_e121059d_000090_14cf59b2+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_e121059d_000090_14cf59b2+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_e121059d_000090_14cf59b2+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_e121059d_000090_14cf59b2+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_e121059d_000090_14cf59b2+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_e121059d_000090_14cf59b2+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   40e550 <__swc_fn_e121059d_000148_e7bfe29e>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_e121059d_000090_14cf59b2+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_e121059d_000090_14cf59b2>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_e121059d_000090_14cf59b2+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_e121059d_000090_14cf59b2+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_e121059d_000090_14cf59b2+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   40e550 <__swc_fn_e121059d_000148_e7bfe29e>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   40e550 <__swc_fn_e121059d_000148_e7bfe29e>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_e121059d_000093_0c97fc6c>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40d570 <__swc_fn_e121059d_000091_f21926ed>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_e121059d_000093_0c97fc6c+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_e121059d_000093_0c97fc6c+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   409d40 <__swc_fn_e121059d_000138_2d595cc7>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_e121059d_000093_0c97fc6c+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_e121059d+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   409870 <__swc_fn_e121059d_000117_3f5cfdef>
  408959:	call   410d00 <__swc_fn_e121059d_000119_591530fe>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_e121059d_000096_a4baaa40>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40896f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  408975:	vzeroupper
  408978:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40897e:	mov    QWORD PTR [rsp+0x48],rdx
  408983:	mov    rax,r8
  408986:	cmp    r8,0x1
  40898a:	mov    edx,0x1
  40898f:	cmovb  rax,rdx
  408993:	mov    QWORD PTR [rsp+0x50],rax
  408998:	mov    rbx,QWORD PTR [rcx+0x8]
  40899c:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a0:	mov    rcx,QWORD PTR [rcx]
  4089a3:	lea    rdx,[rsp+0x8]
  4089a8:	call   rbx
  4089aa:	add    rsp,0x70
  4089ae:	pop    rbx
  4089af:	ret

00000000004089b0 <__swc_fn_e121059d_000099_5232b57d>:
  4089b0:	push   rbx
  4089b1:	push   rsi
  4089b2:	push   rdi
  4089b3:	sub    rsp,0x30
  4089b7:	mov    rbx,rcx
  4089ba:	test   rcx,rcx
  4089bd:	je     4089d2 <__swc_fn_e121059d_000099_5232b57d+0x22>
  4089bf:	mov    rcx,rbx
  4089c2:	mov    edx,0x1
  4089c7:	call   408200 <__swc_fn_e121059d_000078_140918ec>
  4089cc:	cmp    rax,0x1
  4089d0:	je     4089da <__swc_fn_e121059d_000099_5232b57d+0x2a>
  4089d2:	add    rsp,0x30
  4089d6:	pop    rdi
  4089d7:	pop    rsi
  4089d8:	pop    rbx
  4089d9:	ret
  4089da:	lea    rsi,[rsp+0x8]
  4089df:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089e4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089ea:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  4089ef:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4089f5:	mov    rax,QWORD PTR [rsp+0x20]
  4089fa:	test   rax,rax
  4089fd:	je     408a13 <__swc_fn_e121059d_000099_5232b57d+0x63>
  4089ff:	test   DWORD PTR [rax+0x28],0x400000
  408a06:	je     408a13 <__swc_fn_e121059d_000099_5232b57d+0x63>
  408a08:	mov    rcx,QWORD PTR [rax+0x30]
  408a0c:	test   rcx,rcx
  408a0f:	cmovne rax,rcx
  408a13:	mov    edi,DWORD PTR [rax+0x20]
  408a16:	lea    rcx,[rsp+0x18]
  408a1b:	call   40d750 <__swc_fn_e121059d_000100_5714513e>
  408a20:	mov    rcx,rsi
  408a23:	mov    rdx,QWORD PTR [rsp+0x18]
  408a28:	mov    r8,rdi
  408a2b:	call   408960 <__swc_fn_e121059d_000096_a4baaa40>
  408a30:	mov    rcx,QWORD PTR [rbx+0x28]
  408a34:	call   410420 <__swc_fn_e121059d_000098_f82a1ed3>
  408a39:	mov    rcx,rsi
  408a3c:	mov    rdx,rbx
  408a3f:	mov    r8d,0x30
  408a45:	call   408960 <__swc_fn_e121059d_000096_a4baaa40>
  408a4a:	add    rsp,0x30
  408a4e:	pop    rdi
  408a4f:	pop    rsi
  408a50:	pop    rbx
  408a51:	ret
	...

0000000000408a60 <__swc_fn_e121059d_000102_14986ec5>:
  408a60:	push   rbp
  408a61:	push   rbx
  408a62:	push   rsi
  408a63:	push   rdi
  408a64:	push   r12
  408a66:	push   r13
  408a68:	push   r14
  408a6a:	push   r15
  408a6c:	sub    rsp,0x500
  408a73:	mov    rbp,rsp
  408a76:	mov    rbx,rsp
  408a79:	mov    rsi,rdx
  408a7c:	mov    rdi,rcx
  408a7f:	mov    rcx,QWORD PTR [rip+0x1e2ba]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  408a86:	test   rcx,rcx
  408a89:	jne    408aa3 <__swc_fn_e121059d_000102_14986ec5+0x43>
  408a8b:	sub    rsp,0x8
  408a8f:	call   40e940 <__swc_fn_e121059d_000166_56054fe7>
  408a94:	add    rsp,0x8
  408a98:	lea    rcx,[rax+0x1]
  408a9c:	mov    QWORD PTR [rip+0x1e29d],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  408aa3:	dec    rcx
  408aa6:	sub    rsp,0x8
  408aaa:	call   40b620 <__swc_fn_e121059d_000168_39c041ad>
  408aaf:	add    rsp,0x8
  408ab3:	mov    r12,rax
  408ab6:	mov    QWORD PTR [rsp+0x4f0],rax
  408abe:	lea    rax,[rip+0xa83b]        # 413300 <__swc_rdata_base_e121059d+0x1f0>
  408ac5:	sub    rsp,0x20
  408ac9:	mov    rcx,rsp
  408acc:	mov    QWORD PTR [rcx],rax
  408acf:	lea    r13,[rip+0xa83a]        # 413310 <__swc_rdata_base_e121059d+0x200>
  408ad6:	mov    QWORD PTR [rcx+0x8],r13
  408ada:	mov    QWORD PTR [rcx+0x10],rsp
  408ade:	mov    QWORD PTR [rcx+0x18],0x1
  408ae6:	lea    rcx,[rsp+0x10]
  408aeb:	sub    rsp,0x8
  408aef:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  408af4:	add    rsp,0x8
  408af8:	add    rsp,0x20
  408afc:	lea    rax,[rip+0xa855]        # 413358 <__swc_rdata_base_e121059d+0x248>
  408b03:	sub    rsp,0x20
  408b07:	mov    rcx,rsp
  408b0a:	mov    QWORD PTR [rcx],rax
  408b0d:	mov    QWORD PTR [rcx+0x8],r13
  408b11:	mov    QWORD PTR [rcx+0x10],rsp
  408b15:	mov    QWORD PTR [rcx+0x18],0x1
  408b1d:	lea    rcx,[rsp+0x10]
  408b22:	sub    rsp,0x8
  408b26:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  408b2b:	add    rsp,0x8
  408b2f:	add    rsp,0x20
  408b33:	lea    r14,[rip+0xa82e]        # 413368 <__swc_rdata_base_e121059d+0x258>
  408b3a:	sub    rsp,0x50
  408b3e:	mov    rax,rsp
  408b41:	vmovups xmm0,XMMWORD PTR [rip+0xa957]        # 4134a0 <__swc_rdata_base_e121059d+0x390>
  408b49:	vmovups XMMWORD PTR [rax],xmm0
  408b4d:	mov    QWORD PTR [rax+0x10],rsp
  408b51:	mov    QWORD PTR [rax+0x18],r13
  408b55:	mov    QWORD PTR [rax+0x20],rdi
  408b59:	lea    rdi,[rip+0xa818]        # 413378 <__swc_rdata_base_e121059d+0x268>
  408b60:	mov    QWORD PTR [rax+0x28],rdi
  408b64:	mov    QWORD PTR [rax+0x30],r14
  408b68:	mov    QWORD PTR [rax+0x38],r13
  408b6c:	lea    rcx,[rsp+0x10]
  408b71:	mov    QWORD PTR [rax+0x40],rcx
  408b75:	mov    QWORD PTR [rax+0x48],0x3
  408b7d:	lea    rcx,[rsp+0x40]
  408b82:	sub    rsp,0x8
  408b86:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  408b8b:	add    rsp,0x8
  408b8f:	add    rsp,0x50
  408b93:	lea    rax,[rip+0xa826]        # 4133c0 <__swc_rdata_base_e121059d+0x2b0>
  408b9a:	sub    rsp,0x20
  408b9e:	mov    rcx,rsp
  408ba1:	mov    QWORD PTR [rcx],rax
  408ba4:	mov    QWORD PTR [rcx+0x8],r13
  408ba8:	mov    QWORD PTR [rcx+0x10],rsp
  408bac:	mov    QWORD PTR [rcx+0x18],0x1
  408bb4:	lea    rcx,[rsp+0x10]
  408bb9:	sub    rsp,0x8
  408bbd:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  408bc2:	add    rsp,0x8
  408bc6:	add    rsp,0x20
  408bca:	mov    eax,DWORD PTR [rsi+0x20]
  408bcd:	mov    ecx,DWORD PTR [rsi+0x24]
  408bd0:	sub    rsp,0xa0
  408bd7:	mov    rdx,rsp
  408bda:	mov    QWORD PTR [rdx+0x30],rsi
  408bde:	mov    QWORD PTR [rdx+0x38],rdi
  408be2:	vmovups xmm0,XMMWORD PTR [rip+0xa84e]        # 413438 <__swc_rdata_base_e121059d+0x328>
  408bea:	vmovups XMMWORD PTR [rdx],xmm0
  408bee:	mov    QWORD PTR [rdx+0x40],rsp
  408bf2:	mov    QWORD PTR [rdx+0x48],r13
  408bf6:	mov    DWORD PTR [rdx+0x10],eax
  408bf9:	lea    rax,[rsp+0x10]
  408bfe:	mov    QWORD PTR [rdx+0x50],rax
  408c02:	lea    rax,[rip+0xa7c7]        # 4133d0 <__swc_rdata_base_e121059d+0x2c0>
  408c09:	mov    QWORD PTR [rdx+0x58],rax
  408c0d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c12:	lea    r8,[rsp+0x18]
  408c17:	mov    QWORD PTR [rdx+0x60],r8
  408c1b:	mov    QWORD PTR [rdx+0x68],r13
  408c1f:	mov    DWORD PTR [rdx+0x28],ecx
  408c22:	lea    rcx,[rdx+0x28]
  408c26:	mov    QWORD PTR [rdx+0x70],rcx
  408c2a:	mov    QWORD PTR [rdx+0x78],rax
  408c2e:	mov    QWORD PTR [rdx+0x80],r14
  408c35:	mov    QWORD PTR [rdx+0x88],r13
  408c3c:	lea    rax,[rdx+0x30]
  408c40:	mov    QWORD PTR [rdx+0x90],rax
  408c47:	mov    QWORD PTR [rdx+0x98],0x6
  408c52:	lea    rcx,[rdx+0x90]
  408c59:	sub    rsp,0x8
  408c5d:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  408c62:	add    rsp,0x8
  408c66:	add    rsp,0xa0
  408c6d:	sub    rsp,0x20
  408c71:	mov    rax,rsp
  408c74:	mov    QWORD PTR [rax],r14
  408c77:	mov    QWORD PTR [rax+0x8],r13
  408c7b:	mov    QWORD PTR [rax+0x10],rsp
  408c7f:	mov    QWORD PTR [rax+0x18],0x1
  408c87:	lea    rcx,[rsp+0x10]
  408c8c:	sub    rsp,0x8
  408c90:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  408c95:	add    rsp,0x8
  408c99:	add    rsp,0x20
  408c9d:	mov    eax,DWORD PTR [r12+0x9ac]
  408ca5:	test   eax,eax
  408ca7:	je     408ee0 <__swc_fn_e121059d_000102_14986ec5+0x480>
  408cad:	lea    rax,[rip+0xa764]        # 413418 <__swc_rdata_base_e121059d+0x308>
  408cb4:	sub    rsp,0x20
  408cb8:	mov    rcx,rsp
  408cbb:	mov    QWORD PTR [rcx],rax
  408cbe:	mov    QWORD PTR [rcx+0x8],r13
  408cc2:	mov    QWORD PTR [rcx+0x10],rsp
  408cc6:	mov    QWORD PTR [rcx+0x18],0x1
  408cce:	lea    rcx,[rsp+0x10]
  408cd3:	sub    rsp,0x8
  408cd7:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  408cdc:	add    rsp,0x8
  408ce0:	add    rsp,0x20
  408ce4:	mov    eax,DWORD PTR [r12+0x9ac]
  408cec:	dec    eax
  408cee:	mov    esi,eax
  408cf0:	test   esi,esi
  408cf2:	jl     408eb0 <__swc_fn_e121059d_000102_14986ec5+0x450>
  408cf8:	jmp    408d04 <__swc_fn_e121059d_000102_14986ec5+0x2a4>
  408cfa:	nop    WORD PTR [rax+rax*1+0x0]
  408d00:	dec    esi
  408d02:	jmp    408cf0 <__swc_fn_e121059d_000102_14986ec5+0x290>
  408d04:	lea    rax,[rip+0xa71d]        # 413428 <__swc_rdata_base_e121059d+0x318>
  408d0b:	sub    rsp,0x20
  408d0f:	mov    rcx,rsp
  408d12:	mov    QWORD PTR [rcx],rax
  408d15:	mov    QWORD PTR [rcx+0x8],r13
  408d19:	mov    QWORD PTR [rcx+0x10],rsp
  408d1d:	mov    QWORD PTR [rcx+0x18],0x1
  408d25:	lea    rcx,[rsp+0x10]
  408d2a:	sub    rsp,0x8
  408d2e:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  408d33:	add    rsp,0x8
  408d37:	add    rsp,0x20
  408d3b:	movsxd rax,esi
  408d3e:	imul   r15,rax,0x30
  408d42:	add    r15,r12
  408d45:	add    r15,0xf8
  408d4c:	sub    rsp,0x20
  408d50:	mov    rax,rsp
  408d53:	mov    QWORD PTR [rax],r15
  408d56:	mov    QWORD PTR [rax+0x8],rdi
  408d5a:	mov    QWORD PTR [rax+0x10],rsp
  408d5e:	mov    QWORD PTR [rax+0x18],0x1
  408d66:	lea    rcx,[rsp+0x10]
  408d6b:	sub    rsp,0x8
  408d6f:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  408d74:	add    rsp,0x8
  408d78:	add    rsp,0x20
  408d7c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408d84:	lea    rsi,[rip+0xa6ad]        # 413438 <__swc_rdata_base_e121059d+0x328>
  408d8b:	sub    rsp,0x20
  408d8f:	mov    rax,rsp
  408d92:	mov    QWORD PTR [rax],rsi
  408d95:	mov    QWORD PTR [rax+0x8],r13
  408d99:	mov    QWORD PTR [rax+0x10],rsp
  408d9d:	mov    QWORD PTR [rax+0x18],0x1
  408da5:	lea    rcx,[rsp+0x10]
  408daa:	sub    rsp,0x8
  408dae:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  408db3:	add    rsp,0x8
  408db7:	add    rsp,0x20
  408dbb:	sub    rsp,0x30
  408dbf:	mov    rax,rsp
  408dc2:	mov    ecx,DWORD PTR [r15+0x20]
  408dc6:	mov    QWORD PTR [rax],rcx
  408dc9:	mov    QWORD PTR [rax+0x8],rsp
  408dcd:	lea    rdi,[rip+0xa674]        # 413448 <__swc_rdata_base_e121059d+0x338>
  408dd4:	mov    QWORD PTR [rax+0x10],rdi
  408dd8:	lea    rcx,[rsp+0x8]
  408ddd:	mov    QWORD PTR [rax+0x18],rcx
  408de1:	mov    QWORD PTR [rax+0x20],0x1
  408de9:	lea    rcx,[rsp+0x18]
  408dee:	sub    rsp,0x8
  408df2:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  408df7:	add    rsp,0x8
  408dfb:	add    rsp,0x30
  408dff:	sub    rsp,0x20
  408e03:	mov    rax,rsp
  408e06:	mov    QWORD PTR [rax],rsi
  408e09:	mov    QWORD PTR [rax+0x8],r13
  408e0d:	mov    QWORD PTR [rax+0x10],rsp
  408e11:	mov    QWORD PTR [rax+0x18],0x1
  408e19:	lea    rcx,[rsp+0x10]
  408e1e:	sub    rsp,0x8
  408e22:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  408e27:	add    rsp,0x8
  408e2b:	add    rsp,0x20
  408e2f:	sub    rsp,0x30
  408e33:	mov    rax,rsp
  408e36:	mov    ecx,DWORD PTR [r15+0x24]
  408e3a:	mov    QWORD PTR [rax],rcx
  408e3d:	mov    QWORD PTR [rax+0x8],rsp
  408e41:	mov    QWORD PTR [rax+0x10],rdi
  408e45:	lea    rcx,[rsp+0x8]
  408e4a:	mov    QWORD PTR [rax+0x18],rcx
  408e4e:	mov    QWORD PTR [rax+0x20],0x1
  408e56:	lea    rcx,[rsp+0x18]
  408e5b:	sub    rsp,0x8
  408e5f:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  408e64:	add    rsp,0x8
  408e68:	add    rsp,0x30
  408e6c:	sub    rsp,0x20
  408e70:	mov    rax,rsp
  408e73:	mov    QWORD PTR [rax],r14
  408e76:	mov    QWORD PTR [rax+0x8],r13
  408e7a:	mov    QWORD PTR [rax+0x10],rsp
  408e7e:	mov    QWORD PTR [rax+0x18],0x1
  408e86:	lea    rcx,[rsp+0x10]
  408e8b:	sub    rsp,0x8
  408e8f:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  408e94:	add    rsp,0x8
  408e98:	add    rsp,0x20
  408e9c:	lea    rdi,[rip+0xa4d5]        # 413378 <__swc_rdata_base_e121059d+0x268>
  408ea3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408eab:	jmp    408d00 <__swc_fn_e121059d_000102_14986ec5+0x2a0>
  408eb0:	sub    rsp,0x20
  408eb4:	mov    rax,rsp
  408eb7:	mov    QWORD PTR [rax],r14
  408eba:	mov    QWORD PTR [rax+0x8],r13
  408ebe:	mov    QWORD PTR [rax+0x10],rsp
  408ec2:	mov    QWORD PTR [rax+0x18],0x1
  408eca:	lea    rcx,[rsp+0x10]
  408ecf:	sub    rsp,0x8
  408ed3:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  408ed8:	add    rsp,0x8
  408edc:	add    rsp,0x20
  408ee0:	lea    rax,[rbx+0x28]
  408ee4:	mov    rcx,rax
  408ee7:	mov    QWORD PTR [rbx+0x28],0x0
  408eef:	mov    QWORD PTR [rbx+0x30],0x0
  408ef7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408efc:	add    rcx,0x10
  408f00:	mov    edx,0x1f
  408f05:	cs nop WORD PTR [rax+rax*1+0x0]
  408f0f:	nop
  408f10:	vmovups XMMWORD PTR [rcx],xmm0
  408f14:	add    rcx,0x10
  408f18:	sub    rdx,0x1
  408f1c:	jne    408f10 <__swc_fn_e121059d_000102_14986ec5+0x4b0>
  408f1e:	lea    rsi,[rbx+0x228]
  408f25:	xor    ecx,ecx
  408f27:	cs nop WORD PTR [rax+rax*1+0x0]
  408f31:	cs nop WORD PTR [rax+rax*1+0x0]
  408f3b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f40:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f45:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f4a:	add    rcx,0x10
  408f4e:	cmp    rcx,0x200
  408f55:	jne    408f40 <__swc_fn_e121059d_000102_14986ec5+0x4e0>
  408f57:	mov    eax,DWORD PTR [r12+0xbc8]
  408f5f:	lea    rcx,[r12+0x9c8]
  408f67:	mov    QWORD PTR [rbx+0x428],rcx
  408f6e:	mov    QWORD PTR [rbx+0x430],rax
  408f75:	lea    rdi,[rbx+0x438]
  408f7c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408f84:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408f8c:	mov    eax,DWORD PTR [r12+0xbc8]
  408f94:	test   eax,eax
  408f96:	jne    408fe3 <__swc_fn_e121059d_000102_14986ec5+0x583>
  408f98:	lea    rax,[rbx+0x448]
  408f9f:	mov    QWORD PTR [rbx+0x448],rsi
  408fa6:	mov    QWORD PTR [rax+0x8],0x40
  408fae:	mov    ecx,0x1
  408fb3:	mov    rdx,rax
  408fb6:	sub    rsp,0x8
  408fba:	call   409980 <__swc_fn_e121059d_000120_2d9caf16>
  408fbf:	add    rsp,0x8
  408fc3:	mov    QWORD PTR [rbx+0x460],rsi
  408fca:	mov    ecx,eax
  408fcc:	mov    QWORD PTR [rbx+0x468],rcx
  408fd3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408fdb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fe3:	mov    rsi,QWORD PTR [rbx+0x438]
  408fea:	mov    rax,QWORD PTR [rbx+0x440]
  408ff1:	mov    r15,rax
  408ff4:	xor    r12d,r12d
  408ff7:	test   r15,r15
  408ffa:	je     4090b0 <__swc_fn_e121059d_000102_14986ec5+0x650>
  409000:	mov    rax,QWORD PTR [rsi+r12*8]
  409004:	test   rax,rax
  409007:	je     409026 <__swc_fn_e121059d_000102_14986ec5+0x5c6>
  409009:	lea    rcx,[rbx+0x4b8]
  409010:	mov    rdx,rax
  409013:	sub    rsp,0x8
  409017:	call   40e6b0 <__swc_fn_e121059d_000163_61e293bf>
  40901c:	add    rsp,0x8
  409020:	mov    al,BYTE PTR [rax]
  409022:	test   al,al
  409024:	jne    409032 <__swc_fn_e121059d_000102_14986ec5+0x5d2>
  409026:	add    r12,0x1
  40902a:	sub    r15,0x1
  40902e:	jne    409000 <__swc_fn_e121059d_000102_14986ec5+0x5a0>
  409030:	jmp    4090b0 <__swc_fn_e121059d_000102_14986ec5+0x650>
  409032:	lea    rax,[rip+0xa457]        # 413490 <__swc_rdata_base_e121059d+0x380>
  409039:	sub    rsp,0x20
  40903d:	mov    rcx,rsp
  409040:	mov    QWORD PTR [rcx],rax
  409043:	mov    QWORD PTR [rcx+0x8],r13
  409047:	mov    QWORD PTR [rcx+0x10],rsp
  40904b:	mov    QWORD PTR [rcx+0x18],0x1
  409053:	lea    rcx,[rsp+0x10]
  409058:	sub    rsp,0x8
  40905c:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  409061:	add    rsp,0x8
  409065:	add    rsp,0x20
  409069:	mov    rcx,rdi
  40906c:	xor    edx,edx
  40906e:	mov    al,0x1
  409070:	mov    r8,rax
  409073:	sub    rsp,0x8
  409077:	call   4115a0 <__swc_fn_e121059d_000164_3a7aae74>
  40907c:	add    rsp,0x8
  409080:	sub    rsp,0x20
  409084:	mov    rax,rsp
  409087:	mov    QWORD PTR [rax],r14
  40908a:	mov    QWORD PTR [rax+0x8],r13
  40908e:	mov    QWORD PTR [rax+0x10],rsp
  409092:	mov    QWORD PTR [rax+0x18],0x1
  40909a:	lea    rcx,[rsp+0x10]
  40909f:	sub    rsp,0x8
  4090a3:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  4090a8:	add    rsp,0x8
  4090ac:	add    rsp,0x20
  4090b0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090b8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090c4:	add    rsp,0x500
  4090cb:	pop    r15
  4090cd:	pop    r14
  4090cf:	pop    r13
  4090d1:	pop    r12
  4090d3:	pop    rdi
  4090d4:	pop    rsi
  4090d5:	pop    rbx
  4090d6:	pop    rbp
  4090d7:	ret
	...

00000000004090e0 <__swc_fn_e121059d_000105_7e71bba2>:
  4090e0:	test   r8,r8
  4090e3:	jne    4090e6 <__swc_fn_e121059d_000105_7e71bba2+0x6>
  4090e5:	ret
  4090e6:	xor    eax,eax
  4090e8:	movzx  r9d,dl
  4090ec:	movabs r10,0x101010101010101
  4090f6:	imul   r9,r10
  4090fa:	vmovq  xmm0,r9
  4090ff:	vpshufd xmm0,xmm0,0x44
  409104:	cs nop WORD PTR [rax+rax*1+0x0]
  40910e:	xchg   ax,ax
  409110:	mov    r10,r8
  409113:	sub    r10,rax
  409116:	cmp    r10,0x40
  40911a:	jb     40913d <__swc_fn_e121059d_000105_7e71bba2+0x5d>
  40911c:	lea    r10,[rcx+rax*1]
  409120:	vmovups XMMWORD PTR [r10],xmm0
  409125:	vmovups XMMWORD PTR [r10+0x10],xmm0
  40912b:	vmovups XMMWORD PTR [r10+0x20],xmm0
  409131:	vmovups XMMWORD PTR [r10+0x30],xmm0
  409137:	lea    rax,[rax+0x40]
  40913b:	jmp    409110 <__swc_fn_e121059d_000105_7e71bba2+0x30>
  40913d:	nop    DWORD PTR [rax]
  409140:	mov    r10,r8
  409143:	sub    r10,rax
  409146:	cmp    r10,0x10
  40914a:	jb     40915b <__swc_fn_e121059d_000105_7e71bba2+0x7b>
  40914c:	lea    r10,[rcx+rax*1]
  409150:	vmovups XMMWORD PTR [r10],xmm0
  409155:	lea    rax,[rax+0x10]
  409159:	jmp    409140 <__swc_fn_e121059d_000105_7e71bba2+0x60>
  40915b:	nop    DWORD PTR [rax+rax*1+0x0]
  409160:	mov    r10,r8
  409163:	sub    r10,rax
  409166:	cmp    r10,0x8
  40916a:	jb     409179 <__swc_fn_e121059d_000105_7e71bba2+0x99>
  40916c:	lea    r10,[rcx+rax*1]
  409170:	mov    QWORD PTR [r10],r9
  409173:	lea    rax,[rax+0x8]
  409177:	jmp    409160 <__swc_fn_e121059d_000105_7e71bba2+0x80>
  409179:	cmp    rax,r8
  40917c:	jae    40918b <__swc_fn_e121059d_000105_7e71bba2+0xab>
  40917e:	xchg   ax,ax
  409180:	mov    BYTE PTR [rcx+rax*1],dl
  409183:	inc    rax
  409186:	cmp    rax,r8
  409189:	jb     409180 <__swc_fn_e121059d_000105_7e71bba2+0xa0>
  40918b:	ret
  40918c:	add    BYTE PTR [rax],al
	...

0000000000409190 <__swc_fn_e121059d_000108_c8d4a68e>:
  409190:	push   rbx
  409191:	push   r12
  409193:	push   rdi
  409194:	push   rsi
  409195:	push   r13
  409197:	push   r14
  409199:	push   r15
  40919b:	sub    rsp,0x170
  4091a2:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  4091ab:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  4091b4:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  4091bd:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  4091c6:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  4091cf:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  4091d8:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  4091e1:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  4091ea:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  4091f3:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  4091fc:	mov    ebx,edx
  4091fe:	mov    QWORD PTR [rsp+0xa8],rbx
  409206:	mov    r12d,ecx
  409209:	test   edx,edx
  40920b:	jne    409222 <__swc_fn_e121059d_000108_c8d4a68e+0x92>
  40920d:	xor    eax,eax
  40920f:	add    rsp,0x170
  409216:	pop    r15
  409218:	pop    r14
  40921a:	pop    r13
  40921c:	pop    rsi
  40921d:	pop    rdi
  40921e:	pop    r12
  409220:	pop    rbx
  409221:	ret
  409222:	lea    rdi,[rip+0xa287]        # 4134b0 <__swc_rdata_base_e121059d+0x3a0>
  409229:	mov    esi,0x90000
  40922e:	xor    eax,eax
  409230:	call   407010 <open@plt>
  409235:	mov    r13,rax
  409238:	mov    QWORD PTR [rsp+0xb0],rax
  409240:	test   eax,eax
  409242:	jge    40924b <__swc_fn_e121059d_000108_c8d4a68e+0xbb>
  409244:	xor    eax,eax
  409246:	jmp    409746 <__swc_fn_e121059d_000108_c8d4a68e+0x5b6>
  40924b:	nop    DWORD PTR [rax+rax*1+0x0]
  409250:	movsxd rdi,r13d
  409253:	mov    esi,0x2
  409258:	xor    eax,eax
  40925a:	call   407020 <flock@plt>
  40925f:	test   eax,eax
  409261:	je     409280 <__swc_fn_e121059d_000108_c8d4a68e+0xf0>
  409263:	xor    eax,eax
  409265:	call   407030 <__errno_location@plt>
  40926a:	cmp    DWORD PTR [rax],0x4
  40926d:	je     409250 <__swc_fn_e121059d_000108_c8d4a68e+0xc0>
  40926f:	movsxd rdi,r13d
  409272:	xor    eax,eax
  409274:	call   407040 <close@plt>
  409279:	xor    eax,eax
  40927b:	jmp    409746 <__swc_fn_e121059d_000108_c8d4a68e+0x5b6>
  409280:	lea    r14,[rsp+0x8]
  409285:	mov    QWORD PTR [rsp+0xb8],r14
  40928d:	vxorps xmm0,xmm0,xmm0
  409291:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409297:	mov    QWORD PTR [rsp+0x18],0x0
  4092a0:	mov    WORD PTR [rsp+0x20],0x0
  4092a7:	mov    DWORD PTR [r14],0x67617753
  4092ae:	mov    DWORD PTR [r14+0x4],0x2e74522e
  4092b6:	xor    eax,eax
  4092b8:	call   407050 <getpid@plt>
  4092bd:	mov    ecx,eax
  4092bf:	mov    eax,0x1c
  4092c4:	shrx   eax,ecx,eax
  4092c9:	and    eax,0xf
  4092cc:	mov    rdx,QWORD PTR [rip+0xa1fd]        # 4134d0 <__swc_rdata_base_e121059d+0x3c0>
  4092d3:	mov    al,BYTE PTR [rdx+rax*1]
  4092d6:	rex mov BYTE PTR [rsp+0x10],al
  4092db:	mov    eax,0x1c
  4092e0:	shrx   eax,r12d,eax
  4092e5:	and    eax,0xf
  4092e8:	mov    al,BYTE PTR [rdx+rax*1]
  4092eb:	rex mov BYTE PTR [rsp+0x19],al
  4092f0:	mov    eax,0x18
  4092f5:	shrx   eax,ecx,eax
  4092fa:	and    eax,0xf
  4092fd:	mov    al,BYTE PTR [rdx+rax*1]
  409300:	rex mov BYTE PTR [rsp+0x11],al
  409305:	mov    eax,0x18
  40930a:	shrx   eax,r12d,eax
  40930f:	and    eax,0xf
  409312:	mov    al,BYTE PTR [rdx+rax*1]
  409315:	rex mov BYTE PTR [rsp+0x1a],al
  40931a:	mov    eax,0x14
  40931f:	shrx   eax,ecx,eax
  409324:	and    eax,0xf
  409327:	mov    al,BYTE PTR [rdx+rax*1]
  40932a:	rex mov BYTE PTR [rsp+0x12],al
  40932f:	mov    eax,0x14
  409334:	shrx   eax,r12d,eax
  409339:	and    eax,0xf
  40933c:	mov    al,BYTE PTR [rdx+rax*1]
  40933f:	rex mov BYTE PTR [rsp+0x1b],al
  409344:	mov    eax,0x10
  409349:	shrx   eax,ecx,eax
  40934e:	and    eax,0xf
  409351:	mov    al,BYTE PTR [rdx+rax*1]
  409354:	rex mov BYTE PTR [rsp+0x13],al
  409359:	mov    eax,0x10
  40935e:	shrx   eax,r12d,eax
  409363:	and    eax,0xf
  409366:	mov    al,BYTE PTR [rdx+rax*1]
  409369:	rex mov BYTE PTR [rsp+0x1c],al
  40936e:	mov    eax,0xc
  409373:	shrx   eax,ecx,eax
  409378:	and    eax,0xf
  40937b:	mov    al,BYTE PTR [rdx+rax*1]
  40937e:	rex mov BYTE PTR [rsp+0x14],al
  409383:	mov    eax,0xc
  409388:	shrx   eax,r12d,eax
  40938d:	and    eax,0xf
  409390:	mov    al,BYTE PTR [rdx+rax*1]
  409393:	rex mov BYTE PTR [rsp+0x1d],al
  409398:	mov    eax,0x8
  40939d:	shrx   eax,ecx,eax
  4093a2:	and    eax,0xf
  4093a5:	mov    al,BYTE PTR [rdx+rax*1]
  4093a8:	rex mov BYTE PTR [rsp+0x15],al
  4093ad:	mov    eax,0x8
  4093b2:	shrx   eax,r12d,eax
  4093b7:	and    eax,0xf
  4093ba:	mov    al,BYTE PTR [rdx+rax*1]
  4093bd:	rex mov BYTE PTR [rsp+0x1e],al
  4093c2:	mov    eax,0x4
  4093c7:	shrx   eax,ecx,eax
  4093cc:	and    eax,0xf
  4093cf:	mov    al,BYTE PTR [rdx+rax*1]
  4093d2:	rex mov BYTE PTR [rsp+0x16],al
  4093d7:	mov    eax,0x4
  4093dc:	shrx   eax,r12d,eax
  4093e1:	and    eax,0xf
  4093e4:	mov    al,BYTE PTR [rdx+rax*1]
  4093e7:	rex mov BYTE PTR [rsp+0x1f],al
  4093ec:	xor    eax,eax
  4093ee:	shrx   eax,ecx,eax
  4093f3:	and    eax,0xf
  4093f6:	mov    al,BYTE PTR [rdx+rax*1]
  4093f9:	rex mov BYTE PTR [rsp+0x17],al
  4093fe:	xor    eax,eax
  409400:	shrx   eax,r12d,eax
  409405:	and    eax,0xf
  409408:	mov    al,BYTE PTR [rdx+rax*1]
  40940b:	rex mov BYTE PTR [rsp+0x20],al
  409410:	mov    BYTE PTR [r14+0x10],0x2e
  409415:	lea    r12,[rsp+0x22]
  40941a:	vxorps xmm0,xmm0,xmm0
  40941e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  409424:	mov    DWORD PTR [r12],0x6d656d2f
  40942c:	mov    WORD PTR [r12+0x4],0x6466
  409434:	mov    BYTE PTR [r12+0x6],0x3a
  40943a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409440:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  409446:	mov    rax,QWORD PTR [rsp+0x18]
  40944b:	mov    QWORD PTR [rsp+0x39],rax
  409450:	rex mov al,BYTE PTR [rsp+0x20]
  409455:	rex mov BYTE PTR [rsp+0x41],al
  40945a:	mov    DWORD PTR [r12+0x20],0x65642820
  409463:	mov    DWORD PTR [r12+0x24],0x6574656c
  40946c:	mov    WORD PTR [r12+0x28],0x2964
  409474:	lea    rdi,[rip+0xa040]        # 4134bb <__swc_rdata_base_e121059d+0x3ab>
  40947b:	xor    eax,eax
  40947d:	call   407060 <opendir@plt>
  409482:	mov    r15,rax
  409485:	test   rax,rax
  409488:	jne    40949b <__swc_fn_e121059d_000108_c8d4a68e+0x30b>
  40948a:	movsxd rdi,r13d
  40948d:	xor    eax,eax
  40948f:	call   407040 <close@plt>
  409494:	xor    eax,eax
  409496:	jmp    409746 <__swc_fn_e121059d_000108_c8d4a68e+0x5b6>
  40949b:	mov    rdi,r15
  40949e:	xor    eax,eax
  4094a0:	call   407070 <dirfd@plt>
  4094a5:	lea    r14,[rsp+0x54]
  4094aa:	mov    DWORD PTR [rsp+0x54],eax
  4094ae:	lea    rbx,[rsp+0x58]
  4094b3:	cs nop WORD PTR [rax+rax*1+0x0]
  4094bd:	nop    DWORD PTR [rax]
  4094c0:	mov    rdi,r15
  4094c3:	xor    eax,eax
  4094c5:	call   407080 <readdir@plt>
  4094ca:	test   rax,rax
  4094cd:	jne    4094e4 <__swc_fn_e121059d_000108_c8d4a68e+0x354>
  4094cf:	mov    r12,QWORD PTR [rsp+0xa8]
  4094d7:	mov    r13,QWORD PTR [rsp+0xb0]
  4094df:	jmp    40966a <__swc_fn_e121059d_000108_c8d4a68e+0x4da>
  4094e4:	vxorps xmm0,xmm0,xmm0
  4094e8:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  4094ee:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  4094f4:	vzeroupper
  4094f7:	lea    r13,[rax+0x13]
  4094fb:	mov    rax,r14
  4094fe:	movsxd rdi,DWORD PTR [rax]
  409501:	mov    rsi,r13
  409504:	mov    rdx,rbx
  409507:	mov    ecx,0x40
  40950c:	xor    eax,eax
  40950e:	call   407090 <readlinkat@plt>
  409513:	cmp    rax,0x2a
  409517:	jne    4094c0 <__swc_fn_e121059d_000108_c8d4a68e+0x330>
  409519:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40951f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  409525:	vptest xmm0,xmm0
  40952a:	jne    40955a <__swc_fn_e121059d_000108_c8d4a68e+0x3ca>
  40952c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  409532:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  409538:	vptest xmm0,xmm0
  40953d:	jne    40955a <__swc_fn_e121059d_000108_c8d4a68e+0x3ca>
  40953f:	mov    rcx,QWORD PTR [rsp+0x42]
  409544:	cmp    QWORD PTR [rsp+0x78],rcx
  409549:	jne    40955a <__swc_fn_e121059d_000108_c8d4a68e+0x3ca>
  40954b:	mov    cx,WORD PTR [rsp+0x4a]
  409550:	cmp    WORD PTR [rsp+0x80],cx
  409558:	je     409584 <__swc_fn_e121059d_000108_c8d4a68e+0x3f4>
  40955a:	mov    rax,rbx
  40955d:	mov    rcx,r12
  409560:	movzx  edx,BYTE PTR [rax]
  409563:	movzx  r8d,BYTE PTR [rcx]
  409567:	cmp    rdx,r8
  40956a:	jne    409576 <__swc_fn_e121059d_000108_c8d4a68e+0x3e6>
  40956c:	add    rax,0x1
  409570:	add    rcx,0x1
  409574:	jmp    409560 <__swc_fn_e121059d_000108_c8d4a68e+0x3d0>
  409576:	mov    rax,rdx
  409579:	sub    rax,r8
  40957c:	test   eax,eax
  40957e:	jne    4094c0 <__swc_fn_e121059d_000108_c8d4a68e+0x330>
  409584:	movsxd rdi,DWORD PTR [r14]
  409587:	mov    rsi,r13
  40958a:	mov    edx,0x80002
  40958f:	xor    eax,eax
  409591:	call   4070a0 <openat@plt>
  409596:	lea    rbx,[rsp+0x98]
  40959e:	mov    DWORD PTR [rsp+0x98],eax
  4095a5:	test   eax,eax
  4095a7:	mov    r13,QWORD PTR [rsp+0xb0]
  4095af:	jge    4095d4 <__swc_fn_e121059d_000108_c8d4a68e+0x444>
  4095b1:	mov    rdi,r15
  4095b4:	xor    eax,eax
  4095b6:	call   4070b0 <closedir@plt>
  4095bb:	mov    r13,QWORD PTR [rsp+0xb0]
  4095c3:	movsxd rdi,r13d
  4095c6:	xor    eax,eax
  4095c8:	call   407040 <close@plt>
  4095cd:	xor    eax,eax
  4095cf:	jmp    409746 <__swc_fn_e121059d_000108_c8d4a68e+0x5b6>
  4095d4:	mov    rax,rbx
  4095d7:	movsxd rdi,DWORD PTR [rax]
  4095da:	xor    esi,esi
  4095dc:	mov    edx,0x2
  4095e1:	xor    eax,eax
  4095e3:	call   4070c0 <lseek@plt>
  4095e8:	mov    r12,QWORD PTR [rsp+0xa8]
  4095f0:	cmp    rax,r12
  4095f3:	je     40961a <__swc_fn_e121059d_000108_c8d4a68e+0x48a>
  4095f5:	movsxd rdi,DWORD PTR [rbx]
  4095f8:	xor    eax,eax
  4095fa:	call   407040 <close@plt>
  4095ff:	mov    rdi,r15
  409602:	xor    eax,eax
  409604:	call   4070b0 <closedir@plt>
  409609:	movsxd rdi,r13d
  40960c:	xor    eax,eax
  40960e:	call   407040 <close@plt>
  409613:	xor    eax,eax
  409615:	jmp    409746 <__swc_fn_e121059d_000108_c8d4a68e+0x5b6>
  40961a:	xor    edi,edi
  40961c:	mov    rsi,r12
  40961f:	mov    edx,0x3
  409624:	mov    ecx,0x1
  409629:	mov    rax,rbx
  40962c:	movsxd r8,DWORD PTR [rax]
  40962f:	xor    r9d,r9d
  409632:	xor    eax,eax
  409634:	call   4070d0 <mmap@plt>
  409639:	xor    r12d,r12d
  40963c:	cmp    rax,0xffffffffffffffff
  409640:	cmovne r12,rax
  409644:	movsxd rdi,DWORD PTR [rbx]
  409647:	xor    eax,eax
  409649:	call   407040 <close@plt>
  40964e:	mov    rdi,r15
  409651:	xor    eax,eax
  409653:	call   4070b0 <closedir@plt>
  409658:	movsxd rdi,r13d
  40965b:	xor    eax,eax
  40965d:	call   407040 <close@plt>
  409662:	mov    rax,r12
  409665:	jmp    409746 <__swc_fn_e121059d_000108_c8d4a68e+0x5b6>
  40966a:	mov    r14,QWORD PTR [rsp+0xb8]
  409672:	mov    rdi,r14
  409675:	mov    esi,0x1
  40967a:	xor    eax,eax
  40967c:	call   4070e0 <memfd_create@plt>
  409681:	lea    rbx,[rsp+0x9c]
  409689:	mov    DWORD PTR [rsp+0x9c],eax
  409690:	test   eax,eax
  409692:	jge    4096af <__swc_fn_e121059d_000108_c8d4a68e+0x51f>
  409694:	mov    rdi,r15
  409697:	xor    eax,eax
  409699:	call   4070b0 <closedir@plt>
  40969e:	movsxd rdi,r13d
  4096a1:	xor    eax,eax
  4096a3:	call   407040 <close@plt>
  4096a8:	xor    eax,eax
  4096aa:	jmp    409746 <__swc_fn_e121059d_000108_c8d4a68e+0x5b6>
  4096af:	mov    rax,rbx
  4096b2:	movsxd rdi,DWORD PTR [rax]
  4096b5:	mov    rsi,r12
  4096b8:	xor    eax,eax
  4096ba:	call   4070f0 <ftruncate@plt>
  4096bf:	test   eax,eax
  4096c1:	je     4096e5 <__swc_fn_e121059d_000108_c8d4a68e+0x555>
  4096c3:	movsxd rdi,DWORD PTR [rbx]
  4096c6:	xor    eax,eax
  4096c8:	call   407040 <close@plt>
  4096cd:	mov    rdi,r15
  4096d0:	xor    eax,eax
  4096d2:	call   4070b0 <closedir@plt>
  4096d7:	movsxd rdi,r13d
  4096da:	xor    eax,eax
  4096dc:	call   407040 <close@plt>
  4096e1:	xor    eax,eax
  4096e3:	jmp    409746 <__swc_fn_e121059d_000108_c8d4a68e+0x5b6>
  4096e5:	xor    edi,edi
  4096e7:	mov    rsi,r12
  4096ea:	mov    edx,0x3
  4096ef:	mov    ecx,0x1
  4096f4:	mov    rax,rbx
  4096f7:	movsxd r8,DWORD PTR [rax]
  4096fa:	xor    r9d,r9d
  4096fd:	xor    eax,eax
  4096ff:	call   4070d0 <mmap@plt>
  409704:	mov    r12,rax
  409707:	cmp    rax,0xffffffffffffffff
  40970b:	jne    40972f <__swc_fn_e121059d_000108_c8d4a68e+0x59f>
  40970d:	movsxd rdi,DWORD PTR [rbx]
  409710:	xor    eax,eax
  409712:	call   407040 <close@plt>
  409717:	mov    rdi,r15
  40971a:	xor    eax,eax
  40971c:	call   4070b0 <closedir@plt>
  409721:	movsxd rdi,r13d
  409724:	xor    eax,eax
  409726:	call   407040 <close@plt>
  40972b:	xor    eax,eax
  40972d:	jmp    409746 <__swc_fn_e121059d_000108_c8d4a68e+0x5b6>
  40972f:	mov    rdi,r15
  409732:	xor    eax,eax
  409734:	call   4070b0 <closedir@plt>
  409739:	movsxd rdi,r13d
  40973c:	xor    eax,eax
  40973e:	call   407040 <close@plt>
  409743:	mov    rax,r12
  409746:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40974f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  409758:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  409761:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40976a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  409773:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40977c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  409785:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40978e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  409797:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  4097a0:	add    rsp,0x170
  4097a7:	pop    r15
  4097a9:	pop    r14
  4097ab:	pop    r13
  4097ad:	pop    rsi
  4097ae:	pop    rdi
  4097af:	pop    r12
  4097b1:	pop    rbx
  4097b2:	ret
	...

00000000004097c0 <__swc_fn_e121059d_000111_918d5a21>:
  4097c0:	push   rsi
  4097c1:	push   rdi
  4097c2:	push   r12
  4097c4:	push   r13
  4097c6:	sub    rsp,0x8
  4097ca:	mov    rsi,r8
  4097cd:	mov    rdi,rcx
  4097d0:	mov    r12,rdx
  4097d3:	call   40d8a0 <__swc_fn_e121059d_000109_b8f4bd15>
  4097d8:	mov    r13,rax
  4097db:	test   rax,rax
  4097de:	jne    4097eb <__swc_fn_e121059d_000111_918d5a21+0x2b>
  4097e0:	add    rsp,0x8
  4097e4:	pop    r13
  4097e6:	pop    r12
  4097e8:	pop    rdi
  4097e9:	pop    rsi
  4097ea:	ret
  4097eb:	mov    rcx,r13
  4097ee:	call   4110b0 <__swc_fn_e121059d_000134_807fd51d>
  4097f3:	mov    rax,QWORD PTR [r13+0x8]
  4097f7:	test   rax,rax
  4097fa:	je     409839 <__swc_fn_e121059d_000111_918d5a21+0x79>
  4097fc:	nop    DWORD PTR [rax+0x0]
  409800:	lea    rcx,[rax+0x1000]
  409807:	cmp    rdi,rcx
  40980a:	jne    409831 <__swc_fn_e121059d_000111_918d5a21+0x71>
  40980c:	cmp    r12,0x1000
  409813:	jb     409831 <__swc_fn_e121059d_000111_918d5a21+0x71>
  409815:	test   sil,sil
  409818:	setne  cl
  40981b:	mov    BYTE PTR [rax+0x10],cl
  40981e:	mov    rcx,r13
  409821:	call   409d20 <__swc_fn_e121059d_000135_10472836>
  409826:	add    rsp,0x8
  40982a:	pop    r13
  40982c:	pop    r12
  40982e:	pop    rdi
  40982f:	pop    rsi
  409830:	ret
  409831:	mov    rax,QWORD PTR [rax]
  409834:	test   rax,rax
  409837:	jne    409800 <__swc_fn_e121059d_000111_918d5a21+0x40>
  409839:	mov    rcx,r13
  40983c:	call   409d20 <__swc_fn_e121059d_000135_10472836>
  409841:	add    rsp,0x8
  409845:	pop    r13
  409847:	pop    r12
  409849:	pop    rdi
  40984a:	pop    rsi
  40984b:	ret
  40984c:	add    BYTE PTR [rax],al
	...

0000000000409850 <__swc_fn_e121059d_000114_4e83a03a>:
  409850:	sub    rsp,0x8
  409854:	test   rcx,rcx
  409857:	jne    40985e <__swc_fn_e121059d_000114_4e83a03a+0xe>
  409859:	add    rsp,0x8
  40985d:	ret
  40985e:	call   410bb0 <__swc_fn_e121059d_000116_3f6af4b1>
  409863:	add    rsp,0x8
  409867:	ret
	...

0000000000409870 <__swc_fn_e121059d_000117_3f5cfdef>:
  409870:	push   r12
  409872:	push   r13
  409874:	push   r14
  409876:	push   rdi
  409877:	push   rsi
  409878:	sub    rsp,0xc0
  40987f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409885:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40988b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409891:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409897:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40989d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4098a3:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4098a9:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4098b2:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4098bb:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4098c4:	mov    r12,QWORD PTR [rcx]
  4098c7:	test   r12,r12
  4098ca:	jne    4098dc <__swc_fn_e121059d_000117_3f5cfdef+0x6c>
  4098cc:	add    rsp,0xc0
  4098d3:	pop    rsi
  4098d4:	pop    rdi
  4098d5:	pop    r14
  4098d7:	pop    r13
  4098d9:	pop    r12
  4098db:	ret
  4098dc:	xor    r13d,r13d
  4098df:	mov    r14,QWORD PTR [rcx+0x8]
  4098e3:	cs nop WORD PTR [rax+rax*1+0x0]
  4098ed:	nop    DWORD PTR [rax]
  4098f0:	cmp    r13,r14
  4098f3:	jae    40992b <__swc_fn_e121059d_000117_3f5cfdef+0xbb>
  4098f5:	lea    rax,[r12+r13*1]
  4098f9:	mov    rcx,r14
  4098fc:	sub    rcx,r13
  4098ff:	mov    edi,0x1
  409904:	mov    rsi,rax
  409907:	mov    rdx,rcx
  40990a:	xor    eax,eax
  40990c:	call   407100 <write@plt>
  409911:	test   rax,rax
  409914:	jle    40991b <__swc_fn_e121059d_000117_3f5cfdef+0xab>
  409916:	add    r13,rax
  409919:	jmp    4098f0 <__swc_fn_e121059d_000117_3f5cfdef+0x80>
  40991b:	je     409929 <__swc_fn_e121059d_000117_3f5cfdef+0xb9>
  40991d:	xor    eax,eax
  40991f:	call   407030 <__errno_location@plt>
  409924:	cmp    DWORD PTR [rax],0x4
  409927:	je     4098f0 <__swc_fn_e121059d_000117_3f5cfdef+0x80>
  409929:	jmp    40992b <__swc_fn_e121059d_000117_3f5cfdef+0xbb>
  40992b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409931:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409937:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40993d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409943:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409949:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40994f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409955:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40995e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409967:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409970:	add    rsp,0xc0
  409977:	pop    rsi
  409978:	pop    rdi
  409979:	pop    r14
  40997b:	pop    r13
  40997d:	pop    r12
  40997f:	ret

0000000000409980 <__swc_fn_e121059d_000120_2d9caf16>:
  409980:	push   rbx
  409981:	push   r12
  409983:	push   rdi
  409984:	push   rsi
  409985:	sub    rsp,0x4a8
  40998c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  409995:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  40999e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  4099a7:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  4099b0:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  4099b9:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  4099c2:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  4099cb:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  4099d4:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  4099dd:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  4099e6:	mov    rbx,rdx
  4099e9:	mov    r12d,ecx
  4099ec:	vxorps xmm0,xmm0,xmm0
  4099f0:	xor    eax,eax
  4099f2:	cs nop WORD PTR [rax+rax*1+0x0]
  4099fc:	nop    DWORD PTR [rax+0x0]
  409a00:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  409a06:	add    rax,0x10
  409a0a:	cmp    rax,0x400
  409a11:	jne    409a00 <__swc_fn_e121059d_000120_2d9caf16+0x80>
  409a13:	lea    rdi,[rsp+0x8]
  409a18:	mov    esi,0x80
  409a1d:	xor    eax,eax
  409a1f:	call   407110 <backtrace@plt>
  409a24:	test   eax,eax
  409a26:	jle    409a35 <__swc_fn_e121059d_000120_2d9caf16+0xb5>
  409a28:	movsxd rax,eax
  409a2b:	lea    rcx,[r12+0x1]
  409a30:	cmp    rcx,rax
  409a33:	jb     409a39 <__swc_fn_e121059d_000120_2d9caf16+0xb9>
  409a35:	xor    eax,eax
  409a37:	jmp    409a6a <__swc_fn_e121059d_000120_2d9caf16+0xea>
  409a39:	mov    rcx,QWORD PTR [rbx+0x8]
  409a3d:	sub    rax,r12
  409a40:	lea    rsi,[rax-0x1]
  409a44:	cmp    rcx,rsi
  409a47:	cmovbe rsi,rcx
  409a4b:	lea    eax,[r12+0x1]
  409a50:	lea    rax,[rsp+rax*8+0x8]
  409a55:	mov    rcx,QWORD PTR [rbx]
  409a58:	mov    rdx,rax
  409a5b:	lea    r8,[rsi*8+0x0]
  409a63:	call   40d880 <__swc_fn_e121059d_000106_83487ba1>
  409a68:	mov    eax,esi
  409a6a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  409a73:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  409a7c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  409a85:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  409a8e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  409a97:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  409aa0:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  409aa9:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  409ab2:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  409abb:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  409ac4:	add    rsp,0x4a8
  409acb:	pop    rsi
  409acc:	pop    rdi
  409acd:	pop    r12
  409acf:	pop    rbx
  409ad0:	ret
	...

0000000000409ae0 <__swc_fn_e121059d_000123_66e5d2a9>:
  409ae0:	mov    QWORD PTR [rcx],0x0
  409ae7:	ret
	...

0000000000409af0 <__swc_fn_e121059d_000126_7a81492f>:
  409af0:	push   rdi
  409af1:	push   rsi
  409af2:	sub    rsp,0xa8
  409af9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409aff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409b05:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409b0b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409b11:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409b17:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409b1d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409b23:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409b29:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409b32:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409b3b:	mov    edi,ecx
  409b3d:	mov    rsi,rdx
  409b40:	xor    eax,eax
  409b42:	call   407120 <pthread_setspecific@plt>
  409b47:	test   eax,eax
  409b49:	sete   al
  409b4c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409b52:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409b58:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409b5e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409b64:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409b6a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409b70:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409b76:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409b7c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409b85:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409b8e:	add    rsp,0xa8
  409b95:	pop    rsi
  409b96:	pop    rdi
  409b97:	ret
	...

0000000000409ba0 <__swc_fn_e121059d_000129_8d8a7dd2>:
  409ba0:	push   rdi
  409ba1:	push   rsi
  409ba2:	sub    rsp,0xa8
  409ba9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409baf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409bb5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409bbb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409bc1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409bc7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409bcd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409bd3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409bd9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409be2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409beb:	test   rcx,rcx
  409bee:	je     409c01 <__swc_fn_e121059d_000129_8d8a7dd2+0x61>
  409bf0:	lea    rax,[rcx-0x1]
  409bf4:	mov    eax,eax
  409bf6:	mov    edi,eax
  409bf8:	xor    eax,eax
  409bfa:	call   407000 <pthread_getspecific@plt>
  409bff:	jmp    409c03 <__swc_fn_e121059d_000129_8d8a7dd2+0x63>
  409c01:	xor    eax,eax
  409c03:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409c09:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409c0f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409c15:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409c1b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409c21:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409c27:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409c2d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409c33:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409c3c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409c45:	add    rsp,0xa8
  409c4c:	pop    rsi
  409c4d:	pop    rdi
  409c4e:	ret
	...

0000000000409c50 <__swc_fn_e121059d_000132_91db8856>:
  409c50:	push   rdi
  409c51:	push   rsi
  409c52:	sub    rsp,0xb8
  409c59:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409c5f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409c65:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409c6b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409c71:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409c77:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409c7d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409c83:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409c8c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409c95:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409c9e:	vxorps xmm0,xmm0,xmm0
  409ca2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409ca8:	mov    edi,0x1
  409cad:	lea    rsi,[rsp+0x8]
  409cb2:	xor    eax,eax
  409cb4:	call   407130 <clock_gettime@plt>
  409cb9:	mov    rax,QWORD PTR [rsp+0x8]
  409cbe:	imul   rax,rax,0x3b9aca00
  409cc5:	add    rax,QWORD PTR [rsp+0x10]
  409cca:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409cd0:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409cd6:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409cdc:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409ce2:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409ce8:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409cee:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409cf4:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409cfd:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409d06:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409d0f:	add    rsp,0xb8
  409d16:	pop    rsi
  409d17:	pop    rdi
  409d18:	ret
  409d19:	add    BYTE PTR [rax],al
  409d1b:	add    BYTE PTR [rax],al
  409d1d:	add    BYTE PTR [rax],al
	...

0000000000409d20 <__swc_fn_e121059d_000135_10472836>:
  409d20:	sub    rsp,0x8
  409d24:	xor    eax,eax
  409d26:	mov    DWORD PTR [rcx],eax
  409d28:	mov    edx,0x7fffffff
  409d2d:	call   40df80 <__swc_fn_e121059d_000133_51cc49e7>
  409d32:	add    rsp,0x8
  409d36:	ret
	...

0000000000409d40 <__swc_fn_e121059d_000138_2d595cc7>:
  409d40:	push   rdi
  409d41:	push   rsi
  409d42:	sub    rsp,0xb8
  409d49:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409d4f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409d55:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409d5b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409d61:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409d67:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409d6d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409d73:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409d7c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409d85:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409d8e:	mov    edi,0x1
  409d93:	xor    eax,eax
  409d95:	call   407140 <__x86_get_cpuid_feature_leaf@plt>
  409d9a:	mov    eax,DWORD PTR [rax+0x14]
  409d9d:	and    eax,0x20
  409da0:	setne  al
  409da3:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409da9:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409daf:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409db5:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409dbb:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409dc1:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409dc7:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409dcd:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409dd6:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409ddf:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409de8:	add    rsp,0xb8
  409def:	pop    rsi
  409df0:	pop    rdi
  409df1:	ret
	...

0000000000409e00 <__swc_fn_e121059d_000141_55003b6d>:
  409e00:	push   rsi
  409e01:	push   rdi
  409e02:	push   r12
  409e04:	push   r13
  409e06:	push   r14
  409e08:	push   r15
  409e0a:	cmp    rdx,0x40
  409e0e:	jae    409e1d <__swc_fn_e121059d_000141_55003b6d+0x1d>
  409e10:	xor    eax,eax
  409e12:	pop    r15
  409e14:	pop    r14
  409e16:	pop    r13
  409e18:	pop    r12
  409e1a:	pop    rdi
  409e1b:	pop    rsi
  409e1c:	ret
  409e1d:	cmp    BYTE PTR [rcx],0x7f
  409e20:	jne    409e64 <__swc_fn_e121059d_000141_55003b6d+0x64>
  409e22:	movzx  eax,BYTE PTR [rcx+0x1]
  409e26:	cmp    eax,0x45
  409e29:	setne  al
  409e2c:	jne    409e60 <__swc_fn_e121059d_000141_55003b6d+0x60>
  409e2e:	movzx  eax,BYTE PTR [rcx+0x2]
  409e32:	cmp    eax,0x4c
  409e35:	setne  al
  409e38:	jne    409e60 <__swc_fn_e121059d_000141_55003b6d+0x60>
  409e3a:	movzx  eax,BYTE PTR [rcx+0x3]
  409e3e:	cmp    eax,0x46
  409e41:	setne  al
  409e44:	jne    409e60 <__swc_fn_e121059d_000141_55003b6d+0x60>
  409e46:	cmp    BYTE PTR [rcx+0x4],0x2
  409e4a:	setne  al
  409e4d:	jne    409e60 <__swc_fn_e121059d_000141_55003b6d+0x60>
  409e4f:	cmp    BYTE PTR [rcx+0x5],0x1
  409e53:	setne  al
  409e56:	jne    409e60 <__swc_fn_e121059d_000141_55003b6d+0x60>
  409e58:	cmp    WORD PTR [rcx+0x12],0x3e
  409e5d:	setne  al
  409e60:	test   al,al
  409e62:	je     409e71 <__swc_fn_e121059d_000141_55003b6d+0x71>
  409e64:	xor    eax,eax
  409e66:	pop    r15
  409e68:	pop    r14
  409e6a:	pop    r13
  409e6c:	pop    r12
  409e6e:	pop    rdi
  409e6f:	pop    rsi
  409e70:	ret
  409e71:	cmp    WORD PTR [rcx+0x3a],0x40
  409e76:	jne    409e91 <__swc_fn_e121059d_000141_55003b6d+0x91>
  409e78:	cmp    WORD PTR [rcx+0x3c],0x0
  409e7d:	sete   al
  409e80:	je     409e8d <__swc_fn_e121059d_000141_55003b6d+0x8d>
  409e82:	mov    ax,WORD PTR [rcx+0x3c]
  409e86:	cmp    WORD PTR [rcx+0x3e],ax
  409e8a:	setae  al
  409e8d:	test   al,al
  409e8f:	je     409e9e <__swc_fn_e121059d_000141_55003b6d+0x9e>
  409e91:	xor    eax,eax
  409e93:	pop    r15
  409e95:	pop    r14
  409e97:	pop    r13
  409e99:	pop    r12
  409e9b:	pop    rdi
  409e9c:	pop    rsi
  409e9d:	ret
  409e9e:	movzx  eax,WORD PTR [rcx+0x3c]
  409ea2:	shl    rax,0x6
  409ea6:	cmp    rax,rdx
  409ea9:	ja     409eb7 <__swc_fn_e121059d_000141_55003b6d+0xb7>
  409eab:	mov    r9,rdx
  409eae:	sub    r9,rax
  409eb1:	cmp    QWORD PTR [rcx+0x28],r9
  409eb5:	jbe    409ec4 <__swc_fn_e121059d_000141_55003b6d+0xc4>
  409eb7:	xor    eax,eax
  409eb9:	pop    r15
  409ebb:	pop    r14
  409ebd:	pop    r13
  409ebf:	pop    r12
  409ec1:	pop    rdi
  409ec2:	pop    rsi
  409ec3:	ret
  409ec4:	mov    rax,QWORD PTR [rcx+0x28]
  409ec8:	add    rax,rcx
  409ecb:	movzx  r9d,WORD PTR [rcx+0x3e]
  409ed0:	lea    r9,[r9*8+0x0]
  409ed8:	lea    r10,[rax+r9*8]
  409edc:	cmp    QWORD PTR [r10+0x20],rdx
  409ee0:	ja     409f02 <__swc_fn_e121059d_000141_55003b6d+0x102>
  409ee2:	mov    r11,rdx
  409ee5:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  409eea:	cmp    QWORD PTR [r10+0x18],r11
  409eee:	seta   r9b
  409ef2:	ja     409efd <__swc_fn_e121059d_000141_55003b6d+0xfd>
  409ef4:	cmp    QWORD PTR [r10+0x20],0x9
  409ef9:	setb   r9b
  409efd:	test   r9b,r9b
  409f00:	je     409f0f <__swc_fn_e121059d_000141_55003b6d+0x10f>
  409f02:	xor    eax,eax
  409f04:	pop    r15
  409f06:	pop    r14
  409f08:	pop    r13
  409f0a:	pop    r12
  409f0c:	pop    rdi
  409f0d:	pop    rsi
  409f0e:	ret
  409f0f:	movzx  r9d,WORD PTR [rcx+0x3c]
  409f14:	xor    r11d,r11d
  409f17:	test   r9,r9
  409f1a:	jbe    40a015 <__swc_fn_e121059d_000141_55003b6d+0x215>
  409f20:	mov    rsi,QWORD PTR [r10+0x20]
  409f24:	sub    rsi,0x9
  409f28:	cs nop WORD PTR [rax+rax*1+0x0]
  409f32:	cs nop WORD PTR [rax+rax*1+0x0]
  409f3c:	nop    DWORD PTR [rax+0x0]
  409f40:	movzx  edi,r11w
  409f44:	lea    rdi,[rdi*8+0x0]
  409f4c:	lea    r12,[rax+rdi*8]
  409f50:	rex mov edi,DWORD PTR [rax+rdi*8]
  409f54:	cmp    rdi,rsi
  409f57:	ja     40a008 <__swc_fn_e121059d_000141_55003b6d+0x208>
  409f5d:	mov    r13,QWORD PTR [r10+0x18]
  409f61:	add    r13,rdi
  409f64:	lea    rdi,[rcx+r13*1]
  409f68:	lea    r13,[rip+0x95c1]        # 413530 <__swc_rdata_base_e121059d+0x420>
  409f6f:	movabs r14,0x676264676177732e
  409f79:	cmp    QWORD PTR [rdi],r14
  409f7c:	jne    409f85 <__swc_fn_e121059d_000141_55003b6d+0x185>
  409f7e:	rex cmp BYTE PTR [rdi+0x8],0x0
  409f83:	je     409fb2 <__swc_fn_e121059d_000141_55003b6d+0x1b2>
  409f85:	cs nop WORD PTR [rax+rax*1+0x0]
  409f8f:	nop
  409f90:	movzx  r14d,BYTE PTR [rdi]
  409f94:	movzx  r15d,BYTE PTR [r13+0x0]
  409f99:	cmp    r14,r15
  409f9c:	jne    409fa8 <__swc_fn_e121059d_000141_55003b6d+0x1a8>
  409f9e:	add    rdi,0x1
  409fa2:	add    r13,0x1
  409fa6:	jmp    409f90 <__swc_fn_e121059d_000141_55003b6d+0x190>
  409fa8:	mov    rdi,r14
  409fab:	sub    rdi,r15
  409fae:	test   edi,edi
  409fb0:	jne    40a008 <__swc_fn_e121059d_000141_55003b6d+0x208>
  409fb2:	cmp    DWORD PTR [r12+0x4],0x1
  409fb8:	jne    409fe0 <__swc_fn_e121059d_000141_55003b6d+0x1e0>
  409fba:	cmp    QWORD PTR [r12+0x20],0x10
  409fc0:	setb   al
  409fc3:	jb     409fdc <__swc_fn_e121059d_000141_55003b6d+0x1dc>
  409fc5:	cmp    QWORD PTR [r12+0x20],rdx
  409fca:	seta   al
  409fcd:	ja     409fdc <__swc_fn_e121059d_000141_55003b6d+0x1dc>
  409fcf:	sub    rdx,QWORD PTR [r12+0x20]
  409fd4:	cmp    QWORD PTR [r12+0x18],rdx
  409fd9:	seta   al
  409fdc:	test   al,al
  409fde:	je     409fed <__swc_fn_e121059d_000141_55003b6d+0x1ed>
  409fe0:	xor    eax,eax
  409fe2:	pop    r15
  409fe4:	pop    r14
  409fe6:	pop    r13
  409fe8:	pop    r12
  409fea:	pop    rdi
  409feb:	pop    rsi
  409fec:	ret
  409fed:	mov    rax,QWORD PTR [r12+0x20]
  409ff2:	mov    QWORD PTR [r8],rax
  409ff5:	mov    rax,QWORD PTR [r12+0x18]
  409ffa:	add    rax,rcx
  409ffd:	pop    r15
  409fff:	pop    r14
  40a001:	pop    r13
  40a003:	pop    r12
  40a005:	pop    rdi
  40a006:	pop    rsi
  40a007:	ret
  40a008:	add    r11,0x1
  40a00c:	cmp    r11,r9
  40a00f:	jb     409f40 <__swc_fn_e121059d_000141_55003b6d+0x140>
  40a015:	xor    eax,eax
  40a017:	pop    r15
  40a019:	pop    r14
  40a01b:	pop    r13
  40a01d:	pop    r12
  40a01f:	pop    rdi
  40a020:	pop    rsi
  40a021:	ret
	...

000000000040a030 <__swc_fn_e121059d_000144_b7ad855f>:
  40a030:	push   rdi
  40a031:	push   rsi
  40a032:	sub    rsp,0xa8
  40a039:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a03f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a045:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a04b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a051:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a057:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a05d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a063:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a069:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a072:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a07b:	mov    rdi,rcx
  40a07e:	xor    eax,eax
  40a080:	call   407150 <free@plt>
  40a085:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a08b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a091:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a097:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a09d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a0a3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a0a9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a0af:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a0b5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a0be:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a0c7:	add    rsp,0xa8
  40a0ce:	pop    rsi
  40a0cf:	pop    rdi
  40a0d0:	ret
	...

000000000040a0e0 <__swc_fn_e121059d_000147_d2097256>:
  40a0e0:	push   rbx
  40a0e1:	push   rsi
  40a0e2:	push   rdi
  40a0e3:	push   r12
  40a0e5:	push   r13
  40a0e7:	push   r15
  40a0e9:	sub    rsp,0x4e8
  40a0f0:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  40a0f9:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  40a102:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  40a10b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  40a114:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  40a11d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  40a126:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  40a12f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  40a138:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  40a141:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  40a14a:	mov    rbx,QWORD PTR [rcx]
  40a14d:	mov    rcx,QWORD PTR [rcx+0x8]
  40a151:	mov    rsi,rcx
  40a154:	xor    edi,edi
  40a156:	vmovsd xmm6,QWORD PTR [rip+0x9432]        # 413590 <__swc_rdata_base_e121059d+0x480>
  40a15e:	vmovsd xmm7,QWORD PTR [rip+0x9433]        # 413599 <__swc_rdata_base_e121059d+0x489>
  40a166:	vmovsd xmm8,QWORD PTR [rip+0x9434]        # 4135a2 <__swc_rdata_base_e121059d+0x492>
  40a16e:	vmovsd xmm9,QWORD PTR [rip+0x9435]        # 4135ab <__swc_rdata_base_e121059d+0x49b>
  40a176:	vmovsd xmm10,QWORD PTR [rip+0x9436]        # 4135b4 <__swc_rdata_base_e121059d+0x4a4>
  40a17e:	vmovups xmm11,xmm6
  40a182:	vmovsd QWORD PTR [rsp+0x418],xmm7
  40a18b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  40a194:	vmovsd QWORD PTR [rsp+0x428],xmm9
  40a19d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  40a1a6:	vmovsd xmm15,QWORD PTR [rip+0x940f]        # 4135bd <__swc_rdata_base_e121059d+0x4ad>
  40a1ae:	vmovups xmm14,xmm15
  40a1b3:	vmovups xmm0,xmm9
  40a1b8:	vmovsd QWORD PTR [rsp+0x438],xmm15
  40a1c1:	vmovups xmm13,xmm8
  40a1c6:	vmovsd QWORD PTR [rsp+0x440],xmm15
  40a1cf:	test   rsi,rsi
  40a1d2:	je     40b1c3 <__swc_fn_e121059d_000147_d2097256+0x10e3>
  40a1d8:	cs nop WORD PTR [rax+rax*1+0x0]
  40a1e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a1ec:	nop    DWORD PTR [rax+0x0]
  40a1f0:	lea    rcx,[rdi+rdi*1]
  40a1f4:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  40a1f9:	vpshufd xmm3,xmm2,0xee
  40a1fe:	vmovq  rcx,xmm3
  40a203:	test   rcx,rcx
  40a206:	je     40a21c <__swc_fn_e121059d_000147_d2097256+0x13c>
  40a208:	test   DWORD PTR [rcx+0x28],0x400000
  40a20f:	je     40a21c <__swc_fn_e121059d_000147_d2097256+0x13c>
  40a211:	mov    rdx,QWORD PTR [rcx+0x30]
  40a215:	test   rdx,rdx
  40a218:	cmovne rcx,rdx
  40a21c:	test   DWORD PTR [rcx+0x28],0x1000
  40a223:	je     40a244 <__swc_fn_e121059d_000147_d2097256+0x164>
  40a225:	mov    rdx,QWORD PTR [rcx+0x40]
  40a229:	mov    rcx,rdx
  40a22c:	vmovq  r8,xmm2
  40a231:	mov    r8,QWORD PTR [r8]
  40a234:	mov    QWORD PTR [rsp+0x60],r8
  40a239:	mov    QWORD PTR [rsp+0x68],rdx
  40a23e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  40a244:	test   BYTE PTR [rcx+0x28],0x1
  40a248:	jne    40a250 <__swc_fn_e121059d_000147_d2097256+0x170>
  40a24a:	vmovups xmm12,xmm0
  40a24e:	jmp    40a26a <__swc_fn_e121059d_000147_d2097256+0x18a>
  40a250:	vmovq  rax,xmm2
  40a255:	mov    rax,QWORD PTR [rax]
  40a258:	lea    rcx,[rax+0x10]
  40a25c:	vmovups xmm12,xmm0
  40a260:	call   409870 <__swc_fn_e121059d_000117_3f5cfdef>
  40a265:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40a26a:	test   DWORD PTR [rcx+0x28],0x400
  40a271:	je     40a2d2 <__swc_fn_e121059d_000147_d2097256+0x1f2>
  40a273:	vmovq  rax,xmm2
  40a278:	mov    rax,QWORD PTR [rax]
  40a27b:	xor    ecx,ecx
  40a27d:	test   rax,rax
  40a280:	je     40a2b0 <__swc_fn_e121059d_000147_d2097256+0x1d0>
  40a282:	mov    rdx,rax
  40a285:	mov    r8b,BYTE PTR [rdx]
  40a288:	test   r8b,r8b
  40a28b:	je     40a2b0 <__swc_fn_e121059d_000147_d2097256+0x1d0>
  40a28d:	cs nop WORD PTR [rax+rax*1+0x0]
  40a297:	nop    WORD PTR [rax+rax*1+0x0]
  40a2a0:	add    rdx,0x1
  40a2a4:	add    rcx,0x1
  40a2a8:	mov    r8b,BYTE PTR [rdx]
  40a2ab:	test   r8b,r8b
  40a2ae:	jne    40a2a0 <__swc_fn_e121059d_000147_d2097256+0x1c0>
  40a2b0:	mov    QWORD PTR [rsp+0x88],rax
  40a2b8:	mov    QWORD PTR [rsp+0x90],rcx
  40a2c0:	lea    rcx,[rsp+0x88]
  40a2c8:	call   409870 <__swc_fn_e121059d_000117_3f5cfdef>
  40a2cd:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40a2d2:	cmp    BYTE PTR [rcx+0x2c],0x6
  40a2d6:	jne    40a2ed <__swc_fn_e121059d_000147_d2097256+0x20d>
  40a2d8:	vmovq  rax,xmm2
  40a2dd:	mov    rax,QWORD PTR [rax]
  40a2e0:	mov    rcx,rax
  40a2e3:	call   40e450 <__swc_fn_e121059d_000145_c3e86ca0>
  40a2e8:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40a2ed:	cmp    BYTE PTR [rcx+0x2c],0x1
  40a2f1:	jne    40b199 <__swc_fn_e121059d_000147_d2097256+0x10b9>
  40a2f7:	vmovq  rdx,xmm2
  40a2fc:	mov    cl,BYTE PTR [rcx+0x40]
  40a2ff:	cmp    cl,0x7
  40a302:	jb     40a345 <__swc_fn_e121059d_000147_d2097256+0x265>
  40a304:	je     40a3b8 <__swc_fn_e121059d_000147_d2097256+0x2d8>
  40a30a:	cmp    cl,0x8
  40a30d:	je     40a3c4 <__swc_fn_e121059d_000147_d2097256+0x2e4>
  40a313:	cmp    cl,0x9
  40a316:	je     40a3dd <__swc_fn_e121059d_000147_d2097256+0x2fd>
  40a31c:	cmp    cl,0xa
  40a31f:	je     40aaa4 <__swc_fn_e121059d_000147_d2097256+0x9c4>
  40a325:	cmp    cl,0xb
  40a328:	je     40b16b <__swc_fn_e121059d_000147_d2097256+0x108b>
  40a32e:	cmp    cl,0xc
  40a331:	je     40a3d1 <__swc_fn_e121059d_000147_d2097256+0x2f1>
  40a337:	cmp    cl,0xd
  40a33a:	je     40b161 <__swc_fn_e121059d_000147_d2097256+0x1081>
  40a340:	jmp    40b18b <__swc_fn_e121059d_000147_d2097256+0x10ab>
  40a345:	cmp    cl,0x1
  40a348:	je     40a368 <__swc_fn_e121059d_000147_d2097256+0x288>
  40a34a:	cmp    cl,0x2
  40a34d:	je     40a376 <__swc_fn_e121059d_000147_d2097256+0x296>
  40a34f:	cmp    cl,0x3
  40a352:	je     40a384 <__swc_fn_e121059d_000147_d2097256+0x2a4>
  40a354:	cmp    cl,0x4
  40a357:	je     40a391 <__swc_fn_e121059d_000147_d2097256+0x2b1>
  40a359:	cmp    cl,0x5
  40a35c:	je     40a39e <__swc_fn_e121059d_000147_d2097256+0x2be>
  40a35e:	cmp    cl,0x6
  40a361:	je     40a3ab <__swc_fn_e121059d_000147_d2097256+0x2cb>
  40a363:	jmp    40b18b <__swc_fn_e121059d_000147_d2097256+0x10ab>
  40a368:	movsx  rcx,BYTE PTR [rdx]
  40a36c:	call   4112a0 <__swc_fn_e121059d_000146_32a1d6a2>
  40a371:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40a376:	movsx  rcx,WORD PTR [rdx]
  40a37a:	call   4112a0 <__swc_fn_e121059d_000146_32a1d6a2>
  40a37f:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40a384:	movsxd rcx,DWORD PTR [rdx]
  40a387:	call   4112a0 <__swc_fn_e121059d_000146_32a1d6a2>
  40a38c:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40a391:	mov    rcx,QWORD PTR [rdx]
  40a394:	call   4112a0 <__swc_fn_e121059d_000146_32a1d6a2>
  40a399:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40a39e:	movzx  ecx,BYTE PTR [rdx]
  40a3a1:	call   40e450 <__swc_fn_e121059d_000145_c3e86ca0>
  40a3a6:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40a3ab:	movzx  ecx,WORD PTR [rdx]
  40a3ae:	call   40e450 <__swc_fn_e121059d_000145_c3e86ca0>
  40a3b3:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40a3b8:	mov    ecx,DWORD PTR [rdx]
  40a3ba:	call   40e450 <__swc_fn_e121059d_000145_c3e86ca0>
  40a3bf:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40a3c4:	mov    rcx,QWORD PTR [rdx]
  40a3c7:	call   40e450 <__swc_fn_e121059d_000145_c3e86ca0>
  40a3cc:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40a3d1:	mov    ecx,DWORD PTR [rdx]
  40a3d3:	call   40e450 <__swc_fn_e121059d_000145_c3e86ca0>
  40a3d8:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40a3dd:	lea    rcx,[rsp+0xa8]
  40a3e5:	vxorps xmm0,xmm0,xmm0
  40a3e9:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  40a3f2:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  40a3fb:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  40a404:	vzeroupper
  40a407:	mov    DWORD PTR [rsp+0x108],0x0
  40a412:	vxorpd xmm0,xmm0,xmm0
  40a416:	vmovss xmm1,DWORD PTR [rdx]
  40a41a:	vcvtss2sd xmm0,xmm0,xmm1
  40a41e:	vmovsd xmm1,xmm1,xmm0
  40a422:	vcomisd xmm0,xmm0
  40a426:	setne  dl
  40a429:	movzx  edx,dl
  40a42c:	setp   r8b
  40a430:	movzx  r8d,r8b
  40a434:	or     edx,r8d
  40a437:	test   dl,dl
  40a439:	je     40a446 <__swc_fn_e121059d_000147_d2097256+0x366>
  40a43b:	mov    DWORD PTR [rcx],0x6e616e
  40a441:	jmp    40aa38 <__swc_fn_e121059d_000147_d2097256+0x958>
  40a446:	vcomisd xmm1,xmm6
  40a44a:	ja     40a452 <__swc_fn_e121059d_000147_d2097256+0x372>
  40a44c:	vcomisd xmm7,xmm1
  40a450:	jbe    40a476 <__swc_fn_e121059d_000147_d2097256+0x396>
  40a452:	vxorpd xmm0,xmm0,xmm0
  40a456:	vcomisd xmm0,xmm1
  40a45a:	jbe    40a46b <__swc_fn_e121059d_000147_d2097256+0x38b>
  40a45c:	mov    DWORD PTR [rcx],0x666e692d
  40a462:	mov    BYTE PTR [rcx+0x4],0x0
  40a466:	jmp    40aa38 <__swc_fn_e121059d_000147_d2097256+0x958>
  40a46b:	mov    DWORD PTR [rcx],0x666e69
  40a471:	jmp    40aa38 <__swc_fn_e121059d_000147_d2097256+0x958>
  40a476:	vcomisd xmm1,xmm8
  40a47b:	jae    40a487 <__swc_fn_e121059d_000147_d2097256+0x3a7>
  40a47d:	vcomisd xmm9,xmm1
  40a481:	jbe    40a7fe <__swc_fn_e121059d_000147_d2097256+0x71e>
  40a487:	vmovups xmm0,xmm1
  40a48b:	vxorpd xmm2,xmm2,xmm2
  40a48f:	vcomisd xmm2,xmm1
  40a493:	jbe    40a4a3 <__swc_fn_e121059d_000147_d2097256+0x3c3>
  40a495:	vmovsd xmm1,xmm1,xmm0
  40a499:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x90af]        # 413550 <__swc_rdata_base_e121059d+0x440>
  40a4a1:	jmp    40a4a7 <__swc_fn_e121059d_000147_d2097256+0x3c7>
  40a4a3:	vmovsd xmm1,xmm1,xmm0
  40a4a7:	xor    r8d,r8d
  40a4aa:	vcomisd xmm1,xmm15
  40a4af:	jb     40a4d0 <__swc_fn_e121059d_000147_d2097256+0x3f0>
  40a4b1:	cs nop WORD PTR [rax+rax*1+0x0]
  40a4bb:	nop    DWORD PTR [rax+rax*1+0x0]
  40a4c0:	vdivsd xmm1,xmm1,xmm15
  40a4c5:	add    r8,0x1
  40a4c9:	vcomisd xmm1,xmm15
  40a4ce:	jae    40a4c0 <__swc_fn_e121059d_000147_d2097256+0x3e0>
  40a4d0:	mov    r9,rcx
  40a4d3:	vxorpd xmm2,xmm2,xmm2
  40a4d7:	vcomisd xmm2,xmm0
  40a4db:	jbe    40a4e4 <__swc_fn_e121059d_000147_d2097256+0x404>
  40a4dd:	mov    BYTE PTR [rcx],0x2d
  40a4e0:	lea    r9,[rcx+0x1]
  40a4e4:	vcvttsd2si rdx,xmm1
  40a4e9:	mov    r10b,dl
  40a4ec:	add    r10b,0x30
  40a4f0:	mov    BYTE PTR [r9],r10b
  40a4f3:	vxorpd xmm0,xmm0,xmm0
  40a4f7:	movzx  edx,dl
  40a4fa:	vcvtsi2sd xmm0,xmm0,rdx
  40a4ff:	vsubsd xmm0,xmm1,xmm0
  40a503:	vmulsd xmm1,xmm0,xmm15
  40a508:	mov    BYTE PTR [r9+0x1],0x2e
  40a50d:	vcvttsd2si rdx,xmm1
  40a512:	mov    r10b,dl
  40a515:	add    r10b,0x30
  40a519:	mov    BYTE PTR [r9+0x2],r10b
  40a51d:	vxorpd xmm0,xmm0,xmm0
  40a521:	movzx  edx,dl
  40a524:	vcvtsi2sd xmm0,xmm0,rdx
  40a529:	vsubsd xmm0,xmm1,xmm0
  40a52d:	vmulsd xmm1,xmm0,xmm15
  40a532:	vcvttsd2si rdx,xmm1
  40a537:	mov    r10b,dl
  40a53a:	add    r10b,0x30
  40a53e:	mov    BYTE PTR [r9+0x3],r10b
  40a542:	vxorpd xmm0,xmm0,xmm0
  40a546:	movzx  edx,dl
  40a549:	vcvtsi2sd xmm0,xmm0,rdx
  40a54e:	vsubsd xmm0,xmm1,xmm0
  40a552:	vmulsd xmm1,xmm0,xmm15
  40a557:	vcvttsd2si rdx,xmm1
  40a55c:	mov    r10b,dl
  40a55f:	add    r10b,0x30
  40a563:	mov    BYTE PTR [r9+0x4],r10b
  40a567:	vxorpd xmm0,xmm0,xmm0
  40a56b:	movzx  edx,dl
  40a56e:	vcvtsi2sd xmm0,xmm0,rdx
  40a573:	vsubsd xmm0,xmm1,xmm0
  40a577:	vmulsd xmm1,xmm0,xmm15
  40a57c:	vcvttsd2si rdx,xmm1
  40a581:	mov    r10b,dl
  40a584:	add    r10b,0x30
  40a588:	mov    BYTE PTR [r9+0x5],r10b
  40a58c:	vxorpd xmm0,xmm0,xmm0
  40a590:	movzx  edx,dl
  40a593:	vcvtsi2sd xmm0,xmm0,rdx
  40a598:	vsubsd xmm0,xmm1,xmm0
  40a59c:	vmulsd xmm1,xmm0,xmm15
  40a5a1:	vcvttsd2si rdx,xmm1
  40a5a6:	mov    r10b,dl
  40a5a9:	add    r10b,0x30
  40a5ad:	mov    BYTE PTR [r9+0x6],r10b
  40a5b1:	vxorpd xmm0,xmm0,xmm0
  40a5b5:	movzx  edx,dl
  40a5b8:	vcvtsi2sd xmm0,xmm0,rdx
  40a5bd:	vsubsd xmm0,xmm1,xmm0
  40a5c1:	vmulsd xmm1,xmm0,xmm15
  40a5c6:	vcvttsd2si rdx,xmm1
  40a5cb:	mov    r10b,dl
  40a5ce:	add    r10b,0x30
  40a5d2:	mov    BYTE PTR [r9+0x7],r10b
  40a5d6:	vxorpd xmm0,xmm0,xmm0
  40a5da:	movzx  edx,dl
  40a5dd:	vcvtsi2sd xmm0,xmm0,rdx
  40a5e2:	vsubsd xmm0,xmm1,xmm0
  40a5e6:	vmulsd xmm1,xmm0,xmm15
  40a5eb:	vcvttsd2si rdx,xmm1
  40a5f0:	mov    r10b,dl
  40a5f3:	add    r10b,0x30
  40a5f7:	mov    BYTE PTR [r9+0x8],r10b
  40a5fb:	vxorpd xmm0,xmm0,xmm0
  40a5ff:	movzx  edx,dl
  40a602:	vcvtsi2sd xmm0,xmm0,rdx
  40a607:	vsubsd xmm0,xmm1,xmm0
  40a60b:	vmulsd xmm1,xmm0,xmm15
  40a610:	vcvttsd2si rdx,xmm1
  40a615:	mov    r10b,dl
  40a618:	add    r10b,0x30
  40a61c:	mov    BYTE PTR [r9+0x9],r10b
  40a620:	vxorpd xmm0,xmm0,xmm0
  40a624:	movzx  edx,dl
  40a627:	vcvtsi2sd xmm0,xmm0,rdx
  40a62c:	vsubsd xmm0,xmm1,xmm0
  40a630:	vmulsd xmm1,xmm0,xmm15
  40a635:	vcvttsd2si rdx,xmm1
  40a63a:	mov    r10b,dl
  40a63d:	add    r10b,0x30
  40a641:	mov    BYTE PTR [r9+0xa],r10b
  40a645:	vxorpd xmm0,xmm0,xmm0
  40a649:	movzx  edx,dl
  40a64c:	vcvtsi2sd xmm0,xmm0,rdx
  40a651:	vsubsd xmm0,xmm1,xmm0
  40a655:	vmulsd xmm1,xmm0,xmm15
  40a65a:	vcvttsd2si rdx,xmm1
  40a65f:	mov    r10b,dl
  40a662:	add    r10b,0x30
  40a666:	mov    BYTE PTR [r9+0xb],r10b
  40a66a:	lea    r10,[r9+0x4]
  40a66e:	vxorpd xmm0,xmm0,xmm0
  40a672:	movzx  edx,dl
  40a675:	vcvtsi2sd xmm0,xmm0,rdx
  40a67a:	vsubsd xmm0,xmm1,xmm0
  40a67e:	vmulsd xmm1,xmm0,xmm15
  40a683:	vcvttsd2si rdx,xmm1
  40a688:	mov    r11b,dl
  40a68b:	add    r11b,0x30
  40a68f:	mov    BYTE PTR [r9+0xc],r11b
  40a693:	vxorpd xmm0,xmm0,xmm0
  40a697:	movzx  edx,dl
  40a69a:	vcvtsi2sd xmm0,xmm0,rdx
  40a69f:	vsubsd xmm0,xmm1,xmm0
  40a6a3:	vmulsd xmm1,xmm0,xmm15
  40a6a8:	vcvttsd2si rdx,xmm1
  40a6ad:	mov    r11b,dl
  40a6b0:	add    r11b,0x30
  40a6b4:	mov    BYTE PTR [r9+0xd],r11b
  40a6b8:	lea    r10,[r10+0x2]
  40a6bc:	vxorpd xmm0,xmm0,xmm0
  40a6c0:	movzx  edx,dl
  40a6c3:	vcvtsi2sd xmm0,xmm0,rdx
  40a6c8:	vsubsd xmm0,xmm1,xmm0
  40a6cc:	vmulsd xmm1,xmm0,xmm15
  40a6d1:	vcvttsd2si rdx,xmm1
  40a6d6:	mov    r11b,dl
  40a6d9:	add    r11b,0x30
  40a6dd:	mov    BYTE PTR [r9+0xe],r11b
  40a6e1:	vxorpd xmm0,xmm0,xmm0
  40a6e5:	movzx  edx,dl
  40a6e8:	vcvtsi2sd xmm0,xmm0,rdx
  40a6ed:	vsubsd xmm0,xmm1,xmm0
  40a6f1:	vmulsd xmm1,xmm0,xmm15
  40a6f6:	vcvttsd2si rdx,xmm1
  40a6fb:	mov    r11b,dl
  40a6fe:	add    r11b,0x30
  40a702:	mov    BYTE PTR [r9+0xf],r11b
  40a706:	lea    r10,[r10+0x2]
  40a70a:	lea    r10,[r10+0x2]
  40a70e:	lea    r10,[r10+0x2]
  40a712:	lea    r10,[r10+0x2]
  40a716:	lea    r10,[r10+0x2]
  40a71a:	vxorpd xmm0,xmm0,xmm0
  40a71e:	movzx  edx,dl
  40a721:	vcvtsi2sd xmm0,xmm0,rdx
  40a726:	vsubsd xmm0,xmm1,xmm0
  40a72a:	vmulsd xmm1,xmm0,xmm15
  40a72f:	vcvttsd2si rdx,xmm1
  40a734:	mov    r11b,dl
  40a737:	add    r11b,0x30
  40a73b:	mov    BYTE PTR [r9+0x10],r11b
  40a73f:	vxorpd xmm0,xmm0,xmm0
  40a743:	movzx  edx,dl
  40a746:	vcvtsi2sd xmm0,xmm0,rdx
  40a74b:	vsubsd xmm0,xmm1,xmm0
  40a74f:	vmulsd xmm1,xmm0,xmm15
  40a754:	vcvttsd2si rdx,xmm1
  40a759:	add    dl,0x30
  40a75c:	mov    BYTE PTR [r9+0x11],dl
  40a760:	mov    BYTE PTR [r10+0x2],0x65
  40a765:	lea    r9,[r10+0x3]
  40a769:	test   r8,r8
  40a76c:	jl     40a775 <__swc_fn_e121059d_000147_d2097256+0x695>
  40a76e:	mov    BYTE PTR [r9],0x2b
  40a772:	inc    r9
  40a775:	mov    r10,r9
  40a778:	mov    rdx,r8
  40a77b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a780:	mov    r11,rdx
  40a783:	movabs rdx,0x6666666666666667
  40a78d:	mov    rax,r11
  40a790:	imul   rdx
  40a793:	sar    rdx,0x2
  40a797:	mov    r12,rdx
  40a79a:	shr    rdx,0x3f
  40a79e:	add    r12,rdx
  40a7a1:	mov    rdx,r12
  40a7a4:	imul   r13,r12,0xa
  40a7a8:	sub    r11,r13
  40a7ab:	mov    r13,QWORD PTR [rip+0x8d8e]        # 413540 <__swc_rdata_base_e121059d+0x430>
  40a7b2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a7b7:	mov    BYTE PTR [r10],r11b
  40a7ba:	lea    r11,[r10+0x1]
  40a7be:	mov    r10,r11
  40a7c1:	test   r12,r12
  40a7c4:	jne    40a780 <__swc_fn_e121059d_000147_d2097256+0x6a0>
  40a7c6:	test   r8,r8
  40a7c9:	jge    40a7d3 <__swc_fn_e121059d_000147_d2097256+0x6f3>
  40a7cb:	mov    BYTE PTR [r11],0x2d
  40a7cf:	lea    r10,[r11+0x1]
  40a7d3:	mov    BYTE PTR [r10],0x0
  40a7d7:	sub    r10,0x1
  40a7db:	nop    DWORD PTR [rax+rax*1+0x0]
  40a7e0:	cmp    r9,r10
  40a7e3:	jae    40aa38 <__swc_fn_e121059d_000147_d2097256+0x958>
  40a7e9:	mov    al,BYTE PTR [r10]
  40a7ec:	mov    dl,BYTE PTR [r9]
  40a7ef:	mov    BYTE PTR [r10],dl
  40a7f2:	sub    r10,0x1
  40a7f6:	mov    BYTE PTR [r9],al
  40a7f9:	inc    r9
  40a7fc:	jmp    40a7e0 <__swc_fn_e121059d_000147_d2097256+0x700>
  40a7fe:	vcvttsd2si rdx,xmm1
  40a803:	mov    r8,rdx
  40a806:	vxorpd xmm0,xmm0,xmm0
  40a80a:	vcvtsi2sd xmm0,xmm0,rdx
  40a80f:	vsubsd xmm0,xmm1,xmm0
  40a813:	mov    r9d,0x8
  40a819:	vxorpd xmm2,xmm2,xmm2
  40a81d:	vcomisd xmm2,xmm0
  40a821:	jbe    40a82b <__swc_fn_e121059d_000147_d2097256+0x74b>
  40a823:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x8d25]        # 413550 <__swc_rdata_base_e121059d+0x440>
  40a82b:	test   r9d,r9d
  40a82e:	je     40a83a <__swc_fn_e121059d_000147_d2097256+0x75a>
  40a830:	vmulsd xmm0,xmm0,xmm14
  40a835:	dec    r9d
  40a838:	jne    40a830 <__swc_fn_e121059d_000147_d2097256+0x750>
  40a83a:	vcvttsd2si r9,xmm0
  40a83f:	mov    r10,r9
  40a842:	vxorpd xmm2,xmm2,xmm2
  40a846:	vcvtsi2sd xmm2,xmm2,r9
  40a84b:	vsubsd xmm0,xmm0,xmm2
  40a84f:	vcomisd xmm0,xmm10
  40a854:	lea    r9,[r9+0x1]
  40a858:	cmova  r10,r9
  40a85c:	cmp    r10,0x5f5e100
  40a863:	jne    40a87c <__swc_fn_e121059d_000147_d2097256+0x79c>
  40a865:	lea    r8,[rdx-0x1]
  40a869:	vxorpd xmm0,xmm0,xmm0
  40a86d:	vcomisd xmm0,xmm1
  40a871:	lea    rdx,[rdx+0x1]
  40a875:	cmovbe r8,rdx
  40a879:	xor    r10d,r10d
  40a87c:	mov    r9,rcx
  40a87f:	test   r8,r8
  40a882:	jne    40a8a2 <__swc_fn_e121059d_000147_d2097256+0x7c2>
  40a884:	vxorpd xmm0,xmm0,xmm0
  40a888:	vcomisd xmm0,xmm1
  40a88c:	jbe    40a895 <__swc_fn_e121059d_000147_d2097256+0x7b5>
  40a88e:	mov    BYTE PTR [rcx],0x2d
  40a891:	lea    r9,[rcx+0x1]
  40a895:	mov    BYTE PTR [r9],0x30
  40a899:	add    r9,0x1
  40a89d:	jmp    40a93b <__swc_fn_e121059d_000147_d2097256+0x85b>
  40a8a2:	mov    r9,rcx
  40a8a5:	mov    rdx,r8
  40a8a8:	nop    DWORD PTR [rax+rax*1+0x0]
  40a8b0:	mov    r11,rdx
  40a8b3:	movabs rdx,0x6666666666666667
  40a8bd:	mov    r15,rax
  40a8c0:	mov    rax,r11
  40a8c3:	imul   rdx
  40a8c6:	mov    r12,rdx
  40a8c9:	mov    rax,r15
  40a8cc:	sar    r12,0x2
  40a8d0:	mov    rdx,r12
  40a8d3:	shr    rdx,0x3f
  40a8d7:	add    r12,rdx
  40a8da:	mov    rdx,r12
  40a8dd:	imul   r13,r12,0xa
  40a8e1:	sub    r11,r13
  40a8e4:	mov    r13,QWORD PTR [rip+0x8c55]        # 413540 <__swc_rdata_base_e121059d+0x430>
  40a8eb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a8f0:	mov    BYTE PTR [r9],r11b
  40a8f3:	lea    r11,[r9+0x1]
  40a8f7:	mov    r9,r11
  40a8fa:	test   r12,r12
  40a8fd:	jne    40a8b0 <__swc_fn_e121059d_000147_d2097256+0x7d0>
  40a8ff:	test   r8,r8
  40a902:	jge    40a90c <__swc_fn_e121059d_000147_d2097256+0x82c>
  40a904:	mov    BYTE PTR [r11],0x2d
  40a908:	lea    r9,[r11+0x1]
  40a90c:	mov    rdx,r9
  40a90f:	mov    BYTE PTR [r9],0x0
  40a913:	sub    r9,0x1
  40a917:	mov    r8,rcx
  40a91a:	cmp    r8,r9
  40a91d:	jae    40a938 <__swc_fn_e121059d_000147_d2097256+0x858>
  40a91f:	nop
  40a920:	mov    r11b,BYTE PTR [r9]
  40a923:	mov    r12b,BYTE PTR [r8]
  40a926:	mov    BYTE PTR [r9],r12b
  40a929:	sub    r9,0x1
  40a92d:	mov    BYTE PTR [r8],r11b
  40a930:	inc    r8
  40a933:	cmp    r8,r9
  40a936:	jb     40a920 <__swc_fn_e121059d_000147_d2097256+0x840>
  40a938:	mov    r9,rdx
  40a93b:	mov    BYTE PTR [r9],0x2e
  40a93f:	add    r9,0x1
  40a943:	xor    r8d,r8d
  40a946:	test   r10,r10
  40a949:	je     40a98f <__swc_fn_e121059d_000147_d2097256+0x8af>
  40a94b:	mov    r11d,0x989680
  40a951:	cmp    r10,r11
  40a954:	jge    40a98f <__swc_fn_e121059d_000147_d2097256+0x8af>
  40a956:	cs nop WORD PTR [rax+rax*1+0x0]
  40a960:	inc    r8d
  40a963:	movabs rdx,0x6666666666666667
  40a96d:	mov    r15,rax
  40a970:	mov    rax,r11
  40a973:	imul   rdx
  40a976:	mov    r11,rdx
  40a979:	mov    rax,r15
  40a97c:	sar    r11,0x2
  40a980:	mov    rdx,r11
  40a983:	shr    rdx,0x3f
  40a987:	add    r11,rdx
  40a98a:	cmp    r10,r11
  40a98d:	jl     40a960 <__swc_fn_e121059d_000147_d2097256+0x880>
  40a98f:	test   r8d,r8d
  40a992:	je     40a9ad <__swc_fn_e121059d_000147_d2097256+0x8cd>
  40a994:	cs nop WORD PTR [rax+rax*1+0x0]
  40a99e:	xchg   ax,ax
  40a9a0:	mov    BYTE PTR [r9],0x30
  40a9a4:	add    r9,0x1
  40a9a8:	dec    r8d
  40a9ab:	jne    40a9a0 <__swc_fn_e121059d_000147_d2097256+0x8c0>
  40a9ad:	mov    r8,r9
  40a9b0:	mov    rdx,r10
  40a9b3:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9bd:	nop    DWORD PTR [rax]
  40a9c0:	mov    r11,rdx
  40a9c3:	movabs rdx,0x6666666666666667
  40a9cd:	mov    rax,r11
  40a9d0:	imul   rdx
  40a9d3:	sar    rdx,0x2
  40a9d7:	mov    r12,rdx
  40a9da:	shr    rdx,0x3f
  40a9de:	add    r12,rdx
  40a9e1:	mov    rdx,r12
  40a9e4:	imul   r13,r12,0xa
  40a9e8:	sub    r11,r13
  40a9eb:	mov    r13,QWORD PTR [rip+0x8b4e]        # 413540 <__swc_rdata_base_e121059d+0x430>
  40a9f2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a9f7:	mov    BYTE PTR [r8],r11b
  40a9fa:	lea    r11,[r8+0x1]
  40a9fe:	mov    r8,r11
  40aa01:	test   r12,r12
  40aa04:	jne    40a9c0 <__swc_fn_e121059d_000147_d2097256+0x8e0>
  40aa06:	test   r10,r10
  40aa09:	jge    40aa13 <__swc_fn_e121059d_000147_d2097256+0x933>
  40aa0b:	mov    BYTE PTR [r11],0x2d
  40aa0f:	lea    r8,[r11+0x1]
  40aa13:	mov    BYTE PTR [r8],0x0
  40aa17:	sub    r8,0x1
  40aa1b:	cmp    r9,r8
  40aa1e:	jae    40aa38 <__swc_fn_e121059d_000147_d2097256+0x958>
  40aa20:	mov    al,BYTE PTR [r8]
  40aa23:	mov    dl,BYTE PTR [r9]
  40aa26:	mov    BYTE PTR [r8],dl
  40aa29:	sub    r8,0x1
  40aa2d:	mov    BYTE PTR [r9],al
  40aa30:	inc    r9
  40aa33:	cmp    r9,r8
  40aa36:	jb     40aa20 <__swc_fn_e121059d_000147_d2097256+0x940>
  40aa38:	xor    eax,eax
  40aa3a:	test   rcx,rcx
  40aa3d:	je     40aa70 <__swc_fn_e121059d_000147_d2097256+0x990>
  40aa3f:	mov    rdx,rcx
  40aa42:	mov    r8b,BYTE PTR [rdx]
  40aa45:	test   r8b,r8b
  40aa48:	je     40aa70 <__swc_fn_e121059d_000147_d2097256+0x990>
  40aa4a:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa54:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa5e:	xchg   ax,ax
  40aa60:	add    rdx,0x1
  40aa64:	add    rax,0x1
  40aa68:	mov    r8b,BYTE PTR [rdx]
  40aa6b:	test   r8b,r8b
  40aa6e:	jne    40aa60 <__swc_fn_e121059d_000147_d2097256+0x980>
  40aa70:	mov    QWORD PTR [rsp+0x240],rcx
  40aa78:	mov    QWORD PTR [rsp+0x248],rax
  40aa80:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  40aa89:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  40aa92:	lea    rcx,[rsp+0x250]
  40aa9a:	call   409870 <__swc_fn_e121059d_000117_3f5cfdef>
  40aa9f:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40aaa4:	lea    rcx,[rsp+0x260]
  40aaac:	vxorps xmm0,xmm0,xmm0
  40aab0:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  40aab9:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  40aac2:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  40aacb:	vzeroupper
  40aace:	mov    DWORD PTR [rsp+0x2c0],0x0
  40aad9:	vmovsd xmm0,QWORD PTR [rdx]
  40aadd:	vcomisd xmm0,xmm0
  40aae1:	setne  dl
  40aae4:	movzx  edx,dl
  40aae7:	setp   r8b
  40aaeb:	movzx  r8d,r8b
  40aaef:	or     edx,r8d
  40aaf2:	test   dl,dl
  40aaf4:	je     40ab01 <__swc_fn_e121059d_000147_d2097256+0xa21>
  40aaf6:	mov    DWORD PTR [rcx],0x6e616e
  40aafc:	jmp    40b108 <__swc_fn_e121059d_000147_d2097256+0x1028>
  40ab01:	vcomisd xmm0,xmm11
  40ab06:	ja     40ab17 <__swc_fn_e121059d_000147_d2097256+0xa37>
  40ab08:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  40ab11:	vcomisd xmm6,xmm0
  40ab15:	jbe    40ab3b <__swc_fn_e121059d_000147_d2097256+0xa5b>
  40ab17:	vxorpd xmm1,xmm1,xmm1
  40ab1b:	vcomisd xmm1,xmm0
  40ab1f:	jbe    40ab30 <__swc_fn_e121059d_000147_d2097256+0xa50>
  40ab21:	mov    DWORD PTR [rcx],0x666e692d
  40ab27:	mov    BYTE PTR [rcx+0x4],0x0
  40ab2b:	jmp    40b108 <__swc_fn_e121059d_000147_d2097256+0x1028>
  40ab30:	mov    DWORD PTR [rcx],0x666e69
  40ab36:	jmp    40b108 <__swc_fn_e121059d_000147_d2097256+0x1028>
  40ab3b:	vcomisd xmm0,xmm13
  40ab40:	jae    40ab4c <__swc_fn_e121059d_000147_d2097256+0xa6c>
  40ab42:	vcomisd xmm12,xmm0
  40ab46:	jbe    40aeae <__swc_fn_e121059d_000147_d2097256+0xdce>
  40ab4c:	vmovups xmm1,xmm0
  40ab50:	vxorpd xmm2,xmm2,xmm2
  40ab54:	vcomisd xmm2,xmm0
  40ab58:	jbe    40ab68 <__swc_fn_e121059d_000147_d2097256+0xa88>
  40ab5a:	vmovsd xmm0,xmm0,xmm1
  40ab5e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x89ea]        # 413550 <__swc_rdata_base_e121059d+0x440>
  40ab66:	jmp    40ab6c <__swc_fn_e121059d_000147_d2097256+0xa8c>
  40ab68:	vmovsd xmm0,xmm0,xmm1
  40ab6c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  40ab75:	xor    r8d,r8d
  40ab78:	vcomisd xmm0,xmm6
  40ab7c:	jb     40ab8e <__swc_fn_e121059d_000147_d2097256+0xaae>
  40ab7e:	xchg   ax,ax
  40ab80:	vdivsd xmm0,xmm0,xmm6
  40ab84:	add    r8,0x1
  40ab88:	vcomisd xmm0,xmm6
  40ab8c:	jae    40ab80 <__swc_fn_e121059d_000147_d2097256+0xaa0>
  40ab8e:	mov    r9,rcx
  40ab91:	vxorpd xmm2,xmm2,xmm2
  40ab95:	vcomisd xmm2,xmm1
  40ab99:	jbe    40aba2 <__swc_fn_e121059d_000147_d2097256+0xac2>
  40ab9b:	mov    BYTE PTR [rcx],0x2d
  40ab9e:	lea    r9,[rcx+0x1]
  40aba2:	vcvttsd2si rdx,xmm0
  40aba7:	mov    r10b,dl
  40abaa:	add    r10b,0x30
  40abae:	mov    BYTE PTR [r9],r10b
  40abb1:	vxorpd xmm1,xmm1,xmm1
  40abb5:	movzx  edx,dl
  40abb8:	vcvtsi2sd xmm1,xmm1,rdx
  40abbd:	vsubsd xmm0,xmm0,xmm1
  40abc1:	vmulsd xmm0,xmm0,xmm6
  40abc5:	mov    BYTE PTR [r9+0x1],0x2e
  40abca:	vcvttsd2si rdx,xmm0
  40abcf:	mov    r10b,dl
  40abd2:	add    r10b,0x30
  40abd6:	mov    BYTE PTR [r9+0x2],r10b
  40abda:	vxorpd xmm1,xmm1,xmm1
  40abde:	movzx  edx,dl
  40abe1:	vcvtsi2sd xmm1,xmm1,rdx
  40abe6:	vsubsd xmm0,xmm0,xmm1
  40abea:	vmulsd xmm0,xmm0,xmm6
  40abee:	vcvttsd2si rdx,xmm0
  40abf3:	mov    r10b,dl
  40abf6:	add    r10b,0x30
  40abfa:	mov    BYTE PTR [r9+0x3],r10b
  40abfe:	vxorpd xmm1,xmm1,xmm1
  40ac02:	movzx  edx,dl
  40ac05:	vcvtsi2sd xmm1,xmm1,rdx
  40ac0a:	vsubsd xmm0,xmm0,xmm1
  40ac0e:	vmulsd xmm0,xmm0,xmm6
  40ac12:	vcvttsd2si rdx,xmm0
  40ac17:	mov    r10b,dl
  40ac1a:	add    r10b,0x30
  40ac1e:	mov    BYTE PTR [r9+0x4],r10b
  40ac22:	vxorpd xmm1,xmm1,xmm1
  40ac26:	movzx  edx,dl
  40ac29:	vcvtsi2sd xmm1,xmm1,rdx
  40ac2e:	vsubsd xmm0,xmm0,xmm1
  40ac32:	vmulsd xmm0,xmm0,xmm6
  40ac36:	vcvttsd2si rdx,xmm0
  40ac3b:	mov    r10b,dl
  40ac3e:	add    r10b,0x30
  40ac42:	mov    BYTE PTR [r9+0x5],r10b
  40ac46:	vxorpd xmm1,xmm1,xmm1
  40ac4a:	movzx  edx,dl
  40ac4d:	vcvtsi2sd xmm1,xmm1,rdx
  40ac52:	vsubsd xmm0,xmm0,xmm1
  40ac56:	vmulsd xmm0,xmm0,xmm6
  40ac5a:	vcvttsd2si rdx,xmm0
  40ac5f:	mov    r10b,dl
  40ac62:	add    r10b,0x30
  40ac66:	mov    BYTE PTR [r9+0x6],r10b
  40ac6a:	vxorpd xmm1,xmm1,xmm1
  40ac6e:	movzx  edx,dl
  40ac71:	vcvtsi2sd xmm1,xmm1,rdx
  40ac76:	vsubsd xmm0,xmm0,xmm1
  40ac7a:	vmulsd xmm0,xmm0,xmm6
  40ac7e:	vcvttsd2si rdx,xmm0
  40ac83:	mov    r10b,dl
  40ac86:	add    r10b,0x30
  40ac8a:	mov    BYTE PTR [r9+0x7],r10b
  40ac8e:	vxorpd xmm1,xmm1,xmm1
  40ac92:	movzx  edx,dl
  40ac95:	vcvtsi2sd xmm1,xmm1,rdx
  40ac9a:	vsubsd xmm0,xmm0,xmm1
  40ac9e:	vmulsd xmm0,xmm0,xmm6
  40aca2:	vcvttsd2si rdx,xmm0
  40aca7:	mov    r10b,dl
  40acaa:	add    r10b,0x30
  40acae:	mov    BYTE PTR [r9+0x8],r10b
  40acb2:	vxorpd xmm1,xmm1,xmm1
  40acb6:	movzx  edx,dl
  40acb9:	vcvtsi2sd xmm1,xmm1,rdx
  40acbe:	vsubsd xmm0,xmm0,xmm1
  40acc2:	vmulsd xmm0,xmm0,xmm6
  40acc6:	vcvttsd2si rdx,xmm0
  40accb:	mov    r10b,dl
  40acce:	add    r10b,0x30
  40acd2:	mov    BYTE PTR [r9+0x9],r10b
  40acd6:	vxorpd xmm1,xmm1,xmm1
  40acda:	movzx  edx,dl
  40acdd:	vcvtsi2sd xmm1,xmm1,rdx
  40ace2:	vsubsd xmm0,xmm0,xmm1
  40ace6:	vmulsd xmm0,xmm0,xmm6
  40acea:	vcvttsd2si rdx,xmm0
  40acef:	mov    r10b,dl
  40acf2:	add    r10b,0x30
  40acf6:	mov    BYTE PTR [r9+0xa],r10b
  40acfa:	vxorpd xmm1,xmm1,xmm1
  40acfe:	movzx  edx,dl
  40ad01:	vcvtsi2sd xmm1,xmm1,rdx
  40ad06:	vsubsd xmm0,xmm0,xmm1
  40ad0a:	vmulsd xmm0,xmm0,xmm6
  40ad0e:	vcvttsd2si rdx,xmm0
  40ad13:	mov    r10b,dl
  40ad16:	add    r10b,0x30
  40ad1a:	mov    BYTE PTR [r9+0xb],r10b
  40ad1e:	lea    r10,[r9+0x4]
  40ad22:	vxorpd xmm1,xmm1,xmm1
  40ad26:	movzx  edx,dl
  40ad29:	vcvtsi2sd xmm1,xmm1,rdx
  40ad2e:	vsubsd xmm0,xmm0,xmm1
  40ad32:	vmulsd xmm0,xmm0,xmm6
  40ad36:	vcvttsd2si rdx,xmm0
  40ad3b:	mov    r11b,dl
  40ad3e:	add    r11b,0x30
  40ad42:	mov    BYTE PTR [r9+0xc],r11b
  40ad46:	vxorpd xmm1,xmm1,xmm1
  40ad4a:	movzx  edx,dl
  40ad4d:	vcvtsi2sd xmm1,xmm1,rdx
  40ad52:	vsubsd xmm0,xmm0,xmm1
  40ad56:	vmulsd xmm0,xmm0,xmm6
  40ad5a:	vcvttsd2si rdx,xmm0
  40ad5f:	mov    r11b,dl
  40ad62:	add    r11b,0x30
  40ad66:	mov    BYTE PTR [r9+0xd],r11b
  40ad6a:	lea    r10,[r10+0x2]
  40ad6e:	vxorpd xmm1,xmm1,xmm1
  40ad72:	movzx  edx,dl
  40ad75:	vcvtsi2sd xmm1,xmm1,rdx
  40ad7a:	vsubsd xmm0,xmm0,xmm1
  40ad7e:	vmulsd xmm0,xmm0,xmm6
  40ad82:	vcvttsd2si rdx,xmm0
  40ad87:	mov    r11b,dl
  40ad8a:	add    r11b,0x30
  40ad8e:	mov    BYTE PTR [r9+0xe],r11b
  40ad92:	vxorpd xmm1,xmm1,xmm1
  40ad96:	movzx  edx,dl
  40ad99:	vcvtsi2sd xmm1,xmm1,rdx
  40ad9e:	vsubsd xmm0,xmm0,xmm1
  40ada2:	vmulsd xmm0,xmm0,xmm6
  40ada6:	vcvttsd2si rdx,xmm0
  40adab:	mov    r11b,dl
  40adae:	add    r11b,0x30
  40adb2:	mov    BYTE PTR [r9+0xf],r11b
  40adb6:	lea    r10,[r10+0x2]
  40adba:	lea    r10,[r10+0x2]
  40adbe:	lea    r10,[r10+0x2]
  40adc2:	lea    r10,[r10+0x2]
  40adc6:	lea    r10,[r10+0x2]
  40adca:	vxorpd xmm1,xmm1,xmm1
  40adce:	movzx  edx,dl
  40add1:	vcvtsi2sd xmm1,xmm1,rdx
  40add6:	vsubsd xmm0,xmm0,xmm1
  40adda:	vmulsd xmm0,xmm0,xmm6
  40adde:	vcvttsd2si rdx,xmm0
  40ade3:	mov    r11b,dl
  40ade6:	add    r11b,0x30
  40adea:	mov    BYTE PTR [r9+0x10],r11b
  40adee:	vxorpd xmm1,xmm1,xmm1
  40adf2:	movzx  edx,dl
  40adf5:	vcvtsi2sd xmm1,xmm1,rdx
  40adfa:	vsubsd xmm0,xmm0,xmm1
  40adfe:	vmulsd xmm0,xmm0,xmm6
  40ae02:	vcvttsd2si rdx,xmm0
  40ae07:	add    dl,0x30
  40ae0a:	mov    BYTE PTR [r9+0x11],dl
  40ae0e:	mov    BYTE PTR [r10+0x2],0x65
  40ae13:	lea    r9,[r10+0x3]
  40ae17:	test   r8,r8
  40ae1a:	jl     40ae23 <__swc_fn_e121059d_000147_d2097256+0xd43>
  40ae1c:	mov    BYTE PTR [r9],0x2b
  40ae20:	inc    r9
  40ae23:	mov    r10,r9
  40ae26:	mov    rdx,r8
  40ae29:	nop    DWORD PTR [rax+0x0]
  40ae30:	mov    r11,rdx
  40ae33:	movabs rdx,0x6666666666666667
  40ae3d:	mov    rax,r11
  40ae40:	imul   rdx
  40ae43:	sar    rdx,0x2
  40ae47:	mov    r12,rdx
  40ae4a:	shr    rdx,0x3f
  40ae4e:	add    r12,rdx
  40ae51:	mov    rdx,r12
  40ae54:	imul   r13,r12,0xa
  40ae58:	sub    r11,r13
  40ae5b:	mov    r13,QWORD PTR [rip+0x86de]        # 413540 <__swc_rdata_base_e121059d+0x430>
  40ae62:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40ae67:	mov    BYTE PTR [r10],r11b
  40ae6a:	lea    r11,[r10+0x1]
  40ae6e:	mov    r10,r11
  40ae71:	test   r12,r12
  40ae74:	jne    40ae30 <__swc_fn_e121059d_000147_d2097256+0xd50>
  40ae76:	test   r8,r8
  40ae79:	jge    40ae83 <__swc_fn_e121059d_000147_d2097256+0xda3>
  40ae7b:	mov    BYTE PTR [r11],0x2d
  40ae7f:	lea    r10,[r11+0x1]
  40ae83:	mov    BYTE PTR [r10],0x0
  40ae87:	sub    r10,0x1
  40ae8b:	nop    DWORD PTR [rax+rax*1+0x0]
  40ae90:	cmp    r9,r10
  40ae93:	jae    40b108 <__swc_fn_e121059d_000147_d2097256+0x1028>
  40ae99:	mov    al,BYTE PTR [r10]
  40ae9c:	mov    dl,BYTE PTR [r9]
  40ae9f:	mov    BYTE PTR [r10],dl
  40aea2:	sub    r10,0x1
  40aea6:	mov    BYTE PTR [r9],al
  40aea9:	inc    r9
  40aeac:	jmp    40ae90 <__swc_fn_e121059d_000147_d2097256+0xdb0>
  40aeae:	vcvttsd2si rdx,xmm0
  40aeb3:	mov    r8,rdx
  40aeb6:	vxorpd xmm1,xmm1,xmm1
  40aeba:	vcvtsi2sd xmm1,xmm1,rdx
  40aebf:	vsubsd xmm1,xmm0,xmm1
  40aec3:	mov    r9d,0x8
  40aec9:	vxorpd xmm2,xmm2,xmm2
  40aecd:	vcomisd xmm2,xmm1
  40aed1:	ja     40aede <__swc_fn_e121059d_000147_d2097256+0xdfe>
  40aed3:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40aedc:	jmp    40aeef <__swc_fn_e121059d_000147_d2097256+0xe0f>
  40aede:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x866a]        # 413550 <__swc_rdata_base_e121059d+0x440>
  40aee6:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40aeef:	test   r9d,r9d
  40aef2:	je     40af09 <__swc_fn_e121059d_000147_d2097256+0xe29>
  40aef4:	cs nop WORD PTR [rax+rax*1+0x0]
  40aefe:	xchg   ax,ax
  40af00:	vmulsd xmm1,xmm1,xmm6
  40af04:	dec    r9d
  40af07:	jne    40af00 <__swc_fn_e121059d_000147_d2097256+0xe20>
  40af09:	vcvttsd2si r9,xmm1
  40af0e:	mov    r10,r9
  40af11:	vxorpd xmm2,xmm2,xmm2
  40af15:	vcvtsi2sd xmm2,xmm2,r9
  40af1a:	vsubsd xmm1,xmm1,xmm2
  40af1e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  40af27:	vcomisd xmm1,xmm6
  40af2b:	lea    r9,[r9+0x1]
  40af2f:	cmova  r10,r9
  40af33:	cmp    r10,0x5f5e100
  40af3a:	jne    40af53 <__swc_fn_e121059d_000147_d2097256+0xe73>
  40af3c:	lea    r8,[rdx-0x1]
  40af40:	vxorpd xmm1,xmm1,xmm1
  40af44:	vcomisd xmm1,xmm0
  40af48:	lea    rdx,[rdx+0x1]
  40af4c:	cmovbe r8,rdx
  40af50:	xor    r10d,r10d
  40af53:	mov    r9,rcx
  40af56:	test   r8,r8
  40af59:	jne    40af79 <__swc_fn_e121059d_000147_d2097256+0xe99>
  40af5b:	vxorpd xmm1,xmm1,xmm1
  40af5f:	vcomisd xmm1,xmm0
  40af63:	jbe    40af6c <__swc_fn_e121059d_000147_d2097256+0xe8c>
  40af65:	mov    BYTE PTR [rcx],0x2d
  40af68:	lea    r9,[rcx+0x1]
  40af6c:	mov    BYTE PTR [r9],0x30
  40af70:	add    r9,0x1
  40af74:	jmp    40b00b <__swc_fn_e121059d_000147_d2097256+0xf2b>
  40af79:	mov    r9,rcx
  40af7c:	mov    rdx,r8
  40af7f:	nop
  40af80:	mov    r11,rdx
  40af83:	movabs rdx,0x6666666666666667
  40af8d:	mov    r15,rax
  40af90:	mov    rax,r11
  40af93:	imul   rdx
  40af96:	mov    r12,rdx
  40af99:	mov    rax,r15
  40af9c:	sar    r12,0x2
  40afa0:	mov    rdx,r12
  40afa3:	shr    rdx,0x3f
  40afa7:	add    r12,rdx
  40afaa:	mov    rdx,r12
  40afad:	imul   r13,r12,0xa
  40afb1:	sub    r11,r13
  40afb4:	mov    r13,QWORD PTR [rip+0x8585]        # 413540 <__swc_rdata_base_e121059d+0x430>
  40afbb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40afc0:	mov    BYTE PTR [r9],r11b
  40afc3:	lea    r11,[r9+0x1]
  40afc7:	mov    r9,r11
  40afca:	test   r12,r12
  40afcd:	jne    40af80 <__swc_fn_e121059d_000147_d2097256+0xea0>
  40afcf:	test   r8,r8
  40afd2:	jge    40afdc <__swc_fn_e121059d_000147_d2097256+0xefc>
  40afd4:	mov    BYTE PTR [r11],0x2d
  40afd8:	lea    r9,[r11+0x1]
  40afdc:	mov    rdx,r9
  40afdf:	mov    BYTE PTR [r9],0x0
  40afe3:	sub    r9,0x1
  40afe7:	mov    r8,rcx
  40afea:	cmp    r8,r9
  40afed:	jae    40b008 <__swc_fn_e121059d_000147_d2097256+0xf28>
  40afef:	nop
  40aff0:	mov    r11b,BYTE PTR [r9]
  40aff3:	mov    r12b,BYTE PTR [r8]
  40aff6:	mov    BYTE PTR [r9],r12b
  40aff9:	sub    r9,0x1
  40affd:	mov    BYTE PTR [r8],r11b
  40b000:	inc    r8
  40b003:	cmp    r8,r9
  40b006:	jb     40aff0 <__swc_fn_e121059d_000147_d2097256+0xf10>
  40b008:	mov    r9,rdx
  40b00b:	mov    BYTE PTR [r9],0x2e
  40b00f:	add    r9,0x1
  40b013:	xor    r8d,r8d
  40b016:	test   r10,r10
  40b019:	je     40b05f <__swc_fn_e121059d_000147_d2097256+0xf7f>
  40b01b:	mov    r11d,0x989680
  40b021:	cmp    r10,r11
  40b024:	jge    40b05f <__swc_fn_e121059d_000147_d2097256+0xf7f>
  40b026:	cs nop WORD PTR [rax+rax*1+0x0]
  40b030:	inc    r8d
  40b033:	movabs rdx,0x6666666666666667
  40b03d:	mov    r15,rax
  40b040:	mov    rax,r11
  40b043:	imul   rdx
  40b046:	mov    r11,rdx
  40b049:	mov    rax,r15
  40b04c:	sar    r11,0x2
  40b050:	mov    rdx,r11
  40b053:	shr    rdx,0x3f
  40b057:	add    r11,rdx
  40b05a:	cmp    r10,r11
  40b05d:	jl     40b030 <__swc_fn_e121059d_000147_d2097256+0xf50>
  40b05f:	test   r8d,r8d
  40b062:	je     40b07d <__swc_fn_e121059d_000147_d2097256+0xf9d>
  40b064:	cs nop WORD PTR [rax+rax*1+0x0]
  40b06e:	xchg   ax,ax
  40b070:	mov    BYTE PTR [r9],0x30
  40b074:	add    r9,0x1
  40b078:	dec    r8d
  40b07b:	jne    40b070 <__swc_fn_e121059d_000147_d2097256+0xf90>
  40b07d:	mov    r8,r9
  40b080:	mov    rdx,r10
  40b083:	cs nop WORD PTR [rax+rax*1+0x0]
  40b08d:	nop    DWORD PTR [rax]
  40b090:	mov    r11,rdx
  40b093:	movabs rdx,0x6666666666666667
  40b09d:	mov    rax,r11
  40b0a0:	imul   rdx
  40b0a3:	sar    rdx,0x2
  40b0a7:	mov    r12,rdx
  40b0aa:	shr    rdx,0x3f
  40b0ae:	add    r12,rdx
  40b0b1:	mov    rdx,r12
  40b0b4:	imul   r13,r12,0xa
  40b0b8:	sub    r11,r13
  40b0bb:	mov    r13,QWORD PTR [rip+0x847e]        # 413540 <__swc_rdata_base_e121059d+0x430>
  40b0c2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b0c7:	mov    BYTE PTR [r8],r11b
  40b0ca:	lea    r11,[r8+0x1]
  40b0ce:	mov    r8,r11
  40b0d1:	test   r12,r12
  40b0d4:	jne    40b090 <__swc_fn_e121059d_000147_d2097256+0xfb0>
  40b0d6:	test   r10,r10
  40b0d9:	jge    40b0e3 <__swc_fn_e121059d_000147_d2097256+0x1003>
  40b0db:	mov    BYTE PTR [r11],0x2d
  40b0df:	lea    r8,[r11+0x1]
  40b0e3:	mov    BYTE PTR [r8],0x0
  40b0e7:	sub    r8,0x1
  40b0eb:	cmp    r9,r8
  40b0ee:	jae    40b108 <__swc_fn_e121059d_000147_d2097256+0x1028>
  40b0f0:	mov    al,BYTE PTR [r8]
  40b0f3:	mov    dl,BYTE PTR [r9]
  40b0f6:	mov    BYTE PTR [r8],dl
  40b0f9:	sub    r8,0x1
  40b0fd:	mov    BYTE PTR [r9],al
  40b100:	inc    r9
  40b103:	cmp    r9,r8
  40b106:	jb     40b0f0 <__swc_fn_e121059d_000147_d2097256+0x1010>
  40b108:	xor    eax,eax
  40b10a:	test   rcx,rcx
  40b10d:	je     40b130 <__swc_fn_e121059d_000147_d2097256+0x1050>
  40b10f:	mov    rdx,rcx
  40b112:	mov    r8b,BYTE PTR [rdx]
  40b115:	test   r8b,r8b
  40b118:	je     40b130 <__swc_fn_e121059d_000147_d2097256+0x1050>
  40b11a:	nop    WORD PTR [rax+rax*1+0x0]
  40b120:	add    rdx,0x1
  40b124:	add    rax,0x1
  40b128:	mov    r8b,BYTE PTR [rdx]
  40b12b:	test   r8b,r8b
  40b12e:	jne    40b120 <__swc_fn_e121059d_000147_d2097256+0x1040>
  40b130:	mov    QWORD PTR [rsp+0x3f8],rcx
  40b138:	mov    QWORD PTR [rsp+0x400],rax
  40b140:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  40b149:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  40b152:	lea    rcx,[rsp+0x408]
  40b15a:	call   409870 <__swc_fn_e121059d_000117_3f5cfdef>
  40b15f:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40b161:	mov    rcx,rdx
  40b164:	call   409870 <__swc_fn_e121059d_000117_3f5cfdef>
  40b169:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40b16b:	mov    al,BYTE PTR [rdx]
  40b16d:	test   al,al
  40b16f:	je     40b17a <__swc_fn_e121059d_000147_d2097256+0x109a>
  40b171:	lea    rax,[rip+0x83e8]        # 413560 <__swc_rdata_base_e121059d+0x450>
  40b178:	jmp    40b181 <__swc_fn_e121059d_000147_d2097256+0x10a1>
  40b17a:	lea    rax,[rip+0x83ef]        # 413570 <__swc_rdata_base_e121059d+0x460>
  40b181:	mov    rcx,rax
  40b184:	call   409870 <__swc_fn_e121059d_000117_3f5cfdef>
  40b189:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40b18b:	lea    rcx,[rip+0x83ee]        # 413580 <__swc_rdata_base_e121059d+0x470>
  40b192:	call   409870 <__swc_fn_e121059d_000117_3f5cfdef>
  40b197:	jmp    40b1a5 <__swc_fn_e121059d_000147_d2097256+0x10c5>
  40b199:	lea    rcx,[rip+0x83e0]        # 413580 <__swc_rdata_base_e121059d+0x470>
  40b1a0:	call   409870 <__swc_fn_e121059d_000117_3f5cfdef>
  40b1a5:	add    rdi,0x1
  40b1a9:	sub    rsi,0x1
  40b1ad:	vmovups xmm0,xmm12
  40b1b2:	vmovsd xmm6,QWORD PTR [rip+0x83d6]        # 413590 <__swc_rdata_base_e121059d+0x480>
  40b1ba:	test   rsi,rsi
  40b1bd:	jne    40a1f0 <__swc_fn_e121059d_000147_d2097256+0x110>
  40b1c3:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  40b1cc:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  40b1d5:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  40b1de:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  40b1e7:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  40b1f0:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  40b1f9:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  40b202:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  40b20b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  40b214:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  40b21d:	add    rsp,0x4e8
  40b224:	pop    r15
  40b226:	pop    r13
  40b228:	pop    r12
  40b22a:	pop    rdi
  40b22b:	pop    rsi
  40b22c:	pop    rbx
  40b22d:	ret
	...

000000000040b230 <__swc_fn_e121059d_000150_365b4daf>:
  40b230:	vxorps xmm0,xmm0,xmm0
  40b234:	vmovups XMMWORD PTR [rcx],xmm0
  40b238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b23d:	ret
	...

000000000040b240 <__swc_fn_e121059d_000153_365b4daf>:
  40b240:	vxorps xmm0,xmm0,xmm0
  40b244:	vmovups XMMWORD PTR [rcx],xmm0
  40b248:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b24d:	vxorps xmm0,xmm0,xmm0
  40b251:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b256:	vmovups xmm0,XMMWORD PTR [rip+0x8442]        # 4136a0 <__swc_rdata_base_e121059d+0x590>
  40b25e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b263:	vxorps xmm0,xmm0,xmm0
  40b267:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b26c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40b271:	vxorps xmm0,xmm0,xmm0
  40b275:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40b27a:	mov    QWORD PTR [rcx+0x70],0x0
  40b282:	ret
	...

000000000040b290 <__swc_fn_e121059d_000156_365b4daf>:
  40b290:	vxorps xmm0,xmm0,xmm0
  40b294:	vmovups XMMWORD PTR [rcx],xmm0
  40b298:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b29d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b2a2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b2a7:	ret
	...

000000000040b2b0 <__swc_fn_e121059d_000159_31e09513>:
  40b2b0:	push   rsi
  40b2b1:	push   rdi
  40b2b2:	sub    rsp,0x8
  40b2b6:	mov    rsi,rcx
  40b2b9:	mov    rdi,QWORD PTR [rsi+0x50]
  40b2bd:	test   rdi,rdi
  40b2c0:	je     40b2c7 <__swc_fn_e121059d_000159_31e09513+0x17>
  40b2c2:	mov    rcx,rsi
  40b2c5:	call   rdi
  40b2c7:	mov    QWORD PTR [rsi+0x20],0x0
  40b2cf:	mov    rax,QWORD PTR [rsi+0x30]
  40b2d3:	test   rax,rax
  40b2d6:	je     40b304 <__swc_fn_e121059d_000159_31e09513+0x54>
  40b2d8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b2e0:	mov    rdi,QWORD PTR [rax+0x8]
  40b2e4:	mov    rcx,rsi
  40b2e7:	mov    rdx,QWORD PTR [rax+0x10]
  40b2eb:	mov    rax,QWORD PTR [rax+0x18]
  40b2ef:	mov    r8,rax
  40b2f2:	call   40e630 <__swc_fn_e121059d_000157_9e2052d6>
  40b2f7:	mov    QWORD PTR [rsi+0x30],rdi
  40b2fb:	mov    rax,QWORD PTR [rsi+0x30]
  40b2ff:	test   rax,rax
  40b302:	jne    40b2e0 <__swc_fn_e121059d_000159_31e09513+0x30>
  40b304:	mov    QWORD PTR [rsi+0x38],0x0
  40b30c:	add    rsp,0x8
  40b310:	pop    rdi
  40b311:	pop    rsi
  40b312:	ret
	...

000000000040b320 <__swc_fn_e121059d_000162_b553c03d>:
  40b320:	push   rbx
  40b321:	push   rsi
  40b322:	push   rdi
  40b323:	push   r12
  40b325:	sub    rsp,0x188
  40b32c:	mov    rbx,rcx
  40b32f:	lea    rsi,[rip+0x1ba5a]        # 426d90 <__swc_bss_base_e121059d+0x2d50>
  40b336:	mov    rcx,rsi
  40b339:	call   40e040 <__swc_fn_e121059d_000136_db32cc57>
  40b33e:	mov    rax,QWORD PTR [rip+0x1ba53]        # 426d98 <__swc_bss_base_e121059d+0x2d58>
  40b345:	mov    rdi,rax
  40b348:	test   rdi,rdi
  40b34b:	je     40b379 <__swc_fn_e121059d_000162_b553c03d+0x59>
  40b34d:	nop    DWORD PTR [rax]
  40b350:	cmp    QWORD PTR [rdi+0x8],rbx
  40b354:	jne    40b36e <__swc_fn_e121059d_000162_b553c03d+0x4e>
  40b356:	mov    rcx,rsi
  40b359:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40b35e:	mov    rax,rdi
  40b361:	add    rsp,0x188
  40b368:	pop    r12
  40b36a:	pop    rdi
  40b36b:	pop    rsi
  40b36c:	pop    rbx
  40b36d:	ret
  40b36e:	mov    rax,QWORD PTR [rdi]
  40b371:	mov    rdi,rax
  40b374:	test   rax,rax
  40b377:	jne    40b350 <__swc_fn_e121059d_000162_b553c03d+0x30>
  40b379:	call   4111c0 <__swc_fn_e121059d_000140_e4a7a8b1>
  40b37e:	mov    rdi,rax
  40b381:	test   rax,rax
  40b384:	jne    40b39d <__swc_fn_e121059d_000162_b553c03d+0x7d>
  40b386:	mov    rcx,rsi
  40b389:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40b38e:	xor    eax,eax
  40b390:	add    rsp,0x188
  40b397:	pop    r12
  40b399:	pop    rdi
  40b39a:	pop    rsi
  40b39b:	pop    rbx
  40b39c:	ret
  40b39d:	lea    rax,[rsp+0x18]
  40b3a2:	mov    QWORD PTR [rax+0x10],0x0
  40b3aa:	mov    QWORD PTR [rax+0x18],0x0
  40b3b2:	mov    DWORD PTR [rax+0x20],0x0
  40b3b9:	mov    BYTE PTR [rax+0x24],0x0
  40b3bd:	mov    rax,QWORD PTR [rip+0x1b9d4]        # 426d98 <__swc_bss_base_e121059d+0x2d58>
  40b3c4:	mov    QWORD PTR [rsp+0x18],rax
  40b3c9:	mov    QWORD PTR [rsp+0x20],rbx
  40b3ce:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40b3d4:	vmovups XMMWORD PTR [rdi],xmm0
  40b3d8:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40b3de:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  40b3e3:	mov    rax,QWORD PTR [rsp+0x38]
  40b3e8:	mov    QWORD PTR [rdi+0x20],rax
  40b3ec:	mov    QWORD PTR [rip+0x1b9a5],rdi        # 426d98 <__swc_bss_base_e121059d+0x2d58>
  40b3f3:	lea    rax,[rsp+0x40]
  40b3f8:	mov    QWORD PTR [rax],0x0
  40b3ff:	mov    rcx,rbx
  40b402:	mov    rdx,rax
  40b405:	call   40e120 <__swc_fn_e121059d_000142_5e493395>
  40b40a:	mov    rbx,rax
  40b40d:	test   rax,rax
  40b410:	jne    40b42a <__swc_fn_e121059d_000162_b553c03d+0x10a>
  40b412:	mov    rcx,rsi
  40b415:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40b41a:	mov    rax,rdi
  40b41d:	add    rsp,0x188
  40b424:	pop    r12
  40b426:	pop    rdi
  40b427:	pop    rsi
  40b428:	pop    rbx
  40b429:	ret
  40b42a:	lea    r12,[rsp+0x50]
  40b42f:	mov    QWORD PTR [r12],0x0
  40b437:	mov    rcx,rbx
  40b43a:	mov    rdx,QWORD PTR [rsp+0x40]
  40b43f:	mov    r8,r12
  40b442:	call   411270 <__swc_fn_e121059d_000143_89a6ef72>
  40b447:	test   rax,rax
  40b44a:	jne    40b464 <__swc_fn_e121059d_000162_b553c03d+0x144>
  40b44c:	mov    rcx,rsi
  40b44f:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40b454:	mov    rax,rdi
  40b457:	add    rsp,0x188
  40b45e:	pop    r12
  40b460:	pop    rdi
  40b461:	pop    rsi
  40b462:	pop    rbx
  40b463:	ret
  40b464:	cmp    QWORD PTR [r12],0x10
  40b469:	jb     40b56c <__swc_fn_e121059d_000162_b553c03d+0x24c>
  40b46f:	mov    ecx,DWORD PTR [rax]
  40b471:	cmp    ecx,0x42445753
  40b477:	jne    40b56c <__swc_fn_e121059d_000162_b553c03d+0x24c>
  40b47d:	mov    ecx,DWORD PTR [rax+0x4]
  40b480:	cmp    ecx,0x1
  40b483:	jne    40b56c <__swc_fn_e121059d_000162_b553c03d+0x24c>
  40b489:	mov    ecx,DWORD PTR [rax+0x8]
  40b48c:	mov    edx,DWORD PTR [rax+0xc]
  40b48f:	imul   r8,rcx,0x14
  40b493:	mov    r9,QWORD PTR [rsp+0x50]
  40b498:	sub    r9,0x10
  40b49c:	cmp    r8,r9
  40b49f:	ja     40b56c <__swc_fn_e121059d_000162_b553c03d+0x24c>
  40b4a5:	lea    r8,[r8+0x10]
  40b4a9:	cmp    rdx,r8
  40b4ac:	jb     40b56c <__swc_fn_e121059d_000162_b553c03d+0x24c>
  40b4b2:	mov    r8,QWORD PTR [rsp+0x50]
  40b4b7:	cmp    rdx,r8
  40b4ba:	ja     40b56c <__swc_fn_e121059d_000162_b553c03d+0x24c>
  40b4c0:	xor    r8d,r8d
  40b4c3:	test   rcx,rcx
  40b4c6:	jbe    40b592 <__swc_fn_e121059d_000162_b553c03d+0x272>
  40b4cc:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  40b4d2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b4dc:	nop    DWORD PTR [rax+0x0]
  40b4e0:	imul   r9,r8,0x14
  40b4e4:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  40b4e9:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  40b4ee:	add    r10,r11
  40b4f1:	movabs r11,0x100000000
  40b4fb:	cmp    r10,r11
  40b4fe:	ja     40b56c <__swc_fn_e121059d_000162_b553c03d+0x24c>
  40b500:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  40b505:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  40b50a:	test   r10d,r10d
  40b50d:	setne  r11b
  40b511:	je     40b52b <__swc_fn_e121059d_000162_b553c03d+0x20b>
  40b513:	cmp    r10d,edx
  40b516:	setb   r11b
  40b51a:	jb     40b52b <__swc_fn_e121059d_000162_b553c03d+0x20b>
  40b51c:	vmovq  r11,xmm1
  40b521:	cmp    r10,r11
  40b524:	setae  r10b
  40b528:	mov    r11b,r10b
  40b52b:	mov    r10,r11
  40b52e:	test   r11b,r11b
  40b531:	jne    40b558 <__swc_fn_e121059d_000162_b553c03d+0x238>
  40b533:	test   r9d,r9d
  40b536:	setne  r10b
  40b53a:	je     40b558 <__swc_fn_e121059d_000162_b553c03d+0x238>
  40b53c:	cmp    r9d,edx
  40b53f:	setb   r10b
  40b543:	jb     40b558 <__swc_fn_e121059d_000162_b553c03d+0x238>
  40b545:	vmovq  r10,xmm1
  40b54a:	cmp    r9,r10
  40b54d:	setae  r9b
  40b551:	movzx  r9d,r9b
  40b555:	mov    r10b,r9b
  40b558:	test   r10b,r10b
  40b55b:	jne    40b56c <__swc_fn_e121059d_000162_b553c03d+0x24c>
  40b55d:	add    r8,0x1
  40b561:	cmp    r8,rcx
  40b564:	jb     40b4e0 <__swc_fn_e121059d_000162_b553c03d+0x1c0>
  40b56a:	jmp    40b592 <__swc_fn_e121059d_000162_b553c03d+0x272>
  40b56c:	xor    ecx,ecx
  40b56e:	cmp    rax,rbx
  40b571:	cmovne rcx,rax
  40b575:	call   40a030 <__swc_fn_e121059d_000144_b7ad855f>
  40b57a:	mov    rcx,rsi
  40b57d:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40b582:	mov    rax,rdi
  40b585:	add    rsp,0x188
  40b58c:	pop    r12
  40b58e:	pop    rdi
  40b58f:	pop    rsi
  40b590:	pop    rbx
  40b591:	ret
  40b592:	mov    QWORD PTR [rdi+0x10],rax
  40b596:	mov    rcx,QWORD PTR [rsp+0x50]
  40b59b:	mov    QWORD PTR [rdi+0x18],rcx
  40b59f:	mov    eax,DWORD PTR [rax+0x8]
  40b5a2:	mov    DWORD PTR [rdi+0x20],eax
  40b5a5:	rex mov BYTE PTR [rdi+0x24],0x1
  40b5aa:	mov    rcx,rsi
  40b5ad:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40b5b2:	mov    rax,rdi
  40b5b5:	add    rsp,0x188
  40b5bc:	pop    r12
  40b5be:	pop    rdi
  40b5bf:	pop    rsi
  40b5c0:	pop    rbx
  40b5c1:	ret
	...

000000000040b5d0 <__swc_fn_e121059d_000165_d25850aa>:
  40b5d0:	push   rsi
  40b5d1:	push   rdi
  40b5d2:	push   r12
  40b5d4:	mov    rsi,rdx
  40b5d7:	mov    rdi,rcx
  40b5da:	mov    rcx,QWORD PTR [rip+0x1b75f]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40b5e1:	test   rcx,rcx
  40b5e4:	jne    40b5f6 <__swc_fn_e121059d_000165_d25850aa+0x26>
  40b5e6:	call   40e940 <__swc_fn_e121059d_000166_56054fe7>
  40b5eb:	lea    rcx,[rax+0x1]
  40b5ef:	mov    QWORD PTR [rip+0x1b74a],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40b5f6:	dec    rcx
  40b5f9:	call   40b620 <__swc_fn_e121059d_000168_39c041ad>
  40b5fe:	mov    r12,QWORD PTR [rax+0xbe0]
  40b605:	test   r12,r12
  40b608:	setne  al
  40b60b:	je     40b616 <__swc_fn_e121059d_000165_d25850aa+0x46>
  40b60d:	mov    rcx,rdi
  40b610:	mov    rdx,rsi
  40b613:	call   r12
  40b616:	pop    r12
  40b618:	pop    rdi
  40b619:	pop    rsi
  40b61a:	ret
  40b61b:	add    BYTE PTR [rax],al
  40b61d:	add    BYTE PTR [rax],al
	...

000000000040b620 <__swc_fn_e121059d_000168_39c041ad>:
  40b620:	push   r12
  40b622:	push   rdi
  40b623:	push   rsi
  40b624:	sub    rsp,0xd0
  40b62b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40b631:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40b637:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40b63d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40b643:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40b649:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40b64f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40b658:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40b661:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40b66a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40b673:	mov    r12,rcx
  40b676:	mov    edi,ecx
  40b678:	xor    eax,eax
  40b67a:	call   407000 <pthread_getspecific@plt>
  40b67f:	test   rax,rax
  40b682:	je     40b686 <__swc_fn_e121059d_000168_39c041ad+0x66>
  40b684:	jmp    40b68e <__swc_fn_e121059d_000168_39c041ad+0x6e>
  40b686:	mov    rcx,r12
  40b689:	call   40e9a0 <__swc_fn_e121059d_000169_0ad81c51>
  40b68e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40b694:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40b69a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40b6a0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40b6a6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40b6ac:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40b6b2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40b6bb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40b6c4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40b6cd:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40b6d6:	add    rsp,0xd0
  40b6dd:	pop    rsi
  40b6de:	pop    rdi
  40b6df:	pop    r12
  40b6e1:	ret
	...

000000000040b6f0 <__swc_fn_e121059d_000171_4dbacba0>:
  40b6f0:	push   rsi
  40b6f1:	sub    rsp,0x30
  40b6f5:	lea    rsi,[rip+0x1b6ac]        # 426da8 <__swc_bss_base_e121059d+0x2d68>
  40b6fc:	mov    rax,QWORD PTR [rsi]
  40b6ff:	test   rax,rax
  40b702:	je     40b70a <__swc_fn_e121059d_000171_4dbacba0+0x1a>
  40b704:	add    rsp,0x30
  40b708:	pop    rsi
  40b709:	ret
  40b70a:	mov    ecx,0x3
  40b70f:	mov    edx,0x10
  40b714:	call   409190 <__swc_fn_e121059d_000108_c8d4a68e>
  40b719:	test   rax,rax
  40b71c:	jne    40b72d <__swc_fn_e121059d_000171_4dbacba0+0x3d>
  40b71e:	mov    QWORD PTR [rsp+0x18],rax
  40b723:	call   410d00 <__swc_fn_e121059d_000119_591530fe>
  40b728:	mov    rax,QWORD PTR [rsp+0x18]
  40b72d:	mov    rcx,rax
  40b730:	xchg   QWORD PTR [rsi],rcx
  40b733:	add    rsp,0x30
  40b737:	pop    rsi
  40b738:	ret
  40b739:	add    BYTE PTR [rax],al
  40b73b:	add    BYTE PTR [rax],al
  40b73d:	add    BYTE PTR [rax],al
	...

000000000040b740 <__swc_fn_e121059d_000174_e17a224b>:
  40b740:	push   rsi
  40b741:	push   rdi
  40b742:	sub    rsp,0x8
  40b746:	mov    rsi,rdx
  40b749:	mov    rdi,rcx
  40b74c:	mov    rax,QWORD PTR [rsi+0x8]
  40b750:	test   rax,rax
  40b753:	je     40b75d <__swc_fn_e121059d_000174_e17a224b+0x1d>
  40b755:	mov    rcx,QWORD PTR [rsi]
  40b758:	mov    QWORD PTR [rax],rcx
  40b75b:	jmp    40b764 <__swc_fn_e121059d_000174_e17a224b+0x24>
  40b75d:	mov    rax,QWORD PTR [rsi]
  40b760:	mov    QWORD PTR [rdi+0x8],rax
  40b764:	mov    rax,QWORD PTR [rsi]
  40b767:	test   rax,rax
  40b76a:	je     40b774 <__swc_fn_e121059d_000174_e17a224b+0x34>
  40b76c:	mov    rcx,QWORD PTR [rsi+0x8]
  40b770:	mov    QWORD PTR [rax+0x8],rcx
  40b774:	mov    rcx,rdi
  40b777:	mov    rdx,QWORD PTR [rsi+0x10]
  40b77b:	mov    r8,QWORD PTR [rsi+0x18]
  40b77f:	mov    r9,0xffffffffffffffff
  40b786:	call   4118c0 <__swc_fn_e121059d_000173_1751ecdd>
  40b78b:	mov    QWORD PTR [rsi+0x18],0x0
  40b793:	mov    rax,QWORD PTR [rdi+0x8]
  40b797:	test   rax,rax
  40b79a:	jne    40b7ac <__swc_fn_e121059d_000174_e17a224b+0x6c>
  40b79c:	call   40b6f0 <__swc_fn_e121059d_000171_4dbacba0>
  40b7a1:	xor    ecx,ecx
  40b7a3:	mov    QWORD PTR [rax+0x8],rcx
  40b7a7:	xor    ecx,ecx
  40b7a9:	mov    QWORD PTR [rax],rcx
  40b7ac:	add    rsp,0x8
  40b7b0:	pop    rdi
  40b7b1:	pop    rsi
  40b7b2:	ret
	...

000000000040b7c0 <__swc_fn_e121059d_000177_2744b483>:
  40b7c0:	push   rbx
  40b7c1:	sub    rsp,0x70
  40b7c5:	cmp    rcx,0xffffffffffffffef
  40b7c9:	jbe    40b7d3 <__swc_fn_e121059d_000177_2744b483+0x13>
  40b7cb:	xor    eax,eax
  40b7cd:	add    rsp,0x70
  40b7d1:	pop    rbx
  40b7d2:	ret
  40b7d3:	vxorps xmm0,xmm0,xmm0
  40b7d7:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40b7dd:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40b7e3:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40b7e9:	vzeroupper
  40b7ec:	lea    rax,[rcx+0x10]
  40b7f0:	mov    QWORD PTR [rsp+0x50],rax
  40b7f5:	mov    DWORD PTR [rsp+0x60],0x10
  40b7fd:	mov    rcx,QWORD PTR [rip+0x1b53c]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40b804:	test   rcx,rcx
  40b807:	jne    40b819 <__swc_fn_e121059d_000177_2744b483+0x59>
  40b809:	call   40e940 <__swc_fn_e121059d_000166_56054fe7>
  40b80e:	lea    rcx,[rax+0x1]
  40b812:	mov    QWORD PTR [rip+0x1b527],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40b819:	dec    rcx
  40b81c:	call   40b620 <__swc_fn_e121059d_000168_39c041ad>
  40b821:	mov    rcx,QWORD PTR [rax]
  40b824:	lea    rdx,[rsp+0x8]
  40b829:	mov    rbx,QWORD PTR [rax+0x8]
  40b82d:	mov    rbx,QWORD PTR [rbx+0x8]
  40b831:	call   rbx
  40b833:	mov    rax,QWORD PTR [rsp+0x48]
  40b838:	test   rax,rax
  40b83b:	jne    40b845 <__swc_fn_e121059d_000177_2744b483+0x85>
  40b83d:	xor    eax,eax
  40b83f:	add    rsp,0x70
  40b843:	pop    rbx
  40b844:	ret
  40b845:	mov    rcx,QWORD PTR [rsp+0x50]
  40b84a:	mov    QWORD PTR [rax],rcx
  40b84d:	mov    QWORD PTR [rax+0x8],0x0
  40b855:	lea    rax,[rax+0x10]
  40b859:	add    rsp,0x70
  40b85d:	pop    rbx
  40b85e:	ret
	...

000000000040b860 <__swc_fn_e121059d_000001_0e26756e>:
  40b860:	vxorps xmm0,xmm0,xmm0
  40b864:	xor    eax,eax
  40b866:	cs nop WORD PTR [rax+rax*1+0x0]
  40b870:	cs nop WORD PTR [rax+rax*1+0x0]
  40b87a:	nop    WORD PTR [rax+rax*1+0x0]
  40b880:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40b885:	add    rax,0x10
  40b889:	cmp    rax,0x2080
  40b890:	jne    40b880 <__swc_fn_e121059d_000001_0e26756e+0x20>
  40b892:	ret
	...

000000000040b8a0 <__swc_fn_e121059d_000004_3deb8b54>:
  40b8a0:	push   rsi
  40b8a1:	push   rdi
  40b8a2:	push   r12
  40b8a4:	push   r13
  40b8a6:	push   r14
  40b8a8:	mov    rsi,rcx
  40b8ab:	mov    edi,r10d
  40b8ae:	mov    r12,rcx
  40b8b1:	mov    r13,r9
  40b8b4:	mov    ecx,DWORD PTR [rdx+0x28]
  40b8b7:	shlx   r14d,r8d,ecx
  40b8bc:	mov    rcx,rdx
  40b8bf:	mov    edx,r8d
  40b8c2:	call   40ecc0 <__swc_fn_e121059d_000011_71c91685>
  40b8c7:	mov    rcx,rax
  40b8ca:	mov    eax,DWORD PTR [r12+0x3c]
  40b8cf:	xor    edx,edx
  40b8d1:	div    rdi
  40b8d4:	vxorps xmm0,xmm0,xmm0
  40b8d8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40b8dc:	mov    QWORD PTR [r12+0x60],0x0
  40b8e5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40b8ea:	mov    QWORD PTR [r12+0x10],rcx
  40b8ef:	imul   rax,rdi
  40b8f3:	lea    rdx,[rcx+rax*1]
  40b8f7:	mov    QWORD PTR [r12+0x18],rdx
  40b8fc:	mov    QWORD PTR [r12+0x20],rcx
  40b901:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40b906:	mov    DWORD PTR [r12+0x28],0x0
  40b90f:	mov    DWORD PTR [r12+0x68],0x0
  40b918:	mov    BYTE PTR [r12+0x39],r13b
  40b91d:	mov    BYTE PTR [r12+0x3a],r14b
  40b922:	mov    BYTE PTR [r12+0x3b],0x1
  40b928:	mov    DWORD PTR [r12+0x6c],0x0
  40b931:	mov    rcx,r12
  40b934:	mov    edx,edi
  40b936:	call   40ec20 <__swc_fn_e121059d_000005_6a556171>
  40b93b:	pop    r14
  40b93d:	pop    r13
  40b93f:	pop    r12
  40b941:	pop    rdi
  40b942:	pop    rsi
  40b943:	ret
	...

000000000040b950 <__swc_fn_e121059d_000007_a7bfb091>:
  40b950:	mov    r8d,0x1
  40b956:	xor    eax,eax
  40b958:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40b95e:	test   eax,eax
  40b960:	jne    40b950 <__swc_fn_e121059d_000007_a7bfb091>
  40b962:	ret
	...

000000000040b970 <__swc_fn_e121059d_000010_0569f799>:
  40b970:	lea    r8,[rcx+0x60]
  40b974:	mov    rax,QWORD PTR [r8]
  40b977:	mov    r9,rax
  40b97a:	nop    WORD PTR [rax+rax*1+0x0]
  40b980:	mov    QWORD PTR [rdx],r9
  40b983:	mov    rax,r9
  40b986:	lock cmpxchg QWORD PTR [r8],rdx
  40b98b:	cmp    rax,r9
  40b98e:	jne    40b9f7 <__swc_fn_e121059d_000010_0569f799+0x87>
  40b990:	mov    eax,DWORD PTR [rcx+0x6c]
  40b993:	test   eax,eax
  40b995:	je     40b9f6 <__swc_fn_e121059d_000010_0569f799+0x86>
  40b997:	lea    rdx,[rcx+0x70]
  40b99b:	mov    r9d,0x1
  40b9a1:	xor    eax,eax
  40b9a3:	lock cmpxchg DWORD PTR [rdx],r9d
  40b9a8:	test   eax,eax
  40b9aa:	jne    40b9f6 <__swc_fn_e121059d_000010_0569f799+0x86>
  40b9ac:	mov    rax,rcx
  40b9af:	and    rax,0xffffffffffc00000
  40b9b6:	mov    rax,QWORD PTR [rax+0x8]
  40b9ba:	test   rax,rax
  40b9bd:	jne    40b9c5 <__swc_fn_e121059d_000010_0569f799+0x55>
  40b9bf:	xor    eax,eax
  40b9c1:	xchg   DWORD PTR [rdx],eax
  40b9c3:	jmp    40b9f6 <__swc_fn_e121059d_000010_0569f799+0x86>
  40b9c5:	lea    rdx,[rax+0x2a80]
  40b9cc:	mov    rax,QWORD PTR [rdx]
  40b9cf:	mov    r8,rax
  40b9d2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b9dc:	nop    DWORD PTR [rax+0x0]
  40b9e0:	mov    QWORD PTR [rcx+0x78],r8
  40b9e4:	mov    rax,r8
  40b9e7:	lock cmpxchg QWORD PTR [rdx],rcx
  40b9ec:	cmp    rax,r8
  40b9ef:	je     40b9f6 <__swc_fn_e121059d_000010_0569f799+0x86>
  40b9f1:	mov    r8,rax
  40b9f4:	jmp    40b9e0 <__swc_fn_e121059d_000010_0569f799+0x70>
  40b9f6:	ret
  40b9f7:	mov    r9,rax
  40b9fa:	jmp    40b980 <__swc_fn_e121059d_000010_0569f799+0x10>
	...

000000000040ba00 <__swc_fn_e121059d_000013_7b85dbab>:
  40ba00:	push   rsi
  40ba01:	push   rdi
  40ba02:	push   r12
  40ba04:	push   r13
  40ba06:	push   r14
  40ba08:	push   r15
  40ba0a:	push   rbx
  40ba0b:	sub    rsp,0x30
  40ba0f:	mov    QWORD PTR [rsp+0x18],r8
  40ba14:	mov    rsi,rcx
  40ba17:	mov    rdi,rdx
  40ba1a:	mov    rdx,QWORD PTR [rsi+0x40]
  40ba1e:	xchg   ax,ax
  40ba20:	mov    rax,rdx
  40ba23:	not    rax
  40ba26:	and    rax,QWORD PTR [rsi+0x20]
  40ba2a:	test   rax,rax
  40ba2d:	jne    40ba41 <__swc_fn_e121059d_000013_7b85dbab+0x41>
  40ba2f:	xor    eax,eax
  40ba31:	add    rsp,0x30
  40ba35:	pop    rbx
  40ba36:	pop    r15
  40ba38:	pop    r14
  40ba3a:	pop    r13
  40ba3c:	pop    r12
  40ba3e:	pop    rdi
  40ba3f:	pop    rsi
  40ba40:	ret
  40ba41:	xor    ecx,ecx
  40ba43:	tzcnt  rcx,rax
  40ba48:	lea    r12,[rsp+0x8]
  40ba4d:	mov    DWORD PTR [rsp+0x8],ecx
  40ba51:	mov    r13d,0x1
  40ba57:	shl    r13,cl
  40ba5a:	mov    rcx,rdx
  40ba5d:	or     rcx,r13
  40ba60:	mov    rax,rdx
  40ba63:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40ba69:	cmp    rax,rdx
  40ba6c:	je     40ba73 <__swc_fn_e121059d_000013_7b85dbab+0x73>
  40ba6e:	mov    rdx,rax
  40ba71:	jmp    40ba20 <__swc_fn_e121059d_000013_7b85dbab+0x20>
  40ba73:	mov    eax,DWORD PTR [r12]
  40ba77:	shl    rax,0x4
  40ba7b:	lea    r14,[rsi+rax*8+0x80]
  40ba83:	mov    rcx,rsi
  40ba86:	mov    rax,r12
  40ba89:	mov    edx,DWORD PTR [rax]
  40ba8b:	call   40ecc0 <__swc_fn_e121059d_000011_71c91685>
  40ba90:	mov    r15,rax
  40ba93:	mov    rcx,rsi
  40ba96:	mov    rdx,r13
  40ba99:	call   40ee20 <__swc_fn_e121059d_000017_f003fc47>
  40ba9e:	test   al,al
  40baa0:	je     40bad8 <__swc_fn_e121059d_000013_7b85dbab+0xd8>
  40baa2:	mov    ecx,DWORD PTR [r14+0x3c]
  40baa6:	lea    rdx,[rip+0x185ab]        # 424058 <__swc_bss_base_e121059d+0x18>
  40baad:	mov    r8,QWORD PTR [rip+0x185a4]        # 424058 <__swc_bss_base_e121059d+0x18>
  40bab4:	cs nop WORD PTR [rax+rax*1+0x0]
  40babe:	xchg   ax,ax
  40bac0:	mov    r9,r8
  40bac3:	sub    r9,rcx
  40bac6:	mov    rax,r8
  40bac9:	lock cmpxchg QWORD PTR [rdx],r9
  40bace:	cmp    rax,r8
  40bad1:	je     40bb39 <__swc_fn_e121059d_000013_7b85dbab+0x139>
  40bad3:	mov    r8,rax
  40bad6:	jmp    40bac0 <__swc_fn_e121059d_000013_7b85dbab+0xc0>
  40bad8:	mov    rcx,rsi
  40badb:	mov    rax,r12
  40bade:	mov    edx,DWORD PTR [rax]
  40bae0:	call   407450 <__swc_fn_e121059d_000012_be38a1a2>
  40bae5:	mov    rcx,r15
  40bae8:	and    rcx,0xffffffffffff0000
  40baef:	lea    rcx,[rcx+0x10000]
  40baf6:	mov    rbx,rax
  40baf9:	cmp    rax,rcx
  40bafc:	cmova  rbx,rcx
  40bb00:	mov    rax,rbx
  40bb03:	sub    rax,r15
  40bb06:	mov    rcx,r15
  40bb09:	mov    rdx,rax
  40bb0c:	call   4072a0 <__swc_fn_e121059d_000003_81215399>
  40bb11:	test   al,al
  40bb13:	jne    40bb32 <__swc_fn_e121059d_000013_7b85dbab+0x132>
  40bb15:	mov    rcx,rsi
  40bb18:	mov    rdx,r13
  40bb1b:	call   407600 <__swc_fn_e121059d_000018_77ece227>
  40bb20:	xor    eax,eax
  40bb22:	add    rsp,0x30
  40bb26:	pop    rbx
  40bb27:	pop    r15
  40bb29:	pop    r14
  40bb2b:	pop    r13
  40bb2d:	pop    r12
  40bb2f:	pop    rdi
  40bb30:	pop    rsi
  40bb31:	ret
  40bb32:	sub    rbx,r15
  40bb35:	mov    DWORD PTR [r14+0x3c],ebx
  40bb39:	mov    rcx,r14
  40bb3c:	mov    rdx,rsi
  40bb3f:	mov    r8d,DWORD PTR [r12]
  40bb43:	mov    r9d,edi
  40bb46:	mov    rbx,QWORD PTR [rsp+0x18]
  40bb4b:	mov    r10d,ebx
  40bb4e:	call   40b8a0 <__swc_fn_e121059d_000004_3deb8b54>
  40bb53:	mov    rax,r14
  40bb56:	add    rsp,0x30
  40bb5a:	pop    rbx
  40bb5b:	pop    r15
  40bb5d:	pop    r14
  40bb5f:	pop    r13
  40bb61:	pop    r12
  40bb63:	pop    rdi
  40bb64:	pop    rsi
  40bb65:	ret
	...

000000000040bb70 <__swc_fn_e121059d_000016_a0b588d0>:
  40bb70:	mov    r8,QWORD PTR [rcx+0x48]
  40bb74:	cs nop WORD PTR [rax+rax*1+0x0]
  40bb7e:	xchg   ax,ax
  40bb80:	mov    r9,r8
  40bb83:	or     r9,rdx
  40bb86:	mov    rax,r8
  40bb89:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40bb8f:	cmp    rax,r8
  40bb92:	jne    40bb95 <__swc_fn_e121059d_000016_a0b588d0+0x25>
  40bb94:	ret
  40bb95:	mov    r8,rax
  40bb98:	jmp    40bb80 <__swc_fn_e121059d_000016_a0b588d0+0x10>
  40bb9a:	add    BYTE PTR [rax],al
  40bb9c:	add    BYTE PTR [rax],al
	...

000000000040bba0 <__swc_fn_e121059d_000019_447bb610>:
  40bba0:	push   rsi
  40bba1:	push   rdi
  40bba2:	push   r12
  40bba4:	mov    rsi,rcx
  40bba7:	xor    edi,edi
  40bba9:	lea    r12,[rip+0x184b8]        # 424068 <__swc_bss_base_e121059d+0x28>
  40bbb0:	mov    eax,DWORD PTR [r12]
  40bbb4:	xor    ecx,ecx
  40bbb6:	test   rax,rax
  40bbb9:	jbe    40bbf4 <__swc_fn_e121059d_000019_447bb610+0x54>
  40bbbb:	nop    DWORD PTR [rax+rax*1+0x0]
  40bbc0:	lea    rdx,[rip+0x184a9]        # 424070 <__swc_bss_base_e121059d+0x30>
  40bbc7:	mov    r8d,ecx
  40bbca:	lea    r8,[r8+r8*2]
  40bbce:	lea    r8,[rdx+r8*8]
  40bbd2:	mov    rdx,QWORD PTR [r8+0x10]
  40bbd6:	add    rdx,0x400000
  40bbdd:	cmp    rdx,0x40000000
  40bbe4:	ja     40bbeb <__swc_fn_e121059d_000019_447bb610+0x4b>
  40bbe6:	mov    rdi,r8
  40bbe9:	jmp    40bbf4 <__swc_fn_e121059d_000019_447bb610+0x54>
  40bbeb:	add    rcx,0x1
  40bbef:	cmp    rcx,rax
  40bbf2:	jb     40bbc0 <__swc_fn_e121059d_000019_447bb610+0x20>
  40bbf4:	test   rdi,rdi
  40bbf7:	jne    40bc83 <__swc_fn_e121059d_000019_447bb610+0xe3>
  40bbfd:	cmp    DWORD PTR [r12],0x10
  40bc02:	jae    40bc6b <__swc_fn_e121059d_000019_447bb610+0xcb>
  40bc04:	mov    ecx,0x40400000
  40bc09:	call   40ebe0 <__swc_fn_e121059d_000002_102336c4>
  40bc0e:	test   rax,rax
  40bc11:	je     40bc6b <__swc_fn_e121059d_000019_447bb610+0xcb>
  40bc13:	lea    rcx,[rip+0x18456]        # 424070 <__swc_bss_base_e121059d+0x30>
  40bc1a:	mov    edx,DWORD PTR [r12]
  40bc1e:	lea    rdx,[rdx+rdx*2]
  40bc22:	lea    rdx,[rcx+rdx*8]
  40bc26:	mov    QWORD PTR [rdx],rax
  40bc29:	lea    rax,[rax+0x3fffff]
  40bc30:	and    rax,0xffffffffffc00000
  40bc37:	mov    QWORD PTR [rdx+0x8],rax
  40bc3b:	mov    QWORD PTR [rdx+0x10],0x0
  40bc43:	mov    edx,DWORD PTR [rip+0x1841f]        # 424068 <__swc_bss_base_e121059d+0x28>
  40bc49:	nop    DWORD PTR [rax+0x0]
  40bc50:	lea    r9d,[rdx+0x1]
  40bc54:	mov    rax,rdx
  40bc57:	lock cmpxchg DWORD PTR [r12],r9d
  40bc5d:	mov    r8d,eax
  40bc60:	cmp    eax,edx
  40bc62:	je     40bc72 <__swc_fn_e121059d_000019_447bb610+0xd2>
  40bc64:	mov    rdx,r8
  40bc67:	jmp    40bc50 <__swc_fn_e121059d_000019_447bb610+0xb0>
  40bc69:	jmp    40bc72 <__swc_fn_e121059d_000019_447bb610+0xd2>
  40bc6b:	xor    eax,eax
  40bc6d:	pop    r12
  40bc6f:	pop    rdi
  40bc70:	pop    rsi
  40bc71:	ret
  40bc72:	mov    eax,DWORD PTR [rip+0x183f0]        # 424068 <__swc_bss_base_e121059d+0x28>
  40bc78:	sub    eax,0x1
  40bc7b:	lea    rdi,[rax+rax*2]
  40bc7f:	lea    rdi,[rcx+rdi*8]
  40bc83:	mov    r12,QWORD PTR [rdi+0x8]
  40bc87:	add    r12,QWORD PTR [rdi+0x10]
  40bc8b:	mov    rcx,r12
  40bc8e:	mov    edx,0x3000
  40bc93:	call   4072a0 <__swc_fn_e121059d_000003_81215399>
  40bc98:	test   al,al
  40bc9a:	jne    40bca3 <__swc_fn_e121059d_000019_447bb610+0x103>
  40bc9c:	xor    eax,eax
  40bc9e:	pop    r12
  40bca0:	pop    rdi
  40bca1:	pop    rsi
  40bca2:	ret
  40bca3:	vxorps xmm0,xmm0,xmm0
  40bca7:	xor    eax,eax
  40bca9:	cs nop WORD PTR [rax+rax*1+0x0]
  40bcb3:	cs nop WORD PTR [rax+rax*1+0x0]
  40bcbd:	nop    DWORD PTR [rax]
  40bcc0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40bcc6:	add    rax,0x10
  40bcca:	cmp    rax,0x3000
  40bcd1:	jne    40bcc0 <__swc_fn_e121059d_000019_447bb610+0x120>
  40bcd3:	mov    DWORD PTR [r12+0x28],esi
  40bcd8:	mov    eax,0x40
  40bcdd:	mov    ecx,esi
  40bcdf:	shr    eax,cl
  40bce1:	mov    DWORD PTR [r12+0x2c],eax
  40bce6:	cmp    DWORD PTR [r12+0x2c],0x40
  40bcec:	jb     40bcf7 <__swc_fn_e121059d_000019_447bb610+0x157>
  40bcee:	mov    rax,0xffffffffffffffff
  40bcf5:	jmp    40bd07 <__swc_fn_e121059d_000019_447bb610+0x167>
  40bcf7:	mov    eax,0x1
  40bcfc:	mov    ecx,DWORD PTR [r12+0x2c]
  40bd01:	shl    rax,cl
  40bd04:	dec    rax
  40bd07:	mov    QWORD PTR [r12+0x20],rax
  40bd0c:	mov    DWORD PTR [r12],0x4e540001
  40bd14:	mov    DWORD PTR [r12+0x4],0x53474d45
  40bd1d:	add    QWORD PTR [rdi+0x10],0x400000
  40bd25:	mov    rax,r12
  40bd28:	pop    r12
  40bd2a:	pop    rdi
  40bd2b:	pop    rsi
  40bd2c:	ret
  40bd2d:	add    BYTE PTR [rax],al
	...

000000000040bd30 <__swc_fn_e121059d_000022_53fc00d2>:
  40bd30:	mov    eax,0x1
  40bd35:	mov    edx,DWORD PTR [rip+0x1832d]        # 424068 <__swc_bss_base_e121059d+0x28>
  40bd3b:	cmp    eax,edx
  40bd3d:	jae    40bd8b <__swc_fn_e121059d_000022_53fc00d2+0x5b>
  40bd3f:	nop
  40bd40:	lea    r8,[rip+0x18329]        # 424070 <__swc_bss_base_e121059d+0x30>
  40bd47:	lea    r9,[rax+rax*2]
  40bd4b:	lea    r9,[r8+r9*8]
  40bd4f:	mov    r8,rcx
  40bd52:	sub    r8,QWORD PTR [r9+0x8]
  40bd56:	mov    r9,QWORD PTR [r9+0x10]
  40bd5a:	cmp    r8,r9
  40bd5d:	jae    40bd85 <__swc_fn_e121059d_000022_53fc00d2+0x55>
  40bd5f:	mov    rax,rcx
  40bd62:	and    rax,0xffffffffffc00000
  40bd69:	shr    rcx,0x10
  40bd6d:	and    ecx,0x3f
  40bd70:	mov    edx,DWORD PTR [rax+0x28]
  40bd73:	shrx   ecx,ecx,edx
  40bd78:	shl    rcx,0x4
  40bd7c:	lea    rax,[rax+rcx*8+0x80]
  40bd84:	ret
  40bd85:	inc    eax
  40bd87:	cmp    eax,edx
  40bd89:	jb     40bd40 <__swc_fn_e121059d_000022_53fc00d2+0x10>
  40bd8b:	xor    eax,eax
  40bd8d:	ret
	...

000000000040bd90 <__swc_fn_e121059d_000025_e876734d>:
  40bd90:	vxorps xmm0,xmm0,xmm0
  40bd94:	vmovups XMMWORD PTR [rcx],xmm0
  40bd98:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40bd9d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40bda2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40bda7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40bdac:	mov    QWORD PTR [rcx+0x50],0x0
  40bdb4:	ret
	...

000000000040bdc0 <__swc_fn_e121059d_000028_e876734d>:
  40bdc0:	vxorps xmm0,xmm0,xmm0
  40bdc4:	xor    eax,eax
  40bdc6:	cs nop WORD PTR [rax+rax*1+0x0]
  40bdd0:	cs nop WORD PTR [rax+rax*1+0x0]
  40bdda:	nop    WORD PTR [rax+rax*1+0x0]
  40bde0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40bde5:	add    rax,0x10
  40bde9:	cmp    rax,0x9b0
  40bdf0:	jne    40bde0 <__swc_fn_e121059d_000028_e876734d+0x20>
  40bdf2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40bdfd:	ret
	...

000000000040be00 <__swc_fn_e121059d_000031_3c3e930e>:
  40be00:	push   rsi
  40be01:	push   rdi
  40be02:	sub    rsp,0x8
  40be06:	lea    rsi,[rip+0x161fb]        # 422008 <__swc_data_base_e121059d+0x8>
  40be0d:	mov    rax,QWORD PTR [rsi]
  40be10:	mov    ecx,0xffffffff
  40be15:	cmp    rax,rcx
  40be18:	je     40be21 <__swc_fn_e121059d_000031_3c3e930e+0x21>
  40be1a:	add    rsp,0x8
  40be1e:	pop    rdi
  40be1f:	pop    rsi
  40be20:	ret
  40be21:	mov    rcx,QWORD PTR [rip+0x7290]        # 4130b8 <__swc_fn_e121059d_000179_68d30882+0x16b8>
  40be28:	call   40ddf0 <__swc_fn_e121059d_000127_9e9697c7>
  40be2d:	mov    rcx,rax
  40be30:	mov    eax,0xffffffff
  40be35:	lock cmpxchg QWORD PTR [rsi],rcx
  40be3a:	mov    rdi,rax
  40be3d:	mov    eax,0xffffffff
  40be42:	cmp    rdi,rax
  40be45:	je     40be56 <__swc_fn_e121059d_000031_3c3e930e+0x56>
  40be47:	call   410f50 <__swc_fn_e121059d_000128_f163135d>
  40be4c:	mov    rax,rdi
  40be4f:	add    rsp,0x8
  40be53:	pop    rdi
  40be54:	pop    rsi
  40be55:	ret
  40be56:	mov    rax,rcx
  40be59:	add    rsp,0x8
  40be5d:	pop    rdi
  40be5e:	pop    rsi
  40be5f:	ret

000000000040be60 <__swc_fn_e121059d_000034_cf5ba7bd>:
  40be60:	sub    rsp,0x8
  40be64:	vxorps xmm0,xmm0,xmm0
  40be68:	xor    eax,eax
  40be6a:	cs nop WORD PTR [rax+rax*1+0x0]
  40be74:	cs nop WORD PTR [rax+rax*1+0x0]
  40be7e:	xchg   ax,ax
  40be80:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40be85:	add    rax,0x10
  40be89:	cmp    rax,0x2b00
  40be90:	jne    40be80 <__swc_fn_e121059d_000034_cf5ba7bd+0x20>
  40be92:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40be9c:	xor    al,al
  40be9e:	mov    rdx,rax
  40bea1:	xor    al,al
  40bea3:	mov    r8,rax
  40bea6:	xor    al,al
  40bea8:	mov    r9,rax
  40beab:	xor    al,al
  40bead:	mov    r10,rax
  40beb0:	xor    al,al
  40beb2:	mov    r11,rax
  40beb5:	call   40f050 <__swc_fn_e121059d_000035_ab2e8c35>
  40beba:	add    rsp,0x8
  40bebe:	ret
	...

000000000040bec0 <__swc_fn_e121059d_000037_1e381f55>:
  40bec0:	push   rsi
  40bec1:	push   rdi
  40bec2:	push   r12
  40bec4:	mov    rsi,r8
  40bec7:	mov    rdi,rdx
  40beca:	mov    rcx,rdx
  40becd:	call   40ebe0 <__swc_fn_e121059d_000002_102336c4>
  40bed2:	mov    r12,rax
  40bed5:	test   rax,rax
  40bed8:	jne    40bee1 <__swc_fn_e121059d_000037_1e381f55+0x21>
  40beda:	xor    eax,eax
  40bedc:	pop    r12
  40bede:	pop    rdi
  40bedf:	pop    rsi
  40bee0:	ret
  40bee1:	mov    rcx,r12
  40bee4:	mov    rdx,rsi
  40bee7:	call   4072a0 <__swc_fn_e121059d_000003_81215399>
  40beec:	test   al,al
  40beee:	jne    40bf02 <__swc_fn_e121059d_000037_1e381f55+0x42>
  40bef0:	mov    rcx,r12
  40bef3:	mov    rdx,rdi
  40bef6:	call   409850 <__swc_fn_e121059d_000114_4e83a03a>
  40befb:	xor    eax,eax
  40befd:	pop    r12
  40beff:	pop    rdi
  40bf00:	pop    rsi
  40bf01:	ret
  40bf02:	mov    rax,r12
  40bf05:	pop    r12
  40bf07:	pop    rdi
  40bf08:	pop    rsi
  40bf09:	ret
	...

000000000040bf20 <__swc_fn_e121059d_000040_8029566e>:
  40bf20:	push   rsi
  40bf21:	push   rdi
  40bf22:	push   r12
  40bf24:	mov    rsi,rcx
  40bf27:	mov    edx,0x9b8
  40bf2c:	call   40f0c0 <__swc_fn_e121059d_000038_292d55e5>
  40bf31:	mov    rdi,rax
  40bf34:	test   rax,rax
  40bf37:	jne    40bf40 <__swc_fn_e121059d_000040_8029566e+0x20>
  40bf39:	xor    eax,eax
  40bf3b:	pop    r12
  40bf3d:	pop    rdi
  40bf3e:	pop    rsi
  40bf3f:	ret
  40bf40:	vxorps xmm0,xmm0,xmm0
  40bf44:	xor    eax,eax
  40bf46:	cs nop WORD PTR [rax+rax*1+0x0]
  40bf50:	cs nop WORD PTR [rax+rax*1+0x0]
  40bf5a:	nop    WORD PTR [rax+rax*1+0x0]
  40bf60:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40bf65:	add    rax,0x10
  40bf69:	cmp    rax,0x9b0
  40bf70:	jne    40bf60 <__swc_fn_e121059d_000040_8029566e+0x40>
  40bf72:	mov    QWORD PTR [rdi+0x9b0],0x0
  40bf7d:	mov    QWORD PTR [rdi],rsi
  40bf80:	call   411000 <__swc_fn_e121059d_000131_375c7357>
  40bf85:	mov    QWORD PTR [rdi+0x18],rax
  40bf89:	lea    r12,[rsi+0x10]
  40bf8d:	mov    rcx,r12
  40bf90:	call   40e040 <__swc_fn_e121059d_000136_db32cc57>
  40bf95:	mov    rax,QWORD PTR [rsi+0x20]
  40bf99:	mov    QWORD PTR [rdi+0x8],rax
  40bf9d:	mov    rax,QWORD PTR [rsi+0x20]
  40bfa1:	test   rax,rax
  40bfa4:	je     40bfaa <__swc_fn_e121059d_000040_8029566e+0x8a>
  40bfa6:	mov    QWORD PTR [rax+0x10],rdi
  40bfaa:	mov    QWORD PTR [rsi+0x20],rdi
  40bfae:	mov    rcx,r12
  40bfb1:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40bfb6:	mov    rax,rdi
  40bfb9:	pop    r12
  40bfbb:	pop    rdi
  40bfbc:	pop    rsi
  40bfbd:	ret
	...

000000000040bfc0 <__swc_fn_e121059d_000043_47ff6d9b>:
  40bfc0:	mov    rax,QWORD PTR [rdx+0x10]
  40bfc4:	test   rax,rax
  40bfc7:	je     40bfd3 <__swc_fn_e121059d_000043_47ff6d9b+0x13>
  40bfc9:	mov    rcx,QWORD PTR [rdx+0x8]
  40bfcd:	mov    QWORD PTR [rax+0x8],rcx
  40bfd1:	jmp    40bfdb <__swc_fn_e121059d_000043_47ff6d9b+0x1b>
  40bfd3:	mov    rax,QWORD PTR [rdx+0x8]
  40bfd7:	mov    QWORD PTR [rcx+0x20],rax
  40bfdb:	mov    rax,QWORD PTR [rdx+0x8]
  40bfdf:	test   rax,rax
  40bfe2:	je     40bfec <__swc_fn_e121059d_000043_47ff6d9b+0x2c>
  40bfe4:	mov    rcx,QWORD PTR [rdx+0x10]
  40bfe8:	mov    QWORD PTR [rax+0x10],rcx
  40bfec:	vxorps xmm0,xmm0,xmm0
  40bff0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40bff5:	ret
	...

000000000040c000 <__swc_fn_e121059d_000046_b28a6ee7>:
  40c000:	sub    rsp,0x8
  40c004:	mov    r9,r8
  40c007:	mov    r10,rdx
  40c00a:	call   40f170 <__swc_fn_e121059d_000044_fe6bbfdb>
  40c00f:	mov    eax,0x1
  40c014:	xchg   DWORD PTR [r9+0x6c],eax
  40c018:	mov    rax,QWORD PTR [r9+0x60]
  40c01c:	test   rax,rax
  40c01f:	je     40c063 <__swc_fn_e121059d_000046_b28a6ee7+0x63>
  40c021:	xor    eax,eax
  40c023:	xchg   DWORD PTR [r9+0x6c],eax
  40c027:	movzx  eax,BYTE PTR [r9+0x39]
  40c02c:	lea    rax,[rax+rax*4]
  40c030:	lea    rax,[r10+rax*8+0x28]
  40c035:	mov    QWORD PTR [r9+0x50],0x0
  40c03d:	mov    rcx,QWORD PTR [rax+0x8]
  40c041:	mov    QWORD PTR [r9+0x48],rcx
  40c045:	mov    rcx,QWORD PTR [rax+0x8]
  40c049:	test   rcx,rcx
  40c04c:	je     40c054 <__swc_fn_e121059d_000046_b28a6ee7+0x54>
  40c04e:	mov    QWORD PTR [rcx+0x50],r9
  40c052:	jmp    40c058 <__swc_fn_e121059d_000046_b28a6ee7+0x58>
  40c054:	mov    QWORD PTR [rax+0x10],r9
  40c058:	mov    QWORD PTR [rax+0x8],r9
  40c05c:	xor    eax,eax
  40c05e:	add    rsp,0x8
  40c062:	ret
  40c063:	movzx  eax,BYTE PTR [r9+0x39]
  40c068:	lea    rax,[rax+rax*4]
  40c06c:	lea    rax,[r10+rax*8+0x28]
  40c071:	mov    QWORD PTR [r9+0x50],0x0
  40c079:	mov    rcx,QWORD PTR [rax+0x18]
  40c07d:	mov    QWORD PTR [r9+0x48],rcx
  40c081:	mov    rcx,QWORD PTR [rax+0x18]
  40c085:	test   rcx,rcx
  40c088:	je     40c08e <__swc_fn_e121059d_000046_b28a6ee7+0x8e>
  40c08a:	mov    QWORD PTR [rcx+0x50],r9
  40c08e:	mov    QWORD PTR [rax+0x18],r9
  40c092:	mov    eax,0x1
  40c097:	add    rsp,0x8
  40c09b:	ret
  40c09c:	add    BYTE PTR [rax],al
	...

000000000040c0a0 <__swc_fn_e121059d_000049_f6a485a2>:
  40c0a0:	push   r12
  40c0a2:	push   r13
  40c0a4:	push   rdi
  40c0a5:	push   rsi
  40c0a6:	push   r14
  40c0a8:	push   r15
  40c0aa:	sub    rsp,0x178
  40c0b1:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40c0ba:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40c0c3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40c0cc:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40c0d5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40c0de:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40c0e7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40c0f0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40c0f9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40c102:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40c10b:	mov    r12,rcx
  40c10e:	lea    rax,[rip+0x180eb]        # 424200 <__swc_bss_base_e121059d+0x1c0>
  40c115:	mov    rcx,QWORD PTR [rax]
  40c118:	mov    r13,rcx
  40c11b:	test   rcx,rcx
  40c11e:	jne    40c12e <__swc_fn_e121059d_000049_f6a485a2+0x8e>
  40c120:	mov    r13d,0x1dcd6500
  40c126:	mov    ecx,0x1dcd6500
  40c12b:	xchg   QWORD PTR [rax],rcx
  40c12e:	lea    rax,[rip+0x15ecb]        # 422000 <__swc_data_base_e121059d>
  40c135:	mov    rax,QWORD PTR [rax]
  40c138:	cmp    rax,0xffffffffffffffff
  40c13c:	je     40c14b <__swc_fn_e121059d_000049_f6a485a2+0xab>
  40c13e:	mov    eax,eax
  40c140:	mov    edi,eax
  40c142:	xor    eax,eax
  40c144:	call   407000 <pthread_getspecific@plt>
  40c149:	jmp    40c14d <__swc_fn_e121059d_000049_f6a485a2+0xad>
  40c14b:	xor    eax,eax
  40c14d:	test   rax,rax
  40c150:	jne    40c15f <__swc_fn_e121059d_000049_f6a485a2+0xbf>
  40c152:	call   40be00 <__swc_fn_e121059d_000031_3c3e930e>
  40c157:	mov    rcx,rax
  40c15a:	call   409ba0 <__swc_fn_e121059d_000129_8d8a7dd2>
  40c15f:	test   rax,rax
  40c162:	je     40c174 <__swc_fn_e121059d_000049_f6a485a2+0xd4>
  40c164:	cmp    QWORD PTR [rax],r12
  40c167:	jne    40c174 <__swc_fn_e121059d_000049_f6a485a2+0xd4>
  40c169:	cmp    DWORD PTR [rax+0x20],0x0
  40c16d:	jne    40c174 <__swc_fn_e121059d_000049_f6a485a2+0xd4>
  40c16f:	mov    rsi,rax
  40c172:	jmp    40c176 <__swc_fn_e121059d_000049_f6a485a2+0xd6>
  40c174:	xor    esi,esi
  40c176:	lea    rdi,[r12+0x2a88]
  40c17e:	mov    r14,QWORD PTR [rdi]
  40c181:	test   r14,r14
  40c184:	jne    40c1d3 <__swc_fn_e121059d_000049_f6a485a2+0x133>
  40c186:	lea    rax,[rip+0x17ecb]        # 424058 <__swc_bss_base_e121059d+0x18>
  40c18d:	mov    rax,QWORD PTR [rax]
  40c190:	test   rax,rax
  40c193:	setne  al
  40c196:	jne    40c1ba <__swc_fn_e121059d_000049_f6a485a2+0x11a>
  40c198:	mov    rax,QWORD PTR [r12+0x2a70]
  40c1a0:	test   rax,rax
  40c1a3:	setne  al
  40c1a6:	jne    40c1ba <__swc_fn_e121059d_000049_f6a485a2+0x11a>
  40c1a8:	test   rsi,rsi
  40c1ab:	setne  al
  40c1ae:	je     40c1ba <__swc_fn_e121059d_000049_f6a485a2+0x11a>
  40c1b0:	cmp    DWORD PTR [rsi+0x730],0x0
  40c1b7:	setne  al
  40c1ba:	test   al,al
  40c1bc:	je     40c1ce <__swc_fn_e121059d_000049_f6a485a2+0x12e>
  40c1be:	call   409c50 <__swc_fn_e121059d_000132_91db8856>
  40c1c3:	lea    rcx,[rax+r13*1]
  40c1c7:	xor    eax,eax
  40c1c9:	lock cmpxchg QWORD PTR [rdi],rcx
  40c1ce:	jmp    40c2d3 <__swc_fn_e121059d_000049_f6a485a2+0x233>
  40c1d3:	call   409c50 <__swc_fn_e121059d_000132_91db8856>
  40c1d8:	mov    r15,rax
  40c1db:	cmp    rax,r14
  40c1de:	jb     40c1ef <__swc_fn_e121059d_000049_f6a485a2+0x14f>
  40c1e0:	xor    ecx,ecx
  40c1e2:	mov    rax,r14
  40c1e5:	lock cmpxchg QWORD PTR [rdi],rcx
  40c1ea:	cmp    rax,r14
  40c1ed:	je     40c1f4 <__swc_fn_e121059d_000049_f6a485a2+0x154>
  40c1ef:	jmp    40c2d3 <__swc_fn_e121059d_000049_f6a485a2+0x233>
  40c1f4:	test   rsi,rsi
  40c1f7:	je     40c212 <__swc_fn_e121059d_000049_f6a485a2+0x172>
  40c1f9:	cmp    r15,r13
  40c1fc:	jb     40c212 <__swc_fn_e121059d_000049_f6a485a2+0x172>
  40c1fe:	mov    rax,r15
  40c201:	sub    rax,r13
  40c204:	mov    rcx,r12
  40c207:	mov    rdx,rsi
  40c20a:	mov    r8,rax
  40c20d:	call   40f5b0 <__swc_fn_e121059d_000059_ee6a254c>
  40c212:	lea    rsi,[r12+0x10]
  40c217:	mov    rcx,rsi
  40c21a:	call   40e040 <__swc_fn_e121059d_000136_db32cc57>
  40c21f:	mov    rax,QWORD PTR [r12+0x18]
  40c224:	mov    rdi,rax
  40c227:	test   rdi,rdi
  40c22a:	je     40c254 <__swc_fn_e121059d_000049_f6a485a2+0x1b4>
  40c22c:	cs nop WORD PTR [rax+rax*1+0x0]
  40c236:	cs nop WORD PTR [rax+rax*1+0x0]
  40c240:	mov    rcx,rdi
  40c243:	call   407470 <__swc_fn_e121059d_000015_96cb1311>
  40c248:	mov    rax,QWORD PTR [rdi+0x10]
  40c24c:	mov    rdi,rax
  40c24f:	test   rax,rax
  40c252:	jne    40c240 <__swc_fn_e121059d_000049_f6a485a2+0x1a0>
  40c254:	mov    rcx,rsi
  40c257:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40c25c:	mov    rcx,r12
  40c25f:	call   40e040 <__swc_fn_e121059d_000136_db32cc57>
  40c264:	xor    esi,esi
  40c266:	cs nop WORD PTR [rax+rax*1+0x0]
  40c270:	mov    rax,QWORD PTR [r12+0x2a70]
  40c278:	cmp    rsi,rax
  40c27b:	jae    40c2cb <__swc_fn_e121059d_000049_f6a485a2+0x22b>
  40c27d:	lea    rax,[rsi+rsi*4]
  40c281:	lea    rax,[r12+rax*8+0x268]
  40c289:	mov    r8,QWORD PTR [rax]
  40c28c:	mov    r9,QWORD PTR [rax+0x8]
  40c290:	mov    r10,QWORD PTR [rax+0x10]
  40c294:	mov    rax,QWORD PTR [rax+0x20]
  40c298:	cmp    rax,r15
  40c29b:	jae    40c2a8 <__swc_fn_e121059d_000049_f6a485a2+0x208>
  40c29d:	mov    rcx,r15
  40c2a0:	sub    rcx,rax
  40c2a3:	cmp    rcx,r13
  40c2a6:	jae    40c2ad <__swc_fn_e121059d_000049_f6a485a2+0x20d>
  40c2a8:	inc    rsi
  40c2ab:	jmp    40c270 <__swc_fn_e121059d_000049_f6a485a2+0x1d0>
  40c2ad:	mov    rcx,r12
  40c2b0:	mov    rdx,rsi
  40c2b3:	call   40f560 <__swc_fn_e121059d_000056_87dc216f>
  40c2b8:	mov    rcx,r12
  40c2bb:	mov    rdx,r8
  40c2be:	mov    r8,r9
  40c2c1:	mov    r9,r10
  40c2c4:	call   407750 <__swc_fn_e121059d_000039_9ae4348f>
  40c2c9:	jmp    40c270 <__swc_fn_e121059d_000049_f6a485a2+0x1d0>
  40c2cb:	mov    rcx,r12
  40c2ce:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40c2d3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40c2dc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40c2e5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40c2ee:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40c2f7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40c300:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40c309:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40c312:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40c31b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40c324:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40c32d:	add    rsp,0x178
  40c334:	pop    r15
  40c336:	pop    r14
  40c338:	pop    rsi
  40c339:	pop    rdi
  40c33a:	pop    r13
  40c33c:	pop    r12
  40c33e:	ret
	...

000000000040c340 <__swc_fn_e121059d_000052_92b016ae>:
  40c340:	lea    rax,[rdx-0x58]
  40c344:	ret
	...

000000000040c350 <__swc_fn_e121059d_000055_ddf32775>:
  40c350:	push   rsi
  40c351:	push   rdi
  40c352:	push   r12
  40c354:	push   r13
  40c356:	sub    rsp,0x68
  40c35a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40c360:	mov    rsi,r9
  40c363:	mov    rdi,rcx
  40c366:	mov    r12,rdx
  40c369:	mov    r13,r8
  40c36c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40c374:	jne    40c383 <__swc_fn_e121059d_000055_ddf32775+0x33>
  40c376:	xor    eax,eax
  40c378:	add    rsp,0x68
  40c37c:	pop    r13
  40c37e:	pop    r12
  40c380:	pop    rdi
  40c381:	pop    rsi
  40c382:	ret
  40c383:	mov    rcx,rdi
  40c386:	call   40e040 <__swc_fn_e121059d_000136_db32cc57>
  40c38b:	movabs rax,0x7fffffffffffffff
  40c395:	cmp    r12,rax
  40c398:	mov    rax,0xffffffffffffffff
  40c39f:	lea    rcx,[r12+r12*1]
  40c3a3:	cmovbe rax,rcx
  40c3a7:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40c3ae:	mov    rdx,rcx
  40c3b1:	sub    rax,r12
  40c3b4:	inc    rax
  40c3b7:	xor    r8d,r8d
  40c3ba:	test   rcx,rcx
  40c3bd:	jbe    40c3e8 <__swc_fn_e121059d_000055_ddf32775+0x98>
  40c3bf:	nop
  40c3c0:	lea    r9,[r8+r8*4]
  40c3c4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40c3cc:	sub    r9,r12
  40c3cf:	cmp    r9,rax
  40c3d2:	jae    40c3df <__swc_fn_e121059d_000055_ddf32775+0x8f>
  40c3d4:	mov    rdx,r8
  40c3d7:	mov    rax,r9
  40c3da:	test   r9,r9
  40c3dd:	je     40c3e8 <__swc_fn_e121059d_000055_ddf32775+0x98>
  40c3df:	add    r8,0x1
  40c3e3:	cmp    r8,rcx
  40c3e6:	jb     40c3c0 <__swc_fn_e121059d_000055_ddf32775+0x70>
  40c3e8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40c3ef:	cmp    rdx,rax
  40c3f2:	jne    40c40f <__swc_fn_e121059d_000055_ddf32775+0xbf>
  40c3f4:	mov    rcx,rdi
  40c3f7:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40c3fc:	xor    eax,eax
  40c3fe:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40c404:	add    rsp,0x68
  40c408:	pop    r13
  40c40a:	pop    r12
  40c40c:	pop    rdi
  40c40d:	pop    rsi
  40c40e:	ret
  40c40f:	lea    rax,[rdx+rdx*4]
  40c413:	lea    rax,[rdi+rax*8+0x268]
  40c41b:	vmovups xmm6,XMMWORD PTR [rax]
  40c41f:	mov    r8,QWORD PTR [rax+0x10]
  40c423:	mov    rcx,rdi
  40c426:	call   40f560 <__swc_fn_e121059d_000056_87dc216f>
  40c42b:	vpshufd xmm0,xmm6,0xee
  40c430:	vmovsd QWORD PTR [r13+0x0],xmm0
  40c436:	mov    QWORD PTR [rsi],r8
  40c439:	mov    rcx,rdi
  40c43c:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40c441:	vmovq  rax,xmm6
  40c446:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40c44c:	add    rsp,0x68
  40c450:	pop    r13
  40c452:	pop    r12
  40c454:	pop    rdi
  40c455:	pop    rsi
  40c456:	ret
	...

000000000040c460 <__swc_fn_e121059d_000058_01964a17>:
  40c460:	push   r12
  40c462:	push   r13
  40c464:	push   r14
  40c466:	push   r15
  40c468:	push   rdi
  40c469:	push   rsi
  40c46a:	sub    rsp,0x148
  40c471:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40c47a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40c483:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40c48c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40c495:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40c49e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40c4a7:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40c4b0:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40c4b9:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40c4c2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40c4cb:	mov    r12,r9
  40c4ce:	mov    r13,rcx
  40c4d1:	mov    r14,rdx
  40c4d4:	mov    r15,r8
  40c4d7:	test   rdx,rdx
  40c4da:	jne    40c4ee <__swc_fn_e121059d_000058_01964a17+0x8e>
  40c4dc:	add    rsp,0x148
  40c4e3:	pop    rsi
  40c4e4:	pop    rdi
  40c4e5:	pop    r15
  40c4e7:	pop    r14
  40c4e9:	pop    r13
  40c4eb:	pop    r12
  40c4ed:	ret
  40c4ee:	cmp    r12,0x200000
  40c4f5:	ja     40c587 <__swc_fn_e121059d_000058_01964a17+0x127>
  40c4fb:	lea    rax,[rip+0x15afe]        # 422000 <__swc_data_base_e121059d>
  40c502:	mov    rax,QWORD PTR [rax]
  40c505:	cmp    rax,0xffffffffffffffff
  40c509:	je     40c518 <__swc_fn_e121059d_000058_01964a17+0xb8>
  40c50b:	mov    eax,eax
  40c50d:	mov    edi,eax
  40c50f:	xor    eax,eax
  40c511:	call   407000 <pthread_getspecific@plt>
  40c516:	jmp    40c51a <__swc_fn_e121059d_000058_01964a17+0xba>
  40c518:	xor    eax,eax
  40c51a:	test   rax,rax
  40c51d:	je     40c524 <__swc_fn_e121059d_000058_01964a17+0xc4>
  40c51f:	mov    rsi,rax
  40c522:	jmp    40c534 <__swc_fn_e121059d_000058_01964a17+0xd4>
  40c524:	call   40be00 <__swc_fn_e121059d_000031_3c3e930e>
  40c529:	mov    rcx,rax
  40c52c:	call   409ba0 <__swc_fn_e121059d_000129_8d8a7dd2>
  40c531:	mov    rsi,rax
  40c534:	test   rsi,rsi
  40c537:	je     40c587 <__swc_fn_e121059d_000058_01964a17+0x127>
  40c539:	cmp    QWORD PTR [rsi],r13
  40c53c:	jne    40c587 <__swc_fn_e121059d_000058_01964a17+0x127>
  40c53e:	cmp    DWORD PTR [rsi+0x20],0x0
  40c542:	jne    40c587 <__swc_fn_e121059d_000058_01964a17+0x127>
  40c544:	cmp    DWORD PTR [rsi+0x730],0x10
  40c54b:	jae    40c587 <__swc_fn_e121059d_000058_01964a17+0x127>
  40c54d:	mov    eax,DWORD PTR [rsi+0x730]
  40c553:	lea    rdi,[rax+rax*4]
  40c557:	lea    rdi,[rsi+rdi*8+0x738]
  40c55f:	mov    QWORD PTR [rdi],r14
  40c562:	mov    QWORD PTR [rdi+0x8],r15
  40c566:	mov    QWORD PTR [rdi+0x10],r12
  40c56a:	mov    QWORD PTR [rdi+0x18],0x0
  40c572:	call   409c50 <__swc_fn_e121059d_000132_91db8856>
  40c577:	mov    QWORD PTR [rdi+0x20],rax
  40c57b:	add    DWORD PTR [rsi+0x730],0x1
  40c582:	jmp    40c6e6 <__swc_fn_e121059d_000058_01964a17+0x286>
  40c587:	mov    rcx,r13
  40c58a:	call   407e90 <__swc_fn_e121059d_000057_01c75a1d>
  40c58f:	mov    rsi,rax
  40c592:	cmp    r12,rax
  40c595:	jbe    40c5ca <__swc_fn_e121059d_000058_01964a17+0x16a>
  40c597:	cmp    r12,0x10000000
  40c59e:	seta   al
  40c5a1:	ja     40c5b0 <__swc_fn_e121059d_000058_01964a17+0x150>
  40c5a3:	mov    rax,QWORD PTR [r13+0x2a70]
  40c5aa:	test   rax,rax
  40c5ad:	setne  al
  40c5b0:	test   al,al
  40c5b2:	je     40c5ca <__swc_fn_e121059d_000058_01964a17+0x16a>
  40c5b4:	mov    rcx,r13
  40c5b7:	mov    rdx,r14
  40c5ba:	mov    r8,r15
  40c5bd:	mov    r9,r12
  40c5c0:	call   407750 <__swc_fn_e121059d_000039_9ae4348f>
  40c5c5:	jmp    40c6e6 <__swc_fn_e121059d_000058_01964a17+0x286>
  40c5ca:	call   409c50 <__swc_fn_e121059d_000132_91db8856>
  40c5cf:	mov    rdi,rax
  40c5d2:	mov    rcx,r13
  40c5d5:	call   40e040 <__swc_fn_e121059d_000136_db32cc57>
  40c5da:	cmp    QWORD PTR [r13+0x2a70],0x0
  40c5e2:	je     40c69a <__swc_fn_e121059d_000058_01964a17+0x23a>
  40c5e8:	nop    DWORD PTR [rax+rax*1+0x0]
  40c5f0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40c5fb:	jae    40c610 <__swc_fn_e121059d_000058_01964a17+0x1b0>
  40c5fd:	mov    rax,QWORD PTR [r13+0x2a68]
  40c604:	add    rax,r12
  40c607:	cmp    rax,rsi
  40c60a:	jbe    40c69a <__swc_fn_e121059d_000058_01964a17+0x23a>
  40c610:	xor    eax,eax
  40c612:	mov    rcx,QWORD PTR [r13+0x2a70]
  40c619:	mov    edx,0x1
  40c61e:	cmp    rcx,0x1
  40c622:	jbe    40c659 <__swc_fn_e121059d_000058_01964a17+0x1f9>
  40c624:	cs nop WORD PTR [rax+rax*1+0x0]
  40c62e:	xchg   ax,ax
  40c630:	lea    r8,[rdx+rdx*4]
  40c634:	lea    r8,[r13+r8*8+0x268]
  40c63c:	lea    r9,[rax+rax*4]
  40c640:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40c648:	cmp    QWORD PTR [r8+0x18],r9
  40c64c:	cmovb  rax,rdx
  40c650:	add    rdx,0x1
  40c654:	cmp    rdx,rcx
  40c657:	jb     40c630 <__swc_fn_e121059d_000058_01964a17+0x1d0>
  40c659:	lea    rcx,[rax+rax*4]
  40c65d:	lea    rcx,[r13+rcx*8+0x268]
  40c665:	mov    r8,QWORD PTR [rcx]
  40c668:	mov    r9,QWORD PTR [rcx+0x8]
  40c66c:	mov    r10,QWORD PTR [rcx+0x10]
  40c670:	mov    rcx,r13
  40c673:	mov    rdx,rax
  40c676:	call   40f560 <__swc_fn_e121059d_000056_87dc216f>
  40c67b:	mov    rcx,r13
  40c67e:	mov    rdx,r8
  40c681:	mov    r8,r9
  40c684:	mov    r9,r10
  40c687:	call   407750 <__swc_fn_e121059d_000039_9ae4348f>
  40c68c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40c694:	jne    40c5f0 <__swc_fn_e121059d_000058_01964a17+0x190>
  40c69a:	add    QWORD PTR [r13+0x2a78],0x1
  40c6a2:	mov    rax,QWORD PTR [r13+0x2a70]
  40c6a9:	lea    rax,[rax+rax*4]
  40c6ad:	lea    rax,[r13+rax*8+0x268]
  40c6b5:	mov    QWORD PTR [rax],r14
  40c6b8:	mov    QWORD PTR [rax+0x8],r15
  40c6bc:	mov    QWORD PTR [rax+0x10],r12
  40c6c0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40c6c7:	mov    QWORD PTR [rax+0x18],rcx
  40c6cb:	mov    QWORD PTR [rax+0x20],rdi
  40c6cf:	add    QWORD PTR [r13+0x2a68],r12
  40c6d6:	add    QWORD PTR [r13+0x2a70],0x1
  40c6de:	mov    rcx,r13
  40c6e1:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40c6e6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40c6ef:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40c6f8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40c701:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40c70a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40c713:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40c71c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40c725:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40c72e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40c737:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40c740:	add    rsp,0x148
  40c747:	pop    rsi
  40c748:	pop    rdi
  40c749:	pop    r15
  40c74b:	pop    r14
  40c74d:	pop    r13
  40c74f:	pop    r12
  40c751:	ret
	...

000000000040c760 <__swc_fn_e121059d_000061_73a9baa2>:
  40c760:	push   rbx
  40c761:	push   r12
  40c763:	push   r13
  40c765:	push   r14
  40c767:	push   r15
  40c769:	push   rdi
  40c76a:	push   rsi
  40c76b:	sub    rsp,0xf0
  40c772:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40c778:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40c77e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40c784:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40c78a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40c793:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40c79c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40c7a5:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40c7ae:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40c7b7:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40c7c0:	mov    eax,r8d
  40c7c3:	mov    rbx,rcx
  40c7c6:	mov    r12,rdx
  40c7c9:	mov    QWORD PTR [rsp+0x18],rdx
  40c7ce:	mov    ecx,DWORD PTR [r12+0x58]
  40c7d3:	mov    r13d,ecx
  40c7d6:	cmp    ecx,0x10
  40c7d9:	mov    ecx,0x10
  40c7de:	cmovb  r13d,ecx
  40c7e2:	test   r13d,r13d
  40c7e5:	mov    rcx,r13
  40c7e8:	mov    edx,0x8
  40c7ed:	cmove  ecx,edx
  40c7f0:	dec    rcx
  40c7f3:	mov    rdx,0xffffffffffffffff
  40c7fa:	sub    rdx,rcx
  40c7fd:	xor    r14d,r14d
  40c800:	mov    r8,rcx
  40c803:	not    r8
  40c806:	lea    rcx,[rcx+0x58]
  40c80a:	and    rcx,r8
  40c80d:	cmp    rdx,0x58
  40c811:	cmovae r14,rcx
  40c815:	cmp    eax,0xffffffff
  40c818:	jne    40c821 <__swc_fn_e121059d_000061_73a9baa2+0xc1>
  40c81a:	mov    r15,QWORD PTR [r12+0x48]
  40c81f:	jmp    40c853 <__swc_fn_e121059d_000061_73a9baa2+0xf3>
  40c821:	test   eax,eax
  40c823:	jne    40c82c <__swc_fn_e121059d_000061_73a9baa2+0xcc>
  40c825:	mov    eax,0x8
  40c82a:	jmp    40c850 <__swc_fn_e121059d_000061_73a9baa2+0xf0>
  40c82c:	cmp    eax,0x8
  40c82f:	ja     40c837 <__swc_fn_e121059d_000061_73a9baa2+0xd7>
  40c831:	shl    rax,0x4
  40c835:	jmp    40c850 <__swc_fn_e121059d_000061_73a9baa2+0xf0>
  40c837:	lea    eax,[rax-0x9]
  40c83a:	mov    ecx,eax
  40c83c:	shr    ecx,0x2
  40c83f:	and    eax,0x3
  40c842:	lea    ecx,[rcx+0x7]
  40c845:	lea    ecx,[rcx-0x2]
  40c848:	lea    eax,[rax+0x5]
  40c84b:	shlx   rax,rax,rcx
  40c850:	mov    r15,rax
  40c853:	lea    rax,[r14+r13*1]
  40c857:	mov    rcx,0xffffffffffffffff
  40c85e:	sub    rcx,rax
  40c861:	cmp    r15,rcx
  40c864:	jbe    40c874 <__swc_fn_e121059d_000061_73a9baa2+0x114>
  40c866:	mov    QWORD PTR [r12+0x40],0x0
  40c86f:	jmp    40cc46 <__swc_fn_e121059d_000061_73a9baa2+0x4e6>
  40c874:	mov    QWORD PTR [rsp+0x20],r13
  40c879:	lea    r13,[rsp+0x8]
  40c87e:	add    rax,r15
  40c881:	mov    ecx,0x1000
  40c886:	test   ecx,ecx
  40c888:	mov    edx,0x8
  40c88d:	cmove  ecx,edx
  40c890:	dec    rcx
  40c893:	mov    rdx,0xffffffffffffffff
  40c89a:	sub    rdx,rcx
  40c89d:	cmp    rax,rdx
  40c8a0:	jbe    40c8ac <__swc_fn_e121059d_000061_73a9baa2+0x14c>
  40c8a2:	mov    QWORD PTR [r13+0x0],0x0
  40c8aa:	jmp    40c8b9 <__swc_fn_e121059d_000061_73a9baa2+0x159>
  40c8ac:	add    rax,rcx
  40c8af:	andn   rax,rcx,rax
  40c8b4:	mov    QWORD PTR [rsp+0x8],rax
  40c8b9:	cmp    QWORD PTR [r13+0x0],0x0
  40c8be:	jne    40c8ce <__swc_fn_e121059d_000061_73a9baa2+0x16e>
  40c8c0:	mov    QWORD PTR [r12+0x40],0x0
  40c8c9:	jmp    40cc46 <__swc_fn_e121059d_000061_73a9baa2+0x4e6>
  40c8ce:	mov    QWORD PTR [rsp+0x30],r15
  40c8d3:	xor    r15d,r15d
  40c8d6:	mov    QWORD PTR [rsp+0x38],0x0
  40c8df:	lea    r12,[rsp+0x10]
  40c8e4:	mov    QWORD PTR [rsp+0x28],r14
  40c8e9:	mov    r14,QWORD PTR [rsp+0x8]
  40c8ee:	mov    QWORD PTR [rsp+0x10],r14
  40c8f3:	cmp    r14,0x10000
  40c8fa:	ja     40c901 <__swc_fn_e121059d_000061_73a9baa2+0x1a1>
  40c8fc:	mov    rax,r14
  40c8ff:	jmp    40c952 <__swc_fn_e121059d_000061_73a9baa2+0x1f2>
  40c901:	xor    eax,eax
  40c903:	lea    rcx,[r14-0x1]
  40c907:	lzcnt  rax,rcx
  40c90c:	mov    ecx,0x3f
  40c911:	sub    rcx,rax
  40c914:	mov    eax,0x1
  40c919:	lea    rcx,[rcx-0x3]
  40c91d:	shl    rax,cl
  40c920:	mov    rcx,rax
  40c923:	cmp    rax,0x1000
  40c92a:	mov    eax,0x1000
  40c92f:	cmovb  rcx,rax
  40c933:	mov    rdx,0xffffffffffffffff
  40c93a:	sub    rdx,rcx
  40c93d:	mov    rax,r14
  40c940:	lea    r8,[r14+rcx*1-0x1]
  40c945:	neg    rcx
  40c948:	and    r8,rcx
  40c94b:	cmp    r14,rdx
  40c94e:	cmovbe rax,r8
  40c952:	mov    QWORD PTR [rsp+0x8],rax
  40c957:	lea    rax,[rip+0x156a2]        # 422000 <__swc_data_base_e121059d>
  40c95e:	mov    rax,QWORD PTR [rax]
  40c961:	cmp    rax,0xffffffffffffffff
  40c965:	je     40c974 <__swc_fn_e121059d_000061_73a9baa2+0x214>
  40c967:	mov    eax,eax
  40c969:	mov    edi,eax
  40c96b:	xor    eax,eax
  40c96d:	call   407000 <pthread_getspecific@plt>
  40c972:	jmp    40c976 <__swc_fn_e121059d_000061_73a9baa2+0x216>
  40c974:	xor    eax,eax
  40c976:	test   rax,rax
  40c979:	jne    40c988 <__swc_fn_e121059d_000061_73a9baa2+0x228>
  40c97b:	call   40be00 <__swc_fn_e121059d_000031_3c3e930e>
  40c980:	mov    rcx,rax
  40c983:	call   409ba0 <__swc_fn_e121059d_000129_8d8a7dd2>
  40c988:	test   rax,rax
  40c98b:	je     40ca7c <__swc_fn_e121059d_000061_73a9baa2+0x31c>
  40c991:	cmp    QWORD PTR [rax],rbx
  40c994:	jne    40ca7c <__swc_fn_e121059d_000061_73a9baa2+0x31c>
  40c99a:	cmp    DWORD PTR [rax+0x20],0x0
  40c99e:	jne    40ca7c <__swc_fn_e121059d_000061_73a9baa2+0x31c>
  40c9a4:	mov    rcx,QWORD PTR [rsp+0x8]
  40c9a9:	movabs rdx,0x7fffffffffffffff
  40c9b3:	cmp    rcx,rdx
  40c9b6:	mov    rdx,0xffffffffffffffff
  40c9bd:	lea    r8,[rcx+rcx*1]
  40c9c1:	cmovbe rdx,r8
  40c9c5:	mov    r8d,DWORD PTR [rax+0x730]
  40c9cc:	mov    r9d,r8d
  40c9cf:	sub    rdx,rcx
  40c9d2:	inc    rdx
  40c9d5:	xor    r10d,r10d
  40c9d8:	test   r8,r8
  40c9db:	jbe    40ca0b <__swc_fn_e121059d_000061_73a9baa2+0x2ab>
  40c9dd:	nop    DWORD PTR [rax]
  40c9e0:	mov    r11d,r10d
  40c9e3:	lea    r11,[r11+r11*4]
  40c9e7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40c9ef:	sub    r11,rcx
  40c9f2:	cmp    r11,rdx
  40c9f5:	jae    40ca02 <__swc_fn_e121059d_000061_73a9baa2+0x2a2>
  40c9f7:	mov    r9d,r10d
  40c9fa:	mov    rdx,r11
  40c9fd:	test   r11,r11
  40ca00:	je     40ca0b <__swc_fn_e121059d_000061_73a9baa2+0x2ab>
  40ca02:	add    r10,0x1
  40ca06:	cmp    r10,r8
  40ca09:	jb     40c9e0 <__swc_fn_e121059d_000061_73a9baa2+0x280>
  40ca0b:	mov    ecx,DWORD PTR [rax+0x730]
  40ca11:	cmp    r9d,ecx
  40ca14:	jne    40ca1a <__swc_fn_e121059d_000061_73a9baa2+0x2ba>
  40ca16:	xor    eax,eax
  40ca18:	jmp    40ca79 <__swc_fn_e121059d_000061_73a9baa2+0x319>
  40ca1a:	lea    rcx,[r9+r9*4]
  40ca1e:	lea    rcx,[rax+rcx*8+0x738]
  40ca26:	vmovups xmm0,XMMWORD PTR [rcx]
  40ca2a:	mov    rdx,QWORD PTR [rcx+0x10]
  40ca2e:	sub    DWORD PTR [rax+0x730],0x1
  40ca35:	mov    r8d,DWORD PTR [rax+0x730]
  40ca3c:	lea    r8,[r8+r8*4]
  40ca40:	lea    r8,[rax+r8*8+0x738]
  40ca48:	vmovups xmm1,XMMWORD PTR [r8]
  40ca4d:	vmovups XMMWORD PTR [rcx],xmm1
  40ca51:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40ca57:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40ca5c:	mov    rax,QWORD PTR [r8+0x20]
  40ca60:	mov    QWORD PTR [rcx+0x20],rax
  40ca64:	vpshufd xmm1,xmm0,0xee
  40ca69:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40ca6f:	mov    QWORD PTR [rsp+0x10],rdx
  40ca74:	vmovq  rax,xmm0
  40ca79:	mov    r15,rax
  40ca7c:	test   r15,r15
  40ca7f:	jne    40ca97 <__swc_fn_e121059d_000061_73a9baa2+0x337>
  40ca81:	mov    rcx,rbx
  40ca84:	mov    rdx,QWORD PTR [rsp+0x8]
  40ca89:	mov    r8,r13
  40ca8c:	mov    r9,r12
  40ca8f:	call   40c350 <__swc_fn_e121059d_000055_ddf32775>
  40ca94:	mov    r15,rax
  40ca97:	test   r15,r15
  40ca9a:	je     40cadb <__swc_fn_e121059d_000061_73a9baa2+0x37b>
  40ca9c:	cmp    QWORD PTR [r12],r14
  40caa0:	jae    40cadb <__swc_fn_e121059d_000061_73a9baa2+0x37b>
  40caa2:	mov    rax,r15
  40caa5:	add    rax,QWORD PTR [r12]
  40caa9:	mov    rdx,r14
  40caac:	sub    rdx,QWORD PTR [r12]
  40cab0:	mov    rcx,rax
  40cab3:	call   4072a0 <__swc_fn_e121059d_000003_81215399>
  40cab8:	test   al,al
  40caba:	je     40cac3 <__swc_fn_e121059d_000061_73a9baa2+0x363>
  40cabc:	mov    QWORD PTR [rsp+0x10],r14
  40cac1:	jmp    40cadb <__swc_fn_e121059d_000061_73a9baa2+0x37b>
  40cac3:	mov    rcx,rbx
  40cac6:	mov    rdx,r15
  40cac9:	mov    r8,QWORD PTR [rsp+0x8]
  40cace:	mov    r9,QWORD PTR [rsp+0x10]
  40cad3:	call   40c460 <__swc_fn_e121059d_000058_01964a17>
  40cad8:	xor    r15d,r15d
  40cadb:	test   r15,r15
  40cade:	jne    40cb5a <__swc_fn_e121059d_000061_73a9baa2+0x3fa>
  40cae0:	cmp    r14,0x10000
  40cae7:	ja     40caee <__swc_fn_e121059d_000061_73a9baa2+0x38e>
  40cae9:	mov    rax,r14
  40caec:	jmp    40cb3f <__swc_fn_e121059d_000061_73a9baa2+0x3df>
  40caee:	xor    eax,eax
  40caf0:	lea    rcx,[r14-0x1]
  40caf4:	lzcnt  rax,rcx
  40caf9:	mov    ecx,0x3f
  40cafe:	sub    rcx,rax
  40cb01:	mov    eax,0x1
  40cb06:	lea    rcx,[rcx-0x3]
  40cb0a:	shl    rax,cl
  40cb0d:	mov    rcx,rax
  40cb10:	cmp    rax,0x1000
  40cb17:	mov    eax,0x1000
  40cb1c:	cmovb  rcx,rax
  40cb20:	mov    rdx,0xffffffffffffffff
  40cb27:	sub    rdx,rcx
  40cb2a:	mov    rax,r14
  40cb2d:	lea    r8,[r14+rcx*1-0x1]
  40cb32:	neg    rcx
  40cb35:	and    r8,rcx
  40cb38:	cmp    r14,rdx
  40cb3b:	cmovbe rax,r8
  40cb3f:	mov    QWORD PTR [rsp+0x8],rax
  40cb44:	mov    QWORD PTR [rsp+0x10],r14
  40cb49:	mov    rcx,rbx
  40cb4c:	mov    rdx,rax
  40cb4f:	mov    r8,r14
  40cb52:	call   40bec0 <__swc_fn_e121059d_000037_1e381f55>
  40cb57:	mov    r15,rax
  40cb5a:	test   r15,r15
  40cb5d:	jne    40cb6b <__swc_fn_e121059d_000061_73a9baa2+0x40b>
  40cb5f:	mov    r13,QWORD PTR [rsp+0x20]
  40cb64:	mov    rsi,QWORD PTR [rsp+0x38]
  40cb69:	jmp    40cba7 <__swc_fn_e121059d_000061_73a9baa2+0x447>
  40cb6b:	mov    rax,r15
  40cb6e:	add    rax,QWORD PTR [rsp+0x28]
  40cb73:	mov    r13,QWORD PTR [rsp+0x20]
  40cb78:	test   r13d,r13d
  40cb7b:	mov    rcx,r13
  40cb7e:	mov    edx,0x8
  40cb83:	cmove  ecx,edx
  40cb86:	dec    rcx
  40cb89:	mov    rdx,0xffffffffffffffff
  40cb90:	sub    rdx,rcx
  40cb93:	cmp    rax,rdx
  40cb96:	jbe    40cb9c <__swc_fn_e121059d_000061_73a9baa2+0x43c>
  40cb98:	xor    eax,eax
  40cb9a:	jmp    40cba4 <__swc_fn_e121059d_000061_73a9baa2+0x444>
  40cb9c:	add    rax,rcx
  40cb9f:	andn   rax,rcx,rax
  40cba4:	mov    rsi,rax
  40cba7:	mov    rax,QWORD PTR [rsp+0x8]
  40cbac:	test   r15,r15
  40cbaf:	je     40cbb8 <__swc_fn_e121059d_000061_73a9baa2+0x458>
  40cbb1:	mov    rdi,QWORD PTR [rsp+0x18]
  40cbb6:	jmp    40cbca <__swc_fn_e121059d_000061_73a9baa2+0x46a>
  40cbb8:	mov    rdi,QWORD PTR [rsp+0x18]
  40cbbd:	mov    QWORD PTR [rdi+0x40],0x0
  40cbc5:	jmp    40cc46 <__swc_fn_e121059d_000061_73a9baa2+0x4e6>
  40cbca:	lea    rdx,[rsi-0x58]
  40cbce:	mov    QWORD PTR [rsi-0x58],r15
  40cbd2:	mov    QWORD PTR [rsi-0x50],rax
  40cbd6:	mov    rax,QWORD PTR [rsp+0x10]
  40cbdb:	mov    QWORD PTR [rsi-0x48],rax
  40cbdf:	mov    QWORD PTR [rsi-0x40],rsi
  40cbe3:	mov    rax,QWORD PTR [rdi+0x48]
  40cbe7:	mov    QWORD PTR [rsi-0x38],rax
  40cbeb:	mov    rax,QWORD PTR [rsp+0x30]
  40cbf0:	mov    QWORD PTR [rsi-0x30],rax
  40cbf4:	mov    DWORD PTR [rsi-0x10],r13d
  40cbf8:	mov    QWORD PTR [rsi-0x28],0x0
  40cc00:	mov    QWORD PTR [rsi-0x20],0x0
  40cc08:	add    r15,QWORD PTR [r12]
  40cc0c:	sub    r15,rsi
  40cc0f:	mov    QWORD PTR [rsi-0x30],r15
  40cc13:	mov    rcx,QWORD PTR [rbx+0x250]
  40cc1a:	nop    WORD PTR [rax+rax*1+0x0]
  40cc20:	lea    r8,[rcx+r15*1]
  40cc24:	mov    rax,rcx
  40cc27:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40cc30:	cmp    rax,rcx
  40cc33:	je     40cc3a <__swc_fn_e121059d_000061_73a9baa2+0x4da>
  40cc35:	mov    rcx,rax
  40cc38:	jmp    40cc20 <__swc_fn_e121059d_000061_73a9baa2+0x4c0>
  40cc3a:	mov    rcx,rbx
  40cc3d:	call   40f4d0 <__swc_fn_e121059d_000053_9aa81fa7>
  40cc42:	mov    QWORD PTR [rdi+0x40],rsi
  40cc46:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40cc4c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40cc52:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40cc58:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40cc5e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40cc67:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40cc70:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40cc79:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40cc82:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40cc8b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40cc94:	add    rsp,0xf0
  40cc9b:	pop    rsi
  40cc9c:	pop    rdi
  40cc9d:	pop    r15
  40cc9f:	pop    r14
  40cca1:	pop    r13
  40cca3:	pop    r12
  40cca5:	pop    rbx
  40cca6:	ret
	...

000000000040ccb0 <__swc_fn_e121059d_000064_20100e91>:
  40ccb0:	push   rbx
  40ccb1:	push   r12
  40ccb3:	push   rdi
  40ccb4:	push   rsi
  40ccb5:	sub    rsp,0xb8
  40ccbc:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ccc2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40ccc8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40ccce:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ccd4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ccda:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cce0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cce6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40ccef:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ccf8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cd01:	mov    rbx,rdx
  40cd04:	mov    r12,rcx
  40cd07:	cmp    DWORD PTR [rbx+0x58],0x0
  40cd0b:	je     40cd25 <__swc_fn_e121059d_000064_20100e91+0x75>
  40cd0d:	mov    eax,DWORD PTR [rbx+0x58]
  40cd10:	sub    eax,0x1
  40cd13:	test   DWORD PTR [rbx+0x58],eax
  40cd16:	je     40cd25 <__swc_fn_e121059d_000064_20100e91+0x75>
  40cd18:	mov    QWORD PTR [rbx+0x40],0x0
  40cd20:	jmp    40cf37 <__swc_fn_e121059d_000064_20100e91+0x287>
  40cd25:	cmp    QWORD PTR [rbx+0x48],0x0
  40cd2a:	jne    40cd39 <__swc_fn_e121059d_000064_20100e91+0x89>
  40cd2c:	mov    QWORD PTR [rbx+0x40],0x0
  40cd34:	jmp    40cf37 <__swc_fn_e121059d_000064_20100e91+0x287>
  40cd39:	lea    rax,[rsp+0x8]
  40cd3e:	mov    rcx,QWORD PTR [rbx+0x48]
  40cd42:	cmp    rcx,0x8
  40cd46:	ja     40cd50 <__swc_fn_e121059d_000064_20100e91+0xa0>
  40cd48:	mov    DWORD PTR [rax],0x0
  40cd4e:	jmp    40cdab <__swc_fn_e121059d_000064_20100e91+0xfb>
  40cd50:	cmp    rcx,0x80
  40cd57:	ja     40cd67 <__swc_fn_e121059d_000064_20100e91+0xb7>
  40cd59:	lea    rcx,[rcx+0xf]
  40cd5d:	shr    rcx,0x4
  40cd61:	mov    DWORD PTR [rsp+0x8],ecx
  40cd65:	jmp    40cdab <__swc_fn_e121059d_000064_20100e91+0xfb>
  40cd67:	cmp    rcx,0x10000
  40cd6e:	jbe    40cd78 <__swc_fn_e121059d_000064_20100e91+0xc8>
  40cd70:	mov    DWORD PTR [rax],0xffffffff
  40cd76:	jmp    40cdab <__swc_fn_e121059d_000064_20100e91+0xfb>
  40cd78:	dec    rcx
  40cd7b:	xor    edx,edx
  40cd7d:	lzcnt  rdx,rcx
  40cd82:	mov    r8d,0x3f
  40cd88:	sub    r8d,edx
  40cd8b:	lea    edx,[r8-0x2]
  40cd8f:	shrx   rcx,rcx,rdx
  40cd94:	and    ecx,0x3
  40cd97:	lea    edx,[r8-0x7]
  40cd9b:	lea    edx,[rdx*4+0x0]
  40cda2:	lea    edx,[rdx+0x9]
  40cda5:	add    edx,ecx
  40cda7:	mov    DWORD PTR [rsp+0x8],edx
  40cdab:	cmp    DWORD PTR [rax],0x0
  40cdae:	jne    40cdbe <__swc_fn_e121059d_000064_20100e91+0x10e>
  40cdb0:	cmp    DWORD PTR [rbx+0x58],0x8
  40cdb4:	jbe    40cdbe <__swc_fn_e121059d_000064_20100e91+0x10e>
  40cdb6:	mov    DWORD PTR [rsp+0x8],0x1
  40cdbe:	cmp    DWORD PTR [rbx+0x58],0x10
  40cdc2:	jbe    40ce41 <__swc_fn_e121059d_000064_20100e91+0x191>
  40cdc8:	cmp    DWORD PTR [rbx+0x58],0x40
  40cdcc:	ja     40ce41 <__swc_fn_e121059d_000064_20100e91+0x191>
  40cdce:	cmp    DWORD PTR [rax],0xffffffff
  40cdd1:	je     40ce41 <__swc_fn_e121059d_000064_20100e91+0x191>
  40cdd3:	mov    ecx,DWORD PTR [rsp+0x8]
  40cdd7:	mov    edx,DWORD PTR [rbx+0x58]
  40cdda:	dec    rdx
  40cddd:	cmp    ecx,0x2d
  40cde0:	jae    40ce38 <__swc_fn_e121059d_000064_20100e91+0x188>
  40cde2:	cs nop WORD PTR [rax+rax*1+0x0]
  40cdec:	nop    DWORD PTR [rax+0x0]
  40cdf0:	mov    r8d,ecx
  40cdf3:	test   ecx,ecx
  40cdf5:	jne    40cdff <__swc_fn_e121059d_000064_20100e91+0x14f>
  40cdf7:	mov    r8d,0x8
  40cdfd:	jmp    40ce2b <__swc_fn_e121059d_000064_20100e91+0x17b>
  40cdff:	cmp    r8d,0x8
  40ce03:	ja     40ce0b <__swc_fn_e121059d_000064_20100e91+0x15b>
  40ce05:	shl    r8,0x4
  40ce09:	jmp    40ce2b <__swc_fn_e121059d_000064_20100e91+0x17b>
  40ce0b:	lea    r8d,[r8-0x9]
  40ce0f:	mov    r9d,r8d
  40ce12:	shr    r9d,0x2
  40ce16:	and    r8d,0x3
  40ce1a:	lea    r9d,[r9+0x7]
  40ce1e:	lea    r9d,[r9-0x2]
  40ce22:	lea    r8d,[r8+0x5]
  40ce26:	shlx   r8,r8,r9
  40ce2b:	test   r8,rdx
  40ce2e:	je     40ce3d <__swc_fn_e121059d_000064_20100e91+0x18d>
  40ce30:	add    ecx,0x1
  40ce33:	cmp    ecx,0x2d
  40ce36:	jb     40cdf0 <__swc_fn_e121059d_000064_20100e91+0x140>
  40ce38:	mov    ecx,0xffffffff
  40ce3d:	mov    DWORD PTR [rsp+0x8],ecx
  40ce41:	mov    ecx,DWORD PTR [rsp+0x8]
  40ce45:	cmp    ecx,0xffffffff
  40ce48:	je     40ce50 <__swc_fn_e121059d_000064_20100e91+0x1a0>
  40ce4a:	cmp    DWORD PTR [rbx+0x58],0x40
  40ce4e:	jbe    40ce63 <__swc_fn_e121059d_000064_20100e91+0x1b3>
  40ce50:	mov    rcx,r12
  40ce53:	mov    rdx,rbx
  40ce56:	mov    r8d,DWORD PTR [rax]
  40ce59:	call   40c760 <__swc_fn_e121059d_000061_73a9baa2>
  40ce5e:	jmp    40cf37 <__swc_fn_e121059d_000064_20100e91+0x287>
  40ce63:	lea    rax,[rip+0x15196]        # 422000 <__swc_data_base_e121059d>
  40ce6a:	mov    rax,QWORD PTR [rax]
  40ce6d:	cmp    rax,0xffffffffffffffff
  40ce71:	je     40ce80 <__swc_fn_e121059d_000064_20100e91+0x1d0>
  40ce73:	mov    eax,eax
  40ce75:	mov    edi,eax
  40ce77:	xor    eax,eax
  40ce79:	call   407000 <pthread_getspecific@plt>
  40ce7e:	jmp    40ce82 <__swc_fn_e121059d_000064_20100e91+0x1d2>
  40ce80:	xor    eax,eax
  40ce82:	test   rax,rax
  40ce85:	jne    40ce94 <__swc_fn_e121059d_000064_20100e91+0x1e4>
  40ce87:	call   40be00 <__swc_fn_e121059d_000031_3c3e930e>
  40ce8c:	mov    rcx,rax
  40ce8f:	call   409ba0 <__swc_fn_e121059d_000129_8d8a7dd2>
  40ce94:	test   rax,rax
  40ce97:	je     40cea4 <__swc_fn_e121059d_000064_20100e91+0x1f4>
  40ce99:	cmp    QWORD PTR [rax],r12
  40ce9c:	jne    40cea4 <__swc_fn_e121059d_000064_20100e91+0x1f4>
  40ce9e:	cmp    DWORD PTR [rax+0x20],0x0
  40cea2:	je     40ceaf <__swc_fn_e121059d_000064_20100e91+0x1ff>
  40cea4:	mov    rcx,r12
  40cea7:	mov    rdx,rax
  40ceaa:	call   40f110 <__swc_fn_e121059d_000041_41400651>
  40ceaf:	test   rax,rax
  40ceb2:	jne    40cebe <__swc_fn_e121059d_000064_20100e91+0x20e>
  40ceb4:	mov    QWORD PTR [rbx+0x40],0x0
  40cebc:	jmp    40cf37 <__swc_fn_e121059d_000064_20100e91+0x287>
  40cebe:	lea    r8,[rsp+0xc]
  40cec3:	mov    ecx,DWORD PTR [rsp+0x8]
  40cec7:	mov    DWORD PTR [rsp+0xc],ecx
  40cecb:	mov    ecx,DWORD PTR [r8]
  40cece:	lea    rcx,[rcx+rcx*4]
  40ced2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40ced7:	test   rcx,rcx
  40ceda:	je     40cf13 <__swc_fn_e121059d_000064_20100e91+0x263>
  40cedc:	mov    rdx,QWORD PTR [rcx]
  40cedf:	test   rdx,rdx
  40cee2:	je     40cef0 <__swc_fn_e121059d_000064_20100e91+0x240>
  40cee4:	mov    r9,QWORD PTR [rdx]
  40cee7:	mov    QWORD PTR [rcx],r9
  40ceea:	add    DWORD PTR [rcx+0x28],0x1
  40ceee:	jmp    40cf0e <__swc_fn_e121059d_000064_20100e91+0x25e>
  40cef0:	mov    rdx,QWORD PTR [rcx+0x18]
  40cef4:	cmp    QWORD PTR [rcx+0x20],rdx
  40cef8:	jae    40cf0c <__swc_fn_e121059d_000064_20100e91+0x25c>
  40cefa:	mov    rdx,QWORD PTR [rcx+0x20]
  40cefe:	mov    r9d,DWORD PTR [rcx+0x2c]
  40cf02:	add    QWORD PTR [rcx+0x20],r9
  40cf06:	add    DWORD PTR [rcx+0x28],0x1
  40cf0a:	jmp    40cf0e <__swc_fn_e121059d_000064_20100e91+0x25e>
  40cf0c:	xor    edx,edx
  40cf0e:	test   rdx,rdx
  40cf11:	jne    40cf24 <__swc_fn_e121059d_000064_20100e91+0x274>
  40cf13:	mov    rcx,r12
  40cf16:	mov    rdx,rax
  40cf19:	mov    r8d,DWORD PTR [r8]
  40cf1c:	call   40f280 <__swc_fn_e121059d_000050_5e919db9>
  40cf21:	mov    rdx,rax
  40cf24:	test   rdx,rdx
  40cf27:	jne    40cf33 <__swc_fn_e121059d_000064_20100e91+0x283>
  40cf29:	mov    QWORD PTR [rbx+0x40],0x0
  40cf31:	jmp    40cf37 <__swc_fn_e121059d_000064_20100e91+0x287>
  40cf33:	mov    QWORD PTR [rbx+0x40],rdx
  40cf37:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40cf3d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40cf43:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40cf49:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40cf4f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40cf55:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40cf5b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40cf61:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40cf6a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40cf73:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40cf7c:	add    rsp,0xb8
  40cf83:	pop    rsi
  40cf84:	pop    rdi
  40cf85:	pop    r12
  40cf87:	pop    rbx
  40cf88:	ret
  40cf89:	add    BYTE PTR [rax],al
  40cf8b:	add    BYTE PTR [rax],al
  40cf8d:	add    BYTE PTR [rax],al
	...

000000000040cf90 <__swc_fn_e121059d_000067_0145abfc>:
  40cf90:	ret
	...

000000000040cfa0 <__swc_fn_e121059d_000070_357c932c>:
  40cfa0:	push   r12
  40cfa2:	push   r13
  40cfa4:	push   r14
  40cfa6:	push   rdi
  40cfa7:	push   rsi
  40cfa8:	sub    rsp,0x1a0
  40cfaf:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40cfb8:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40cfc1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40cfca:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40cfd3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40cfdc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40cfe5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40cfee:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40cff7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40d000:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40d009:	mov    r12,rdx
  40d00c:	mov    r13,rcx
  40d00f:	mov    rax,QWORD PTR [r12+0x48]
  40d014:	mov    ecx,DWORD PTR [r12+0x58]
  40d019:	lea    rdx,[rax-0x1]
  40d01d:	cmp    rdx,0x10000
  40d024:	jae    40d11e <__swc_fn_e121059d_000070_357c932c+0x17e>
  40d02a:	cmp    rax,0x8
  40d02e:	ja     40d035 <__swc_fn_e121059d_000070_357c932c+0x95>
  40d030:	xor    r14d,r14d
  40d033:	jmp    40d087 <__swc_fn_e121059d_000070_357c932c+0xe7>
  40d035:	cmp    rax,0x80
  40d03c:	ja     40d048 <__swc_fn_e121059d_000070_357c932c+0xa8>
  40d03e:	lea    r14,[rax+0xf]
  40d042:	shr    r14,0x4
  40d046:	jmp    40d087 <__swc_fn_e121059d_000070_357c932c+0xe7>
  40d048:	cmp    rax,0x10000
  40d04f:	jbe    40d059 <__swc_fn_e121059d_000070_357c932c+0xb9>
  40d051:	mov    r14d,0xffffffff
  40d057:	jmp    40d087 <__swc_fn_e121059d_000070_357c932c+0xe7>
  40d059:	xor    eax,eax
  40d05b:	lzcnt  rax,rdx
  40d060:	mov    r8d,0x3f
  40d066:	sub    r8d,eax
  40d069:	lea    eax,[r8-0x2]
  40d06d:	shrx   rax,rdx,rax
  40d072:	and    eax,0x3
  40d075:	lea    edx,[r8-0x7]
  40d079:	lea    edx,[rdx*4+0x0]
  40d080:	lea    edx,[rdx+0x9]
  40d083:	lea    r14d,[rdx+rax*1]
  40d087:	cmp    ecx,0x8
  40d08a:	jbe    40d0a3 <__swc_fn_e121059d_000070_357c932c+0x103>
  40d08c:	cmp    ecx,0x10
  40d08f:	jne    40d11e <__swc_fn_e121059d_000070_357c932c+0x17e>
  40d095:	test   r14d,r14d
  40d098:	mov    eax,0x1
  40d09d:	cmove  r14d,eax
  40d0a1:	jmp    40d0aa <__swc_fn_e121059d_000070_357c932c+0x10a>
  40d0a3:	lea    eax,[rcx-0x1]
  40d0a6:	test   eax,ecx
  40d0a8:	jne    40d11e <__swc_fn_e121059d_000070_357c932c+0x17e>
  40d0aa:	lea    rax,[rip+0x14f4f]        # 422000 <__swc_data_base_e121059d>
  40d0b1:	mov    rax,QWORD PTR [rax]
  40d0b4:	cmp    rax,0xffffffffffffffff
  40d0b8:	je     40d0c7 <__swc_fn_e121059d_000070_357c932c+0x127>
  40d0ba:	mov    eax,eax
  40d0bc:	mov    edi,eax
  40d0be:	xor    eax,eax
  40d0c0:	call   407000 <pthread_getspecific@plt>
  40d0c5:	jmp    40d0c9 <__swc_fn_e121059d_000070_357c932c+0x129>
  40d0c7:	xor    eax,eax
  40d0c9:	test   rax,rax
  40d0cc:	je     40d11e <__swc_fn_e121059d_000070_357c932c+0x17e>
  40d0ce:	cmp    QWORD PTR [rax],r13
  40d0d1:	jne    40d11e <__swc_fn_e121059d_000070_357c932c+0x17e>
  40d0d3:	lea    rcx,[r14+r14*4]
  40d0d7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40d0dc:	test   rax,rax
  40d0df:	je     40d11e <__swc_fn_e121059d_000070_357c932c+0x17e>
  40d0e1:	mov    rcx,QWORD PTR [rax]
  40d0e4:	test   rcx,rcx
  40d0e7:	je     40d0f5 <__swc_fn_e121059d_000070_357c932c+0x155>
  40d0e9:	mov    rdx,QWORD PTR [rcx]
  40d0ec:	mov    QWORD PTR [rax],rdx
  40d0ef:	add    DWORD PTR [rax+0x28],0x1
  40d0f3:	jmp    40d112 <__swc_fn_e121059d_000070_357c932c+0x172>
  40d0f5:	mov    rcx,QWORD PTR [rax+0x18]
  40d0f9:	cmp    QWORD PTR [rax+0x20],rcx
  40d0fd:	jae    40d110 <__swc_fn_e121059d_000070_357c932c+0x170>
  40d0ff:	mov    rcx,QWORD PTR [rax+0x20]
  40d103:	mov    edx,DWORD PTR [rax+0x2c]
  40d106:	add    QWORD PTR [rax+0x20],rdx
  40d10a:	add    DWORD PTR [rax+0x28],0x1
  40d10e:	jmp    40d112 <__swc_fn_e121059d_000070_357c932c+0x172>
  40d110:	xor    ecx,ecx
  40d112:	test   rcx,rcx
  40d115:	je     40d11e <__swc_fn_e121059d_000070_357c932c+0x17e>
  40d117:	mov    QWORD PTR [r12+0x40],rcx
  40d11c:	jmp    40d129 <__swc_fn_e121059d_000070_357c932c+0x189>
  40d11e:	mov    rcx,r13
  40d121:	mov    rdx,r12
  40d124:	call   40fd00 <__swc_fn_e121059d_000071_1e1e3bf8>
  40d129:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40d132:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40d13b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40d144:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40d14d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40d156:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40d15f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40d168:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40d171:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40d17a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40d183:	add    rsp,0x1a0
  40d18a:	pop    rsi
  40d18b:	pop    rdi
  40d18c:	pop    r14
  40d18e:	pop    r13
  40d190:	pop    r12
  40d192:	ret
	...

000000000040d1a0 <__swc_fn_e121059d_000073_cdd57f51>:
  40d1a0:	push   r12
  40d1a2:	push   r13
  40d1a4:	push   r14
  40d1a6:	push   r15
  40d1a8:	push   rdi
  40d1a9:	push   rsi
  40d1aa:	sub    rsp,0x188
  40d1b1:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40d1ba:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40d1c3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40d1cc:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40d1d5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40d1de:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40d1e7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40d1f0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40d1f9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40d202:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40d20b:	mov    r12,rdx
  40d20e:	mov    r13,rcx
  40d211:	mov    r14,QWORD PTR [r12+0x40]
  40d216:	lea    rax,[rip+0x16e53]        # 424070 <__swc_bss_base_e121059d+0x30>
  40d21d:	mov    rcx,r14
  40d220:	sub    rcx,QWORD PTR [rax+0x8]
  40d224:	mov    rax,QWORD PTR [rip+0x16e55]        # 424080 <__swc_bss_base_e121059d+0x40>
  40d22b:	cmp    rcx,rax
  40d22e:	jae    40d25a <__swc_fn_e121059d_000073_cdd57f51+0xba>
  40d230:	mov    rax,r14
  40d233:	and    rax,0xffffffffffc00000
  40d23a:	mov    rcx,r14
  40d23d:	shr    rcx,0x10
  40d241:	and    ecx,0x3f
  40d244:	mov    edx,DWORD PTR [rax+0x28]
  40d247:	shrx   ecx,ecx,edx
  40d24c:	shl    rcx,0x4
  40d250:	lea    r15,[rax+rcx*8+0x80]
  40d258:	jmp    40d265 <__swc_fn_e121059d_000073_cdd57f51+0xc5>
  40d25a:	mov    rcx,r14
  40d25d:	call   40bd30 <__swc_fn_e121059d_000022_53fc00d2>
  40d262:	mov    r15,rax
  40d265:	test   r15,r15
  40d268:	je     40d30f <__swc_fn_e121059d_000073_cdd57f51+0x16f>
  40d26e:	lea    rax,[rip+0x14d8b]        # 422000 <__swc_data_base_e121059d>
  40d275:	mov    rax,QWORD PTR [rax]
  40d278:	cmp    rax,0xffffffffffffffff
  40d27c:	je     40d28b <__swc_fn_e121059d_000073_cdd57f51+0xeb>
  40d27e:	mov    eax,eax
  40d280:	mov    edi,eax
  40d282:	xor    eax,eax
  40d284:	call   407000 <pthread_getspecific@plt>
  40d289:	jmp    40d28d <__swc_fn_e121059d_000073_cdd57f51+0xed>
  40d28b:	xor    eax,eax
  40d28d:	mov    rcx,QWORD PTR [r15+0x40]
  40d291:	cmp    rcx,rax
  40d294:	jne    40d2f4 <__swc_fn_e121059d_000073_cdd57f51+0x154>
  40d296:	test   rax,rax
  40d299:	je     40d30f <__swc_fn_e121059d_000073_cdd57f51+0x16f>
  40d29b:	mov    ecx,DWORD PTR [r15+0x6c]
  40d29f:	test   ecx,ecx
  40d2a1:	je     40d2c1 <__swc_fn_e121059d_000073_cdd57f51+0x121>
  40d2a3:	mov    rcx,r13
  40d2a6:	mov    rdx,rax
  40d2a9:	mov    r8,r15
  40d2ac:	mov    QWORD PTR [rsp+0xd8],rax
  40d2b4:	call   40f210 <__swc_fn_e121059d_000047_e7fd8d42>
  40d2b9:	mov    rax,QWORD PTR [rsp+0xd8]
  40d2c1:	mov    rcx,QWORD PTR [r15]
  40d2c4:	mov    QWORD PTR [r14],rcx
  40d2c7:	mov    QWORD PTR [r15],r14
  40d2ca:	sub    DWORD PTR [r15+0x28],0x1
  40d2cf:	jne    40d304 <__swc_fn_e121059d_000073_cdd57f51+0x164>
  40d2d1:	movzx  ecx,BYTE PTR [r15+0x39]
  40d2d6:	lea    rcx,[rcx+rcx*4]
  40d2da:	lea    rcx,[rax+rcx*8+0x28]
  40d2df:	cmp    QWORD PTR [rcx],r15
  40d2e2:	je     40d304 <__swc_fn_e121059d_000073_cdd57f51+0x164>
  40d2e4:	mov    rcx,r13
  40d2e7:	mov    rdx,rax
  40d2ea:	mov    r8,r15
  40d2ed:	call   407d80 <__swc_fn_e121059d_000051_27d2a35f>
  40d2f2:	jmp    40d304 <__swc_fn_e121059d_000073_cdd57f51+0x164>
  40d2f4:	test   rcx,rcx
  40d2f7:	je     40d30f <__swc_fn_e121059d_000073_cdd57f51+0x16f>
  40d2f9:	mov    rcx,r15
  40d2fc:	mov    rdx,r14
  40d2ff:	call   40b970 <__swc_fn_e121059d_000010_0569f799>
  40d304:	mov    QWORD PTR [r12+0x40],0x0
  40d30d:	jmp    40d31a <__swc_fn_e121059d_000073_cdd57f51+0x17a>
  40d30f:	mov    rcx,r13
  40d312:	mov    rdx,r12
  40d315:	call   40fd20 <__swc_fn_e121059d_000074_30b8696a>
  40d31a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40d323:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40d32c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40d335:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40d33e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40d347:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40d350:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40d359:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40d362:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40d36b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40d374:	add    rsp,0x188
  40d37b:	pop    rsi
  40d37c:	pop    rdi
  40d37d:	pop    r15
  40d37f:	pop    r14
  40d381:	pop    r13
  40d383:	pop    r12
  40d385:	ret
	...

000000000040d390 <__swc_fn_e121059d_000076_c3ad0fb4>:
  40d390:	sub    rsp,0x8
  40d394:	mov    rax,rdx
  40d397:	mov    rdx,QWORD PTR [rax+0x40]
  40d39b:	mov    r8,rax
  40d39e:	call   40cf90 <__swc_fn_e121059d_000067_0145abfc>
  40d3a3:	add    rsp,0x8
  40d3a7:	ret
	...

000000000040d3b0 <__swc_fn_e121059d_000079_633af784>:
  40d3b0:	push   rsi
  40d3b1:	push   rdi
  40d3b2:	sub    rsp,0x8
  40d3b6:	cmp    rcx,0xffffffffffffffef
  40d3ba:	ja     40d3e0 <__swc_fn_e121059d_000079_633af784+0x30>
  40d3bc:	xor    esi,esi
  40d3be:	lea    rax,[rcx+0x100f]
  40d3c5:	and    rax,0xfffffffffffff000
  40d3cc:	lea    rcx,[rcx+0x10]
  40d3d0:	cmp    rcx,0xfffffffffffff000
  40d3d7:	cmovbe rsi,rax
  40d3db:	test   rsi,rsi
  40d3de:	jne    40d3e9 <__swc_fn_e121059d_000079_633af784+0x39>
  40d3e0:	xor    eax,eax
  40d3e2:	add    rsp,0x8
  40d3e6:	pop    rdi
  40d3e7:	pop    rsi
  40d3e8:	ret
  40d3e9:	mov    rcx,rsi
  40d3ec:	call   410950 <__swc_fn_e121059d_000110_9f5af8ae>
  40d3f1:	mov    rdi,rax
  40d3f4:	test   rax,rax
  40d3f7:	jne    40d402 <__swc_fn_e121059d_000079_633af784+0x52>
  40d3f9:	xor    eax,eax
  40d3fb:	add    rsp,0x8
  40d3ff:	pop    rdi
  40d400:	pop    rsi
  40d401:	ret
  40d402:	mov    rcx,rdi
  40d405:	mov    rdx,rsi
  40d408:	call   40d9e0 <__swc_fn_e121059d_000112_f9e19033>
  40d40d:	test   al,al
  40d40f:	jne    40d425 <__swc_fn_e121059d_000079_633af784+0x75>
  40d411:	mov    rcx,rdi
  40d414:	mov    rdx,rsi
  40d417:	call   409850 <__swc_fn_e121059d_000114_4e83a03a>
  40d41c:	xor    eax,eax
  40d41e:	add    rsp,0x8
  40d422:	pop    rdi
  40d423:	pop    rsi
  40d424:	ret
  40d425:	mov    QWORD PTR [rdi],rsi
  40d428:	mov    QWORD PTR [rdi+0x8],0x0
  40d430:	lea    rax,[rdi+0x10]
  40d434:	add    rsp,0x8
  40d438:	pop    rdi
  40d439:	pop    rsi
  40d43a:	ret
  40d43b:	add    BYTE PTR [rax],al
  40d43d:	add    BYTE PTR [rax],al
	...

000000000040d440 <__swc_fn_e121059d_000082_ff7d1455>:
  40d440:	sub    rsp,0x8
  40d444:	cmp    BYTE PTR [rcx+0x2c],0x10
  40d448:	jne    40d453 <__swc_fn_e121059d_000082_ff7d1455+0x13>
  40d44a:	test   DWORD PTR [rcx+0x28],0x80
  40d451:	je     40d45b <__swc_fn_e121059d_000082_ff7d1455+0x1b>
  40d453:	mov    rax,rcx
  40d456:	add    rsp,0x8
  40d45a:	ret
  40d45b:	mov    rcx,QWORD PTR [rcx+0x40]
  40d45f:	call   40d440 <__swc_fn_e121059d_000082_ff7d1455>
  40d464:	add    rsp,0x8
  40d468:	ret
	...

000000000040d480 <__swc_fn_e121059d_000085_e24ecd12>:
  40d480:	push   rsi
  40d481:	push   rdi
  40d482:	push   r12
  40d484:	push   r13
  40d486:	sub    rsp,0x8
  40d48a:	mov    rsi,rdx
  40d48d:	mov    rdi,rcx
  40d490:	xor    r8d,r8d
  40d493:	call   4085a0 <__swc_fn_e121059d_000090_14cf59b2>
  40d498:	test   al,al
  40d49a:	je     40d4ac <__swc_fn_e121059d_000085_e24ecd12+0x2c>
  40d49c:	mov    eax,0x1
  40d4a1:	add    rsp,0x8
  40d4a5:	pop    r13
  40d4a7:	pop    r12
  40d4a9:	pop    rdi
  40d4aa:	pop    rsi
  40d4ab:	ret
  40d4ac:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40d4b1:	je     40d4c0 <__swc_fn_e121059d_000085_e24ecd12+0x40>
  40d4b3:	xor    eax,eax
  40d4b5:	add    rsp,0x8
  40d4b9:	pop    r13
  40d4bb:	pop    r12
  40d4bd:	pop    rdi
  40d4be:	pop    rsi
  40d4bf:	ret
  40d4c0:	mov    r12,QWORD PTR [rsi+0x98]
  40d4c7:	mov    rax,QWORD PTR [rsi+0xa0]
  40d4ce:	mov    rsi,rax
  40d4d1:	xor    r13d,r13d
  40d4d4:	test   rsi,rsi
  40d4d7:	je     40d534 <__swc_fn_e121059d_000085_e24ecd12+0xb4>
  40d4d9:	cs nop WORD PTR [rax+rax*1+0x0]
  40d4e3:	cs nop WORD PTR [rax+rax*1+0x0]
  40d4ed:	nop    DWORD PTR [rax]
  40d4f0:	lea    rax,[r13*8+0x0]
  40d4f8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40d4fd:	mov    rcx,rax
  40d500:	call   40d440 <__swc_fn_e121059d_000082_ff7d1455>
  40d505:	cmp    BYTE PTR [rax+0x2c],0xe
  40d509:	jne    40d52a <__swc_fn_e121059d_000085_e24ecd12+0xaa>
  40d50b:	mov    rcx,rdi
  40d50e:	mov    rdx,rax
  40d511:	call   40d480 <__swc_fn_e121059d_000085_e24ecd12>
  40d516:	test   al,al
  40d518:	je     40d52a <__swc_fn_e121059d_000085_e24ecd12+0xaa>
  40d51a:	mov    eax,0x1
  40d51f:	add    rsp,0x8
  40d523:	pop    r13
  40d525:	pop    r12
  40d527:	pop    rdi
  40d528:	pop    rsi
  40d529:	ret
  40d52a:	add    r13,0x1
  40d52e:	sub    rsi,0x1
  40d532:	jne    40d4f0 <__swc_fn_e121059d_000085_e24ecd12+0x70>
  40d534:	xor    eax,eax
  40d536:	add    rsp,0x8
  40d53a:	pop    r13
  40d53c:	pop    r12
  40d53e:	pop    rdi
  40d53f:	pop    rsi
  40d540:	ret
	...

000000000040d550 <__swc_fn_e121059d_000088_ab2f35d8>:
  40d550:	sub    rsp,0x18
  40d554:	vxorps xmm0,xmm0,xmm0
  40d558:	vmovdqu XMMWORD PTR [rsp],xmm0
  40d55d:	call   40ff30 <__swc_fn_e121059d_000089_3c530920>
  40d562:	add    rsp,0x18
  40d566:	ret
	...

000000000040d570 <__swc_fn_e121059d_000091_f21926ed>:
  40d570:	sub    rsp,0x8
  40d574:	mov    rcx,QWORD PTR [rip+0x197c5]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d57b:	test   rcx,rcx
  40d57e:	jne    40d590 <__swc_fn_e121059d_000091_f21926ed+0x20>
  40d580:	call   40e940 <__swc_fn_e121059d_000166_56054fe7>
  40d585:	lea    rcx,[rax+0x1]
  40d589:	mov    QWORD PTR [rip+0x197b0],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d590:	dec    rcx
  40d593:	call   40b620 <__swc_fn_e121059d_000168_39c041ad>
  40d598:	mov    rax,QWORD PTR [rax+0xc0]
  40d59f:	and    eax,0x1
  40d5a2:	setne  al
  40d5a5:	add    rsp,0x8
  40d5a9:	ret
	...

000000000040d5c0 <__swc_fn_e121059d_000094_383a814c>:
  40d5c0:	push   rbx
  40d5c1:	push   rsi
  40d5c2:	push   rdi
  40d5c3:	push   r12
  40d5c5:	sub    rsp,0x28
  40d5c9:	mov    rbx,rcx
  40d5cc:	call   408900 <__swc_fn_e121059d_000093_0c97fc6c>
  40d5d1:	mov    rcx,QWORD PTR [rip+0x19768]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d5d8:	test   rcx,rcx
  40d5db:	jne    40d5ed <__swc_fn_e121059d_000094_383a814c+0x2d>
  40d5dd:	call   40e940 <__swc_fn_e121059d_000166_56054fe7>
  40d5e2:	lea    rcx,[rax+0x1]
  40d5e6:	mov    QWORD PTR [rip+0x19753],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d5ed:	dec    rcx
  40d5f0:	call   40b620 <__swc_fn_e121059d_000168_39c041ad>
  40d5f5:	mov    rsi,rax
  40d5f8:	lea    rcx,[rsp+0x8]
  40d5fd:	call   410370 <__swc_fn_e121059d_000092_809deff5>
  40d602:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40d609:	mov    r12,QWORD PTR [rsi+0xbe8]
  40d610:	lea    rcx,[rsi+0x10]
  40d614:	call   4114b0 <__swc_fn_e121059d_000158_3495a3ca>
  40d619:	mov    rcx,rsi
  40d61c:	call   4104e0 <__swc_fn_e121059d_000101_afcb7774>
  40d621:	vxorps xmm0,xmm0,xmm0
  40d625:	xor    eax,eax
  40d627:	cs nop WORD PTR [rax+rax*1+0x0]
  40d631:	cs nop WORD PTR [rax+rax*1+0x0]
  40d63b:	nop    DWORD PTR [rax+rax*1+0x0]
  40d640:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40d645:	add    rax,0x10
  40d649:	cmp    rax,0xbf0
  40d650:	jne    40d640 <__swc_fn_e121059d_000094_383a814c+0x80>
  40d652:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40d658:	vmovups XMMWORD PTR [rsi],xmm0
  40d65c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40d662:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40d66a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40d671:	mov    QWORD PTR [rsi+0xbe8],r12
  40d678:	mov    rcx,QWORD PTR [rip+0x196c1]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d67f:	test   rcx,rcx
  40d682:	jne    40d694 <__swc_fn_e121059d_000094_383a814c+0xd4>
  40d684:	call   40e940 <__swc_fn_e121059d_000166_56054fe7>
  40d689:	lea    rcx,[rax+0x1]
  40d68d:	mov    QWORD PTR [rip+0x196ac],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d694:	dec    rcx
  40d697:	call   40b620 <__swc_fn_e121059d_000168_39c041ad>
  40d69c:	mov    rsi,rax
  40d69f:	mov    QWORD PTR [rsi+0xc0],rbx
  40d6a6:	and    ebx,0x1
  40d6a9:	jne    40d6ad <__swc_fn_e121059d_000094_383a814c+0xed>
  40d6ab:	xor    eax,eax
  40d6ad:	test   rbx,rbx
  40d6b0:	sete   al
  40d6b3:	xor    cl,cl
  40d6b5:	xor    dl,dl
  40d6b7:	xor    r8b,r8b
  40d6ba:	xor    r9b,r9b
  40d6bd:	xor    r10b,r10b
  40d6c0:	mov    r11,rax
  40d6c3:	call   40fd30 <__swc_fn_e121059d_000077_948ef603>
  40d6c8:	lea    rbx,[rsp+0x18]
  40d6cd:	mov    rcx,rbx
  40d6d0:	call   410370 <__swc_fn_e121059d_000092_809deff5>
  40d6d5:	lea    rcx,[rsi+0x10]
  40d6d9:	mov    edx,0x400000
  40d6de:	mov    r8,rbx
  40d6e1:	call   40e680 <__swc_fn_e121059d_000160_6861d596>
  40d6e6:	lea    rcx,[rsi+0x68]
  40d6ea:	mov    edx,0x4000
  40d6ef:	mov    r8,rbx
  40d6f2:	call   40e680 <__swc_fn_e121059d_000160_6861d596>
  40d6f7:	add    rsp,0x28
  40d6fb:	pop    r12
  40d6fd:	pop    rdi
  40d6fe:	pop    rsi
  40d6ff:	pop    rbx
  40d700:	ret
	...

000000000040d710 <__swc_fn_e121059d_000097_96d6739a>:
  40d710:	push   rbx
  40d711:	push   rsi
  40d712:	sub    rsp,0x18
  40d716:	mov    rbx,rcx
  40d719:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40d71e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d724:	mov    rsi,QWORD PTR [rbx+0x70]
  40d728:	lea    rcx,[rcx+0x18]
  40d72c:	call   4114b0 <__swc_fn_e121059d_000158_3495a3ca>
  40d731:	lea    rcx,[rsp+0x8]
  40d736:	mov    rdx,rbx
  40d739:	mov    r8d,0x78
  40d73f:	call   408960 <__swc_fn_e121059d_000096_a4baaa40>
  40d744:	mov    rax,rsi
  40d747:	add    rsp,0x18
  40d74b:	pop    rsi
  40d74c:	pop    rbx
  40d74d:	ret
	...

000000000040d750 <__swc_fn_e121059d_000100_5714513e>:
  40d750:	push   rsi
  40d751:	push   rdi
  40d752:	sub    rsp,0x8
  40d756:	cmp    QWORD PTR [rcx],0x0
  40d75a:	jne    40d763 <__swc_fn_e121059d_000100_5714513e+0x13>
  40d75c:	add    rsp,0x8
  40d760:	pop    rdi
  40d761:	pop    rsi
  40d762:	ret
  40d763:	mov    rsi,QWORD PTR [rcx]
  40d766:	mov    rax,QWORD PTR [rcx+0x8]
  40d76a:	test   rax,rax
  40d76d:	je     40d783 <__swc_fn_e121059d_000100_5714513e+0x33>
  40d76f:	test   DWORD PTR [rax+0x28],0x400000
  40d776:	je     40d783 <__swc_fn_e121059d_000100_5714513e+0x33>
  40d778:	mov    rcx,QWORD PTR [rax+0x30]
  40d77c:	test   rcx,rcx
  40d77f:	cmovne rax,rcx
  40d783:	lea    rdx,[rip+0x5a46]        # 4131d0 <__swc_rdata_base_e121059d+0xc0>
  40d78a:	lea    rcx,[rip+0x5b27]        # 4132b8 <__swc_rdata_base_e121059d+0x1a8>
  40d791:	mov    r8,rax
  40d794:	xor    r9d,r9d
  40d797:	xor    al,al
  40d799:	mov    r10,rax
  40d79c:	xor    r11d,r11d
  40d79f:	call   40d550 <__swc_fn_e121059d_000088_ab2f35d8>
  40d7a4:	test   rax,rax
  40d7a7:	je     40d7b7 <__swc_fn_e121059d_000100_5714513e+0x67>
  40d7a9:	mov    rdi,QWORD PTR [rax+0x48]
  40d7ad:	test   rdi,rdi
  40d7b0:	je     40d7b7 <__swc_fn_e121059d_000100_5714513e+0x67>
  40d7b2:	mov    rcx,rsi
  40d7b5:	call   rdi
  40d7b7:	add    rsp,0x8
  40d7bb:	pop    rdi
  40d7bc:	pop    rsi
  40d7bd:	ret
	...

000000000040d7c0 <__swc_fn_e121059d_000103_0d4cc079>:
  40d7c0:	push   rbx
  40d7c1:	push   rsi
  40d7c2:	push   rdi
  40d7c3:	sub    rsp,0x20
  40d7c7:	mov    rbx,rdx
  40d7ca:	mov    rsi,rcx
  40d7cd:	mov    rcx,QWORD PTR [rip+0x1956c]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d7d4:	test   rcx,rcx
  40d7d7:	jne    40d7e9 <__swc_fn_e121059d_000103_0d4cc079+0x29>
  40d7d9:	call   40e940 <__swc_fn_e121059d_000166_56054fe7>
  40d7de:	lea    rcx,[rax+0x1]
  40d7e2:	mov    QWORD PTR [rip+0x19557],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d7e9:	dec    rcx
  40d7ec:	call   40b620 <__swc_fn_e121059d_000168_39c041ad>
  40d7f1:	mov    rdi,rax
  40d7f4:	mov    rax,QWORD PTR [rdi+0xbd0]
  40d7fb:	xor    ecx,ecx
  40d7fd:	test   rax,rax
  40d800:	je     40d805 <__swc_fn_e121059d_000103_0d4cc079+0x45>
  40d802:	mov    rcx,QWORD PTR [rax]
  40d805:	call   40ea70 <__swc_fn_e121059d_000175_02e645b4>
  40d80a:	lea    rax,[rsp+0x8]
  40d80f:	lea    rcx,[rdi+0x9c8]
  40d816:	mov    QWORD PTR [rsp+0x8],rcx
  40d81b:	mov    QWORD PTR [rax+0x8],0x40
  40d823:	xor    ecx,ecx
  40d825:	mov    rdx,rax
  40d828:	call   409980 <__swc_fn_e121059d_000120_2d9caf16>
  40d82d:	mov    DWORD PTR [rdi+0xbc8],eax
  40d833:	mov    rdi,QWORD PTR [rdi+0x990]
  40d83a:	test   rdi,rdi
  40d83d:	je     40d847 <__swc_fn_e121059d_000103_0d4cc079+0x87>
  40d83f:	mov    rcx,rsi
  40d842:	mov    rdx,rbx
  40d845:	call   rdi
  40d847:	call   40d570 <__swc_fn_e121059d_000091_f21926ed>
  40d84c:	test   al,al
  40d84e:	je     40d85e <__swc_fn_e121059d_000103_0d4cc079+0x9e>
  40d850:	mov    rcx,rsi
  40d853:	mov    rdx,rbx
  40d856:	xor    r8d,r8d
  40d859:	call   40db80 <__swc_fn_e121059d_000121_1e032ef6>
  40d85e:	mov    rcx,rsi
  40d861:	mov    rdx,rbx
  40d864:	call   408a60 <__swc_fn_e121059d_000102_14986ec5>
  40d869:	call   410d00 <__swc_fn_e121059d_000119_591530fe>
  40d86e:	add    rsp,0x20
  40d872:	pop    rdi
  40d873:	pop    rsi
  40d874:	pop    rbx
  40d875:	ret
	...

000000000040d880 <__swc_fn_e121059d_000106_83487ba1>:
  40d880:	sub    rsp,0x8
  40d884:	test   r8,r8
  40d887:	je     40d88e <__swc_fn_e121059d_000106_83487ba1+0xe>
  40d889:	call   4106b0 <__swc_fn_e121059d_000104_04d1a8be>
  40d88e:	add    rsp,0x8
  40d892:	ret
	...

000000000040d8a0 <__swc_fn_e121059d_000109_b8f4bd15>:
  40d8a0:	push   rsi
  40d8a1:	push   rdi
  40d8a2:	push   r12
  40d8a4:	push   r13
  40d8a6:	sub    rsp,0xd8
  40d8ad:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40d8b3:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40d8b9:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40d8bf:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40d8c5:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40d8cb:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40d8d4:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40d8dd:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40d8e6:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40d8ef:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40d8f8:	xor    eax,eax
  40d8fa:	call   407050 <getpid@plt>
  40d8ff:	mov    rsi,rax
  40d902:	lea    rdi,[rip+0x1943f]        # 426d48 <__swc_bss_base_e121059d+0x2d08>
  40d909:	mov    r12,QWORD PTR [rdi]
  40d90c:	test   r12,r12
  40d90f:	je     40d91d <__swc_fn_e121059d_000109_b8f4bd15+0x7d>
  40d911:	cmp    DWORD PTR [r12+0x10],esi
  40d916:	jne    40d91d <__swc_fn_e121059d_000109_b8f4bd15+0x7d>
  40d918:	mov    rax,r12
  40d91b:	jmp    40d980 <__swc_fn_e121059d_000109_b8f4bd15+0xe0>
  40d91d:	mov    ecx,0x4
  40d922:	mov    edx,0x18
  40d927:	call   409190 <__swc_fn_e121059d_000108_c8d4a68e>
  40d92c:	mov    rcx,rax
  40d92f:	test   rax,rax
  40d932:	jne    40d938 <__swc_fn_e121059d_000109_b8f4bd15+0x98>
  40d934:	xor    eax,eax
  40d936:	jmp    40d980 <__swc_fn_e121059d_000109_b8f4bd15+0xe0>
  40d938:	mov    DWORD PTR [rcx+0x10],esi
  40d93b:	mov    rax,r12
  40d93e:	lock cmpxchg QWORD PTR [rdi],rcx
  40d943:	mov    r13,rax
  40d946:	cmp    rax,r12
  40d949:	je     40d95f <__swc_fn_e121059d_000109_b8f4bd15+0xbf>
  40d94b:	mov    rdi,rcx
  40d94e:	mov    esi,0x18
  40d953:	xor    eax,eax
  40d955:	call   407160 <munmap@plt>
  40d95a:	mov    rax,r13
  40d95d:	jmp    40d980 <__swc_fn_e121059d_000109_b8f4bd15+0xe0>
  40d95f:	test   r12,r12
  40d962:	je     40d97d <__swc_fn_e121059d_000109_b8f4bd15+0xdd>
  40d964:	mov    rdi,r12
  40d967:	mov    esi,0x18
  40d96c:	xor    eax,eax
  40d96e:	mov    QWORD PTR [rsp+0x28],rcx
  40d973:	call   407160 <munmap@plt>
  40d978:	mov    rcx,QWORD PTR [rsp+0x28]
  40d97d:	mov    rax,rcx
  40d980:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40d986:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40d98c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40d992:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40d998:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40d99e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40d9a7:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40d9b0:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40d9b9:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40d9c2:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40d9cb:	add    rsp,0xd8
  40d9d2:	pop    r13
  40d9d4:	pop    r12
  40d9d6:	pop    rdi
  40d9d7:	pop    rsi
  40d9d8:	ret
  40d9d9:	add    BYTE PTR [rax],al
  40d9db:	add    BYTE PTR [rax],al
  40d9dd:	add    BYTE PTR [rax],al
	...

000000000040d9e0 <__swc_fn_e121059d_000112_f9e19033>:
  40d9e0:	push   rbx
  40d9e1:	push   r12
  40d9e3:	push   rdi
  40d9e4:	push   rsi
  40d9e5:	sub    rsp,0xa8
  40d9ec:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d9f2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d9f8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d9fe:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40da04:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40da0a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40da10:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40da16:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40da1c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40da25:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40da2e:	mov    rbx,rdx
  40da31:	mov    r12,rcx
  40da34:	mov    rdi,rcx
  40da37:	mov    rsi,rdx
  40da3a:	mov    edx,0x3
  40da3f:	xor    eax,eax
  40da41:	call   407170 <mprotect@plt>
  40da46:	test   eax,eax
  40da48:	je     40da4e <__swc_fn_e121059d_000112_f9e19033+0x6e>
  40da4a:	xor    eax,eax
  40da4c:	jmp    40da63 <__swc_fn_e121059d_000112_f9e19033+0x83>
  40da4e:	mov    rcx,r12
  40da51:	mov    rdx,rbx
  40da54:	mov    al,0x1
  40da56:	mov    r8,rax
  40da59:	call   4097c0 <__swc_fn_e121059d_000111_918d5a21>
  40da5e:	mov    eax,0x1
  40da63:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40da69:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40da6f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40da75:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40da7b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40da81:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40da87:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40da8d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40da93:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40da9c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40daa5:	add    rsp,0xa8
  40daac:	pop    rsi
  40daad:	pop    rdi
  40daae:	pop    r12
  40dab0:	pop    rbx
  40dab1:	ret
	...

000000000040dac0 <__swc_fn_e121059d_000115_cc486df9>:
  40dac0:	sub    rsp,0x8
  40dac4:	test   rcx,rcx
  40dac7:	jne    40dace <__swc_fn_e121059d_000115_cc486df9+0xe>
  40dac9:	add    rsp,0x8
  40dacd:	ret
  40dace:	call   410bb0 <__swc_fn_e121059d_000116_3f6af4b1>
  40dad3:	add    rsp,0x8
  40dad7:	ret
	...

000000000040dae0 <__swc_fn_e121059d_000118_5aba1420>:
  40dae0:	push   rdi
  40dae1:	push   rsi
  40dae2:	sub    rsp,0xa8
  40dae9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40daef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40daf5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40dafb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40db01:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40db07:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40db0d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40db13:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40db19:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40db22:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40db2b:	xor    edi,edi
  40db2d:	xor    eax,eax
  40db2f:	call   407180 <exit@plt>
  40db34:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40db3a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40db40:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40db46:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40db4c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40db52:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40db58:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40db5e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40db64:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40db6d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40db76:	add    rsp,0xa8
  40db7d:	pop    rsi
  40db7e:	pop    rdi
  40db7f:	ret

000000000040db80 <__swc_fn_e121059d_000121_1e032ef6>:
  40db80:	push   rbx
  40db81:	push   rsi
  40db82:	push   rdi
  40db83:	push   r12
  40db85:	sub    rsp,0x18
  40db89:	mov    rbx,r8
  40db8c:	mov    rsi,rcx
  40db8f:	mov    rdi,rdx
  40db92:	mov    rcx,QWORD PTR [rip+0x191a7]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40db99:	test   rcx,rcx
  40db9c:	jne    40dbae <__swc_fn_e121059d_000121_1e032ef6+0x2e>
  40db9e:	call   40e940 <__swc_fn_e121059d_000166_56054fe7>
  40dba3:	lea    rcx,[rax+0x1]
  40dba7:	mov    QWORD PTR [rip+0x19192],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40dbae:	dec    rcx
  40dbb1:	call   40b620 <__swc_fn_e121059d_000168_39c041ad>
  40dbb6:	mov    r12,rax
  40dbb9:	cmp    ebx,0x3
  40dbbc:	jne    40dbcf <__swc_fn_e121059d_000121_1e032ef6+0x4f>
  40dbbe:	mov    rax,QWORD PTR [r12+0xbd0]
  40dbc6:	test   rax,rax
  40dbc9:	jne    40dd0c <__swc_fn_e121059d_000121_1e032ef6+0x18c>
  40dbcf:	cmp    ebx,0x5
  40dbd2:	jne    40dbf6 <__swc_fn_e121059d_000121_1e032ef6+0x76>
  40dbd4:	call   40d570 <__swc_fn_e121059d_000091_f21926ed>
  40dbd9:	test   al,al
  40dbdb:	jne    40dbf6 <__swc_fn_e121059d_000121_1e032ef6+0x76>
  40dbdd:	mov    rcx,rsi
  40dbe0:	mov    rdx,rdi
  40dbe3:	call   40b5d0 <__swc_fn_e121059d_000165_d25850aa>
  40dbe8:	test   al,al
  40dbea:	je     40dbf6 <__swc_fn_e121059d_000121_1e032ef6+0x76>
  40dbec:	add    rsp,0x18
  40dbf0:	pop    r12
  40dbf2:	pop    rdi
  40dbf3:	pop    rsi
  40dbf4:	pop    rbx
  40dbf5:	ret
  40dbf6:	call   40d570 <__swc_fn_e121059d_000091_f21926ed>
  40dbfb:	test   al,al
  40dbfd:	jne    40dc6f <__swc_fn_e121059d_000121_1e032ef6+0xef>
  40dbff:	vmovups xmm0,XMMWORD PTR [rsi]
  40dc03:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dc09:	mov    rax,QWORD PTR [rsp+0x8]
  40dc0e:	test   rax,rax
  40dc11:	jne    40dc62 <__swc_fn_e121059d_000121_1e032ef6+0xe2>
  40dc13:	cmp    ebx,0x3
  40dc16:	je     40dc24 <__swc_fn_e121059d_000121_1e032ef6+0xa4>
  40dc18:	cmp    ebx,0x4
  40dc1b:	je     40dc34 <__swc_fn_e121059d_000121_1e032ef6+0xb4>
  40dc1d:	cmp    ebx,0x5
  40dc20:	je     40dc44 <__swc_fn_e121059d_000121_1e032ef6+0xc4>
  40dc22:	jmp    40dc54 <__swc_fn_e121059d_000121_1e032ef6+0xd4>
  40dc24:	vmovups xmm0,XMMWORD PTR [rip+0x58b4]        # 4134e0 <__swc_rdata_base_e121059d+0x3d0>
  40dc2c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dc32:	jmp    40dc62 <__swc_fn_e121059d_000121_1e032ef6+0xe2>
  40dc34:	vmovups xmm0,XMMWORD PTR [rip+0x58b4]        # 4134f0 <__swc_rdata_base_e121059d+0x3e0>
  40dc3c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dc42:	jmp    40dc62 <__swc_fn_e121059d_000121_1e032ef6+0xe2>
  40dc44:	vmovups xmm0,XMMWORD PTR [rip+0x58b4]        # 413500 <__swc_rdata_base_e121059d+0x3f0>
  40dc4c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dc52:	jmp    40dc62 <__swc_fn_e121059d_000121_1e032ef6+0xe2>
  40dc54:	vmovups xmm0,XMMWORD PTR [rip+0x58b4]        # 413510 <__swc_rdata_base_e121059d+0x400>
  40dc5c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dc62:	lea    rcx,[rsp+0x8]
  40dc67:	mov    rdx,rdi
  40dc6a:	call   40d7c0 <__swc_fn_e121059d_000103_0d4cc079>
  40dc6f:	vmovups xmm0,XMMWORD PTR [rdi]
  40dc73:	vmovups XMMWORD PTR [r12+0x940],xmm0
  40dc7d:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  40dc82:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40dc8c:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  40dc91:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40dc9b:	lea    rax,[r12+0x940]
  40dca3:	mov    QWORD PTR [r12+0x970],rax
  40dcab:	mov    rax,QWORD PTR [rsi]
  40dcae:	mov    QWORD PTR [r12+0x978],rax
  40dcb6:	mov    rax,QWORD PTR [rsi+0x8]
  40dcba:	mov    QWORD PTR [r12+0x980],rax
  40dcc2:	movsxd rax,ebx
  40dcc5:	mov    QWORD PTR [r12+0x988],rax
  40dccd:	cmp    ebx,0x5
  40dcd0:	je     40dcd9 <__swc_fn_e121059d_000121_1e032ef6+0x159>
  40dcd2:	xor    ecx,ecx
  40dcd4:	call   40ea70 <__swc_fn_e121059d_000175_02e645b4>
  40dcd9:	mov    rbx,QWORD PTR [r12+0xbe8]
  40dce1:	test   rbx,rbx
  40dce4:	je     40dcf5 <__swc_fn_e121059d_000121_1e032ef6+0x175>
  40dce6:	mov    rcx,r12
  40dce9:	call   rbx
  40dceb:	add    rsp,0x18
  40dcef:	pop    r12
  40dcf1:	pop    rdi
  40dcf2:	pop    rsi
  40dcf3:	pop    rbx
  40dcf4:	ret
  40dcf5:	mov    rcx,rsi
  40dcf8:	call   409870 <__swc_fn_e121059d_000117_3f5cfdef>
  40dcfd:	call   410d00 <__swc_fn_e121059d_000119_591530fe>
  40dd02:	add    rsp,0x18
  40dd06:	pop    r12
  40dd08:	pop    rdi
  40dd09:	pop    rsi
  40dd0a:	pop    rbx
  40dd0b:	ret
  40dd0c:	mov    rcx,rsi
  40dd0f:	mov    rdx,rdi
  40dd12:	call   40d7c0 <__swc_fn_e121059d_000103_0d4cc079>
  40dd17:	jmp    40dbcf <__swc_fn_e121059d_000121_1e032ef6+0x4f>
  40dd1c:	add    BYTE PTR [rax],al
	...

000000000040dd20 <__swc_fn_e121059d_000124_e4107ade>:
  40dd20:	push   rdi
  40dd21:	push   rsi
  40dd22:	sub    rsp,0xb8
  40dd29:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40dd2f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40dd35:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40dd3b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40dd41:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40dd47:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40dd4d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40dd53:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40dd5c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40dd65:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40dd6e:	mov    DWORD PTR [rsp+0x8],0x0
  40dd76:	lea    rdi,[rsp+0x8]
  40dd7b:	xor    esi,esi
  40dd7d:	xor    eax,eax
  40dd7f:	call   407190 <pthread_key_create@plt>
  40dd84:	test   eax,eax
  40dd86:	jne    40dd8e <__swc_fn_e121059d_000124_e4107ade+0x6e>
  40dd88:	mov    eax,DWORD PTR [rsp+0x8]
  40dd8c:	jmp    40dd95 <__swc_fn_e121059d_000124_e4107ade+0x75>
  40dd8e:	mov    rax,0xffffffffffffffff
  40dd95:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40dd9b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40dda1:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40dda7:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ddad:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ddb3:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ddb9:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ddbf:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ddc8:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ddd1:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ddda:	add    rsp,0xb8
  40dde1:	pop    rsi
  40dde2:	pop    rdi
  40dde3:	ret
	...

000000000040ddf0 <__swc_fn_e121059d_000127_9e9697c7>:
  40ddf0:	push   rdi
  40ddf1:	push   rsi
  40ddf2:	sub    rsp,0xb8
  40ddf9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ddff:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40de05:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40de0b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40de11:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40de17:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40de1d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40de23:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40de2c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40de35:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40de3e:	mov    DWORD PTR [rsp+0x8],0x0
  40de46:	lea    rdi,[rsp+0x8]
  40de4b:	mov    rsi,rcx
  40de4e:	xor    eax,eax
  40de50:	call   407190 <pthread_key_create@plt>
  40de55:	test   eax,eax
  40de57:	jne    40de62 <__swc_fn_e121059d_000127_9e9697c7+0x72>
  40de59:	mov    eax,DWORD PTR [rsp+0x8]
  40de5d:	inc    rax
  40de60:	jmp    40de64 <__swc_fn_e121059d_000127_9e9697c7+0x74>
  40de62:	xor    eax,eax
  40de64:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40de6a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40de70:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40de76:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40de7c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40de82:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40de88:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40de8e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40de97:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40dea0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40dea9:	add    rsp,0xb8
  40deb0:	pop    rsi
  40deb1:	pop    rdi
  40deb2:	ret
	...

000000000040dec0 <__swc_fn_e121059d_000130_bc477461>:
  40dec0:	push   rdi
  40dec1:	push   rsi
  40dec2:	sub    rsp,0xa8
  40dec9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40decf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ded5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40dedb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40dee1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40dee7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40deed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40def3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40def9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40df02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40df0b:	test   rcx,rcx
  40df0e:	setne  al
  40df11:	je     40df2a <__swc_fn_e121059d_000130_bc477461+0x6a>
  40df13:	lea    rax,[rcx-0x1]
  40df17:	mov    eax,eax
  40df19:	mov    edi,eax
  40df1b:	mov    rsi,rdx
  40df1e:	xor    eax,eax
  40df20:	call   407120 <pthread_setspecific@plt>
  40df25:	test   eax,eax
  40df27:	sete   al
  40df2a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40df30:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40df36:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40df3c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40df42:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40df48:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40df4e:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40df54:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40df5a:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40df63:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40df6c:	add    rsp,0xa8
  40df73:	pop    rsi
  40df74:	pop    rdi
  40df75:	ret
	...

000000000040df80 <__swc_fn_e121059d_000133_51cc49e7>:
  40df80:	push   rdi
  40df81:	push   rsi
  40df82:	sub    rsp,0xa8
  40df89:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40df8f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40df95:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40df9b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40dfa1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40dfa7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40dfad:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40dfb3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40dfb9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40dfc2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40dfcb:	mov    rax,rdx
  40dfce:	mov    QWORD PTR [rsp],0x0
  40dfd6:	mov    edi,0xca
  40dfdb:	mov    rsi,rcx
  40dfde:	mov    edx,0x81
  40dfe3:	mov    eax,eax
  40dfe5:	mov    ecx,eax
  40dfe7:	xor    r8d,r8d
  40dfea:	xor    r9d,r9d
  40dfed:	xor    eax,eax
  40dfef:	call   4071a0 <syscall@plt>
  40dff4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40dffa:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e000:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e006:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e00c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e012:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e018:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e01e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e024:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e02d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e036:	add    rsp,0xa8
  40e03d:	pop    rsi
  40e03e:	pop    rdi
  40e03f:	ret

000000000040e040 <__swc_fn_e121059d_000136_db32cc57>:
  40e040:	sub    rsp,0x8
  40e044:	call   4110b0 <__swc_fn_e121059d_000134_807fd51d>
  40e049:	add    rsp,0x8
  40e04d:	ret
	...

000000000040e050 <__swc_fn_e121059d_000139_22d6573c>:
  40e050:	push   rdi
  40e051:	push   rsi
  40e052:	sub    rsp,0xc8
  40e059:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40e05f:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40e065:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40e06b:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40e071:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40e077:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40e07d:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40e086:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40e08f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40e098:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40e0a1:	vxorps xmm0,xmm0,xmm0
  40e0a5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e0ab:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e0b1:	mov    rdi,rcx
  40e0b4:	lea    rsi,[rsp+0x8]
  40e0b9:	xor    eax,eax
  40e0bb:	call   4071b0 <dladdr@plt>
  40e0c0:	xor    ecx,ecx
  40e0c2:	test   eax,eax
  40e0c4:	je     40e0cb <__swc_fn_e121059d_000139_22d6573c+0x7b>
  40e0c6:	mov    rcx,QWORD PTR [rsp+0x10]
  40e0cb:	mov    rax,rcx
  40e0ce:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40e0d4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40e0da:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40e0e0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40e0e6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40e0ec:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40e0f2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40e0fb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40e104:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40e10d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40e116:	add    rsp,0xc8
  40e11d:	pop    rsi
  40e11e:	pop    rdi
  40e11f:	ret

000000000040e120 <__swc_fn_e121059d_000142_5e493395>:
  40e120:	push   rbx
  40e121:	push   r12
  40e123:	push   r13
  40e125:	push   rdi
  40e126:	push   rsi
  40e127:	push   r14
  40e129:	push   r15
  40e12b:	sub    rsp,0x150
  40e132:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40e13b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40e144:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40e14d:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40e156:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40e15f:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40e168:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40e171:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40e17a:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40e183:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40e18c:	mov    rbx,rdx
  40e18f:	mov    QWORD PTR [rsp+0x98],rdx
  40e197:	mov    r12,rcx
  40e19a:	mov    QWORD PTR [rsp+0xa0],rcx
  40e1a2:	mov    QWORD PTR [rbx],0x0
  40e1a9:	lea    r13,[rip+0x18bd0]        # 426d80 <__swc_bss_base_e121059d+0x2d40>
  40e1b0:	mov    rcx,r13
  40e1b3:	call   40e040 <__swc_fn_e121059d_000136_db32cc57>
  40e1b8:	mov    rax,QWORD PTR [rip+0x18bc9]        # 426d88 <__swc_bss_base_e121059d+0x2d48>
  40e1bf:	test   rax,rax
  40e1c2:	je     40e1f9 <__swc_fn_e121059d_000142_5e493395+0xd9>
  40e1c4:	cs nop WORD PTR [rax+rax*1+0x0]
  40e1ce:	xchg   ax,ax
  40e1d0:	cmp    QWORD PTR [rax+0x8],r12
  40e1d4:	jne    40e1f1 <__swc_fn_e121059d_000142_5e493395+0xd1>
  40e1d6:	mov    rcx,QWORD PTR [rax+0x18]
  40e1da:	mov    QWORD PTR [rbx],rcx
  40e1dd:	mov    rbx,QWORD PTR [rax+0x10]
  40e1e1:	mov    rcx,r13
  40e1e4:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40e1e9:	mov    rax,rbx
  40e1ec:	jmp    40e3db <__swc_fn_e121059d_000142_5e493395+0x2bb>
  40e1f1:	mov    rax,QWORD PTR [rax]
  40e1f4:	test   rax,rax
  40e1f7:	jne    40e1d0 <__swc_fn_e121059d_000142_5e493395+0xb0>
  40e1f9:	vxorps xmm0,xmm0,xmm0
  40e1fd:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  40e203:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  40e209:	mov    rdi,r12
  40e20c:	lea    rsi,[rsp+0x10]
  40e211:	xor    eax,eax
  40e213:	call   4071b0 <dladdr@plt>
  40e218:	test   eax,eax
  40e21a:	sete   al
  40e21d:	je     40e22a <__swc_fn_e121059d_000142_5e493395+0x10a>
  40e21f:	mov    rax,QWORD PTR [rsp+0x10]
  40e224:	test   rax,rax
  40e227:	sete   al
  40e22a:	test   al,al
  40e22c:	je     40e23d <__swc_fn_e121059d_000142_5e493395+0x11d>
  40e22e:	mov    rcx,r13
  40e231:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40e236:	xor    eax,eax
  40e238:	jmp    40e3db <__swc_fn_e121059d_000142_5e493395+0x2bb>
  40e23d:	mov    rdi,QWORD PTR [rsp+0x10]
  40e242:	mov    esi,0x80000
  40e247:	xor    eax,eax
  40e249:	call   407010 <open@plt>
  40e24e:	lea    r14,[rsp+0x30]
  40e253:	mov    DWORD PTR [rsp+0x30],eax
  40e257:	cmp    DWORD PTR [r14],0x0
  40e25b:	jge    40e26c <__swc_fn_e121059d_000142_5e493395+0x14c>
  40e25d:	mov    rcx,r13
  40e260:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40e265:	xor    eax,eax
  40e267:	jmp    40e3db <__swc_fn_e121059d_000142_5e493395+0x2bb>
  40e26c:	mov    rax,r14
  40e26f:	movsxd rdi,DWORD PTR [rax]
  40e272:	xor    esi,esi
  40e274:	mov    edx,0x2
  40e279:	xor    eax,eax
  40e27b:	call   4070c0 <lseek@plt>
  40e280:	mov    r15,rax
  40e283:	test   rax,rax
  40e286:	jg     40e2a1 <__swc_fn_e121059d_000142_5e493395+0x181>
  40e288:	movsxd rdi,DWORD PTR [r14]
  40e28b:	xor    eax,eax
  40e28d:	call   407040 <close@plt>
  40e292:	mov    rcx,r13
  40e295:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40e29a:	xor    eax,eax
  40e29c:	jmp    40e3db <__swc_fn_e121059d_000142_5e493395+0x2bb>
  40e2a1:	xor    edi,edi
  40e2a3:	mov    rsi,r15
  40e2a6:	mov    edx,0x1
  40e2ab:	mov    ecx,0x2
  40e2b0:	mov    rax,r14
  40e2b3:	movsxd r8,DWORD PTR [rax]
  40e2b6:	xor    r9d,r9d
  40e2b9:	xor    eax,eax
  40e2bb:	call   4070d0 <mmap@plt>
  40e2c0:	mov    rbx,rax
  40e2c3:	test   rax,rax
  40e2c6:	sete   al
  40e2c9:	cmp    rbx,0xffffffffffffffff
  40e2cd:	sete   cl
  40e2d0:	or     al,cl
  40e2d2:	je     40e2ed <__swc_fn_e121059d_000142_5e493395+0x1cd>
  40e2d4:	movsxd rdi,DWORD PTR [r14]
  40e2d7:	xor    eax,eax
  40e2d9:	call   407040 <close@plt>
  40e2de:	mov    rcx,r13
  40e2e1:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40e2e6:	xor    eax,eax
  40e2e8:	jmp    40e3db <__swc_fn_e121059d_000142_5e493395+0x2bb>
  40e2ed:	lea    rax,[rsp+0x50]
  40e2f2:	mov    QWORD PTR [rax],0x0
  40e2f9:	mov    rcx,rbx
  40e2fc:	mov    rdx,r15
  40e2ff:	mov    r8,rax
  40e302:	call   409e00 <__swc_fn_e121059d_000141_55003b6d>
  40e307:	mov    r12,rax
  40e30a:	test   rax,rax
  40e30d:	jne    40e335 <__swc_fn_e121059d_000142_5e493395+0x215>
  40e30f:	mov    rdi,rbx
  40e312:	mov    rsi,r15
  40e315:	xor    eax,eax
  40e317:	call   407160 <munmap@plt>
  40e31c:	movsxd rdi,DWORD PTR [r14]
  40e31f:	xor    eax,eax
  40e321:	call   407040 <close@plt>
  40e326:	mov    rcx,r13
  40e329:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40e32e:	xor    eax,eax
  40e330:	jmp    40e3db <__swc_fn_e121059d_000142_5e493395+0x2bb>
  40e335:	mov    edi,0x20
  40e33a:	xor    eax,eax
  40e33c:	call   4071c0 <malloc@plt>
  40e341:	test   rax,rax
  40e344:	jne    40e369 <__swc_fn_e121059d_000142_5e493395+0x249>
  40e346:	mov    rdi,rbx
  40e349:	mov    rsi,r15
  40e34c:	xor    eax,eax
  40e34e:	call   407160 <munmap@plt>
  40e353:	movsxd rdi,DWORD PTR [r14]
  40e356:	xor    eax,eax
  40e358:	call   407040 <close@plt>
  40e35d:	mov    rcx,r13
  40e360:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40e365:	xor    eax,eax
  40e367:	jmp    40e3db <__swc_fn_e121059d_000142_5e493395+0x2bb>
  40e369:	mov    rcx,QWORD PTR [rip+0x18a18]        # 426d88 <__swc_bss_base_e121059d+0x2d48>
  40e370:	mov    QWORD PTR [rsp+0x70],rcx
  40e375:	mov    rcx,QWORD PTR [rsp+0xa0]
  40e37d:	mov    QWORD PTR [rsp+0x78],rcx
  40e382:	mov    QWORD PTR [rsp+0x80],r12
  40e38a:	mov    rcx,QWORD PTR [rsp+0x50]
  40e38f:	mov    QWORD PTR [rsp+0x88],rcx
  40e397:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  40e39d:	vmovups XMMWORD PTR [rax],xmm0
  40e3a1:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  40e3aa:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e3af:	mov    QWORD PTR [rip+0x189d2],rax        # 426d88 <__swc_bss_base_e121059d+0x2d48>
  40e3b6:	mov    rax,QWORD PTR [rsp+0x50]
  40e3bb:	mov    rbx,QWORD PTR [rsp+0x98]
  40e3c3:	mov    QWORD PTR [rbx],rax
  40e3c6:	movsxd rdi,DWORD PTR [r14]
  40e3c9:	xor    eax,eax
  40e3cb:	call   407040 <close@plt>
  40e3d0:	mov    rcx,r13
  40e3d3:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40e3d8:	mov    rax,r12
  40e3db:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40e3e4:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40e3ed:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40e3f6:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40e3ff:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40e408:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40e411:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40e41a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40e423:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40e42c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40e435:	add    rsp,0x150
  40e43c:	pop    r15
  40e43e:	pop    r14
  40e440:	pop    rsi
  40e441:	pop    rdi
  40e442:	pop    r13
  40e444:	pop    r12
  40e446:	pop    rbx
  40e447:	ret
	...

000000000040e450 <__swc_fn_e121059d_000145_c3e86ca0>:
  40e450:	push   rbx
  40e451:	sub    rsp,0xe0
  40e458:	lea    rbx,[rsp+0x8]
  40e45d:	vxorps xmm0,xmm0,xmm0
  40e461:	vmovups YMMWORD PTR [rbx],ymm0
  40e465:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40e46a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40e46f:	vzeroupper
  40e472:	mov    DWORD PTR [rbx+0x60],0x0
  40e479:	mov    r8,rbx
  40e47c:	nop    DWORD PTR [rax+0x0]
  40e480:	mov    r9,rcx
  40e483:	movabs rcx,0xcccccccccccccccd
  40e48d:	mov    rax,r9
  40e490:	mul    rcx
  40e493:	mov    r10,rdx
  40e496:	shr    r10,0x3
  40e49a:	mov    rcx,r10
  40e49d:	imul   rdx,r10,0xa
  40e4a1:	sub    r9,rdx
  40e4a4:	mov    rdx,QWORD PTR [rip+0x5095]        # 413540 <__swc_rdata_base_e121059d+0x430>
  40e4ab:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  40e4b0:	mov    BYTE PTR [r8],dl
  40e4b3:	lea    rdx,[r8+0x1]
  40e4b7:	mov    r8,rdx
  40e4ba:	test   r10,r10
  40e4bd:	jne    40e480 <__swc_fn_e121059d_000145_c3e86ca0+0x30>
  40e4bf:	mov    BYTE PTR [rdx],0x0
  40e4c2:	sub    r8,0x1
  40e4c6:	mov    rax,rbx
  40e4c9:	cmp    rax,r8
  40e4cc:	jae    40e4e6 <__swc_fn_e121059d_000145_c3e86ca0+0x96>
  40e4ce:	xchg   ax,ax
  40e4d0:	mov    cl,BYTE PTR [r8]
  40e4d3:	mov    dl,BYTE PTR [rax]
  40e4d5:	mov    BYTE PTR [r8],dl
  40e4d8:	sub    r8,0x1
  40e4dc:	mov    BYTE PTR [rax],cl
  40e4de:	inc    rax
  40e4e1:	cmp    rax,r8
  40e4e4:	jb     40e4d0 <__swc_fn_e121059d_000145_c3e86ca0+0x80>
  40e4e6:	xor    eax,eax
  40e4e8:	test   rbx,rbx
  40e4eb:	je     40e50e <__swc_fn_e121059d_000145_c3e86ca0+0xbe>
  40e4ed:	mov    rcx,rbx
  40e4f0:	mov    dl,BYTE PTR [rcx]
  40e4f2:	test   dl,dl
  40e4f4:	je     40e50e <__swc_fn_e121059d_000145_c3e86ca0+0xbe>
  40e4f6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e500:	add    rcx,0x1
  40e504:	add    rax,0x1
  40e508:	mov    dl,BYTE PTR [rcx]
  40e50a:	test   dl,dl
  40e50c:	jne    40e500 <__swc_fn_e121059d_000145_c3e86ca0+0xb0>
  40e50e:	mov    QWORD PTR [rbx+0xa8],rbx
  40e515:	mov    QWORD PTR [rbx+0xb0],rax
  40e51c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40e524:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40e52c:	lea    rcx,[rbx+0xb8]
  40e533:	call   409870 <__swc_fn_e121059d_000117_3f5cfdef>
  40e538:	add    rsp,0xe0
  40e53f:	pop    rbx
  40e540:	ret
	...

000000000040e550 <__swc_fn_e121059d_000148_e7bfe29e>:
  40e550:	sub    rsp,0x8
  40e554:	mov    rax,QWORD PTR [rcx+0x8]
  40e558:	mov    r8,QWORD PTR [rdx+0x8]
  40e55c:	cmp    rax,r8
  40e55f:	je     40e568 <__swc_fn_e121059d_000148_e7bfe29e+0x18>
  40e561:	xor    eax,eax
  40e563:	add    rsp,0x8
  40e567:	ret
  40e568:	test   rax,rax
  40e56b:	jne    40e57c <__swc_fn_e121059d_000148_e7bfe29e+0x2c>
  40e56d:	test   r8,r8
  40e570:	jne    40e57c <__swc_fn_e121059d_000148_e7bfe29e+0x2c>
  40e572:	mov    eax,0x1
  40e577:	add    rsp,0x8
  40e57b:	ret
  40e57c:	mov    rcx,QWORD PTR [rcx]
  40e57f:	mov    rdx,QWORD PTR [rdx]
  40e582:	test   rcx,rcx
  40e585:	sete   r8b
  40e589:	test   rdx,rdx
  40e58c:	sete   r9b
  40e590:	or     r8b,r9b
  40e593:	je     40e5a0 <__swc_fn_e121059d_000148_e7bfe29e+0x50>
  40e595:	cmp    rcx,rdx
  40e598:	sete   al
  40e59b:	add    rsp,0x8
  40e59f:	ret
  40e5a0:	cmp    rcx,rdx
  40e5a3:	jne    40e5af <__swc_fn_e121059d_000148_e7bfe29e+0x5f>
  40e5a5:	mov    eax,0x1
  40e5aa:	add    rsp,0x8
  40e5ae:	ret
  40e5af:	mov    r8,rax
  40e5b2:	call   410790 <__swc_fn_e121059d_000107_aba05410>
  40e5b7:	test   eax,eax
  40e5b9:	sete   al
  40e5bc:	add    rsp,0x8
  40e5c0:	ret
	...

000000000040e5d0 <__swc_fn_e121059d_000151_365b4daf>:
  40e5d0:	vxorps xmm0,xmm0,xmm0
  40e5d4:	vmovups XMMWORD PTR [rcx],xmm0
  40e5d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e5dd:	vxorps xmm0,xmm0,xmm0
  40e5e1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e5e6:	vmovups xmm0,XMMWORD PTR [rip+0x500a]        # 4135f8 <__swc_rdata_base_e121059d+0x4e8>
  40e5ee:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e5f3:	ret
	...

000000000040e600 <__swc_fn_e121059d_000154_365b4daf>:
  40e600:	vxorps xmm0,xmm0,xmm0
  40e604:	vmovups XMMWORD PTR [rcx],xmm0
  40e608:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e60d:	vxorps xmm0,xmm0,xmm0
  40e611:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e616:	vmovups xmm0,XMMWORD PTR [rip+0x50fa]        # 413718 <__swc_rdata_base_e121059d+0x608>
  40e61e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e623:	mov    QWORD PTR [rcx+0x40],0x0
  40e62b:	ret
  40e62c:	add    BYTE PTR [rax],al
	...

000000000040e630 <__swc_fn_e121059d_000157_9e2052d6>:
  40e630:	push   rbx
  40e631:	sub    rsp,0x70
  40e635:	mov    rax,QWORD PTR [rcx]
  40e638:	mov    rbx,QWORD PTR [rcx+0x8]
  40e63c:	vxorps xmm0,xmm0,xmm0
  40e640:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40e646:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40e64c:	vzeroupper
  40e64f:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40e655:	mov    QWORD PTR [rsp+0x48],rdx
  40e65a:	mov    QWORD PTR [rsp+0x50],r8
  40e65f:	mov    rcx,rax
  40e662:	lea    rdx,[rsp+0x8]
  40e667:	mov    rbx,QWORD PTR [rbx+0x18]
  40e66b:	call   rbx
  40e66d:	add    rsp,0x70
  40e671:	pop    rbx
  40e672:	ret
	...

000000000040e680 <__swc_fn_e121059d_000160_6861d596>:
  40e680:	push   rbx
  40e681:	push   rsi
  40e682:	push   rdi
  40e683:	mov    rbx,r8
  40e686:	mov    rsi,rcx
  40e689:	mov    rdi,rdx
  40e68c:	call   4114b0 <__swc_fn_e121059d_000158_3495a3ca>
  40e691:	vmovups xmm0,XMMWORD PTR [rbx]
  40e695:	vmovups XMMWORD PTR [rsi],xmm0
  40e699:	mov    QWORD PTR [rsi+0x18],rdi
  40e69d:	pop    rdi
  40e69e:	pop    rsi
  40e69f:	pop    rbx
  40e6a0:	ret
	...

000000000040e6b0 <__swc_fn_e121059d_000163_61e293bf>:
  40e6b0:	push   rbx
  40e6b1:	push   rsi
  40e6b2:	push   rdi
  40e6b3:	push   r12
  40e6b5:	push   r13
  40e6b7:	sub    rsp,0x50
  40e6bb:	mov    rbx,rcx
  40e6be:	mov    rsi,rdx
  40e6c1:	vmovups xmm0,XMMWORD PTR [rip+0x515f]        # 413828 <__swc_rdata_base_e121059d+0x718>
  40e6c9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e6cf:	vmovups xmm0,XMMWORD PTR [rip+0x5161]        # 413838 <__swc_rdata_base_e121059d+0x728>
  40e6d7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e6dd:	vxorps xmm0,xmm0,xmm0
  40e6e1:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e6e7:	mov    rcx,rdx
  40e6ea:	call   40e050 <__swc_fn_e121059d_000139_22d6573c>
  40e6ef:	mov    rdi,rax
  40e6f2:	test   rax,rax
  40e6f5:	jne    40e726 <__swc_fn_e121059d_000163_61e293bf+0x76>
  40e6f7:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e6fd:	vmovups XMMWORD PTR [rbx],xmm0
  40e701:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e707:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e70c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e712:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e717:	mov    rax,rbx
  40e71a:	add    rsp,0x50
  40e71e:	pop    r13
  40e720:	pop    r12
  40e722:	pop    rdi
  40e723:	pop    rsi
  40e724:	pop    rbx
  40e725:	ret
  40e726:	mov    rcx,rdi
  40e729:	call   40b320 <__swc_fn_e121059d_000162_b553c03d>
  40e72e:	mov    r11,rax
  40e731:	test   rax,rax
  40e734:	je     40e73e <__swc_fn_e121059d_000163_61e293bf+0x8e>
  40e736:	mov    al,BYTE PTR [r11+0x24]
  40e73a:	test   al,al
  40e73c:	jne    40e76d <__swc_fn_e121059d_000163_61e293bf+0xbd>
  40e73e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e744:	vmovups XMMWORD PTR [rbx],xmm0
  40e748:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e74e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e753:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e759:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e75e:	mov    rax,rbx
  40e761:	add    rsp,0x50
  40e765:	pop    r13
  40e767:	pop    r12
  40e769:	pop    rdi
  40e76a:	pop    rsi
  40e76b:	pop    rbx
  40e76c:	ret
  40e76d:	sub    rsi,rdi
  40e770:	mov    eax,0xffffffff
  40e775:	cmp    rsi,rax
  40e778:	jbe    40e7a9 <__swc_fn_e121059d_000163_61e293bf+0xf9>
  40e77a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e780:	vmovups XMMWORD PTR [rbx],xmm0
  40e784:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e78a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e78f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e795:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e79a:	mov    rax,rbx
  40e79d:	add    rsp,0x50
  40e7a1:	pop    r13
  40e7a3:	pop    r12
  40e7a5:	pop    rdi
  40e7a6:	pop    rsi
  40e7a7:	pop    rbx
  40e7a8:	ret
  40e7a9:	mov    rdi,QWORD PTR [r11+0x10]
  40e7ad:	mov    eax,DWORD PTR [r11+0x20]
  40e7b1:	xor    ecx,ecx
  40e7b3:	test   rax,rax
  40e7b6:	jbe    40e908 <__swc_fn_e121059d_000163_61e293bf+0x258>
  40e7bc:	nop    DWORD PTR [rax+0x0]
  40e7c0:	mov    edx,ecx
  40e7c2:	imul   r12,rdx,0x14
  40e7c6:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40e7cb:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40e7d0:	mov    r9d,esi
  40e7d3:	cmp    r9,rdx
  40e7d6:	jb     40e8fb <__swc_fn_e121059d_000163_61e293bf+0x24b>
  40e7dc:	add    rdx,r8
  40e7df:	mov    r8d,esi
  40e7e2:	cmp    r8,rdx
  40e7e5:	jae    40e8fb <__swc_fn_e121059d_000163_61e293bf+0x24b>
  40e7eb:	lea    rsi,[rsp+0x38]
  40e7f0:	mov    eax,DWORD PTR [rdi+0xc]
  40e7f3:	mov    DWORD PTR [rsp+0x38],eax
  40e7f7:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40e7fc:	mov    rcx,rdi
  40e7ff:	mov    rdx,QWORD PTR [r11+0x18]
  40e803:	mov    r8,rsi
  40e806:	mov    r8d,DWORD PTR [r8]
  40e809:	mov    r9,rax
  40e80c:	lea    r10,[rsp+0x10]
  40e811:	call   411500 <__swc_fn_e121059d_000161_dfca9093>
  40e816:	test   al,al
  40e818:	jne    40e84b <__swc_fn_e121059d_000163_61e293bf+0x19b>
  40e81a:	vmovups xmm0,XMMWORD PTR [rip+0x5036]        # 413858 <__swc_rdata_base_e121059d+0x748>
  40e822:	vmovups XMMWORD PTR [rbx],xmm0
  40e826:	vmovups xmm0,XMMWORD PTR [rip+0x503a]        # 413868 <__swc_rdata_base_e121059d+0x758>
  40e82e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e833:	vxorps xmm0,xmm0,xmm0
  40e837:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e83c:	mov    rax,rbx
  40e83f:	add    rsp,0x50
  40e843:	pop    r13
  40e845:	pop    r12
  40e847:	pop    rdi
  40e848:	pop    rsi
  40e849:	pop    rbx
  40e84a:	ret
  40e84b:	lea    r13,[rsp+0x3c]
  40e850:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40e855:	mov    DWORD PTR [rsp+0x3c],eax
  40e859:	test   eax,eax
  40e85b:	je     40e8ac <__swc_fn_e121059d_000163_61e293bf+0x1fc>
  40e85d:	mov    rcx,rdi
  40e860:	mov    rdx,QWORD PTR [r11+0x18]
  40e864:	mov    r8d,DWORD PTR [rsi]
  40e867:	mov    rax,r13
  40e86a:	mov    r9d,DWORD PTR [rax]
  40e86d:	lea    r10,[rsp+0x20]
  40e872:	call   411500 <__swc_fn_e121059d_000161_dfca9093>
  40e877:	test   al,al
  40e879:	jne    40e8ac <__swc_fn_e121059d_000163_61e293bf+0x1fc>
  40e87b:	vmovups xmm0,XMMWORD PTR [rip+0x5005]        # 413888 <__swc_rdata_base_e121059d+0x778>
  40e883:	vmovups XMMWORD PTR [rbx],xmm0
  40e887:	vmovups xmm0,XMMWORD PTR [rip+0x5009]        # 413898 <__swc_rdata_base_e121059d+0x788>
  40e88f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e894:	vxorps xmm0,xmm0,xmm0
  40e898:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e89d:	mov    rax,rbx
  40e8a0:	add    rsp,0x50
  40e8a4:	pop    r13
  40e8a6:	pop    r12
  40e8a8:	pop    rdi
  40e8a9:	pop    rsi
  40e8aa:	pop    rbx
  40e8ab:	ret
  40e8ac:	mov    eax,0x1
  40e8b1:	rex mov BYTE PTR [rsp+0x8],al
  40e8b6:	cmp    DWORD PTR [r13+0x0],0x0
  40e8bb:	je     40e8cc <__swc_fn_e121059d_000163_61e293bf+0x21c>
  40e8bd:	rex mov BYTE PTR [rsp+0x9],0x1
  40e8c3:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40e8c8:	mov    DWORD PTR [rsp+0x30],eax
  40e8cc:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e8d2:	vmovups XMMWORD PTR [rbx],xmm0
  40e8d6:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e8dc:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e8e1:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e8e7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e8ec:	mov    rax,rbx
  40e8ef:	add    rsp,0x50
  40e8f3:	pop    r13
  40e8f5:	pop    r12
  40e8f7:	pop    rdi
  40e8f8:	pop    rsi
  40e8f9:	pop    rbx
  40e8fa:	ret
  40e8fb:	add    rcx,0x1
  40e8ff:	cmp    rcx,rax
  40e902:	jb     40e7c0 <__swc_fn_e121059d_000163_61e293bf+0x110>
  40e908:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e90e:	vmovups XMMWORD PTR [rbx],xmm0
  40e912:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e918:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e91d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e923:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e928:	mov    rax,rbx
  40e92b:	add    rsp,0x50
  40e92f:	pop    r13
  40e931:	pop    r12
  40e933:	pop    rdi
  40e934:	pop    rsi
  40e935:	pop    rbx
  40e936:	ret
	...

000000000040e940 <__swc_fn_e121059d_000166_56054fe7>:
  40e940:	sub    rsp,0x48
  40e944:	call   40dd20 <__swc_fn_e121059d_000124_e4107ade>
  40e949:	cmp    rax,0xffffffffffffffff
  40e94d:	je     40e954 <__swc_fn_e121059d_000166_56054fe7+0x14>
  40e94f:	add    rsp,0x48
  40e953:	ret
  40e954:	lea    rcx,[rip+0x4f6d]        # 4138c8 <__swc_rdata_base_e121059d+0x7b8>
  40e95b:	vmovups xmm0,XMMWORD PTR [rip+0x4f75]        # 4138d8 <__swc_rdata_base_e121059d+0x7c8>
  40e963:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e969:	vmovups xmm0,XMMWORD PTR [rip+0x4f77]        # 4138e8 <__swc_rdata_base_e121059d+0x7d8>
  40e971:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e977:	vmovups xmm0,XMMWORD PTR [rip+0x4f79]        # 4138f8 <__swc_rdata_base_e121059d+0x7e8>
  40e97f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e985:	lea    rdx,[rsp+0x8]
  40e98a:	mov    QWORD PTR [rsp+0x38],rax
  40e98f:	call   40d7c0 <__swc_fn_e121059d_000103_0d4cc079>
  40e994:	mov    rax,QWORD PTR [rsp+0x38]
  40e999:	jmp    40e94f <__swc_fn_e121059d_000166_56054fe7+0xf>
  40e99b:	add    BYTE PTR [rax],al
  40e99d:	add    BYTE PTR [rax],al
	...

000000000040e9a0 <__swc_fn_e121059d_000169_0ad81c51>:
  40e9a0:	push   rbx
  40e9a1:	push   rsi
  40e9a2:	sub    rsp,0x28
  40e9a6:	mov    rbx,rcx
  40e9a9:	mov    DWORD PTR [rsp+0x8],0xbf0
  40e9b1:	mov    ecx,0xbf0
  40e9b6:	call   40d3b0 <__swc_fn_e121059d_000079_633af784>
  40e9bb:	mov    rsi,rax
  40e9be:	test   rax,rax
  40e9c1:	jne    40e9cc <__swc_fn_e121059d_000169_0ad81c51+0x2c>
  40e9c3:	xor    eax,eax
  40e9c5:	add    rsp,0x28
  40e9c9:	pop    rsi
  40e9ca:	pop    rbx
  40e9cb:	ret
  40e9cc:	vxorps xmm0,xmm0,xmm0
  40e9d0:	xor    eax,eax
  40e9d2:	cs nop WORD PTR [rax+rax*1+0x0]
  40e9dc:	nop    DWORD PTR [rax+0x0]
  40e9e0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40e9e5:	add    rax,0x10
  40e9e9:	cmp    rax,0xbf0
  40e9f0:	jne    40e9e0 <__swc_fn_e121059d_000169_0ad81c51+0x40>
  40e9f2:	lea    rax,[rbx+0x1]
  40e9f6:	mov    QWORD PTR [rsi+0x9c0],rax
  40e9fd:	mov    rcx,rbx
  40ea00:	mov    rdx,rsi
  40ea03:	call   411860 <__swc_fn_e121059d_000167_c370e18e>
  40ea08:	test   al,al
  40ea0a:	jne    40ea1d <__swc_fn_e121059d_000169_0ad81c51+0x7d>
  40ea0c:	mov    rcx,rsi
  40ea0f:	call   40fdf0 <__swc_fn_e121059d_000080_207908fe>
  40ea14:	xor    eax,eax
  40ea16:	add    rsp,0x28
  40ea1a:	pop    rsi
  40ea1b:	pop    rbx
  40ea1c:	ret
  40ea1d:	lea    rcx,[rsp+0x18]
  40ea22:	call   410370 <__swc_fn_e121059d_000092_809deff5>
  40ea27:	mov    rax,rsi
  40ea2a:	add    rsp,0x28
  40ea2e:	pop    rsi
  40ea2f:	pop    rbx
  40ea30:	ret
	...

000000000040ea40 <__swc_fn_e121059d_000172_8c19aea5>:
  40ea40:	xor    eax,eax
  40ea42:	mov    edx,0x1
  40ea47:	lock cmpxchg QWORD PTR [rcx],rdx
  40ea4c:	test   rax,rax
  40ea4f:	jne    40ea52 <__swc_fn_e121059d_000172_8c19aea5+0x12>
  40ea51:	ret
  40ea52:	cs nop WORD PTR [rax+rax*1+0x0]
  40ea5c:	nop    DWORD PTR [rax+0x0]
  40ea60:	mov    rax,QWORD PTR [rcx]
  40ea63:	test   rax,rax
  40ea66:	je     40ea40 <__swc_fn_e121059d_000172_8c19aea5>
  40ea68:	jmp    40ea60 <__swc_fn_e121059d_000172_8c19aea5+0x20>
  40ea6a:	add    BYTE PTR [rax],al
  40ea6c:	add    BYTE PTR [rax],al
	...

000000000040ea70 <__swc_fn_e121059d_000175_02e645b4>:
  40ea70:	push   rsi
  40ea71:	push   rdi
  40ea72:	sub    rsp,0x38
  40ea76:	mov    rsi,rcx
  40ea79:	call   411870 <__swc_fn_e121059d_000170_4694b8ad>
  40ea7e:	mov    rdi,rax
  40ea81:	call   411000 <__swc_fn_e121059d_000131_375c7357>
  40ea86:	mov    r8,rax
  40ea89:	mov    rcx,rdi
  40ea8c:	call   40ea40 <__swc_fn_e121059d_000172_8c19aea5>
  40ea91:	mov    rax,QWORD PTR [rdi+0x8]
  40ea95:	test   rax,rax
  40ea98:	je     40ead5 <__swc_fn_e121059d_000175_02e645b4+0x65>
  40ea9a:	nop    WORD PTR [rax+rax*1+0x0]
  40eaa0:	cmp    rax,rsi
  40eaa3:	je     40ead5 <__swc_fn_e121059d_000175_02e645b4+0x65>
  40eaa5:	mov    r9,QWORD PTR [rax]
  40eaa8:	cmp    QWORD PTR [rax+0x20],r8
  40eaac:	jne    40eacd <__swc_fn_e121059d_000175_02e645b4+0x5d>
  40eaae:	mov    rcx,rdi
  40eab1:	mov    rdx,rax
  40eab4:	mov    QWORD PTR [rsp+0x28],r8
  40eab9:	mov    QWORD PTR [rsp+0x30],r9
  40eabe:	call   40b740 <__swc_fn_e121059d_000174_e17a224b>
  40eac3:	mov    r8,QWORD PTR [rsp+0x28]
  40eac8:	mov    r9,QWORD PTR [rsp+0x30]
  40eacd:	mov    rax,r9
  40ead0:	test   r9,r9
  40ead3:	jne    40eaa0 <__swc_fn_e121059d_000175_02e645b4+0x30>
  40ead5:	xor    eax,eax
  40ead7:	mov    QWORD PTR [rdi],rax
  40eada:	add    rsp,0x38
  40eade:	pop    rdi
  40eadf:	pop    rsi
  40eae0:	ret
	...

000000000040eaf0 <__swc_fn_e121059d_000178_1ca87929>:
  40eaf0:	push   rdi
  40eaf1:	push   rsi
  40eaf2:	sub    rsp,0xb8
  40eaf9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40eaff:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40eb05:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40eb0b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40eb11:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40eb17:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40eb1d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40eb23:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40eb2c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40eb35:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40eb3e:	vxorps xmm0,xmm0,xmm0
  40eb42:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40eb48:	mov    edi,0x1
  40eb4d:	lea    rsi,[rsp+0x8]
  40eb52:	xor    eax,eax
  40eb54:	call   407130 <clock_gettime@plt>
  40eb59:	vxorpd xmm0,xmm0,xmm0
  40eb5d:	mov    rax,QWORD PTR [rsp+0x8]
  40eb62:	vcvtsi2sd xmm0,xmm0,rax
  40eb67:	vxorpd xmm1,xmm1,xmm1
  40eb6b:	mov    rax,QWORD PTR [rsp+0x10]
  40eb70:	vcvtsi2sd xmm1,xmm1,rax
  40eb75:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x4d8b]        # 413908 <__swc_rdata_base_e121059d+0x7f8>
  40eb7d:	vaddsd xmm0,xmm0,xmm1
  40eb81:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40eb87:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40eb8d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40eb93:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40eb99:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40eb9f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40eba5:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ebab:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ebb4:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ebbd:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ebc6:	add    rsp,0xb8
  40ebcd:	pop    rsi
  40ebce:	pop    rdi
  40ebcf:	ret
	...

000000000040ebe0 <__swc_fn_e121059d_000002_102336c4>:
  40ebe0:	sub    rsp,0x8
  40ebe4:	call   410950 <__swc_fn_e121059d_000110_9f5af8ae>
  40ebe9:	mov    rcx,rax
  40ebec:	test   rax,rax
  40ebef:	je     40ec16 <__swc_fn_e121059d_000002_102336c4+0x36>
  40ebf1:	lea    rdx,[rip+0x15448]        # 424040 <__swc_bss_base_e121059d>
  40ebf8:	mov    r8,QWORD PTR [rip+0x15441]        # 424040 <__swc_bss_base_e121059d>
  40ebff:	nop
  40ec00:	lea    r9,[r8+0x1]
  40ec04:	mov    rax,r8
  40ec07:	lock cmpxchg QWORD PTR [rdx],r9
  40ec0c:	cmp    rax,r8
  40ec0f:	je     40ec16 <__swc_fn_e121059d_000002_102336c4+0x36>
  40ec11:	mov    r8,rax
  40ec14:	jmp    40ec00 <__swc_fn_e121059d_000002_102336c4+0x20>
  40ec16:	mov    rax,rcx
  40ec19:	add    rsp,0x8
  40ec1d:	ret
	...

000000000040ec20 <__swc_fn_e121059d_000005_6a556171>:
  40ec20:	mov    r8d,edx
  40ec23:	xor    eax,eax
  40ec25:	tzcnt  eax,edx
  40ec29:	shrx   r9d,edx,eax
  40ec2e:	mov    DWORD PTR [rcx+0x2c],edx
  40ec31:	xor    eax,eax
  40ec33:	tzcnt  eax,edx
  40ec37:	mov    BYTE PTR [rcx+0x38],al
  40ec3a:	mov    eax,0xffffffff
  40ec3f:	xor    edx,edx
  40ec41:	div    r8d
  40ec44:	mov    DWORD PTR [rcx+0x34],eax
  40ec47:	mov    eax,r9d
  40ec4a:	mov    edx,r9d
  40ec4d:	imul   edx,r9d
  40ec51:	mov    r8d,0x2
  40ec57:	sub    r8d,edx
  40ec5a:	imul   eax,r8d
  40ec5e:	mov    edx,r9d
  40ec61:	imul   edx,eax
  40ec64:	mov    r8d,0x2
  40ec6a:	sub    r8d,edx
  40ec6d:	imul   eax,r8d
  40ec71:	mov    edx,r9d
  40ec74:	imul   edx,eax
  40ec77:	mov    r8d,0x2
  40ec7d:	sub    r8d,edx
  40ec80:	imul   eax,r8d
  40ec84:	mov    edx,r9d
  40ec87:	imul   edx,eax
  40ec8a:	mov    r8d,0x2
  40ec90:	sub    r8d,edx
  40ec93:	imul   eax,r8d
  40ec97:	imul   r9d,eax
  40ec9b:	mov    edx,0x2
  40eca0:	sub    edx,r9d
  40eca3:	imul   eax,edx
  40eca6:	mov    DWORD PTR [rcx+0x30],eax
  40eca9:	ret
  40ecaa:	add    BYTE PTR [rax],al
  40ecac:	add    BYTE PTR [rax],al
	...

000000000040ecb0 <__swc_fn_e121059d_000008_b2f73e0d>:
  40ecb0:	xor    eax,eax
  40ecb2:	mov    DWORD PTR [rcx+0x68],eax
  40ecb5:	ret
	...

000000000040ecc0 <__swc_fn_e121059d_000011_71c91685>:
  40ecc0:	mov    eax,DWORD PTR [rcx+0x28]
  40ecc3:	shlx   eax,edx,eax
  40ecc8:	shl    rax,0x10
  40eccc:	lea    rdx,[rcx+rax*1]
  40ecd0:	lea    rax,[rcx+0x3000]
  40ecd7:	cmp    rdx,rax
  40ecda:	cmovae rax,rdx
  40ecde:	ret
	...

000000000040ece0 <__swc_fn_e121059d_000014_be17798c>:
  40ece0:	push   rsi
  40ece1:	push   rdi
  40ece2:	push   r12
  40ece4:	push   r13
  40ece6:	push   r14
  40ece8:	mov    rsi,rdx
  40eceb:	mov    rdi,rcx
  40ecee:	rex mov dl,BYTE PTR [rsi+0x3a]
  40ecf2:	mov    ecx,DWORD PTR [rdi+0x28]
  40ecf5:	shr    dl,cl
  40ecf7:	mov    r12d,0x1
  40ecfd:	mov    ecx,edx
  40ecff:	shl    r12,cl
  40ed02:	mov    r13d,DWORD PTR [rsi+0x3c]
  40ed06:	rex mov BYTE PTR [rsi+0x3b],0x0
  40ed0b:	mov    QWORD PTR [rsi+0x40],0x0
  40ed13:	mov    QWORD PTR [rsi],0x0
  40ed1a:	mov    rax,QWORD PTR [rsi+0x10]
  40ed1e:	mov    QWORD PTR [rsi+0x20],rax
  40ed22:	lea    r14,[rip+0x1531f]        # 424048 <__swc_bss_base_e121059d+0x8>
  40ed29:	mov    rax,QWORD PTR [r14]
  40ed2c:	shr    rax,0x2
  40ed30:	mov    rcx,rax
  40ed33:	cmp    rax,0x800000
  40ed3a:	mov    eax,0x800000
  40ed3f:	cmovb  rcx,rax
  40ed43:	lea    r8,[rip+0x1530e]        # 424058 <__swc_bss_base_e121059d+0x18>
  40ed4a:	mov    rax,QWORD PTR [r8]
  40ed4d:	mov    r9,rax
  40ed50:	lea    r10,[r9+r13*1]
  40ed54:	cmp    r10,rcx
  40ed57:	ja     40ed7b <__swc_fn_e121059d_000014_be17798c+0x9b>
  40ed59:	mov    rax,r9
  40ed5c:	lock cmpxchg QWORD PTR [r8],r10
  40ed61:	cmp    rax,r9
  40ed64:	je     40ed6b <__swc_fn_e121059d_000014_be17798c+0x8b>
  40ed66:	mov    r9,rax
  40ed69:	jmp    40ed50 <__swc_fn_e121059d_000014_be17798c+0x70>
  40ed6b:	mov    rcx,rdi
  40ed6e:	mov    rdx,r12
  40ed71:	call   40bb70 <__swc_fn_e121059d_000016_a0b588d0>
  40ed76:	jmp    40edfd <__swc_fn_e121059d_000014_be17798c+0x11d>
  40ed7b:	mov    rcx,rdi
  40ed7e:	movzx  edx,dl
  40ed81:	call   40ecc0 <__swc_fn_e121059d_000011_71c91685>
  40ed86:	test   r13,r13
  40ed89:	je     40edf6 <__swc_fn_e121059d_000014_be17798c+0x116>
  40ed8f:	mov    rcx,rax
  40ed92:	mov    rdx,r13
  40ed95:	call   410ad0 <__swc_fn_e121059d_000113_2f7f9346>
  40ed9a:	mov    rcx,QWORD PTR [rip+0x152a7]        # 424048 <__swc_bss_base_e121059d+0x8>
  40eda1:	cs nop WORD PTR [rax+rax*1+0x0]
  40edab:	nop    DWORD PTR [rax+rax*1+0x0]
  40edb0:	mov    rdx,rcx
  40edb3:	sub    rdx,r13
  40edb6:	mov    rax,rcx
  40edb9:	lock cmpxchg QWORD PTR [r14],rdx
  40edbe:	cmp    rax,rcx
  40edc1:	je     40edc8 <__swc_fn_e121059d_000014_be17798c+0xe8>
  40edc3:	mov    rcx,rax
  40edc6:	jmp    40edb0 <__swc_fn_e121059d_000014_be17798c+0xd0>
  40edc8:	lea    rcx,[rip+0x15291]        # 424060 <__swc_bss_base_e121059d+0x20>
  40edcf:	mov    rdx,QWORD PTR [rip+0x1528a]        # 424060 <__swc_bss_base_e121059d+0x20>
  40edd6:	cs nop WORD PTR [rax+rax*1+0x0]
  40ede0:	lea    r8,[rdx+0x1]
  40ede4:	mov    rax,rdx
  40ede7:	lock cmpxchg QWORD PTR [rcx],r8
  40edec:	cmp    rax,rdx
  40edef:	je     40edf6 <__swc_fn_e121059d_000014_be17798c+0x116>
  40edf1:	mov    rdx,rax
  40edf4:	jmp    40ede0 <__swc_fn_e121059d_000014_be17798c+0x100>
  40edf6:	mov    DWORD PTR [rsi+0x3c],0x0
  40edfd:	mov    rcx,rdi
  40ee00:	mov    rdx,r12
  40ee03:	call   407600 <__swc_fn_e121059d_000018_77ece227>
  40ee08:	pop    r14
  40ee0a:	pop    r13
  40ee0c:	pop    r12
  40ee0e:	pop    rdi
  40ee0f:	pop    rsi
  40ee10:	ret
	...

000000000040ee20 <__swc_fn_e121059d_000017_f003fc47>:
  40ee20:	mov    r8,QWORD PTR [rcx+0x48]
  40ee24:	test   r8,rdx
  40ee27:	je     40ee58 <__swc_fn_e121059d_000017_f003fc47+0x38>
  40ee29:	nop    DWORD PTR [rax+0x0]
  40ee30:	mov    rax,rdx
  40ee33:	not    rax
  40ee36:	mov    r9,r8
  40ee39:	and    r9,rax
  40ee3c:	mov    rax,r8
  40ee3f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40ee45:	cmp    rax,r8
  40ee48:	jne    40ee50 <__swc_fn_e121059d_000017_f003fc47+0x30>
  40ee4a:	mov    eax,0x1
  40ee4f:	ret
  40ee50:	mov    r8,rax
  40ee53:	test   rax,rdx
  40ee56:	jne    40ee30 <__swc_fn_e121059d_000017_f003fc47+0x10>
  40ee58:	xor    eax,eax
  40ee5a:	ret
  40ee5b:	add    BYTE PTR [rax],al
  40ee5d:	add    BYTE PTR [rax],al
	...

000000000040ee60 <__swc_fn_e121059d_000020_4285d9c5>:
  40ee60:	push   rsi
  40ee61:	push   rdi
  40ee62:	push   r12
  40ee64:	push   r13
  40ee66:	sub    rsp,0x8
  40ee6a:	mov    rsi,rdx
  40ee6d:	mov    rdi,rcx
  40ee70:	lea    r12,[rip+0x15379]        # 4241f0 <__swc_bss_base_e121059d+0x1b0>
  40ee77:	mov    rcx,r12
  40ee7a:	call   40e040 <__swc_fn_e121059d_000136_db32cc57>
  40ee7f:	xor    eax,eax
  40ee81:	mov    rcx,QWORD PTR [rip+0x15370]        # 4241f8 <__swc_bss_base_e121059d+0x1b8>
  40ee88:	mov    r13,rcx
  40ee8b:	test   r13,r13
  40ee8e:	je     40eedb <__swc_fn_e121059d_000020_4285d9c5+0x7b>
  40ee90:	mov    rcx,QWORD PTR [r13+0x10]
  40ee94:	cmp    DWORD PTR [r13+0x28],esi
  40ee98:	jne    40eed0 <__swc_fn_e121059d_000020_4285d9c5+0x70>
  40ee9a:	test   rax,rax
  40ee9d:	jne    40eea8 <__swc_fn_e121059d_000020_4285d9c5+0x48>
  40ee9f:	mov    QWORD PTR [rip+0x15352],rcx        # 4241f8 <__swc_bss_base_e121059d+0x1b8>
  40eea6:	jmp    40eeac <__swc_fn_e121059d_000020_4285d9c5+0x4c>
  40eea8:	mov    QWORD PTR [rax+0x10],rcx
  40eeac:	vxorps xmm0,xmm0,xmm0
  40eeb0:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40eeb6:	mov    QWORD PTR [r13+0x8],rdi
  40eeba:	mov    rcx,r12
  40eebd:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40eec2:	mov    rax,r13
  40eec5:	add    rsp,0x8
  40eec9:	pop    r13
  40eecb:	pop    r12
  40eecd:	pop    rdi
  40eece:	pop    rsi
  40eecf:	ret
  40eed0:	mov    rax,r13
  40eed3:	mov    r13,rcx
  40eed6:	test   rcx,rcx
  40eed9:	jne    40ee90 <__swc_fn_e121059d_000020_4285d9c5+0x30>
  40eedb:	mov    ecx,esi
  40eedd:	call   40bba0 <__swc_fn_e121059d_000019_447bb610>
  40eee2:	mov    rsi,rax
  40eee5:	test   rax,rax
  40eee8:	jne    40eeff <__swc_fn_e121059d_000020_4285d9c5+0x9f>
  40eeea:	mov    rcx,r12
  40eeed:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40eef2:	xor    eax,eax
  40eef4:	add    rsp,0x8
  40eef8:	pop    r13
  40eefa:	pop    r12
  40eefc:	pop    rdi
  40eefd:	pop    rsi
  40eefe:	ret
  40eeff:	mov    QWORD PTR [rsi+0x8],rdi
  40ef03:	mov    rcx,r12
  40ef06:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40ef0b:	mov    rax,rsi
  40ef0e:	add    rsp,0x8
  40ef12:	pop    r13
  40ef14:	pop    r12
  40ef16:	pop    rdi
  40ef17:	pop    rsi
  40ef18:	ret
  40ef19:	add    BYTE PTR [rax],al
  40ef1b:	add    BYTE PTR [rax],al
  40ef1d:	add    BYTE PTR [rax],al
	...

000000000040ef20 <__swc_fn_e121059d_000023_e876734d>:
  40ef20:	vxorps xmm0,xmm0,xmm0
  40ef24:	xor    eax,eax
  40ef26:	cs nop WORD PTR [rax+rax*1+0x0]
  40ef30:	cs nop WORD PTR [rax+rax*1+0x0]
  40ef3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ef40:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40ef45:	add    rax,0x10
  40ef49:	cmp    rax,0x2b00
  40ef50:	jne    40ef40 <__swc_fn_e121059d_000023_e876734d+0x20>
  40ef52:	ret
	...

000000000040ef60 <__swc_fn_e121059d_000026_e876734d>:
  40ef60:	vxorps xmm0,xmm0,xmm0
  40ef64:	vmovups XMMWORD PTR [rcx],xmm0
  40ef68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40ef6d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ef72:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ef77:	ret
	...

000000000040ef80 <__swc_fn_e121059d_000029_e876734d>:
  40ef80:	vxorps xmm0,xmm0,xmm0
  40ef84:	vmovups XMMWORD PTR [rcx],xmm0
  40ef88:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40ef8d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ef92:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ef97:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40ef9c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40efa1:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40efa6:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40efab:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40efb3:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40efbb:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40efc3:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40efcb:	mov    QWORD PTR [rcx+0xc0],0x0
  40efd6:	ret
	...

000000000040efe0 <__swc_fn_e121059d_000032_f1940e30>:
  40efe0:	push   rsi
  40efe1:	push   rdi
  40efe2:	sub    rsp,0x8
  40efe6:	mov    rsi,rcx
  40efe9:	lea    rdi,[rip+0x13010]        # 422000 <__swc_data_base_e121059d>
  40eff0:	mov    rax,QWORD PTR [rdi]
  40eff3:	cmp    rax,0xffffffffffffffff
  40eff7:	je     40effe <__swc_fn_e121059d_000032_f1940e30+0x1e>
  40eff9:	mov    rdi,rax
  40effc:	jmp    40f02b <__swc_fn_e121059d_000032_f1940e30+0x4b>
  40effe:	call   40dd20 <__swc_fn_e121059d_000124_e4107ade>
  40f003:	mov    rcx,rax
  40f006:	cmp    rax,0xffffffffffffffff
  40f00a:	je     40f03c <__swc_fn_e121059d_000032_f1940e30+0x5c>
  40f00c:	mov    rax,0xffffffffffffffff
  40f013:	lock cmpxchg QWORD PTR [rdi],rcx
  40f018:	cmp    rax,0xffffffffffffffff
  40f01c:	je     40f028 <__swc_fn_e121059d_000032_f1940e30+0x48>
  40f01e:	mov    rdi,rax
  40f021:	call   410eb0 <__swc_fn_e121059d_000125_37eaf452>
  40f026:	jmp    40f02b <__swc_fn_e121059d_000032_f1940e30+0x4b>
  40f028:	mov    rdi,rcx
  40f02b:	cmp    rdi,0xffffffffffffffff
  40f02f:	je     40f03c <__swc_fn_e121059d_000032_f1940e30+0x5c>
  40f031:	mov    rcx,rdi
  40f034:	mov    rdx,rsi
  40f037:	call   409af0 <__swc_fn_e121059d_000126_7a81492f>
  40f03c:	add    rsp,0x8
  40f040:	pop    rdi
  40f041:	pop    rsi
  40f042:	ret
	...

000000000040f050 <__swc_fn_e121059d_000035_ab2e8c35>:
  40f050:	sub    rsp,0x38
  40f054:	mov    rax,rdx
  40f057:	test   dl,dl
  40f059:	jne    40f071 <__swc_fn_e121059d_000035_ab2e8c35+0x21>
  40f05b:	mov    rax,r8
  40f05e:	test   r8b,r8b
  40f061:	cmove  eax,r9d
  40f065:	test   al,al
  40f067:	cmove  eax,r10d
  40f06b:	test   al,al
  40f06d:	cmove  eax,r11d
  40f071:	test   al,al
  40f073:	jne    40f07a <__swc_fn_e121059d_000035_ab2e8c35+0x2a>
  40f075:	add    rsp,0x38
  40f079:	ret
  40f07a:	lea    rcx,[rip+0x408f]        # 413110 <__swc_rdata_base_e121059d>
  40f081:	vmovups xmm0,XMMWORD PTR [rip+0x4097]        # 413120 <__swc_rdata_base_e121059d+0x10>
  40f089:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f08f:	vmovups xmm0,XMMWORD PTR [rip+0x4099]        # 413130 <__swc_rdata_base_e121059d+0x20>
  40f097:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f09d:	vmovups xmm0,XMMWORD PTR [rip+0x409b]        # 413140 <__swc_rdata_base_e121059d+0x30>
  40f0a5:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40f0ab:	lea    rdx,[rsp+0x8]
  40f0b0:	call   40d7c0 <__swc_fn_e121059d_000103_0d4cc079>
  40f0b5:	jmp    40f075 <__swc_fn_e121059d_000035_ab2e8c35+0x25>
	...

000000000040f0c0 <__swc_fn_e121059d_000038_292d55e5>:
  40f0c0:	sub    rsp,0x8
  40f0c4:	mov    eax,0x1000
  40f0c9:	test   eax,eax
  40f0cb:	mov    r8d,0x8
  40f0d1:	cmove  eax,r8d
  40f0d5:	dec    rax
  40f0d8:	mov    r8,0xffffffffffffffff
  40f0df:	sub    r8,rax
  40f0e2:	cmp    rdx,r8
  40f0e5:	ja     40f0f5 <__swc_fn_e121059d_000038_292d55e5+0x35>
  40f0e7:	add    rdx,rax
  40f0ea:	not    rax
  40f0ed:	mov    r8,rdx
  40f0f0:	and    r8,rax
  40f0f3:	jne    40f0fc <__swc_fn_e121059d_000038_292d55e5+0x3c>
  40f0f5:	xor    eax,eax
  40f0f7:	add    rsp,0x8
  40f0fb:	ret
  40f0fc:	mov    rdx,r8
  40f0ff:	call   40bec0 <__swc_fn_e121059d_000037_1e381f55>
  40f104:	add    rsp,0x8
  40f108:	ret
  40f109:	add    BYTE PTR [rax],al
  40f10b:	add    BYTE PTR [rax],al
  40f10d:	add    BYTE PTR [rax],al
	...

000000000040f110 <__swc_fn_e121059d_000041_41400651>:
  40f110:	push   rsi
  40f111:	push   rdi
  40f112:	sub    rsp,0x8
  40f116:	mov    rsi,rdx
  40f119:	mov    rdi,rcx
  40f11c:	test   rdx,rdx
  40f11f:	je     40f13b <__swc_fn_e121059d_000041_41400651+0x2b>
  40f121:	xor    ecx,ecx
  40f123:	call   407720 <__swc_fn_e121059d_000033_d15eb4ea>
  40f128:	mov    rax,QWORD PTR [rsi]
  40f12b:	test   rax,rax
  40f12e:	je     40f13b <__swc_fn_e121059d_000041_41400651+0x2b>
  40f130:	mov    rcx,rax
  40f133:	mov    rdx,rsi
  40f136:	call   407840 <__swc_fn_e121059d_000042_0573444d>
  40f13b:	mov    rcx,rdi
  40f13e:	call   40bf20 <__swc_fn_e121059d_000040_8029566e>
  40f143:	mov    rsi,rax
  40f146:	test   rax,rax
  40f149:	jne    40f154 <__swc_fn_e121059d_000041_41400651+0x44>
  40f14b:	xor    eax,eax
  40f14d:	add    rsp,0x8
  40f151:	pop    rdi
  40f152:	pop    rsi
  40f153:	ret
  40f154:	mov    rcx,rsi
  40f157:	call   407720 <__swc_fn_e121059d_000033_d15eb4ea>
  40f15c:	mov    rax,rsi
  40f15f:	add    rsp,0x8
  40f163:	pop    rdi
  40f164:	pop    rsi
  40f165:	ret
	...

000000000040f170 <__swc_fn_e121059d_000044_fe6bbfdb>:
  40f170:	movzx  eax,BYTE PTR [r8+0x39]
  40f175:	lea    rax,[rax+rax*4]
  40f179:	lea    rax,[rdx+rax*8+0x28]
  40f17e:	mov    ecx,DWORD PTR [r8+0x6c]
  40f182:	test   ecx,ecx
  40f184:	je     40f1bd <__swc_fn_e121059d_000044_fe6bbfdb+0x4d>
  40f186:	mov    rcx,QWORD PTR [r8+0x50]
  40f18a:	test   rcx,rcx
  40f18d:	je     40f199 <__swc_fn_e121059d_000044_fe6bbfdb+0x29>
  40f18f:	mov    rax,QWORD PTR [r8+0x48]
  40f193:	mov    QWORD PTR [rcx+0x48],rax
  40f197:	jmp    40f1a1 <__swc_fn_e121059d_000044_fe6bbfdb+0x31>
  40f199:	mov    rcx,QWORD PTR [r8+0x48]
  40f19d:	mov    QWORD PTR [rax+0x18],rcx
  40f1a1:	mov    rax,QWORD PTR [r8+0x48]
  40f1a5:	test   rax,rax
  40f1a8:	je     40f1b2 <__swc_fn_e121059d_000044_fe6bbfdb+0x42>
  40f1aa:	mov    rcx,QWORD PTR [r8+0x50]
  40f1ae:	mov    QWORD PTR [rax+0x50],rcx
  40f1b2:	vxorps xmm0,xmm0,xmm0
  40f1b6:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40f1bc:	ret
  40f1bd:	mov    rcx,QWORD PTR [r8+0x50]
  40f1c1:	test   rcx,rcx
  40f1c4:	je     40f1d0 <__swc_fn_e121059d_000044_fe6bbfdb+0x60>
  40f1c6:	mov    rdx,QWORD PTR [r8+0x48]
  40f1ca:	mov    QWORD PTR [rcx+0x48],rdx
  40f1ce:	jmp    40f1d8 <__swc_fn_e121059d_000044_fe6bbfdb+0x68>
  40f1d0:	mov    rcx,QWORD PTR [r8+0x48]
  40f1d4:	mov    QWORD PTR [rax+0x8],rcx
  40f1d8:	mov    rcx,QWORD PTR [r8+0x48]
  40f1dc:	test   rcx,rcx
  40f1df:	je     40f1eb <__swc_fn_e121059d_000044_fe6bbfdb+0x7b>
  40f1e1:	mov    rdx,QWORD PTR [r8+0x50]
  40f1e5:	mov    QWORD PTR [rcx+0x50],rdx
  40f1e9:	jmp    40f1f3 <__swc_fn_e121059d_000044_fe6bbfdb+0x83>
  40f1eb:	mov    rcx,QWORD PTR [r8+0x50]
  40f1ef:	mov    QWORD PTR [rax+0x10],rcx
  40f1f3:	cmp    QWORD PTR [rax],r8
  40f1f6:	jne    40f1ff <__swc_fn_e121059d_000044_fe6bbfdb+0x8f>
  40f1f8:	mov    QWORD PTR [rax],0x0
  40f1ff:	vxorps xmm0,xmm0,xmm0
  40f203:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40f209:	ret
  40f20a:	add    BYTE PTR [rax],al
  40f20c:	add    BYTE PTR [rax],al
	...

000000000040f210 <__swc_fn_e121059d_000047_e7fd8d42>:
  40f210:	sub    rsp,0x8
  40f214:	mov    r9,r8
  40f217:	mov    r10,rdx
  40f21a:	call   40f170 <__swc_fn_e121059d_000044_fe6bbfdb>
  40f21f:	mov    DWORD PTR [r9+0x6c],0x0
  40f227:	movzx  eax,BYTE PTR [r9+0x39]
  40f22c:	lea    rax,[rax+rax*4]
  40f230:	lea    rax,[r10+rax*8+0x28]
  40f235:	mov    rcx,QWORD PTR [rax+0x10]
  40f239:	mov    QWORD PTR [r9+0x50],rcx
  40f23d:	mov    QWORD PTR [r9+0x48],0x0
  40f245:	mov    rcx,QWORD PTR [rax+0x10]
  40f249:	test   rcx,rcx
  40f24c:	je     40f254 <__swc_fn_e121059d_000047_e7fd8d42+0x44>
  40f24e:	mov    QWORD PTR [rcx+0x48],r9
  40f252:	jmp    40f258 <__swc_fn_e121059d_000047_e7fd8d42+0x48>
  40f254:	mov    QWORD PTR [rax+0x8],r9
  40f258:	mov    QWORD PTR [rax+0x10],r9
  40f25c:	add    rsp,0x8
  40f260:	ret
	...

000000000040f280 <__swc_fn_e121059d_000050_5e919db9>:
  40f280:	push   rsi
  40f281:	push   rdi
  40f282:	push   r12
  40f284:	push   r13
  40f286:	push   r14
  40f288:	push   r15
  40f28a:	sub    rsp,0x1f8
  40f291:	mov    esi,r8d
  40f294:	mov    QWORD PTR [rsp+0x1e8],rsi
  40f29c:	mov    rdi,rcx
  40f29f:	mov    r12,rdx
  40f2a2:	lea    r13,[rsi+rsi*4]
  40f2a6:	lea    r13,[rdx+r13*8+0x28]
  40f2ab:	call   407ca0 <__swc_fn_e121059d_000048_8e68f77b>
  40f2b0:	add    DWORD PTR [r12+0x24],0x1
  40f2b6:	test   BYTE PTR [r12+0x24],0x3f
  40f2bc:	jne    40f2c6 <__swc_fn_e121059d_000050_5e919db9+0x46>
  40f2be:	mov    rcx,rdi
  40f2c1:	call   40c0a0 <__swc_fn_e121059d_000049_f6a485a2>
  40f2c6:	mov    rax,QWORD PTR [r13+0x8]
  40f2ca:	mov    r14,rax
  40f2cd:	nop    DWORD PTR [rax]
  40f2d0:	test   r14,r14
  40f2d3:	jne    40f2e2 <__swc_fn_e121059d_000050_5e919db9+0x62>
  40f2d5:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40f2dd:	jmp    40f3e9 <__swc_fn_e121059d_000050_5e919db9+0x169>
  40f2e2:	mov    r15,QWORD PTR [r14+0x48]
  40f2e6:	mov    rcx,r14
  40f2e9:	call   4073f0 <__swc_fn_e121059d_000009_4c3ebf16>
  40f2ee:	mov    rax,QWORD PTR [r14]
  40f2f1:	test   rax,rax
  40f2f4:	je     40f306 <__swc_fn_e121059d_000050_5e919db9+0x86>
  40f2f6:	mov    rcx,QWORD PTR [rax]
  40f2f9:	mov    QWORD PTR [r14],rcx
  40f2fc:	add    DWORD PTR [r14+0x28],0x1
  40f301:	mov    rsi,rax
  40f304:	jmp    40f325 <__swc_fn_e121059d_000050_5e919db9+0xa5>
  40f306:	mov    rax,QWORD PTR [r14+0x18]
  40f30a:	cmp    QWORD PTR [r14+0x20],rax
  40f30e:	jae    40f323 <__swc_fn_e121059d_000050_5e919db9+0xa3>
  40f310:	mov    rsi,QWORD PTR [r14+0x20]
  40f314:	mov    eax,DWORD PTR [r14+0x2c]
  40f318:	add    QWORD PTR [r14+0x20],rax
  40f31c:	add    DWORD PTR [r14+0x28],0x1
  40f321:	jmp    40f325 <__swc_fn_e121059d_000050_5e919db9+0xa5>
  40f323:	xor    esi,esi
  40f325:	test   rsi,rsi
  40f328:	jne    40f36d <__swc_fn_e121059d_000050_5e919db9+0xed>
  40f32a:	mov    rcx,r14
  40f32d:	call   407320 <__swc_fn_e121059d_000006_7b253ae1>
  40f332:	test   al,al
  40f334:	je     40f36d <__swc_fn_e121059d_000050_5e919db9+0xed>
  40f336:	mov    rax,QWORD PTR [r14]
  40f339:	test   rax,rax
  40f33c:	je     40f34b <__swc_fn_e121059d_000050_5e919db9+0xcb>
  40f33e:	mov    rcx,QWORD PTR [rax]
  40f341:	mov    QWORD PTR [r14],rcx
  40f344:	add    DWORD PTR [r14+0x28],0x1
  40f349:	jmp    40f36a <__swc_fn_e121059d_000050_5e919db9+0xea>
  40f34b:	mov    rax,QWORD PTR [r14+0x18]
  40f34f:	cmp    QWORD PTR [r14+0x20],rax
  40f353:	jae    40f368 <__swc_fn_e121059d_000050_5e919db9+0xe8>
  40f355:	mov    rax,QWORD PTR [r14+0x20]
  40f359:	mov    ecx,DWORD PTR [r14+0x2c]
  40f35d:	add    QWORD PTR [r14+0x20],rcx
  40f361:	add    DWORD PTR [r14+0x28],0x1
  40f366:	jmp    40f36a <__swc_fn_e121059d_000050_5e919db9+0xea>
  40f368:	xor    eax,eax
  40f36a:	mov    rsi,rax
  40f36d:	test   rsi,rsi
  40f370:	jne    40f3c3 <__swc_fn_e121059d_000050_5e919db9+0x143>
  40f372:	mov    rcx,rdi
  40f375:	mov    rdx,r12
  40f378:	mov    r8,r14
  40f37b:	call   40c000 <__swc_fn_e121059d_000046_b28a6ee7>
  40f380:	test   al,al
  40f382:	jne    40f3c3 <__swc_fn_e121059d_000050_5e919db9+0x143>
  40f384:	mov    rcx,r14
  40f387:	call   4073f0 <__swc_fn_e121059d_000009_4c3ebf16>
  40f38c:	mov    rax,QWORD PTR [r14]
  40f38f:	test   rax,rax
  40f392:	je     40f3a1 <__swc_fn_e121059d_000050_5e919db9+0x121>
  40f394:	mov    rcx,QWORD PTR [rax]
  40f397:	mov    QWORD PTR [r14],rcx
  40f39a:	add    DWORD PTR [r14+0x28],0x1
  40f39f:	jmp    40f3c0 <__swc_fn_e121059d_000050_5e919db9+0x140>
  40f3a1:	mov    rax,QWORD PTR [r14+0x18]
  40f3a5:	cmp    QWORD PTR [r14+0x20],rax
  40f3a9:	jae    40f3be <__swc_fn_e121059d_000050_5e919db9+0x13e>
  40f3ab:	mov    rax,QWORD PTR [r14+0x20]
  40f3af:	mov    ecx,DWORD PTR [r14+0x2c]
  40f3b3:	add    QWORD PTR [r14+0x20],rcx
  40f3b7:	add    DWORD PTR [r14+0x28],0x1
  40f3bc:	jmp    40f3c0 <__swc_fn_e121059d_000050_5e919db9+0x140>
  40f3be:	xor    eax,eax
  40f3c0:	mov    rsi,rax
  40f3c3:	test   rsi,rsi
  40f3c6:	je     40f3e1 <__swc_fn_e121059d_000050_5e919db9+0x161>
  40f3c8:	mov    QWORD PTR [r13+0x0],r14
  40f3cc:	mov    rax,rsi
  40f3cf:	add    rsp,0x1f8
  40f3d6:	pop    r15
  40f3d8:	pop    r14
  40f3da:	pop    r13
  40f3dc:	pop    r12
  40f3de:	pop    rdi
  40f3df:	pop    rsi
  40f3e0:	ret
  40f3e1:	mov    r14,r15
  40f3e4:	jmp    40f2d0 <__swc_fn_e121059d_000050_5e919db9+0x50>
  40f3e9:	cs nop WORD PTR [rax+rax*1+0x0]
  40f3f3:	cs nop WORD PTR [rax+rax*1+0x0]
  40f3fd:	nop    DWORD PTR [rax]
  40f400:	mov    rcx,rdi
  40f403:	mov    rdx,r12
  40f406:	mov    r8d,esi
  40f409:	call   4079e0 <__swc_fn_e121059d_000045_bb688d37>
  40f40e:	mov    r14,rax
  40f411:	test   rax,rax
  40f414:	jne    40f42a <__swc_fn_e121059d_000050_5e919db9+0x1aa>
  40f416:	xor    eax,eax
  40f418:	add    rsp,0x1f8
  40f41f:	pop    r15
  40f421:	pop    r14
  40f423:	pop    r13
  40f425:	pop    r12
  40f427:	pop    rdi
  40f428:	pop    rsi
  40f429:	ret
  40f42a:	mov    QWORD PTR [r13+0x0],r14
  40f42e:	mov    rax,QWORD PTR [r14]
  40f431:	test   rax,rax
  40f434:	je     40f446 <__swc_fn_e121059d_000050_5e919db9+0x1c6>
  40f436:	mov    rcx,QWORD PTR [rax]
  40f439:	mov    QWORD PTR [r14],rcx
  40f43c:	add    DWORD PTR [r14+0x28],0x1
  40f441:	mov    r15,rax
  40f444:	jmp    40f466 <__swc_fn_e121059d_000050_5e919db9+0x1e6>
  40f446:	mov    rax,QWORD PTR [r14+0x18]
  40f44a:	cmp    QWORD PTR [r14+0x20],rax
  40f44e:	jae    40f463 <__swc_fn_e121059d_000050_5e919db9+0x1e3>
  40f450:	mov    r15,QWORD PTR [r14+0x20]
  40f454:	mov    eax,DWORD PTR [r14+0x2c]
  40f458:	add    QWORD PTR [r14+0x20],rax
  40f45c:	add    DWORD PTR [r14+0x28],0x1
  40f461:	jmp    40f466 <__swc_fn_e121059d_000050_5e919db9+0x1e6>
  40f463:	xor    r15d,r15d
  40f466:	test   r15,r15
  40f469:	jne    40f4ae <__swc_fn_e121059d_000050_5e919db9+0x22e>
  40f46b:	mov    rcx,r14
  40f46e:	call   407320 <__swc_fn_e121059d_000006_7b253ae1>
  40f473:	test   al,al
  40f475:	je     40f4ae <__swc_fn_e121059d_000050_5e919db9+0x22e>
  40f477:	mov    rax,QWORD PTR [r14]
  40f47a:	test   rax,rax
  40f47d:	je     40f48c <__swc_fn_e121059d_000050_5e919db9+0x20c>
  40f47f:	mov    rcx,QWORD PTR [rax]
  40f482:	mov    QWORD PTR [r14],rcx
  40f485:	add    DWORD PTR [r14+0x28],0x1
  40f48a:	jmp    40f4ab <__swc_fn_e121059d_000050_5e919db9+0x22b>
  40f48c:	mov    rax,QWORD PTR [r14+0x18]
  40f490:	cmp    QWORD PTR [r14+0x20],rax
  40f494:	jae    40f4a9 <__swc_fn_e121059d_000050_5e919db9+0x229>
  40f496:	mov    rax,QWORD PTR [r14+0x20]
  40f49a:	mov    ecx,DWORD PTR [r14+0x2c]
  40f49e:	add    QWORD PTR [r14+0x20],rcx
  40f4a2:	add    DWORD PTR [r14+0x28],0x1
  40f4a7:	jmp    40f4ab <__swc_fn_e121059d_000050_5e919db9+0x22b>
  40f4a9:	xor    eax,eax
  40f4ab:	mov    r15,rax
  40f4ae:	test   r15,r15
  40f4b1:	je     40f400 <__swc_fn_e121059d_000050_5e919db9+0x180>
  40f4b7:	mov    rax,r15
  40f4ba:	add    rsp,0x1f8
  40f4c1:	pop    r15
  40f4c3:	pop    r14
  40f4c5:	pop    r13
  40f4c7:	pop    r12
  40f4c9:	pop    rdi
  40f4ca:	pop    rsi
  40f4cb:	ret
  40f4cc:	add    BYTE PTR [rax],al
	...

000000000040f4d0 <__swc_fn_e121059d_000053_9aa81fa7>:
  40f4d0:	push   rsi
  40f4d1:	push   rdi
  40f4d2:	push   r12
  40f4d4:	mov    rsi,rdx
  40f4d7:	mov    rax,rdx
  40f4da:	shr    rax,0xc
  40f4de:	movabs rdx,0x9e3779b97f4a7c15
  40f4e8:	imul   rax,rdx
  40f4ec:	shr    rax,0x20
  40f4f0:	lea    rax,[rax*8+0x0]
  40f4f8:	shr    rax,0x20
  40f4fc:	lea    rax,[rax*8+0x0]
  40f504:	lea    rax,[rcx+rax*8+0x40]
  40f509:	xor    edx,edx
  40f50b:	test   dl,dl
  40f50d:	lea    rdi,[rcx+0x8]
  40f511:	cmove  rdi,rax
  40f515:	xor    edx,edx
  40f517:	test   dl,dl
  40f519:	lea    r12,[rcx+0x30]
  40f51d:	lea    rax,[rax+0x8]
  40f521:	cmove  r12,rax
  40f525:	mov    rcx,rdi
  40f528:	call   40e040 <__swc_fn_e121059d_000136_db32cc57>
  40f52d:	mov    QWORD PTR [rsi+0x30],0x0
  40f535:	mov    rax,QWORD PTR [r12]
  40f539:	mov    QWORD PTR [rsi+0x38],rax
  40f53d:	test   rax,rax
  40f540:	je     40f54a <__swc_fn_e121059d_000053_9aa81fa7+0x7a>
  40f542:	mov    rax,QWORD PTR [rsi+0x38]
  40f546:	mov    QWORD PTR [rax+0x30],rsi
  40f54a:	mov    QWORD PTR [r12],rsi
  40f54e:	mov    rcx,rdi
  40f551:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40f556:	pop    r12
  40f558:	pop    rdi
  40f559:	pop    rsi
  40f55a:	ret
  40f55b:	add    BYTE PTR [rax],al
  40f55d:	add    BYTE PTR [rax],al
	...

000000000040f560 <__swc_fn_e121059d_000056_87dc216f>:
  40f560:	lea    rax,[rdx+rdx*4]
  40f564:	lea    rax,[rcx+rax*8+0x268]
  40f56c:	mov    rdx,QWORD PTR [rax+0x10]
  40f570:	sub    QWORD PTR [rcx+0x2a68],rdx
  40f577:	sub    QWORD PTR [rcx+0x2a70],0x1
  40f57f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40f586:	lea    rdx,[rdx+rdx*4]
  40f58a:	lea    rdx,[rcx+rdx*8+0x268]
  40f592:	vmovups xmm0,XMMWORD PTR [rdx]
  40f596:	vmovups XMMWORD PTR [rax],xmm0
  40f59a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40f59f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40f5a4:	mov    rcx,QWORD PTR [rdx+0x20]
  40f5a8:	mov    QWORD PTR [rax+0x20],rcx
  40f5ac:	ret
  40f5ad:	add    BYTE PTR [rax],al
	...

000000000040f5b0 <__swc_fn_e121059d_000059_ee6a254c>:
  40f5b0:	push   rsi
  40f5b1:	push   rdi
  40f5b2:	push   r12
  40f5b4:	push   r13
  40f5b6:	sub    rsp,0x8
  40f5ba:	mov    rsi,r8
  40f5bd:	mov    rdi,rcx
  40f5c0:	mov    r12,rdx
  40f5c3:	xor    r13d,r13d
  40f5c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f5d0:	mov    eax,DWORD PTR [r12+0x730]
  40f5d8:	cmp    r13d,eax
  40f5db:	jae    40f641 <__swc_fn_e121059d_000059_ee6a254c+0x91>
  40f5dd:	lea    rax,[r13+r13*4+0x0]
  40f5e2:	lea    rax,[r12+rax*8+0x738]
  40f5ea:	mov    rdx,QWORD PTR [rax]
  40f5ed:	mov    r8,QWORD PTR [rax+0x8]
  40f5f1:	mov    r9,QWORD PTR [rax+0x10]
  40f5f5:	cmp    QWORD PTR [rax+0x20],rsi
  40f5f9:	jb     40f600 <__swc_fn_e121059d_000059_ee6a254c+0x50>
  40f5fb:	inc    r13d
  40f5fe:	jmp    40f5d0 <__swc_fn_e121059d_000059_ee6a254c+0x20>
  40f600:	sub    DWORD PTR [r12+0x730],0x1
  40f609:	mov    ecx,DWORD PTR [r12+0x730]
  40f611:	lea    rcx,[rcx+rcx*4]
  40f615:	lea    rcx,[r12+rcx*8+0x738]
  40f61d:	vmovups xmm0,XMMWORD PTR [rcx]
  40f621:	vmovups XMMWORD PTR [rax],xmm0
  40f625:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40f62a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40f62f:	mov    rcx,QWORD PTR [rcx+0x20]
  40f633:	mov    QWORD PTR [rax+0x20],rcx
  40f637:	mov    rcx,rdi
  40f63a:	call   407750 <__swc_fn_e121059d_000039_9ae4348f>
  40f63f:	jmp    40f5d0 <__swc_fn_e121059d_000059_ee6a254c+0x20>
  40f641:	add    rsp,0x8
  40f645:	pop    r13
  40f647:	pop    r12
  40f649:	pop    rdi
  40f64a:	pop    rsi
  40f64b:	ret
  40f64c:	add    BYTE PTR [rax],al
	...

000000000040f650 <__swc_fn_e121059d_000062_0a65f1d5>:
  40f650:	push   rsi
  40f651:	push   rdi
  40f652:	push   r12
  40f654:	push   r13
  40f656:	push   r14
  40f658:	mov    rsi,rcx
  40f65b:	mov    rdi,rdx
  40f65e:	mov    r12,QWORD PTR [rdi]
  40f661:	mov    r13,QWORD PTR [rdi+0x18]
  40f665:	mov    rax,r12
  40f668:	add    rax,QWORD PTR [rdi+0x8]
  40f66c:	sub    rax,r13
  40f66f:	cmp    r8,rax
  40f672:	jbe    40f67d <__swc_fn_e121059d_000062_0a65f1d5+0x2d>
  40f674:	pop    r14
  40f676:	pop    r13
  40f678:	pop    r12
  40f67a:	pop    rdi
  40f67b:	pop    rsi
  40f67c:	ret
  40f67d:	lea    rax,[r13+r8*1+0x0]
  40f682:	sub    rax,r12
  40f685:	mov    ecx,0x1000
  40f68a:	test   ecx,ecx
  40f68c:	mov    edx,0x8
  40f691:	cmove  ecx,edx
  40f694:	dec    rcx
  40f697:	mov    rdx,0xffffffffffffffff
  40f69e:	sub    rdx,rcx
  40f6a1:	cmp    rax,rdx
  40f6a4:	jbe    40f6ab <__swc_fn_e121059d_000062_0a65f1d5+0x5b>
  40f6a6:	xor    r14d,r14d
  40f6a9:	jmp    40f6b6 <__swc_fn_e121059d_000062_0a65f1d5+0x66>
  40f6ab:	add    rax,rcx
  40f6ae:	andn   rax,rcx,rax
  40f6b3:	mov    r14,rax
  40f6b6:	mov    rax,QWORD PTR [rdi+0x10]
  40f6ba:	cmp    r14,rax
  40f6bd:	ja     40f6c8 <__swc_fn_e121059d_000062_0a65f1d5+0x78>
  40f6bf:	pop    r14
  40f6c1:	pop    r13
  40f6c3:	pop    r12
  40f6c5:	pop    rdi
  40f6c6:	pop    rsi
  40f6c7:	ret
  40f6c8:	mov    rax,r12
  40f6cb:	add    rax,QWORD PTR [rdi+0x10]
  40f6cf:	mov    rdx,r14
  40f6d2:	sub    rdx,QWORD PTR [rdi+0x10]
  40f6d6:	mov    rcx,rax
  40f6d9:	call   4072a0 <__swc_fn_e121059d_000003_81215399>
  40f6de:	test   al,al
  40f6e0:	jne    40f6eb <__swc_fn_e121059d_000062_0a65f1d5+0x9b>
  40f6e2:	pop    r14
  40f6e4:	pop    r13
  40f6e6:	pop    r12
  40f6e8:	pop    rdi
  40f6e9:	pop    rsi
  40f6ea:	ret
  40f6eb:	add    r12,r14
  40f6ee:	sub    r12,r13
  40f6f1:	mov    rcx,r12
  40f6f4:	sub    rcx,QWORD PTR [rdi+0x28]
  40f6f8:	mov    rdx,QWORD PTR [rsi+0x250]
  40f6ff:	nop
  40f700:	lea    r8,[rdx+rcx*1]
  40f704:	mov    rax,rdx
  40f707:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40f710:	cmp    rax,rdx
  40f713:	je     40f71a <__swc_fn_e121059d_000062_0a65f1d5+0xca>
  40f715:	mov    rdx,rax
  40f718:	jmp    40f700 <__swc_fn_e121059d_000062_0a65f1d5+0xb0>
  40f71a:	mov    QWORD PTR [rdi+0x10],r14
  40f71e:	mov    QWORD PTR [rdi+0x28],r12
  40f722:	pop    r14
  40f724:	pop    r13
  40f726:	pop    r12
  40f728:	pop    rdi
  40f729:	pop    rsi
  40f72a:	ret
  40f72b:	add    BYTE PTR [rax],al
  40f72d:	add    BYTE PTR [rax],al
	...

000000000040f730 <__swc_fn_e121059d_000065_0b20477c>:
  40f730:	push   rbx
  40f731:	push   rsi
  40f732:	push   rdi
  40f733:	push   r12
  40f735:	push   r13
  40f737:	sub    rsp,0xe0
  40f73e:	mov    rbx,rdx
  40f741:	mov    rsi,rcx
  40f744:	cmp    DWORD PTR [rbx+0x58],0x0
  40f748:	je     40f76c <__swc_fn_e121059d_000065_0b20477c+0x3c>
  40f74a:	mov    eax,DWORD PTR [rbx+0x58]
  40f74d:	sub    eax,0x1
  40f750:	test   DWORD PTR [rbx+0x58],eax
  40f753:	je     40f76c <__swc_fn_e121059d_000065_0b20477c+0x3c>
  40f755:	mov    QWORD PTR [rbx+0x40],0x0
  40f75d:	add    rsp,0xe0
  40f764:	pop    r13
  40f766:	pop    r12
  40f768:	pop    rdi
  40f769:	pop    rsi
  40f76a:	pop    rbx
  40f76b:	ret
  40f76c:	mov    rax,QWORD PTR [rbx+0x40]
  40f770:	test   rax,rax
  40f773:	jne    40f78f <__swc_fn_e121059d_000065_0b20477c+0x5f>
  40f775:	mov    rcx,rsi
  40f778:	mov    rdx,rbx
  40f77b:	call   40ccb0 <__swc_fn_e121059d_000064_20100e91>
  40f780:	add    rsp,0xe0
  40f787:	pop    r13
  40f789:	pop    r12
  40f78b:	pop    rdi
  40f78c:	pop    rsi
  40f78d:	pop    rbx
  40f78e:	ret
  40f78f:	cmp    QWORD PTR [rbx+0x48],0x0
  40f794:	jne    40f7b0 <__swc_fn_e121059d_000065_0b20477c+0x80>
  40f796:	mov    rcx,rsi
  40f799:	mov    rdx,rbx
  40f79c:	call   407f90 <__swc_fn_e121059d_000066_918d3875>
  40f7a1:	add    rsp,0xe0
  40f7a8:	pop    r13
  40f7aa:	pop    r12
  40f7ac:	pop    rdi
  40f7ad:	pop    rsi
  40f7ae:	pop    rbx
  40f7af:	ret
  40f7b0:	mov    rdi,QWORD PTR [rbx+0x40]
  40f7b4:	lea    rax,[rip+0x148b5]        # 424070 <__swc_bss_base_e121059d+0x30>
  40f7bb:	mov    rcx,rdi
  40f7be:	sub    rcx,QWORD PTR [rax+0x8]
  40f7c2:	mov    rax,QWORD PTR [rip+0x148b7]        # 424080 <__swc_bss_base_e121059d+0x40>
  40f7c9:	cmp    rcx,rax
  40f7cc:	jae    40f7f8 <__swc_fn_e121059d_000065_0b20477c+0xc8>
  40f7ce:	mov    rax,rdi
  40f7d1:	and    rax,0xffffffffffc00000
  40f7d8:	mov    rcx,rdi
  40f7db:	shr    rcx,0x10
  40f7df:	and    ecx,0x3f
  40f7e2:	mov    edx,DWORD PTR [rax+0x28]
  40f7e5:	shrx   ecx,ecx,edx
  40f7ea:	shl    rcx,0x4
  40f7ee:	lea    r12,[rax+rcx*8+0x80]
  40f7f6:	jmp    40f803 <__swc_fn_e121059d_000065_0b20477c+0xd3>
  40f7f8:	mov    rcx,rdi
  40f7fb:	call   40bd30 <__swc_fn_e121059d_000022_53fc00d2>
  40f800:	mov    r12,rax
  40f803:	test   r12,r12
  40f806:	je     40f815 <__swc_fn_e121059d_000065_0b20477c+0xe5>
  40f808:	mov    eax,DWORD PTR [r12+0x2c]
  40f80d:	mov    r9d,eax
  40f810:	mov    r13,rax
  40f813:	jmp    40f894 <__swc_fn_e121059d_000065_0b20477c+0x164>
  40f815:	mov    rcx,rsi
  40f818:	mov    rdx,rdi
  40f81b:	call   40c340 <__swc_fn_e121059d_000052_92b016ae>
  40f820:	mov    rcx,QWORD PTR [rax+0x28]
  40f824:	mov    r9,rcx
  40f827:	mov    rdx,QWORD PTR [rax+0x20]
  40f82b:	mov    r13,rdx
  40f82e:	cmp    QWORD PTR [rbx+0x48],rcx
  40f832:	jbe    40f86b <__swc_fn_e121059d_000065_0b20477c+0x13b>
  40f834:	mov    ecx,DWORD PTR [rax+0x48]
  40f837:	cmp    DWORD PTR [rbx+0x58],ecx
  40f83a:	ja     40f86b <__swc_fn_e121059d_000065_0b20477c+0x13b>
  40f83c:	mov    rcx,rsi
  40f83f:	mov    rdx,rax
  40f842:	mov    r8,QWORD PTR [rbx+0x48]
  40f846:	mov    QWORD PTR [rsp+0xc8],r9
  40f84e:	mov    QWORD PTR [rsp+0xd0],rax
  40f856:	call   40f650 <__swc_fn_e121059d_000062_0a65f1d5>
  40f85b:	mov    r9,QWORD PTR [rsp+0xc8]
  40f863:	mov    rax,QWORD PTR [rsp+0xd0]
  40f86b:	mov    rcx,QWORD PTR [rax+0x28]
  40f86f:	cmp    QWORD PTR [rbx+0x48],rcx
  40f873:	ja     40f894 <__swc_fn_e121059d_000065_0b20477c+0x164>
  40f875:	mov    ecx,DWORD PTR [rax+0x48]
  40f878:	cmp    DWORD PTR [rbx+0x58],ecx
  40f87b:	ja     40f894 <__swc_fn_e121059d_000065_0b20477c+0x164>
  40f87d:	mov    rcx,QWORD PTR [rbx+0x48]
  40f881:	mov    QWORD PTR [rax+0x20],rcx
  40f885:	add    rsp,0xe0
  40f88c:	pop    r13
  40f88e:	pop    r12
  40f890:	pop    rdi
  40f891:	pop    rsi
  40f892:	pop    rbx
  40f893:	ret
  40f894:	test   r12,r12
  40f897:	je     40f8c9 <__swc_fn_e121059d_000065_0b20477c+0x199>
  40f899:	cmp    QWORD PTR [rbx+0x48],r9
  40f89d:	ja     40f8c9 <__swc_fn_e121059d_000065_0b20477c+0x199>
  40f89f:	cmp    DWORD PTR [rbx+0x58],0x40
  40f8a3:	ja     40f8c9 <__swc_fn_e121059d_000065_0b20477c+0x199>
  40f8a5:	cmp    DWORD PTR [rbx+0x58],0x0
  40f8a9:	je     40f8b6 <__swc_fn_e121059d_000065_0b20477c+0x186>
  40f8ab:	mov    ecx,DWORD PTR [rbx+0x58]
  40f8ae:	dec    rcx
  40f8b1:	test   rdi,rcx
  40f8b4:	jne    40f8c9 <__swc_fn_e121059d_000065_0b20477c+0x199>
  40f8b6:	mov    QWORD PTR [rbx+0x40],rdi
  40f8ba:	add    rsp,0xe0
  40f8c1:	pop    r13
  40f8c3:	pop    r12
  40f8c5:	pop    rdi
  40f8c6:	pop    rsi
  40f8c7:	pop    rbx
  40f8c8:	ret
  40f8c9:	vmovups xmm0,XMMWORD PTR [rbx]
  40f8cd:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f8d3:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40f8d8:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f8de:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40f8e3:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40f8e9:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40f8ee:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40f8f4:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40f8f9:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40f8ff:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40f904:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40f90a:	mov    QWORD PTR [rsp+0x48],0x0
  40f913:	mov    rcx,rsi
  40f916:	lea    rdx,[rsp+0x8]
  40f91b:	call   40ccb0 <__swc_fn_e121059d_000064_20100e91>
  40f920:	mov    rax,QWORD PTR [rsp+0x48]
  40f925:	test   rax,rax
  40f928:	jne    40f941 <__swc_fn_e121059d_000065_0b20477c+0x211>
  40f92a:	mov    QWORD PTR [rbx+0x40],0x0
  40f932:	add    rsp,0xe0
  40f939:	pop    r13
  40f93b:	pop    r12
  40f93d:	pop    rdi
  40f93e:	pop    rsi
  40f93f:	pop    rbx
  40f940:	ret
  40f941:	mov    rax,QWORD PTR [rbx+0x48]
  40f945:	cmp    r13,rax
  40f948:	cmovbe rax,r13
  40f94c:	mov    rcx,QWORD PTR [rsp+0x48]
  40f951:	mov    rdx,rdi
  40f954:	mov    r8,rax
  40f957:	call   40d880 <__swc_fn_e121059d_000106_83487ba1>
  40f95c:	vmovups xmm0,XMMWORD PTR [rbx]
  40f960:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40f966:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40f96b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40f971:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40f976:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40f97f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40f984:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40f98d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40f992:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40f99b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40f9a0:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40f9a9:	mov    QWORD PTR [rsp+0xa8],rdi
  40f9b1:	mov    rcx,rsi
  40f9b4:	lea    rdx,[rsp+0x68]
  40f9b9:	call   407f90 <__swc_fn_e121059d_000066_918d3875>
  40f9be:	mov    rax,QWORD PTR [rsp+0x48]
  40f9c3:	mov    QWORD PTR [rbx+0x40],rax
  40f9c7:	add    rsp,0xe0
  40f9ce:	pop    r13
  40f9d0:	pop    r12
  40f9d2:	pop    rdi
  40f9d3:	pop    rsi
  40f9d4:	pop    rbx
  40f9d5:	ret
	...

000000000040f9e0 <__swc_fn_e121059d_000068_f501e74b>:
  40f9e0:	push   r12
  40f9e2:	push   rdi
  40f9e3:	push   rsi
  40f9e4:	push   r13
  40f9e6:	push   r14
  40f9e8:	sub    rsp,0x190
  40f9ef:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40f9f8:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40fa01:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40fa0a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40fa13:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40fa1c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40fa25:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40fa2e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40fa37:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40fa40:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40fa49:	mov    r12,rcx
  40fa4c:	lea    rax,[rip+0x125ad]        # 422000 <__swc_data_base_e121059d>
  40fa53:	mov    rax,QWORD PTR [rax]
  40fa56:	cmp    rax,0xffffffffffffffff
  40fa5a:	je     40fa69 <__swc_fn_e121059d_000068_f501e74b+0x89>
  40fa5c:	mov    eax,eax
  40fa5e:	mov    edi,eax
  40fa60:	xor    eax,eax
  40fa62:	call   407000 <pthread_getspecific@plt>
  40fa67:	jmp    40fa6b <__swc_fn_e121059d_000068_f501e74b+0x8b>
  40fa69:	xor    eax,eax
  40fa6b:	test   rax,rax
  40fa6e:	jne    40fa7d <__swc_fn_e121059d_000068_f501e74b+0x9d>
  40fa70:	call   40be00 <__swc_fn_e121059d_000031_3c3e930e>
  40fa75:	mov    rcx,rax
  40fa78:	call   409ba0 <__swc_fn_e121059d_000129_8d8a7dd2>
  40fa7d:	test   rax,rax
  40fa80:	je     40faa6 <__swc_fn_e121059d_000068_f501e74b+0xc6>
  40fa82:	cmp    QWORD PTR [rax],r12
  40fa85:	jne    40faa6 <__swc_fn_e121059d_000068_f501e74b+0xc6>
  40fa87:	xor    ecx,ecx
  40fa89:	mov    QWORD PTR [rsp+0xc8],rax
  40fa91:	call   407720 <__swc_fn_e121059d_000033_d15eb4ea>
  40fa96:	mov    rdx,QWORD PTR [rsp+0xc8]
  40fa9e:	mov    rcx,r12
  40faa1:	call   407840 <__swc_fn_e121059d_000042_0573444d>
  40faa6:	lea    rsi,[r12+0x10]
  40faab:	mov    rcx,rsi
  40faae:	call   40e040 <__swc_fn_e121059d_000136_db32cc57>
  40fab3:	mov    rdi,QWORD PTR [r12+0x20]
  40fab8:	test   rdi,rdi
  40fabb:	je     40fafe <__swc_fn_e121059d_000068_f501e74b+0x11e>
  40fabd:	nop    DWORD PTR [rax]
  40fac0:	mov    rcx,r12
  40fac3:	mov    rdx,rdi
  40fac6:	call   40bfc0 <__swc_fn_e121059d_000043_47ff6d9b>
  40facb:	mov    rcx,r12
  40face:	mov    rdx,rdi
  40fad1:	mov    r8,0xffffffffffffffff
  40fad8:	call   40f5b0 <__swc_fn_e121059d_000059_ee6a254c>
  40fadd:	mov    rcx,r12
  40fae0:	mov    rdx,rdi
  40fae3:	mov    r8d,0x9b8
  40fae9:	mov    r9d,0x9b8
  40faef:	call   407750 <__swc_fn_e121059d_000039_9ae4348f>
  40faf4:	mov    rdi,QWORD PTR [r12+0x20]
  40faf9:	test   rdi,rdi
  40fafc:	jne    40fac0 <__swc_fn_e121059d_000068_f501e74b+0xe0>
  40fafe:	xor    eax,eax
  40fb00:	xchg   QWORD PTR [r12+0x2a80],rax
  40fb08:	test   rax,rax
  40fb0b:	je     40fb31 <__swc_fn_e121059d_000068_f501e74b+0x151>
  40fb0d:	cs nop WORD PTR [rax+rax*1+0x0]
  40fb17:	nop    WORD PTR [rax+rax*1+0x0]
  40fb20:	mov    rcx,rax
  40fb23:	mov    rax,QWORD PTR [rax+0x78]
  40fb27:	xor    edx,edx
  40fb29:	xchg   DWORD PTR [rcx+0x70],edx
  40fb2c:	test   rax,rax
  40fb2f:	jne    40fb20 <__swc_fn_e121059d_000068_f501e74b+0x140>
  40fb31:	mov    rax,QWORD PTR [r12+0x18]
  40fb36:	mov    rdi,rax
  40fb39:	test   rdi,rdi
  40fb3c:	je     40fbd1 <__swc_fn_e121059d_000068_f501e74b+0x1f1>
  40fb42:	cs nop WORD PTR [rax+rax*1+0x0]
  40fb4c:	nop    DWORD PTR [rax+0x0]
  40fb50:	mov    rax,QWORD PTR [rdi+0x10]
  40fb54:	mov    r8d,DWORD PTR [rdi+0x2c]
  40fb58:	xor    r9d,r9d
  40fb5b:	test   r8,r8
  40fb5e:	jbe    40fbbd <__swc_fn_e121059d_000068_f501e74b+0x1dd>
  40fb60:	mov    ecx,r9d
  40fb63:	shl    rcx,0x4
  40fb67:	lea    rdx,[rdi+rcx*8+0x80]
  40fb6f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40fb73:	je     40fbb4 <__swc_fn_e121059d_000068_f501e74b+0x1d4>
  40fb75:	mov    DWORD PTR [rdx+0x28],0x0
  40fb7c:	mov    rcx,rdi
  40fb7f:	mov    QWORD PTR [rsp+0xd0],rax
  40fb87:	mov    QWORD PTR [rsp+0xd8],r8
  40fb8f:	mov    QWORD PTR [rsp+0xe0],r9
  40fb97:	call   40ece0 <__swc_fn_e121059d_000014_be17798c>
  40fb9c:	mov    rax,QWORD PTR [rsp+0xd0]
  40fba4:	mov    r8,QWORD PTR [rsp+0xd8]
  40fbac:	mov    r9,QWORD PTR [rsp+0xe0]
  40fbb4:	add    r9,0x1
  40fbb8:	cmp    r9,r8
  40fbbb:	jb     40fb60 <__swc_fn_e121059d_000068_f501e74b+0x180>
  40fbbd:	mov    rcx,rdi
  40fbc0:	mov    rdi,rax
  40fbc3:	call   407630 <__swc_fn_e121059d_000021_9cf87641>
  40fbc8:	test   rdi,rdi
  40fbcb:	jne    40fb50 <__swc_fn_e121059d_000068_f501e74b+0x170>
  40fbd1:	mov    QWORD PTR [r12+0x18],0x0
  40fbda:	mov    QWORD PTR [r12+0x28],0x0
  40fbe3:	mov    rcx,rsi
  40fbe6:	call   4111b0 <__swc_fn_e121059d_000137_d579ef75>
  40fbeb:	mov    esi,0x8
  40fbf0:	xor    edi,edi
  40fbf2:	test   rsi,rsi
  40fbf5:	je     40fc52 <__swc_fn_e121059d_000068_f501e74b+0x272>
  40fbfb:	nop    DWORD PTR [rax+rax*1+0x0]
  40fc00:	lea    r13,[rdi*8+0x0]
  40fc08:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40fc0d:	test   r14,r14
  40fc10:	je     40fc48 <__swc_fn_e121059d_000068_f501e74b+0x268>
  40fc12:	cs nop WORD PTR [rax+rax*1+0x0]
  40fc1c:	nop    DWORD PTR [rax+0x0]
  40fc20:	mov    rcx,r12
  40fc23:	mov    rdx,r14
  40fc26:	call   407df0 <__swc_fn_e121059d_000054_e8e85c01>
  40fc2b:	mov    rcx,r12
  40fc2e:	mov    rdx,QWORD PTR [r14]
  40fc31:	mov    r8,QWORD PTR [r14+0x8]
  40fc35:	mov    r9,QWORD PTR [r14+0x10]
  40fc39:	call   407750 <__swc_fn_e121059d_000039_9ae4348f>
  40fc3e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40fc43:	test   r14,r14
  40fc46:	jne    40fc20 <__swc_fn_e121059d_000068_f501e74b+0x240>
  40fc48:	add    rdi,0x1
  40fc4c:	sub    rsi,0x1
  40fc50:	jne    40fc00 <__swc_fn_e121059d_000068_f501e74b+0x220>
  40fc52:	mov    rcx,r12
  40fc55:	call   407ec0 <__swc_fn_e121059d_000060_6818d0d1>
  40fc5a:	lea    rcx,[r12+0x250]
  40fc62:	mov    rdx,QWORD PTR [rcx]
  40fc65:	mov    r8,QWORD PTR [r12+0x250]
  40fc6d:	nop    DWORD PTR [rax]
  40fc70:	mov    r9,r8
  40fc73:	sub    r9,rdx
  40fc76:	mov    rax,r8
  40fc79:	lock cmpxchg QWORD PTR [rcx],r9
  40fc7e:	cmp    rax,r8
  40fc81:	je     40fc88 <__swc_fn_e121059d_000068_f501e74b+0x2a8>
  40fc83:	mov    r8,rax
  40fc86:	jmp    40fc70 <__swc_fn_e121059d_000068_f501e74b+0x290>
  40fc88:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40fc91:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40fc9a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40fca3:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40fcac:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40fcb5:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40fcbe:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40fcc7:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40fcd0:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40fcd9:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40fce2:	add    rsp,0x190
  40fce9:	pop    r14
  40fceb:	pop    r13
  40fced:	pop    rsi
  40fcee:	pop    rdi
  40fcef:	pop    r12
  40fcf1:	ret
	...

000000000040fd00 <__swc_fn_e121059d_000071_1e1e3bf8>:
  40fd00:	sub    rsp,0x8
  40fd04:	mov    QWORD PTR [rdx+0x40],0x0
  40fd0c:	call   40ccb0 <__swc_fn_e121059d_000064_20100e91>
  40fd11:	add    rsp,0x8
  40fd15:	ret
	...

000000000040fd20 <__swc_fn_e121059d_000074_30b8696a>:
  40fd20:	sub    rsp,0x8
  40fd24:	call   407f90 <__swc_fn_e121059d_000066_918d3875>
  40fd29:	add    rsp,0x8
  40fd2d:	ret
	...

000000000040fd30 <__swc_fn_e121059d_000077_948ef603>:
  40fd30:	push   rbx
  40fd31:	push   rsi
  40fd32:	push   rdi
  40fd33:	push   r12
  40fd35:	push   r13
  40fd37:	push   r14
  40fd39:	push   r15
  40fd3b:	sub    rsp,0x20
  40fd3f:	mov    rbx,r11
  40fd42:	mov    rsi,rcx
  40fd45:	mov    rdi,rdx
  40fd48:	mov    r12,r8
  40fd4b:	mov    r13,r9
  40fd4e:	mov    r14,r10
  40fd51:	mov    rcx,QWORD PTR [rip+0x16fe8]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40fd58:	test   rcx,rcx
  40fd5b:	jne    40fd6d <__swc_fn_e121059d_000077_948ef603+0x3d>
  40fd5d:	call   40e940 <__swc_fn_e121059d_000166_56054fe7>
  40fd62:	lea    rcx,[rax+0x1]
  40fd66:	mov    QWORD PTR [rip+0x16fd3],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40fd6d:	dec    rcx
  40fd70:	call   40b620 <__swc_fn_e121059d_000168_39c041ad>
  40fd75:	mov    r15,rax
  40fd78:	lea    r11,[rip+0x144c1]        # 424240 <__swc_bss_base_e121059d+0x200>
  40fd7f:	mov    rcx,r11
  40fd82:	call   407740 <__swc_fn_e121059d_000036_290a131c>
  40fd87:	test   al,al
  40fd89:	jne    40fd9a <__swc_fn_e121059d_000077_948ef603+0x6a>
  40fd8b:	mov    rcx,r11
  40fd8e:	call   40be60 <__swc_fn_e121059d_000034_cf5ba7bd>
  40fd93:	lea    r11,[rip+0x144a6]        # 424240 <__swc_bss_base_e121059d+0x200>
  40fd9a:	mov    rcx,r11
  40fd9d:	mov    rdx,rsi
  40fda0:	mov    r8,rdi
  40fda3:	mov    r9,r12
  40fda6:	mov    r10,r13
  40fda9:	mov    rsi,r11
  40fdac:	mov    r11,r14
  40fdaf:	call   40f050 <__swc_fn_e121059d_000035_ab2e8c35>
  40fdb4:	test   bl,bl
  40fdb6:	je     40fddd <__swc_fn_e121059d_000077_948ef603+0xad>
  40fdb8:	mov    QWORD PTR [rsp+0x8],rsi
  40fdbd:	lea    rax,[rip+0x338c]        # 413150 <__swc_rdata_base_e121059d+0x40>
  40fdc4:	mov    QWORD PTR [rsp+0x10],rax
  40fdc9:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40fdcf:	vmovups XMMWORD PTR [r15],xmm0
  40fdd4:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40fddd:	mov    rax,rsi
  40fde0:	add    rsp,0x20
  40fde4:	pop    r15
  40fde6:	pop    r14
  40fde8:	pop    r13
  40fdea:	pop    r12
  40fdec:	pop    rdi
  40fded:	pop    rsi
  40fdee:	pop    rbx
  40fdef:	ret

000000000040fdf0 <__swc_fn_e121059d_000080_207908fe>:
  40fdf0:	sub    rsp,0x8
  40fdf4:	mov    rax,rcx
  40fdf7:	test   rcx,rcx
  40fdfa:	jne    40fe01 <__swc_fn_e121059d_000080_207908fe+0x11>
  40fdfc:	add    rsp,0x8
  40fe00:	ret
  40fe01:	lea    rcx,[rax-0x10]
  40fe05:	mov    rax,QWORD PTR [rax-0x10]
  40fe09:	mov    rdx,rax
  40fe0c:	call   409850 <__swc_fn_e121059d_000114_4e83a03a>
  40fe11:	add    rsp,0x8
  40fe15:	ret
	...

000000000040fe20 <__swc_fn_e121059d_000083_f2d93dad>:
  40fe20:	sub    rsp,0x8
  40fe24:	xor    r11d,r11d
  40fe27:	call   408250 <__swc_fn_e121059d_000084_5ed30bd6>
  40fe2c:	add    rsp,0x8
  40fe30:	ret
	...

000000000040fe40 <__swc_fn_e121059d_000086_d9243de4>:
  40fe40:	push   rsi
  40fe41:	push   rdi
  40fe42:	push   r12
  40fe44:	push   r13
  40fe46:	push   r14
  40fe48:	push   r15
  40fe4a:	sub    rsp,0x68
  40fe4e:	mov    rsi,r9
  40fe51:	mov    rdi,rcx
  40fe54:	mov    r12,rdx
  40fe57:	mov    r13,r8
  40fe5a:	cmp    r8,r9
  40fe5d:	jne    40fe85 <__swc_fn_e121059d_000086_d9243de4+0x45>
  40fe5f:	mov    rcx,rdi
  40fe62:	mov    rdx,r12
  40fe65:	xor    r8d,r8d
  40fe68:	call   4085a0 <__swc_fn_e121059d_000090_14cf59b2>
  40fe6d:	test   al,al
  40fe6f:	je     40fe85 <__swc_fn_e121059d_000086_d9243de4+0x45>
  40fe71:	mov    eax,0x1
  40fe76:	add    rsp,0x68
  40fe7a:	pop    r15
  40fe7c:	pop    r14
  40fe7e:	pop    r13
  40fe80:	pop    r12
  40fe82:	pop    rdi
  40fe83:	pop    rsi
  40fe84:	ret
  40fe85:	cmp    BYTE PTR [r12+0x2c],0xe
  40fe8b:	je     40fe9e <__swc_fn_e121059d_000086_d9243de4+0x5e>
  40fe8d:	xor    eax,eax
  40fe8f:	add    rsp,0x68
  40fe93:	pop    r15
  40fe95:	pop    r14
  40fe97:	pop    r13
  40fe99:	pop    r12
  40fe9b:	pop    rdi
  40fe9c:	pop    rsi
  40fe9d:	ret
  40fe9e:	mov    r14,QWORD PTR [r12+0x98]
  40fea6:	mov    rax,QWORD PTR [r12+0xa0]
  40feae:	mov    r12,rax
  40feb1:	xor    r15d,r15d
  40feb4:	test   r12,r12
  40feb7:	je     40ff1f <__swc_fn_e121059d_000086_d9243de4+0xdf>
  40feb9:	nop    DWORD PTR [rax+0x0]
  40fec0:	mov    QWORD PTR [rsp+0x58],r12
  40fec5:	lea    r12,[r15*8+0x0]
  40fecd:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40fed2:	mov    rcx,rax
  40fed5:	call   40d440 <__swc_fn_e121059d_000082_ff7d1455>
  40feda:	cmp    BYTE PTR [rax+0x2c],0xe
  40fede:	jne    40ff10 <__swc_fn_e121059d_000086_d9243de4+0xd0>
  40fee0:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40fee5:	lea    r8,[r13+rcx*1+0x0]
  40feea:	mov    rcx,rdi
  40feed:	mov    rdx,rax
  40fef0:	mov    r9,rsi
  40fef3:	call   40fe40 <__swc_fn_e121059d_000086_d9243de4>
  40fef8:	test   al,al
  40fefa:	je     40ff10 <__swc_fn_e121059d_000086_d9243de4+0xd0>
  40fefc:	mov    eax,0x1
  40ff01:	add    rsp,0x68
  40ff05:	pop    r15
  40ff07:	pop    r14
  40ff09:	pop    r13
  40ff0b:	pop    r12
  40ff0d:	pop    rdi
  40ff0e:	pop    rsi
  40ff0f:	ret
  40ff10:	add    r15,0x1
  40ff14:	mov    r12,QWORD PTR [rsp+0x58]
  40ff19:	sub    r12,0x1
  40ff1d:	jne    40fec0 <__swc_fn_e121059d_000086_d9243de4+0x80>
  40ff1f:	xor    eax,eax
  40ff21:	add    rsp,0x68
  40ff25:	pop    r15
  40ff27:	pop    r14
  40ff29:	pop    r13
  40ff2b:	pop    r12
  40ff2d:	pop    rdi
  40ff2e:	pop    rsi
  40ff2f:	ret

000000000040ff30 <__swc_fn_e121059d_000089_3c530920>:
  40ff30:	push   rbp
  40ff31:	push   rbx
  40ff32:	push   rsi
  40ff33:	push   rdi
  40ff34:	push   r12
  40ff36:	push   r13
  40ff38:	push   r14
  40ff3a:	push   r15
  40ff3c:	sub    rsp,0x38
  40ff40:	mov    rbp,rsp
  40ff43:	mov    rbx,r11
  40ff46:	mov    rsi,rdx
  40ff49:	mov    rdi,r8
  40ff4c:	mov    r12,r9
  40ff4f:	mov    QWORD PTR [rsp+0x18],r9
  40ff54:	mov    r13,r10
  40ff57:	movzx  r14d,BYTE PTR [rbp+0x80]
  40ff5f:	movzx  r15d,BYTE PTR [rbp+0x88]
  40ff67:	test   r11,r11
  40ff6a:	je     40ff70 <__swc_fn_e121059d_000089_3c530920+0x40>
  40ff6c:	xor    eax,eax
  40ff6e:	mov    BYTE PTR [rbx],al
  40ff70:	test   r12,r12
  40ff73:	je     40ff7e <__swc_fn_e121059d_000089_3c530920+0x4e>
  40ff75:	mov    QWORD PTR [r12+0x8],0x0
  40ff7e:	test   rcx,rcx
  40ff81:	je     40ff88 <__swc_fn_e121059d_000089_3c530920+0x58>
  40ff83:	test   rsi,rsi
  40ff86:	jne    40ff9b <__swc_fn_e121059d_000089_3c530920+0x6b>
  40ff88:	xor    eax,eax
  40ff8a:	add    rsp,0x38
  40ff8e:	pop    r15
  40ff90:	pop    r14
  40ff92:	pop    r13
  40ff94:	pop    r12
  40ff96:	pop    rdi
  40ff97:	pop    rsi
  40ff98:	pop    rbx
  40ff99:	pop    rbp
  40ff9a:	ret
  40ff9b:	call   40d440 <__swc_fn_e121059d_000082_ff7d1455>
  40ffa0:	mov    r12,rax
  40ffa3:	mov    al,r15b
  40ffa6:	test   r15b,r15b
  40ffa9:	jne    40ffb9 <__swc_fn_e121059d_000089_3c530920+0x89>
  40ffab:	mov    eax,DWORD PTR [r12+0x28]
  40ffb0:	and    eax,0x10000
  40ffb6:	setne  al
  40ffb9:	lea    r15,[rsp+0x8]
  40ffbe:	mov    QWORD PTR [rsp+0x20],r15
  40ffc3:	rex mov BYTE PTR [rsp+0x8],al
  40ffc8:	test   DWORD PTR [rsi+0x28],0x400000
  40ffcf:	je     410007 <__swc_fn_e121059d_000089_3c530920+0xd7>
  40ffd1:	test   rsi,rsi
  40ffd4:	je     40fff4 <__swc_fn_e121059d_000089_3c530920+0xc4>
  40ffd6:	mov    rax,QWORD PTR [rsi+0x38]
  40ffda:	cmp    QWORD PTR [rax+0x10],rsi
  40ffde:	jne    40fff4 <__swc_fn_e121059d_000089_3c530920+0xc4>
  40ffe0:	rex mov al,BYTE PTR [rsp+0x8]
  40ffe5:	test   al,al
  40ffe7:	sete   al
  40ffea:	test   r14b,r14b
  40ffed:	sete   cl
  40fff0:	test   al,cl
  40fff2:	je     410007 <__swc_fn_e121059d_000089_3c530920+0xd7>
  40fff4:	xor    eax,eax
  40fff6:	add    rsp,0x38
  40fffa:	pop    r15
  40fffc:	pop    r14
  40fffe:	pop    r13
  410000:	pop    r12
  410002:	pop    rdi
  410003:	pop    rsi
  410004:	pop    rbx
  410005:	pop    rbp
  410006:	ret
  410007:	mov    r15,r12
  41000a:	test   r14b,r14b
  41000d:	jne    410024 <__swc_fn_e121059d_000089_3c530920+0xf4>
  41000f:	cmp    BYTE PTR [r12+0x2c],0x6
  410015:	jne    410024 <__swc_fn_e121059d_000089_3c530920+0xf4>
  410017:	mov    rcx,QWORD PTR [r12+0x40]
  41001c:	call   40d440 <__swc_fn_e121059d_000082_ff7d1455>
  410021:	mov    r15,rax
  410024:	test   r14b,r14b
  410027:	je     41002d <__swc_fn_e121059d_000089_3c530920+0xfd>
  410029:	mov    r15,QWORD PTR [r15+0x30]
  41002d:	mov    rcx,rsi
  410030:	call   40d440 <__swc_fn_e121059d_000082_ff7d1455>
  410035:	mov    rsi,rax
  410038:	rex cmp BYTE PTR [rsi+0x2c],0x6
  41003d:	je     410074 <__swc_fn_e121059d_000089_3c530920+0x144>
  41003f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  410044:	je     410074 <__swc_fn_e121059d_000089_3c530920+0x144>
  410046:	mov    eax,DWORD PTR [rsi+0x28]
  410049:	and    eax,0x10000
  41004f:	je     410074 <__swc_fn_e121059d_000089_3c530920+0x144>
  410051:	rex mov al,BYTE PTR [rsp+0x8]
  410056:	test   al,al
  410058:	jne    41006d <__swc_fn_e121059d_000089_3c530920+0x13d>
  41005a:	xor    eax,eax
  41005c:	add    rsp,0x38
  410060:	pop    r15
  410062:	pop    r14
  410064:	pop    r13
  410066:	pop    r12
  410068:	pop    rdi
  410069:	pop    rsi
  41006a:	pop    rbx
  41006b:	pop    rbp
  41006c:	ret
  41006d:	mov    rax,QWORD PTR [rsi+0x30]
  410071:	mov    rsi,rax
  410074:	mov    r14b,r13b
  410077:	test   rbx,rbx
  41007a:	je     4100b0 <__swc_fn_e121059d_000089_3c530920+0x180>
  41007c:	cmp    BYTE PTR [r12+0x2c],0x6
  410082:	jne    4100b0 <__swc_fn_e121059d_000089_3c530920+0x180>
  410084:	lea    rdx,[rip+0x30f5]        # 413180 <__swc_rdata_base_e121059d+0x70>
  41008b:	mov    rcx,rsi
  41008e:	xor    r8d,r8d
  410091:	call   4085a0 <__swc_fn_e121059d_000090_14cf59b2>
  410096:	test   al,al
  410098:	je     4100b0 <__swc_fn_e121059d_000089_3c530920+0x180>
  41009a:	mov    BYTE PTR [rbx],0x1
  41009d:	xor    eax,eax
  41009f:	add    rsp,0x38
  4100a3:	pop    r15
  4100a5:	pop    r14
  4100a7:	pop    r13
  4100a9:	pop    r12
  4100ab:	pop    rdi
  4100ac:	pop    rsi
  4100ad:	pop    rbx
  4100ae:	pop    rbp
  4100af:	ret
  4100b0:	test   rdi,rdi
  4100b3:	jne    4100cd <__swc_fn_e121059d_000089_3c530920+0x19d>
  4100b5:	test   r13b,r13b
  4100b8:	jne    4100cd <__swc_fn_e121059d_000089_3c530920+0x19d>
  4100ba:	xor    eax,eax
  4100bc:	add    rsp,0x38
  4100c0:	pop    r15
  4100c2:	pop    r14
  4100c4:	pop    r13
  4100c6:	pop    r12
  4100c8:	pop    rdi
  4100c9:	pop    rsi
  4100ca:	pop    rbx
  4100cb:	pop    rbp
  4100cc:	ret
  4100cd:	rex cmp BYTE PTR [rsi+0x2c],0x6
  4100d2:	jne    410188 <__swc_fn_e121059d_000089_3c530920+0x258>
  4100d8:	mov    rcx,r15
  4100db:	mov    rdx,rsi
  4100de:	xor    r8d,r8d
  4100e1:	call   4085a0 <__swc_fn_e121059d_000090_14cf59b2>
  4100e6:	test   al,al
  4100e8:	jne    410188 <__swc_fn_e121059d_000089_3c530920+0x258>
  4100ee:	test   DWORD PTR [rsi+0x28],0x10000
  4100f5:	je     410113 <__swc_fn_e121059d_000089_3c530920+0x1e3>
  4100f7:	rex mov al,BYTE PTR [rsp+0x8]
  4100fc:	test   al,al
  4100fe:	jne    410113 <__swc_fn_e121059d_000089_3c530920+0x1e3>
  410100:	xor    eax,eax
  410102:	add    rsp,0x38
  410106:	pop    r15
  410108:	pop    r14
  41010a:	pop    r13
  41010c:	pop    r12
  41010e:	pop    rdi
  41010f:	pop    rsi
  410110:	pop    rbx
  410111:	pop    rbp
  410112:	ret
  410113:	test   rdi,rdi
  410116:	jne    41012b <__swc_fn_e121059d_000089_3c530920+0x1fb>
  410118:	xor    eax,eax
  41011a:	add    rsp,0x38
  41011e:	pop    r15
  410120:	pop    r14
  410122:	pop    r13
  410124:	pop    r12
  410126:	pop    rdi
  410127:	pop    rsi
  410128:	pop    rbx
  410129:	pop    rbp
  41012a:	ret
  41012b:	mov    rcx,QWORD PTR [rsi+0x40]
  41012f:	call   40d440 <__swc_fn_e121059d_000082_ff7d1455>
  410134:	mov    rsi,rax
  410137:	mov    rax,QWORD PTR [rdi]
  41013a:	mov    rdi,rax
  41013d:	test   rax,rax
  410140:	jne    410183 <__swc_fn_e121059d_000089_3c530920+0x253>
  410142:	test   rbx,rbx
  410145:	je     410183 <__swc_fn_e121059d_000089_3c530920+0x253>
  410147:	mov    rcx,r15
  41014a:	mov    rdx,rsi
  41014d:	xor    r8d,r8d
  410150:	call   4085a0 <__swc_fn_e121059d_000090_14cf59b2>
  410155:	mov    rcx,rax
  410158:	test   al,al
  41015a:	jne    41017c <__swc_fn_e121059d_000089_3c530920+0x24c>
  41015c:	mov    rcx,r15
  41015f:	mov    rdx,rsi
  410162:	call   40d480 <__swc_fn_e121059d_000085_e24ecd12>
  410167:	mov    rcx,rax
  41016a:	test   al,al
  41016c:	jne    41017c <__swc_fn_e121059d_000089_3c530920+0x24c>
  41016e:	mov    rcx,rsi
  410171:	mov    rdx,r15
  410174:	call   40d480 <__swc_fn_e121059d_000085_e24ecd12>
  410179:	mov    rcx,rax
  41017c:	test   cl,cl
  41017e:	setne  al
  410181:	mov    BYTE PTR [rbx],al
  410183:	xor    eax,eax
  410185:	mov    r14b,al
  410188:	test   rdi,rdi
  41018b:	jne    4101a5 <__swc_fn_e121059d_000089_3c530920+0x275>
  41018d:	test   r14b,r14b
  410190:	jne    4101a5 <__swc_fn_e121059d_000089_3c530920+0x275>
  410192:	xor    eax,eax
  410194:	add    rsp,0x38
  410198:	pop    r15
  41019a:	pop    r14
  41019c:	pop    r13
  41019e:	pop    r12
  4101a0:	pop    rdi
  4101a1:	pop    rsi
  4101a2:	pop    rbx
  4101a3:	pop    rbp
  4101a4:	ret
  4101a5:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4101aa:	je     4101b6 <__swc_fn_e121059d_000089_3c530920+0x286>
  4101ac:	mov    r12,QWORD PTR [rsp+0x18]
  4101b1:	jmp    41023e <__swc_fn_e121059d_000089_3c530920+0x30e>
  4101b6:	mov    r12,QWORD PTR [rsp+0x18]
  4101bb:	test   r12,r12
  4101be:	jne    4101d2 <__swc_fn_e121059d_000089_3c530920+0x2a2>
  4101c0:	mov    rcx,r15
  4101c3:	mov    rdx,rsi
  4101c6:	xor    r8d,r8d
  4101c9:	call   4085a0 <__swc_fn_e121059d_000090_14cf59b2>
  4101ce:	test   al,al
  4101d0:	jne    41023e <__swc_fn_e121059d_000089_3c530920+0x30e>
  4101d2:	test   DWORD PTR [rsi+0x28],0x10000
  4101d9:	je     4101f7 <__swc_fn_e121059d_000089_3c530920+0x2c7>
  4101db:	rex mov al,BYTE PTR [rsp+0x8]
  4101e0:	test   al,al
  4101e2:	jne    4101f7 <__swc_fn_e121059d_000089_3c530920+0x2c7>
  4101e4:	xor    eax,eax
  4101e6:	add    rsp,0x38
  4101ea:	pop    r15
  4101ec:	pop    r14
  4101ee:	pop    r13
  4101f0:	pop    r12
  4101f2:	pop    rdi
  4101f3:	pop    rsi
  4101f4:	pop    rbx
  4101f5:	pop    rbp
  4101f6:	ret
  4101f7:	test   rdi,rdi
  4101fa:	jne    41020f <__swc_fn_e121059d_000089_3c530920+0x2df>
  4101fc:	xor    eax,eax
  4101fe:	add    rsp,0x38
  410202:	pop    r15
  410204:	pop    r14
  410206:	pop    r13
  410208:	pop    r12
  41020a:	pop    rdi
  41020b:	pop    rsi
  41020c:	pop    rbx
  41020d:	pop    rbp
  41020e:	ret
  41020f:	cmp    QWORD PTR [rdi+0x8],0x0
  410214:	jne    410229 <__swc_fn_e121059d_000089_3c530920+0x2f9>
  410216:	xor    eax,eax
  410218:	add    rsp,0x38
  41021c:	pop    r15
  41021e:	pop    r14
  410220:	pop    r13
  410222:	pop    r12
  410224:	pop    rdi
  410225:	pop    rsi
  410226:	pop    rbx
  410227:	pop    rbp
  410228:	ret
  410229:	mov    rax,QWORD PTR [rdi+0x8]
  41022d:	mov    rax,QWORD PTR [rax]
  410230:	mov    rsi,rax
  410233:	mov    rdi,QWORD PTR [rdi]
  410236:	mov    eax,0x1
  41023b:	mov    r14b,al
  41023e:	test   rdi,rdi
  410241:	mov    rbx,QWORD PTR [rsp+0x20]
  410246:	jne    410290 <__swc_fn_e121059d_000089_3c530920+0x360>
  410248:	test   r14b,r14b
  41024b:	je     41027d <__swc_fn_e121059d_000089_3c530920+0x34d>
  41024d:	test   r12,r12
  410250:	je     41027d <__swc_fn_e121059d_000089_3c530920+0x34d>
  410252:	mov    rcx,r15
  410255:	mov    rdx,rsi
  410258:	xor    r8d,r8d
  41025b:	mov    r9,r12
  41025e:	mov    rbx,QWORD PTR [rsp+0x20]
  410263:	movzx  r10d,BYTE PTR [rbx]
  410267:	call   40fe20 <__swc_fn_e121059d_000083_f2d93dad>
  41026c:	add    rsp,0x38
  410270:	pop    r15
  410272:	pop    r14
  410274:	pop    r13
  410276:	pop    r12
  410278:	pop    rdi
  410279:	pop    rsi
  41027a:	pop    rbx
  41027b:	pop    rbp
  41027c:	ret
  41027d:	xor    eax,eax
  41027f:	add    rsp,0x38
  410283:	pop    r15
  410285:	pop    r14
  410287:	pop    r13
  410289:	pop    r12
  41028b:	pop    rdi
  41028c:	pop    rsi
  41028d:	pop    rbx
  41028e:	pop    rbp
  41028f:	ret
  410290:	mov    r13,rsi
  410293:	mov    QWORD PTR [rsp+0x28],rdi
  410298:	cmp    BYTE PTR [r15+0x2c],0xe
  41029d:	sete   al
  4102a0:	mov    r14b,al
  4102a3:	jne    4102b7 <__swc_fn_e121059d_000089_3c530920+0x387>
  4102a5:	mov    rcx,rsi
  4102a8:	mov    rdx,r15
  4102ab:	call   40d480 <__swc_fn_e121059d_000085_e24ecd12>
  4102b0:	mov    r14b,al
  4102b3:	test   al,al
  4102b5:	jne    4102ec <__swc_fn_e121059d_000089_3c530920+0x3bc>
  4102b7:	cmp    BYTE PTR [r15+0x2c],0x12
  4102bc:	je     4102ec <__swc_fn_e121059d_000089_3c530920+0x3bc>
  4102be:	mov    rcx,r15
  4102c1:	mov    rdx,rsi
  4102c4:	mov    r8,rdi
  4102c7:	mov    r9,r12
  4102ca:	mov    rax,rbx
  4102cd:	movzx  r10d,BYTE PTR [rax]
  4102d1:	call   40fe20 <__swc_fn_e121059d_000083_f2d93dad>
  4102d6:	test   rax,rax
  4102d9:	je     4102ec <__swc_fn_e121059d_000089_3c530920+0x3bc>
  4102db:	add    rsp,0x38
  4102df:	pop    r15
  4102e1:	pop    r14
  4102e3:	pop    r13
  4102e5:	pop    r12
  4102e7:	pop    rdi
  4102e8:	pop    rsi
  4102e9:	pop    rbx
  4102ea:	pop    rbp
  4102eb:	ret
  4102ec:	rex cmp BYTE PTR [rsi+0x2c],0xe
  4102f1:	jne    410310 <__swc_fn_e121059d_000089_3c530920+0x3e0>
  4102f3:	mov    rax,QWORD PTR [rsi+0xd8]
  4102fa:	test   rax,rax
  4102fd:	je     410310 <__swc_fn_e121059d_000089_3c530920+0x3e0>
  4102ff:	add    rdi,QWORD PTR [rax+0x8]
  410303:	mov    rax,QWORD PTR [rdi]
  410306:	sub    rdi,QWORD PTR [rax+0x8]
  41030a:	mov    rax,QWORD PTR [rax]
  41030d:	mov    rsi,rax
  410310:	test   r14b,r14b
  410313:	je     41033f <__swc_fn_e121059d_000089_3c530920+0x40f>
  410315:	mov    rcx,r15
  410318:	mov    rdx,rsi
  41031b:	mov    r8,rdi
  41031e:	mov    r9,r13
  410321:	mov    r14,QWORD PTR [rsp+0x28]
  410326:	mov    r10,r14
  410329:	call   408480 <__swc_fn_e121059d_000087_693f118e>
  41032e:	add    rsp,0x38
  410332:	pop    r15
  410334:	pop    r14
  410336:	pop    r13
  410338:	pop    r12
  41033a:	pop    rdi
  41033b:	pop    rsi
  41033c:	pop    rbx
  41033d:	pop    rbp
  41033e:	ret
  41033f:	mov    rcx,r15
  410342:	mov    rdx,rsi
  410345:	mov    r8,rdi
  410348:	mov    r9,r12
  41034b:	movzx  r10d,BYTE PTR [rbx]
  41034f:	call   40fe20 <__swc_fn_e121059d_000083_f2d93dad>
  410354:	add    rsp,0x38
  410358:	pop    r15
  41035a:	pop    r14
  41035c:	pop    r13
  41035e:	pop    r12
  410360:	pop    rdi
  410361:	pop    rsi
  410362:	pop    rbx
  410363:	pop    rbp
  410364:	ret
	...

0000000000410370 <__swc_fn_e121059d_000092_809deff5>:
  410370:	push   rbx
  410371:	push   rsi
  410372:	sub    rsp,0x18
  410376:	mov    rbx,rcx
  410379:	mov    rcx,QWORD PTR [rip+0x169c0]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  410380:	test   rcx,rcx
  410383:	jne    410395 <__swc_fn_e121059d_000092_809deff5+0x25>
  410385:	call   40e940 <__swc_fn_e121059d_000166_56054fe7>
  41038a:	lea    rcx,[rax+0x1]
  41038e:	mov    QWORD PTR [rip+0x169ab],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  410395:	dec    rcx
  410398:	call   40b620 <__swc_fn_e121059d_000168_39c041ad>
  41039d:	mov    rsi,rax
  4103a0:	mov    rax,QWORD PTR [rsi+0x8]
  4103a4:	test   rax,rax
  4103a7:	jne    4103f7 <__swc_fn_e121059d_000092_809deff5+0x87>
  4103a9:	call   40d570 <__swc_fn_e121059d_000091_f21926ed>
  4103ae:	test   al,al
  4103b0:	jne    4103f7 <__swc_fn_e121059d_000092_809deff5+0x87>
  4103b2:	lea    rdx,[rip+0x13e87]        # 424240 <__swc_bss_base_e121059d+0x200>
  4103b9:	mov    rcx,rdx
  4103bc:	call   407740 <__swc_fn_e121059d_000036_290a131c>
  4103c1:	test   al,al
  4103c3:	jne    4103d4 <__swc_fn_e121059d_000092_809deff5+0x64>
  4103c5:	mov    rcx,rdx
  4103c8:	call   40be60 <__swc_fn_e121059d_000034_cf5ba7bd>
  4103cd:	lea    rdx,[rip+0x13e6c]        # 424240 <__swc_bss_base_e121059d+0x200>
  4103d4:	mov    QWORD PTR [rsp+0x8],rdx
  4103d9:	lea    rax,[rip+0x2d70]        # 413150 <__swc_rdata_base_e121059d+0x40>
  4103e0:	mov    QWORD PTR [rsp+0x10],rax
  4103e5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4103eb:	vmovups XMMWORD PTR [rsi],xmm0
  4103ef:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  4103f7:	vmovups xmm0,XMMWORD PTR [rsi]
  4103fb:	vmovups XMMWORD PTR [rbx],xmm0
  4103ff:	mov    rax,rbx
  410402:	add    rsp,0x18
  410406:	pop    rsi
  410407:	pop    rbx
  410408:	ret
  410409:	add    BYTE PTR [rax],al
  41040b:	add    BYTE PTR [rax],al
  41040d:	add    BYTE PTR [rax],al
	...

0000000000410410 <__swc_fn_e121059d_000095_8cc4b392>:
  410410:	sub    rsp,0x8
  410414:	call   40dae0 <__swc_fn_e121059d_000118_5aba1420>
  410419:	add    rsp,0x8
  41041d:	ret
	...

0000000000410420 <__swc_fn_e121059d_000098_f82a1ed3>:
  410420:	push   rbx
  410421:	push   rsi
  410422:	sub    rsp,0x28
  410426:	mov    rbx,rcx
  410429:	xor    esi,esi
  41042b:	jmp    410440 <__swc_fn_e121059d_000098_f82a1ed3+0x20>
  41042d:	nop    DWORD PTR [rax]
  410430:	mov    QWORD PTR [rbx+0x28],rsi
  410434:	mov    rsi,rbx
  410437:	mov    rbx,rax
  41043a:	nop    WORD PTR [rax+rax*1+0x0]
  410440:	test   rbx,rbx
  410443:	je     4104a3 <__swc_fn_e121059d_000098_f82a1ed3+0x83>
  410445:	mov    rcx,rbx
  410448:	mov    edx,0x1
  41044d:	call   408200 <__swc_fn_e121059d_000078_140918ec>
  410452:	cmp    rax,0x1
  410456:	jne    4104a3 <__swc_fn_e121059d_000098_f82a1ed3+0x83>
  410458:	mov    r10,QWORD PTR [rbx+0x18]
  41045c:	mov    rcx,r10
  41045f:	mov    edx,0x1
  410464:	call   408200 <__swc_fn_e121059d_000078_140918ec>
  410469:	cmp    rax,0x1
  41046d:	jne    41047c <__swc_fn_e121059d_000098_f82a1ed3+0x5c>
  41046f:	mov    rcx,r10
  410472:	call   40d710 <__swc_fn_e121059d_000097_96d6739a>
  410477:	test   rax,rax
  41047a:	jne    410430 <__swc_fn_e121059d_000098_f82a1ed3+0x10>
  41047c:	mov    rax,QWORD PTR [rbx+0x20]
  410480:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  410485:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  41048b:	lea    rcx,[rsp+0x8]
  410490:	mov    rdx,rbx
  410493:	mov    r8d,0x30
  410499:	mov    rbx,rax
  41049c:	call   408960 <__swc_fn_e121059d_000096_a4baaa40>
  4104a1:	jmp    410440 <__swc_fn_e121059d_000098_f82a1ed3+0x20>
  4104a3:	test   rsi,rsi
  4104a6:	jne    4104af <__swc_fn_e121059d_000098_f82a1ed3+0x8f>
  4104a8:	add    rsp,0x28
  4104ac:	pop    rsi
  4104ad:	pop    rbx
  4104ae:	ret
  4104af:	mov    rax,rsi
  4104b2:	mov    rsi,QWORD PTR [rsi+0x28]
  4104b6:	mov    rbx,QWORD PTR [rax+0x20]
  4104ba:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  4104bf:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4104c5:	lea    rcx,[rsp+0x18]
  4104ca:	mov    rdx,rax
  4104cd:	mov    r8d,0x30
  4104d3:	call   408960 <__swc_fn_e121059d_000096_a4baaa40>
  4104d8:	jmp    410440 <__swc_fn_e121059d_000098_f82a1ed3+0x20>
  4104dd:	add    BYTE PTR [rax],al
	...

00000000004104e0 <__swc_fn_e121059d_000101_afcb7774>:
  4104e0:	push   rbx
  4104e1:	push   rsi
  4104e2:	push   rdi
  4104e3:	push   r12
  4104e5:	push   r13
  4104e7:	sub    rsp,0x20
  4104eb:	mov    rbx,rcx
  4104ee:	lea    rsi,[rcx+0x6f8]
  4104f5:	mov    edi,0x4
  4104fa:	mov    r12,rsi
  4104fd:	test   rdi,rdi
  410500:	je     41054a <__swc_fn_e121059d_000101_afcb7774+0x6a>
  410502:	cs nop WORD PTR [rax+rax*1+0x0]
  41050c:	nop    DWORD PTR [rax+0x0]
  410510:	mov    rcx,QWORD PTR [r12+0x10]
  410515:	mov    QWORD PTR [r12+0x10],0x0
  41051e:	vxorps xmm0,xmm0,xmm0
  410522:	vmovups XMMWORD PTR [r12],xmm0
  410528:	vmovups XMMWORD PTR [r12+0x28],xmm0
  41052f:	mov    DWORD PTR [r12+0x20],0x0
  410538:	call   4089b0 <__swc_fn_e121059d_000099_5232b57d>
  41053d:	add    r12,0x90
  410544:	sub    rdi,0x1
  410548:	jne    410510 <__swc_fn_e121059d_000101_afcb7774+0x30>
  41054a:	mov    rax,QWORD PTR [rbx+0x938]
  410551:	mov    rdi,rax
  410554:	test   rdi,rdi
  410557:	je     4105b1 <__swc_fn_e121059d_000101_afcb7774+0xd1>
  410559:	nop    DWORD PTR [rax+0x0]
  410560:	mov    r12d,0x10
  410566:	lea    r13,[rdi+0x18]
  41056a:	test   r12,r12
  41056d:	je     4105a6 <__swc_fn_e121059d_000101_afcb7774+0xc6>
  41056f:	nop
  410570:	mov    rcx,QWORD PTR [r13+0x10]
  410574:	mov    QWORD PTR [r13+0x10],0x0
  41057c:	vxorps xmm0,xmm0,xmm0
  410580:	vmovups XMMWORD PTR [r13+0x0],xmm0
  410586:	vmovups XMMWORD PTR [r13+0x28],xmm0
  41058c:	mov    DWORD PTR [r13+0x20],0x0
  410594:	call   4089b0 <__swc_fn_e121059d_000099_5232b57d>
  410599:	add    r13,0x90
  4105a0:	sub    r12,0x1
  4105a4:	jne    410570 <__swc_fn_e121059d_000101_afcb7774+0x90>
  4105a6:	mov    rax,QWORD PTR [rdi]
  4105a9:	mov    rdi,rax
  4105ac:	test   rax,rax
  4105af:	jne    410560 <__swc_fn_e121059d_000101_afcb7774+0x80>
  4105b1:	vxorps xmm0,xmm0,xmm0
  4105b5:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  4105bd:	mov    DWORD PTR [rbx+0x9b0],0x0
  4105c7:	mov    DWORD PTR [rbx+0x9a8],0x0
  4105d1:	mov    edi,0x4
  4105d6:	mov    r12,rsi
  4105d9:	lea    rsi,[rsi+0x38]
  4105dd:	test   rdi,rdi
  4105e0:	je     41060c <__swc_fn_e121059d_000101_afcb7774+0x12c>
  4105e2:	cs nop WORD PTR [rax+rax*1+0x0]
  4105ec:	nop    DWORD PTR [rax+0x0]
  4105f0:	mov    rcx,rsi
  4105f3:	call   4114b0 <__swc_fn_e121059d_000158_3495a3ca>
  4105f8:	add    rsi,0x90
  4105ff:	add    r12,0x90
  410606:	sub    rdi,0x1
  41060a:	jne    4105f0 <__swc_fn_e121059d_000101_afcb7774+0x110>
  41060c:	mov    rax,QWORD PTR [rbx+0x938]
  410613:	mov    rdi,rax
  410616:	mov    QWORD PTR [rbx+0x938],0x0
  410621:	test   rdi,rdi
  410624:	je     410695 <__swc_fn_e121059d_000101_afcb7774+0x1b5>
  41062a:	nop    WORD PTR [rax+rax*1+0x0]
  410630:	mov    esi,0x10
  410635:	lea    r12,[rdi+0x18]
  410639:	lea    r13,[rdi+0x50]
  41063d:	test   rsi,rsi
  410640:	je     41066c <__swc_fn_e121059d_000101_afcb7774+0x18c>
  410642:	cs nop WORD PTR [rax+rax*1+0x0]
  41064c:	nop    DWORD PTR [rax+0x0]
  410650:	mov    rcx,r13
  410653:	call   4114b0 <__swc_fn_e121059d_000158_3495a3ca>
  410658:	add    r13,0x90
  41065f:	add    r12,0x90
  410666:	sub    rsi,0x1
  41066a:	jne    410650 <__swc_fn_e121059d_000101_afcb7774+0x170>
  41066c:	mov    rax,QWORD PTR [rdi]
  41066f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  410674:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  41067a:	lea    rcx,[rsp+0x8]
  41067f:	mov    rdx,rdi
  410682:	mov    r8d,0x918
  410688:	mov    rdi,rax
  41068b:	call   408960 <__swc_fn_e121059d_000096_a4baaa40>
  410690:	test   rdi,rdi
  410693:	jne    410630 <__swc_fn_e121059d_000101_afcb7774+0x150>
  410695:	lea    rcx,[rbx+0x68]
  410699:	call   4114b0 <__swc_fn_e121059d_000158_3495a3ca>
  41069e:	add    rsp,0x20
  4106a2:	pop    r13
  4106a4:	pop    r12
  4106a6:	pop    rdi
  4106a7:	pop    rsi
  4106a8:	pop    rbx
  4106a9:	ret
  4106aa:	add    BYTE PTR [rax],al
  4106ac:	add    BYTE PTR [rax],al
	...

00000000004106b0 <__swc_fn_e121059d_000104_04d1a8be>:
  4106b0:	xor    eax,eax
  4106b2:	cs nop WORD PTR [rax+rax*1+0x0]
  4106bc:	nop    DWORD PTR [rax+0x0]
  4106c0:	mov    r9,r8
  4106c3:	sub    r9,rax
  4106c6:	cmp    r9,0x40
  4106ca:	jb     410708 <__swc_fn_e121059d_000104_04d1a8be+0x58>
  4106cc:	lea    r9,[rcx+rax*1]
  4106d0:	lea    r10,[rdx+rax*1]
  4106d4:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  4106da:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  4106e0:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  4106e6:	vmovups xmm3,XMMWORD PTR [r10]
  4106eb:	vmovups XMMWORD PTR [r9],xmm3
  4106f0:	vmovups XMMWORD PTR [r9+0x10],xmm0
  4106f6:	vmovups XMMWORD PTR [r9+0x20],xmm1
  4106fc:	vmovups XMMWORD PTR [r9+0x30],xmm2
  410702:	lea    rax,[rax+0x40]
  410706:	jmp    4106c0 <__swc_fn_e121059d_000104_04d1a8be+0x10>
  410708:	nop    DWORD PTR [rax+rax*1+0x0]
  410710:	mov    r9,r8
  410713:	sub    r9,rax
  410716:	cmp    r9,0x10
  41071a:	jb     410734 <__swc_fn_e121059d_000104_04d1a8be+0x84>
  41071c:	lea    r9,[rdx+rax*1]
  410720:	lea    r10,[rcx+rax*1]
  410724:	vmovups xmm0,XMMWORD PTR [r9]
  410729:	vmovups XMMWORD PTR [r10],xmm0
  41072e:	lea    rax,[rax+0x10]
  410732:	jmp    410710 <__swc_fn_e121059d_000104_04d1a8be+0x60>
  410734:	cs nop WORD PTR [rax+rax*1+0x0]
  41073e:	xchg   ax,ax
  410740:	mov    r9,r8
  410743:	sub    r9,rax
  410746:	cmp    r9,0x8
  41074a:	jb     41075d <__swc_fn_e121059d_000104_04d1a8be+0xad>
  41074c:	lea    r9,[rcx+rax*1]
  410750:	mov    r10,QWORD PTR [rdx+rax*1]
  410754:	mov    QWORD PTR [r9],r10
  410757:	lea    rax,[rax+0x8]
  41075b:	jmp    410740 <__swc_fn_e121059d_000104_04d1a8be+0x90>
  41075d:	cmp    rax,r8
  410760:	jae    410780 <__swc_fn_e121059d_000104_04d1a8be+0xd0>
  410762:	cs nop WORD PTR [rax+rax*1+0x0]
  41076c:	nop    DWORD PTR [rax+0x0]
  410770:	mov    r9b,BYTE PTR [rdx+rax*1]
  410774:	mov    BYTE PTR [rcx+rax*1],r9b
  410778:	inc    rax
  41077b:	cmp    rax,r8
  41077e:	jb     410770 <__swc_fn_e121059d_000104_04d1a8be+0xc0>
  410780:	ret
	...

0000000000410790 <__swc_fn_e121059d_000107_aba05410>:
  410790:	test   r8,r8
  410793:	jne    410798 <__swc_fn_e121059d_000107_aba05410+0x8>
  410795:	xor    eax,eax
  410797:	ret
  410798:	xor    eax,eax
  41079a:	nop    WORD PTR [rax+rax*1+0x0]
  4107a0:	mov    r9,r8
  4107a3:	sub    r9,rax
  4107a6:	cmp    r9,0x10
  4107aa:	jb     4107f4 <__swc_fn_e121059d_000107_aba05410+0x64>
  4107ac:	lea    r9,[rcx+rax*1]
  4107b0:	lea    r10,[rdx+rax*1]
  4107b4:	vmovups xmm0,XMMWORD PTR [r10]
  4107b9:	vmovups xmm1,XMMWORD PTR [r9]
  4107be:	vpcmpeqb xmm0,xmm1,xmm0
  4107c2:	vpmovmskb r9d,xmm0
  4107c6:	cmp    r9d,0xffff
  4107cd:	je     4107ee <__swc_fn_e121059d_000107_aba05410+0x5e>
  4107cf:	not    r9d
  4107d2:	xor    r8d,r8d
  4107d5:	movzx  r9d,r9w
  4107d9:	tzcnt  r8d,r9d
  4107de:	add    rax,r8
  4107e1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4107e5:	movzx  eax,BYTE PTR [rdx+rax*1]
  4107e9:	sub    ecx,eax
  4107eb:	mov    eax,ecx
  4107ed:	ret
  4107ee:	lea    rax,[rax+0x10]
  4107f2:	jmp    4107a0 <__swc_fn_e121059d_000107_aba05410+0x10>
  4107f4:	cmp    r9,0x8
  4107f8:	jb     41086b <__swc_fn_e121059d_000107_aba05410+0xdb>
  4107fa:	lea    r9,[rcx+rax*1]
  4107fe:	lea    r10,[rdx+rax*1]
  410802:	mov    r9,QWORD PTR [r9]
  410805:	xor    r9,QWORD PTR [r10]
  410808:	test   r9,r9
  41080b:	je     410829 <__swc_fn_e121059d_000107_aba05410+0x99>
  41080d:	xor    r8d,r8d
  410810:	tzcnt  r8,r9
  410815:	shr    r8,0x3
  410819:	add    rax,r8
  41081c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410820:	movzx  eax,BYTE PTR [rdx+rax*1]
  410824:	sub    ecx,eax
  410826:	mov    eax,ecx
  410828:	ret
  410829:	lea    rax,[rax+0x8]
  41082d:	cmp    rax,r8
  410830:	jne    410835 <__swc_fn_e121059d_000107_aba05410+0xa5>
  410832:	xor    eax,eax
  410834:	ret
  410835:	lea    rax,[r8-0x8]
  410839:	lea    r8,[rcx+rax*1]
  41083d:	lea    r9,[rdx+rax*1]
  410841:	mov    r8,QWORD PTR [r8]
  410844:	xor    r8,QWORD PTR [r9]
  410847:	test   r8,r8
  41084a:	je     410868 <__swc_fn_e121059d_000107_aba05410+0xd8>
  41084c:	xor    r9d,r9d
  41084f:	tzcnt  r9,r8
  410854:	shr    r9,0x3
  410858:	add    rax,r9
  41085b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  41085f:	movzx  eax,BYTE PTR [rdx+rax*1]
  410863:	sub    ecx,eax
  410865:	mov    eax,ecx
  410867:	ret
  410868:	xor    eax,eax
  41086a:	ret
  41086b:	cmp    r9,0x4
  41086f:	jb     4108e2 <__swc_fn_e121059d_000107_aba05410+0x152>
  410871:	lea    r9,[rcx+rax*1]
  410875:	lea    r10,[rdx+rax*1]
  410879:	mov    r9d,DWORD PTR [r9]
  41087c:	xor    r9d,DWORD PTR [r10]
  41087f:	test   r9d,r9d
  410882:	je     4108a0 <__swc_fn_e121059d_000107_aba05410+0x110>
  410884:	xor    r8d,r8d
  410887:	tzcnt  r8,r9
  41088c:	shr    r8,0x3
  410890:	add    rax,r8
  410893:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410897:	movzx  eax,BYTE PTR [rdx+rax*1]
  41089b:	sub    ecx,eax
  41089d:	mov    eax,ecx
  41089f:	ret
  4108a0:	lea    rax,[rax+0x4]
  4108a4:	cmp    rax,r8
  4108a7:	jne    4108ac <__swc_fn_e121059d_000107_aba05410+0x11c>
  4108a9:	xor    eax,eax
  4108ab:	ret
  4108ac:	lea    rax,[r8-0x4]
  4108b0:	lea    r8,[rcx+rax*1]
  4108b4:	lea    r9,[rdx+rax*1]
  4108b8:	mov    r8d,DWORD PTR [r8]
  4108bb:	xor    r8d,DWORD PTR [r9]
  4108be:	test   r8d,r8d
  4108c1:	je     4108df <__swc_fn_e121059d_000107_aba05410+0x14f>
  4108c3:	xor    r9d,r9d
  4108c6:	tzcnt  r9,r8
  4108cb:	shr    r9,0x3
  4108cf:	add    rax,r9
  4108d2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4108d6:	movzx  eax,BYTE PTR [rdx+rax*1]
  4108da:	sub    ecx,eax
  4108dc:	mov    eax,ecx
  4108de:	ret
  4108df:	xor    eax,eax
  4108e1:	ret
  4108e2:	cmp    r9,0x2
  4108e6:	jb     410939 <__swc_fn_e121059d_000107_aba05410+0x1a9>
  4108e8:	lea    r9,[rcx+rax*1]
  4108ec:	lea    r10,[rdx+rax*1]
  4108f0:	mov    r9w,WORD PTR [r9]
  4108f4:	xor    r9w,WORD PTR [r10]
  4108f8:	test   r9w,r9w
  4108fc:	je     41091e <__swc_fn_e121059d_000107_aba05410+0x18e>
  4108fe:	xor    r8d,r8d
  410901:	movzx  r9d,r9w
  410905:	tzcnt  r8,r9
  41090a:	shr    r8,0x3
  41090e:	add    rax,r8
  410911:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410915:	movzx  eax,BYTE PTR [rdx+rax*1]
  410919:	sub    ecx,eax
  41091b:	mov    eax,ecx
  41091d:	ret
  41091e:	lea    rax,[rax+0x2]
  410922:	cmp    rax,r8
  410925:	jne    41092a <__swc_fn_e121059d_000107_aba05410+0x19a>
  410927:	xor    eax,eax
  410929:	ret
  41092a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  410930:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  410936:	sub    eax,ecx
  410938:	ret
  410939:	test   r9,r9
  41093c:	je     41094b <__swc_fn_e121059d_000107_aba05410+0x1bb>
  41093e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410942:	movzx  eax,BYTE PTR [rdx+rax*1]
  410946:	sub    ecx,eax
  410948:	mov    eax,ecx
  41094a:	ret
  41094b:	xor    eax,eax
  41094d:	ret
	...

0000000000410950 <__swc_fn_e121059d_000110_9f5af8ae>:
  410950:	push   r12
  410952:	push   r13
  410954:	push   r14
  410956:	push   rdi
  410957:	push   rsi
  410958:	push   r15
  41095a:	sub    rsp,0xd8
  410961:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  410967:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  41096d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  410973:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  410979:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  41097f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  410988:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  410991:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  41099a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  4109a3:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  4109ac:	mov    r12,rcx
  4109af:	test   rcx,rcx
  4109b2:	je     4109ce <__swc_fn_e121059d_000110_9f5af8ae+0x7e>
  4109b4:	mov    eax,r12d
  4109b7:	and    eax,0xfff
  4109bd:	setne  al
  4109c0:	cmp    r12,0xffffffffffffefff
  4109c7:	seta   cl
  4109ca:	or     al,cl
  4109cc:	je     4109d5 <__swc_fn_e121059d_000110_9f5af8ae+0x85>
  4109ce:	xor    eax,eax
  4109d0:	jmp    410a6b <__swc_fn_e121059d_000110_9f5af8ae+0x11b>
  4109d5:	call   40d8a0 <__swc_fn_e121059d_000109_b8f4bd15>
  4109da:	mov    r13,rax
  4109dd:	test   rax,rax
  4109e0:	jne    4109e9 <__swc_fn_e121059d_000110_9f5af8ae+0x99>
  4109e2:	xor    eax,eax
  4109e4:	jmp    410a6b <__swc_fn_e121059d_000110_9f5af8ae+0x11b>
  4109e9:	lea    r14,[r12+0x1000]
  4109f1:	xor    edi,edi
  4109f3:	mov    rsi,r14
  4109f6:	xor    edx,edx
  4109f8:	mov    ecx,0x22
  4109fd:	mov    eax,0xffffffff
  410a02:	movsxd r8,eax
  410a05:	xor    r9d,r9d
  410a08:	xor    eax,eax
  410a0a:	call   4070d0 <mmap@plt>
  410a0f:	mov    r15,rax
  410a12:	cmp    rax,0xffffffffffffffff
  410a16:	jne    410a1c <__swc_fn_e121059d_000110_9f5af8ae+0xcc>
  410a18:	xor    eax,eax
  410a1a:	jmp    410a6b <__swc_fn_e121059d_000110_9f5af8ae+0x11b>
  410a1c:	mov    rdi,r15
  410a1f:	mov    esi,0x1000
  410a24:	mov    edx,0x3
  410a29:	xor    eax,eax
  410a2b:	call   407170 <mprotect@plt>
  410a30:	test   eax,eax
  410a32:	je     410a45 <__swc_fn_e121059d_000110_9f5af8ae+0xf5>
  410a34:	mov    rdi,r15
  410a37:	mov    rsi,r14
  410a3a:	xor    eax,eax
  410a3c:	call   407160 <munmap@plt>
  410a41:	xor    eax,eax
  410a43:	jmp    410a6b <__swc_fn_e121059d_000110_9f5af8ae+0x11b>
  410a45:	mov    QWORD PTR [r15+0x8],r12
  410a49:	mov    rcx,r13
  410a4c:	call   4110b0 <__swc_fn_e121059d_000134_807fd51d>
  410a51:	mov    rax,QWORD PTR [r13+0x8]
  410a55:	mov    QWORD PTR [r15],rax
  410a58:	mov    QWORD PTR [r13+0x8],r15
  410a5c:	mov    rcx,r13
  410a5f:	call   409d20 <__swc_fn_e121059d_000135_10472836>
  410a64:	lea    rax,[r15+0x1000]
  410a6b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  410a71:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  410a77:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  410a7d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  410a83:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  410a89:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  410a92:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  410a9b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  410aa4:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  410aad:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  410ab6:	add    rsp,0xd8
  410abd:	pop    r15
  410abf:	pop    rsi
  410ac0:	pop    rdi
  410ac1:	pop    r14
  410ac3:	pop    r13
  410ac5:	pop    r12
  410ac7:	ret
	...

0000000000410ad0 <__swc_fn_e121059d_000113_2f7f9346>:
  410ad0:	push   rbx
  410ad1:	push   r12
  410ad3:	push   rdi
  410ad4:	push   rsi
  410ad5:	sub    rsp,0xa8
  410adc:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  410ae2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410ae8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  410aee:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410af4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410afa:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  410b00:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410b06:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410b0c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410b15:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  410b1e:	mov    rbx,rdx
  410b21:	mov    r12,rcx
  410b24:	mov    rdi,rcx
  410b27:	mov    rsi,rdx
  410b2a:	xor    edx,edx
  410b2c:	xor    eax,eax
  410b2e:	call   407170 <mprotect@plt>
  410b33:	test   eax,eax
  410b35:	jne    410b59 <__swc_fn_e121059d_000113_2f7f9346+0x89>
  410b37:	mov    rcx,r12
  410b3a:	mov    rdx,rbx
  410b3d:	xor    al,al
  410b3f:	mov    r8,rax
  410b42:	call   4097c0 <__swc_fn_e121059d_000111_918d5a21>
  410b47:	mov    rdi,r12
  410b4a:	mov    rsi,rbx
  410b4d:	mov    edx,0x4
  410b52:	xor    eax,eax
  410b54:	call   4071d0 <madvise@plt>
  410b59:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410b5f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410b65:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410b6b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410b71:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410b77:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410b7d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410b83:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410b89:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410b92:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410b9b:	add    rsp,0xa8
  410ba2:	pop    rsi
  410ba3:	pop    rdi
  410ba4:	pop    r12
  410ba6:	pop    rbx
  410ba7:	ret
	...

0000000000410bb0 <__swc_fn_e121059d_000116_3f6af4b1>:
  410bb0:	push   rsi
  410bb1:	push   rdi
  410bb2:	push   r12
  410bb4:	push   r13
  410bb6:	push   r14
  410bb8:	sub    rsp,0xe0
  410bbf:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  410bc5:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  410bcb:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  410bd1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  410bd7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  410bdd:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  410be6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  410bef:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  410bf8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  410c01:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  410c0a:	mov    rsi,rdx
  410c0d:	mov    rdi,rcx
  410c10:	call   40d8a0 <__swc_fn_e121059d_000109_b8f4bd15>
  410c15:	mov    r12,rax
  410c18:	test   rax,rax
  410c1b:	jne    410c22 <__swc_fn_e121059d_000116_3f6af4b1+0x72>
  410c1d:	jmp    410c96 <__swc_fn_e121059d_000116_3f6af4b1+0xe6>
  410c22:	mov    rcx,r12
  410c25:	call   4110b0 <__swc_fn_e121059d_000134_807fd51d>
  410c2a:	lea    r13,[r12+0x8]
  410c2f:	mov    rax,QWORD PTR [r13+0x0]
  410c33:	test   rax,rax
  410c36:	je     410c8e <__swc_fn_e121059d_000116_3f6af4b1+0xde>
  410c38:	nop    DWORD PTR [rax+rax*1+0x0]
  410c40:	lea    rcx,[rax+0x1000]
  410c47:	cmp    rcx,rdi
  410c4a:	jne    410c82 <__swc_fn_e121059d_000116_3f6af4b1+0xd2>
  410c4c:	cmp    QWORD PTR [rax+0x8],rsi
  410c50:	je     410c5c <__swc_fn_e121059d_000116_3f6af4b1+0xac>
  410c52:	mov    rcx,r12
  410c55:	call   409d20 <__swc_fn_e121059d_000135_10472836>
  410c5a:	jmp    410c96 <__swc_fn_e121059d_000116_3f6af4b1+0xe6>
  410c5c:	mov    r14,QWORD PTR [rax]
  410c5f:	mov    rdi,rax
  410c62:	lea    rsi,[rsi+0x1000]
  410c69:	xor    eax,eax
  410c6b:	call   407160 <munmap@plt>
  410c70:	test   eax,eax
  410c72:	jne    410c78 <__swc_fn_e121059d_000116_3f6af4b1+0xc8>
  410c74:	mov    QWORD PTR [r13+0x0],r14
  410c78:	mov    rcx,r12
  410c7b:	call   409d20 <__swc_fn_e121059d_000135_10472836>
  410c80:	jmp    410c96 <__swc_fn_e121059d_000116_3f6af4b1+0xe6>
  410c82:	mov    r13,rax
  410c85:	mov    rax,QWORD PTR [r13+0x0]
  410c89:	test   rax,rax
  410c8c:	jne    410c40 <__swc_fn_e121059d_000116_3f6af4b1+0x90>
  410c8e:	mov    rcx,r12
  410c91:	call   409d20 <__swc_fn_e121059d_000135_10472836>
  410c96:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  410c9c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  410ca2:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  410ca8:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  410cae:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  410cb4:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  410cbd:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  410cc6:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  410ccf:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  410cd8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  410ce1:	add    rsp,0xe0
  410ce8:	pop    r14
  410cea:	pop    r13
  410cec:	pop    r12
  410cee:	pop    rdi
  410cef:	pop    rsi
  410cf0:	ret
	...

0000000000410d00 <__swc_fn_e121059d_000119_591530fe>:
  410d00:	push   rdi
  410d01:	push   rsi
  410d02:	sub    rsp,0xa8
  410d09:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  410d0f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410d15:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  410d1b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410d21:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410d27:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  410d2d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410d33:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410d39:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410d42:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  410d4b:	mov    rdi,0xfffffffffffffd66
  410d52:	xor    eax,eax
  410d54:	call   407180 <exit@plt>
  410d59:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410d5f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410d65:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410d6b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410d71:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410d77:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410d7d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410d83:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410d89:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410d92:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410d9b:	add    rsp,0xa8
  410da2:	pop    rsi
  410da3:	pop    rdi
  410da4:	ret
	...

0000000000410dc0 <__swc_fn_e121059d_000122_1c5e75b6>:
  410dc0:	push   rbx
  410dc1:	push   rsi
  410dc2:	push   rdi
  410dc3:	sub    rsp,0x30
  410dc7:	mov    rbx,rdx
  410dca:	mov    esi,ecx
  410dcc:	test   ecx,ecx
  410dce:	je     410ea3 <__swc_fn_e121059d_000122_1c5e75b6+0xe3>
  410dd4:	mov    rcx,rsi
  410dd7:	shl    rcx,0x4
  410ddb:	call   40d3b0 <__swc_fn_e121059d_000079_633af784>
  410de0:	test   rax,rax
  410de3:	je     410e92 <__swc_fn_e121059d_000122_1c5e75b6+0xd2>
  410de9:	mov    rcx,rsi
  410dec:	xor    edx,edx
  410dee:	test   rsi,rsi
  410df1:	jbe    410e72 <__swc_fn_e121059d_000122_1c5e75b6+0xb2>
  410df7:	nop    WORD PTR [rax+rax*1+0x0]
  410e00:	mov    r8d,edx
  410e03:	mov    r9,QWORD PTR [rbx+r8*8]
  410e07:	add    r8,r8
  410e0a:	lea    r8,[rax+r8*8]
  410e0e:	xor    r10d,r10d
  410e11:	test   r9,r9
  410e14:	je     410e50 <__swc_fn_e121059d_000122_1c5e75b6+0x90>
  410e16:	mov    r11,r9
  410e19:	mov    dil,BYTE PTR [r11]
  410e1c:	test   dil,dil
  410e1f:	je     410e50 <__swc_fn_e121059d_000122_1c5e75b6+0x90>
  410e21:	cs nop WORD PTR [rax+rax*1+0x0]
  410e2b:	cs nop WORD PTR [rax+rax*1+0x0]
  410e35:	cs nop WORD PTR [rax+rax*1+0x0]
  410e3f:	nop
  410e40:	add    r11,0x1
  410e44:	add    r10,0x1
  410e48:	mov    dil,BYTE PTR [r11]
  410e4b:	test   dil,dil
  410e4e:	jne    410e40 <__swc_fn_e121059d_000122_1c5e75b6+0x80>
  410e50:	mov    QWORD PTR [rsp+0x18],r9
  410e55:	mov    QWORD PTR [rsp+0x20],r10
  410e5a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  410e60:	vmovups XMMWORD PTR [r8],xmm0
  410e65:	add    rdx,0x1
  410e69:	cmp    rdx,rcx
  410e6c:	jb     410e00 <__swc_fn_e121059d_000122_1c5e75b6+0x40>
  410e72:	lea    rcx,[rip+0x15ed7]        # 426d50 <__swc_bss_base_e121059d+0x2d10>
  410e79:	mov    QWORD PTR [rsp+0x8],rax
  410e7e:	mov    esi,esi
  410e80:	mov    QWORD PTR [rsp+0x10],rsi
  410e85:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  410e8b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  410e90:	jmp    410ea3 <__swc_fn_e121059d_000122_1c5e75b6+0xe3>
  410e92:	lea    rcx,[rip+0x2687]        # 413520 <__swc_rdata_base_e121059d+0x410>
  410e99:	call   409870 <__swc_fn_e121059d_000117_3f5cfdef>
  410e9e:	call   410d00 <__swc_fn_e121059d_000119_591530fe>
  410ea3:	add    rsp,0x30
  410ea7:	pop    rdi
  410ea8:	pop    rsi
  410ea9:	pop    rbx
  410eaa:	ret
  410eab:	add    BYTE PTR [rax],al
  410ead:	add    BYTE PTR [rax],al
	...

0000000000410eb0 <__swc_fn_e121059d_000125_37eaf452>:
  410eb0:	push   rdi
  410eb1:	push   rsi
  410eb2:	sub    rsp,0xa8
  410eb9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  410ebf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410ec5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  410ecb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410ed1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410ed7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  410edd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410ee3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410ee9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410ef2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  410efb:	mov    edi,ecx
  410efd:	xor    eax,eax
  410eff:	call   4071e0 <pthread_key_delete@plt>
  410f04:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410f0a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410f10:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410f16:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410f1c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410f22:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410f28:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410f2e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410f34:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410f3d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410f46:	add    rsp,0xa8
  410f4d:	pop    rsi
  410f4e:	pop    rdi
  410f4f:	ret

0000000000410f50 <__swc_fn_e121059d_000128_f163135d>:
  410f50:	push   rdi
  410f51:	push   rsi
  410f52:	sub    rsp,0xa8
  410f59:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  410f5f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410f65:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  410f6b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410f71:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410f77:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  410f7d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410f83:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410f89:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410f92:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  410f9b:	test   rcx,rcx
  410f9e:	je     410faf <__swc_fn_e121059d_000128_f163135d+0x5f>
  410fa0:	lea    rax,[rcx-0x1]
  410fa4:	mov    eax,eax
  410fa6:	mov    edi,eax
  410fa8:	xor    eax,eax
  410faa:	call   4071e0 <pthread_key_delete@plt>
  410faf:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410fb5:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410fbb:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410fc1:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410fc7:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410fcd:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410fd3:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410fd9:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410fdf:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410fe8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410ff1:	add    rsp,0xa8
  410ff8:	pop    rsi
  410ff9:	pop    rdi
  410ffa:	ret
  410ffb:	add    BYTE PTR [rax],al
  410ffd:	add    BYTE PTR [rax],al
	...

0000000000411000 <__swc_fn_e121059d_000131_375c7357>:
  411000:	push   rsi
  411001:	push   rdi
  411002:	sub    rsp,0xa8
  411009:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41100f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411015:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41101b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411021:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411027:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41102d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411033:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411039:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411042:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41104b:	xor    eax,eax
  41104d:	call   4071f0 <gettid@plt>
  411052:	movsxd rax,eax
  411055:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41105b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411061:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411067:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41106d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411073:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411079:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41107f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411085:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41108e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411097:	add    rsp,0xa8
  41109e:	pop    rdi
  41109f:	pop    rsi
  4110a0:	ret
	...

00000000004110b0 <__swc_fn_e121059d_000134_807fd51d>:
  4110b0:	push   rbx
  4110b1:	push   rdi
  4110b2:	push   rsi
  4110b3:	sub    rsp,0xc0
  4110ba:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4110c0:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4110c6:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4110cc:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4110d2:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4110d8:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4110de:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4110e4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4110ed:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4110f6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4110ff:	mov    rbx,rcx
  411102:	cs nop WORD PTR [rax+rax*1+0x0]
  41110c:	nop    DWORD PTR [rax+0x0]
  411110:	mov    edx,0x80000000
  411115:	xor    eax,eax
  411117:	lock cmpxchg DWORD PTR [rbx],edx
  41111b:	test   eax,eax
  41111d:	je     411154 <__swc_fn_e121059d_000134_807fd51d+0xa4>
  41111f:	mov    eax,DWORD PTR [rbx]
  411121:	lea    rcx,[rsp+0x14]
  411126:	mov    DWORD PTR [rsp+0x14],eax
  41112a:	test   eax,eax
  41112c:	je     411110 <__swc_fn_e121059d_000134_807fd51d+0x60>
  41112e:	mov    QWORD PTR [rsp],0x0
  411136:	mov    edi,0xca
  41113b:	mov    rsi,rbx
  41113e:	mov    edx,0x80
  411143:	mov    ecx,DWORD PTR [rcx]
  411145:	xor    r8d,r8d
  411148:	xor    r9d,r9d
  41114b:	xor    eax,eax
  41114d:	call   4071a0 <syscall@plt>
  411152:	jmp    411110 <__swc_fn_e121059d_000134_807fd51d+0x60>
  411154:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  41115a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411160:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411166:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41116c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411172:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411178:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41117e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  411187:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  411190:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  411199:	add    rsp,0xc0
  4111a0:	pop    rsi
  4111a1:	pop    rdi
  4111a2:	pop    rbx
  4111a3:	ret
	...

00000000004111b0 <__swc_fn_e121059d_000137_d579ef75>:
  4111b0:	sub    rsp,0x8
  4111b4:	call   409d20 <__swc_fn_e121059d_000135_10472836>
  4111b9:	add    rsp,0x8
  4111bd:	ret
	...

00000000004111c0 <__swc_fn_e121059d_000140_e4a7a8b1>:
  4111c0:	push   rdi
  4111c1:	push   rsi
  4111c2:	sub    rsp,0xa8
  4111c9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4111cf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4111d5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4111db:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4111e1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4111e7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4111ed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4111f3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4111f9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411202:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41120b:	mov    edi,0x28
  411210:	xor    eax,eax
  411212:	call   4071c0 <malloc@plt>
  411217:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41121d:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411223:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411229:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41122f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411235:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  41123b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411241:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411247:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411250:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411259:	add    rsp,0xa8
  411260:	pop    rsi
  411261:	pop    rdi
  411262:	ret
	...

0000000000411270 <__swc_fn_e121059d_000143_89a6ef72>:
  411270:	mov    QWORD PTR [r8],0x0
  411277:	cmp    rdx,0x10
  41127b:	jae    411280 <__swc_fn_e121059d_000143_89a6ef72+0x10>
  41127d:	xor    eax,eax
  41127f:	ret
  411280:	mov    eax,DWORD PTR [rcx]
  411282:	cmp    eax,0x42445753
  411288:	jne    411292 <__swc_fn_e121059d_000143_89a6ef72+0x22>
  41128a:	mov    eax,DWORD PTR [rcx+0x4]
  41128d:	cmp    eax,0x1
  411290:	je     411295 <__swc_fn_e121059d_000143_89a6ef72+0x25>
  411292:	xor    eax,eax
  411294:	ret
  411295:	mov    QWORD PTR [r8],rdx
  411298:	mov    rax,rcx
  41129b:	ret
  41129c:	add    BYTE PTR [rax],al
	...

00000000004112a0 <__swc_fn_e121059d_000146_32a1d6a2>:
  4112a0:	push   rbx
  4112a1:	sub    rsp,0xe0
  4112a8:	lea    rbx,[rsp+0x8]
  4112ad:	vxorps xmm0,xmm0,xmm0
  4112b1:	vmovups YMMWORD PTR [rbx],ymm0
  4112b5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  4112ba:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  4112bf:	vzeroupper
  4112c2:	mov    DWORD PTR [rbx+0x60],0x0
  4112c9:	mov    r8,rbx
  4112cc:	mov    rdx,rcx
  4112cf:	nop
  4112d0:	mov    r9,rdx
  4112d3:	movabs rdx,0x6666666666666667
  4112dd:	mov    rax,r9
  4112e0:	imul   rdx
  4112e3:	sar    rdx,0x2
  4112e7:	mov    r10,rdx
  4112ea:	shr    rdx,0x3f
  4112ee:	add    r10,rdx
  4112f1:	mov    rdx,r10
  4112f4:	imul   r11,r10,0xa
  4112f8:	sub    r9,r11
  4112fb:	mov    r11,QWORD PTR [rip+0x223e]        # 413540 <__swc_rdata_base_e121059d+0x430>
  411302:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  411307:	mov    BYTE PTR [r8],r9b
  41130a:	lea    r9,[r8+0x1]
  41130e:	mov    r8,r9
  411311:	test   r10,r10
  411314:	jne    4112d0 <__swc_fn_e121059d_000146_32a1d6a2+0x30>
  411316:	test   rcx,rcx
  411319:	jge    411323 <__swc_fn_e121059d_000146_32a1d6a2+0x83>
  41131b:	mov    BYTE PTR [r9],0x2d
  41131f:	add    r8,0x1
  411323:	mov    BYTE PTR [r8],0x0
  411327:	sub    r8,0x1
  41132b:	mov    rax,rbx
  41132e:	cmp    rax,r8
  411331:	jae    411356 <__swc_fn_e121059d_000146_32a1d6a2+0xb6>
  411333:	cs nop WORD PTR [rax+rax*1+0x0]
  41133d:	nop    DWORD PTR [rax]
  411340:	mov    cl,BYTE PTR [r8]
  411343:	mov    dl,BYTE PTR [rax]
  411345:	mov    BYTE PTR [r8],dl
  411348:	sub    r8,0x1
  41134c:	mov    BYTE PTR [rax],cl
  41134e:	inc    rax
  411351:	cmp    rax,r8
  411354:	jb     411340 <__swc_fn_e121059d_000146_32a1d6a2+0xa0>
  411356:	xor    eax,eax
  411358:	test   rbx,rbx
  41135b:	je     41137e <__swc_fn_e121059d_000146_32a1d6a2+0xde>
  41135d:	mov    rcx,rbx
  411360:	mov    dl,BYTE PTR [rcx]
  411362:	test   dl,dl
  411364:	je     41137e <__swc_fn_e121059d_000146_32a1d6a2+0xde>
  411366:	cs nop WORD PTR [rax+rax*1+0x0]
  411370:	add    rcx,0x1
  411374:	add    rax,0x1
  411378:	mov    dl,BYTE PTR [rcx]
  41137a:	test   dl,dl
  41137c:	jne    411370 <__swc_fn_e121059d_000146_32a1d6a2+0xd0>
  41137e:	mov    QWORD PTR [rbx+0xa8],rbx
  411385:	mov    QWORD PTR [rbx+0xb0],rax
  41138c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  411394:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  41139c:	lea    rcx,[rbx+0xb8]
  4113a3:	call   409870 <__swc_fn_e121059d_000117_3f5cfdef>
  4113a8:	add    rsp,0xe0
  4113af:	pop    rbx
  4113b0:	ret
	...

00000000004113c0 <__swc_fn_e121059d_000149_365b4daf>:
  4113c0:	vxorps xmm0,xmm0,xmm0
  4113c4:	vmovups XMMWORD PTR [rcx],xmm0
  4113c8:	mov    QWORD PTR [rcx+0x10],0x0
  4113d0:	ret
	...

00000000004113e0 <__swc_fn_e121059d_000152_365b4daf>:
  4113e0:	vxorps xmm0,xmm0,xmm0
  4113e4:	vmovups XMMWORD PTR [rcx],xmm0
  4113e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4113ed:	vxorps xmm0,xmm0,xmm0
  4113f1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4113f6:	vmovups xmm0,XMMWORD PTR [rip+0x223a]        # 413638 <__swc_rdata_base_e121059d+0x528>
  4113fe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411403:	vxorps xmm0,xmm0,xmm0
  411407:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  41140c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411411:	mov    QWORD PTR [rcx+0x60],0x0
  411419:	ret
  41141a:	add    BYTE PTR [rax],al
  41141c:	add    BYTE PTR [rax],al
	...

0000000000411420 <__swc_fn_e121059d_000155_365b4daf>:
  411420:	vxorps xmm0,xmm0,xmm0
  411424:	vmovups XMMWORD PTR [rcx],xmm0
  411428:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41142d:	vxorps xmm0,xmm0,xmm0
  411431:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411436:	vmovups xmm0,XMMWORD PTR [rip+0x2322]        # 413760 <__swc_rdata_base_e121059d+0x650>
  41143e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411443:	vxorps xmm0,xmm0,xmm0
  411447:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  41144c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411451:	vxorps xmm0,xmm0,xmm0
  411455:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  41145a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  41145f:	vxorps xmm0,xmm0,xmm0
  411463:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  41146b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  411473:	vxorps xmm0,xmm0,xmm0
  411477:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  41147f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  411487:	vxorps xmm0,xmm0,xmm0
  41148b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  411493:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  41149b:	mov    QWORD PTR [rcx+0xe0],0x0
  4114a6:	ret
	...

00000000004114b0 <__swc_fn_e121059d_000158_3495a3ca>:
  4114b0:	push   rbx
  4114b1:	mov    rbx,rcx
  4114b4:	call   40b2b0 <__swc_fn_e121059d_000159_31e09513>
  4114b9:	mov    rax,QWORD PTR [rbx+0x10]
  4114bd:	test   rax,rax
  4114c0:	je     4114d1 <__swc_fn_e121059d_000158_3495a3ca+0x21>
  4114c2:	mov    rcx,rbx
  4114c5:	mov    rdx,rax
  4114c8:	mov    r8,QWORD PTR [rbx+0x18]
  4114cc:	call   40e630 <__swc_fn_e121059d_000157_9e2052d6>
  4114d1:	vxorps xmm0,xmm0,xmm0
  4114d5:	vmovups XMMWORD PTR [rbx],xmm0
  4114d9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  4114de:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  4114e3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  4114e8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  4114ed:	mov    QWORD PTR [rbx+0x50],0x0
  4114f5:	pop    rbx
  4114f6:	ret
	...

0000000000411500 <__swc_fn_e121059d_000161_dfca9093>:
  411500:	sub    rsp,0x10
  411504:	mov    eax,r8d
  411507:	mov    r8d,r9d
  41150a:	test   r9d,r9d
  41150d:	jne    411526 <__swc_fn_e121059d_000161_dfca9093+0x26>
  41150f:	vmovups xmm0,XMMWORD PTR [rip+0x2301]        # 413818 <__swc_rdata_base_e121059d+0x708>
  411517:	vmovups XMMWORD PTR [r10],xmm0
  41151c:	mov    eax,0x1
  411521:	add    rsp,0x10
  411525:	ret
  411526:	mov    r9,r8
  411529:	cmp    r8,rax
  41152c:	jb     411533 <__swc_fn_e121059d_000161_dfca9093+0x33>
  41152e:	cmp    r9,rdx
  411531:	jb     41153a <__swc_fn_e121059d_000161_dfca9093+0x3a>
  411533:	xor    eax,eax
  411535:	add    rsp,0x10
  411539:	ret
  41153a:	xor    eax,eax
  41153c:	lea    r8,[r9+rax*1]
  411540:	cmp    r8,rdx
  411543:	jae    411573 <__swc_fn_e121059d_000161_dfca9093+0x73>
  411545:	cs nop WORD PTR [rax+rax*1+0x0]
  41154f:	cs nop WORD PTR [rax+rax*1+0x0]
  411559:	nop    DWORD PTR [rax+0x0]
  411560:	cmp    BYTE PTR [rcx+r8*1],0x0
  411565:	je     411573 <__swc_fn_e121059d_000161_dfca9093+0x73>
  411567:	inc    rax
  41156a:	lea    r8,[r9+rax*1]
  41156e:	cmp    r8,rdx
  411571:	jb     411560 <__swc_fn_e121059d_000161_dfca9093+0x60>
  411573:	cmp    r8,rdx
  411576:	jne    41157f <__swc_fn_e121059d_000161_dfca9093+0x7f>
  411578:	xor    eax,eax
  41157a:	add    rsp,0x10
  41157e:	ret
  41157f:	add    rcx,r9
  411582:	mov    QWORD PTR [rsp],rcx
  411586:	mov    QWORD PTR [rsp+0x8],rax
  41158b:	vmovups xmm0,XMMWORD PTR [rsp]
  411590:	vmovups XMMWORD PTR [r10],xmm0
  411595:	mov    eax,0x1
  41159a:	add    rsp,0x10
  41159e:	ret
	...

00000000004115a0 <__swc_fn_e121059d_000164_3a7aae74>:
  4115a0:	push   rbp
  4115a1:	push   rbx
  4115a2:	push   rsi
  4115a3:	push   rdi
  4115a4:	push   r12
  4115a6:	push   r13
  4115a8:	push   r14
  4115aa:	push   r15
  4115ac:	sub    rsp,0x10
  4115b0:	mov    rbp,rsp
  4115b3:	vmovups XMMWORD PTR [rsp],xmm6
  4115b8:	sub    rsp,0x50
  4115bc:	mov    rbx,rsp
  4115bf:	mov    rsi,r8
  4115c2:	mov    QWORD PTR [rsp+0x30],r8
  4115c7:	mov    rdi,rcx
  4115ca:	mov    QWORD PTR [rsp+0x38],rcx
  4115cf:	mov    r12,rdx
  4115d2:	xor    r13b,r13b
  4115d5:	mov    r14,QWORD PTR [rdi+0x8]
  4115d9:	mov    QWORD PTR [rsp+0x40],r14
  4115de:	xor    r15d,r15d
  4115e1:	test   r14,r14
  4115e4:	jbe    41183e <__swc_fn_e121059d_000164_3a7aae74+0x29e>
  4115ea:	mov    r14,QWORD PTR [rdi]
  4115ed:	mov    rax,QWORD PTR [rsp+0x40]
  4115f2:	mov    QWORD PTR [rsp+0x48],r14
  4115f7:	vmovups xmm6,XMMWORD PTR [rip+0x1e39]        # 413438 <__swc_rdata_base_e121059d+0x328>
  4115ff:	nop
  411600:	cmp    QWORD PTR [r14+r15*8],0x0
  411605:	jne    41160f <__swc_fn_e121059d_000164_3a7aae74+0x6f>
  411607:	mov    r14,rax
  41160a:	jmp    41181e <__swc_fn_e121059d_000164_3a7aae74+0x27e>
  41160f:	mov    rcx,QWORD PTR [rdi]
  411612:	mov    rdx,QWORD PTR [rcx+r15*8]
  411616:	mov    rdi,rbx
  411619:	mov    rcx,rdi
  41161c:	sub    rsp,0x8
  411620:	mov    r14,rax
  411623:	call   40e6b0 <__swc_fn_e121059d_000163_61e293bf>
  411628:	add    rsp,0x8
  41162c:	mov    al,BYTE PTR [rbx]
  41162e:	test   al,al
  411630:	je     41181e <__swc_fn_e121059d_000164_3a7aae74+0x27e>
  411636:	mov    al,BYTE PTR [rbx+0x1]
  411639:	test   al,al
  41163b:	jne    411646 <__swc_fn_e121059d_000164_3a7aae74+0xa6>
  41163d:	test   sil,sil
  411640:	je     41181e <__swc_fn_e121059d_000164_3a7aae74+0x27e>
  411646:	test   r13b,r13b
  411649:	jne    411707 <__swc_fn_e121059d_000164_3a7aae74+0x167>
  41164f:	test   r12,r12
  411652:	je     411707 <__swc_fn_e121059d_000164_3a7aae74+0x167>
  411658:	mov    al,BYTE PTR [rbx+0x1]
  41165b:	test   al,al
  41165d:	je     41181e <__swc_fn_e121059d_000164_3a7aae74+0x27e>
  411663:	mov    eax,DWORD PTR [rbx+0x28]
  411666:	cmp    DWORD PTR [r12+0x20],eax
  41166b:	jne    41181e <__swc_fn_e121059d_000164_3a7aae74+0x27e>
  411671:	mov    rax,QWORD PTR [r12]
  411675:	mov    rcx,QWORD PTR [r12+0x8]
  41167a:	cmp    QWORD PTR [rbx+0x20],rcx
  41167e:	jne    41181e <__swc_fn_e121059d_000164_3a7aae74+0x27e>
  411684:	mov    cl,0x1
  411686:	test   rax,rax
  411689:	je     4116f2 <__swc_fn_e121059d_000164_3a7aae74+0x152>
  41168f:	mov    rdx,QWORD PTR [rbx+0x20]
  411693:	xor    r8d,r8d
  411696:	test   rdx,rdx
  411699:	jbe    4116f2 <__swc_fn_e121059d_000164_3a7aae74+0x152>
  41169b:	mov    r9,QWORD PTR [rbx+0x18]
  41169f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  4116a4:	cs nop WORD PTR [rax+rax*1+0x0]
  4116ae:	xchg   ax,ax
  4116b0:	mov    r10b,BYTE PTR [rax+r8*1]
  4116b4:	cmp    BYTE PTR [r9+r8*1],r10b
  4116b8:	je     4116e9 <__swc_fn_e121059d_000164_3a7aae74+0x149>
  4116ba:	vmovq  r10,xmm0
  4116bf:	cmp    BYTE PTR [r10+r8*1],0x5c
  4116c4:	jne    4116cd <__swc_fn_e121059d_000164_3a7aae74+0x12d>
  4116c6:	cmp    BYTE PTR [rax+r8*1],0x2f
  4116cb:	je     4116e9 <__swc_fn_e121059d_000164_3a7aae74+0x149>
  4116cd:	vmovq  r10,xmm0
  4116d2:	cmp    BYTE PTR [r10+r8*1],0x2f
  4116d7:	jne    4116e0 <__swc_fn_e121059d_000164_3a7aae74+0x140>
  4116d9:	cmp    BYTE PTR [rax+r8*1],0x5c
  4116de:	je     4116e9 <__swc_fn_e121059d_000164_3a7aae74+0x149>
  4116e0:	xor    eax,eax
  4116e2:	movzx  eax,al
  4116e5:	mov    cl,al
  4116e7:	jmp    4116f2 <__swc_fn_e121059d_000164_3a7aae74+0x152>
  4116e9:	add    r8,0x1
  4116ed:	cmp    r8,rdx
  4116f0:	jb     4116b0 <__swc_fn_e121059d_000164_3a7aae74+0x110>
  4116f2:	test   cl,cl
  4116f4:	je     41181e <__swc_fn_e121059d_000164_3a7aae74+0x27e>
  4116fa:	mov    eax,0x1
  4116ff:	mov    r13b,al
  411702:	jmp    41181e <__swc_fn_e121059d_000164_3a7aae74+0x27e>
  411707:	mov    r13b,0x1
  41170a:	sub    rsp,0x20
  41170e:	mov    rax,rsp
  411711:	lea    rcx,[rdi+0x8]
  411715:	mov    QWORD PTR [rax],rcx
  411718:	lea    rsi,[rip+0x1bf1]        # 413310 <__swc_rdata_base_e121059d+0x200>
  41171f:	mov    QWORD PTR [rax+0x8],rsi
  411723:	mov    QWORD PTR [rax+0x10],rsp
  411727:	mov    QWORD PTR [rax+0x18],0x1
  41172f:	lea    rcx,[rsp+0x10]
  411734:	sub    rsp,0x8
  411738:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  41173d:	add    rsp,0x8
  411741:	add    rsp,0x20
  411745:	mov    al,BYTE PTR [rbx+0x1]
  411748:	test   al,al
  41174a:	je     4117e7 <__swc_fn_e121059d_000164_3a7aae74+0x247>
  411750:	lea    rax,[rip+0x2161]        # 4138b8 <__swc_rdata_base_e121059d+0x7a8>
  411757:	sub    rsp,0x20
  41175b:	mov    rcx,rsp
  41175e:	mov    QWORD PTR [rcx],rax
  411761:	mov    QWORD PTR [rcx+0x8],rsi
  411765:	mov    QWORD PTR [rcx+0x10],rsp
  411769:	mov    QWORD PTR [rcx+0x18],0x1
  411771:	lea    rcx,[rsp+0x10]
  411776:	sub    rsp,0x8
  41177a:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  41177f:	add    rsp,0x8
  411783:	add    rsp,0x20
  411787:	mov    eax,DWORD PTR [rbx+0x28]
  41178a:	sub    rsp,0x60
  41178e:	mov    rcx,rsp
  411791:	lea    rdx,[rdi+0x18]
  411795:	mov    QWORD PTR [rcx+0x18],rdx
  411799:	mov    QWORD PTR [rcx+0x20],rsi
  41179d:	vmovups XMMWORD PTR [rcx],xmm6
  4117a1:	mov    QWORD PTR [rcx+0x28],rsp
  4117a5:	mov    QWORD PTR [rcx+0x30],rsi
  4117a9:	mov    DWORD PTR [rcx+0x10],eax
  4117ac:	lea    rax,[rsp+0x10]
  4117b1:	mov    QWORD PTR [rcx+0x38],rax
  4117b5:	lea    rax,[rip+0x1c14]        # 4133d0 <__swc_rdata_base_e121059d+0x2c0>
  4117bc:	mov    QWORD PTR [rcx+0x40],rax
  4117c0:	lea    rax,[rsp+0x18]
  4117c5:	mov    QWORD PTR [rcx+0x48],rax
  4117c9:	mov    QWORD PTR [rcx+0x50],0x3
  4117d1:	lea    rcx,[rsp+0x48]
  4117d6:	sub    rsp,0x8
  4117da:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  4117df:	add    rsp,0x8
  4117e3:	add    rsp,0x60
  4117e7:	lea    rax,[rip+0x1b7a]        # 413368 <__swc_rdata_base_e121059d+0x258>
  4117ee:	sub    rsp,0x20
  4117f2:	mov    rcx,rsp
  4117f5:	mov    QWORD PTR [rcx],rax
  4117f8:	mov    QWORD PTR [rcx+0x8],rsi
  4117fc:	mov    QWORD PTR [rcx+0x10],rsp
  411800:	mov    QWORD PTR [rcx+0x18],0x1
  411808:	lea    rcx,[rsp+0x10]
  41180d:	sub    rsp,0x8
  411811:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  411816:	add    rsp,0x8
  41181a:	add    rsp,0x20
  41181e:	add    r15,0x1
  411822:	cmp    r15,r14
  411825:	jae    41183e <__swc_fn_e121059d_000164_3a7aae74+0x29e>
  411827:	mov    rsi,QWORD PTR [rsp+0x30]
  41182c:	mov    rdi,QWORD PTR [rsp+0x38]
  411831:	mov    rax,r14
  411834:	mov    r14,QWORD PTR [rsp+0x48]
  411839:	jmp    411600 <__swc_fn_e121059d_000164_3a7aae74+0x60>
  41183e:	add    rsp,0x50
  411842:	vmovups xmm6,XMMWORD PTR [rsp]
  411847:	add    rsp,0x10
  41184b:	pop    r15
  41184d:	pop    r14
  41184f:	pop    r13
  411851:	pop    r12
  411853:	pop    rdi
  411854:	pop    rsi
  411855:	pop    rbx
  411856:	pop    rbp
  411857:	ret
	...

0000000000411860 <__swc_fn_e121059d_000167_c370e18e>:
  411860:	sub    rsp,0x8
  411864:	call   409af0 <__swc_fn_e121059d_000126_7a81492f>
  411869:	add    rsp,0x8
  41186d:	ret
	...

0000000000411870 <__swc_fn_e121059d_000170_4694b8ad>:
  411870:	push   rsi
  411871:	sub    rsp,0x30
  411875:	lea    rsi,[rip+0x15524]        # 426da0 <__swc_bss_base_e121059d+0x2d60>
  41187c:	mov    rax,QWORD PTR [rsi]
  41187f:	test   rax,rax
  411882:	je     41188a <__swc_fn_e121059d_000170_4694b8ad+0x1a>
  411884:	add    rsp,0x30
  411888:	pop    rsi
  411889:	ret
  41188a:	mov    ecx,0x2
  41188f:	mov    edx,0x8020
  411894:	call   409190 <__swc_fn_e121059d_000108_c8d4a68e>
  411899:	test   rax,rax
  41189c:	jne    4118ad <__swc_fn_e121059d_000170_4694b8ad+0x3d>
  41189e:	mov    QWORD PTR [rsp+0x18],rax
  4118a3:	call   410d00 <__swc_fn_e121059d_000119_591530fe>
  4118a8:	mov    rax,QWORD PTR [rsp+0x18]
  4118ad:	mov    rcx,rax
  4118b0:	xchg   QWORD PTR [rsi],rcx
  4118b3:	add    rsp,0x30
  4118b7:	pop    rsi
  4118b8:	ret
  4118b9:	add    BYTE PTR [rax],al
  4118bb:	add    BYTE PTR [rax],al
  4118bd:	add    BYTE PTR [rax],al
	...

00000000004118c0 <__swc_fn_e121059d_000173_1751ecdd>:
  4118c0:	push   rsi
  4118c1:	test   r8,r8
  4118c4:	jne    4118c8 <__swc_fn_e121059d_000173_1751ecdd+0x8>
  4118c6:	pop    rsi
  4118c7:	ret
  4118c8:	lea    rax,[rcx+0x18]
  4118cc:	mov    r10,QWORD PTR [rax]
  4118cf:	lea    r11,[r10+0x1]
  4118d3:	mov    QWORD PTR [rax],r11
  4118d6:	mov    r11,rdx
  4118d9:	not    rdx
  4118dc:	lea    rsi,[r8-0x1]
  4118e0:	cmp    rsi,rdx
  4118e3:	ja     411903 <__swc_fn_e121059d_000173_1751ecdd+0x43>
  4118e5:	lea    rdx,[r11+r8*1]
  4118e9:	dec    rdx
  4118ec:	shr    rdx,0x6
  4118f0:	mov    r8,r11
  4118f3:	shr    r8,0x6
  4118f7:	mov    rsi,rdx
  4118fa:	sub    rsi,r8
  4118fd:	cmp    rsi,0x8
  411901:	jb     411919 <__swc_fn_e121059d_000173_1751ecdd+0x59>
  411903:	lea    rcx,[rcx+0x10]
  411907:	mov    rdx,QWORD PTR [rcx]
  41190a:	add    rdx,r9
  41190d:	mov    QWORD PTR [rcx],rdx
  411910:	lea    rcx,[r10+0x2]
  411914:	mov    QWORD PTR [rax],rcx
  411917:	pop    rsi
  411918:	ret
  411919:	shr    r11,0x6
  41191d:	nop    DWORD PTR [rax]
  411920:	cmp    r11,rdx
  411923:	ja     411963 <__swc_fn_e121059d_000173_1751ecdd+0xa3>
  411925:	jmp    411936 <__swc_fn_e121059d_000173_1751ecdd+0x76>
  411927:	nop    WORD PTR [rax+rax*1+0x0]
  411930:	add    r11,0x1
  411934:	jmp    411920 <__swc_fn_e121059d_000173_1751ecdd+0x60>
  411936:	mov    r8,r11
  411939:	shr    r8,0xc
  41193d:	mov    rsi,r11
  411940:	xor    rsi,r8
  411943:	mov    r8,r11
  411946:	shr    r8,0x18
  41194a:	xor    rsi,r8
  41194d:	and    esi,0xfff
  411953:	lea    r8,[rcx+rsi*8+0x20]
  411958:	mov    rsi,QWORD PTR [r8]
  41195b:	add    rsi,r9
  41195e:	mov    QWORD PTR [r8],rsi
  411961:	jmp    411930 <__swc_fn_e121059d_000173_1751ecdd+0x70>
  411963:	lea    rcx,[r10+0x2]
  411967:	mov    QWORD PTR [rax],rcx
  41196a:	pop    rsi
  41196b:	ret
  41196c:	add    BYTE PTR [rax],al
	...

0000000000411970 <__swc_fn_e121059d_000176_e7f0b636>:
  411970:	push   rsi
  411971:	push   rdi
  411972:	push   r12
  411974:	mov    rsi,r8
  411977:	mov    rdi,rcx
  41197a:	mov    r12,rdx
  41197d:	lea    rcx,[rdx*8+0x0]
  411985:	call   40b7c0 <__swc_fn_e121059d_000177_2744b483>
  41198a:	mov    QWORD PTR [rdi],rax
  41198d:	lea    rcx,[r12*8+0x0]
  411995:	call   40b7c0 <__swc_fn_e121059d_000177_2744b483>
  41199a:	mov    QWORD PTR [rdi+0x8],rax
  41199e:	lea    rcx,[r12*8+0x0]
  4119a6:	call   40b7c0 <__swc_fn_e121059d_000177_2744b483>
  4119ab:	mov    QWORD PTR [rdi+0x10],rax
  4119af:	mov    rcx,r12
  4119b2:	call   40b7c0 <__swc_fn_e121059d_000177_2744b483>
  4119b7:	mov    QWORD PTR [rdi+0x18],rax
  4119bb:	mov    rcx,rax
  4119be:	xor    al,al
  4119c0:	mov    rdx,rax
  4119c3:	mov    r8,r12
  4119c6:	call   4090e0 <__swc_fn_e121059d_000105_7e71bba2>
  4119cb:	mov    QWORD PTR [rdi+0x20],rsi
  4119cf:	lea    rax,[r12-0x1]
  4119d4:	mov    QWORD PTR [rdi+0x28],rax
  4119d8:	mov    QWORD PTR [rdi+0x30],0x0
  4119e0:	pop    r12
  4119e2:	pop    rdi
  4119e3:	pop    rsi
  4119e4:	ret
	...

0000000000411a00 <__swc_fn_e121059d_000179_68d30882>:
  411a00:	push   rbp
  411a01:	push   rbx
  411a02:	push   rsi
  411a03:	push   rdi
  411a04:	push   r12
  411a06:	push   r13
  411a08:	push   r14
  411a0a:	push   r15
  411a0c:	sub    rsp,0x50
  411a10:	mov    rbp,rsp
  411a13:	vmovups XMMWORD PTR [rsp],xmm6
  411a18:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  411a1e:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  411a24:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  411a2a:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  411a30:	sub    rsp,0x8b0
  411a37:	mov    rbx,rsp
  411a3a:	sub    rsp,0x8
  411a3e:	mov    ecx,0x124f800
  411a43:	call   40b7c0 <__swc_fn_e121059d_000177_2744b483>
  411a48:	mov    rsi,rax
  411a4b:	mov    QWORD PTR [rsp+0x7a8],rax
  411a53:	xor    ecx,ecx
  411a55:	xor    r8d,r8d
  411a58:	mov    QWORD PTR [rsp+0x7b0],r8
  411a60:	lea    r9,[rbx+0xa0]
  411a67:	lea    r10,[rbx+0xf0]
  411a6e:	lea    r11,[rbx+0x168]
  411a75:	mov    QWORD PTR [rsp+0x7b8],r11
  411a7d:	lea    rdi,[rbx+0x1b0]
  411a84:	mov    QWORD PTR [rsp+0x7c0],rdi
  411a8c:	nop    DWORD PTR [rax+0x0]
  411a90:	test   r8,r8
  411a93:	jbe    411a9d <__swc_fn_e121059d_000179_68d30882+0x9d>
  411a95:	mov    BYTE PTR [rsi+rcx*1],0xa
  411a99:	add    rcx,0x1
  411a9d:	lea    r12,[rip+0x1e74]        # 413918 <__swc_rdata_base_e121059d+0x808>
  411aa4:	mov    r13,QWORD PTR [rip+0x10565]        # 422010 <__swc_data_base_e121059d+0x10>
  411aab:	imul   r13,r13,0x41a7
  411ab2:	movabs rdx,0x200000005
  411abc:	mov    r11,rax
  411abf:	mov    rax,r13
  411ac2:	mul    rdx
  411ac5:	mov    r14,rdx
  411ac8:	mov    rdx,r13
  411acb:	sub    rdx,r14
  411ace:	shr    rdx,1
  411ad1:	add    rdx,r14
  411ad4:	shr    rdx,0x1e
  411ad8:	imul   r14,rdx,0x7fffffff
  411adf:	sub    r13,r14
  411ae2:	mov    QWORD PTR [rip+0x10527],r13        # 422010 <__swc_data_base_e121059d+0x10>
  411ae9:	mov    edx,r13d
  411aec:	and    edx,0x7
  411aef:	add    rdx,rdx
  411af2:	mov    r14,QWORD PTR [r12+rdx*8]
  411af6:	mov    r12,QWORD PTR [r12+rdx*8+0x8]
  411afb:	imul   r13,r13,0x41a7
  411b02:	movabs rdx,0x200000005
  411b0c:	mov    rax,r13
  411b0f:	mul    rdx
  411b12:	mov    r15,rdx
  411b15:	mov    rdx,r13
  411b18:	sub    rdx,r15
  411b1b:	shr    rdx,1
  411b1e:	add    rdx,r15
  411b21:	shr    rdx,0x1e
  411b25:	imul   r15,rdx,0x7fffffff
  411b2c:	sub    r13,r15
  411b2f:	mov    QWORD PTR [rip+0x104da],r13        # 422010 <__swc_data_base_e121059d+0x10>
  411b36:	movabs rdx,0xaaaaaaaaaaaaaaab
  411b40:	mov    rax,r13
  411b43:	mul    rdx
  411b46:	mov    r15,rdx
  411b49:	shr    r15,1
  411b4c:	lea    r15,[r15+r15*2]
  411b50:	mov    rdx,r13
  411b53:	sub    rdx,r15
  411b56:	lea    r15,[rdx+0x7e8]
  411b5d:	imul   r13,r13,0x41a7
  411b64:	movabs rdx,0x200000005
  411b6e:	mov    rax,r13
  411b71:	mul    rdx
  411b74:	mov    rdi,rdx
  411b77:	mov    rdx,r13
  411b7a:	sub    rdx,rdi
  411b7d:	shr    rdx,1
  411b80:	add    rdx,rdi
  411b83:	shr    rdx,0x1e
  411b87:	imul   rdi,rdx,0x7fffffff
  411b8e:	sub    r13,rdi
  411b91:	mov    QWORD PTR [rip+0x10478],r13        # 422010 <__swc_data_base_e121059d+0x10>
  411b98:	movabs rdx,0xaaaaaaaaaaaaaaab
  411ba2:	mov    rax,r13
  411ba5:	mul    rdx
  411ba8:	mov    rdi,rdx
  411bab:	shr    rdi,0x3
  411baf:	imul   rdi,rdi,0xc
  411bb3:	mov    rdx,r13
  411bb6:	sub    rdx,rdi
  411bb9:	lea    rdi,[rdx+0x1]
  411bbd:	imul   r13,r13,0x41a7
  411bc4:	movabs rdx,0x200000005
  411bce:	mov    QWORD PTR [rsp+0x878],rcx
  411bd6:	mov    rcx,r11
  411bd9:	mov    rax,r13
  411bdc:	mul    rdx
  411bdf:	mov    r11,rdx
  411be2:	mov    rax,rcx
  411be5:	mov    rcx,QWORD PTR [rsp+0x878]
  411bed:	mov    rdx,r13
  411bf0:	sub    rdx,r11
  411bf3:	shr    rdx,1
  411bf6:	add    rdx,r11
  411bf9:	shr    rdx,0x1e
  411bfd:	imul   r11,rdx,0x7fffffff
  411c04:	sub    r13,r11
  411c07:	mov    QWORD PTR [rip+0x10402],r13        # 422010 <__swc_data_base_e121059d+0x10>
  411c0e:	mov    r11,r13
  411c11:	shr    r11,0x2
  411c15:	movabs rdx,0x4924924924924925
  411c1f:	mov    QWORD PTR [rsp+0x880],rcx
  411c27:	mov    rcx,rax
  411c2a:	mov    rax,r11
  411c2d:	mul    rdx
  411c30:	mov    r11,rdx
  411c33:	mov    rax,rcx
  411c36:	mov    rcx,QWORD PTR [rsp+0x880]
  411c3e:	shr    r11,1
  411c41:	imul   r11,r11,0x1c
  411c45:	mov    rdx,r13
  411c48:	sub    rdx,r11
  411c4b:	lea    r11,[rdx+0x1]
  411c4f:	mov    QWORD PTR [rsp+0x7d8],r11
  411c57:	imul   r13,r13,0x41a7
  411c5e:	movabs rdx,0x200000005
  411c68:	mov    QWORD PTR [rsp+0x888],rcx
  411c70:	mov    rcx,rax
  411c73:	mov    rax,r13
  411c76:	mul    rdx
  411c79:	mov    r11,rdx
  411c7c:	mov    rax,rcx
  411c7f:	mov    rcx,QWORD PTR [rsp+0x888]
  411c87:	mov    rdx,r13
  411c8a:	sub    rdx,r11
  411c8d:	shr    rdx,1
  411c90:	add    rdx,r11
  411c93:	shr    rdx,0x1e
  411c97:	imul   r11,rdx,0x7fffffff
  411c9e:	sub    r13,r11
  411ca1:	mov    QWORD PTR [rip+0x10368],r13        # 422010 <__swc_data_base_e121059d+0x10>
  411ca8:	mov    r11,r13
  411cab:	shr    r11,1
  411cae:	movabs rdx,0xa3d70a3d70a3d70b
  411cb8:	mov    QWORD PTR [rsp+0x890],rcx
  411cc0:	mov    rcx,rax
  411cc3:	mov    rax,r11
  411cc6:	mul    rdx
  411cc9:	mov    r11,rdx
  411ccc:	mov    rax,rcx
  411ccf:	mov    rcx,QWORD PTR [rsp+0x890]
  411cd7:	shr    r11,0x4
  411cdb:	imul   r11,r11,0x32
  411cdf:	mov    rdx,r13
  411ce2:	sub    rdx,r11
  411ce5:	lea    r11,[rdx+0x1]
  411ce9:	mov    QWORD PTR [rsp+0x7e8],r11
  411cf1:	imul   r13,r13,0x41a7
  411cf8:	movabs rdx,0x200000005
  411d02:	mov    QWORD PTR [rsp+0x898],rcx
  411d0a:	mov    rcx,rax
  411d0d:	mov    rax,r13
  411d10:	mul    rdx
  411d13:	mov    r11,rdx
  411d16:	mov    rax,rcx
  411d19:	mov    rcx,QWORD PTR [rsp+0x898]
  411d21:	mov    rdx,r13
  411d24:	sub    rdx,r11
  411d27:	shr    rdx,1
  411d2a:	add    rdx,r11
  411d2d:	shr    rdx,0x1e
  411d31:	imul   r11,rdx,0x7fffffff
  411d38:	sub    r13,r11
  411d3b:	mov    QWORD PTR [rip+0x102ce],r13        # 422010 <__swc_data_base_e121059d+0x10>
  411d42:	movabs rdx,0xa7f0aa6670e5710d
  411d4c:	mov    QWORD PTR [rsp+0x8a0],rcx
  411d54:	mov    rcx,rax
  411d57:	mov    rax,r13
  411d5a:	mul    rdx
  411d5d:	mov    rax,rcx
  411d60:	mov    rcx,QWORD PTR [rsp+0x8a0]
  411d68:	shr    rdx,0x10
  411d6c:	imul   rdx,rdx,0x1863c
  411d73:	sub    r13,rdx
  411d76:	lea    r11,[r13+0x64]
  411d7a:	mov    QWORD PTR [rsp+0x7f8],r11
  411d82:	vxorps xmm0,xmm0,xmm0
  411d86:	vmovups XMMWORD PTR [rbx+0xa0],xmm0
  411d8e:	mov    QWORD PTR [rbx+0xb0],0x0
  411d99:	xor    r13d,r13d
  411d9c:	mov    rdx,r8
  411d9f:	test   r8,r8
  411da2:	jne    411dae <__swc_fn_e121059d_000179_68d30882+0x3ae>
  411da4:	mov    BYTE PTR [r9],0x30
  411da8:	mov    r13d,0x1
  411dae:	vmovsd xmm6,QWORD PTR [rsp+0x800]
  411db7:	vmovsd xmm7,QWORD PTR [rsp+0x8a8]
  411dc0:	test   rdx,rdx
  411dc3:	jbe    411e30 <__swc_fn_e121059d_000179_68d30882+0x430>
  411dc9:	cs nop WORD PTR [rax+rax*1+0x0]
  411dd3:	cs nop WORD PTR [rax+rax*1+0x0]
  411ddd:	nop    DWORD PTR [rax]
  411de0:	mov    r8,rdx
  411de3:	vmovq  xmm6,rdx
  411de8:	movabs rdx,0xcccccccccccccccd
  411df2:	vmovq  r11,xmm6
  411df7:	vmovq  xmm7,rcx
  411dfc:	mov    rcx,rax
  411dff:	mov    rax,r8
  411e02:	mul    rdx
  411e05:	mov    r8,rdx
  411e08:	mov    rax,rcx
  411e0b:	vmovq  rcx,xmm7
  411e10:	shr    r8,0x3
  411e14:	imul   r8,r8,0xa
  411e18:	sub    r11,r8
  411e1b:	lea    r8,[r11+0x30]
  411e1f:	mov    BYTE PTR [r9+r13*1],r8b
  411e23:	add    r13,0x1
  411e27:	shr    rdx,0x3
  411e2b:	test   rdx,rdx
  411e2e:	ja     411de0 <__swc_fn_e121059d_000179_68d30882+0x3e0>
  411e30:	vmovsd QWORD PTR [rsp+0x800],xmm6
  411e39:	vmovsd QWORD PTR [rsp+0x8a8],xmm7
  411e42:	test   r13,r13
  411e45:	jbe    411e66 <__swc_fn_e121059d_000179_68d30882+0x466>
  411e47:	nop    WORD PTR [rax+rax*1+0x0]
  411e50:	lea    rdx,[r13-0x1]
  411e54:	mov    r13,rdx
  411e57:	mov    dl,BYTE PTR [r9+rdx*1]
  411e5b:	mov    BYTE PTR [rsi+rcx*1],dl
  411e5e:	inc    rcx
  411e61:	test   r13,r13
  411e64:	ja     411e50 <__swc_fn_e121059d_000179_68d30882+0x450>
  411e66:	mov    BYTE PTR [rsi+rcx*1],0x2c
  411e6a:	inc    rcx
  411e6d:	xor    edx,edx
  411e6f:	test   r12,r12
  411e72:	jbe    411e95 <__swc_fn_e121059d_000179_68d30882+0x495>
  411e74:	cs nop WORD PTR [rax+rax*1+0x0]
  411e7e:	xchg   ax,ax
  411e80:	mov    r8b,BYTE PTR [r14+rdx*1]
  411e84:	mov    BYTE PTR [rsi+rcx*1],r8b
  411e88:	add    rcx,0x1
  411e8c:	add    rdx,0x1
  411e90:	cmp    rdx,r12
  411e93:	jb     411e80 <__swc_fn_e121059d_000179_68d30882+0x480>
  411e95:	mov    BYTE PTR [rsi+rcx*1],0x2c
  411e99:	inc    rcx
  411e9c:	vxorps xmm0,xmm0,xmm0
  411ea0:	vmovups XMMWORD PTR [rbx+0xf0],xmm0
  411ea8:	mov    QWORD PTR [rbx+0x100],0x0
  411eb3:	xor    r8d,r8d
  411eb6:	mov    r11,r15
  411eb9:	test   r15,r15
  411ebc:	jne    411ec8 <__swc_fn_e121059d_000179_68d30882+0x4c8>
  411ebe:	mov    BYTE PTR [r10],0x30
  411ec2:	mov    r8d,0x1
  411ec8:	test   r11,r11
  411ecb:	jbe    411f0c <__swc_fn_e121059d_000179_68d30882+0x50c>
  411ecd:	nop    DWORD PTR [rax]
  411ed0:	movabs rdx,0xcccccccccccccccd
  411eda:	mov    r14,rax
  411edd:	mov    rax,r11
  411ee0:	mul    rdx
  411ee3:	mov    r12,rdx
  411ee6:	mov    rax,r14
  411ee9:	shr    r12,0x3
  411eed:	imul   r12,r12,0xa
  411ef1:	sub    r11,r12
  411ef4:	lea    r11,[r11+0x30]
  411ef8:	mov    BYTE PTR [r10+r8*1],r11b
  411efc:	add    r8,0x1
  411f00:	mov    r11,rdx
  411f03:	shr    r11,0x3
  411f07:	test   r11,r11
  411f0a:	ja     411ed0 <__swc_fn_e121059d_000179_68d30882+0x4d0>
  411f0c:	test   r8,r8
  411f0f:	jbe    411f36 <__swc_fn_e121059d_000179_68d30882+0x536>
  411f11:	cs nop WORD PTR [rax+rax*1+0x0]
  411f1b:	nop    DWORD PTR [rax+rax*1+0x0]
  411f20:	lea    rdx,[r8-0x1]
  411f24:	mov    r8,rdx
  411f27:	mov    dl,BYTE PTR [r10+rdx*1]
  411f2b:	mov    BYTE PTR [rsi+rcx*1],dl
  411f2e:	inc    rcx
  411f31:	test   r8,r8
  411f34:	ja     411f20 <__swc_fn_e121059d_000179_68d30882+0x520>
  411f36:	mov    BYTE PTR [rsi+rcx*1],0x2d
  411f3a:	movabs rdx,0xcccccccccccccccd
  411f44:	mov    r11,rax
  411f47:	mov    rax,rdi
  411f4a:	mul    rdx
  411f4d:	mov    r8,rdx
  411f50:	mov    r14,r11
  411f53:	shr    r8,0x3
  411f57:	lea    rdx,[r8+0x30]
  411f5b:	mov    BYTE PTR [rsi+rcx*1+0x1],dl
  411f5f:	imul   r8,r8,0xa
  411f63:	sub    rdi,r8
  411f66:	lea    rdx,[rdi+0x30]
  411f6a:	mov    BYTE PTR [rsi+rcx*1+0x2],dl
  411f6e:	mov    BYTE PTR [rsi+rcx*1+0x3],0x2d
  411f73:	mov    r11,QWORD PTR [rsp+0x7d8]
  411f7b:	movabs rdx,0xcccccccccccccccd
  411f85:	mov    rax,r11
  411f88:	mul    rdx
  411f8b:	mov    r8,rdx
  411f8e:	mov    rax,r14
  411f91:	shr    r8,0x3
  411f95:	lea    rdx,[r8+0x30]
  411f99:	mov    BYTE PTR [rsi+rcx*1+0x4],dl
  411f9d:	imul   r8,r8,0xa
  411fa1:	sub    r11,r8
  411fa4:	lea    rdx,[r11+0x30]
  411fa8:	mov    BYTE PTR [rsi+rcx*1+0x5],dl
  411fac:	mov    BYTE PTR [rsi+rcx*1+0x6],0x2c
  411fb1:	lea    rcx,[rcx+0x7]
  411fb5:	vxorps xmm0,xmm0,xmm0
  411fb9:	vmovups XMMWORD PTR [rbx+0x168],xmm0
  411fc1:	mov    QWORD PTR [rbx+0x178],0x0
  411fcc:	xor    r8d,r8d
  411fcf:	mov    r11,QWORD PTR [rsp+0x7e8]
  411fd7:	mov    rdi,r11
  411fda:	test   r11,r11
  411fdd:	je     411fe9 <__swc_fn_e121059d_000179_68d30882+0x5e9>
  411fdf:	mov    r11,QWORD PTR [rsp+0x7b8]
  411fe7:	jmp    411ffb <__swc_fn_e121059d_000179_68d30882+0x5fb>
  411fe9:	mov    r11,QWORD PTR [rsp+0x7b8]
  411ff1:	mov    BYTE PTR [r11],0x30
  411ff5:	mov    r8d,0x1
  411ffb:	test   rdi,rdi
  411ffe:	jbe    41203c <__swc_fn_e121059d_000179_68d30882+0x63c>
  412000:	movabs rdx,0xcccccccccccccccd
  41200a:	mov    r14,rax
  41200d:	mov    rax,rdi
  412010:	mul    rdx
  412013:	mov    r12,rdx
  412016:	mov    rax,r14
  412019:	shr    r12,0x3
  41201d:	imul   r12,r12,0xa
  412021:	sub    rdi,r12
  412024:	lea    rdi,[rdi+0x30]
  412028:	mov    BYTE PTR [r11+r8*1],dil
  41202c:	add    r8,0x1
  412030:	mov    rdi,rdx
  412033:	shr    rdi,0x3
  412037:	test   rdi,rdi
  41203a:	ja     412000 <__swc_fn_e121059d_000179_68d30882+0x600>
  41203c:	test   r8,r8
  41203f:	jbe    412066 <__swc_fn_e121059d_000179_68d30882+0x666>
  412041:	cs nop WORD PTR [rax+rax*1+0x0]
  41204b:	nop    DWORD PTR [rax+rax*1+0x0]
  412050:	lea    rdx,[r8-0x1]
  412054:	mov    r8,rdx
  412057:	mov    dl,BYTE PTR [r11+rdx*1]
  41205b:	mov    BYTE PTR [rsi+rcx*1],dl
  41205e:	inc    rcx
  412061:	test   r8,r8
  412064:	ja     412050 <__swc_fn_e121059d_000179_68d30882+0x650>
  412066:	mov    BYTE PTR [rsi+rcx*1],0x2c
  41206a:	inc    rcx
  41206d:	vxorps xmm0,xmm0,xmm0
  412071:	vmovups XMMWORD PTR [rbx+0x1b0],xmm0
  412079:	mov    QWORD PTR [rbx+0x1c0],0x0
  412084:	xor    r8d,r8d
  412087:	mov    rdi,QWORD PTR [rsp+0x7f8]
  41208f:	mov    r12,rdi
  412092:	shr    r12,0x2
  412096:	movabs rdx,0x28f5c28f5c28f5c3
  4120a0:	mov    r11,rax
  4120a3:	mov    rax,r12
  4120a6:	mul    rdx
  4120a9:	mov    r12,rdx
  4120ac:	mov    rax,r11
  4120af:	shr    r12,0x2
  4120b3:	mov    r13,r12
  4120b6:	test   r12,r12
  4120b9:	je     4120c5 <__swc_fn_e121059d_000179_68d30882+0x6c5>
  4120bb:	mov    r14,QWORD PTR [rsp+0x7c0]
  4120c3:	jmp    4120d7 <__swc_fn_e121059d_000179_68d30882+0x6d7>
  4120c5:	mov    r14,QWORD PTR [rsp+0x7c0]
  4120cd:	mov    BYTE PTR [r14],0x30
  4120d1:	mov    r8d,0x1
  4120d7:	test   r13,r13
  4120da:	jbe    41211c <__swc_fn_e121059d_000179_68d30882+0x71c>
  4120dc:	nop    DWORD PTR [rax+0x0]
  4120e0:	movabs rdx,0xcccccccccccccccd
  4120ea:	mov    r11,rax
  4120ed:	mov    rax,r13
  4120f0:	mul    rdx
  4120f3:	mov    r15,rdx
  4120f6:	mov    rax,r11
  4120f9:	shr    r15,0x3
  4120fd:	imul   r15,r15,0xa
  412101:	sub    r13,r15
  412104:	lea    r13,[r13+0x30]
  412108:	mov    BYTE PTR [r14+r8*1],r13b
  41210c:	add    r8,0x1
  412110:	mov    r13,rdx
  412113:	shr    r13,0x3
  412117:	test   r13,r13
  41211a:	ja     4120e0 <__swc_fn_e121059d_000179_68d30882+0x6e0>
  41211c:	test   r8,r8
  41211f:	jbe    412146 <__swc_fn_e121059d_000179_68d30882+0x746>
  412121:	cs nop WORD PTR [rax+rax*1+0x0]
  41212b:	nop    DWORD PTR [rax+rax*1+0x0]
  412130:	lea    rdx,[r8-0x1]
  412134:	mov    r8,rdx
  412137:	mov    dl,BYTE PTR [r14+rdx*1]
  41213b:	mov    BYTE PTR [rsi+rcx*1],dl
  41213e:	inc    rcx
  412141:	test   r8,r8
  412144:	ja     412130 <__swc_fn_e121059d_000179_68d30882+0x730>
  412146:	mov    BYTE PTR [rsi+rcx*1],0x2e
  41214a:	imul   r12,r12,0x64
  41214e:	sub    rdi,r12
  412151:	movabs rdx,0xcccccccccccccccd
  41215b:	mov    r11,rax
  41215e:	mov    rax,rdi
  412161:	mul    rdx
  412164:	mov    r8,rdx
  412167:	mov    rax,r11
  41216a:	shr    r8,0x3
  41216e:	lea    rdx,[r8+0x30]
  412172:	mov    BYTE PTR [rsi+rcx*1+0x1],dl
  412176:	imul   r8,r8,0xa
  41217a:	sub    rdi,r8
  41217d:	lea    rdx,[rdi+0x30]
  412181:	mov    BYTE PTR [rsi+rcx*1+0x2],dl
  412185:	lea    rdi,[rcx+0x3]
  412189:	mov    QWORD PTR [rsp+0x808],rdi
  412191:	mov    rcx,rdi
  412194:	mov    r8,QWORD PTR [rsp+0x7b0]
  41219c:	add    r8,0x1
  4121a0:	mov    QWORD PTR [rsp+0x7b0],r8
  4121a8:	cmp    r8,0x61a80
  4121af:	jb     411a90 <__swc_fn_e121059d_000179_68d30882+0x90>
  4121b5:	call   40eaf0 <__swc_fn_e121059d_000178_1ca87929>
  4121ba:	vmovups xmm6,xmm0
  4121be:	vxorps xmm0,xmm0,xmm0
  4121c2:	vmovups XMMWORD PTR [rbx+0x208],xmm0
  4121ca:	vmovups XMMWORD PTR [rbx+0x218],xmm0
  4121d2:	vmovups XMMWORD PTR [rbx+0x228],xmm0
  4121da:	mov    QWORD PTR [rbx+0x238],0x0
  4121e5:	lea    rcx,[rbx+0x208]
  4121ec:	mov    edx,0x40
  4121f1:	mov    r8,rsi
  4121f4:	call   411970 <__swc_fn_e121059d_000176_e7f0b636>
  4121f9:	mov    ecx,0x200
  4121fe:	call   40b7c0 <__swc_fn_e121059d_000177_2744b483>
  412203:	mov    r12,rax
  412206:	mov    QWORD PTR [rsp+0x810],rax
  41220e:	mov    ecx,0x200
  412213:	call   40b7c0 <__swc_fn_e121059d_000177_2744b483>
  412218:	mov    QWORD PTR [rsp+0x818],rax
  412220:	mov    ecx,0x200
  412225:	call   40b7c0 <__swc_fn_e121059d_000177_2744b483>
  41222a:	mov    QWORD PTR [rsp+0x820],rax
  412232:	mov    ecx,0x200
  412237:	call   40b7c0 <__swc_fn_e121059d_000177_2744b483>
  41223c:	mov    QWORD PTR [rsp+0x828],rax
  412244:	xor    ecx,ecx
  412246:	xor    r15d,r15d
  412249:	mov    QWORD PTR [rsp+0x830],r15
  412251:	vmovups xmm7,XMMWORD PTR [rip+0x17d7]        # 413a30 <__swc_rdata_base_e121059d+0x920>
  412259:	vmovups xmm8,XMMWORD PTR [rip+0x17df]        # 413a40 <__swc_rdata_base_e121059d+0x930>
  412261:	vmovsd xmm9,QWORD PTR [rip+0x1807]        # 413a70 <__swc_rdata_base_e121059d+0x960>
  412269:	cmp    rcx,rdi
  41226c:	jae    4127ac <__swc_fn_e121059d_000179_68d30882+0xdac>
  412272:	cs nop WORD PTR [rax+rax*1+0x0]
  41227c:	nop    DWORD PTR [rax+0x0]
  412280:	mov    r15,rcx
  412283:	cmp    rcx,rdi
  412286:	jae    412300 <__swc_fn_e121059d_000179_68d30882+0x900>
  41228c:	mov    rax,rdi
  41228f:	sub    rax,r15
  412292:	cmp    rax,0x4
  412296:	jb     4122e0 <__swc_fn_e121059d_000179_68d30882+0x8e0>
  412298:	mov    rax,rdi
  41229b:	sub    rax,0x3
  41229f:	cmp    r15,rax
  4122a2:	jae    4122e0 <__swc_fn_e121059d_000179_68d30882+0x8e0>
  4122a4:	cs nop WORD PTR [rax+rax*1+0x0]
  4122ae:	xchg   ax,ax
  4122b0:	cmp    BYTE PTR [rsi+r15*1],0xa
  4122b5:	je     412300 <__swc_fn_e121059d_000179_68d30882+0x900>
  4122b7:	cmp    BYTE PTR [rsi+r15*1+0x1],0xa
  4122bd:	je     4122f1 <__swc_fn_e121059d_000179_68d30882+0x8f1>
  4122bf:	cmp    BYTE PTR [rsi+r15*1+0x2],0xa
  4122c5:	je     4122f6 <__swc_fn_e121059d_000179_68d30882+0x8f6>
  4122c7:	cmp    BYTE PTR [rsi+r15*1+0x3],0xa
  4122cd:	je     4122fc <__swc_fn_e121059d_000179_68d30882+0x8fc>
  4122cf:	lea    r15,[r15+0x4]
  4122d3:	cmp    r15,rax
  4122d6:	jb     4122b0 <__swc_fn_e121059d_000179_68d30882+0x8b0>
  4122d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4122e0:	cmp    r15,rdi
  4122e3:	jae    412300 <__swc_fn_e121059d_000179_68d30882+0x900>
  4122e5:	cmp    BYTE PTR [rsi+r15*1],0xa
  4122ea:	je     412300 <__swc_fn_e121059d_000179_68d30882+0x900>
  4122ec:	inc    r15
  4122ef:	jmp    4122e0 <__swc_fn_e121059d_000179_68d30882+0x8e0>
  4122f1:	inc    r15
  4122f4:	jmp    412300 <__swc_fn_e121059d_000179_68d30882+0x900>
  4122f6:	lea    r15,[r15+0x2]
  4122fa:	jmp    412300 <__swc_fn_e121059d_000179_68d30882+0x900>
  4122fc:	lea    r15,[r15+0x3]
  412300:	cmp    rcx,r15
  412303:	jae    412380 <__swc_fn_e121059d_000179_68d30882+0x980>
  412309:	mov    rax,r15
  41230c:	sub    rax,rcx
  41230f:	cmp    rax,0x4
  412313:	jb     412360 <__swc_fn_e121059d_000179_68d30882+0x960>
  412319:	mov    rax,r15
  41231c:	sub    rax,0x3
  412320:	cmp    rcx,rax
  412323:	jae    412360 <__swc_fn_e121059d_000179_68d30882+0x960>
  412325:	cs nop WORD PTR [rax+rax*1+0x0]
  41232f:	nop
  412330:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  412334:	je     412380 <__swc_fn_e121059d_000179_68d30882+0x980>
  412336:	cmp    BYTE PTR [rsi+rcx*1+0x1],0x2c
  41233b:	je     412371 <__swc_fn_e121059d_000179_68d30882+0x971>
  41233d:	cmp    BYTE PTR [rsi+rcx*1+0x2],0x2c
  412342:	je     412376 <__swc_fn_e121059d_000179_68d30882+0x976>
  412344:	cmp    BYTE PTR [rsi+rcx*1+0x3],0x2c
  412349:	je     41237c <__swc_fn_e121059d_000179_68d30882+0x97c>
  41234b:	lea    rcx,[rcx+0x4]
  41234f:	cmp    rcx,rax
  412352:	jb     412330 <__swc_fn_e121059d_000179_68d30882+0x930>
  412354:	cs nop WORD PTR [rax+rax*1+0x0]
  41235e:	xchg   ax,ax
  412360:	cmp    rcx,r15
  412363:	jae    412380 <__swc_fn_e121059d_000179_68d30882+0x980>
  412365:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  412369:	je     412380 <__swc_fn_e121059d_000179_68d30882+0x980>
  41236b:	add    rcx,0x1
  41236f:	jmp    412360 <__swc_fn_e121059d_000179_68d30882+0x960>
  412371:	inc    rcx
  412374:	jmp    412380 <__swc_fn_e121059d_000179_68d30882+0x980>
  412376:	lea    rcx,[rcx+0x2]
  41237a:	jmp    412380 <__swc_fn_e121059d_000179_68d30882+0x980>
  41237c:	lea    rcx,[rcx+0x3]
  412380:	lea    rdi,[rcx+0x1]
  412384:	mov    rcx,rdi
  412387:	cmp    rdi,r15
  41238a:	jae    412400 <__swc_fn_e121059d_000179_68d30882+0xa00>
  412390:	mov    rax,r15
  412393:	sub    rax,rcx
  412396:	cmp    rax,0x4
  41239a:	jb     4123e0 <__swc_fn_e121059d_000179_68d30882+0x9e0>
  41239c:	mov    rax,r15
  41239f:	sub    rax,0x3
  4123a3:	cmp    rcx,rax
  4123a6:	jae    4123e0 <__swc_fn_e121059d_000179_68d30882+0x9e0>
  4123a8:	nop    DWORD PTR [rax+rax*1+0x0]
  4123b0:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  4123b4:	je     412400 <__swc_fn_e121059d_000179_68d30882+0xa00>
  4123b6:	cmp    BYTE PTR [rsi+rcx*1+0x1],0x2c
  4123bb:	je     4123f1 <__swc_fn_e121059d_000179_68d30882+0x9f1>
  4123bd:	cmp    BYTE PTR [rsi+rcx*1+0x2],0x2c
  4123c2:	je     4123f6 <__swc_fn_e121059d_000179_68d30882+0x9f6>
  4123c4:	cmp    BYTE PTR [rsi+rcx*1+0x3],0x2c
  4123c9:	je     4123fc <__swc_fn_e121059d_000179_68d30882+0x9fc>
  4123cb:	lea    rcx,[rcx+0x4]
  4123cf:	cmp    rcx,rax
  4123d2:	jb     4123b0 <__swc_fn_e121059d_000179_68d30882+0x9b0>
  4123d4:	cs nop WORD PTR [rax+rax*1+0x0]
  4123de:	xchg   ax,ax
  4123e0:	cmp    rcx,r15
  4123e3:	jae    412400 <__swc_fn_e121059d_000179_68d30882+0xa00>
  4123e5:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  4123e9:	je     412400 <__swc_fn_e121059d_000179_68d30882+0xa00>
  4123eb:	add    rcx,0x1
  4123ef:	jmp    4123e0 <__swc_fn_e121059d_000179_68d30882+0x9e0>
  4123f1:	inc    rcx
  4123f4:	jmp    412400 <__swc_fn_e121059d_000179_68d30882+0xa00>
  4123f6:	lea    rcx,[rcx+0x2]
  4123fa:	jmp    412400 <__swc_fn_e121059d_000179_68d30882+0xa00>
  4123fc:	lea    rcx,[rcx+0x3]
  412400:	mov    r14,rcx
  412403:	sub    r14,rdi
  412406:	add    rcx,0x1
  41240a:	cmp    rcx,r15
  41240d:	jae    4124a0 <__swc_fn_e121059d_000179_68d30882+0xaa0>
  412413:	mov    rax,r15
  412416:	sub    rax,rcx
  412419:	cmp    rax,0x4
  41241d:	jb     412480 <__swc_fn_e121059d_000179_68d30882+0xa80>
  412423:	mov    rax,r15
  412426:	sub    rax,0x3
  41242a:	cmp    rcx,rax
  41242d:	jae    412480 <__swc_fn_e121059d_000179_68d30882+0xa80>
  412433:	cs nop WORD PTR [rax+rax*1+0x0]
  41243d:	cs nop WORD PTR [rax+rax*1+0x0]
  412447:	nop    WORD PTR [rax+rax*1+0x0]
  412450:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  412454:	je     4124a0 <__swc_fn_e121059d_000179_68d30882+0xaa0>
  412456:	cmp    BYTE PTR [rsi+rcx*1+0x1],0x2c
  41245b:	je     412491 <__swc_fn_e121059d_000179_68d30882+0xa91>
  41245d:	cmp    BYTE PTR [rsi+rcx*1+0x2],0x2c
  412462:	je     412496 <__swc_fn_e121059d_000179_68d30882+0xa96>
  412464:	cmp    BYTE PTR [rsi+rcx*1+0x3],0x2c
  412469:	je     41249c <__swc_fn_e121059d_000179_68d30882+0xa9c>
  41246b:	lea    rcx,[rcx+0x4]
  41246f:	cmp    rcx,rax
  412472:	jb     412450 <__swc_fn_e121059d_000179_68d30882+0xa50>
  412474:	cs nop WORD PTR [rax+rax*1+0x0]
  41247e:	xchg   ax,ax
  412480:	cmp    rcx,r15
  412483:	jae    4124a0 <__swc_fn_e121059d_000179_68d30882+0xaa0>
  412485:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  412489:	je     4124a0 <__swc_fn_e121059d_000179_68d30882+0xaa0>
  41248b:	add    rcx,0x1
  41248f:	jmp    412480 <__swc_fn_e121059d_000179_68d30882+0xa80>
  412491:	inc    rcx
  412494:	jmp    4124a0 <__swc_fn_e121059d_000179_68d30882+0xaa0>
  412496:	lea    rcx,[rcx+0x2]
  41249a:	jmp    4124a0 <__swc_fn_e121059d_000179_68d30882+0xaa0>
  41249c:	lea    rcx,[rcx+0x3]
  4124a0:	add    rcx,0x1
  4124a4:	xor    r13d,r13d
  4124a7:	cmp    rcx,r15
  4124aa:	jae    4124ce <__swc_fn_e121059d_000179_68d30882+0xace>
  4124ac:	nop    DWORD PTR [rax+0x0]
  4124b0:	movzx  edx,BYTE PTR [rsi+rcx*1]
  4124b4:	cmp    edx,0x2c
  4124b7:	je     4124ce <__swc_fn_e121059d_000179_68d30882+0xace>
  4124b9:	lea    r8,[r13+r13*4+0x0]
  4124be:	sub    dl,0x30
  4124c1:	lea    r13,[rdx+r8*2]
  4124c5:	add    rcx,0x1
  4124c9:	cmp    rcx,r15
  4124cc:	jb     4124b0 <__swc_fn_e121059d_000179_68d30882+0xab0>
  4124ce:	add    rcx,0x1
  4124d2:	xor    edx,edx
  4124d4:	cmp    rcx,r15
  4124d7:	jae    412510 <__swc_fn_e121059d_000179_68d30882+0xb10>
  4124d9:	cs nop WORD PTR [rax+rax*1+0x0]
  4124e3:	cs nop WORD PTR [rax+rax*1+0x0]
  4124ed:	nop    DWORD PTR [rax]
  4124f0:	movzx  r8d,BYTE PTR [rsi+rcx*1]
  4124f5:	cmp    r8d,0x2e
  4124f9:	je     412510 <__swc_fn_e121059d_000179_68d30882+0xb10>
  4124fb:	lea    rdx,[rdx+rdx*4]
  4124ff:	sub    r8b,0x30
  412503:	lea    rdx,[r8+rdx*2]
  412507:	add    rcx,0x1
  41250b:	cmp    rcx,r15
  41250e:	jb     4124f0 <__swc_fn_e121059d_000179_68d30882+0xaf0>
  412510:	add    rcx,0x1
  412514:	xor    r8d,r8d
  412517:	cmp    rcx,r15
  41251a:	jae    41253a <__swc_fn_e121059d_000179_68d30882+0xb3a>
  41251c:	nop    DWORD PTR [rax+0x0]
  412520:	lea    r8,[r8+r8*4]
  412524:	movzx  r9d,BYTE PTR [rsi+rcx*1]
  412529:	sub    r9b,0x30
  41252d:	lea    r8,[r9+r8*2]
  412531:	add    rcx,0x1
  412535:	cmp    rcx,r15
  412538:	jb     412520 <__swc_fn_e121059d_000179_68d30882+0xb20>
  41253a:	vmovq  xmm0,rdx
  41253f:	vpunpckldq xmm0,xmm0,xmm7
  412543:	vsubpd xmm0,xmm0,xmm8
  412548:	vpunpckhqdq xmm1,xmm0,xmm0
  41254c:	vaddsd xmm0,xmm0,xmm1
  412550:	vmovq  xmm1,r8
  412555:	vpunpckldq xmm1,xmm1,xmm7
  412559:	vsubpd xmm1,xmm1,xmm8
  41255e:	vpunpckhqdq xmm2,xmm1,xmm1
  412562:	vaddsd xmm1,xmm1,xmm2
  412566:	vdivsd xmm1,xmm1,xmm9
  41256b:	vaddsd xmm10,xmm0,xmm1
  41256f:	mov    ecx,0x811c9dc5
  412574:	xor    edx,edx
  412576:	test   r14,r14
  412579:	jbe    4125f3 <__swc_fn_e121059d_000179_68d30882+0xbf3>
  41257f:	mov    r8,QWORD PTR [rbx+0x228]
  412586:	add    r8,rdi
  412589:	cmp    r14,0x4
  41258d:	jb     4125e0 <__swc_fn_e121059d_000179_68d30882+0xbe0>
  412593:	lea    r9,[r14-0x3]
  412597:	nop    WORD PTR [rax+rax*1+0x0]
  4125a0:	xor    cl,BYTE PTR [r8+rdx*1]
  4125a4:	imul   ecx,ecx,0x1000193
  4125aa:	xor    cl,BYTE PTR [r8+rdx*1+0x1]
  4125af:	imul   ecx,ecx,0x1000193
  4125b5:	xor    cl,BYTE PTR [r8+rdx*1+0x2]
  4125ba:	imul   ecx,ecx,0x1000193
  4125c0:	xor    cl,BYTE PTR [r8+rdx*1+0x3]
  4125c5:	imul   ecx,ecx,0x1000193
  4125cb:	add    rdx,0x4
  4125cf:	cmp    rdx,r9
  4125d2:	jb     4125a0 <__swc_fn_e121059d_000179_68d30882+0xba0>
  4125d4:	cmp    rdx,r14
  4125d7:	jae    4125f3 <__swc_fn_e121059d_000179_68d30882+0xbf3>
  4125d9:	nop    DWORD PTR [rax+0x0]
  4125e0:	xor    cl,BYTE PTR [r8+rdx*1]
  4125e4:	imul   ecx,ecx,0x1000193
  4125ea:	add    rdx,0x1
  4125ee:	cmp    rdx,r14
  4125f1:	jb     4125e0 <__swc_fn_e121059d_000179_68d30882+0xbe0>
  4125f3:	and    rcx,QWORD PTR [rbx+0x230]
  4125fa:	mov    rsi,rcx
  4125fd:	mov    QWORD PTR [rsp+0x838],r15
  412605:	mov    r15,QWORD PTR [rbx+0x220]
  41260c:	mov    QWORD PTR [rsp+0x840],r13
  412614:	mov    r13,QWORD PTR [rbx+0x210]
  41261b:	cmp    BYTE PTR [r15+rsi*1],0x0
  412620:	je     412670 <__swc_fn_e121059d_000179_68d30882+0xc70>
  412622:	cs nop WORD PTR [rax+rax*1+0x0]
  41262c:	nop    DWORD PTR [rax+0x0]
  412630:	cmp    QWORD PTR [r13+rsi*8+0x0],r14
  412635:	jne    41265f <__swc_fn_e121059d_000179_68d30882+0xc5f>
  412637:	mov    rax,QWORD PTR [rbx+0x208]
  41263e:	mov    rax,QWORD PTR [rax+rsi*8]
  412642:	mov    rcx,QWORD PTR [rbx+0x228]
  412649:	add    rax,rcx
  41264c:	lea    rdx,[rcx+rdi*1]
  412650:	mov    rcx,rax
  412653:	mov    r8,r14
  412656:	call   410790 <__swc_fn_e121059d_000107_aba05410>
  41265b:	test   eax,eax
  41265d:	je     412670 <__swc_fn_e121059d_000179_68d30882+0xc70>
  41265f:	inc    rsi
  412662:	and    rsi,QWORD PTR [rbx+0x230]
  412669:	cmp    BYTE PTR [r15+rsi*1],0x0
  41266e:	jne    412630 <__swc_fn_e121059d_000179_68d30882+0xc30>
  412670:	cmp    BYTE PTR [r15+rsi*1],0x0
  412675:	je     41269c <__swc_fn_e121059d_000179_68d30882+0xc9c>
  412677:	mov    rdi,QWORD PTR [rsp+0x818]
  41267f:	mov    r14,QWORD PTR [rsp+0x820]
  412687:	mov    r15,QWORD PTR [rsp+0x828]
  41268f:	mov    r13,QWORD PTR [rsp+0x840]
  412697:	jmp    41272c <__swc_fn_e121059d_000179_68d30882+0xd2c>
  41269c:	mov    rcx,QWORD PTR [rbx+0x238]
  4126a3:	mov    rdx,QWORD PTR [rbx+0x220]
  4126aa:	mov    BYTE PTR [rdx+rsi*1],0x1
  4126ae:	mov    rdx,QWORD PTR [rbx+0x208]
  4126b5:	mov    QWORD PTR [rdx+rsi*8],rdi
  4126b9:	mov    rdx,QWORD PTR [rbx+0x210]
  4126c0:	mov    QWORD PTR [rdx+rsi*8],r14
  4126c4:	mov    rdx,QWORD PTR [rbx+0x218]
  4126cb:	mov    QWORD PTR [rdx+rsi*8],rcx
  4126cf:	add    QWORD PTR [rbx+0x238],0x1
  4126d7:	mov    QWORD PTR [r12+rcx*8],0x1
  4126df:	mov    rdi,QWORD PTR [rsp+0x818]
  4126e7:	mov    r13,QWORD PTR [rsp+0x840]
  4126ef:	mov    QWORD PTR [rdi+rcx*8],r13
  4126f3:	vmovq  xmm0,r13
  4126f8:	vpunpckldq xmm0,xmm0,xmm7
  4126fc:	vsubpd xmm0,xmm0,xmm8
  412701:	vpunpckhqdq xmm1,xmm0,xmm0
  412705:	vaddsd xmm0,xmm0,xmm1
  412709:	vmulsd xmm0,xmm0,xmm10
  41270e:	mov    r14,QWORD PTR [rsp+0x820]
  412716:	vmovq  QWORD PTR [r14+rcx*8],xmm0
  41271c:	mov    r15,QWORD PTR [rsp+0x828]
  412724:	vmovq  QWORD PTR [r15+rcx*8],xmm10
  41272a:	jmp    412774 <__swc_fn_e121059d_000179_68d30882+0xd74>
  41272c:	mov    rcx,QWORD PTR [rbx+0x218]
  412733:	mov    rcx,QWORD PTR [rcx+rsi*8]
  412737:	inc    QWORD PTR [r12+rcx*8]
  41273b:	add    QWORD PTR [rdi+rcx*8],r13
  41273f:	vmovq  xmm0,r13
  412744:	vpunpckldq xmm0,xmm0,xmm7
  412748:	vsubpd xmm0,xmm0,xmm8
  41274d:	vpunpckhqdq xmm1,xmm0,xmm0
  412751:	vaddsd xmm0,xmm0,xmm1
  412755:	vmulsd xmm0,xmm0,xmm10
  41275a:	vaddsd xmm0,xmm0,QWORD PTR [r14+rcx*8]
  412760:	vmovq  QWORD PTR [r14+rcx*8],xmm0
  412766:	vcomisd xmm10,QWORD PTR [r15+rcx*8]
  41276c:	jbe    412774 <__swc_fn_e121059d_000179_68d30882+0xd74>
  41276e:	vmovq  QWORD PTR [r15+rcx*8],xmm10
  412774:	mov    rsi,QWORD PTR [rsp+0x830]
  41277c:	add    rsi,0x1
  412780:	mov    rcx,QWORD PTR [rsp+0x838]
  412788:	mov    QWORD PTR [rsp+0x830],rsi
  412790:	inc    rcx
  412793:	mov    rsi,QWORD PTR [rsp+0x7a8]
  41279b:	mov    rdi,QWORD PTR [rsp+0x808]
  4127a3:	cmp    rcx,rdi
  4127a6:	jb     412280 <__swc_fn_e121059d_000179_68d30882+0x880>
  4127ac:	lea    r13,[rbx+0x320]
  4127b3:	mov    QWORD PTR [rsp+0x848],r13
  4127bb:	vxorps xmm0,xmm0,xmm0
  4127bf:	xor    ecx,ecx
  4127c1:	cs nop WORD PTR [rax+rax*1+0x0]
  4127cb:	cs nop WORD PTR [rax+rax*1+0x0]
  4127d5:	cs nop WORD PTR [rax+rax*1+0x0]
  4127df:	nop
  4127e0:	vmovdqu XMMWORD PTR [r13+rcx*1+0x0],xmm0
  4127e7:	add    rcx,0x10
  4127eb:	cmp    rcx,0x200
  4127f2:	jne    4127e0 <__swc_fn_e121059d_000179_68d30882+0xde0>
  4127f4:	lea    r15,[rbx+0x520]
  4127fb:	vxorps xmm0,xmm0,xmm0
  4127ff:	xor    ecx,ecx
  412801:	cs nop WORD PTR [rax+rax*1+0x0]
  41280b:	cs nop WORD PTR [rax+rax*1+0x0]
  412815:	cs nop WORD PTR [rax+rax*1+0x0]
  41281f:	nop
  412820:	vmovdqu XMMWORD PTR [r15+rcx*1],xmm0
  412826:	add    rcx,0x10
  41282a:	cmp    rcx,0x200
  412831:	jne    412820 <__swc_fn_e121059d_000179_68d30882+0xe20>
  412833:	xor    edi,edi
  412835:	xor    ecx,ecx
  412837:	mov    rsi,rdi
  41283a:	cs nop WORD PTR [rax+rax*1+0x0]
  412844:	cs nop WORD PTR [rax+rax*1+0x0]
  41284e:	xchg   ax,ax
  412850:	mov    rdx,QWORD PTR [rbx+0x220]
  412857:	cmp    BYTE PTR [rdx+rcx*1],0x0
  41285b:	je     412867 <__swc_fn_e121059d_000179_68d30882+0xe67>
  41285d:	mov    QWORD PTR [r15+rdi*8],rcx
  412861:	inc    rdi
  412864:	mov    rsi,rdi
  412867:	add    rcx,0x1
  41286b:	cmp    rcx,0x40
  41286f:	jb     412850 <__swc_fn_e121059d_000179_68d30882+0xe50>
  412871:	mov    QWORD PTR [rsp+0x850],rsi
  412879:	xor    ecx,ecx
  41287b:	test   rdi,rdi
  41287e:	jbe    41288e <__swc_fn_e121059d_000179_68d30882+0xe8e>
  412880:	mov    QWORD PTR [r13+rcx*8+0x0],rcx
  412885:	add    rcx,0x1
  412889:	cmp    rcx,rdi
  41288c:	jb     412880 <__swc_fn_e121059d_000179_68d30882+0xe80>
  41288e:	xor    r12d,r12d
  412891:	mov    QWORD PTR [rsp+0x858],r12
  412899:	test   rdi,rdi
  41289c:	mov    r14,QWORD PTR [rsp+0x7a8]
  4128a4:	mov    rcx,rdi
  4128a7:	jbe    4129ce <__swc_fn_e121059d_000179_68d30882+0xfce>
  4128ad:	nop    DWORD PTR [rax]
  4128b0:	mov    rsi,r12
  4128b3:	xor    r9d,r9d
  4128b6:	test   rdi,rdi
  4128b9:	mov    rdi,r9
  4128bc:	ja     4128cb <__swc_fn_e121059d_000179_68d30882+0xecb>
  4128be:	mov    rcx,QWORD PTR [rsp+0x850]
  4128c6:	jmp    412992 <__swc_fn_e121059d_000179_68d30882+0xf92>
  4128cb:	cs nop WORD PTR [rax+rax*1+0x0]
  4128d5:	cs nop WORD PTR [rax+rax*1+0x0]
  4128df:	nop
  4128e0:	cmp    rdi,r12
  4128e3:	jbe    41296c <__swc_fn_e121059d_000179_68d30882+0xf6c>
  4128e9:	mov    rax,QWORD PTR [r13+rsi*8+0x0]
  4128ee:	mov    r12,QWORD PTR [r15+rax*8]
  4128f2:	mov    rax,QWORD PTR [r13+rdi*8+0x0]
  4128f7:	mov    r13,QWORD PTR [r15+rax*8]
  4128fb:	mov    rax,QWORD PTR [rbx+0x210]
  412902:	mov    rcx,QWORD PTR [rax+r12*8]
  412906:	mov    r8,rcx
  412909:	mov    rax,QWORD PTR [rax+r13*8]
  41290d:	cmp    rax,rcx
  412910:	jae    412920 <__swc_fn_e121059d_000179_68d30882+0xf20>
  412912:	mov    rax,QWORD PTR [rbx+0x210]
  412919:	mov    rax,QWORD PTR [rax+r13*8]
  41291d:	mov    r8,rax
  412920:	mov    rax,QWORD PTR [rbx+0x208]
  412927:	mov    rcx,QWORD PTR [rax+r13*8]
  41292b:	add    rcx,r14
  41292e:	mov    rax,QWORD PTR [rax+r12*8]
  412932:	lea    rdx,[rax+r14*1]
  412936:	call   410790 <__swc_fn_e121059d_000107_aba05410>
  41293b:	mov    rcx,rax
  41293e:	test   eax,eax
  412940:	setl   dl
  412943:	jl     412966 <__swc_fn_e121059d_000179_68d30882+0xf66>
  412945:	test   ecx,ecx
  412947:	sete   cl
  41294a:	movzx  ecx,cl
  41294d:	jne    412964 <__swc_fn_e121059d_000179_68d30882+0xf64>
  41294f:	mov    rcx,QWORD PTR [rbx+0x210]
  412956:	mov    rdx,QWORD PTR [rcx+r12*8]
  41295a:	cmp    QWORD PTR [rcx+r13*8],rdx
  41295e:	setb   cl
  412961:	movzx  ecx,cl
  412964:	mov    dl,cl
  412966:	test   dl,dl
  412968:	cmovne rsi,rdi
  41296c:	add    rdi,0x1
  412970:	mov    rcx,QWORD PTR [rsp+0x850]
  412978:	cmp    rdi,rcx
  41297b:	jae    412992 <__swc_fn_e121059d_000179_68d30882+0xf92>
  41297d:	mov    r13,QWORD PTR [rsp+0x848]
  412985:	mov    r12,QWORD PTR [rsp+0x858]
  41298d:	jmp    4128e0 <__swc_fn_e121059d_000179_68d30882+0xee0>
  412992:	mov    r13,QWORD PTR [rsp+0x848]
  41299a:	mov    r12,QWORD PTR [rsp+0x858]
  4129a2:	mov    rdx,QWORD PTR [r13+r12*8+0x0]
  4129a7:	mov    r8,QWORD PTR [r13+rsi*8+0x0]
  4129ac:	mov    QWORD PTR [r13+r12*8+0x0],r8
  4129b1:	mov    QWORD PTR [r13+rsi*8+0x0],rdx
  4129b6:	add    r12,0x1
  4129ba:	mov    QWORD PTR [rsp+0x858],r12
  4129c2:	cmp    r12,rcx
  4129c5:	mov    rdi,rcx
  4129c8:	jb     4128b0 <__swc_fn_e121059d_000179_68d30882+0xeb0>
  4129ce:	mov    rsi,QWORD PTR [rsp+0x830]
  4129d6:	xor    edx,edx
  4129d8:	test   rcx,rcx
  4129db:	jbe    412b09 <__swc_fn_e121059d_000179_68d30882+0x1109>
  4129e1:	mov    r8,QWORD PTR [rbx+0x218]
  4129e8:	vmovsd xmm0,QWORD PTR [rip+0xbc4]        # 4135b4 <__swc_rdata_base_e121059d+0x4a4>
  4129f0:	vmovsd xmm1,QWORD PTR [rip+0xbaa]        # 4135a2 <__swc_rdata_base_e121059d+0x492>
  4129f8:	mov    r12,QWORD PTR [rsp+0x810]
  412a00:	mov    rdi,QWORD PTR [rsp+0x818]
  412a08:	mov    r14,QWORD PTR [rsp+0x820]
  412a10:	mov    r9,QWORD PTR [rsp+0x828]
  412a18:	vmovups xmm2,xmm1
  412a1c:	vmovsd xmm4,QWORD PTR [rsp+0x848]
  412a25:	vmovq  xmm5,r8
  412a2a:	nop    WORD PTR [rax+rax*1+0x0]
  412a30:	mov    r10,QWORD PTR [r13+rdx*8+0x0]
  412a35:	mov    r10,QWORD PTR [r15+r10*8]
  412a39:	mov    r10,QWORD PTR [r8+r10*8]
  412a3d:	lea    r11,[rdx+0x1]
  412a41:	vmovq  xmm3,QWORD PTR [r14+r10*8]
  412a47:	vfmadd213sd xmm3,xmm9,xmm0
  412a4c:	vcomisd xmm3,xmm1
  412a50:	jb     412a6a <__swc_fn_e121059d_000179_68d30882+0x106a>
  412a52:	vsubsd xmm3,xmm3,xmm1
  412a56:	vcvttsd2si rdx,xmm3
  412a5b:	movabs r8,0x8000000000000000
  412a65:	xor    rdx,r8
  412a68:	jmp    412a6f <__swc_fn_e121059d_000179_68d30882+0x106f>
  412a6a:	vcvttsd2si rdx,xmm3
  412a6f:	mov    rax,rdx
  412a72:	mov    QWORD PTR [rsp+0x868],rdx
  412a7a:	movabs rdx,0xc6f45449cb59c69
  412a84:	mov    r13,QWORD PTR [rsp+0x868]
  412a8c:	mul    rdx
  412a8f:	mov    r8,rdx
  412a92:	mov    rdx,r13
  412a95:	sub    rdx,r8
  412a98:	shr    rdx,1
  412a9b:	add    rdx,r8
  412a9e:	shr    rdx,0x13
  412aa2:	imul   r8,rdx,0xf4243
  412aa9:	sub    r13,r8
  412aac:	mov    rdx,r11
  412aaf:	imul   rdx,r13
  412ab3:	add    rsi,rdx
  412ab6:	mov    rdx,QWORD PTR [r12+r10*8]
  412aba:	add    rdx,QWORD PTR [rdi+r10*8]
  412abe:	vmovq  xmm3,QWORD PTR [r9+r10*8]
  412ac4:	vfmadd213sd xmm3,xmm9,xmm0
  412ac9:	vcomisd xmm3,xmm2
  412acd:	jb     412ae7 <__swc_fn_e121059d_000179_68d30882+0x10e7>
  412acf:	vsubsd xmm3,xmm3,xmm2
  412ad3:	vcvttsd2si r8,xmm3
  412ad8:	movabs r10,0x8000000000000000
  412ae2:	xor    r8,r10
  412ae5:	jmp    412aec <__swc_fn_e121059d_000179_68d30882+0x10ec>
  412ae7:	vcvttsd2si r8,xmm3
  412aec:	add    rdx,r8
  412aef:	add    rsi,rdx
  412af2:	mov    rdx,r11
  412af5:	cmp    r11,rcx
  412af8:	jae    412b09 <__swc_fn_e121059d_000179_68d30882+0x1109>
  412afa:	vmovq  r13,xmm4
  412aff:	vmovq  r8,xmm5
  412b04:	jmp    412a30 <__swc_fn_e121059d_000179_68d30882+0x1030>
  412b09:	call   40eaf0 <__swc_fn_e121059d_000178_1ca87929>
  412b0e:	vsubsd xmm0,xmm0,xmm6
  412b12:	vmulsd xmm0,xmm0,QWORD PTR [rip+0xf5f]        # 413a79 <__swc_rdata_base_e121059d+0x969>
  412b1a:	lea    rax,[rip+0x847]        # 413368 <__swc_rdata_base_e121059d+0x258>
  412b21:	sub    rsp,0x88
  412b28:	mov    rcx,rsp
  412b2b:	vmovups xmm1,XMMWORD PTR [rip+0xf1d]        # 413a50 <__swc_rdata_base_e121059d+0x940>
  412b33:	vmovups XMMWORD PTR [rcx],xmm1
  412b37:	mov    QWORD PTR [rcx+0x30],rsp
  412b3b:	lea    rdx,[rip+0x7ce]        # 413310 <__swc_rdata_base_e121059d+0x200>
  412b42:	mov    QWORD PTR [rcx+0x38],rdx
  412b46:	mov    QWORD PTR [rcx+0x10],rsi
  412b4a:	lea    r8,[rsp+0x10]
  412b4f:	mov    QWORD PTR [rcx+0x40],r8
  412b53:	lea    r8,[rip+0xe3e]        # 413998 <__swc_rdata_base_e121059d+0x888>
  412b5a:	mov    QWORD PTR [rcx+0x48],r8
  412b5e:	vmovups xmm1,XMMWORD PTR [rip+0xefa]        # 413a60 <__swc_rdata_base_e121059d+0x950>
  412b66:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  412b6b:	lea    r8,[rsp+0x18]
  412b70:	mov    QWORD PTR [rcx+0x50],r8
  412b74:	mov    QWORD PTR [rcx+0x58],rdx
  412b78:	vmovsd QWORD PTR [rcx+0x28],xmm0
  412b7d:	lea    r8,[rcx+0x28]
  412b81:	mov    QWORD PTR [rcx+0x60],r8
  412b85:	lea    r8,[rip+0xe54]        # 4139e0 <__swc_rdata_base_e121059d+0x8d0>
  412b8c:	mov    QWORD PTR [rcx+0x68],r8
  412b90:	mov    QWORD PTR [rcx+0x70],rax
  412b94:	mov    QWORD PTR [rcx+0x78],rdx
  412b98:	lea    rax,[rcx+0x30]
  412b9c:	mov    QWORD PTR [rcx+0x80],rax
  412ba3:	mov    QWORD PTR [rcx+0x88],0x5
  412bae:	lea    rcx,[rcx+0x80]
  412bb5:	sub    rsp,0x8
  412bb9:	call   40a0e0 <__swc_fn_e121059d_000147_d2097256>
  412bbe:	add    rsp,0x948
  412bc5:	vmovups xmm6,XMMWORD PTR [rsp]
  412bca:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  412bd0:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  412bd6:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  412bdc:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  412be2:	add    rsp,0x50
  412be6:	pop    r15
  412be8:	pop    r14
  412bea:	pop    r13
  412bec:	pop    r12
  412bee:	pop    rdi
  412bef:	pop    rsi
  412bf0:	pop    rbx
  412bf1:	pop    rbp
  412bf2:	ret
