import sys,re,collections,json,difflib
from pathlib import Path
sys.path.insert(0,'/workspace/swc-codegen-20261115/bench/scripts')
import microdiff as m
root=Path(sys.argv[1])
def name(s):
 s=re.sub(r'#\d+$','',s)
 return re.sub(r'(__lambda_|__run_expr_)[0-9a-f]+',r'\1HASH',s)
def normalized(body):return tuple(name(x) for x in m.normalized(body))
summary={}
for task in m.tc.TASKS:
 a=m.parse((root/'base'/task/'micro.txt').read_text());b=m.parse((root/'new'/task/'micro.txt').read_text())
 old=collections.defaultdict(collections.Counter);new=collections.defaultdict(collections.Counter)
 for key,body in a.items():old[name(key)][normalized(body)]+=1
 for key,body in b.items():new[name(key)][normalized(body)]+=1
 changed=[key for key in sorted(set(old)|set(new)) if old[key]!=new[key]]
 print(task,'real changes',changed);summary[task]=changed
 for key in changed:
  aa=list((old[key]-new[key]).elements());bb=list((new[key]-old[key]).elements())
  for x,y in zip(aa,bb):
   print('\n'.join(difflib.unified_diff(x,y,'base/'+key,'new/'+key,n=4)))
(root/'normalized-changes.json').write_text(json.dumps(summary,indent=2)+'\n')
