
/workspace/prompt2-20261115/session-combined-micro/base/csvagg/csvagg:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <open@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <open@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <flock@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <flock@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <__errno_location@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <__errno_location@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <close@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <close@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <getpid@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <getpid@GLIBC_2.2.5>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <opendir@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <opendir@GLIBC_2.2.5>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <dirfd@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <dirfd@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <readdir@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <readdir@GLIBC_2.2.5>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <readlinkat@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <readlinkat@GLIBC_2.4>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <openat@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <openat@GLIBC_2.4>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <closedir@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <closedir@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <lseek@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <lseek@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <mmap@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <mmap@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <memfd_create@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <memfd_create@GLIBC_2.27>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <ftruncate@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf8a]        # 413080 <ftruncate@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <write@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf82]        # 413088 <write@GLIBC_2.2.5>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <backtrace@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf7a]        # 413090 <backtrace@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <pthread_setspecific@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf72]        # 413098 <pthread_setspecific@GLIBC_2.34>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <clock_gettime@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf6a]        # 4130a0 <clock_gettime@GLIBC_2.17>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <__x86_get_cpuid_feature_leaf@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf62]        # 4130a8 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <free@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf5a]        # 4130b0 <free@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <munmap@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <munmap@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <mprotect@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <mprotect@GLIBC_2.2.5>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <exit@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <exit@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <pthread_key_create@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <pthread_key_create@GLIBC_2.34>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <syscall@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <syscall@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <dladdr@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <dladdr@GLIBC_2.34>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <malloc@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <malloc@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <madvise@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <madvise@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <pthread_key_delete@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <pthread_key_delete@GLIBC_2.34>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <gettid@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <gettid@GLIBC_2.30>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_e121059d_000179_68d30882+0x1520>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   410e80 <__swc_fn_e121059d_000122_12b4ed22>
  40724e:	xor    ecx,ecx
  407250:	call   40d680 <__swc_fn_e121059d_000094_14db3cf9>
  407255:	call   411ae0 <__swc_fn_e121059d_000179_68d30882>
  40725a:	call   4104d0 <__swc_fn_e121059d_000095_337e587a>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_e121059d_000000_46f18a51>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_e121059d_000003_7ab4792e>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_e121059d_000003_7ab4792e+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   40daa0 <__swc_fn_e121059d_000112_b25e3a45>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_e121059d_000003_7ab4792e+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_e121059d+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_e121059d+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_e121059d_000003_7ab4792e+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_e121059d_000003_7ab4792e+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_e121059d+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_e121059d+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_e121059d_000003_7ab4792e+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_e121059d_000003_7ab4792e+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_e121059d_000006_a23dca5f>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40ed80 <__swc_fn_e121059d_000011_6493fbbc>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_e121059d_000012_c7df5d22>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_e121059d_000006_a23dca5f+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_e121059d_000003_7ab4792e>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_e121059d_000006_a23dca5f+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_e121059d_000009_d7e2bb25>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_e121059d_000009_d7e2bb25+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40ba10 <__swc_fn_e121059d_000007_614a4804>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40ed70 <__swc_fn_e121059d_000008_4e857afc>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_e121059d_000009_d7e2bb25+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_e121059d_000009_d7e2bb25+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_e121059d_000012_c7df5d22>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_e121059d_000015_07eb9884>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_e121059d_000015_07eb9884+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_e121059d_000015_07eb9884+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_e121059d_000015_07eb9884+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_e121059d_000015_07eb9884+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40eee0 <__swc_fn_e121059d_000017_4df2d1a0>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_e121059d_000015_07eb9884+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_e121059d+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_e121059d+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_e121059d_000015_07eb9884+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_e121059d_000015_07eb9884+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40ed80 <__swc_fn_e121059d_000011_6493fbbc>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_e121059d_000015_07eb9884+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   410b90 <__swc_fn_e121059d_000113_759e9ceb>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_e121059d+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_e121059d+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_e121059d_000015_07eb9884+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_e121059d_000015_07eb9884+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_e121059d+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_e121059d+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_e121059d_000015_07eb9884+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_e121059d_000015_07eb9884+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_e121059d_000018_7d1e8a10>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_e121059d_000015_07eb9884+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_e121059d_000018_7d1e8a10>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_e121059d_000018_7d1e8a10+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_e121059d_000018_7d1e8a10+0x10>

0000000000407630 <__swc_fn_e121059d_000021_491ac000>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_e121059d_000015_07eb9884>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_e121059d+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   40e100 <__swc_fn_e121059d_000136_e3032dc2>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_e121059d+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_e121059d+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_e121059d_000024_4aca8b9e>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_e121059d_000027_4aca8b9e>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_e121059d_000030_06a93956>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_e121059d_000030_06a93956+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_e121059d>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_e121059d_000030_06a93956+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_e121059d_000030_06a93956+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_e121059d_000030_06a93956+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40f0a0 <__swc_fn_e121059d_000032_84881cd8>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_e121059d_000030_06a93956+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_e121059d_000036_8d895ba1>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_e121059d_000030_06a93956+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_e121059d_000042_bab03645>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_e121059d_000033_7ca1566d>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40bec0 <__swc_fn_e121059d_000031_90860ff2>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   40df80 <__swc_fn_e121059d_000130_74b163fe>
  407734:	mov    rcx,rsi
  407737:	call   40f0a0 <__swc_fn_e121059d_000032_84881cd8>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_e121059d_000036_8d895ba1>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_e121059d_000039_40d1e569>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_e121059d_000039_40d1e569+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_e121059d_000039_40d1e569+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_e121059d_000039_40d1e569+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_e121059d_000039_40d1e569+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_e121059d_000039_40d1e569+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   40db80 <__swc_fn_e121059d_000115_27d95464>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_e121059d+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_e121059d+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_e121059d_000039_40d1e569+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_e121059d_000039_40d1e569+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_e121059d+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_e121059d+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_e121059d_000039_40d1e569+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_e121059d_000039_40d1e569+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_e121059d_000042_bab03645>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_e121059d_000042_bab03645+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40f670 <__swc_fn_e121059d_000059_3ca3ac64>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   40e100 <__swc_fn_e121059d_000136_e3032dc2>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_e121059d_000042_bab03645+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_e121059d_000042_bab03645+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_e121059d_000009_d7e2bb25>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_e121059d_000042_bab03645+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40eda0 <__swc_fn_e121059d_000014_afb279e2>
  40791e:	jmp    407941 <__swc_fn_e121059d_000042_bab03645+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_e121059d_000042_bab03645+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_e121059d_000042_bab03645+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_e121059d_000042_bab03645+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40c080 <__swc_fn_e121059d_000043_957e4917>
  407997:	mov    rcx,rdi
  40799a:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_e121059d_000039_40d1e569>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_e121059d_000045_1fe0f4e2>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_e121059d_000045_1fe0f4e2+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_e121059d_000045_1fe0f4e2+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_e121059d_000045_1fe0f4e2+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_e121059d_000045_1fe0f4e2+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   40e100 <__swc_fn_e121059d_000136_e3032dc2>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_e121059d_000045_1fe0f4e2+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_e121059d_000045_1fe0f4e2+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_e121059d_000045_1fe0f4e2+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_e121059d_000045_1fe0f4e2+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_e121059d_000009_d7e2bb25>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_e121059d_000045_1fe0f4e2+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_e121059d_000045_1fe0f4e2+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_e121059d_000045_1fe0f4e2+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_e121059d_000045_1fe0f4e2+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_e121059d_000045_1fe0f4e2+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40bac0 <__swc_fn_e121059d_000013_9ba72deb>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_e121059d_000045_1fe0f4e2+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_e121059d_000045_1fe0f4e2+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_e121059d_000045_1fe0f4e2+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_e121059d_000045_1fe0f4e2+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40ef20 <__swc_fn_e121059d_000020_a66e8b97>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_e121059d_000045_1fe0f4e2+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40bac0 <__swc_fn_e121059d_000013_9ba72deb>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_e121059d_000045_1fe0f4e2+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_e121059d_000021_491ac000>
  407c07:	mov    rcx,r14
  407c0a:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_e121059d_000045_1fe0f4e2+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_e121059d_000045_1fe0f4e2+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_e121059d_000045_1fe0f4e2+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_e121059d_000048_c877e9d2>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_e121059d_000048_c877e9d2+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_e121059d_000048_c877e9d2+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_e121059d_000048_c877e9d2+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_e121059d_000048_c877e9d2+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40f2d0 <__swc_fn_e121059d_000047_bc5ec610>
  407d14:	jmp    407ce0 <__swc_fn_e121059d_000048_c877e9d2+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_e121059d_000048_c877e9d2+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_e121059d_000048_c877e9d2+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_e121059d_000048_c877e9d2+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_e121059d_000048_c877e9d2+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_e121059d_000048_c877e9d2+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_e121059d_000048_c877e9d2+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_e121059d_000048_c877e9d2+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_e121059d_000051_f7021588>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_e121059d_000051_f7021588+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_e121059d_000051_f7021588+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_e121059d_000051_f7021588+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_e121059d_000051_f7021588+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40f230 <__swc_fn_e121059d_000044_9c2ade9b>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40eda0 <__swc_fn_e121059d_000014_afb279e2>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_e121059d_000054_ae20ea33>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   40e100 <__swc_fn_e121059d_000136_e3032dc2>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_e121059d_000054_ae20ea33+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_e121059d_000054_ae20ea33+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_e121059d_000054_ae20ea33+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_e121059d_000057_5b81d8b6>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_e121059d_000060_e6407a0a>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_e121059d_000060_e6407a0a+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_e121059d_000039_40d1e569>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_e121059d_000060_e6407a0a+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_e121059d_000063_c8a062d6>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40c400 <__swc_fn_e121059d_000052_c7484fb0>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_e121059d_000054_ae20ea33>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_e121059d_000063_c8a062d6+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_e121059d_000063_c8a062d6+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40c520 <__swc_fn_e121059d_000058_8bd8d1d5>
  407f7f:	mov    rcx,rsi
  407f82:	call   40c160 <__swc_fn_e121059d_000049_2ff013cc>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_e121059d_000066_254b71af>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_e121059d_000066_254b71af+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_e121059d+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_e121059d+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_e121059d_000066_254b71af+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_e121059d_000066_254b71af+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40bdf0 <__swc_fn_e121059d_000022_3a2e2048>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_e121059d_000066_254b71af+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_e121059d_000063_c8a062d6>
  40808f:	jmp    408122 <__swc_fn_e121059d_000066_254b71af+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_e121059d>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_e121059d_000066_254b71af+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_e121059d_000066_254b71af+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_e121059d_000066_254b71af+0x135>
  4080b8:	call   40bec0 <__swc_fn_e121059d_000031_90860ff2>
  4080bd:	mov    rcx,rax
  4080c0:	call   409c00 <__swc_fn_e121059d_000129_41c3251c>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_e121059d_000066_254b71af+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_e121059d_000066_254b71af+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_e121059d_000066_254b71af+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40f2d0 <__swc_fn_e121059d_000047_bc5ec610>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_e121059d_000066_254b71af+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_e121059d_000051_f7021588>
  408115:	jmp    408122 <__swc_fn_e121059d_000066_254b71af+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40ba30 <__swc_fn_e121059d_000010_395bb04b>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_e121059d_000069_e681a956>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_e121059d_000036_8d895ba1>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_e121059d_000069_e681a956+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_e121059d+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_e121059d_000069_e681a956+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   40e100 <__swc_fn_e121059d_000136_e3032dc2>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40faa0 <__swc_fn_e121059d_000068_7d4c42bf>
  4081bd:	mov    rcx,rsi
  4081c0:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_e121059d_000072_bfa08900>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40f7f0 <__swc_fn_e121059d_000065_f9f4b610>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_e121059d_000075_524b0734>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40faa0 <__swc_fn_e121059d_000068_7d4c42bf>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_e121059d_000078_a120bd2b>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_e121059d_000078_a120bd2b+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_e121059d_000078_a120bd2b+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_e121059d_000081_c25a0e73>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_e121059d_000084_ddf2b8a1>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_e121059d_000090_a2d50c23>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_e121059d_000084_ddf2b8a1+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_e121059d_000084_ddf2b8a1+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_e121059d_000084_ddf2b8a1+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_e121059d_000084_ddf2b8a1+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_e121059d_000090_a2d50c23>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_e121059d_000084_ddf2b8a1+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_e121059d_000084_ddf2b8a1+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_e121059d_000084_ddf2b8a1+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_e121059d_000084_ddf2b8a1+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_e121059d_000084_ddf2b8a1+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_e121059d_000084_ddf2b8a1+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_e121059d_000084_ddf2b8a1+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_e121059d_000084_ddf2b8a1+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_e121059d_000084_ddf2b8a1+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_e121059d_000084_ddf2b8a1+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40d500 <__swc_fn_e121059d_000082_754dcd57>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_e121059d_000084_ddf2b8a1+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_e121059d_000084_ddf2b8a1+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_e121059d_000084_ddf2b8a1+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40d500 <__swc_fn_e121059d_000082_754dcd57>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_e121059d_000084_ddf2b8a1+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_e121059d_000084_ddf2b8a1>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_e121059d_000084_ddf2b8a1+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_e121059d_000084_ddf2b8a1+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_e121059d_000087_ea575bb3>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_e121059d_000090_a2d50c23>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_e121059d_000087_ea575bb3+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40ff00 <__swc_fn_e121059d_000086_c45095aa>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_e121059d_000087_ea575bb3+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_e121059d_000087_ea575bb3+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_e121059d_000087_ea575bb3+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40d500 <__swc_fn_e121059d_000082_754dcd57>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_e121059d_000087_ea575bb3+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_e121059d_000087_ea575bb3>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_e121059d_000087_ea575bb3+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_e121059d_000087_ea575bb3+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_e121059d_000090_a2d50c23>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_e121059d_000090_a2d50c23+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_e121059d_000090_a2d50c23+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_e121059d_000090_a2d50c23+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_e121059d_000090_a2d50c23+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40d500 <__swc_fn_e121059d_000082_754dcd57>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40d500 <__swc_fn_e121059d_000082_754dcd57>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_e121059d_000090_a2d50c23+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_e121059d_000090_a2d50c23+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_e121059d_000090_a2d50c23+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_e121059d_000090_a2d50c23+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_e121059d_000090_a2d50c23>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_e121059d_000090_a2d50c23+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_e121059d_000090_a2d50c23+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_e121059d_000090_a2d50c23+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_e121059d_000090_a2d50c23+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_e121059d_000090_a2d50c23+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_e121059d_000090_a2d50c23+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_e121059d_000090_a2d50c23+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_e121059d_000090_a2d50c23+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_e121059d_000090_a2d50c23+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_e121059d_000090_a2d50c23+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_e121059d_000090_a2d50c23+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_e121059d_000090_a2d50c23+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_e121059d_000090_a2d50c23+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_e121059d_000090_a2d50c23+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_e121059d_000090_a2d50c23+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_e121059d_000090_a2d50c23+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   40e620 <__swc_fn_e121059d_000148_32a497f3>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_e121059d_000090_a2d50c23+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_e121059d_000090_a2d50c23>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_e121059d_000090_a2d50c23+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_e121059d_000090_a2d50c23+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_e121059d_000090_a2d50c23+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   40e620 <__swc_fn_e121059d_000148_32a497f3>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   40e620 <__swc_fn_e121059d_000148_32a497f3>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_e121059d_000093_f8c16535>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40d630 <__swc_fn_e121059d_000091_3d2f5a0d>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_e121059d_000093_f8c16535+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_e121059d_000093_f8c16535+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   409da0 <__swc_fn_e121059d_000138_a4ba10ed>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_e121059d_000093_f8c16535+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_e121059d+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   4098c0 <__swc_fn_e121059d_000117_035d76a1>
  408959:	call   410dc0 <__swc_fn_e121059d_000119_7f430081>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_e121059d_000096_ad982b35>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40896f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408975:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40897b:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  408981:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  408987:	mov    QWORD PTR [rsp+0x48],rdx
  40898c:	mov    rax,r8
  40898f:	cmp    r8,0x1
  408993:	mov    edx,0x1
  408998:	cmovb  rax,rdx
  40899c:	mov    QWORD PTR [rsp+0x50],rax
  4089a1:	mov    rbx,QWORD PTR [rcx+0x8]
  4089a5:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a9:	mov    rcx,QWORD PTR [rcx]
  4089ac:	lea    rdx,[rsp+0x8]
  4089b1:	call   rbx
  4089b3:	add    rsp,0x70
  4089b7:	pop    rbx
  4089b8:	ret
  4089b9:	add    BYTE PTR [rax],al
  4089bb:	add    BYTE PTR [rax],al
  4089bd:	add    BYTE PTR [rax],al
	...

00000000004089c0 <__swc_fn_e121059d_000099_b4c6da83>:
  4089c0:	push   rbx
  4089c1:	push   rsi
  4089c2:	push   rdi
  4089c3:	sub    rsp,0x30
  4089c7:	mov    rbx,rcx
  4089ca:	test   rcx,rcx
  4089cd:	je     4089e2 <__swc_fn_e121059d_000099_b4c6da83+0x22>
  4089cf:	mov    rcx,rbx
  4089d2:	mov    edx,0x1
  4089d7:	call   408200 <__swc_fn_e121059d_000078_a120bd2b>
  4089dc:	cmp    rax,0x1
  4089e0:	je     4089ea <__swc_fn_e121059d_000099_b4c6da83+0x2a>
  4089e2:	add    rsp,0x30
  4089e6:	pop    rdi
  4089e7:	pop    rsi
  4089e8:	pop    rbx
  4089e9:	ret
  4089ea:	lea    rsi,[rsp+0x8]
  4089ef:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089f4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089fa:	lea    rax,[rsp+0x18]
  4089ff:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  408a04:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408a0a:	mov    rcx,QWORD PTR [rsp+0x20]
  408a0f:	test   rcx,rcx
  408a12:	je     408a28 <__swc_fn_e121059d_000099_b4c6da83+0x68>
  408a14:	test   DWORD PTR [rcx+0x28],0x400000
  408a1b:	je     408a28 <__swc_fn_e121059d_000099_b4c6da83+0x68>
  408a1d:	mov    rdx,QWORD PTR [rcx+0x30]
  408a21:	test   rdx,rdx
  408a24:	cmovne rcx,rdx
  408a28:	mov    edi,DWORD PTR [rcx+0x20]
  408a2b:	mov    rcx,rax
  408a2e:	call   40d810 <__swc_fn_e121059d_000100_3ed08774>
  408a33:	mov    rcx,rsi
  408a36:	mov    rdx,QWORD PTR [rsp+0x18]
  408a3b:	mov    r8,rdi
  408a3e:	call   408960 <__swc_fn_e121059d_000096_ad982b35>
  408a43:	mov    rcx,QWORD PTR [rbx+0x28]
  408a47:	call   4104e0 <__swc_fn_e121059d_000098_00f01091>
  408a4c:	mov    rcx,rsi
  408a4f:	mov    rdx,rbx
  408a52:	mov    r8d,0x30
  408a58:	call   408960 <__swc_fn_e121059d_000096_ad982b35>
  408a5d:	add    rsp,0x30
  408a61:	pop    rdi
  408a62:	pop    rsi
  408a63:	pop    rbx
  408a64:	ret
	...

0000000000408a80 <__swc_fn_e121059d_000102_e9fdc18e>:
  408a80:	push   rbp
  408a81:	push   rbx
  408a82:	push   rsi
  408a83:	push   rdi
  408a84:	push   r12
  408a86:	push   r13
  408a88:	push   r14
  408a8a:	push   r15
  408a8c:	sub    rsp,0x500
  408a93:	mov    rbp,rsp
  408a96:	mov    rbx,rsp
  408a99:	mov    rsi,rdx
  408a9c:	mov    rdi,rcx
  408a9f:	mov    rcx,QWORD PTR [rip+0x1e29a]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  408aa6:	test   rcx,rcx
  408aa9:	jne    408ac3 <__swc_fn_e121059d_000102_e9fdc18e+0x43>
  408aab:	sub    rsp,0x8
  408aaf:	call   40ea10 <__swc_fn_e121059d_000166_cf398896>
  408ab4:	add    rsp,0x8
  408ab8:	lea    rcx,[rax+0x1]
  408abc:	mov    QWORD PTR [rip+0x1e27d],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  408ac3:	dec    rcx
  408ac6:	sub    rsp,0x8
  408aca:	call   40b6c0 <__swc_fn_e121059d_000168_fce60b2b>
  408acf:	add    rsp,0x8
  408ad3:	mov    r12,rax
  408ad6:	mov    QWORD PTR [rsp+0x4f0],rax
  408ade:	lea    rax,[rip+0xa81b]        # 413300 <__swc_rdata_base_e121059d+0x1f0>
  408ae5:	sub    rsp,0x20
  408ae9:	mov    rcx,rsp
  408aec:	mov    QWORD PTR [rcx],rax
  408aef:	lea    r13,[rip+0xa81a]        # 413310 <__swc_rdata_base_e121059d+0x200>
  408af6:	mov    QWORD PTR [rcx+0x8],r13
  408afa:	mov    QWORD PTR [rcx+0x10],rsp
  408afe:	mov    QWORD PTR [rcx+0x18],0x1
  408b06:	lea    rcx,[rsp+0x10]
  408b0b:	sub    rsp,0x8
  408b0f:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  408b14:	add    rsp,0x8
  408b18:	add    rsp,0x20
  408b1c:	lea    rax,[rip+0xa835]        # 413358 <__swc_rdata_base_e121059d+0x248>
  408b23:	sub    rsp,0x20
  408b27:	mov    rcx,rsp
  408b2a:	mov    QWORD PTR [rcx],rax
  408b2d:	mov    QWORD PTR [rcx+0x8],r13
  408b31:	mov    QWORD PTR [rcx+0x10],rsp
  408b35:	mov    QWORD PTR [rcx+0x18],0x1
  408b3d:	lea    rcx,[rsp+0x10]
  408b42:	sub    rsp,0x8
  408b46:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  408b4b:	add    rsp,0x8
  408b4f:	add    rsp,0x20
  408b53:	lea    r14,[rip+0xa80e]        # 413368 <__swc_rdata_base_e121059d+0x258>
  408b5a:	sub    rsp,0x50
  408b5e:	mov    rax,rsp
  408b61:	vmovups xmm0,XMMWORD PTR [rip+0xa937]        # 4134a0 <__swc_rdata_base_e121059d+0x390>
  408b69:	vmovups XMMWORD PTR [rax],xmm0
  408b6d:	mov    QWORD PTR [rax+0x10],rsp
  408b71:	mov    QWORD PTR [rax+0x18],r13
  408b75:	mov    QWORD PTR [rax+0x20],rdi
  408b79:	lea    rdi,[rip+0xa7f8]        # 413378 <__swc_rdata_base_e121059d+0x268>
  408b80:	mov    QWORD PTR [rax+0x28],rdi
  408b84:	mov    QWORD PTR [rax+0x30],r14
  408b88:	mov    QWORD PTR [rax+0x38],r13
  408b8c:	lea    rcx,[rsp+0x10]
  408b91:	mov    QWORD PTR [rax+0x40],rcx
  408b95:	mov    QWORD PTR [rax+0x48],0x3
  408b9d:	lea    rcx,[rsp+0x40]
  408ba2:	sub    rsp,0x8
  408ba6:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  408bab:	add    rsp,0x8
  408baf:	add    rsp,0x50
  408bb3:	lea    rax,[rip+0xa806]        # 4133c0 <__swc_rdata_base_e121059d+0x2b0>
  408bba:	sub    rsp,0x20
  408bbe:	mov    rcx,rsp
  408bc1:	mov    QWORD PTR [rcx],rax
  408bc4:	mov    QWORD PTR [rcx+0x8],r13
  408bc8:	mov    QWORD PTR [rcx+0x10],rsp
  408bcc:	mov    QWORD PTR [rcx+0x18],0x1
  408bd4:	lea    rcx,[rsp+0x10]
  408bd9:	sub    rsp,0x8
  408bdd:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  408be2:	add    rsp,0x8
  408be6:	add    rsp,0x20
  408bea:	mov    eax,DWORD PTR [rsi+0x20]
  408bed:	mov    ecx,DWORD PTR [rsi+0x24]
  408bf0:	sub    rsp,0xa0
  408bf7:	mov    rdx,rsp
  408bfa:	mov    QWORD PTR [rdx+0x30],rsi
  408bfe:	mov    QWORD PTR [rdx+0x38],rdi
  408c02:	vmovups xmm0,XMMWORD PTR [rip+0xa82e]        # 413438 <__swc_rdata_base_e121059d+0x328>
  408c0a:	vmovups XMMWORD PTR [rdx],xmm0
  408c0e:	mov    QWORD PTR [rdx+0x40],rsp
  408c12:	mov    QWORD PTR [rdx+0x48],r13
  408c16:	mov    DWORD PTR [rdx+0x10],eax
  408c19:	lea    rax,[rsp+0x10]
  408c1e:	mov    QWORD PTR [rdx+0x50],rax
  408c22:	lea    rax,[rip+0xa7a7]        # 4133d0 <__swc_rdata_base_e121059d+0x2c0>
  408c29:	mov    QWORD PTR [rdx+0x58],rax
  408c2d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c32:	lea    r8,[rsp+0x18]
  408c37:	mov    QWORD PTR [rdx+0x60],r8
  408c3b:	mov    QWORD PTR [rdx+0x68],r13
  408c3f:	mov    DWORD PTR [rdx+0x28],ecx
  408c42:	lea    rcx,[rdx+0x28]
  408c46:	mov    QWORD PTR [rdx+0x70],rcx
  408c4a:	mov    QWORD PTR [rdx+0x78],rax
  408c4e:	mov    QWORD PTR [rdx+0x80],r14
  408c55:	mov    QWORD PTR [rdx+0x88],r13
  408c5c:	lea    rax,[rdx+0x30]
  408c60:	mov    QWORD PTR [rdx+0x90],rax
  408c67:	mov    QWORD PTR [rdx+0x98],0x6
  408c72:	lea    rcx,[rdx+0x90]
  408c79:	sub    rsp,0x8
  408c7d:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  408c82:	add    rsp,0x8
  408c86:	add    rsp,0xa0
  408c8d:	sub    rsp,0x20
  408c91:	mov    rax,rsp
  408c94:	mov    QWORD PTR [rax],r14
  408c97:	mov    QWORD PTR [rax+0x8],r13
  408c9b:	mov    QWORD PTR [rax+0x10],rsp
  408c9f:	mov    QWORD PTR [rax+0x18],0x1
  408ca7:	lea    rcx,[rsp+0x10]
  408cac:	sub    rsp,0x8
  408cb0:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  408cb5:	add    rsp,0x8
  408cb9:	add    rsp,0x20
  408cbd:	mov    eax,DWORD PTR [r12+0x9ac]
  408cc5:	test   eax,eax
  408cc7:	je     408f00 <__swc_fn_e121059d_000102_e9fdc18e+0x480>
  408ccd:	lea    rax,[rip+0xa744]        # 413418 <__swc_rdata_base_e121059d+0x308>
  408cd4:	sub    rsp,0x20
  408cd8:	mov    rcx,rsp
  408cdb:	mov    QWORD PTR [rcx],rax
  408cde:	mov    QWORD PTR [rcx+0x8],r13
  408ce2:	mov    QWORD PTR [rcx+0x10],rsp
  408ce6:	mov    QWORD PTR [rcx+0x18],0x1
  408cee:	lea    rcx,[rsp+0x10]
  408cf3:	sub    rsp,0x8
  408cf7:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  408cfc:	add    rsp,0x8
  408d00:	add    rsp,0x20
  408d04:	mov    eax,DWORD PTR [r12+0x9ac]
  408d0c:	dec    eax
  408d0e:	mov    esi,eax
  408d10:	test   esi,esi
  408d12:	jl     408ed0 <__swc_fn_e121059d_000102_e9fdc18e+0x450>
  408d18:	jmp    408d24 <__swc_fn_e121059d_000102_e9fdc18e+0x2a4>
  408d1a:	nop    WORD PTR [rax+rax*1+0x0]
  408d20:	dec    esi
  408d22:	jmp    408d10 <__swc_fn_e121059d_000102_e9fdc18e+0x290>
  408d24:	lea    rax,[rip+0xa6fd]        # 413428 <__swc_rdata_base_e121059d+0x318>
  408d2b:	sub    rsp,0x20
  408d2f:	mov    rcx,rsp
  408d32:	mov    QWORD PTR [rcx],rax
  408d35:	mov    QWORD PTR [rcx+0x8],r13
  408d39:	mov    QWORD PTR [rcx+0x10],rsp
  408d3d:	mov    QWORD PTR [rcx+0x18],0x1
  408d45:	lea    rcx,[rsp+0x10]
  408d4a:	sub    rsp,0x8
  408d4e:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  408d53:	add    rsp,0x8
  408d57:	add    rsp,0x20
  408d5b:	movsxd rax,esi
  408d5e:	imul   r15,rax,0x30
  408d62:	add    r15,r12
  408d65:	add    r15,0xf8
  408d6c:	sub    rsp,0x20
  408d70:	mov    rax,rsp
  408d73:	mov    QWORD PTR [rax],r15
  408d76:	mov    QWORD PTR [rax+0x8],rdi
  408d7a:	mov    QWORD PTR [rax+0x10],rsp
  408d7e:	mov    QWORD PTR [rax+0x18],0x1
  408d86:	lea    rcx,[rsp+0x10]
  408d8b:	sub    rsp,0x8
  408d8f:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  408d94:	add    rsp,0x8
  408d98:	add    rsp,0x20
  408d9c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408da4:	lea    rsi,[rip+0xa68d]        # 413438 <__swc_rdata_base_e121059d+0x328>
  408dab:	sub    rsp,0x20
  408daf:	mov    rax,rsp
  408db2:	mov    QWORD PTR [rax],rsi
  408db5:	mov    QWORD PTR [rax+0x8],r13
  408db9:	mov    QWORD PTR [rax+0x10],rsp
  408dbd:	mov    QWORD PTR [rax+0x18],0x1
  408dc5:	lea    rcx,[rsp+0x10]
  408dca:	sub    rsp,0x8
  408dce:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  408dd3:	add    rsp,0x8
  408dd7:	add    rsp,0x20
  408ddb:	sub    rsp,0x30
  408ddf:	mov    rax,rsp
  408de2:	mov    ecx,DWORD PTR [r15+0x20]
  408de6:	mov    QWORD PTR [rax],rcx
  408de9:	mov    QWORD PTR [rax+0x8],rsp
  408ded:	lea    rdi,[rip+0xa654]        # 413448 <__swc_rdata_base_e121059d+0x338>
  408df4:	mov    QWORD PTR [rax+0x10],rdi
  408df8:	lea    rcx,[rsp+0x8]
  408dfd:	mov    QWORD PTR [rax+0x18],rcx
  408e01:	mov    QWORD PTR [rax+0x20],0x1
  408e09:	lea    rcx,[rsp+0x18]
  408e0e:	sub    rsp,0x8
  408e12:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  408e17:	add    rsp,0x8
  408e1b:	add    rsp,0x30
  408e1f:	sub    rsp,0x20
  408e23:	mov    rax,rsp
  408e26:	mov    QWORD PTR [rax],rsi
  408e29:	mov    QWORD PTR [rax+0x8],r13
  408e2d:	mov    QWORD PTR [rax+0x10],rsp
  408e31:	mov    QWORD PTR [rax+0x18],0x1
  408e39:	lea    rcx,[rsp+0x10]
  408e3e:	sub    rsp,0x8
  408e42:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  408e47:	add    rsp,0x8
  408e4b:	add    rsp,0x20
  408e4f:	sub    rsp,0x30
  408e53:	mov    rax,rsp
  408e56:	mov    ecx,DWORD PTR [r15+0x24]
  408e5a:	mov    QWORD PTR [rax],rcx
  408e5d:	mov    QWORD PTR [rax+0x8],rsp
  408e61:	mov    QWORD PTR [rax+0x10],rdi
  408e65:	lea    rcx,[rsp+0x8]
  408e6a:	mov    QWORD PTR [rax+0x18],rcx
  408e6e:	mov    QWORD PTR [rax+0x20],0x1
  408e76:	lea    rcx,[rsp+0x18]
  408e7b:	sub    rsp,0x8
  408e7f:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  408e84:	add    rsp,0x8
  408e88:	add    rsp,0x30
  408e8c:	sub    rsp,0x20
  408e90:	mov    rax,rsp
  408e93:	mov    QWORD PTR [rax],r14
  408e96:	mov    QWORD PTR [rax+0x8],r13
  408e9a:	mov    QWORD PTR [rax+0x10],rsp
  408e9e:	mov    QWORD PTR [rax+0x18],0x1
  408ea6:	lea    rcx,[rsp+0x10]
  408eab:	sub    rsp,0x8
  408eaf:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  408eb4:	add    rsp,0x8
  408eb8:	add    rsp,0x20
  408ebc:	lea    rdi,[rip+0xa4b5]        # 413378 <__swc_rdata_base_e121059d+0x268>
  408ec3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408ecb:	jmp    408d20 <__swc_fn_e121059d_000102_e9fdc18e+0x2a0>
  408ed0:	sub    rsp,0x20
  408ed4:	mov    rax,rsp
  408ed7:	mov    QWORD PTR [rax],r14
  408eda:	mov    QWORD PTR [rax+0x8],r13
  408ede:	mov    QWORD PTR [rax+0x10],rsp
  408ee2:	mov    QWORD PTR [rax+0x18],0x1
  408eea:	lea    rcx,[rsp+0x10]
  408eef:	sub    rsp,0x8
  408ef3:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  408ef8:	add    rsp,0x8
  408efc:	add    rsp,0x20
  408f00:	lea    rax,[rbx+0x28]
  408f04:	mov    rcx,rax
  408f07:	mov    QWORD PTR [rbx+0x28],0x0
  408f0f:	mov    QWORD PTR [rbx+0x30],0x0
  408f17:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408f1c:	add    rcx,0x10
  408f20:	mov    edx,0x1f
  408f25:	cs nop WORD PTR [rax+rax*1+0x0]
  408f2f:	nop
  408f30:	vmovups XMMWORD PTR [rcx],xmm0
  408f34:	add    rcx,0x10
  408f38:	sub    rdx,0x1
  408f3c:	jne    408f30 <__swc_fn_e121059d_000102_e9fdc18e+0x4b0>
  408f3e:	lea    rsi,[rbx+0x228]
  408f45:	xor    ecx,ecx
  408f47:	cs nop WORD PTR [rax+rax*1+0x0]
  408f51:	cs nop WORD PTR [rax+rax*1+0x0]
  408f5b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f60:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f65:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f6a:	add    rcx,0x10
  408f6e:	cmp    rcx,0x200
  408f75:	jne    408f60 <__swc_fn_e121059d_000102_e9fdc18e+0x4e0>
  408f77:	mov    eax,DWORD PTR [r12+0xbc8]
  408f7f:	lea    rcx,[r12+0x9c8]
  408f87:	mov    QWORD PTR [rbx+0x428],rcx
  408f8e:	mov    QWORD PTR [rbx+0x430],rax
  408f95:	lea    rdi,[rbx+0x438]
  408f9c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408fa4:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fac:	mov    eax,DWORD PTR [r12+0xbc8]
  408fb4:	test   eax,eax
  408fb6:	jne    409003 <__swc_fn_e121059d_000102_e9fdc18e+0x583>
  408fb8:	lea    rax,[rbx+0x448]
  408fbf:	mov    QWORD PTR [rbx+0x448],rsi
  408fc6:	mov    QWORD PTR [rax+0x8],0x40
  408fce:	mov    ecx,0x1
  408fd3:	mov    rdx,rax
  408fd6:	sub    rsp,0x8
  408fda:	call   4099e0 <__swc_fn_e121059d_000120_9175a56a>
  408fdf:	add    rsp,0x8
  408fe3:	mov    QWORD PTR [rbx+0x460],rsi
  408fea:	mov    ecx,eax
  408fec:	mov    QWORD PTR [rbx+0x468],rcx
  408ff3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408ffb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  409003:	mov    rsi,QWORD PTR [rbx+0x438]
  40900a:	mov    rax,QWORD PTR [rbx+0x440]
  409011:	mov    r15,rax
  409014:	xor    r12d,r12d
  409017:	test   r15,r15
  40901a:	je     4090d0 <__swc_fn_e121059d_000102_e9fdc18e+0x650>
  409020:	mov    rax,QWORD PTR [rsi+r12*8]
  409024:	test   rax,rax
  409027:	je     409046 <__swc_fn_e121059d_000102_e9fdc18e+0x5c6>
  409029:	lea    rcx,[rbx+0x4b8]
  409030:	mov    rdx,rax
  409033:	sub    rsp,0x8
  409037:	call   40e780 <__swc_fn_e121059d_000163_60216e69>
  40903c:	add    rsp,0x8
  409040:	mov    al,BYTE PTR [rax]
  409042:	test   al,al
  409044:	jne    409052 <__swc_fn_e121059d_000102_e9fdc18e+0x5d2>
  409046:	add    r12,0x1
  40904a:	sub    r15,0x1
  40904e:	jne    409020 <__swc_fn_e121059d_000102_e9fdc18e+0x5a0>
  409050:	jmp    4090d0 <__swc_fn_e121059d_000102_e9fdc18e+0x650>
  409052:	lea    rax,[rip+0xa437]        # 413490 <__swc_rdata_base_e121059d+0x380>
  409059:	sub    rsp,0x20
  40905d:	mov    rcx,rsp
  409060:	mov    QWORD PTR [rcx],rax
  409063:	mov    QWORD PTR [rcx+0x8],r13
  409067:	mov    QWORD PTR [rcx+0x10],rsp
  40906b:	mov    QWORD PTR [rcx+0x18],0x1
  409073:	lea    rcx,[rsp+0x10]
  409078:	sub    rsp,0x8
  40907c:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  409081:	add    rsp,0x8
  409085:	add    rsp,0x20
  409089:	mov    rcx,rdi
  40908c:	xor    edx,edx
  40908e:	mov    al,0x1
  409090:	mov    r8,rax
  409093:	sub    rsp,0x8
  409097:	call   411680 <__swc_fn_e121059d_000164_8e41797b>
  40909c:	add    rsp,0x8
  4090a0:	sub    rsp,0x20
  4090a4:	mov    rax,rsp
  4090a7:	mov    QWORD PTR [rax],r14
  4090aa:	mov    QWORD PTR [rax+0x8],r13
  4090ae:	mov    QWORD PTR [rax+0x10],rsp
  4090b2:	mov    QWORD PTR [rax+0x18],0x1
  4090ba:	lea    rcx,[rsp+0x10]
  4090bf:	sub    rsp,0x8
  4090c3:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  4090c8:	add    rsp,0x8
  4090cc:	add    rsp,0x20
  4090d0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090d8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090e4:	add    rsp,0x500
  4090eb:	pop    r15
  4090ed:	pop    r14
  4090ef:	pop    r13
  4090f1:	pop    r12
  4090f3:	pop    rdi
  4090f4:	pop    rsi
  4090f5:	pop    rbx
  4090f6:	pop    rbp
  4090f7:	ret
	...

0000000000409100 <__swc_fn_e121059d_000105_5f646f9d>:
  409100:	test   r8,r8
  409103:	jne    409106 <__swc_fn_e121059d_000105_5f646f9d+0x6>
  409105:	ret
  409106:	xor    eax,eax
  409108:	movzx  r9d,dl
  40910c:	movabs r10,0x101010101010101
  409116:	imul   r9,r10
  40911a:	vmovq  xmm0,r9
  40911f:	vpshufd xmm0,xmm0,0x44
  409124:	cs nop WORD PTR [rax+rax*1+0x0]
  40912e:	xchg   ax,ax
  409130:	mov    r10,r8
  409133:	sub    r10,rax
  409136:	cmp    r10,0x40
  40913a:	jb     40915d <__swc_fn_e121059d_000105_5f646f9d+0x5d>
  40913c:	lea    r10,[rcx+rax*1]
  409140:	vmovups XMMWORD PTR [r10],xmm0
  409145:	vmovups XMMWORD PTR [r10+0x10],xmm0
  40914b:	vmovups XMMWORD PTR [r10+0x20],xmm0
  409151:	vmovups XMMWORD PTR [r10+0x30],xmm0
  409157:	lea    rax,[rax+0x40]
  40915b:	jmp    409130 <__swc_fn_e121059d_000105_5f646f9d+0x30>
  40915d:	nop    DWORD PTR [rax]
  409160:	mov    r10,r8
  409163:	sub    r10,rax
  409166:	cmp    r10,0x10
  40916a:	jb     40917b <__swc_fn_e121059d_000105_5f646f9d+0x7b>
  40916c:	lea    r10,[rcx+rax*1]
  409170:	vmovups XMMWORD PTR [r10],xmm0
  409175:	lea    rax,[rax+0x10]
  409179:	jmp    409160 <__swc_fn_e121059d_000105_5f646f9d+0x60>
  40917b:	nop    DWORD PTR [rax+rax*1+0x0]
  409180:	mov    r10,r8
  409183:	sub    r10,rax
  409186:	cmp    r10,0x8
  40918a:	jb     409199 <__swc_fn_e121059d_000105_5f646f9d+0x99>
  40918c:	lea    r10,[rcx+rax*1]
  409190:	mov    QWORD PTR [r10],r9
  409193:	lea    rax,[rax+0x8]
  409197:	jmp    409180 <__swc_fn_e121059d_000105_5f646f9d+0x80>
  409199:	cmp    rax,r8
  40919c:	jae    4091ab <__swc_fn_e121059d_000105_5f646f9d+0xab>
  40919e:	xchg   ax,ax
  4091a0:	mov    BYTE PTR [rcx+rax*1],dl
  4091a3:	inc    rax
  4091a6:	cmp    rax,r8
  4091a9:	jb     4091a0 <__swc_fn_e121059d_000105_5f646f9d+0xa0>
  4091ab:	ret
	...

00000000004091c0 <__swc_fn_e121059d_000108_4796e893>:
  4091c0:	push   rbx
  4091c1:	push   r12
  4091c3:	push   rdi
  4091c4:	push   rsi
  4091c5:	push   r13
  4091c7:	push   r14
  4091c9:	push   r15
  4091cb:	sub    rsp,0x170
  4091d2:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  4091db:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  4091e4:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  4091ed:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  4091f6:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  4091ff:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  409208:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  409211:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40921a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  409223:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40922c:	mov    ebx,edx
  40922e:	mov    QWORD PTR [rsp+0xa8],rbx
  409236:	mov    r12d,ecx
  409239:	test   edx,edx
  40923b:	jne    409252 <__swc_fn_e121059d_000108_4796e893+0x92>
  40923d:	xor    eax,eax
  40923f:	add    rsp,0x170
  409246:	pop    r15
  409248:	pop    r14
  40924a:	pop    r13
  40924c:	pop    rsi
  40924d:	pop    rdi
  40924e:	pop    r12
  409250:	pop    rbx
  409251:	ret
  409252:	lea    rdi,[rip+0xa257]        # 4134b0 <__swc_rdata_base_e121059d+0x3a0>
  409259:	mov    esi,0x90000
  40925e:	xor    eax,eax
  409260:	call   407010 <open@plt>
  409265:	mov    r13,rax
  409268:	mov    QWORD PTR [rsp+0xb0],rax
  409270:	test   eax,eax
  409272:	jge    40927b <__swc_fn_e121059d_000108_4796e893+0xbb>
  409274:	xor    eax,eax
  409276:	jmp    409796 <__swc_fn_e121059d_000108_4796e893+0x5d6>
  40927b:	nop    DWORD PTR [rax+rax*1+0x0]
  409280:	movsxd rdi,r13d
  409283:	mov    esi,0x2
  409288:	xor    eax,eax
  40928a:	call   407020 <flock@plt>
  40928f:	test   eax,eax
  409291:	je     4092b0 <__swc_fn_e121059d_000108_4796e893+0xf0>
  409293:	xor    eax,eax
  409295:	call   407030 <__errno_location@plt>
  40929a:	cmp    DWORD PTR [rax],0x4
  40929d:	je     409280 <__swc_fn_e121059d_000108_4796e893+0xc0>
  40929f:	movsxd rdi,r13d
  4092a2:	xor    eax,eax
  4092a4:	call   407040 <close@plt>
  4092a9:	xor    eax,eax
  4092ab:	jmp    409796 <__swc_fn_e121059d_000108_4796e893+0x5d6>
  4092b0:	lea    r14,[rsp+0x8]
  4092b5:	mov    QWORD PTR [rsp+0xb8],r14
  4092bd:	vxorps xmm0,xmm0,xmm0
  4092c1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4092c7:	mov    QWORD PTR [rsp+0x18],0x0
  4092d0:	mov    WORD PTR [rsp+0x20],0x0
  4092d7:	mov    DWORD PTR [r14],0x67617753
  4092de:	mov    DWORD PTR [r14+0x4],0x2e74522e
  4092e6:	xor    eax,eax
  4092e8:	call   407050 <getpid@plt>
  4092ed:	mov    ecx,eax
  4092ef:	mov    eax,0x1c
  4092f4:	shrx   eax,ecx,eax
  4092f9:	and    eax,0xf
  4092fc:	mov    rdx,QWORD PTR [rip+0xa1cd]        # 4134d0 <__swc_rdata_base_e121059d+0x3c0>
  409303:	mov    al,BYTE PTR [rdx+rax*1]
  409306:	rex mov BYTE PTR [rsp+0x10],al
  40930b:	mov    eax,0x1c
  409310:	shrx   eax,r12d,eax
  409315:	and    eax,0xf
  409318:	mov    al,BYTE PTR [rdx+rax*1]
  40931b:	rex mov BYTE PTR [rsp+0x19],al
  409320:	mov    eax,0x18
  409325:	shrx   eax,ecx,eax
  40932a:	and    eax,0xf
  40932d:	mov    al,BYTE PTR [rdx+rax*1]
  409330:	rex mov BYTE PTR [rsp+0x11],al
  409335:	mov    eax,0x18
  40933a:	shrx   eax,r12d,eax
  40933f:	and    eax,0xf
  409342:	mov    al,BYTE PTR [rdx+rax*1]
  409345:	rex mov BYTE PTR [rsp+0x1a],al
  40934a:	mov    eax,0x14
  40934f:	shrx   eax,ecx,eax
  409354:	and    eax,0xf
  409357:	mov    al,BYTE PTR [rdx+rax*1]
  40935a:	rex mov BYTE PTR [rsp+0x12],al
  40935f:	mov    eax,0x14
  409364:	shrx   eax,r12d,eax
  409369:	and    eax,0xf
  40936c:	mov    al,BYTE PTR [rdx+rax*1]
  40936f:	rex mov BYTE PTR [rsp+0x1b],al
  409374:	mov    eax,0x10
  409379:	shrx   eax,ecx,eax
  40937e:	and    eax,0xf
  409381:	mov    al,BYTE PTR [rdx+rax*1]
  409384:	rex mov BYTE PTR [rsp+0x13],al
  409389:	mov    eax,0x10
  40938e:	shrx   eax,r12d,eax
  409393:	and    eax,0xf
  409396:	mov    al,BYTE PTR [rdx+rax*1]
  409399:	rex mov BYTE PTR [rsp+0x1c],al
  40939e:	mov    eax,0xc
  4093a3:	shrx   eax,ecx,eax
  4093a8:	and    eax,0xf
  4093ab:	mov    al,BYTE PTR [rdx+rax*1]
  4093ae:	rex mov BYTE PTR [rsp+0x14],al
  4093b3:	mov    eax,0xc
  4093b8:	shrx   eax,r12d,eax
  4093bd:	and    eax,0xf
  4093c0:	mov    al,BYTE PTR [rdx+rax*1]
  4093c3:	rex mov BYTE PTR [rsp+0x1d],al
  4093c8:	mov    eax,0x8
  4093cd:	shrx   eax,ecx,eax
  4093d2:	and    eax,0xf
  4093d5:	mov    al,BYTE PTR [rdx+rax*1]
  4093d8:	rex mov BYTE PTR [rsp+0x15],al
  4093dd:	mov    eax,0x8
  4093e2:	shrx   eax,r12d,eax
  4093e7:	and    eax,0xf
  4093ea:	mov    al,BYTE PTR [rdx+rax*1]
  4093ed:	rex mov BYTE PTR [rsp+0x1e],al
  4093f2:	mov    eax,0x4
  4093f7:	shrx   eax,ecx,eax
  4093fc:	and    eax,0xf
  4093ff:	mov    al,BYTE PTR [rdx+rax*1]
  409402:	rex mov BYTE PTR [rsp+0x16],al
  409407:	mov    eax,0x4
  40940c:	shrx   eax,r12d,eax
  409411:	and    eax,0xf
  409414:	mov    al,BYTE PTR [rdx+rax*1]
  409417:	rex mov BYTE PTR [rsp+0x1f],al
  40941c:	xor    eax,eax
  40941e:	shrx   eax,ecx,eax
  409423:	and    eax,0xf
  409426:	mov    al,BYTE PTR [rdx+rax*1]
  409429:	rex mov BYTE PTR [rsp+0x17],al
  40942e:	xor    eax,eax
  409430:	shrx   eax,r12d,eax
  409435:	and    eax,0xf
  409438:	mov    al,BYTE PTR [rdx+rax*1]
  40943b:	rex mov BYTE PTR [rsp+0x20],al
  409440:	mov    BYTE PTR [r14+0x10],0x2e
  409445:	lea    r12,[rsp+0x22]
  40944a:	vxorps xmm0,xmm0,xmm0
  40944e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  409454:	mov    DWORD PTR [r12],0x6d656d2f
  40945c:	mov    WORD PTR [r12+0x4],0x6466
  409464:	mov    BYTE PTR [r12+0x6],0x3a
  40946a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409470:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  409476:	mov    rax,QWORD PTR [rsp+0x18]
  40947b:	mov    QWORD PTR [rsp+0x39],rax
  409480:	rex mov al,BYTE PTR [rsp+0x20]
  409485:	rex mov BYTE PTR [rsp+0x41],al
  40948a:	mov    DWORD PTR [r12+0x20],0x65642820
  409493:	mov    DWORD PTR [r12+0x24],0x6574656c
  40949c:	mov    WORD PTR [r12+0x28],0x2964
  4094a4:	lea    rdi,[rip+0xa010]        # 4134bb <__swc_rdata_base_e121059d+0x3ab>
  4094ab:	xor    eax,eax
  4094ad:	call   407060 <opendir@plt>
  4094b2:	mov    r15,rax
  4094b5:	test   rax,rax
  4094b8:	jne    4094cb <__swc_fn_e121059d_000108_4796e893+0x30b>
  4094ba:	movsxd rdi,r13d
  4094bd:	xor    eax,eax
  4094bf:	call   407040 <close@plt>
  4094c4:	xor    eax,eax
  4094c6:	jmp    409796 <__swc_fn_e121059d_000108_4796e893+0x5d6>
  4094cb:	mov    rdi,r15
  4094ce:	xor    eax,eax
  4094d0:	call   407070 <dirfd@plt>
  4094d5:	lea    r14,[rsp+0x54]
  4094da:	mov    DWORD PTR [rsp+0x54],eax
  4094de:	lea    rbx,[rsp+0x58]
  4094e3:	cs nop WORD PTR [rax+rax*1+0x0]
  4094ed:	cs nop WORD PTR [rax+rax*1+0x0]
  4094f7:	nop    WORD PTR [rax+rax*1+0x0]
  409500:	mov    rdi,r15
  409503:	xor    eax,eax
  409505:	call   407080 <readdir@plt>
  40950a:	test   rax,rax
  40950d:	jne    409524 <__swc_fn_e121059d_000108_4796e893+0x364>
  40950f:	mov    r12,QWORD PTR [rsp+0xa8]
  409517:	mov    r13,QWORD PTR [rsp+0xb0]
  40951f:	jmp    4096ba <__swc_fn_e121059d_000108_4796e893+0x4fa>
  409524:	vxorps xmm0,xmm0,xmm0
  409528:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40952e:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  409534:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40953a:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  409543:	lea    r13,[rax+0x13]
  409547:	mov    rax,r14
  40954a:	movsxd rdi,DWORD PTR [rax]
  40954d:	mov    rsi,r13
  409550:	mov    rdx,rbx
  409553:	mov    ecx,0x40
  409558:	xor    eax,eax
  40955a:	call   407090 <readlinkat@plt>
  40955f:	cmp    rax,0x2a
  409563:	jne    409500 <__swc_fn_e121059d_000108_4796e893+0x340>
  409565:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40956b:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  409571:	vptest xmm0,xmm0
  409576:	jne    4095a6 <__swc_fn_e121059d_000108_4796e893+0x3e6>
  409578:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40957e:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  409584:	vptest xmm0,xmm0
  409589:	jne    4095a6 <__swc_fn_e121059d_000108_4796e893+0x3e6>
  40958b:	mov    rcx,QWORD PTR [rsp+0x42]
  409590:	cmp    QWORD PTR [rsp+0x78],rcx
  409595:	jne    4095a6 <__swc_fn_e121059d_000108_4796e893+0x3e6>
  409597:	mov    cx,WORD PTR [rsp+0x4a]
  40959c:	cmp    WORD PTR [rsp+0x80],cx
  4095a4:	je     4095d4 <__swc_fn_e121059d_000108_4796e893+0x414>
  4095a6:	mov    rax,rbx
  4095a9:	mov    rcx,r12
  4095ac:	nop    DWORD PTR [rax+0x0]
  4095b0:	movzx  edx,BYTE PTR [rax]
  4095b3:	movzx  r8d,BYTE PTR [rcx]
  4095b7:	cmp    rdx,r8
  4095ba:	jne    4095c6 <__swc_fn_e121059d_000108_4796e893+0x406>
  4095bc:	add    rax,0x1
  4095c0:	add    rcx,0x1
  4095c4:	jmp    4095b0 <__swc_fn_e121059d_000108_4796e893+0x3f0>
  4095c6:	mov    rax,rdx
  4095c9:	sub    rax,r8
  4095cc:	test   eax,eax
  4095ce:	jne    409500 <__swc_fn_e121059d_000108_4796e893+0x340>
  4095d4:	movsxd rdi,DWORD PTR [r14]
  4095d7:	mov    rsi,r13
  4095da:	mov    edx,0x80002
  4095df:	xor    eax,eax
  4095e1:	call   4070a0 <openat@plt>
  4095e6:	lea    rbx,[rsp+0x98]
  4095ee:	mov    DWORD PTR [rsp+0x98],eax
  4095f5:	test   eax,eax
  4095f7:	mov    r13,QWORD PTR [rsp+0xb0]
  4095ff:	jge    409624 <__swc_fn_e121059d_000108_4796e893+0x464>
  409601:	mov    rdi,r15
  409604:	xor    eax,eax
  409606:	call   4070b0 <closedir@plt>
  40960b:	mov    r13,QWORD PTR [rsp+0xb0]
  409613:	movsxd rdi,r13d
  409616:	xor    eax,eax
  409618:	call   407040 <close@plt>
  40961d:	xor    eax,eax
  40961f:	jmp    409796 <__swc_fn_e121059d_000108_4796e893+0x5d6>
  409624:	mov    rax,rbx
  409627:	movsxd rdi,DWORD PTR [rax]
  40962a:	xor    esi,esi
  40962c:	mov    edx,0x2
  409631:	xor    eax,eax
  409633:	call   4070c0 <lseek@plt>
  409638:	mov    r12,QWORD PTR [rsp+0xa8]
  409640:	cmp    rax,r12
  409643:	je     40966a <__swc_fn_e121059d_000108_4796e893+0x4aa>
  409645:	movsxd rdi,DWORD PTR [rbx]
  409648:	xor    eax,eax
  40964a:	call   407040 <close@plt>
  40964f:	mov    rdi,r15
  409652:	xor    eax,eax
  409654:	call   4070b0 <closedir@plt>
  409659:	movsxd rdi,r13d
  40965c:	xor    eax,eax
  40965e:	call   407040 <close@plt>
  409663:	xor    eax,eax
  409665:	jmp    409796 <__swc_fn_e121059d_000108_4796e893+0x5d6>
  40966a:	xor    edi,edi
  40966c:	mov    rsi,r12
  40966f:	mov    edx,0x3
  409674:	mov    ecx,0x1
  409679:	mov    rax,rbx
  40967c:	movsxd r8,DWORD PTR [rax]
  40967f:	xor    r9d,r9d
  409682:	xor    eax,eax
  409684:	call   4070d0 <mmap@plt>
  409689:	xor    r12d,r12d
  40968c:	cmp    rax,0xffffffffffffffff
  409690:	cmovne r12,rax
  409694:	movsxd rdi,DWORD PTR [rbx]
  409697:	xor    eax,eax
  409699:	call   407040 <close@plt>
  40969e:	mov    rdi,r15
  4096a1:	xor    eax,eax
  4096a3:	call   4070b0 <closedir@plt>
  4096a8:	movsxd rdi,r13d
  4096ab:	xor    eax,eax
  4096ad:	call   407040 <close@plt>
  4096b2:	mov    rax,r12
  4096b5:	jmp    409796 <__swc_fn_e121059d_000108_4796e893+0x5d6>
  4096ba:	mov    r14,QWORD PTR [rsp+0xb8]
  4096c2:	mov    rdi,r14
  4096c5:	mov    esi,0x1
  4096ca:	xor    eax,eax
  4096cc:	call   4070e0 <memfd_create@plt>
  4096d1:	lea    rbx,[rsp+0x9c]
  4096d9:	mov    DWORD PTR [rsp+0x9c],eax
  4096e0:	test   eax,eax
  4096e2:	jge    4096ff <__swc_fn_e121059d_000108_4796e893+0x53f>
  4096e4:	mov    rdi,r15
  4096e7:	xor    eax,eax
  4096e9:	call   4070b0 <closedir@plt>
  4096ee:	movsxd rdi,r13d
  4096f1:	xor    eax,eax
  4096f3:	call   407040 <close@plt>
  4096f8:	xor    eax,eax
  4096fa:	jmp    409796 <__swc_fn_e121059d_000108_4796e893+0x5d6>
  4096ff:	mov    rax,rbx
  409702:	movsxd rdi,DWORD PTR [rax]
  409705:	mov    rsi,r12
  409708:	xor    eax,eax
  40970a:	call   4070f0 <ftruncate@plt>
  40970f:	test   eax,eax
  409711:	je     409735 <__swc_fn_e121059d_000108_4796e893+0x575>
  409713:	movsxd rdi,DWORD PTR [rbx]
  409716:	xor    eax,eax
  409718:	call   407040 <close@plt>
  40971d:	mov    rdi,r15
  409720:	xor    eax,eax
  409722:	call   4070b0 <closedir@plt>
  409727:	movsxd rdi,r13d
  40972a:	xor    eax,eax
  40972c:	call   407040 <close@plt>
  409731:	xor    eax,eax
  409733:	jmp    409796 <__swc_fn_e121059d_000108_4796e893+0x5d6>
  409735:	xor    edi,edi
  409737:	mov    rsi,r12
  40973a:	mov    edx,0x3
  40973f:	mov    ecx,0x1
  409744:	mov    rax,rbx
  409747:	movsxd r8,DWORD PTR [rax]
  40974a:	xor    r9d,r9d
  40974d:	xor    eax,eax
  40974f:	call   4070d0 <mmap@plt>
  409754:	mov    r12,rax
  409757:	cmp    rax,0xffffffffffffffff
  40975b:	jne    40977f <__swc_fn_e121059d_000108_4796e893+0x5bf>
  40975d:	movsxd rdi,DWORD PTR [rbx]
  409760:	xor    eax,eax
  409762:	call   407040 <close@plt>
  409767:	mov    rdi,r15
  40976a:	xor    eax,eax
  40976c:	call   4070b0 <closedir@plt>
  409771:	movsxd rdi,r13d
  409774:	xor    eax,eax
  409776:	call   407040 <close@plt>
  40977b:	xor    eax,eax
  40977d:	jmp    409796 <__swc_fn_e121059d_000108_4796e893+0x5d6>
  40977f:	mov    rdi,r15
  409782:	xor    eax,eax
  409784:	call   4070b0 <closedir@plt>
  409789:	movsxd rdi,r13d
  40978c:	xor    eax,eax
  40978e:	call   407040 <close@plt>
  409793:	mov    rax,r12
  409796:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40979f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  4097a8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  4097b1:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  4097ba:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  4097c3:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  4097cc:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  4097d5:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  4097de:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  4097e7:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  4097f0:	add    rsp,0x170
  4097f7:	pop    r15
  4097f9:	pop    r14
  4097fb:	pop    r13
  4097fd:	pop    rsi
  4097fe:	pop    rdi
  4097ff:	pop    r12
  409801:	pop    rbx
  409802:	ret
	...

0000000000409810 <__swc_fn_e121059d_000111_a808fe76>:
  409810:	push   rsi
  409811:	push   rdi
  409812:	push   r12
  409814:	push   r13
  409816:	sub    rsp,0x8
  40981a:	mov    rsi,r8
  40981d:	mov    rdi,rcx
  409820:	mov    r12,rdx
  409823:	call   40d960 <__swc_fn_e121059d_000109_84af7666>
  409828:	mov    r13,rax
  40982b:	test   rax,rax
  40982e:	jne    40983b <__swc_fn_e121059d_000111_a808fe76+0x2b>
  409830:	add    rsp,0x8
  409834:	pop    r13
  409836:	pop    r12
  409838:	pop    rdi
  409839:	pop    rsi
  40983a:	ret
  40983b:	mov    rcx,r13
  40983e:	call   411170 <__swc_fn_e121059d_000134_4b2af8da>
  409843:	mov    rax,QWORD PTR [r13+0x8]
  409847:	test   rax,rax
  40984a:	je     409889 <__swc_fn_e121059d_000111_a808fe76+0x79>
  40984c:	nop    DWORD PTR [rax+0x0]
  409850:	lea    rcx,[rax+0x1000]
  409857:	cmp    rdi,rcx
  40985a:	jne    409881 <__swc_fn_e121059d_000111_a808fe76+0x71>
  40985c:	cmp    r12,0x1000
  409863:	jb     409881 <__swc_fn_e121059d_000111_a808fe76+0x71>
  409865:	test   sil,sil
  409868:	setne  cl
  40986b:	mov    BYTE PTR [rax+0x10],cl
  40986e:	mov    rcx,r13
  409871:	call   409d80 <__swc_fn_e121059d_000135_29412410>
  409876:	add    rsp,0x8
  40987a:	pop    r13
  40987c:	pop    r12
  40987e:	pop    rdi
  40987f:	pop    rsi
  409880:	ret
  409881:	mov    rax,QWORD PTR [rax]
  409884:	test   rax,rax
  409887:	jne    409850 <__swc_fn_e121059d_000111_a808fe76+0x40>
  409889:	mov    rcx,r13
  40988c:	call   409d80 <__swc_fn_e121059d_000135_29412410>
  409891:	add    rsp,0x8
  409895:	pop    r13
  409897:	pop    r12
  409899:	pop    rdi
  40989a:	pop    rsi
  40989b:	ret
  40989c:	add    BYTE PTR [rax],al
	...

00000000004098a0 <__swc_fn_e121059d_000114_49b378a9>:
  4098a0:	sub    rsp,0x8
  4098a4:	test   rcx,rcx
  4098a7:	jne    4098ae <__swc_fn_e121059d_000114_49b378a9+0xe>
  4098a9:	add    rsp,0x8
  4098ad:	ret
  4098ae:	call   410c70 <__swc_fn_e121059d_000116_1ba33335>
  4098b3:	add    rsp,0x8
  4098b7:	ret
	...

00000000004098c0 <__swc_fn_e121059d_000117_035d76a1>:
  4098c0:	push   r12
  4098c2:	push   r13
  4098c4:	push   r14
  4098c6:	push   rdi
  4098c7:	push   rsi
  4098c8:	sub    rsp,0xc0
  4098cf:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4098d5:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4098db:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4098e1:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4098e7:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4098ed:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4098f3:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4098f9:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409902:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40990b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409914:	mov    r12,QWORD PTR [rcx]
  409917:	test   r12,r12
  40991a:	jne    40992c <__swc_fn_e121059d_000117_035d76a1+0x6c>
  40991c:	add    rsp,0xc0
  409923:	pop    rsi
  409924:	pop    rdi
  409925:	pop    r14
  409927:	pop    r13
  409929:	pop    r12
  40992b:	ret
  40992c:	xor    r13d,r13d
  40992f:	mov    r14,QWORD PTR [rcx+0x8]
  409933:	cs nop WORD PTR [rax+rax*1+0x0]
  40993d:	nop    DWORD PTR [rax]
  409940:	cmp    r13,r14
  409943:	jae    40997e <__swc_fn_e121059d_000117_035d76a1+0xbe>
  409945:	lea    rax,[r12+r13*1]
  409949:	mov    rcx,r14
  40994c:	sub    rcx,r13
  40994f:	mov    edi,0x1
  409954:	mov    rsi,rax
  409957:	mov    rdx,rcx
  40995a:	xor    eax,eax
  40995c:	call   407100 <write@plt>
  409961:	test   rax,rax
  409964:	jle    40996b <__swc_fn_e121059d_000117_035d76a1+0xab>
  409966:	add    r13,rax
  409969:	jmp    409940 <__swc_fn_e121059d_000117_035d76a1+0x80>
  40996b:	test   rax,rax
  40996e:	je     40997c <__swc_fn_e121059d_000117_035d76a1+0xbc>
  409970:	xor    eax,eax
  409972:	call   407030 <__errno_location@plt>
  409977:	cmp    DWORD PTR [rax],0x4
  40997a:	je     409940 <__swc_fn_e121059d_000117_035d76a1+0x80>
  40997c:	jmp    40997e <__swc_fn_e121059d_000117_035d76a1+0xbe>
  40997e:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409984:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40998a:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409990:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409996:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40999c:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4099a2:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4099a8:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4099b1:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4099ba:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4099c3:	add    rsp,0xc0
  4099ca:	pop    rsi
  4099cb:	pop    rdi
  4099cc:	pop    r14
  4099ce:	pop    r13
  4099d0:	pop    r12
  4099d2:	ret
	...

00000000004099e0 <__swc_fn_e121059d_000120_9175a56a>:
  4099e0:	push   rbx
  4099e1:	push   r12
  4099e3:	push   rdi
  4099e4:	push   rsi
  4099e5:	sub    rsp,0x4a8
  4099ec:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  4099f5:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  4099fe:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  409a07:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  409a10:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  409a19:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  409a22:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  409a2b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  409a34:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  409a3d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  409a46:	mov    rbx,rdx
  409a49:	mov    r12d,ecx
  409a4c:	vxorps xmm0,xmm0,xmm0
  409a50:	xor    eax,eax
  409a52:	cs nop WORD PTR [rax+rax*1+0x0]
  409a5c:	nop    DWORD PTR [rax+0x0]
  409a60:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  409a66:	add    rax,0x10
  409a6a:	cmp    rax,0x400
  409a71:	jne    409a60 <__swc_fn_e121059d_000120_9175a56a+0x80>
  409a73:	lea    rdi,[rsp+0x8]
  409a78:	mov    esi,0x80
  409a7d:	xor    eax,eax
  409a7f:	call   407110 <backtrace@plt>
  409a84:	test   eax,eax
  409a86:	jle    409a95 <__swc_fn_e121059d_000120_9175a56a+0xb5>
  409a88:	movsxd rax,eax
  409a8b:	lea    rcx,[r12+0x1]
  409a90:	cmp    rcx,rax
  409a93:	jb     409a99 <__swc_fn_e121059d_000120_9175a56a+0xb9>
  409a95:	xor    eax,eax
  409a97:	jmp    409aca <__swc_fn_e121059d_000120_9175a56a+0xea>
  409a99:	mov    rcx,QWORD PTR [rbx+0x8]
  409a9d:	sub    rax,r12
  409aa0:	lea    rsi,[rax-0x1]
  409aa4:	cmp    rcx,rsi
  409aa7:	cmovbe rsi,rcx
  409aab:	lea    eax,[r12+0x1]
  409ab0:	lea    rax,[rsp+rax*8+0x8]
  409ab5:	mov    rcx,QWORD PTR [rbx]
  409ab8:	mov    rdx,rax
  409abb:	lea    r8,[rsi*8+0x0]
  409ac3:	call   40d940 <__swc_fn_e121059d_000106_6fd80914>
  409ac8:	mov    eax,esi
  409aca:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  409ad3:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  409adc:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  409ae5:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  409aee:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  409af7:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  409b00:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  409b09:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  409b12:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  409b1b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  409b24:	add    rsp,0x4a8
  409b2b:	pop    rsi
  409b2c:	pop    rdi
  409b2d:	pop    r12
  409b2f:	pop    rbx
  409b30:	ret
	...

0000000000409b40 <__swc_fn_e121059d_000123_e09461fd>:
  409b40:	mov    QWORD PTR [rcx],0x0
  409b47:	ret
	...

0000000000409b50 <__swc_fn_e121059d_000126_ce762363>:
  409b50:	push   rdi
  409b51:	push   rsi
  409b52:	sub    rsp,0xa8
  409b59:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409b5f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409b65:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409b6b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409b71:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409b77:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409b7d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409b83:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409b89:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409b92:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409b9b:	mov    edi,ecx
  409b9d:	mov    rsi,rdx
  409ba0:	xor    eax,eax
  409ba2:	call   407120 <pthread_setspecific@plt>
  409ba7:	test   eax,eax
  409ba9:	sete   al
  409bac:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409bb2:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409bb8:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409bbe:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409bc4:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409bca:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409bd0:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409bd6:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409bdc:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409be5:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409bee:	add    rsp,0xa8
  409bf5:	pop    rsi
  409bf6:	pop    rdi
  409bf7:	ret
	...

0000000000409c00 <__swc_fn_e121059d_000129_41c3251c>:
  409c00:	push   rdi
  409c01:	push   rsi
  409c02:	sub    rsp,0xa8
  409c09:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409c0f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409c15:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409c1b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409c21:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409c27:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409c2d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409c33:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409c39:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409c42:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409c4b:	test   rcx,rcx
  409c4e:	je     409c61 <__swc_fn_e121059d_000129_41c3251c+0x61>
  409c50:	lea    rax,[rcx-0x1]
  409c54:	mov    eax,eax
  409c56:	mov    edi,eax
  409c58:	xor    eax,eax
  409c5a:	call   407000 <pthread_getspecific@plt>
  409c5f:	jmp    409c63 <__swc_fn_e121059d_000129_41c3251c+0x63>
  409c61:	xor    eax,eax
  409c63:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409c69:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409c6f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409c75:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409c7b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409c81:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409c87:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409c8d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409c93:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409c9c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409ca5:	add    rsp,0xa8
  409cac:	pop    rsi
  409cad:	pop    rdi
  409cae:	ret
	...

0000000000409cb0 <__swc_fn_e121059d_000132_944f555b>:
  409cb0:	push   rdi
  409cb1:	push   rsi
  409cb2:	sub    rsp,0xb8
  409cb9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409cbf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409cc5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409ccb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409cd1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409cd7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409cdd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409ce3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409cec:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409cf5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409cfe:	vxorps xmm0,xmm0,xmm0
  409d02:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409d08:	mov    edi,0x1
  409d0d:	lea    rsi,[rsp+0x8]
  409d12:	xor    eax,eax
  409d14:	call   407130 <clock_gettime@plt>
  409d19:	mov    rax,QWORD PTR [rsp+0x8]
  409d1e:	imul   rax,rax,0x3b9aca00
  409d25:	add    rax,QWORD PTR [rsp+0x10]
  409d2a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409d30:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409d36:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409d3c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409d42:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409d48:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409d4e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409d54:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409d5d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409d66:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409d6f:	add    rsp,0xb8
  409d76:	pop    rsi
  409d77:	pop    rdi
  409d78:	ret
  409d79:	add    BYTE PTR [rax],al
  409d7b:	add    BYTE PTR [rax],al
  409d7d:	add    BYTE PTR [rax],al
	...

0000000000409d80 <__swc_fn_e121059d_000135_29412410>:
  409d80:	sub    rsp,0x8
  409d84:	xor    eax,eax
  409d86:	mov    DWORD PTR [rcx],eax
  409d88:	mov    edx,0x7fffffff
  409d8d:	call   40e040 <__swc_fn_e121059d_000133_f908e7f9>
  409d92:	add    rsp,0x8
  409d96:	ret
	...

0000000000409da0 <__swc_fn_e121059d_000138_a4ba10ed>:
  409da0:	push   rdi
  409da1:	push   rsi
  409da2:	sub    rsp,0xb8
  409da9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409daf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409db5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409dbb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409dc1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409dc7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409dcd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409dd3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409ddc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409de5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409dee:	mov    edi,0x1
  409df3:	xor    eax,eax
  409df5:	call   407140 <__x86_get_cpuid_feature_leaf@plt>
  409dfa:	mov    eax,DWORD PTR [rax+0x14]
  409dfd:	and    eax,0x20
  409e00:	setne  al
  409e03:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409e09:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409e0f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409e15:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409e1b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409e21:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409e27:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409e2d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409e36:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409e3f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409e48:	add    rsp,0xb8
  409e4f:	pop    rsi
  409e50:	pop    rdi
  409e51:	ret
	...

0000000000409e60 <__swc_fn_e121059d_000141_c6b99a56>:
  409e60:	push   rsi
  409e61:	push   rdi
  409e62:	push   r12
  409e64:	push   r13
  409e66:	push   r14
  409e68:	push   r15
  409e6a:	cmp    rdx,0x40
  409e6e:	jae    409e7d <__swc_fn_e121059d_000141_c6b99a56+0x1d>
  409e70:	xor    eax,eax
  409e72:	pop    r15
  409e74:	pop    r14
  409e76:	pop    r13
  409e78:	pop    r12
  409e7a:	pop    rdi
  409e7b:	pop    rsi
  409e7c:	ret
  409e7d:	cmp    BYTE PTR [rcx],0x7f
  409e80:	jne    409ec4 <__swc_fn_e121059d_000141_c6b99a56+0x64>
  409e82:	movzx  eax,BYTE PTR [rcx+0x1]
  409e86:	cmp    eax,0x45
  409e89:	setne  al
  409e8c:	jne    409ec0 <__swc_fn_e121059d_000141_c6b99a56+0x60>
  409e8e:	movzx  eax,BYTE PTR [rcx+0x2]
  409e92:	cmp    eax,0x4c
  409e95:	setne  al
  409e98:	jne    409ec0 <__swc_fn_e121059d_000141_c6b99a56+0x60>
  409e9a:	movzx  eax,BYTE PTR [rcx+0x3]
  409e9e:	cmp    eax,0x46
  409ea1:	setne  al
  409ea4:	jne    409ec0 <__swc_fn_e121059d_000141_c6b99a56+0x60>
  409ea6:	cmp    BYTE PTR [rcx+0x4],0x2
  409eaa:	setne  al
  409ead:	jne    409ec0 <__swc_fn_e121059d_000141_c6b99a56+0x60>
  409eaf:	cmp    BYTE PTR [rcx+0x5],0x1
  409eb3:	setne  al
  409eb6:	jne    409ec0 <__swc_fn_e121059d_000141_c6b99a56+0x60>
  409eb8:	cmp    WORD PTR [rcx+0x12],0x3e
  409ebd:	setne  al
  409ec0:	test   al,al
  409ec2:	je     409ed1 <__swc_fn_e121059d_000141_c6b99a56+0x71>
  409ec4:	xor    eax,eax
  409ec6:	pop    r15
  409ec8:	pop    r14
  409eca:	pop    r13
  409ecc:	pop    r12
  409ece:	pop    rdi
  409ecf:	pop    rsi
  409ed0:	ret
  409ed1:	cmp    WORD PTR [rcx+0x3a],0x40
  409ed6:	jne    409ef1 <__swc_fn_e121059d_000141_c6b99a56+0x91>
  409ed8:	cmp    WORD PTR [rcx+0x3c],0x0
  409edd:	sete   al
  409ee0:	je     409eed <__swc_fn_e121059d_000141_c6b99a56+0x8d>
  409ee2:	mov    ax,WORD PTR [rcx+0x3c]
  409ee6:	cmp    WORD PTR [rcx+0x3e],ax
  409eea:	setae  al
  409eed:	test   al,al
  409eef:	je     409efe <__swc_fn_e121059d_000141_c6b99a56+0x9e>
  409ef1:	xor    eax,eax
  409ef3:	pop    r15
  409ef5:	pop    r14
  409ef7:	pop    r13
  409ef9:	pop    r12
  409efb:	pop    rdi
  409efc:	pop    rsi
  409efd:	ret
  409efe:	movzx  eax,WORD PTR [rcx+0x3c]
  409f02:	shl    rax,0x6
  409f06:	cmp    rax,rdx
  409f09:	ja     409f17 <__swc_fn_e121059d_000141_c6b99a56+0xb7>
  409f0b:	mov    r9,rdx
  409f0e:	sub    r9,rax
  409f11:	cmp    QWORD PTR [rcx+0x28],r9
  409f15:	jbe    409f24 <__swc_fn_e121059d_000141_c6b99a56+0xc4>
  409f17:	xor    eax,eax
  409f19:	pop    r15
  409f1b:	pop    r14
  409f1d:	pop    r13
  409f1f:	pop    r12
  409f21:	pop    rdi
  409f22:	pop    rsi
  409f23:	ret
  409f24:	mov    rax,QWORD PTR [rcx+0x28]
  409f28:	add    rax,rcx
  409f2b:	movzx  r9d,WORD PTR [rcx+0x3e]
  409f30:	lea    r9,[r9*8+0x0]
  409f38:	lea    r10,[rax+r9*8]
  409f3c:	cmp    QWORD PTR [r10+0x20],rdx
  409f40:	ja     409f62 <__swc_fn_e121059d_000141_c6b99a56+0x102>
  409f42:	mov    r11,rdx
  409f45:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  409f4a:	cmp    QWORD PTR [r10+0x18],r11
  409f4e:	seta   r9b
  409f52:	ja     409f5d <__swc_fn_e121059d_000141_c6b99a56+0xfd>
  409f54:	cmp    QWORD PTR [r10+0x20],0x9
  409f59:	setb   r9b
  409f5d:	test   r9b,r9b
  409f60:	je     409f6f <__swc_fn_e121059d_000141_c6b99a56+0x10f>
  409f62:	xor    eax,eax
  409f64:	pop    r15
  409f66:	pop    r14
  409f68:	pop    r13
  409f6a:	pop    r12
  409f6c:	pop    rdi
  409f6d:	pop    rsi
  409f6e:	ret
  409f6f:	movzx  r9d,WORD PTR [rcx+0x3c]
  409f74:	xor    r11d,r11d
  409f77:	test   r9,r9
  409f7a:	jbe    40a075 <__swc_fn_e121059d_000141_c6b99a56+0x215>
  409f80:	mov    rsi,QWORD PTR [r10+0x20]
  409f84:	sub    rsi,0x9
  409f88:	cs nop WORD PTR [rax+rax*1+0x0]
  409f92:	cs nop WORD PTR [rax+rax*1+0x0]
  409f9c:	nop    DWORD PTR [rax+0x0]
  409fa0:	movzx  edi,r11w
  409fa4:	lea    rdi,[rdi*8+0x0]
  409fac:	lea    r12,[rax+rdi*8]
  409fb0:	rex mov edi,DWORD PTR [rax+rdi*8]
  409fb4:	cmp    rdi,rsi
  409fb7:	ja     40a068 <__swc_fn_e121059d_000141_c6b99a56+0x208>
  409fbd:	mov    r13,QWORD PTR [r10+0x18]
  409fc1:	add    r13,rdi
  409fc4:	lea    rdi,[rcx+r13*1]
  409fc8:	lea    r13,[rip+0x9561]        # 413530 <__swc_rdata_base_e121059d+0x420>
  409fcf:	movabs r14,0x676264676177732e
  409fd9:	cmp    QWORD PTR [rdi],r14
  409fdc:	jne    409fe5 <__swc_fn_e121059d_000141_c6b99a56+0x185>
  409fde:	rex cmp BYTE PTR [rdi+0x8],0x0
  409fe3:	je     40a012 <__swc_fn_e121059d_000141_c6b99a56+0x1b2>
  409fe5:	cs nop WORD PTR [rax+rax*1+0x0]
  409fef:	nop
  409ff0:	movzx  r14d,BYTE PTR [rdi]
  409ff4:	movzx  r15d,BYTE PTR [r13+0x0]
  409ff9:	cmp    r14,r15
  409ffc:	jne    40a008 <__swc_fn_e121059d_000141_c6b99a56+0x1a8>
  409ffe:	add    rdi,0x1
  40a002:	add    r13,0x1
  40a006:	jmp    409ff0 <__swc_fn_e121059d_000141_c6b99a56+0x190>
  40a008:	mov    rdi,r14
  40a00b:	sub    rdi,r15
  40a00e:	test   edi,edi
  40a010:	jne    40a068 <__swc_fn_e121059d_000141_c6b99a56+0x208>
  40a012:	cmp    DWORD PTR [r12+0x4],0x1
  40a018:	jne    40a040 <__swc_fn_e121059d_000141_c6b99a56+0x1e0>
  40a01a:	cmp    QWORD PTR [r12+0x20],0x10
  40a020:	setb   al
  40a023:	jb     40a03c <__swc_fn_e121059d_000141_c6b99a56+0x1dc>
  40a025:	cmp    QWORD PTR [r12+0x20],rdx
  40a02a:	seta   al
  40a02d:	ja     40a03c <__swc_fn_e121059d_000141_c6b99a56+0x1dc>
  40a02f:	sub    rdx,QWORD PTR [r12+0x20]
  40a034:	cmp    QWORD PTR [r12+0x18],rdx
  40a039:	seta   al
  40a03c:	test   al,al
  40a03e:	je     40a04d <__swc_fn_e121059d_000141_c6b99a56+0x1ed>
  40a040:	xor    eax,eax
  40a042:	pop    r15
  40a044:	pop    r14
  40a046:	pop    r13
  40a048:	pop    r12
  40a04a:	pop    rdi
  40a04b:	pop    rsi
  40a04c:	ret
  40a04d:	mov    rax,QWORD PTR [r12+0x20]
  40a052:	mov    QWORD PTR [r8],rax
  40a055:	mov    rax,QWORD PTR [r12+0x18]
  40a05a:	add    rax,rcx
  40a05d:	pop    r15
  40a05f:	pop    r14
  40a061:	pop    r13
  40a063:	pop    r12
  40a065:	pop    rdi
  40a066:	pop    rsi
  40a067:	ret
  40a068:	add    r11,0x1
  40a06c:	cmp    r11,r9
  40a06f:	jb     409fa0 <__swc_fn_e121059d_000141_c6b99a56+0x140>
  40a075:	xor    eax,eax
  40a077:	pop    r15
  40a079:	pop    r14
  40a07b:	pop    r13
  40a07d:	pop    r12
  40a07f:	pop    rdi
  40a080:	pop    rsi
  40a081:	ret
	...

000000000040a090 <__swc_fn_e121059d_000144_81c0d993>:
  40a090:	push   rdi
  40a091:	push   rsi
  40a092:	sub    rsp,0xa8
  40a099:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a09f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a0a5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a0ab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a0b1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a0b7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a0bd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a0c3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a0c9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a0d2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a0db:	mov    rdi,rcx
  40a0de:	xor    eax,eax
  40a0e0:	call   407150 <free@plt>
  40a0e5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a0eb:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a0f1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a0f7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a0fd:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a103:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a109:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a10f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a115:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a11e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a127:	add    rsp,0xa8
  40a12e:	pop    rsi
  40a12f:	pop    rdi
  40a130:	ret
	...

000000000040a140 <__swc_fn_e121059d_000147_43f4fdca>:
  40a140:	push   rbx
  40a141:	push   rsi
  40a142:	push   rdi
  40a143:	push   r12
  40a145:	push   r13
  40a147:	push   r15
  40a149:	sub    rsp,0x4e8
  40a150:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  40a159:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  40a162:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  40a16b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  40a174:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  40a17d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  40a186:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  40a18f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  40a198:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  40a1a1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  40a1aa:	mov    rbx,QWORD PTR [rcx]
  40a1ad:	mov    rcx,QWORD PTR [rcx+0x8]
  40a1b1:	mov    rsi,rcx
  40a1b4:	xor    edi,edi
  40a1b6:	vmovsd xmm6,QWORD PTR [rip+0x93d2]        # 413590 <__swc_rdata_base_e121059d+0x480>
  40a1be:	vmovsd xmm7,QWORD PTR [rip+0x93d3]        # 413599 <__swc_rdata_base_e121059d+0x489>
  40a1c6:	vmovsd xmm8,QWORD PTR [rip+0x93d4]        # 4135a2 <__swc_rdata_base_e121059d+0x492>
  40a1ce:	vmovsd xmm9,QWORD PTR [rip+0x93d5]        # 4135ab <__swc_rdata_base_e121059d+0x49b>
  40a1d6:	vmovsd xmm10,QWORD PTR [rip+0x93d6]        # 4135b4 <__swc_rdata_base_e121059d+0x4a4>
  40a1de:	vmovups xmm11,xmm6
  40a1e2:	vmovsd QWORD PTR [rsp+0x418],xmm7
  40a1eb:	vmovsd QWORD PTR [rsp+0x420],xmm8
  40a1f4:	vmovsd QWORD PTR [rsp+0x428],xmm9
  40a1fd:	vmovsd QWORD PTR [rsp+0x430],xmm10
  40a206:	vmovsd xmm15,QWORD PTR [rip+0x93af]        # 4135bd <__swc_rdata_base_e121059d+0x4ad>
  40a20e:	vmovups xmm14,xmm15
  40a213:	vmovups xmm0,xmm9
  40a218:	vmovsd QWORD PTR [rsp+0x438],xmm15
  40a221:	vmovups xmm13,xmm8
  40a226:	vmovsd QWORD PTR [rsp+0x440],xmm15
  40a22f:	test   rsi,rsi
  40a232:	je     40b263 <__swc_fn_e121059d_000147_43f4fdca+0x1123>
  40a238:	cs nop WORD PTR [rax+rax*1+0x0]
  40a242:	cs nop WORD PTR [rax+rax*1+0x0]
  40a24c:	nop    DWORD PTR [rax+0x0]
  40a250:	lea    rcx,[rdi+rdi*1]
  40a254:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  40a259:	vpshufd xmm3,xmm2,0xee
  40a25e:	vmovq  rcx,xmm3
  40a263:	test   rcx,rcx
  40a266:	je     40a27c <__swc_fn_e121059d_000147_43f4fdca+0x13c>
  40a268:	test   DWORD PTR [rcx+0x28],0x400000
  40a26f:	je     40a27c <__swc_fn_e121059d_000147_43f4fdca+0x13c>
  40a271:	mov    rdx,QWORD PTR [rcx+0x30]
  40a275:	test   rdx,rdx
  40a278:	cmovne rcx,rdx
  40a27c:	test   DWORD PTR [rcx+0x28],0x1000
  40a283:	je     40a2a4 <__swc_fn_e121059d_000147_43f4fdca+0x164>
  40a285:	mov    rdx,QWORD PTR [rcx+0x40]
  40a289:	mov    rcx,rdx
  40a28c:	vmovq  r8,xmm2
  40a291:	mov    r8,QWORD PTR [r8]
  40a294:	mov    QWORD PTR [rsp+0x60],r8
  40a299:	mov    QWORD PTR [rsp+0x68],rdx
  40a29e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  40a2a4:	test   BYTE PTR [rcx+0x28],0x1
  40a2a8:	jne    40a2b0 <__swc_fn_e121059d_000147_43f4fdca+0x170>
  40a2aa:	vmovups xmm12,xmm0
  40a2ae:	jmp    40a2ca <__swc_fn_e121059d_000147_43f4fdca+0x18a>
  40a2b0:	vmovq  rax,xmm2
  40a2b5:	mov    rax,QWORD PTR [rax]
  40a2b8:	lea    rcx,[rax+0x10]
  40a2bc:	vmovups xmm12,xmm0
  40a2c0:	call   4098c0 <__swc_fn_e121059d_000117_035d76a1>
  40a2c5:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40a2ca:	test   DWORD PTR [rcx+0x28],0x400
  40a2d1:	je     40a332 <__swc_fn_e121059d_000147_43f4fdca+0x1f2>
  40a2d3:	vmovq  rax,xmm2
  40a2d8:	mov    rax,QWORD PTR [rax]
  40a2db:	xor    ecx,ecx
  40a2dd:	test   rax,rax
  40a2e0:	je     40a310 <__swc_fn_e121059d_000147_43f4fdca+0x1d0>
  40a2e2:	mov    rdx,rax
  40a2e5:	mov    r8b,BYTE PTR [rdx]
  40a2e8:	test   r8b,r8b
  40a2eb:	je     40a310 <__swc_fn_e121059d_000147_43f4fdca+0x1d0>
  40a2ed:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2f7:	nop    WORD PTR [rax+rax*1+0x0]
  40a300:	add    rdx,0x1
  40a304:	add    rcx,0x1
  40a308:	mov    r8b,BYTE PTR [rdx]
  40a30b:	test   r8b,r8b
  40a30e:	jne    40a300 <__swc_fn_e121059d_000147_43f4fdca+0x1c0>
  40a310:	mov    QWORD PTR [rsp+0x88],rax
  40a318:	mov    QWORD PTR [rsp+0x90],rcx
  40a320:	lea    rcx,[rsp+0x88]
  40a328:	call   4098c0 <__swc_fn_e121059d_000117_035d76a1>
  40a32d:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40a332:	cmp    BYTE PTR [rcx+0x2c],0x6
  40a336:	jne    40a34d <__swc_fn_e121059d_000147_43f4fdca+0x20d>
  40a338:	vmovq  rax,xmm2
  40a33d:	mov    rax,QWORD PTR [rax]
  40a340:	mov    rcx,rax
  40a343:	call   40e510 <__swc_fn_e121059d_000145_72996a5b>
  40a348:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40a34d:	cmp    BYTE PTR [rcx+0x2c],0x1
  40a351:	jne    40b239 <__swc_fn_e121059d_000147_43f4fdca+0x10f9>
  40a357:	vmovq  rdx,xmm2
  40a35c:	mov    cl,BYTE PTR [rcx+0x40]
  40a35f:	cmp    cl,0x7
  40a362:	jb     40a3a5 <__swc_fn_e121059d_000147_43f4fdca+0x265>
  40a364:	je     40a418 <__swc_fn_e121059d_000147_43f4fdca+0x2d8>
  40a36a:	cmp    cl,0x8
  40a36d:	je     40a424 <__swc_fn_e121059d_000147_43f4fdca+0x2e4>
  40a373:	cmp    cl,0x9
  40a376:	je     40a43d <__swc_fn_e121059d_000147_43f4fdca+0x2fd>
  40a37c:	cmp    cl,0xa
  40a37f:	je     40ab24 <__swc_fn_e121059d_000147_43f4fdca+0x9e4>
  40a385:	cmp    cl,0xb
  40a388:	je     40b20b <__swc_fn_e121059d_000147_43f4fdca+0x10cb>
  40a38e:	cmp    cl,0xc
  40a391:	je     40a431 <__swc_fn_e121059d_000147_43f4fdca+0x2f1>
  40a397:	cmp    cl,0xd
  40a39a:	je     40b201 <__swc_fn_e121059d_000147_43f4fdca+0x10c1>
  40a3a0:	jmp    40b22b <__swc_fn_e121059d_000147_43f4fdca+0x10eb>
  40a3a5:	cmp    cl,0x1
  40a3a8:	je     40a3c8 <__swc_fn_e121059d_000147_43f4fdca+0x288>
  40a3aa:	cmp    cl,0x2
  40a3ad:	je     40a3d6 <__swc_fn_e121059d_000147_43f4fdca+0x296>
  40a3af:	cmp    cl,0x3
  40a3b2:	je     40a3e4 <__swc_fn_e121059d_000147_43f4fdca+0x2a4>
  40a3b4:	cmp    cl,0x4
  40a3b7:	je     40a3f1 <__swc_fn_e121059d_000147_43f4fdca+0x2b1>
  40a3b9:	cmp    cl,0x5
  40a3bc:	je     40a3fe <__swc_fn_e121059d_000147_43f4fdca+0x2be>
  40a3be:	cmp    cl,0x6
  40a3c1:	je     40a40b <__swc_fn_e121059d_000147_43f4fdca+0x2cb>
  40a3c3:	jmp    40b22b <__swc_fn_e121059d_000147_43f4fdca+0x10eb>
  40a3c8:	movsx  rcx,BYTE PTR [rdx]
  40a3cc:	call   411360 <__swc_fn_e121059d_000146_863755b5>
  40a3d1:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40a3d6:	movsx  rcx,WORD PTR [rdx]
  40a3da:	call   411360 <__swc_fn_e121059d_000146_863755b5>
  40a3df:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40a3e4:	movsxd rcx,DWORD PTR [rdx]
  40a3e7:	call   411360 <__swc_fn_e121059d_000146_863755b5>
  40a3ec:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40a3f1:	mov    rcx,QWORD PTR [rdx]
  40a3f4:	call   411360 <__swc_fn_e121059d_000146_863755b5>
  40a3f9:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40a3fe:	movzx  ecx,BYTE PTR [rdx]
  40a401:	call   40e510 <__swc_fn_e121059d_000145_72996a5b>
  40a406:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40a40b:	movzx  ecx,WORD PTR [rdx]
  40a40e:	call   40e510 <__swc_fn_e121059d_000145_72996a5b>
  40a413:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40a418:	mov    ecx,DWORD PTR [rdx]
  40a41a:	call   40e510 <__swc_fn_e121059d_000145_72996a5b>
  40a41f:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40a424:	mov    rcx,QWORD PTR [rdx]
  40a427:	call   40e510 <__swc_fn_e121059d_000145_72996a5b>
  40a42c:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40a431:	mov    ecx,DWORD PTR [rdx]
  40a433:	call   40e510 <__swc_fn_e121059d_000145_72996a5b>
  40a438:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40a43d:	lea    rcx,[rsp+0xa8]
  40a445:	vxorps xmm0,xmm0,xmm0
  40a449:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40a452:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40a45b:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  40a464:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  40a46d:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40a476:	vmovups XMMWORD PTR [rsp+0xf8],xmm0
  40a47f:	mov    DWORD PTR [rsp+0x108],0x0
  40a48a:	vxorpd xmm0,xmm0,xmm0
  40a48e:	vmovss xmm1,DWORD PTR [rdx]
  40a492:	vcvtss2sd xmm0,xmm0,xmm1
  40a496:	vmovsd xmm1,xmm1,xmm0
  40a49a:	vcomisd xmm0,xmm0
  40a49e:	setne  dl
  40a4a1:	movzx  edx,dl
  40a4a4:	setp   r8b
  40a4a8:	movzx  r8d,r8b
  40a4ac:	or     edx,r8d
  40a4af:	test   dl,dl
  40a4b1:	je     40a4be <__swc_fn_e121059d_000147_43f4fdca+0x37e>
  40a4b3:	mov    DWORD PTR [rcx],0x6e616e
  40a4b9:	jmp    40aab8 <__swc_fn_e121059d_000147_43f4fdca+0x978>
  40a4be:	vcomisd xmm1,xmm6
  40a4c2:	ja     40a4ca <__swc_fn_e121059d_000147_43f4fdca+0x38a>
  40a4c4:	vcomisd xmm7,xmm1
  40a4c8:	jbe    40a4ee <__swc_fn_e121059d_000147_43f4fdca+0x3ae>
  40a4ca:	vxorpd xmm0,xmm0,xmm0
  40a4ce:	vcomisd xmm0,xmm1
  40a4d2:	jbe    40a4e3 <__swc_fn_e121059d_000147_43f4fdca+0x3a3>
  40a4d4:	mov    DWORD PTR [rcx],0x666e692d
  40a4da:	mov    BYTE PTR [rcx+0x4],0x0
  40a4de:	jmp    40aab8 <__swc_fn_e121059d_000147_43f4fdca+0x978>
  40a4e3:	mov    DWORD PTR [rcx],0x666e69
  40a4e9:	jmp    40aab8 <__swc_fn_e121059d_000147_43f4fdca+0x978>
  40a4ee:	vcomisd xmm1,xmm8
  40a4f3:	jae    40a4ff <__swc_fn_e121059d_000147_43f4fdca+0x3bf>
  40a4f5:	vcomisd xmm9,xmm1
  40a4f9:	jbe    40a87e <__swc_fn_e121059d_000147_43f4fdca+0x73e>
  40a4ff:	vmovups xmm0,xmm1
  40a503:	vxorpd xmm2,xmm2,xmm2
  40a507:	vcomisd xmm2,xmm1
  40a50b:	jbe    40a51b <__swc_fn_e121059d_000147_43f4fdca+0x3db>
  40a50d:	vmovsd xmm1,xmm1,xmm0
  40a511:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x9037]        # 413550 <__swc_rdata_base_e121059d+0x440>
  40a519:	jmp    40a51f <__swc_fn_e121059d_000147_43f4fdca+0x3df>
  40a51b:	vmovsd xmm1,xmm1,xmm0
  40a51f:	xor    r8d,r8d
  40a522:	vcomisd xmm1,xmm15
  40a527:	jb     40a550 <__swc_fn_e121059d_000147_43f4fdca+0x410>
  40a529:	cs nop WORD PTR [rax+rax*1+0x0]
  40a533:	cs nop WORD PTR [rax+rax*1+0x0]
  40a53d:	nop    DWORD PTR [rax]
  40a540:	vdivsd xmm1,xmm1,xmm15
  40a545:	add    r8,0x1
  40a549:	vcomisd xmm1,xmm15
  40a54e:	jae    40a540 <__swc_fn_e121059d_000147_43f4fdca+0x400>
  40a550:	mov    r9,rcx
  40a553:	vxorpd xmm2,xmm2,xmm2
  40a557:	vcomisd xmm2,xmm0
  40a55b:	jbe    40a564 <__swc_fn_e121059d_000147_43f4fdca+0x424>
  40a55d:	mov    BYTE PTR [rcx],0x2d
  40a560:	lea    r9,[rcx+0x1]
  40a564:	vcvttsd2si rdx,xmm1
  40a569:	mov    r10b,dl
  40a56c:	add    r10b,0x30
  40a570:	mov    BYTE PTR [r9],r10b
  40a573:	vxorpd xmm0,xmm0,xmm0
  40a577:	movzx  edx,dl
  40a57a:	vcvtsi2sd xmm0,xmm0,rdx
  40a57f:	vsubsd xmm0,xmm1,xmm0
  40a583:	vmulsd xmm1,xmm0,xmm15
  40a588:	mov    BYTE PTR [r9+0x1],0x2e
  40a58d:	vcvttsd2si rdx,xmm1
  40a592:	mov    r10b,dl
  40a595:	add    r10b,0x30
  40a599:	mov    BYTE PTR [r9+0x2],r10b
  40a59d:	vxorpd xmm0,xmm0,xmm0
  40a5a1:	movzx  edx,dl
  40a5a4:	vcvtsi2sd xmm0,xmm0,rdx
  40a5a9:	vsubsd xmm0,xmm1,xmm0
  40a5ad:	vmulsd xmm1,xmm0,xmm15
  40a5b2:	vcvttsd2si rdx,xmm1
  40a5b7:	mov    r10b,dl
  40a5ba:	add    r10b,0x30
  40a5be:	mov    BYTE PTR [r9+0x3],r10b
  40a5c2:	vxorpd xmm0,xmm0,xmm0
  40a5c6:	movzx  edx,dl
  40a5c9:	vcvtsi2sd xmm0,xmm0,rdx
  40a5ce:	vsubsd xmm0,xmm1,xmm0
  40a5d2:	vmulsd xmm1,xmm0,xmm15
  40a5d7:	vcvttsd2si rdx,xmm1
  40a5dc:	mov    r10b,dl
  40a5df:	add    r10b,0x30
  40a5e3:	mov    BYTE PTR [r9+0x4],r10b
  40a5e7:	vxorpd xmm0,xmm0,xmm0
  40a5eb:	movzx  edx,dl
  40a5ee:	vcvtsi2sd xmm0,xmm0,rdx
  40a5f3:	vsubsd xmm0,xmm1,xmm0
  40a5f7:	vmulsd xmm1,xmm0,xmm15
  40a5fc:	vcvttsd2si rdx,xmm1
  40a601:	mov    r10b,dl
  40a604:	add    r10b,0x30
  40a608:	mov    BYTE PTR [r9+0x5],r10b
  40a60c:	vxorpd xmm0,xmm0,xmm0
  40a610:	movzx  edx,dl
  40a613:	vcvtsi2sd xmm0,xmm0,rdx
  40a618:	vsubsd xmm0,xmm1,xmm0
  40a61c:	vmulsd xmm1,xmm0,xmm15
  40a621:	vcvttsd2si rdx,xmm1
  40a626:	mov    r10b,dl
  40a629:	add    r10b,0x30
  40a62d:	mov    BYTE PTR [r9+0x6],r10b
  40a631:	vxorpd xmm0,xmm0,xmm0
  40a635:	movzx  edx,dl
  40a638:	vcvtsi2sd xmm0,xmm0,rdx
  40a63d:	vsubsd xmm0,xmm1,xmm0
  40a641:	vmulsd xmm1,xmm0,xmm15
  40a646:	vcvttsd2si rdx,xmm1
  40a64b:	mov    r10b,dl
  40a64e:	add    r10b,0x30
  40a652:	mov    BYTE PTR [r9+0x7],r10b
  40a656:	vxorpd xmm0,xmm0,xmm0
  40a65a:	movzx  edx,dl
  40a65d:	vcvtsi2sd xmm0,xmm0,rdx
  40a662:	vsubsd xmm0,xmm1,xmm0
  40a666:	vmulsd xmm1,xmm0,xmm15
  40a66b:	vcvttsd2si rdx,xmm1
  40a670:	mov    r10b,dl
  40a673:	add    r10b,0x30
  40a677:	mov    BYTE PTR [r9+0x8],r10b
  40a67b:	vxorpd xmm0,xmm0,xmm0
  40a67f:	movzx  edx,dl
  40a682:	vcvtsi2sd xmm0,xmm0,rdx
  40a687:	vsubsd xmm0,xmm1,xmm0
  40a68b:	vmulsd xmm1,xmm0,xmm15
  40a690:	vcvttsd2si rdx,xmm1
  40a695:	mov    r10b,dl
  40a698:	add    r10b,0x30
  40a69c:	mov    BYTE PTR [r9+0x9],r10b
  40a6a0:	vxorpd xmm0,xmm0,xmm0
  40a6a4:	movzx  edx,dl
  40a6a7:	vcvtsi2sd xmm0,xmm0,rdx
  40a6ac:	vsubsd xmm0,xmm1,xmm0
  40a6b0:	vmulsd xmm1,xmm0,xmm15
  40a6b5:	vcvttsd2si rdx,xmm1
  40a6ba:	mov    r10b,dl
  40a6bd:	add    r10b,0x30
  40a6c1:	mov    BYTE PTR [r9+0xa],r10b
  40a6c5:	vxorpd xmm0,xmm0,xmm0
  40a6c9:	movzx  edx,dl
  40a6cc:	vcvtsi2sd xmm0,xmm0,rdx
  40a6d1:	vsubsd xmm0,xmm1,xmm0
  40a6d5:	vmulsd xmm1,xmm0,xmm15
  40a6da:	vcvttsd2si rdx,xmm1
  40a6df:	mov    r10b,dl
  40a6e2:	add    r10b,0x30
  40a6e6:	mov    BYTE PTR [r9+0xb],r10b
  40a6ea:	lea    r10,[r9+0x4]
  40a6ee:	vxorpd xmm0,xmm0,xmm0
  40a6f2:	movzx  edx,dl
  40a6f5:	vcvtsi2sd xmm0,xmm0,rdx
  40a6fa:	vsubsd xmm0,xmm1,xmm0
  40a6fe:	vmulsd xmm1,xmm0,xmm15
  40a703:	vcvttsd2si rdx,xmm1
  40a708:	mov    r11b,dl
  40a70b:	add    r11b,0x30
  40a70f:	mov    BYTE PTR [r9+0xc],r11b
  40a713:	vxorpd xmm0,xmm0,xmm0
  40a717:	movzx  edx,dl
  40a71a:	vcvtsi2sd xmm0,xmm0,rdx
  40a71f:	vsubsd xmm0,xmm1,xmm0
  40a723:	vmulsd xmm1,xmm0,xmm15
  40a728:	vcvttsd2si rdx,xmm1
  40a72d:	mov    r11b,dl
  40a730:	add    r11b,0x30
  40a734:	mov    BYTE PTR [r9+0xd],r11b
  40a738:	lea    r10,[r10+0x2]
  40a73c:	vxorpd xmm0,xmm0,xmm0
  40a740:	movzx  edx,dl
  40a743:	vcvtsi2sd xmm0,xmm0,rdx
  40a748:	vsubsd xmm0,xmm1,xmm0
  40a74c:	vmulsd xmm1,xmm0,xmm15
  40a751:	vcvttsd2si rdx,xmm1
  40a756:	mov    r11b,dl
  40a759:	add    r11b,0x30
  40a75d:	mov    BYTE PTR [r9+0xe],r11b
  40a761:	vxorpd xmm0,xmm0,xmm0
  40a765:	movzx  edx,dl
  40a768:	vcvtsi2sd xmm0,xmm0,rdx
  40a76d:	vsubsd xmm0,xmm1,xmm0
  40a771:	vmulsd xmm1,xmm0,xmm15
  40a776:	vcvttsd2si rdx,xmm1
  40a77b:	mov    r11b,dl
  40a77e:	add    r11b,0x30
  40a782:	mov    BYTE PTR [r9+0xf],r11b
  40a786:	lea    r10,[r10+0x2]
  40a78a:	lea    r10,[r10+0x2]
  40a78e:	lea    r10,[r10+0x2]
  40a792:	lea    r10,[r10+0x2]
  40a796:	lea    r10,[r10+0x2]
  40a79a:	vxorpd xmm0,xmm0,xmm0
  40a79e:	movzx  edx,dl
  40a7a1:	vcvtsi2sd xmm0,xmm0,rdx
  40a7a6:	vsubsd xmm0,xmm1,xmm0
  40a7aa:	vmulsd xmm1,xmm0,xmm15
  40a7af:	vcvttsd2si rdx,xmm1
  40a7b4:	mov    r11b,dl
  40a7b7:	add    r11b,0x30
  40a7bb:	mov    BYTE PTR [r9+0x10],r11b
  40a7bf:	vxorpd xmm0,xmm0,xmm0
  40a7c3:	movzx  edx,dl
  40a7c6:	vcvtsi2sd xmm0,xmm0,rdx
  40a7cb:	vsubsd xmm0,xmm1,xmm0
  40a7cf:	vmulsd xmm1,xmm0,xmm15
  40a7d4:	vcvttsd2si rdx,xmm1
  40a7d9:	add    dl,0x30
  40a7dc:	mov    BYTE PTR [r9+0x11],dl
  40a7e0:	mov    BYTE PTR [r10+0x2],0x65
  40a7e5:	lea    r9,[r10+0x3]
  40a7e9:	test   r8,r8
  40a7ec:	jl     40a7f5 <__swc_fn_e121059d_000147_43f4fdca+0x6b5>
  40a7ee:	mov    BYTE PTR [r9],0x2b
  40a7f2:	inc    r9
  40a7f5:	mov    r10,r9
  40a7f8:	mov    rdx,r8
  40a7fb:	nop    DWORD PTR [rax+rax*1+0x0]
  40a800:	mov    r11,rdx
  40a803:	movabs rdx,0x6666666666666667
  40a80d:	mov    rax,r11
  40a810:	imul   rdx
  40a813:	sar    rdx,0x2
  40a817:	mov    r12,rdx
  40a81a:	shr    rdx,0x3f
  40a81e:	add    r12,rdx
  40a821:	mov    rdx,r12
  40a824:	imul   r13,r12,0xa
  40a828:	sub    r11,r13
  40a82b:	mov    r13,QWORD PTR [rip+0x8d0e]        # 413540 <__swc_rdata_base_e121059d+0x430>
  40a832:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a837:	mov    BYTE PTR [r10],r11b
  40a83a:	lea    r11,[r10+0x1]
  40a83e:	mov    r10,r11
  40a841:	test   r12,r12
  40a844:	jne    40a800 <__swc_fn_e121059d_000147_43f4fdca+0x6c0>
  40a846:	test   r8,r8
  40a849:	jge    40a853 <__swc_fn_e121059d_000147_43f4fdca+0x713>
  40a84b:	mov    BYTE PTR [r11],0x2d
  40a84f:	lea    r10,[r11+0x1]
  40a853:	mov    BYTE PTR [r10],0x0
  40a857:	sub    r10,0x1
  40a85b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a860:	cmp    r9,r10
  40a863:	jae    40aab8 <__swc_fn_e121059d_000147_43f4fdca+0x978>
  40a869:	mov    al,BYTE PTR [r10]
  40a86c:	mov    dl,BYTE PTR [r9]
  40a86f:	mov    BYTE PTR [r10],dl
  40a872:	sub    r10,0x1
  40a876:	mov    BYTE PTR [r9],al
  40a879:	inc    r9
  40a87c:	jmp    40a860 <__swc_fn_e121059d_000147_43f4fdca+0x720>
  40a87e:	vcvttsd2si rdx,xmm1
  40a883:	mov    r8,rdx
  40a886:	vxorpd xmm0,xmm0,xmm0
  40a88a:	vcvtsi2sd xmm0,xmm0,rdx
  40a88f:	vsubsd xmm0,xmm1,xmm0
  40a893:	mov    r9d,0x8
  40a899:	vxorpd xmm2,xmm2,xmm2
  40a89d:	vcomisd xmm2,xmm0
  40a8a1:	jbe    40a8ab <__swc_fn_e121059d_000147_43f4fdca+0x76b>
  40a8a3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x8ca5]        # 413550 <__swc_rdata_base_e121059d+0x440>
  40a8ab:	test   r9d,r9d
  40a8ae:	je     40a8ba <__swc_fn_e121059d_000147_43f4fdca+0x77a>
  40a8b0:	vmulsd xmm0,xmm0,xmm14
  40a8b5:	dec    r9d
  40a8b8:	jne    40a8b0 <__swc_fn_e121059d_000147_43f4fdca+0x770>
  40a8ba:	vcvttsd2si r9,xmm0
  40a8bf:	mov    r10,r9
  40a8c2:	vxorpd xmm2,xmm2,xmm2
  40a8c6:	vcvtsi2sd xmm2,xmm2,r9
  40a8cb:	vsubsd xmm0,xmm0,xmm2
  40a8cf:	vcomisd xmm0,xmm10
  40a8d4:	lea    r9,[r9+0x1]
  40a8d8:	cmova  r10,r9
  40a8dc:	cmp    r10,0x5f5e100
  40a8e3:	jne    40a8fc <__swc_fn_e121059d_000147_43f4fdca+0x7bc>
  40a8e5:	lea    r8,[rdx-0x1]
  40a8e9:	vxorpd xmm0,xmm0,xmm0
  40a8ed:	vcomisd xmm0,xmm1
  40a8f1:	lea    rdx,[rdx+0x1]
  40a8f5:	cmovbe r8,rdx
  40a8f9:	xor    r10d,r10d
  40a8fc:	mov    r9,rcx
  40a8ff:	test   r8,r8
  40a902:	jne    40a922 <__swc_fn_e121059d_000147_43f4fdca+0x7e2>
  40a904:	vxorpd xmm0,xmm0,xmm0
  40a908:	vcomisd xmm0,xmm1
  40a90c:	jbe    40a915 <__swc_fn_e121059d_000147_43f4fdca+0x7d5>
  40a90e:	mov    BYTE PTR [rcx],0x2d
  40a911:	lea    r9,[rcx+0x1]
  40a915:	mov    BYTE PTR [r9],0x30
  40a919:	add    r9,0x1
  40a91d:	jmp    40a9bb <__swc_fn_e121059d_000147_43f4fdca+0x87b>
  40a922:	mov    r9,rcx
  40a925:	mov    rdx,r8
  40a928:	nop    DWORD PTR [rax+rax*1+0x0]
  40a930:	mov    r11,rdx
  40a933:	movabs rdx,0x6666666666666667
  40a93d:	mov    r15,rax
  40a940:	mov    rax,r11
  40a943:	imul   rdx
  40a946:	mov    r12,rdx
  40a949:	mov    rax,r15
  40a94c:	sar    r12,0x2
  40a950:	mov    rdx,r12
  40a953:	shr    rdx,0x3f
  40a957:	add    r12,rdx
  40a95a:	mov    rdx,r12
  40a95d:	imul   r13,r12,0xa
  40a961:	sub    r11,r13
  40a964:	mov    r13,QWORD PTR [rip+0x8bd5]        # 413540 <__swc_rdata_base_e121059d+0x430>
  40a96b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a970:	mov    BYTE PTR [r9],r11b
  40a973:	lea    r11,[r9+0x1]
  40a977:	mov    r9,r11
  40a97a:	test   r12,r12
  40a97d:	jne    40a930 <__swc_fn_e121059d_000147_43f4fdca+0x7f0>
  40a97f:	test   r8,r8
  40a982:	jge    40a98c <__swc_fn_e121059d_000147_43f4fdca+0x84c>
  40a984:	mov    BYTE PTR [r11],0x2d
  40a988:	lea    r9,[r11+0x1]
  40a98c:	mov    rdx,r9
  40a98f:	mov    BYTE PTR [r9],0x0
  40a993:	sub    r9,0x1
  40a997:	mov    r8,rcx
  40a99a:	cmp    r8,r9
  40a99d:	jae    40a9b8 <__swc_fn_e121059d_000147_43f4fdca+0x878>
  40a99f:	nop
  40a9a0:	mov    r11b,BYTE PTR [r9]
  40a9a3:	mov    r12b,BYTE PTR [r8]
  40a9a6:	mov    BYTE PTR [r9],r12b
  40a9a9:	sub    r9,0x1
  40a9ad:	mov    BYTE PTR [r8],r11b
  40a9b0:	inc    r8
  40a9b3:	cmp    r8,r9
  40a9b6:	jb     40a9a0 <__swc_fn_e121059d_000147_43f4fdca+0x860>
  40a9b8:	mov    r9,rdx
  40a9bb:	mov    BYTE PTR [r9],0x2e
  40a9bf:	add    r9,0x1
  40a9c3:	xor    r8d,r8d
  40a9c6:	test   r10,r10
  40a9c9:	je     40aa0f <__swc_fn_e121059d_000147_43f4fdca+0x8cf>
  40a9cb:	mov    r11d,0x989680
  40a9d1:	cmp    r10,r11
  40a9d4:	jge    40aa0f <__swc_fn_e121059d_000147_43f4fdca+0x8cf>
  40a9d6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9e0:	inc    r8d
  40a9e3:	movabs rdx,0x6666666666666667
  40a9ed:	mov    r15,rax
  40a9f0:	mov    rax,r11
  40a9f3:	imul   rdx
  40a9f6:	mov    r11,rdx
  40a9f9:	mov    rax,r15
  40a9fc:	sar    r11,0x2
  40aa00:	mov    rdx,r11
  40aa03:	shr    rdx,0x3f
  40aa07:	add    r11,rdx
  40aa0a:	cmp    r10,r11
  40aa0d:	jl     40a9e0 <__swc_fn_e121059d_000147_43f4fdca+0x8a0>
  40aa0f:	test   r8d,r8d
  40aa12:	je     40aa2d <__swc_fn_e121059d_000147_43f4fdca+0x8ed>
  40aa14:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa1e:	xchg   ax,ax
  40aa20:	mov    BYTE PTR [r9],0x30
  40aa24:	add    r9,0x1
  40aa28:	dec    r8d
  40aa2b:	jne    40aa20 <__swc_fn_e121059d_000147_43f4fdca+0x8e0>
  40aa2d:	mov    r8,r9
  40aa30:	mov    rdx,r10
  40aa33:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa3d:	nop    DWORD PTR [rax]
  40aa40:	mov    r11,rdx
  40aa43:	movabs rdx,0x6666666666666667
  40aa4d:	mov    rax,r11
  40aa50:	imul   rdx
  40aa53:	sar    rdx,0x2
  40aa57:	mov    r12,rdx
  40aa5a:	shr    rdx,0x3f
  40aa5e:	add    r12,rdx
  40aa61:	mov    rdx,r12
  40aa64:	imul   r13,r12,0xa
  40aa68:	sub    r11,r13
  40aa6b:	mov    r13,QWORD PTR [rip+0x8ace]        # 413540 <__swc_rdata_base_e121059d+0x430>
  40aa72:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40aa77:	mov    BYTE PTR [r8],r11b
  40aa7a:	lea    r11,[r8+0x1]
  40aa7e:	mov    r8,r11
  40aa81:	test   r12,r12
  40aa84:	jne    40aa40 <__swc_fn_e121059d_000147_43f4fdca+0x900>
  40aa86:	test   r10,r10
  40aa89:	jge    40aa93 <__swc_fn_e121059d_000147_43f4fdca+0x953>
  40aa8b:	mov    BYTE PTR [r11],0x2d
  40aa8f:	lea    r8,[r11+0x1]
  40aa93:	mov    BYTE PTR [r8],0x0
  40aa97:	sub    r8,0x1
  40aa9b:	cmp    r9,r8
  40aa9e:	jae    40aab8 <__swc_fn_e121059d_000147_43f4fdca+0x978>
  40aaa0:	mov    al,BYTE PTR [r8]
  40aaa3:	mov    dl,BYTE PTR [r9]
  40aaa6:	mov    BYTE PTR [r8],dl
  40aaa9:	sub    r8,0x1
  40aaad:	mov    BYTE PTR [r9],al
  40aab0:	inc    r9
  40aab3:	cmp    r9,r8
  40aab6:	jb     40aaa0 <__swc_fn_e121059d_000147_43f4fdca+0x960>
  40aab8:	xor    eax,eax
  40aaba:	test   rcx,rcx
  40aabd:	je     40aaf0 <__swc_fn_e121059d_000147_43f4fdca+0x9b0>
  40aabf:	mov    rdx,rcx
  40aac2:	mov    r8b,BYTE PTR [rdx]
  40aac5:	test   r8b,r8b
  40aac8:	je     40aaf0 <__swc_fn_e121059d_000147_43f4fdca+0x9b0>
  40aaca:	cs nop WORD PTR [rax+rax*1+0x0]
  40aad4:	cs nop WORD PTR [rax+rax*1+0x0]
  40aade:	xchg   ax,ax
  40aae0:	add    rdx,0x1
  40aae4:	add    rax,0x1
  40aae8:	mov    r8b,BYTE PTR [rdx]
  40aaeb:	test   r8b,r8b
  40aaee:	jne    40aae0 <__swc_fn_e121059d_000147_43f4fdca+0x9a0>
  40aaf0:	mov    QWORD PTR [rsp+0x240],rcx
  40aaf8:	mov    QWORD PTR [rsp+0x248],rax
  40ab00:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  40ab09:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  40ab12:	lea    rcx,[rsp+0x250]
  40ab1a:	call   4098c0 <__swc_fn_e121059d_000117_035d76a1>
  40ab1f:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40ab24:	lea    rcx,[rsp+0x260]
  40ab2c:	vxorps xmm0,xmm0,xmm0
  40ab30:	vmovups XMMWORD PTR [rsp+0x260],xmm0
  40ab39:	vmovups XMMWORD PTR [rsp+0x270],xmm0
  40ab42:	vmovups XMMWORD PTR [rsp+0x280],xmm0
  40ab4b:	vmovups XMMWORD PTR [rsp+0x290],xmm0
  40ab54:	vmovups XMMWORD PTR [rsp+0x2a0],xmm0
  40ab5d:	vmovups XMMWORD PTR [rsp+0x2b0],xmm0
  40ab66:	mov    DWORD PTR [rsp+0x2c0],0x0
  40ab71:	vmovsd xmm0,QWORD PTR [rdx]
  40ab75:	vcomisd xmm0,xmm0
  40ab79:	setne  dl
  40ab7c:	movzx  edx,dl
  40ab7f:	setp   r8b
  40ab83:	movzx  r8d,r8b
  40ab87:	or     edx,r8d
  40ab8a:	test   dl,dl
  40ab8c:	je     40ab99 <__swc_fn_e121059d_000147_43f4fdca+0xa59>
  40ab8e:	mov    DWORD PTR [rcx],0x6e616e
  40ab94:	jmp    40b1a8 <__swc_fn_e121059d_000147_43f4fdca+0x1068>
  40ab99:	vcomisd xmm0,xmm11
  40ab9e:	ja     40abaf <__swc_fn_e121059d_000147_43f4fdca+0xa6f>
  40aba0:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  40aba9:	vcomisd xmm6,xmm0
  40abad:	jbe    40abd3 <__swc_fn_e121059d_000147_43f4fdca+0xa93>
  40abaf:	vxorpd xmm1,xmm1,xmm1
  40abb3:	vcomisd xmm1,xmm0
  40abb7:	jbe    40abc8 <__swc_fn_e121059d_000147_43f4fdca+0xa88>
  40abb9:	mov    DWORD PTR [rcx],0x666e692d
  40abbf:	mov    BYTE PTR [rcx+0x4],0x0
  40abc3:	jmp    40b1a8 <__swc_fn_e121059d_000147_43f4fdca+0x1068>
  40abc8:	mov    DWORD PTR [rcx],0x666e69
  40abce:	jmp    40b1a8 <__swc_fn_e121059d_000147_43f4fdca+0x1068>
  40abd3:	vcomisd xmm0,xmm13
  40abd8:	jae    40abe4 <__swc_fn_e121059d_000147_43f4fdca+0xaa4>
  40abda:	vcomisd xmm12,xmm0
  40abde:	jbe    40af4e <__swc_fn_e121059d_000147_43f4fdca+0xe0e>
  40abe4:	vmovups xmm1,xmm0
  40abe8:	vxorpd xmm2,xmm2,xmm2
  40abec:	vcomisd xmm2,xmm0
  40abf0:	jbe    40ac00 <__swc_fn_e121059d_000147_43f4fdca+0xac0>
  40abf2:	vmovsd xmm0,xmm0,xmm1
  40abf6:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x8952]        # 413550 <__swc_rdata_base_e121059d+0x440>
  40abfe:	jmp    40ac04 <__swc_fn_e121059d_000147_43f4fdca+0xac4>
  40ac00:	vmovsd xmm0,xmm0,xmm1
  40ac04:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  40ac0d:	xor    r8d,r8d
  40ac10:	vcomisd xmm0,xmm6
  40ac14:	jb     40ac2e <__swc_fn_e121059d_000147_43f4fdca+0xaee>
  40ac16:	cs nop WORD PTR [rax+rax*1+0x0]
  40ac20:	vdivsd xmm0,xmm0,xmm6
  40ac24:	add    r8,0x1
  40ac28:	vcomisd xmm0,xmm6
  40ac2c:	jae    40ac20 <__swc_fn_e121059d_000147_43f4fdca+0xae0>
  40ac2e:	mov    r9,rcx
  40ac31:	vxorpd xmm2,xmm2,xmm2
  40ac35:	vcomisd xmm2,xmm1
  40ac39:	jbe    40ac42 <__swc_fn_e121059d_000147_43f4fdca+0xb02>
  40ac3b:	mov    BYTE PTR [rcx],0x2d
  40ac3e:	lea    r9,[rcx+0x1]
  40ac42:	vcvttsd2si rdx,xmm0
  40ac47:	mov    r10b,dl
  40ac4a:	add    r10b,0x30
  40ac4e:	mov    BYTE PTR [r9],r10b
  40ac51:	vxorpd xmm1,xmm1,xmm1
  40ac55:	movzx  edx,dl
  40ac58:	vcvtsi2sd xmm1,xmm1,rdx
  40ac5d:	vsubsd xmm0,xmm0,xmm1
  40ac61:	vmulsd xmm0,xmm0,xmm6
  40ac65:	mov    BYTE PTR [r9+0x1],0x2e
  40ac6a:	vcvttsd2si rdx,xmm0
  40ac6f:	mov    r10b,dl
  40ac72:	add    r10b,0x30
  40ac76:	mov    BYTE PTR [r9+0x2],r10b
  40ac7a:	vxorpd xmm1,xmm1,xmm1
  40ac7e:	movzx  edx,dl
  40ac81:	vcvtsi2sd xmm1,xmm1,rdx
  40ac86:	vsubsd xmm0,xmm0,xmm1
  40ac8a:	vmulsd xmm0,xmm0,xmm6
  40ac8e:	vcvttsd2si rdx,xmm0
  40ac93:	mov    r10b,dl
  40ac96:	add    r10b,0x30
  40ac9a:	mov    BYTE PTR [r9+0x3],r10b
  40ac9e:	vxorpd xmm1,xmm1,xmm1
  40aca2:	movzx  edx,dl
  40aca5:	vcvtsi2sd xmm1,xmm1,rdx
  40acaa:	vsubsd xmm0,xmm0,xmm1
  40acae:	vmulsd xmm0,xmm0,xmm6
  40acb2:	vcvttsd2si rdx,xmm0
  40acb7:	mov    r10b,dl
  40acba:	add    r10b,0x30
  40acbe:	mov    BYTE PTR [r9+0x4],r10b
  40acc2:	vxorpd xmm1,xmm1,xmm1
  40acc6:	movzx  edx,dl
  40acc9:	vcvtsi2sd xmm1,xmm1,rdx
  40acce:	vsubsd xmm0,xmm0,xmm1
  40acd2:	vmulsd xmm0,xmm0,xmm6
  40acd6:	vcvttsd2si rdx,xmm0
  40acdb:	mov    r10b,dl
  40acde:	add    r10b,0x30
  40ace2:	mov    BYTE PTR [r9+0x5],r10b
  40ace6:	vxorpd xmm1,xmm1,xmm1
  40acea:	movzx  edx,dl
  40aced:	vcvtsi2sd xmm1,xmm1,rdx
  40acf2:	vsubsd xmm0,xmm0,xmm1
  40acf6:	vmulsd xmm0,xmm0,xmm6
  40acfa:	vcvttsd2si rdx,xmm0
  40acff:	mov    r10b,dl
  40ad02:	add    r10b,0x30
  40ad06:	mov    BYTE PTR [r9+0x6],r10b
  40ad0a:	vxorpd xmm1,xmm1,xmm1
  40ad0e:	movzx  edx,dl
  40ad11:	vcvtsi2sd xmm1,xmm1,rdx
  40ad16:	vsubsd xmm0,xmm0,xmm1
  40ad1a:	vmulsd xmm0,xmm0,xmm6
  40ad1e:	vcvttsd2si rdx,xmm0
  40ad23:	mov    r10b,dl
  40ad26:	add    r10b,0x30
  40ad2a:	mov    BYTE PTR [r9+0x7],r10b
  40ad2e:	vxorpd xmm1,xmm1,xmm1
  40ad32:	movzx  edx,dl
  40ad35:	vcvtsi2sd xmm1,xmm1,rdx
  40ad3a:	vsubsd xmm0,xmm0,xmm1
  40ad3e:	vmulsd xmm0,xmm0,xmm6
  40ad42:	vcvttsd2si rdx,xmm0
  40ad47:	mov    r10b,dl
  40ad4a:	add    r10b,0x30
  40ad4e:	mov    BYTE PTR [r9+0x8],r10b
  40ad52:	vxorpd xmm1,xmm1,xmm1
  40ad56:	movzx  edx,dl
  40ad59:	vcvtsi2sd xmm1,xmm1,rdx
  40ad5e:	vsubsd xmm0,xmm0,xmm1
  40ad62:	vmulsd xmm0,xmm0,xmm6
  40ad66:	vcvttsd2si rdx,xmm0
  40ad6b:	mov    r10b,dl
  40ad6e:	add    r10b,0x30
  40ad72:	mov    BYTE PTR [r9+0x9],r10b
  40ad76:	vxorpd xmm1,xmm1,xmm1
  40ad7a:	movzx  edx,dl
  40ad7d:	vcvtsi2sd xmm1,xmm1,rdx
  40ad82:	vsubsd xmm0,xmm0,xmm1
  40ad86:	vmulsd xmm0,xmm0,xmm6
  40ad8a:	vcvttsd2si rdx,xmm0
  40ad8f:	mov    r10b,dl
  40ad92:	add    r10b,0x30
  40ad96:	mov    BYTE PTR [r9+0xa],r10b
  40ad9a:	vxorpd xmm1,xmm1,xmm1
  40ad9e:	movzx  edx,dl
  40ada1:	vcvtsi2sd xmm1,xmm1,rdx
  40ada6:	vsubsd xmm0,xmm0,xmm1
  40adaa:	vmulsd xmm0,xmm0,xmm6
  40adae:	vcvttsd2si rdx,xmm0
  40adb3:	mov    r10b,dl
  40adb6:	add    r10b,0x30
  40adba:	mov    BYTE PTR [r9+0xb],r10b
  40adbe:	lea    r10,[r9+0x4]
  40adc2:	vxorpd xmm1,xmm1,xmm1
  40adc6:	movzx  edx,dl
  40adc9:	vcvtsi2sd xmm1,xmm1,rdx
  40adce:	vsubsd xmm0,xmm0,xmm1
  40add2:	vmulsd xmm0,xmm0,xmm6
  40add6:	vcvttsd2si rdx,xmm0
  40addb:	mov    r11b,dl
  40adde:	add    r11b,0x30
  40ade2:	mov    BYTE PTR [r9+0xc],r11b
  40ade6:	vxorpd xmm1,xmm1,xmm1
  40adea:	movzx  edx,dl
  40aded:	vcvtsi2sd xmm1,xmm1,rdx
  40adf2:	vsubsd xmm0,xmm0,xmm1
  40adf6:	vmulsd xmm0,xmm0,xmm6
  40adfa:	vcvttsd2si rdx,xmm0
  40adff:	mov    r11b,dl
  40ae02:	add    r11b,0x30
  40ae06:	mov    BYTE PTR [r9+0xd],r11b
  40ae0a:	lea    r10,[r10+0x2]
  40ae0e:	vxorpd xmm1,xmm1,xmm1
  40ae12:	movzx  edx,dl
  40ae15:	vcvtsi2sd xmm1,xmm1,rdx
  40ae1a:	vsubsd xmm0,xmm0,xmm1
  40ae1e:	vmulsd xmm0,xmm0,xmm6
  40ae22:	vcvttsd2si rdx,xmm0
  40ae27:	mov    r11b,dl
  40ae2a:	add    r11b,0x30
  40ae2e:	mov    BYTE PTR [r9+0xe],r11b
  40ae32:	vxorpd xmm1,xmm1,xmm1
  40ae36:	movzx  edx,dl
  40ae39:	vcvtsi2sd xmm1,xmm1,rdx
  40ae3e:	vsubsd xmm0,xmm0,xmm1
  40ae42:	vmulsd xmm0,xmm0,xmm6
  40ae46:	vcvttsd2si rdx,xmm0
  40ae4b:	mov    r11b,dl
  40ae4e:	add    r11b,0x30
  40ae52:	mov    BYTE PTR [r9+0xf],r11b
  40ae56:	lea    r10,[r10+0x2]
  40ae5a:	lea    r10,[r10+0x2]
  40ae5e:	lea    r10,[r10+0x2]
  40ae62:	lea    r10,[r10+0x2]
  40ae66:	lea    r10,[r10+0x2]
  40ae6a:	vxorpd xmm1,xmm1,xmm1
  40ae6e:	movzx  edx,dl
  40ae71:	vcvtsi2sd xmm1,xmm1,rdx
  40ae76:	vsubsd xmm0,xmm0,xmm1
  40ae7a:	vmulsd xmm0,xmm0,xmm6
  40ae7e:	vcvttsd2si rdx,xmm0
  40ae83:	mov    r11b,dl
  40ae86:	add    r11b,0x30
  40ae8a:	mov    BYTE PTR [r9+0x10],r11b
  40ae8e:	vxorpd xmm1,xmm1,xmm1
  40ae92:	movzx  edx,dl
  40ae95:	vcvtsi2sd xmm1,xmm1,rdx
  40ae9a:	vsubsd xmm0,xmm0,xmm1
  40ae9e:	vmulsd xmm0,xmm0,xmm6
  40aea2:	vcvttsd2si rdx,xmm0
  40aea7:	add    dl,0x30
  40aeaa:	mov    BYTE PTR [r9+0x11],dl
  40aeae:	mov    BYTE PTR [r10+0x2],0x65
  40aeb3:	lea    r9,[r10+0x3]
  40aeb7:	test   r8,r8
  40aeba:	jl     40aec3 <__swc_fn_e121059d_000147_43f4fdca+0xd83>
  40aebc:	mov    BYTE PTR [r9],0x2b
  40aec0:	inc    r9
  40aec3:	mov    r10,r9
  40aec6:	mov    rdx,r8
  40aec9:	nop    DWORD PTR [rax+0x0]
  40aed0:	mov    r11,rdx
  40aed3:	movabs rdx,0x6666666666666667
  40aedd:	mov    rax,r11
  40aee0:	imul   rdx
  40aee3:	sar    rdx,0x2
  40aee7:	mov    r12,rdx
  40aeea:	shr    rdx,0x3f
  40aeee:	add    r12,rdx
  40aef1:	mov    rdx,r12
  40aef4:	imul   r13,r12,0xa
  40aef8:	sub    r11,r13
  40aefb:	mov    r13,QWORD PTR [rip+0x863e]        # 413540 <__swc_rdata_base_e121059d+0x430>
  40af02:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40af07:	mov    BYTE PTR [r10],r11b
  40af0a:	lea    r11,[r10+0x1]
  40af0e:	mov    r10,r11
  40af11:	test   r12,r12
  40af14:	jne    40aed0 <__swc_fn_e121059d_000147_43f4fdca+0xd90>
  40af16:	test   r8,r8
  40af19:	jge    40af23 <__swc_fn_e121059d_000147_43f4fdca+0xde3>
  40af1b:	mov    BYTE PTR [r11],0x2d
  40af1f:	lea    r10,[r11+0x1]
  40af23:	mov    BYTE PTR [r10],0x0
  40af27:	sub    r10,0x1
  40af2b:	nop    DWORD PTR [rax+rax*1+0x0]
  40af30:	cmp    r9,r10
  40af33:	jae    40b1a8 <__swc_fn_e121059d_000147_43f4fdca+0x1068>
  40af39:	mov    al,BYTE PTR [r10]
  40af3c:	mov    dl,BYTE PTR [r9]
  40af3f:	mov    BYTE PTR [r10],dl
  40af42:	sub    r10,0x1
  40af46:	mov    BYTE PTR [r9],al
  40af49:	inc    r9
  40af4c:	jmp    40af30 <__swc_fn_e121059d_000147_43f4fdca+0xdf0>
  40af4e:	vcvttsd2si rdx,xmm0
  40af53:	mov    r8,rdx
  40af56:	vxorpd xmm1,xmm1,xmm1
  40af5a:	vcvtsi2sd xmm1,xmm1,rdx
  40af5f:	vsubsd xmm1,xmm0,xmm1
  40af63:	mov    r9d,0x8
  40af69:	vxorpd xmm2,xmm2,xmm2
  40af6d:	vcomisd xmm2,xmm1
  40af71:	ja     40af7e <__swc_fn_e121059d_000147_43f4fdca+0xe3e>
  40af73:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40af7c:	jmp    40af8f <__swc_fn_e121059d_000147_43f4fdca+0xe4f>
  40af7e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x85ca]        # 413550 <__swc_rdata_base_e121059d+0x440>
  40af86:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40af8f:	test   r9d,r9d
  40af92:	je     40afa9 <__swc_fn_e121059d_000147_43f4fdca+0xe69>
  40af94:	cs nop WORD PTR [rax+rax*1+0x0]
  40af9e:	xchg   ax,ax
  40afa0:	vmulsd xmm1,xmm1,xmm6
  40afa4:	dec    r9d
  40afa7:	jne    40afa0 <__swc_fn_e121059d_000147_43f4fdca+0xe60>
  40afa9:	vcvttsd2si r9,xmm1
  40afae:	mov    r10,r9
  40afb1:	vxorpd xmm2,xmm2,xmm2
  40afb5:	vcvtsi2sd xmm2,xmm2,r9
  40afba:	vsubsd xmm1,xmm1,xmm2
  40afbe:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  40afc7:	vcomisd xmm1,xmm6
  40afcb:	lea    r9,[r9+0x1]
  40afcf:	cmova  r10,r9
  40afd3:	cmp    r10,0x5f5e100
  40afda:	jne    40aff3 <__swc_fn_e121059d_000147_43f4fdca+0xeb3>
  40afdc:	lea    r8,[rdx-0x1]
  40afe0:	vxorpd xmm1,xmm1,xmm1
  40afe4:	vcomisd xmm1,xmm0
  40afe8:	lea    rdx,[rdx+0x1]
  40afec:	cmovbe r8,rdx
  40aff0:	xor    r10d,r10d
  40aff3:	mov    r9,rcx
  40aff6:	test   r8,r8
  40aff9:	jne    40b019 <__swc_fn_e121059d_000147_43f4fdca+0xed9>
  40affb:	vxorpd xmm1,xmm1,xmm1
  40afff:	vcomisd xmm1,xmm0
  40b003:	jbe    40b00c <__swc_fn_e121059d_000147_43f4fdca+0xecc>
  40b005:	mov    BYTE PTR [rcx],0x2d
  40b008:	lea    r9,[rcx+0x1]
  40b00c:	mov    BYTE PTR [r9],0x30
  40b010:	add    r9,0x1
  40b014:	jmp    40b0ab <__swc_fn_e121059d_000147_43f4fdca+0xf6b>
  40b019:	mov    r9,rcx
  40b01c:	mov    rdx,r8
  40b01f:	nop
  40b020:	mov    r11,rdx
  40b023:	movabs rdx,0x6666666666666667
  40b02d:	mov    r15,rax
  40b030:	mov    rax,r11
  40b033:	imul   rdx
  40b036:	mov    r12,rdx
  40b039:	mov    rax,r15
  40b03c:	sar    r12,0x2
  40b040:	mov    rdx,r12
  40b043:	shr    rdx,0x3f
  40b047:	add    r12,rdx
  40b04a:	mov    rdx,r12
  40b04d:	imul   r13,r12,0xa
  40b051:	sub    r11,r13
  40b054:	mov    r13,QWORD PTR [rip+0x84e5]        # 413540 <__swc_rdata_base_e121059d+0x430>
  40b05b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b060:	mov    BYTE PTR [r9],r11b
  40b063:	lea    r11,[r9+0x1]
  40b067:	mov    r9,r11
  40b06a:	test   r12,r12
  40b06d:	jne    40b020 <__swc_fn_e121059d_000147_43f4fdca+0xee0>
  40b06f:	test   r8,r8
  40b072:	jge    40b07c <__swc_fn_e121059d_000147_43f4fdca+0xf3c>
  40b074:	mov    BYTE PTR [r11],0x2d
  40b078:	lea    r9,[r11+0x1]
  40b07c:	mov    rdx,r9
  40b07f:	mov    BYTE PTR [r9],0x0
  40b083:	sub    r9,0x1
  40b087:	mov    r8,rcx
  40b08a:	cmp    r8,r9
  40b08d:	jae    40b0a8 <__swc_fn_e121059d_000147_43f4fdca+0xf68>
  40b08f:	nop
  40b090:	mov    r11b,BYTE PTR [r9]
  40b093:	mov    r12b,BYTE PTR [r8]
  40b096:	mov    BYTE PTR [r9],r12b
  40b099:	sub    r9,0x1
  40b09d:	mov    BYTE PTR [r8],r11b
  40b0a0:	inc    r8
  40b0a3:	cmp    r8,r9
  40b0a6:	jb     40b090 <__swc_fn_e121059d_000147_43f4fdca+0xf50>
  40b0a8:	mov    r9,rdx
  40b0ab:	mov    BYTE PTR [r9],0x2e
  40b0af:	add    r9,0x1
  40b0b3:	xor    r8d,r8d
  40b0b6:	test   r10,r10
  40b0b9:	je     40b0ff <__swc_fn_e121059d_000147_43f4fdca+0xfbf>
  40b0bb:	mov    r11d,0x989680
  40b0c1:	cmp    r10,r11
  40b0c4:	jge    40b0ff <__swc_fn_e121059d_000147_43f4fdca+0xfbf>
  40b0c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40b0d0:	inc    r8d
  40b0d3:	movabs rdx,0x6666666666666667
  40b0dd:	mov    r15,rax
  40b0e0:	mov    rax,r11
  40b0e3:	imul   rdx
  40b0e6:	mov    r11,rdx
  40b0e9:	mov    rax,r15
  40b0ec:	sar    r11,0x2
  40b0f0:	mov    rdx,r11
  40b0f3:	shr    rdx,0x3f
  40b0f7:	add    r11,rdx
  40b0fa:	cmp    r10,r11
  40b0fd:	jl     40b0d0 <__swc_fn_e121059d_000147_43f4fdca+0xf90>
  40b0ff:	test   r8d,r8d
  40b102:	je     40b11d <__swc_fn_e121059d_000147_43f4fdca+0xfdd>
  40b104:	cs nop WORD PTR [rax+rax*1+0x0]
  40b10e:	xchg   ax,ax
  40b110:	mov    BYTE PTR [r9],0x30
  40b114:	add    r9,0x1
  40b118:	dec    r8d
  40b11b:	jne    40b110 <__swc_fn_e121059d_000147_43f4fdca+0xfd0>
  40b11d:	mov    r8,r9
  40b120:	mov    rdx,r10
  40b123:	cs nop WORD PTR [rax+rax*1+0x0]
  40b12d:	nop    DWORD PTR [rax]
  40b130:	mov    r11,rdx
  40b133:	movabs rdx,0x6666666666666667
  40b13d:	mov    rax,r11
  40b140:	imul   rdx
  40b143:	sar    rdx,0x2
  40b147:	mov    r12,rdx
  40b14a:	shr    rdx,0x3f
  40b14e:	add    r12,rdx
  40b151:	mov    rdx,r12
  40b154:	imul   r13,r12,0xa
  40b158:	sub    r11,r13
  40b15b:	mov    r13,QWORD PTR [rip+0x83de]        # 413540 <__swc_rdata_base_e121059d+0x430>
  40b162:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b167:	mov    BYTE PTR [r8],r11b
  40b16a:	lea    r11,[r8+0x1]
  40b16e:	mov    r8,r11
  40b171:	test   r12,r12
  40b174:	jne    40b130 <__swc_fn_e121059d_000147_43f4fdca+0xff0>
  40b176:	test   r10,r10
  40b179:	jge    40b183 <__swc_fn_e121059d_000147_43f4fdca+0x1043>
  40b17b:	mov    BYTE PTR [r11],0x2d
  40b17f:	lea    r8,[r11+0x1]
  40b183:	mov    BYTE PTR [r8],0x0
  40b187:	sub    r8,0x1
  40b18b:	cmp    r9,r8
  40b18e:	jae    40b1a8 <__swc_fn_e121059d_000147_43f4fdca+0x1068>
  40b190:	mov    al,BYTE PTR [r8]
  40b193:	mov    dl,BYTE PTR [r9]
  40b196:	mov    BYTE PTR [r8],dl
  40b199:	sub    r8,0x1
  40b19d:	mov    BYTE PTR [r9],al
  40b1a0:	inc    r9
  40b1a3:	cmp    r9,r8
  40b1a6:	jb     40b190 <__swc_fn_e121059d_000147_43f4fdca+0x1050>
  40b1a8:	xor    eax,eax
  40b1aa:	test   rcx,rcx
  40b1ad:	je     40b1d0 <__swc_fn_e121059d_000147_43f4fdca+0x1090>
  40b1af:	mov    rdx,rcx
  40b1b2:	mov    r8b,BYTE PTR [rdx]
  40b1b5:	test   r8b,r8b
  40b1b8:	je     40b1d0 <__swc_fn_e121059d_000147_43f4fdca+0x1090>
  40b1ba:	nop    WORD PTR [rax+rax*1+0x0]
  40b1c0:	add    rdx,0x1
  40b1c4:	add    rax,0x1
  40b1c8:	mov    r8b,BYTE PTR [rdx]
  40b1cb:	test   r8b,r8b
  40b1ce:	jne    40b1c0 <__swc_fn_e121059d_000147_43f4fdca+0x1080>
  40b1d0:	mov    QWORD PTR [rsp+0x3f8],rcx
  40b1d8:	mov    QWORD PTR [rsp+0x400],rax
  40b1e0:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  40b1e9:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  40b1f2:	lea    rcx,[rsp+0x408]
  40b1fa:	call   4098c0 <__swc_fn_e121059d_000117_035d76a1>
  40b1ff:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40b201:	mov    rcx,rdx
  40b204:	call   4098c0 <__swc_fn_e121059d_000117_035d76a1>
  40b209:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40b20b:	mov    al,BYTE PTR [rdx]
  40b20d:	test   al,al
  40b20f:	je     40b21a <__swc_fn_e121059d_000147_43f4fdca+0x10da>
  40b211:	lea    rax,[rip+0x8348]        # 413560 <__swc_rdata_base_e121059d+0x450>
  40b218:	jmp    40b221 <__swc_fn_e121059d_000147_43f4fdca+0x10e1>
  40b21a:	lea    rax,[rip+0x834f]        # 413570 <__swc_rdata_base_e121059d+0x460>
  40b221:	mov    rcx,rax
  40b224:	call   4098c0 <__swc_fn_e121059d_000117_035d76a1>
  40b229:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40b22b:	lea    rcx,[rip+0x834e]        # 413580 <__swc_rdata_base_e121059d+0x470>
  40b232:	call   4098c0 <__swc_fn_e121059d_000117_035d76a1>
  40b237:	jmp    40b245 <__swc_fn_e121059d_000147_43f4fdca+0x1105>
  40b239:	lea    rcx,[rip+0x8340]        # 413580 <__swc_rdata_base_e121059d+0x470>
  40b240:	call   4098c0 <__swc_fn_e121059d_000117_035d76a1>
  40b245:	add    rdi,0x1
  40b249:	sub    rsi,0x1
  40b24d:	vmovups xmm0,xmm12
  40b252:	vmovsd xmm6,QWORD PTR [rip+0x8336]        # 413590 <__swc_rdata_base_e121059d+0x480>
  40b25a:	test   rsi,rsi
  40b25d:	jne    40a250 <__swc_fn_e121059d_000147_43f4fdca+0x110>
  40b263:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  40b26c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  40b275:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  40b27e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  40b287:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  40b290:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  40b299:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  40b2a2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  40b2ab:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  40b2b4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  40b2bd:	add    rsp,0x4e8
  40b2c4:	pop    r15
  40b2c6:	pop    r13
  40b2c8:	pop    r12
  40b2ca:	pop    rdi
  40b2cb:	pop    rsi
  40b2cc:	pop    rbx
  40b2cd:	ret
	...

000000000040b2d0 <__swc_fn_e121059d_000150_9e4bc402>:
  40b2d0:	vxorps xmm0,xmm0,xmm0
  40b2d4:	vmovups XMMWORD PTR [rcx],xmm0
  40b2d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b2dd:	ret
	...

000000000040b2e0 <__swc_fn_e121059d_000153_9e4bc402>:
  40b2e0:	vxorps xmm0,xmm0,xmm0
  40b2e4:	vmovups XMMWORD PTR [rcx],xmm0
  40b2e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b2ed:	vxorps xmm0,xmm0,xmm0
  40b2f1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b2f6:	vmovups xmm0,XMMWORD PTR [rip+0x83a2]        # 4136a0 <__swc_rdata_base_e121059d+0x590>
  40b2fe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b303:	vxorps xmm0,xmm0,xmm0
  40b307:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b30c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40b311:	vxorps xmm0,xmm0,xmm0
  40b315:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40b31a:	mov    QWORD PTR [rcx+0x70],0x0
  40b322:	ret
	...

000000000040b330 <__swc_fn_e121059d_000156_9e4bc402>:
  40b330:	vxorps xmm0,xmm0,xmm0
  40b334:	vmovups XMMWORD PTR [rcx],xmm0
  40b338:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b33d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b342:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b347:	ret
	...

000000000040b350 <__swc_fn_e121059d_000159_b43b2f96>:
  40b350:	push   rsi
  40b351:	push   rdi
  40b352:	sub    rsp,0x8
  40b356:	mov    rsi,rcx
  40b359:	mov    rdi,QWORD PTR [rsi+0x50]
  40b35d:	test   rdi,rdi
  40b360:	je     40b367 <__swc_fn_e121059d_000159_b43b2f96+0x17>
  40b362:	mov    rcx,rsi
  40b365:	call   rdi
  40b367:	mov    QWORD PTR [rsi+0x20],0x0
  40b36f:	mov    rax,QWORD PTR [rsi+0x30]
  40b373:	test   rax,rax
  40b376:	je     40b3a4 <__swc_fn_e121059d_000159_b43b2f96+0x54>
  40b378:	nop    DWORD PTR [rax+rax*1+0x0]
  40b380:	mov    rdi,QWORD PTR [rax+0x8]
  40b384:	mov    rcx,rsi
  40b387:	mov    rdx,QWORD PTR [rax+0x10]
  40b38b:	mov    rax,QWORD PTR [rax+0x18]
  40b38f:	mov    r8,rax
  40b392:	call   40e700 <__swc_fn_e121059d_000157_2745c4a5>
  40b397:	mov    QWORD PTR [rsi+0x30],rdi
  40b39b:	mov    rax,QWORD PTR [rsi+0x30]
  40b39f:	test   rax,rax
  40b3a2:	jne    40b380 <__swc_fn_e121059d_000159_b43b2f96+0x30>
  40b3a4:	mov    QWORD PTR [rsi+0x38],0x0
  40b3ac:	add    rsp,0x8
  40b3b0:	pop    rdi
  40b3b1:	pop    rsi
  40b3b2:	ret
	...

000000000040b3c0 <__swc_fn_e121059d_000162_b5a9d657>:
  40b3c0:	push   rbx
  40b3c1:	push   rsi
  40b3c2:	push   rdi
  40b3c3:	push   r12
  40b3c5:	sub    rsp,0x188
  40b3cc:	mov    rbx,rcx
  40b3cf:	lea    rsi,[rip+0x1b9ba]        # 426d90 <__swc_bss_base_e121059d+0x2d50>
  40b3d6:	mov    rcx,rsi
  40b3d9:	call   40e100 <__swc_fn_e121059d_000136_e3032dc2>
  40b3de:	mov    rax,QWORD PTR [rip+0x1b9b3]        # 426d98 <__swc_bss_base_e121059d+0x2d58>
  40b3e5:	mov    rdi,rax
  40b3e8:	test   rdi,rdi
  40b3eb:	je     40b419 <__swc_fn_e121059d_000162_b5a9d657+0x59>
  40b3ed:	nop    DWORD PTR [rax]
  40b3f0:	cmp    QWORD PTR [rdi+0x8],rbx
  40b3f4:	jne    40b40e <__swc_fn_e121059d_000162_b5a9d657+0x4e>
  40b3f6:	mov    rcx,rsi
  40b3f9:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40b3fe:	mov    rax,rdi
  40b401:	add    rsp,0x188
  40b408:	pop    r12
  40b40a:	pop    rdi
  40b40b:	pop    rsi
  40b40c:	pop    rbx
  40b40d:	ret
  40b40e:	mov    rax,QWORD PTR [rdi]
  40b411:	mov    rdi,rax
  40b414:	test   rax,rax
  40b417:	jne    40b3f0 <__swc_fn_e121059d_000162_b5a9d657+0x30>
  40b419:	call   411280 <__swc_fn_e121059d_000140_7c02fe26>
  40b41e:	mov    rdi,rax
  40b421:	test   rax,rax
  40b424:	jne    40b43d <__swc_fn_e121059d_000162_b5a9d657+0x7d>
  40b426:	mov    rcx,rsi
  40b429:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40b42e:	xor    eax,eax
  40b430:	add    rsp,0x188
  40b437:	pop    r12
  40b439:	pop    rdi
  40b43a:	pop    rsi
  40b43b:	pop    rbx
  40b43c:	ret
  40b43d:	lea    rax,[rsp+0x18]
  40b442:	mov    QWORD PTR [rax+0x10],0x0
  40b44a:	mov    QWORD PTR [rax+0x18],0x0
  40b452:	mov    DWORD PTR [rax+0x20],0x0
  40b459:	mov    BYTE PTR [rax+0x24],0x0
  40b45d:	mov    rax,QWORD PTR [rip+0x1b934]        # 426d98 <__swc_bss_base_e121059d+0x2d58>
  40b464:	mov    QWORD PTR [rsp+0x18],rax
  40b469:	mov    QWORD PTR [rsp+0x20],rbx
  40b46e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40b474:	vmovups XMMWORD PTR [rdi],xmm0
  40b478:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40b47e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  40b483:	mov    rax,QWORD PTR [rsp+0x38]
  40b488:	mov    QWORD PTR [rdi+0x20],rax
  40b48c:	mov    QWORD PTR [rip+0x1b905],rdi        # 426d98 <__swc_bss_base_e121059d+0x2d58>
  40b493:	lea    rax,[rsp+0x40]
  40b498:	mov    QWORD PTR [rax],0x0
  40b49f:	mov    rcx,rbx
  40b4a2:	mov    rdx,rax
  40b4a5:	call   40e1e0 <__swc_fn_e121059d_000142_2ce79e3b>
  40b4aa:	mov    rbx,rax
  40b4ad:	test   rax,rax
  40b4b0:	jne    40b4ca <__swc_fn_e121059d_000162_b5a9d657+0x10a>
  40b4b2:	mov    rcx,rsi
  40b4b5:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40b4ba:	mov    rax,rdi
  40b4bd:	add    rsp,0x188
  40b4c4:	pop    r12
  40b4c6:	pop    rdi
  40b4c7:	pop    rsi
  40b4c8:	pop    rbx
  40b4c9:	ret
  40b4ca:	lea    r12,[rsp+0x50]
  40b4cf:	mov    QWORD PTR [r12],0x0
  40b4d7:	mov    rcx,rbx
  40b4da:	mov    rdx,QWORD PTR [rsp+0x40]
  40b4df:	mov    r8,r12
  40b4e2:	call   411330 <__swc_fn_e121059d_000143_56e56812>
  40b4e7:	test   rax,rax
  40b4ea:	jne    40b504 <__swc_fn_e121059d_000162_b5a9d657+0x144>
  40b4ec:	mov    rcx,rsi
  40b4ef:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40b4f4:	mov    rax,rdi
  40b4f7:	add    rsp,0x188
  40b4fe:	pop    r12
  40b500:	pop    rdi
  40b501:	pop    rsi
  40b502:	pop    rbx
  40b503:	ret
  40b504:	cmp    QWORD PTR [r12],0x10
  40b509:	jb     40b60c <__swc_fn_e121059d_000162_b5a9d657+0x24c>
  40b50f:	mov    ecx,DWORD PTR [rax]
  40b511:	cmp    ecx,0x42445753
  40b517:	jne    40b60c <__swc_fn_e121059d_000162_b5a9d657+0x24c>
  40b51d:	mov    ecx,DWORD PTR [rax+0x4]
  40b520:	cmp    ecx,0x1
  40b523:	jne    40b60c <__swc_fn_e121059d_000162_b5a9d657+0x24c>
  40b529:	mov    ecx,DWORD PTR [rax+0x8]
  40b52c:	mov    edx,DWORD PTR [rax+0xc]
  40b52f:	imul   r8,rcx,0x14
  40b533:	mov    r9,QWORD PTR [rsp+0x50]
  40b538:	sub    r9,0x10
  40b53c:	cmp    r8,r9
  40b53f:	ja     40b60c <__swc_fn_e121059d_000162_b5a9d657+0x24c>
  40b545:	lea    r8,[r8+0x10]
  40b549:	cmp    rdx,r8
  40b54c:	jb     40b60c <__swc_fn_e121059d_000162_b5a9d657+0x24c>
  40b552:	mov    r8,QWORD PTR [rsp+0x50]
  40b557:	cmp    rdx,r8
  40b55a:	ja     40b60c <__swc_fn_e121059d_000162_b5a9d657+0x24c>
  40b560:	xor    r8d,r8d
  40b563:	test   rcx,rcx
  40b566:	jbe    40b632 <__swc_fn_e121059d_000162_b5a9d657+0x272>
  40b56c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  40b572:	cs nop WORD PTR [rax+rax*1+0x0]
  40b57c:	nop    DWORD PTR [rax+0x0]
  40b580:	imul   r9,r8,0x14
  40b584:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  40b589:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  40b58e:	add    r10,r11
  40b591:	movabs r11,0x100000000
  40b59b:	cmp    r10,r11
  40b59e:	ja     40b60c <__swc_fn_e121059d_000162_b5a9d657+0x24c>
  40b5a0:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  40b5a5:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  40b5aa:	test   r10d,r10d
  40b5ad:	setne  r11b
  40b5b1:	je     40b5cb <__swc_fn_e121059d_000162_b5a9d657+0x20b>
  40b5b3:	cmp    r10d,edx
  40b5b6:	setb   r11b
  40b5ba:	jb     40b5cb <__swc_fn_e121059d_000162_b5a9d657+0x20b>
  40b5bc:	vmovq  r11,xmm1
  40b5c1:	cmp    r10,r11
  40b5c4:	setae  r10b
  40b5c8:	mov    r11b,r10b
  40b5cb:	mov    r10,r11
  40b5ce:	test   r11b,r11b
  40b5d1:	jne    40b5f8 <__swc_fn_e121059d_000162_b5a9d657+0x238>
  40b5d3:	test   r9d,r9d
  40b5d6:	setne  r10b
  40b5da:	je     40b5f8 <__swc_fn_e121059d_000162_b5a9d657+0x238>
  40b5dc:	cmp    r9d,edx
  40b5df:	setb   r10b
  40b5e3:	jb     40b5f8 <__swc_fn_e121059d_000162_b5a9d657+0x238>
  40b5e5:	vmovq  r10,xmm1
  40b5ea:	cmp    r9,r10
  40b5ed:	setae  r9b
  40b5f1:	movzx  r9d,r9b
  40b5f5:	mov    r10b,r9b
  40b5f8:	test   r10b,r10b
  40b5fb:	jne    40b60c <__swc_fn_e121059d_000162_b5a9d657+0x24c>
  40b5fd:	add    r8,0x1
  40b601:	cmp    r8,rcx
  40b604:	jb     40b580 <__swc_fn_e121059d_000162_b5a9d657+0x1c0>
  40b60a:	jmp    40b632 <__swc_fn_e121059d_000162_b5a9d657+0x272>
  40b60c:	xor    ecx,ecx
  40b60e:	cmp    rax,rbx
  40b611:	cmovne rcx,rax
  40b615:	call   40a090 <__swc_fn_e121059d_000144_81c0d993>
  40b61a:	mov    rcx,rsi
  40b61d:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40b622:	mov    rax,rdi
  40b625:	add    rsp,0x188
  40b62c:	pop    r12
  40b62e:	pop    rdi
  40b62f:	pop    rsi
  40b630:	pop    rbx
  40b631:	ret
  40b632:	mov    QWORD PTR [rdi+0x10],rax
  40b636:	mov    rcx,QWORD PTR [rsp+0x50]
  40b63b:	mov    QWORD PTR [rdi+0x18],rcx
  40b63f:	mov    eax,DWORD PTR [rax+0x8]
  40b642:	mov    DWORD PTR [rdi+0x20],eax
  40b645:	rex mov BYTE PTR [rdi+0x24],0x1
  40b64a:	mov    rcx,rsi
  40b64d:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40b652:	mov    rax,rdi
  40b655:	add    rsp,0x188
  40b65c:	pop    r12
  40b65e:	pop    rdi
  40b65f:	pop    rsi
  40b660:	pop    rbx
  40b661:	ret
	...

000000000040b670 <__swc_fn_e121059d_000165_1962e12a>:
  40b670:	push   rsi
  40b671:	push   rdi
  40b672:	push   r12
  40b674:	mov    rsi,rdx
  40b677:	mov    rdi,rcx
  40b67a:	mov    rcx,QWORD PTR [rip+0x1b6bf]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40b681:	test   rcx,rcx
  40b684:	jne    40b696 <__swc_fn_e121059d_000165_1962e12a+0x26>
  40b686:	call   40ea10 <__swc_fn_e121059d_000166_cf398896>
  40b68b:	lea    rcx,[rax+0x1]
  40b68f:	mov    QWORD PTR [rip+0x1b6aa],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40b696:	dec    rcx
  40b699:	call   40b6c0 <__swc_fn_e121059d_000168_fce60b2b>
  40b69e:	mov    r12,QWORD PTR [rax+0xbe0]
  40b6a5:	test   r12,r12
  40b6a8:	setne  al
  40b6ab:	je     40b6b6 <__swc_fn_e121059d_000165_1962e12a+0x46>
  40b6ad:	mov    rcx,rdi
  40b6b0:	mov    rdx,rsi
  40b6b3:	call   r12
  40b6b6:	pop    r12
  40b6b8:	pop    rdi
  40b6b9:	pop    rsi
  40b6ba:	ret
  40b6bb:	add    BYTE PTR [rax],al
  40b6bd:	add    BYTE PTR [rax],al
	...

000000000040b6c0 <__swc_fn_e121059d_000168_fce60b2b>:
  40b6c0:	push   r12
  40b6c2:	push   rdi
  40b6c3:	push   rsi
  40b6c4:	sub    rsp,0xd0
  40b6cb:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40b6d1:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40b6d7:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40b6dd:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40b6e3:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40b6e9:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40b6ef:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40b6f8:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40b701:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40b70a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40b713:	mov    r12,rcx
  40b716:	mov    edi,ecx
  40b718:	xor    eax,eax
  40b71a:	call   407000 <pthread_getspecific@plt>
  40b71f:	test   rax,rax
  40b722:	je     40b726 <__swc_fn_e121059d_000168_fce60b2b+0x66>
  40b724:	jmp    40b72e <__swc_fn_e121059d_000168_fce60b2b+0x6e>
  40b726:	mov    rcx,r12
  40b729:	call   40ea70 <__swc_fn_e121059d_000169_92b7d63c>
  40b72e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40b734:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40b73a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40b740:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40b746:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40b74c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40b752:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40b75b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40b764:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40b76d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40b776:	add    rsp,0xd0
  40b77d:	pop    rsi
  40b77e:	pop    rdi
  40b77f:	pop    r12
  40b781:	ret
	...

000000000040b790 <__swc_fn_e121059d_000171_fa3003e2>:
  40b790:	push   rsi
  40b791:	sub    rsp,0x30
  40b795:	lea    rsi,[rip+0x1b60c]        # 426da8 <__swc_bss_base_e121059d+0x2d68>
  40b79c:	mov    rax,QWORD PTR [rsi]
  40b79f:	test   rax,rax
  40b7a2:	je     40b7aa <__swc_fn_e121059d_000171_fa3003e2+0x1a>
  40b7a4:	add    rsp,0x30
  40b7a8:	pop    rsi
  40b7a9:	ret
  40b7aa:	mov    ecx,0x3
  40b7af:	mov    edx,0x10
  40b7b4:	call   4091c0 <__swc_fn_e121059d_000108_4796e893>
  40b7b9:	test   rax,rax
  40b7bc:	jne    40b7cd <__swc_fn_e121059d_000171_fa3003e2+0x3d>
  40b7be:	mov    QWORD PTR [rsp+0x18],rax
  40b7c3:	call   410dc0 <__swc_fn_e121059d_000119_7f430081>
  40b7c8:	mov    rax,QWORD PTR [rsp+0x18]
  40b7cd:	mov    rcx,rax
  40b7d0:	xchg   QWORD PTR [rsi],rcx
  40b7d3:	add    rsp,0x30
  40b7d7:	pop    rsi
  40b7d8:	ret
  40b7d9:	add    BYTE PTR [rax],al
  40b7db:	add    BYTE PTR [rax],al
  40b7dd:	add    BYTE PTR [rax],al
	...

000000000040b7e0 <__swc_fn_e121059d_000174_f69b1f05>:
  40b7e0:	push   rsi
  40b7e1:	push   rdi
  40b7e2:	sub    rsp,0x8
  40b7e6:	mov    rsi,rdx
  40b7e9:	mov    rdi,rcx
  40b7ec:	mov    rax,QWORD PTR [rsi+0x8]
  40b7f0:	test   rax,rax
  40b7f3:	je     40b7fd <__swc_fn_e121059d_000174_f69b1f05+0x1d>
  40b7f5:	mov    rcx,QWORD PTR [rsi]
  40b7f8:	mov    QWORD PTR [rax],rcx
  40b7fb:	jmp    40b804 <__swc_fn_e121059d_000174_f69b1f05+0x24>
  40b7fd:	mov    rax,QWORD PTR [rsi]
  40b800:	mov    QWORD PTR [rdi+0x8],rax
  40b804:	mov    rax,QWORD PTR [rsi]
  40b807:	test   rax,rax
  40b80a:	je     40b814 <__swc_fn_e121059d_000174_f69b1f05+0x34>
  40b80c:	mov    rcx,QWORD PTR [rsi+0x8]
  40b810:	mov    QWORD PTR [rax+0x8],rcx
  40b814:	mov    rcx,rdi
  40b817:	mov    rdx,QWORD PTR [rsi+0x10]
  40b81b:	mov    r8,QWORD PTR [rsi+0x18]
  40b81f:	mov    r9,0xffffffffffffffff
  40b826:	call   4119a0 <__swc_fn_e121059d_000173_97fbc432>
  40b82b:	mov    QWORD PTR [rsi+0x18],0x0
  40b833:	mov    rax,QWORD PTR [rdi+0x8]
  40b837:	test   rax,rax
  40b83a:	jne    40b84c <__swc_fn_e121059d_000174_f69b1f05+0x6c>
  40b83c:	call   40b790 <__swc_fn_e121059d_000171_fa3003e2>
  40b841:	xor    ecx,ecx
  40b843:	mov    QWORD PTR [rax+0x8],rcx
  40b847:	xor    ecx,ecx
  40b849:	mov    QWORD PTR [rax],rcx
  40b84c:	add    rsp,0x8
  40b850:	pop    rdi
  40b851:	pop    rsi
  40b852:	ret
	...

000000000040b860 <__swc_fn_e121059d_000177_2744b483>:
  40b860:	push   rbx
  40b861:	sub    rsp,0x70
  40b865:	cmp    rcx,0xffffffffffffffef
  40b869:	jbe    40b873 <__swc_fn_e121059d_000177_2744b483+0x13>
  40b86b:	xor    eax,eax
  40b86d:	add    rsp,0x70
  40b871:	pop    rbx
  40b872:	ret
  40b873:	vxorps xmm0,xmm0,xmm0
  40b877:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40b87d:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40b883:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40b889:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40b88f:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40b895:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40b89b:	lea    rax,[rcx+0x10]
  40b89f:	mov    QWORD PTR [rsp+0x50],rax
  40b8a4:	mov    DWORD PTR [rsp+0x60],0x10
  40b8ac:	mov    rcx,QWORD PTR [rip+0x1b48d]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40b8b3:	test   rcx,rcx
  40b8b6:	jne    40b8c8 <__swc_fn_e121059d_000177_2744b483+0x68>
  40b8b8:	call   40ea10 <__swc_fn_e121059d_000166_cf398896>
  40b8bd:	lea    rcx,[rax+0x1]
  40b8c1:	mov    QWORD PTR [rip+0x1b478],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40b8c8:	dec    rcx
  40b8cb:	call   40b6c0 <__swc_fn_e121059d_000168_fce60b2b>
  40b8d0:	mov    rcx,QWORD PTR [rax]
  40b8d3:	lea    rdx,[rsp+0x8]
  40b8d8:	mov    rbx,QWORD PTR [rax+0x8]
  40b8dc:	mov    rbx,QWORD PTR [rbx+0x8]
  40b8e0:	call   rbx
  40b8e2:	mov    rax,QWORD PTR [rsp+0x48]
  40b8e7:	test   rax,rax
  40b8ea:	jne    40b8f4 <__swc_fn_e121059d_000177_2744b483+0x94>
  40b8ec:	xor    eax,eax
  40b8ee:	add    rsp,0x70
  40b8f2:	pop    rbx
  40b8f3:	ret
  40b8f4:	mov    rcx,QWORD PTR [rsp+0x50]
  40b8f9:	mov    QWORD PTR [rax],rcx
  40b8fc:	mov    QWORD PTR [rax+0x8],0x0
  40b904:	lea    rax,[rax+0x10]
  40b908:	add    rsp,0x70
  40b90c:	pop    rbx
  40b90d:	ret
	...

000000000040b920 <__swc_fn_e121059d_000001_46f18a51>:
  40b920:	vxorps xmm0,xmm0,xmm0
  40b924:	xor    eax,eax
  40b926:	cs nop WORD PTR [rax+rax*1+0x0]
  40b930:	cs nop WORD PTR [rax+rax*1+0x0]
  40b93a:	nop    WORD PTR [rax+rax*1+0x0]
  40b940:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40b945:	add    rax,0x10
  40b949:	cmp    rax,0x2080
  40b950:	jne    40b940 <__swc_fn_e121059d_000001_46f18a51+0x20>
  40b952:	ret
	...

000000000040b960 <__swc_fn_e121059d_000004_1acc36a6>:
  40b960:	push   rsi
  40b961:	push   rdi
  40b962:	push   r12
  40b964:	push   r13
  40b966:	push   r14
  40b968:	mov    rsi,rcx
  40b96b:	mov    edi,r10d
  40b96e:	mov    r12,rcx
  40b971:	mov    r13,r9
  40b974:	mov    ecx,DWORD PTR [rdx+0x28]
  40b977:	shlx   r14d,r8d,ecx
  40b97c:	mov    rcx,rdx
  40b97f:	mov    edx,r8d
  40b982:	call   40ed80 <__swc_fn_e121059d_000011_6493fbbc>
  40b987:	mov    rcx,rax
  40b98a:	mov    eax,DWORD PTR [r12+0x3c]
  40b98f:	xor    edx,edx
  40b991:	div    rdi
  40b994:	vxorps xmm0,xmm0,xmm0
  40b998:	vmovdqu XMMWORD PTR [rsi],xmm0
  40b99c:	mov    QWORD PTR [r12+0x60],0x0
  40b9a5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40b9aa:	mov    QWORD PTR [r12+0x10],rcx
  40b9af:	imul   rax,rdi
  40b9b3:	lea    rdx,[rcx+rax*1]
  40b9b7:	mov    QWORD PTR [r12+0x18],rdx
  40b9bc:	mov    QWORD PTR [r12+0x20],rcx
  40b9c1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40b9c6:	mov    DWORD PTR [r12+0x28],0x0
  40b9cf:	mov    DWORD PTR [r12+0x68],0x0
  40b9d8:	mov    BYTE PTR [r12+0x39],r13b
  40b9dd:	mov    BYTE PTR [r12+0x3a],r14b
  40b9e2:	mov    BYTE PTR [r12+0x3b],0x1
  40b9e8:	mov    DWORD PTR [r12+0x6c],0x0
  40b9f1:	mov    rcx,r12
  40b9f4:	mov    edx,edi
  40b9f6:	call   40ece0 <__swc_fn_e121059d_000005_b2240b56>
  40b9fb:	pop    r14
  40b9fd:	pop    r13
  40b9ff:	pop    r12
  40ba01:	pop    rdi
  40ba02:	pop    rsi
  40ba03:	ret
	...

000000000040ba10 <__swc_fn_e121059d_000007_614a4804>:
  40ba10:	mov    r8d,0x1
  40ba16:	xor    eax,eax
  40ba18:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40ba1e:	test   eax,eax
  40ba20:	jne    40ba10 <__swc_fn_e121059d_000007_614a4804>
  40ba22:	ret
	...

000000000040ba30 <__swc_fn_e121059d_000010_395bb04b>:
  40ba30:	lea    r8,[rcx+0x60]
  40ba34:	mov    rax,QWORD PTR [r8]
  40ba37:	mov    r9,rax
  40ba3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ba40:	mov    QWORD PTR [rdx],r9
  40ba43:	mov    rax,r9
  40ba46:	lock cmpxchg QWORD PTR [r8],rdx
  40ba4b:	cmp    rax,r9
  40ba4e:	jne    40bab7 <__swc_fn_e121059d_000010_395bb04b+0x87>
  40ba50:	mov    eax,DWORD PTR [rcx+0x6c]
  40ba53:	test   eax,eax
  40ba55:	je     40bab6 <__swc_fn_e121059d_000010_395bb04b+0x86>
  40ba57:	lea    rdx,[rcx+0x70]
  40ba5b:	mov    r9d,0x1
  40ba61:	xor    eax,eax
  40ba63:	lock cmpxchg DWORD PTR [rdx],r9d
  40ba68:	test   eax,eax
  40ba6a:	jne    40bab6 <__swc_fn_e121059d_000010_395bb04b+0x86>
  40ba6c:	mov    rax,rcx
  40ba6f:	and    rax,0xffffffffffc00000
  40ba76:	mov    rax,QWORD PTR [rax+0x8]
  40ba7a:	test   rax,rax
  40ba7d:	jne    40ba85 <__swc_fn_e121059d_000010_395bb04b+0x55>
  40ba7f:	xor    eax,eax
  40ba81:	xchg   DWORD PTR [rdx],eax
  40ba83:	jmp    40bab6 <__swc_fn_e121059d_000010_395bb04b+0x86>
  40ba85:	lea    rdx,[rax+0x2a80]
  40ba8c:	mov    rax,QWORD PTR [rdx]
  40ba8f:	mov    r8,rax
  40ba92:	cs nop WORD PTR [rax+rax*1+0x0]
  40ba9c:	nop    DWORD PTR [rax+0x0]
  40baa0:	mov    QWORD PTR [rcx+0x78],r8
  40baa4:	mov    rax,r8
  40baa7:	lock cmpxchg QWORD PTR [rdx],rcx
  40baac:	cmp    rax,r8
  40baaf:	je     40bab6 <__swc_fn_e121059d_000010_395bb04b+0x86>
  40bab1:	mov    r8,rax
  40bab4:	jmp    40baa0 <__swc_fn_e121059d_000010_395bb04b+0x70>
  40bab6:	ret
  40bab7:	mov    r9,rax
  40baba:	jmp    40ba40 <__swc_fn_e121059d_000010_395bb04b+0x10>
	...

000000000040bac0 <__swc_fn_e121059d_000013_9ba72deb>:
  40bac0:	push   rsi
  40bac1:	push   rdi
  40bac2:	push   r12
  40bac4:	push   r13
  40bac6:	push   r14
  40bac8:	push   r15
  40baca:	push   rbx
  40bacb:	sub    rsp,0x30
  40bacf:	mov    QWORD PTR [rsp+0x18],r8
  40bad4:	mov    rsi,rcx
  40bad7:	mov    rdi,rdx
  40bada:	mov    rdx,QWORD PTR [rsi+0x40]
  40bade:	xchg   ax,ax
  40bae0:	mov    rax,rdx
  40bae3:	not    rax
  40bae6:	and    rax,QWORD PTR [rsi+0x20]
  40baea:	test   rax,rax
  40baed:	jne    40bb01 <__swc_fn_e121059d_000013_9ba72deb+0x41>
  40baef:	xor    eax,eax
  40baf1:	add    rsp,0x30
  40baf5:	pop    rbx
  40baf6:	pop    r15
  40baf8:	pop    r14
  40bafa:	pop    r13
  40bafc:	pop    r12
  40bafe:	pop    rdi
  40baff:	pop    rsi
  40bb00:	ret
  40bb01:	xor    ecx,ecx
  40bb03:	tzcnt  rcx,rax
  40bb08:	lea    r12,[rsp+0x8]
  40bb0d:	mov    DWORD PTR [rsp+0x8],ecx
  40bb11:	mov    r13d,0x1
  40bb17:	shl    r13,cl
  40bb1a:	mov    rcx,rdx
  40bb1d:	or     rcx,r13
  40bb20:	mov    rax,rdx
  40bb23:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40bb29:	cmp    rax,rdx
  40bb2c:	je     40bb33 <__swc_fn_e121059d_000013_9ba72deb+0x73>
  40bb2e:	mov    rdx,rax
  40bb31:	jmp    40bae0 <__swc_fn_e121059d_000013_9ba72deb+0x20>
  40bb33:	mov    eax,DWORD PTR [r12]
  40bb37:	shl    rax,0x4
  40bb3b:	lea    r14,[rsi+rax*8+0x80]
  40bb43:	mov    rcx,rsi
  40bb46:	mov    rax,r12
  40bb49:	mov    edx,DWORD PTR [rax]
  40bb4b:	call   40ed80 <__swc_fn_e121059d_000011_6493fbbc>
  40bb50:	mov    r15,rax
  40bb53:	mov    rcx,rsi
  40bb56:	mov    rdx,r13
  40bb59:	call   40eee0 <__swc_fn_e121059d_000017_4df2d1a0>
  40bb5e:	test   al,al
  40bb60:	je     40bb98 <__swc_fn_e121059d_000013_9ba72deb+0xd8>
  40bb62:	mov    ecx,DWORD PTR [r14+0x3c]
  40bb66:	lea    rdx,[rip+0x184eb]        # 424058 <__swc_bss_base_e121059d+0x18>
  40bb6d:	mov    r8,QWORD PTR [rip+0x184e4]        # 424058 <__swc_bss_base_e121059d+0x18>
  40bb74:	cs nop WORD PTR [rax+rax*1+0x0]
  40bb7e:	xchg   ax,ax
  40bb80:	mov    r9,r8
  40bb83:	sub    r9,rcx
  40bb86:	mov    rax,r8
  40bb89:	lock cmpxchg QWORD PTR [rdx],r9
  40bb8e:	cmp    rax,r8
  40bb91:	je     40bbf9 <__swc_fn_e121059d_000013_9ba72deb+0x139>
  40bb93:	mov    r8,rax
  40bb96:	jmp    40bb80 <__swc_fn_e121059d_000013_9ba72deb+0xc0>
  40bb98:	mov    rcx,rsi
  40bb9b:	mov    rax,r12
  40bb9e:	mov    edx,DWORD PTR [rax]
  40bba0:	call   407450 <__swc_fn_e121059d_000012_c7df5d22>
  40bba5:	mov    rcx,r15
  40bba8:	and    rcx,0xffffffffffff0000
  40bbaf:	lea    rcx,[rcx+0x10000]
  40bbb6:	mov    rbx,rax
  40bbb9:	cmp    rax,rcx
  40bbbc:	cmova  rbx,rcx
  40bbc0:	mov    rax,rbx
  40bbc3:	sub    rax,r15
  40bbc6:	mov    rcx,r15
  40bbc9:	mov    rdx,rax
  40bbcc:	call   4072a0 <__swc_fn_e121059d_000003_7ab4792e>
  40bbd1:	test   al,al
  40bbd3:	jne    40bbf2 <__swc_fn_e121059d_000013_9ba72deb+0x132>
  40bbd5:	mov    rcx,rsi
  40bbd8:	mov    rdx,r13
  40bbdb:	call   407600 <__swc_fn_e121059d_000018_7d1e8a10>
  40bbe0:	xor    eax,eax
  40bbe2:	add    rsp,0x30
  40bbe6:	pop    rbx
  40bbe7:	pop    r15
  40bbe9:	pop    r14
  40bbeb:	pop    r13
  40bbed:	pop    r12
  40bbef:	pop    rdi
  40bbf0:	pop    rsi
  40bbf1:	ret
  40bbf2:	sub    rbx,r15
  40bbf5:	mov    DWORD PTR [r14+0x3c],ebx
  40bbf9:	mov    rcx,r14
  40bbfc:	mov    rdx,rsi
  40bbff:	mov    r8d,DWORD PTR [r12]
  40bc03:	mov    r9d,edi
  40bc06:	mov    rbx,QWORD PTR [rsp+0x18]
  40bc0b:	mov    r10d,ebx
  40bc0e:	call   40b960 <__swc_fn_e121059d_000004_1acc36a6>
  40bc13:	mov    rax,r14
  40bc16:	add    rsp,0x30
  40bc1a:	pop    rbx
  40bc1b:	pop    r15
  40bc1d:	pop    r14
  40bc1f:	pop    r13
  40bc21:	pop    r12
  40bc23:	pop    rdi
  40bc24:	pop    rsi
  40bc25:	ret
	...

000000000040bc30 <__swc_fn_e121059d_000016_4b207b58>:
  40bc30:	mov    r8,QWORD PTR [rcx+0x48]
  40bc34:	cs nop WORD PTR [rax+rax*1+0x0]
  40bc3e:	xchg   ax,ax
  40bc40:	mov    r9,r8
  40bc43:	or     r9,rdx
  40bc46:	mov    rax,r8
  40bc49:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40bc4f:	cmp    rax,r8
  40bc52:	jne    40bc55 <__swc_fn_e121059d_000016_4b207b58+0x25>
  40bc54:	ret
  40bc55:	mov    r8,rax
  40bc58:	jmp    40bc40 <__swc_fn_e121059d_000016_4b207b58+0x10>
  40bc5a:	add    BYTE PTR [rax],al
  40bc5c:	add    BYTE PTR [rax],al
	...

000000000040bc60 <__swc_fn_e121059d_000019_2cc1532c>:
  40bc60:	push   rsi
  40bc61:	push   rdi
  40bc62:	push   r12
  40bc64:	mov    rsi,rcx
  40bc67:	xor    edi,edi
  40bc69:	lea    r12,[rip+0x183f8]        # 424068 <__swc_bss_base_e121059d+0x28>
  40bc70:	mov    eax,DWORD PTR [r12]
  40bc74:	xor    ecx,ecx
  40bc76:	test   rax,rax
  40bc79:	jbe    40bcb4 <__swc_fn_e121059d_000019_2cc1532c+0x54>
  40bc7b:	nop    DWORD PTR [rax+rax*1+0x0]
  40bc80:	lea    rdx,[rip+0x183e9]        # 424070 <__swc_bss_base_e121059d+0x30>
  40bc87:	mov    r8d,ecx
  40bc8a:	lea    r8,[r8+r8*2]
  40bc8e:	lea    r8,[rdx+r8*8]
  40bc92:	mov    rdx,QWORD PTR [r8+0x10]
  40bc96:	add    rdx,0x400000
  40bc9d:	cmp    rdx,0x40000000
  40bca4:	ja     40bcab <__swc_fn_e121059d_000019_2cc1532c+0x4b>
  40bca6:	mov    rdi,r8
  40bca9:	jmp    40bcb4 <__swc_fn_e121059d_000019_2cc1532c+0x54>
  40bcab:	add    rcx,0x1
  40bcaf:	cmp    rcx,rax
  40bcb2:	jb     40bc80 <__swc_fn_e121059d_000019_2cc1532c+0x20>
  40bcb4:	test   rdi,rdi
  40bcb7:	jne    40bd43 <__swc_fn_e121059d_000019_2cc1532c+0xe3>
  40bcbd:	cmp    DWORD PTR [r12],0x10
  40bcc2:	jae    40bd2b <__swc_fn_e121059d_000019_2cc1532c+0xcb>
  40bcc4:	mov    ecx,0x40400000
  40bcc9:	call   40eca0 <__swc_fn_e121059d_000002_884bb5c0>
  40bcce:	test   rax,rax
  40bcd1:	je     40bd2b <__swc_fn_e121059d_000019_2cc1532c+0xcb>
  40bcd3:	lea    rcx,[rip+0x18396]        # 424070 <__swc_bss_base_e121059d+0x30>
  40bcda:	mov    edx,DWORD PTR [r12]
  40bcde:	lea    rdx,[rdx+rdx*2]
  40bce2:	lea    rdx,[rcx+rdx*8]
  40bce6:	mov    QWORD PTR [rdx],rax
  40bce9:	lea    rax,[rax+0x3fffff]
  40bcf0:	and    rax,0xffffffffffc00000
  40bcf7:	mov    QWORD PTR [rdx+0x8],rax
  40bcfb:	mov    QWORD PTR [rdx+0x10],0x0
  40bd03:	mov    edx,DWORD PTR [rip+0x1835f]        # 424068 <__swc_bss_base_e121059d+0x28>
  40bd09:	nop    DWORD PTR [rax+0x0]
  40bd10:	lea    r9d,[rdx+0x1]
  40bd14:	mov    rax,rdx
  40bd17:	lock cmpxchg DWORD PTR [r12],r9d
  40bd1d:	mov    r8d,eax
  40bd20:	cmp    eax,edx
  40bd22:	je     40bd32 <__swc_fn_e121059d_000019_2cc1532c+0xd2>
  40bd24:	mov    rdx,r8
  40bd27:	jmp    40bd10 <__swc_fn_e121059d_000019_2cc1532c+0xb0>
  40bd29:	jmp    40bd32 <__swc_fn_e121059d_000019_2cc1532c+0xd2>
  40bd2b:	xor    eax,eax
  40bd2d:	pop    r12
  40bd2f:	pop    rdi
  40bd30:	pop    rsi
  40bd31:	ret
  40bd32:	mov    eax,DWORD PTR [rip+0x18330]        # 424068 <__swc_bss_base_e121059d+0x28>
  40bd38:	sub    eax,0x1
  40bd3b:	lea    rdi,[rax+rax*2]
  40bd3f:	lea    rdi,[rcx+rdi*8]
  40bd43:	mov    r12,QWORD PTR [rdi+0x8]
  40bd47:	add    r12,QWORD PTR [rdi+0x10]
  40bd4b:	mov    rcx,r12
  40bd4e:	mov    edx,0x3000
  40bd53:	call   4072a0 <__swc_fn_e121059d_000003_7ab4792e>
  40bd58:	test   al,al
  40bd5a:	jne    40bd63 <__swc_fn_e121059d_000019_2cc1532c+0x103>
  40bd5c:	xor    eax,eax
  40bd5e:	pop    r12
  40bd60:	pop    rdi
  40bd61:	pop    rsi
  40bd62:	ret
  40bd63:	vxorps xmm0,xmm0,xmm0
  40bd67:	xor    eax,eax
  40bd69:	cs nop WORD PTR [rax+rax*1+0x0]
  40bd73:	cs nop WORD PTR [rax+rax*1+0x0]
  40bd7d:	nop    DWORD PTR [rax]
  40bd80:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40bd86:	add    rax,0x10
  40bd8a:	cmp    rax,0x3000
  40bd91:	jne    40bd80 <__swc_fn_e121059d_000019_2cc1532c+0x120>
  40bd93:	mov    DWORD PTR [r12+0x28],esi
  40bd98:	mov    eax,0x40
  40bd9d:	mov    ecx,esi
  40bd9f:	shr    eax,cl
  40bda1:	mov    DWORD PTR [r12+0x2c],eax
  40bda6:	cmp    DWORD PTR [r12+0x2c],0x40
  40bdac:	jb     40bdb7 <__swc_fn_e121059d_000019_2cc1532c+0x157>
  40bdae:	mov    rax,0xffffffffffffffff
  40bdb5:	jmp    40bdc7 <__swc_fn_e121059d_000019_2cc1532c+0x167>
  40bdb7:	mov    eax,0x1
  40bdbc:	mov    ecx,DWORD PTR [r12+0x2c]
  40bdc1:	shl    rax,cl
  40bdc4:	dec    rax
  40bdc7:	mov    QWORD PTR [r12+0x20],rax
  40bdcc:	mov    DWORD PTR [r12],0x4e540001
  40bdd4:	mov    DWORD PTR [r12+0x4],0x53474d45
  40bddd:	add    QWORD PTR [rdi+0x10],0x400000
  40bde5:	mov    rax,r12
  40bde8:	pop    r12
  40bdea:	pop    rdi
  40bdeb:	pop    rsi
  40bdec:	ret
  40bded:	add    BYTE PTR [rax],al
	...

000000000040bdf0 <__swc_fn_e121059d_000022_3a2e2048>:
  40bdf0:	mov    eax,0x1
  40bdf5:	mov    edx,DWORD PTR [rip+0x1826d]        # 424068 <__swc_bss_base_e121059d+0x28>
  40bdfb:	cmp    eax,edx
  40bdfd:	jae    40be4b <__swc_fn_e121059d_000022_3a2e2048+0x5b>
  40bdff:	nop
  40be00:	lea    r8,[rip+0x18269]        # 424070 <__swc_bss_base_e121059d+0x30>
  40be07:	lea    r9,[rax+rax*2]
  40be0b:	lea    r9,[r8+r9*8]
  40be0f:	mov    r8,rcx
  40be12:	sub    r8,QWORD PTR [r9+0x8]
  40be16:	mov    r9,QWORD PTR [r9+0x10]
  40be1a:	cmp    r8,r9
  40be1d:	jae    40be45 <__swc_fn_e121059d_000022_3a2e2048+0x55>
  40be1f:	mov    rax,rcx
  40be22:	and    rax,0xffffffffffc00000
  40be29:	shr    rcx,0x10
  40be2d:	and    ecx,0x3f
  40be30:	mov    edx,DWORD PTR [rax+0x28]
  40be33:	shrx   ecx,ecx,edx
  40be38:	shl    rcx,0x4
  40be3c:	lea    rax,[rax+rcx*8+0x80]
  40be44:	ret
  40be45:	inc    eax
  40be47:	cmp    eax,edx
  40be49:	jb     40be00 <__swc_fn_e121059d_000022_3a2e2048+0x10>
  40be4b:	xor    eax,eax
  40be4d:	ret
	...

000000000040be50 <__swc_fn_e121059d_000025_4aca8b9e>:
  40be50:	vxorps xmm0,xmm0,xmm0
  40be54:	vmovups XMMWORD PTR [rcx],xmm0
  40be58:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40be5d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40be62:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40be67:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40be6c:	mov    QWORD PTR [rcx+0x50],0x0
  40be74:	ret
	...

000000000040be80 <__swc_fn_e121059d_000028_4aca8b9e>:
  40be80:	vxorps xmm0,xmm0,xmm0
  40be84:	xor    eax,eax
  40be86:	cs nop WORD PTR [rax+rax*1+0x0]
  40be90:	cs nop WORD PTR [rax+rax*1+0x0]
  40be9a:	nop    WORD PTR [rax+rax*1+0x0]
  40bea0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40bea5:	add    rax,0x10
  40bea9:	cmp    rax,0x9b0
  40beb0:	jne    40bea0 <__swc_fn_e121059d_000028_4aca8b9e+0x20>
  40beb2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40bebd:	ret
	...

000000000040bec0 <__swc_fn_e121059d_000031_90860ff2>:
  40bec0:	push   rsi
  40bec1:	push   rdi
  40bec2:	sub    rsp,0x8
  40bec6:	lea    rsi,[rip+0x1613b]        # 422008 <__swc_data_base_e121059d+0x8>
  40becd:	mov    rax,QWORD PTR [rsi]
  40bed0:	mov    ecx,0xffffffff
  40bed5:	cmp    rax,rcx
  40bed8:	je     40bee1 <__swc_fn_e121059d_000031_90860ff2+0x21>
  40beda:	add    rsp,0x8
  40bede:	pop    rdi
  40bedf:	pop    rsi
  40bee0:	ret
  40bee1:	mov    rcx,QWORD PTR [rip+0x71d0]        # 4130b8 <__swc_fn_e121059d_000179_68d30882+0x15d8>
  40bee8:	call   40deb0 <__swc_fn_e121059d_000127_102fe7b9>
  40beed:	mov    rcx,rax
  40bef0:	mov    eax,0xffffffff
  40bef5:	lock cmpxchg QWORD PTR [rsi],rcx
  40befa:	mov    rdi,rax
  40befd:	mov    eax,0xffffffff
  40bf02:	cmp    rdi,rax
  40bf05:	je     40bf16 <__swc_fn_e121059d_000031_90860ff2+0x56>
  40bf07:	call   411010 <__swc_fn_e121059d_000128_8dffa290>
  40bf0c:	mov    rax,rdi
  40bf0f:	add    rsp,0x8
  40bf13:	pop    rdi
  40bf14:	pop    rsi
  40bf15:	ret
  40bf16:	mov    rax,rcx
  40bf19:	add    rsp,0x8
  40bf1d:	pop    rdi
  40bf1e:	pop    rsi
  40bf1f:	ret

000000000040bf20 <__swc_fn_e121059d_000034_25f19556>:
  40bf20:	sub    rsp,0x8
  40bf24:	vxorps xmm0,xmm0,xmm0
  40bf28:	xor    eax,eax
  40bf2a:	cs nop WORD PTR [rax+rax*1+0x0]
  40bf34:	cs nop WORD PTR [rax+rax*1+0x0]
  40bf3e:	xchg   ax,ax
  40bf40:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40bf45:	add    rax,0x10
  40bf49:	cmp    rax,0x2b00
  40bf50:	jne    40bf40 <__swc_fn_e121059d_000034_25f19556+0x20>
  40bf52:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40bf5c:	xor    al,al
  40bf5e:	mov    rdx,rax
  40bf61:	xor    al,al
  40bf63:	mov    r8,rax
  40bf66:	xor    al,al
  40bf68:	mov    r9,rax
  40bf6b:	xor    al,al
  40bf6d:	mov    r10,rax
  40bf70:	xor    al,al
  40bf72:	mov    r11,rax
  40bf75:	call   40f110 <__swc_fn_e121059d_000035_95622a2b>
  40bf7a:	add    rsp,0x8
  40bf7e:	ret
	...

000000000040bf80 <__swc_fn_e121059d_000037_b4982903>:
  40bf80:	push   rsi
  40bf81:	push   rdi
  40bf82:	push   r12
  40bf84:	mov    rsi,r8
  40bf87:	mov    rdi,rdx
  40bf8a:	mov    rcx,rdx
  40bf8d:	call   40eca0 <__swc_fn_e121059d_000002_884bb5c0>
  40bf92:	mov    r12,rax
  40bf95:	test   rax,rax
  40bf98:	jne    40bfa1 <__swc_fn_e121059d_000037_b4982903+0x21>
  40bf9a:	xor    eax,eax
  40bf9c:	pop    r12
  40bf9e:	pop    rdi
  40bf9f:	pop    rsi
  40bfa0:	ret
  40bfa1:	mov    rcx,r12
  40bfa4:	mov    rdx,rsi
  40bfa7:	call   4072a0 <__swc_fn_e121059d_000003_7ab4792e>
  40bfac:	test   al,al
  40bfae:	jne    40bfc2 <__swc_fn_e121059d_000037_b4982903+0x42>
  40bfb0:	mov    rcx,r12
  40bfb3:	mov    rdx,rdi
  40bfb6:	call   4098a0 <__swc_fn_e121059d_000114_49b378a9>
  40bfbb:	xor    eax,eax
  40bfbd:	pop    r12
  40bfbf:	pop    rdi
  40bfc0:	pop    rsi
  40bfc1:	ret
  40bfc2:	mov    rax,r12
  40bfc5:	pop    r12
  40bfc7:	pop    rdi
  40bfc8:	pop    rsi
  40bfc9:	ret
	...

000000000040bfe0 <__swc_fn_e121059d_000040_6895916d>:
  40bfe0:	push   rsi
  40bfe1:	push   rdi
  40bfe2:	push   r12
  40bfe4:	mov    rsi,rcx
  40bfe7:	mov    edx,0x9b8
  40bfec:	call   40f180 <__swc_fn_e121059d_000038_788ceb38>
  40bff1:	mov    rdi,rax
  40bff4:	test   rax,rax
  40bff7:	jne    40c000 <__swc_fn_e121059d_000040_6895916d+0x20>
  40bff9:	xor    eax,eax
  40bffb:	pop    r12
  40bffd:	pop    rdi
  40bffe:	pop    rsi
  40bfff:	ret
  40c000:	vxorps xmm0,xmm0,xmm0
  40c004:	xor    eax,eax
  40c006:	cs nop WORD PTR [rax+rax*1+0x0]
  40c010:	cs nop WORD PTR [rax+rax*1+0x0]
  40c01a:	nop    WORD PTR [rax+rax*1+0x0]
  40c020:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40c025:	add    rax,0x10
  40c029:	cmp    rax,0x9b0
  40c030:	jne    40c020 <__swc_fn_e121059d_000040_6895916d+0x40>
  40c032:	mov    QWORD PTR [rdi+0x9b0],0x0
  40c03d:	mov    QWORD PTR [rdi],rsi
  40c040:	call   4110c0 <__swc_fn_e121059d_000131_c1196dfb>
  40c045:	mov    QWORD PTR [rdi+0x18],rax
  40c049:	lea    r12,[rsi+0x10]
  40c04d:	mov    rcx,r12
  40c050:	call   40e100 <__swc_fn_e121059d_000136_e3032dc2>
  40c055:	mov    rax,QWORD PTR [rsi+0x20]
  40c059:	mov    QWORD PTR [rdi+0x8],rax
  40c05d:	mov    rax,QWORD PTR [rsi+0x20]
  40c061:	test   rax,rax
  40c064:	je     40c06a <__swc_fn_e121059d_000040_6895916d+0x8a>
  40c066:	mov    QWORD PTR [rax+0x10],rdi
  40c06a:	mov    QWORD PTR [rsi+0x20],rdi
  40c06e:	mov    rcx,r12
  40c071:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40c076:	mov    rax,rdi
  40c079:	pop    r12
  40c07b:	pop    rdi
  40c07c:	pop    rsi
  40c07d:	ret
	...

000000000040c080 <__swc_fn_e121059d_000043_957e4917>:
  40c080:	mov    rax,QWORD PTR [rdx+0x10]
  40c084:	test   rax,rax
  40c087:	je     40c093 <__swc_fn_e121059d_000043_957e4917+0x13>
  40c089:	mov    rcx,QWORD PTR [rdx+0x8]
  40c08d:	mov    QWORD PTR [rax+0x8],rcx
  40c091:	jmp    40c09b <__swc_fn_e121059d_000043_957e4917+0x1b>
  40c093:	mov    rax,QWORD PTR [rdx+0x8]
  40c097:	mov    QWORD PTR [rcx+0x20],rax
  40c09b:	mov    rax,QWORD PTR [rdx+0x8]
  40c09f:	test   rax,rax
  40c0a2:	je     40c0ac <__swc_fn_e121059d_000043_957e4917+0x2c>
  40c0a4:	mov    rcx,QWORD PTR [rdx+0x10]
  40c0a8:	mov    QWORD PTR [rax+0x10],rcx
  40c0ac:	vxorps xmm0,xmm0,xmm0
  40c0b0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40c0b5:	ret
	...

000000000040c0c0 <__swc_fn_e121059d_000046_88f44774>:
  40c0c0:	sub    rsp,0x8
  40c0c4:	mov    r9,r8
  40c0c7:	mov    r10,rdx
  40c0ca:	call   40f230 <__swc_fn_e121059d_000044_9c2ade9b>
  40c0cf:	mov    eax,0x1
  40c0d4:	xchg   DWORD PTR [r9+0x6c],eax
  40c0d8:	mov    rax,QWORD PTR [r9+0x60]
  40c0dc:	test   rax,rax
  40c0df:	je     40c123 <__swc_fn_e121059d_000046_88f44774+0x63>
  40c0e1:	xor    eax,eax
  40c0e3:	xchg   DWORD PTR [r9+0x6c],eax
  40c0e7:	movzx  eax,BYTE PTR [r9+0x39]
  40c0ec:	lea    rax,[rax+rax*4]
  40c0f0:	lea    rax,[r10+rax*8+0x28]
  40c0f5:	mov    QWORD PTR [r9+0x50],0x0
  40c0fd:	mov    rcx,QWORD PTR [rax+0x8]
  40c101:	mov    QWORD PTR [r9+0x48],rcx
  40c105:	mov    rcx,QWORD PTR [rax+0x8]
  40c109:	test   rcx,rcx
  40c10c:	je     40c114 <__swc_fn_e121059d_000046_88f44774+0x54>
  40c10e:	mov    QWORD PTR [rcx+0x50],r9
  40c112:	jmp    40c118 <__swc_fn_e121059d_000046_88f44774+0x58>
  40c114:	mov    QWORD PTR [rax+0x10],r9
  40c118:	mov    QWORD PTR [rax+0x8],r9
  40c11c:	xor    eax,eax
  40c11e:	add    rsp,0x8
  40c122:	ret
  40c123:	movzx  eax,BYTE PTR [r9+0x39]
  40c128:	lea    rax,[rax+rax*4]
  40c12c:	lea    rax,[r10+rax*8+0x28]
  40c131:	mov    QWORD PTR [r9+0x50],0x0
  40c139:	mov    rcx,QWORD PTR [rax+0x18]
  40c13d:	mov    QWORD PTR [r9+0x48],rcx
  40c141:	mov    rcx,QWORD PTR [rax+0x18]
  40c145:	test   rcx,rcx
  40c148:	je     40c14e <__swc_fn_e121059d_000046_88f44774+0x8e>
  40c14a:	mov    QWORD PTR [rcx+0x50],r9
  40c14e:	mov    QWORD PTR [rax+0x18],r9
  40c152:	mov    eax,0x1
  40c157:	add    rsp,0x8
  40c15b:	ret
  40c15c:	add    BYTE PTR [rax],al
	...

000000000040c160 <__swc_fn_e121059d_000049_2ff013cc>:
  40c160:	push   r12
  40c162:	push   r13
  40c164:	push   rdi
  40c165:	push   rsi
  40c166:	push   r14
  40c168:	push   r15
  40c16a:	sub    rsp,0x178
  40c171:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40c17a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40c183:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40c18c:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40c195:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40c19e:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40c1a7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40c1b0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40c1b9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40c1c2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40c1cb:	mov    r12,rcx
  40c1ce:	lea    rax,[rip+0x1802b]        # 424200 <__swc_bss_base_e121059d+0x1c0>
  40c1d5:	mov    rcx,QWORD PTR [rax]
  40c1d8:	mov    r13,rcx
  40c1db:	test   rcx,rcx
  40c1de:	jne    40c1ee <__swc_fn_e121059d_000049_2ff013cc+0x8e>
  40c1e0:	mov    r13d,0x1dcd6500
  40c1e6:	mov    ecx,0x1dcd6500
  40c1eb:	xchg   QWORD PTR [rax],rcx
  40c1ee:	lea    rax,[rip+0x15e0b]        # 422000 <__swc_data_base_e121059d>
  40c1f5:	mov    rax,QWORD PTR [rax]
  40c1f8:	cmp    rax,0xffffffffffffffff
  40c1fc:	je     40c20b <__swc_fn_e121059d_000049_2ff013cc+0xab>
  40c1fe:	mov    eax,eax
  40c200:	mov    edi,eax
  40c202:	xor    eax,eax
  40c204:	call   407000 <pthread_getspecific@plt>
  40c209:	jmp    40c20d <__swc_fn_e121059d_000049_2ff013cc+0xad>
  40c20b:	xor    eax,eax
  40c20d:	test   rax,rax
  40c210:	jne    40c21f <__swc_fn_e121059d_000049_2ff013cc+0xbf>
  40c212:	call   40bec0 <__swc_fn_e121059d_000031_90860ff2>
  40c217:	mov    rcx,rax
  40c21a:	call   409c00 <__swc_fn_e121059d_000129_41c3251c>
  40c21f:	test   rax,rax
  40c222:	je     40c234 <__swc_fn_e121059d_000049_2ff013cc+0xd4>
  40c224:	cmp    QWORD PTR [rax],r12
  40c227:	jne    40c234 <__swc_fn_e121059d_000049_2ff013cc+0xd4>
  40c229:	cmp    DWORD PTR [rax+0x20],0x0
  40c22d:	jne    40c234 <__swc_fn_e121059d_000049_2ff013cc+0xd4>
  40c22f:	mov    rsi,rax
  40c232:	jmp    40c236 <__swc_fn_e121059d_000049_2ff013cc+0xd6>
  40c234:	xor    esi,esi
  40c236:	lea    rdi,[r12+0x2a88]
  40c23e:	mov    r14,QWORD PTR [rdi]
  40c241:	test   r14,r14
  40c244:	jne    40c293 <__swc_fn_e121059d_000049_2ff013cc+0x133>
  40c246:	lea    rax,[rip+0x17e0b]        # 424058 <__swc_bss_base_e121059d+0x18>
  40c24d:	mov    rax,QWORD PTR [rax]
  40c250:	test   rax,rax
  40c253:	setne  al
  40c256:	jne    40c27a <__swc_fn_e121059d_000049_2ff013cc+0x11a>
  40c258:	mov    rax,QWORD PTR [r12+0x2a70]
  40c260:	test   rax,rax
  40c263:	setne  al
  40c266:	jne    40c27a <__swc_fn_e121059d_000049_2ff013cc+0x11a>
  40c268:	test   rsi,rsi
  40c26b:	setne  al
  40c26e:	je     40c27a <__swc_fn_e121059d_000049_2ff013cc+0x11a>
  40c270:	cmp    DWORD PTR [rsi+0x730],0x0
  40c277:	setne  al
  40c27a:	test   al,al
  40c27c:	je     40c28e <__swc_fn_e121059d_000049_2ff013cc+0x12e>
  40c27e:	call   409cb0 <__swc_fn_e121059d_000132_944f555b>
  40c283:	lea    rcx,[rax+r13*1]
  40c287:	xor    eax,eax
  40c289:	lock cmpxchg QWORD PTR [rdi],rcx
  40c28e:	jmp    40c393 <__swc_fn_e121059d_000049_2ff013cc+0x233>
  40c293:	call   409cb0 <__swc_fn_e121059d_000132_944f555b>
  40c298:	mov    r15,rax
  40c29b:	cmp    rax,r14
  40c29e:	jb     40c2af <__swc_fn_e121059d_000049_2ff013cc+0x14f>
  40c2a0:	xor    ecx,ecx
  40c2a2:	mov    rax,r14
  40c2a5:	lock cmpxchg QWORD PTR [rdi],rcx
  40c2aa:	cmp    rax,r14
  40c2ad:	je     40c2b4 <__swc_fn_e121059d_000049_2ff013cc+0x154>
  40c2af:	jmp    40c393 <__swc_fn_e121059d_000049_2ff013cc+0x233>
  40c2b4:	test   rsi,rsi
  40c2b7:	je     40c2d2 <__swc_fn_e121059d_000049_2ff013cc+0x172>
  40c2b9:	cmp    r15,r13
  40c2bc:	jb     40c2d2 <__swc_fn_e121059d_000049_2ff013cc+0x172>
  40c2be:	mov    rax,r15
  40c2c1:	sub    rax,r13
  40c2c4:	mov    rcx,r12
  40c2c7:	mov    rdx,rsi
  40c2ca:	mov    r8,rax
  40c2cd:	call   40f670 <__swc_fn_e121059d_000059_3ca3ac64>
  40c2d2:	lea    rsi,[r12+0x10]
  40c2d7:	mov    rcx,rsi
  40c2da:	call   40e100 <__swc_fn_e121059d_000136_e3032dc2>
  40c2df:	mov    rax,QWORD PTR [r12+0x18]
  40c2e4:	mov    rdi,rax
  40c2e7:	test   rdi,rdi
  40c2ea:	je     40c314 <__swc_fn_e121059d_000049_2ff013cc+0x1b4>
  40c2ec:	cs nop WORD PTR [rax+rax*1+0x0]
  40c2f6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c300:	mov    rcx,rdi
  40c303:	call   407470 <__swc_fn_e121059d_000015_07eb9884>
  40c308:	mov    rax,QWORD PTR [rdi+0x10]
  40c30c:	mov    rdi,rax
  40c30f:	test   rax,rax
  40c312:	jne    40c300 <__swc_fn_e121059d_000049_2ff013cc+0x1a0>
  40c314:	mov    rcx,rsi
  40c317:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40c31c:	mov    rcx,r12
  40c31f:	call   40e100 <__swc_fn_e121059d_000136_e3032dc2>
  40c324:	xor    esi,esi
  40c326:	cs nop WORD PTR [rax+rax*1+0x0]
  40c330:	mov    rax,QWORD PTR [r12+0x2a70]
  40c338:	cmp    rsi,rax
  40c33b:	jae    40c38b <__swc_fn_e121059d_000049_2ff013cc+0x22b>
  40c33d:	lea    rax,[rsi+rsi*4]
  40c341:	lea    rax,[r12+rax*8+0x268]
  40c349:	mov    r8,QWORD PTR [rax]
  40c34c:	mov    r9,QWORD PTR [rax+0x8]
  40c350:	mov    r10,QWORD PTR [rax+0x10]
  40c354:	mov    rax,QWORD PTR [rax+0x20]
  40c358:	cmp    rax,r15
  40c35b:	jae    40c368 <__swc_fn_e121059d_000049_2ff013cc+0x208>
  40c35d:	mov    rcx,r15
  40c360:	sub    rcx,rax
  40c363:	cmp    rcx,r13
  40c366:	jae    40c36d <__swc_fn_e121059d_000049_2ff013cc+0x20d>
  40c368:	inc    rsi
  40c36b:	jmp    40c330 <__swc_fn_e121059d_000049_2ff013cc+0x1d0>
  40c36d:	mov    rcx,r12
  40c370:	mov    rdx,rsi
  40c373:	call   40f620 <__swc_fn_e121059d_000056_38b21f11>
  40c378:	mov    rcx,r12
  40c37b:	mov    rdx,r8
  40c37e:	mov    r8,r9
  40c381:	mov    r9,r10
  40c384:	call   407750 <__swc_fn_e121059d_000039_40d1e569>
  40c389:	jmp    40c330 <__swc_fn_e121059d_000049_2ff013cc+0x1d0>
  40c38b:	mov    rcx,r12
  40c38e:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40c393:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40c39c:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40c3a5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40c3ae:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40c3b7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40c3c0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40c3c9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40c3d2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40c3db:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40c3e4:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40c3ed:	add    rsp,0x178
  40c3f4:	pop    r15
  40c3f6:	pop    r14
  40c3f8:	pop    rsi
  40c3f9:	pop    rdi
  40c3fa:	pop    r13
  40c3fc:	pop    r12
  40c3fe:	ret
	...

000000000040c400 <__swc_fn_e121059d_000052_c7484fb0>:
  40c400:	lea    rax,[rdx-0x58]
  40c404:	ret
	...

000000000040c410 <__swc_fn_e121059d_000055_81f7713d>:
  40c410:	push   rsi
  40c411:	push   rdi
  40c412:	push   r12
  40c414:	push   r13
  40c416:	sub    rsp,0x68
  40c41a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40c420:	mov    rsi,r9
  40c423:	mov    rdi,rcx
  40c426:	mov    r12,rdx
  40c429:	mov    r13,r8
  40c42c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40c434:	jne    40c443 <__swc_fn_e121059d_000055_81f7713d+0x33>
  40c436:	xor    eax,eax
  40c438:	add    rsp,0x68
  40c43c:	pop    r13
  40c43e:	pop    r12
  40c440:	pop    rdi
  40c441:	pop    rsi
  40c442:	ret
  40c443:	mov    rcx,rdi
  40c446:	call   40e100 <__swc_fn_e121059d_000136_e3032dc2>
  40c44b:	movabs rax,0x7fffffffffffffff
  40c455:	cmp    r12,rax
  40c458:	mov    rax,0xffffffffffffffff
  40c45f:	lea    rcx,[r12+r12*1]
  40c463:	cmovbe rax,rcx
  40c467:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40c46e:	mov    rdx,rcx
  40c471:	sub    rax,r12
  40c474:	inc    rax
  40c477:	xor    r8d,r8d
  40c47a:	test   rcx,rcx
  40c47d:	jbe    40c4a8 <__swc_fn_e121059d_000055_81f7713d+0x98>
  40c47f:	nop
  40c480:	lea    r9,[r8+r8*4]
  40c484:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40c48c:	sub    r9,r12
  40c48f:	cmp    r9,rax
  40c492:	jae    40c49f <__swc_fn_e121059d_000055_81f7713d+0x8f>
  40c494:	mov    rdx,r8
  40c497:	mov    rax,r9
  40c49a:	test   r9,r9
  40c49d:	je     40c4a8 <__swc_fn_e121059d_000055_81f7713d+0x98>
  40c49f:	add    r8,0x1
  40c4a3:	cmp    r8,rcx
  40c4a6:	jb     40c480 <__swc_fn_e121059d_000055_81f7713d+0x70>
  40c4a8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40c4af:	cmp    rdx,rax
  40c4b2:	jne    40c4cf <__swc_fn_e121059d_000055_81f7713d+0xbf>
  40c4b4:	mov    rcx,rdi
  40c4b7:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40c4bc:	xor    eax,eax
  40c4be:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40c4c4:	add    rsp,0x68
  40c4c8:	pop    r13
  40c4ca:	pop    r12
  40c4cc:	pop    rdi
  40c4cd:	pop    rsi
  40c4ce:	ret
  40c4cf:	lea    rax,[rdx+rdx*4]
  40c4d3:	lea    rax,[rdi+rax*8+0x268]
  40c4db:	vmovups xmm6,XMMWORD PTR [rax]
  40c4df:	mov    r8,QWORD PTR [rax+0x10]
  40c4e3:	mov    rcx,rdi
  40c4e6:	call   40f620 <__swc_fn_e121059d_000056_38b21f11>
  40c4eb:	vpshufd xmm0,xmm6,0xee
  40c4f0:	vmovsd QWORD PTR [r13+0x0],xmm0
  40c4f6:	mov    QWORD PTR [rsi],r8
  40c4f9:	mov    rcx,rdi
  40c4fc:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40c501:	vmovq  rax,xmm6
  40c506:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40c50c:	add    rsp,0x68
  40c510:	pop    r13
  40c512:	pop    r12
  40c514:	pop    rdi
  40c515:	pop    rsi
  40c516:	ret
	...

000000000040c520 <__swc_fn_e121059d_000058_8bd8d1d5>:
  40c520:	push   r12
  40c522:	push   r13
  40c524:	push   r14
  40c526:	push   r15
  40c528:	push   rdi
  40c529:	push   rsi
  40c52a:	sub    rsp,0x148
  40c531:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40c53a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40c543:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40c54c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40c555:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40c55e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40c567:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40c570:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40c579:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40c582:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40c58b:	mov    r12,r9
  40c58e:	mov    r13,rcx
  40c591:	mov    r14,rdx
  40c594:	mov    r15,r8
  40c597:	test   rdx,rdx
  40c59a:	jne    40c5ae <__swc_fn_e121059d_000058_8bd8d1d5+0x8e>
  40c59c:	add    rsp,0x148
  40c5a3:	pop    rsi
  40c5a4:	pop    rdi
  40c5a5:	pop    r15
  40c5a7:	pop    r14
  40c5a9:	pop    r13
  40c5ab:	pop    r12
  40c5ad:	ret
  40c5ae:	cmp    r12,0x200000
  40c5b5:	ja     40c647 <__swc_fn_e121059d_000058_8bd8d1d5+0x127>
  40c5bb:	lea    rax,[rip+0x15a3e]        # 422000 <__swc_data_base_e121059d>
  40c5c2:	mov    rax,QWORD PTR [rax]
  40c5c5:	cmp    rax,0xffffffffffffffff
  40c5c9:	je     40c5d8 <__swc_fn_e121059d_000058_8bd8d1d5+0xb8>
  40c5cb:	mov    eax,eax
  40c5cd:	mov    edi,eax
  40c5cf:	xor    eax,eax
  40c5d1:	call   407000 <pthread_getspecific@plt>
  40c5d6:	jmp    40c5da <__swc_fn_e121059d_000058_8bd8d1d5+0xba>
  40c5d8:	xor    eax,eax
  40c5da:	test   rax,rax
  40c5dd:	je     40c5e4 <__swc_fn_e121059d_000058_8bd8d1d5+0xc4>
  40c5df:	mov    rsi,rax
  40c5e2:	jmp    40c5f4 <__swc_fn_e121059d_000058_8bd8d1d5+0xd4>
  40c5e4:	call   40bec0 <__swc_fn_e121059d_000031_90860ff2>
  40c5e9:	mov    rcx,rax
  40c5ec:	call   409c00 <__swc_fn_e121059d_000129_41c3251c>
  40c5f1:	mov    rsi,rax
  40c5f4:	test   rsi,rsi
  40c5f7:	je     40c647 <__swc_fn_e121059d_000058_8bd8d1d5+0x127>
  40c5f9:	cmp    QWORD PTR [rsi],r13
  40c5fc:	jne    40c647 <__swc_fn_e121059d_000058_8bd8d1d5+0x127>
  40c5fe:	cmp    DWORD PTR [rsi+0x20],0x0
  40c602:	jne    40c647 <__swc_fn_e121059d_000058_8bd8d1d5+0x127>
  40c604:	cmp    DWORD PTR [rsi+0x730],0x10
  40c60b:	jae    40c647 <__swc_fn_e121059d_000058_8bd8d1d5+0x127>
  40c60d:	mov    eax,DWORD PTR [rsi+0x730]
  40c613:	lea    rdi,[rax+rax*4]
  40c617:	lea    rdi,[rsi+rdi*8+0x738]
  40c61f:	mov    QWORD PTR [rdi],r14
  40c622:	mov    QWORD PTR [rdi+0x8],r15
  40c626:	mov    QWORD PTR [rdi+0x10],r12
  40c62a:	mov    QWORD PTR [rdi+0x18],0x0
  40c632:	call   409cb0 <__swc_fn_e121059d_000132_944f555b>
  40c637:	mov    QWORD PTR [rdi+0x20],rax
  40c63b:	add    DWORD PTR [rsi+0x730],0x1
  40c642:	jmp    40c7a6 <__swc_fn_e121059d_000058_8bd8d1d5+0x286>
  40c647:	mov    rcx,r13
  40c64a:	call   407e90 <__swc_fn_e121059d_000057_5b81d8b6>
  40c64f:	mov    rsi,rax
  40c652:	cmp    r12,rax
  40c655:	jbe    40c68a <__swc_fn_e121059d_000058_8bd8d1d5+0x16a>
  40c657:	cmp    r12,0x10000000
  40c65e:	seta   al
  40c661:	ja     40c670 <__swc_fn_e121059d_000058_8bd8d1d5+0x150>
  40c663:	mov    rax,QWORD PTR [r13+0x2a70]
  40c66a:	test   rax,rax
  40c66d:	setne  al
  40c670:	test   al,al
  40c672:	je     40c68a <__swc_fn_e121059d_000058_8bd8d1d5+0x16a>
  40c674:	mov    rcx,r13
  40c677:	mov    rdx,r14
  40c67a:	mov    r8,r15
  40c67d:	mov    r9,r12
  40c680:	call   407750 <__swc_fn_e121059d_000039_40d1e569>
  40c685:	jmp    40c7a6 <__swc_fn_e121059d_000058_8bd8d1d5+0x286>
  40c68a:	call   409cb0 <__swc_fn_e121059d_000132_944f555b>
  40c68f:	mov    rdi,rax
  40c692:	mov    rcx,r13
  40c695:	call   40e100 <__swc_fn_e121059d_000136_e3032dc2>
  40c69a:	cmp    QWORD PTR [r13+0x2a70],0x0
  40c6a2:	je     40c75a <__swc_fn_e121059d_000058_8bd8d1d5+0x23a>
  40c6a8:	nop    DWORD PTR [rax+rax*1+0x0]
  40c6b0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40c6bb:	jae    40c6d0 <__swc_fn_e121059d_000058_8bd8d1d5+0x1b0>
  40c6bd:	mov    rax,QWORD PTR [r13+0x2a68]
  40c6c4:	add    rax,r12
  40c6c7:	cmp    rax,rsi
  40c6ca:	jbe    40c75a <__swc_fn_e121059d_000058_8bd8d1d5+0x23a>
  40c6d0:	xor    eax,eax
  40c6d2:	mov    rcx,QWORD PTR [r13+0x2a70]
  40c6d9:	mov    edx,0x1
  40c6de:	cmp    rcx,0x1
  40c6e2:	jbe    40c719 <__swc_fn_e121059d_000058_8bd8d1d5+0x1f9>
  40c6e4:	cs nop WORD PTR [rax+rax*1+0x0]
  40c6ee:	xchg   ax,ax
  40c6f0:	lea    r8,[rdx+rdx*4]
  40c6f4:	lea    r8,[r13+r8*8+0x268]
  40c6fc:	lea    r9,[rax+rax*4]
  40c700:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40c708:	cmp    QWORD PTR [r8+0x18],r9
  40c70c:	cmovb  rax,rdx
  40c710:	add    rdx,0x1
  40c714:	cmp    rdx,rcx
  40c717:	jb     40c6f0 <__swc_fn_e121059d_000058_8bd8d1d5+0x1d0>
  40c719:	lea    rcx,[rax+rax*4]
  40c71d:	lea    rcx,[r13+rcx*8+0x268]
  40c725:	mov    r8,QWORD PTR [rcx]
  40c728:	mov    r9,QWORD PTR [rcx+0x8]
  40c72c:	mov    r10,QWORD PTR [rcx+0x10]
  40c730:	mov    rcx,r13
  40c733:	mov    rdx,rax
  40c736:	call   40f620 <__swc_fn_e121059d_000056_38b21f11>
  40c73b:	mov    rcx,r13
  40c73e:	mov    rdx,r8
  40c741:	mov    r8,r9
  40c744:	mov    r9,r10
  40c747:	call   407750 <__swc_fn_e121059d_000039_40d1e569>
  40c74c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40c754:	jne    40c6b0 <__swc_fn_e121059d_000058_8bd8d1d5+0x190>
  40c75a:	add    QWORD PTR [r13+0x2a78],0x1
  40c762:	mov    rax,QWORD PTR [r13+0x2a70]
  40c769:	lea    rax,[rax+rax*4]
  40c76d:	lea    rax,[r13+rax*8+0x268]
  40c775:	mov    QWORD PTR [rax],r14
  40c778:	mov    QWORD PTR [rax+0x8],r15
  40c77c:	mov    QWORD PTR [rax+0x10],r12
  40c780:	mov    rcx,QWORD PTR [r13+0x2a78]
  40c787:	mov    QWORD PTR [rax+0x18],rcx
  40c78b:	mov    QWORD PTR [rax+0x20],rdi
  40c78f:	add    QWORD PTR [r13+0x2a68],r12
  40c796:	add    QWORD PTR [r13+0x2a70],0x1
  40c79e:	mov    rcx,r13
  40c7a1:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40c7a6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40c7af:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40c7b8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40c7c1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40c7ca:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40c7d3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40c7dc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40c7e5:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40c7ee:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40c7f7:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40c800:	add    rsp,0x148
  40c807:	pop    rsi
  40c808:	pop    rdi
  40c809:	pop    r15
  40c80b:	pop    r14
  40c80d:	pop    r13
  40c80f:	pop    r12
  40c811:	ret
	...

000000000040c820 <__swc_fn_e121059d_000061_0a7f67d9>:
  40c820:	push   rbx
  40c821:	push   r12
  40c823:	push   r13
  40c825:	push   r14
  40c827:	push   r15
  40c829:	push   rdi
  40c82a:	push   rsi
  40c82b:	sub    rsp,0xf0
  40c832:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40c838:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40c83e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40c844:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40c84a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40c853:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40c85c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40c865:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40c86e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40c877:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40c880:	mov    eax,r8d
  40c883:	mov    rbx,rcx
  40c886:	mov    r12,rdx
  40c889:	mov    QWORD PTR [rsp+0x18],rdx
  40c88e:	mov    ecx,DWORD PTR [r12+0x58]
  40c893:	mov    r13d,ecx
  40c896:	cmp    ecx,0x10
  40c899:	mov    ecx,0x10
  40c89e:	cmovb  r13d,ecx
  40c8a2:	test   r13d,r13d
  40c8a5:	mov    rcx,r13
  40c8a8:	mov    edx,0x8
  40c8ad:	cmove  ecx,edx
  40c8b0:	dec    rcx
  40c8b3:	mov    rdx,0xffffffffffffffff
  40c8ba:	sub    rdx,rcx
  40c8bd:	xor    r14d,r14d
  40c8c0:	mov    r8,rcx
  40c8c3:	not    r8
  40c8c6:	lea    rcx,[rcx+0x58]
  40c8ca:	and    rcx,r8
  40c8cd:	cmp    rdx,0x58
  40c8d1:	cmovae r14,rcx
  40c8d5:	cmp    eax,0xffffffff
  40c8d8:	jne    40c8e1 <__swc_fn_e121059d_000061_0a7f67d9+0xc1>
  40c8da:	mov    r15,QWORD PTR [r12+0x48]
  40c8df:	jmp    40c913 <__swc_fn_e121059d_000061_0a7f67d9+0xf3>
  40c8e1:	test   eax,eax
  40c8e3:	jne    40c8ec <__swc_fn_e121059d_000061_0a7f67d9+0xcc>
  40c8e5:	mov    eax,0x8
  40c8ea:	jmp    40c910 <__swc_fn_e121059d_000061_0a7f67d9+0xf0>
  40c8ec:	cmp    eax,0x8
  40c8ef:	ja     40c8f7 <__swc_fn_e121059d_000061_0a7f67d9+0xd7>
  40c8f1:	shl    rax,0x4
  40c8f5:	jmp    40c910 <__swc_fn_e121059d_000061_0a7f67d9+0xf0>
  40c8f7:	lea    eax,[rax-0x9]
  40c8fa:	mov    ecx,eax
  40c8fc:	shr    ecx,0x2
  40c8ff:	and    eax,0x3
  40c902:	lea    ecx,[rcx+0x7]
  40c905:	lea    ecx,[rcx-0x2]
  40c908:	lea    eax,[rax+0x5]
  40c90b:	shlx   rax,rax,rcx
  40c910:	mov    r15,rax
  40c913:	lea    rax,[r14+r13*1]
  40c917:	mov    rcx,0xffffffffffffffff
  40c91e:	sub    rcx,rax
  40c921:	cmp    r15,rcx
  40c924:	jbe    40c934 <__swc_fn_e121059d_000061_0a7f67d9+0x114>
  40c926:	mov    QWORD PTR [r12+0x40],0x0
  40c92f:	jmp    40cd06 <__swc_fn_e121059d_000061_0a7f67d9+0x4e6>
  40c934:	mov    QWORD PTR [rsp+0x20],r13
  40c939:	lea    r13,[rsp+0x8]
  40c93e:	add    rax,r15
  40c941:	mov    ecx,0x1000
  40c946:	test   ecx,ecx
  40c948:	mov    edx,0x8
  40c94d:	cmove  ecx,edx
  40c950:	dec    rcx
  40c953:	mov    rdx,0xffffffffffffffff
  40c95a:	sub    rdx,rcx
  40c95d:	cmp    rax,rdx
  40c960:	jbe    40c96c <__swc_fn_e121059d_000061_0a7f67d9+0x14c>
  40c962:	mov    QWORD PTR [r13+0x0],0x0
  40c96a:	jmp    40c979 <__swc_fn_e121059d_000061_0a7f67d9+0x159>
  40c96c:	add    rax,rcx
  40c96f:	andn   rax,rcx,rax
  40c974:	mov    QWORD PTR [rsp+0x8],rax
  40c979:	cmp    QWORD PTR [r13+0x0],0x0
  40c97e:	jne    40c98e <__swc_fn_e121059d_000061_0a7f67d9+0x16e>
  40c980:	mov    QWORD PTR [r12+0x40],0x0
  40c989:	jmp    40cd06 <__swc_fn_e121059d_000061_0a7f67d9+0x4e6>
  40c98e:	mov    QWORD PTR [rsp+0x30],r15
  40c993:	xor    r15d,r15d
  40c996:	mov    QWORD PTR [rsp+0x38],0x0
  40c99f:	lea    r12,[rsp+0x10]
  40c9a4:	mov    QWORD PTR [rsp+0x28],r14
  40c9a9:	mov    r14,QWORD PTR [rsp+0x8]
  40c9ae:	mov    QWORD PTR [rsp+0x10],r14
  40c9b3:	cmp    r14,0x10000
  40c9ba:	ja     40c9c1 <__swc_fn_e121059d_000061_0a7f67d9+0x1a1>
  40c9bc:	mov    rax,r14
  40c9bf:	jmp    40ca12 <__swc_fn_e121059d_000061_0a7f67d9+0x1f2>
  40c9c1:	xor    eax,eax
  40c9c3:	lea    rcx,[r14-0x1]
  40c9c7:	lzcnt  rax,rcx
  40c9cc:	mov    ecx,0x3f
  40c9d1:	sub    rcx,rax
  40c9d4:	mov    eax,0x1
  40c9d9:	lea    rcx,[rcx-0x3]
  40c9dd:	shl    rax,cl
  40c9e0:	mov    rcx,rax
  40c9e3:	cmp    rax,0x1000
  40c9ea:	mov    eax,0x1000
  40c9ef:	cmovb  rcx,rax
  40c9f3:	mov    rdx,0xffffffffffffffff
  40c9fa:	sub    rdx,rcx
  40c9fd:	mov    rax,r14
  40ca00:	lea    r8,[r14+rcx*1-0x1]
  40ca05:	neg    rcx
  40ca08:	and    r8,rcx
  40ca0b:	cmp    r14,rdx
  40ca0e:	cmovbe rax,r8
  40ca12:	mov    QWORD PTR [rsp+0x8],rax
  40ca17:	lea    rax,[rip+0x155e2]        # 422000 <__swc_data_base_e121059d>
  40ca1e:	mov    rax,QWORD PTR [rax]
  40ca21:	cmp    rax,0xffffffffffffffff
  40ca25:	je     40ca34 <__swc_fn_e121059d_000061_0a7f67d9+0x214>
  40ca27:	mov    eax,eax
  40ca29:	mov    edi,eax
  40ca2b:	xor    eax,eax
  40ca2d:	call   407000 <pthread_getspecific@plt>
  40ca32:	jmp    40ca36 <__swc_fn_e121059d_000061_0a7f67d9+0x216>
  40ca34:	xor    eax,eax
  40ca36:	test   rax,rax
  40ca39:	jne    40ca48 <__swc_fn_e121059d_000061_0a7f67d9+0x228>
  40ca3b:	call   40bec0 <__swc_fn_e121059d_000031_90860ff2>
  40ca40:	mov    rcx,rax
  40ca43:	call   409c00 <__swc_fn_e121059d_000129_41c3251c>
  40ca48:	test   rax,rax
  40ca4b:	je     40cb3c <__swc_fn_e121059d_000061_0a7f67d9+0x31c>
  40ca51:	cmp    QWORD PTR [rax],rbx
  40ca54:	jne    40cb3c <__swc_fn_e121059d_000061_0a7f67d9+0x31c>
  40ca5a:	cmp    DWORD PTR [rax+0x20],0x0
  40ca5e:	jne    40cb3c <__swc_fn_e121059d_000061_0a7f67d9+0x31c>
  40ca64:	mov    rcx,QWORD PTR [rsp+0x8]
  40ca69:	movabs rdx,0x7fffffffffffffff
  40ca73:	cmp    rcx,rdx
  40ca76:	mov    rdx,0xffffffffffffffff
  40ca7d:	lea    r8,[rcx+rcx*1]
  40ca81:	cmovbe rdx,r8
  40ca85:	mov    r8d,DWORD PTR [rax+0x730]
  40ca8c:	mov    r9d,r8d
  40ca8f:	sub    rdx,rcx
  40ca92:	inc    rdx
  40ca95:	xor    r10d,r10d
  40ca98:	test   r8,r8
  40ca9b:	jbe    40cacb <__swc_fn_e121059d_000061_0a7f67d9+0x2ab>
  40ca9d:	nop    DWORD PTR [rax]
  40caa0:	mov    r11d,r10d
  40caa3:	lea    r11,[r11+r11*4]
  40caa7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40caaf:	sub    r11,rcx
  40cab2:	cmp    r11,rdx
  40cab5:	jae    40cac2 <__swc_fn_e121059d_000061_0a7f67d9+0x2a2>
  40cab7:	mov    r9d,r10d
  40caba:	mov    rdx,r11
  40cabd:	test   r11,r11
  40cac0:	je     40cacb <__swc_fn_e121059d_000061_0a7f67d9+0x2ab>
  40cac2:	add    r10,0x1
  40cac6:	cmp    r10,r8
  40cac9:	jb     40caa0 <__swc_fn_e121059d_000061_0a7f67d9+0x280>
  40cacb:	mov    ecx,DWORD PTR [rax+0x730]
  40cad1:	cmp    r9d,ecx
  40cad4:	jne    40cada <__swc_fn_e121059d_000061_0a7f67d9+0x2ba>
  40cad6:	xor    eax,eax
  40cad8:	jmp    40cb39 <__swc_fn_e121059d_000061_0a7f67d9+0x319>
  40cada:	lea    rcx,[r9+r9*4]
  40cade:	lea    rcx,[rax+rcx*8+0x738]
  40cae6:	vmovups xmm0,XMMWORD PTR [rcx]
  40caea:	mov    rdx,QWORD PTR [rcx+0x10]
  40caee:	sub    DWORD PTR [rax+0x730],0x1
  40caf5:	mov    r8d,DWORD PTR [rax+0x730]
  40cafc:	lea    r8,[r8+r8*4]
  40cb00:	lea    r8,[rax+r8*8+0x738]
  40cb08:	vmovups xmm1,XMMWORD PTR [r8]
  40cb0d:	vmovups XMMWORD PTR [rcx],xmm1
  40cb11:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40cb17:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40cb1c:	mov    rax,QWORD PTR [r8+0x20]
  40cb20:	mov    QWORD PTR [rcx+0x20],rax
  40cb24:	vpshufd xmm1,xmm0,0xee
  40cb29:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40cb2f:	mov    QWORD PTR [rsp+0x10],rdx
  40cb34:	vmovq  rax,xmm0
  40cb39:	mov    r15,rax
  40cb3c:	test   r15,r15
  40cb3f:	jne    40cb57 <__swc_fn_e121059d_000061_0a7f67d9+0x337>
  40cb41:	mov    rcx,rbx
  40cb44:	mov    rdx,QWORD PTR [rsp+0x8]
  40cb49:	mov    r8,r13
  40cb4c:	mov    r9,r12
  40cb4f:	call   40c410 <__swc_fn_e121059d_000055_81f7713d>
  40cb54:	mov    r15,rax
  40cb57:	test   r15,r15
  40cb5a:	je     40cb9b <__swc_fn_e121059d_000061_0a7f67d9+0x37b>
  40cb5c:	cmp    QWORD PTR [r12],r14
  40cb60:	jae    40cb9b <__swc_fn_e121059d_000061_0a7f67d9+0x37b>
  40cb62:	mov    rax,r15
  40cb65:	add    rax,QWORD PTR [r12]
  40cb69:	mov    rdx,r14
  40cb6c:	sub    rdx,QWORD PTR [r12]
  40cb70:	mov    rcx,rax
  40cb73:	call   4072a0 <__swc_fn_e121059d_000003_7ab4792e>
  40cb78:	test   al,al
  40cb7a:	je     40cb83 <__swc_fn_e121059d_000061_0a7f67d9+0x363>
  40cb7c:	mov    QWORD PTR [rsp+0x10],r14
  40cb81:	jmp    40cb9b <__swc_fn_e121059d_000061_0a7f67d9+0x37b>
  40cb83:	mov    rcx,rbx
  40cb86:	mov    rdx,r15
  40cb89:	mov    r8,QWORD PTR [rsp+0x8]
  40cb8e:	mov    r9,QWORD PTR [rsp+0x10]
  40cb93:	call   40c520 <__swc_fn_e121059d_000058_8bd8d1d5>
  40cb98:	xor    r15d,r15d
  40cb9b:	test   r15,r15
  40cb9e:	jne    40cc1a <__swc_fn_e121059d_000061_0a7f67d9+0x3fa>
  40cba0:	cmp    r14,0x10000
  40cba7:	ja     40cbae <__swc_fn_e121059d_000061_0a7f67d9+0x38e>
  40cba9:	mov    rax,r14
  40cbac:	jmp    40cbff <__swc_fn_e121059d_000061_0a7f67d9+0x3df>
  40cbae:	xor    eax,eax
  40cbb0:	lea    rcx,[r14-0x1]
  40cbb4:	lzcnt  rax,rcx
  40cbb9:	mov    ecx,0x3f
  40cbbe:	sub    rcx,rax
  40cbc1:	mov    eax,0x1
  40cbc6:	lea    rcx,[rcx-0x3]
  40cbca:	shl    rax,cl
  40cbcd:	mov    rcx,rax
  40cbd0:	cmp    rax,0x1000
  40cbd7:	mov    eax,0x1000
  40cbdc:	cmovb  rcx,rax
  40cbe0:	mov    rdx,0xffffffffffffffff
  40cbe7:	sub    rdx,rcx
  40cbea:	mov    rax,r14
  40cbed:	lea    r8,[r14+rcx*1-0x1]
  40cbf2:	neg    rcx
  40cbf5:	and    r8,rcx
  40cbf8:	cmp    r14,rdx
  40cbfb:	cmovbe rax,r8
  40cbff:	mov    QWORD PTR [rsp+0x8],rax
  40cc04:	mov    QWORD PTR [rsp+0x10],r14
  40cc09:	mov    rcx,rbx
  40cc0c:	mov    rdx,rax
  40cc0f:	mov    r8,r14
  40cc12:	call   40bf80 <__swc_fn_e121059d_000037_b4982903>
  40cc17:	mov    r15,rax
  40cc1a:	test   r15,r15
  40cc1d:	jne    40cc2b <__swc_fn_e121059d_000061_0a7f67d9+0x40b>
  40cc1f:	mov    r13,QWORD PTR [rsp+0x20]
  40cc24:	mov    rsi,QWORD PTR [rsp+0x38]
  40cc29:	jmp    40cc67 <__swc_fn_e121059d_000061_0a7f67d9+0x447>
  40cc2b:	mov    rax,r15
  40cc2e:	add    rax,QWORD PTR [rsp+0x28]
  40cc33:	mov    r13,QWORD PTR [rsp+0x20]
  40cc38:	test   r13d,r13d
  40cc3b:	mov    rcx,r13
  40cc3e:	mov    edx,0x8
  40cc43:	cmove  ecx,edx
  40cc46:	dec    rcx
  40cc49:	mov    rdx,0xffffffffffffffff
  40cc50:	sub    rdx,rcx
  40cc53:	cmp    rax,rdx
  40cc56:	jbe    40cc5c <__swc_fn_e121059d_000061_0a7f67d9+0x43c>
  40cc58:	xor    eax,eax
  40cc5a:	jmp    40cc64 <__swc_fn_e121059d_000061_0a7f67d9+0x444>
  40cc5c:	add    rax,rcx
  40cc5f:	andn   rax,rcx,rax
  40cc64:	mov    rsi,rax
  40cc67:	mov    rax,QWORD PTR [rsp+0x8]
  40cc6c:	test   r15,r15
  40cc6f:	je     40cc78 <__swc_fn_e121059d_000061_0a7f67d9+0x458>
  40cc71:	mov    rdi,QWORD PTR [rsp+0x18]
  40cc76:	jmp    40cc8a <__swc_fn_e121059d_000061_0a7f67d9+0x46a>
  40cc78:	mov    rdi,QWORD PTR [rsp+0x18]
  40cc7d:	mov    QWORD PTR [rdi+0x40],0x0
  40cc85:	jmp    40cd06 <__swc_fn_e121059d_000061_0a7f67d9+0x4e6>
  40cc8a:	lea    rdx,[rsi-0x58]
  40cc8e:	mov    QWORD PTR [rsi-0x58],r15
  40cc92:	mov    QWORD PTR [rsi-0x50],rax
  40cc96:	mov    rax,QWORD PTR [rsp+0x10]
  40cc9b:	mov    QWORD PTR [rsi-0x48],rax
  40cc9f:	mov    QWORD PTR [rsi-0x40],rsi
  40cca3:	mov    rax,QWORD PTR [rdi+0x48]
  40cca7:	mov    QWORD PTR [rsi-0x38],rax
  40ccab:	mov    rax,QWORD PTR [rsp+0x30]
  40ccb0:	mov    QWORD PTR [rsi-0x30],rax
  40ccb4:	mov    DWORD PTR [rsi-0x10],r13d
  40ccb8:	mov    QWORD PTR [rsi-0x28],0x0
  40ccc0:	mov    QWORD PTR [rsi-0x20],0x0
  40ccc8:	add    r15,QWORD PTR [r12]
  40cccc:	sub    r15,rsi
  40cccf:	mov    QWORD PTR [rsi-0x30],r15
  40ccd3:	mov    rcx,QWORD PTR [rbx+0x250]
  40ccda:	nop    WORD PTR [rax+rax*1+0x0]
  40cce0:	lea    r8,[rcx+r15*1]
  40cce4:	mov    rax,rcx
  40cce7:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40ccf0:	cmp    rax,rcx
  40ccf3:	je     40ccfa <__swc_fn_e121059d_000061_0a7f67d9+0x4da>
  40ccf5:	mov    rcx,rax
  40ccf8:	jmp    40cce0 <__swc_fn_e121059d_000061_0a7f67d9+0x4c0>
  40ccfa:	mov    rcx,rbx
  40ccfd:	call   40f590 <__swc_fn_e121059d_000053_82546d94>
  40cd02:	mov    QWORD PTR [rdi+0x40],rsi
  40cd06:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40cd0c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40cd12:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40cd18:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40cd1e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40cd27:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40cd30:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40cd39:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40cd42:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40cd4b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40cd54:	add    rsp,0xf0
  40cd5b:	pop    rsi
  40cd5c:	pop    rdi
  40cd5d:	pop    r15
  40cd5f:	pop    r14
  40cd61:	pop    r13
  40cd63:	pop    r12
  40cd65:	pop    rbx
  40cd66:	ret
	...

000000000040cd70 <__swc_fn_e121059d_000064_b0d63361>:
  40cd70:	push   rbx
  40cd71:	push   r12
  40cd73:	push   rdi
  40cd74:	push   rsi
  40cd75:	sub    rsp,0xb8
  40cd7c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40cd82:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40cd88:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cd8e:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40cd94:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40cd9a:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cda0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cda6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cdaf:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40cdb8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cdc1:	mov    rbx,rdx
  40cdc4:	mov    r12,rcx
  40cdc7:	cmp    DWORD PTR [rbx+0x58],0x0
  40cdcb:	je     40cde5 <__swc_fn_e121059d_000064_b0d63361+0x75>
  40cdcd:	mov    eax,DWORD PTR [rbx+0x58]
  40cdd0:	sub    eax,0x1
  40cdd3:	test   DWORD PTR [rbx+0x58],eax
  40cdd6:	je     40cde5 <__swc_fn_e121059d_000064_b0d63361+0x75>
  40cdd8:	mov    QWORD PTR [rbx+0x40],0x0
  40cde0:	jmp    40cff7 <__swc_fn_e121059d_000064_b0d63361+0x287>
  40cde5:	cmp    QWORD PTR [rbx+0x48],0x0
  40cdea:	jne    40cdf9 <__swc_fn_e121059d_000064_b0d63361+0x89>
  40cdec:	mov    QWORD PTR [rbx+0x40],0x0
  40cdf4:	jmp    40cff7 <__swc_fn_e121059d_000064_b0d63361+0x287>
  40cdf9:	lea    rax,[rsp+0x8]
  40cdfe:	mov    rcx,QWORD PTR [rbx+0x48]
  40ce02:	cmp    rcx,0x8
  40ce06:	ja     40ce10 <__swc_fn_e121059d_000064_b0d63361+0xa0>
  40ce08:	mov    DWORD PTR [rax],0x0
  40ce0e:	jmp    40ce6b <__swc_fn_e121059d_000064_b0d63361+0xfb>
  40ce10:	cmp    rcx,0x80
  40ce17:	ja     40ce27 <__swc_fn_e121059d_000064_b0d63361+0xb7>
  40ce19:	lea    rcx,[rcx+0xf]
  40ce1d:	shr    rcx,0x4
  40ce21:	mov    DWORD PTR [rsp+0x8],ecx
  40ce25:	jmp    40ce6b <__swc_fn_e121059d_000064_b0d63361+0xfb>
  40ce27:	cmp    rcx,0x10000
  40ce2e:	jbe    40ce38 <__swc_fn_e121059d_000064_b0d63361+0xc8>
  40ce30:	mov    DWORD PTR [rax],0xffffffff
  40ce36:	jmp    40ce6b <__swc_fn_e121059d_000064_b0d63361+0xfb>
  40ce38:	dec    rcx
  40ce3b:	xor    edx,edx
  40ce3d:	lzcnt  rdx,rcx
  40ce42:	mov    r8d,0x3f
  40ce48:	sub    r8d,edx
  40ce4b:	lea    edx,[r8-0x2]
  40ce4f:	shrx   rcx,rcx,rdx
  40ce54:	and    ecx,0x3
  40ce57:	lea    edx,[r8-0x7]
  40ce5b:	lea    edx,[rdx*4+0x0]
  40ce62:	lea    edx,[rdx+0x9]
  40ce65:	add    edx,ecx
  40ce67:	mov    DWORD PTR [rsp+0x8],edx
  40ce6b:	cmp    DWORD PTR [rax],0x0
  40ce6e:	jne    40ce7e <__swc_fn_e121059d_000064_b0d63361+0x10e>
  40ce70:	cmp    DWORD PTR [rbx+0x58],0x8
  40ce74:	jbe    40ce7e <__swc_fn_e121059d_000064_b0d63361+0x10e>
  40ce76:	mov    DWORD PTR [rsp+0x8],0x1
  40ce7e:	cmp    DWORD PTR [rbx+0x58],0x10
  40ce82:	jbe    40cf01 <__swc_fn_e121059d_000064_b0d63361+0x191>
  40ce88:	cmp    DWORD PTR [rbx+0x58],0x40
  40ce8c:	ja     40cf01 <__swc_fn_e121059d_000064_b0d63361+0x191>
  40ce8e:	cmp    DWORD PTR [rax],0xffffffff
  40ce91:	je     40cf01 <__swc_fn_e121059d_000064_b0d63361+0x191>
  40ce93:	mov    ecx,DWORD PTR [rsp+0x8]
  40ce97:	mov    edx,DWORD PTR [rbx+0x58]
  40ce9a:	dec    rdx
  40ce9d:	cmp    ecx,0x2d
  40cea0:	jae    40cef8 <__swc_fn_e121059d_000064_b0d63361+0x188>
  40cea2:	cs nop WORD PTR [rax+rax*1+0x0]
  40ceac:	nop    DWORD PTR [rax+0x0]
  40ceb0:	mov    r8d,ecx
  40ceb3:	test   ecx,ecx
  40ceb5:	jne    40cebf <__swc_fn_e121059d_000064_b0d63361+0x14f>
  40ceb7:	mov    r8d,0x8
  40cebd:	jmp    40ceeb <__swc_fn_e121059d_000064_b0d63361+0x17b>
  40cebf:	cmp    r8d,0x8
  40cec3:	ja     40cecb <__swc_fn_e121059d_000064_b0d63361+0x15b>
  40cec5:	shl    r8,0x4
  40cec9:	jmp    40ceeb <__swc_fn_e121059d_000064_b0d63361+0x17b>
  40cecb:	lea    r8d,[r8-0x9]
  40cecf:	mov    r9d,r8d
  40ced2:	shr    r9d,0x2
  40ced6:	and    r8d,0x3
  40ceda:	lea    r9d,[r9+0x7]
  40cede:	lea    r9d,[r9-0x2]
  40cee2:	lea    r8d,[r8+0x5]
  40cee6:	shlx   r8,r8,r9
  40ceeb:	test   r8,rdx
  40ceee:	je     40cefd <__swc_fn_e121059d_000064_b0d63361+0x18d>
  40cef0:	add    ecx,0x1
  40cef3:	cmp    ecx,0x2d
  40cef6:	jb     40ceb0 <__swc_fn_e121059d_000064_b0d63361+0x140>
  40cef8:	mov    ecx,0xffffffff
  40cefd:	mov    DWORD PTR [rsp+0x8],ecx
  40cf01:	mov    ecx,DWORD PTR [rsp+0x8]
  40cf05:	cmp    ecx,0xffffffff
  40cf08:	je     40cf10 <__swc_fn_e121059d_000064_b0d63361+0x1a0>
  40cf0a:	cmp    DWORD PTR [rbx+0x58],0x40
  40cf0e:	jbe    40cf23 <__swc_fn_e121059d_000064_b0d63361+0x1b3>
  40cf10:	mov    rcx,r12
  40cf13:	mov    rdx,rbx
  40cf16:	mov    r8d,DWORD PTR [rax]
  40cf19:	call   40c820 <__swc_fn_e121059d_000061_0a7f67d9>
  40cf1e:	jmp    40cff7 <__swc_fn_e121059d_000064_b0d63361+0x287>
  40cf23:	lea    rax,[rip+0x150d6]        # 422000 <__swc_data_base_e121059d>
  40cf2a:	mov    rax,QWORD PTR [rax]
  40cf2d:	cmp    rax,0xffffffffffffffff
  40cf31:	je     40cf40 <__swc_fn_e121059d_000064_b0d63361+0x1d0>
  40cf33:	mov    eax,eax
  40cf35:	mov    edi,eax
  40cf37:	xor    eax,eax
  40cf39:	call   407000 <pthread_getspecific@plt>
  40cf3e:	jmp    40cf42 <__swc_fn_e121059d_000064_b0d63361+0x1d2>
  40cf40:	xor    eax,eax
  40cf42:	test   rax,rax
  40cf45:	jne    40cf54 <__swc_fn_e121059d_000064_b0d63361+0x1e4>
  40cf47:	call   40bec0 <__swc_fn_e121059d_000031_90860ff2>
  40cf4c:	mov    rcx,rax
  40cf4f:	call   409c00 <__swc_fn_e121059d_000129_41c3251c>
  40cf54:	test   rax,rax
  40cf57:	je     40cf64 <__swc_fn_e121059d_000064_b0d63361+0x1f4>
  40cf59:	cmp    QWORD PTR [rax],r12
  40cf5c:	jne    40cf64 <__swc_fn_e121059d_000064_b0d63361+0x1f4>
  40cf5e:	cmp    DWORD PTR [rax+0x20],0x0
  40cf62:	je     40cf6f <__swc_fn_e121059d_000064_b0d63361+0x1ff>
  40cf64:	mov    rcx,r12
  40cf67:	mov    rdx,rax
  40cf6a:	call   40f1d0 <__swc_fn_e121059d_000041_414cc921>
  40cf6f:	test   rax,rax
  40cf72:	jne    40cf7e <__swc_fn_e121059d_000064_b0d63361+0x20e>
  40cf74:	mov    QWORD PTR [rbx+0x40],0x0
  40cf7c:	jmp    40cff7 <__swc_fn_e121059d_000064_b0d63361+0x287>
  40cf7e:	lea    r8,[rsp+0xc]
  40cf83:	mov    ecx,DWORD PTR [rsp+0x8]
  40cf87:	mov    DWORD PTR [rsp+0xc],ecx
  40cf8b:	mov    ecx,DWORD PTR [r8]
  40cf8e:	lea    rcx,[rcx+rcx*4]
  40cf92:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40cf97:	test   rcx,rcx
  40cf9a:	je     40cfd3 <__swc_fn_e121059d_000064_b0d63361+0x263>
  40cf9c:	mov    rdx,QWORD PTR [rcx]
  40cf9f:	test   rdx,rdx
  40cfa2:	je     40cfb0 <__swc_fn_e121059d_000064_b0d63361+0x240>
  40cfa4:	mov    r9,QWORD PTR [rdx]
  40cfa7:	mov    QWORD PTR [rcx],r9
  40cfaa:	add    DWORD PTR [rcx+0x28],0x1
  40cfae:	jmp    40cfce <__swc_fn_e121059d_000064_b0d63361+0x25e>
  40cfb0:	mov    rdx,QWORD PTR [rcx+0x18]
  40cfb4:	cmp    QWORD PTR [rcx+0x20],rdx
  40cfb8:	jae    40cfcc <__swc_fn_e121059d_000064_b0d63361+0x25c>
  40cfba:	mov    rdx,QWORD PTR [rcx+0x20]
  40cfbe:	mov    r9d,DWORD PTR [rcx+0x2c]
  40cfc2:	add    QWORD PTR [rcx+0x20],r9
  40cfc6:	add    DWORD PTR [rcx+0x28],0x1
  40cfca:	jmp    40cfce <__swc_fn_e121059d_000064_b0d63361+0x25e>
  40cfcc:	xor    edx,edx
  40cfce:	test   rdx,rdx
  40cfd1:	jne    40cfe4 <__swc_fn_e121059d_000064_b0d63361+0x274>
  40cfd3:	mov    rcx,r12
  40cfd6:	mov    rdx,rax
  40cfd9:	mov    r8d,DWORD PTR [r8]
  40cfdc:	call   40f340 <__swc_fn_e121059d_000050_ab8077df>
  40cfe1:	mov    rdx,rax
  40cfe4:	test   rdx,rdx
  40cfe7:	jne    40cff3 <__swc_fn_e121059d_000064_b0d63361+0x283>
  40cfe9:	mov    QWORD PTR [rbx+0x40],0x0
  40cff1:	jmp    40cff7 <__swc_fn_e121059d_000064_b0d63361+0x287>
  40cff3:	mov    QWORD PTR [rbx+0x40],rdx
  40cff7:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40cffd:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d003:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d009:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d00f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d015:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d01b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d021:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d02a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d033:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d03c:	add    rsp,0xb8
  40d043:	pop    rsi
  40d044:	pop    rdi
  40d045:	pop    r12
  40d047:	pop    rbx
  40d048:	ret
  40d049:	add    BYTE PTR [rax],al
  40d04b:	add    BYTE PTR [rax],al
  40d04d:	add    BYTE PTR [rax],al
	...

000000000040d050 <__swc_fn_e121059d_000067_94a51053>:
  40d050:	ret
	...

000000000040d060 <__swc_fn_e121059d_000070_3181d86c>:
  40d060:	push   r12
  40d062:	push   r13
  40d064:	push   r14
  40d066:	push   rdi
  40d067:	push   rsi
  40d068:	sub    rsp,0x1a0
  40d06f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40d078:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40d081:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40d08a:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40d093:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40d09c:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40d0a5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40d0ae:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40d0b7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40d0c0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40d0c9:	mov    r12,rdx
  40d0cc:	mov    r13,rcx
  40d0cf:	mov    rax,QWORD PTR [r12+0x48]
  40d0d4:	mov    ecx,DWORD PTR [r12+0x58]
  40d0d9:	lea    rdx,[rax-0x1]
  40d0dd:	cmp    rdx,0x10000
  40d0e4:	jae    40d1de <__swc_fn_e121059d_000070_3181d86c+0x17e>
  40d0ea:	cmp    rax,0x8
  40d0ee:	ja     40d0f5 <__swc_fn_e121059d_000070_3181d86c+0x95>
  40d0f0:	xor    r14d,r14d
  40d0f3:	jmp    40d147 <__swc_fn_e121059d_000070_3181d86c+0xe7>
  40d0f5:	cmp    rax,0x80
  40d0fc:	ja     40d108 <__swc_fn_e121059d_000070_3181d86c+0xa8>
  40d0fe:	lea    r14,[rax+0xf]
  40d102:	shr    r14,0x4
  40d106:	jmp    40d147 <__swc_fn_e121059d_000070_3181d86c+0xe7>
  40d108:	cmp    rax,0x10000
  40d10f:	jbe    40d119 <__swc_fn_e121059d_000070_3181d86c+0xb9>
  40d111:	mov    r14d,0xffffffff
  40d117:	jmp    40d147 <__swc_fn_e121059d_000070_3181d86c+0xe7>
  40d119:	xor    eax,eax
  40d11b:	lzcnt  rax,rdx
  40d120:	mov    r8d,0x3f
  40d126:	sub    r8d,eax
  40d129:	lea    eax,[r8-0x2]
  40d12d:	shrx   rax,rdx,rax
  40d132:	and    eax,0x3
  40d135:	lea    edx,[r8-0x7]
  40d139:	lea    edx,[rdx*4+0x0]
  40d140:	lea    edx,[rdx+0x9]
  40d143:	lea    r14d,[rdx+rax*1]
  40d147:	cmp    ecx,0x8
  40d14a:	jbe    40d163 <__swc_fn_e121059d_000070_3181d86c+0x103>
  40d14c:	cmp    ecx,0x10
  40d14f:	jne    40d1de <__swc_fn_e121059d_000070_3181d86c+0x17e>
  40d155:	test   r14d,r14d
  40d158:	mov    eax,0x1
  40d15d:	cmove  r14d,eax
  40d161:	jmp    40d16a <__swc_fn_e121059d_000070_3181d86c+0x10a>
  40d163:	lea    eax,[rcx-0x1]
  40d166:	test   eax,ecx
  40d168:	jne    40d1de <__swc_fn_e121059d_000070_3181d86c+0x17e>
  40d16a:	lea    rax,[rip+0x14e8f]        # 422000 <__swc_data_base_e121059d>
  40d171:	mov    rax,QWORD PTR [rax]
  40d174:	cmp    rax,0xffffffffffffffff
  40d178:	je     40d187 <__swc_fn_e121059d_000070_3181d86c+0x127>
  40d17a:	mov    eax,eax
  40d17c:	mov    edi,eax
  40d17e:	xor    eax,eax
  40d180:	call   407000 <pthread_getspecific@plt>
  40d185:	jmp    40d189 <__swc_fn_e121059d_000070_3181d86c+0x129>
  40d187:	xor    eax,eax
  40d189:	test   rax,rax
  40d18c:	je     40d1de <__swc_fn_e121059d_000070_3181d86c+0x17e>
  40d18e:	cmp    QWORD PTR [rax],r13
  40d191:	jne    40d1de <__swc_fn_e121059d_000070_3181d86c+0x17e>
  40d193:	lea    rcx,[r14+r14*4]
  40d197:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40d19c:	test   rax,rax
  40d19f:	je     40d1de <__swc_fn_e121059d_000070_3181d86c+0x17e>
  40d1a1:	mov    rcx,QWORD PTR [rax]
  40d1a4:	test   rcx,rcx
  40d1a7:	je     40d1b5 <__swc_fn_e121059d_000070_3181d86c+0x155>
  40d1a9:	mov    rdx,QWORD PTR [rcx]
  40d1ac:	mov    QWORD PTR [rax],rdx
  40d1af:	add    DWORD PTR [rax+0x28],0x1
  40d1b3:	jmp    40d1d2 <__swc_fn_e121059d_000070_3181d86c+0x172>
  40d1b5:	mov    rcx,QWORD PTR [rax+0x18]
  40d1b9:	cmp    QWORD PTR [rax+0x20],rcx
  40d1bd:	jae    40d1d0 <__swc_fn_e121059d_000070_3181d86c+0x170>
  40d1bf:	mov    rcx,QWORD PTR [rax+0x20]
  40d1c3:	mov    edx,DWORD PTR [rax+0x2c]
  40d1c6:	add    QWORD PTR [rax+0x20],rdx
  40d1ca:	add    DWORD PTR [rax+0x28],0x1
  40d1ce:	jmp    40d1d2 <__swc_fn_e121059d_000070_3181d86c+0x172>
  40d1d0:	xor    ecx,ecx
  40d1d2:	test   rcx,rcx
  40d1d5:	je     40d1de <__swc_fn_e121059d_000070_3181d86c+0x17e>
  40d1d7:	mov    QWORD PTR [r12+0x40],rcx
  40d1dc:	jmp    40d1e9 <__swc_fn_e121059d_000070_3181d86c+0x189>
  40d1de:	mov    rcx,r13
  40d1e1:	mov    rdx,r12
  40d1e4:	call   40fdc0 <__swc_fn_e121059d_000071_0d1ef36f>
  40d1e9:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40d1f2:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40d1fb:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40d204:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40d20d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40d216:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40d21f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40d228:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40d231:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40d23a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40d243:	add    rsp,0x1a0
  40d24a:	pop    rsi
  40d24b:	pop    rdi
  40d24c:	pop    r14
  40d24e:	pop    r13
  40d250:	pop    r12
  40d252:	ret
	...

000000000040d260 <__swc_fn_e121059d_000073_c6c71bf7>:
  40d260:	push   r12
  40d262:	push   r13
  40d264:	push   r14
  40d266:	push   r15
  40d268:	push   rdi
  40d269:	push   rsi
  40d26a:	sub    rsp,0x188
  40d271:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40d27a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40d283:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40d28c:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40d295:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40d29e:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40d2a7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40d2b0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40d2b9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40d2c2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40d2cb:	mov    r12,rdx
  40d2ce:	mov    r13,rcx
  40d2d1:	mov    r14,QWORD PTR [r12+0x40]
  40d2d6:	lea    rax,[rip+0x16d93]        # 424070 <__swc_bss_base_e121059d+0x30>
  40d2dd:	mov    rcx,r14
  40d2e0:	sub    rcx,QWORD PTR [rax+0x8]
  40d2e4:	mov    rax,QWORD PTR [rip+0x16d95]        # 424080 <__swc_bss_base_e121059d+0x40>
  40d2eb:	cmp    rcx,rax
  40d2ee:	jae    40d31a <__swc_fn_e121059d_000073_c6c71bf7+0xba>
  40d2f0:	mov    rax,r14
  40d2f3:	and    rax,0xffffffffffc00000
  40d2fa:	mov    rcx,r14
  40d2fd:	shr    rcx,0x10
  40d301:	and    ecx,0x3f
  40d304:	mov    edx,DWORD PTR [rax+0x28]
  40d307:	shrx   ecx,ecx,edx
  40d30c:	shl    rcx,0x4
  40d310:	lea    r15,[rax+rcx*8+0x80]
  40d318:	jmp    40d325 <__swc_fn_e121059d_000073_c6c71bf7+0xc5>
  40d31a:	mov    rcx,r14
  40d31d:	call   40bdf0 <__swc_fn_e121059d_000022_3a2e2048>
  40d322:	mov    r15,rax
  40d325:	test   r15,r15
  40d328:	je     40d3cf <__swc_fn_e121059d_000073_c6c71bf7+0x16f>
  40d32e:	lea    rax,[rip+0x14ccb]        # 422000 <__swc_data_base_e121059d>
  40d335:	mov    rax,QWORD PTR [rax]
  40d338:	cmp    rax,0xffffffffffffffff
  40d33c:	je     40d34b <__swc_fn_e121059d_000073_c6c71bf7+0xeb>
  40d33e:	mov    eax,eax
  40d340:	mov    edi,eax
  40d342:	xor    eax,eax
  40d344:	call   407000 <pthread_getspecific@plt>
  40d349:	jmp    40d34d <__swc_fn_e121059d_000073_c6c71bf7+0xed>
  40d34b:	xor    eax,eax
  40d34d:	mov    rcx,QWORD PTR [r15+0x40]
  40d351:	cmp    rcx,rax
  40d354:	jne    40d3b4 <__swc_fn_e121059d_000073_c6c71bf7+0x154>
  40d356:	test   rax,rax
  40d359:	je     40d3cf <__swc_fn_e121059d_000073_c6c71bf7+0x16f>
  40d35b:	mov    ecx,DWORD PTR [r15+0x6c]
  40d35f:	test   ecx,ecx
  40d361:	je     40d381 <__swc_fn_e121059d_000073_c6c71bf7+0x121>
  40d363:	mov    rcx,r13
  40d366:	mov    rdx,rax
  40d369:	mov    r8,r15
  40d36c:	mov    QWORD PTR [rsp+0xd8],rax
  40d374:	call   40f2d0 <__swc_fn_e121059d_000047_bc5ec610>
  40d379:	mov    rax,QWORD PTR [rsp+0xd8]
  40d381:	mov    rcx,QWORD PTR [r15]
  40d384:	mov    QWORD PTR [r14],rcx
  40d387:	mov    QWORD PTR [r15],r14
  40d38a:	sub    DWORD PTR [r15+0x28],0x1
  40d38f:	jne    40d3c4 <__swc_fn_e121059d_000073_c6c71bf7+0x164>
  40d391:	movzx  ecx,BYTE PTR [r15+0x39]
  40d396:	lea    rcx,[rcx+rcx*4]
  40d39a:	lea    rcx,[rax+rcx*8+0x28]
  40d39f:	cmp    QWORD PTR [rcx],r15
  40d3a2:	je     40d3c4 <__swc_fn_e121059d_000073_c6c71bf7+0x164>
  40d3a4:	mov    rcx,r13
  40d3a7:	mov    rdx,rax
  40d3aa:	mov    r8,r15
  40d3ad:	call   407d80 <__swc_fn_e121059d_000051_f7021588>
  40d3b2:	jmp    40d3c4 <__swc_fn_e121059d_000073_c6c71bf7+0x164>
  40d3b4:	test   rcx,rcx
  40d3b7:	je     40d3cf <__swc_fn_e121059d_000073_c6c71bf7+0x16f>
  40d3b9:	mov    rcx,r15
  40d3bc:	mov    rdx,r14
  40d3bf:	call   40ba30 <__swc_fn_e121059d_000010_395bb04b>
  40d3c4:	mov    QWORD PTR [r12+0x40],0x0
  40d3cd:	jmp    40d3da <__swc_fn_e121059d_000073_c6c71bf7+0x17a>
  40d3cf:	mov    rcx,r13
  40d3d2:	mov    rdx,r12
  40d3d5:	call   40fde0 <__swc_fn_e121059d_000074_518516c2>
  40d3da:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40d3e3:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40d3ec:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40d3f5:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40d3fe:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40d407:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40d410:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40d419:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40d422:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40d42b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40d434:	add    rsp,0x188
  40d43b:	pop    rsi
  40d43c:	pop    rdi
  40d43d:	pop    r15
  40d43f:	pop    r14
  40d441:	pop    r13
  40d443:	pop    r12
  40d445:	ret
	...

000000000040d450 <__swc_fn_e121059d_000076_9f0c6acf>:
  40d450:	sub    rsp,0x8
  40d454:	mov    rax,rdx
  40d457:	mov    rdx,QWORD PTR [rax+0x40]
  40d45b:	mov    r8,rax
  40d45e:	call   40d050 <__swc_fn_e121059d_000067_94a51053>
  40d463:	add    rsp,0x8
  40d467:	ret
	...

000000000040d470 <__swc_fn_e121059d_000079_34776ded>:
  40d470:	push   rsi
  40d471:	push   rdi
  40d472:	sub    rsp,0x8
  40d476:	cmp    rcx,0xffffffffffffffef
  40d47a:	ja     40d4a0 <__swc_fn_e121059d_000079_34776ded+0x30>
  40d47c:	xor    esi,esi
  40d47e:	lea    rax,[rcx+0x100f]
  40d485:	and    rax,0xfffffffffffff000
  40d48c:	lea    rcx,[rcx+0x10]
  40d490:	cmp    rcx,0xfffffffffffff000
  40d497:	cmovbe rsi,rax
  40d49b:	test   rsi,rsi
  40d49e:	jne    40d4a9 <__swc_fn_e121059d_000079_34776ded+0x39>
  40d4a0:	xor    eax,eax
  40d4a2:	add    rsp,0x8
  40d4a6:	pop    rdi
  40d4a7:	pop    rsi
  40d4a8:	ret
  40d4a9:	mov    rcx,rsi
  40d4ac:	call   410a10 <__swc_fn_e121059d_000110_8d425bd3>
  40d4b1:	mov    rdi,rax
  40d4b4:	test   rax,rax
  40d4b7:	jne    40d4c2 <__swc_fn_e121059d_000079_34776ded+0x52>
  40d4b9:	xor    eax,eax
  40d4bb:	add    rsp,0x8
  40d4bf:	pop    rdi
  40d4c0:	pop    rsi
  40d4c1:	ret
  40d4c2:	mov    rcx,rdi
  40d4c5:	mov    rdx,rsi
  40d4c8:	call   40daa0 <__swc_fn_e121059d_000112_b25e3a45>
  40d4cd:	test   al,al
  40d4cf:	jne    40d4e5 <__swc_fn_e121059d_000079_34776ded+0x75>
  40d4d1:	mov    rcx,rdi
  40d4d4:	mov    rdx,rsi
  40d4d7:	call   4098a0 <__swc_fn_e121059d_000114_49b378a9>
  40d4dc:	xor    eax,eax
  40d4de:	add    rsp,0x8
  40d4e2:	pop    rdi
  40d4e3:	pop    rsi
  40d4e4:	ret
  40d4e5:	mov    QWORD PTR [rdi],rsi
  40d4e8:	mov    QWORD PTR [rdi+0x8],0x0
  40d4f0:	lea    rax,[rdi+0x10]
  40d4f4:	add    rsp,0x8
  40d4f8:	pop    rdi
  40d4f9:	pop    rsi
  40d4fa:	ret
  40d4fb:	add    BYTE PTR [rax],al
  40d4fd:	add    BYTE PTR [rax],al
	...

000000000040d500 <__swc_fn_e121059d_000082_754dcd57>:
  40d500:	sub    rsp,0x8
  40d504:	cmp    BYTE PTR [rcx+0x2c],0x10
  40d508:	jne    40d513 <__swc_fn_e121059d_000082_754dcd57+0x13>
  40d50a:	test   DWORD PTR [rcx+0x28],0x80
  40d511:	je     40d51b <__swc_fn_e121059d_000082_754dcd57+0x1b>
  40d513:	mov    rax,rcx
  40d516:	add    rsp,0x8
  40d51a:	ret
  40d51b:	mov    rcx,QWORD PTR [rcx+0x40]
  40d51f:	call   40d500 <__swc_fn_e121059d_000082_754dcd57>
  40d524:	add    rsp,0x8
  40d528:	ret
	...

000000000040d540 <__swc_fn_e121059d_000085_1edf7c76>:
  40d540:	push   rsi
  40d541:	push   rdi
  40d542:	push   r12
  40d544:	push   r13
  40d546:	sub    rsp,0x8
  40d54a:	mov    rsi,rdx
  40d54d:	mov    rdi,rcx
  40d550:	xor    r8d,r8d
  40d553:	call   4085a0 <__swc_fn_e121059d_000090_a2d50c23>
  40d558:	test   al,al
  40d55a:	je     40d56c <__swc_fn_e121059d_000085_1edf7c76+0x2c>
  40d55c:	mov    eax,0x1
  40d561:	add    rsp,0x8
  40d565:	pop    r13
  40d567:	pop    r12
  40d569:	pop    rdi
  40d56a:	pop    rsi
  40d56b:	ret
  40d56c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40d571:	je     40d580 <__swc_fn_e121059d_000085_1edf7c76+0x40>
  40d573:	xor    eax,eax
  40d575:	add    rsp,0x8
  40d579:	pop    r13
  40d57b:	pop    r12
  40d57d:	pop    rdi
  40d57e:	pop    rsi
  40d57f:	ret
  40d580:	mov    r12,QWORD PTR [rsi+0x98]
  40d587:	mov    rax,QWORD PTR [rsi+0xa0]
  40d58e:	mov    rsi,rax
  40d591:	xor    r13d,r13d
  40d594:	test   rsi,rsi
  40d597:	je     40d5f4 <__swc_fn_e121059d_000085_1edf7c76+0xb4>
  40d599:	cs nop WORD PTR [rax+rax*1+0x0]
  40d5a3:	cs nop WORD PTR [rax+rax*1+0x0]
  40d5ad:	nop    DWORD PTR [rax]
  40d5b0:	lea    rax,[r13*8+0x0]
  40d5b8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40d5bd:	mov    rcx,rax
  40d5c0:	call   40d500 <__swc_fn_e121059d_000082_754dcd57>
  40d5c5:	cmp    BYTE PTR [rax+0x2c],0xe
  40d5c9:	jne    40d5ea <__swc_fn_e121059d_000085_1edf7c76+0xaa>
  40d5cb:	mov    rcx,rdi
  40d5ce:	mov    rdx,rax
  40d5d1:	call   40d540 <__swc_fn_e121059d_000085_1edf7c76>
  40d5d6:	test   al,al
  40d5d8:	je     40d5ea <__swc_fn_e121059d_000085_1edf7c76+0xaa>
  40d5da:	mov    eax,0x1
  40d5df:	add    rsp,0x8
  40d5e3:	pop    r13
  40d5e5:	pop    r12
  40d5e7:	pop    rdi
  40d5e8:	pop    rsi
  40d5e9:	ret
  40d5ea:	add    r13,0x1
  40d5ee:	sub    rsi,0x1
  40d5f2:	jne    40d5b0 <__swc_fn_e121059d_000085_1edf7c76+0x70>
  40d5f4:	xor    eax,eax
  40d5f6:	add    rsp,0x8
  40d5fa:	pop    r13
  40d5fc:	pop    r12
  40d5fe:	pop    rdi
  40d5ff:	pop    rsi
  40d600:	ret
	...

000000000040d610 <__swc_fn_e121059d_000088_fcb34f6a>:
  40d610:	sub    rsp,0x18
  40d614:	vxorps xmm0,xmm0,xmm0
  40d618:	vmovdqu XMMWORD PTR [rsp],xmm0
  40d61d:	call   40fff0 <__swc_fn_e121059d_000089_386582f3>
  40d622:	add    rsp,0x18
  40d626:	ret
	...

000000000040d630 <__swc_fn_e121059d_000091_3d2f5a0d>:
  40d630:	sub    rsp,0x8
  40d634:	mov    rcx,QWORD PTR [rip+0x19705]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d63b:	test   rcx,rcx
  40d63e:	jne    40d650 <__swc_fn_e121059d_000091_3d2f5a0d+0x20>
  40d640:	call   40ea10 <__swc_fn_e121059d_000166_cf398896>
  40d645:	lea    rcx,[rax+0x1]
  40d649:	mov    QWORD PTR [rip+0x196f0],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d650:	dec    rcx
  40d653:	call   40b6c0 <__swc_fn_e121059d_000168_fce60b2b>
  40d658:	mov    rax,QWORD PTR [rax+0xc0]
  40d65f:	and    eax,0x1
  40d662:	setne  al
  40d665:	add    rsp,0x8
  40d669:	ret
	...

000000000040d680 <__swc_fn_e121059d_000094_14db3cf9>:
  40d680:	push   rbx
  40d681:	push   rsi
  40d682:	push   rdi
  40d683:	push   r12
  40d685:	sub    rsp,0x28
  40d689:	mov    rbx,rcx
  40d68c:	call   408900 <__swc_fn_e121059d_000093_f8c16535>
  40d691:	mov    rcx,QWORD PTR [rip+0x196a8]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d698:	test   rcx,rcx
  40d69b:	jne    40d6ad <__swc_fn_e121059d_000094_14db3cf9+0x2d>
  40d69d:	call   40ea10 <__swc_fn_e121059d_000166_cf398896>
  40d6a2:	lea    rcx,[rax+0x1]
  40d6a6:	mov    QWORD PTR [rip+0x19693],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d6ad:	dec    rcx
  40d6b0:	call   40b6c0 <__swc_fn_e121059d_000168_fce60b2b>
  40d6b5:	mov    rsi,rax
  40d6b8:	lea    rcx,[rsp+0x8]
  40d6bd:	call   410430 <__swc_fn_e121059d_000092_8252f8c0>
  40d6c2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40d6c9:	mov    r12,QWORD PTR [rsi+0xbe8]
  40d6d0:	lea    rcx,[rsi+0x10]
  40d6d4:	call   411580 <__swc_fn_e121059d_000158_232ffa22>
  40d6d9:	mov    rcx,rsi
  40d6dc:	call   4105a0 <__swc_fn_e121059d_000101_eab3874f>
  40d6e1:	vxorps xmm0,xmm0,xmm0
  40d6e5:	xor    eax,eax
  40d6e7:	cs nop WORD PTR [rax+rax*1+0x0]
  40d6f1:	cs nop WORD PTR [rax+rax*1+0x0]
  40d6fb:	nop    DWORD PTR [rax+rax*1+0x0]
  40d700:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40d705:	add    rax,0x10
  40d709:	cmp    rax,0xbf0
  40d710:	jne    40d700 <__swc_fn_e121059d_000094_14db3cf9+0x80>
  40d712:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40d718:	vmovups XMMWORD PTR [rsi],xmm0
  40d71c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40d722:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40d72a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40d731:	mov    QWORD PTR [rsi+0xbe8],r12
  40d738:	mov    rcx,QWORD PTR [rip+0x19601]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d73f:	test   rcx,rcx
  40d742:	jne    40d754 <__swc_fn_e121059d_000094_14db3cf9+0xd4>
  40d744:	call   40ea10 <__swc_fn_e121059d_000166_cf398896>
  40d749:	lea    rcx,[rax+0x1]
  40d74d:	mov    QWORD PTR [rip+0x195ec],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d754:	dec    rcx
  40d757:	call   40b6c0 <__swc_fn_e121059d_000168_fce60b2b>
  40d75c:	mov    rsi,rax
  40d75f:	mov    QWORD PTR [rsi+0xc0],rbx
  40d766:	and    ebx,0x1
  40d769:	jne    40d76d <__swc_fn_e121059d_000094_14db3cf9+0xed>
  40d76b:	xor    eax,eax
  40d76d:	test   rbx,rbx
  40d770:	sete   al
  40d773:	xor    cl,cl
  40d775:	xor    dl,dl
  40d777:	xor    r8b,r8b
  40d77a:	xor    r9b,r9b
  40d77d:	xor    r10b,r10b
  40d780:	mov    r11,rax
  40d783:	call   40fdf0 <__swc_fn_e121059d_000077_8b8614a7>
  40d788:	lea    rbx,[rsp+0x18]
  40d78d:	mov    rcx,rbx
  40d790:	call   410430 <__swc_fn_e121059d_000092_8252f8c0>
  40d795:	lea    rcx,[rsi+0x10]
  40d799:	mov    edx,0x400000
  40d79e:	mov    r8,rbx
  40d7a1:	call   40e750 <__swc_fn_e121059d_000160_d8afac28>
  40d7a6:	lea    rcx,[rsi+0x68]
  40d7aa:	mov    edx,0x4000
  40d7af:	mov    r8,rbx
  40d7b2:	call   40e750 <__swc_fn_e121059d_000160_d8afac28>
  40d7b7:	add    rsp,0x28
  40d7bb:	pop    r12
  40d7bd:	pop    rdi
  40d7be:	pop    rsi
  40d7bf:	pop    rbx
  40d7c0:	ret
	...

000000000040d7d0 <__swc_fn_e121059d_000097_4c97e0db>:
  40d7d0:	push   rbx
  40d7d1:	push   rsi
  40d7d2:	sub    rsp,0x18
  40d7d6:	mov    rbx,rcx
  40d7d9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40d7de:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d7e4:	mov    rsi,QWORD PTR [rbx+0x70]
  40d7e8:	lea    rcx,[rcx+0x18]
  40d7ec:	call   411580 <__swc_fn_e121059d_000158_232ffa22>
  40d7f1:	lea    rcx,[rsp+0x8]
  40d7f6:	mov    rdx,rbx
  40d7f9:	mov    r8d,0x78
  40d7ff:	call   408960 <__swc_fn_e121059d_000096_ad982b35>
  40d804:	mov    rax,rsi
  40d807:	add    rsp,0x18
  40d80b:	pop    rsi
  40d80c:	pop    rbx
  40d80d:	ret
	...

000000000040d810 <__swc_fn_e121059d_000100_3ed08774>:
  40d810:	push   rsi
  40d811:	push   rdi
  40d812:	sub    rsp,0x8
  40d816:	cmp    QWORD PTR [rcx],0x0
  40d81a:	jne    40d823 <__swc_fn_e121059d_000100_3ed08774+0x13>
  40d81c:	add    rsp,0x8
  40d820:	pop    rdi
  40d821:	pop    rsi
  40d822:	ret
  40d823:	mov    rsi,QWORD PTR [rcx]
  40d826:	mov    rax,QWORD PTR [rcx+0x8]
  40d82a:	test   rax,rax
  40d82d:	je     40d843 <__swc_fn_e121059d_000100_3ed08774+0x33>
  40d82f:	test   DWORD PTR [rax+0x28],0x400000
  40d836:	je     40d843 <__swc_fn_e121059d_000100_3ed08774+0x33>
  40d838:	mov    rcx,QWORD PTR [rax+0x30]
  40d83c:	test   rcx,rcx
  40d83f:	cmovne rax,rcx
  40d843:	lea    rdx,[rip+0x5986]        # 4131d0 <__swc_rdata_base_e121059d+0xc0>
  40d84a:	lea    rcx,[rip+0x5a67]        # 4132b8 <__swc_rdata_base_e121059d+0x1a8>
  40d851:	mov    r8,rax
  40d854:	xor    r9d,r9d
  40d857:	xor    al,al
  40d859:	mov    r10,rax
  40d85c:	xor    r11d,r11d
  40d85f:	call   40d610 <__swc_fn_e121059d_000088_fcb34f6a>
  40d864:	test   rax,rax
  40d867:	je     40d877 <__swc_fn_e121059d_000100_3ed08774+0x67>
  40d869:	mov    rdi,QWORD PTR [rax+0x48]
  40d86d:	test   rdi,rdi
  40d870:	je     40d877 <__swc_fn_e121059d_000100_3ed08774+0x67>
  40d872:	mov    rcx,rsi
  40d875:	call   rdi
  40d877:	add    rsp,0x8
  40d87b:	pop    rdi
  40d87c:	pop    rsi
  40d87d:	ret
	...

000000000040d880 <__swc_fn_e121059d_000103_67100064>:
  40d880:	push   rbx
  40d881:	push   rsi
  40d882:	push   rdi
  40d883:	sub    rsp,0x20
  40d887:	mov    rbx,rdx
  40d88a:	mov    rsi,rcx
  40d88d:	mov    rcx,QWORD PTR [rip+0x194ac]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d894:	test   rcx,rcx
  40d897:	jne    40d8a9 <__swc_fn_e121059d_000103_67100064+0x29>
  40d899:	call   40ea10 <__swc_fn_e121059d_000166_cf398896>
  40d89e:	lea    rcx,[rax+0x1]
  40d8a2:	mov    QWORD PTR [rip+0x19497],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40d8a9:	dec    rcx
  40d8ac:	call   40b6c0 <__swc_fn_e121059d_000168_fce60b2b>
  40d8b1:	mov    rdi,rax
  40d8b4:	mov    rax,QWORD PTR [rdi+0xbd0]
  40d8bb:	xor    ecx,ecx
  40d8bd:	test   rax,rax
  40d8c0:	je     40d8c5 <__swc_fn_e121059d_000103_67100064+0x45>
  40d8c2:	mov    rcx,QWORD PTR [rax]
  40d8c5:	call   40eb40 <__swc_fn_e121059d_000175_176517f9>
  40d8ca:	lea    rax,[rsp+0x8]
  40d8cf:	lea    rcx,[rdi+0x9c8]
  40d8d6:	mov    QWORD PTR [rsp+0x8],rcx
  40d8db:	mov    QWORD PTR [rax+0x8],0x40
  40d8e3:	xor    ecx,ecx
  40d8e5:	mov    rdx,rax
  40d8e8:	call   4099e0 <__swc_fn_e121059d_000120_9175a56a>
  40d8ed:	mov    DWORD PTR [rdi+0xbc8],eax
  40d8f3:	mov    rdi,QWORD PTR [rdi+0x990]
  40d8fa:	test   rdi,rdi
  40d8fd:	je     40d907 <__swc_fn_e121059d_000103_67100064+0x87>
  40d8ff:	mov    rcx,rsi
  40d902:	mov    rdx,rbx
  40d905:	call   rdi
  40d907:	call   40d630 <__swc_fn_e121059d_000091_3d2f5a0d>
  40d90c:	test   al,al
  40d90e:	je     40d91e <__swc_fn_e121059d_000103_67100064+0x9e>
  40d910:	mov    rcx,rsi
  40d913:	mov    rdx,rbx
  40d916:	xor    r8d,r8d
  40d919:	call   40dc40 <__swc_fn_e121059d_000121_ea68f292>
  40d91e:	mov    rcx,rsi
  40d921:	mov    rdx,rbx
  40d924:	call   408a80 <__swc_fn_e121059d_000102_e9fdc18e>
  40d929:	call   410dc0 <__swc_fn_e121059d_000119_7f430081>
  40d92e:	add    rsp,0x20
  40d932:	pop    rdi
  40d933:	pop    rsi
  40d934:	pop    rbx
  40d935:	ret
	...

000000000040d940 <__swc_fn_e121059d_000106_6fd80914>:
  40d940:	sub    rsp,0x8
  40d944:	test   r8,r8
  40d947:	je     40d94e <__swc_fn_e121059d_000106_6fd80914+0xe>
  40d949:	call   410770 <__swc_fn_e121059d_000104_5589fdbd>
  40d94e:	add    rsp,0x8
  40d952:	ret
	...

000000000040d960 <__swc_fn_e121059d_000109_84af7666>:
  40d960:	push   rsi
  40d961:	push   rdi
  40d962:	push   r12
  40d964:	push   r13
  40d966:	sub    rsp,0xd8
  40d96d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40d973:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40d979:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40d97f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40d985:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40d98b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40d994:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40d99d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40d9a6:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40d9af:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40d9b8:	xor    eax,eax
  40d9ba:	call   407050 <getpid@plt>
  40d9bf:	mov    rsi,rax
  40d9c2:	lea    rdi,[rip+0x1937f]        # 426d48 <__swc_bss_base_e121059d+0x2d08>
  40d9c9:	mov    r12,QWORD PTR [rdi]
  40d9cc:	test   r12,r12
  40d9cf:	je     40d9dd <__swc_fn_e121059d_000109_84af7666+0x7d>
  40d9d1:	cmp    DWORD PTR [r12+0x10],esi
  40d9d6:	jne    40d9dd <__swc_fn_e121059d_000109_84af7666+0x7d>
  40d9d8:	mov    rax,r12
  40d9db:	jmp    40da40 <__swc_fn_e121059d_000109_84af7666+0xe0>
  40d9dd:	mov    ecx,0x4
  40d9e2:	mov    edx,0x18
  40d9e7:	call   4091c0 <__swc_fn_e121059d_000108_4796e893>
  40d9ec:	mov    rcx,rax
  40d9ef:	test   rax,rax
  40d9f2:	jne    40d9f8 <__swc_fn_e121059d_000109_84af7666+0x98>
  40d9f4:	xor    eax,eax
  40d9f6:	jmp    40da40 <__swc_fn_e121059d_000109_84af7666+0xe0>
  40d9f8:	mov    DWORD PTR [rcx+0x10],esi
  40d9fb:	mov    rax,r12
  40d9fe:	lock cmpxchg QWORD PTR [rdi],rcx
  40da03:	mov    r13,rax
  40da06:	cmp    rax,r12
  40da09:	je     40da1f <__swc_fn_e121059d_000109_84af7666+0xbf>
  40da0b:	mov    rdi,rcx
  40da0e:	mov    esi,0x18
  40da13:	xor    eax,eax
  40da15:	call   407160 <munmap@plt>
  40da1a:	mov    rax,r13
  40da1d:	jmp    40da40 <__swc_fn_e121059d_000109_84af7666+0xe0>
  40da1f:	test   r12,r12
  40da22:	je     40da3d <__swc_fn_e121059d_000109_84af7666+0xdd>
  40da24:	mov    rdi,r12
  40da27:	mov    esi,0x18
  40da2c:	xor    eax,eax
  40da2e:	mov    QWORD PTR [rsp+0x28],rcx
  40da33:	call   407160 <munmap@plt>
  40da38:	mov    rcx,QWORD PTR [rsp+0x28]
  40da3d:	mov    rax,rcx
  40da40:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40da46:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40da4c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40da52:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40da58:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40da5e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40da67:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40da70:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40da79:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40da82:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40da8b:	add    rsp,0xd8
  40da92:	pop    r13
  40da94:	pop    r12
  40da96:	pop    rdi
  40da97:	pop    rsi
  40da98:	ret
  40da99:	add    BYTE PTR [rax],al
  40da9b:	add    BYTE PTR [rax],al
  40da9d:	add    BYTE PTR [rax],al
	...

000000000040daa0 <__swc_fn_e121059d_000112_b25e3a45>:
  40daa0:	push   rbx
  40daa1:	push   r12
  40daa3:	push   rdi
  40daa4:	push   rsi
  40daa5:	sub    rsp,0xa8
  40daac:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40dab2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40dab8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40dabe:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40dac4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40daca:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40dad0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40dad6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40dadc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40dae5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40daee:	mov    rbx,rdx
  40daf1:	mov    r12,rcx
  40daf4:	mov    rdi,rcx
  40daf7:	mov    rsi,rdx
  40dafa:	mov    edx,0x3
  40daff:	xor    eax,eax
  40db01:	call   407170 <mprotect@plt>
  40db06:	test   eax,eax
  40db08:	je     40db0e <__swc_fn_e121059d_000112_b25e3a45+0x6e>
  40db0a:	xor    eax,eax
  40db0c:	jmp    40db23 <__swc_fn_e121059d_000112_b25e3a45+0x83>
  40db0e:	mov    rcx,r12
  40db11:	mov    rdx,rbx
  40db14:	mov    al,0x1
  40db16:	mov    r8,rax
  40db19:	call   409810 <__swc_fn_e121059d_000111_a808fe76>
  40db1e:	mov    eax,0x1
  40db23:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40db29:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40db2f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40db35:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40db3b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40db41:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40db47:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40db4d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40db53:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40db5c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40db65:	add    rsp,0xa8
  40db6c:	pop    rsi
  40db6d:	pop    rdi
  40db6e:	pop    r12
  40db70:	pop    rbx
  40db71:	ret
	...

000000000040db80 <__swc_fn_e121059d_000115_27d95464>:
  40db80:	sub    rsp,0x8
  40db84:	test   rcx,rcx
  40db87:	jne    40db8e <__swc_fn_e121059d_000115_27d95464+0xe>
  40db89:	add    rsp,0x8
  40db8d:	ret
  40db8e:	call   410c70 <__swc_fn_e121059d_000116_1ba33335>
  40db93:	add    rsp,0x8
  40db97:	ret
	...

000000000040dba0 <__swc_fn_e121059d_000118_86a7fb9e>:
  40dba0:	push   rdi
  40dba1:	push   rsi
  40dba2:	sub    rsp,0xa8
  40dba9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40dbaf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40dbb5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40dbbb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40dbc1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40dbc7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40dbcd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40dbd3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40dbd9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40dbe2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40dbeb:	xor    edi,edi
  40dbed:	xor    eax,eax
  40dbef:	call   407180 <exit@plt>
  40dbf4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40dbfa:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40dc00:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40dc06:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40dc0c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40dc12:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40dc18:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40dc1e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40dc24:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40dc2d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40dc36:	add    rsp,0xa8
  40dc3d:	pop    rsi
  40dc3e:	pop    rdi
  40dc3f:	ret

000000000040dc40 <__swc_fn_e121059d_000121_ea68f292>:
  40dc40:	push   rbx
  40dc41:	push   rsi
  40dc42:	push   rdi
  40dc43:	push   r12
  40dc45:	sub    rsp,0x18
  40dc49:	mov    rbx,r8
  40dc4c:	mov    rsi,rcx
  40dc4f:	mov    rdi,rdx
  40dc52:	mov    rcx,QWORD PTR [rip+0x190e7]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40dc59:	test   rcx,rcx
  40dc5c:	jne    40dc6e <__swc_fn_e121059d_000121_ea68f292+0x2e>
  40dc5e:	call   40ea10 <__swc_fn_e121059d_000166_cf398896>
  40dc63:	lea    rcx,[rax+0x1]
  40dc67:	mov    QWORD PTR [rip+0x190d2],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40dc6e:	dec    rcx
  40dc71:	call   40b6c0 <__swc_fn_e121059d_000168_fce60b2b>
  40dc76:	mov    r12,rax
  40dc79:	cmp    ebx,0x3
  40dc7c:	jne    40dc8f <__swc_fn_e121059d_000121_ea68f292+0x4f>
  40dc7e:	mov    rax,QWORD PTR [r12+0xbd0]
  40dc86:	test   rax,rax
  40dc89:	jne    40ddcf <__swc_fn_e121059d_000121_ea68f292+0x18f>
  40dc8f:	cmp    ebx,0x5
  40dc92:	jne    40dcb6 <__swc_fn_e121059d_000121_ea68f292+0x76>
  40dc94:	call   40d630 <__swc_fn_e121059d_000091_3d2f5a0d>
  40dc99:	test   al,al
  40dc9b:	jne    40dcb6 <__swc_fn_e121059d_000121_ea68f292+0x76>
  40dc9d:	mov    rcx,rsi
  40dca0:	mov    rdx,rdi
  40dca3:	call   40b670 <__swc_fn_e121059d_000165_1962e12a>
  40dca8:	test   al,al
  40dcaa:	je     40dcb6 <__swc_fn_e121059d_000121_ea68f292+0x76>
  40dcac:	add    rsp,0x18
  40dcb0:	pop    r12
  40dcb2:	pop    rdi
  40dcb3:	pop    rsi
  40dcb4:	pop    rbx
  40dcb5:	ret
  40dcb6:	call   40d630 <__swc_fn_e121059d_000091_3d2f5a0d>
  40dcbb:	test   al,al
  40dcbd:	jne    40dd32 <__swc_fn_e121059d_000121_ea68f292+0xf2>
  40dcbf:	lea    rax,[rsp+0x8]
  40dcc4:	vmovups xmm0,XMMWORD PTR [rsi]
  40dcc8:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dcce:	mov    rcx,QWORD PTR [rsp+0x8]
  40dcd3:	test   rcx,rcx
  40dcd6:	jne    40dd27 <__swc_fn_e121059d_000121_ea68f292+0xe7>
  40dcd8:	cmp    ebx,0x3
  40dcdb:	je     40dce9 <__swc_fn_e121059d_000121_ea68f292+0xa9>
  40dcdd:	cmp    ebx,0x4
  40dce0:	je     40dcf9 <__swc_fn_e121059d_000121_ea68f292+0xb9>
  40dce2:	cmp    ebx,0x5
  40dce5:	je     40dd09 <__swc_fn_e121059d_000121_ea68f292+0xc9>
  40dce7:	jmp    40dd19 <__swc_fn_e121059d_000121_ea68f292+0xd9>
  40dce9:	vmovups xmm0,XMMWORD PTR [rip+0x57ef]        # 4134e0 <__swc_rdata_base_e121059d+0x3d0>
  40dcf1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dcf7:	jmp    40dd27 <__swc_fn_e121059d_000121_ea68f292+0xe7>
  40dcf9:	vmovups xmm0,XMMWORD PTR [rip+0x57ef]        # 4134f0 <__swc_rdata_base_e121059d+0x3e0>
  40dd01:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dd07:	jmp    40dd27 <__swc_fn_e121059d_000121_ea68f292+0xe7>
  40dd09:	vmovups xmm0,XMMWORD PTR [rip+0x57ef]        # 413500 <__swc_rdata_base_e121059d+0x3f0>
  40dd11:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dd17:	jmp    40dd27 <__swc_fn_e121059d_000121_ea68f292+0xe7>
  40dd19:	vmovups xmm0,XMMWORD PTR [rip+0x57ef]        # 413510 <__swc_rdata_base_e121059d+0x400>
  40dd21:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dd27:	mov    rcx,rax
  40dd2a:	mov    rdx,rdi
  40dd2d:	call   40d880 <__swc_fn_e121059d_000103_67100064>
  40dd32:	vmovups xmm0,XMMWORD PTR [rdi]
  40dd36:	vmovups XMMWORD PTR [r12+0x940],xmm0
  40dd40:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  40dd45:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40dd4f:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  40dd54:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40dd5e:	lea    rax,[r12+0x940]
  40dd66:	mov    QWORD PTR [r12+0x970],rax
  40dd6e:	mov    rax,QWORD PTR [rsi]
  40dd71:	mov    QWORD PTR [r12+0x978],rax
  40dd79:	mov    rax,QWORD PTR [rsi+0x8]
  40dd7d:	mov    QWORD PTR [r12+0x980],rax
  40dd85:	movsxd rax,ebx
  40dd88:	mov    QWORD PTR [r12+0x988],rax
  40dd90:	cmp    ebx,0x5
  40dd93:	je     40dd9c <__swc_fn_e121059d_000121_ea68f292+0x15c>
  40dd95:	xor    ecx,ecx
  40dd97:	call   40eb40 <__swc_fn_e121059d_000175_176517f9>
  40dd9c:	mov    rbx,QWORD PTR [r12+0xbe8]
  40dda4:	test   rbx,rbx
  40dda7:	je     40ddb8 <__swc_fn_e121059d_000121_ea68f292+0x178>
  40dda9:	mov    rcx,r12
  40ddac:	call   rbx
  40ddae:	add    rsp,0x18
  40ddb2:	pop    r12
  40ddb4:	pop    rdi
  40ddb5:	pop    rsi
  40ddb6:	pop    rbx
  40ddb7:	ret
  40ddb8:	mov    rcx,rsi
  40ddbb:	call   4098c0 <__swc_fn_e121059d_000117_035d76a1>
  40ddc0:	call   410dc0 <__swc_fn_e121059d_000119_7f430081>
  40ddc5:	add    rsp,0x18
  40ddc9:	pop    r12
  40ddcb:	pop    rdi
  40ddcc:	pop    rsi
  40ddcd:	pop    rbx
  40ddce:	ret
  40ddcf:	mov    rcx,rsi
  40ddd2:	mov    rdx,rdi
  40ddd5:	call   40d880 <__swc_fn_e121059d_000103_67100064>
  40ddda:	jmp    40dc8f <__swc_fn_e121059d_000121_ea68f292+0x4f>
	...

000000000040dde0 <__swc_fn_e121059d_000124_9d2cbd72>:
  40dde0:	push   rdi
  40dde1:	push   rsi
  40dde2:	sub    rsp,0xb8
  40dde9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ddef:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40ddf5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40ddfb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40de01:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40de07:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40de0d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40de13:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40de1c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40de25:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40de2e:	mov    DWORD PTR [rsp+0x8],0x0
  40de36:	lea    rdi,[rsp+0x8]
  40de3b:	xor    esi,esi
  40de3d:	xor    eax,eax
  40de3f:	call   407190 <pthread_key_create@plt>
  40de44:	test   eax,eax
  40de46:	jne    40de4e <__swc_fn_e121059d_000124_9d2cbd72+0x6e>
  40de48:	mov    eax,DWORD PTR [rsp+0x8]
  40de4c:	jmp    40de55 <__swc_fn_e121059d_000124_9d2cbd72+0x75>
  40de4e:	mov    rax,0xffffffffffffffff
  40de55:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40de5b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40de61:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40de67:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40de6d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40de73:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40de79:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40de7f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40de88:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40de91:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40de9a:	add    rsp,0xb8
  40dea1:	pop    rsi
  40dea2:	pop    rdi
  40dea3:	ret
	...

000000000040deb0 <__swc_fn_e121059d_000127_102fe7b9>:
  40deb0:	push   rdi
  40deb1:	push   rsi
  40deb2:	sub    rsp,0xb8
  40deb9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40debf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40dec5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40decb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ded1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ded7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40dedd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40dee3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40deec:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40def5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40defe:	mov    DWORD PTR [rsp+0x8],0x0
  40df06:	lea    rdi,[rsp+0x8]
  40df0b:	mov    rsi,rcx
  40df0e:	xor    eax,eax
  40df10:	call   407190 <pthread_key_create@plt>
  40df15:	test   eax,eax
  40df17:	jne    40df22 <__swc_fn_e121059d_000127_102fe7b9+0x72>
  40df19:	mov    eax,DWORD PTR [rsp+0x8]
  40df1d:	inc    rax
  40df20:	jmp    40df24 <__swc_fn_e121059d_000127_102fe7b9+0x74>
  40df22:	xor    eax,eax
  40df24:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40df2a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40df30:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40df36:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40df3c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40df42:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40df48:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40df4e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40df57:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40df60:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40df69:	add    rsp,0xb8
  40df70:	pop    rsi
  40df71:	pop    rdi
  40df72:	ret
	...

000000000040df80 <__swc_fn_e121059d_000130_74b163fe>:
  40df80:	push   rdi
  40df81:	push   rsi
  40df82:	sub    rsp,0xa8
  40df89:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40df8f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40df95:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40df9b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40dfa1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40dfa7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40dfad:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40dfb3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40dfb9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40dfc2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40dfcb:	test   rcx,rcx
  40dfce:	setne  al
  40dfd1:	je     40dfea <__swc_fn_e121059d_000130_74b163fe+0x6a>
  40dfd3:	lea    rax,[rcx-0x1]
  40dfd7:	mov    eax,eax
  40dfd9:	mov    edi,eax
  40dfdb:	mov    rsi,rdx
  40dfde:	xor    eax,eax
  40dfe0:	call   407120 <pthread_setspecific@plt>
  40dfe5:	test   eax,eax
  40dfe7:	sete   al
  40dfea:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40dff0:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40dff6:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40dffc:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e002:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e008:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e00e:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e014:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e01a:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e023:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e02c:	add    rsp,0xa8
  40e033:	pop    rsi
  40e034:	pop    rdi
  40e035:	ret
	...

000000000040e040 <__swc_fn_e121059d_000133_f908e7f9>:
  40e040:	push   rdi
  40e041:	push   rsi
  40e042:	sub    rsp,0xa8
  40e049:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e04f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e055:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e05b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e061:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e067:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e06d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e073:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e079:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e082:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e08b:	mov    rax,rdx
  40e08e:	mov    QWORD PTR [rsp],0x0
  40e096:	mov    edi,0xca
  40e09b:	mov    rsi,rcx
  40e09e:	mov    edx,0x81
  40e0a3:	mov    eax,eax
  40e0a5:	mov    ecx,eax
  40e0a7:	xor    r8d,r8d
  40e0aa:	xor    r9d,r9d
  40e0ad:	xor    eax,eax
  40e0af:	call   4071a0 <syscall@plt>
  40e0b4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e0ba:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e0c0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e0c6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e0cc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e0d2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e0d8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e0de:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e0e4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e0ed:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e0f6:	add    rsp,0xa8
  40e0fd:	pop    rsi
  40e0fe:	pop    rdi
  40e0ff:	ret

000000000040e100 <__swc_fn_e121059d_000136_e3032dc2>:
  40e100:	sub    rsp,0x8
  40e104:	call   411170 <__swc_fn_e121059d_000134_4b2af8da>
  40e109:	add    rsp,0x8
  40e10d:	ret
	...

000000000040e110 <__swc_fn_e121059d_000139_0c00232f>:
  40e110:	push   rdi
  40e111:	push   rsi
  40e112:	sub    rsp,0xc8
  40e119:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40e11f:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40e125:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40e12b:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40e131:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40e137:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40e13d:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40e146:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40e14f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40e158:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40e161:	vxorps xmm0,xmm0,xmm0
  40e165:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e16b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e171:	mov    rdi,rcx
  40e174:	lea    rsi,[rsp+0x8]
  40e179:	xor    eax,eax
  40e17b:	call   4071b0 <dladdr@plt>
  40e180:	xor    ecx,ecx
  40e182:	test   eax,eax
  40e184:	je     40e18b <__swc_fn_e121059d_000139_0c00232f+0x7b>
  40e186:	mov    rcx,QWORD PTR [rsp+0x10]
  40e18b:	mov    rax,rcx
  40e18e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40e194:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40e19a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40e1a0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40e1a6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40e1ac:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40e1b2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40e1bb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40e1c4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40e1cd:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40e1d6:	add    rsp,0xc8
  40e1dd:	pop    rsi
  40e1de:	pop    rdi
  40e1df:	ret

000000000040e1e0 <__swc_fn_e121059d_000142_2ce79e3b>:
  40e1e0:	push   rbx
  40e1e1:	push   r12
  40e1e3:	push   r13
  40e1e5:	push   rdi
  40e1e6:	push   rsi
  40e1e7:	push   r14
  40e1e9:	push   r15
  40e1eb:	sub    rsp,0x150
  40e1f2:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40e1fb:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40e204:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40e20d:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40e216:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40e21f:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40e228:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40e231:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40e23a:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40e243:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40e24c:	mov    rbx,rdx
  40e24f:	mov    QWORD PTR [rsp+0x98],rdx
  40e257:	mov    r12,rcx
  40e25a:	mov    QWORD PTR [rsp+0xa0],rcx
  40e262:	mov    QWORD PTR [rbx],0x0
  40e269:	lea    r13,[rip+0x18b10]        # 426d80 <__swc_bss_base_e121059d+0x2d40>
  40e270:	mov    rcx,r13
  40e273:	call   40e100 <__swc_fn_e121059d_000136_e3032dc2>
  40e278:	mov    rax,QWORD PTR [rip+0x18b09]        # 426d88 <__swc_bss_base_e121059d+0x2d48>
  40e27f:	test   rax,rax
  40e282:	je     40e2b9 <__swc_fn_e121059d_000142_2ce79e3b+0xd9>
  40e284:	cs nop WORD PTR [rax+rax*1+0x0]
  40e28e:	xchg   ax,ax
  40e290:	cmp    QWORD PTR [rax+0x8],r12
  40e294:	jne    40e2b1 <__swc_fn_e121059d_000142_2ce79e3b+0xd1>
  40e296:	mov    rcx,QWORD PTR [rax+0x18]
  40e29a:	mov    QWORD PTR [rbx],rcx
  40e29d:	mov    rbx,QWORD PTR [rax+0x10]
  40e2a1:	mov    rcx,r13
  40e2a4:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40e2a9:	mov    rax,rbx
  40e2ac:	jmp    40e49b <__swc_fn_e121059d_000142_2ce79e3b+0x2bb>
  40e2b1:	mov    rax,QWORD PTR [rax]
  40e2b4:	test   rax,rax
  40e2b7:	jne    40e290 <__swc_fn_e121059d_000142_2ce79e3b+0xb0>
  40e2b9:	vxorps xmm0,xmm0,xmm0
  40e2bd:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  40e2c3:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  40e2c9:	mov    rdi,r12
  40e2cc:	lea    rsi,[rsp+0x10]
  40e2d1:	xor    eax,eax
  40e2d3:	call   4071b0 <dladdr@plt>
  40e2d8:	test   eax,eax
  40e2da:	sete   al
  40e2dd:	je     40e2ea <__swc_fn_e121059d_000142_2ce79e3b+0x10a>
  40e2df:	mov    rax,QWORD PTR [rsp+0x10]
  40e2e4:	test   rax,rax
  40e2e7:	sete   al
  40e2ea:	test   al,al
  40e2ec:	je     40e2fd <__swc_fn_e121059d_000142_2ce79e3b+0x11d>
  40e2ee:	mov    rcx,r13
  40e2f1:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40e2f6:	xor    eax,eax
  40e2f8:	jmp    40e49b <__swc_fn_e121059d_000142_2ce79e3b+0x2bb>
  40e2fd:	mov    rdi,QWORD PTR [rsp+0x10]
  40e302:	mov    esi,0x80000
  40e307:	xor    eax,eax
  40e309:	call   407010 <open@plt>
  40e30e:	lea    r14,[rsp+0x30]
  40e313:	mov    DWORD PTR [rsp+0x30],eax
  40e317:	cmp    DWORD PTR [r14],0x0
  40e31b:	jge    40e32c <__swc_fn_e121059d_000142_2ce79e3b+0x14c>
  40e31d:	mov    rcx,r13
  40e320:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40e325:	xor    eax,eax
  40e327:	jmp    40e49b <__swc_fn_e121059d_000142_2ce79e3b+0x2bb>
  40e32c:	mov    rax,r14
  40e32f:	movsxd rdi,DWORD PTR [rax]
  40e332:	xor    esi,esi
  40e334:	mov    edx,0x2
  40e339:	xor    eax,eax
  40e33b:	call   4070c0 <lseek@plt>
  40e340:	mov    r15,rax
  40e343:	test   rax,rax
  40e346:	jg     40e361 <__swc_fn_e121059d_000142_2ce79e3b+0x181>
  40e348:	movsxd rdi,DWORD PTR [r14]
  40e34b:	xor    eax,eax
  40e34d:	call   407040 <close@plt>
  40e352:	mov    rcx,r13
  40e355:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40e35a:	xor    eax,eax
  40e35c:	jmp    40e49b <__swc_fn_e121059d_000142_2ce79e3b+0x2bb>
  40e361:	xor    edi,edi
  40e363:	mov    rsi,r15
  40e366:	mov    edx,0x1
  40e36b:	mov    ecx,0x2
  40e370:	mov    rax,r14
  40e373:	movsxd r8,DWORD PTR [rax]
  40e376:	xor    r9d,r9d
  40e379:	xor    eax,eax
  40e37b:	call   4070d0 <mmap@plt>
  40e380:	mov    rbx,rax
  40e383:	test   rax,rax
  40e386:	sete   al
  40e389:	cmp    rbx,0xffffffffffffffff
  40e38d:	sete   cl
  40e390:	or     al,cl
  40e392:	je     40e3ad <__swc_fn_e121059d_000142_2ce79e3b+0x1cd>
  40e394:	movsxd rdi,DWORD PTR [r14]
  40e397:	xor    eax,eax
  40e399:	call   407040 <close@plt>
  40e39e:	mov    rcx,r13
  40e3a1:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40e3a6:	xor    eax,eax
  40e3a8:	jmp    40e49b <__swc_fn_e121059d_000142_2ce79e3b+0x2bb>
  40e3ad:	lea    rax,[rsp+0x50]
  40e3b2:	mov    QWORD PTR [rax],0x0
  40e3b9:	mov    rcx,rbx
  40e3bc:	mov    rdx,r15
  40e3bf:	mov    r8,rax
  40e3c2:	call   409e60 <__swc_fn_e121059d_000141_c6b99a56>
  40e3c7:	mov    r12,rax
  40e3ca:	test   rax,rax
  40e3cd:	jne    40e3f5 <__swc_fn_e121059d_000142_2ce79e3b+0x215>
  40e3cf:	mov    rdi,rbx
  40e3d2:	mov    rsi,r15
  40e3d5:	xor    eax,eax
  40e3d7:	call   407160 <munmap@plt>
  40e3dc:	movsxd rdi,DWORD PTR [r14]
  40e3df:	xor    eax,eax
  40e3e1:	call   407040 <close@plt>
  40e3e6:	mov    rcx,r13
  40e3e9:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40e3ee:	xor    eax,eax
  40e3f0:	jmp    40e49b <__swc_fn_e121059d_000142_2ce79e3b+0x2bb>
  40e3f5:	mov    edi,0x20
  40e3fa:	xor    eax,eax
  40e3fc:	call   4071c0 <malloc@plt>
  40e401:	test   rax,rax
  40e404:	jne    40e429 <__swc_fn_e121059d_000142_2ce79e3b+0x249>
  40e406:	mov    rdi,rbx
  40e409:	mov    rsi,r15
  40e40c:	xor    eax,eax
  40e40e:	call   407160 <munmap@plt>
  40e413:	movsxd rdi,DWORD PTR [r14]
  40e416:	xor    eax,eax
  40e418:	call   407040 <close@plt>
  40e41d:	mov    rcx,r13
  40e420:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40e425:	xor    eax,eax
  40e427:	jmp    40e49b <__swc_fn_e121059d_000142_2ce79e3b+0x2bb>
  40e429:	mov    rcx,QWORD PTR [rip+0x18958]        # 426d88 <__swc_bss_base_e121059d+0x2d48>
  40e430:	mov    QWORD PTR [rsp+0x70],rcx
  40e435:	mov    rcx,QWORD PTR [rsp+0xa0]
  40e43d:	mov    QWORD PTR [rsp+0x78],rcx
  40e442:	mov    QWORD PTR [rsp+0x80],r12
  40e44a:	mov    rcx,QWORD PTR [rsp+0x50]
  40e44f:	mov    QWORD PTR [rsp+0x88],rcx
  40e457:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  40e45d:	vmovups XMMWORD PTR [rax],xmm0
  40e461:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  40e46a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e46f:	mov    QWORD PTR [rip+0x18912],rax        # 426d88 <__swc_bss_base_e121059d+0x2d48>
  40e476:	mov    rax,QWORD PTR [rsp+0x50]
  40e47b:	mov    rbx,QWORD PTR [rsp+0x98]
  40e483:	mov    QWORD PTR [rbx],rax
  40e486:	movsxd rdi,DWORD PTR [r14]
  40e489:	xor    eax,eax
  40e48b:	call   407040 <close@plt>
  40e490:	mov    rcx,r13
  40e493:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40e498:	mov    rax,r12
  40e49b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40e4a4:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40e4ad:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40e4b6:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40e4bf:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40e4c8:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40e4d1:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40e4da:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40e4e3:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40e4ec:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40e4f5:	add    rsp,0x150
  40e4fc:	pop    r15
  40e4fe:	pop    r14
  40e500:	pop    rsi
  40e501:	pop    rdi
  40e502:	pop    r13
  40e504:	pop    r12
  40e506:	pop    rbx
  40e507:	ret
	...

000000000040e510 <__swc_fn_e121059d_000145_72996a5b>:
  40e510:	push   rbx
  40e511:	sub    rsp,0xe0
  40e518:	lea    rbx,[rsp+0x8]
  40e51d:	vxorps xmm0,xmm0,xmm0
  40e521:	vmovups XMMWORD PTR [rbx],xmm0
  40e525:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e52a:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e52f:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40e534:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40e539:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  40e53e:	mov    DWORD PTR [rbx+0x60],0x0
  40e545:	mov    r8,rbx
  40e548:	nop    DWORD PTR [rax+rax*1+0x0]
  40e550:	mov    r9,rcx
  40e553:	movabs rcx,0xcccccccccccccccd
  40e55d:	mov    rax,r9
  40e560:	mul    rcx
  40e563:	mov    r10,rdx
  40e566:	shr    r10,0x3
  40e56a:	mov    rcx,r10
  40e56d:	imul   rdx,r10,0xa
  40e571:	sub    r9,rdx
  40e574:	mov    rdx,QWORD PTR [rip+0x4fc5]        # 413540 <__swc_rdata_base_e121059d+0x430>
  40e57b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  40e580:	mov    BYTE PTR [r8],dl
  40e583:	lea    rdx,[r8+0x1]
  40e587:	mov    r8,rdx
  40e58a:	test   r10,r10
  40e58d:	jne    40e550 <__swc_fn_e121059d_000145_72996a5b+0x40>
  40e58f:	mov    BYTE PTR [rdx],0x0
  40e592:	sub    r8,0x1
  40e596:	mov    rax,rbx
  40e599:	cmp    rax,r8
  40e59c:	jae    40e5b6 <__swc_fn_e121059d_000145_72996a5b+0xa6>
  40e59e:	xchg   ax,ax
  40e5a0:	mov    cl,BYTE PTR [r8]
  40e5a3:	mov    dl,BYTE PTR [rax]
  40e5a5:	mov    BYTE PTR [r8],dl
  40e5a8:	sub    r8,0x1
  40e5ac:	mov    BYTE PTR [rax],cl
  40e5ae:	inc    rax
  40e5b1:	cmp    rax,r8
  40e5b4:	jb     40e5a0 <__swc_fn_e121059d_000145_72996a5b+0x90>
  40e5b6:	xor    eax,eax
  40e5b8:	test   rbx,rbx
  40e5bb:	je     40e5de <__swc_fn_e121059d_000145_72996a5b+0xce>
  40e5bd:	mov    rcx,rbx
  40e5c0:	mov    dl,BYTE PTR [rcx]
  40e5c2:	test   dl,dl
  40e5c4:	je     40e5de <__swc_fn_e121059d_000145_72996a5b+0xce>
  40e5c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e5d0:	add    rcx,0x1
  40e5d4:	add    rax,0x1
  40e5d8:	mov    dl,BYTE PTR [rcx]
  40e5da:	test   dl,dl
  40e5dc:	jne    40e5d0 <__swc_fn_e121059d_000145_72996a5b+0xc0>
  40e5de:	mov    QWORD PTR [rbx+0xa8],rbx
  40e5e5:	mov    QWORD PTR [rbx+0xb0],rax
  40e5ec:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40e5f4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40e5fc:	lea    rcx,[rbx+0xb8]
  40e603:	call   4098c0 <__swc_fn_e121059d_000117_035d76a1>
  40e608:	add    rsp,0xe0
  40e60f:	pop    rbx
  40e610:	ret
	...

000000000040e620 <__swc_fn_e121059d_000148_32a497f3>:
  40e620:	sub    rsp,0x8
  40e624:	mov    rax,QWORD PTR [rcx+0x8]
  40e628:	mov    r8,QWORD PTR [rdx+0x8]
  40e62c:	cmp    rax,r8
  40e62f:	je     40e638 <__swc_fn_e121059d_000148_32a497f3+0x18>
  40e631:	xor    eax,eax
  40e633:	add    rsp,0x8
  40e637:	ret
  40e638:	test   rax,rax
  40e63b:	jne    40e64c <__swc_fn_e121059d_000148_32a497f3+0x2c>
  40e63d:	test   r8,r8
  40e640:	jne    40e64c <__swc_fn_e121059d_000148_32a497f3+0x2c>
  40e642:	mov    eax,0x1
  40e647:	add    rsp,0x8
  40e64b:	ret
  40e64c:	mov    rcx,QWORD PTR [rcx]
  40e64f:	mov    rdx,QWORD PTR [rdx]
  40e652:	test   rcx,rcx
  40e655:	sete   r8b
  40e659:	test   rdx,rdx
  40e65c:	sete   r9b
  40e660:	or     r8b,r9b
  40e663:	je     40e670 <__swc_fn_e121059d_000148_32a497f3+0x50>
  40e665:	cmp    rcx,rdx
  40e668:	sete   al
  40e66b:	add    rsp,0x8
  40e66f:	ret
  40e670:	cmp    rcx,rdx
  40e673:	jne    40e67f <__swc_fn_e121059d_000148_32a497f3+0x5f>
  40e675:	mov    eax,0x1
  40e67a:	add    rsp,0x8
  40e67e:	ret
  40e67f:	mov    r8,rax
  40e682:	call   410850 <__swc_fn_e121059d_000107_ed4b1681>
  40e687:	test   eax,eax
  40e689:	sete   al
  40e68c:	add    rsp,0x8
  40e690:	ret
	...

000000000040e6a0 <__swc_fn_e121059d_000151_9e4bc402>:
  40e6a0:	vxorps xmm0,xmm0,xmm0
  40e6a4:	vmovups XMMWORD PTR [rcx],xmm0
  40e6a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e6ad:	vxorps xmm0,xmm0,xmm0
  40e6b1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e6b6:	vmovups xmm0,XMMWORD PTR [rip+0x4f3a]        # 4135f8 <__swc_rdata_base_e121059d+0x4e8>
  40e6be:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e6c3:	ret
	...

000000000040e6d0 <__swc_fn_e121059d_000154_9e4bc402>:
  40e6d0:	vxorps xmm0,xmm0,xmm0
  40e6d4:	vmovups XMMWORD PTR [rcx],xmm0
  40e6d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e6dd:	vxorps xmm0,xmm0,xmm0
  40e6e1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e6e6:	vmovups xmm0,XMMWORD PTR [rip+0x502a]        # 413718 <__swc_rdata_base_e121059d+0x608>
  40e6ee:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e6f3:	mov    QWORD PTR [rcx+0x40],0x0
  40e6fb:	ret
  40e6fc:	add    BYTE PTR [rax],al
	...

000000000040e700 <__swc_fn_e121059d_000157_2745c4a5>:
  40e700:	push   rbx
  40e701:	sub    rsp,0x70
  40e705:	mov    rax,QWORD PTR [rcx]
  40e708:	mov    rbx,QWORD PTR [rcx+0x8]
  40e70c:	vxorps xmm0,xmm0,xmm0
  40e710:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e716:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e71c:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e722:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40e728:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40e72e:	mov    QWORD PTR [rsp+0x48],rdx
  40e733:	mov    QWORD PTR [rsp+0x50],r8
  40e738:	mov    rcx,rax
  40e73b:	lea    rdx,[rsp+0x8]
  40e740:	mov    rbx,QWORD PTR [rbx+0x18]
  40e744:	call   rbx
  40e746:	add    rsp,0x70
  40e74a:	pop    rbx
  40e74b:	ret
  40e74c:	add    BYTE PTR [rax],al
	...

000000000040e750 <__swc_fn_e121059d_000160_d8afac28>:
  40e750:	push   rbx
  40e751:	push   rsi
  40e752:	push   rdi
  40e753:	mov    rbx,r8
  40e756:	mov    rsi,rcx
  40e759:	mov    rdi,rdx
  40e75c:	call   411580 <__swc_fn_e121059d_000158_232ffa22>
  40e761:	vmovups xmm0,XMMWORD PTR [rbx]
  40e765:	vmovups XMMWORD PTR [rsi],xmm0
  40e769:	mov    QWORD PTR [rsi+0x18],rdi
  40e76d:	pop    rdi
  40e76e:	pop    rsi
  40e76f:	pop    rbx
  40e770:	ret
	...

000000000040e780 <__swc_fn_e121059d_000163_60216e69>:
  40e780:	push   rbx
  40e781:	push   rsi
  40e782:	push   rdi
  40e783:	push   r12
  40e785:	push   r13
  40e787:	sub    rsp,0x50
  40e78b:	mov    rbx,rcx
  40e78e:	mov    rsi,rdx
  40e791:	vmovups xmm0,XMMWORD PTR [rip+0x508f]        # 413828 <__swc_rdata_base_e121059d+0x718>
  40e799:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e79f:	vmovups xmm0,XMMWORD PTR [rip+0x5091]        # 413838 <__swc_rdata_base_e121059d+0x728>
  40e7a7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e7ad:	vxorps xmm0,xmm0,xmm0
  40e7b1:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e7b7:	mov    rcx,rdx
  40e7ba:	call   40e110 <__swc_fn_e121059d_000139_0c00232f>
  40e7bf:	mov    rdi,rax
  40e7c2:	test   rax,rax
  40e7c5:	jne    40e7f6 <__swc_fn_e121059d_000163_60216e69+0x76>
  40e7c7:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e7cd:	vmovups XMMWORD PTR [rbx],xmm0
  40e7d1:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e7d7:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e7dc:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e7e2:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e7e7:	mov    rax,rbx
  40e7ea:	add    rsp,0x50
  40e7ee:	pop    r13
  40e7f0:	pop    r12
  40e7f2:	pop    rdi
  40e7f3:	pop    rsi
  40e7f4:	pop    rbx
  40e7f5:	ret
  40e7f6:	mov    rcx,rdi
  40e7f9:	call   40b3c0 <__swc_fn_e121059d_000162_b5a9d657>
  40e7fe:	mov    r11,rax
  40e801:	test   rax,rax
  40e804:	je     40e80e <__swc_fn_e121059d_000163_60216e69+0x8e>
  40e806:	mov    al,BYTE PTR [r11+0x24]
  40e80a:	test   al,al
  40e80c:	jne    40e83d <__swc_fn_e121059d_000163_60216e69+0xbd>
  40e80e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e814:	vmovups XMMWORD PTR [rbx],xmm0
  40e818:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e81e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e823:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e829:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e82e:	mov    rax,rbx
  40e831:	add    rsp,0x50
  40e835:	pop    r13
  40e837:	pop    r12
  40e839:	pop    rdi
  40e83a:	pop    rsi
  40e83b:	pop    rbx
  40e83c:	ret
  40e83d:	sub    rsi,rdi
  40e840:	mov    eax,0xffffffff
  40e845:	cmp    rsi,rax
  40e848:	jbe    40e879 <__swc_fn_e121059d_000163_60216e69+0xf9>
  40e84a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e850:	vmovups XMMWORD PTR [rbx],xmm0
  40e854:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e85a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e85f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e865:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e86a:	mov    rax,rbx
  40e86d:	add    rsp,0x50
  40e871:	pop    r13
  40e873:	pop    r12
  40e875:	pop    rdi
  40e876:	pop    rsi
  40e877:	pop    rbx
  40e878:	ret
  40e879:	mov    rdi,QWORD PTR [r11+0x10]
  40e87d:	mov    eax,DWORD PTR [r11+0x20]
  40e881:	xor    ecx,ecx
  40e883:	test   rax,rax
  40e886:	jbe    40e9d8 <__swc_fn_e121059d_000163_60216e69+0x258>
  40e88c:	nop    DWORD PTR [rax+0x0]
  40e890:	mov    edx,ecx
  40e892:	imul   r12,rdx,0x14
  40e896:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40e89b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40e8a0:	mov    r9d,esi
  40e8a3:	cmp    r9,rdx
  40e8a6:	jb     40e9cb <__swc_fn_e121059d_000163_60216e69+0x24b>
  40e8ac:	add    rdx,r8
  40e8af:	mov    r8d,esi
  40e8b2:	cmp    r8,rdx
  40e8b5:	jae    40e9cb <__swc_fn_e121059d_000163_60216e69+0x24b>
  40e8bb:	lea    rsi,[rsp+0x38]
  40e8c0:	mov    eax,DWORD PTR [rdi+0xc]
  40e8c3:	mov    DWORD PTR [rsp+0x38],eax
  40e8c7:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40e8cc:	mov    rcx,rdi
  40e8cf:	mov    rdx,QWORD PTR [r11+0x18]
  40e8d3:	mov    r8,rsi
  40e8d6:	mov    r8d,DWORD PTR [r8]
  40e8d9:	mov    r9,rax
  40e8dc:	lea    r10,[rsp+0x10]
  40e8e1:	call   4115e0 <__swc_fn_e121059d_000161_01cbb887>
  40e8e6:	test   al,al
  40e8e8:	jne    40e91b <__swc_fn_e121059d_000163_60216e69+0x19b>
  40e8ea:	vmovups xmm0,XMMWORD PTR [rip+0x4f66]        # 413858 <__swc_rdata_base_e121059d+0x748>
  40e8f2:	vmovups XMMWORD PTR [rbx],xmm0
  40e8f6:	vmovups xmm0,XMMWORD PTR [rip+0x4f6a]        # 413868 <__swc_rdata_base_e121059d+0x758>
  40e8fe:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e903:	vxorps xmm0,xmm0,xmm0
  40e907:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e90c:	mov    rax,rbx
  40e90f:	add    rsp,0x50
  40e913:	pop    r13
  40e915:	pop    r12
  40e917:	pop    rdi
  40e918:	pop    rsi
  40e919:	pop    rbx
  40e91a:	ret
  40e91b:	lea    r13,[rsp+0x3c]
  40e920:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40e925:	mov    DWORD PTR [rsp+0x3c],eax
  40e929:	test   eax,eax
  40e92b:	je     40e97c <__swc_fn_e121059d_000163_60216e69+0x1fc>
  40e92d:	mov    rcx,rdi
  40e930:	mov    rdx,QWORD PTR [r11+0x18]
  40e934:	mov    r8d,DWORD PTR [rsi]
  40e937:	mov    rax,r13
  40e93a:	mov    r9d,DWORD PTR [rax]
  40e93d:	lea    r10,[rsp+0x20]
  40e942:	call   4115e0 <__swc_fn_e121059d_000161_01cbb887>
  40e947:	test   al,al
  40e949:	jne    40e97c <__swc_fn_e121059d_000163_60216e69+0x1fc>
  40e94b:	vmovups xmm0,XMMWORD PTR [rip+0x4f35]        # 413888 <__swc_rdata_base_e121059d+0x778>
  40e953:	vmovups XMMWORD PTR [rbx],xmm0
  40e957:	vmovups xmm0,XMMWORD PTR [rip+0x4f39]        # 413898 <__swc_rdata_base_e121059d+0x788>
  40e95f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e964:	vxorps xmm0,xmm0,xmm0
  40e968:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e96d:	mov    rax,rbx
  40e970:	add    rsp,0x50
  40e974:	pop    r13
  40e976:	pop    r12
  40e978:	pop    rdi
  40e979:	pop    rsi
  40e97a:	pop    rbx
  40e97b:	ret
  40e97c:	mov    eax,0x1
  40e981:	rex mov BYTE PTR [rsp+0x8],al
  40e986:	cmp    DWORD PTR [r13+0x0],0x0
  40e98b:	je     40e99c <__swc_fn_e121059d_000163_60216e69+0x21c>
  40e98d:	rex mov BYTE PTR [rsp+0x9],0x1
  40e993:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40e998:	mov    DWORD PTR [rsp+0x30],eax
  40e99c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e9a2:	vmovups XMMWORD PTR [rbx],xmm0
  40e9a6:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e9ac:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e9b1:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e9b7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e9bc:	mov    rax,rbx
  40e9bf:	add    rsp,0x50
  40e9c3:	pop    r13
  40e9c5:	pop    r12
  40e9c7:	pop    rdi
  40e9c8:	pop    rsi
  40e9c9:	pop    rbx
  40e9ca:	ret
  40e9cb:	add    rcx,0x1
  40e9cf:	cmp    rcx,rax
  40e9d2:	jb     40e890 <__swc_fn_e121059d_000163_60216e69+0x110>
  40e9d8:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e9de:	vmovups XMMWORD PTR [rbx],xmm0
  40e9e2:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e9e8:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e9ed:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e9f3:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e9f8:	mov    rax,rbx
  40e9fb:	add    rsp,0x50
  40e9ff:	pop    r13
  40ea01:	pop    r12
  40ea03:	pop    rdi
  40ea04:	pop    rsi
  40ea05:	pop    rbx
  40ea06:	ret
	...

000000000040ea10 <__swc_fn_e121059d_000166_cf398896>:
  40ea10:	sub    rsp,0x48
  40ea14:	call   40dde0 <__swc_fn_e121059d_000124_9d2cbd72>
  40ea19:	cmp    rax,0xffffffffffffffff
  40ea1d:	je     40ea24 <__swc_fn_e121059d_000166_cf398896+0x14>
  40ea1f:	add    rsp,0x48
  40ea23:	ret
  40ea24:	lea    rcx,[rip+0x4e9d]        # 4138c8 <__swc_rdata_base_e121059d+0x7b8>
  40ea2b:	vmovups xmm0,XMMWORD PTR [rip+0x4ea5]        # 4138d8 <__swc_rdata_base_e121059d+0x7c8>
  40ea33:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ea39:	vmovups xmm0,XMMWORD PTR [rip+0x4ea7]        # 4138e8 <__swc_rdata_base_e121059d+0x7d8>
  40ea41:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ea47:	vmovups xmm0,XMMWORD PTR [rip+0x4ea9]        # 4138f8 <__swc_rdata_base_e121059d+0x7e8>
  40ea4f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ea55:	lea    rdx,[rsp+0x8]
  40ea5a:	mov    QWORD PTR [rsp+0x38],rax
  40ea5f:	call   40d880 <__swc_fn_e121059d_000103_67100064>
  40ea64:	mov    rax,QWORD PTR [rsp+0x38]
  40ea69:	jmp    40ea1f <__swc_fn_e121059d_000166_cf398896+0xf>
  40ea6b:	add    BYTE PTR [rax],al
  40ea6d:	add    BYTE PTR [rax],al
	...

000000000040ea70 <__swc_fn_e121059d_000169_92b7d63c>:
  40ea70:	push   rbx
  40ea71:	push   rsi
  40ea72:	sub    rsp,0x28
  40ea76:	mov    rbx,rcx
  40ea79:	mov    DWORD PTR [rsp+0x8],0xbf0
  40ea81:	mov    ecx,0xbf0
  40ea86:	call   40d470 <__swc_fn_e121059d_000079_34776ded>
  40ea8b:	mov    rsi,rax
  40ea8e:	test   rax,rax
  40ea91:	jne    40ea9c <__swc_fn_e121059d_000169_92b7d63c+0x2c>
  40ea93:	xor    eax,eax
  40ea95:	add    rsp,0x28
  40ea99:	pop    rsi
  40ea9a:	pop    rbx
  40ea9b:	ret
  40ea9c:	vxorps xmm0,xmm0,xmm0
  40eaa0:	xor    eax,eax
  40eaa2:	cs nop WORD PTR [rax+rax*1+0x0]
  40eaac:	nop    DWORD PTR [rax+0x0]
  40eab0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40eab5:	add    rax,0x10
  40eab9:	cmp    rax,0xbf0
  40eac0:	jne    40eab0 <__swc_fn_e121059d_000169_92b7d63c+0x40>
  40eac2:	lea    rax,[rbx+0x1]
  40eac6:	mov    QWORD PTR [rsi+0x9c0],rax
  40eacd:	mov    rcx,rbx
  40ead0:	mov    rdx,rsi
  40ead3:	call   411940 <__swc_fn_e121059d_000167_f6173642>
  40ead8:	test   al,al
  40eada:	jne    40eaed <__swc_fn_e121059d_000169_92b7d63c+0x7d>
  40eadc:	mov    rcx,rsi
  40eadf:	call   40feb0 <__swc_fn_e121059d_000080_c1514492>
  40eae4:	xor    eax,eax
  40eae6:	add    rsp,0x28
  40eaea:	pop    rsi
  40eaeb:	pop    rbx
  40eaec:	ret
  40eaed:	lea    rcx,[rsp+0x18]
  40eaf2:	call   410430 <__swc_fn_e121059d_000092_8252f8c0>
  40eaf7:	mov    rax,rsi
  40eafa:	add    rsp,0x28
  40eafe:	pop    rsi
  40eaff:	pop    rbx
  40eb00:	ret
	...

000000000040eb10 <__swc_fn_e121059d_000172_c0e8acb1>:
  40eb10:	xor    eax,eax
  40eb12:	mov    edx,0x1
  40eb17:	lock cmpxchg QWORD PTR [rcx],rdx
  40eb1c:	test   rax,rax
  40eb1f:	jne    40eb22 <__swc_fn_e121059d_000172_c0e8acb1+0x12>
  40eb21:	ret
  40eb22:	cs nop WORD PTR [rax+rax*1+0x0]
  40eb2c:	nop    DWORD PTR [rax+0x0]
  40eb30:	mov    rax,QWORD PTR [rcx]
  40eb33:	test   rax,rax
  40eb36:	je     40eb10 <__swc_fn_e121059d_000172_c0e8acb1>
  40eb38:	jmp    40eb30 <__swc_fn_e121059d_000172_c0e8acb1+0x20>
  40eb3a:	add    BYTE PTR [rax],al
  40eb3c:	add    BYTE PTR [rax],al
	...

000000000040eb40 <__swc_fn_e121059d_000175_176517f9>:
  40eb40:	push   rsi
  40eb41:	push   rdi
  40eb42:	sub    rsp,0x38
  40eb46:	mov    rsi,rcx
  40eb49:	call   411950 <__swc_fn_e121059d_000170_4579a84c>
  40eb4e:	mov    rdi,rax
  40eb51:	call   4110c0 <__swc_fn_e121059d_000131_c1196dfb>
  40eb56:	mov    r8,rax
  40eb59:	mov    rcx,rdi
  40eb5c:	call   40eb10 <__swc_fn_e121059d_000172_c0e8acb1>
  40eb61:	mov    rax,QWORD PTR [rdi+0x8]
  40eb65:	test   rax,rax
  40eb68:	je     40eba5 <__swc_fn_e121059d_000175_176517f9+0x65>
  40eb6a:	nop    WORD PTR [rax+rax*1+0x0]
  40eb70:	cmp    rax,rsi
  40eb73:	je     40eba5 <__swc_fn_e121059d_000175_176517f9+0x65>
  40eb75:	mov    r9,QWORD PTR [rax]
  40eb78:	cmp    QWORD PTR [rax+0x20],r8
  40eb7c:	jne    40eb9d <__swc_fn_e121059d_000175_176517f9+0x5d>
  40eb7e:	mov    rcx,rdi
  40eb81:	mov    rdx,rax
  40eb84:	mov    QWORD PTR [rsp+0x28],r8
  40eb89:	mov    QWORD PTR [rsp+0x30],r9
  40eb8e:	call   40b7e0 <__swc_fn_e121059d_000174_f69b1f05>
  40eb93:	mov    r8,QWORD PTR [rsp+0x28]
  40eb98:	mov    r9,QWORD PTR [rsp+0x30]
  40eb9d:	mov    rax,r9
  40eba0:	test   r9,r9
  40eba3:	jne    40eb70 <__swc_fn_e121059d_000175_176517f9+0x30>
  40eba5:	xor    eax,eax
  40eba7:	mov    QWORD PTR [rdi],rax
  40ebaa:	add    rsp,0x38
  40ebae:	pop    rdi
  40ebaf:	pop    rsi
  40ebb0:	ret
	...

000000000040ebc0 <__swc_fn_e121059d_000178_1ca87929>:
  40ebc0:	push   rdi
  40ebc1:	push   rsi
  40ebc2:	sub    rsp,0xb8
  40ebc9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ebcf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40ebd5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40ebdb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ebe1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ebe7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ebed:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40ebf3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40ebfc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ec05:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ec0e:	vxorps xmm0,xmm0,xmm0
  40ec12:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ec18:	mov    edi,0x1
  40ec1d:	lea    rsi,[rsp+0x8]
  40ec22:	xor    eax,eax
  40ec24:	call   407130 <clock_gettime@plt>
  40ec29:	vxorpd xmm0,xmm0,xmm0
  40ec2d:	mov    rax,QWORD PTR [rsp+0x8]
  40ec32:	vcvtsi2sd xmm0,xmm0,rax
  40ec37:	vxorpd xmm1,xmm1,xmm1
  40ec3b:	mov    rax,QWORD PTR [rsp+0x10]
  40ec40:	vcvtsi2sd xmm1,xmm1,rax
  40ec45:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x4cbb]        # 413908 <__swc_rdata_base_e121059d+0x7f8>
  40ec4d:	vaddsd xmm0,xmm0,xmm1
  40ec51:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ec57:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ec5d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ec63:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ec69:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ec6f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ec75:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ec7b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ec84:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ec8d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ec96:	add    rsp,0xb8
  40ec9d:	pop    rsi
  40ec9e:	pop    rdi
  40ec9f:	ret

000000000040eca0 <__swc_fn_e121059d_000002_884bb5c0>:
  40eca0:	sub    rsp,0x8
  40eca4:	call   410a10 <__swc_fn_e121059d_000110_8d425bd3>
  40eca9:	mov    rcx,rax
  40ecac:	test   rax,rax
  40ecaf:	je     40ecd6 <__swc_fn_e121059d_000002_884bb5c0+0x36>
  40ecb1:	lea    rdx,[rip+0x15388]        # 424040 <__swc_bss_base_e121059d>
  40ecb8:	mov    r8,QWORD PTR [rip+0x15381]        # 424040 <__swc_bss_base_e121059d>
  40ecbf:	nop
  40ecc0:	lea    r9,[r8+0x1]
  40ecc4:	mov    rax,r8
  40ecc7:	lock cmpxchg QWORD PTR [rdx],r9
  40eccc:	cmp    rax,r8
  40eccf:	je     40ecd6 <__swc_fn_e121059d_000002_884bb5c0+0x36>
  40ecd1:	mov    r8,rax
  40ecd4:	jmp    40ecc0 <__swc_fn_e121059d_000002_884bb5c0+0x20>
  40ecd6:	mov    rax,rcx
  40ecd9:	add    rsp,0x8
  40ecdd:	ret
	...

000000000040ece0 <__swc_fn_e121059d_000005_b2240b56>:
  40ece0:	mov    r8d,edx
  40ece3:	xor    eax,eax
  40ece5:	tzcnt  eax,edx
  40ece9:	shrx   r9d,edx,eax
  40ecee:	mov    DWORD PTR [rcx+0x2c],edx
  40ecf1:	xor    eax,eax
  40ecf3:	tzcnt  eax,edx
  40ecf7:	mov    BYTE PTR [rcx+0x38],al
  40ecfa:	mov    eax,0xffffffff
  40ecff:	xor    edx,edx
  40ed01:	div    r8d
  40ed04:	mov    DWORD PTR [rcx+0x34],eax
  40ed07:	mov    eax,r9d
  40ed0a:	mov    edx,r9d
  40ed0d:	imul   edx,r9d
  40ed11:	mov    r8d,0x2
  40ed17:	sub    r8d,edx
  40ed1a:	imul   eax,r8d
  40ed1e:	mov    edx,r9d
  40ed21:	imul   edx,eax
  40ed24:	mov    r8d,0x2
  40ed2a:	sub    r8d,edx
  40ed2d:	imul   eax,r8d
  40ed31:	mov    edx,r9d
  40ed34:	imul   edx,eax
  40ed37:	mov    r8d,0x2
  40ed3d:	sub    r8d,edx
  40ed40:	imul   eax,r8d
  40ed44:	mov    edx,r9d
  40ed47:	imul   edx,eax
  40ed4a:	mov    r8d,0x2
  40ed50:	sub    r8d,edx
  40ed53:	imul   eax,r8d
  40ed57:	imul   r9d,eax
  40ed5b:	mov    edx,0x2
  40ed60:	sub    edx,r9d
  40ed63:	imul   eax,edx
  40ed66:	mov    DWORD PTR [rcx+0x30],eax
  40ed69:	ret
  40ed6a:	add    BYTE PTR [rax],al
  40ed6c:	add    BYTE PTR [rax],al
	...

000000000040ed70 <__swc_fn_e121059d_000008_4e857afc>:
  40ed70:	xor    eax,eax
  40ed72:	mov    DWORD PTR [rcx+0x68],eax
  40ed75:	ret
	...

000000000040ed80 <__swc_fn_e121059d_000011_6493fbbc>:
  40ed80:	mov    eax,DWORD PTR [rcx+0x28]
  40ed83:	shlx   eax,edx,eax
  40ed88:	shl    rax,0x10
  40ed8c:	lea    rdx,[rcx+rax*1]
  40ed90:	lea    rax,[rcx+0x3000]
  40ed97:	cmp    rdx,rax
  40ed9a:	cmovae rax,rdx
  40ed9e:	ret
	...

000000000040eda0 <__swc_fn_e121059d_000014_afb279e2>:
  40eda0:	push   rsi
  40eda1:	push   rdi
  40eda2:	push   r12
  40eda4:	push   r13
  40eda6:	push   r14
  40eda8:	mov    rsi,rdx
  40edab:	mov    rdi,rcx
  40edae:	rex mov dl,BYTE PTR [rsi+0x3a]
  40edb2:	mov    ecx,DWORD PTR [rdi+0x28]
  40edb5:	shr    dl,cl
  40edb7:	mov    r12d,0x1
  40edbd:	mov    ecx,edx
  40edbf:	shl    r12,cl
  40edc2:	mov    r13d,DWORD PTR [rsi+0x3c]
  40edc6:	rex mov BYTE PTR [rsi+0x3b],0x0
  40edcb:	mov    QWORD PTR [rsi+0x40],0x0
  40edd3:	mov    QWORD PTR [rsi],0x0
  40edda:	mov    rax,QWORD PTR [rsi+0x10]
  40edde:	mov    QWORD PTR [rsi+0x20],rax
  40ede2:	lea    r14,[rip+0x1525f]        # 424048 <__swc_bss_base_e121059d+0x8>
  40ede9:	mov    rax,QWORD PTR [r14]
  40edec:	shr    rax,0x2
  40edf0:	mov    rcx,rax
  40edf3:	cmp    rax,0x800000
  40edfa:	mov    eax,0x800000
  40edff:	cmovb  rcx,rax
  40ee03:	lea    r8,[rip+0x1524e]        # 424058 <__swc_bss_base_e121059d+0x18>
  40ee0a:	mov    rax,QWORD PTR [r8]
  40ee0d:	mov    r9,rax
  40ee10:	lea    r10,[r9+r13*1]
  40ee14:	cmp    r10,rcx
  40ee17:	ja     40ee3b <__swc_fn_e121059d_000014_afb279e2+0x9b>
  40ee19:	mov    rax,r9
  40ee1c:	lock cmpxchg QWORD PTR [r8],r10
  40ee21:	cmp    rax,r9
  40ee24:	je     40ee2b <__swc_fn_e121059d_000014_afb279e2+0x8b>
  40ee26:	mov    r9,rax
  40ee29:	jmp    40ee10 <__swc_fn_e121059d_000014_afb279e2+0x70>
  40ee2b:	mov    rcx,rdi
  40ee2e:	mov    rdx,r12
  40ee31:	call   40bc30 <__swc_fn_e121059d_000016_4b207b58>
  40ee36:	jmp    40eebd <__swc_fn_e121059d_000014_afb279e2+0x11d>
  40ee3b:	mov    rcx,rdi
  40ee3e:	movzx  edx,dl
  40ee41:	call   40ed80 <__swc_fn_e121059d_000011_6493fbbc>
  40ee46:	test   r13,r13
  40ee49:	je     40eeb6 <__swc_fn_e121059d_000014_afb279e2+0x116>
  40ee4f:	mov    rcx,rax
  40ee52:	mov    rdx,r13
  40ee55:	call   410b90 <__swc_fn_e121059d_000113_759e9ceb>
  40ee5a:	mov    rcx,QWORD PTR [rip+0x151e7]        # 424048 <__swc_bss_base_e121059d+0x8>
  40ee61:	cs nop WORD PTR [rax+rax*1+0x0]
  40ee6b:	nop    DWORD PTR [rax+rax*1+0x0]
  40ee70:	mov    rdx,rcx
  40ee73:	sub    rdx,r13
  40ee76:	mov    rax,rcx
  40ee79:	lock cmpxchg QWORD PTR [r14],rdx
  40ee7e:	cmp    rax,rcx
  40ee81:	je     40ee88 <__swc_fn_e121059d_000014_afb279e2+0xe8>
  40ee83:	mov    rcx,rax
  40ee86:	jmp    40ee70 <__swc_fn_e121059d_000014_afb279e2+0xd0>
  40ee88:	lea    rcx,[rip+0x151d1]        # 424060 <__swc_bss_base_e121059d+0x20>
  40ee8f:	mov    rdx,QWORD PTR [rip+0x151ca]        # 424060 <__swc_bss_base_e121059d+0x20>
  40ee96:	cs nop WORD PTR [rax+rax*1+0x0]
  40eea0:	lea    r8,[rdx+0x1]
  40eea4:	mov    rax,rdx
  40eea7:	lock cmpxchg QWORD PTR [rcx],r8
  40eeac:	cmp    rax,rdx
  40eeaf:	je     40eeb6 <__swc_fn_e121059d_000014_afb279e2+0x116>
  40eeb1:	mov    rdx,rax
  40eeb4:	jmp    40eea0 <__swc_fn_e121059d_000014_afb279e2+0x100>
  40eeb6:	mov    DWORD PTR [rsi+0x3c],0x0
  40eebd:	mov    rcx,rdi
  40eec0:	mov    rdx,r12
  40eec3:	call   407600 <__swc_fn_e121059d_000018_7d1e8a10>
  40eec8:	pop    r14
  40eeca:	pop    r13
  40eecc:	pop    r12
  40eece:	pop    rdi
  40eecf:	pop    rsi
  40eed0:	ret
	...

000000000040eee0 <__swc_fn_e121059d_000017_4df2d1a0>:
  40eee0:	mov    r8,QWORD PTR [rcx+0x48]
  40eee4:	test   r8,rdx
  40eee7:	je     40ef18 <__swc_fn_e121059d_000017_4df2d1a0+0x38>
  40eee9:	nop    DWORD PTR [rax+0x0]
  40eef0:	mov    rax,rdx
  40eef3:	not    rax
  40eef6:	mov    r9,r8
  40eef9:	and    r9,rax
  40eefc:	mov    rax,r8
  40eeff:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40ef05:	cmp    rax,r8
  40ef08:	jne    40ef10 <__swc_fn_e121059d_000017_4df2d1a0+0x30>
  40ef0a:	mov    eax,0x1
  40ef0f:	ret
  40ef10:	mov    r8,rax
  40ef13:	test   rax,rdx
  40ef16:	jne    40eef0 <__swc_fn_e121059d_000017_4df2d1a0+0x10>
  40ef18:	xor    eax,eax
  40ef1a:	ret
  40ef1b:	add    BYTE PTR [rax],al
  40ef1d:	add    BYTE PTR [rax],al
	...

000000000040ef20 <__swc_fn_e121059d_000020_a66e8b97>:
  40ef20:	push   rsi
  40ef21:	push   rdi
  40ef22:	push   r12
  40ef24:	push   r13
  40ef26:	sub    rsp,0x8
  40ef2a:	mov    rsi,rdx
  40ef2d:	mov    rdi,rcx
  40ef30:	lea    r12,[rip+0x152b9]        # 4241f0 <__swc_bss_base_e121059d+0x1b0>
  40ef37:	mov    rcx,r12
  40ef3a:	call   40e100 <__swc_fn_e121059d_000136_e3032dc2>
  40ef3f:	xor    eax,eax
  40ef41:	mov    rcx,QWORD PTR [rip+0x152b0]        # 4241f8 <__swc_bss_base_e121059d+0x1b8>
  40ef48:	mov    r13,rcx
  40ef4b:	test   r13,r13
  40ef4e:	je     40ef9b <__swc_fn_e121059d_000020_a66e8b97+0x7b>
  40ef50:	mov    rcx,QWORD PTR [r13+0x10]
  40ef54:	cmp    DWORD PTR [r13+0x28],esi
  40ef58:	jne    40ef90 <__swc_fn_e121059d_000020_a66e8b97+0x70>
  40ef5a:	test   rax,rax
  40ef5d:	jne    40ef68 <__swc_fn_e121059d_000020_a66e8b97+0x48>
  40ef5f:	mov    QWORD PTR [rip+0x15292],rcx        # 4241f8 <__swc_bss_base_e121059d+0x1b8>
  40ef66:	jmp    40ef6c <__swc_fn_e121059d_000020_a66e8b97+0x4c>
  40ef68:	mov    QWORD PTR [rax+0x10],rcx
  40ef6c:	vxorps xmm0,xmm0,xmm0
  40ef70:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40ef76:	mov    QWORD PTR [r13+0x8],rdi
  40ef7a:	mov    rcx,r12
  40ef7d:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40ef82:	mov    rax,r13
  40ef85:	add    rsp,0x8
  40ef89:	pop    r13
  40ef8b:	pop    r12
  40ef8d:	pop    rdi
  40ef8e:	pop    rsi
  40ef8f:	ret
  40ef90:	mov    rax,r13
  40ef93:	mov    r13,rcx
  40ef96:	test   rcx,rcx
  40ef99:	jne    40ef50 <__swc_fn_e121059d_000020_a66e8b97+0x30>
  40ef9b:	mov    ecx,esi
  40ef9d:	call   40bc60 <__swc_fn_e121059d_000019_2cc1532c>
  40efa2:	mov    rsi,rax
  40efa5:	test   rax,rax
  40efa8:	jne    40efbf <__swc_fn_e121059d_000020_a66e8b97+0x9f>
  40efaa:	mov    rcx,r12
  40efad:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40efb2:	xor    eax,eax
  40efb4:	add    rsp,0x8
  40efb8:	pop    r13
  40efba:	pop    r12
  40efbc:	pop    rdi
  40efbd:	pop    rsi
  40efbe:	ret
  40efbf:	mov    QWORD PTR [rsi+0x8],rdi
  40efc3:	mov    rcx,r12
  40efc6:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40efcb:	mov    rax,rsi
  40efce:	add    rsp,0x8
  40efd2:	pop    r13
  40efd4:	pop    r12
  40efd6:	pop    rdi
  40efd7:	pop    rsi
  40efd8:	ret
  40efd9:	add    BYTE PTR [rax],al
  40efdb:	add    BYTE PTR [rax],al
  40efdd:	add    BYTE PTR [rax],al
	...

000000000040efe0 <__swc_fn_e121059d_000023_4aca8b9e>:
  40efe0:	vxorps xmm0,xmm0,xmm0
  40efe4:	xor    eax,eax
  40efe6:	cs nop WORD PTR [rax+rax*1+0x0]
  40eff0:	cs nop WORD PTR [rax+rax*1+0x0]
  40effa:	nop    WORD PTR [rax+rax*1+0x0]
  40f000:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40f005:	add    rax,0x10
  40f009:	cmp    rax,0x2b00
  40f010:	jne    40f000 <__swc_fn_e121059d_000023_4aca8b9e+0x20>
  40f012:	ret
	...

000000000040f020 <__swc_fn_e121059d_000026_4aca8b9e>:
  40f020:	vxorps xmm0,xmm0,xmm0
  40f024:	vmovups XMMWORD PTR [rcx],xmm0
  40f028:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f02d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f032:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f037:	ret
	...

000000000040f040 <__swc_fn_e121059d_000029_4aca8b9e>:
  40f040:	vxorps xmm0,xmm0,xmm0
  40f044:	vmovups XMMWORD PTR [rcx],xmm0
  40f048:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f04d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f052:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f057:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40f05c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40f061:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40f066:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40f06b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40f073:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40f07b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40f083:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40f08b:	mov    QWORD PTR [rcx+0xc0],0x0
  40f096:	ret
	...

000000000040f0a0 <__swc_fn_e121059d_000032_84881cd8>:
  40f0a0:	push   rsi
  40f0a1:	push   rdi
  40f0a2:	sub    rsp,0x8
  40f0a6:	mov    rsi,rcx
  40f0a9:	lea    rdi,[rip+0x12f50]        # 422000 <__swc_data_base_e121059d>
  40f0b0:	mov    rax,QWORD PTR [rdi]
  40f0b3:	cmp    rax,0xffffffffffffffff
  40f0b7:	je     40f0be <__swc_fn_e121059d_000032_84881cd8+0x1e>
  40f0b9:	mov    rdi,rax
  40f0bc:	jmp    40f0eb <__swc_fn_e121059d_000032_84881cd8+0x4b>
  40f0be:	call   40dde0 <__swc_fn_e121059d_000124_9d2cbd72>
  40f0c3:	mov    rcx,rax
  40f0c6:	cmp    rax,0xffffffffffffffff
  40f0ca:	je     40f0fc <__swc_fn_e121059d_000032_84881cd8+0x5c>
  40f0cc:	mov    rax,0xffffffffffffffff
  40f0d3:	lock cmpxchg QWORD PTR [rdi],rcx
  40f0d8:	cmp    rax,0xffffffffffffffff
  40f0dc:	je     40f0e8 <__swc_fn_e121059d_000032_84881cd8+0x48>
  40f0de:	mov    rdi,rax
  40f0e1:	call   410f70 <__swc_fn_e121059d_000125_667fbf24>
  40f0e6:	jmp    40f0eb <__swc_fn_e121059d_000032_84881cd8+0x4b>
  40f0e8:	mov    rdi,rcx
  40f0eb:	cmp    rdi,0xffffffffffffffff
  40f0ef:	je     40f0fc <__swc_fn_e121059d_000032_84881cd8+0x5c>
  40f0f1:	mov    rcx,rdi
  40f0f4:	mov    rdx,rsi
  40f0f7:	call   409b50 <__swc_fn_e121059d_000126_ce762363>
  40f0fc:	add    rsp,0x8
  40f100:	pop    rdi
  40f101:	pop    rsi
  40f102:	ret
	...

000000000040f110 <__swc_fn_e121059d_000035_95622a2b>:
  40f110:	sub    rsp,0x38
  40f114:	mov    rax,rdx
  40f117:	test   dl,dl
  40f119:	jne    40f131 <__swc_fn_e121059d_000035_95622a2b+0x21>
  40f11b:	mov    rax,r8
  40f11e:	test   r8b,r8b
  40f121:	cmove  eax,r9d
  40f125:	test   al,al
  40f127:	cmove  eax,r10d
  40f12b:	test   al,al
  40f12d:	cmove  eax,r11d
  40f131:	test   al,al
  40f133:	jne    40f13a <__swc_fn_e121059d_000035_95622a2b+0x2a>
  40f135:	add    rsp,0x38
  40f139:	ret
  40f13a:	lea    rcx,[rip+0x3fcf]        # 413110 <__swc_rdata_base_e121059d>
  40f141:	vmovups xmm0,XMMWORD PTR [rip+0x3fd7]        # 413120 <__swc_rdata_base_e121059d+0x10>
  40f149:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f14f:	vmovups xmm0,XMMWORD PTR [rip+0x3fd9]        # 413130 <__swc_rdata_base_e121059d+0x20>
  40f157:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f15d:	vmovups xmm0,XMMWORD PTR [rip+0x3fdb]        # 413140 <__swc_rdata_base_e121059d+0x30>
  40f165:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40f16b:	lea    rdx,[rsp+0x8]
  40f170:	call   40d880 <__swc_fn_e121059d_000103_67100064>
  40f175:	jmp    40f135 <__swc_fn_e121059d_000035_95622a2b+0x25>
	...

000000000040f180 <__swc_fn_e121059d_000038_788ceb38>:
  40f180:	sub    rsp,0x8
  40f184:	mov    eax,0x1000
  40f189:	test   eax,eax
  40f18b:	mov    r8d,0x8
  40f191:	cmove  eax,r8d
  40f195:	dec    rax
  40f198:	mov    r8,0xffffffffffffffff
  40f19f:	sub    r8,rax
  40f1a2:	cmp    rdx,r8
  40f1a5:	ja     40f1b5 <__swc_fn_e121059d_000038_788ceb38+0x35>
  40f1a7:	add    rdx,rax
  40f1aa:	not    rax
  40f1ad:	mov    r8,rdx
  40f1b0:	and    r8,rax
  40f1b3:	jne    40f1bc <__swc_fn_e121059d_000038_788ceb38+0x3c>
  40f1b5:	xor    eax,eax
  40f1b7:	add    rsp,0x8
  40f1bb:	ret
  40f1bc:	mov    rdx,r8
  40f1bf:	call   40bf80 <__swc_fn_e121059d_000037_b4982903>
  40f1c4:	add    rsp,0x8
  40f1c8:	ret
  40f1c9:	add    BYTE PTR [rax],al
  40f1cb:	add    BYTE PTR [rax],al
  40f1cd:	add    BYTE PTR [rax],al
	...

000000000040f1d0 <__swc_fn_e121059d_000041_414cc921>:
  40f1d0:	push   rsi
  40f1d1:	push   rdi
  40f1d2:	sub    rsp,0x8
  40f1d6:	mov    rsi,rdx
  40f1d9:	mov    rdi,rcx
  40f1dc:	test   rdx,rdx
  40f1df:	je     40f1fb <__swc_fn_e121059d_000041_414cc921+0x2b>
  40f1e1:	xor    ecx,ecx
  40f1e3:	call   407720 <__swc_fn_e121059d_000033_7ca1566d>
  40f1e8:	mov    rax,QWORD PTR [rsi]
  40f1eb:	test   rax,rax
  40f1ee:	je     40f1fb <__swc_fn_e121059d_000041_414cc921+0x2b>
  40f1f0:	mov    rcx,rax
  40f1f3:	mov    rdx,rsi
  40f1f6:	call   407840 <__swc_fn_e121059d_000042_bab03645>
  40f1fb:	mov    rcx,rdi
  40f1fe:	call   40bfe0 <__swc_fn_e121059d_000040_6895916d>
  40f203:	mov    rsi,rax
  40f206:	test   rax,rax
  40f209:	jne    40f214 <__swc_fn_e121059d_000041_414cc921+0x44>
  40f20b:	xor    eax,eax
  40f20d:	add    rsp,0x8
  40f211:	pop    rdi
  40f212:	pop    rsi
  40f213:	ret
  40f214:	mov    rcx,rsi
  40f217:	call   407720 <__swc_fn_e121059d_000033_7ca1566d>
  40f21c:	mov    rax,rsi
  40f21f:	add    rsp,0x8
  40f223:	pop    rdi
  40f224:	pop    rsi
  40f225:	ret
	...

000000000040f230 <__swc_fn_e121059d_000044_9c2ade9b>:
  40f230:	movzx  eax,BYTE PTR [r8+0x39]
  40f235:	lea    rax,[rax+rax*4]
  40f239:	lea    rax,[rdx+rax*8+0x28]
  40f23e:	mov    ecx,DWORD PTR [r8+0x6c]
  40f242:	test   ecx,ecx
  40f244:	je     40f27d <__swc_fn_e121059d_000044_9c2ade9b+0x4d>
  40f246:	mov    rcx,QWORD PTR [r8+0x50]
  40f24a:	test   rcx,rcx
  40f24d:	je     40f259 <__swc_fn_e121059d_000044_9c2ade9b+0x29>
  40f24f:	mov    rax,QWORD PTR [r8+0x48]
  40f253:	mov    QWORD PTR [rcx+0x48],rax
  40f257:	jmp    40f261 <__swc_fn_e121059d_000044_9c2ade9b+0x31>
  40f259:	mov    rcx,QWORD PTR [r8+0x48]
  40f25d:	mov    QWORD PTR [rax+0x18],rcx
  40f261:	mov    rax,QWORD PTR [r8+0x48]
  40f265:	test   rax,rax
  40f268:	je     40f272 <__swc_fn_e121059d_000044_9c2ade9b+0x42>
  40f26a:	mov    rcx,QWORD PTR [r8+0x50]
  40f26e:	mov    QWORD PTR [rax+0x50],rcx
  40f272:	vxorps xmm0,xmm0,xmm0
  40f276:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40f27c:	ret
  40f27d:	mov    rcx,QWORD PTR [r8+0x50]
  40f281:	test   rcx,rcx
  40f284:	je     40f290 <__swc_fn_e121059d_000044_9c2ade9b+0x60>
  40f286:	mov    rdx,QWORD PTR [r8+0x48]
  40f28a:	mov    QWORD PTR [rcx+0x48],rdx
  40f28e:	jmp    40f298 <__swc_fn_e121059d_000044_9c2ade9b+0x68>
  40f290:	mov    rcx,QWORD PTR [r8+0x48]
  40f294:	mov    QWORD PTR [rax+0x8],rcx
  40f298:	mov    rcx,QWORD PTR [r8+0x48]
  40f29c:	test   rcx,rcx
  40f29f:	je     40f2ab <__swc_fn_e121059d_000044_9c2ade9b+0x7b>
  40f2a1:	mov    rdx,QWORD PTR [r8+0x50]
  40f2a5:	mov    QWORD PTR [rcx+0x50],rdx
  40f2a9:	jmp    40f2b3 <__swc_fn_e121059d_000044_9c2ade9b+0x83>
  40f2ab:	mov    rcx,QWORD PTR [r8+0x50]
  40f2af:	mov    QWORD PTR [rax+0x10],rcx
  40f2b3:	cmp    QWORD PTR [rax],r8
  40f2b6:	jne    40f2bf <__swc_fn_e121059d_000044_9c2ade9b+0x8f>
  40f2b8:	mov    QWORD PTR [rax],0x0
  40f2bf:	vxorps xmm0,xmm0,xmm0
  40f2c3:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40f2c9:	ret
  40f2ca:	add    BYTE PTR [rax],al
  40f2cc:	add    BYTE PTR [rax],al
	...

000000000040f2d0 <__swc_fn_e121059d_000047_bc5ec610>:
  40f2d0:	sub    rsp,0x8
  40f2d4:	mov    r9,r8
  40f2d7:	mov    r10,rdx
  40f2da:	call   40f230 <__swc_fn_e121059d_000044_9c2ade9b>
  40f2df:	mov    DWORD PTR [r9+0x6c],0x0
  40f2e7:	movzx  eax,BYTE PTR [r9+0x39]
  40f2ec:	lea    rax,[rax+rax*4]
  40f2f0:	lea    rax,[r10+rax*8+0x28]
  40f2f5:	mov    rcx,QWORD PTR [rax+0x10]
  40f2f9:	mov    QWORD PTR [r9+0x50],rcx
  40f2fd:	mov    QWORD PTR [r9+0x48],0x0
  40f305:	mov    rcx,QWORD PTR [rax+0x10]
  40f309:	test   rcx,rcx
  40f30c:	je     40f314 <__swc_fn_e121059d_000047_bc5ec610+0x44>
  40f30e:	mov    QWORD PTR [rcx+0x48],r9
  40f312:	jmp    40f318 <__swc_fn_e121059d_000047_bc5ec610+0x48>
  40f314:	mov    QWORD PTR [rax+0x8],r9
  40f318:	mov    QWORD PTR [rax+0x10],r9
  40f31c:	add    rsp,0x8
  40f320:	ret
	...

000000000040f340 <__swc_fn_e121059d_000050_ab8077df>:
  40f340:	push   rsi
  40f341:	push   rdi
  40f342:	push   r12
  40f344:	push   r13
  40f346:	push   r14
  40f348:	push   r15
  40f34a:	sub    rsp,0x1f8
  40f351:	mov    esi,r8d
  40f354:	mov    QWORD PTR [rsp+0x1e8],rsi
  40f35c:	mov    rdi,rcx
  40f35f:	mov    r12,rdx
  40f362:	lea    r13,[rsi+rsi*4]
  40f366:	lea    r13,[rdx+r13*8+0x28]
  40f36b:	call   407ca0 <__swc_fn_e121059d_000048_c877e9d2>
  40f370:	add    DWORD PTR [r12+0x24],0x1
  40f376:	test   BYTE PTR [r12+0x24],0x3f
  40f37c:	jne    40f386 <__swc_fn_e121059d_000050_ab8077df+0x46>
  40f37e:	mov    rcx,rdi
  40f381:	call   40c160 <__swc_fn_e121059d_000049_2ff013cc>
  40f386:	mov    rax,QWORD PTR [r13+0x8]
  40f38a:	mov    r14,rax
  40f38d:	nop    DWORD PTR [rax]
  40f390:	test   r14,r14
  40f393:	jne    40f3a2 <__swc_fn_e121059d_000050_ab8077df+0x62>
  40f395:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40f39d:	jmp    40f4a9 <__swc_fn_e121059d_000050_ab8077df+0x169>
  40f3a2:	mov    r15,QWORD PTR [r14+0x48]
  40f3a6:	mov    rcx,r14
  40f3a9:	call   4073f0 <__swc_fn_e121059d_000009_d7e2bb25>
  40f3ae:	mov    rax,QWORD PTR [r14]
  40f3b1:	test   rax,rax
  40f3b4:	je     40f3c6 <__swc_fn_e121059d_000050_ab8077df+0x86>
  40f3b6:	mov    rcx,QWORD PTR [rax]
  40f3b9:	mov    QWORD PTR [r14],rcx
  40f3bc:	add    DWORD PTR [r14+0x28],0x1
  40f3c1:	mov    rsi,rax
  40f3c4:	jmp    40f3e5 <__swc_fn_e121059d_000050_ab8077df+0xa5>
  40f3c6:	mov    rax,QWORD PTR [r14+0x18]
  40f3ca:	cmp    QWORD PTR [r14+0x20],rax
  40f3ce:	jae    40f3e3 <__swc_fn_e121059d_000050_ab8077df+0xa3>
  40f3d0:	mov    rsi,QWORD PTR [r14+0x20]
  40f3d4:	mov    eax,DWORD PTR [r14+0x2c]
  40f3d8:	add    QWORD PTR [r14+0x20],rax
  40f3dc:	add    DWORD PTR [r14+0x28],0x1
  40f3e1:	jmp    40f3e5 <__swc_fn_e121059d_000050_ab8077df+0xa5>
  40f3e3:	xor    esi,esi
  40f3e5:	test   rsi,rsi
  40f3e8:	jne    40f42d <__swc_fn_e121059d_000050_ab8077df+0xed>
  40f3ea:	mov    rcx,r14
  40f3ed:	call   407320 <__swc_fn_e121059d_000006_a23dca5f>
  40f3f2:	test   al,al
  40f3f4:	je     40f42d <__swc_fn_e121059d_000050_ab8077df+0xed>
  40f3f6:	mov    rax,QWORD PTR [r14]
  40f3f9:	test   rax,rax
  40f3fc:	je     40f40b <__swc_fn_e121059d_000050_ab8077df+0xcb>
  40f3fe:	mov    rcx,QWORD PTR [rax]
  40f401:	mov    QWORD PTR [r14],rcx
  40f404:	add    DWORD PTR [r14+0x28],0x1
  40f409:	jmp    40f42a <__swc_fn_e121059d_000050_ab8077df+0xea>
  40f40b:	mov    rax,QWORD PTR [r14+0x18]
  40f40f:	cmp    QWORD PTR [r14+0x20],rax
  40f413:	jae    40f428 <__swc_fn_e121059d_000050_ab8077df+0xe8>
  40f415:	mov    rax,QWORD PTR [r14+0x20]
  40f419:	mov    ecx,DWORD PTR [r14+0x2c]
  40f41d:	add    QWORD PTR [r14+0x20],rcx
  40f421:	add    DWORD PTR [r14+0x28],0x1
  40f426:	jmp    40f42a <__swc_fn_e121059d_000050_ab8077df+0xea>
  40f428:	xor    eax,eax
  40f42a:	mov    rsi,rax
  40f42d:	test   rsi,rsi
  40f430:	jne    40f483 <__swc_fn_e121059d_000050_ab8077df+0x143>
  40f432:	mov    rcx,rdi
  40f435:	mov    rdx,r12
  40f438:	mov    r8,r14
  40f43b:	call   40c0c0 <__swc_fn_e121059d_000046_88f44774>
  40f440:	test   al,al
  40f442:	jne    40f483 <__swc_fn_e121059d_000050_ab8077df+0x143>
  40f444:	mov    rcx,r14
  40f447:	call   4073f0 <__swc_fn_e121059d_000009_d7e2bb25>
  40f44c:	mov    rax,QWORD PTR [r14]
  40f44f:	test   rax,rax
  40f452:	je     40f461 <__swc_fn_e121059d_000050_ab8077df+0x121>
  40f454:	mov    rcx,QWORD PTR [rax]
  40f457:	mov    QWORD PTR [r14],rcx
  40f45a:	add    DWORD PTR [r14+0x28],0x1
  40f45f:	jmp    40f480 <__swc_fn_e121059d_000050_ab8077df+0x140>
  40f461:	mov    rax,QWORD PTR [r14+0x18]
  40f465:	cmp    QWORD PTR [r14+0x20],rax
  40f469:	jae    40f47e <__swc_fn_e121059d_000050_ab8077df+0x13e>
  40f46b:	mov    rax,QWORD PTR [r14+0x20]
  40f46f:	mov    ecx,DWORD PTR [r14+0x2c]
  40f473:	add    QWORD PTR [r14+0x20],rcx
  40f477:	add    DWORD PTR [r14+0x28],0x1
  40f47c:	jmp    40f480 <__swc_fn_e121059d_000050_ab8077df+0x140>
  40f47e:	xor    eax,eax
  40f480:	mov    rsi,rax
  40f483:	test   rsi,rsi
  40f486:	je     40f4a1 <__swc_fn_e121059d_000050_ab8077df+0x161>
  40f488:	mov    QWORD PTR [r13+0x0],r14
  40f48c:	mov    rax,rsi
  40f48f:	add    rsp,0x1f8
  40f496:	pop    r15
  40f498:	pop    r14
  40f49a:	pop    r13
  40f49c:	pop    r12
  40f49e:	pop    rdi
  40f49f:	pop    rsi
  40f4a0:	ret
  40f4a1:	mov    r14,r15
  40f4a4:	jmp    40f390 <__swc_fn_e121059d_000050_ab8077df+0x50>
  40f4a9:	cs nop WORD PTR [rax+rax*1+0x0]
  40f4b3:	cs nop WORD PTR [rax+rax*1+0x0]
  40f4bd:	nop    DWORD PTR [rax]
  40f4c0:	mov    rcx,rdi
  40f4c3:	mov    rdx,r12
  40f4c6:	mov    r8d,esi
  40f4c9:	call   4079e0 <__swc_fn_e121059d_000045_1fe0f4e2>
  40f4ce:	mov    r14,rax
  40f4d1:	test   rax,rax
  40f4d4:	jne    40f4ea <__swc_fn_e121059d_000050_ab8077df+0x1aa>
  40f4d6:	xor    eax,eax
  40f4d8:	add    rsp,0x1f8
  40f4df:	pop    r15
  40f4e1:	pop    r14
  40f4e3:	pop    r13
  40f4e5:	pop    r12
  40f4e7:	pop    rdi
  40f4e8:	pop    rsi
  40f4e9:	ret
  40f4ea:	mov    QWORD PTR [r13+0x0],r14
  40f4ee:	mov    rax,QWORD PTR [r14]
  40f4f1:	test   rax,rax
  40f4f4:	je     40f506 <__swc_fn_e121059d_000050_ab8077df+0x1c6>
  40f4f6:	mov    rcx,QWORD PTR [rax]
  40f4f9:	mov    QWORD PTR [r14],rcx
  40f4fc:	add    DWORD PTR [r14+0x28],0x1
  40f501:	mov    r15,rax
  40f504:	jmp    40f526 <__swc_fn_e121059d_000050_ab8077df+0x1e6>
  40f506:	mov    rax,QWORD PTR [r14+0x18]
  40f50a:	cmp    QWORD PTR [r14+0x20],rax
  40f50e:	jae    40f523 <__swc_fn_e121059d_000050_ab8077df+0x1e3>
  40f510:	mov    r15,QWORD PTR [r14+0x20]
  40f514:	mov    eax,DWORD PTR [r14+0x2c]
  40f518:	add    QWORD PTR [r14+0x20],rax
  40f51c:	add    DWORD PTR [r14+0x28],0x1
  40f521:	jmp    40f526 <__swc_fn_e121059d_000050_ab8077df+0x1e6>
  40f523:	xor    r15d,r15d
  40f526:	test   r15,r15
  40f529:	jne    40f56e <__swc_fn_e121059d_000050_ab8077df+0x22e>
  40f52b:	mov    rcx,r14
  40f52e:	call   407320 <__swc_fn_e121059d_000006_a23dca5f>
  40f533:	test   al,al
  40f535:	je     40f56e <__swc_fn_e121059d_000050_ab8077df+0x22e>
  40f537:	mov    rax,QWORD PTR [r14]
  40f53a:	test   rax,rax
  40f53d:	je     40f54c <__swc_fn_e121059d_000050_ab8077df+0x20c>
  40f53f:	mov    rcx,QWORD PTR [rax]
  40f542:	mov    QWORD PTR [r14],rcx
  40f545:	add    DWORD PTR [r14+0x28],0x1
  40f54a:	jmp    40f56b <__swc_fn_e121059d_000050_ab8077df+0x22b>
  40f54c:	mov    rax,QWORD PTR [r14+0x18]
  40f550:	cmp    QWORD PTR [r14+0x20],rax
  40f554:	jae    40f569 <__swc_fn_e121059d_000050_ab8077df+0x229>
  40f556:	mov    rax,QWORD PTR [r14+0x20]
  40f55a:	mov    ecx,DWORD PTR [r14+0x2c]
  40f55e:	add    QWORD PTR [r14+0x20],rcx
  40f562:	add    DWORD PTR [r14+0x28],0x1
  40f567:	jmp    40f56b <__swc_fn_e121059d_000050_ab8077df+0x22b>
  40f569:	xor    eax,eax
  40f56b:	mov    r15,rax
  40f56e:	test   r15,r15
  40f571:	je     40f4c0 <__swc_fn_e121059d_000050_ab8077df+0x180>
  40f577:	mov    rax,r15
  40f57a:	add    rsp,0x1f8
  40f581:	pop    r15
  40f583:	pop    r14
  40f585:	pop    r13
  40f587:	pop    r12
  40f589:	pop    rdi
  40f58a:	pop    rsi
  40f58b:	ret
  40f58c:	add    BYTE PTR [rax],al
	...

000000000040f590 <__swc_fn_e121059d_000053_82546d94>:
  40f590:	push   rsi
  40f591:	push   rdi
  40f592:	push   r12
  40f594:	mov    rsi,rdx
  40f597:	mov    rax,rdx
  40f59a:	shr    rax,0xc
  40f59e:	movabs rdx,0x9e3779b97f4a7c15
  40f5a8:	imul   rax,rdx
  40f5ac:	shr    rax,0x20
  40f5b0:	lea    rax,[rax*8+0x0]
  40f5b8:	shr    rax,0x20
  40f5bc:	lea    rax,[rax*8+0x0]
  40f5c4:	lea    rax,[rcx+rax*8+0x40]
  40f5c9:	xor    edx,edx
  40f5cb:	test   dl,dl
  40f5cd:	lea    rdi,[rcx+0x8]
  40f5d1:	cmove  rdi,rax
  40f5d5:	xor    edx,edx
  40f5d7:	test   dl,dl
  40f5d9:	lea    r12,[rcx+0x30]
  40f5dd:	lea    rax,[rax+0x8]
  40f5e1:	cmove  r12,rax
  40f5e5:	mov    rcx,rdi
  40f5e8:	call   40e100 <__swc_fn_e121059d_000136_e3032dc2>
  40f5ed:	mov    QWORD PTR [rsi+0x30],0x0
  40f5f5:	mov    rax,QWORD PTR [r12]
  40f5f9:	mov    QWORD PTR [rsi+0x38],rax
  40f5fd:	test   rax,rax
  40f600:	je     40f60a <__swc_fn_e121059d_000053_82546d94+0x7a>
  40f602:	mov    rax,QWORD PTR [rsi+0x38]
  40f606:	mov    QWORD PTR [rax+0x30],rsi
  40f60a:	mov    QWORD PTR [r12],rsi
  40f60e:	mov    rcx,rdi
  40f611:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40f616:	pop    r12
  40f618:	pop    rdi
  40f619:	pop    rsi
  40f61a:	ret
  40f61b:	add    BYTE PTR [rax],al
  40f61d:	add    BYTE PTR [rax],al
	...

000000000040f620 <__swc_fn_e121059d_000056_38b21f11>:
  40f620:	lea    rax,[rdx+rdx*4]
  40f624:	lea    rax,[rcx+rax*8+0x268]
  40f62c:	mov    rdx,QWORD PTR [rax+0x10]
  40f630:	sub    QWORD PTR [rcx+0x2a68],rdx
  40f637:	sub    QWORD PTR [rcx+0x2a70],0x1
  40f63f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40f646:	lea    rdx,[rdx+rdx*4]
  40f64a:	lea    rdx,[rcx+rdx*8+0x268]
  40f652:	vmovups xmm0,XMMWORD PTR [rdx]
  40f656:	vmovups XMMWORD PTR [rax],xmm0
  40f65a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40f65f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40f664:	mov    rcx,QWORD PTR [rdx+0x20]
  40f668:	mov    QWORD PTR [rax+0x20],rcx
  40f66c:	ret
  40f66d:	add    BYTE PTR [rax],al
	...

000000000040f670 <__swc_fn_e121059d_000059_3ca3ac64>:
  40f670:	push   rsi
  40f671:	push   rdi
  40f672:	push   r12
  40f674:	push   r13
  40f676:	sub    rsp,0x8
  40f67a:	mov    rsi,r8
  40f67d:	mov    rdi,rcx
  40f680:	mov    r12,rdx
  40f683:	xor    r13d,r13d
  40f686:	cs nop WORD PTR [rax+rax*1+0x0]
  40f690:	mov    eax,DWORD PTR [r12+0x730]
  40f698:	cmp    r13d,eax
  40f69b:	jae    40f701 <__swc_fn_e121059d_000059_3ca3ac64+0x91>
  40f69d:	lea    rax,[r13+r13*4+0x0]
  40f6a2:	lea    rax,[r12+rax*8+0x738]
  40f6aa:	mov    rdx,QWORD PTR [rax]
  40f6ad:	mov    r8,QWORD PTR [rax+0x8]
  40f6b1:	mov    r9,QWORD PTR [rax+0x10]
  40f6b5:	cmp    QWORD PTR [rax+0x20],rsi
  40f6b9:	jb     40f6c0 <__swc_fn_e121059d_000059_3ca3ac64+0x50>
  40f6bb:	inc    r13d
  40f6be:	jmp    40f690 <__swc_fn_e121059d_000059_3ca3ac64+0x20>
  40f6c0:	sub    DWORD PTR [r12+0x730],0x1
  40f6c9:	mov    ecx,DWORD PTR [r12+0x730]
  40f6d1:	lea    rcx,[rcx+rcx*4]
  40f6d5:	lea    rcx,[r12+rcx*8+0x738]
  40f6dd:	vmovups xmm0,XMMWORD PTR [rcx]
  40f6e1:	vmovups XMMWORD PTR [rax],xmm0
  40f6e5:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40f6ea:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40f6ef:	mov    rcx,QWORD PTR [rcx+0x20]
  40f6f3:	mov    QWORD PTR [rax+0x20],rcx
  40f6f7:	mov    rcx,rdi
  40f6fa:	call   407750 <__swc_fn_e121059d_000039_40d1e569>
  40f6ff:	jmp    40f690 <__swc_fn_e121059d_000059_3ca3ac64+0x20>
  40f701:	add    rsp,0x8
  40f705:	pop    r13
  40f707:	pop    r12
  40f709:	pop    rdi
  40f70a:	pop    rsi
  40f70b:	ret
  40f70c:	add    BYTE PTR [rax],al
	...

000000000040f710 <__swc_fn_e121059d_000062_7e482c5f>:
  40f710:	push   rsi
  40f711:	push   rdi
  40f712:	push   r12
  40f714:	push   r13
  40f716:	push   r14
  40f718:	mov    rsi,rcx
  40f71b:	mov    rdi,rdx
  40f71e:	mov    r12,QWORD PTR [rdi]
  40f721:	mov    r13,QWORD PTR [rdi+0x18]
  40f725:	mov    rax,r12
  40f728:	add    rax,QWORD PTR [rdi+0x8]
  40f72c:	sub    rax,r13
  40f72f:	cmp    r8,rax
  40f732:	jbe    40f73d <__swc_fn_e121059d_000062_7e482c5f+0x2d>
  40f734:	pop    r14
  40f736:	pop    r13
  40f738:	pop    r12
  40f73a:	pop    rdi
  40f73b:	pop    rsi
  40f73c:	ret
  40f73d:	lea    rax,[r13+r8*1+0x0]
  40f742:	sub    rax,r12
  40f745:	mov    ecx,0x1000
  40f74a:	test   ecx,ecx
  40f74c:	mov    edx,0x8
  40f751:	cmove  ecx,edx
  40f754:	dec    rcx
  40f757:	mov    rdx,0xffffffffffffffff
  40f75e:	sub    rdx,rcx
  40f761:	cmp    rax,rdx
  40f764:	jbe    40f76b <__swc_fn_e121059d_000062_7e482c5f+0x5b>
  40f766:	xor    r14d,r14d
  40f769:	jmp    40f776 <__swc_fn_e121059d_000062_7e482c5f+0x66>
  40f76b:	add    rax,rcx
  40f76e:	andn   rax,rcx,rax
  40f773:	mov    r14,rax
  40f776:	mov    rax,QWORD PTR [rdi+0x10]
  40f77a:	cmp    r14,rax
  40f77d:	ja     40f788 <__swc_fn_e121059d_000062_7e482c5f+0x78>
  40f77f:	pop    r14
  40f781:	pop    r13
  40f783:	pop    r12
  40f785:	pop    rdi
  40f786:	pop    rsi
  40f787:	ret
  40f788:	mov    rax,r12
  40f78b:	add    rax,QWORD PTR [rdi+0x10]
  40f78f:	mov    rdx,r14
  40f792:	sub    rdx,QWORD PTR [rdi+0x10]
  40f796:	mov    rcx,rax
  40f799:	call   4072a0 <__swc_fn_e121059d_000003_7ab4792e>
  40f79e:	test   al,al
  40f7a0:	jne    40f7ab <__swc_fn_e121059d_000062_7e482c5f+0x9b>
  40f7a2:	pop    r14
  40f7a4:	pop    r13
  40f7a6:	pop    r12
  40f7a8:	pop    rdi
  40f7a9:	pop    rsi
  40f7aa:	ret
  40f7ab:	add    r12,r14
  40f7ae:	sub    r12,r13
  40f7b1:	mov    rcx,r12
  40f7b4:	sub    rcx,QWORD PTR [rdi+0x28]
  40f7b8:	mov    rdx,QWORD PTR [rsi+0x250]
  40f7bf:	nop
  40f7c0:	lea    r8,[rdx+rcx*1]
  40f7c4:	mov    rax,rdx
  40f7c7:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40f7d0:	cmp    rax,rdx
  40f7d3:	je     40f7da <__swc_fn_e121059d_000062_7e482c5f+0xca>
  40f7d5:	mov    rdx,rax
  40f7d8:	jmp    40f7c0 <__swc_fn_e121059d_000062_7e482c5f+0xb0>
  40f7da:	mov    QWORD PTR [rdi+0x10],r14
  40f7de:	mov    QWORD PTR [rdi+0x28],r12
  40f7e2:	pop    r14
  40f7e4:	pop    r13
  40f7e6:	pop    r12
  40f7e8:	pop    rdi
  40f7e9:	pop    rsi
  40f7ea:	ret
  40f7eb:	add    BYTE PTR [rax],al
  40f7ed:	add    BYTE PTR [rax],al
	...

000000000040f7f0 <__swc_fn_e121059d_000065_f9f4b610>:
  40f7f0:	push   rbx
  40f7f1:	push   rsi
  40f7f2:	push   rdi
  40f7f3:	push   r12
  40f7f5:	push   r13
  40f7f7:	sub    rsp,0xe0
  40f7fe:	mov    rbx,rdx
  40f801:	mov    rsi,rcx
  40f804:	cmp    DWORD PTR [rbx+0x58],0x0
  40f808:	je     40f82c <__swc_fn_e121059d_000065_f9f4b610+0x3c>
  40f80a:	mov    eax,DWORD PTR [rbx+0x58]
  40f80d:	sub    eax,0x1
  40f810:	test   DWORD PTR [rbx+0x58],eax
  40f813:	je     40f82c <__swc_fn_e121059d_000065_f9f4b610+0x3c>
  40f815:	mov    QWORD PTR [rbx+0x40],0x0
  40f81d:	add    rsp,0xe0
  40f824:	pop    r13
  40f826:	pop    r12
  40f828:	pop    rdi
  40f829:	pop    rsi
  40f82a:	pop    rbx
  40f82b:	ret
  40f82c:	mov    rax,QWORD PTR [rbx+0x40]
  40f830:	test   rax,rax
  40f833:	jne    40f84f <__swc_fn_e121059d_000065_f9f4b610+0x5f>
  40f835:	mov    rcx,rsi
  40f838:	mov    rdx,rbx
  40f83b:	call   40cd70 <__swc_fn_e121059d_000064_b0d63361>
  40f840:	add    rsp,0xe0
  40f847:	pop    r13
  40f849:	pop    r12
  40f84b:	pop    rdi
  40f84c:	pop    rsi
  40f84d:	pop    rbx
  40f84e:	ret
  40f84f:	cmp    QWORD PTR [rbx+0x48],0x0
  40f854:	jne    40f870 <__swc_fn_e121059d_000065_f9f4b610+0x80>
  40f856:	mov    rcx,rsi
  40f859:	mov    rdx,rbx
  40f85c:	call   407f90 <__swc_fn_e121059d_000066_254b71af>
  40f861:	add    rsp,0xe0
  40f868:	pop    r13
  40f86a:	pop    r12
  40f86c:	pop    rdi
  40f86d:	pop    rsi
  40f86e:	pop    rbx
  40f86f:	ret
  40f870:	mov    rdi,QWORD PTR [rbx+0x40]
  40f874:	lea    rax,[rip+0x147f5]        # 424070 <__swc_bss_base_e121059d+0x30>
  40f87b:	mov    rcx,rdi
  40f87e:	sub    rcx,QWORD PTR [rax+0x8]
  40f882:	mov    rax,QWORD PTR [rip+0x147f7]        # 424080 <__swc_bss_base_e121059d+0x40>
  40f889:	cmp    rcx,rax
  40f88c:	jae    40f8b8 <__swc_fn_e121059d_000065_f9f4b610+0xc8>
  40f88e:	mov    rax,rdi
  40f891:	and    rax,0xffffffffffc00000
  40f898:	mov    rcx,rdi
  40f89b:	shr    rcx,0x10
  40f89f:	and    ecx,0x3f
  40f8a2:	mov    edx,DWORD PTR [rax+0x28]
  40f8a5:	shrx   ecx,ecx,edx
  40f8aa:	shl    rcx,0x4
  40f8ae:	lea    r12,[rax+rcx*8+0x80]
  40f8b6:	jmp    40f8c3 <__swc_fn_e121059d_000065_f9f4b610+0xd3>
  40f8b8:	mov    rcx,rdi
  40f8bb:	call   40bdf0 <__swc_fn_e121059d_000022_3a2e2048>
  40f8c0:	mov    r12,rax
  40f8c3:	test   r12,r12
  40f8c6:	je     40f8d5 <__swc_fn_e121059d_000065_f9f4b610+0xe5>
  40f8c8:	mov    eax,DWORD PTR [r12+0x2c]
  40f8cd:	mov    r9d,eax
  40f8d0:	mov    r13,rax
  40f8d3:	jmp    40f954 <__swc_fn_e121059d_000065_f9f4b610+0x164>
  40f8d5:	mov    rcx,rsi
  40f8d8:	mov    rdx,rdi
  40f8db:	call   40c400 <__swc_fn_e121059d_000052_c7484fb0>
  40f8e0:	mov    rcx,QWORD PTR [rax+0x28]
  40f8e4:	mov    r9,rcx
  40f8e7:	mov    rdx,QWORD PTR [rax+0x20]
  40f8eb:	mov    r13,rdx
  40f8ee:	cmp    QWORD PTR [rbx+0x48],rcx
  40f8f2:	jbe    40f92b <__swc_fn_e121059d_000065_f9f4b610+0x13b>
  40f8f4:	mov    ecx,DWORD PTR [rax+0x48]
  40f8f7:	cmp    DWORD PTR [rbx+0x58],ecx
  40f8fa:	ja     40f92b <__swc_fn_e121059d_000065_f9f4b610+0x13b>
  40f8fc:	mov    rcx,rsi
  40f8ff:	mov    rdx,rax
  40f902:	mov    r8,QWORD PTR [rbx+0x48]
  40f906:	mov    QWORD PTR [rsp+0xc8],r9
  40f90e:	mov    QWORD PTR [rsp+0xd0],rax
  40f916:	call   40f710 <__swc_fn_e121059d_000062_7e482c5f>
  40f91b:	mov    r9,QWORD PTR [rsp+0xc8]
  40f923:	mov    rax,QWORD PTR [rsp+0xd0]
  40f92b:	mov    rcx,QWORD PTR [rax+0x28]
  40f92f:	cmp    QWORD PTR [rbx+0x48],rcx
  40f933:	ja     40f954 <__swc_fn_e121059d_000065_f9f4b610+0x164>
  40f935:	mov    ecx,DWORD PTR [rax+0x48]
  40f938:	cmp    DWORD PTR [rbx+0x58],ecx
  40f93b:	ja     40f954 <__swc_fn_e121059d_000065_f9f4b610+0x164>
  40f93d:	mov    rcx,QWORD PTR [rbx+0x48]
  40f941:	mov    QWORD PTR [rax+0x20],rcx
  40f945:	add    rsp,0xe0
  40f94c:	pop    r13
  40f94e:	pop    r12
  40f950:	pop    rdi
  40f951:	pop    rsi
  40f952:	pop    rbx
  40f953:	ret
  40f954:	test   r12,r12
  40f957:	je     40f989 <__swc_fn_e121059d_000065_f9f4b610+0x199>
  40f959:	cmp    QWORD PTR [rbx+0x48],r9
  40f95d:	ja     40f989 <__swc_fn_e121059d_000065_f9f4b610+0x199>
  40f95f:	cmp    DWORD PTR [rbx+0x58],0x40
  40f963:	ja     40f989 <__swc_fn_e121059d_000065_f9f4b610+0x199>
  40f965:	cmp    DWORD PTR [rbx+0x58],0x0
  40f969:	je     40f976 <__swc_fn_e121059d_000065_f9f4b610+0x186>
  40f96b:	mov    ecx,DWORD PTR [rbx+0x58]
  40f96e:	dec    rcx
  40f971:	test   rdi,rcx
  40f974:	jne    40f989 <__swc_fn_e121059d_000065_f9f4b610+0x199>
  40f976:	mov    QWORD PTR [rbx+0x40],rdi
  40f97a:	add    rsp,0xe0
  40f981:	pop    r13
  40f983:	pop    r12
  40f985:	pop    rdi
  40f986:	pop    rsi
  40f987:	pop    rbx
  40f988:	ret
  40f989:	vmovups xmm0,XMMWORD PTR [rbx]
  40f98d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f993:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40f998:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f99e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40f9a3:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40f9a9:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40f9ae:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40f9b4:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40f9b9:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40f9bf:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40f9c4:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40f9ca:	mov    QWORD PTR [rsp+0x48],0x0
  40f9d3:	mov    rcx,rsi
  40f9d6:	lea    rdx,[rsp+0x8]
  40f9db:	call   40cd70 <__swc_fn_e121059d_000064_b0d63361>
  40f9e0:	mov    rax,QWORD PTR [rsp+0x48]
  40f9e5:	test   rax,rax
  40f9e8:	jne    40fa01 <__swc_fn_e121059d_000065_f9f4b610+0x211>
  40f9ea:	mov    QWORD PTR [rbx+0x40],0x0
  40f9f2:	add    rsp,0xe0
  40f9f9:	pop    r13
  40f9fb:	pop    r12
  40f9fd:	pop    rdi
  40f9fe:	pop    rsi
  40f9ff:	pop    rbx
  40fa00:	ret
  40fa01:	mov    rax,QWORD PTR [rbx+0x48]
  40fa05:	cmp    r13,rax
  40fa08:	cmovbe rax,r13
  40fa0c:	mov    rcx,QWORD PTR [rsp+0x48]
  40fa11:	mov    rdx,rdi
  40fa14:	mov    r8,rax
  40fa17:	call   40d940 <__swc_fn_e121059d_000106_6fd80914>
  40fa1c:	vmovups xmm0,XMMWORD PTR [rbx]
  40fa20:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40fa26:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40fa2b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40fa31:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40fa36:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40fa3f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40fa44:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40fa4d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40fa52:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40fa5b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40fa60:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40fa69:	mov    QWORD PTR [rsp+0xa8],rdi
  40fa71:	mov    rcx,rsi
  40fa74:	lea    rdx,[rsp+0x68]
  40fa79:	call   407f90 <__swc_fn_e121059d_000066_254b71af>
  40fa7e:	mov    rax,QWORD PTR [rsp+0x48]
  40fa83:	mov    QWORD PTR [rbx+0x40],rax
  40fa87:	add    rsp,0xe0
  40fa8e:	pop    r13
  40fa90:	pop    r12
  40fa92:	pop    rdi
  40fa93:	pop    rsi
  40fa94:	pop    rbx
  40fa95:	ret
	...

000000000040faa0 <__swc_fn_e121059d_000068_7d4c42bf>:
  40faa0:	push   r12
  40faa2:	push   rdi
  40faa3:	push   rsi
  40faa4:	push   r13
  40faa6:	push   r14
  40faa8:	sub    rsp,0x190
  40faaf:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40fab8:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40fac1:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40faca:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40fad3:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40fadc:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40fae5:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40faee:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40faf7:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40fb00:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40fb09:	mov    r12,rcx
  40fb0c:	lea    rax,[rip+0x124ed]        # 422000 <__swc_data_base_e121059d>
  40fb13:	mov    rax,QWORD PTR [rax]
  40fb16:	cmp    rax,0xffffffffffffffff
  40fb1a:	je     40fb29 <__swc_fn_e121059d_000068_7d4c42bf+0x89>
  40fb1c:	mov    eax,eax
  40fb1e:	mov    edi,eax
  40fb20:	xor    eax,eax
  40fb22:	call   407000 <pthread_getspecific@plt>
  40fb27:	jmp    40fb2b <__swc_fn_e121059d_000068_7d4c42bf+0x8b>
  40fb29:	xor    eax,eax
  40fb2b:	test   rax,rax
  40fb2e:	jne    40fb3d <__swc_fn_e121059d_000068_7d4c42bf+0x9d>
  40fb30:	call   40bec0 <__swc_fn_e121059d_000031_90860ff2>
  40fb35:	mov    rcx,rax
  40fb38:	call   409c00 <__swc_fn_e121059d_000129_41c3251c>
  40fb3d:	test   rax,rax
  40fb40:	je     40fb66 <__swc_fn_e121059d_000068_7d4c42bf+0xc6>
  40fb42:	cmp    QWORD PTR [rax],r12
  40fb45:	jne    40fb66 <__swc_fn_e121059d_000068_7d4c42bf+0xc6>
  40fb47:	xor    ecx,ecx
  40fb49:	mov    QWORD PTR [rsp+0xc8],rax
  40fb51:	call   407720 <__swc_fn_e121059d_000033_7ca1566d>
  40fb56:	mov    rdx,QWORD PTR [rsp+0xc8]
  40fb5e:	mov    rcx,r12
  40fb61:	call   407840 <__swc_fn_e121059d_000042_bab03645>
  40fb66:	lea    rsi,[r12+0x10]
  40fb6b:	mov    rcx,rsi
  40fb6e:	call   40e100 <__swc_fn_e121059d_000136_e3032dc2>
  40fb73:	mov    rdi,QWORD PTR [r12+0x20]
  40fb78:	test   rdi,rdi
  40fb7b:	je     40fbbe <__swc_fn_e121059d_000068_7d4c42bf+0x11e>
  40fb7d:	nop    DWORD PTR [rax]
  40fb80:	mov    rcx,r12
  40fb83:	mov    rdx,rdi
  40fb86:	call   40c080 <__swc_fn_e121059d_000043_957e4917>
  40fb8b:	mov    rcx,r12
  40fb8e:	mov    rdx,rdi
  40fb91:	mov    r8,0xffffffffffffffff
  40fb98:	call   40f670 <__swc_fn_e121059d_000059_3ca3ac64>
  40fb9d:	mov    rcx,r12
  40fba0:	mov    rdx,rdi
  40fba3:	mov    r8d,0x9b8
  40fba9:	mov    r9d,0x9b8
  40fbaf:	call   407750 <__swc_fn_e121059d_000039_40d1e569>
  40fbb4:	mov    rdi,QWORD PTR [r12+0x20]
  40fbb9:	test   rdi,rdi
  40fbbc:	jne    40fb80 <__swc_fn_e121059d_000068_7d4c42bf+0xe0>
  40fbbe:	xor    eax,eax
  40fbc0:	xchg   QWORD PTR [r12+0x2a80],rax
  40fbc8:	test   rax,rax
  40fbcb:	je     40fbf1 <__swc_fn_e121059d_000068_7d4c42bf+0x151>
  40fbcd:	cs nop WORD PTR [rax+rax*1+0x0]
  40fbd7:	nop    WORD PTR [rax+rax*1+0x0]
  40fbe0:	mov    rcx,rax
  40fbe3:	mov    rax,QWORD PTR [rax+0x78]
  40fbe7:	xor    edx,edx
  40fbe9:	xchg   DWORD PTR [rcx+0x70],edx
  40fbec:	test   rax,rax
  40fbef:	jne    40fbe0 <__swc_fn_e121059d_000068_7d4c42bf+0x140>
  40fbf1:	mov    rax,QWORD PTR [r12+0x18]
  40fbf6:	mov    rdi,rax
  40fbf9:	test   rdi,rdi
  40fbfc:	je     40fc91 <__swc_fn_e121059d_000068_7d4c42bf+0x1f1>
  40fc02:	cs nop WORD PTR [rax+rax*1+0x0]
  40fc0c:	nop    DWORD PTR [rax+0x0]
  40fc10:	mov    rax,QWORD PTR [rdi+0x10]
  40fc14:	mov    r8d,DWORD PTR [rdi+0x2c]
  40fc18:	xor    r9d,r9d
  40fc1b:	test   r8,r8
  40fc1e:	jbe    40fc7d <__swc_fn_e121059d_000068_7d4c42bf+0x1dd>
  40fc20:	mov    ecx,r9d
  40fc23:	shl    rcx,0x4
  40fc27:	lea    rdx,[rdi+rcx*8+0x80]
  40fc2f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40fc33:	je     40fc74 <__swc_fn_e121059d_000068_7d4c42bf+0x1d4>
  40fc35:	mov    DWORD PTR [rdx+0x28],0x0
  40fc3c:	mov    rcx,rdi
  40fc3f:	mov    QWORD PTR [rsp+0xd0],rax
  40fc47:	mov    QWORD PTR [rsp+0xd8],r8
  40fc4f:	mov    QWORD PTR [rsp+0xe0],r9
  40fc57:	call   40eda0 <__swc_fn_e121059d_000014_afb279e2>
  40fc5c:	mov    rax,QWORD PTR [rsp+0xd0]
  40fc64:	mov    r8,QWORD PTR [rsp+0xd8]
  40fc6c:	mov    r9,QWORD PTR [rsp+0xe0]
  40fc74:	add    r9,0x1
  40fc78:	cmp    r9,r8
  40fc7b:	jb     40fc20 <__swc_fn_e121059d_000068_7d4c42bf+0x180>
  40fc7d:	mov    rcx,rdi
  40fc80:	mov    rdi,rax
  40fc83:	call   407630 <__swc_fn_e121059d_000021_491ac000>
  40fc88:	test   rdi,rdi
  40fc8b:	jne    40fc10 <__swc_fn_e121059d_000068_7d4c42bf+0x170>
  40fc91:	mov    QWORD PTR [r12+0x18],0x0
  40fc9a:	mov    QWORD PTR [r12+0x28],0x0
  40fca3:	mov    rcx,rsi
  40fca6:	call   411270 <__swc_fn_e121059d_000137_3e875c27>
  40fcab:	mov    esi,0x8
  40fcb0:	xor    edi,edi
  40fcb2:	test   rsi,rsi
  40fcb5:	je     40fd12 <__swc_fn_e121059d_000068_7d4c42bf+0x272>
  40fcbb:	nop    DWORD PTR [rax+rax*1+0x0]
  40fcc0:	lea    r13,[rdi*8+0x0]
  40fcc8:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40fccd:	test   r14,r14
  40fcd0:	je     40fd08 <__swc_fn_e121059d_000068_7d4c42bf+0x268>
  40fcd2:	cs nop WORD PTR [rax+rax*1+0x0]
  40fcdc:	nop    DWORD PTR [rax+0x0]
  40fce0:	mov    rcx,r12
  40fce3:	mov    rdx,r14
  40fce6:	call   407df0 <__swc_fn_e121059d_000054_ae20ea33>
  40fceb:	mov    rcx,r12
  40fcee:	mov    rdx,QWORD PTR [r14]
  40fcf1:	mov    r8,QWORD PTR [r14+0x8]
  40fcf5:	mov    r9,QWORD PTR [r14+0x10]
  40fcf9:	call   407750 <__swc_fn_e121059d_000039_40d1e569>
  40fcfe:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40fd03:	test   r14,r14
  40fd06:	jne    40fce0 <__swc_fn_e121059d_000068_7d4c42bf+0x240>
  40fd08:	add    rdi,0x1
  40fd0c:	sub    rsi,0x1
  40fd10:	jne    40fcc0 <__swc_fn_e121059d_000068_7d4c42bf+0x220>
  40fd12:	mov    rcx,r12
  40fd15:	call   407ec0 <__swc_fn_e121059d_000060_e6407a0a>
  40fd1a:	lea    rcx,[r12+0x250]
  40fd22:	mov    rdx,QWORD PTR [rcx]
  40fd25:	mov    r8,QWORD PTR [r12+0x250]
  40fd2d:	nop    DWORD PTR [rax]
  40fd30:	mov    r9,r8
  40fd33:	sub    r9,rdx
  40fd36:	mov    rax,r8
  40fd39:	lock cmpxchg QWORD PTR [rcx],r9
  40fd3e:	cmp    rax,r8
  40fd41:	je     40fd48 <__swc_fn_e121059d_000068_7d4c42bf+0x2a8>
  40fd43:	mov    r8,rax
  40fd46:	jmp    40fd30 <__swc_fn_e121059d_000068_7d4c42bf+0x290>
  40fd48:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40fd51:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40fd5a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40fd63:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40fd6c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40fd75:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40fd7e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40fd87:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40fd90:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40fd99:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40fda2:	add    rsp,0x190
  40fda9:	pop    r14
  40fdab:	pop    r13
  40fdad:	pop    rsi
  40fdae:	pop    rdi
  40fdaf:	pop    r12
  40fdb1:	ret
	...

000000000040fdc0 <__swc_fn_e121059d_000071_0d1ef36f>:
  40fdc0:	sub    rsp,0x8
  40fdc4:	mov    QWORD PTR [rdx+0x40],0x0
  40fdcc:	call   40cd70 <__swc_fn_e121059d_000064_b0d63361>
  40fdd1:	add    rsp,0x8
  40fdd5:	ret
	...

000000000040fde0 <__swc_fn_e121059d_000074_518516c2>:
  40fde0:	sub    rsp,0x8
  40fde4:	call   407f90 <__swc_fn_e121059d_000066_254b71af>
  40fde9:	add    rsp,0x8
  40fded:	ret
	...

000000000040fdf0 <__swc_fn_e121059d_000077_8b8614a7>:
  40fdf0:	push   rbx
  40fdf1:	push   rsi
  40fdf2:	push   rdi
  40fdf3:	push   r12
  40fdf5:	push   r13
  40fdf7:	push   r14
  40fdf9:	push   r15
  40fdfb:	sub    rsp,0x20
  40fdff:	mov    rbx,r11
  40fe02:	mov    rsi,rcx
  40fe05:	mov    rdi,rdx
  40fe08:	mov    r12,r8
  40fe0b:	mov    r13,r9
  40fe0e:	mov    r14,r10
  40fe11:	mov    rcx,QWORD PTR [rip+0x16f28]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40fe18:	test   rcx,rcx
  40fe1b:	jne    40fe2d <__swc_fn_e121059d_000077_8b8614a7+0x3d>
  40fe1d:	call   40ea10 <__swc_fn_e121059d_000166_cf398896>
  40fe22:	lea    rcx,[rax+0x1]
  40fe26:	mov    QWORD PTR [rip+0x16f13],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  40fe2d:	dec    rcx
  40fe30:	call   40b6c0 <__swc_fn_e121059d_000168_fce60b2b>
  40fe35:	mov    r15,rax
  40fe38:	lea    r11,[rip+0x14401]        # 424240 <__swc_bss_base_e121059d+0x200>
  40fe3f:	mov    rcx,r11
  40fe42:	call   407740 <__swc_fn_e121059d_000036_8d895ba1>
  40fe47:	test   al,al
  40fe49:	jne    40fe5a <__swc_fn_e121059d_000077_8b8614a7+0x6a>
  40fe4b:	mov    rcx,r11
  40fe4e:	call   40bf20 <__swc_fn_e121059d_000034_25f19556>
  40fe53:	lea    r11,[rip+0x143e6]        # 424240 <__swc_bss_base_e121059d+0x200>
  40fe5a:	mov    rcx,r11
  40fe5d:	mov    rdx,rsi
  40fe60:	mov    r8,rdi
  40fe63:	mov    r9,r12
  40fe66:	mov    r10,r13
  40fe69:	mov    rsi,r11
  40fe6c:	mov    r11,r14
  40fe6f:	call   40f110 <__swc_fn_e121059d_000035_95622a2b>
  40fe74:	test   bl,bl
  40fe76:	je     40fe9d <__swc_fn_e121059d_000077_8b8614a7+0xad>
  40fe78:	mov    QWORD PTR [rsp+0x8],rsi
  40fe7d:	lea    rax,[rip+0x32cc]        # 413150 <__swc_rdata_base_e121059d+0x40>
  40fe84:	mov    QWORD PTR [rsp+0x10],rax
  40fe89:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40fe8f:	vmovups XMMWORD PTR [r15],xmm0
  40fe94:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40fe9d:	mov    rax,rsi
  40fea0:	add    rsp,0x20
  40fea4:	pop    r15
  40fea6:	pop    r14
  40fea8:	pop    r13
  40feaa:	pop    r12
  40feac:	pop    rdi
  40fead:	pop    rsi
  40feae:	pop    rbx
  40feaf:	ret

000000000040feb0 <__swc_fn_e121059d_000080_c1514492>:
  40feb0:	sub    rsp,0x8
  40feb4:	mov    rax,rcx
  40feb7:	test   rcx,rcx
  40feba:	jne    40fec1 <__swc_fn_e121059d_000080_c1514492+0x11>
  40febc:	add    rsp,0x8
  40fec0:	ret
  40fec1:	lea    rcx,[rax-0x10]
  40fec5:	mov    rax,QWORD PTR [rax-0x10]
  40fec9:	mov    rdx,rax
  40fecc:	call   4098a0 <__swc_fn_e121059d_000114_49b378a9>
  40fed1:	add    rsp,0x8
  40fed5:	ret
	...

000000000040fee0 <__swc_fn_e121059d_000083_31b501f2>:
  40fee0:	sub    rsp,0x8
  40fee4:	xor    r11d,r11d
  40fee7:	call   408250 <__swc_fn_e121059d_000084_ddf2b8a1>
  40feec:	add    rsp,0x8
  40fef0:	ret
	...

000000000040ff00 <__swc_fn_e121059d_000086_c45095aa>:
  40ff00:	push   rsi
  40ff01:	push   rdi
  40ff02:	push   r12
  40ff04:	push   r13
  40ff06:	push   r14
  40ff08:	push   r15
  40ff0a:	sub    rsp,0x68
  40ff0e:	mov    rsi,r9
  40ff11:	mov    rdi,rcx
  40ff14:	mov    r12,rdx
  40ff17:	mov    r13,r8
  40ff1a:	cmp    r8,r9
  40ff1d:	jne    40ff45 <__swc_fn_e121059d_000086_c45095aa+0x45>
  40ff1f:	mov    rcx,rdi
  40ff22:	mov    rdx,r12
  40ff25:	xor    r8d,r8d
  40ff28:	call   4085a0 <__swc_fn_e121059d_000090_a2d50c23>
  40ff2d:	test   al,al
  40ff2f:	je     40ff45 <__swc_fn_e121059d_000086_c45095aa+0x45>
  40ff31:	mov    eax,0x1
  40ff36:	add    rsp,0x68
  40ff3a:	pop    r15
  40ff3c:	pop    r14
  40ff3e:	pop    r13
  40ff40:	pop    r12
  40ff42:	pop    rdi
  40ff43:	pop    rsi
  40ff44:	ret
  40ff45:	cmp    BYTE PTR [r12+0x2c],0xe
  40ff4b:	je     40ff5e <__swc_fn_e121059d_000086_c45095aa+0x5e>
  40ff4d:	xor    eax,eax
  40ff4f:	add    rsp,0x68
  40ff53:	pop    r15
  40ff55:	pop    r14
  40ff57:	pop    r13
  40ff59:	pop    r12
  40ff5b:	pop    rdi
  40ff5c:	pop    rsi
  40ff5d:	ret
  40ff5e:	mov    r14,QWORD PTR [r12+0x98]
  40ff66:	mov    rax,QWORD PTR [r12+0xa0]
  40ff6e:	mov    r12,rax
  40ff71:	xor    r15d,r15d
  40ff74:	test   r12,r12
  40ff77:	je     40ffdf <__swc_fn_e121059d_000086_c45095aa+0xdf>
  40ff79:	nop    DWORD PTR [rax+0x0]
  40ff80:	mov    QWORD PTR [rsp+0x58],r12
  40ff85:	lea    r12,[r15*8+0x0]
  40ff8d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40ff92:	mov    rcx,rax
  40ff95:	call   40d500 <__swc_fn_e121059d_000082_754dcd57>
  40ff9a:	cmp    BYTE PTR [rax+0x2c],0xe
  40ff9e:	jne    40ffd0 <__swc_fn_e121059d_000086_c45095aa+0xd0>
  40ffa0:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40ffa5:	lea    r8,[r13+rcx*1+0x0]
  40ffaa:	mov    rcx,rdi
  40ffad:	mov    rdx,rax
  40ffb0:	mov    r9,rsi
  40ffb3:	call   40ff00 <__swc_fn_e121059d_000086_c45095aa>
  40ffb8:	test   al,al
  40ffba:	je     40ffd0 <__swc_fn_e121059d_000086_c45095aa+0xd0>
  40ffbc:	mov    eax,0x1
  40ffc1:	add    rsp,0x68
  40ffc5:	pop    r15
  40ffc7:	pop    r14
  40ffc9:	pop    r13
  40ffcb:	pop    r12
  40ffcd:	pop    rdi
  40ffce:	pop    rsi
  40ffcf:	ret
  40ffd0:	add    r15,0x1
  40ffd4:	mov    r12,QWORD PTR [rsp+0x58]
  40ffd9:	sub    r12,0x1
  40ffdd:	jne    40ff80 <__swc_fn_e121059d_000086_c45095aa+0x80>
  40ffdf:	xor    eax,eax
  40ffe1:	add    rsp,0x68
  40ffe5:	pop    r15
  40ffe7:	pop    r14
  40ffe9:	pop    r13
  40ffeb:	pop    r12
  40ffed:	pop    rdi
  40ffee:	pop    rsi
  40ffef:	ret

000000000040fff0 <__swc_fn_e121059d_000089_386582f3>:
  40fff0:	push   rbp
  40fff1:	push   rbx
  40fff2:	push   rsi
  40fff3:	push   rdi
  40fff4:	push   r12
  40fff6:	push   r13
  40fff8:	push   r14
  40fffa:	push   r15
  40fffc:	sub    rsp,0x38
  410000:	mov    rbp,rsp
  410003:	mov    rbx,r11
  410006:	mov    rsi,rdx
  410009:	mov    rdi,r8
  41000c:	mov    r12,r9
  41000f:	mov    QWORD PTR [rsp+0x18],r9
  410014:	mov    r13,r10
  410017:	movzx  r14d,BYTE PTR [rbp+0x80]
  41001f:	movzx  r15d,BYTE PTR [rbp+0x88]
  410027:	test   r11,r11
  41002a:	je     410030 <__swc_fn_e121059d_000089_386582f3+0x40>
  41002c:	xor    eax,eax
  41002e:	mov    BYTE PTR [rbx],al
  410030:	test   r12,r12
  410033:	je     41003e <__swc_fn_e121059d_000089_386582f3+0x4e>
  410035:	mov    QWORD PTR [r12+0x8],0x0
  41003e:	test   rcx,rcx
  410041:	je     410048 <__swc_fn_e121059d_000089_386582f3+0x58>
  410043:	test   rsi,rsi
  410046:	jne    41005b <__swc_fn_e121059d_000089_386582f3+0x6b>
  410048:	xor    eax,eax
  41004a:	add    rsp,0x38
  41004e:	pop    r15
  410050:	pop    r14
  410052:	pop    r13
  410054:	pop    r12
  410056:	pop    rdi
  410057:	pop    rsi
  410058:	pop    rbx
  410059:	pop    rbp
  41005a:	ret
  41005b:	call   40d500 <__swc_fn_e121059d_000082_754dcd57>
  410060:	mov    r12,rax
  410063:	mov    al,r15b
  410066:	test   r15b,r15b
  410069:	jne    410079 <__swc_fn_e121059d_000089_386582f3+0x89>
  41006b:	mov    eax,DWORD PTR [r12+0x28]
  410070:	and    eax,0x10000
  410076:	setne  al
  410079:	lea    r15,[rsp+0x8]
  41007e:	mov    QWORD PTR [rsp+0x20],r15
  410083:	rex mov BYTE PTR [rsp+0x8],al
  410088:	test   DWORD PTR [rsi+0x28],0x400000
  41008f:	je     4100c7 <__swc_fn_e121059d_000089_386582f3+0xd7>
  410091:	test   rsi,rsi
  410094:	je     4100b4 <__swc_fn_e121059d_000089_386582f3+0xc4>
  410096:	mov    rax,QWORD PTR [rsi+0x38]
  41009a:	cmp    QWORD PTR [rax+0x10],rsi
  41009e:	jne    4100b4 <__swc_fn_e121059d_000089_386582f3+0xc4>
  4100a0:	rex mov al,BYTE PTR [rsp+0x8]
  4100a5:	test   al,al
  4100a7:	sete   al
  4100aa:	test   r14b,r14b
  4100ad:	sete   cl
  4100b0:	test   al,cl
  4100b2:	je     4100c7 <__swc_fn_e121059d_000089_386582f3+0xd7>
  4100b4:	xor    eax,eax
  4100b6:	add    rsp,0x38
  4100ba:	pop    r15
  4100bc:	pop    r14
  4100be:	pop    r13
  4100c0:	pop    r12
  4100c2:	pop    rdi
  4100c3:	pop    rsi
  4100c4:	pop    rbx
  4100c5:	pop    rbp
  4100c6:	ret
  4100c7:	mov    r15,r12
  4100ca:	test   r14b,r14b
  4100cd:	jne    4100e4 <__swc_fn_e121059d_000089_386582f3+0xf4>
  4100cf:	cmp    BYTE PTR [r12+0x2c],0x6
  4100d5:	jne    4100e4 <__swc_fn_e121059d_000089_386582f3+0xf4>
  4100d7:	mov    rcx,QWORD PTR [r12+0x40]
  4100dc:	call   40d500 <__swc_fn_e121059d_000082_754dcd57>
  4100e1:	mov    r15,rax
  4100e4:	test   r14b,r14b
  4100e7:	je     4100ed <__swc_fn_e121059d_000089_386582f3+0xfd>
  4100e9:	mov    r15,QWORD PTR [r15+0x30]
  4100ed:	mov    rcx,rsi
  4100f0:	call   40d500 <__swc_fn_e121059d_000082_754dcd57>
  4100f5:	mov    rsi,rax
  4100f8:	rex cmp BYTE PTR [rsi+0x2c],0x6
  4100fd:	je     410134 <__swc_fn_e121059d_000089_386582f3+0x144>
  4100ff:	rex cmp BYTE PTR [rsi+0x2c],0x12
  410104:	je     410134 <__swc_fn_e121059d_000089_386582f3+0x144>
  410106:	mov    eax,DWORD PTR [rsi+0x28]
  410109:	and    eax,0x10000
  41010f:	je     410134 <__swc_fn_e121059d_000089_386582f3+0x144>
  410111:	rex mov al,BYTE PTR [rsp+0x8]
  410116:	test   al,al
  410118:	jne    41012d <__swc_fn_e121059d_000089_386582f3+0x13d>
  41011a:	xor    eax,eax
  41011c:	add    rsp,0x38
  410120:	pop    r15
  410122:	pop    r14
  410124:	pop    r13
  410126:	pop    r12
  410128:	pop    rdi
  410129:	pop    rsi
  41012a:	pop    rbx
  41012b:	pop    rbp
  41012c:	ret
  41012d:	mov    rax,QWORD PTR [rsi+0x30]
  410131:	mov    rsi,rax
  410134:	mov    r14b,r13b
  410137:	test   rbx,rbx
  41013a:	je     410170 <__swc_fn_e121059d_000089_386582f3+0x180>
  41013c:	cmp    BYTE PTR [r12+0x2c],0x6
  410142:	jne    410170 <__swc_fn_e121059d_000089_386582f3+0x180>
  410144:	lea    rdx,[rip+0x3035]        # 413180 <__swc_rdata_base_e121059d+0x70>
  41014b:	mov    rcx,rsi
  41014e:	xor    r8d,r8d
  410151:	call   4085a0 <__swc_fn_e121059d_000090_a2d50c23>
  410156:	test   al,al
  410158:	je     410170 <__swc_fn_e121059d_000089_386582f3+0x180>
  41015a:	mov    BYTE PTR [rbx],0x1
  41015d:	xor    eax,eax
  41015f:	add    rsp,0x38
  410163:	pop    r15
  410165:	pop    r14
  410167:	pop    r13
  410169:	pop    r12
  41016b:	pop    rdi
  41016c:	pop    rsi
  41016d:	pop    rbx
  41016e:	pop    rbp
  41016f:	ret
  410170:	test   rdi,rdi
  410173:	jne    41018d <__swc_fn_e121059d_000089_386582f3+0x19d>
  410175:	test   r13b,r13b
  410178:	jne    41018d <__swc_fn_e121059d_000089_386582f3+0x19d>
  41017a:	xor    eax,eax
  41017c:	add    rsp,0x38
  410180:	pop    r15
  410182:	pop    r14
  410184:	pop    r13
  410186:	pop    r12
  410188:	pop    rdi
  410189:	pop    rsi
  41018a:	pop    rbx
  41018b:	pop    rbp
  41018c:	ret
  41018d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  410192:	jne    410248 <__swc_fn_e121059d_000089_386582f3+0x258>
  410198:	mov    rcx,r15
  41019b:	mov    rdx,rsi
  41019e:	xor    r8d,r8d
  4101a1:	call   4085a0 <__swc_fn_e121059d_000090_a2d50c23>
  4101a6:	test   al,al
  4101a8:	jne    410248 <__swc_fn_e121059d_000089_386582f3+0x258>
  4101ae:	test   DWORD PTR [rsi+0x28],0x10000
  4101b5:	je     4101d3 <__swc_fn_e121059d_000089_386582f3+0x1e3>
  4101b7:	rex mov al,BYTE PTR [rsp+0x8]
  4101bc:	test   al,al
  4101be:	jne    4101d3 <__swc_fn_e121059d_000089_386582f3+0x1e3>
  4101c0:	xor    eax,eax
  4101c2:	add    rsp,0x38
  4101c6:	pop    r15
  4101c8:	pop    r14
  4101ca:	pop    r13
  4101cc:	pop    r12
  4101ce:	pop    rdi
  4101cf:	pop    rsi
  4101d0:	pop    rbx
  4101d1:	pop    rbp
  4101d2:	ret
  4101d3:	test   rdi,rdi
  4101d6:	jne    4101eb <__swc_fn_e121059d_000089_386582f3+0x1fb>
  4101d8:	xor    eax,eax
  4101da:	add    rsp,0x38
  4101de:	pop    r15
  4101e0:	pop    r14
  4101e2:	pop    r13
  4101e4:	pop    r12
  4101e6:	pop    rdi
  4101e7:	pop    rsi
  4101e8:	pop    rbx
  4101e9:	pop    rbp
  4101ea:	ret
  4101eb:	mov    rcx,QWORD PTR [rsi+0x40]
  4101ef:	call   40d500 <__swc_fn_e121059d_000082_754dcd57>
  4101f4:	mov    rsi,rax
  4101f7:	mov    rax,QWORD PTR [rdi]
  4101fa:	mov    rdi,rax
  4101fd:	test   rax,rax
  410200:	jne    410243 <__swc_fn_e121059d_000089_386582f3+0x253>
  410202:	test   rbx,rbx
  410205:	je     410243 <__swc_fn_e121059d_000089_386582f3+0x253>
  410207:	mov    rcx,r15
  41020a:	mov    rdx,rsi
  41020d:	xor    r8d,r8d
  410210:	call   4085a0 <__swc_fn_e121059d_000090_a2d50c23>
  410215:	mov    rcx,rax
  410218:	test   al,al
  41021a:	jne    41023c <__swc_fn_e121059d_000089_386582f3+0x24c>
  41021c:	mov    rcx,r15
  41021f:	mov    rdx,rsi
  410222:	call   40d540 <__swc_fn_e121059d_000085_1edf7c76>
  410227:	mov    rcx,rax
  41022a:	test   al,al
  41022c:	jne    41023c <__swc_fn_e121059d_000089_386582f3+0x24c>
  41022e:	mov    rcx,rsi
  410231:	mov    rdx,r15
  410234:	call   40d540 <__swc_fn_e121059d_000085_1edf7c76>
  410239:	mov    rcx,rax
  41023c:	test   cl,cl
  41023e:	setne  al
  410241:	mov    BYTE PTR [rbx],al
  410243:	xor    eax,eax
  410245:	mov    r14b,al
  410248:	test   rdi,rdi
  41024b:	jne    410265 <__swc_fn_e121059d_000089_386582f3+0x275>
  41024d:	test   r14b,r14b
  410250:	jne    410265 <__swc_fn_e121059d_000089_386582f3+0x275>
  410252:	xor    eax,eax
  410254:	add    rsp,0x38
  410258:	pop    r15
  41025a:	pop    r14
  41025c:	pop    r13
  41025e:	pop    r12
  410260:	pop    rdi
  410261:	pop    rsi
  410262:	pop    rbx
  410263:	pop    rbp
  410264:	ret
  410265:	rex cmp BYTE PTR [rsi+0x2c],0x12
  41026a:	je     410276 <__swc_fn_e121059d_000089_386582f3+0x286>
  41026c:	mov    r12,QWORD PTR [rsp+0x18]
  410271:	jmp    4102fe <__swc_fn_e121059d_000089_386582f3+0x30e>
  410276:	mov    r12,QWORD PTR [rsp+0x18]
  41027b:	test   r12,r12
  41027e:	jne    410292 <__swc_fn_e121059d_000089_386582f3+0x2a2>
  410280:	mov    rcx,r15
  410283:	mov    rdx,rsi
  410286:	xor    r8d,r8d
  410289:	call   4085a0 <__swc_fn_e121059d_000090_a2d50c23>
  41028e:	test   al,al
  410290:	jne    4102fe <__swc_fn_e121059d_000089_386582f3+0x30e>
  410292:	test   DWORD PTR [rsi+0x28],0x10000
  410299:	je     4102b7 <__swc_fn_e121059d_000089_386582f3+0x2c7>
  41029b:	rex mov al,BYTE PTR [rsp+0x8]
  4102a0:	test   al,al
  4102a2:	jne    4102b7 <__swc_fn_e121059d_000089_386582f3+0x2c7>
  4102a4:	xor    eax,eax
  4102a6:	add    rsp,0x38
  4102aa:	pop    r15
  4102ac:	pop    r14
  4102ae:	pop    r13
  4102b0:	pop    r12
  4102b2:	pop    rdi
  4102b3:	pop    rsi
  4102b4:	pop    rbx
  4102b5:	pop    rbp
  4102b6:	ret
  4102b7:	test   rdi,rdi
  4102ba:	jne    4102cf <__swc_fn_e121059d_000089_386582f3+0x2df>
  4102bc:	xor    eax,eax
  4102be:	add    rsp,0x38
  4102c2:	pop    r15
  4102c4:	pop    r14
  4102c6:	pop    r13
  4102c8:	pop    r12
  4102ca:	pop    rdi
  4102cb:	pop    rsi
  4102cc:	pop    rbx
  4102cd:	pop    rbp
  4102ce:	ret
  4102cf:	cmp    QWORD PTR [rdi+0x8],0x0
  4102d4:	jne    4102e9 <__swc_fn_e121059d_000089_386582f3+0x2f9>
  4102d6:	xor    eax,eax
  4102d8:	add    rsp,0x38
  4102dc:	pop    r15
  4102de:	pop    r14
  4102e0:	pop    r13
  4102e2:	pop    r12
  4102e4:	pop    rdi
  4102e5:	pop    rsi
  4102e6:	pop    rbx
  4102e7:	pop    rbp
  4102e8:	ret
  4102e9:	mov    rax,QWORD PTR [rdi+0x8]
  4102ed:	mov    rax,QWORD PTR [rax]
  4102f0:	mov    rsi,rax
  4102f3:	mov    rdi,QWORD PTR [rdi]
  4102f6:	mov    eax,0x1
  4102fb:	mov    r14b,al
  4102fe:	test   rdi,rdi
  410301:	mov    rbx,QWORD PTR [rsp+0x20]
  410306:	jne    410350 <__swc_fn_e121059d_000089_386582f3+0x360>
  410308:	test   r14b,r14b
  41030b:	je     41033d <__swc_fn_e121059d_000089_386582f3+0x34d>
  41030d:	test   r12,r12
  410310:	je     41033d <__swc_fn_e121059d_000089_386582f3+0x34d>
  410312:	mov    rcx,r15
  410315:	mov    rdx,rsi
  410318:	xor    r8d,r8d
  41031b:	mov    r9,r12
  41031e:	mov    rbx,QWORD PTR [rsp+0x20]
  410323:	movzx  r10d,BYTE PTR [rbx]
  410327:	call   40fee0 <__swc_fn_e121059d_000083_31b501f2>
  41032c:	add    rsp,0x38
  410330:	pop    r15
  410332:	pop    r14
  410334:	pop    r13
  410336:	pop    r12
  410338:	pop    rdi
  410339:	pop    rsi
  41033a:	pop    rbx
  41033b:	pop    rbp
  41033c:	ret
  41033d:	xor    eax,eax
  41033f:	add    rsp,0x38
  410343:	pop    r15
  410345:	pop    r14
  410347:	pop    r13
  410349:	pop    r12
  41034b:	pop    rdi
  41034c:	pop    rsi
  41034d:	pop    rbx
  41034e:	pop    rbp
  41034f:	ret
  410350:	mov    r13,rsi
  410353:	mov    QWORD PTR [rsp+0x28],rdi
  410358:	cmp    BYTE PTR [r15+0x2c],0xe
  41035d:	sete   al
  410360:	mov    r14b,al
  410363:	jne    410377 <__swc_fn_e121059d_000089_386582f3+0x387>
  410365:	mov    rcx,rsi
  410368:	mov    rdx,r15
  41036b:	call   40d540 <__swc_fn_e121059d_000085_1edf7c76>
  410370:	mov    r14b,al
  410373:	test   al,al
  410375:	jne    4103ac <__swc_fn_e121059d_000089_386582f3+0x3bc>
  410377:	cmp    BYTE PTR [r15+0x2c],0x12
  41037c:	je     4103ac <__swc_fn_e121059d_000089_386582f3+0x3bc>
  41037e:	mov    rcx,r15
  410381:	mov    rdx,rsi
  410384:	mov    r8,rdi
  410387:	mov    r9,r12
  41038a:	mov    rax,rbx
  41038d:	movzx  r10d,BYTE PTR [rax]
  410391:	call   40fee0 <__swc_fn_e121059d_000083_31b501f2>
  410396:	test   rax,rax
  410399:	je     4103ac <__swc_fn_e121059d_000089_386582f3+0x3bc>
  41039b:	add    rsp,0x38
  41039f:	pop    r15
  4103a1:	pop    r14
  4103a3:	pop    r13
  4103a5:	pop    r12
  4103a7:	pop    rdi
  4103a8:	pop    rsi
  4103a9:	pop    rbx
  4103aa:	pop    rbp
  4103ab:	ret
  4103ac:	rex cmp BYTE PTR [rsi+0x2c],0xe
  4103b1:	jne    4103d0 <__swc_fn_e121059d_000089_386582f3+0x3e0>
  4103b3:	mov    rax,QWORD PTR [rsi+0xd8]
  4103ba:	test   rax,rax
  4103bd:	je     4103d0 <__swc_fn_e121059d_000089_386582f3+0x3e0>
  4103bf:	add    rdi,QWORD PTR [rax+0x8]
  4103c3:	mov    rax,QWORD PTR [rdi]
  4103c6:	sub    rdi,QWORD PTR [rax+0x8]
  4103ca:	mov    rax,QWORD PTR [rax]
  4103cd:	mov    rsi,rax
  4103d0:	test   r14b,r14b
  4103d3:	je     4103ff <__swc_fn_e121059d_000089_386582f3+0x40f>
  4103d5:	mov    rcx,r15
  4103d8:	mov    rdx,rsi
  4103db:	mov    r8,rdi
  4103de:	mov    r9,r13
  4103e1:	mov    r14,QWORD PTR [rsp+0x28]
  4103e6:	mov    r10,r14
  4103e9:	call   408480 <__swc_fn_e121059d_000087_ea575bb3>
  4103ee:	add    rsp,0x38
  4103f2:	pop    r15
  4103f4:	pop    r14
  4103f6:	pop    r13
  4103f8:	pop    r12
  4103fa:	pop    rdi
  4103fb:	pop    rsi
  4103fc:	pop    rbx
  4103fd:	pop    rbp
  4103fe:	ret
  4103ff:	mov    rcx,r15
  410402:	mov    rdx,rsi
  410405:	mov    r8,rdi
  410408:	mov    r9,r12
  41040b:	movzx  r10d,BYTE PTR [rbx]
  41040f:	call   40fee0 <__swc_fn_e121059d_000083_31b501f2>
  410414:	add    rsp,0x38
  410418:	pop    r15
  41041a:	pop    r14
  41041c:	pop    r13
  41041e:	pop    r12
  410420:	pop    rdi
  410421:	pop    rsi
  410422:	pop    rbx
  410423:	pop    rbp
  410424:	ret
	...

0000000000410430 <__swc_fn_e121059d_000092_8252f8c0>:
  410430:	push   rbx
  410431:	push   rsi
  410432:	sub    rsp,0x18
  410436:	mov    rbx,rcx
  410439:	mov    rcx,QWORD PTR [rip+0x16900]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  410440:	test   rcx,rcx
  410443:	jne    410455 <__swc_fn_e121059d_000092_8252f8c0+0x25>
  410445:	call   40ea10 <__swc_fn_e121059d_000166_cf398896>
  41044a:	lea    rcx,[rax+0x1]
  41044e:	mov    QWORD PTR [rip+0x168eb],rcx        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  410455:	dec    rcx
  410458:	call   40b6c0 <__swc_fn_e121059d_000168_fce60b2b>
  41045d:	mov    rsi,rax
  410460:	mov    rax,QWORD PTR [rsi+0x8]
  410464:	test   rax,rax
  410467:	jne    4104b7 <__swc_fn_e121059d_000092_8252f8c0+0x87>
  410469:	call   40d630 <__swc_fn_e121059d_000091_3d2f5a0d>
  41046e:	test   al,al
  410470:	jne    4104b7 <__swc_fn_e121059d_000092_8252f8c0+0x87>
  410472:	lea    rdx,[rip+0x13dc7]        # 424240 <__swc_bss_base_e121059d+0x200>
  410479:	mov    rcx,rdx
  41047c:	call   407740 <__swc_fn_e121059d_000036_8d895ba1>
  410481:	test   al,al
  410483:	jne    410494 <__swc_fn_e121059d_000092_8252f8c0+0x64>
  410485:	mov    rcx,rdx
  410488:	call   40bf20 <__swc_fn_e121059d_000034_25f19556>
  41048d:	lea    rdx,[rip+0x13dac]        # 424240 <__swc_bss_base_e121059d+0x200>
  410494:	mov    QWORD PTR [rsp+0x8],rdx
  410499:	lea    rax,[rip+0x2cb0]        # 413150 <__swc_rdata_base_e121059d+0x40>
  4104a0:	mov    QWORD PTR [rsp+0x10],rax
  4104a5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4104ab:	vmovups XMMWORD PTR [rsi],xmm0
  4104af:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  4104b7:	vmovups xmm0,XMMWORD PTR [rsi]
  4104bb:	vmovups XMMWORD PTR [rbx],xmm0
  4104bf:	mov    rax,rbx
  4104c2:	add    rsp,0x18
  4104c6:	pop    rsi
  4104c7:	pop    rbx
  4104c8:	ret
  4104c9:	add    BYTE PTR [rax],al
  4104cb:	add    BYTE PTR [rax],al
  4104cd:	add    BYTE PTR [rax],al
	...

00000000004104d0 <__swc_fn_e121059d_000095_337e587a>:
  4104d0:	sub    rsp,0x8
  4104d4:	call   40dba0 <__swc_fn_e121059d_000118_86a7fb9e>
  4104d9:	add    rsp,0x8
  4104dd:	ret
	...

00000000004104e0 <__swc_fn_e121059d_000098_00f01091>:
  4104e0:	push   rbx
  4104e1:	push   rsi
  4104e2:	sub    rsp,0x28
  4104e6:	mov    rbx,rcx
  4104e9:	xor    esi,esi
  4104eb:	jmp    410500 <__swc_fn_e121059d_000098_00f01091+0x20>
  4104ed:	nop    DWORD PTR [rax]
  4104f0:	mov    QWORD PTR [rbx+0x28],rsi
  4104f4:	mov    rsi,rbx
  4104f7:	mov    rbx,rax
  4104fa:	nop    WORD PTR [rax+rax*1+0x0]
  410500:	test   rbx,rbx
  410503:	je     410563 <__swc_fn_e121059d_000098_00f01091+0x83>
  410505:	mov    rcx,rbx
  410508:	mov    edx,0x1
  41050d:	call   408200 <__swc_fn_e121059d_000078_a120bd2b>
  410512:	cmp    rax,0x1
  410516:	jne    410563 <__swc_fn_e121059d_000098_00f01091+0x83>
  410518:	mov    r10,QWORD PTR [rbx+0x18]
  41051c:	mov    rcx,r10
  41051f:	mov    edx,0x1
  410524:	call   408200 <__swc_fn_e121059d_000078_a120bd2b>
  410529:	cmp    rax,0x1
  41052d:	jne    41053c <__swc_fn_e121059d_000098_00f01091+0x5c>
  41052f:	mov    rcx,r10
  410532:	call   40d7d0 <__swc_fn_e121059d_000097_4c97e0db>
  410537:	test   rax,rax
  41053a:	jne    4104f0 <__swc_fn_e121059d_000098_00f01091+0x10>
  41053c:	mov    rax,QWORD PTR [rbx+0x20]
  410540:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  410545:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  41054b:	lea    rcx,[rsp+0x8]
  410550:	mov    rdx,rbx
  410553:	mov    r8d,0x30
  410559:	mov    rbx,rax
  41055c:	call   408960 <__swc_fn_e121059d_000096_ad982b35>
  410561:	jmp    410500 <__swc_fn_e121059d_000098_00f01091+0x20>
  410563:	test   rsi,rsi
  410566:	jne    41056f <__swc_fn_e121059d_000098_00f01091+0x8f>
  410568:	add    rsp,0x28
  41056c:	pop    rsi
  41056d:	pop    rbx
  41056e:	ret
  41056f:	mov    rax,rsi
  410572:	mov    rsi,QWORD PTR [rsi+0x28]
  410576:	mov    rbx,QWORD PTR [rax+0x20]
  41057a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  41057f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  410585:	lea    rcx,[rsp+0x18]
  41058a:	mov    rdx,rax
  41058d:	mov    r8d,0x30
  410593:	call   408960 <__swc_fn_e121059d_000096_ad982b35>
  410598:	jmp    410500 <__swc_fn_e121059d_000098_00f01091+0x20>
  41059d:	add    BYTE PTR [rax],al
	...

00000000004105a0 <__swc_fn_e121059d_000101_eab3874f>:
  4105a0:	push   rbx
  4105a1:	push   rsi
  4105a2:	push   rdi
  4105a3:	push   r12
  4105a5:	push   r13
  4105a7:	sub    rsp,0x20
  4105ab:	mov    rbx,rcx
  4105ae:	lea    rsi,[rcx+0x6f8]
  4105b5:	mov    edi,0x4
  4105ba:	mov    r12,rsi
  4105bd:	test   rdi,rdi
  4105c0:	je     41060a <__swc_fn_e121059d_000101_eab3874f+0x6a>
  4105c2:	cs nop WORD PTR [rax+rax*1+0x0]
  4105cc:	nop    DWORD PTR [rax+0x0]
  4105d0:	mov    rcx,QWORD PTR [r12+0x10]
  4105d5:	mov    QWORD PTR [r12+0x10],0x0
  4105de:	vxorps xmm0,xmm0,xmm0
  4105e2:	vmovups XMMWORD PTR [r12],xmm0
  4105e8:	vmovups XMMWORD PTR [r12+0x28],xmm0
  4105ef:	mov    DWORD PTR [r12+0x20],0x0
  4105f8:	call   4089c0 <__swc_fn_e121059d_000099_b4c6da83>
  4105fd:	add    r12,0x90
  410604:	sub    rdi,0x1
  410608:	jne    4105d0 <__swc_fn_e121059d_000101_eab3874f+0x30>
  41060a:	mov    rax,QWORD PTR [rbx+0x938]
  410611:	mov    rdi,rax
  410614:	test   rdi,rdi
  410617:	je     410671 <__swc_fn_e121059d_000101_eab3874f+0xd1>
  410619:	nop    DWORD PTR [rax+0x0]
  410620:	mov    r12d,0x10
  410626:	lea    r13,[rdi+0x18]
  41062a:	test   r12,r12
  41062d:	je     410666 <__swc_fn_e121059d_000101_eab3874f+0xc6>
  41062f:	nop
  410630:	mov    rcx,QWORD PTR [r13+0x10]
  410634:	mov    QWORD PTR [r13+0x10],0x0
  41063c:	vxorps xmm0,xmm0,xmm0
  410640:	vmovups XMMWORD PTR [r13+0x0],xmm0
  410646:	vmovups XMMWORD PTR [r13+0x28],xmm0
  41064c:	mov    DWORD PTR [r13+0x20],0x0
  410654:	call   4089c0 <__swc_fn_e121059d_000099_b4c6da83>
  410659:	add    r13,0x90
  410660:	sub    r12,0x1
  410664:	jne    410630 <__swc_fn_e121059d_000101_eab3874f+0x90>
  410666:	mov    rax,QWORD PTR [rdi]
  410669:	mov    rdi,rax
  41066c:	test   rax,rax
  41066f:	jne    410620 <__swc_fn_e121059d_000101_eab3874f+0x80>
  410671:	vxorps xmm0,xmm0,xmm0
  410675:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  41067d:	mov    DWORD PTR [rbx+0x9b0],0x0
  410687:	mov    DWORD PTR [rbx+0x9a8],0x0
  410691:	mov    edi,0x4
  410696:	mov    r12,rsi
  410699:	lea    rsi,[rsi+0x38]
  41069d:	test   rdi,rdi
  4106a0:	je     4106cc <__swc_fn_e121059d_000101_eab3874f+0x12c>
  4106a2:	cs nop WORD PTR [rax+rax*1+0x0]
  4106ac:	nop    DWORD PTR [rax+0x0]
  4106b0:	mov    rcx,rsi
  4106b3:	call   411580 <__swc_fn_e121059d_000158_232ffa22>
  4106b8:	add    rsi,0x90
  4106bf:	add    r12,0x90
  4106c6:	sub    rdi,0x1
  4106ca:	jne    4106b0 <__swc_fn_e121059d_000101_eab3874f+0x110>
  4106cc:	mov    rax,QWORD PTR [rbx+0x938]
  4106d3:	mov    rdi,rax
  4106d6:	mov    QWORD PTR [rbx+0x938],0x0
  4106e1:	test   rdi,rdi
  4106e4:	je     410755 <__swc_fn_e121059d_000101_eab3874f+0x1b5>
  4106ea:	nop    WORD PTR [rax+rax*1+0x0]
  4106f0:	mov    esi,0x10
  4106f5:	lea    r12,[rdi+0x18]
  4106f9:	lea    r13,[rdi+0x50]
  4106fd:	test   rsi,rsi
  410700:	je     41072c <__swc_fn_e121059d_000101_eab3874f+0x18c>
  410702:	cs nop WORD PTR [rax+rax*1+0x0]
  41070c:	nop    DWORD PTR [rax+0x0]
  410710:	mov    rcx,r13
  410713:	call   411580 <__swc_fn_e121059d_000158_232ffa22>
  410718:	add    r13,0x90
  41071f:	add    r12,0x90
  410726:	sub    rsi,0x1
  41072a:	jne    410710 <__swc_fn_e121059d_000101_eab3874f+0x170>
  41072c:	mov    rax,QWORD PTR [rdi]
  41072f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  410734:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  41073a:	lea    rcx,[rsp+0x8]
  41073f:	mov    rdx,rdi
  410742:	mov    r8d,0x918
  410748:	mov    rdi,rax
  41074b:	call   408960 <__swc_fn_e121059d_000096_ad982b35>
  410750:	test   rdi,rdi
  410753:	jne    4106f0 <__swc_fn_e121059d_000101_eab3874f+0x150>
  410755:	lea    rcx,[rbx+0x68]
  410759:	call   411580 <__swc_fn_e121059d_000158_232ffa22>
  41075e:	add    rsp,0x20
  410762:	pop    r13
  410764:	pop    r12
  410766:	pop    rdi
  410767:	pop    rsi
  410768:	pop    rbx
  410769:	ret
  41076a:	add    BYTE PTR [rax],al
  41076c:	add    BYTE PTR [rax],al
	...

0000000000410770 <__swc_fn_e121059d_000104_5589fdbd>:
  410770:	xor    eax,eax
  410772:	cs nop WORD PTR [rax+rax*1+0x0]
  41077c:	nop    DWORD PTR [rax+0x0]
  410780:	mov    r9,r8
  410783:	sub    r9,rax
  410786:	cmp    r9,0x40
  41078a:	jb     4107c8 <__swc_fn_e121059d_000104_5589fdbd+0x58>
  41078c:	lea    r9,[rcx+rax*1]
  410790:	lea    r10,[rdx+rax*1]
  410794:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  41079a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  4107a0:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  4107a6:	vmovups xmm3,XMMWORD PTR [r10]
  4107ab:	vmovups XMMWORD PTR [r9],xmm3
  4107b0:	vmovups XMMWORD PTR [r9+0x10],xmm0
  4107b6:	vmovups XMMWORD PTR [r9+0x20],xmm1
  4107bc:	vmovups XMMWORD PTR [r9+0x30],xmm2
  4107c2:	lea    rax,[rax+0x40]
  4107c6:	jmp    410780 <__swc_fn_e121059d_000104_5589fdbd+0x10>
  4107c8:	nop    DWORD PTR [rax+rax*1+0x0]
  4107d0:	mov    r9,r8
  4107d3:	sub    r9,rax
  4107d6:	cmp    r9,0x10
  4107da:	jb     4107f4 <__swc_fn_e121059d_000104_5589fdbd+0x84>
  4107dc:	lea    r9,[rdx+rax*1]
  4107e0:	lea    r10,[rcx+rax*1]
  4107e4:	vmovups xmm0,XMMWORD PTR [r9]
  4107e9:	vmovups XMMWORD PTR [r10],xmm0
  4107ee:	lea    rax,[rax+0x10]
  4107f2:	jmp    4107d0 <__swc_fn_e121059d_000104_5589fdbd+0x60>
  4107f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4107fe:	xchg   ax,ax
  410800:	mov    r9,r8
  410803:	sub    r9,rax
  410806:	cmp    r9,0x8
  41080a:	jb     41081d <__swc_fn_e121059d_000104_5589fdbd+0xad>
  41080c:	lea    r9,[rcx+rax*1]
  410810:	mov    r10,QWORD PTR [rdx+rax*1]
  410814:	mov    QWORD PTR [r9],r10
  410817:	lea    rax,[rax+0x8]
  41081b:	jmp    410800 <__swc_fn_e121059d_000104_5589fdbd+0x90>
  41081d:	cmp    rax,r8
  410820:	jae    410840 <__swc_fn_e121059d_000104_5589fdbd+0xd0>
  410822:	cs nop WORD PTR [rax+rax*1+0x0]
  41082c:	nop    DWORD PTR [rax+0x0]
  410830:	mov    r9b,BYTE PTR [rdx+rax*1]
  410834:	mov    BYTE PTR [rcx+rax*1],r9b
  410838:	inc    rax
  41083b:	cmp    rax,r8
  41083e:	jb     410830 <__swc_fn_e121059d_000104_5589fdbd+0xc0>
  410840:	ret
	...

0000000000410850 <__swc_fn_e121059d_000107_ed4b1681>:
  410850:	test   r8,r8
  410853:	jne    410858 <__swc_fn_e121059d_000107_ed4b1681+0x8>
  410855:	xor    eax,eax
  410857:	ret
  410858:	xor    eax,eax
  41085a:	nop    WORD PTR [rax+rax*1+0x0]
  410860:	mov    r9,r8
  410863:	sub    r9,rax
  410866:	cmp    r9,0x10
  41086a:	jb     4108b4 <__swc_fn_e121059d_000107_ed4b1681+0x64>
  41086c:	lea    r9,[rcx+rax*1]
  410870:	lea    r10,[rdx+rax*1]
  410874:	vmovups xmm0,XMMWORD PTR [r10]
  410879:	vmovups xmm1,XMMWORD PTR [r9]
  41087e:	vpcmpeqb xmm0,xmm1,xmm0
  410882:	vpmovmskb r9d,xmm0
  410886:	cmp    r9d,0xffff
  41088d:	je     4108ae <__swc_fn_e121059d_000107_ed4b1681+0x5e>
  41088f:	not    r9d
  410892:	xor    r8d,r8d
  410895:	movzx  r9d,r9w
  410899:	tzcnt  r8d,r9d
  41089e:	add    rax,r8
  4108a1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4108a5:	movzx  eax,BYTE PTR [rdx+rax*1]
  4108a9:	sub    ecx,eax
  4108ab:	mov    eax,ecx
  4108ad:	ret
  4108ae:	lea    rax,[rax+0x10]
  4108b2:	jmp    410860 <__swc_fn_e121059d_000107_ed4b1681+0x10>
  4108b4:	cmp    r9,0x8
  4108b8:	jb     41092b <__swc_fn_e121059d_000107_ed4b1681+0xdb>
  4108ba:	lea    r9,[rcx+rax*1]
  4108be:	lea    r10,[rdx+rax*1]
  4108c2:	mov    r9,QWORD PTR [r9]
  4108c5:	xor    r9,QWORD PTR [r10]
  4108c8:	test   r9,r9
  4108cb:	je     4108e9 <__swc_fn_e121059d_000107_ed4b1681+0x99>
  4108cd:	xor    r8d,r8d
  4108d0:	tzcnt  r8,r9
  4108d5:	shr    r8,0x3
  4108d9:	add    rax,r8
  4108dc:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4108e0:	movzx  eax,BYTE PTR [rdx+rax*1]
  4108e4:	sub    ecx,eax
  4108e6:	mov    eax,ecx
  4108e8:	ret
  4108e9:	lea    rax,[rax+0x8]
  4108ed:	cmp    rax,r8
  4108f0:	jne    4108f5 <__swc_fn_e121059d_000107_ed4b1681+0xa5>
  4108f2:	xor    eax,eax
  4108f4:	ret
  4108f5:	lea    rax,[r8-0x8]
  4108f9:	lea    r8,[rcx+rax*1]
  4108fd:	lea    r9,[rdx+rax*1]
  410901:	mov    r8,QWORD PTR [r8]
  410904:	xor    r8,QWORD PTR [r9]
  410907:	test   r8,r8
  41090a:	je     410928 <__swc_fn_e121059d_000107_ed4b1681+0xd8>
  41090c:	xor    r9d,r9d
  41090f:	tzcnt  r9,r8
  410914:	shr    r9,0x3
  410918:	add    rax,r9
  41091b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  41091f:	movzx  eax,BYTE PTR [rdx+rax*1]
  410923:	sub    ecx,eax
  410925:	mov    eax,ecx
  410927:	ret
  410928:	xor    eax,eax
  41092a:	ret
  41092b:	cmp    r9,0x4
  41092f:	jb     4109a2 <__swc_fn_e121059d_000107_ed4b1681+0x152>
  410931:	lea    r9,[rcx+rax*1]
  410935:	lea    r10,[rdx+rax*1]
  410939:	mov    r9d,DWORD PTR [r9]
  41093c:	xor    r9d,DWORD PTR [r10]
  41093f:	test   r9d,r9d
  410942:	je     410960 <__swc_fn_e121059d_000107_ed4b1681+0x110>
  410944:	xor    r8d,r8d
  410947:	tzcnt  r8,r9
  41094c:	shr    r8,0x3
  410950:	add    rax,r8
  410953:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410957:	movzx  eax,BYTE PTR [rdx+rax*1]
  41095b:	sub    ecx,eax
  41095d:	mov    eax,ecx
  41095f:	ret
  410960:	lea    rax,[rax+0x4]
  410964:	cmp    rax,r8
  410967:	jne    41096c <__swc_fn_e121059d_000107_ed4b1681+0x11c>
  410969:	xor    eax,eax
  41096b:	ret
  41096c:	lea    rax,[r8-0x4]
  410970:	lea    r8,[rcx+rax*1]
  410974:	lea    r9,[rdx+rax*1]
  410978:	mov    r8d,DWORD PTR [r8]
  41097b:	xor    r8d,DWORD PTR [r9]
  41097e:	test   r8d,r8d
  410981:	je     41099f <__swc_fn_e121059d_000107_ed4b1681+0x14f>
  410983:	xor    r9d,r9d
  410986:	tzcnt  r9,r8
  41098b:	shr    r9,0x3
  41098f:	add    rax,r9
  410992:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410996:	movzx  eax,BYTE PTR [rdx+rax*1]
  41099a:	sub    ecx,eax
  41099c:	mov    eax,ecx
  41099e:	ret
  41099f:	xor    eax,eax
  4109a1:	ret
  4109a2:	cmp    r9,0x2
  4109a6:	jb     4109f9 <__swc_fn_e121059d_000107_ed4b1681+0x1a9>
  4109a8:	lea    r9,[rcx+rax*1]
  4109ac:	lea    r10,[rdx+rax*1]
  4109b0:	mov    r9w,WORD PTR [r9]
  4109b4:	xor    r9w,WORD PTR [r10]
  4109b8:	test   r9w,r9w
  4109bc:	je     4109de <__swc_fn_e121059d_000107_ed4b1681+0x18e>
  4109be:	xor    r8d,r8d
  4109c1:	movzx  r9d,r9w
  4109c5:	tzcnt  r8,r9
  4109ca:	shr    r8,0x3
  4109ce:	add    rax,r8
  4109d1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4109d5:	movzx  eax,BYTE PTR [rdx+rax*1]
  4109d9:	sub    ecx,eax
  4109db:	mov    eax,ecx
  4109dd:	ret
  4109de:	lea    rax,[rax+0x2]
  4109e2:	cmp    rax,r8
  4109e5:	jne    4109ea <__swc_fn_e121059d_000107_ed4b1681+0x19a>
  4109e7:	xor    eax,eax
  4109e9:	ret
  4109ea:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  4109f0:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  4109f6:	sub    eax,ecx
  4109f8:	ret
  4109f9:	test   r9,r9
  4109fc:	je     410a0b <__swc_fn_e121059d_000107_ed4b1681+0x1bb>
  4109fe:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410a02:	movzx  eax,BYTE PTR [rdx+rax*1]
  410a06:	sub    ecx,eax
  410a08:	mov    eax,ecx
  410a0a:	ret
  410a0b:	xor    eax,eax
  410a0d:	ret
	...

0000000000410a10 <__swc_fn_e121059d_000110_8d425bd3>:
  410a10:	push   r12
  410a12:	push   r13
  410a14:	push   r14
  410a16:	push   rdi
  410a17:	push   rsi
  410a18:	push   r15
  410a1a:	sub    rsp,0xd8
  410a21:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  410a27:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  410a2d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  410a33:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  410a39:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  410a3f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  410a48:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  410a51:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  410a5a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  410a63:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  410a6c:	mov    r12,rcx
  410a6f:	test   rcx,rcx
  410a72:	je     410a8e <__swc_fn_e121059d_000110_8d425bd3+0x7e>
  410a74:	mov    eax,r12d
  410a77:	and    eax,0xfff
  410a7d:	setne  al
  410a80:	cmp    r12,0xffffffffffffefff
  410a87:	seta   cl
  410a8a:	or     al,cl
  410a8c:	je     410a95 <__swc_fn_e121059d_000110_8d425bd3+0x85>
  410a8e:	xor    eax,eax
  410a90:	jmp    410b2b <__swc_fn_e121059d_000110_8d425bd3+0x11b>
  410a95:	call   40d960 <__swc_fn_e121059d_000109_84af7666>
  410a9a:	mov    r13,rax
  410a9d:	test   rax,rax
  410aa0:	jne    410aa9 <__swc_fn_e121059d_000110_8d425bd3+0x99>
  410aa2:	xor    eax,eax
  410aa4:	jmp    410b2b <__swc_fn_e121059d_000110_8d425bd3+0x11b>
  410aa9:	lea    r14,[r12+0x1000]
  410ab1:	xor    edi,edi
  410ab3:	mov    rsi,r14
  410ab6:	xor    edx,edx
  410ab8:	mov    ecx,0x22
  410abd:	mov    eax,0xffffffff
  410ac2:	movsxd r8,eax
  410ac5:	xor    r9d,r9d
  410ac8:	xor    eax,eax
  410aca:	call   4070d0 <mmap@plt>
  410acf:	mov    r15,rax
  410ad2:	cmp    rax,0xffffffffffffffff
  410ad6:	jne    410adc <__swc_fn_e121059d_000110_8d425bd3+0xcc>
  410ad8:	xor    eax,eax
  410ada:	jmp    410b2b <__swc_fn_e121059d_000110_8d425bd3+0x11b>
  410adc:	mov    rdi,r15
  410adf:	mov    esi,0x1000
  410ae4:	mov    edx,0x3
  410ae9:	xor    eax,eax
  410aeb:	call   407170 <mprotect@plt>
  410af0:	test   eax,eax
  410af2:	je     410b05 <__swc_fn_e121059d_000110_8d425bd3+0xf5>
  410af4:	mov    rdi,r15
  410af7:	mov    rsi,r14
  410afa:	xor    eax,eax
  410afc:	call   407160 <munmap@plt>
  410b01:	xor    eax,eax
  410b03:	jmp    410b2b <__swc_fn_e121059d_000110_8d425bd3+0x11b>
  410b05:	mov    QWORD PTR [r15+0x8],r12
  410b09:	mov    rcx,r13
  410b0c:	call   411170 <__swc_fn_e121059d_000134_4b2af8da>
  410b11:	mov    rax,QWORD PTR [r13+0x8]
  410b15:	mov    QWORD PTR [r15],rax
  410b18:	mov    QWORD PTR [r13+0x8],r15
  410b1c:	mov    rcx,r13
  410b1f:	call   409d80 <__swc_fn_e121059d_000135_29412410>
  410b24:	lea    rax,[r15+0x1000]
  410b2b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  410b31:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  410b37:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  410b3d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  410b43:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  410b49:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  410b52:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  410b5b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  410b64:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  410b6d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  410b76:	add    rsp,0xd8
  410b7d:	pop    r15
  410b7f:	pop    rsi
  410b80:	pop    rdi
  410b81:	pop    r14
  410b83:	pop    r13
  410b85:	pop    r12
  410b87:	ret
	...

0000000000410b90 <__swc_fn_e121059d_000113_759e9ceb>:
  410b90:	push   rbx
  410b91:	push   r12
  410b93:	push   rdi
  410b94:	push   rsi
  410b95:	sub    rsp,0xa8
  410b9c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  410ba2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410ba8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  410bae:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410bb4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410bba:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  410bc0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410bc6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410bcc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410bd5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  410bde:	mov    rbx,rdx
  410be1:	mov    r12,rcx
  410be4:	mov    rdi,rcx
  410be7:	mov    rsi,rdx
  410bea:	xor    edx,edx
  410bec:	xor    eax,eax
  410bee:	call   407170 <mprotect@plt>
  410bf3:	test   eax,eax
  410bf5:	jne    410c19 <__swc_fn_e121059d_000113_759e9ceb+0x89>
  410bf7:	mov    rcx,r12
  410bfa:	mov    rdx,rbx
  410bfd:	xor    al,al
  410bff:	mov    r8,rax
  410c02:	call   409810 <__swc_fn_e121059d_000111_a808fe76>
  410c07:	mov    rdi,r12
  410c0a:	mov    rsi,rbx
  410c0d:	mov    edx,0x4
  410c12:	xor    eax,eax
  410c14:	call   4071d0 <madvise@plt>
  410c19:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410c1f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410c25:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410c2b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410c31:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410c37:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410c3d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410c43:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410c49:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410c52:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410c5b:	add    rsp,0xa8
  410c62:	pop    rsi
  410c63:	pop    rdi
  410c64:	pop    r12
  410c66:	pop    rbx
  410c67:	ret
	...

0000000000410c70 <__swc_fn_e121059d_000116_1ba33335>:
  410c70:	push   rsi
  410c71:	push   rdi
  410c72:	push   r12
  410c74:	push   r13
  410c76:	push   r14
  410c78:	sub    rsp,0xe0
  410c7f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  410c85:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  410c8b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  410c91:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  410c97:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  410c9d:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  410ca6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  410caf:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  410cb8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  410cc1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  410cca:	mov    rsi,rdx
  410ccd:	mov    rdi,rcx
  410cd0:	call   40d960 <__swc_fn_e121059d_000109_84af7666>
  410cd5:	mov    r12,rax
  410cd8:	test   rax,rax
  410cdb:	jne    410ce2 <__swc_fn_e121059d_000116_1ba33335+0x72>
  410cdd:	jmp    410d56 <__swc_fn_e121059d_000116_1ba33335+0xe6>
  410ce2:	mov    rcx,r12
  410ce5:	call   411170 <__swc_fn_e121059d_000134_4b2af8da>
  410cea:	lea    r13,[r12+0x8]
  410cef:	mov    rax,QWORD PTR [r13+0x0]
  410cf3:	test   rax,rax
  410cf6:	je     410d4e <__swc_fn_e121059d_000116_1ba33335+0xde>
  410cf8:	nop    DWORD PTR [rax+rax*1+0x0]
  410d00:	lea    rcx,[rax+0x1000]
  410d07:	cmp    rcx,rdi
  410d0a:	jne    410d42 <__swc_fn_e121059d_000116_1ba33335+0xd2>
  410d0c:	cmp    QWORD PTR [rax+0x8],rsi
  410d10:	je     410d1c <__swc_fn_e121059d_000116_1ba33335+0xac>
  410d12:	mov    rcx,r12
  410d15:	call   409d80 <__swc_fn_e121059d_000135_29412410>
  410d1a:	jmp    410d56 <__swc_fn_e121059d_000116_1ba33335+0xe6>
  410d1c:	mov    r14,QWORD PTR [rax]
  410d1f:	mov    rdi,rax
  410d22:	lea    rsi,[rsi+0x1000]
  410d29:	xor    eax,eax
  410d2b:	call   407160 <munmap@plt>
  410d30:	test   eax,eax
  410d32:	jne    410d38 <__swc_fn_e121059d_000116_1ba33335+0xc8>
  410d34:	mov    QWORD PTR [r13+0x0],r14
  410d38:	mov    rcx,r12
  410d3b:	call   409d80 <__swc_fn_e121059d_000135_29412410>
  410d40:	jmp    410d56 <__swc_fn_e121059d_000116_1ba33335+0xe6>
  410d42:	mov    r13,rax
  410d45:	mov    rax,QWORD PTR [r13+0x0]
  410d49:	test   rax,rax
  410d4c:	jne    410d00 <__swc_fn_e121059d_000116_1ba33335+0x90>
  410d4e:	mov    rcx,r12
  410d51:	call   409d80 <__swc_fn_e121059d_000135_29412410>
  410d56:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  410d5c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  410d62:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  410d68:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  410d6e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  410d74:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  410d7d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  410d86:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  410d8f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  410d98:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  410da1:	add    rsp,0xe0
  410da8:	pop    r14
  410daa:	pop    r13
  410dac:	pop    r12
  410dae:	pop    rdi
  410daf:	pop    rsi
  410db0:	ret
	...

0000000000410dc0 <__swc_fn_e121059d_000119_7f430081>:
  410dc0:	push   rdi
  410dc1:	push   rsi
  410dc2:	sub    rsp,0xa8
  410dc9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  410dcf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410dd5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  410ddb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410de1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410de7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  410ded:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410df3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410df9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410e02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  410e0b:	mov    rdi,0xfffffffffffffd66
  410e12:	xor    eax,eax
  410e14:	call   407180 <exit@plt>
  410e19:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410e1f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410e25:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410e2b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410e31:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410e37:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410e3d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410e43:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410e49:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410e52:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410e5b:	add    rsp,0xa8
  410e62:	pop    rsi
  410e63:	pop    rdi
  410e64:	ret
	...

0000000000410e80 <__swc_fn_e121059d_000122_12b4ed22>:
  410e80:	push   rbx
  410e81:	push   rsi
  410e82:	push   rdi
  410e83:	sub    rsp,0x30
  410e87:	mov    rbx,rdx
  410e8a:	mov    esi,ecx
  410e8c:	test   ecx,ecx
  410e8e:	je     410f63 <__swc_fn_e121059d_000122_12b4ed22+0xe3>
  410e94:	mov    rcx,rsi
  410e97:	shl    rcx,0x4
  410e9b:	call   40d470 <__swc_fn_e121059d_000079_34776ded>
  410ea0:	test   rax,rax
  410ea3:	je     410f52 <__swc_fn_e121059d_000122_12b4ed22+0xd2>
  410ea9:	mov    rcx,rsi
  410eac:	xor    edx,edx
  410eae:	test   rsi,rsi
  410eb1:	jbe    410f32 <__swc_fn_e121059d_000122_12b4ed22+0xb2>
  410eb7:	nop    WORD PTR [rax+rax*1+0x0]
  410ec0:	mov    r8d,edx
  410ec3:	mov    r9,QWORD PTR [rbx+r8*8]
  410ec7:	add    r8,r8
  410eca:	lea    r8,[rax+r8*8]
  410ece:	xor    r10d,r10d
  410ed1:	test   r9,r9
  410ed4:	je     410f10 <__swc_fn_e121059d_000122_12b4ed22+0x90>
  410ed6:	mov    r11,r9
  410ed9:	mov    dil,BYTE PTR [r11]
  410edc:	test   dil,dil
  410edf:	je     410f10 <__swc_fn_e121059d_000122_12b4ed22+0x90>
  410ee1:	cs nop WORD PTR [rax+rax*1+0x0]
  410eeb:	cs nop WORD PTR [rax+rax*1+0x0]
  410ef5:	cs nop WORD PTR [rax+rax*1+0x0]
  410eff:	nop
  410f00:	add    r11,0x1
  410f04:	add    r10,0x1
  410f08:	mov    dil,BYTE PTR [r11]
  410f0b:	test   dil,dil
  410f0e:	jne    410f00 <__swc_fn_e121059d_000122_12b4ed22+0x80>
  410f10:	mov    QWORD PTR [rsp+0x18],r9
  410f15:	mov    QWORD PTR [rsp+0x20],r10
  410f1a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  410f20:	vmovups XMMWORD PTR [r8],xmm0
  410f25:	add    rdx,0x1
  410f29:	cmp    rdx,rcx
  410f2c:	jb     410ec0 <__swc_fn_e121059d_000122_12b4ed22+0x40>
  410f32:	lea    rcx,[rip+0x15e17]        # 426d50 <__swc_bss_base_e121059d+0x2d10>
  410f39:	mov    QWORD PTR [rsp+0x8],rax
  410f3e:	mov    esi,esi
  410f40:	mov    QWORD PTR [rsp+0x10],rsi
  410f45:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  410f4b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  410f50:	jmp    410f63 <__swc_fn_e121059d_000122_12b4ed22+0xe3>
  410f52:	lea    rcx,[rip+0x25c7]        # 413520 <__swc_rdata_base_e121059d+0x410>
  410f59:	call   4098c0 <__swc_fn_e121059d_000117_035d76a1>
  410f5e:	call   410dc0 <__swc_fn_e121059d_000119_7f430081>
  410f63:	add    rsp,0x30
  410f67:	pop    rdi
  410f68:	pop    rsi
  410f69:	pop    rbx
  410f6a:	ret
  410f6b:	add    BYTE PTR [rax],al
  410f6d:	add    BYTE PTR [rax],al
	...

0000000000410f70 <__swc_fn_e121059d_000125_667fbf24>:
  410f70:	push   rdi
  410f71:	push   rsi
  410f72:	sub    rsp,0xa8
  410f79:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  410f7f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410f85:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  410f8b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410f91:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410f97:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  410f9d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410fa3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410fa9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410fb2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  410fbb:	mov    edi,ecx
  410fbd:	xor    eax,eax
  410fbf:	call   4071e0 <pthread_key_delete@plt>
  410fc4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410fca:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410fd0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410fd6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410fdc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410fe2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410fe8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410fee:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410ff4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410ffd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411006:	add    rsp,0xa8
  41100d:	pop    rsi
  41100e:	pop    rdi
  41100f:	ret

0000000000411010 <__swc_fn_e121059d_000128_8dffa290>:
  411010:	push   rdi
  411011:	push   rsi
  411012:	sub    rsp,0xa8
  411019:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41101f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411025:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41102b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411031:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411037:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41103d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411043:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411049:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411052:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41105b:	test   rcx,rcx
  41105e:	je     41106f <__swc_fn_e121059d_000128_8dffa290+0x5f>
  411060:	lea    rax,[rcx-0x1]
  411064:	mov    eax,eax
  411066:	mov    edi,eax
  411068:	xor    eax,eax
  41106a:	call   4071e0 <pthread_key_delete@plt>
  41106f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  411075:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  41107b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411081:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411087:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41108d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411093:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411099:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41109f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4110a8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4110b1:	add    rsp,0xa8
  4110b8:	pop    rsi
  4110b9:	pop    rdi
  4110ba:	ret
  4110bb:	add    BYTE PTR [rax],al
  4110bd:	add    BYTE PTR [rax],al
	...

00000000004110c0 <__swc_fn_e121059d_000131_c1196dfb>:
  4110c0:	push   rsi
  4110c1:	push   rdi
  4110c2:	sub    rsp,0xa8
  4110c9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4110cf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4110d5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4110db:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4110e1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4110e7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4110ed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4110f3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4110f9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411102:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41110b:	xor    eax,eax
  41110d:	call   4071f0 <gettid@plt>
  411112:	movsxd rax,eax
  411115:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41111b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411121:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411127:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41112d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411133:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411139:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41113f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411145:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41114e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411157:	add    rsp,0xa8
  41115e:	pop    rdi
  41115f:	pop    rsi
  411160:	ret
	...

0000000000411170 <__swc_fn_e121059d_000134_4b2af8da>:
  411170:	push   rbx
  411171:	push   rdi
  411172:	push   rsi
  411173:	sub    rsp,0xc0
  41117a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  411180:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  411186:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41118c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  411192:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  411198:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41119e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4111a4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4111ad:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4111b6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4111bf:	mov    rbx,rcx
  4111c2:	cs nop WORD PTR [rax+rax*1+0x0]
  4111cc:	nop    DWORD PTR [rax+0x0]
  4111d0:	mov    edx,0x80000000
  4111d5:	xor    eax,eax
  4111d7:	lock cmpxchg DWORD PTR [rbx],edx
  4111db:	test   eax,eax
  4111dd:	je     411214 <__swc_fn_e121059d_000134_4b2af8da+0xa4>
  4111df:	mov    eax,DWORD PTR [rbx]
  4111e1:	lea    rcx,[rsp+0x14]
  4111e6:	mov    DWORD PTR [rsp+0x14],eax
  4111ea:	test   eax,eax
  4111ec:	je     4111d0 <__swc_fn_e121059d_000134_4b2af8da+0x60>
  4111ee:	mov    QWORD PTR [rsp],0x0
  4111f6:	mov    edi,0xca
  4111fb:	mov    rsi,rbx
  4111fe:	mov    edx,0x80
  411203:	mov    ecx,DWORD PTR [rcx]
  411205:	xor    r8d,r8d
  411208:	xor    r9d,r9d
  41120b:	xor    eax,eax
  41120d:	call   4071a0 <syscall@plt>
  411212:	jmp    4111d0 <__swc_fn_e121059d_000134_4b2af8da+0x60>
  411214:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  41121a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411220:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411226:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41122c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411232:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411238:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41123e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  411247:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  411250:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  411259:	add    rsp,0xc0
  411260:	pop    rsi
  411261:	pop    rdi
  411262:	pop    rbx
  411263:	ret
	...

0000000000411270 <__swc_fn_e121059d_000137_3e875c27>:
  411270:	sub    rsp,0x8
  411274:	call   409d80 <__swc_fn_e121059d_000135_29412410>
  411279:	add    rsp,0x8
  41127d:	ret
	...

0000000000411280 <__swc_fn_e121059d_000140_7c02fe26>:
  411280:	push   rdi
  411281:	push   rsi
  411282:	sub    rsp,0xa8
  411289:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41128f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411295:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41129b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4112a1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4112a7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4112ad:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4112b3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4112b9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4112c2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4112cb:	mov    edi,0x28
  4112d0:	xor    eax,eax
  4112d2:	call   4071c0 <malloc@plt>
  4112d7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4112dd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4112e3:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4112e9:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4112ef:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4112f5:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4112fb:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411301:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411307:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411310:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411319:	add    rsp,0xa8
  411320:	pop    rsi
  411321:	pop    rdi
  411322:	ret
	...

0000000000411330 <__swc_fn_e121059d_000143_56e56812>:
  411330:	mov    QWORD PTR [r8],0x0
  411337:	cmp    rdx,0x10
  41133b:	jae    411340 <__swc_fn_e121059d_000143_56e56812+0x10>
  41133d:	xor    eax,eax
  41133f:	ret
  411340:	mov    eax,DWORD PTR [rcx]
  411342:	cmp    eax,0x42445753
  411348:	jne    411352 <__swc_fn_e121059d_000143_56e56812+0x22>
  41134a:	mov    eax,DWORD PTR [rcx+0x4]
  41134d:	cmp    eax,0x1
  411350:	je     411355 <__swc_fn_e121059d_000143_56e56812+0x25>
  411352:	xor    eax,eax
  411354:	ret
  411355:	mov    QWORD PTR [r8],rdx
  411358:	mov    rax,rcx
  41135b:	ret
  41135c:	add    BYTE PTR [rax],al
	...

0000000000411360 <__swc_fn_e121059d_000146_863755b5>:
  411360:	push   rbx
  411361:	sub    rsp,0xe0
  411368:	lea    rbx,[rsp+0x8]
  41136d:	vxorps xmm0,xmm0,xmm0
  411371:	vmovups XMMWORD PTR [rbx],xmm0
  411375:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  41137a:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  41137f:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  411384:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  411389:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  41138e:	mov    DWORD PTR [rbx+0x60],0x0
  411395:	mov    r8,rbx
  411398:	mov    rdx,rcx
  41139b:	nop    DWORD PTR [rax+rax*1+0x0]
  4113a0:	mov    r9,rdx
  4113a3:	movabs rdx,0x6666666666666667
  4113ad:	mov    rax,r9
  4113b0:	imul   rdx
  4113b3:	sar    rdx,0x2
  4113b7:	mov    r10,rdx
  4113ba:	shr    rdx,0x3f
  4113be:	add    r10,rdx
  4113c1:	mov    rdx,r10
  4113c4:	imul   r11,r10,0xa
  4113c8:	sub    r9,r11
  4113cb:	mov    r11,QWORD PTR [rip+0x216e]        # 413540 <__swc_rdata_base_e121059d+0x430>
  4113d2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  4113d7:	mov    BYTE PTR [r8],r9b
  4113da:	lea    r9,[r8+0x1]
  4113de:	mov    r8,r9
  4113e1:	test   r10,r10
  4113e4:	jne    4113a0 <__swc_fn_e121059d_000146_863755b5+0x40>
  4113e6:	test   rcx,rcx
  4113e9:	jge    4113f3 <__swc_fn_e121059d_000146_863755b5+0x93>
  4113eb:	mov    BYTE PTR [r9],0x2d
  4113ef:	add    r8,0x1
  4113f3:	mov    BYTE PTR [r8],0x0
  4113f7:	sub    r8,0x1
  4113fb:	mov    rax,rbx
  4113fe:	cmp    rax,r8
  411401:	jae    411426 <__swc_fn_e121059d_000146_863755b5+0xc6>
  411403:	cs nop WORD PTR [rax+rax*1+0x0]
  41140d:	nop    DWORD PTR [rax]
  411410:	mov    cl,BYTE PTR [r8]
  411413:	mov    dl,BYTE PTR [rax]
  411415:	mov    BYTE PTR [r8],dl
  411418:	sub    r8,0x1
  41141c:	mov    BYTE PTR [rax],cl
  41141e:	inc    rax
  411421:	cmp    rax,r8
  411424:	jb     411410 <__swc_fn_e121059d_000146_863755b5+0xb0>
  411426:	xor    eax,eax
  411428:	test   rbx,rbx
  41142b:	je     41144e <__swc_fn_e121059d_000146_863755b5+0xee>
  41142d:	mov    rcx,rbx
  411430:	mov    dl,BYTE PTR [rcx]
  411432:	test   dl,dl
  411434:	je     41144e <__swc_fn_e121059d_000146_863755b5+0xee>
  411436:	cs nop WORD PTR [rax+rax*1+0x0]
  411440:	add    rcx,0x1
  411444:	add    rax,0x1
  411448:	mov    dl,BYTE PTR [rcx]
  41144a:	test   dl,dl
  41144c:	jne    411440 <__swc_fn_e121059d_000146_863755b5+0xe0>
  41144e:	mov    QWORD PTR [rbx+0xa8],rbx
  411455:	mov    QWORD PTR [rbx+0xb0],rax
  41145c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  411464:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  41146c:	lea    rcx,[rbx+0xb8]
  411473:	call   4098c0 <__swc_fn_e121059d_000117_035d76a1>
  411478:	add    rsp,0xe0
  41147f:	pop    rbx
  411480:	ret
	...

0000000000411490 <__swc_fn_e121059d_000149_9e4bc402>:
  411490:	vxorps xmm0,xmm0,xmm0
  411494:	vmovups XMMWORD PTR [rcx],xmm0
  411498:	mov    QWORD PTR [rcx+0x10],0x0
  4114a0:	ret
	...

00000000004114b0 <__swc_fn_e121059d_000152_9e4bc402>:
  4114b0:	vxorps xmm0,xmm0,xmm0
  4114b4:	vmovups XMMWORD PTR [rcx],xmm0
  4114b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4114bd:	vxorps xmm0,xmm0,xmm0
  4114c1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4114c6:	vmovups xmm0,XMMWORD PTR [rip+0x216a]        # 413638 <__swc_rdata_base_e121059d+0x528>
  4114ce:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4114d3:	vxorps xmm0,xmm0,xmm0
  4114d7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  4114dc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  4114e1:	mov    QWORD PTR [rcx+0x60],0x0
  4114e9:	ret
  4114ea:	add    BYTE PTR [rax],al
  4114ec:	add    BYTE PTR [rax],al
	...

00000000004114f0 <__swc_fn_e121059d_000155_9e4bc402>:
  4114f0:	vxorps xmm0,xmm0,xmm0
  4114f4:	vmovups XMMWORD PTR [rcx],xmm0
  4114f8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4114fd:	vxorps xmm0,xmm0,xmm0
  411501:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411506:	vmovups xmm0,XMMWORD PTR [rip+0x2252]        # 413760 <__swc_rdata_base_e121059d+0x650>
  41150e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411513:	vxorps xmm0,xmm0,xmm0
  411517:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  41151c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411521:	vxorps xmm0,xmm0,xmm0
  411525:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  41152a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  41152f:	vxorps xmm0,xmm0,xmm0
  411533:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  41153b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  411543:	vxorps xmm0,xmm0,xmm0
  411547:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  41154f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  411557:	vxorps xmm0,xmm0,xmm0
  41155b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  411563:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  41156b:	mov    QWORD PTR [rcx+0xe0],0x0
  411576:	ret
	...

0000000000411580 <__swc_fn_e121059d_000158_232ffa22>:
  411580:	push   rbx
  411581:	mov    rbx,rcx
  411584:	call   40b350 <__swc_fn_e121059d_000159_b43b2f96>
  411589:	mov    rax,QWORD PTR [rbx+0x10]
  41158d:	test   rax,rax
  411590:	je     4115a1 <__swc_fn_e121059d_000158_232ffa22+0x21>
  411592:	mov    rcx,rbx
  411595:	mov    rdx,rax
  411598:	mov    r8,QWORD PTR [rbx+0x18]
  41159c:	call   40e700 <__swc_fn_e121059d_000157_2745c4a5>
  4115a1:	vxorps xmm0,xmm0,xmm0
  4115a5:	vmovups XMMWORD PTR [rbx],xmm0
  4115a9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  4115ae:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  4115b3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  4115b8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  4115bd:	mov    QWORD PTR [rbx+0x50],0x0
  4115c5:	pop    rbx
  4115c6:	ret
	...

00000000004115e0 <__swc_fn_e121059d_000161_01cbb887>:
  4115e0:	sub    rsp,0x10
  4115e4:	mov    eax,r8d
  4115e7:	mov    r8d,r9d
  4115ea:	test   r9d,r9d
  4115ed:	jne    411606 <__swc_fn_e121059d_000161_01cbb887+0x26>
  4115ef:	vmovups xmm0,XMMWORD PTR [rip+0x2221]        # 413818 <__swc_rdata_base_e121059d+0x708>
  4115f7:	vmovups XMMWORD PTR [r10],xmm0
  4115fc:	mov    eax,0x1
  411601:	add    rsp,0x10
  411605:	ret
  411606:	mov    r9,r8
  411609:	cmp    r8,rax
  41160c:	jb     411613 <__swc_fn_e121059d_000161_01cbb887+0x33>
  41160e:	cmp    r9,rdx
  411611:	jb     41161a <__swc_fn_e121059d_000161_01cbb887+0x3a>
  411613:	xor    eax,eax
  411615:	add    rsp,0x10
  411619:	ret
  41161a:	xor    eax,eax
  41161c:	lea    r8,[r9+rax*1]
  411620:	cmp    r8,rdx
  411623:	jae    411653 <__swc_fn_e121059d_000161_01cbb887+0x73>
  411625:	cs nop WORD PTR [rax+rax*1+0x0]
  41162f:	cs nop WORD PTR [rax+rax*1+0x0]
  411639:	nop    DWORD PTR [rax+0x0]
  411640:	cmp    BYTE PTR [rcx+r8*1],0x0
  411645:	je     411653 <__swc_fn_e121059d_000161_01cbb887+0x73>
  411647:	inc    rax
  41164a:	lea    r8,[r9+rax*1]
  41164e:	cmp    r8,rdx
  411651:	jb     411640 <__swc_fn_e121059d_000161_01cbb887+0x60>
  411653:	cmp    r8,rdx
  411656:	jne    41165f <__swc_fn_e121059d_000161_01cbb887+0x7f>
  411658:	xor    eax,eax
  41165a:	add    rsp,0x10
  41165e:	ret
  41165f:	add    rcx,r9
  411662:	mov    QWORD PTR [rsp],rcx
  411666:	mov    QWORD PTR [rsp+0x8],rax
  41166b:	vmovups xmm0,XMMWORD PTR [rsp]
  411670:	vmovups XMMWORD PTR [r10],xmm0
  411675:	mov    eax,0x1
  41167a:	add    rsp,0x10
  41167e:	ret
	...

0000000000411680 <__swc_fn_e121059d_000164_8e41797b>:
  411680:	push   rbp
  411681:	push   rbx
  411682:	push   rsi
  411683:	push   rdi
  411684:	push   r12
  411686:	push   r13
  411688:	push   r14
  41168a:	push   r15
  41168c:	sub    rsp,0x10
  411690:	mov    rbp,rsp
  411693:	vmovups XMMWORD PTR [rsp],xmm6
  411698:	sub    rsp,0x50
  41169c:	mov    rbx,rsp
  41169f:	mov    rsi,r8
  4116a2:	mov    QWORD PTR [rsp+0x30],r8
  4116a7:	mov    rdi,rcx
  4116aa:	mov    QWORD PTR [rsp+0x38],rcx
  4116af:	mov    r12,rdx
  4116b2:	xor    r13b,r13b
  4116b5:	mov    r14,QWORD PTR [rdi+0x8]
  4116b9:	mov    QWORD PTR [rsp+0x40],r14
  4116be:	xor    r15d,r15d
  4116c1:	test   r14,r14
  4116c4:	jbe    41191e <__swc_fn_e121059d_000164_8e41797b+0x29e>
  4116ca:	mov    r14,QWORD PTR [rdi]
  4116cd:	mov    rax,QWORD PTR [rsp+0x40]
  4116d2:	mov    QWORD PTR [rsp+0x48],r14
  4116d7:	vmovups xmm6,XMMWORD PTR [rip+0x1d59]        # 413438 <__swc_rdata_base_e121059d+0x328>
  4116df:	nop
  4116e0:	cmp    QWORD PTR [r14+r15*8],0x0
  4116e5:	jne    4116ef <__swc_fn_e121059d_000164_8e41797b+0x6f>
  4116e7:	mov    r14,rax
  4116ea:	jmp    4118fe <__swc_fn_e121059d_000164_8e41797b+0x27e>
  4116ef:	mov    rcx,QWORD PTR [rdi]
  4116f2:	mov    rdx,QWORD PTR [rcx+r15*8]
  4116f6:	mov    rdi,rbx
  4116f9:	mov    rcx,rdi
  4116fc:	sub    rsp,0x8
  411700:	mov    r14,rax
  411703:	call   40e780 <__swc_fn_e121059d_000163_60216e69>
  411708:	add    rsp,0x8
  41170c:	mov    al,BYTE PTR [rbx]
  41170e:	test   al,al
  411710:	je     4118fe <__swc_fn_e121059d_000164_8e41797b+0x27e>
  411716:	mov    al,BYTE PTR [rbx+0x1]
  411719:	test   al,al
  41171b:	jne    411726 <__swc_fn_e121059d_000164_8e41797b+0xa6>
  41171d:	test   sil,sil
  411720:	je     4118fe <__swc_fn_e121059d_000164_8e41797b+0x27e>
  411726:	test   r13b,r13b
  411729:	jne    4117e7 <__swc_fn_e121059d_000164_8e41797b+0x167>
  41172f:	test   r12,r12
  411732:	je     4117e7 <__swc_fn_e121059d_000164_8e41797b+0x167>
  411738:	mov    al,BYTE PTR [rbx+0x1]
  41173b:	test   al,al
  41173d:	je     4118fe <__swc_fn_e121059d_000164_8e41797b+0x27e>
  411743:	mov    eax,DWORD PTR [rbx+0x28]
  411746:	cmp    DWORD PTR [r12+0x20],eax
  41174b:	jne    4118fe <__swc_fn_e121059d_000164_8e41797b+0x27e>
  411751:	mov    rax,QWORD PTR [r12]
  411755:	mov    rcx,QWORD PTR [r12+0x8]
  41175a:	cmp    QWORD PTR [rbx+0x20],rcx
  41175e:	jne    4118fe <__swc_fn_e121059d_000164_8e41797b+0x27e>
  411764:	mov    cl,0x1
  411766:	test   rax,rax
  411769:	je     4117d2 <__swc_fn_e121059d_000164_8e41797b+0x152>
  41176f:	mov    rdx,QWORD PTR [rbx+0x20]
  411773:	xor    r8d,r8d
  411776:	test   rdx,rdx
  411779:	jbe    4117d2 <__swc_fn_e121059d_000164_8e41797b+0x152>
  41177b:	mov    r9,QWORD PTR [rbx+0x18]
  41177f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  411784:	cs nop WORD PTR [rax+rax*1+0x0]
  41178e:	xchg   ax,ax
  411790:	mov    r10b,BYTE PTR [rax+r8*1]
  411794:	cmp    BYTE PTR [r9+r8*1],r10b
  411798:	je     4117c9 <__swc_fn_e121059d_000164_8e41797b+0x149>
  41179a:	vmovq  r10,xmm0
  41179f:	cmp    BYTE PTR [r10+r8*1],0x5c
  4117a4:	jne    4117ad <__swc_fn_e121059d_000164_8e41797b+0x12d>
  4117a6:	cmp    BYTE PTR [rax+r8*1],0x2f
  4117ab:	je     4117c9 <__swc_fn_e121059d_000164_8e41797b+0x149>
  4117ad:	vmovq  r10,xmm0
  4117b2:	cmp    BYTE PTR [r10+r8*1],0x2f
  4117b7:	jne    4117c0 <__swc_fn_e121059d_000164_8e41797b+0x140>
  4117b9:	cmp    BYTE PTR [rax+r8*1],0x5c
  4117be:	je     4117c9 <__swc_fn_e121059d_000164_8e41797b+0x149>
  4117c0:	xor    eax,eax
  4117c2:	movzx  eax,al
  4117c5:	mov    cl,al
  4117c7:	jmp    4117d2 <__swc_fn_e121059d_000164_8e41797b+0x152>
  4117c9:	add    r8,0x1
  4117cd:	cmp    r8,rdx
  4117d0:	jb     411790 <__swc_fn_e121059d_000164_8e41797b+0x110>
  4117d2:	test   cl,cl
  4117d4:	je     4118fe <__swc_fn_e121059d_000164_8e41797b+0x27e>
  4117da:	mov    eax,0x1
  4117df:	mov    r13b,al
  4117e2:	jmp    4118fe <__swc_fn_e121059d_000164_8e41797b+0x27e>
  4117e7:	mov    r13b,0x1
  4117ea:	sub    rsp,0x20
  4117ee:	mov    rax,rsp
  4117f1:	lea    rcx,[rdi+0x8]
  4117f5:	mov    QWORD PTR [rax],rcx
  4117f8:	lea    rsi,[rip+0x1b11]        # 413310 <__swc_rdata_base_e121059d+0x200>
  4117ff:	mov    QWORD PTR [rax+0x8],rsi
  411803:	mov    QWORD PTR [rax+0x10],rsp
  411807:	mov    QWORD PTR [rax+0x18],0x1
  41180f:	lea    rcx,[rsp+0x10]
  411814:	sub    rsp,0x8
  411818:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  41181d:	add    rsp,0x8
  411821:	add    rsp,0x20
  411825:	mov    al,BYTE PTR [rbx+0x1]
  411828:	test   al,al
  41182a:	je     4118c7 <__swc_fn_e121059d_000164_8e41797b+0x247>
  411830:	lea    rax,[rip+0x2081]        # 4138b8 <__swc_rdata_base_e121059d+0x7a8>
  411837:	sub    rsp,0x20
  41183b:	mov    rcx,rsp
  41183e:	mov    QWORD PTR [rcx],rax
  411841:	mov    QWORD PTR [rcx+0x8],rsi
  411845:	mov    QWORD PTR [rcx+0x10],rsp
  411849:	mov    QWORD PTR [rcx+0x18],0x1
  411851:	lea    rcx,[rsp+0x10]
  411856:	sub    rsp,0x8
  41185a:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  41185f:	add    rsp,0x8
  411863:	add    rsp,0x20
  411867:	mov    eax,DWORD PTR [rbx+0x28]
  41186a:	sub    rsp,0x60
  41186e:	mov    rcx,rsp
  411871:	lea    rdx,[rdi+0x18]
  411875:	mov    QWORD PTR [rcx+0x18],rdx
  411879:	mov    QWORD PTR [rcx+0x20],rsi
  41187d:	vmovups XMMWORD PTR [rcx],xmm6
  411881:	mov    QWORD PTR [rcx+0x28],rsp
  411885:	mov    QWORD PTR [rcx+0x30],rsi
  411889:	mov    DWORD PTR [rcx+0x10],eax
  41188c:	lea    rax,[rsp+0x10]
  411891:	mov    QWORD PTR [rcx+0x38],rax
  411895:	lea    rax,[rip+0x1b34]        # 4133d0 <__swc_rdata_base_e121059d+0x2c0>
  41189c:	mov    QWORD PTR [rcx+0x40],rax
  4118a0:	lea    rax,[rsp+0x18]
  4118a5:	mov    QWORD PTR [rcx+0x48],rax
  4118a9:	mov    QWORD PTR [rcx+0x50],0x3
  4118b1:	lea    rcx,[rsp+0x48]
  4118b6:	sub    rsp,0x8
  4118ba:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  4118bf:	add    rsp,0x8
  4118c3:	add    rsp,0x60
  4118c7:	lea    rax,[rip+0x1a9a]        # 413368 <__swc_rdata_base_e121059d+0x258>
  4118ce:	sub    rsp,0x20
  4118d2:	mov    rcx,rsp
  4118d5:	mov    QWORD PTR [rcx],rax
  4118d8:	mov    QWORD PTR [rcx+0x8],rsi
  4118dc:	mov    QWORD PTR [rcx+0x10],rsp
  4118e0:	mov    QWORD PTR [rcx+0x18],0x1
  4118e8:	lea    rcx,[rsp+0x10]
  4118ed:	sub    rsp,0x8
  4118f1:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  4118f6:	add    rsp,0x8
  4118fa:	add    rsp,0x20
  4118fe:	add    r15,0x1
  411902:	cmp    r15,r14
  411905:	jae    41191e <__swc_fn_e121059d_000164_8e41797b+0x29e>
  411907:	mov    rsi,QWORD PTR [rsp+0x30]
  41190c:	mov    rdi,QWORD PTR [rsp+0x38]
  411911:	mov    rax,r14
  411914:	mov    r14,QWORD PTR [rsp+0x48]
  411919:	jmp    4116e0 <__swc_fn_e121059d_000164_8e41797b+0x60>
  41191e:	add    rsp,0x50
  411922:	vmovups xmm6,XMMWORD PTR [rsp]
  411927:	add    rsp,0x10
  41192b:	pop    r15
  41192d:	pop    r14
  41192f:	pop    r13
  411931:	pop    r12
  411933:	pop    rdi
  411934:	pop    rsi
  411935:	pop    rbx
  411936:	pop    rbp
  411937:	ret
	...

0000000000411940 <__swc_fn_e121059d_000167_f6173642>:
  411940:	sub    rsp,0x8
  411944:	call   409b50 <__swc_fn_e121059d_000126_ce762363>
  411949:	add    rsp,0x8
  41194d:	ret
	...

0000000000411950 <__swc_fn_e121059d_000170_4579a84c>:
  411950:	push   rsi
  411951:	sub    rsp,0x30
  411955:	lea    rsi,[rip+0x15444]        # 426da0 <__swc_bss_base_e121059d+0x2d60>
  41195c:	mov    rax,QWORD PTR [rsi]
  41195f:	test   rax,rax
  411962:	je     41196a <__swc_fn_e121059d_000170_4579a84c+0x1a>
  411964:	add    rsp,0x30
  411968:	pop    rsi
  411969:	ret
  41196a:	mov    ecx,0x2
  41196f:	mov    edx,0x8020
  411974:	call   4091c0 <__swc_fn_e121059d_000108_4796e893>
  411979:	test   rax,rax
  41197c:	jne    41198d <__swc_fn_e121059d_000170_4579a84c+0x3d>
  41197e:	mov    QWORD PTR [rsp+0x18],rax
  411983:	call   410dc0 <__swc_fn_e121059d_000119_7f430081>
  411988:	mov    rax,QWORD PTR [rsp+0x18]
  41198d:	mov    rcx,rax
  411990:	xchg   QWORD PTR [rsi],rcx
  411993:	add    rsp,0x30
  411997:	pop    rsi
  411998:	ret
  411999:	add    BYTE PTR [rax],al
  41199b:	add    BYTE PTR [rax],al
  41199d:	add    BYTE PTR [rax],al
	...

00000000004119a0 <__swc_fn_e121059d_000173_97fbc432>:
  4119a0:	push   rsi
  4119a1:	test   r8,r8
  4119a4:	jne    4119a8 <__swc_fn_e121059d_000173_97fbc432+0x8>
  4119a6:	pop    rsi
  4119a7:	ret
  4119a8:	lea    rax,[rcx+0x18]
  4119ac:	mov    r10,QWORD PTR [rax]
  4119af:	lea    r11,[r10+0x1]
  4119b3:	mov    QWORD PTR [rax],r11
  4119b6:	mov    r11,rdx
  4119b9:	not    rdx
  4119bc:	lea    rsi,[r8-0x1]
  4119c0:	cmp    rsi,rdx
  4119c3:	ja     4119e3 <__swc_fn_e121059d_000173_97fbc432+0x43>
  4119c5:	lea    rdx,[r11+r8*1]
  4119c9:	dec    rdx
  4119cc:	shr    rdx,0x6
  4119d0:	mov    r8,r11
  4119d3:	shr    r8,0x6
  4119d7:	mov    rsi,rdx
  4119da:	sub    rsi,r8
  4119dd:	cmp    rsi,0x8
  4119e1:	jb     4119f9 <__swc_fn_e121059d_000173_97fbc432+0x59>
  4119e3:	lea    rcx,[rcx+0x10]
  4119e7:	mov    rdx,QWORD PTR [rcx]
  4119ea:	add    rdx,r9
  4119ed:	mov    QWORD PTR [rcx],rdx
  4119f0:	lea    rcx,[r10+0x2]
  4119f4:	mov    QWORD PTR [rax],rcx
  4119f7:	pop    rsi
  4119f8:	ret
  4119f9:	shr    r11,0x6
  4119fd:	nop    DWORD PTR [rax]
  411a00:	cmp    r11,rdx
  411a03:	ja     411a43 <__swc_fn_e121059d_000173_97fbc432+0xa3>
  411a05:	jmp    411a16 <__swc_fn_e121059d_000173_97fbc432+0x76>
  411a07:	nop    WORD PTR [rax+rax*1+0x0]
  411a10:	add    r11,0x1
  411a14:	jmp    411a00 <__swc_fn_e121059d_000173_97fbc432+0x60>
  411a16:	mov    r8,r11
  411a19:	shr    r8,0xc
  411a1d:	mov    rsi,r11
  411a20:	xor    rsi,r8
  411a23:	mov    r8,r11
  411a26:	shr    r8,0x18
  411a2a:	xor    rsi,r8
  411a2d:	and    esi,0xfff
  411a33:	lea    r8,[rcx+rsi*8+0x20]
  411a38:	mov    rsi,QWORD PTR [r8]
  411a3b:	add    rsi,r9
  411a3e:	mov    QWORD PTR [r8],rsi
  411a41:	jmp    411a10 <__swc_fn_e121059d_000173_97fbc432+0x70>
  411a43:	lea    rcx,[r10+0x2]
  411a47:	mov    QWORD PTR [rax],rcx
  411a4a:	pop    rsi
  411a4b:	ret
  411a4c:	add    BYTE PTR [rax],al
	...

0000000000411a50 <__swc_fn_e121059d_000176_e7f0b636>:
  411a50:	push   rsi
  411a51:	push   rdi
  411a52:	push   r12
  411a54:	mov    rsi,r8
  411a57:	mov    rdi,rcx
  411a5a:	mov    r12,rdx
  411a5d:	lea    rcx,[rdx*8+0x0]
  411a65:	call   40b860 <__swc_fn_e121059d_000177_2744b483>
  411a6a:	mov    QWORD PTR [rdi],rax
  411a6d:	lea    rcx,[r12*8+0x0]
  411a75:	call   40b860 <__swc_fn_e121059d_000177_2744b483>
  411a7a:	mov    QWORD PTR [rdi+0x8],rax
  411a7e:	lea    rcx,[r12*8+0x0]
  411a86:	call   40b860 <__swc_fn_e121059d_000177_2744b483>
  411a8b:	mov    QWORD PTR [rdi+0x10],rax
  411a8f:	mov    rcx,r12
  411a92:	call   40b860 <__swc_fn_e121059d_000177_2744b483>
  411a97:	mov    QWORD PTR [rdi+0x18],rax
  411a9b:	mov    rcx,rax
  411a9e:	xor    al,al
  411aa0:	mov    rdx,rax
  411aa3:	mov    r8,r12
  411aa6:	call   409100 <__swc_fn_e121059d_000105_5f646f9d>
  411aab:	mov    QWORD PTR [rdi+0x20],rsi
  411aaf:	lea    rax,[r12-0x1]
  411ab4:	mov    QWORD PTR [rdi+0x28],rax
  411ab8:	mov    QWORD PTR [rdi+0x30],0x0
  411ac0:	pop    r12
  411ac2:	pop    rdi
  411ac3:	pop    rsi
  411ac4:	ret
	...

0000000000411ae0 <__swc_fn_e121059d_000179_68d30882>:
  411ae0:	push   rbp
  411ae1:	push   rbx
  411ae2:	push   rsi
  411ae3:	push   rdi
  411ae4:	push   r12
  411ae6:	push   r13
  411ae8:	push   r14
  411aea:	push   r15
  411aec:	sub    rsp,0x50
  411af0:	mov    rbp,rsp
  411af3:	vmovups XMMWORD PTR [rsp],xmm6
  411af8:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  411afe:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  411b04:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  411b0a:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  411b10:	sub    rsp,0x8b0
  411b17:	mov    rbx,rsp
  411b1a:	sub    rsp,0x8
  411b1e:	mov    ecx,0x124f800
  411b23:	call   40b860 <__swc_fn_e121059d_000177_2744b483>
  411b28:	mov    rsi,rax
  411b2b:	mov    QWORD PTR [rsp+0x7a8],rax
  411b33:	xor    ecx,ecx
  411b35:	xor    r8d,r8d
  411b38:	mov    QWORD PTR [rsp+0x7b0],r8
  411b40:	lea    r9,[rbx+0xa0]
  411b47:	lea    r10,[rbx+0xf0]
  411b4e:	lea    r11,[rbx+0x168]
  411b55:	mov    QWORD PTR [rsp+0x7b8],r11
  411b5d:	lea    rdi,[rbx+0x1b0]
  411b64:	mov    QWORD PTR [rsp+0x7c0],rdi
  411b6c:	nop    DWORD PTR [rax+0x0]
  411b70:	test   r8,r8
  411b73:	jbe    411b7d <__swc_fn_e121059d_000179_68d30882+0x9d>
  411b75:	mov    BYTE PTR [rsi+rcx*1],0xa
  411b79:	add    rcx,0x1
  411b7d:	lea    r12,[rip+0x1d94]        # 413918 <__swc_rdata_base_e121059d+0x808>
  411b84:	mov    r13,QWORD PTR [rip+0x10485]        # 422010 <__swc_data_base_e121059d+0x10>
  411b8b:	imul   r13,r13,0x41a7
  411b92:	movabs rdx,0x200000005
  411b9c:	mov    r11,rax
  411b9f:	mov    rax,r13
  411ba2:	mul    rdx
  411ba5:	mov    r14,rdx
  411ba8:	mov    rdx,r13
  411bab:	sub    rdx,r14
  411bae:	shr    rdx,1
  411bb1:	add    rdx,r14
  411bb4:	shr    rdx,0x1e
  411bb8:	imul   r14,rdx,0x7fffffff
  411bbf:	sub    r13,r14
  411bc2:	mov    QWORD PTR [rip+0x10447],r13        # 422010 <__swc_data_base_e121059d+0x10>
  411bc9:	mov    edx,r13d
  411bcc:	and    edx,0x7
  411bcf:	add    rdx,rdx
  411bd2:	mov    r14,QWORD PTR [r12+rdx*8]
  411bd6:	mov    r12,QWORD PTR [r12+rdx*8+0x8]
  411bdb:	imul   r13,r13,0x41a7
  411be2:	movabs rdx,0x200000005
  411bec:	mov    rax,r13
  411bef:	mul    rdx
  411bf2:	mov    r15,rdx
  411bf5:	mov    rdx,r13
  411bf8:	sub    rdx,r15
  411bfb:	shr    rdx,1
  411bfe:	add    rdx,r15
  411c01:	shr    rdx,0x1e
  411c05:	imul   r15,rdx,0x7fffffff
  411c0c:	sub    r13,r15
  411c0f:	mov    QWORD PTR [rip+0x103fa],r13        # 422010 <__swc_data_base_e121059d+0x10>
  411c16:	movabs rdx,0xaaaaaaaaaaaaaaab
  411c20:	mov    rax,r13
  411c23:	mul    rdx
  411c26:	mov    r15,rdx
  411c29:	shr    r15,1
  411c2c:	lea    r15,[r15+r15*2]
  411c30:	mov    rdx,r13
  411c33:	sub    rdx,r15
  411c36:	lea    r15,[rdx+0x7e8]
  411c3d:	imul   r13,r13,0x41a7
  411c44:	movabs rdx,0x200000005
  411c4e:	mov    rax,r13
  411c51:	mul    rdx
  411c54:	mov    rdi,rdx
  411c57:	mov    rdx,r13
  411c5a:	sub    rdx,rdi
  411c5d:	shr    rdx,1
  411c60:	add    rdx,rdi
  411c63:	shr    rdx,0x1e
  411c67:	imul   rdi,rdx,0x7fffffff
  411c6e:	sub    r13,rdi
  411c71:	mov    QWORD PTR [rip+0x10398],r13        # 422010 <__swc_data_base_e121059d+0x10>
  411c78:	movabs rdx,0xaaaaaaaaaaaaaaab
  411c82:	mov    rax,r13
  411c85:	mul    rdx
  411c88:	mov    rdi,rdx
  411c8b:	shr    rdi,0x3
  411c8f:	imul   rdi,rdi,0xc
  411c93:	mov    rdx,r13
  411c96:	sub    rdx,rdi
  411c99:	lea    rdi,[rdx+0x1]
  411c9d:	imul   r13,r13,0x41a7
  411ca4:	movabs rdx,0x200000005
  411cae:	mov    QWORD PTR [rsp+0x878],rcx
  411cb6:	mov    rcx,r11
  411cb9:	mov    rax,r13
  411cbc:	mul    rdx
  411cbf:	mov    r11,rdx
  411cc2:	mov    rax,rcx
  411cc5:	mov    rcx,QWORD PTR [rsp+0x878]
  411ccd:	mov    rdx,r13
  411cd0:	sub    rdx,r11
  411cd3:	shr    rdx,1
  411cd6:	add    rdx,r11
  411cd9:	shr    rdx,0x1e
  411cdd:	imul   r11,rdx,0x7fffffff
  411ce4:	sub    r13,r11
  411ce7:	mov    QWORD PTR [rip+0x10322],r13        # 422010 <__swc_data_base_e121059d+0x10>
  411cee:	mov    r11,r13
  411cf1:	shr    r11,0x2
  411cf5:	movabs rdx,0x4924924924924925
  411cff:	mov    QWORD PTR [rsp+0x880],rcx
  411d07:	mov    rcx,rax
  411d0a:	mov    rax,r11
  411d0d:	mul    rdx
  411d10:	mov    r11,rdx
  411d13:	mov    rax,rcx
  411d16:	mov    rcx,QWORD PTR [rsp+0x880]
  411d1e:	shr    r11,1
  411d21:	imul   r11,r11,0x1c
  411d25:	mov    rdx,r13
  411d28:	sub    rdx,r11
  411d2b:	lea    r11,[rdx+0x1]
  411d2f:	mov    QWORD PTR [rsp+0x7d8],r11
  411d37:	imul   r13,r13,0x41a7
  411d3e:	movabs rdx,0x200000005
  411d48:	mov    QWORD PTR [rsp+0x888],rcx
  411d50:	mov    rcx,rax
  411d53:	mov    rax,r13
  411d56:	mul    rdx
  411d59:	mov    r11,rdx
  411d5c:	mov    rax,rcx
  411d5f:	mov    rcx,QWORD PTR [rsp+0x888]
  411d67:	mov    rdx,r13
  411d6a:	sub    rdx,r11
  411d6d:	shr    rdx,1
  411d70:	add    rdx,r11
  411d73:	shr    rdx,0x1e
  411d77:	imul   r11,rdx,0x7fffffff
  411d7e:	sub    r13,r11
  411d81:	mov    QWORD PTR [rip+0x10288],r13        # 422010 <__swc_data_base_e121059d+0x10>
  411d88:	mov    r11,r13
  411d8b:	shr    r11,1
  411d8e:	movabs rdx,0xa3d70a3d70a3d70b
  411d98:	mov    QWORD PTR [rsp+0x890],rcx
  411da0:	mov    rcx,rax
  411da3:	mov    rax,r11
  411da6:	mul    rdx
  411da9:	mov    r11,rdx
  411dac:	mov    rax,rcx
  411daf:	mov    rcx,QWORD PTR [rsp+0x890]
  411db7:	shr    r11,0x4
  411dbb:	imul   r11,r11,0x32
  411dbf:	mov    rdx,r13
  411dc2:	sub    rdx,r11
  411dc5:	lea    r11,[rdx+0x1]
  411dc9:	mov    QWORD PTR [rsp+0x7e8],r11
  411dd1:	imul   r13,r13,0x41a7
  411dd8:	movabs rdx,0x200000005
  411de2:	mov    QWORD PTR [rsp+0x898],rcx
  411dea:	mov    rcx,rax
  411ded:	mov    rax,r13
  411df0:	mul    rdx
  411df3:	mov    r11,rdx
  411df6:	mov    rax,rcx
  411df9:	mov    rcx,QWORD PTR [rsp+0x898]
  411e01:	mov    rdx,r13
  411e04:	sub    rdx,r11
  411e07:	shr    rdx,1
  411e0a:	add    rdx,r11
  411e0d:	shr    rdx,0x1e
  411e11:	imul   r11,rdx,0x7fffffff
  411e18:	sub    r13,r11
  411e1b:	mov    QWORD PTR [rip+0x101ee],r13        # 422010 <__swc_data_base_e121059d+0x10>
  411e22:	movabs rdx,0xa7f0aa6670e5710d
  411e2c:	mov    QWORD PTR [rsp+0x8a0],rcx
  411e34:	mov    rcx,rax
  411e37:	mov    rax,r13
  411e3a:	mul    rdx
  411e3d:	mov    rax,rcx
  411e40:	mov    rcx,QWORD PTR [rsp+0x8a0]
  411e48:	shr    rdx,0x10
  411e4c:	imul   rdx,rdx,0x1863c
  411e53:	sub    r13,rdx
  411e56:	lea    r11,[r13+0x64]
  411e5a:	mov    QWORD PTR [rsp+0x7f8],r11
  411e62:	vxorps xmm0,xmm0,xmm0
  411e66:	vmovups XMMWORD PTR [rbx+0xa0],xmm0
  411e6e:	mov    QWORD PTR [rbx+0xb0],0x0
  411e79:	xor    r13d,r13d
  411e7c:	mov    rdx,r8
  411e7f:	test   r8,r8
  411e82:	jne    411e8e <__swc_fn_e121059d_000179_68d30882+0x3ae>
  411e84:	mov    BYTE PTR [r9],0x30
  411e88:	mov    r13d,0x1
  411e8e:	vmovsd xmm6,QWORD PTR [rsp+0x800]
  411e97:	vmovsd xmm7,QWORD PTR [rsp+0x8a8]
  411ea0:	test   rdx,rdx
  411ea3:	jbe    411f10 <__swc_fn_e121059d_000179_68d30882+0x430>
  411ea9:	cs nop WORD PTR [rax+rax*1+0x0]
  411eb3:	cs nop WORD PTR [rax+rax*1+0x0]
  411ebd:	nop    DWORD PTR [rax]
  411ec0:	mov    r8,rdx
  411ec3:	vmovq  xmm6,rdx
  411ec8:	movabs rdx,0xcccccccccccccccd
  411ed2:	vmovq  r11,xmm6
  411ed7:	vmovq  xmm7,rcx
  411edc:	mov    rcx,rax
  411edf:	mov    rax,r8
  411ee2:	mul    rdx
  411ee5:	mov    r8,rdx
  411ee8:	mov    rax,rcx
  411eeb:	vmovq  rcx,xmm7
  411ef0:	shr    r8,0x3
  411ef4:	imul   r8,r8,0xa
  411ef8:	sub    r11,r8
  411efb:	lea    r8,[r11+0x30]
  411eff:	mov    BYTE PTR [r9+r13*1],r8b
  411f03:	add    r13,0x1
  411f07:	shr    rdx,0x3
  411f0b:	test   rdx,rdx
  411f0e:	ja     411ec0 <__swc_fn_e121059d_000179_68d30882+0x3e0>
  411f10:	vmovsd QWORD PTR [rsp+0x800],xmm6
  411f19:	vmovsd QWORD PTR [rsp+0x8a8],xmm7
  411f22:	test   r13,r13
  411f25:	jbe    411f46 <__swc_fn_e121059d_000179_68d30882+0x466>
  411f27:	nop    WORD PTR [rax+rax*1+0x0]
  411f30:	lea    rdx,[r13-0x1]
  411f34:	mov    r13,rdx
  411f37:	mov    dl,BYTE PTR [r9+rdx*1]
  411f3b:	mov    BYTE PTR [rsi+rcx*1],dl
  411f3e:	inc    rcx
  411f41:	test   r13,r13
  411f44:	ja     411f30 <__swc_fn_e121059d_000179_68d30882+0x450>
  411f46:	mov    BYTE PTR [rsi+rcx*1],0x2c
  411f4a:	inc    rcx
  411f4d:	xor    edx,edx
  411f4f:	test   r12,r12
  411f52:	jbe    411f75 <__swc_fn_e121059d_000179_68d30882+0x495>
  411f54:	cs nop WORD PTR [rax+rax*1+0x0]
  411f5e:	xchg   ax,ax
  411f60:	mov    r8b,BYTE PTR [r14+rdx*1]
  411f64:	mov    BYTE PTR [rsi+rcx*1],r8b
  411f68:	add    rcx,0x1
  411f6c:	add    rdx,0x1
  411f70:	cmp    rdx,r12
  411f73:	jb     411f60 <__swc_fn_e121059d_000179_68d30882+0x480>
  411f75:	mov    BYTE PTR [rsi+rcx*1],0x2c
  411f79:	inc    rcx
  411f7c:	vxorps xmm0,xmm0,xmm0
  411f80:	vmovups XMMWORD PTR [rbx+0xf0],xmm0
  411f88:	mov    QWORD PTR [rbx+0x100],0x0
  411f93:	xor    r8d,r8d
  411f96:	mov    r11,r15
  411f99:	test   r15,r15
  411f9c:	jne    411fa8 <__swc_fn_e121059d_000179_68d30882+0x4c8>
  411f9e:	mov    BYTE PTR [r10],0x30
  411fa2:	mov    r8d,0x1
  411fa8:	test   r11,r11
  411fab:	jbe    411fec <__swc_fn_e121059d_000179_68d30882+0x50c>
  411fad:	nop    DWORD PTR [rax]
  411fb0:	movabs rdx,0xcccccccccccccccd
  411fba:	mov    r14,rax
  411fbd:	mov    rax,r11
  411fc0:	mul    rdx
  411fc3:	mov    r12,rdx
  411fc6:	mov    rax,r14
  411fc9:	shr    r12,0x3
  411fcd:	imul   r12,r12,0xa
  411fd1:	sub    r11,r12
  411fd4:	lea    r11,[r11+0x30]
  411fd8:	mov    BYTE PTR [r10+r8*1],r11b
  411fdc:	add    r8,0x1
  411fe0:	mov    r11,rdx
  411fe3:	shr    r11,0x3
  411fe7:	test   r11,r11
  411fea:	ja     411fb0 <__swc_fn_e121059d_000179_68d30882+0x4d0>
  411fec:	test   r8,r8
  411fef:	jbe    412016 <__swc_fn_e121059d_000179_68d30882+0x536>
  411ff1:	cs nop WORD PTR [rax+rax*1+0x0]
  411ffb:	nop    DWORD PTR [rax+rax*1+0x0]
  412000:	lea    rdx,[r8-0x1]
  412004:	mov    r8,rdx
  412007:	mov    dl,BYTE PTR [r10+rdx*1]
  41200b:	mov    BYTE PTR [rsi+rcx*1],dl
  41200e:	inc    rcx
  412011:	test   r8,r8
  412014:	ja     412000 <__swc_fn_e121059d_000179_68d30882+0x520>
  412016:	mov    BYTE PTR [rsi+rcx*1],0x2d
  41201a:	movabs rdx,0xcccccccccccccccd
  412024:	mov    r11,rax
  412027:	mov    rax,rdi
  41202a:	mul    rdx
  41202d:	mov    r8,rdx
  412030:	mov    r14,r11
  412033:	shr    r8,0x3
  412037:	lea    rdx,[r8+0x30]
  41203b:	mov    BYTE PTR [rsi+rcx*1+0x1],dl
  41203f:	imul   r8,r8,0xa
  412043:	sub    rdi,r8
  412046:	lea    rdx,[rdi+0x30]
  41204a:	mov    BYTE PTR [rsi+rcx*1+0x2],dl
  41204e:	mov    BYTE PTR [rsi+rcx*1+0x3],0x2d
  412053:	mov    r11,QWORD PTR [rsp+0x7d8]
  41205b:	movabs rdx,0xcccccccccccccccd
  412065:	mov    rax,r11
  412068:	mul    rdx
  41206b:	mov    r8,rdx
  41206e:	mov    rax,r14
  412071:	shr    r8,0x3
  412075:	lea    rdx,[r8+0x30]
  412079:	mov    BYTE PTR [rsi+rcx*1+0x4],dl
  41207d:	imul   r8,r8,0xa
  412081:	sub    r11,r8
  412084:	lea    rdx,[r11+0x30]
  412088:	mov    BYTE PTR [rsi+rcx*1+0x5],dl
  41208c:	mov    BYTE PTR [rsi+rcx*1+0x6],0x2c
  412091:	lea    rcx,[rcx+0x7]
  412095:	vxorps xmm0,xmm0,xmm0
  412099:	vmovups XMMWORD PTR [rbx+0x168],xmm0
  4120a1:	mov    QWORD PTR [rbx+0x178],0x0
  4120ac:	xor    r8d,r8d
  4120af:	mov    r11,QWORD PTR [rsp+0x7e8]
  4120b7:	mov    rdi,r11
  4120ba:	test   r11,r11
  4120bd:	je     4120c9 <__swc_fn_e121059d_000179_68d30882+0x5e9>
  4120bf:	mov    r11,QWORD PTR [rsp+0x7b8]
  4120c7:	jmp    4120db <__swc_fn_e121059d_000179_68d30882+0x5fb>
  4120c9:	mov    r11,QWORD PTR [rsp+0x7b8]
  4120d1:	mov    BYTE PTR [r11],0x30
  4120d5:	mov    r8d,0x1
  4120db:	test   rdi,rdi
  4120de:	jbe    41211c <__swc_fn_e121059d_000179_68d30882+0x63c>
  4120e0:	movabs rdx,0xcccccccccccccccd
  4120ea:	mov    r14,rax
  4120ed:	mov    rax,rdi
  4120f0:	mul    rdx
  4120f3:	mov    r12,rdx
  4120f6:	mov    rax,r14
  4120f9:	shr    r12,0x3
  4120fd:	imul   r12,r12,0xa
  412101:	sub    rdi,r12
  412104:	lea    rdi,[rdi+0x30]
  412108:	mov    BYTE PTR [r11+r8*1],dil
  41210c:	add    r8,0x1
  412110:	mov    rdi,rdx
  412113:	shr    rdi,0x3
  412117:	test   rdi,rdi
  41211a:	ja     4120e0 <__swc_fn_e121059d_000179_68d30882+0x600>
  41211c:	test   r8,r8
  41211f:	jbe    412146 <__swc_fn_e121059d_000179_68d30882+0x666>
  412121:	cs nop WORD PTR [rax+rax*1+0x0]
  41212b:	nop    DWORD PTR [rax+rax*1+0x0]
  412130:	lea    rdx,[r8-0x1]
  412134:	mov    r8,rdx
  412137:	mov    dl,BYTE PTR [r11+rdx*1]
  41213b:	mov    BYTE PTR [rsi+rcx*1],dl
  41213e:	inc    rcx
  412141:	test   r8,r8
  412144:	ja     412130 <__swc_fn_e121059d_000179_68d30882+0x650>
  412146:	mov    BYTE PTR [rsi+rcx*1],0x2c
  41214a:	inc    rcx
  41214d:	vxorps xmm0,xmm0,xmm0
  412151:	vmovups XMMWORD PTR [rbx+0x1b0],xmm0
  412159:	mov    QWORD PTR [rbx+0x1c0],0x0
  412164:	xor    r8d,r8d
  412167:	mov    rdi,QWORD PTR [rsp+0x7f8]
  41216f:	mov    r12,rdi
  412172:	shr    r12,0x2
  412176:	movabs rdx,0x28f5c28f5c28f5c3
  412180:	mov    r11,rax
  412183:	mov    rax,r12
  412186:	mul    rdx
  412189:	mov    r12,rdx
  41218c:	mov    rax,r11
  41218f:	shr    r12,0x2
  412193:	mov    r13,r12
  412196:	test   r12,r12
  412199:	je     4121a5 <__swc_fn_e121059d_000179_68d30882+0x6c5>
  41219b:	mov    r14,QWORD PTR [rsp+0x7c0]
  4121a3:	jmp    4121b7 <__swc_fn_e121059d_000179_68d30882+0x6d7>
  4121a5:	mov    r14,QWORD PTR [rsp+0x7c0]
  4121ad:	mov    BYTE PTR [r14],0x30
  4121b1:	mov    r8d,0x1
  4121b7:	test   r13,r13
  4121ba:	jbe    4121fc <__swc_fn_e121059d_000179_68d30882+0x71c>
  4121bc:	nop    DWORD PTR [rax+0x0]
  4121c0:	movabs rdx,0xcccccccccccccccd
  4121ca:	mov    r11,rax
  4121cd:	mov    rax,r13
  4121d0:	mul    rdx
  4121d3:	mov    r15,rdx
  4121d6:	mov    rax,r11
  4121d9:	shr    r15,0x3
  4121dd:	imul   r15,r15,0xa
  4121e1:	sub    r13,r15
  4121e4:	lea    r13,[r13+0x30]
  4121e8:	mov    BYTE PTR [r14+r8*1],r13b
  4121ec:	add    r8,0x1
  4121f0:	mov    r13,rdx
  4121f3:	shr    r13,0x3
  4121f7:	test   r13,r13
  4121fa:	ja     4121c0 <__swc_fn_e121059d_000179_68d30882+0x6e0>
  4121fc:	test   r8,r8
  4121ff:	jbe    412226 <__swc_fn_e121059d_000179_68d30882+0x746>
  412201:	cs nop WORD PTR [rax+rax*1+0x0]
  41220b:	nop    DWORD PTR [rax+rax*1+0x0]
  412210:	lea    rdx,[r8-0x1]
  412214:	mov    r8,rdx
  412217:	mov    dl,BYTE PTR [r14+rdx*1]
  41221b:	mov    BYTE PTR [rsi+rcx*1],dl
  41221e:	inc    rcx
  412221:	test   r8,r8
  412224:	ja     412210 <__swc_fn_e121059d_000179_68d30882+0x730>
  412226:	mov    BYTE PTR [rsi+rcx*1],0x2e
  41222a:	imul   r12,r12,0x64
  41222e:	sub    rdi,r12
  412231:	movabs rdx,0xcccccccccccccccd
  41223b:	mov    r11,rax
  41223e:	mov    rax,rdi
  412241:	mul    rdx
  412244:	mov    r8,rdx
  412247:	mov    rax,r11
  41224a:	shr    r8,0x3
  41224e:	lea    rdx,[r8+0x30]
  412252:	mov    BYTE PTR [rsi+rcx*1+0x1],dl
  412256:	imul   r8,r8,0xa
  41225a:	sub    rdi,r8
  41225d:	lea    rdx,[rdi+0x30]
  412261:	mov    BYTE PTR [rsi+rcx*1+0x2],dl
  412265:	lea    rdi,[rcx+0x3]
  412269:	mov    QWORD PTR [rsp+0x808],rdi
  412271:	mov    rcx,rdi
  412274:	mov    r8,QWORD PTR [rsp+0x7b0]
  41227c:	add    r8,0x1
  412280:	mov    QWORD PTR [rsp+0x7b0],r8
  412288:	cmp    r8,0x61a80
  41228f:	jb     411b70 <__swc_fn_e121059d_000179_68d30882+0x90>
  412295:	call   40ebc0 <__swc_fn_e121059d_000178_1ca87929>
  41229a:	vmovups xmm6,xmm0
  41229e:	vxorps xmm0,xmm0,xmm0
  4122a2:	vmovups XMMWORD PTR [rbx+0x208],xmm0
  4122aa:	vmovups XMMWORD PTR [rbx+0x218],xmm0
  4122b2:	vmovups XMMWORD PTR [rbx+0x228],xmm0
  4122ba:	mov    QWORD PTR [rbx+0x238],0x0
  4122c5:	lea    rcx,[rbx+0x208]
  4122cc:	mov    edx,0x40
  4122d1:	mov    r8,rsi
  4122d4:	call   411a50 <__swc_fn_e121059d_000176_e7f0b636>
  4122d9:	mov    ecx,0x200
  4122de:	call   40b860 <__swc_fn_e121059d_000177_2744b483>
  4122e3:	mov    r12,rax
  4122e6:	mov    QWORD PTR [rsp+0x810],rax
  4122ee:	mov    ecx,0x200
  4122f3:	call   40b860 <__swc_fn_e121059d_000177_2744b483>
  4122f8:	mov    QWORD PTR [rsp+0x818],rax
  412300:	mov    ecx,0x200
  412305:	call   40b860 <__swc_fn_e121059d_000177_2744b483>
  41230a:	mov    QWORD PTR [rsp+0x820],rax
  412312:	mov    ecx,0x200
  412317:	call   40b860 <__swc_fn_e121059d_000177_2744b483>
  41231c:	mov    QWORD PTR [rsp+0x828],rax
  412324:	xor    ecx,ecx
  412326:	xor    r15d,r15d
  412329:	mov    QWORD PTR [rsp+0x830],r15
  412331:	vmovups xmm7,XMMWORD PTR [rip+0x16f7]        # 413a30 <__swc_rdata_base_e121059d+0x920>
  412339:	vmovups xmm8,XMMWORD PTR [rip+0x16ff]        # 413a40 <__swc_rdata_base_e121059d+0x930>
  412341:	vmovsd xmm9,QWORD PTR [rip+0x1727]        # 413a70 <__swc_rdata_base_e121059d+0x960>
  412349:	cmp    rcx,rdi
  41234c:	jae    41288c <__swc_fn_e121059d_000179_68d30882+0xdac>
  412352:	cs nop WORD PTR [rax+rax*1+0x0]
  41235c:	nop    DWORD PTR [rax+0x0]
  412360:	mov    r15,rcx
  412363:	cmp    rcx,rdi
  412366:	jae    4123e0 <__swc_fn_e121059d_000179_68d30882+0x900>
  41236c:	mov    rax,rdi
  41236f:	sub    rax,r15
  412372:	cmp    rax,0x4
  412376:	jb     4123c0 <__swc_fn_e121059d_000179_68d30882+0x8e0>
  412378:	mov    rax,rdi
  41237b:	sub    rax,0x3
  41237f:	cmp    r15,rax
  412382:	jae    4123c0 <__swc_fn_e121059d_000179_68d30882+0x8e0>
  412384:	cs nop WORD PTR [rax+rax*1+0x0]
  41238e:	xchg   ax,ax
  412390:	cmp    BYTE PTR [rsi+r15*1],0xa
  412395:	je     4123e0 <__swc_fn_e121059d_000179_68d30882+0x900>
  412397:	cmp    BYTE PTR [rsi+r15*1+0x1],0xa
  41239d:	je     4123d1 <__swc_fn_e121059d_000179_68d30882+0x8f1>
  41239f:	cmp    BYTE PTR [rsi+r15*1+0x2],0xa
  4123a5:	je     4123d6 <__swc_fn_e121059d_000179_68d30882+0x8f6>
  4123a7:	cmp    BYTE PTR [rsi+r15*1+0x3],0xa
  4123ad:	je     4123dc <__swc_fn_e121059d_000179_68d30882+0x8fc>
  4123af:	lea    r15,[r15+0x4]
  4123b3:	cmp    r15,rax
  4123b6:	jb     412390 <__swc_fn_e121059d_000179_68d30882+0x8b0>
  4123b8:	nop    DWORD PTR [rax+rax*1+0x0]
  4123c0:	cmp    r15,rdi
  4123c3:	jae    4123e0 <__swc_fn_e121059d_000179_68d30882+0x900>
  4123c5:	cmp    BYTE PTR [rsi+r15*1],0xa
  4123ca:	je     4123e0 <__swc_fn_e121059d_000179_68d30882+0x900>
  4123cc:	inc    r15
  4123cf:	jmp    4123c0 <__swc_fn_e121059d_000179_68d30882+0x8e0>
  4123d1:	inc    r15
  4123d4:	jmp    4123e0 <__swc_fn_e121059d_000179_68d30882+0x900>
  4123d6:	lea    r15,[r15+0x2]
  4123da:	jmp    4123e0 <__swc_fn_e121059d_000179_68d30882+0x900>
  4123dc:	lea    r15,[r15+0x3]
  4123e0:	cmp    rcx,r15
  4123e3:	jae    412460 <__swc_fn_e121059d_000179_68d30882+0x980>
  4123e9:	mov    rax,r15
  4123ec:	sub    rax,rcx
  4123ef:	cmp    rax,0x4
  4123f3:	jb     412440 <__swc_fn_e121059d_000179_68d30882+0x960>
  4123f9:	mov    rax,r15
  4123fc:	sub    rax,0x3
  412400:	cmp    rcx,rax
  412403:	jae    412440 <__swc_fn_e121059d_000179_68d30882+0x960>
  412405:	cs nop WORD PTR [rax+rax*1+0x0]
  41240f:	nop
  412410:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  412414:	je     412460 <__swc_fn_e121059d_000179_68d30882+0x980>
  412416:	cmp    BYTE PTR [rsi+rcx*1+0x1],0x2c
  41241b:	je     412451 <__swc_fn_e121059d_000179_68d30882+0x971>
  41241d:	cmp    BYTE PTR [rsi+rcx*1+0x2],0x2c
  412422:	je     412456 <__swc_fn_e121059d_000179_68d30882+0x976>
  412424:	cmp    BYTE PTR [rsi+rcx*1+0x3],0x2c
  412429:	je     41245c <__swc_fn_e121059d_000179_68d30882+0x97c>
  41242b:	lea    rcx,[rcx+0x4]
  41242f:	cmp    rcx,rax
  412432:	jb     412410 <__swc_fn_e121059d_000179_68d30882+0x930>
  412434:	cs nop WORD PTR [rax+rax*1+0x0]
  41243e:	xchg   ax,ax
  412440:	cmp    rcx,r15
  412443:	jae    412460 <__swc_fn_e121059d_000179_68d30882+0x980>
  412445:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  412449:	je     412460 <__swc_fn_e121059d_000179_68d30882+0x980>
  41244b:	add    rcx,0x1
  41244f:	jmp    412440 <__swc_fn_e121059d_000179_68d30882+0x960>
  412451:	inc    rcx
  412454:	jmp    412460 <__swc_fn_e121059d_000179_68d30882+0x980>
  412456:	lea    rcx,[rcx+0x2]
  41245a:	jmp    412460 <__swc_fn_e121059d_000179_68d30882+0x980>
  41245c:	lea    rcx,[rcx+0x3]
  412460:	lea    rdi,[rcx+0x1]
  412464:	mov    rcx,rdi
  412467:	cmp    rdi,r15
  41246a:	jae    4124e0 <__swc_fn_e121059d_000179_68d30882+0xa00>
  412470:	mov    rax,r15
  412473:	sub    rax,rcx
  412476:	cmp    rax,0x4
  41247a:	jb     4124c0 <__swc_fn_e121059d_000179_68d30882+0x9e0>
  41247c:	mov    rax,r15
  41247f:	sub    rax,0x3
  412483:	cmp    rcx,rax
  412486:	jae    4124c0 <__swc_fn_e121059d_000179_68d30882+0x9e0>
  412488:	nop    DWORD PTR [rax+rax*1+0x0]
  412490:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  412494:	je     4124e0 <__swc_fn_e121059d_000179_68d30882+0xa00>
  412496:	cmp    BYTE PTR [rsi+rcx*1+0x1],0x2c
  41249b:	je     4124d1 <__swc_fn_e121059d_000179_68d30882+0x9f1>
  41249d:	cmp    BYTE PTR [rsi+rcx*1+0x2],0x2c
  4124a2:	je     4124d6 <__swc_fn_e121059d_000179_68d30882+0x9f6>
  4124a4:	cmp    BYTE PTR [rsi+rcx*1+0x3],0x2c
  4124a9:	je     4124dc <__swc_fn_e121059d_000179_68d30882+0x9fc>
  4124ab:	lea    rcx,[rcx+0x4]
  4124af:	cmp    rcx,rax
  4124b2:	jb     412490 <__swc_fn_e121059d_000179_68d30882+0x9b0>
  4124b4:	cs nop WORD PTR [rax+rax*1+0x0]
  4124be:	xchg   ax,ax
  4124c0:	cmp    rcx,r15
  4124c3:	jae    4124e0 <__swc_fn_e121059d_000179_68d30882+0xa00>
  4124c5:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  4124c9:	je     4124e0 <__swc_fn_e121059d_000179_68d30882+0xa00>
  4124cb:	add    rcx,0x1
  4124cf:	jmp    4124c0 <__swc_fn_e121059d_000179_68d30882+0x9e0>
  4124d1:	inc    rcx
  4124d4:	jmp    4124e0 <__swc_fn_e121059d_000179_68d30882+0xa00>
  4124d6:	lea    rcx,[rcx+0x2]
  4124da:	jmp    4124e0 <__swc_fn_e121059d_000179_68d30882+0xa00>
  4124dc:	lea    rcx,[rcx+0x3]
  4124e0:	mov    r14,rcx
  4124e3:	sub    r14,rdi
  4124e6:	add    rcx,0x1
  4124ea:	cmp    rcx,r15
  4124ed:	jae    412580 <__swc_fn_e121059d_000179_68d30882+0xaa0>
  4124f3:	mov    rax,r15
  4124f6:	sub    rax,rcx
  4124f9:	cmp    rax,0x4
  4124fd:	jb     412560 <__swc_fn_e121059d_000179_68d30882+0xa80>
  412503:	mov    rax,r15
  412506:	sub    rax,0x3
  41250a:	cmp    rcx,rax
  41250d:	jae    412560 <__swc_fn_e121059d_000179_68d30882+0xa80>
  412513:	cs nop WORD PTR [rax+rax*1+0x0]
  41251d:	cs nop WORD PTR [rax+rax*1+0x0]
  412527:	nop    WORD PTR [rax+rax*1+0x0]
  412530:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  412534:	je     412580 <__swc_fn_e121059d_000179_68d30882+0xaa0>
  412536:	cmp    BYTE PTR [rsi+rcx*1+0x1],0x2c
  41253b:	je     412571 <__swc_fn_e121059d_000179_68d30882+0xa91>
  41253d:	cmp    BYTE PTR [rsi+rcx*1+0x2],0x2c
  412542:	je     412576 <__swc_fn_e121059d_000179_68d30882+0xa96>
  412544:	cmp    BYTE PTR [rsi+rcx*1+0x3],0x2c
  412549:	je     41257c <__swc_fn_e121059d_000179_68d30882+0xa9c>
  41254b:	lea    rcx,[rcx+0x4]
  41254f:	cmp    rcx,rax
  412552:	jb     412530 <__swc_fn_e121059d_000179_68d30882+0xa50>
  412554:	cs nop WORD PTR [rax+rax*1+0x0]
  41255e:	xchg   ax,ax
  412560:	cmp    rcx,r15
  412563:	jae    412580 <__swc_fn_e121059d_000179_68d30882+0xaa0>
  412565:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  412569:	je     412580 <__swc_fn_e121059d_000179_68d30882+0xaa0>
  41256b:	add    rcx,0x1
  41256f:	jmp    412560 <__swc_fn_e121059d_000179_68d30882+0xa80>
  412571:	inc    rcx
  412574:	jmp    412580 <__swc_fn_e121059d_000179_68d30882+0xaa0>
  412576:	lea    rcx,[rcx+0x2]
  41257a:	jmp    412580 <__swc_fn_e121059d_000179_68d30882+0xaa0>
  41257c:	lea    rcx,[rcx+0x3]
  412580:	add    rcx,0x1
  412584:	xor    r13d,r13d
  412587:	cmp    rcx,r15
  41258a:	jae    4125ae <__swc_fn_e121059d_000179_68d30882+0xace>
  41258c:	nop    DWORD PTR [rax+0x0]
  412590:	movzx  edx,BYTE PTR [rsi+rcx*1]
  412594:	cmp    edx,0x2c
  412597:	je     4125ae <__swc_fn_e121059d_000179_68d30882+0xace>
  412599:	lea    r8,[r13+r13*4+0x0]
  41259e:	sub    dl,0x30
  4125a1:	lea    r13,[rdx+r8*2]
  4125a5:	add    rcx,0x1
  4125a9:	cmp    rcx,r15
  4125ac:	jb     412590 <__swc_fn_e121059d_000179_68d30882+0xab0>
  4125ae:	add    rcx,0x1
  4125b2:	xor    edx,edx
  4125b4:	cmp    rcx,r15
  4125b7:	jae    4125f0 <__swc_fn_e121059d_000179_68d30882+0xb10>
  4125b9:	cs nop WORD PTR [rax+rax*1+0x0]
  4125c3:	cs nop WORD PTR [rax+rax*1+0x0]
  4125cd:	nop    DWORD PTR [rax]
  4125d0:	movzx  r8d,BYTE PTR [rsi+rcx*1]
  4125d5:	cmp    r8d,0x2e
  4125d9:	je     4125f0 <__swc_fn_e121059d_000179_68d30882+0xb10>
  4125db:	lea    rdx,[rdx+rdx*4]
  4125df:	sub    r8b,0x30
  4125e3:	lea    rdx,[r8+rdx*2]
  4125e7:	add    rcx,0x1
  4125eb:	cmp    rcx,r15
  4125ee:	jb     4125d0 <__swc_fn_e121059d_000179_68d30882+0xaf0>
  4125f0:	add    rcx,0x1
  4125f4:	xor    r8d,r8d
  4125f7:	cmp    rcx,r15
  4125fa:	jae    41261a <__swc_fn_e121059d_000179_68d30882+0xb3a>
  4125fc:	nop    DWORD PTR [rax+0x0]
  412600:	lea    r8,[r8+r8*4]
  412604:	movzx  r9d,BYTE PTR [rsi+rcx*1]
  412609:	sub    r9b,0x30
  41260d:	lea    r8,[r9+r8*2]
  412611:	add    rcx,0x1
  412615:	cmp    rcx,r15
  412618:	jb     412600 <__swc_fn_e121059d_000179_68d30882+0xb20>
  41261a:	vmovq  xmm0,rdx
  41261f:	vpunpckldq xmm0,xmm0,xmm7
  412623:	vsubpd xmm0,xmm0,xmm8
  412628:	vpunpckhqdq xmm1,xmm0,xmm0
  41262c:	vaddsd xmm0,xmm0,xmm1
  412630:	vmovq  xmm1,r8
  412635:	vpunpckldq xmm1,xmm1,xmm7
  412639:	vsubpd xmm1,xmm1,xmm8
  41263e:	vpunpckhqdq xmm2,xmm1,xmm1
  412642:	vaddsd xmm1,xmm1,xmm2
  412646:	vdivsd xmm1,xmm1,xmm9
  41264b:	vaddsd xmm10,xmm0,xmm1
  41264f:	mov    ecx,0x811c9dc5
  412654:	xor    edx,edx
  412656:	test   r14,r14
  412659:	jbe    4126d3 <__swc_fn_e121059d_000179_68d30882+0xbf3>
  41265f:	mov    r8,QWORD PTR [rbx+0x228]
  412666:	add    r8,rdi
  412669:	cmp    r14,0x4
  41266d:	jb     4126c0 <__swc_fn_e121059d_000179_68d30882+0xbe0>
  412673:	lea    r9,[r14-0x3]
  412677:	nop    WORD PTR [rax+rax*1+0x0]
  412680:	xor    cl,BYTE PTR [r8+rdx*1]
  412684:	imul   ecx,ecx,0x1000193
  41268a:	xor    cl,BYTE PTR [r8+rdx*1+0x1]
  41268f:	imul   ecx,ecx,0x1000193
  412695:	xor    cl,BYTE PTR [r8+rdx*1+0x2]
  41269a:	imul   ecx,ecx,0x1000193
  4126a0:	xor    cl,BYTE PTR [r8+rdx*1+0x3]
  4126a5:	imul   ecx,ecx,0x1000193
  4126ab:	add    rdx,0x4
  4126af:	cmp    rdx,r9
  4126b2:	jb     412680 <__swc_fn_e121059d_000179_68d30882+0xba0>
  4126b4:	cmp    rdx,r14
  4126b7:	jae    4126d3 <__swc_fn_e121059d_000179_68d30882+0xbf3>
  4126b9:	nop    DWORD PTR [rax+0x0]
  4126c0:	xor    cl,BYTE PTR [r8+rdx*1]
  4126c4:	imul   ecx,ecx,0x1000193
  4126ca:	add    rdx,0x1
  4126ce:	cmp    rdx,r14
  4126d1:	jb     4126c0 <__swc_fn_e121059d_000179_68d30882+0xbe0>
  4126d3:	and    rcx,QWORD PTR [rbx+0x230]
  4126da:	mov    rsi,rcx
  4126dd:	mov    QWORD PTR [rsp+0x838],r15
  4126e5:	mov    r15,QWORD PTR [rbx+0x220]
  4126ec:	mov    QWORD PTR [rsp+0x840],r13
  4126f4:	mov    r13,QWORD PTR [rbx+0x210]
  4126fb:	cmp    BYTE PTR [r15+rsi*1],0x0
  412700:	je     412750 <__swc_fn_e121059d_000179_68d30882+0xc70>
  412702:	cs nop WORD PTR [rax+rax*1+0x0]
  41270c:	nop    DWORD PTR [rax+0x0]
  412710:	cmp    QWORD PTR [r13+rsi*8+0x0],r14
  412715:	jne    41273f <__swc_fn_e121059d_000179_68d30882+0xc5f>
  412717:	mov    rax,QWORD PTR [rbx+0x208]
  41271e:	mov    rax,QWORD PTR [rax+rsi*8]
  412722:	mov    rcx,QWORD PTR [rbx+0x228]
  412729:	add    rax,rcx
  41272c:	lea    rdx,[rcx+rdi*1]
  412730:	mov    rcx,rax
  412733:	mov    r8,r14
  412736:	call   410850 <__swc_fn_e121059d_000107_ed4b1681>
  41273b:	test   eax,eax
  41273d:	je     412750 <__swc_fn_e121059d_000179_68d30882+0xc70>
  41273f:	inc    rsi
  412742:	and    rsi,QWORD PTR [rbx+0x230]
  412749:	cmp    BYTE PTR [r15+rsi*1],0x0
  41274e:	jne    412710 <__swc_fn_e121059d_000179_68d30882+0xc30>
  412750:	cmp    BYTE PTR [r15+rsi*1],0x0
  412755:	je     41277c <__swc_fn_e121059d_000179_68d30882+0xc9c>
  412757:	mov    rdi,QWORD PTR [rsp+0x818]
  41275f:	mov    r14,QWORD PTR [rsp+0x820]
  412767:	mov    r15,QWORD PTR [rsp+0x828]
  41276f:	mov    r13,QWORD PTR [rsp+0x840]
  412777:	jmp    41280c <__swc_fn_e121059d_000179_68d30882+0xd2c>
  41277c:	mov    rcx,QWORD PTR [rbx+0x238]
  412783:	mov    rdx,QWORD PTR [rbx+0x220]
  41278a:	mov    BYTE PTR [rdx+rsi*1],0x1
  41278e:	mov    rdx,QWORD PTR [rbx+0x208]
  412795:	mov    QWORD PTR [rdx+rsi*8],rdi
  412799:	mov    rdx,QWORD PTR [rbx+0x210]
  4127a0:	mov    QWORD PTR [rdx+rsi*8],r14
  4127a4:	mov    rdx,QWORD PTR [rbx+0x218]
  4127ab:	mov    QWORD PTR [rdx+rsi*8],rcx
  4127af:	add    QWORD PTR [rbx+0x238],0x1
  4127b7:	mov    QWORD PTR [r12+rcx*8],0x1
  4127bf:	mov    rdi,QWORD PTR [rsp+0x818]
  4127c7:	mov    r13,QWORD PTR [rsp+0x840]
  4127cf:	mov    QWORD PTR [rdi+rcx*8],r13
  4127d3:	vmovq  xmm0,r13
  4127d8:	vpunpckldq xmm0,xmm0,xmm7
  4127dc:	vsubpd xmm0,xmm0,xmm8
  4127e1:	vpunpckhqdq xmm1,xmm0,xmm0
  4127e5:	vaddsd xmm0,xmm0,xmm1
  4127e9:	vmulsd xmm0,xmm0,xmm10
  4127ee:	mov    r14,QWORD PTR [rsp+0x820]
  4127f6:	vmovq  QWORD PTR [r14+rcx*8],xmm0
  4127fc:	mov    r15,QWORD PTR [rsp+0x828]
  412804:	vmovq  QWORD PTR [r15+rcx*8],xmm10
  41280a:	jmp    412854 <__swc_fn_e121059d_000179_68d30882+0xd74>
  41280c:	mov    rcx,QWORD PTR [rbx+0x218]
  412813:	mov    rcx,QWORD PTR [rcx+rsi*8]
  412817:	inc    QWORD PTR [r12+rcx*8]
  41281b:	add    QWORD PTR [rdi+rcx*8],r13
  41281f:	vmovq  xmm0,r13
  412824:	vpunpckldq xmm0,xmm0,xmm7
  412828:	vsubpd xmm0,xmm0,xmm8
  41282d:	vpunpckhqdq xmm1,xmm0,xmm0
  412831:	vaddsd xmm0,xmm0,xmm1
  412835:	vmulsd xmm0,xmm0,xmm10
  41283a:	vaddsd xmm0,xmm0,QWORD PTR [r14+rcx*8]
  412840:	vmovq  QWORD PTR [r14+rcx*8],xmm0
  412846:	vcomisd xmm10,QWORD PTR [r15+rcx*8]
  41284c:	jbe    412854 <__swc_fn_e121059d_000179_68d30882+0xd74>
  41284e:	vmovq  QWORD PTR [r15+rcx*8],xmm10
  412854:	mov    rsi,QWORD PTR [rsp+0x830]
  41285c:	add    rsi,0x1
  412860:	mov    rcx,QWORD PTR [rsp+0x838]
  412868:	mov    QWORD PTR [rsp+0x830],rsi
  412870:	inc    rcx
  412873:	mov    rsi,QWORD PTR [rsp+0x7a8]
  41287b:	mov    rdi,QWORD PTR [rsp+0x808]
  412883:	cmp    rcx,rdi
  412886:	jb     412360 <__swc_fn_e121059d_000179_68d30882+0x880>
  41288c:	lea    r13,[rbx+0x320]
  412893:	mov    QWORD PTR [rsp+0x848],r13
  41289b:	vxorps xmm0,xmm0,xmm0
  41289f:	xor    ecx,ecx
  4128a1:	cs nop WORD PTR [rax+rax*1+0x0]
  4128ab:	cs nop WORD PTR [rax+rax*1+0x0]
  4128b5:	cs nop WORD PTR [rax+rax*1+0x0]
  4128bf:	nop
  4128c0:	vmovdqu XMMWORD PTR [r13+rcx*1+0x0],xmm0
  4128c7:	add    rcx,0x10
  4128cb:	cmp    rcx,0x200
  4128d2:	jne    4128c0 <__swc_fn_e121059d_000179_68d30882+0xde0>
  4128d4:	lea    r15,[rbx+0x520]
  4128db:	vxorps xmm0,xmm0,xmm0
  4128df:	xor    ecx,ecx
  4128e1:	cs nop WORD PTR [rax+rax*1+0x0]
  4128eb:	cs nop WORD PTR [rax+rax*1+0x0]
  4128f5:	cs nop WORD PTR [rax+rax*1+0x0]
  4128ff:	nop
  412900:	vmovdqu XMMWORD PTR [r15+rcx*1],xmm0
  412906:	add    rcx,0x10
  41290a:	cmp    rcx,0x200
  412911:	jne    412900 <__swc_fn_e121059d_000179_68d30882+0xe20>
  412913:	xor    edi,edi
  412915:	xor    ecx,ecx
  412917:	mov    rsi,rdi
  41291a:	cs nop WORD PTR [rax+rax*1+0x0]
  412924:	cs nop WORD PTR [rax+rax*1+0x0]
  41292e:	xchg   ax,ax
  412930:	mov    rdx,QWORD PTR [rbx+0x220]
  412937:	cmp    BYTE PTR [rdx+rcx*1],0x0
  41293b:	je     412947 <__swc_fn_e121059d_000179_68d30882+0xe67>
  41293d:	mov    QWORD PTR [r15+rdi*8],rcx
  412941:	inc    rdi
  412944:	mov    rsi,rdi
  412947:	add    rcx,0x1
  41294b:	cmp    rcx,0x40
  41294f:	jb     412930 <__swc_fn_e121059d_000179_68d30882+0xe50>
  412951:	mov    QWORD PTR [rsp+0x850],rsi
  412959:	xor    ecx,ecx
  41295b:	test   rdi,rdi
  41295e:	jbe    41296e <__swc_fn_e121059d_000179_68d30882+0xe8e>
  412960:	mov    QWORD PTR [r13+rcx*8+0x0],rcx
  412965:	add    rcx,0x1
  412969:	cmp    rcx,rdi
  41296c:	jb     412960 <__swc_fn_e121059d_000179_68d30882+0xe80>
  41296e:	xor    r12d,r12d
  412971:	mov    QWORD PTR [rsp+0x858],r12
  412979:	test   rdi,rdi
  41297c:	mov    r14,QWORD PTR [rsp+0x7a8]
  412984:	mov    rcx,rdi
  412987:	jbe    412aae <__swc_fn_e121059d_000179_68d30882+0xfce>
  41298d:	nop    DWORD PTR [rax]
  412990:	mov    rsi,r12
  412993:	xor    r9d,r9d
  412996:	test   rdi,rdi
  412999:	mov    rdi,r9
  41299c:	ja     4129ab <__swc_fn_e121059d_000179_68d30882+0xecb>
  41299e:	mov    rcx,QWORD PTR [rsp+0x850]
  4129a6:	jmp    412a72 <__swc_fn_e121059d_000179_68d30882+0xf92>
  4129ab:	cs nop WORD PTR [rax+rax*1+0x0]
  4129b5:	cs nop WORD PTR [rax+rax*1+0x0]
  4129bf:	nop
  4129c0:	cmp    rdi,r12
  4129c3:	jbe    412a4c <__swc_fn_e121059d_000179_68d30882+0xf6c>
  4129c9:	mov    rax,QWORD PTR [r13+rsi*8+0x0]
  4129ce:	mov    r12,QWORD PTR [r15+rax*8]
  4129d2:	mov    rax,QWORD PTR [r13+rdi*8+0x0]
  4129d7:	mov    r13,QWORD PTR [r15+rax*8]
  4129db:	mov    rax,QWORD PTR [rbx+0x210]
  4129e2:	mov    rcx,QWORD PTR [rax+r12*8]
  4129e6:	mov    r8,rcx
  4129e9:	mov    rax,QWORD PTR [rax+r13*8]
  4129ed:	cmp    rax,rcx
  4129f0:	jae    412a00 <__swc_fn_e121059d_000179_68d30882+0xf20>
  4129f2:	mov    rax,QWORD PTR [rbx+0x210]
  4129f9:	mov    rax,QWORD PTR [rax+r13*8]
  4129fd:	mov    r8,rax
  412a00:	mov    rax,QWORD PTR [rbx+0x208]
  412a07:	mov    rcx,QWORD PTR [rax+r13*8]
  412a0b:	add    rcx,r14
  412a0e:	mov    rax,QWORD PTR [rax+r12*8]
  412a12:	lea    rdx,[rax+r14*1]
  412a16:	call   410850 <__swc_fn_e121059d_000107_ed4b1681>
  412a1b:	mov    rcx,rax
  412a1e:	test   eax,eax
  412a20:	setl   dl
  412a23:	jl     412a46 <__swc_fn_e121059d_000179_68d30882+0xf66>
  412a25:	test   ecx,ecx
  412a27:	sete   cl
  412a2a:	movzx  ecx,cl
  412a2d:	jne    412a44 <__swc_fn_e121059d_000179_68d30882+0xf64>
  412a2f:	mov    rcx,QWORD PTR [rbx+0x210]
  412a36:	mov    rdx,QWORD PTR [rcx+r12*8]
  412a3a:	cmp    QWORD PTR [rcx+r13*8],rdx
  412a3e:	setb   cl
  412a41:	movzx  ecx,cl
  412a44:	mov    dl,cl
  412a46:	test   dl,dl
  412a48:	cmovne rsi,rdi
  412a4c:	add    rdi,0x1
  412a50:	mov    rcx,QWORD PTR [rsp+0x850]
  412a58:	cmp    rdi,rcx
  412a5b:	jae    412a72 <__swc_fn_e121059d_000179_68d30882+0xf92>
  412a5d:	mov    r13,QWORD PTR [rsp+0x848]
  412a65:	mov    r12,QWORD PTR [rsp+0x858]
  412a6d:	jmp    4129c0 <__swc_fn_e121059d_000179_68d30882+0xee0>
  412a72:	mov    r13,QWORD PTR [rsp+0x848]
  412a7a:	mov    r12,QWORD PTR [rsp+0x858]
  412a82:	mov    rdx,QWORD PTR [r13+r12*8+0x0]
  412a87:	mov    r8,QWORD PTR [r13+rsi*8+0x0]
  412a8c:	mov    QWORD PTR [r13+r12*8+0x0],r8
  412a91:	mov    QWORD PTR [r13+rsi*8+0x0],rdx
  412a96:	add    r12,0x1
  412a9a:	mov    QWORD PTR [rsp+0x858],r12
  412aa2:	cmp    r12,rcx
  412aa5:	mov    rdi,rcx
  412aa8:	jb     412990 <__swc_fn_e121059d_000179_68d30882+0xeb0>
  412aae:	mov    rsi,QWORD PTR [rsp+0x830]
  412ab6:	xor    edx,edx
  412ab8:	test   rcx,rcx
  412abb:	jbe    412be9 <__swc_fn_e121059d_000179_68d30882+0x1109>
  412ac1:	mov    r8,QWORD PTR [rbx+0x218]
  412ac8:	vmovsd xmm0,QWORD PTR [rip+0xae4]        # 4135b4 <__swc_rdata_base_e121059d+0x4a4>
  412ad0:	vmovsd xmm1,QWORD PTR [rip+0xaca]        # 4135a2 <__swc_rdata_base_e121059d+0x492>
  412ad8:	mov    r12,QWORD PTR [rsp+0x810]
  412ae0:	mov    rdi,QWORD PTR [rsp+0x818]
  412ae8:	mov    r14,QWORD PTR [rsp+0x820]
  412af0:	mov    r9,QWORD PTR [rsp+0x828]
  412af8:	vmovups xmm2,xmm1
  412afc:	vmovsd xmm4,QWORD PTR [rsp+0x848]
  412b05:	vmovq  xmm5,r8
  412b0a:	nop    WORD PTR [rax+rax*1+0x0]
  412b10:	mov    r10,QWORD PTR [r13+rdx*8+0x0]
  412b15:	mov    r10,QWORD PTR [r15+r10*8]
  412b19:	mov    r10,QWORD PTR [r8+r10*8]
  412b1d:	lea    r11,[rdx+0x1]
  412b21:	vmovq  xmm3,QWORD PTR [r14+r10*8]
  412b27:	vfmadd213sd xmm3,xmm9,xmm0
  412b2c:	vcomisd xmm3,xmm1
  412b30:	jb     412b4a <__swc_fn_e121059d_000179_68d30882+0x106a>
  412b32:	vsubsd xmm3,xmm3,xmm1
  412b36:	vcvttsd2si rdx,xmm3
  412b3b:	movabs r8,0x8000000000000000
  412b45:	xor    rdx,r8
  412b48:	jmp    412b4f <__swc_fn_e121059d_000179_68d30882+0x106f>
  412b4a:	vcvttsd2si rdx,xmm3
  412b4f:	mov    rax,rdx
  412b52:	mov    QWORD PTR [rsp+0x868],rdx
  412b5a:	movabs rdx,0xc6f45449cb59c69
  412b64:	mov    r13,QWORD PTR [rsp+0x868]
  412b6c:	mul    rdx
  412b6f:	mov    r8,rdx
  412b72:	mov    rdx,r13
  412b75:	sub    rdx,r8
  412b78:	shr    rdx,1
  412b7b:	add    rdx,r8
  412b7e:	shr    rdx,0x13
  412b82:	imul   r8,rdx,0xf4243
  412b89:	sub    r13,r8
  412b8c:	mov    rdx,r11
  412b8f:	imul   rdx,r13
  412b93:	add    rsi,rdx
  412b96:	mov    rdx,QWORD PTR [r12+r10*8]
  412b9a:	add    rdx,QWORD PTR [rdi+r10*8]
  412b9e:	vmovq  xmm3,QWORD PTR [r9+r10*8]
  412ba4:	vfmadd213sd xmm3,xmm9,xmm0
  412ba9:	vcomisd xmm3,xmm2
  412bad:	jb     412bc7 <__swc_fn_e121059d_000179_68d30882+0x10e7>
  412baf:	vsubsd xmm3,xmm3,xmm2
  412bb3:	vcvttsd2si r8,xmm3
  412bb8:	movabs r10,0x8000000000000000
  412bc2:	xor    r8,r10
  412bc5:	jmp    412bcc <__swc_fn_e121059d_000179_68d30882+0x10ec>
  412bc7:	vcvttsd2si r8,xmm3
  412bcc:	add    rdx,r8
  412bcf:	add    rsi,rdx
  412bd2:	mov    rdx,r11
  412bd5:	cmp    r11,rcx
  412bd8:	jae    412be9 <__swc_fn_e121059d_000179_68d30882+0x1109>
  412bda:	vmovq  r13,xmm4
  412bdf:	vmovq  r8,xmm5
  412be4:	jmp    412b10 <__swc_fn_e121059d_000179_68d30882+0x1030>
  412be9:	call   40ebc0 <__swc_fn_e121059d_000178_1ca87929>
  412bee:	vsubsd xmm0,xmm0,xmm6
  412bf2:	vmulsd xmm0,xmm0,QWORD PTR [rip+0xe7f]        # 413a79 <__swc_rdata_base_e121059d+0x969>
  412bfa:	lea    rax,[rip+0x767]        # 413368 <__swc_rdata_base_e121059d+0x258>
  412c01:	sub    rsp,0x88
  412c08:	mov    rcx,rsp
  412c0b:	vmovups xmm1,XMMWORD PTR [rip+0xe3d]        # 413a50 <__swc_rdata_base_e121059d+0x940>
  412c13:	vmovups XMMWORD PTR [rcx],xmm1
  412c17:	mov    QWORD PTR [rcx+0x30],rsp
  412c1b:	lea    rdx,[rip+0x6ee]        # 413310 <__swc_rdata_base_e121059d+0x200>
  412c22:	mov    QWORD PTR [rcx+0x38],rdx
  412c26:	mov    QWORD PTR [rcx+0x10],rsi
  412c2a:	lea    r8,[rsp+0x10]
  412c2f:	mov    QWORD PTR [rcx+0x40],r8
  412c33:	lea    r8,[rip+0xd5e]        # 413998 <__swc_rdata_base_e121059d+0x888>
  412c3a:	mov    QWORD PTR [rcx+0x48],r8
  412c3e:	vmovups xmm1,XMMWORD PTR [rip+0xe1a]        # 413a60 <__swc_rdata_base_e121059d+0x950>
  412c46:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  412c4b:	lea    r8,[rsp+0x18]
  412c50:	mov    QWORD PTR [rcx+0x50],r8
  412c54:	mov    QWORD PTR [rcx+0x58],rdx
  412c58:	vmovsd QWORD PTR [rcx+0x28],xmm0
  412c5d:	lea    r8,[rcx+0x28]
  412c61:	mov    QWORD PTR [rcx+0x60],r8
  412c65:	lea    r8,[rip+0xd74]        # 4139e0 <__swc_rdata_base_e121059d+0x8d0>
  412c6c:	mov    QWORD PTR [rcx+0x68],r8
  412c70:	mov    QWORD PTR [rcx+0x70],rax
  412c74:	mov    QWORD PTR [rcx+0x78],rdx
  412c78:	lea    rax,[rcx+0x30]
  412c7c:	mov    QWORD PTR [rcx+0x80],rax
  412c83:	mov    QWORD PTR [rcx+0x88],0x5
  412c8e:	lea    rcx,[rcx+0x80]
  412c95:	sub    rsp,0x8
  412c99:	call   40a140 <__swc_fn_e121059d_000147_43f4fdca>
  412c9e:	add    rsp,0x948
  412ca5:	vmovups xmm6,XMMWORD PTR [rsp]
  412caa:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  412cb0:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  412cb6:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  412cbc:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  412cc2:	add    rsp,0x50
  412cc6:	pop    r15
  412cc8:	pop    r14
  412cca:	pop    r13
  412ccc:	pop    r12
  412cce:	pop    rdi
  412ccf:	pop    rsi
  412cd0:	pop    rbx
  412cd1:	pop    rbp
  412cd2:	ret
