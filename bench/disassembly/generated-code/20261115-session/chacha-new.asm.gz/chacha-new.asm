
/workspace/prompt2-20261115/session-combined-micro/new/chacha/chacha:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <madvise@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf9a]        # 413080 <madvise@GLIBC_2.2.5>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <pthread_key_delete@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf92]        # 413088 <pthread_key_delete@GLIBC_2.34>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <gettid@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf8a]        # 413090 <gettid@GLIBC_2.30>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <clock_gettime@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf82]        # 413098 <clock_gettime@GLIBC_2.17>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <flock@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf7a]        # 4130a0 <flock@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <__errno_location@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf72]        # 4130a8 <__errno_location@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <opendir@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf6a]        # 4130b0 <opendir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <dirfd@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf62]        # 4130b8 <dirfd@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readdir@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <readdir@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <readlinkat@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <readlinkat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <openat@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <openat@GLIBC_2.4>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <closedir@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <closedir@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <memfd_create@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <memfd_create@GLIBC_2.27>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <ftruncate@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <ftruncate@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <write@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <write@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <backtrace@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <backtrace@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_3464c816_000176_cf4ffedd+0x1020>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40d1e0 <__swc_fn_3464c816_000124_540bf7e8>
  40724e:	xor    ecx,ecx
  407250:	call   40c900 <__swc_fn_3464c816_000097_4f209617>
  407255:	call   407280 <__swc_fn_3464c816_000000_7f24d040>
  40725a:	call   40f6b0 <__swc_fn_3464c816_000098_65137b72>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407280 <__swc_fn_3464c816_000000_7f24d040>:
  407280:	push   rbp
  407281:	push   rbx
  407282:	push   rsi
  407283:	push   rdi
  407284:	push   r12
  407286:	push   r13
  407288:	push   r15
  40728a:	push   r14
  40728c:	sub    rsp,0x50
  407290:	mov    rbp,rsp
  407293:	vmovups XMMWORD PTR [rsp],xmm6
  407298:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  40729e:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  4072a4:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  4072aa:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  4072b0:	sub    rsp,0x70
  4072b4:	mov    rbx,rsp
  4072b7:	mov    ecx,0x1000000
  4072bc:	sub    rsp,0x8
  4072c0:	call   40ab00 <__swc_fn_3464c816_000001_2744b483>
  4072c5:	add    rsp,0x8
  4072c9:	mov    rsi,rax
  4072cc:	mov    QWORD PTR [rsp+0x50],rax
  4072d1:	xor    ecx,ecx
  4072d3:	cs nop WORD PTR [rax+rax*1+0x0]
  4072dd:	cs nop WORD PTR [rax+rax*1+0x0]
  4072e7:	nop    WORD PTR [rax+rax*1+0x0]
  4072f0:	mov    r8,QWORD PTR [rip+0x1ad09]        # 422000 <__swc_data_base_3464c816>
  4072f7:	imul   r8,r8,0x41a7
  4072fe:	movabs rdx,0x200000005
  407308:	mov    r11,rax
  40730b:	mov    rax,r8
  40730e:	mul    rdx
  407311:	mov    r9,rdx
  407314:	mov    rdx,r8
  407317:	sub    rdx,r9
  40731a:	shr    rdx,1
  40731d:	add    rdx,r9
  407320:	shr    rdx,0x1e
  407324:	imul   r9,rdx,0x7fffffff
  40732b:	sub    r8,r9
  40732e:	mov    QWORD PTR [rip+0x1accb],r8        # 422000 <__swc_data_base_3464c816>
  407335:	mov    DWORD PTR [rsi+rcx*4],r8d
  407339:	add    rcx,0x1
  40733d:	mov    r8,QWORD PTR [rip+0x1acbc]        # 422000 <__swc_data_base_3464c816>
  407344:	imul   r8,r8,0x41a7
  40734b:	movabs rdx,0x200000005
  407355:	mov    rax,r8
  407358:	mul    rdx
  40735b:	mov    r9,rdx
  40735e:	mov    rax,r11
  407361:	mov    rdx,r8
  407364:	sub    rdx,r9
  407367:	shr    rdx,1
  40736a:	add    rdx,r9
  40736d:	shr    rdx,0x1e
  407371:	imul   rdx,rdx,0x7fffffff
  407378:	sub    r8,rdx
  40737b:	mov    QWORD PTR [rip+0x1ac7e],r8        # 422000 <__swc_data_base_3464c816>
  407382:	mov    DWORD PTR [rsi+rcx*4],r8d
  407386:	add    rcx,0x1
  40738a:	cmp    rcx,0x400000
  407391:	jb     4072f0 <__swc_fn_3464c816_000000_7f24d040+0x70>
  407397:	mov    rcx,QWORD PTR [rip+0x1ac62]        # 422000 <__swc_data_base_3464c816>
  40739e:	imul   rcx,rcx,0x41a7
  4073a5:	movabs rdx,0x200000005
  4073af:	mov    rax,rcx
  4073b2:	mul    rdx
  4073b5:	mov    r8,rdx
  4073b8:	mov    rdx,rcx
  4073bb:	sub    rdx,r8
  4073be:	shr    rdx,1
  4073c1:	add    rdx,r8
  4073c4:	shr    rdx,0x1e
  4073c8:	imul   r8,rdx,0x7fffffff
  4073cf:	mov    rdi,rcx
  4073d2:	sub    rdi,r8
  4073d5:	mov    QWORD PTR [rip+0x1ac24],rdi        # 422000 <__swc_data_base_3464c816>
  4073dc:	imul   rcx,rdi,0x41a7
  4073e3:	movabs rdx,0x200000005
  4073ed:	mov    rax,rcx
  4073f0:	mul    rdx
  4073f3:	mov    r8,rdx
  4073f6:	mov    rdx,rcx
  4073f9:	sub    rdx,r8
  4073fc:	shr    rdx,1
  4073ff:	add    rdx,r8
  407402:	shr    rdx,0x1e
  407406:	imul   rdx,rdx,0x7fffffff
  40740d:	mov    r12,rcx
  407410:	sub    r12,rdx
  407413:	mov    QWORD PTR [rip+0x1abe6],r12        # 422000 <__swc_data_base_3464c816>
  40741a:	imul   rcx,r12,0x41a7
  407421:	movabs rdx,0x200000005
  40742b:	mov    rax,rcx
  40742e:	mul    rdx
  407431:	mov    r8,rdx
  407434:	mov    rdx,rcx
  407437:	sub    rdx,r8
  40743a:	shr    rdx,1
  40743d:	add    rdx,r8
  407440:	shr    rdx,0x1e
  407444:	imul   rdx,rdx,0x7fffffff
  40744b:	mov    r13,rcx
  40744e:	sub    r13,rdx
  407451:	mov    QWORD PTR [rip+0x1aba8],r13        # 422000 <__swc_data_base_3464c816>
  407458:	imul   rcx,r13,0x41a7
  40745f:	movabs rdx,0x200000005
  407469:	mov    rax,rcx
  40746c:	mul    rdx
  40746f:	mov    r8,rdx
  407472:	mov    rdx,rcx
  407475:	sub    rdx,r8
  407478:	shr    rdx,1
  40747b:	add    rdx,r8
  40747e:	shr    rdx,0x1e
  407482:	imul   rdx,rdx,0x7fffffff
  407489:	mov    r14,rcx
  40748c:	sub    r14,rdx
  40748f:	mov    QWORD PTR [rip+0x1ab6a],r14        # 422000 <__swc_data_base_3464c816>
  407496:	imul   rcx,r14,0x41a7
  40749d:	movabs rdx,0x200000005
  4074a7:	mov    rax,rcx
  4074aa:	mul    rdx
  4074ad:	mov    r8,rdx
  4074b0:	mov    rdx,rcx
  4074b3:	sub    rdx,r8
  4074b6:	shr    rdx,1
  4074b9:	add    rdx,r8
  4074bc:	shr    rdx,0x1e
  4074c0:	imul   rdx,rdx,0x7fffffff
  4074c7:	mov    r15,rcx
  4074ca:	sub    r15,rdx
  4074cd:	mov    QWORD PTR [rip+0x1ab2c],r15        # 422000 <__swc_data_base_3464c816>
  4074d4:	imul   rcx,r15,0x41a7
  4074db:	movabs rdx,0x200000005
  4074e5:	mov    rax,rcx
  4074e8:	mul    rdx
  4074eb:	mov    r8,rdx
  4074ee:	mov    rdx,rcx
  4074f1:	sub    rdx,r8
  4074f4:	shr    rdx,1
  4074f7:	add    rdx,r8
  4074fa:	shr    rdx,0x1e
  4074fe:	imul   rdx,rdx,0x7fffffff
  407505:	mov    rsi,rcx
  407508:	sub    rsi,rdx
  40750b:	mov    QWORD PTR [rip+0x1aaee],rsi        # 422000 <__swc_data_base_3464c816>
  407512:	imul   rcx,rsi,0x41a7
  407519:	movabs rdx,0x200000005
  407523:	mov    rax,rcx
  407526:	mul    rdx
  407529:	mov    r8,rdx
  40752c:	mov    rdx,rcx
  40752f:	sub    rdx,r8
  407532:	shr    rdx,1
  407535:	add    rdx,r8
  407538:	shr    rdx,0x1e
  40753c:	imul   rdx,rdx,0x7fffffff
  407543:	mov    QWORD PTR [rsp+0x58],rsi
  407548:	mov    rsi,rcx
  40754b:	sub    rsi,rdx
  40754e:	mov    QWORD PTR [rip+0x1aaab],rsi        # 422000 <__swc_data_base_3464c816>
  407555:	imul   rcx,rsi,0x41a7
  40755c:	movabs rdx,0x200000005
  407566:	mov    rax,rcx
  407569:	mul    rdx
  40756c:	mov    r8,rdx
  40756f:	mov    rdx,rcx
  407572:	sub    rdx,r8
  407575:	shr    rdx,1
  407578:	add    rdx,r8
  40757b:	shr    rdx,0x1e
  40757f:	imul   rdx,rdx,0x7fffffff
  407586:	mov    QWORD PTR [rsp+0x60],rsi
  40758b:	mov    rsi,rcx
  40758e:	sub    rsi,rdx
  407591:	mov    QWORD PTR [rip+0x1aa68],rsi        # 422000 <__swc_data_base_3464c816>
  407598:	mov    QWORD PTR [rbx],0x0
  40759f:	mov    rcx,QWORD PTR [rip+0x1aa5a]        # 422000 <__swc_data_base_3464c816>
  4075a6:	imul   rcx,rcx,0x41a7
  4075ad:	movabs rdx,0x200000005
  4075b7:	mov    rax,rcx
  4075ba:	mul    rdx
  4075bd:	mov    r8,rdx
  4075c0:	mov    rdx,rcx
  4075c3:	sub    rdx,r8
  4075c6:	shr    rdx,1
  4075c9:	add    rdx,r8
  4075cc:	shr    rdx,0x1e
  4075d0:	imul   r8,rdx,0x7fffffff
  4075d7:	mov    QWORD PTR [rsp+0x68],rsi
  4075dc:	mov    rsi,rcx
  4075df:	sub    rsi,r8
  4075e2:	mov    QWORD PTR [rip+0x1aa17],rsi        # 422000 <__swc_data_base_3464c816>
  4075e9:	mov    DWORD PTR [rbx],esi
  4075eb:	mov    rcx,QWORD PTR [rip+0x1aa0e]        # 422000 <__swc_data_base_3464c816>
  4075f2:	imul   rcx,rcx,0x41a7
  4075f9:	movabs rdx,0x200000005
  407603:	mov    rax,rcx
  407606:	mul    rdx
  407609:	mov    r8,rdx
  40760c:	mov    rdx,rcx
  40760f:	sub    rdx,r8
  407612:	shr    rdx,1
  407615:	add    rdx,r8
  407618:	shr    rdx,0x1e
  40761c:	imul   r8,rdx,0x7fffffff
  407623:	mov    rsi,rcx
  407626:	sub    rsi,r8
  407629:	mov    QWORD PTR [rip+0x1a9d0],rsi        # 422000 <__swc_data_base_3464c816>
  407630:	mov    DWORD PTR [rbx+0x4],esi
  407633:	mov    rcx,QWORD PTR [rip+0x1a9c6]        # 422000 <__swc_data_base_3464c816>
  40763a:	imul   rcx,rcx,0x41a7
  407641:	movabs rdx,0x200000005
  40764b:	mov    rax,rcx
  40764e:	mul    rdx
  407651:	mov    r8,rdx
  407654:	mov    rdx,rcx
  407657:	sub    rdx,r8
  40765a:	shr    rdx,1
  40765d:	add    rdx,r8
  407660:	shr    rdx,0x1e
  407664:	imul   r8,rdx,0x7fffffff
  40766b:	mov    rsi,rcx
  40766e:	sub    rsi,r8
  407671:	mov    QWORD PTR [rip+0x1a988],rsi        # 422000 <__swc_data_base_3464c816>
  407678:	sub    rsp,0x8
  40767c:	call   40dda0 <__swc_fn_3464c816_000002_1ca87929>
  407681:	add    rsp,0x8
  407685:	vmovups xmm6,xmm0
  407689:	lea    rax,[rbx+0xc]
  40768d:	vxorps xmm0,xmm0,xmm0
  407691:	vmovups YMMWORD PTR [rbx+0xc],ymm0
  407696:	vmovups YMMWORD PTR [rbx+0x2c],ymm0
  40769b:	vzeroupper
  40769e:	mov    DWORD PTR [rax],0x61707865
  4076a4:	mov    DWORD PTR [rax+0x4],0x3320646e
  4076ab:	mov    DWORD PTR [rax+0x8],0x79622d32
  4076b2:	mov    DWORD PTR [rax+0xc],0x6b206574
  4076b9:	mov    DWORD PTR [rbx+0x1c],edi
  4076bc:	mov    DWORD PTR [rbx+0x20],r12d
  4076c0:	mov    DWORD PTR [rbx+0x24],r13d
  4076c4:	mov    DWORD PTR [rbx+0x28],r14d
  4076c8:	mov    DWORD PTR [rbx+0x2c],r15d
  4076cc:	mov    rax,QWORD PTR [rsp+0x58]
  4076d1:	mov    DWORD PTR [rbx+0x30],eax
  4076d4:	mov    rax,QWORD PTR [rsp+0x60]
  4076d9:	mov    DWORD PTR [rbx+0x34],eax
  4076dc:	mov    rax,QWORD PTR [rsp+0x68]
  4076e1:	mov    DWORD PTR [rbx+0x38],eax
  4076e4:	mov    eax,DWORD PTR [rbx]
  4076e6:	mov    DWORD PTR [rbx+0x40],eax
  4076e9:	mov    eax,DWORD PTR [rbx+0x4]
  4076ec:	mov    DWORD PTR [rbx+0x44],eax
  4076ef:	mov    DWORD PTR [rbx+0x48],esi
  4076f2:	xor    eax,eax
  4076f4:	mov    ecx,0x1
  4076f9:	vmovups xmm0,XMMWORD PTR [rip+0xbb1f]        # 413220 <__swc_rdata_base_3464c816+0x110>
  407701:	mov    rsi,QWORD PTR [rsp+0x50]
  407706:	vmovups xmm1,XMMWORD PTR [rip+0xbb22]        # 413230 <__swc_rdata_base_3464c816+0x120>
  40770e:	cmp    rax,0x400000
  407715:	jae    40787b <__swc_fn_3464c816_000000_7f24d040+0x5fb>
  40771b:	nop    DWORD PTR [rax+rax*1+0x0]
  407720:	mov    DWORD PTR [rbx+0x3c],ecx
  407723:	vmovups xmm3,XMMWORD PTR [rbx+0xc]
  407728:	vmovups xmm4,XMMWORD PTR [rbx+0x1c]
  40772d:	vmovups xmm5,XMMWORD PTR [rbx+0x2c]
  407732:	vmovups xmm2,XMMWORD PTR [rbx+0x3c]
  407737:	xor    edx,edx
  407739:	nop    DWORD PTR [rax+0x0]
  407740:	vpaddd xmm3,xmm3,xmm4
  407744:	vpxor  xmm2,xmm2,xmm3
  407748:	vpshufb xmm2,xmm2,xmm0
  40774d:	vpaddd xmm5,xmm5,xmm2
  407751:	vpxor  xmm4,xmm4,xmm5
  407755:	vpslld xmm7,xmm4,0xc
  40775a:	vpsrld xmm4,xmm4,0x14
  40775f:	vpor   xmm4,xmm7,xmm4
  407763:	vpaddd xmm3,xmm3,xmm4
  407767:	vpshufd xmm7,xmm3,0x39
  40776c:	vpshufd xmm2,xmm2,0x39
  407771:	vpxor  xmm2,xmm2,xmm7
  407775:	vpshufb xmm2,xmm2,xmm1
  40777a:	vpshufd xmm5,xmm5,0x39
  40777f:	vpaddd xmm5,xmm5,xmm2
  407783:	vpshufd xmm4,xmm4,0x39
  407788:	vpxor  xmm4,xmm4,xmm5
  40778c:	vpslld xmm7,xmm4,0x7
  407791:	vpsrld xmm4,xmm4,0x19
  407796:	vpor   xmm4,xmm7,xmm4
  40779a:	vpaddd xmm3,xmm3,xmm4
  40779e:	vpshufd xmm2,xmm2,0x4e
  4077a3:	vpxor  xmm2,xmm2,xmm3
  4077a7:	vpshufb xmm2,xmm2,xmm0
  4077ac:	vpshufd xmm5,xmm5,0x39
  4077b1:	vpaddd xmm5,xmm5,xmm2
  4077b5:	vpxor  xmm4,xmm4,xmm5
  4077b9:	vpslld xmm7,xmm4,0xc
  4077be:	vpsrld xmm4,xmm4,0x14
  4077c3:	vpor   xmm4,xmm7,xmm4
  4077c7:	vpaddd xmm3,xmm3,xmm4
  4077cb:	vpshufd xmm2,xmm2,0x93
  4077d0:	vpshufd xmm7,xmm3,0x93
  4077d5:	vpxor  xmm2,xmm2,xmm7
  4077d9:	vpshufb xmm2,xmm2,xmm1
  4077de:	vpshufd xmm5,xmm5,0x93
  4077e3:	vpaddd xmm5,xmm5,xmm2
  4077e7:	vpshufd xmm4,xmm4,0x93
  4077ec:	vpxor  xmm4,xmm4,xmm5
  4077f0:	vpslld xmm7,xmm4,0x7
  4077f5:	vpsrld xmm4,xmm4,0x19
  4077fa:	vpor   xmm4,xmm7,xmm4
  4077fe:	vpshufd xmm5,xmm5,0x93
  407803:	vpshufd xmm2,xmm2,0x4e
  407808:	add    rdx,0x1
  40780c:	cmp    rdx,0xa
  407810:	jb     407740 <__swc_fn_3464c816_000000_7f24d040+0x4c0>
  407816:	lea    rdx,[rsi+rax*4]
  40781a:	vpaddd xmm3,xmm3,XMMWORD PTR [rsp+0xc]
  407820:	vpxor  xmm3,xmm3,XMMWORD PTR [rsi+rax*4]
  407825:	vpaddd xmm4,xmm4,XMMWORD PTR [rsp+0x1c]
  40782b:	vpxor  xmm4,xmm4,XMMWORD PTR [rsi+rax*4+0x10]
  407831:	vpaddd xmm5,xmm5,XMMWORD PTR [rsp+0x2c]
  407837:	vpxor  xmm5,xmm5,XMMWORD PTR [rsi+rax*4+0x20]
  40783d:	vpaddd xmm7,xmm2,XMMWORD PTR [rsp+0x3c]
  407843:	vpxor  xmm7,xmm7,XMMWORD PTR [rsi+rax*4+0x30]
  407849:	vmovdqu XMMWORD PTR [rdx],xmm3
  40784d:	vmovdqu XMMWORD PTR [rdx+0x10],xmm4
  407852:	vmovdqu XMMWORD PTR [rdx+0x20],xmm5
  407857:	vmovdqu XMMWORD PTR [rdx+0x30],xmm7
  40785c:	vpshufd xmm2,xmm2,0x3
  407861:	vmovd  edx,xmm2
  407865:	add    edx,DWORD PTR [rbx+0x48]
  407868:	lea    rax,[rax+0x10]
  40786c:	inc    ecx
  40786e:	cmp    rax,0x400000
  407875:	jb     407720 <__swc_fn_3464c816_000000_7f24d040+0x4a0>
  40787b:	xor    edi,edi
  40787d:	xor    eax,eax
  40787f:	vxorps xmm0,xmm0,xmm0
  407883:	mov    ecx,0x1
  407888:	vpinsrd xmm0,xmm0,ecx,0x1
  40788e:	mov    ecx,0x2
  407893:	vpinsrd xmm0,xmm0,ecx,0x2
  407899:	mov    ecx,0x3
  40789e:	vpinsrd xmm0,xmm0,ecx,0x3
  4078a4:	vmovss xmm1,DWORD PTR [rip+0xb994]        # 413240 <__swc_rdata_base_3464c816+0x130>
  4078ac:	vpshufd xmm1,xmm1,0x0
  4078b1:	vpaddd xmm2,xmm0,xmm1
  4078b5:	vmovss xmm1,DWORD PTR [rip+0xb98c]        # 413249 <__swc_rdata_base_3464c816+0x139>
  4078bd:	vpshufd xmm1,xmm1,0x0
  4078c2:	vxorps xmm3,xmm3,xmm3
  4078c6:	vxorps xmm4,xmm4,xmm4
  4078ca:	nop    WORD PTR [rax+rax*1+0x0]
  4078d0:	vpaddd xmm5,xmm0,XMMWORD PTR [rsi+rax*4]
  4078d5:	vpxor  xmm3,xmm3,xmm5
  4078d9:	vpaddd xmm5,xmm2,XMMWORD PTR [rsi+rax*4+0x10]
  4078df:	vpxor  xmm4,xmm4,xmm5
  4078e3:	vpaddd xmm2,xmm2,xmm1
  4078e7:	vpaddd xmm0,xmm0,xmm1
  4078eb:	add    rax,0x8
  4078ef:	cmp    rax,0x3ffff9
  4078f6:	jb     4078d0 <__swc_fn_3464c816_000000_7f24d040+0x650>
  4078f8:	vpxor  xmm3,xmm3,xmm4
  4078fc:	vpshufd xmm5,xmm3,0x4e
  407901:	vpxor  xmm3,xmm3,xmm5
  407905:	vpshufd xmm5,xmm3,0xb1
  40790a:	vpxor  xmm3,xmm3,xmm5
  40790e:	vmovd  eax,xmm3
  407912:	xor    rdi,rax
  407915:	sub    rsp,0x8
  407919:	call   40dda0 <__swc_fn_3464c816_000002_1ca87929>
  40791e:	add    rsp,0x8
  407922:	vsubsd xmm0,xmm0,xmm6
  407926:	vmulsd xmm0,xmm0,QWORD PTR [rip+0xb924]        # 413252 <__swc_rdata_base_3464c816+0x142>
  40792e:	lea    rax,[rip+0xb7db]        # 413110 <__swc_rdata_base_3464c816>
  407935:	sub    rsp,0x90
  40793c:	mov    rcx,rsp
  40793f:	vmovups xmm1,XMMWORD PTR [rip+0xb8b1]        # 4131f8 <__swc_rdata_base_3464c816+0xe8>
  407947:	vmovups XMMWORD PTR [rcx],xmm1
  40794b:	mov    QWORD PTR [rcx+0x30],rsp
  40794f:	lea    rdx,[rip+0xb7ca]        # 413120 <__swc_rdata_base_3464c816+0x10>
  407956:	mov    QWORD PTR [rcx+0x38],rdx
  40795a:	mov    QWORD PTR [rcx+0x10],rdi
  40795e:	lea    r8,[rsp+0x10]
  407963:	mov    QWORD PTR [rcx+0x40],r8
  407967:	lea    r8,[rip+0xb7fa]        # 413168 <__swc_rdata_base_3464c816+0x58>
  40796e:	mov    QWORD PTR [rcx+0x48],r8
  407972:	vmovups xmm1,XMMWORD PTR [rip+0xb88e]        # 413208 <__swc_rdata_base_3464c816+0xf8>
  40797a:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40797f:	lea    r8,[rsp+0x18]
  407984:	mov    QWORD PTR [rcx+0x50],r8
  407988:	mov    QWORD PTR [rcx+0x58],rdx
  40798c:	vmovsd QWORD PTR [rcx+0x28],xmm0
  407991:	lea    r8,[rcx+0x28]
  407995:	mov    QWORD PTR [rcx+0x60],r8
  407999:	lea    r8,[rip+0xb810]        # 4131b0 <__swc_rdata_base_3464c816+0xa0>
  4079a0:	mov    QWORD PTR [rcx+0x68],r8
  4079a4:	mov    QWORD PTR [rcx+0x70],rax
  4079a8:	mov    QWORD PTR [rcx+0x78],rdx
  4079ac:	lea    rax,[rcx+0x30]
  4079b0:	mov    QWORD PTR [rcx+0x80],rax
  4079b7:	mov    QWORD PTR [rcx+0x88],0x5
  4079c2:	lea    rcx,[rcx+0x80]
  4079c9:	sub    rsp,0x8
  4079cd:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  4079d2:	add    rsp,0x108
  4079d9:	vmovups xmm6,XMMWORD PTR [rsp]
  4079de:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  4079e4:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  4079ea:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  4079f0:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  4079f6:	add    rsp,0x50
  4079fa:	pop    r14
  4079fc:	pop    r15
  4079fe:	pop    r13
  407a00:	pop    r12
  407a02:	pop    rdi
  407a03:	pop    rsi
  407a04:	pop    rbx
  407a05:	pop    rbp
  407a06:	ret
	...

0000000000407a10 <__swc_fn_3464c816_000003_9ee35b18>:
  407a10:	vxorps xmm0,xmm0,xmm0
  407a14:	vmovups XMMWORD PTR [rcx],xmm0
  407a18:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  407a1d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407a22:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407a27:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  407a2c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407a31:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407a36:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  407a3b:	ret
  407a3c:	add    BYTE PTR [rax],al
	...

0000000000407a40 <__swc_fn_3464c816_000006_f7acedb0>:
  407a40:	push   rsi
  407a41:	mov    rsi,rdx
  407a44:	test   rdx,rdx
  407a47:	jne    407a50 <__swc_fn_3464c816_000006_f7acedb0+0x10>
  407a49:	mov    eax,0x1
  407a4e:	pop    rsi
  407a4f:	ret
  407a50:	mov    rdx,rsi
  407a53:	call   4099e0 <__swc_fn_3464c816_000114_36905703>
  407a58:	test   al,al
  407a5a:	jne    407a60 <__swc_fn_3464c816_000006_f7acedb0+0x20>
  407a5c:	xor    eax,eax
  407a5e:	pop    rsi
  407a5f:	ret
  407a60:	lea    rcx,[rip+0x1c5e9]        # 424050 <__swc_bss_base_3464c816+0x10>
  407a67:	mov    rdx,QWORD PTR [rip+0x1c5e2]        # 424050 <__swc_bss_base_3464c816+0x10>
  407a6e:	xchg   ax,ax
  407a70:	lea    r8,[rdx+rsi*1]
  407a74:	mov    rax,rdx
  407a77:	lock cmpxchg QWORD PTR [rcx],r8
  407a7c:	cmp    rax,rdx
  407a7f:	je     407a86 <__swc_fn_3464c816_000006_f7acedb0+0x46>
  407a81:	mov    rdx,rax
  407a84:	jmp    407a70 <__swc_fn_3464c816_000006_f7acedb0+0x30>
  407a86:	lea    rcx,[rip+0x1c5cb]        # 424058 <__swc_bss_base_3464c816+0x18>
  407a8d:	mov    rdx,QWORD PTR [rip+0x1c5c4]        # 424058 <__swc_bss_base_3464c816+0x18>
  407a94:	cs nop WORD PTR [rax+rax*1+0x0]
  407a9e:	xchg   ax,ax
  407aa0:	lea    r8,[rdx+0x1]
  407aa4:	mov    rax,rdx
  407aa7:	lock cmpxchg QWORD PTR [rcx],r8
  407aac:	cmp    rax,rdx
  407aaf:	je     407ab6 <__swc_fn_3464c816_000006_f7acedb0+0x76>
  407ab1:	mov    rdx,rax
  407ab4:	jmp    407aa0 <__swc_fn_3464c816_000006_f7acedb0+0x60>
  407ab6:	mov    eax,0x1
  407abb:	pop    rsi
  407abc:	ret
  407abd:	add    BYTE PTR [rax],al
	...

0000000000407ac0 <__swc_fn_3464c816_000009_24a20786>:
  407ac0:	push   rbx
  407ac1:	push   rsi
  407ac2:	push   rdi
  407ac3:	push   r12
  407ac5:	sub    rsp,0x18
  407ac9:	mov    rbx,rcx
  407acc:	mov    rsi,rcx
  407acf:	and    rsi,0xffffffffffc00000
  407ad6:	movzx  eax,BYTE PTR [rbx+0x3a]
  407ada:	mov    ecx,DWORD PTR [rsi+0x28]
  407add:	shrx   eax,eax,ecx
  407ae2:	lea    rdi,[rsp+0x8]
  407ae7:	mov    DWORD PTR [rsp+0x8],eax
  407aeb:	mov    rcx,rsi
  407aee:	mov    rax,rdi
  407af1:	mov    edx,DWORD PTR [rax]
  407af3:	call   40df60 <__swc_fn_3464c816_000014_9dea5065>
  407af8:	mov    r12,rax
  407afb:	mov    rcx,rsi
  407afe:	mov    edx,DWORD PTR [rdi]
  407b00:	call   407bf0 <__swc_fn_3464c816_000015_9afb7cfb>
  407b05:	mov    rcx,r12
  407b08:	mov    edx,DWORD PTR [rbx+0x3c]
  407b0b:	add    rcx,rdx
  407b0e:	cmp    rcx,rax
  407b11:	jb     407b1f <__swc_fn_3464c816_000009_24a20786+0x5f>
  407b13:	xor    eax,eax
  407b15:	add    rsp,0x18
  407b19:	pop    r12
  407b1b:	pop    rdi
  407b1c:	pop    rsi
  407b1d:	pop    rbx
  407b1e:	ret
  407b1f:	mov    rdx,QWORD PTR [rbx+0x20]
  407b23:	mov    r8d,DWORD PTR [rbx+0x2c]
  407b27:	add    rdx,r8
  407b2a:	lea    rsi,[rdx+0xffff]
  407b31:	and    rsi,0xffffffffffff0000
  407b38:	cmp    rax,rsi
  407b3b:	cmovbe rsi,rax
  407b3f:	mov    rax,rsi
  407b42:	sub    rax,rcx
  407b45:	mov    rdx,rax
  407b48:	call   407a40 <__swc_fn_3464c816_000006_f7acedb0>
  407b4d:	test   al,al
  407b4f:	jne    407b5d <__swc_fn_3464c816_000009_24a20786+0x9d>
  407b51:	xor    eax,eax
  407b53:	add    rsp,0x18
  407b57:	pop    r12
  407b59:	pop    rdi
  407b5a:	pop    rsi
  407b5b:	pop    rbx
  407b5c:	ret
  407b5d:	sub    rsi,r12
  407b60:	mov    DWORD PTR [rbx+0x3c],esi
  407b63:	mov    ecx,DWORD PTR [rbx+0x2c]
  407b66:	mov    rax,rsi
  407b69:	xor    edx,edx
  407b6b:	div    rcx
  407b6e:	imul   rax,rcx
  407b72:	add    r12,rax
  407b75:	mov    QWORD PTR [rbx+0x18],r12
  407b79:	mov    eax,0x1
  407b7e:	add    rsp,0x18
  407b82:	pop    r12
  407b84:	pop    rdi
  407b85:	pop    rsi
  407b86:	pop    rbx
  407b87:	ret
	...

0000000000407b90 <__swc_fn_3464c816_000012_e4b0ddfc>:
  407b90:	sub    rsp,0x8
  407b94:	mov    rdx,rcx
  407b97:	lea    r9,[rcx+0x60]
  407b9b:	mov    rax,QWORD PTR [r9]
  407b9e:	test   rax,rax
  407ba1:	jne    407ba8 <__swc_fn_3464c816_000012_e4b0ddfc+0x18>
  407ba3:	add    rsp,0x8
  407ba7:	ret
  407ba8:	mov    rcx,rdx
  407bab:	call   40ac90 <__swc_fn_3464c816_000010_c3647f66>
  407bb0:	xor    eax,eax
  407bb2:	xchg   QWORD PTR [r9],rax
  407bb5:	mov    r8,rax
  407bb8:	mov    rcx,rdx
  407bbb:	call   40df50 <__swc_fn_3464c816_000011_861b8b62>
  407bc0:	xor    eax,eax
  407bc2:	test   r8,r8
  407bc5:	je     407be6 <__swc_fn_3464c816_000012_e4b0ddfc+0x56>
  407bc7:	nop    WORD PTR [rax+rax*1+0x0]
  407bd0:	mov    rcx,QWORD PTR [r8]
  407bd3:	mov    r9,QWORD PTR [rdx]
  407bd6:	mov    QWORD PTR [r8],r9
  407bd9:	mov    QWORD PTR [rdx],r8
  407bdc:	mov    r8,rcx
  407bdf:	inc    eax
  407be1:	test   rcx,rcx
  407be4:	jne    407bd0 <__swc_fn_3464c816_000012_e4b0ddfc+0x40>
  407be6:	sub    DWORD PTR [rdx+0x28],eax
  407be9:	add    rsp,0x8
  407bed:	ret
	...

0000000000407bf0 <__swc_fn_3464c816_000015_9afb7cfb>:
  407bf0:	lea    eax,[rdx+0x1]
  407bf3:	mov    edx,DWORD PTR [rcx+0x28]
  407bf6:	shlx   eax,eax,edx
  407bfb:	shl    rax,0x10
  407bff:	add    rax,rcx
  407c02:	ret
	...

0000000000407c10 <__swc_fn_3464c816_000018_adca76cf>:
  407c10:	push   rbx
  407c11:	push   rsi
  407c12:	push   rdi
  407c13:	push   r12
  407c15:	push   r13
  407c17:	push   r14
  407c19:	push   r15
  407c1b:	sub    rsp,0x30
  407c1f:	mov    rbx,rcx
  407c22:	lea    rsi,[rcx+0x48]
  407c26:	mov    QWORD PTR [rsp+0x18],rsi
  407c2b:	mov    rax,QWORD PTR [rsi]
  407c2e:	mov    rdi,rax
  407c31:	lea    r12,[rsp+0x8]
  407c36:	lea    r13,[rcx+0x40]
  407c3a:	nop    WORD PTR [rax+rax*1+0x0]
  407c40:	test   rdi,rdi
  407c43:	je     407d83 <__swc_fn_3464c816_000018_adca76cf+0x173>
  407c49:	xor    eax,eax
  407c4b:	tzcnt  rax,rdi
  407c50:	mov    DWORD PTR [rsp+0x8],eax
  407c54:	mov    r14d,0x1
  407c5a:	mov    ecx,eax
  407c5c:	shl    r14,cl
  407c5f:	andn   rdi,r14,rdi
  407c64:	mov    rcx,QWORD PTR [r13+0x0]
  407c68:	test   rcx,r14
  407c6b:	jne    407c40 <__swc_fn_3464c816_000018_adca76cf+0x30>
  407c6d:	mov    rdx,rcx
  407c70:	or     rdx,r14
  407c73:	mov    rax,rcx
  407c76:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  407c7c:	cmp    rax,rcx
  407c7f:	je     407c89 <__swc_fn_3464c816_000018_adca76cf+0x79>
  407c81:	mov    rax,QWORD PTR [rsi]
  407c84:	mov    rdi,rax
  407c87:	jmp    407c40 <__swc_fn_3464c816_000018_adca76cf+0x30>
  407c89:	mov    rcx,rbx
  407c8c:	mov    rdx,r14
  407c8f:	call   40e0c0 <__swc_fn_3464c816_000020_fd2b165c>
  407c94:	test   al,al
  407c96:	je     407d6e <__swc_fn_3464c816_000018_adca76cf+0x15e>
  407c9c:	mov    eax,DWORD PTR [r12]
  407ca0:	shl    rax,0x4
  407ca4:	lea    r15,[rbx+rax*8+0x80]
  407cac:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407cb4:	lea    rcx,[rip+0x1c3a5]        # 424060 <__swc_bss_base_3464c816+0x20>
  407cbb:	mov    rdx,QWORD PTR [rip+0x1c39e]        # 424060 <__swc_bss_base_3464c816+0x20>
  407cc2:	cs nop WORD PTR [rax+rax*1+0x0]
  407ccc:	nop    DWORD PTR [rax+0x0]
  407cd0:	mov    r8,rdx
  407cd3:	sub    r8,rsi
  407cd6:	mov    rax,rdx
  407cd9:	lock cmpxchg QWORD PTR [rcx],r8
  407cde:	cmp    rax,rdx
  407ce1:	je     407ce8 <__swc_fn_3464c816_000018_adca76cf+0xd8>
  407ce3:	mov    rdx,rax
  407ce6:	jmp    407cd0 <__swc_fn_3464c816_000018_adca76cf+0xc0>
  407ce8:	mov    rcx,rbx
  407ceb:	mov    rax,r12
  407cee:	mov    edx,DWORD PTR [rax]
  407cf0:	call   40df60 <__swc_fn_3464c816_000014_9dea5065>
  407cf5:	test   rsi,rsi
  407cf8:	je     407d66 <__swc_fn_3464c816_000018_adca76cf+0x156>
  407cfe:	mov    rcx,rax
  407d01:	mov    rdx,rsi
  407d04:	call   40cf00 <__swc_fn_3464c816_000115_e9fc0224>
  407d09:	lea    rcx,[rip+0x1c340]        # 424050 <__swc_bss_base_3464c816+0x10>
  407d10:	mov    rdx,QWORD PTR [rip+0x1c339]        # 424050 <__swc_bss_base_3464c816+0x10>
  407d17:	nop    WORD PTR [rax+rax*1+0x0]
  407d20:	mov    r8,rdx
  407d23:	sub    r8,rsi
  407d26:	mov    rax,rdx
  407d29:	lock cmpxchg QWORD PTR [rcx],r8
  407d2e:	cmp    rax,rdx
  407d31:	je     407d38 <__swc_fn_3464c816_000018_adca76cf+0x128>
  407d33:	mov    rdx,rax
  407d36:	jmp    407d20 <__swc_fn_3464c816_000018_adca76cf+0x110>
  407d38:	lea    rcx,[rip+0x1c329]        # 424068 <__swc_bss_base_3464c816+0x28>
  407d3f:	mov    rdx,QWORD PTR [rip+0x1c322]        # 424068 <__swc_bss_base_3464c816+0x28>
  407d46:	cs nop WORD PTR [rax+rax*1+0x0]
  407d50:	lea    r8,[rdx+0x1]
  407d54:	mov    rax,rdx
  407d57:	lock cmpxchg QWORD PTR [rcx],r8
  407d5c:	cmp    rax,rdx
  407d5f:	je     407d66 <__swc_fn_3464c816_000018_adca76cf+0x156>
  407d61:	mov    rdx,rax
  407d64:	jmp    407d50 <__swc_fn_3464c816_000018_adca76cf+0x140>
  407d66:	mov    DWORD PTR [r15+0x3c],0x0
  407d6e:	mov    rcx,rbx
  407d71:	mov    rdx,r14
  407d74:	call   407da0 <__swc_fn_3464c816_000021_c8f5f27c>
  407d79:	mov    rsi,QWORD PTR [rsp+0x18]
  407d7e:	jmp    407c40 <__swc_fn_3464c816_000018_adca76cf+0x30>
  407d83:	add    rsp,0x30
  407d87:	pop    r15
  407d89:	pop    r14
  407d8b:	pop    r13
  407d8d:	pop    r12
  407d8f:	pop    rdi
  407d90:	pop    rsi
  407d91:	pop    rbx
  407d92:	ret
	...

0000000000407da0 <__swc_fn_3464c816_000021_c8f5f27c>:
  407da0:	mov    r8,QWORD PTR [rcx+0x40]
  407da4:	cs nop WORD PTR [rax+rax*1+0x0]
  407dae:	xchg   ax,ax
  407db0:	mov    rax,rdx
  407db3:	not    rax
  407db6:	mov    r9,r8
  407db9:	and    r9,rax
  407dbc:	mov    rax,r8
  407dbf:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407dc5:	cmp    rax,r8
  407dc8:	jne    407dcb <__swc_fn_3464c816_000021_c8f5f27c+0x2b>
  407dca:	ret
  407dcb:	mov    r8,rax
  407dce:	jmp    407db0 <__swc_fn_3464c816_000021_c8f5f27c+0x10>

0000000000407dd0 <__swc_fn_3464c816_000024_aa910677>:
  407dd0:	push   rsi
  407dd1:	push   rdi
  407dd2:	sub    rsp,0x8
  407dd6:	mov    rsi,rcx
  407dd9:	call   407c10 <__swc_fn_3464c816_000018_adca76cf>
  407dde:	lea    rdi,[rip+0x1c413]        # 4241f8 <__swc_bss_base_3464c816+0x1b8>
  407de5:	mov    rcx,rdi
  407de8:	call   40a040 <__swc_fn_3464c816_000138_86bb0f90>
  407ded:	mov    QWORD PTR [rsi+0x8],0x0
  407df5:	mov    QWORD PTR [rsi+0x18],0x0
  407dfd:	mov    rax,QWORD PTR [rip+0x1c3fc]        # 424200 <__swc_bss_base_3464c816+0x1c0>
  407e04:	mov    QWORD PTR [rsi+0x10],rax
  407e08:	mov    QWORD PTR [rip+0x1c3f1],rsi        # 424200 <__swc_bss_base_3464c816+0x1c0>
  407e0f:	mov    rcx,rdi
  407e12:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  407e17:	add    rsp,0x8
  407e1b:	pop    rdi
  407e1c:	pop    rsi
  407e1d:	ret
	...

0000000000407e20 <__swc_fn_3464c816_000027_9798fb47>:
  407e20:	vxorps xmm0,xmm0,xmm0
  407e24:	vmovups XMMWORD PTR [rcx],xmm0
  407e28:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  407e2d:	mov    QWORD PTR [rcx+0x20],0x0
  407e35:	ret
	...

0000000000407e40 <__swc_fn_3464c816_000030_9798fb47>:
  407e40:	vxorps xmm0,xmm0,xmm0
  407e44:	vmovups XMMWORD PTR [rcx],xmm0
  407e48:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  407e4d:	mov    QWORD PTR [rcx+0x20],0x0
  407e55:	ret
	...

0000000000407e60 <__swc_fn_3464c816_000033_9128bcf9>:
  407e60:	push   r12
  407e62:	mov    r12,rdi
  407e65:	test   rdi,rdi
  407e68:	jne    407e6d <__swc_fn_3464c816_000033_9128bcf9+0xd>
  407e6a:	pop    r12
  407e6c:	ret
  407e6d:	lea    rax,[rip+0x1a194]        # 422008 <__swc_data_base_3464c816+0x8>
  407e74:	mov    rax,QWORD PTR [rax]
  407e77:	cmp    rax,0xffffffffffffffff
  407e7b:	je     407e8a <__swc_fn_3464c816_000033_9128bcf9+0x2a>
  407e7d:	mov    eax,eax
  407e7f:	mov    edi,eax
  407e81:	xor    eax,eax
  407e83:	call   407000 <pthread_getspecific@plt>
  407e88:	jmp    407e8c <__swc_fn_3464c816_000033_9128bcf9+0x2c>
  407e8a:	xor    eax,eax
  407e8c:	cmp    rax,r12
  407e8f:	jne    407e98 <__swc_fn_3464c816_000033_9128bcf9+0x38>
  407e91:	xor    ecx,ecx
  407e93:	call   40e280 <__swc_fn_3464c816_000035_92d9bbff>
  407e98:	mov    rdx,QWORD PTR [r12]
  407e9c:	test   rdx,rdx
  407e9f:	je     407eb8 <__swc_fn_3464c816_000033_9128bcf9+0x58>
  407ea1:	mov    rcx,rdx
  407ea4:	call   407ee0 <__swc_fn_3464c816_000039_eb6108f2>
  407ea9:	test   al,al
  407eab:	je     407eb8 <__swc_fn_3464c816_000033_9128bcf9+0x58>
  407ead:	mov    rcx,rdx
  407eb0:	mov    rdx,r12
  407eb3:	call   407fe0 <__swc_fn_3464c816_000045_b30433d0>
  407eb8:	pop    r12
  407eba:	ret
  407ebb:	add    BYTE PTR [rax],al
  407ebd:	add    BYTE PTR [rax],al
	...

0000000000407ec0 <__swc_fn_3464c816_000036_28d0e998>:
  407ec0:	push   rsi
  407ec1:	mov    rsi,rcx
  407ec4:	call   40b140 <__swc_fn_3464c816_000034_cd1a4e8c>
  407ec9:	mov    rcx,rax
  407ecc:	mov    rdx,rsi
  407ecf:	call   409ec0 <__swc_fn_3464c816_000132_ae5891af>
  407ed4:	mov    rcx,rsi
  407ed7:	call   40e280 <__swc_fn_3464c816_000035_92d9bbff>
  407edc:	pop    rsi
  407edd:	ret
	...

0000000000407ee0 <__swc_fn_3464c816_000039_eb6108f2>:
  407ee0:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  407eea:	sete   al
  407eed:	ret
	...

0000000000407ef0 <__swc_fn_3464c816_000042_d3c2ab54>:
  407ef0:	push   rsi
  407ef1:	test   rdx,rdx
  407ef4:	jne    407ef8 <__swc_fn_3464c816_000042_d3c2ab54+0x8>
  407ef6:	pop    rsi
  407ef7:	ret
  407ef8:	mov    rax,r8
  407efb:	mov    ecx,0x1000
  407f00:	test   ecx,ecx
  407f02:	mov    r10d,0x8
  407f08:	cmove  ecx,r10d
  407f0c:	dec    rcx
  407f0f:	mov    r10,0xffffffffffffffff
  407f16:	sub    r10,rcx
  407f19:	cmp    r8,r10
  407f1c:	jbe    407f22 <__swc_fn_3464c816_000042_d3c2ab54+0x32>
  407f1e:	xor    eax,eax
  407f20:	jmp    407f2a <__swc_fn_3464c816_000042_d3c2ab54+0x3a>
  407f22:	add    rax,rcx
  407f25:	andn   rax,rcx,rax
  407f2a:	mov    ecx,0x1000
  407f2f:	test   ecx,ecx
  407f31:	mov    r8d,0x8
  407f37:	cmove  ecx,r8d
  407f3b:	dec    rcx
  407f3e:	mov    r8,0xffffffffffffffff
  407f45:	sub    r8,rcx
  407f48:	cmp    r9,r8
  407f4b:	jbe    407f51 <__swc_fn_3464c816_000042_d3c2ab54+0x61>
  407f4d:	xor    esi,esi
  407f4f:	jmp    407f5c <__swc_fn_3464c816_000042_d3c2ab54+0x6c>
  407f51:	add    r9,rcx
  407f54:	andn   r9,rcx,r9
  407f59:	mov    rsi,r9
  407f5c:	mov    rcx,rdx
  407f5f:	mov    rdx,rax
  407f62:	mov    r8,rsi
  407f65:	call   409ac0 <__swc_fn_3464c816_000117_5208f471>
  407f6a:	lea    rcx,[rip+0x1c0df]        # 424050 <__swc_bss_base_3464c816+0x10>
  407f71:	mov    rdx,QWORD PTR [rip+0x1c0d8]        # 424050 <__swc_bss_base_3464c816+0x10>
  407f78:	nop    DWORD PTR [rax+rax*1+0x0]
  407f80:	mov    r8,rdx
  407f83:	sub    r8,rsi
  407f86:	mov    rax,rdx
  407f89:	lock cmpxchg QWORD PTR [rcx],r8
  407f8e:	cmp    rax,rdx
  407f91:	je     407f98 <__swc_fn_3464c816_000042_d3c2ab54+0xa8>
  407f93:	mov    rdx,rax
  407f96:	jmp    407f80 <__swc_fn_3464c816_000042_d3c2ab54+0x90>
  407f98:	lea    rcx,[rip+0x1c0c9]        # 424068 <__swc_bss_base_3464c816+0x28>
  407f9f:	mov    rdx,QWORD PTR [rip+0x1c0c2]        # 424068 <__swc_bss_base_3464c816+0x28>
  407fa6:	cs nop WORD PTR [rax+rax*1+0x0]
  407fb0:	lea    r8,[rdx+0x1]
  407fb4:	mov    rax,rdx
  407fb7:	lock cmpxchg QWORD PTR [rcx],r8
  407fbc:	cmp    rax,rdx
  407fbf:	je     407fc6 <__swc_fn_3464c816_000042_d3c2ab54+0xd6>
  407fc1:	mov    rdx,rax
  407fc4:	jmp    407fb0 <__swc_fn_3464c816_000042_d3c2ab54+0xc0>
  407fc6:	pop    rsi
  407fc7:	ret
	...

0000000000407fe0 <__swc_fn_3464c816_000045_b30433d0>:
  407fe0:	push   rbx
  407fe1:	push   rsi
  407fe2:	push   rdi
  407fe3:	push   r12
  407fe5:	push   r13
  407fe7:	push   r14
  407fe9:	push   r15
  407feb:	sub    rsp,0x30
  407fef:	mov    rbx,rdx
  407ff2:	mov    QWORD PTR [rsp+0x18],rdx
  407ff7:	mov    rsi,rcx
  407ffa:	mov    eax,0x1
  407fff:	xchg   DWORD PTR [rbx+0x20],eax
  408002:	test   eax,eax
  408004:	je     408016 <__swc_fn_3464c816_000045_b30433d0+0x36>
  408006:	add    rsp,0x30
  40800a:	pop    r15
  40800c:	pop    r14
  40800e:	pop    r13
  408010:	pop    r12
  408012:	pop    rdi
  408013:	pop    rsi
  408014:	pop    rbx
  408015:	ret
  408016:	mov    rcx,rsi
  408019:	mov    rdx,rbx
  40801c:	mov    r8,0xffffffffffffffff
  408023:	call   40e850 <__swc_fn_3464c816_000062_dea90857>
  408028:	lea    rdi,[rsi+0x10]
  40802c:	mov    QWORD PTR [rsp+0x20],rdi
  408031:	mov    rcx,rdi
  408034:	call   40a040 <__swc_fn_3464c816_000138_86bb0f90>
  408039:	xor    r12d,r12d
  40803c:	cs nop WORD PTR [rax+rax*1+0x0]
  408046:	cs nop WORD PTR [rax+rax*1+0x0]
  408050:	mov    eax,r12d
  408053:	lea    r13,[rax+rax*4]
  408057:	lea    r13,[rbx+r13*8+0x28]
  40805c:	mov    rax,QWORD PTR [r13+0x8]
  408060:	mov    QWORD PTR [rsp+0x8],rax
  408065:	mov    rax,QWORD PTR [r13+0x18]
  408069:	mov    QWORD PTR [rsp+0x10],rax
  40806e:	mov    r14d,0x2
  408074:	xor    r15d,r15d
  408077:	test   r14,r14
  40807a:	je     4080f7 <__swc_fn_3464c816_000045_b30433d0+0x117>
  408080:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  408085:	mov    rdi,rax
  408088:	test   rdi,rdi
  40808b:	je     4080e9 <__swc_fn_3464c816_000045_b30433d0+0x109>
  40808d:	nop    DWORD PTR [rax]
  408090:	mov    rbx,QWORD PTR [rdi+0x48]
  408094:	mov    DWORD PTR [rdi+0x6c],0x0
  40809b:	mov    rcx,rdi
  40809e:	call   407b90 <__swc_fn_3464c816_000012_e4b0ddfc>
  4080a3:	cmp    DWORD PTR [rdi+0x28],0x0
  4080a7:	jne    4080c0 <__swc_fn_3464c816_000045_b30433d0+0xe0>
  4080a9:	mov    rax,rdi
  4080ac:	and    rax,0xffffffffffc00000
  4080b3:	mov    rcx,rax
  4080b6:	mov    rdx,rdi
  4080b9:	call   40df80 <__swc_fn_3464c816_000017_283e2b5e>
  4080be:	jmp    4080e1 <__swc_fn_3464c816_000045_b30433d0+0x101>
  4080c0:	mov    QWORD PTR [rdi+0x40],0x0
  4080c8:	rex mov BYTE PTR [rdi+0x3b],0x2
  4080cd:	mov    QWORD PTR [rdi+0x50],0x0
  4080d5:	mov    rax,QWORD PTR [rsi+0x28]
  4080d9:	mov    QWORD PTR [rdi+0x48],rax
  4080dd:	mov    QWORD PTR [rsi+0x28],rdi
  4080e1:	mov    rdi,rbx
  4080e4:	test   rbx,rbx
  4080e7:	jne    408090 <__swc_fn_3464c816_000045_b30433d0+0xb0>
  4080e9:	add    r15,0x1
  4080ed:	sub    r14,0x1
  4080f1:	jne    408080 <__swc_fn_3464c816_000045_b30433d0+0xa0>
  4080f7:	vxorps xmm0,xmm0,xmm0
  4080fb:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  408101:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  408107:	mov    QWORD PTR [r13+0x20],0x0
  40810f:	add    r12,0x1
  408113:	cmp    r12,0x2d
  408117:	mov    rbx,QWORD PTR [rsp+0x18]
  40811c:	jb     408050 <__swc_fn_3464c816_000045_b30433d0+0x70>
  408122:	mov    rcx,rsi
  408125:	mov    rbx,QWORD PTR [rsp+0x18]
  40812a:	mov    rdx,rbx
  40812d:	mov    rdi,QWORD PTR [rsp+0x20]
  408132:	call   40b300 <__swc_fn_3464c816_000046_6e7a8d58>
  408137:	mov    rcx,rdi
  40813a:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40813f:	mov    rcx,rsi
  408142:	mov    rdx,rbx
  408145:	mov    r8d,0x9b8
  40814b:	mov    r9d,0x9b8
  408151:	call   407ef0 <__swc_fn_3464c816_000042_d3c2ab54>
  408156:	add    rsp,0x30
  40815a:	pop    r15
  40815c:	pop    r14
  40815e:	pop    r13
  408160:	pop    r12
  408162:	pop    rdi
  408163:	pop    rsi
  408164:	pop    rbx
  408165:	ret
	...

0000000000408180 <__swc_fn_3464c816_000048_ad48ec88>:
  408180:	push   rbx
  408181:	push   rsi
  408182:	push   rdi
  408183:	push   r12
  408185:	push   r13
  408187:	push   r14
  408189:	push   r15
  40818b:	sub    rsp,0x30
  40818f:	mov    ebx,r8d
  408192:	mov    rsi,rcx
  408195:	mov    rdi,rdx
  408198:	test   r8d,r8d
  40819b:	jne    4081a4 <__swc_fn_3464c816_000048_ad48ec88+0x24>
  40819d:	mov    eax,0x8
  4081a2:	jmp    4081cb <__swc_fn_3464c816_000048_ad48ec88+0x4b>
  4081a4:	cmp    ebx,0x8
  4081a7:	ja     4081b2 <__swc_fn_3464c816_000048_ad48ec88+0x32>
  4081a9:	mov    rax,rbx
  4081ac:	shl    rax,0x4
  4081b0:	jmp    4081cb <__swc_fn_3464c816_000048_ad48ec88+0x4b>
  4081b2:	lea    eax,[rbx-0x9]
  4081b5:	mov    ecx,eax
  4081b7:	shr    ecx,0x2
  4081ba:	and    eax,0x3
  4081bd:	lea    ecx,[rcx+0x7]
  4081c0:	lea    ecx,[rcx-0x2]
  4081c3:	lea    eax,[rax+0x5]
  4081c6:	shlx   rax,rax,rcx
  4081cb:	lea    r12,[rsp+0x8]
  4081d0:	mov    DWORD PTR [rsp+0x8],eax
  4081d4:	lea    r13,[rsp+0xc]
  4081d9:	mov    QWORD PTR [rsp+0x18],r13
  4081de:	xor    eax,eax
  4081e0:	cmp    ebx,0x21
  4081e3:	setae  al
  4081e6:	lea    eax,[rax+rax*2]
  4081e9:	mov    DWORD PTR [rsp+0xc],eax
  4081ed:	lea    r14,[rsi+0x10]
  4081f1:	mov    rcx,r14
  4081f4:	call   40a040 <__swc_fn_3464c816_000138_86bb0f90>
  4081f9:	xor    eax,eax
  4081fb:	mov    rcx,QWORD PTR [rsi+0x28]
  4081ff:	mov    r15,rcx
  408202:	test   r15,r15
  408205:	je     4082b6 <__swc_fn_3464c816_000048_ad48ec88+0x136>
  40820b:	cs nop WORD PTR [rax+rax*1+0x0]
  408215:	cs nop WORD PTR [rax+rax*1+0x0]
  40821f:	nop
  408220:	mov    rcx,QWORD PTR [r15+0x48]
  408224:	movzx  edx,BYTE PTR [r15+0x39]
  408229:	cmp    edx,ebx
  40822b:	jne    4082a7 <__swc_fn_3464c816_000048_ad48ec88+0x127>
  40822d:	test   rax,rax
  408230:	jne    408238 <__swc_fn_3464c816_000048_ad48ec88+0xb8>
  408232:	mov    QWORD PTR [rsi+0x28],rcx
  408236:	jmp    40823c <__swc_fn_3464c816_000048_ad48ec88+0xbc>
  408238:	mov    QWORD PTR [rax+0x48],rcx
  40823c:	vxorps xmm0,xmm0,xmm0
  408240:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  408246:	mov    BYTE PTR [r15+0x3b],0x1
  40824b:	mov    QWORD PTR [r15+0x40],rdi
  40824f:	mov    rcx,r15
  408252:	call   407b90 <__swc_fn_3464c816_000012_e4b0ddfc>
  408257:	movzx  eax,BYTE PTR [r15+0x39]
  40825c:	lea    rax,[rax+rax*4]
  408260:	lea    rax,[rdi+rax*8+0x28]
  408265:	mov    rcx,QWORD PTR [rax+0x10]
  408269:	mov    QWORD PTR [r15+0x50],rcx
  40826d:	mov    QWORD PTR [r15+0x48],0x0
  408275:	mov    rcx,QWORD PTR [rax+0x10]
  408279:	test   rcx,rcx
  40827c:	je     408284 <__swc_fn_3464c816_000048_ad48ec88+0x104>
  40827e:	mov    QWORD PTR [rcx+0x48],r15
  408282:	jmp    408288 <__swc_fn_3464c816_000048_ad48ec88+0x108>
  408284:	mov    QWORD PTR [rax+0x8],r15
  408288:	mov    QWORD PTR [rax+0x10],r15
  40828c:	mov    rcx,r14
  40828f:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  408294:	mov    rax,r15
  408297:	add    rsp,0x30
  40829b:	pop    r15
  40829d:	pop    r14
  40829f:	pop    r13
  4082a1:	pop    r12
  4082a3:	pop    rdi
  4082a4:	pop    rsi
  4082a5:	pop    rbx
  4082a6:	ret
  4082a7:	mov    rax,r15
  4082aa:	mov    r15,rcx
  4082ad:	test   rcx,rcx
  4082b0:	jne    408220 <__swc_fn_3464c816_000048_ad48ec88+0xa0>
  4082b6:	mov    rax,QWORD PTR [rsi+0x18]
  4082ba:	mov    r15,rax
  4082bd:	test   r15,r15
  4082c0:	je     408356 <__swc_fn_3464c816_000048_ad48ec88+0x1d6>
  4082c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4082d0:	mov    eax,DWORD PTR [rsp+0xc]
  4082d4:	cmp    DWORD PTR [r15+0x28],eax
  4082d8:	jne    408346 <__swc_fn_3464c816_000048_ad48ec88+0x1c6>
  4082da:	mov    rcx,r15
  4082dd:	mov    edx,ebx
  4082df:	mov    rax,r12
  4082e2:	mov    r8d,DWORD PTR [rax]
  4082e5:	call   40ad40 <__swc_fn_3464c816_000016_efc44797>
  4082ea:	mov    r13,rax
  4082ed:	test   rax,rax
  4082f0:	je     408346 <__swc_fn_3464c816_000048_ad48ec88+0x1c6>
  4082f2:	mov    QWORD PTR [r13+0x40],rdi
  4082f6:	movzx  eax,BYTE PTR [r13+0x39]
  4082fb:	lea    rax,[rax+rax*4]
  4082ff:	lea    rax,[rdi+rax*8+0x28]
  408304:	mov    rcx,QWORD PTR [rax+0x10]
  408308:	mov    QWORD PTR [r13+0x50],rcx
  40830c:	mov    QWORD PTR [r13+0x48],0x0
  408314:	mov    rcx,QWORD PTR [rax+0x10]
  408318:	test   rcx,rcx
  40831b:	je     408323 <__swc_fn_3464c816_000048_ad48ec88+0x1a3>
  40831d:	mov    QWORD PTR [rcx+0x48],r13
  408321:	jmp    408327 <__swc_fn_3464c816_000048_ad48ec88+0x1a7>
  408323:	mov    QWORD PTR [rax+0x8],r13
  408327:	mov    QWORD PTR [rax+0x10],r13
  40832b:	mov    rcx,r14
  40832e:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  408333:	mov    rax,r13
  408336:	add    rsp,0x30
  40833a:	pop    r15
  40833c:	pop    r14
  40833e:	pop    r13
  408340:	pop    r12
  408342:	pop    rdi
  408343:	pop    rsi
  408344:	pop    rbx
  408345:	ret
  408346:	mov    rax,QWORD PTR [r15+0x10]
  40834a:	mov    r15,rax
  40834d:	test   rax,rax
  408350:	jne    4082d0 <__swc_fn_3464c816_000048_ad48ec88+0x150>
  408356:	mov    rcx,rsi
  408359:	mov    r13,QWORD PTR [rsp+0x18]
  40835e:	mov    edx,DWORD PTR [r13+0x0]
  408362:	call   40e100 <__swc_fn_3464c816_000023_2685aade>
  408367:	mov    r13,rax
  40836a:	test   rax,rax
  40836d:	jne    408389 <__swc_fn_3464c816_000048_ad48ec88+0x209>
  40836f:	mov    rcx,r14
  408372:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  408377:	xor    eax,eax
  408379:	add    rsp,0x30
  40837d:	pop    r15
  40837f:	pop    r14
  408381:	pop    r13
  408383:	pop    r12
  408385:	pop    rdi
  408386:	pop    rsi
  408387:	pop    rbx
  408388:	ret
  408389:	mov    rcx,r13
  40838c:	mov    edx,ebx
  40838e:	mov    r8d,DWORD PTR [r12]
  408392:	call   40ad40 <__swc_fn_3464c816_000016_efc44797>
  408397:	mov    rbx,rax
  40839a:	test   rax,rax
  40839d:	jne    4083c1 <__swc_fn_3464c816_000048_ad48ec88+0x241>
  40839f:	mov    rcx,r13
  4083a2:	call   407dd0 <__swc_fn_3464c816_000024_aa910677>
  4083a7:	mov    rcx,r14
  4083aa:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  4083af:	xor    eax,eax
  4083b1:	add    rsp,0x30
  4083b5:	pop    r15
  4083b7:	pop    r14
  4083b9:	pop    r13
  4083bb:	pop    r12
  4083bd:	pop    rdi
  4083be:	pop    rsi
  4083bf:	pop    rbx
  4083c0:	ret
  4083c1:	mov    rax,QWORD PTR [rsi+0x18]
  4083c5:	mov    QWORD PTR [r13+0x10],rax
  4083c9:	mov    rax,QWORD PTR [rsi+0x18]
  4083cd:	test   rax,rax
  4083d0:	je     4083d6 <__swc_fn_3464c816_000048_ad48ec88+0x256>
  4083d2:	mov    QWORD PTR [rax+0x18],r13
  4083d6:	mov    QWORD PTR [rsi+0x18],r13
  4083da:	mov    QWORD PTR [rbx+0x40],rdi
  4083de:	movzx  eax,BYTE PTR [rbx+0x39]
  4083e2:	lea    rax,[rax+rax*4]
  4083e6:	lea    rax,[rdi+rax*8+0x28]
  4083eb:	mov    rcx,QWORD PTR [rax+0x10]
  4083ef:	mov    QWORD PTR [rbx+0x50],rcx
  4083f3:	mov    QWORD PTR [rbx+0x48],0x0
  4083fb:	mov    rcx,QWORD PTR [rax+0x10]
  4083ff:	test   rcx,rcx
  408402:	je     40840a <__swc_fn_3464c816_000048_ad48ec88+0x28a>
  408404:	mov    QWORD PTR [rcx+0x48],rbx
  408408:	jmp    40840e <__swc_fn_3464c816_000048_ad48ec88+0x28e>
  40840a:	mov    QWORD PTR [rax+0x8],rbx
  40840e:	mov    QWORD PTR [rax+0x10],rbx
  408412:	mov    rcx,r14
  408415:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40841a:	mov    rax,rbx
  40841d:	add    rsp,0x30
  408421:	pop    r15
  408423:	pop    r14
  408425:	pop    r13
  408427:	pop    r12
  408429:	pop    rdi
  40842a:	pop    rsi
  40842b:	pop    rbx
  40842c:	ret
	...

0000000000408440 <__swc_fn_3464c816_000051_d846b172>:
  408440:	push   rsi
  408441:	push   rdi
  408442:	push   r12
  408444:	mov    rsi,rdx
  408447:	mov    rdi,rcx
  40844a:	lea    rax,[rcx+0x2a80]
  408451:	mov    rcx,QWORD PTR [rax]
  408454:	test   rcx,rcx
  408457:	jne    40845e <__swc_fn_3464c816_000051_d846b172+0x1e>
  408459:	pop    r12
  40845b:	pop    rdi
  40845c:	pop    rsi
  40845d:	ret
  40845e:	xor    ecx,ecx
  408460:	xchg   QWORD PTR [rax],rcx
  408463:	mov    r12,rcx
  408466:	cs nop WORD PTR [rax+rax*1+0x0]
  408470:	cs nop WORD PTR [rax+rax*1+0x0]
  40847a:	nop    WORD PTR [rax+rax*1+0x0]
  408480:	test   r12,r12
  408483:	je     40851a <__swc_fn_3464c816_000051_d846b172+0xda>
  408489:	mov    r8,r12
  40848c:	mov    r12,QWORD PTR [r12+0x78]
  408491:	lea    rcx,[r8+0x70]
  408495:	xor    eax,eax
  408497:	xchg   DWORD PTR [r8+0x70],eax
  40849b:	cmp    QWORD PTR [r8+0x40],rsi
  40849f:	jne    4084b6 <__swc_fn_3464c816_000051_d846b172+0x76>
  4084a1:	mov    eax,DWORD PTR [r8+0x6c]
  4084a5:	test   eax,eax
  4084a7:	je     408480 <__swc_fn_3464c816_000051_d846b172+0x40>
  4084a9:	mov    rcx,rdi
  4084ac:	mov    rdx,rsi
  4084af:	call   40e4b0 <__swc_fn_3464c816_000050_e072b516>
  4084b4:	jmp    408480 <__swc_fn_3464c816_000051_d846b172+0x40>
  4084b6:	mov    rax,QWORD PTR [r8+0x40]
  4084ba:	test   rax,rax
  4084bd:	je     408480 <__swc_fn_3464c816_000051_d846b172+0x40>
  4084bf:	mov    eax,DWORD PTR [r8+0x6c]
  4084c3:	test   eax,eax
  4084c5:	je     408480 <__swc_fn_3464c816_000051_d846b172+0x40>
  4084c7:	mov    r9d,0x1
  4084cd:	xor    eax,eax
  4084cf:	lock cmpxchg DWORD PTR [rcx],r9d
  4084d4:	test   eax,eax
  4084d6:	jne    408480 <__swc_fn_3464c816_000051_d846b172+0x40>
  4084d8:	mov    rax,r8
  4084db:	and    rax,0xffffffffffc00000
  4084e2:	mov    rax,QWORD PTR [rax+0x8]
  4084e6:	test   rax,rax
  4084e9:	jne    4084f1 <__swc_fn_3464c816_000051_d846b172+0xb1>
  4084eb:	xor    eax,eax
  4084ed:	xchg   DWORD PTR [rcx],eax
  4084ef:	jmp    408480 <__swc_fn_3464c816_000051_d846b172+0x40>
  4084f1:	lea    rcx,[rax+0x2a80]
  4084f8:	mov    rax,QWORD PTR [rcx]
  4084fb:	mov    rdx,rax
  4084fe:	xchg   ax,ax
  408500:	mov    QWORD PTR [r8+0x78],rdx
  408504:	mov    rax,rdx
  408507:	lock cmpxchg QWORD PTR [rcx],r8
  40850c:	cmp    rax,rdx
  40850f:	je     408480 <__swc_fn_3464c816_000051_d846b172+0x40>
  408515:	mov    rdx,rax
  408518:	jmp    408500 <__swc_fn_3464c816_000051_d846b172+0xc0>
  40851a:	pop    r12
  40851c:	pop    rdi
  40851d:	pop    rsi
  40851e:	ret
	...

0000000000408520 <__swc_fn_3464c816_000054_2e3450f7>:
  408520:	sub    rsp,0x8
  408524:	mov    r9,r8
  408527:	movzx  eax,BYTE PTR [r9+0x39]
  40852c:	lea    rax,[rax+rax*4]
  408530:	lea    rax,[rdx+rax*8+0x28]
  408535:	cmp    QWORD PTR [rax],r9
  408538:	je     408540 <__swc_fn_3464c816_000054_2e3450f7+0x20>
  40853a:	cmp    QWORD PTR [rax+0x20],r9
  40853e:	jne    408545 <__swc_fn_3464c816_000054_2e3450f7+0x25>
  408540:	add    rsp,0x8
  408544:	ret
  408545:	cmp    QWORD PTR [rax+0x20],0x0
  40854a:	je     408557 <__swc_fn_3464c816_000054_2e3450f7+0x37>
  40854c:	mov    r8,QWORD PTR [rax+0x20]
  408550:	cmp    DWORD PTR [r8+0x28],0x0
  408555:	je     408560 <__swc_fn_3464c816_000054_2e3450f7+0x40>
  408557:	mov    QWORD PTR [rax+0x20],r9
  40855b:	add    rsp,0x8
  40855f:	ret
  408560:	mov    r8,r9
  408563:	call   40e410 <__swc_fn_3464c816_000047_137687bb>
  408568:	mov    rax,r9
  40856b:	and    rax,0xffffffffffc00000
  408572:	mov    rcx,rax
  408575:	mov    rdx,r9
  408578:	call   40df80 <__swc_fn_3464c816_000017_283e2b5e>
  40857d:	add    rsp,0x8
  408581:	ret
	...

0000000000408590 <__swc_fn_3464c816_000057_1bb23e77>:
  408590:	push   rsi
  408591:	push   rdi
  408592:	push   r12
  408594:	mov    rsi,rdx
  408597:	mov    rax,rdx
  40859a:	shr    rax,0xc
  40859e:	movabs rdx,0x9e3779b97f4a7c15
  4085a8:	imul   rax,rdx
  4085ac:	shr    rax,0x20
  4085b0:	lea    rax,[rax*8+0x0]
  4085b8:	shr    rax,0x20
  4085bc:	lea    rax,[rax*8+0x0]
  4085c4:	lea    rax,[rcx+rax*8+0x40]
  4085c9:	xor    edx,edx
  4085cb:	test   dl,dl
  4085cd:	lea    rdi,[rcx+0x8]
  4085d1:	cmove  rdi,rax
  4085d5:	xor    edx,edx
  4085d7:	test   dl,dl
  4085d9:	lea    r12,[rcx+0x30]
  4085dd:	lea    rax,[rax+0x8]
  4085e1:	cmove  r12,rax
  4085e5:	mov    rcx,rdi
  4085e8:	call   40a040 <__swc_fn_3464c816_000138_86bb0f90>
  4085ed:	mov    rax,QWORD PTR [rsi+0x30]
  4085f1:	test   rax,rax
  4085f4:	jne    408600 <__swc_fn_3464c816_000057_1bb23e77+0x70>
  4085f6:	mov    rax,QWORD PTR [rsi+0x38]
  4085fa:	mov    QWORD PTR [r12],rax
  4085fe:	jmp    408608 <__swc_fn_3464c816_000057_1bb23e77+0x78>
  408600:	mov    rcx,QWORD PTR [rsi+0x38]
  408604:	mov    QWORD PTR [rax+0x38],rcx
  408608:	mov    rax,QWORD PTR [rsi+0x38]
  40860c:	test   rax,rax
  40860f:	je     408619 <__swc_fn_3464c816_000057_1bb23e77+0x89>
  408611:	mov    rcx,QWORD PTR [rsi+0x30]
  408615:	mov    QWORD PTR [rax+0x30],rcx
  408619:	vxorps xmm0,xmm0,xmm0
  40861d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  408622:	mov    rcx,rdi
  408625:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40862a:	pop    r12
  40862c:	pop    rdi
  40862d:	pop    rsi
  40862e:	ret
	...

0000000000408630 <__swc_fn_3464c816_000060_ad030a10>:
  408630:	mov    rax,QWORD PTR [rcx+0x250]
  408637:	mov    rcx,rax
  40863a:	cmp    rax,0x1000000
  408641:	mov    eax,0x1000000
  408646:	cmovb  rcx,rax
  40864a:	mov    rax,rcx
  40864d:	cmp    rcx,0x10000000
  408654:	mov    ecx,0x10000000
  408659:	cmova  rax,rcx
  40865d:	ret
	...

0000000000408660 <__swc_fn_3464c816_000063_ffcd96eb>:
  408660:	push   rsi
  408661:	push   rdi
  408662:	push   r12
  408664:	mov    rsi,rcx
  408667:	mov    rdi,QWORD PTR [rsi+0x2a70]
  40866e:	xor    r12d,r12d
  408671:	test   rdi,rdi
  408674:	jbe    4086ab <__swc_fn_3464c816_000063_ffcd96eb+0x4b>
  408676:	cs nop WORD PTR [rax+rax*1+0x0]
  408680:	lea    rax,[r12+r12*4]
  408684:	lea    rax,[rsi+rax*8+0x268]
  40868c:	mov    rcx,rsi
  40868f:	mov    rdx,QWORD PTR [rax]
  408692:	mov    r8,QWORD PTR [rax+0x8]
  408696:	mov    rax,QWORD PTR [rax+0x10]
  40869a:	mov    r9,rax
  40869d:	call   407ef0 <__swc_fn_3464c816_000042_d3c2ab54>
  4086a2:	add    r12,0x1
  4086a6:	cmp    r12,rdi
  4086a9:	jb     408680 <__swc_fn_3464c816_000063_ffcd96eb+0x20>
  4086ab:	vxorps xmm0,xmm0,xmm0
  4086af:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  4086b7:	pop    r12
  4086b9:	pop    rdi
  4086ba:	pop    rsi
  4086bb:	ret
  4086bc:	add    BYTE PTR [rax],al
	...

00000000004086c0 <__swc_fn_3464c816_000066_8c7d044b>:
  4086c0:	push   rsi
  4086c1:	push   rdi
  4086c2:	sub    rsp,0x8
  4086c6:	mov    rsi,rcx
  4086c9:	call   40b680 <__swc_fn_3464c816_000055_df0696cd>
  4086ce:	mov    rdi,rax
  4086d1:	mov    rcx,rsi
  4086d4:	mov    rdx,rax
  4086d7:	call   408590 <__swc_fn_3464c816_000057_1bb23e77>
  4086dc:	mov    rcx,QWORD PTR [rdi+0x28]
  4086e0:	mov    rdx,QWORD PTR [rsi+0x250]
  4086e7:	nop    WORD PTR [rax+rax*1+0x0]
  4086f0:	mov    r8,rdx
  4086f3:	sub    r8,rcx
  4086f6:	mov    rax,rdx
  4086f9:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  408702:	cmp    rax,rdx
  408705:	je     40870c <__swc_fn_3464c816_000066_8c7d044b+0x4c>
  408707:	mov    rdx,rax
  40870a:	jmp    4086f0 <__swc_fn_3464c816_000066_8c7d044b+0x30>
  40870c:	mov    rcx,rsi
  40870f:	mov    rdx,QWORD PTR [rdi]
  408712:	mov    r8,QWORD PTR [rdi+0x8]
  408716:	mov    r9,QWORD PTR [rdi+0x10]
  40871a:	call   40b7a0 <__swc_fn_3464c816_000061_b304235a>
  40871f:	mov    rcx,rsi
  408722:	call   40b3e0 <__swc_fn_3464c816_000052_3af34d7f>
  408727:	add    rsp,0x8
  40872b:	pop    rdi
  40872c:	pop    rsi
  40872d:	ret
	...

0000000000408730 <__swc_fn_3464c816_000069_97813b89>:
  408730:	push   r12
  408732:	push   r13
  408734:	push   r14
  408736:	push   rdi
  408737:	push   rsi
  408738:	sub    rsp,0x1b0
  40873f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  408748:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  408751:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  40875a:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  408763:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  40876c:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  408775:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  40877e:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  408787:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  408790:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  408799:	mov    r8,rdx
  40879c:	mov    r12,rcx
  40879f:	mov    r13,QWORD PTR [r8+0x40]
  4087a3:	test   r13,r13
  4087a6:	jne    4087b8 <__swc_fn_3464c816_000069_97813b89+0x88>
  4087a8:	add    rsp,0x1b0
  4087af:	pop    rsi
  4087b0:	pop    rdi
  4087b1:	pop    r14
  4087b3:	pop    r13
  4087b5:	pop    r12
  4087b7:	ret
  4087b8:	mov    QWORD PTR [r8+0x40],0x0
  4087c0:	lea    rax,[rip+0x1b8b1]        # 424078 <__swc_bss_base_3464c816+0x38>
  4087c7:	mov    rcx,r13
  4087ca:	sub    rcx,QWORD PTR [rax+0x8]
  4087ce:	mov    rax,QWORD PTR [rip+0x1b8b3]        # 424088 <__swc_bss_base_3464c816+0x48>
  4087d5:	cmp    rcx,rax
  4087d8:	jae    408804 <__swc_fn_3464c816_000069_97813b89+0xd4>
  4087da:	mov    rax,r13
  4087dd:	and    rax,0xffffffffffc00000
  4087e4:	mov    rcx,r13
  4087e7:	shr    rcx,0x10
  4087eb:	and    ecx,0x3f
  4087ee:	mov    edx,DWORD PTR [rax+0x28]
  4087f1:	shrx   ecx,ecx,edx
  4087f6:	shl    rcx,0x4
  4087fa:	lea    r14,[rax+rcx*8+0x80]
  408802:	jmp    40881f <__swc_fn_3464c816_000069_97813b89+0xef>
  408804:	mov    rcx,r13
  408807:	mov    QWORD PTR [rsp+0xf8],r8
  40880f:	call   40b070 <__swc_fn_3464c816_000025_bcdc5519>
  408814:	mov    r8,QWORD PTR [rsp+0xf8]
  40881c:	mov    r14,rax
  40881f:	test   r14,r14
  408822:	jne    408834 <__swc_fn_3464c816_000069_97813b89+0x104>
  408824:	mov    rcx,r12
  408827:	mov    rdx,r13
  40882a:	call   4086c0 <__swc_fn_3464c816_000066_8c7d044b>
  40882f:	jmp    4088c2 <__swc_fn_3464c816_000069_97813b89+0x192>
  408834:	lea    rax,[rip+0x197cd]        # 422008 <__swc_data_base_3464c816+0x8>
  40883b:	mov    rax,QWORD PTR [rax]
  40883e:	cmp    rax,0xffffffffffffffff
  408842:	je     408851 <__swc_fn_3464c816_000069_97813b89+0x121>
  408844:	mov    eax,eax
  408846:	mov    edi,eax
  408848:	xor    eax,eax
  40884a:	call   407000 <pthread_getspecific@plt>
  40884f:	jmp    408853 <__swc_fn_3464c816_000069_97813b89+0x123>
  408851:	xor    eax,eax
  408853:	test   rax,rax
  408856:	jne    408865 <__swc_fn_3464c816_000069_97813b89+0x135>
  408858:	call   40b140 <__swc_fn_3464c816_000034_cd1a4e8c>
  40885d:	mov    rcx,rax
  408860:	call   410440 <__swc_fn_3464c816_000131_5f757033>
  408865:	test   rax,rax
  408868:	je     4088b7 <__swc_fn_3464c816_000069_97813b89+0x187>
  40886a:	cmp    QWORD PTR [r14+0x40],rax
  40886e:	jne    4088b7 <__swc_fn_3464c816_000069_97813b89+0x187>
  408870:	mov    ecx,DWORD PTR [r14+0x6c]
  408874:	test   ecx,ecx
  408876:	je     408896 <__swc_fn_3464c816_000069_97813b89+0x166>
  408878:	mov    rcx,r12
  40887b:	mov    rdx,rax
  40887e:	mov    r8,r14
  408881:	mov    QWORD PTR [rsp+0x100],rax
  408889:	call   40e4b0 <__swc_fn_3464c816_000050_e072b516>
  40888e:	mov    rax,QWORD PTR [rsp+0x100]
  408896:	mov    rcx,QWORD PTR [r14]
  408899:	mov    QWORD PTR [r13+0x0],rcx
  40889d:	mov    QWORD PTR [r14],r13
  4088a0:	sub    DWORD PTR [r14+0x28],0x1
  4088a5:	jne    4088c2 <__swc_fn_3464c816_000069_97813b89+0x192>
  4088a7:	mov    rcx,r12
  4088aa:	mov    rdx,rax
  4088ad:	mov    r8,r14
  4088b0:	call   408520 <__swc_fn_3464c816_000054_2e3450f7>
  4088b5:	jmp    4088c2 <__swc_fn_3464c816_000069_97813b89+0x192>
  4088b7:	mov    rcx,r14
  4088ba:	mov    rdx,r13
  4088bd:	call   40acb0 <__swc_fn_3464c816_000013_524c1f23>
  4088c2:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  4088cb:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  4088d4:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  4088dd:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  4088e6:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  4088ef:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  4088f8:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408901:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40890a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408913:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40891c:	add    rsp,0x1b0
  408923:	pop    rsi
  408924:	pop    rdi
  408925:	pop    r14
  408927:	pop    r13
  408929:	pop    r12
  40892b:	ret
  40892c:	add    BYTE PTR [rax],al
	...

0000000000408930 <__swc_fn_3464c816_000072_9c99bf04>:
  408930:	push   rsi
  408931:	mov    rsi,rcx
  408934:	call   407ee0 <__swc_fn_3464c816_000039_eb6108f2>
  408939:	test   al,al
  40893b:	jne    40893f <__swc_fn_3464c816_000072_9c99bf04+0xf>
  40893d:	pop    rsi
  40893e:	ret
  40893f:	lea    rax,[rip+0x1b8fa]        # 424240 <__swc_bss_base_3464c816+0x200>
  408946:	cmp    rsi,rax
  408949:	jne    40894d <__swc_fn_3464c816_000072_9c99bf04+0x1d>
  40894b:	pop    rsi
  40894c:	ret
  40894d:	mov    rcx,rsi
  408950:	call   40a040 <__swc_fn_3464c816_000138_86bb0f90>
  408955:	mov    rcx,rsi
  408958:	call   40ec80 <__swc_fn_3464c816_000071_61e60aab>
  40895d:	mov    rcx,rsi
  408960:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  408965:	pop    rsi
  408966:	ret
	...

0000000000408970 <__swc_fn_3464c816_000075_15bd096c>:
  408970:	sub    rsp,0x8
  408974:	call   40e9d0 <__swc_fn_3464c816_000068_7130736e>
  408979:	add    rsp,0x8
  40897d:	ret
	...

0000000000408980 <__swc_fn_3464c816_000078_a5fd3362>:
  408980:	push   rsi
  408981:	mov    rsi,rdx
  408984:	call   40ec80 <__swc_fn_3464c816_000071_61e60aab>
  408989:	mov    QWORD PTR [rsi+0x40],0x0
  408991:	pop    rsi
  408992:	ret
	...

00000000004089a0 <__swc_fn_3464c816_000081_63a67586>:
  4089a0:	mov    r8,rcx
  4089a3:	mov    rcx,QWORD PTR [rcx]
  4089a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4089b0:	mov    r9,rcx
  4089b3:	sub    r9,rdx
  4089b6:	mov    rax,rcx
  4089b9:	lock cmpxchg QWORD PTR [r8],r9
  4089be:	cmp    rax,rcx
  4089c1:	je     4089c8 <__swc_fn_3464c816_000081_63a67586+0x28>
  4089c3:	mov    rcx,rax
  4089c6:	jmp    4089b0 <__swc_fn_3464c816_000081_63a67586+0x10>
  4089c8:	mov    rax,rcx
  4089cb:	ret
  4089cc:	add    BYTE PTR [rax],al
	...

00000000004089d0 <__swc_fn_3464c816_000084_c618ff58>:
  4089d0:	vxorps xmm0,xmm0,xmm0
  4089d4:	vmovups XMMWORD PTR [rcx],xmm0
  4089d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4089dd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4089e2:	ret
	...

00000000004089f0 <__swc_fn_3464c816_000087_0d280354>:
  4089f0:	push   rsi
  4089f1:	push   rdi
  4089f2:	push   r12
  4089f4:	push   r13
  4089f6:	push   r15
  4089f8:	push   r14
  4089fa:	push   rbx
  4089fb:	sub    rsp,0x60
  4089ff:	mov    QWORD PTR [rsp+0x28],r11
  408a04:	mov    rsi,rcx
  408a07:	mov    rdi,rdx
  408a0a:	mov    QWORD PTR [rsp+0x30],rdx
  408a0f:	mov    r12,r8
  408a12:	mov    r13,r9
  408a15:	mov    QWORD PTR [rsp+0x38],r10
  408a1a:	xor    r8d,r8d
  408a1d:	call   408d40 <__swc_fn_3464c816_000093_63c1827b>
  408a22:	test   al,al
  408a24:	je     408a39 <__swc_fn_3464c816_000087_0d280354+0x49>
  408a26:	mov    rax,r12
  408a29:	add    rsp,0x60
  408a2d:	pop    rbx
  408a2e:	pop    r14
  408a30:	pop    r15
  408a32:	pop    r13
  408a34:	pop    r12
  408a36:	pop    rdi
  408a37:	pop    rsi
  408a38:	ret
  408a39:	rex cmp BYTE PTR [rdi+0x2c],0xe
  408a3e:	je     408a52 <__swc_fn_3464c816_000087_0d280354+0x62>
  408a40:	xor    eax,eax
  408a42:	add    rsp,0x60
  408a46:	pop    rbx
  408a47:	pop    r14
  408a49:	pop    r15
  408a4b:	pop    r13
  408a4d:	pop    r12
  408a4f:	pop    rdi
  408a50:	pop    rsi
  408a51:	ret
  408a52:	mov    r15,rdi
  408a55:	mov    QWORD PTR [rsp+0x40],rdi
  408a5a:	rex cmp BYTE PTR [rsi+0x2c],0x12
  408a5f:	jne    408acf <__swc_fn_3464c816_000087_0d280354+0xdf>
  408a61:	mov    r14,QWORD PTR [r15+0xb8]
  408a68:	mov    rax,QWORD PTR [r15+0xc0]
  408a6f:	mov    r15,rax
  408a72:	xor    edi,edi
  408a74:	test   r15,r15
  408a77:	je     408acf <__swc_fn_3464c816_000087_0d280354+0xdf>
  408a79:	nop    DWORD PTR [rax+0x0]
  408a80:	lea    rbx,[rdi*8+0x0]
  408a88:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  408a8d:	mov    rcx,rax
  408a90:	mov    rdx,rsi
  408a93:	xor    r8d,r8d
  408a96:	call   408d40 <__swc_fn_3464c816_000093_63c1827b>
  408a9b:	test   al,al
  408a9d:	je     408ac5 <__swc_fn_3464c816_000087_0d280354+0xd5>
  408a9f:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408aa4:	test   rax,rax
  408aa7:	je     408ac5 <__swc_fn_3464c816_000087_0d280354+0xd5>
  408aa9:	test   r13,r13
  408aac:	je     408ab2 <__swc_fn_3464c816_000087_0d280354+0xc2>
  408aae:	mov    QWORD PTR [r13+0x8],rax
  408ab2:	mov    rax,r12
  408ab5:	add    rsp,0x60
  408ab9:	pop    rbx
  408aba:	pop    r14
  408abc:	pop    r15
  408abe:	pop    r13
  408ac0:	pop    r12
  408ac2:	pop    rdi
  408ac3:	pop    rsi
  408ac4:	ret
  408ac5:	add    rdi,0x1
  408ac9:	sub    r15,0x1
  408acd:	jne    408a80 <__swc_fn_3464c816_000087_0d280354+0x90>
  408acf:	test   r12,r12
  408ad2:	jne    408ae6 <__swc_fn_3464c816_000087_0d280354+0xf6>
  408ad4:	xor    eax,eax
  408ad6:	add    rsp,0x60
  408ada:	pop    rbx
  408adb:	pop    r14
  408add:	pop    r15
  408adf:	pop    r13
  408ae1:	pop    r12
  408ae3:	pop    rdi
  408ae4:	pop    rsi
  408ae5:	ret
  408ae6:	mov    rbx,QWORD PTR [rsp+0x28]
  408aeb:	mov    rdi,QWORD PTR [rsp+0x30]
  408af0:	mov    rax,rbx
  408af3:	test   rax,rax
  408af6:	je     408b26 <__swc_fn_3464c816_000087_0d280354+0x136>
  408af8:	nop    DWORD PTR [rax+rax*1+0x0]
  408b00:	cmp    QWORD PTR [rax+0x8],r12
  408b04:	jne    408b1d <__swc_fn_3464c816_000087_0d280354+0x12d>
  408b06:	cmp    QWORD PTR [rax],rdi
  408b09:	jne    408b1d <__swc_fn_3464c816_000087_0d280354+0x12d>
  408b0b:	xor    eax,eax
  408b0d:	add    rsp,0x60
  408b11:	pop    rbx
  408b12:	pop    r14
  408b14:	pop    r15
  408b16:	pop    r13
  408b18:	pop    r12
  408b1a:	pop    rdi
  408b1b:	pop    rsi
  408b1c:	ret
  408b1d:	mov    rax,QWORD PTR [rax+0x10]
  408b21:	test   rax,rax
  408b24:	jne    408b00 <__swc_fn_3464c816_000087_0d280354+0x110>
  408b26:	lea    r14,[rsp+0x8]
  408b2b:	mov    QWORD PTR [rsp+0x48],r14
  408b30:	mov    QWORD PTR [rsp+0x8],rdi
  408b35:	mov    QWORD PTR [rsp+0x10],r12
  408b3a:	mov    QWORD PTR [rsp+0x18],rbx
  408b3f:	mov    r15,QWORD PTR [rsp+0x40]
  408b44:	mov    rbx,QWORD PTR [r15+0x98]
  408b4b:	mov    rax,QWORD PTR [r15+0xa0]
  408b52:	mov    rdi,rax
  408b55:	mov    r15,QWORD PTR [rsp+0x38]
  408b5a:	xor    r14d,r14d
  408b5d:	test   rdi,rdi
  408b60:	je     408c0a <__swc_fn_3464c816_000087_0d280354+0x21a>
  408b66:	cs nop WORD PTR [rax+rax*1+0x0]
  408b70:	mov    QWORD PTR [rsp+0x50],rdi
  408b75:	lea    rdi,[r14*8+0x0]
  408b7d:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  408b82:	mov    rcx,rax
  408b85:	call   40c780 <__swc_fn_3464c816_000085_3953ef98>
  408b8a:	test   DWORD PTR [rax+0x28],0x10000
  408b91:	je     408b98 <__swc_fn_3464c816_000087_0d280354+0x1a8>
  408b93:	test   r15b,r15b
  408b96:	je     408bf1 <__swc_fn_3464c816_000087_0d280354+0x201>
  408b98:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  408b9c:	lea    rdi,[r12+rcx*1]
  408ba0:	cmp    BYTE PTR [rax+0x2c],0x6
  408ba4:	jne    408bb8 <__swc_fn_3464c816_000087_0d280354+0x1c8>
  408ba6:	mov    rax,QWORD PTR [rax+0x40]
  408baa:	mov    rcx,rax
  408bad:	call   40c780 <__swc_fn_3464c816_000085_3953ef98>
  408bb2:	mov    rcx,QWORD PTR [rdi]
  408bb5:	mov    rdi,rcx
  408bb8:	test   rdi,rdi
  408bbb:	je     408bf1 <__swc_fn_3464c816_000087_0d280354+0x201>
  408bbd:	mov    rcx,rsi
  408bc0:	mov    rdx,rax
  408bc3:	mov    r8,rdi
  408bc6:	mov    r9,r13
  408bc9:	mov    al,r15b
  408bcc:	mov    r10,rax
  408bcf:	mov    rdi,QWORD PTR [rsp+0x48]
  408bd4:	mov    r11,rdi
  408bd7:	call   4089f0 <__swc_fn_3464c816_000087_0d280354>
  408bdc:	test   rax,rax
  408bdf:	je     408bf1 <__swc_fn_3464c816_000087_0d280354+0x201>
  408be1:	add    rsp,0x60
  408be5:	pop    rbx
  408be6:	pop    r14
  408be8:	pop    r15
  408bea:	pop    r13
  408bec:	pop    r12
  408bee:	pop    rdi
  408bef:	pop    rsi
  408bf0:	ret
  408bf1:	add    r14,0x1
  408bf5:	mov    rax,QWORD PTR [rsp+0x50]
  408bfa:	sub    rax,0x1
  408bfe:	mov    rdi,rax
  408c01:	test   rax,rax
  408c04:	jne    408b70 <__swc_fn_3464c816_000087_0d280354+0x180>
  408c0a:	xor    eax,eax
  408c0c:	add    rsp,0x60
  408c10:	pop    rbx
  408c11:	pop    r14
  408c13:	pop    r15
  408c15:	pop    r13
  408c17:	pop    r12
  408c19:	pop    rdi
  408c1a:	pop    rsi
  408c1b:	ret
  408c1c:	add    BYTE PTR [rax],al
	...

0000000000408c20 <__swc_fn_3464c816_000090_c1c9085b>:
  408c20:	push   rsi
  408c21:	push   rdi
  408c22:	push   r12
  408c24:	push   r13
  408c26:	push   r14
  408c28:	push   r15
  408c2a:	sub    rsp,0x78
  408c2e:	mov    rsi,r10
  408c31:	mov    QWORD PTR [rsp+0x68],r10
  408c36:	mov    rdi,rcx
  408c39:	mov    r12,rdx
  408c3c:	mov    r13,r8
  408c3f:	mov    r14,r9
  408c42:	xor    r8d,r8d
  408c45:	call   408d40 <__swc_fn_3464c816_000093_63c1827b>
  408c4a:	test   al,al
  408c4c:	je     408c75 <__swc_fn_3464c816_000090_c1c9085b+0x55>
  408c4e:	mov    rcx,r14
  408c51:	mov    rdx,r12
  408c54:	mov    r8,r13
  408c57:	mov    r9,rsi
  408c5a:	call   40f0e0 <__swc_fn_3464c816_000089_23214800>
  408c5f:	test   al,al
  408c61:	je     408c75 <__swc_fn_3464c816_000090_c1c9085b+0x55>
  408c63:	mov    rax,r13
  408c66:	add    rsp,0x78
  408c6a:	pop    r15
  408c6c:	pop    r14
  408c6e:	pop    r13
  408c70:	pop    r12
  408c72:	pop    rdi
  408c73:	pop    rsi
  408c74:	ret
  408c75:	cmp    BYTE PTR [r12+0x2c],0xe
  408c7b:	je     408c8e <__swc_fn_3464c816_000090_c1c9085b+0x6e>
  408c7d:	xor    eax,eax
  408c7f:	add    rsp,0x78
  408c83:	pop    r15
  408c85:	pop    r14
  408c87:	pop    r13
  408c89:	pop    r12
  408c8b:	pop    rdi
  408c8c:	pop    rsi
  408c8d:	ret
  408c8e:	mov    r15,QWORD PTR [r12+0x98]
  408c96:	mov    rax,QWORD PTR [r12+0xa0]
  408c9e:	mov    r12,rax
  408ca1:	xor    esi,esi
  408ca3:	test   r12,r12
  408ca6:	je     408d19 <__swc_fn_3464c816_000090_c1c9085b+0xf9>
  408ca8:	nop    DWORD PTR [rax+rax*1+0x0]
  408cb0:	mov    QWORD PTR [rsp+0x70],r12
  408cb5:	lea    r12,[rsi*8+0x0]
  408cbd:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408cc2:	mov    rcx,rax
  408cc5:	call   40c780 <__swc_fn_3464c816_000085_3953ef98>
  408cca:	cmp    BYTE PTR [rax+0x2c],0xe
  408cce:	jne    408d04 <__swc_fn_3464c816_000090_c1c9085b+0xe4>
  408cd0:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408cd5:	lea    r8,[r13+rcx*1+0x0]
  408cda:	mov    rcx,rdi
  408cdd:	mov    rdx,rax
  408ce0:	mov    r9,r14
  408ce3:	mov    r12,QWORD PTR [rsp+0x68]
  408ce8:	mov    r10,r12
  408ceb:	call   408c20 <__swc_fn_3464c816_000090_c1c9085b>
  408cf0:	test   rax,rax
  408cf3:	je     408d04 <__swc_fn_3464c816_000090_c1c9085b+0xe4>
  408cf5:	add    rsp,0x78
  408cf9:	pop    r15
  408cfb:	pop    r14
  408cfd:	pop    r13
  408cff:	pop    r12
  408d01:	pop    rdi
  408d02:	pop    rsi
  408d03:	ret
  408d04:	add    rsi,0x1
  408d08:	mov    rax,QWORD PTR [rsp+0x70]
  408d0d:	sub    rax,0x1
  408d11:	mov    r12,rax
  408d14:	test   rax,rax
  408d17:	jne    408cb0 <__swc_fn_3464c816_000090_c1c9085b+0x90>
  408d19:	xor    eax,eax
  408d1b:	add    rsp,0x78
  408d1f:	pop    r15
  408d21:	pop    r14
  408d23:	pop    r13
  408d25:	pop    r12
  408d27:	pop    rdi
  408d28:	pop    rsi
  408d29:	ret
	...

0000000000408d40 <__swc_fn_3464c816_000093_63c1827b>:
  408d40:	push   rbx
  408d41:	push   rsi
  408d42:	push   rdi
  408d43:	push   r12
  408d45:	push   r13
  408d47:	push   r14
  408d49:	push   r15
  408d4b:	sub    rsp,0x120
  408d52:	mov    rbx,r8
  408d55:	mov    rsi,rdx
  408d58:	test   rcx,rcx
  408d5b:	jne    408d7a <__swc_fn_3464c816_000093_63c1827b+0x3a>
  408d5d:	test   rsi,rsi
  408d60:	jne    408d7a <__swc_fn_3464c816_000093_63c1827b+0x3a>
  408d62:	mov    eax,0x1
  408d67:	add    rsp,0x120
  408d6e:	pop    r15
  408d70:	pop    r14
  408d72:	pop    r13
  408d74:	pop    r12
  408d76:	pop    rdi
  408d77:	pop    rsi
  408d78:	pop    rbx
  408d79:	ret
  408d7a:	test   rcx,rcx
  408d7d:	je     408d84 <__swc_fn_3464c816_000093_63c1827b+0x44>
  408d7f:	test   rsi,rsi
  408d82:	jne    408d99 <__swc_fn_3464c816_000093_63c1827b+0x59>
  408d84:	xor    eax,eax
  408d86:	add    rsp,0x120
  408d8d:	pop    r15
  408d8f:	pop    r14
  408d91:	pop    r13
  408d93:	pop    r12
  408d95:	pop    rdi
  408d96:	pop    rsi
  408d97:	pop    rbx
  408d98:	ret
  408d99:	call   40c780 <__swc_fn_3464c816_000085_3953ef98>
  408d9e:	mov    rdi,rax
  408da1:	mov    rcx,rsi
  408da4:	call   40c780 <__swc_fn_3464c816_000085_3953ef98>
  408da9:	test   bl,0x1
  408dac:	je     408dea <__swc_fn_3464c816_000093_63c1827b+0xaa>
  408dae:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408db3:	jne    408dea <__swc_fn_3464c816_000093_63c1827b+0xaa>
  408db5:	mov    ecx,DWORD PTR [rdi+0x28]
  408db8:	test   ecx,0x1000
  408dbe:	je     408dea <__swc_fn_3464c816_000093_63c1827b+0xaa>
  408dc0:	test   ecx,0x10000
  408dc6:	je     408dea <__swc_fn_3464c816_000093_63c1827b+0xaa>
  408dc8:	mov    rcx,QWORD PTR [rdi+0x40]
  408dcc:	mov    rdx,rax
  408dcf:	mov    r8d,ebx
  408dd2:	call   408d40 <__swc_fn_3464c816_000093_63c1827b>
  408dd7:	add    rsp,0x120
  408dde:	pop    r15
  408de0:	pop    r14
  408de2:	pop    r13
  408de4:	pop    r12
  408de6:	pop    rdi
  408de7:	pop    rsi
  408de8:	pop    rbx
  408de9:	ret
  408dea:	mov    cl,BYTE PTR [rax+0x2c]
  408ded:	rex cmp BYTE PTR [rdi+0x2c],cl
  408df1:	jne    408dfb <__swc_fn_3464c816_000093_63c1827b+0xbb>
  408df3:	mov    ecx,DWORD PTR [rax+0x20]
  408df6:	cmp    DWORD PTR [rdi+0x20],ecx
  408df9:	je     408e10 <__swc_fn_3464c816_000093_63c1827b+0xd0>
  408dfb:	xor    eax,eax
  408dfd:	add    rsp,0x120
  408e04:	pop    r15
  408e06:	pop    r14
  408e08:	pop    r13
  408e0a:	pop    r12
  408e0c:	pop    rdi
  408e0d:	pop    rsi
  408e0e:	pop    rbx
  408e0f:	ret
  408e10:	mov    ecx,DWORD PTR [rdi+0x28]
  408e13:	and    ecx,0xffb5ffff
  408e19:	mov    edx,DWORD PTR [rax+0x28]
  408e1c:	and    edx,0xffb5ffff
  408e22:	cmp    ecx,edx
  408e24:	je     408e3b <__swc_fn_3464c816_000093_63c1827b+0xfb>
  408e26:	xor    eax,eax
  408e28:	add    rsp,0x120
  408e2f:	pop    r15
  408e31:	pop    r14
  408e33:	pop    r13
  408e35:	pop    r12
  408e37:	pop    rdi
  408e38:	pop    rsi
  408e39:	pop    rbx
  408e3a:	ret
  408e3b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  408e40:	jne    408e95 <__swc_fn_3464c816_000093_63c1827b+0x155>
  408e42:	mov    cl,BYTE PTR [rax+0x40]
  408e45:	rex cmp BYTE PTR [rdi+0x40],cl
  408e49:	je     408e60 <__swc_fn_3464c816_000093_63c1827b+0x120>
  408e4b:	xor    eax,eax
  408e4d:	add    rsp,0x120
  408e54:	pop    r15
  408e56:	pop    r14
  408e58:	pop    r13
  408e5a:	pop    r12
  408e5c:	pop    rdi
  408e5d:	pop    rsi
  408e5e:	pop    rbx
  408e5f:	ret
  408e60:	rex cmp BYTE PTR [rdi+0x40],0xd
  408e65:	je     408e7d <__swc_fn_3464c816_000093_63c1827b+0x13d>
  408e67:	rex cmp BYTE PTR [rdi+0x40],0xf
  408e6c:	sete   cl
  408e6f:	je     408e79 <__swc_fn_3464c816_000093_63c1827b+0x139>
  408e71:	rex cmp BYTE PTR [rdi+0x40],0xe
  408e76:	sete   cl
  408e79:	test   cl,cl
  408e7b:	je     408e95 <__swc_fn_3464c816_000093_63c1827b+0x155>
  408e7d:	mov    eax,0x1
  408e82:	add    rsp,0x120
  408e89:	pop    r15
  408e8b:	pop    r14
  408e8d:	pop    r13
  408e8f:	pop    r12
  408e91:	pop    rdi
  408e92:	pop    rsi
  408e93:	pop    rbx
  408e94:	ret
  408e95:	test   DWORD PTR [rdi+0x28],0x200200
  408e9c:	je     40904f <__swc_fn_3464c816_000093_63c1827b+0x30f>
  408ea2:	mov    rsi,QWORD PTR [rdi+0x88]
  408ea9:	mov    rdi,QWORD PTR [rdi+0x90]
  408eb0:	mov    r12,QWORD PTR [rax+0x88]
  408eb7:	mov    rax,QWORD PTR [rax+0x90]
  408ebe:	cmp    rdi,rax
  408ec1:	je     408ed8 <__swc_fn_3464c816_000093_63c1827b+0x198>
  408ec3:	xor    eax,eax
  408ec5:	add    rsp,0x120
  408ecc:	pop    r15
  408ece:	pop    r14
  408ed0:	pop    r13
  408ed2:	pop    r12
  408ed4:	pop    rdi
  408ed5:	pop    rsi
  408ed6:	pop    rbx
  408ed7:	ret
  408ed8:	test   rsi,rsi
  408edb:	je     408ee2 <__swc_fn_3464c816_000093_63c1827b+0x1a2>
  408edd:	test   r12,r12
  408ee0:	jne    408efa <__swc_fn_3464c816_000093_63c1827b+0x1ba>
  408ee2:	mov    eax,0x1
  408ee7:	add    rsp,0x120
  408eee:	pop    r15
  408ef0:	pop    r14
  408ef2:	pop    r13
  408ef4:	pop    r12
  408ef6:	pop    rdi
  408ef7:	pop    rsi
  408ef8:	pop    rbx
  408ef9:	ret
  408efa:	xor    r13d,r13d
  408efd:	test   rdi,rdi
  408f00:	jbe    409037 <__swc_fn_3464c816_000093_63c1827b+0x2f7>
  408f06:	lea    r14,[rsp+0x78]
  408f0b:	lea    r15,[rsp+0xb8]
  408f13:	cs nop WORD PTR [rax+rax*1+0x0]
  408f1d:	cs nop WORD PTR [rax+rax*1+0x0]
  408f27:	nop    WORD PTR [rax+rax*1+0x0]
  408f30:	lea    rax,[r13*8+0x0]
  408f38:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  408f3d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  408f43:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  408f49:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  408f52:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  408f58:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  408f61:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  408f67:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  408f70:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  408f76:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  408f7f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  408f86:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  408f8f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  408f96:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  408f9f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408fa6:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  408faf:	xor    al,al
  408fb1:	rex test BYTE PTR [rsp+0xb0],0x1
  408fba:	je     408fc1 <__swc_fn_3464c816_000093_63c1827b+0x281>
  408fbc:	mov    eax,0x1
  408fc1:	rex test BYTE PTR [rsp+0xf0],0x1
  408fca:	je     408fd1 <__swc_fn_3464c816_000093_63c1827b+0x291>
  408fcc:	mov    eax,0x1
  408fd1:	test   al,al
  408fd3:	jne    408ff9 <__swc_fn_3464c816_000093_63c1827b+0x2b9>
  408fd5:	mov    rcx,r14
  408fd8:	mov    rdx,r15
  408fdb:	call   40a550 <__swc_fn_3464c816_000150_6fb05988>
  408fe0:	test   al,al
  408fe2:	jne    408ff9 <__swc_fn_3464c816_000093_63c1827b+0x2b9>
  408fe4:	xor    eax,eax
  408fe6:	add    rsp,0x120
  408fed:	pop    r15
  408fef:	pop    r14
  408ff1:	pop    r13
  408ff3:	pop    r12
  408ff5:	pop    rdi
  408ff6:	pop    rsi
  408ff7:	pop    rbx
  408ff8:	ret
  408ff9:	mov    rcx,QWORD PTR [rsp+0x88]
  409001:	mov    rdx,QWORD PTR [rsp+0xc8]
  409009:	mov    r8d,ebx
  40900c:	call   408d40 <__swc_fn_3464c816_000093_63c1827b>
  409011:	test   al,al
  409013:	jne    40902a <__swc_fn_3464c816_000093_63c1827b+0x2ea>
  409015:	xor    eax,eax
  409017:	add    rsp,0x120
  40901e:	pop    r15
  409020:	pop    r14
  409022:	pop    r13
  409024:	pop    r12
  409026:	pop    rdi
  409027:	pop    rsi
  409028:	pop    rbx
  409029:	ret
  40902a:	add    r13,0x1
  40902e:	cmp    r13,rdi
  409031:	jb     408f30 <__swc_fn_3464c816_000093_63c1827b+0x1f0>
  409037:	mov    eax,0x1
  40903c:	add    rsp,0x120
  409043:	pop    r15
  409045:	pop    r14
  409047:	pop    r13
  409049:	pop    r12
  40904b:	pop    rdi
  40904c:	pop    rsi
  40904d:	pop    rbx
  40904e:	ret
  40904f:	test   bl,0x2
  409052:	je     409074 <__swc_fn_3464c816_000093_63c1827b+0x334>
  409054:	lea    rcx,[rdi+0x10]
  409058:	lea    rdx,[rax+0x10]
  40905c:	call   40a550 <__swc_fn_3464c816_000150_6fb05988>
  409061:	add    rsp,0x120
  409068:	pop    r15
  40906a:	pop    r14
  40906c:	pop    r13
  40906e:	pop    r12
  409070:	pop    rdi
  409071:	pop    rsi
  409072:	pop    rbx
  409073:	ret
  409074:	mov    rcx,rdi
  409077:	mov    rdx,rax
  40907a:	call   40a550 <__swc_fn_3464c816_000150_6fb05988>
  40907f:	add    rsp,0x120
  409086:	pop    r15
  409088:	pop    r14
  40908a:	pop    r13
  40908c:	pop    r12
  40908e:	pop    rdi
  40908f:	pop    rsi
  409090:	pop    rbx
  409091:	ret
	...

00000000004090a0 <__swc_fn_3464c816_000096_4185993f>:
  4090a0:	push   rbx
  4090a1:	mov    rbx,rcx
  4090a4:	call   40c8b0 <__swc_fn_3464c816_000094_ad13d15c>
  4090a9:	movzx  r11d,al
  4090ad:	mov    r8b,r11b
  4090b0:	test   r8b,r8b
  4090b3:	jne    4090cd <__swc_fn_3464c816_000096_4185993f+0x2d>
  4090b5:	mov    r11d,0x1
  4090bb:	mov    r10,rbx
  4090be:	mov    r9,r11
  4090c1:	and    r10,r11
  4090c4:	test   r10,r10
  4090c7:	setne  dl
  4090ca:	mov    r8b,dl
  4090cd:	mov    r10b,r8b
  4090d0:	test   r10b,r10b
  4090d3:	je     4090d7 <__swc_fn_3464c816_000096_4185993f+0x37>
  4090d5:	pop    rbx
  4090d6:	ret
  4090d7:	call   4105e0 <__swc_fn_3464c816_000140_519fdf94>
  4090dc:	movzx  r10d,al
  4090e0:	test   r10b,r10b
  4090e3:	je     4090e7 <__swc_fn_3464c816_000096_4185993f+0x47>
  4090e5:	pop    rbx
  4090e6:	ret
  4090e7:	lea    r10,[rip+0xa22a]        # 413318 <__swc_rdata_base_3464c816+0x208>
  4090ee:	mov    rax,r10
  4090f1:	mov    rcx,rax
  4090f4:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  4090f9:	call   40d130 <__swc_fn_3464c816_000121_be2e2f68>
  4090fe:	pop    rbx
  4090ff:	ret

0000000000409100 <__swc_fn_3464c816_000099_d4bdcaa4>:
  409100:	push   rbx
  409101:	sub    rsp,0x70
  409105:	vxorps xmm0,xmm0,xmm0
  409109:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40910f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  409115:	vzeroupper
  409118:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40911e:	mov    QWORD PTR [rsp+0x48],rdx
  409123:	mov    rax,r8
  409126:	cmp    r8,0x1
  40912a:	mov    edx,0x1
  40912f:	cmovb  rax,rdx
  409133:	mov    QWORD PTR [rsp+0x50],rax
  409138:	mov    rbx,QWORD PTR [rcx+0x8]
  40913c:	mov    rbx,QWORD PTR [rbx+0x18]
  409140:	mov    rcx,QWORD PTR [rcx]
  409143:	lea    rdx,[rsp+0x8]
  409148:	call   rbx
  40914a:	add    rsp,0x70
  40914e:	pop    rbx
  40914f:	ret

0000000000409150 <__swc_fn_3464c816_000102_2fdd2c61>:
  409150:	push   rbx
  409151:	push   rsi
  409152:	push   rdi
  409153:	sub    rsp,0x30
  409157:	mov    rbx,rcx
  40915a:	test   rcx,rcx
  40915d:	je     409172 <__swc_fn_3464c816_000102_2fdd2c61+0x22>
  40915f:	mov    rcx,rbx
  409162:	mov    edx,0x1
  409167:	call   4089a0 <__swc_fn_3464c816_000081_63a67586>
  40916c:	cmp    rax,0x1
  409170:	je     40917a <__swc_fn_3464c816_000102_2fdd2c61+0x2a>
  409172:	add    rsp,0x30
  409176:	pop    rdi
  409177:	pop    rsi
  409178:	pop    rbx
  409179:	ret
  40917a:	lea    rsi,[rsp+0x8]
  40917f:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  409184:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40918a:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  40918f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409195:	mov    rax,QWORD PTR [rsp+0x20]
  40919a:	test   rax,rax
  40919d:	je     4091b3 <__swc_fn_3464c816_000102_2fdd2c61+0x63>
  40919f:	test   DWORD PTR [rax+0x28],0x400000
  4091a6:	je     4091b3 <__swc_fn_3464c816_000102_2fdd2c61+0x63>
  4091a8:	mov    rcx,QWORD PTR [rax+0x30]
  4091ac:	test   rcx,rcx
  4091af:	cmovne rax,rcx
  4091b3:	mov    edi,DWORD PTR [rax+0x20]
  4091b6:	lea    rcx,[rsp+0x18]
  4091bb:	call   40ca90 <__swc_fn_3464c816_000103_3c3b96fb>
  4091c0:	mov    rcx,rsi
  4091c3:	mov    rdx,QWORD PTR [rsp+0x18]
  4091c8:	mov    r8,rdi
  4091cb:	call   409100 <__swc_fn_3464c816_000099_d4bdcaa4>
  4091d0:	mov    rcx,QWORD PTR [rbx+0x28]
  4091d4:	call   40f6c0 <__swc_fn_3464c816_000101_e34f54dc>
  4091d9:	mov    rcx,rsi
  4091dc:	mov    rdx,rbx
  4091df:	mov    r8d,0x30
  4091e5:	call   409100 <__swc_fn_3464c816_000099_d4bdcaa4>
  4091ea:	add    rsp,0x30
  4091ee:	pop    rdi
  4091ef:	pop    rsi
  4091f0:	pop    rbx
  4091f1:	ret
	...

0000000000409200 <__swc_fn_3464c816_000105_ffe51047>:
  409200:	push   rbp
  409201:	push   rbx
  409202:	push   rsi
  409203:	push   rdi
  409204:	push   r12
  409206:	push   r13
  409208:	push   r14
  40920a:	push   r15
  40920c:	sub    rsp,0x500
  409213:	mov    rbp,rsp
  409216:	mov    rbx,rsp
  409219:	mov    rsi,rdx
  40921c:	mov    rdi,rcx
  40921f:	mov    rcx,QWORD PTR [rip+0x1ae1a]        # 424040 <__swc_bss_base_3464c816>
  409226:	test   rcx,rcx
  409229:	jne    409243 <__swc_fn_3464c816_000105_ffe51047+0x43>
  40922b:	sub    rsp,0x8
  40922f:	call   40a940 <__swc_fn_3464c816_000168_994c8876>
  409234:	add    rsp,0x8
  409238:	lea    rcx,[rax+0x1]
  40923c:	mov    QWORD PTR [rip+0x1adfd],rcx        # 424040 <__swc_bss_base_3464c816>
  409243:	dec    rcx
  409246:	sub    rsp,0x8
  40924a:	call   411ec0 <__swc_fn_3464c816_000170_360af05d>
  40924f:	add    rsp,0x8
  409253:	mov    r12,rax
  409256:	mov    QWORD PTR [rsp+0x4f0],rax
  40925e:	lea    rax,[rip+0xa1f3]        # 413458 <__swc_rdata_base_3464c816+0x348>
  409265:	sub    rsp,0x20
  409269:	mov    rcx,rsp
  40926c:	mov    QWORD PTR [rcx],rax
  40926f:	lea    r13,[rip+0x9eaa]        # 413120 <__swc_rdata_base_3464c816+0x10>
  409276:	mov    QWORD PTR [rcx+0x8],r13
  40927a:	mov    QWORD PTR [rcx+0x10],rsp
  40927e:	mov    QWORD PTR [rcx+0x18],0x1
  409286:	lea    rcx,[rsp+0x10]
  40928b:	sub    rsp,0x8
  40928f:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  409294:	add    rsp,0x8
  409298:	add    rsp,0x20
  40929c:	lea    rax,[rip+0xa1c5]        # 413468 <__swc_rdata_base_3464c816+0x358>
  4092a3:	sub    rsp,0x20
  4092a7:	mov    rcx,rsp
  4092aa:	mov    QWORD PTR [rcx],rax
  4092ad:	mov    QWORD PTR [rcx+0x8],r13
  4092b1:	mov    QWORD PTR [rcx+0x10],rsp
  4092b5:	mov    QWORD PTR [rcx+0x18],0x1
  4092bd:	lea    rcx,[rsp+0x10]
  4092c2:	sub    rsp,0x8
  4092c6:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  4092cb:	add    rsp,0x8
  4092cf:	add    rsp,0x20
  4092d3:	lea    r14,[rip+0x9e36]        # 413110 <__swc_rdata_base_3464c816>
  4092da:	sub    rsp,0x50
  4092de:	mov    rax,rsp
  4092e1:	vmovups xmm0,XMMWORD PTR [rip+0xa2b7]        # 4135a0 <__swc_rdata_base_3464c816+0x490>
  4092e9:	vmovups XMMWORD PTR [rax],xmm0
  4092ed:	mov    QWORD PTR [rax+0x10],rsp
  4092f1:	mov    QWORD PTR [rax+0x18],r13
  4092f5:	mov    QWORD PTR [rax+0x20],rdi
  4092f9:	lea    rdi,[rip+0xa178]        # 413478 <__swc_rdata_base_3464c816+0x368>
  409300:	mov    QWORD PTR [rax+0x28],rdi
  409304:	mov    QWORD PTR [rax+0x30],r14
  409308:	mov    QWORD PTR [rax+0x38],r13
  40930c:	lea    rcx,[rsp+0x10]
  409311:	mov    QWORD PTR [rax+0x40],rcx
  409315:	mov    QWORD PTR [rax+0x48],0x3
  40931d:	lea    rcx,[rsp+0x40]
  409322:	sub    rsp,0x8
  409326:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  40932b:	add    rsp,0x8
  40932f:	add    rsp,0x50
  409333:	lea    rax,[rip+0xa186]        # 4134c0 <__swc_rdata_base_3464c816+0x3b0>
  40933a:	sub    rsp,0x20
  40933e:	mov    rcx,rsp
  409341:	mov    QWORD PTR [rcx],rax
  409344:	mov    QWORD PTR [rcx+0x8],r13
  409348:	mov    QWORD PTR [rcx+0x10],rsp
  40934c:	mov    QWORD PTR [rcx+0x18],0x1
  409354:	lea    rcx,[rsp+0x10]
  409359:	sub    rsp,0x8
  40935d:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  409362:	add    rsp,0x8
  409366:	add    rsp,0x20
  40936a:	mov    eax,DWORD PTR [rsi+0x20]
  40936d:	mov    ecx,DWORD PTR [rsi+0x24]
  409370:	sub    rsp,0xa0
  409377:	mov    rdx,rsp
  40937a:	mov    QWORD PTR [rdx+0x30],rsi
  40937e:	mov    QWORD PTR [rdx+0x38],rdi
  409382:	vmovups xmm0,XMMWORD PTR [rip+0xa1ae]        # 413538 <__swc_rdata_base_3464c816+0x428>
  40938a:	vmovups XMMWORD PTR [rdx],xmm0
  40938e:	mov    QWORD PTR [rdx+0x40],rsp
  409392:	mov    QWORD PTR [rdx+0x48],r13
  409396:	mov    DWORD PTR [rdx+0x10],eax
  409399:	lea    rax,[rsp+0x10]
  40939e:	mov    QWORD PTR [rdx+0x50],rax
  4093a2:	lea    rax,[rip+0xa127]        # 4134d0 <__swc_rdata_base_3464c816+0x3c0>
  4093a9:	mov    QWORD PTR [rdx+0x58],rax
  4093ad:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  4093b2:	lea    r8,[rsp+0x18]
  4093b7:	mov    QWORD PTR [rdx+0x60],r8
  4093bb:	mov    QWORD PTR [rdx+0x68],r13
  4093bf:	mov    DWORD PTR [rdx+0x28],ecx
  4093c2:	lea    rcx,[rdx+0x28]
  4093c6:	mov    QWORD PTR [rdx+0x70],rcx
  4093ca:	mov    QWORD PTR [rdx+0x78],rax
  4093ce:	mov    QWORD PTR [rdx+0x80],r14
  4093d5:	mov    QWORD PTR [rdx+0x88],r13
  4093dc:	lea    rax,[rdx+0x30]
  4093e0:	mov    QWORD PTR [rdx+0x90],rax
  4093e7:	mov    QWORD PTR [rdx+0x98],0x6
  4093f2:	lea    rcx,[rdx+0x90]
  4093f9:	sub    rsp,0x8
  4093fd:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  409402:	add    rsp,0x8
  409406:	add    rsp,0xa0
  40940d:	sub    rsp,0x20
  409411:	mov    rax,rsp
  409414:	mov    QWORD PTR [rax],r14
  409417:	mov    QWORD PTR [rax+0x8],r13
  40941b:	mov    QWORD PTR [rax+0x10],rsp
  40941f:	mov    QWORD PTR [rax+0x18],0x1
  409427:	lea    rcx,[rsp+0x10]
  40942c:	sub    rsp,0x8
  409430:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  409435:	add    rsp,0x8
  409439:	add    rsp,0x20
  40943d:	mov    eax,DWORD PTR [r12+0x9ac]
  409445:	test   eax,eax
  409447:	je     409680 <__swc_fn_3464c816_000105_ffe51047+0x480>
  40944d:	lea    rax,[rip+0xa0c4]        # 413518 <__swc_rdata_base_3464c816+0x408>
  409454:	sub    rsp,0x20
  409458:	mov    rcx,rsp
  40945b:	mov    QWORD PTR [rcx],rax
  40945e:	mov    QWORD PTR [rcx+0x8],r13
  409462:	mov    QWORD PTR [rcx+0x10],rsp
  409466:	mov    QWORD PTR [rcx+0x18],0x1
  40946e:	lea    rcx,[rsp+0x10]
  409473:	sub    rsp,0x8
  409477:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  40947c:	add    rsp,0x8
  409480:	add    rsp,0x20
  409484:	mov    eax,DWORD PTR [r12+0x9ac]
  40948c:	dec    eax
  40948e:	mov    esi,eax
  409490:	test   esi,esi
  409492:	jl     409650 <__swc_fn_3464c816_000105_ffe51047+0x450>
  409498:	jmp    4094a4 <__swc_fn_3464c816_000105_ffe51047+0x2a4>
  40949a:	nop    WORD PTR [rax+rax*1+0x0]
  4094a0:	dec    esi
  4094a2:	jmp    409490 <__swc_fn_3464c816_000105_ffe51047+0x290>
  4094a4:	lea    rax,[rip+0xa07d]        # 413528 <__swc_rdata_base_3464c816+0x418>
  4094ab:	sub    rsp,0x20
  4094af:	mov    rcx,rsp
  4094b2:	mov    QWORD PTR [rcx],rax
  4094b5:	mov    QWORD PTR [rcx+0x8],r13
  4094b9:	mov    QWORD PTR [rcx+0x10],rsp
  4094bd:	mov    QWORD PTR [rcx+0x18],0x1
  4094c5:	lea    rcx,[rsp+0x10]
  4094ca:	sub    rsp,0x8
  4094ce:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  4094d3:	add    rsp,0x8
  4094d7:	add    rsp,0x20
  4094db:	movsxd rax,esi
  4094de:	imul   r15,rax,0x30
  4094e2:	add    r15,r12
  4094e5:	add    r15,0xf8
  4094ec:	sub    rsp,0x20
  4094f0:	mov    rax,rsp
  4094f3:	mov    QWORD PTR [rax],r15
  4094f6:	mov    QWORD PTR [rax+0x8],rdi
  4094fa:	mov    QWORD PTR [rax+0x10],rsp
  4094fe:	mov    QWORD PTR [rax+0x18],0x1
  409506:	lea    rcx,[rsp+0x10]
  40950b:	sub    rsp,0x8
  40950f:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  409514:	add    rsp,0x8
  409518:	add    rsp,0x20
  40951c:	mov    QWORD PTR [rsp+0x4f8],rsi
  409524:	lea    rsi,[rip+0xa00d]        # 413538 <__swc_rdata_base_3464c816+0x428>
  40952b:	sub    rsp,0x20
  40952f:	mov    rax,rsp
  409532:	mov    QWORD PTR [rax],rsi
  409535:	mov    QWORD PTR [rax+0x8],r13
  409539:	mov    QWORD PTR [rax+0x10],rsp
  40953d:	mov    QWORD PTR [rax+0x18],0x1
  409545:	lea    rcx,[rsp+0x10]
  40954a:	sub    rsp,0x8
  40954e:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  409553:	add    rsp,0x8
  409557:	add    rsp,0x20
  40955b:	sub    rsp,0x30
  40955f:	mov    rax,rsp
  409562:	mov    ecx,DWORD PTR [r15+0x20]
  409566:	mov    QWORD PTR [rax],rcx
  409569:	mov    QWORD PTR [rax+0x8],rsp
  40956d:	lea    rdi,[rip+0x9fd4]        # 413548 <__swc_rdata_base_3464c816+0x438>
  409574:	mov    QWORD PTR [rax+0x10],rdi
  409578:	lea    rcx,[rsp+0x8]
  40957d:	mov    QWORD PTR [rax+0x18],rcx
  409581:	mov    QWORD PTR [rax+0x20],0x1
  409589:	lea    rcx,[rsp+0x18]
  40958e:	sub    rsp,0x8
  409592:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  409597:	add    rsp,0x8
  40959b:	add    rsp,0x30
  40959f:	sub    rsp,0x20
  4095a3:	mov    rax,rsp
  4095a6:	mov    QWORD PTR [rax],rsi
  4095a9:	mov    QWORD PTR [rax+0x8],r13
  4095ad:	mov    QWORD PTR [rax+0x10],rsp
  4095b1:	mov    QWORD PTR [rax+0x18],0x1
  4095b9:	lea    rcx,[rsp+0x10]
  4095be:	sub    rsp,0x8
  4095c2:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  4095c7:	add    rsp,0x8
  4095cb:	add    rsp,0x20
  4095cf:	sub    rsp,0x30
  4095d3:	mov    rax,rsp
  4095d6:	mov    ecx,DWORD PTR [r15+0x24]
  4095da:	mov    QWORD PTR [rax],rcx
  4095dd:	mov    QWORD PTR [rax+0x8],rsp
  4095e1:	mov    QWORD PTR [rax+0x10],rdi
  4095e5:	lea    rcx,[rsp+0x8]
  4095ea:	mov    QWORD PTR [rax+0x18],rcx
  4095ee:	mov    QWORD PTR [rax+0x20],0x1
  4095f6:	lea    rcx,[rsp+0x18]
  4095fb:	sub    rsp,0x8
  4095ff:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  409604:	add    rsp,0x8
  409608:	add    rsp,0x30
  40960c:	sub    rsp,0x20
  409610:	mov    rax,rsp
  409613:	mov    QWORD PTR [rax],r14
  409616:	mov    QWORD PTR [rax+0x8],r13
  40961a:	mov    QWORD PTR [rax+0x10],rsp
  40961e:	mov    QWORD PTR [rax+0x18],0x1
  409626:	lea    rcx,[rsp+0x10]
  40962b:	sub    rsp,0x8
  40962f:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  409634:	add    rsp,0x8
  409638:	add    rsp,0x20
  40963c:	lea    rdi,[rip+0x9e35]        # 413478 <__swc_rdata_base_3464c816+0x368>
  409643:	mov    rsi,QWORD PTR [rsp+0x4f8]
  40964b:	jmp    4094a0 <__swc_fn_3464c816_000105_ffe51047+0x2a0>
  409650:	sub    rsp,0x20
  409654:	mov    rax,rsp
  409657:	mov    QWORD PTR [rax],r14
  40965a:	mov    QWORD PTR [rax+0x8],r13
  40965e:	mov    QWORD PTR [rax+0x10],rsp
  409662:	mov    QWORD PTR [rax+0x18],0x1
  40966a:	lea    rcx,[rsp+0x10]
  40966f:	sub    rsp,0x8
  409673:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  409678:	add    rsp,0x8
  40967c:	add    rsp,0x20
  409680:	lea    rax,[rbx+0x28]
  409684:	mov    rcx,rax
  409687:	mov    QWORD PTR [rbx+0x28],0x0
  40968f:	mov    QWORD PTR [rbx+0x30],0x0
  409697:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  40969c:	add    rcx,0x10
  4096a0:	mov    edx,0x1f
  4096a5:	cs nop WORD PTR [rax+rax*1+0x0]
  4096af:	nop
  4096b0:	vmovups XMMWORD PTR [rcx],xmm0
  4096b4:	add    rcx,0x10
  4096b8:	sub    rdx,0x1
  4096bc:	jne    4096b0 <__swc_fn_3464c816_000105_ffe51047+0x4b0>
  4096be:	lea    rsi,[rbx+0x228]
  4096c5:	xor    ecx,ecx
  4096c7:	cs nop WORD PTR [rax+rax*1+0x0]
  4096d1:	cs nop WORD PTR [rax+rax*1+0x0]
  4096db:	nop    DWORD PTR [rax+rax*1+0x0]
  4096e0:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  4096e5:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  4096ea:	add    rcx,0x10
  4096ee:	cmp    rcx,0x200
  4096f5:	jne    4096e0 <__swc_fn_3464c816_000105_ffe51047+0x4e0>
  4096f7:	mov    eax,DWORD PTR [r12+0xbc8]
  4096ff:	lea    rcx,[r12+0x9c8]
  409707:	mov    QWORD PTR [rbx+0x428],rcx
  40970e:	mov    QWORD PTR [rbx+0x430],rax
  409715:	lea    rdi,[rbx+0x438]
  40971c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  409724:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40972c:	mov    eax,DWORD PTR [r12+0xbc8]
  409734:	test   eax,eax
  409736:	jne    409783 <__swc_fn_3464c816_000105_ffe51047+0x583>
  409738:	lea    rax,[rbx+0x448]
  40973f:	mov    QWORD PTR [rbx+0x448],rsi
  409746:	mov    QWORD PTR [rax+0x8],0x40
  40974e:	mov    ecx,0x1
  409753:	mov    rdx,rax
  409756:	sub    rsp,0x8
  40975a:	call   410220 <__swc_fn_3464c816_000122_4f256d58>
  40975f:	add    rsp,0x8
  409763:	mov    QWORD PTR [rbx+0x460],rsi
  40976a:	mov    ecx,eax
  40976c:	mov    QWORD PTR [rbx+0x468],rcx
  409773:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  40977b:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  409783:	mov    rsi,QWORD PTR [rbx+0x438]
  40978a:	mov    rax,QWORD PTR [rbx+0x440]
  409791:	mov    r15,rax
  409794:	xor    r12d,r12d
  409797:	test   r15,r15
  40979a:	je     409850 <__swc_fn_3464c816_000105_ffe51047+0x650>
  4097a0:	mov    rax,QWORD PTR [rsi+r12*8]
  4097a4:	test   rax,rax
  4097a7:	je     4097c6 <__swc_fn_3464c816_000105_ffe51047+0x5c6>
  4097a9:	lea    rcx,[rbx+0x4b8]
  4097b0:	mov    rdx,rax
  4097b3:	sub    rsp,0x8
  4097b7:	call   40a6b0 <__swc_fn_3464c816_000165_cc119975>
  4097bc:	add    rsp,0x8
  4097c0:	mov    al,BYTE PTR [rax]
  4097c2:	test   al,al
  4097c4:	jne    4097d2 <__swc_fn_3464c816_000105_ffe51047+0x5d2>
  4097c6:	add    r12,0x1
  4097ca:	sub    r15,0x1
  4097ce:	jne    4097a0 <__swc_fn_3464c816_000105_ffe51047+0x5a0>
  4097d0:	jmp    409850 <__swc_fn_3464c816_000105_ffe51047+0x650>
  4097d2:	lea    rax,[rip+0x9db7]        # 413590 <__swc_rdata_base_3464c816+0x480>
  4097d9:	sub    rsp,0x20
  4097dd:	mov    rcx,rsp
  4097e0:	mov    QWORD PTR [rcx],rax
  4097e3:	mov    QWORD PTR [rcx+0x8],r13
  4097e7:	mov    QWORD PTR [rcx+0x10],rsp
  4097eb:	mov    QWORD PTR [rcx+0x18],0x1
  4097f3:	lea    rcx,[rsp+0x10]
  4097f8:	sub    rsp,0x8
  4097fc:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  409801:	add    rsp,0x8
  409805:	add    rsp,0x20
  409809:	mov    rcx,rdi
  40980c:	xor    edx,edx
  40980e:	mov    al,0x1
  409810:	mov    r8,rax
  409813:	sub    rsp,0x8
  409817:	call   40d9c0 <__swc_fn_3464c816_000166_bcc835b8>
  40981c:	add    rsp,0x8
  409820:	sub    rsp,0x20
  409824:	mov    rax,rsp
  409827:	mov    QWORD PTR [rax],r14
  40982a:	mov    QWORD PTR [rax+0x8],r13
  40982e:	mov    QWORD PTR [rax+0x10],rsp
  409832:	mov    QWORD PTR [rax+0x18],0x1
  40983a:	lea    rcx,[rsp+0x10]
  40983f:	sub    rsp,0x8
  409843:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  409848:	add    rsp,0x8
  40984c:	add    rsp,0x20
  409850:	mov    r12,QWORD PTR [rsp+0x4f0]
  409858:	mov    DWORD PTR [r12+0xbc8],0x0
  409864:	add    rsp,0x500
  40986b:	pop    r15
  40986d:	pop    r14
  40986f:	pop    r13
  409871:	pop    r12
  409873:	pop    rdi
  409874:	pop    rsi
  409875:	pop    rbx
  409876:	pop    rbp
  409877:	ret
	...

0000000000409880 <__swc_fn_3464c816_000108_7c204aac>:
  409880:	sub    rsp,0x8
  409884:	test   r8,r8
  409887:	je     40988e <__swc_fn_3464c816_000108_7c204aac+0xe>
  409889:	call   40f950 <__swc_fn_3464c816_000107_c51c3158>
  40988e:	add    rsp,0x8
  409892:	ret
	...

00000000004098a0 <__swc_fn_3464c816_000111_126150d1>:
  4098a0:	push   rsi
  4098a1:	push   rdi
  4098a2:	push   r12
  4098a4:	push   r13
  4098a6:	sub    rsp,0xd8
  4098ad:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  4098b3:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  4098b9:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  4098bf:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  4098c5:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  4098cb:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  4098d4:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  4098dd:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  4098e6:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  4098ef:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  4098f8:	xor    eax,eax
  4098fa:	call   407010 <getpid@plt>
  4098ff:	mov    rsi,rax
  409902:	lea    rdi,[rip+0x1d437]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  409909:	mov    r12,QWORD PTR [rdi]
  40990c:	test   r12,r12
  40990f:	je     40991d <__swc_fn_3464c816_000111_126150d1+0x7d>
  409911:	cmp    DWORD PTR [r12+0x10],esi
  409916:	jne    40991d <__swc_fn_3464c816_000111_126150d1+0x7d>
  409918:	mov    rax,r12
  40991b:	jmp    409980 <__swc_fn_3464c816_000111_126150d1+0xe0>
  40991d:	mov    ecx,0x4
  409922:	mov    edx,0x18
  409927:	call   40fa30 <__swc_fn_3464c816_000110_6814119b>
  40992c:	mov    rcx,rax
  40992f:	test   rax,rax
  409932:	jne    409938 <__swc_fn_3464c816_000111_126150d1+0x98>
  409934:	xor    eax,eax
  409936:	jmp    409980 <__swc_fn_3464c816_000111_126150d1+0xe0>
  409938:	mov    DWORD PTR [rcx+0x10],esi
  40993b:	mov    rax,r12
  40993e:	lock cmpxchg QWORD PTR [rdi],rcx
  409943:	mov    r13,rax
  409946:	cmp    rax,r12
  409949:	je     40995f <__swc_fn_3464c816_000111_126150d1+0xbf>
  40994b:	mov    rdi,rcx
  40994e:	mov    esi,0x18
  409953:	xor    eax,eax
  409955:	call   407020 <munmap@plt>
  40995a:	mov    rax,r13
  40995d:	jmp    409980 <__swc_fn_3464c816_000111_126150d1+0xe0>
  40995f:	test   r12,r12
  409962:	je     40997d <__swc_fn_3464c816_000111_126150d1+0xdd>
  409964:	mov    rdi,r12
  409967:	mov    esi,0x18
  40996c:	xor    eax,eax
  40996e:	mov    QWORD PTR [rsp+0x28],rcx
  409973:	call   407020 <munmap@plt>
  409978:	mov    rcx,QWORD PTR [rsp+0x28]
  40997d:	mov    rax,rcx
  409980:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  409986:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40998c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  409992:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  409998:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40999e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  4099a7:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  4099b0:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  4099b9:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  4099c2:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  4099cb:	add    rsp,0xd8
  4099d2:	pop    r13
  4099d4:	pop    r12
  4099d6:	pop    rdi
  4099d7:	pop    rsi
  4099d8:	ret
  4099d9:	add    BYTE PTR [rax],al
  4099db:	add    BYTE PTR [rax],al
  4099dd:	add    BYTE PTR [rax],al
	...

00000000004099e0 <__swc_fn_3464c816_000114_36905703>:
  4099e0:	push   rbx
  4099e1:	push   r12
  4099e3:	push   rdi
  4099e4:	push   rsi
  4099e5:	sub    rsp,0xa8
  4099ec:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4099f2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4099f8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4099fe:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409a04:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409a0a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409a10:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409a16:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409a1c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409a25:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409a2e:	mov    rbx,rdx
  409a31:	mov    r12,rcx
  409a34:	mov    rdi,rcx
  409a37:	mov    rsi,rdx
  409a3a:	mov    edx,0x3
  409a3f:	xor    eax,eax
  409a41:	call   407030 <mprotect@plt>
  409a46:	test   eax,eax
  409a48:	je     409a4e <__swc_fn_3464c816_000114_36905703+0x6e>
  409a4a:	xor    eax,eax
  409a4c:	jmp    409a63 <__swc_fn_3464c816_000114_36905703+0x83>
  409a4e:	mov    rcx,r12
  409a51:	mov    rdx,rbx
  409a54:	mov    al,0x1
  409a56:	mov    r8,rax
  409a59:	call   410060 <__swc_fn_3464c816_000113_5f48311c>
  409a5e:	mov    eax,0x1
  409a63:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409a69:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409a6f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409a75:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409a7b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409a81:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409a87:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409a8d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409a93:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409a9c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409aa5:	add    rsp,0xa8
  409aac:	pop    rsi
  409aad:	pop    rdi
  409aae:	pop    r12
  409ab0:	pop    rbx
  409ab1:	ret
	...

0000000000409ac0 <__swc_fn_3464c816_000117_5208f471>:
  409ac0:	sub    rsp,0x8
  409ac4:	test   rcx,rcx
  409ac7:	jne    409ace <__swc_fn_3464c816_000117_5208f471+0xe>
  409ac9:	add    rsp,0x8
  409acd:	ret
  409ace:	call   40cfe0 <__swc_fn_3464c816_000118_d3318640>
  409ad3:	add    rsp,0x8
  409ad7:	ret
	...

0000000000409ae0 <__swc_fn_3464c816_000120_0a5fa85a>:
  409ae0:	push   rdi
  409ae1:	push   rsi
  409ae2:	sub    rsp,0xa8
  409ae9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409aef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409af5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409afb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409b01:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409b07:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409b0d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409b13:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409b19:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409b22:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409b2b:	xor    edi,edi
  409b2d:	xor    eax,eax
  409b2f:	call   407040 <exit@plt>
  409b34:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409b3a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409b40:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409b46:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409b4c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409b52:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409b58:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409b5e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409b64:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409b6d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409b76:	add    rsp,0xa8
  409b7d:	pop    rsi
  409b7e:	pop    rdi
  409b7f:	ret

0000000000409b80 <__swc_fn_3464c816_000123_83db7238>:
  409b80:	push   rbx
  409b81:	push   rsi
  409b82:	push   rdi
  409b83:	push   r12
  409b85:	sub    rsp,0x18
  409b89:	mov    rbx,r8
  409b8c:	mov    rsi,rcx
  409b8f:	mov    rdi,rdx
  409b92:	mov    rcx,QWORD PTR [rip+0x1a4a7]        # 424040 <__swc_bss_base_3464c816>
  409b99:	test   rcx,rcx
  409b9c:	jne    409bae <__swc_fn_3464c816_000123_83db7238+0x2e>
  409b9e:	call   40a940 <__swc_fn_3464c816_000168_994c8876>
  409ba3:	lea    rcx,[rax+0x1]
  409ba7:	mov    QWORD PTR [rip+0x1a492],rcx        # 424040 <__swc_bss_base_3464c816>
  409bae:	dec    rcx
  409bb1:	call   411ec0 <__swc_fn_3464c816_000170_360af05d>
  409bb6:	mov    r12,rax
  409bb9:	cmp    ebx,0x3
  409bbc:	jne    409bcf <__swc_fn_3464c816_000123_83db7238+0x4f>
  409bbe:	mov    rax,QWORD PTR [r12+0xbd0]
  409bc6:	test   rax,rax
  409bc9:	jne    409d0c <__swc_fn_3464c816_000123_83db7238+0x18c>
  409bcf:	cmp    ebx,0x5
  409bd2:	jne    409bf6 <__swc_fn_3464c816_000123_83db7238+0x76>
  409bd4:	call   40c8b0 <__swc_fn_3464c816_000094_ad13d15c>
  409bd9:	test   al,al
  409bdb:	jne    409bf6 <__swc_fn_3464c816_000123_83db7238+0x76>
  409bdd:	mov    rcx,rsi
  409be0:	mov    rdx,rdi
  409be3:	call   411e70 <__swc_fn_3464c816_000167_3459066f>
  409be8:	test   al,al
  409bea:	je     409bf6 <__swc_fn_3464c816_000123_83db7238+0x76>
  409bec:	add    rsp,0x18
  409bf0:	pop    r12
  409bf2:	pop    rdi
  409bf3:	pop    rsi
  409bf4:	pop    rbx
  409bf5:	ret
  409bf6:	call   40c8b0 <__swc_fn_3464c816_000094_ad13d15c>
  409bfb:	test   al,al
  409bfd:	jne    409c6f <__swc_fn_3464c816_000123_83db7238+0xef>
  409bff:	vmovups xmm0,XMMWORD PTR [rsi]
  409c03:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409c09:	mov    rax,QWORD PTR [rsp+0x8]
  409c0e:	test   rax,rax
  409c11:	jne    409c62 <__swc_fn_3464c816_000123_83db7238+0xe2>
  409c13:	cmp    ebx,0x3
  409c16:	je     409c24 <__swc_fn_3464c816_000123_83db7238+0xa4>
  409c18:	cmp    ebx,0x4
  409c1b:	je     409c34 <__swc_fn_3464c816_000123_83db7238+0xb4>
  409c1d:	cmp    ebx,0x5
  409c20:	je     409c44 <__swc_fn_3464c816_000123_83db7238+0xc4>
  409c22:	jmp    409c54 <__swc_fn_3464c816_000123_83db7238+0xd4>
  409c24:	vmovups xmm0,XMMWORD PTR [rip+0x99b4]        # 4135e0 <__swc_rdata_base_3464c816+0x4d0>
  409c2c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409c32:	jmp    409c62 <__swc_fn_3464c816_000123_83db7238+0xe2>
  409c34:	vmovups xmm0,XMMWORD PTR [rip+0x99b4]        # 4135f0 <__swc_rdata_base_3464c816+0x4e0>
  409c3c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409c42:	jmp    409c62 <__swc_fn_3464c816_000123_83db7238+0xe2>
  409c44:	vmovups xmm0,XMMWORD PTR [rip+0x99b4]        # 413600 <__swc_rdata_base_3464c816+0x4f0>
  409c4c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409c52:	jmp    409c62 <__swc_fn_3464c816_000123_83db7238+0xe2>
  409c54:	vmovups xmm0,XMMWORD PTR [rip+0x99b4]        # 413610 <__swc_rdata_base_3464c816+0x500>
  409c5c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409c62:	lea    rcx,[rsp+0x8]
  409c67:	mov    rdx,rdi
  409c6a:	call   40cb00 <__swc_fn_3464c816_000106_90faaa26>
  409c6f:	vmovups xmm0,XMMWORD PTR [rdi]
  409c73:	vmovups XMMWORD PTR [r12+0x940],xmm0
  409c7d:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  409c82:	vmovups XMMWORD PTR [r12+0x950],xmm0
  409c8c:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  409c91:	vmovups XMMWORD PTR [r12+0x960],xmm0
  409c9b:	lea    rax,[r12+0x940]
  409ca3:	mov    QWORD PTR [r12+0x970],rax
  409cab:	mov    rax,QWORD PTR [rsi]
  409cae:	mov    QWORD PTR [r12+0x978],rax
  409cb6:	mov    rax,QWORD PTR [rsi+0x8]
  409cba:	mov    QWORD PTR [r12+0x980],rax
  409cc2:	movsxd rax,ebx
  409cc5:	mov    QWORD PTR [r12+0x988],rax
  409ccd:	cmp    ebx,0x5
  409cd0:	je     409cd9 <__swc_fn_3464c816_000123_83db7238+0x159>
  409cd2:	xor    ecx,ecx
  409cd4:	call   40aa70 <__swc_fn_3464c816_000177_718d7b54>
  409cd9:	mov    rbx,QWORD PTR [r12+0xbe8]
  409ce1:	test   rbx,rbx
  409ce4:	je     409cf5 <__swc_fn_3464c816_000123_83db7238+0x175>
  409ce6:	mov    rcx,r12
  409ce9:	call   rbx
  409ceb:	add    rsp,0x18
  409cef:	pop    r12
  409cf1:	pop    rdi
  409cf2:	pop    rsi
  409cf3:	pop    rbx
  409cf4:	ret
  409cf5:	mov    rcx,rsi
  409cf8:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  409cfd:	call   40d130 <__swc_fn_3464c816_000121_be2e2f68>
  409d02:	add    rsp,0x18
  409d06:	pop    r12
  409d08:	pop    rdi
  409d09:	pop    rsi
  409d0a:	pop    rbx
  409d0b:	ret
  409d0c:	mov    rcx,rsi
  409d0f:	mov    rdx,rdi
  409d12:	call   40cb00 <__swc_fn_3464c816_000106_90faaa26>
  409d17:	jmp    409bcf <__swc_fn_3464c816_000123_83db7238+0x4f>
  409d1c:	add    BYTE PTR [rax],al
	...

0000000000409d20 <__swc_fn_3464c816_000126_58f0f391>:
  409d20:	push   rdi
  409d21:	push   rsi
  409d22:	sub    rsp,0xb8
  409d29:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409d2f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409d35:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409d3b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409d41:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409d47:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409d4d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409d53:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409d5c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409d65:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409d6e:	mov    DWORD PTR [rsp+0x8],0x0
  409d76:	lea    rdi,[rsp+0x8]
  409d7b:	xor    esi,esi
  409d7d:	xor    eax,eax
  409d7f:	call   407050 <pthread_key_create@plt>
  409d84:	test   eax,eax
  409d86:	jne    409d8e <__swc_fn_3464c816_000126_58f0f391+0x6e>
  409d88:	mov    eax,DWORD PTR [rsp+0x8]
  409d8c:	jmp    409d95 <__swc_fn_3464c816_000126_58f0f391+0x75>
  409d8e:	mov    rax,0xffffffffffffffff
  409d95:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409d9b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409da1:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409da7:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409dad:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409db3:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409db9:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409dbf:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409dc8:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409dd1:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409dda:	add    rsp,0xb8
  409de1:	pop    rsi
  409de2:	pop    rdi
  409de3:	ret
	...

0000000000409df0 <__swc_fn_3464c816_000129_4a82cdf6>:
  409df0:	push   rdi
  409df1:	push   rsi
  409df2:	sub    rsp,0xb8
  409df9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409dff:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409e05:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409e0b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409e11:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409e17:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409e1d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409e23:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409e2c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409e35:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409e3e:	mov    DWORD PTR [rsp+0x8],0x0
  409e46:	lea    rdi,[rsp+0x8]
  409e4b:	mov    rsi,rcx
  409e4e:	xor    eax,eax
  409e50:	call   407050 <pthread_key_create@plt>
  409e55:	test   eax,eax
  409e57:	jne    409e62 <__swc_fn_3464c816_000129_4a82cdf6+0x72>
  409e59:	mov    eax,DWORD PTR [rsp+0x8]
  409e5d:	inc    rax
  409e60:	jmp    409e64 <__swc_fn_3464c816_000129_4a82cdf6+0x74>
  409e62:	xor    eax,eax
  409e64:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409e6a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409e70:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409e76:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409e7c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409e82:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409e88:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409e8e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409e97:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409ea0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409ea9:	add    rsp,0xb8
  409eb0:	pop    rsi
  409eb1:	pop    rdi
  409eb2:	ret
	...

0000000000409ec0 <__swc_fn_3464c816_000132_ae5891af>:
  409ec0:	push   rdi
  409ec1:	push   rsi
  409ec2:	sub    rsp,0xa8
  409ec9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409ecf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409ed5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409edb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409ee1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409ee7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409eed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409ef3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409ef9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409f02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409f0b:	test   rcx,rcx
  409f0e:	setne  al
  409f11:	je     409f2a <__swc_fn_3464c816_000132_ae5891af+0x6a>
  409f13:	lea    rax,[rcx-0x1]
  409f17:	mov    eax,eax
  409f19:	mov    edi,eax
  409f1b:	mov    rsi,rdx
  409f1e:	xor    eax,eax
  409f20:	call   407060 <pthread_setspecific@plt>
  409f25:	test   eax,eax
  409f27:	sete   al
  409f2a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409f30:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409f36:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409f3c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409f42:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409f48:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409f4e:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409f54:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409f5a:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409f63:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409f6c:	add    rsp,0xa8
  409f73:	pop    rsi
  409f74:	pop    rdi
  409f75:	ret
	...

0000000000409f80 <__swc_fn_3464c816_000135_865f5106>:
  409f80:	push   rdi
  409f81:	push   rsi
  409f82:	sub    rsp,0xa8
  409f89:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409f8f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409f95:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409f9b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409fa1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409fa7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409fad:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409fb3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409fb9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409fc2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409fcb:	mov    rax,rdx
  409fce:	mov    QWORD PTR [rsp],0x0
  409fd6:	mov    edi,0xca
  409fdb:	mov    rsi,rcx
  409fde:	mov    edx,0x81
  409fe3:	mov    eax,eax
  409fe5:	mov    ecx,eax
  409fe7:	xor    r8d,r8d
  409fea:	xor    r9d,r9d
  409fed:	xor    eax,eax
  409fef:	call   407070 <syscall@plt>
  409ff4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409ffa:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a000:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a006:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a00c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a012:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a018:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a01e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a024:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a02d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a036:	add    rsp,0xa8
  40a03d:	pop    rsi
  40a03e:	pop    rdi
  40a03f:	ret

000000000040a040 <__swc_fn_3464c816_000138_86bb0f90>:
  40a040:	sub    rsp,0x8
  40a044:	call   40d4d0 <__swc_fn_3464c816_000136_8c07c14b>
  40a049:	add    rsp,0x8
  40a04d:	ret
	...

000000000040a050 <__swc_fn_3464c816_000141_be4c2719>:
  40a050:	push   rdi
  40a051:	push   rsi
  40a052:	sub    rsp,0xc8
  40a059:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40a05f:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40a065:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40a06b:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40a071:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40a077:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40a07d:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40a086:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40a08f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40a098:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40a0a1:	vxorps xmm0,xmm0,xmm0
  40a0a5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a0ab:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a0b1:	mov    rdi,rcx
  40a0b4:	lea    rsi,[rsp+0x8]
  40a0b9:	xor    eax,eax
  40a0bb:	call   407080 <dladdr@plt>
  40a0c0:	xor    ecx,ecx
  40a0c2:	test   eax,eax
  40a0c4:	je     40a0cb <__swc_fn_3464c816_000141_be4c2719+0x7b>
  40a0c6:	mov    rcx,QWORD PTR [rsp+0x10]
  40a0cb:	mov    rax,rcx
  40a0ce:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40a0d4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40a0da:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40a0e0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40a0e6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40a0ec:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40a0f2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40a0fb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40a104:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40a10d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40a116:	add    rsp,0xc8
  40a11d:	pop    rsi
  40a11e:	pop    rdi
  40a11f:	ret

000000000040a120 <__swc_fn_3464c816_000144_1534de9a>:
  40a120:	push   rbx
  40a121:	push   r12
  40a123:	push   r13
  40a125:	push   rdi
  40a126:	push   rsi
  40a127:	push   r14
  40a129:	push   r15
  40a12b:	sub    rsp,0x150
  40a132:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40a13b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40a144:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40a14d:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40a156:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40a15f:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40a168:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40a171:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40a17a:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40a183:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40a18c:	mov    rbx,rdx
  40a18f:	mov    QWORD PTR [rsp+0x98],rdx
  40a197:	mov    r12,rcx
  40a19a:	mov    QWORD PTR [rsp+0xa0],rcx
  40a1a2:	mov    QWORD PTR [rbx],0x0
  40a1a9:	lea    r13,[rip+0x1cbc8]        # 426d78 <__swc_bss_base_3464c816+0x2d38>
  40a1b0:	mov    rcx,r13
  40a1b3:	call   40a040 <__swc_fn_3464c816_000138_86bb0f90>
  40a1b8:	mov    rax,QWORD PTR [rip+0x1cbc1]        # 426d80 <__swc_bss_base_3464c816+0x2d40>
  40a1bf:	test   rax,rax
  40a1c2:	je     40a1f9 <__swc_fn_3464c816_000144_1534de9a+0xd9>
  40a1c4:	cs nop WORD PTR [rax+rax*1+0x0]
  40a1ce:	xchg   ax,ax
  40a1d0:	cmp    QWORD PTR [rax+0x8],r12
  40a1d4:	jne    40a1f1 <__swc_fn_3464c816_000144_1534de9a+0xd1>
  40a1d6:	mov    rcx,QWORD PTR [rax+0x18]
  40a1da:	mov    QWORD PTR [rbx],rcx
  40a1dd:	mov    rbx,QWORD PTR [rax+0x10]
  40a1e1:	mov    rcx,r13
  40a1e4:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40a1e9:	mov    rax,rbx
  40a1ec:	jmp    40a3db <__swc_fn_3464c816_000144_1534de9a+0x2bb>
  40a1f1:	mov    rax,QWORD PTR [rax]
  40a1f4:	test   rax,rax
  40a1f7:	jne    40a1d0 <__swc_fn_3464c816_000144_1534de9a+0xb0>
  40a1f9:	vxorps xmm0,xmm0,xmm0
  40a1fd:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  40a203:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  40a209:	mov    rdi,r12
  40a20c:	lea    rsi,[rsp+0x10]
  40a211:	xor    eax,eax
  40a213:	call   407080 <dladdr@plt>
  40a218:	test   eax,eax
  40a21a:	sete   al
  40a21d:	je     40a22a <__swc_fn_3464c816_000144_1534de9a+0x10a>
  40a21f:	mov    rax,QWORD PTR [rsp+0x10]
  40a224:	test   rax,rax
  40a227:	sete   al
  40a22a:	test   al,al
  40a22c:	je     40a23d <__swc_fn_3464c816_000144_1534de9a+0x11d>
  40a22e:	mov    rcx,r13
  40a231:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40a236:	xor    eax,eax
  40a238:	jmp    40a3db <__swc_fn_3464c816_000144_1534de9a+0x2bb>
  40a23d:	mov    rdi,QWORD PTR [rsp+0x10]
  40a242:	mov    esi,0x80000
  40a247:	xor    eax,eax
  40a249:	call   407090 <open@plt>
  40a24e:	lea    r14,[rsp+0x30]
  40a253:	mov    DWORD PTR [rsp+0x30],eax
  40a257:	cmp    DWORD PTR [r14],0x0
  40a25b:	jge    40a26c <__swc_fn_3464c816_000144_1534de9a+0x14c>
  40a25d:	mov    rcx,r13
  40a260:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40a265:	xor    eax,eax
  40a267:	jmp    40a3db <__swc_fn_3464c816_000144_1534de9a+0x2bb>
  40a26c:	mov    rax,r14
  40a26f:	movsxd rdi,DWORD PTR [rax]
  40a272:	xor    esi,esi
  40a274:	mov    edx,0x2
  40a279:	xor    eax,eax
  40a27b:	call   4070a0 <lseek@plt>
  40a280:	mov    r15,rax
  40a283:	test   rax,rax
  40a286:	jg     40a2a1 <__swc_fn_3464c816_000144_1534de9a+0x181>
  40a288:	movsxd rdi,DWORD PTR [r14]
  40a28b:	xor    eax,eax
  40a28d:	call   4070b0 <close@plt>
  40a292:	mov    rcx,r13
  40a295:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40a29a:	xor    eax,eax
  40a29c:	jmp    40a3db <__swc_fn_3464c816_000144_1534de9a+0x2bb>
  40a2a1:	xor    edi,edi
  40a2a3:	mov    rsi,r15
  40a2a6:	mov    edx,0x1
  40a2ab:	mov    ecx,0x2
  40a2b0:	mov    rax,r14
  40a2b3:	movsxd r8,DWORD PTR [rax]
  40a2b6:	xor    r9d,r9d
  40a2b9:	xor    eax,eax
  40a2bb:	call   4070c0 <mmap@plt>
  40a2c0:	mov    rbx,rax
  40a2c3:	test   rax,rax
  40a2c6:	sete   al
  40a2c9:	cmp    rbx,0xffffffffffffffff
  40a2cd:	sete   cl
  40a2d0:	or     al,cl
  40a2d2:	je     40a2ed <__swc_fn_3464c816_000144_1534de9a+0x1cd>
  40a2d4:	movsxd rdi,DWORD PTR [r14]
  40a2d7:	xor    eax,eax
  40a2d9:	call   4070b0 <close@plt>
  40a2de:	mov    rcx,r13
  40a2e1:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40a2e6:	xor    eax,eax
  40a2e8:	jmp    40a3db <__swc_fn_3464c816_000144_1534de9a+0x2bb>
  40a2ed:	lea    rax,[rsp+0x50]
  40a2f2:	mov    QWORD PTR [rax],0x0
  40a2f9:	mov    rcx,rbx
  40a2fc:	mov    rdx,r15
  40a2ff:	mov    r8,rax
  40a302:	call   4106a0 <__swc_fn_3464c816_000143_d5d4d43f>
  40a307:	mov    r12,rax
  40a30a:	test   rax,rax
  40a30d:	jne    40a335 <__swc_fn_3464c816_000144_1534de9a+0x215>
  40a30f:	mov    rdi,rbx
  40a312:	mov    rsi,r15
  40a315:	xor    eax,eax
  40a317:	call   407020 <munmap@plt>
  40a31c:	movsxd rdi,DWORD PTR [r14]
  40a31f:	xor    eax,eax
  40a321:	call   4070b0 <close@plt>
  40a326:	mov    rcx,r13
  40a329:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40a32e:	xor    eax,eax
  40a330:	jmp    40a3db <__swc_fn_3464c816_000144_1534de9a+0x2bb>
  40a335:	mov    edi,0x20
  40a33a:	xor    eax,eax
  40a33c:	call   4070d0 <malloc@plt>
  40a341:	test   rax,rax
  40a344:	jne    40a369 <__swc_fn_3464c816_000144_1534de9a+0x249>
  40a346:	mov    rdi,rbx
  40a349:	mov    rsi,r15
  40a34c:	xor    eax,eax
  40a34e:	call   407020 <munmap@plt>
  40a353:	movsxd rdi,DWORD PTR [r14]
  40a356:	xor    eax,eax
  40a358:	call   4070b0 <close@plt>
  40a35d:	mov    rcx,r13
  40a360:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40a365:	xor    eax,eax
  40a367:	jmp    40a3db <__swc_fn_3464c816_000144_1534de9a+0x2bb>
  40a369:	mov    rcx,QWORD PTR [rip+0x1ca10]        # 426d80 <__swc_bss_base_3464c816+0x2d40>
  40a370:	mov    QWORD PTR [rsp+0x70],rcx
  40a375:	mov    rcx,QWORD PTR [rsp+0xa0]
  40a37d:	mov    QWORD PTR [rsp+0x78],rcx
  40a382:	mov    QWORD PTR [rsp+0x80],r12
  40a38a:	mov    rcx,QWORD PTR [rsp+0x50]
  40a38f:	mov    QWORD PTR [rsp+0x88],rcx
  40a397:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  40a39d:	vmovups XMMWORD PTR [rax],xmm0
  40a3a1:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  40a3aa:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40a3af:	mov    QWORD PTR [rip+0x1c9ca],rax        # 426d80 <__swc_bss_base_3464c816+0x2d40>
  40a3b6:	mov    rax,QWORD PTR [rsp+0x50]
  40a3bb:	mov    rbx,QWORD PTR [rsp+0x98]
  40a3c3:	mov    QWORD PTR [rbx],rax
  40a3c6:	movsxd rdi,DWORD PTR [r14]
  40a3c9:	xor    eax,eax
  40a3cb:	call   4070b0 <close@plt>
  40a3d0:	mov    rcx,r13
  40a3d3:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40a3d8:	mov    rax,r12
  40a3db:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40a3e4:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40a3ed:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40a3f6:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40a3ff:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40a408:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40a411:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40a41a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40a423:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40a42c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40a435:	add    rsp,0x150
  40a43c:	pop    r15
  40a43e:	pop    r14
  40a440:	pop    rsi
  40a441:	pop    rdi
  40a442:	pop    r13
  40a444:	pop    r12
  40a446:	pop    rbx
  40a447:	ret
	...

000000000040a450 <__swc_fn_3464c816_000147_43c96957>:
  40a450:	push   rbx
  40a451:	sub    rsp,0xe0
  40a458:	lea    rbx,[rsp+0x8]
  40a45d:	vxorps xmm0,xmm0,xmm0
  40a461:	vmovups YMMWORD PTR [rbx],ymm0
  40a465:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40a46a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40a46f:	vzeroupper
  40a472:	mov    DWORD PTR [rbx+0x60],0x0
  40a479:	mov    r8,rbx
  40a47c:	nop    DWORD PTR [rax+0x0]
  40a480:	mov    r9,rcx
  40a483:	movabs rcx,0xcccccccccccccccd
  40a48d:	mov    rax,r9
  40a490:	mul    rcx
  40a493:	mov    r10,rdx
  40a496:	shr    r10,0x3
  40a49a:	mov    rcx,r10
  40a49d:	imul   rdx,r10,0xa
  40a4a1:	sub    r9,rdx
  40a4a4:	mov    rdx,QWORD PTR [rip+0x9195]        # 413640 <__swc_rdata_base_3464c816+0x530>
  40a4ab:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  40a4b0:	mov    BYTE PTR [r8],dl
  40a4b3:	lea    rdx,[r8+0x1]
  40a4b7:	mov    r8,rdx
  40a4ba:	test   r10,r10
  40a4bd:	jne    40a480 <__swc_fn_3464c816_000147_43c96957+0x30>
  40a4bf:	mov    BYTE PTR [rdx],0x0
  40a4c2:	sub    r8,0x1
  40a4c6:	mov    rax,rbx
  40a4c9:	cmp    rax,r8
  40a4cc:	jae    40a4e6 <__swc_fn_3464c816_000147_43c96957+0x96>
  40a4ce:	xchg   ax,ax
  40a4d0:	mov    cl,BYTE PTR [r8]
  40a4d3:	mov    dl,BYTE PTR [rax]
  40a4d5:	mov    BYTE PTR [r8],dl
  40a4d8:	sub    r8,0x1
  40a4dc:	mov    BYTE PTR [rax],cl
  40a4de:	inc    rax
  40a4e1:	cmp    rax,r8
  40a4e4:	jb     40a4d0 <__swc_fn_3464c816_000147_43c96957+0x80>
  40a4e6:	xor    eax,eax
  40a4e8:	test   rbx,rbx
  40a4eb:	je     40a50e <__swc_fn_3464c816_000147_43c96957+0xbe>
  40a4ed:	mov    rcx,rbx
  40a4f0:	mov    dl,BYTE PTR [rcx]
  40a4f2:	test   dl,dl
  40a4f4:	je     40a50e <__swc_fn_3464c816_000147_43c96957+0xbe>
  40a4f6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a500:	add    rcx,0x1
  40a504:	add    rax,0x1
  40a508:	mov    dl,BYTE PTR [rcx]
  40a50a:	test   dl,dl
  40a50c:	jne    40a500 <__swc_fn_3464c816_000147_43c96957+0xb0>
  40a50e:	mov    QWORD PTR [rbx+0xa8],rbx
  40a515:	mov    QWORD PTR [rbx+0xb0],rax
  40a51c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40a524:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40a52c:	lea    rcx,[rbx+0xb8]
  40a533:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  40a538:	add    rsp,0xe0
  40a53f:	pop    rbx
  40a540:	ret
	...

000000000040a550 <__swc_fn_3464c816_000150_6fb05988>:
  40a550:	sub    rsp,0x8
  40a554:	mov    rax,QWORD PTR [rcx+0x8]
  40a558:	mov    r8,QWORD PTR [rdx+0x8]
  40a55c:	cmp    rax,r8
  40a55f:	je     40a568 <__swc_fn_3464c816_000150_6fb05988+0x18>
  40a561:	xor    eax,eax
  40a563:	add    rsp,0x8
  40a567:	ret
  40a568:	test   rax,rax
  40a56b:	jne    40a57c <__swc_fn_3464c816_000150_6fb05988+0x2c>
  40a56d:	test   r8,r8
  40a570:	jne    40a57c <__swc_fn_3464c816_000150_6fb05988+0x2c>
  40a572:	mov    eax,0x1
  40a577:	add    rsp,0x8
  40a57b:	ret
  40a57c:	mov    rcx,QWORD PTR [rcx]
  40a57f:	mov    rdx,QWORD PTR [rdx]
  40a582:	test   rcx,rcx
  40a585:	sete   r8b
  40a589:	test   rdx,rdx
  40a58c:	sete   r9b
  40a590:	or     r8b,r9b
  40a593:	je     40a5a0 <__swc_fn_3464c816_000150_6fb05988+0x50>
  40a595:	cmp    rcx,rdx
  40a598:	sete   al
  40a59b:	add    rsp,0x8
  40a59f:	ret
  40a5a0:	cmp    rcx,rdx
  40a5a3:	jne    40a5af <__swc_fn_3464c816_000150_6fb05988+0x5f>
  40a5a5:	mov    eax,0x1
  40a5aa:	add    rsp,0x8
  40a5ae:	ret
  40a5af:	mov    r8,rax
  40a5b2:	call   40cbc0 <__swc_fn_3464c816_000109_3dc01326>
  40a5b7:	test   eax,eax
  40a5b9:	sete   al
  40a5bc:	add    rsp,0x8
  40a5c0:	ret
	...

000000000040a5d0 <__swc_fn_3464c816_000153_86f1d437>:
  40a5d0:	vxorps xmm0,xmm0,xmm0
  40a5d4:	vmovups XMMWORD PTR [rcx],xmm0
  40a5d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a5dd:	vxorps xmm0,xmm0,xmm0
  40a5e1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a5e6:	vmovups xmm0,XMMWORD PTR [rip+0x910a]        # 4136f8 <__swc_rdata_base_3464c816+0x5e8>
  40a5ee:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a5f3:	ret
	...

000000000040a600 <__swc_fn_3464c816_000156_86f1d437>:
  40a600:	vxorps xmm0,xmm0,xmm0
  40a604:	vmovups XMMWORD PTR [rcx],xmm0
  40a608:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a60d:	vxorps xmm0,xmm0,xmm0
  40a611:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a616:	vmovups xmm0,XMMWORD PTR [rip+0x91fa]        # 413818 <__swc_rdata_base_3464c816+0x708>
  40a61e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a623:	mov    QWORD PTR [rcx+0x40],0x0
  40a62b:	ret
  40a62c:	add    BYTE PTR [rax],al
	...

000000000040a630 <__swc_fn_3464c816_000159_47b270e1>:
  40a630:	push   rbx
  40a631:	sub    rsp,0x70
  40a635:	mov    rax,QWORD PTR [rcx]
  40a638:	mov    rbx,QWORD PTR [rcx+0x8]
  40a63c:	vxorps xmm0,xmm0,xmm0
  40a640:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40a646:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40a64c:	vzeroupper
  40a64f:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40a655:	mov    QWORD PTR [rsp+0x48],rdx
  40a65a:	mov    QWORD PTR [rsp+0x50],r8
  40a65f:	mov    rcx,rax
  40a662:	lea    rdx,[rsp+0x8]
  40a667:	mov    rbx,QWORD PTR [rbx+0x18]
  40a66b:	call   rbx
  40a66d:	add    rsp,0x70
  40a671:	pop    rbx
  40a672:	ret
	...

000000000040a680 <__swc_fn_3464c816_000162_8a3d304f>:
  40a680:	push   rbx
  40a681:	push   rsi
  40a682:	push   rdi
  40a683:	mov    rbx,r8
  40a686:	mov    rsi,rcx
  40a689:	mov    rdi,rdx
  40a68c:	call   40d8d0 <__swc_fn_3464c816_000160_13ead2ff>
  40a691:	vmovups xmm0,XMMWORD PTR [rbx]
  40a695:	vmovups XMMWORD PTR [rsi],xmm0
  40a699:	mov    QWORD PTR [rsi+0x18],rdi
  40a69d:	pop    rdi
  40a69e:	pop    rsi
  40a69f:	pop    rbx
  40a6a0:	ret
	...

000000000040a6b0 <__swc_fn_3464c816_000165_cc119975>:
  40a6b0:	push   rbx
  40a6b1:	push   rsi
  40a6b2:	push   rdi
  40a6b3:	push   r12
  40a6b5:	push   r13
  40a6b7:	sub    rsp,0x50
  40a6bb:	mov    rbx,rcx
  40a6be:	mov    rsi,rdx
  40a6c1:	vmovups xmm0,XMMWORD PTR [rip+0x925f]        # 413928 <__swc_rdata_base_3464c816+0x818>
  40a6c9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a6cf:	vmovups xmm0,XMMWORD PTR [rip+0x9261]        # 413938 <__swc_rdata_base_3464c816+0x828>
  40a6d7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a6dd:	vxorps xmm0,xmm0,xmm0
  40a6e1:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a6e7:	mov    rcx,rdx
  40a6ea:	call   40a050 <__swc_fn_3464c816_000141_be4c2719>
  40a6ef:	mov    rdi,rax
  40a6f2:	test   rax,rax
  40a6f5:	jne    40a726 <__swc_fn_3464c816_000165_cc119975+0x76>
  40a6f7:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a6fd:	vmovups XMMWORD PTR [rbx],xmm0
  40a701:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a707:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a70c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a712:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a717:	mov    rax,rbx
  40a71a:	add    rsp,0x50
  40a71e:	pop    r13
  40a720:	pop    r12
  40a722:	pop    rdi
  40a723:	pop    rsi
  40a724:	pop    rbx
  40a725:	ret
  40a726:	mov    rcx,rdi
  40a729:	call   411bc0 <__swc_fn_3464c816_000164_016ee66a>
  40a72e:	mov    r11,rax
  40a731:	test   rax,rax
  40a734:	je     40a73e <__swc_fn_3464c816_000165_cc119975+0x8e>
  40a736:	mov    al,BYTE PTR [r11+0x24]
  40a73a:	test   al,al
  40a73c:	jne    40a76d <__swc_fn_3464c816_000165_cc119975+0xbd>
  40a73e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a744:	vmovups XMMWORD PTR [rbx],xmm0
  40a748:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a74e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a753:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a759:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a75e:	mov    rax,rbx
  40a761:	add    rsp,0x50
  40a765:	pop    r13
  40a767:	pop    r12
  40a769:	pop    rdi
  40a76a:	pop    rsi
  40a76b:	pop    rbx
  40a76c:	ret
  40a76d:	sub    rsi,rdi
  40a770:	mov    eax,0xffffffff
  40a775:	cmp    rsi,rax
  40a778:	jbe    40a7a9 <__swc_fn_3464c816_000165_cc119975+0xf9>
  40a77a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a780:	vmovups XMMWORD PTR [rbx],xmm0
  40a784:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a78a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a78f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a795:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a79a:	mov    rax,rbx
  40a79d:	add    rsp,0x50
  40a7a1:	pop    r13
  40a7a3:	pop    r12
  40a7a5:	pop    rdi
  40a7a6:	pop    rsi
  40a7a7:	pop    rbx
  40a7a8:	ret
  40a7a9:	mov    rdi,QWORD PTR [r11+0x10]
  40a7ad:	mov    eax,DWORD PTR [r11+0x20]
  40a7b1:	xor    ecx,ecx
  40a7b3:	test   rax,rax
  40a7b6:	jbe    40a908 <__swc_fn_3464c816_000165_cc119975+0x258>
  40a7bc:	nop    DWORD PTR [rax+0x0]
  40a7c0:	mov    edx,ecx
  40a7c2:	imul   r12,rdx,0x14
  40a7c6:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a7cb:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a7d0:	mov    r9d,esi
  40a7d3:	cmp    r9,rdx
  40a7d6:	jb     40a8fb <__swc_fn_3464c816_000165_cc119975+0x24b>
  40a7dc:	add    rdx,r8
  40a7df:	mov    r8d,esi
  40a7e2:	cmp    r8,rdx
  40a7e5:	jae    40a8fb <__swc_fn_3464c816_000165_cc119975+0x24b>
  40a7eb:	lea    rsi,[rsp+0x38]
  40a7f0:	mov    eax,DWORD PTR [rdi+0xc]
  40a7f3:	mov    DWORD PTR [rsp+0x38],eax
  40a7f7:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a7fc:	mov    rcx,rdi
  40a7ff:	mov    rdx,QWORD PTR [r11+0x18]
  40a803:	mov    r8,rsi
  40a806:	mov    r8d,DWORD PTR [r8]
  40a809:	mov    r9,rax
  40a80c:	lea    r10,[rsp+0x10]
  40a811:	call   40d920 <__swc_fn_3464c816_000163_72795826>
  40a816:	test   al,al
  40a818:	jne    40a84b <__swc_fn_3464c816_000165_cc119975+0x19b>
  40a81a:	vmovups xmm0,XMMWORD PTR [rip+0x9136]        # 413958 <__swc_rdata_base_3464c816+0x848>
  40a822:	vmovups XMMWORD PTR [rbx],xmm0
  40a826:	vmovups xmm0,XMMWORD PTR [rip+0x913a]        # 413968 <__swc_rdata_base_3464c816+0x858>
  40a82e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a833:	vxorps xmm0,xmm0,xmm0
  40a837:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a83c:	mov    rax,rbx
  40a83f:	add    rsp,0x50
  40a843:	pop    r13
  40a845:	pop    r12
  40a847:	pop    rdi
  40a848:	pop    rsi
  40a849:	pop    rbx
  40a84a:	ret
  40a84b:	lea    r13,[rsp+0x3c]
  40a850:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a855:	mov    DWORD PTR [rsp+0x3c],eax
  40a859:	test   eax,eax
  40a85b:	je     40a8ac <__swc_fn_3464c816_000165_cc119975+0x1fc>
  40a85d:	mov    rcx,rdi
  40a860:	mov    rdx,QWORD PTR [r11+0x18]
  40a864:	mov    r8d,DWORD PTR [rsi]
  40a867:	mov    rax,r13
  40a86a:	mov    r9d,DWORD PTR [rax]
  40a86d:	lea    r10,[rsp+0x20]
  40a872:	call   40d920 <__swc_fn_3464c816_000163_72795826>
  40a877:	test   al,al
  40a879:	jne    40a8ac <__swc_fn_3464c816_000165_cc119975+0x1fc>
  40a87b:	vmovups xmm0,XMMWORD PTR [rip+0x9105]        # 413988 <__swc_rdata_base_3464c816+0x878>
  40a883:	vmovups XMMWORD PTR [rbx],xmm0
  40a887:	vmovups xmm0,XMMWORD PTR [rip+0x9109]        # 413998 <__swc_rdata_base_3464c816+0x888>
  40a88f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a894:	vxorps xmm0,xmm0,xmm0
  40a898:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a89d:	mov    rax,rbx
  40a8a0:	add    rsp,0x50
  40a8a4:	pop    r13
  40a8a6:	pop    r12
  40a8a8:	pop    rdi
  40a8a9:	pop    rsi
  40a8aa:	pop    rbx
  40a8ab:	ret
  40a8ac:	mov    eax,0x1
  40a8b1:	rex mov BYTE PTR [rsp+0x8],al
  40a8b6:	cmp    DWORD PTR [r13+0x0],0x0
  40a8bb:	je     40a8cc <__swc_fn_3464c816_000165_cc119975+0x21c>
  40a8bd:	rex mov BYTE PTR [rsp+0x9],0x1
  40a8c3:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a8c8:	mov    DWORD PTR [rsp+0x30],eax
  40a8cc:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a8d2:	vmovups XMMWORD PTR [rbx],xmm0
  40a8d6:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a8dc:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a8e1:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a8e7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a8ec:	mov    rax,rbx
  40a8ef:	add    rsp,0x50
  40a8f3:	pop    r13
  40a8f5:	pop    r12
  40a8f7:	pop    rdi
  40a8f8:	pop    rsi
  40a8f9:	pop    rbx
  40a8fa:	ret
  40a8fb:	add    rcx,0x1
  40a8ff:	cmp    rcx,rax
  40a902:	jb     40a7c0 <__swc_fn_3464c816_000165_cc119975+0x110>
  40a908:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a90e:	vmovups XMMWORD PTR [rbx],xmm0
  40a912:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a918:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a91d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a923:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a928:	mov    rax,rbx
  40a92b:	add    rsp,0x50
  40a92f:	pop    r13
  40a931:	pop    r12
  40a933:	pop    rdi
  40a934:	pop    rsi
  40a935:	pop    rbx
  40a936:	ret
	...

000000000040a940 <__swc_fn_3464c816_000168_994c8876>:
  40a940:	sub    rsp,0x48
  40a944:	call   409d20 <__swc_fn_3464c816_000126_58f0f391>
  40a949:	cmp    rax,0xffffffffffffffff
  40a94d:	je     40a954 <__swc_fn_3464c816_000168_994c8876+0x14>
  40a94f:	add    rsp,0x48
  40a953:	ret
  40a954:	lea    rcx,[rip+0x906d]        # 4139c8 <__swc_rdata_base_3464c816+0x8b8>
  40a95b:	vmovups xmm0,XMMWORD PTR [rip+0x9075]        # 4139d8 <__swc_rdata_base_3464c816+0x8c8>
  40a963:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a969:	vmovups xmm0,XMMWORD PTR [rip+0x9077]        # 4139e8 <__swc_rdata_base_3464c816+0x8d8>
  40a971:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a977:	vmovups xmm0,XMMWORD PTR [rip+0x9079]        # 4139f8 <__swc_rdata_base_3464c816+0x8e8>
  40a97f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a985:	lea    rdx,[rsp+0x8]
  40a98a:	mov    QWORD PTR [rsp+0x38],rax
  40a98f:	call   40cb00 <__swc_fn_3464c816_000106_90faaa26>
  40a994:	mov    rax,QWORD PTR [rsp+0x38]
  40a999:	jmp    40a94f <__swc_fn_3464c816_000168_994c8876+0xf>
  40a99b:	add    BYTE PTR [rax],al
  40a99d:	add    BYTE PTR [rax],al
	...

000000000040a9a0 <__swc_fn_3464c816_000171_cbeff767>:
  40a9a0:	push   rbx
  40a9a1:	push   rsi
  40a9a2:	sub    rsp,0x28
  40a9a6:	mov    rbx,rcx
  40a9a9:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a9b1:	mov    ecx,0xbf0
  40a9b6:	call   40c6f0 <__swc_fn_3464c816_000082_4a10c7e7>
  40a9bb:	mov    rsi,rax
  40a9be:	test   rax,rax
  40a9c1:	jne    40a9cc <__swc_fn_3464c816_000171_cbeff767+0x2c>
  40a9c3:	xor    eax,eax
  40a9c5:	add    rsp,0x28
  40a9c9:	pop    rsi
  40a9ca:	pop    rbx
  40a9cb:	ret
  40a9cc:	vxorps xmm0,xmm0,xmm0
  40a9d0:	xor    eax,eax
  40a9d2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9dc:	nop    DWORD PTR [rax+0x0]
  40a9e0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a9e5:	add    rax,0x10
  40a9e9:	cmp    rax,0xbf0
  40a9f0:	jne    40a9e0 <__swc_fn_3464c816_000171_cbeff767+0x40>
  40a9f2:	lea    rax,[rbx+0x1]
  40a9f6:	mov    QWORD PTR [rsi+0x9c0],rax
  40a9fd:	mov    rcx,rbx
  40aa00:	mov    rdx,rsi
  40aa03:	call   40dc80 <__swc_fn_3464c816_000169_646fdf20>
  40aa08:	test   al,al
  40aa0a:	jne    40aa1d <__swc_fn_3464c816_000171_cbeff767+0x7d>
  40aa0c:	mov    rcx,rsi
  40aa0f:	call   40f090 <__swc_fn_3464c816_000083_cf82995a>
  40aa14:	xor    eax,eax
  40aa16:	add    rsp,0x28
  40aa1a:	pop    rsi
  40aa1b:	pop    rbx
  40aa1c:	ret
  40aa1d:	lea    rcx,[rsp+0x18]
  40aa22:	call   40f610 <__swc_fn_3464c816_000095_93bfe675>
  40aa27:	mov    rax,rsi
  40aa2a:	add    rsp,0x28
  40aa2e:	pop    rsi
  40aa2f:	pop    rbx
  40aa30:	ret
	...

000000000040aa40 <__swc_fn_3464c816_000174_e09f8b62>:
  40aa40:	xor    eax,eax
  40aa42:	mov    edx,0x1
  40aa47:	lock cmpxchg QWORD PTR [rcx],rdx
  40aa4c:	test   rax,rax
  40aa4f:	jne    40aa52 <__swc_fn_3464c816_000174_e09f8b62+0x12>
  40aa51:	ret
  40aa52:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa5c:	nop    DWORD PTR [rax+0x0]
  40aa60:	mov    rax,QWORD PTR [rcx]
  40aa63:	test   rax,rax
  40aa66:	je     40aa40 <__swc_fn_3464c816_000174_e09f8b62>
  40aa68:	jmp    40aa60 <__swc_fn_3464c816_000174_e09f8b62+0x20>
  40aa6a:	add    BYTE PTR [rax],al
  40aa6c:	add    BYTE PTR [rax],al
	...

000000000040aa70 <__swc_fn_3464c816_000177_718d7b54>:
  40aa70:	push   rsi
  40aa71:	push   rdi
  40aa72:	sub    rsp,0x38
  40aa76:	mov    rsi,rcx
  40aa79:	call   40dc90 <__swc_fn_3464c816_000172_1e0ea8cf>
  40aa7e:	mov    rdi,rax
  40aa81:	call   40d420 <__swc_fn_3464c816_000133_a9c1c700>
  40aa86:	mov    r8,rax
  40aa89:	mov    rcx,rdi
  40aa8c:	call   40aa40 <__swc_fn_3464c816_000174_e09f8b62>
  40aa91:	mov    rax,QWORD PTR [rdi+0x8]
  40aa95:	test   rax,rax
  40aa98:	je     40aad5 <__swc_fn_3464c816_000177_718d7b54+0x65>
  40aa9a:	nop    WORD PTR [rax+rax*1+0x0]
  40aaa0:	cmp    rax,rsi
  40aaa3:	je     40aad5 <__swc_fn_3464c816_000177_718d7b54+0x65>
  40aaa5:	mov    r9,QWORD PTR [rax]
  40aaa8:	cmp    QWORD PTR [rax+0x20],r8
  40aaac:	jne    40aacd <__swc_fn_3464c816_000177_718d7b54+0x5d>
  40aaae:	mov    rcx,rdi
  40aab1:	mov    rdx,rax
  40aab4:	mov    QWORD PTR [rsp+0x28],r8
  40aab9:	mov    QWORD PTR [rsp+0x30],r9
  40aabe:	call   411fe0 <__swc_fn_3464c816_000176_cf4ffedd>
  40aac3:	mov    r8,QWORD PTR [rsp+0x28]
  40aac8:	mov    r9,QWORD PTR [rsp+0x30]
  40aacd:	mov    rax,r9
  40aad0:	test   r9,r9
  40aad3:	jne    40aaa0 <__swc_fn_3464c816_000177_718d7b54+0x30>
  40aad5:	xor    eax,eax
  40aad7:	mov    QWORD PTR [rdi],rax
  40aada:	add    rsp,0x38
  40aade:	pop    rdi
  40aadf:	pop    rsi
  40aae0:	ret
	...

000000000040ab00 <__swc_fn_3464c816_000001_2744b483>:
  40ab00:	push   rbx
  40ab01:	sub    rsp,0x70
  40ab05:	cmp    rcx,0xffffffffffffffef
  40ab09:	jbe    40ab13 <__swc_fn_3464c816_000001_2744b483+0x13>
  40ab0b:	xor    eax,eax
  40ab0d:	add    rsp,0x70
  40ab11:	pop    rbx
  40ab12:	ret
  40ab13:	vxorps xmm0,xmm0,xmm0
  40ab17:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40ab1d:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40ab23:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40ab29:	vzeroupper
  40ab2c:	lea    rax,[rcx+0x10]
  40ab30:	mov    QWORD PTR [rsp+0x50],rax
  40ab35:	mov    DWORD PTR [rsp+0x60],0x10
  40ab3d:	mov    rcx,QWORD PTR [rip+0x194fc]        # 424040 <__swc_bss_base_3464c816>
  40ab44:	test   rcx,rcx
  40ab47:	jne    40ab59 <__swc_fn_3464c816_000001_2744b483+0x59>
  40ab49:	call   40a940 <__swc_fn_3464c816_000168_994c8876>
  40ab4e:	lea    rcx,[rax+0x1]
  40ab52:	mov    QWORD PTR [rip+0x194e7],rcx        # 424040 <__swc_bss_base_3464c816>
  40ab59:	dec    rcx
  40ab5c:	call   411ec0 <__swc_fn_3464c816_000170_360af05d>
  40ab61:	mov    rcx,QWORD PTR [rax]
  40ab64:	lea    rdx,[rsp+0x8]
  40ab69:	mov    rbx,QWORD PTR [rax+0x8]
  40ab6d:	mov    rbx,QWORD PTR [rbx+0x8]
  40ab71:	call   rbx
  40ab73:	mov    rax,QWORD PTR [rsp+0x48]
  40ab78:	test   rax,rax
  40ab7b:	jne    40ab85 <__swc_fn_3464c816_000001_2744b483+0x85>
  40ab7d:	xor    eax,eax
  40ab7f:	add    rsp,0x70
  40ab83:	pop    rbx
  40ab84:	ret
  40ab85:	mov    rcx,QWORD PTR [rsp+0x50]
  40ab8a:	mov    QWORD PTR [rax],rcx
  40ab8d:	mov    QWORD PTR [rax+0x8],0x0
  40ab95:	lea    rax,[rax+0x10]
  40ab99:	add    rsp,0x70
  40ab9d:	pop    rbx
  40ab9e:	ret
	...

000000000040aba0 <__swc_fn_3464c816_000004_9ee35b18>:
  40aba0:	vxorps xmm0,xmm0,xmm0
  40aba4:	xor    eax,eax
  40aba6:	cs nop WORD PTR [rax+rax*1+0x0]
  40abb0:	cs nop WORD PTR [rax+rax*1+0x0]
  40abba:	nop    WORD PTR [rax+rax*1+0x0]
  40abc0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40abc5:	add    rax,0x10
  40abc9:	cmp    rax,0x2080
  40abd0:	jne    40abc0 <__swc_fn_3464c816_000004_9ee35b18+0x20>
  40abd2:	ret
	...

000000000040abe0 <__swc_fn_3464c816_000007_d64b2baa>:
  40abe0:	push   rsi
  40abe1:	push   rdi
  40abe2:	push   r12
  40abe4:	push   r13
  40abe6:	push   r14
  40abe8:	mov    rsi,rcx
  40abeb:	mov    edi,r10d
  40abee:	mov    r12,rcx
  40abf1:	mov    r13,r9
  40abf4:	mov    ecx,DWORD PTR [rdx+0x28]
  40abf7:	shlx   r14d,r8d,ecx
  40abfc:	mov    rcx,rdx
  40abff:	mov    edx,r8d
  40ac02:	call   40df60 <__swc_fn_3464c816_000014_9dea5065>
  40ac07:	mov    rcx,rax
  40ac0a:	mov    eax,DWORD PTR [r12+0x3c]
  40ac0f:	xor    edx,edx
  40ac11:	div    rdi
  40ac14:	vxorps xmm0,xmm0,xmm0
  40ac18:	vmovdqu XMMWORD PTR [rsi],xmm0
  40ac1c:	mov    QWORD PTR [r12+0x60],0x0
  40ac25:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40ac2a:	mov    QWORD PTR [r12+0x10],rcx
  40ac2f:	imul   rax,rdi
  40ac33:	lea    rdx,[rcx+rax*1]
  40ac37:	mov    QWORD PTR [r12+0x18],rdx
  40ac3c:	mov    QWORD PTR [r12+0x20],rcx
  40ac41:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40ac46:	mov    DWORD PTR [r12+0x28],0x0
  40ac4f:	mov    DWORD PTR [r12+0x68],0x0
  40ac58:	mov    BYTE PTR [r12+0x39],r13b
  40ac5d:	mov    BYTE PTR [r12+0x3a],r14b
  40ac62:	mov    BYTE PTR [r12+0x3b],0x1
  40ac68:	mov    DWORD PTR [r12+0x6c],0x0
  40ac71:	mov    rcx,r12
  40ac74:	mov    edx,edi
  40ac76:	call   40dec0 <__swc_fn_3464c816_000008_065ed5b1>
  40ac7b:	pop    r14
  40ac7d:	pop    r13
  40ac7f:	pop    r12
  40ac81:	pop    rdi
  40ac82:	pop    rsi
  40ac83:	ret
	...

000000000040ac90 <__swc_fn_3464c816_000010_c3647f66>:
  40ac90:	mov    r8d,0x1
  40ac96:	xor    eax,eax
  40ac98:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40ac9e:	test   eax,eax
  40aca0:	jne    40ac90 <__swc_fn_3464c816_000010_c3647f66>
  40aca2:	ret
	...

000000000040acb0 <__swc_fn_3464c816_000013_524c1f23>:
  40acb0:	lea    r8,[rcx+0x60]
  40acb4:	mov    rax,QWORD PTR [r8]
  40acb7:	mov    r9,rax
  40acba:	nop    WORD PTR [rax+rax*1+0x0]
  40acc0:	mov    QWORD PTR [rdx],r9
  40acc3:	mov    rax,r9
  40acc6:	lock cmpxchg QWORD PTR [r8],rdx
  40accb:	cmp    rax,r9
  40acce:	jne    40ad37 <__swc_fn_3464c816_000013_524c1f23+0x87>
  40acd0:	mov    eax,DWORD PTR [rcx+0x6c]
  40acd3:	test   eax,eax
  40acd5:	je     40ad36 <__swc_fn_3464c816_000013_524c1f23+0x86>
  40acd7:	lea    rdx,[rcx+0x70]
  40acdb:	mov    r9d,0x1
  40ace1:	xor    eax,eax
  40ace3:	lock cmpxchg DWORD PTR [rdx],r9d
  40ace8:	test   eax,eax
  40acea:	jne    40ad36 <__swc_fn_3464c816_000013_524c1f23+0x86>
  40acec:	mov    rax,rcx
  40acef:	and    rax,0xffffffffffc00000
  40acf6:	mov    rax,QWORD PTR [rax+0x8]
  40acfa:	test   rax,rax
  40acfd:	jne    40ad05 <__swc_fn_3464c816_000013_524c1f23+0x55>
  40acff:	xor    eax,eax
  40ad01:	xchg   DWORD PTR [rdx],eax
  40ad03:	jmp    40ad36 <__swc_fn_3464c816_000013_524c1f23+0x86>
  40ad05:	lea    rdx,[rax+0x2a80]
  40ad0c:	mov    rax,QWORD PTR [rdx]
  40ad0f:	mov    r8,rax
  40ad12:	cs nop WORD PTR [rax+rax*1+0x0]
  40ad1c:	nop    DWORD PTR [rax+0x0]
  40ad20:	mov    QWORD PTR [rcx+0x78],r8
  40ad24:	mov    rax,r8
  40ad27:	lock cmpxchg QWORD PTR [rdx],rcx
  40ad2c:	cmp    rax,r8
  40ad2f:	je     40ad36 <__swc_fn_3464c816_000013_524c1f23+0x86>
  40ad31:	mov    r8,rax
  40ad34:	jmp    40ad20 <__swc_fn_3464c816_000013_524c1f23+0x70>
  40ad36:	ret
  40ad37:	mov    r9,rax
  40ad3a:	jmp    40acc0 <__swc_fn_3464c816_000013_524c1f23+0x10>
	...

000000000040ad40 <__swc_fn_3464c816_000016_efc44797>:
  40ad40:	push   rsi
  40ad41:	push   rdi
  40ad42:	push   r12
  40ad44:	push   r13
  40ad46:	push   r14
  40ad48:	push   r15
  40ad4a:	push   rbx
  40ad4b:	sub    rsp,0x30
  40ad4f:	mov    QWORD PTR [rsp+0x18],r8
  40ad54:	mov    rsi,rcx
  40ad57:	mov    rdi,rdx
  40ad5a:	mov    rdx,QWORD PTR [rsi+0x40]
  40ad5e:	xchg   ax,ax
  40ad60:	mov    rax,rdx
  40ad63:	not    rax
  40ad66:	and    rax,QWORD PTR [rsi+0x20]
  40ad6a:	test   rax,rax
  40ad6d:	jne    40ad81 <__swc_fn_3464c816_000016_efc44797+0x41>
  40ad6f:	xor    eax,eax
  40ad71:	add    rsp,0x30
  40ad75:	pop    rbx
  40ad76:	pop    r15
  40ad78:	pop    r14
  40ad7a:	pop    r13
  40ad7c:	pop    r12
  40ad7e:	pop    rdi
  40ad7f:	pop    rsi
  40ad80:	ret
  40ad81:	xor    ecx,ecx
  40ad83:	tzcnt  rcx,rax
  40ad88:	lea    r12,[rsp+0x8]
  40ad8d:	mov    DWORD PTR [rsp+0x8],ecx
  40ad91:	mov    r13d,0x1
  40ad97:	shl    r13,cl
  40ad9a:	mov    rcx,rdx
  40ad9d:	or     rcx,r13
  40ada0:	mov    rax,rdx
  40ada3:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40ada9:	cmp    rax,rdx
  40adac:	je     40adb3 <__swc_fn_3464c816_000016_efc44797+0x73>
  40adae:	mov    rdx,rax
  40adb1:	jmp    40ad60 <__swc_fn_3464c816_000016_efc44797+0x20>
  40adb3:	mov    eax,DWORD PTR [r12]
  40adb7:	shl    rax,0x4
  40adbb:	lea    r14,[rsi+rax*8+0x80]
  40adc3:	mov    rcx,rsi
  40adc6:	mov    rax,r12
  40adc9:	mov    edx,DWORD PTR [rax]
  40adcb:	call   40df60 <__swc_fn_3464c816_000014_9dea5065>
  40add0:	mov    r15,rax
  40add3:	mov    rcx,rsi
  40add6:	mov    rdx,r13
  40add9:	call   40e0c0 <__swc_fn_3464c816_000020_fd2b165c>
  40adde:	test   al,al
  40ade0:	je     40ae18 <__swc_fn_3464c816_000016_efc44797+0xd8>
  40ade2:	mov    ecx,DWORD PTR [r14+0x3c]
  40ade6:	lea    rdx,[rip+0x19273]        # 424060 <__swc_bss_base_3464c816+0x20>
  40aded:	mov    r8,QWORD PTR [rip+0x1926c]        # 424060 <__swc_bss_base_3464c816+0x20>
  40adf4:	cs nop WORD PTR [rax+rax*1+0x0]
  40adfe:	xchg   ax,ax
  40ae00:	mov    r9,r8
  40ae03:	sub    r9,rcx
  40ae06:	mov    rax,r8
  40ae09:	lock cmpxchg QWORD PTR [rdx],r9
  40ae0e:	cmp    rax,r8
  40ae11:	je     40ae79 <__swc_fn_3464c816_000016_efc44797+0x139>
  40ae13:	mov    r8,rax
  40ae16:	jmp    40ae00 <__swc_fn_3464c816_000016_efc44797+0xc0>
  40ae18:	mov    rcx,rsi
  40ae1b:	mov    rax,r12
  40ae1e:	mov    edx,DWORD PTR [rax]
  40ae20:	call   407bf0 <__swc_fn_3464c816_000015_9afb7cfb>
  40ae25:	mov    rcx,r15
  40ae28:	and    rcx,0xffffffffffff0000
  40ae2f:	lea    rcx,[rcx+0x10000]
  40ae36:	mov    rbx,rax
  40ae39:	cmp    rax,rcx
  40ae3c:	cmova  rbx,rcx
  40ae40:	mov    rax,rbx
  40ae43:	sub    rax,r15
  40ae46:	mov    rcx,r15
  40ae49:	mov    rdx,rax
  40ae4c:	call   407a40 <__swc_fn_3464c816_000006_f7acedb0>
  40ae51:	test   al,al
  40ae53:	jne    40ae72 <__swc_fn_3464c816_000016_efc44797+0x132>
  40ae55:	mov    rcx,rsi
  40ae58:	mov    rdx,r13
  40ae5b:	call   407da0 <__swc_fn_3464c816_000021_c8f5f27c>
  40ae60:	xor    eax,eax
  40ae62:	add    rsp,0x30
  40ae66:	pop    rbx
  40ae67:	pop    r15
  40ae69:	pop    r14
  40ae6b:	pop    r13
  40ae6d:	pop    r12
  40ae6f:	pop    rdi
  40ae70:	pop    rsi
  40ae71:	ret
  40ae72:	sub    rbx,r15
  40ae75:	mov    DWORD PTR [r14+0x3c],ebx
  40ae79:	mov    rcx,r14
  40ae7c:	mov    rdx,rsi
  40ae7f:	mov    r8d,DWORD PTR [r12]
  40ae83:	mov    r9d,edi
  40ae86:	mov    rbx,QWORD PTR [rsp+0x18]
  40ae8b:	mov    r10d,ebx
  40ae8e:	call   40abe0 <__swc_fn_3464c816_000007_d64b2baa>
  40ae93:	mov    rax,r14
  40ae96:	add    rsp,0x30
  40ae9a:	pop    rbx
  40ae9b:	pop    r15
  40ae9d:	pop    r14
  40ae9f:	pop    r13
  40aea1:	pop    r12
  40aea3:	pop    rdi
  40aea4:	pop    rsi
  40aea5:	ret
	...

000000000040aeb0 <__swc_fn_3464c816_000019_de02dbdf>:
  40aeb0:	mov    r8,QWORD PTR [rcx+0x48]
  40aeb4:	cs nop WORD PTR [rax+rax*1+0x0]
  40aebe:	xchg   ax,ax
  40aec0:	mov    r9,r8
  40aec3:	or     r9,rdx
  40aec6:	mov    rax,r8
  40aec9:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40aecf:	cmp    rax,r8
  40aed2:	jne    40aed5 <__swc_fn_3464c816_000019_de02dbdf+0x25>
  40aed4:	ret
  40aed5:	mov    r8,rax
  40aed8:	jmp    40aec0 <__swc_fn_3464c816_000019_de02dbdf+0x10>
  40aeda:	add    BYTE PTR [rax],al
  40aedc:	add    BYTE PTR [rax],al
	...

000000000040aee0 <__swc_fn_3464c816_000022_2d0fcd2c>:
  40aee0:	push   rsi
  40aee1:	push   rdi
  40aee2:	push   r12
  40aee4:	mov    rsi,rcx
  40aee7:	xor    edi,edi
  40aee9:	lea    r12,[rip+0x19180]        # 424070 <__swc_bss_base_3464c816+0x30>
  40aef0:	mov    eax,DWORD PTR [r12]
  40aef4:	xor    ecx,ecx
  40aef6:	test   rax,rax
  40aef9:	jbe    40af34 <__swc_fn_3464c816_000022_2d0fcd2c+0x54>
  40aefb:	nop    DWORD PTR [rax+rax*1+0x0]
  40af00:	lea    rdx,[rip+0x19171]        # 424078 <__swc_bss_base_3464c816+0x38>
  40af07:	mov    r8d,ecx
  40af0a:	lea    r8,[r8+r8*2]
  40af0e:	lea    r8,[rdx+r8*8]
  40af12:	mov    rdx,QWORD PTR [r8+0x10]
  40af16:	add    rdx,0x400000
  40af1d:	cmp    rdx,0x40000000
  40af24:	ja     40af2b <__swc_fn_3464c816_000022_2d0fcd2c+0x4b>
  40af26:	mov    rdi,r8
  40af29:	jmp    40af34 <__swc_fn_3464c816_000022_2d0fcd2c+0x54>
  40af2b:	add    rcx,0x1
  40af2f:	cmp    rcx,rax
  40af32:	jb     40af00 <__swc_fn_3464c816_000022_2d0fcd2c+0x20>
  40af34:	test   rdi,rdi
  40af37:	jne    40afc3 <__swc_fn_3464c816_000022_2d0fcd2c+0xe3>
  40af3d:	cmp    DWORD PTR [r12],0x10
  40af42:	jae    40afab <__swc_fn_3464c816_000022_2d0fcd2c+0xcb>
  40af44:	mov    ecx,0x40400000
  40af49:	call   40de80 <__swc_fn_3464c816_000005_81d2e1e9>
  40af4e:	test   rax,rax
  40af51:	je     40afab <__swc_fn_3464c816_000022_2d0fcd2c+0xcb>
  40af53:	lea    rcx,[rip+0x1911e]        # 424078 <__swc_bss_base_3464c816+0x38>
  40af5a:	mov    edx,DWORD PTR [r12]
  40af5e:	lea    rdx,[rdx+rdx*2]
  40af62:	lea    rdx,[rcx+rdx*8]
  40af66:	mov    QWORD PTR [rdx],rax
  40af69:	lea    rax,[rax+0x3fffff]
  40af70:	and    rax,0xffffffffffc00000
  40af77:	mov    QWORD PTR [rdx+0x8],rax
  40af7b:	mov    QWORD PTR [rdx+0x10],0x0
  40af83:	mov    edx,DWORD PTR [rip+0x190e7]        # 424070 <__swc_bss_base_3464c816+0x30>
  40af89:	nop    DWORD PTR [rax+0x0]
  40af90:	lea    r9d,[rdx+0x1]
  40af94:	mov    rax,rdx
  40af97:	lock cmpxchg DWORD PTR [r12],r9d
  40af9d:	mov    r8d,eax
  40afa0:	cmp    eax,edx
  40afa2:	je     40afb2 <__swc_fn_3464c816_000022_2d0fcd2c+0xd2>
  40afa4:	mov    rdx,r8
  40afa7:	jmp    40af90 <__swc_fn_3464c816_000022_2d0fcd2c+0xb0>
  40afa9:	jmp    40afb2 <__swc_fn_3464c816_000022_2d0fcd2c+0xd2>
  40afab:	xor    eax,eax
  40afad:	pop    r12
  40afaf:	pop    rdi
  40afb0:	pop    rsi
  40afb1:	ret
  40afb2:	mov    eax,DWORD PTR [rip+0x190b8]        # 424070 <__swc_bss_base_3464c816+0x30>
  40afb8:	sub    eax,0x1
  40afbb:	lea    rdi,[rax+rax*2]
  40afbf:	lea    rdi,[rcx+rdi*8]
  40afc3:	mov    r12,QWORD PTR [rdi+0x8]
  40afc7:	add    r12,QWORD PTR [rdi+0x10]
  40afcb:	mov    rcx,r12
  40afce:	mov    edx,0x3000
  40afd3:	call   407a40 <__swc_fn_3464c816_000006_f7acedb0>
  40afd8:	test   al,al
  40afda:	jne    40afe3 <__swc_fn_3464c816_000022_2d0fcd2c+0x103>
  40afdc:	xor    eax,eax
  40afde:	pop    r12
  40afe0:	pop    rdi
  40afe1:	pop    rsi
  40afe2:	ret
  40afe3:	vxorps xmm0,xmm0,xmm0
  40afe7:	xor    eax,eax
  40afe9:	cs nop WORD PTR [rax+rax*1+0x0]
  40aff3:	cs nop WORD PTR [rax+rax*1+0x0]
  40affd:	nop    DWORD PTR [rax]
  40b000:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40b006:	add    rax,0x10
  40b00a:	cmp    rax,0x3000
  40b011:	jne    40b000 <__swc_fn_3464c816_000022_2d0fcd2c+0x120>
  40b013:	mov    DWORD PTR [r12+0x28],esi
  40b018:	mov    eax,0x40
  40b01d:	mov    ecx,esi
  40b01f:	shr    eax,cl
  40b021:	mov    DWORD PTR [r12+0x2c],eax
  40b026:	cmp    DWORD PTR [r12+0x2c],0x40
  40b02c:	jb     40b037 <__swc_fn_3464c816_000022_2d0fcd2c+0x157>
  40b02e:	mov    rax,0xffffffffffffffff
  40b035:	jmp    40b047 <__swc_fn_3464c816_000022_2d0fcd2c+0x167>
  40b037:	mov    eax,0x1
  40b03c:	mov    ecx,DWORD PTR [r12+0x2c]
  40b041:	shl    rax,cl
  40b044:	dec    rax
  40b047:	mov    QWORD PTR [r12+0x20],rax
  40b04c:	mov    DWORD PTR [r12],0x4e540001
  40b054:	mov    DWORD PTR [r12+0x4],0x53474d45
  40b05d:	add    QWORD PTR [rdi+0x10],0x400000
  40b065:	mov    rax,r12
  40b068:	pop    r12
  40b06a:	pop    rdi
  40b06b:	pop    rsi
  40b06c:	ret
  40b06d:	add    BYTE PTR [rax],al
	...

000000000040b070 <__swc_fn_3464c816_000025_bcdc5519>:
  40b070:	mov    eax,0x1
  40b075:	mov    edx,DWORD PTR [rip+0x18ff5]        # 424070 <__swc_bss_base_3464c816+0x30>
  40b07b:	cmp    eax,edx
  40b07d:	jae    40b0cb <__swc_fn_3464c816_000025_bcdc5519+0x5b>
  40b07f:	nop
  40b080:	lea    r8,[rip+0x18ff1]        # 424078 <__swc_bss_base_3464c816+0x38>
  40b087:	lea    r9,[rax+rax*2]
  40b08b:	lea    r9,[r8+r9*8]
  40b08f:	mov    r8,rcx
  40b092:	sub    r8,QWORD PTR [r9+0x8]
  40b096:	mov    r9,QWORD PTR [r9+0x10]
  40b09a:	cmp    r8,r9
  40b09d:	jae    40b0c5 <__swc_fn_3464c816_000025_bcdc5519+0x55>
  40b09f:	mov    rax,rcx
  40b0a2:	and    rax,0xffffffffffc00000
  40b0a9:	shr    rcx,0x10
  40b0ad:	and    ecx,0x3f
  40b0b0:	mov    edx,DWORD PTR [rax+0x28]
  40b0b3:	shrx   ecx,ecx,edx
  40b0b8:	shl    rcx,0x4
  40b0bc:	lea    rax,[rax+rcx*8+0x80]
  40b0c4:	ret
  40b0c5:	inc    eax
  40b0c7:	cmp    eax,edx
  40b0c9:	jb     40b080 <__swc_fn_3464c816_000025_bcdc5519+0x10>
  40b0cb:	xor    eax,eax
  40b0cd:	ret
	...

000000000040b0d0 <__swc_fn_3464c816_000028_9798fb47>:
  40b0d0:	vxorps xmm0,xmm0,xmm0
  40b0d4:	vmovups XMMWORD PTR [rcx],xmm0
  40b0d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b0dd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b0e2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b0e7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b0ec:	mov    QWORD PTR [rcx+0x50],0x0
  40b0f4:	ret
	...

000000000040b100 <__swc_fn_3464c816_000031_9798fb47>:
  40b100:	vxorps xmm0,xmm0,xmm0
  40b104:	xor    eax,eax
  40b106:	cs nop WORD PTR [rax+rax*1+0x0]
  40b110:	cs nop WORD PTR [rax+rax*1+0x0]
  40b11a:	nop    WORD PTR [rax+rax*1+0x0]
  40b120:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40b125:	add    rax,0x10
  40b129:	cmp    rax,0x9b0
  40b130:	jne    40b120 <__swc_fn_3464c816_000031_9798fb47+0x20>
  40b132:	mov    QWORD PTR [rcx+0x9b0],0x0
  40b13d:	ret
	...

000000000040b140 <__swc_fn_3464c816_000034_cd1a4e8c>:
  40b140:	push   rsi
  40b141:	push   rdi
  40b142:	sub    rsp,0x8
  40b146:	lea    rsi,[rip+0x16ec3]        # 422010 <__swc_data_base_3464c816+0x10>
  40b14d:	mov    rax,QWORD PTR [rsi]
  40b150:	mov    ecx,0xffffffff
  40b155:	cmp    rax,rcx
  40b158:	je     40b161 <__swc_fn_3464c816_000034_cd1a4e8c+0x21>
  40b15a:	add    rsp,0x8
  40b15e:	pop    rdi
  40b15f:	pop    rsi
  40b160:	ret
  40b161:	mov    rcx,QWORD PTR [rip+0x7f10]        # 413078 <__swc_fn_3464c816_000176_cf4ffedd+0x1098>
  40b168:	call   409df0 <__swc_fn_3464c816_000129_4a82cdf6>
  40b16d:	mov    rcx,rax
  40b170:	mov    eax,0xffffffff
  40b175:	lock cmpxchg QWORD PTR [rsi],rcx
  40b17a:	mov    rdi,rax
  40b17d:	mov    eax,0xffffffff
  40b182:	cmp    rdi,rax
  40b185:	je     40b196 <__swc_fn_3464c816_000034_cd1a4e8c+0x56>
  40b187:	call   40d370 <__swc_fn_3464c816_000130_a611b8c4>
  40b18c:	mov    rax,rdi
  40b18f:	add    rsp,0x8
  40b193:	pop    rdi
  40b194:	pop    rsi
  40b195:	ret
  40b196:	mov    rax,rcx
  40b199:	add    rsp,0x8
  40b19d:	pop    rdi
  40b19e:	pop    rsi
  40b19f:	ret

000000000040b1a0 <__swc_fn_3464c816_000037_14f56618>:
  40b1a0:	sub    rsp,0x8
  40b1a4:	vxorps xmm0,xmm0,xmm0
  40b1a8:	xor    eax,eax
  40b1aa:	cs nop WORD PTR [rax+rax*1+0x0]
  40b1b4:	cs nop WORD PTR [rax+rax*1+0x0]
  40b1be:	xchg   ax,ax
  40b1c0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40b1c5:	add    rax,0x10
  40b1c9:	cmp    rax,0x2b00
  40b1d0:	jne    40b1c0 <__swc_fn_3464c816_000037_14f56618+0x20>
  40b1d2:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40b1dc:	xor    al,al
  40b1de:	mov    rdx,rax
  40b1e1:	xor    al,al
  40b1e3:	mov    r8,rax
  40b1e6:	xor    al,al
  40b1e8:	mov    r9,rax
  40b1eb:	xor    al,al
  40b1ed:	mov    r10,rax
  40b1f0:	xor    al,al
  40b1f2:	mov    r11,rax
  40b1f5:	call   40e2f0 <__swc_fn_3464c816_000038_03f1bf9a>
  40b1fa:	add    rsp,0x8
  40b1fe:	ret
	...

000000000040b200 <__swc_fn_3464c816_000040_c90d80c1>:
  40b200:	push   rsi
  40b201:	push   rdi
  40b202:	push   r12
  40b204:	mov    rsi,r8
  40b207:	mov    rdi,rdx
  40b20a:	mov    rcx,rdx
  40b20d:	call   40de80 <__swc_fn_3464c816_000005_81d2e1e9>
  40b212:	mov    r12,rax
  40b215:	test   rax,rax
  40b218:	jne    40b221 <__swc_fn_3464c816_000040_c90d80c1+0x21>
  40b21a:	xor    eax,eax
  40b21c:	pop    r12
  40b21e:	pop    rdi
  40b21f:	pop    rsi
  40b220:	ret
  40b221:	mov    rcx,r12
  40b224:	mov    rdx,rsi
  40b227:	call   407a40 <__swc_fn_3464c816_000006_f7acedb0>
  40b22c:	test   al,al
  40b22e:	jne    40b242 <__swc_fn_3464c816_000040_c90d80c1+0x42>
  40b230:	mov    rcx,r12
  40b233:	mov    rdx,rdi
  40b236:	call   4100f0 <__swc_fn_3464c816_000116_ed2d8fed>
  40b23b:	xor    eax,eax
  40b23d:	pop    r12
  40b23f:	pop    rdi
  40b240:	pop    rsi
  40b241:	ret
  40b242:	mov    rax,r12
  40b245:	pop    r12
  40b247:	pop    rdi
  40b248:	pop    rsi
  40b249:	ret
	...

000000000040b260 <__swc_fn_3464c816_000043_a78ae66b>:
  40b260:	push   rsi
  40b261:	push   rdi
  40b262:	push   r12
  40b264:	mov    rsi,rcx
  40b267:	mov    edx,0x9b8
  40b26c:	call   40e360 <__swc_fn_3464c816_000041_facd3e17>
  40b271:	mov    rdi,rax
  40b274:	test   rax,rax
  40b277:	jne    40b280 <__swc_fn_3464c816_000043_a78ae66b+0x20>
  40b279:	xor    eax,eax
  40b27b:	pop    r12
  40b27d:	pop    rdi
  40b27e:	pop    rsi
  40b27f:	ret
  40b280:	vxorps xmm0,xmm0,xmm0
  40b284:	xor    eax,eax
  40b286:	cs nop WORD PTR [rax+rax*1+0x0]
  40b290:	cs nop WORD PTR [rax+rax*1+0x0]
  40b29a:	nop    WORD PTR [rax+rax*1+0x0]
  40b2a0:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40b2a5:	add    rax,0x10
  40b2a9:	cmp    rax,0x9b0
  40b2b0:	jne    40b2a0 <__swc_fn_3464c816_000043_a78ae66b+0x40>
  40b2b2:	mov    QWORD PTR [rdi+0x9b0],0x0
  40b2bd:	mov    QWORD PTR [rdi],rsi
  40b2c0:	call   40d420 <__swc_fn_3464c816_000133_a9c1c700>
  40b2c5:	mov    QWORD PTR [rdi+0x18],rax
  40b2c9:	lea    r12,[rsi+0x10]
  40b2cd:	mov    rcx,r12
  40b2d0:	call   40a040 <__swc_fn_3464c816_000138_86bb0f90>
  40b2d5:	mov    rax,QWORD PTR [rsi+0x20]
  40b2d9:	mov    QWORD PTR [rdi+0x8],rax
  40b2dd:	mov    rax,QWORD PTR [rsi+0x20]
  40b2e1:	test   rax,rax
  40b2e4:	je     40b2ea <__swc_fn_3464c816_000043_a78ae66b+0x8a>
  40b2e6:	mov    QWORD PTR [rax+0x10],rdi
  40b2ea:	mov    QWORD PTR [rsi+0x20],rdi
  40b2ee:	mov    rcx,r12
  40b2f1:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40b2f6:	mov    rax,rdi
  40b2f9:	pop    r12
  40b2fb:	pop    rdi
  40b2fc:	pop    rsi
  40b2fd:	ret
	...

000000000040b300 <__swc_fn_3464c816_000046_6e7a8d58>:
  40b300:	mov    rax,QWORD PTR [rdx+0x10]
  40b304:	test   rax,rax
  40b307:	je     40b313 <__swc_fn_3464c816_000046_6e7a8d58+0x13>
  40b309:	mov    rcx,QWORD PTR [rdx+0x8]
  40b30d:	mov    QWORD PTR [rax+0x8],rcx
  40b311:	jmp    40b31b <__swc_fn_3464c816_000046_6e7a8d58+0x1b>
  40b313:	mov    rax,QWORD PTR [rdx+0x8]
  40b317:	mov    QWORD PTR [rcx+0x20],rax
  40b31b:	mov    rax,QWORD PTR [rdx+0x8]
  40b31f:	test   rax,rax
  40b322:	je     40b32c <__swc_fn_3464c816_000046_6e7a8d58+0x2c>
  40b324:	mov    rcx,QWORD PTR [rdx+0x10]
  40b328:	mov    QWORD PTR [rax+0x10],rcx
  40b32c:	vxorps xmm0,xmm0,xmm0
  40b330:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40b335:	ret
	...

000000000040b340 <__swc_fn_3464c816_000049_129b9bf4>:
  40b340:	sub    rsp,0x8
  40b344:	mov    r9,r8
  40b347:	mov    r10,rdx
  40b34a:	call   40e410 <__swc_fn_3464c816_000047_137687bb>
  40b34f:	mov    eax,0x1
  40b354:	xchg   DWORD PTR [r9+0x6c],eax
  40b358:	mov    rax,QWORD PTR [r9+0x60]
  40b35c:	test   rax,rax
  40b35f:	je     40b3a3 <__swc_fn_3464c816_000049_129b9bf4+0x63>
  40b361:	xor    eax,eax
  40b363:	xchg   DWORD PTR [r9+0x6c],eax
  40b367:	movzx  eax,BYTE PTR [r9+0x39]
  40b36c:	lea    rax,[rax+rax*4]
  40b370:	lea    rax,[r10+rax*8+0x28]
  40b375:	mov    QWORD PTR [r9+0x50],0x0
  40b37d:	mov    rcx,QWORD PTR [rax+0x8]
  40b381:	mov    QWORD PTR [r9+0x48],rcx
  40b385:	mov    rcx,QWORD PTR [rax+0x8]
  40b389:	test   rcx,rcx
  40b38c:	je     40b394 <__swc_fn_3464c816_000049_129b9bf4+0x54>
  40b38e:	mov    QWORD PTR [rcx+0x50],r9
  40b392:	jmp    40b398 <__swc_fn_3464c816_000049_129b9bf4+0x58>
  40b394:	mov    QWORD PTR [rax+0x10],r9
  40b398:	mov    QWORD PTR [rax+0x8],r9
  40b39c:	xor    eax,eax
  40b39e:	add    rsp,0x8
  40b3a2:	ret
  40b3a3:	movzx  eax,BYTE PTR [r9+0x39]
  40b3a8:	lea    rax,[rax+rax*4]
  40b3ac:	lea    rax,[r10+rax*8+0x28]
  40b3b1:	mov    QWORD PTR [r9+0x50],0x0
  40b3b9:	mov    rcx,QWORD PTR [rax+0x18]
  40b3bd:	mov    QWORD PTR [r9+0x48],rcx
  40b3c1:	mov    rcx,QWORD PTR [rax+0x18]
  40b3c5:	test   rcx,rcx
  40b3c8:	je     40b3ce <__swc_fn_3464c816_000049_129b9bf4+0x8e>
  40b3ca:	mov    QWORD PTR [rcx+0x50],r9
  40b3ce:	mov    QWORD PTR [rax+0x18],r9
  40b3d2:	mov    eax,0x1
  40b3d7:	add    rsp,0x8
  40b3db:	ret
  40b3dc:	add    BYTE PTR [rax],al
	...

000000000040b3e0 <__swc_fn_3464c816_000052_3af34d7f>:
  40b3e0:	push   r12
  40b3e2:	push   r13
  40b3e4:	push   rdi
  40b3e5:	push   rsi
  40b3e6:	push   r14
  40b3e8:	push   r15
  40b3ea:	sub    rsp,0x178
  40b3f1:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40b3fa:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40b403:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40b40c:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40b415:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40b41e:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40b427:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40b430:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40b439:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40b442:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40b44b:	mov    r12,rcx
  40b44e:	lea    rax,[rip+0x18db3]        # 424208 <__swc_bss_base_3464c816+0x1c8>
  40b455:	mov    rcx,QWORD PTR [rax]
  40b458:	mov    r13,rcx
  40b45b:	test   rcx,rcx
  40b45e:	jne    40b46e <__swc_fn_3464c816_000052_3af34d7f+0x8e>
  40b460:	mov    r13d,0x1dcd6500
  40b466:	mov    ecx,0x1dcd6500
  40b46b:	xchg   QWORD PTR [rax],rcx
  40b46e:	lea    rax,[rip+0x16b93]        # 422008 <__swc_data_base_3464c816+0x8>
  40b475:	mov    rax,QWORD PTR [rax]
  40b478:	cmp    rax,0xffffffffffffffff
  40b47c:	je     40b48b <__swc_fn_3464c816_000052_3af34d7f+0xab>
  40b47e:	mov    eax,eax
  40b480:	mov    edi,eax
  40b482:	xor    eax,eax
  40b484:	call   407000 <pthread_getspecific@plt>
  40b489:	jmp    40b48d <__swc_fn_3464c816_000052_3af34d7f+0xad>
  40b48b:	xor    eax,eax
  40b48d:	test   rax,rax
  40b490:	jne    40b49f <__swc_fn_3464c816_000052_3af34d7f+0xbf>
  40b492:	call   40b140 <__swc_fn_3464c816_000034_cd1a4e8c>
  40b497:	mov    rcx,rax
  40b49a:	call   410440 <__swc_fn_3464c816_000131_5f757033>
  40b49f:	test   rax,rax
  40b4a2:	je     40b4b4 <__swc_fn_3464c816_000052_3af34d7f+0xd4>
  40b4a4:	cmp    QWORD PTR [rax],r12
  40b4a7:	jne    40b4b4 <__swc_fn_3464c816_000052_3af34d7f+0xd4>
  40b4a9:	cmp    DWORD PTR [rax+0x20],0x0
  40b4ad:	jne    40b4b4 <__swc_fn_3464c816_000052_3af34d7f+0xd4>
  40b4af:	mov    rsi,rax
  40b4b2:	jmp    40b4b6 <__swc_fn_3464c816_000052_3af34d7f+0xd6>
  40b4b4:	xor    esi,esi
  40b4b6:	lea    rdi,[r12+0x2a88]
  40b4be:	mov    r14,QWORD PTR [rdi]
  40b4c1:	test   r14,r14
  40b4c4:	jne    40b513 <__swc_fn_3464c816_000052_3af34d7f+0x133>
  40b4c6:	lea    rax,[rip+0x18b93]        # 424060 <__swc_bss_base_3464c816+0x20>
  40b4cd:	mov    rax,QWORD PTR [rax]
  40b4d0:	test   rax,rax
  40b4d3:	setne  al
  40b4d6:	jne    40b4fa <__swc_fn_3464c816_000052_3af34d7f+0x11a>
  40b4d8:	mov    rax,QWORD PTR [r12+0x2a70]
  40b4e0:	test   rax,rax
  40b4e3:	setne  al
  40b4e6:	jne    40b4fa <__swc_fn_3464c816_000052_3af34d7f+0x11a>
  40b4e8:	test   rsi,rsi
  40b4eb:	setne  al
  40b4ee:	je     40b4fa <__swc_fn_3464c816_000052_3af34d7f+0x11a>
  40b4f0:	cmp    DWORD PTR [rsi+0x730],0x0
  40b4f7:	setne  al
  40b4fa:	test   al,al
  40b4fc:	je     40b50e <__swc_fn_3464c816_000052_3af34d7f+0x12e>
  40b4fe:	call   4104f0 <__swc_fn_3464c816_000134_07d76562>
  40b503:	lea    rcx,[rax+r13*1]
  40b507:	xor    eax,eax
  40b509:	lock cmpxchg QWORD PTR [rdi],rcx
  40b50e:	jmp    40b613 <__swc_fn_3464c816_000052_3af34d7f+0x233>
  40b513:	call   4104f0 <__swc_fn_3464c816_000134_07d76562>
  40b518:	mov    r15,rax
  40b51b:	cmp    rax,r14
  40b51e:	jb     40b52f <__swc_fn_3464c816_000052_3af34d7f+0x14f>
  40b520:	xor    ecx,ecx
  40b522:	mov    rax,r14
  40b525:	lock cmpxchg QWORD PTR [rdi],rcx
  40b52a:	cmp    rax,r14
  40b52d:	je     40b534 <__swc_fn_3464c816_000052_3af34d7f+0x154>
  40b52f:	jmp    40b613 <__swc_fn_3464c816_000052_3af34d7f+0x233>
  40b534:	test   rsi,rsi
  40b537:	je     40b552 <__swc_fn_3464c816_000052_3af34d7f+0x172>
  40b539:	cmp    r15,r13
  40b53c:	jb     40b552 <__swc_fn_3464c816_000052_3af34d7f+0x172>
  40b53e:	mov    rax,r15
  40b541:	sub    rax,r13
  40b544:	mov    rcx,r12
  40b547:	mov    rdx,rsi
  40b54a:	mov    r8,rax
  40b54d:	call   40e850 <__swc_fn_3464c816_000062_dea90857>
  40b552:	lea    rsi,[r12+0x10]
  40b557:	mov    rcx,rsi
  40b55a:	call   40a040 <__swc_fn_3464c816_000138_86bb0f90>
  40b55f:	mov    rax,QWORD PTR [r12+0x18]
  40b564:	mov    rdi,rax
  40b567:	test   rdi,rdi
  40b56a:	je     40b594 <__swc_fn_3464c816_000052_3af34d7f+0x1b4>
  40b56c:	cs nop WORD PTR [rax+rax*1+0x0]
  40b576:	cs nop WORD PTR [rax+rax*1+0x0]
  40b580:	mov    rcx,rdi
  40b583:	call   407c10 <__swc_fn_3464c816_000018_adca76cf>
  40b588:	mov    rax,QWORD PTR [rdi+0x10]
  40b58c:	mov    rdi,rax
  40b58f:	test   rax,rax
  40b592:	jne    40b580 <__swc_fn_3464c816_000052_3af34d7f+0x1a0>
  40b594:	mov    rcx,rsi
  40b597:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40b59c:	mov    rcx,r12
  40b59f:	call   40a040 <__swc_fn_3464c816_000138_86bb0f90>
  40b5a4:	xor    esi,esi
  40b5a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40b5b0:	mov    rax,QWORD PTR [r12+0x2a70]
  40b5b8:	cmp    rsi,rax
  40b5bb:	jae    40b60b <__swc_fn_3464c816_000052_3af34d7f+0x22b>
  40b5bd:	lea    rax,[rsi+rsi*4]
  40b5c1:	lea    rax,[r12+rax*8+0x268]
  40b5c9:	mov    r8,QWORD PTR [rax]
  40b5cc:	mov    r9,QWORD PTR [rax+0x8]
  40b5d0:	mov    r10,QWORD PTR [rax+0x10]
  40b5d4:	mov    rax,QWORD PTR [rax+0x20]
  40b5d8:	cmp    rax,r15
  40b5db:	jae    40b5e8 <__swc_fn_3464c816_000052_3af34d7f+0x208>
  40b5dd:	mov    rcx,r15
  40b5e0:	sub    rcx,rax
  40b5e3:	cmp    rcx,r13
  40b5e6:	jae    40b5ed <__swc_fn_3464c816_000052_3af34d7f+0x20d>
  40b5e8:	inc    rsi
  40b5eb:	jmp    40b5b0 <__swc_fn_3464c816_000052_3af34d7f+0x1d0>
  40b5ed:	mov    rcx,r12
  40b5f0:	mov    rdx,rsi
  40b5f3:	call   40e800 <__swc_fn_3464c816_000059_15c28ca7>
  40b5f8:	mov    rcx,r12
  40b5fb:	mov    rdx,r8
  40b5fe:	mov    r8,r9
  40b601:	mov    r9,r10
  40b604:	call   407ef0 <__swc_fn_3464c816_000042_d3c2ab54>
  40b609:	jmp    40b5b0 <__swc_fn_3464c816_000052_3af34d7f+0x1d0>
  40b60b:	mov    rcx,r12
  40b60e:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40b613:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40b61c:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40b625:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40b62e:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40b637:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40b640:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40b649:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40b652:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40b65b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40b664:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40b66d:	add    rsp,0x178
  40b674:	pop    r15
  40b676:	pop    r14
  40b678:	pop    rsi
  40b679:	pop    rdi
  40b67a:	pop    r13
  40b67c:	pop    r12
  40b67e:	ret
	...

000000000040b680 <__swc_fn_3464c816_000055_df0696cd>:
  40b680:	lea    rax,[rdx-0x58]
  40b684:	ret
	...

000000000040b690 <__swc_fn_3464c816_000058_2ca0cb05>:
  40b690:	push   rsi
  40b691:	push   rdi
  40b692:	push   r12
  40b694:	push   r13
  40b696:	sub    rsp,0x68
  40b69a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40b6a0:	mov    rsi,r9
  40b6a3:	mov    rdi,rcx
  40b6a6:	mov    r12,rdx
  40b6a9:	mov    r13,r8
  40b6ac:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40b6b4:	jne    40b6c3 <__swc_fn_3464c816_000058_2ca0cb05+0x33>
  40b6b6:	xor    eax,eax
  40b6b8:	add    rsp,0x68
  40b6bc:	pop    r13
  40b6be:	pop    r12
  40b6c0:	pop    rdi
  40b6c1:	pop    rsi
  40b6c2:	ret
  40b6c3:	mov    rcx,rdi
  40b6c6:	call   40a040 <__swc_fn_3464c816_000138_86bb0f90>
  40b6cb:	movabs rax,0x7fffffffffffffff
  40b6d5:	cmp    r12,rax
  40b6d8:	mov    rax,0xffffffffffffffff
  40b6df:	lea    rcx,[r12+r12*1]
  40b6e3:	cmovbe rax,rcx
  40b6e7:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40b6ee:	mov    rdx,rcx
  40b6f1:	sub    rax,r12
  40b6f4:	inc    rax
  40b6f7:	xor    r8d,r8d
  40b6fa:	test   rcx,rcx
  40b6fd:	jbe    40b728 <__swc_fn_3464c816_000058_2ca0cb05+0x98>
  40b6ff:	nop
  40b700:	lea    r9,[r8+r8*4]
  40b704:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40b70c:	sub    r9,r12
  40b70f:	cmp    r9,rax
  40b712:	jae    40b71f <__swc_fn_3464c816_000058_2ca0cb05+0x8f>
  40b714:	mov    rdx,r8
  40b717:	mov    rax,r9
  40b71a:	test   r9,r9
  40b71d:	je     40b728 <__swc_fn_3464c816_000058_2ca0cb05+0x98>
  40b71f:	add    r8,0x1
  40b723:	cmp    r8,rcx
  40b726:	jb     40b700 <__swc_fn_3464c816_000058_2ca0cb05+0x70>
  40b728:	mov    rax,QWORD PTR [rdi+0x2a70]
  40b72f:	cmp    rdx,rax
  40b732:	jne    40b74f <__swc_fn_3464c816_000058_2ca0cb05+0xbf>
  40b734:	mov    rcx,rdi
  40b737:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40b73c:	xor    eax,eax
  40b73e:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b744:	add    rsp,0x68
  40b748:	pop    r13
  40b74a:	pop    r12
  40b74c:	pop    rdi
  40b74d:	pop    rsi
  40b74e:	ret
  40b74f:	lea    rax,[rdx+rdx*4]
  40b753:	lea    rax,[rdi+rax*8+0x268]
  40b75b:	vmovups xmm6,XMMWORD PTR [rax]
  40b75f:	mov    r8,QWORD PTR [rax+0x10]
  40b763:	mov    rcx,rdi
  40b766:	call   40e800 <__swc_fn_3464c816_000059_15c28ca7>
  40b76b:	vpshufd xmm0,xmm6,0xee
  40b770:	vmovsd QWORD PTR [r13+0x0],xmm0
  40b776:	mov    QWORD PTR [rsi],r8
  40b779:	mov    rcx,rdi
  40b77c:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40b781:	vmovq  rax,xmm6
  40b786:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b78c:	add    rsp,0x68
  40b790:	pop    r13
  40b792:	pop    r12
  40b794:	pop    rdi
  40b795:	pop    rsi
  40b796:	ret
	...

000000000040b7a0 <__swc_fn_3464c816_000061_b304235a>:
  40b7a0:	push   r12
  40b7a2:	push   r13
  40b7a4:	push   r14
  40b7a6:	push   r15
  40b7a8:	push   rdi
  40b7a9:	push   rsi
  40b7aa:	sub    rsp,0x148
  40b7b1:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b7ba:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b7c3:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b7cc:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b7d5:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b7de:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b7e7:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b7f0:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b7f9:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b802:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b80b:	mov    r12,r9
  40b80e:	mov    r13,rcx
  40b811:	mov    r14,rdx
  40b814:	mov    r15,r8
  40b817:	test   rdx,rdx
  40b81a:	jne    40b82e <__swc_fn_3464c816_000061_b304235a+0x8e>
  40b81c:	add    rsp,0x148
  40b823:	pop    rsi
  40b824:	pop    rdi
  40b825:	pop    r15
  40b827:	pop    r14
  40b829:	pop    r13
  40b82b:	pop    r12
  40b82d:	ret
  40b82e:	cmp    r12,0x200000
  40b835:	ja     40b8c7 <__swc_fn_3464c816_000061_b304235a+0x127>
  40b83b:	lea    rax,[rip+0x167c6]        # 422008 <__swc_data_base_3464c816+0x8>
  40b842:	mov    rax,QWORD PTR [rax]
  40b845:	cmp    rax,0xffffffffffffffff
  40b849:	je     40b858 <__swc_fn_3464c816_000061_b304235a+0xb8>
  40b84b:	mov    eax,eax
  40b84d:	mov    edi,eax
  40b84f:	xor    eax,eax
  40b851:	call   407000 <pthread_getspecific@plt>
  40b856:	jmp    40b85a <__swc_fn_3464c816_000061_b304235a+0xba>
  40b858:	xor    eax,eax
  40b85a:	test   rax,rax
  40b85d:	je     40b864 <__swc_fn_3464c816_000061_b304235a+0xc4>
  40b85f:	mov    rsi,rax
  40b862:	jmp    40b874 <__swc_fn_3464c816_000061_b304235a+0xd4>
  40b864:	call   40b140 <__swc_fn_3464c816_000034_cd1a4e8c>
  40b869:	mov    rcx,rax
  40b86c:	call   410440 <__swc_fn_3464c816_000131_5f757033>
  40b871:	mov    rsi,rax
  40b874:	test   rsi,rsi
  40b877:	je     40b8c7 <__swc_fn_3464c816_000061_b304235a+0x127>
  40b879:	cmp    QWORD PTR [rsi],r13
  40b87c:	jne    40b8c7 <__swc_fn_3464c816_000061_b304235a+0x127>
  40b87e:	cmp    DWORD PTR [rsi+0x20],0x0
  40b882:	jne    40b8c7 <__swc_fn_3464c816_000061_b304235a+0x127>
  40b884:	cmp    DWORD PTR [rsi+0x730],0x10
  40b88b:	jae    40b8c7 <__swc_fn_3464c816_000061_b304235a+0x127>
  40b88d:	mov    eax,DWORD PTR [rsi+0x730]
  40b893:	lea    rdi,[rax+rax*4]
  40b897:	lea    rdi,[rsi+rdi*8+0x738]
  40b89f:	mov    QWORD PTR [rdi],r14
  40b8a2:	mov    QWORD PTR [rdi+0x8],r15
  40b8a6:	mov    QWORD PTR [rdi+0x10],r12
  40b8aa:	mov    QWORD PTR [rdi+0x18],0x0
  40b8b2:	call   4104f0 <__swc_fn_3464c816_000134_07d76562>
  40b8b7:	mov    QWORD PTR [rdi+0x20],rax
  40b8bb:	add    DWORD PTR [rsi+0x730],0x1
  40b8c2:	jmp    40ba26 <__swc_fn_3464c816_000061_b304235a+0x286>
  40b8c7:	mov    rcx,r13
  40b8ca:	call   408630 <__swc_fn_3464c816_000060_ad030a10>
  40b8cf:	mov    rsi,rax
  40b8d2:	cmp    r12,rax
  40b8d5:	jbe    40b90a <__swc_fn_3464c816_000061_b304235a+0x16a>
  40b8d7:	cmp    r12,0x10000000
  40b8de:	seta   al
  40b8e1:	ja     40b8f0 <__swc_fn_3464c816_000061_b304235a+0x150>
  40b8e3:	mov    rax,QWORD PTR [r13+0x2a70]
  40b8ea:	test   rax,rax
  40b8ed:	setne  al
  40b8f0:	test   al,al
  40b8f2:	je     40b90a <__swc_fn_3464c816_000061_b304235a+0x16a>
  40b8f4:	mov    rcx,r13
  40b8f7:	mov    rdx,r14
  40b8fa:	mov    r8,r15
  40b8fd:	mov    r9,r12
  40b900:	call   407ef0 <__swc_fn_3464c816_000042_d3c2ab54>
  40b905:	jmp    40ba26 <__swc_fn_3464c816_000061_b304235a+0x286>
  40b90a:	call   4104f0 <__swc_fn_3464c816_000134_07d76562>
  40b90f:	mov    rdi,rax
  40b912:	mov    rcx,r13
  40b915:	call   40a040 <__swc_fn_3464c816_000138_86bb0f90>
  40b91a:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b922:	je     40b9da <__swc_fn_3464c816_000061_b304235a+0x23a>
  40b928:	nop    DWORD PTR [rax+rax*1+0x0]
  40b930:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b93b:	jae    40b950 <__swc_fn_3464c816_000061_b304235a+0x1b0>
  40b93d:	mov    rax,QWORD PTR [r13+0x2a68]
  40b944:	add    rax,r12
  40b947:	cmp    rax,rsi
  40b94a:	jbe    40b9da <__swc_fn_3464c816_000061_b304235a+0x23a>
  40b950:	xor    eax,eax
  40b952:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b959:	mov    edx,0x1
  40b95e:	cmp    rcx,0x1
  40b962:	jbe    40b999 <__swc_fn_3464c816_000061_b304235a+0x1f9>
  40b964:	cs nop WORD PTR [rax+rax*1+0x0]
  40b96e:	xchg   ax,ax
  40b970:	lea    r8,[rdx+rdx*4]
  40b974:	lea    r8,[r13+r8*8+0x268]
  40b97c:	lea    r9,[rax+rax*4]
  40b980:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b988:	cmp    QWORD PTR [r8+0x18],r9
  40b98c:	cmovb  rax,rdx
  40b990:	add    rdx,0x1
  40b994:	cmp    rdx,rcx
  40b997:	jb     40b970 <__swc_fn_3464c816_000061_b304235a+0x1d0>
  40b999:	lea    rcx,[rax+rax*4]
  40b99d:	lea    rcx,[r13+rcx*8+0x268]
  40b9a5:	mov    r8,QWORD PTR [rcx]
  40b9a8:	mov    r9,QWORD PTR [rcx+0x8]
  40b9ac:	mov    r10,QWORD PTR [rcx+0x10]
  40b9b0:	mov    rcx,r13
  40b9b3:	mov    rdx,rax
  40b9b6:	call   40e800 <__swc_fn_3464c816_000059_15c28ca7>
  40b9bb:	mov    rcx,r13
  40b9be:	mov    rdx,r8
  40b9c1:	mov    r8,r9
  40b9c4:	mov    r9,r10
  40b9c7:	call   407ef0 <__swc_fn_3464c816_000042_d3c2ab54>
  40b9cc:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b9d4:	jne    40b930 <__swc_fn_3464c816_000061_b304235a+0x190>
  40b9da:	add    QWORD PTR [r13+0x2a78],0x1
  40b9e2:	mov    rax,QWORD PTR [r13+0x2a70]
  40b9e9:	lea    rax,[rax+rax*4]
  40b9ed:	lea    rax,[r13+rax*8+0x268]
  40b9f5:	mov    QWORD PTR [rax],r14
  40b9f8:	mov    QWORD PTR [rax+0x8],r15
  40b9fc:	mov    QWORD PTR [rax+0x10],r12
  40ba00:	mov    rcx,QWORD PTR [r13+0x2a78]
  40ba07:	mov    QWORD PTR [rax+0x18],rcx
  40ba0b:	mov    QWORD PTR [rax+0x20],rdi
  40ba0f:	add    QWORD PTR [r13+0x2a68],r12
  40ba16:	add    QWORD PTR [r13+0x2a70],0x1
  40ba1e:	mov    rcx,r13
  40ba21:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40ba26:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40ba2f:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40ba38:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40ba41:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40ba4a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40ba53:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40ba5c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40ba65:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40ba6e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40ba77:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40ba80:	add    rsp,0x148
  40ba87:	pop    rsi
  40ba88:	pop    rdi
  40ba89:	pop    r15
  40ba8b:	pop    r14
  40ba8d:	pop    r13
  40ba8f:	pop    r12
  40ba91:	ret
	...

000000000040baa0 <__swc_fn_3464c816_000064_d9ee99ea>:
  40baa0:	push   rbx
  40baa1:	push   r12
  40baa3:	push   r13
  40baa5:	push   r14
  40baa7:	push   r15
  40baa9:	push   rdi
  40baaa:	push   rsi
  40baab:	sub    rsp,0xf0
  40bab2:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40bab8:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40babe:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40bac4:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40baca:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40bad3:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40badc:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40bae5:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40baee:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40baf7:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40bb00:	mov    eax,r8d
  40bb03:	mov    rbx,rcx
  40bb06:	mov    r12,rdx
  40bb09:	mov    QWORD PTR [rsp+0x18],rdx
  40bb0e:	mov    ecx,DWORD PTR [r12+0x58]
  40bb13:	mov    r13d,ecx
  40bb16:	cmp    ecx,0x10
  40bb19:	mov    ecx,0x10
  40bb1e:	cmovb  r13d,ecx
  40bb22:	test   r13d,r13d
  40bb25:	mov    rcx,r13
  40bb28:	mov    edx,0x8
  40bb2d:	cmove  ecx,edx
  40bb30:	dec    rcx
  40bb33:	mov    rdx,0xffffffffffffffff
  40bb3a:	sub    rdx,rcx
  40bb3d:	xor    r14d,r14d
  40bb40:	mov    r8,rcx
  40bb43:	not    r8
  40bb46:	lea    rcx,[rcx+0x58]
  40bb4a:	and    rcx,r8
  40bb4d:	cmp    rdx,0x58
  40bb51:	cmovae r14,rcx
  40bb55:	cmp    eax,0xffffffff
  40bb58:	jne    40bb61 <__swc_fn_3464c816_000064_d9ee99ea+0xc1>
  40bb5a:	mov    r15,QWORD PTR [r12+0x48]
  40bb5f:	jmp    40bb93 <__swc_fn_3464c816_000064_d9ee99ea+0xf3>
  40bb61:	test   eax,eax
  40bb63:	jne    40bb6c <__swc_fn_3464c816_000064_d9ee99ea+0xcc>
  40bb65:	mov    eax,0x8
  40bb6a:	jmp    40bb90 <__swc_fn_3464c816_000064_d9ee99ea+0xf0>
  40bb6c:	cmp    eax,0x8
  40bb6f:	ja     40bb77 <__swc_fn_3464c816_000064_d9ee99ea+0xd7>
  40bb71:	shl    rax,0x4
  40bb75:	jmp    40bb90 <__swc_fn_3464c816_000064_d9ee99ea+0xf0>
  40bb77:	lea    eax,[rax-0x9]
  40bb7a:	mov    ecx,eax
  40bb7c:	shr    ecx,0x2
  40bb7f:	and    eax,0x3
  40bb82:	lea    ecx,[rcx+0x7]
  40bb85:	lea    ecx,[rcx-0x2]
  40bb88:	lea    eax,[rax+0x5]
  40bb8b:	shlx   rax,rax,rcx
  40bb90:	mov    r15,rax
  40bb93:	lea    rax,[r14+r13*1]
  40bb97:	mov    rcx,0xffffffffffffffff
  40bb9e:	sub    rcx,rax
  40bba1:	cmp    r15,rcx
  40bba4:	jbe    40bbb4 <__swc_fn_3464c816_000064_d9ee99ea+0x114>
  40bba6:	mov    QWORD PTR [r12+0x40],0x0
  40bbaf:	jmp    40bf86 <__swc_fn_3464c816_000064_d9ee99ea+0x4e6>
  40bbb4:	mov    QWORD PTR [rsp+0x20],r13
  40bbb9:	lea    r13,[rsp+0x8]
  40bbbe:	add    rax,r15
  40bbc1:	mov    ecx,0x1000
  40bbc6:	test   ecx,ecx
  40bbc8:	mov    edx,0x8
  40bbcd:	cmove  ecx,edx
  40bbd0:	dec    rcx
  40bbd3:	mov    rdx,0xffffffffffffffff
  40bbda:	sub    rdx,rcx
  40bbdd:	cmp    rax,rdx
  40bbe0:	jbe    40bbec <__swc_fn_3464c816_000064_d9ee99ea+0x14c>
  40bbe2:	mov    QWORD PTR [r13+0x0],0x0
  40bbea:	jmp    40bbf9 <__swc_fn_3464c816_000064_d9ee99ea+0x159>
  40bbec:	add    rax,rcx
  40bbef:	andn   rax,rcx,rax
  40bbf4:	mov    QWORD PTR [rsp+0x8],rax
  40bbf9:	cmp    QWORD PTR [r13+0x0],0x0
  40bbfe:	jne    40bc0e <__swc_fn_3464c816_000064_d9ee99ea+0x16e>
  40bc00:	mov    QWORD PTR [r12+0x40],0x0
  40bc09:	jmp    40bf86 <__swc_fn_3464c816_000064_d9ee99ea+0x4e6>
  40bc0e:	mov    QWORD PTR [rsp+0x30],r15
  40bc13:	xor    r15d,r15d
  40bc16:	mov    QWORD PTR [rsp+0x38],0x0
  40bc1f:	lea    r12,[rsp+0x10]
  40bc24:	mov    QWORD PTR [rsp+0x28],r14
  40bc29:	mov    r14,QWORD PTR [rsp+0x8]
  40bc2e:	mov    QWORD PTR [rsp+0x10],r14
  40bc33:	cmp    r14,0x10000
  40bc3a:	ja     40bc41 <__swc_fn_3464c816_000064_d9ee99ea+0x1a1>
  40bc3c:	mov    rax,r14
  40bc3f:	jmp    40bc92 <__swc_fn_3464c816_000064_d9ee99ea+0x1f2>
  40bc41:	xor    eax,eax
  40bc43:	lea    rcx,[r14-0x1]
  40bc47:	lzcnt  rax,rcx
  40bc4c:	mov    ecx,0x3f
  40bc51:	sub    rcx,rax
  40bc54:	mov    eax,0x1
  40bc59:	lea    rcx,[rcx-0x3]
  40bc5d:	shl    rax,cl
  40bc60:	mov    rcx,rax
  40bc63:	cmp    rax,0x1000
  40bc6a:	mov    eax,0x1000
  40bc6f:	cmovb  rcx,rax
  40bc73:	mov    rdx,0xffffffffffffffff
  40bc7a:	sub    rdx,rcx
  40bc7d:	mov    rax,r14
  40bc80:	lea    r8,[r14+rcx*1-0x1]
  40bc85:	neg    rcx
  40bc88:	and    r8,rcx
  40bc8b:	cmp    r14,rdx
  40bc8e:	cmovbe rax,r8
  40bc92:	mov    QWORD PTR [rsp+0x8],rax
  40bc97:	lea    rax,[rip+0x1636a]        # 422008 <__swc_data_base_3464c816+0x8>
  40bc9e:	mov    rax,QWORD PTR [rax]
  40bca1:	cmp    rax,0xffffffffffffffff
  40bca5:	je     40bcb4 <__swc_fn_3464c816_000064_d9ee99ea+0x214>
  40bca7:	mov    eax,eax
  40bca9:	mov    edi,eax
  40bcab:	xor    eax,eax
  40bcad:	call   407000 <pthread_getspecific@plt>
  40bcb2:	jmp    40bcb6 <__swc_fn_3464c816_000064_d9ee99ea+0x216>
  40bcb4:	xor    eax,eax
  40bcb6:	test   rax,rax
  40bcb9:	jne    40bcc8 <__swc_fn_3464c816_000064_d9ee99ea+0x228>
  40bcbb:	call   40b140 <__swc_fn_3464c816_000034_cd1a4e8c>
  40bcc0:	mov    rcx,rax
  40bcc3:	call   410440 <__swc_fn_3464c816_000131_5f757033>
  40bcc8:	test   rax,rax
  40bccb:	je     40bdbc <__swc_fn_3464c816_000064_d9ee99ea+0x31c>
  40bcd1:	cmp    QWORD PTR [rax],rbx
  40bcd4:	jne    40bdbc <__swc_fn_3464c816_000064_d9ee99ea+0x31c>
  40bcda:	cmp    DWORD PTR [rax+0x20],0x0
  40bcde:	jne    40bdbc <__swc_fn_3464c816_000064_d9ee99ea+0x31c>
  40bce4:	mov    rcx,QWORD PTR [rsp+0x8]
  40bce9:	movabs rdx,0x7fffffffffffffff
  40bcf3:	cmp    rcx,rdx
  40bcf6:	mov    rdx,0xffffffffffffffff
  40bcfd:	lea    r8,[rcx+rcx*1]
  40bd01:	cmovbe rdx,r8
  40bd05:	mov    r8d,DWORD PTR [rax+0x730]
  40bd0c:	mov    r9d,r8d
  40bd0f:	sub    rdx,rcx
  40bd12:	inc    rdx
  40bd15:	xor    r10d,r10d
  40bd18:	test   r8,r8
  40bd1b:	jbe    40bd4b <__swc_fn_3464c816_000064_d9ee99ea+0x2ab>
  40bd1d:	nop    DWORD PTR [rax]
  40bd20:	mov    r11d,r10d
  40bd23:	lea    r11,[r11+r11*4]
  40bd27:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40bd2f:	sub    r11,rcx
  40bd32:	cmp    r11,rdx
  40bd35:	jae    40bd42 <__swc_fn_3464c816_000064_d9ee99ea+0x2a2>
  40bd37:	mov    r9d,r10d
  40bd3a:	mov    rdx,r11
  40bd3d:	test   r11,r11
  40bd40:	je     40bd4b <__swc_fn_3464c816_000064_d9ee99ea+0x2ab>
  40bd42:	add    r10,0x1
  40bd46:	cmp    r10,r8
  40bd49:	jb     40bd20 <__swc_fn_3464c816_000064_d9ee99ea+0x280>
  40bd4b:	mov    ecx,DWORD PTR [rax+0x730]
  40bd51:	cmp    r9d,ecx
  40bd54:	jne    40bd5a <__swc_fn_3464c816_000064_d9ee99ea+0x2ba>
  40bd56:	xor    eax,eax
  40bd58:	jmp    40bdb9 <__swc_fn_3464c816_000064_d9ee99ea+0x319>
  40bd5a:	lea    rcx,[r9+r9*4]
  40bd5e:	lea    rcx,[rax+rcx*8+0x738]
  40bd66:	vmovups xmm0,XMMWORD PTR [rcx]
  40bd6a:	mov    rdx,QWORD PTR [rcx+0x10]
  40bd6e:	sub    DWORD PTR [rax+0x730],0x1
  40bd75:	mov    r8d,DWORD PTR [rax+0x730]
  40bd7c:	lea    r8,[r8+r8*4]
  40bd80:	lea    r8,[rax+r8*8+0x738]
  40bd88:	vmovups xmm1,XMMWORD PTR [r8]
  40bd8d:	vmovups XMMWORD PTR [rcx],xmm1
  40bd91:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40bd97:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40bd9c:	mov    rax,QWORD PTR [r8+0x20]
  40bda0:	mov    QWORD PTR [rcx+0x20],rax
  40bda4:	vpshufd xmm1,xmm0,0xee
  40bda9:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40bdaf:	mov    QWORD PTR [rsp+0x10],rdx
  40bdb4:	vmovq  rax,xmm0
  40bdb9:	mov    r15,rax
  40bdbc:	test   r15,r15
  40bdbf:	jne    40bdd7 <__swc_fn_3464c816_000064_d9ee99ea+0x337>
  40bdc1:	mov    rcx,rbx
  40bdc4:	mov    rdx,QWORD PTR [rsp+0x8]
  40bdc9:	mov    r8,r13
  40bdcc:	mov    r9,r12
  40bdcf:	call   40b690 <__swc_fn_3464c816_000058_2ca0cb05>
  40bdd4:	mov    r15,rax
  40bdd7:	test   r15,r15
  40bdda:	je     40be1b <__swc_fn_3464c816_000064_d9ee99ea+0x37b>
  40bddc:	cmp    QWORD PTR [r12],r14
  40bde0:	jae    40be1b <__swc_fn_3464c816_000064_d9ee99ea+0x37b>
  40bde2:	mov    rax,r15
  40bde5:	add    rax,QWORD PTR [r12]
  40bde9:	mov    rdx,r14
  40bdec:	sub    rdx,QWORD PTR [r12]
  40bdf0:	mov    rcx,rax
  40bdf3:	call   407a40 <__swc_fn_3464c816_000006_f7acedb0>
  40bdf8:	test   al,al
  40bdfa:	je     40be03 <__swc_fn_3464c816_000064_d9ee99ea+0x363>
  40bdfc:	mov    QWORD PTR [rsp+0x10],r14
  40be01:	jmp    40be1b <__swc_fn_3464c816_000064_d9ee99ea+0x37b>
  40be03:	mov    rcx,rbx
  40be06:	mov    rdx,r15
  40be09:	mov    r8,QWORD PTR [rsp+0x8]
  40be0e:	mov    r9,QWORD PTR [rsp+0x10]
  40be13:	call   40b7a0 <__swc_fn_3464c816_000061_b304235a>
  40be18:	xor    r15d,r15d
  40be1b:	test   r15,r15
  40be1e:	jne    40be9a <__swc_fn_3464c816_000064_d9ee99ea+0x3fa>
  40be20:	cmp    r14,0x10000
  40be27:	ja     40be2e <__swc_fn_3464c816_000064_d9ee99ea+0x38e>
  40be29:	mov    rax,r14
  40be2c:	jmp    40be7f <__swc_fn_3464c816_000064_d9ee99ea+0x3df>
  40be2e:	xor    eax,eax
  40be30:	lea    rcx,[r14-0x1]
  40be34:	lzcnt  rax,rcx
  40be39:	mov    ecx,0x3f
  40be3e:	sub    rcx,rax
  40be41:	mov    eax,0x1
  40be46:	lea    rcx,[rcx-0x3]
  40be4a:	shl    rax,cl
  40be4d:	mov    rcx,rax
  40be50:	cmp    rax,0x1000
  40be57:	mov    eax,0x1000
  40be5c:	cmovb  rcx,rax
  40be60:	mov    rdx,0xffffffffffffffff
  40be67:	sub    rdx,rcx
  40be6a:	mov    rax,r14
  40be6d:	lea    r8,[r14+rcx*1-0x1]
  40be72:	neg    rcx
  40be75:	and    r8,rcx
  40be78:	cmp    r14,rdx
  40be7b:	cmovbe rax,r8
  40be7f:	mov    QWORD PTR [rsp+0x8],rax
  40be84:	mov    QWORD PTR [rsp+0x10],r14
  40be89:	mov    rcx,rbx
  40be8c:	mov    rdx,rax
  40be8f:	mov    r8,r14
  40be92:	call   40b200 <__swc_fn_3464c816_000040_c90d80c1>
  40be97:	mov    r15,rax
  40be9a:	test   r15,r15
  40be9d:	jne    40beab <__swc_fn_3464c816_000064_d9ee99ea+0x40b>
  40be9f:	mov    r13,QWORD PTR [rsp+0x20]
  40bea4:	mov    rsi,QWORD PTR [rsp+0x38]
  40bea9:	jmp    40bee7 <__swc_fn_3464c816_000064_d9ee99ea+0x447>
  40beab:	mov    rax,r15
  40beae:	add    rax,QWORD PTR [rsp+0x28]
  40beb3:	mov    r13,QWORD PTR [rsp+0x20]
  40beb8:	test   r13d,r13d
  40bebb:	mov    rcx,r13
  40bebe:	mov    edx,0x8
  40bec3:	cmove  ecx,edx
  40bec6:	dec    rcx
  40bec9:	mov    rdx,0xffffffffffffffff
  40bed0:	sub    rdx,rcx
  40bed3:	cmp    rax,rdx
  40bed6:	jbe    40bedc <__swc_fn_3464c816_000064_d9ee99ea+0x43c>
  40bed8:	xor    eax,eax
  40beda:	jmp    40bee4 <__swc_fn_3464c816_000064_d9ee99ea+0x444>
  40bedc:	add    rax,rcx
  40bedf:	andn   rax,rcx,rax
  40bee4:	mov    rsi,rax
  40bee7:	mov    rax,QWORD PTR [rsp+0x8]
  40beec:	test   r15,r15
  40beef:	je     40bef8 <__swc_fn_3464c816_000064_d9ee99ea+0x458>
  40bef1:	mov    rdi,QWORD PTR [rsp+0x18]
  40bef6:	jmp    40bf0a <__swc_fn_3464c816_000064_d9ee99ea+0x46a>
  40bef8:	mov    rdi,QWORD PTR [rsp+0x18]
  40befd:	mov    QWORD PTR [rdi+0x40],0x0
  40bf05:	jmp    40bf86 <__swc_fn_3464c816_000064_d9ee99ea+0x4e6>
  40bf0a:	lea    rdx,[rsi-0x58]
  40bf0e:	mov    QWORD PTR [rsi-0x58],r15
  40bf12:	mov    QWORD PTR [rsi-0x50],rax
  40bf16:	mov    rax,QWORD PTR [rsp+0x10]
  40bf1b:	mov    QWORD PTR [rsi-0x48],rax
  40bf1f:	mov    QWORD PTR [rsi-0x40],rsi
  40bf23:	mov    rax,QWORD PTR [rdi+0x48]
  40bf27:	mov    QWORD PTR [rsi-0x38],rax
  40bf2b:	mov    rax,QWORD PTR [rsp+0x30]
  40bf30:	mov    QWORD PTR [rsi-0x30],rax
  40bf34:	mov    DWORD PTR [rsi-0x10],r13d
  40bf38:	mov    QWORD PTR [rsi-0x28],0x0
  40bf40:	mov    QWORD PTR [rsi-0x20],0x0
  40bf48:	add    r15,QWORD PTR [r12]
  40bf4c:	sub    r15,rsi
  40bf4f:	mov    QWORD PTR [rsi-0x30],r15
  40bf53:	mov    rcx,QWORD PTR [rbx+0x250]
  40bf5a:	nop    WORD PTR [rax+rax*1+0x0]
  40bf60:	lea    r8,[rcx+r15*1]
  40bf64:	mov    rax,rcx
  40bf67:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40bf70:	cmp    rax,rcx
  40bf73:	je     40bf7a <__swc_fn_3464c816_000064_d9ee99ea+0x4da>
  40bf75:	mov    rcx,rax
  40bf78:	jmp    40bf60 <__swc_fn_3464c816_000064_d9ee99ea+0x4c0>
  40bf7a:	mov    rcx,rbx
  40bf7d:	call   40e770 <__swc_fn_3464c816_000056_7e1dbcb0>
  40bf82:	mov    QWORD PTR [rdi+0x40],rsi
  40bf86:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40bf8c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40bf92:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40bf98:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40bf9e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40bfa7:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40bfb0:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40bfb9:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40bfc2:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40bfcb:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40bfd4:	add    rsp,0xf0
  40bfdb:	pop    rsi
  40bfdc:	pop    rdi
  40bfdd:	pop    r15
  40bfdf:	pop    r14
  40bfe1:	pop    r13
  40bfe3:	pop    r12
  40bfe5:	pop    rbx
  40bfe6:	ret
	...

000000000040bff0 <__swc_fn_3464c816_000067_f3aa21af>:
  40bff0:	push   rbx
  40bff1:	push   r12
  40bff3:	push   rdi
  40bff4:	push   rsi
  40bff5:	sub    rsp,0xb8
  40bffc:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40c002:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40c008:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40c00e:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40c014:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40c01a:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40c020:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40c026:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40c02f:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40c038:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40c041:	mov    rbx,rdx
  40c044:	mov    r12,rcx
  40c047:	cmp    DWORD PTR [rbx+0x58],0x0
  40c04b:	je     40c065 <__swc_fn_3464c816_000067_f3aa21af+0x75>
  40c04d:	mov    eax,DWORD PTR [rbx+0x58]
  40c050:	sub    eax,0x1
  40c053:	test   DWORD PTR [rbx+0x58],eax
  40c056:	je     40c065 <__swc_fn_3464c816_000067_f3aa21af+0x75>
  40c058:	mov    QWORD PTR [rbx+0x40],0x0
  40c060:	jmp    40c277 <__swc_fn_3464c816_000067_f3aa21af+0x287>
  40c065:	cmp    QWORD PTR [rbx+0x48],0x0
  40c06a:	jne    40c079 <__swc_fn_3464c816_000067_f3aa21af+0x89>
  40c06c:	mov    QWORD PTR [rbx+0x40],0x0
  40c074:	jmp    40c277 <__swc_fn_3464c816_000067_f3aa21af+0x287>
  40c079:	lea    rax,[rsp+0x8]
  40c07e:	mov    rcx,QWORD PTR [rbx+0x48]
  40c082:	cmp    rcx,0x8
  40c086:	ja     40c090 <__swc_fn_3464c816_000067_f3aa21af+0xa0>
  40c088:	mov    DWORD PTR [rax],0x0
  40c08e:	jmp    40c0eb <__swc_fn_3464c816_000067_f3aa21af+0xfb>
  40c090:	cmp    rcx,0x80
  40c097:	ja     40c0a7 <__swc_fn_3464c816_000067_f3aa21af+0xb7>
  40c099:	lea    rcx,[rcx+0xf]
  40c09d:	shr    rcx,0x4
  40c0a1:	mov    DWORD PTR [rsp+0x8],ecx
  40c0a5:	jmp    40c0eb <__swc_fn_3464c816_000067_f3aa21af+0xfb>
  40c0a7:	cmp    rcx,0x10000
  40c0ae:	jbe    40c0b8 <__swc_fn_3464c816_000067_f3aa21af+0xc8>
  40c0b0:	mov    DWORD PTR [rax],0xffffffff
  40c0b6:	jmp    40c0eb <__swc_fn_3464c816_000067_f3aa21af+0xfb>
  40c0b8:	dec    rcx
  40c0bb:	xor    edx,edx
  40c0bd:	lzcnt  rdx,rcx
  40c0c2:	mov    r8d,0x3f
  40c0c8:	sub    r8d,edx
  40c0cb:	lea    edx,[r8-0x2]
  40c0cf:	shrx   rcx,rcx,rdx
  40c0d4:	and    ecx,0x3
  40c0d7:	lea    edx,[r8-0x7]
  40c0db:	lea    edx,[rdx*4+0x0]
  40c0e2:	lea    edx,[rdx+0x9]
  40c0e5:	add    edx,ecx
  40c0e7:	mov    DWORD PTR [rsp+0x8],edx
  40c0eb:	cmp    DWORD PTR [rax],0x0
  40c0ee:	jne    40c0fe <__swc_fn_3464c816_000067_f3aa21af+0x10e>
  40c0f0:	cmp    DWORD PTR [rbx+0x58],0x8
  40c0f4:	jbe    40c0fe <__swc_fn_3464c816_000067_f3aa21af+0x10e>
  40c0f6:	mov    DWORD PTR [rsp+0x8],0x1
  40c0fe:	cmp    DWORD PTR [rbx+0x58],0x10
  40c102:	jbe    40c181 <__swc_fn_3464c816_000067_f3aa21af+0x191>
  40c108:	cmp    DWORD PTR [rbx+0x58],0x40
  40c10c:	ja     40c181 <__swc_fn_3464c816_000067_f3aa21af+0x191>
  40c10e:	cmp    DWORD PTR [rax],0xffffffff
  40c111:	je     40c181 <__swc_fn_3464c816_000067_f3aa21af+0x191>
  40c113:	mov    ecx,DWORD PTR [rsp+0x8]
  40c117:	mov    edx,DWORD PTR [rbx+0x58]
  40c11a:	dec    rdx
  40c11d:	cmp    ecx,0x2d
  40c120:	jae    40c178 <__swc_fn_3464c816_000067_f3aa21af+0x188>
  40c122:	cs nop WORD PTR [rax+rax*1+0x0]
  40c12c:	nop    DWORD PTR [rax+0x0]
  40c130:	mov    r8d,ecx
  40c133:	test   ecx,ecx
  40c135:	jne    40c13f <__swc_fn_3464c816_000067_f3aa21af+0x14f>
  40c137:	mov    r8d,0x8
  40c13d:	jmp    40c16b <__swc_fn_3464c816_000067_f3aa21af+0x17b>
  40c13f:	cmp    r8d,0x8
  40c143:	ja     40c14b <__swc_fn_3464c816_000067_f3aa21af+0x15b>
  40c145:	shl    r8,0x4
  40c149:	jmp    40c16b <__swc_fn_3464c816_000067_f3aa21af+0x17b>
  40c14b:	lea    r8d,[r8-0x9]
  40c14f:	mov    r9d,r8d
  40c152:	shr    r9d,0x2
  40c156:	and    r8d,0x3
  40c15a:	lea    r9d,[r9+0x7]
  40c15e:	lea    r9d,[r9-0x2]
  40c162:	lea    r8d,[r8+0x5]
  40c166:	shlx   r8,r8,r9
  40c16b:	test   r8,rdx
  40c16e:	je     40c17d <__swc_fn_3464c816_000067_f3aa21af+0x18d>
  40c170:	add    ecx,0x1
  40c173:	cmp    ecx,0x2d
  40c176:	jb     40c130 <__swc_fn_3464c816_000067_f3aa21af+0x140>
  40c178:	mov    ecx,0xffffffff
  40c17d:	mov    DWORD PTR [rsp+0x8],ecx
  40c181:	mov    ecx,DWORD PTR [rsp+0x8]
  40c185:	cmp    ecx,0xffffffff
  40c188:	je     40c190 <__swc_fn_3464c816_000067_f3aa21af+0x1a0>
  40c18a:	cmp    DWORD PTR [rbx+0x58],0x40
  40c18e:	jbe    40c1a3 <__swc_fn_3464c816_000067_f3aa21af+0x1b3>
  40c190:	mov    rcx,r12
  40c193:	mov    rdx,rbx
  40c196:	mov    r8d,DWORD PTR [rax]
  40c199:	call   40baa0 <__swc_fn_3464c816_000064_d9ee99ea>
  40c19e:	jmp    40c277 <__swc_fn_3464c816_000067_f3aa21af+0x287>
  40c1a3:	lea    rax,[rip+0x15e5e]        # 422008 <__swc_data_base_3464c816+0x8>
  40c1aa:	mov    rax,QWORD PTR [rax]
  40c1ad:	cmp    rax,0xffffffffffffffff
  40c1b1:	je     40c1c0 <__swc_fn_3464c816_000067_f3aa21af+0x1d0>
  40c1b3:	mov    eax,eax
  40c1b5:	mov    edi,eax
  40c1b7:	xor    eax,eax
  40c1b9:	call   407000 <pthread_getspecific@plt>
  40c1be:	jmp    40c1c2 <__swc_fn_3464c816_000067_f3aa21af+0x1d2>
  40c1c0:	xor    eax,eax
  40c1c2:	test   rax,rax
  40c1c5:	jne    40c1d4 <__swc_fn_3464c816_000067_f3aa21af+0x1e4>
  40c1c7:	call   40b140 <__swc_fn_3464c816_000034_cd1a4e8c>
  40c1cc:	mov    rcx,rax
  40c1cf:	call   410440 <__swc_fn_3464c816_000131_5f757033>
  40c1d4:	test   rax,rax
  40c1d7:	je     40c1e4 <__swc_fn_3464c816_000067_f3aa21af+0x1f4>
  40c1d9:	cmp    QWORD PTR [rax],r12
  40c1dc:	jne    40c1e4 <__swc_fn_3464c816_000067_f3aa21af+0x1f4>
  40c1de:	cmp    DWORD PTR [rax+0x20],0x0
  40c1e2:	je     40c1ef <__swc_fn_3464c816_000067_f3aa21af+0x1ff>
  40c1e4:	mov    rcx,r12
  40c1e7:	mov    rdx,rax
  40c1ea:	call   40e3b0 <__swc_fn_3464c816_000044_d8bd27c3>
  40c1ef:	test   rax,rax
  40c1f2:	jne    40c1fe <__swc_fn_3464c816_000067_f3aa21af+0x20e>
  40c1f4:	mov    QWORD PTR [rbx+0x40],0x0
  40c1fc:	jmp    40c277 <__swc_fn_3464c816_000067_f3aa21af+0x287>
  40c1fe:	lea    r8,[rsp+0xc]
  40c203:	mov    ecx,DWORD PTR [rsp+0x8]
  40c207:	mov    DWORD PTR [rsp+0xc],ecx
  40c20b:	mov    ecx,DWORD PTR [r8]
  40c20e:	lea    rcx,[rcx+rcx*4]
  40c212:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40c217:	test   rcx,rcx
  40c21a:	je     40c253 <__swc_fn_3464c816_000067_f3aa21af+0x263>
  40c21c:	mov    rdx,QWORD PTR [rcx]
  40c21f:	test   rdx,rdx
  40c222:	je     40c230 <__swc_fn_3464c816_000067_f3aa21af+0x240>
  40c224:	mov    r9,QWORD PTR [rdx]
  40c227:	mov    QWORD PTR [rcx],r9
  40c22a:	add    DWORD PTR [rcx+0x28],0x1
  40c22e:	jmp    40c24e <__swc_fn_3464c816_000067_f3aa21af+0x25e>
  40c230:	mov    rdx,QWORD PTR [rcx+0x18]
  40c234:	cmp    QWORD PTR [rcx+0x20],rdx
  40c238:	jae    40c24c <__swc_fn_3464c816_000067_f3aa21af+0x25c>
  40c23a:	mov    rdx,QWORD PTR [rcx+0x20]
  40c23e:	mov    r9d,DWORD PTR [rcx+0x2c]
  40c242:	add    QWORD PTR [rcx+0x20],r9
  40c246:	add    DWORD PTR [rcx+0x28],0x1
  40c24a:	jmp    40c24e <__swc_fn_3464c816_000067_f3aa21af+0x25e>
  40c24c:	xor    edx,edx
  40c24e:	test   rdx,rdx
  40c251:	jne    40c264 <__swc_fn_3464c816_000067_f3aa21af+0x274>
  40c253:	mov    rcx,r12
  40c256:	mov    rdx,rax
  40c259:	mov    r8d,DWORD PTR [r8]
  40c25c:	call   40e520 <__swc_fn_3464c816_000053_faa92dcc>
  40c261:	mov    rdx,rax
  40c264:	test   rdx,rdx
  40c267:	jne    40c273 <__swc_fn_3464c816_000067_f3aa21af+0x283>
  40c269:	mov    QWORD PTR [rbx+0x40],0x0
  40c271:	jmp    40c277 <__swc_fn_3464c816_000067_f3aa21af+0x287>
  40c273:	mov    QWORD PTR [rbx+0x40],rdx
  40c277:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40c27d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40c283:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40c289:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40c28f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40c295:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40c29b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40c2a1:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40c2aa:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40c2b3:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40c2bc:	add    rsp,0xb8
  40c2c3:	pop    rsi
  40c2c4:	pop    rdi
  40c2c5:	pop    r12
  40c2c7:	pop    rbx
  40c2c8:	ret
  40c2c9:	add    BYTE PTR [rax],al
  40c2cb:	add    BYTE PTR [rax],al
  40c2cd:	add    BYTE PTR [rax],al
	...

000000000040c2d0 <__swc_fn_3464c816_000070_b3d7b28e>:
  40c2d0:	ret
	...

000000000040c2e0 <__swc_fn_3464c816_000073_042643a3>:
  40c2e0:	push   r12
  40c2e2:	push   r13
  40c2e4:	push   r14
  40c2e6:	push   rdi
  40c2e7:	push   rsi
  40c2e8:	sub    rsp,0x1a0
  40c2ef:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40c2f8:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40c301:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40c30a:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40c313:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40c31c:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40c325:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40c32e:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40c337:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40c340:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40c349:	mov    r12,rdx
  40c34c:	mov    r13,rcx
  40c34f:	mov    rax,QWORD PTR [r12+0x48]
  40c354:	mov    ecx,DWORD PTR [r12+0x58]
  40c359:	lea    rdx,[rax-0x1]
  40c35d:	cmp    rdx,0x10000
  40c364:	jae    40c45e <__swc_fn_3464c816_000073_042643a3+0x17e>
  40c36a:	cmp    rax,0x8
  40c36e:	ja     40c375 <__swc_fn_3464c816_000073_042643a3+0x95>
  40c370:	xor    r14d,r14d
  40c373:	jmp    40c3c7 <__swc_fn_3464c816_000073_042643a3+0xe7>
  40c375:	cmp    rax,0x80
  40c37c:	ja     40c388 <__swc_fn_3464c816_000073_042643a3+0xa8>
  40c37e:	lea    r14,[rax+0xf]
  40c382:	shr    r14,0x4
  40c386:	jmp    40c3c7 <__swc_fn_3464c816_000073_042643a3+0xe7>
  40c388:	cmp    rax,0x10000
  40c38f:	jbe    40c399 <__swc_fn_3464c816_000073_042643a3+0xb9>
  40c391:	mov    r14d,0xffffffff
  40c397:	jmp    40c3c7 <__swc_fn_3464c816_000073_042643a3+0xe7>
  40c399:	xor    eax,eax
  40c39b:	lzcnt  rax,rdx
  40c3a0:	mov    r8d,0x3f
  40c3a6:	sub    r8d,eax
  40c3a9:	lea    eax,[r8-0x2]
  40c3ad:	shrx   rax,rdx,rax
  40c3b2:	and    eax,0x3
  40c3b5:	lea    edx,[r8-0x7]
  40c3b9:	lea    edx,[rdx*4+0x0]
  40c3c0:	lea    edx,[rdx+0x9]
  40c3c3:	lea    r14d,[rdx+rax*1]
  40c3c7:	cmp    ecx,0x8
  40c3ca:	jbe    40c3e3 <__swc_fn_3464c816_000073_042643a3+0x103>
  40c3cc:	cmp    ecx,0x10
  40c3cf:	jne    40c45e <__swc_fn_3464c816_000073_042643a3+0x17e>
  40c3d5:	test   r14d,r14d
  40c3d8:	mov    eax,0x1
  40c3dd:	cmove  r14d,eax
  40c3e1:	jmp    40c3ea <__swc_fn_3464c816_000073_042643a3+0x10a>
  40c3e3:	lea    eax,[rcx-0x1]
  40c3e6:	test   eax,ecx
  40c3e8:	jne    40c45e <__swc_fn_3464c816_000073_042643a3+0x17e>
  40c3ea:	lea    rax,[rip+0x15c17]        # 422008 <__swc_data_base_3464c816+0x8>
  40c3f1:	mov    rax,QWORD PTR [rax]
  40c3f4:	cmp    rax,0xffffffffffffffff
  40c3f8:	je     40c407 <__swc_fn_3464c816_000073_042643a3+0x127>
  40c3fa:	mov    eax,eax
  40c3fc:	mov    edi,eax
  40c3fe:	xor    eax,eax
  40c400:	call   407000 <pthread_getspecific@plt>
  40c405:	jmp    40c409 <__swc_fn_3464c816_000073_042643a3+0x129>
  40c407:	xor    eax,eax
  40c409:	test   rax,rax
  40c40c:	je     40c45e <__swc_fn_3464c816_000073_042643a3+0x17e>
  40c40e:	cmp    QWORD PTR [rax],r13
  40c411:	jne    40c45e <__swc_fn_3464c816_000073_042643a3+0x17e>
  40c413:	lea    rcx,[r14+r14*4]
  40c417:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40c41c:	test   rax,rax
  40c41f:	je     40c45e <__swc_fn_3464c816_000073_042643a3+0x17e>
  40c421:	mov    rcx,QWORD PTR [rax]
  40c424:	test   rcx,rcx
  40c427:	je     40c435 <__swc_fn_3464c816_000073_042643a3+0x155>
  40c429:	mov    rdx,QWORD PTR [rcx]
  40c42c:	mov    QWORD PTR [rax],rdx
  40c42f:	add    DWORD PTR [rax+0x28],0x1
  40c433:	jmp    40c452 <__swc_fn_3464c816_000073_042643a3+0x172>
  40c435:	mov    rcx,QWORD PTR [rax+0x18]
  40c439:	cmp    QWORD PTR [rax+0x20],rcx
  40c43d:	jae    40c450 <__swc_fn_3464c816_000073_042643a3+0x170>
  40c43f:	mov    rcx,QWORD PTR [rax+0x20]
  40c443:	mov    edx,DWORD PTR [rax+0x2c]
  40c446:	add    QWORD PTR [rax+0x20],rdx
  40c44a:	add    DWORD PTR [rax+0x28],0x1
  40c44e:	jmp    40c452 <__swc_fn_3464c816_000073_042643a3+0x172>
  40c450:	xor    ecx,ecx
  40c452:	test   rcx,rcx
  40c455:	je     40c45e <__swc_fn_3464c816_000073_042643a3+0x17e>
  40c457:	mov    QWORD PTR [r12+0x40],rcx
  40c45c:	jmp    40c469 <__swc_fn_3464c816_000073_042643a3+0x189>
  40c45e:	mov    rcx,r13
  40c461:	mov    rdx,r12
  40c464:	call   40efa0 <__swc_fn_3464c816_000074_64d36d78>
  40c469:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40c472:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40c47b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40c484:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40c48d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40c496:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40c49f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40c4a8:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40c4b1:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40c4ba:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40c4c3:	add    rsp,0x1a0
  40c4ca:	pop    rsi
  40c4cb:	pop    rdi
  40c4cc:	pop    r14
  40c4ce:	pop    r13
  40c4d0:	pop    r12
  40c4d2:	ret
	...

000000000040c4e0 <__swc_fn_3464c816_000076_7b195156>:
  40c4e0:	push   r12
  40c4e2:	push   r13
  40c4e4:	push   r14
  40c4e6:	push   r15
  40c4e8:	push   rdi
  40c4e9:	push   rsi
  40c4ea:	sub    rsp,0x188
  40c4f1:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40c4fa:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40c503:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40c50c:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40c515:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40c51e:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40c527:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40c530:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40c539:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40c542:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40c54b:	mov    r12,rdx
  40c54e:	mov    r13,rcx
  40c551:	mov    r14,QWORD PTR [r12+0x40]
  40c556:	lea    rax,[rip+0x17b1b]        # 424078 <__swc_bss_base_3464c816+0x38>
  40c55d:	mov    rcx,r14
  40c560:	sub    rcx,QWORD PTR [rax+0x8]
  40c564:	mov    rax,QWORD PTR [rip+0x17b1d]        # 424088 <__swc_bss_base_3464c816+0x48>
  40c56b:	cmp    rcx,rax
  40c56e:	jae    40c59a <__swc_fn_3464c816_000076_7b195156+0xba>
  40c570:	mov    rax,r14
  40c573:	and    rax,0xffffffffffc00000
  40c57a:	mov    rcx,r14
  40c57d:	shr    rcx,0x10
  40c581:	and    ecx,0x3f
  40c584:	mov    edx,DWORD PTR [rax+0x28]
  40c587:	shrx   ecx,ecx,edx
  40c58c:	shl    rcx,0x4
  40c590:	lea    r15,[rax+rcx*8+0x80]
  40c598:	jmp    40c5a5 <__swc_fn_3464c816_000076_7b195156+0xc5>
  40c59a:	mov    rcx,r14
  40c59d:	call   40b070 <__swc_fn_3464c816_000025_bcdc5519>
  40c5a2:	mov    r15,rax
  40c5a5:	test   r15,r15
  40c5a8:	je     40c64f <__swc_fn_3464c816_000076_7b195156+0x16f>
  40c5ae:	lea    rax,[rip+0x15a53]        # 422008 <__swc_data_base_3464c816+0x8>
  40c5b5:	mov    rax,QWORD PTR [rax]
  40c5b8:	cmp    rax,0xffffffffffffffff
  40c5bc:	je     40c5cb <__swc_fn_3464c816_000076_7b195156+0xeb>
  40c5be:	mov    eax,eax
  40c5c0:	mov    edi,eax
  40c5c2:	xor    eax,eax
  40c5c4:	call   407000 <pthread_getspecific@plt>
  40c5c9:	jmp    40c5cd <__swc_fn_3464c816_000076_7b195156+0xed>
  40c5cb:	xor    eax,eax
  40c5cd:	mov    rcx,QWORD PTR [r15+0x40]
  40c5d1:	cmp    rcx,rax
  40c5d4:	jne    40c634 <__swc_fn_3464c816_000076_7b195156+0x154>
  40c5d6:	test   rax,rax
  40c5d9:	je     40c64f <__swc_fn_3464c816_000076_7b195156+0x16f>
  40c5db:	mov    ecx,DWORD PTR [r15+0x6c]
  40c5df:	test   ecx,ecx
  40c5e1:	je     40c601 <__swc_fn_3464c816_000076_7b195156+0x121>
  40c5e3:	mov    rcx,r13
  40c5e6:	mov    rdx,rax
  40c5e9:	mov    r8,r15
  40c5ec:	mov    QWORD PTR [rsp+0xd8],rax
  40c5f4:	call   40e4b0 <__swc_fn_3464c816_000050_e072b516>
  40c5f9:	mov    rax,QWORD PTR [rsp+0xd8]
  40c601:	mov    rcx,QWORD PTR [r15]
  40c604:	mov    QWORD PTR [r14],rcx
  40c607:	mov    QWORD PTR [r15],r14
  40c60a:	sub    DWORD PTR [r15+0x28],0x1
  40c60f:	jne    40c644 <__swc_fn_3464c816_000076_7b195156+0x164>
  40c611:	movzx  ecx,BYTE PTR [r15+0x39]
  40c616:	lea    rcx,[rcx+rcx*4]
  40c61a:	lea    rcx,[rax+rcx*8+0x28]
  40c61f:	cmp    QWORD PTR [rcx],r15
  40c622:	je     40c644 <__swc_fn_3464c816_000076_7b195156+0x164>
  40c624:	mov    rcx,r13
  40c627:	mov    rdx,rax
  40c62a:	mov    r8,r15
  40c62d:	call   408520 <__swc_fn_3464c816_000054_2e3450f7>
  40c632:	jmp    40c644 <__swc_fn_3464c816_000076_7b195156+0x164>
  40c634:	test   rcx,rcx
  40c637:	je     40c64f <__swc_fn_3464c816_000076_7b195156+0x16f>
  40c639:	mov    rcx,r15
  40c63c:	mov    rdx,r14
  40c63f:	call   40acb0 <__swc_fn_3464c816_000013_524c1f23>
  40c644:	mov    QWORD PTR [r12+0x40],0x0
  40c64d:	jmp    40c65a <__swc_fn_3464c816_000076_7b195156+0x17a>
  40c64f:	mov    rcx,r13
  40c652:	mov    rdx,r12
  40c655:	call   40efc0 <__swc_fn_3464c816_000077_1966ae2e>
  40c65a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40c663:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40c66c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40c675:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40c67e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40c687:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40c690:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40c699:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40c6a2:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40c6ab:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40c6b4:	add    rsp,0x188
  40c6bb:	pop    rsi
  40c6bc:	pop    rdi
  40c6bd:	pop    r15
  40c6bf:	pop    r14
  40c6c1:	pop    r13
  40c6c3:	pop    r12
  40c6c5:	ret
	...

000000000040c6d0 <__swc_fn_3464c816_000079_d2cd17e2>:
  40c6d0:	sub    rsp,0x8
  40c6d4:	mov    rax,rdx
  40c6d7:	mov    rdx,QWORD PTR [rax+0x40]
  40c6db:	mov    r8,rax
  40c6de:	call   40c2d0 <__swc_fn_3464c816_000070_b3d7b28e>
  40c6e3:	add    rsp,0x8
  40c6e7:	ret
	...

000000000040c6f0 <__swc_fn_3464c816_000082_4a10c7e7>:
  40c6f0:	push   rsi
  40c6f1:	push   rdi
  40c6f2:	sub    rsp,0x8
  40c6f6:	cmp    rcx,0xffffffffffffffef
  40c6fa:	ja     40c720 <__swc_fn_3464c816_000082_4a10c7e7+0x30>
  40c6fc:	xor    esi,esi
  40c6fe:	lea    rax,[rcx+0x100f]
  40c705:	and    rax,0xfffffffffffff000
  40c70c:	lea    rcx,[rcx+0x10]
  40c710:	cmp    rcx,0xfffffffffffff000
  40c717:	cmovbe rsi,rax
  40c71b:	test   rsi,rsi
  40c71e:	jne    40c729 <__swc_fn_3464c816_000082_4a10c7e7+0x39>
  40c720:	xor    eax,eax
  40c722:	add    rsp,0x8
  40c726:	pop    rdi
  40c727:	pop    rsi
  40c728:	ret
  40c729:	mov    rcx,rsi
  40c72c:	call   40cd80 <__swc_fn_3464c816_000112_6b799b8d>
  40c731:	mov    rdi,rax
  40c734:	test   rax,rax
  40c737:	jne    40c742 <__swc_fn_3464c816_000082_4a10c7e7+0x52>
  40c739:	xor    eax,eax
  40c73b:	add    rsp,0x8
  40c73f:	pop    rdi
  40c740:	pop    rsi
  40c741:	ret
  40c742:	mov    rcx,rdi
  40c745:	mov    rdx,rsi
  40c748:	call   4099e0 <__swc_fn_3464c816_000114_36905703>
  40c74d:	test   al,al
  40c74f:	jne    40c765 <__swc_fn_3464c816_000082_4a10c7e7+0x75>
  40c751:	mov    rcx,rdi
  40c754:	mov    rdx,rsi
  40c757:	call   4100f0 <__swc_fn_3464c816_000116_ed2d8fed>
  40c75c:	xor    eax,eax
  40c75e:	add    rsp,0x8
  40c762:	pop    rdi
  40c763:	pop    rsi
  40c764:	ret
  40c765:	mov    QWORD PTR [rdi],rsi
  40c768:	mov    QWORD PTR [rdi+0x8],0x0
  40c770:	lea    rax,[rdi+0x10]
  40c774:	add    rsp,0x8
  40c778:	pop    rdi
  40c779:	pop    rsi
  40c77a:	ret
  40c77b:	add    BYTE PTR [rax],al
  40c77d:	add    BYTE PTR [rax],al
	...

000000000040c780 <__swc_fn_3464c816_000085_3953ef98>:
  40c780:	sub    rsp,0x8
  40c784:	cmp    BYTE PTR [rcx+0x2c],0x10
  40c788:	jne    40c793 <__swc_fn_3464c816_000085_3953ef98+0x13>
  40c78a:	test   DWORD PTR [rcx+0x28],0x80
  40c791:	je     40c79b <__swc_fn_3464c816_000085_3953ef98+0x1b>
  40c793:	mov    rax,rcx
  40c796:	add    rsp,0x8
  40c79a:	ret
  40c79b:	mov    rcx,QWORD PTR [rcx+0x40]
  40c79f:	call   40c780 <__swc_fn_3464c816_000085_3953ef98>
  40c7a4:	add    rsp,0x8
  40c7a8:	ret
	...

000000000040c7c0 <__swc_fn_3464c816_000088_d182c4dc>:
  40c7c0:	push   rsi
  40c7c1:	push   rdi
  40c7c2:	push   r12
  40c7c4:	push   r13
  40c7c6:	sub    rsp,0x8
  40c7ca:	mov    rsi,rdx
  40c7cd:	mov    rdi,rcx
  40c7d0:	xor    r8d,r8d
  40c7d3:	call   408d40 <__swc_fn_3464c816_000093_63c1827b>
  40c7d8:	test   al,al
  40c7da:	je     40c7ec <__swc_fn_3464c816_000088_d182c4dc+0x2c>
  40c7dc:	mov    eax,0x1
  40c7e1:	add    rsp,0x8
  40c7e5:	pop    r13
  40c7e7:	pop    r12
  40c7e9:	pop    rdi
  40c7ea:	pop    rsi
  40c7eb:	ret
  40c7ec:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c7f1:	je     40c800 <__swc_fn_3464c816_000088_d182c4dc+0x40>
  40c7f3:	xor    eax,eax
  40c7f5:	add    rsp,0x8
  40c7f9:	pop    r13
  40c7fb:	pop    r12
  40c7fd:	pop    rdi
  40c7fe:	pop    rsi
  40c7ff:	ret
  40c800:	mov    r12,QWORD PTR [rsi+0x98]
  40c807:	mov    rax,QWORD PTR [rsi+0xa0]
  40c80e:	mov    rsi,rax
  40c811:	xor    r13d,r13d
  40c814:	test   rsi,rsi
  40c817:	je     40c874 <__swc_fn_3464c816_000088_d182c4dc+0xb4>
  40c819:	cs nop WORD PTR [rax+rax*1+0x0]
  40c823:	cs nop WORD PTR [rax+rax*1+0x0]
  40c82d:	nop    DWORD PTR [rax]
  40c830:	lea    rax,[r13*8+0x0]
  40c838:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c83d:	mov    rcx,rax
  40c840:	call   40c780 <__swc_fn_3464c816_000085_3953ef98>
  40c845:	cmp    BYTE PTR [rax+0x2c],0xe
  40c849:	jne    40c86a <__swc_fn_3464c816_000088_d182c4dc+0xaa>
  40c84b:	mov    rcx,rdi
  40c84e:	mov    rdx,rax
  40c851:	call   40c7c0 <__swc_fn_3464c816_000088_d182c4dc>
  40c856:	test   al,al
  40c858:	je     40c86a <__swc_fn_3464c816_000088_d182c4dc+0xaa>
  40c85a:	mov    eax,0x1
  40c85f:	add    rsp,0x8
  40c863:	pop    r13
  40c865:	pop    r12
  40c867:	pop    rdi
  40c868:	pop    rsi
  40c869:	ret
  40c86a:	add    r13,0x1
  40c86e:	sub    rsi,0x1
  40c872:	jne    40c830 <__swc_fn_3464c816_000088_d182c4dc+0x70>
  40c874:	xor    eax,eax
  40c876:	add    rsp,0x8
  40c87a:	pop    r13
  40c87c:	pop    r12
  40c87e:	pop    rdi
  40c87f:	pop    rsi
  40c880:	ret
	...

000000000040c890 <__swc_fn_3464c816_000091_14c65203>:
  40c890:	sub    rsp,0x18
  40c894:	vxorps xmm0,xmm0,xmm0
  40c898:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c89d:	call   40f1d0 <__swc_fn_3464c816_000092_c2567a3b>
  40c8a2:	add    rsp,0x18
  40c8a6:	ret
	...

000000000040c8b0 <__swc_fn_3464c816_000094_ad13d15c>:
  40c8b0:	sub    rsp,0x8
  40c8b4:	mov    rcx,QWORD PTR [rip+0x17785]        # 424040 <__swc_bss_base_3464c816>
  40c8bb:	test   rcx,rcx
  40c8be:	jne    40c8d0 <__swc_fn_3464c816_000094_ad13d15c+0x20>
  40c8c0:	call   40a940 <__swc_fn_3464c816_000168_994c8876>
  40c8c5:	lea    rcx,[rax+0x1]
  40c8c9:	mov    QWORD PTR [rip+0x17770],rcx        # 424040 <__swc_bss_base_3464c816>
  40c8d0:	dec    rcx
  40c8d3:	call   411ec0 <__swc_fn_3464c816_000170_360af05d>
  40c8d8:	mov    rax,QWORD PTR [rax+0xc0]
  40c8df:	and    eax,0x1
  40c8e2:	setne  al
  40c8e5:	add    rsp,0x8
  40c8e9:	ret
	...

000000000040c900 <__swc_fn_3464c816_000097_4f209617>:
  40c900:	push   rbx
  40c901:	push   rsi
  40c902:	push   rdi
  40c903:	push   r12
  40c905:	sub    rsp,0x28
  40c909:	mov    rbx,rcx
  40c90c:	call   4090a0 <__swc_fn_3464c816_000096_4185993f>
  40c911:	mov    rcx,QWORD PTR [rip+0x17728]        # 424040 <__swc_bss_base_3464c816>
  40c918:	test   rcx,rcx
  40c91b:	jne    40c92d <__swc_fn_3464c816_000097_4f209617+0x2d>
  40c91d:	call   40a940 <__swc_fn_3464c816_000168_994c8876>
  40c922:	lea    rcx,[rax+0x1]
  40c926:	mov    QWORD PTR [rip+0x17713],rcx        # 424040 <__swc_bss_base_3464c816>
  40c92d:	dec    rcx
  40c930:	call   411ec0 <__swc_fn_3464c816_000170_360af05d>
  40c935:	mov    rsi,rax
  40c938:	lea    rcx,[rsp+0x8]
  40c93d:	call   40f610 <__swc_fn_3464c816_000095_93bfe675>
  40c942:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c949:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c950:	lea    rcx,[rsi+0x10]
  40c954:	call   40d8d0 <__swc_fn_3464c816_000160_13ead2ff>
  40c959:	mov    rcx,rsi
  40c95c:	call   40f780 <__swc_fn_3464c816_000104_5a85fcf5>
  40c961:	vxorps xmm0,xmm0,xmm0
  40c965:	xor    eax,eax
  40c967:	cs nop WORD PTR [rax+rax*1+0x0]
  40c971:	cs nop WORD PTR [rax+rax*1+0x0]
  40c97b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c980:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c985:	add    rax,0x10
  40c989:	cmp    rax,0xbf0
  40c990:	jne    40c980 <__swc_fn_3464c816_000097_4f209617+0x80>
  40c992:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c998:	vmovups XMMWORD PTR [rsi],xmm0
  40c99c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c9a2:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c9aa:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c9b1:	mov    QWORD PTR [rsi+0xbe8],r12
  40c9b8:	mov    rcx,QWORD PTR [rip+0x17681]        # 424040 <__swc_bss_base_3464c816>
  40c9bf:	test   rcx,rcx
  40c9c2:	jne    40c9d4 <__swc_fn_3464c816_000097_4f209617+0xd4>
  40c9c4:	call   40a940 <__swc_fn_3464c816_000168_994c8876>
  40c9c9:	lea    rcx,[rax+0x1]
  40c9cd:	mov    QWORD PTR [rip+0x1766c],rcx        # 424040 <__swc_bss_base_3464c816>
  40c9d4:	dec    rcx
  40c9d7:	call   411ec0 <__swc_fn_3464c816_000170_360af05d>
  40c9dc:	mov    rsi,rax
  40c9df:	mov    QWORD PTR [rsi+0xc0],rbx
  40c9e6:	and    ebx,0x1
  40c9e9:	jne    40c9ed <__swc_fn_3464c816_000097_4f209617+0xed>
  40c9eb:	xor    eax,eax
  40c9ed:	test   rbx,rbx
  40c9f0:	sete   al
  40c9f3:	xor    cl,cl
  40c9f5:	xor    dl,dl
  40c9f7:	xor    r8b,r8b
  40c9fa:	xor    r9b,r9b
  40c9fd:	xor    r10b,r10b
  40ca00:	mov    r11,rax
  40ca03:	call   40efd0 <__swc_fn_3464c816_000080_5cc7acfc>
  40ca08:	lea    rbx,[rsp+0x18]
  40ca0d:	mov    rcx,rbx
  40ca10:	call   40f610 <__swc_fn_3464c816_000095_93bfe675>
  40ca15:	lea    rcx,[rsi+0x10]
  40ca19:	mov    edx,0x400000
  40ca1e:	mov    r8,rbx
  40ca21:	call   40a680 <__swc_fn_3464c816_000162_8a3d304f>
  40ca26:	lea    rcx,[rsi+0x68]
  40ca2a:	mov    edx,0x4000
  40ca2f:	mov    r8,rbx
  40ca32:	call   40a680 <__swc_fn_3464c816_000162_8a3d304f>
  40ca37:	add    rsp,0x28
  40ca3b:	pop    r12
  40ca3d:	pop    rdi
  40ca3e:	pop    rsi
  40ca3f:	pop    rbx
  40ca40:	ret
	...

000000000040ca50 <__swc_fn_3464c816_000100_d0b19c14>:
  40ca50:	push   rbx
  40ca51:	push   rsi
  40ca52:	sub    rsp,0x18
  40ca56:	mov    rbx,rcx
  40ca59:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40ca5e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ca64:	mov    rsi,QWORD PTR [rbx+0x70]
  40ca68:	lea    rcx,[rcx+0x18]
  40ca6c:	call   40d8d0 <__swc_fn_3464c816_000160_13ead2ff>
  40ca71:	lea    rcx,[rsp+0x8]
  40ca76:	mov    rdx,rbx
  40ca79:	mov    r8d,0x78
  40ca7f:	call   409100 <__swc_fn_3464c816_000099_d4bdcaa4>
  40ca84:	mov    rax,rsi
  40ca87:	add    rsp,0x18
  40ca8b:	pop    rsi
  40ca8c:	pop    rbx
  40ca8d:	ret
	...

000000000040ca90 <__swc_fn_3464c816_000103_3c3b96fb>:
  40ca90:	push   rsi
  40ca91:	push   rdi
  40ca92:	sub    rsp,0x8
  40ca96:	cmp    QWORD PTR [rcx],0x0
  40ca9a:	jne    40caa3 <__swc_fn_3464c816_000103_3c3b96fb+0x13>
  40ca9c:	add    rsp,0x8
  40caa0:	pop    rdi
  40caa1:	pop    rsi
  40caa2:	ret
  40caa3:	mov    rsi,QWORD PTR [rcx]
  40caa6:	mov    rax,QWORD PTR [rcx+0x8]
  40caaa:	test   rax,rax
  40caad:	je     40cac3 <__swc_fn_3464c816_000103_3c3b96fb+0x33>
  40caaf:	test   DWORD PTR [rax+0x28],0x400000
  40cab6:	je     40cac3 <__swc_fn_3464c816_000103_3c3b96fb+0x33>
  40cab8:	mov    rcx,QWORD PTR [rax+0x30]
  40cabc:	test   rcx,rcx
  40cabf:	cmovne rax,rcx
  40cac3:	lea    rdx,[rip+0x685e]        # 413328 <__swc_rdata_base_3464c816+0x218>
  40caca:	lea    rcx,[rip+0x693f]        # 413410 <__swc_rdata_base_3464c816+0x300>
  40cad1:	mov    r8,rax
  40cad4:	xor    r9d,r9d
  40cad7:	xor    al,al
  40cad9:	mov    r10,rax
  40cadc:	xor    r11d,r11d
  40cadf:	call   40c890 <__swc_fn_3464c816_000091_14c65203>
  40cae4:	test   rax,rax
  40cae7:	je     40caf7 <__swc_fn_3464c816_000103_3c3b96fb+0x67>
  40cae9:	mov    rdi,QWORD PTR [rax+0x48]
  40caed:	test   rdi,rdi
  40caf0:	je     40caf7 <__swc_fn_3464c816_000103_3c3b96fb+0x67>
  40caf2:	mov    rcx,rsi
  40caf5:	call   rdi
  40caf7:	add    rsp,0x8
  40cafb:	pop    rdi
  40cafc:	pop    rsi
  40cafd:	ret
	...

000000000040cb00 <__swc_fn_3464c816_000106_90faaa26>:
  40cb00:	push   rbx
  40cb01:	push   rsi
  40cb02:	push   rdi
  40cb03:	sub    rsp,0x20
  40cb07:	mov    rbx,rdx
  40cb0a:	mov    rsi,rcx
  40cb0d:	mov    rcx,QWORD PTR [rip+0x1752c]        # 424040 <__swc_bss_base_3464c816>
  40cb14:	test   rcx,rcx
  40cb17:	jne    40cb29 <__swc_fn_3464c816_000106_90faaa26+0x29>
  40cb19:	call   40a940 <__swc_fn_3464c816_000168_994c8876>
  40cb1e:	lea    rcx,[rax+0x1]
  40cb22:	mov    QWORD PTR [rip+0x17517],rcx        # 424040 <__swc_bss_base_3464c816>
  40cb29:	dec    rcx
  40cb2c:	call   411ec0 <__swc_fn_3464c816_000170_360af05d>
  40cb31:	mov    rdi,rax
  40cb34:	mov    rax,QWORD PTR [rdi+0xbd0]
  40cb3b:	xor    ecx,ecx
  40cb3d:	test   rax,rax
  40cb40:	je     40cb45 <__swc_fn_3464c816_000106_90faaa26+0x45>
  40cb42:	mov    rcx,QWORD PTR [rax]
  40cb45:	call   40aa70 <__swc_fn_3464c816_000177_718d7b54>
  40cb4a:	lea    rax,[rsp+0x8]
  40cb4f:	lea    rcx,[rdi+0x9c8]
  40cb56:	mov    QWORD PTR [rsp+0x8],rcx
  40cb5b:	mov    QWORD PTR [rax+0x8],0x40
  40cb63:	xor    ecx,ecx
  40cb65:	mov    rdx,rax
  40cb68:	call   410220 <__swc_fn_3464c816_000122_4f256d58>
  40cb6d:	mov    DWORD PTR [rdi+0xbc8],eax
  40cb73:	mov    rdi,QWORD PTR [rdi+0x990]
  40cb7a:	test   rdi,rdi
  40cb7d:	je     40cb87 <__swc_fn_3464c816_000106_90faaa26+0x87>
  40cb7f:	mov    rcx,rsi
  40cb82:	mov    rdx,rbx
  40cb85:	call   rdi
  40cb87:	call   40c8b0 <__swc_fn_3464c816_000094_ad13d15c>
  40cb8c:	test   al,al
  40cb8e:	je     40cb9e <__swc_fn_3464c816_000106_90faaa26+0x9e>
  40cb90:	mov    rcx,rsi
  40cb93:	mov    rdx,rbx
  40cb96:	xor    r8d,r8d
  40cb99:	call   409b80 <__swc_fn_3464c816_000123_83db7238>
  40cb9e:	mov    rcx,rsi
  40cba1:	mov    rdx,rbx
  40cba4:	call   409200 <__swc_fn_3464c816_000105_ffe51047>
  40cba9:	call   40d130 <__swc_fn_3464c816_000121_be2e2f68>
  40cbae:	add    rsp,0x20
  40cbb2:	pop    rdi
  40cbb3:	pop    rsi
  40cbb4:	pop    rbx
  40cbb5:	ret
	...

000000000040cbc0 <__swc_fn_3464c816_000109_3dc01326>:
  40cbc0:	test   r8,r8
  40cbc3:	jne    40cbc8 <__swc_fn_3464c816_000109_3dc01326+0x8>
  40cbc5:	xor    eax,eax
  40cbc7:	ret
  40cbc8:	xor    eax,eax
  40cbca:	nop    WORD PTR [rax+rax*1+0x0]
  40cbd0:	mov    r9,r8
  40cbd3:	sub    r9,rax
  40cbd6:	cmp    r9,0x10
  40cbda:	jb     40cc24 <__swc_fn_3464c816_000109_3dc01326+0x64>
  40cbdc:	lea    r9,[rcx+rax*1]
  40cbe0:	lea    r10,[rdx+rax*1]
  40cbe4:	vmovups xmm0,XMMWORD PTR [r10]
  40cbe9:	vmovups xmm1,XMMWORD PTR [r9]
  40cbee:	vpcmpeqb xmm0,xmm1,xmm0
  40cbf2:	vpmovmskb r9d,xmm0
  40cbf6:	cmp    r9d,0xffff
  40cbfd:	je     40cc1e <__swc_fn_3464c816_000109_3dc01326+0x5e>
  40cbff:	not    r9d
  40cc02:	xor    r8d,r8d
  40cc05:	movzx  r9d,r9w
  40cc09:	tzcnt  r8d,r9d
  40cc0e:	add    rax,r8
  40cc11:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cc15:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cc19:	sub    ecx,eax
  40cc1b:	mov    eax,ecx
  40cc1d:	ret
  40cc1e:	lea    rax,[rax+0x10]
  40cc22:	jmp    40cbd0 <__swc_fn_3464c816_000109_3dc01326+0x10>
  40cc24:	cmp    r9,0x8
  40cc28:	jb     40cc9b <__swc_fn_3464c816_000109_3dc01326+0xdb>
  40cc2a:	lea    r9,[rcx+rax*1]
  40cc2e:	lea    r10,[rdx+rax*1]
  40cc32:	mov    r9,QWORD PTR [r9]
  40cc35:	xor    r9,QWORD PTR [r10]
  40cc38:	test   r9,r9
  40cc3b:	je     40cc59 <__swc_fn_3464c816_000109_3dc01326+0x99>
  40cc3d:	xor    r8d,r8d
  40cc40:	tzcnt  r8,r9
  40cc45:	shr    r8,0x3
  40cc49:	add    rax,r8
  40cc4c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cc50:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cc54:	sub    ecx,eax
  40cc56:	mov    eax,ecx
  40cc58:	ret
  40cc59:	lea    rax,[rax+0x8]
  40cc5d:	cmp    rax,r8
  40cc60:	jne    40cc65 <__swc_fn_3464c816_000109_3dc01326+0xa5>
  40cc62:	xor    eax,eax
  40cc64:	ret
  40cc65:	lea    rax,[r8-0x8]
  40cc69:	lea    r8,[rcx+rax*1]
  40cc6d:	lea    r9,[rdx+rax*1]
  40cc71:	mov    r8,QWORD PTR [r8]
  40cc74:	xor    r8,QWORD PTR [r9]
  40cc77:	test   r8,r8
  40cc7a:	je     40cc98 <__swc_fn_3464c816_000109_3dc01326+0xd8>
  40cc7c:	xor    r9d,r9d
  40cc7f:	tzcnt  r9,r8
  40cc84:	shr    r9,0x3
  40cc88:	add    rax,r9
  40cc8b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cc8f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cc93:	sub    ecx,eax
  40cc95:	mov    eax,ecx
  40cc97:	ret
  40cc98:	xor    eax,eax
  40cc9a:	ret
  40cc9b:	cmp    r9,0x4
  40cc9f:	jb     40cd12 <__swc_fn_3464c816_000109_3dc01326+0x152>
  40cca1:	lea    r9,[rcx+rax*1]
  40cca5:	lea    r10,[rdx+rax*1]
  40cca9:	mov    r9d,DWORD PTR [r9]
  40ccac:	xor    r9d,DWORD PTR [r10]
  40ccaf:	test   r9d,r9d
  40ccb2:	je     40ccd0 <__swc_fn_3464c816_000109_3dc01326+0x110>
  40ccb4:	xor    r8d,r8d
  40ccb7:	tzcnt  r8,r9
  40ccbc:	shr    r8,0x3
  40ccc0:	add    rax,r8
  40ccc3:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40ccc7:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cccb:	sub    ecx,eax
  40cccd:	mov    eax,ecx
  40cccf:	ret
  40ccd0:	lea    rax,[rax+0x4]
  40ccd4:	cmp    rax,r8
  40ccd7:	jne    40ccdc <__swc_fn_3464c816_000109_3dc01326+0x11c>
  40ccd9:	xor    eax,eax
  40ccdb:	ret
  40ccdc:	lea    rax,[r8-0x4]
  40cce0:	lea    r8,[rcx+rax*1]
  40cce4:	lea    r9,[rdx+rax*1]
  40cce8:	mov    r8d,DWORD PTR [r8]
  40cceb:	xor    r8d,DWORD PTR [r9]
  40ccee:	test   r8d,r8d
  40ccf1:	je     40cd0f <__swc_fn_3464c816_000109_3dc01326+0x14f>
  40ccf3:	xor    r9d,r9d
  40ccf6:	tzcnt  r9,r8
  40ccfb:	shr    r9,0x3
  40ccff:	add    rax,r9
  40cd02:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cd06:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cd0a:	sub    ecx,eax
  40cd0c:	mov    eax,ecx
  40cd0e:	ret
  40cd0f:	xor    eax,eax
  40cd11:	ret
  40cd12:	cmp    r9,0x2
  40cd16:	jb     40cd69 <__swc_fn_3464c816_000109_3dc01326+0x1a9>
  40cd18:	lea    r9,[rcx+rax*1]
  40cd1c:	lea    r10,[rdx+rax*1]
  40cd20:	mov    r9w,WORD PTR [r9]
  40cd24:	xor    r9w,WORD PTR [r10]
  40cd28:	test   r9w,r9w
  40cd2c:	je     40cd4e <__swc_fn_3464c816_000109_3dc01326+0x18e>
  40cd2e:	xor    r8d,r8d
  40cd31:	movzx  r9d,r9w
  40cd35:	tzcnt  r8,r9
  40cd3a:	shr    r8,0x3
  40cd3e:	add    rax,r8
  40cd41:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cd45:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cd49:	sub    ecx,eax
  40cd4b:	mov    eax,ecx
  40cd4d:	ret
  40cd4e:	lea    rax,[rax+0x2]
  40cd52:	cmp    rax,r8
  40cd55:	jne    40cd5a <__swc_fn_3464c816_000109_3dc01326+0x19a>
  40cd57:	xor    eax,eax
  40cd59:	ret
  40cd5a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40cd60:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40cd66:	sub    eax,ecx
  40cd68:	ret
  40cd69:	test   r9,r9
  40cd6c:	je     40cd7b <__swc_fn_3464c816_000109_3dc01326+0x1bb>
  40cd6e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cd72:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cd76:	sub    ecx,eax
  40cd78:	mov    eax,ecx
  40cd7a:	ret
  40cd7b:	xor    eax,eax
  40cd7d:	ret
	...

000000000040cd80 <__swc_fn_3464c816_000112_6b799b8d>:
  40cd80:	push   r12
  40cd82:	push   r13
  40cd84:	push   r14
  40cd86:	push   rdi
  40cd87:	push   rsi
  40cd88:	push   r15
  40cd8a:	sub    rsp,0xd8
  40cd91:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40cd97:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40cd9d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40cda3:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40cda9:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40cdaf:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40cdb8:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40cdc1:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40cdca:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40cdd3:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40cddc:	mov    r12,rcx
  40cddf:	test   rcx,rcx
  40cde2:	je     40cdfe <__swc_fn_3464c816_000112_6b799b8d+0x7e>
  40cde4:	mov    eax,r12d
  40cde7:	and    eax,0xfff
  40cded:	setne  al
  40cdf0:	cmp    r12,0xffffffffffffefff
  40cdf7:	seta   cl
  40cdfa:	or     al,cl
  40cdfc:	je     40ce05 <__swc_fn_3464c816_000112_6b799b8d+0x85>
  40cdfe:	xor    eax,eax
  40ce00:	jmp    40ce9b <__swc_fn_3464c816_000112_6b799b8d+0x11b>
  40ce05:	call   4098a0 <__swc_fn_3464c816_000111_126150d1>
  40ce0a:	mov    r13,rax
  40ce0d:	test   rax,rax
  40ce10:	jne    40ce19 <__swc_fn_3464c816_000112_6b799b8d+0x99>
  40ce12:	xor    eax,eax
  40ce14:	jmp    40ce9b <__swc_fn_3464c816_000112_6b799b8d+0x11b>
  40ce19:	lea    r14,[r12+0x1000]
  40ce21:	xor    edi,edi
  40ce23:	mov    rsi,r14
  40ce26:	xor    edx,edx
  40ce28:	mov    ecx,0x22
  40ce2d:	mov    eax,0xffffffff
  40ce32:	movsxd r8,eax
  40ce35:	xor    r9d,r9d
  40ce38:	xor    eax,eax
  40ce3a:	call   4070c0 <mmap@plt>
  40ce3f:	mov    r15,rax
  40ce42:	cmp    rax,0xffffffffffffffff
  40ce46:	jne    40ce4c <__swc_fn_3464c816_000112_6b799b8d+0xcc>
  40ce48:	xor    eax,eax
  40ce4a:	jmp    40ce9b <__swc_fn_3464c816_000112_6b799b8d+0x11b>
  40ce4c:	mov    rdi,r15
  40ce4f:	mov    esi,0x1000
  40ce54:	mov    edx,0x3
  40ce59:	xor    eax,eax
  40ce5b:	call   407030 <mprotect@plt>
  40ce60:	test   eax,eax
  40ce62:	je     40ce75 <__swc_fn_3464c816_000112_6b799b8d+0xf5>
  40ce64:	mov    rdi,r15
  40ce67:	mov    rsi,r14
  40ce6a:	xor    eax,eax
  40ce6c:	call   407020 <munmap@plt>
  40ce71:	xor    eax,eax
  40ce73:	jmp    40ce9b <__swc_fn_3464c816_000112_6b799b8d+0x11b>
  40ce75:	mov    QWORD PTR [r15+0x8],r12
  40ce79:	mov    rcx,r13
  40ce7c:	call   40d4d0 <__swc_fn_3464c816_000136_8c07c14b>
  40ce81:	mov    rax,QWORD PTR [r13+0x8]
  40ce85:	mov    QWORD PTR [r15],rax
  40ce88:	mov    QWORD PTR [r13+0x8],r15
  40ce8c:	mov    rcx,r13
  40ce8f:	call   4105c0 <__swc_fn_3464c816_000137_715e84ff>
  40ce94:	lea    rax,[r15+0x1000]
  40ce9b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40cea1:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40cea7:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40cead:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40ceb3:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40ceb9:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40cec2:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40cecb:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40ced4:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40cedd:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40cee6:	add    rsp,0xd8
  40ceed:	pop    r15
  40ceef:	pop    rsi
  40cef0:	pop    rdi
  40cef1:	pop    r14
  40cef3:	pop    r13
  40cef5:	pop    r12
  40cef7:	ret
	...

000000000040cf00 <__swc_fn_3464c816_000115_e9fc0224>:
  40cf00:	push   rbx
  40cf01:	push   r12
  40cf03:	push   rdi
  40cf04:	push   rsi
  40cf05:	sub    rsp,0xa8
  40cf0c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cf12:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cf18:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cf1e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cf24:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cf2a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cf30:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cf36:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cf3c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cf45:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cf4e:	mov    rbx,rdx
  40cf51:	mov    r12,rcx
  40cf54:	mov    rdi,rcx
  40cf57:	mov    rsi,rdx
  40cf5a:	xor    edx,edx
  40cf5c:	xor    eax,eax
  40cf5e:	call   407030 <mprotect@plt>
  40cf63:	test   eax,eax
  40cf65:	jne    40cf89 <__swc_fn_3464c816_000115_e9fc0224+0x89>
  40cf67:	mov    rcx,r12
  40cf6a:	mov    rdx,rbx
  40cf6d:	xor    al,al
  40cf6f:	mov    r8,rax
  40cf72:	call   410060 <__swc_fn_3464c816_000113_5f48311c>
  40cf77:	mov    rdi,r12
  40cf7a:	mov    rsi,rbx
  40cf7d:	mov    edx,0x4
  40cf82:	xor    eax,eax
  40cf84:	call   4070e0 <madvise@plt>
  40cf89:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cf8f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cf95:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cf9b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cfa1:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cfa7:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cfad:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cfb3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cfb9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cfc2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cfcb:	add    rsp,0xa8
  40cfd2:	pop    rsi
  40cfd3:	pop    rdi
  40cfd4:	pop    r12
  40cfd6:	pop    rbx
  40cfd7:	ret
	...

000000000040cfe0 <__swc_fn_3464c816_000118_d3318640>:
  40cfe0:	push   rsi
  40cfe1:	push   rdi
  40cfe2:	push   r12
  40cfe4:	push   r13
  40cfe6:	push   r14
  40cfe8:	sub    rsp,0xe0
  40cfef:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40cff5:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40cffb:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40d001:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40d007:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40d00d:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40d016:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40d01f:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40d028:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40d031:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40d03a:	mov    rsi,rdx
  40d03d:	mov    rdi,rcx
  40d040:	call   4098a0 <__swc_fn_3464c816_000111_126150d1>
  40d045:	mov    r12,rax
  40d048:	test   rax,rax
  40d04b:	jne    40d052 <__swc_fn_3464c816_000118_d3318640+0x72>
  40d04d:	jmp    40d0c6 <__swc_fn_3464c816_000118_d3318640+0xe6>
  40d052:	mov    rcx,r12
  40d055:	call   40d4d0 <__swc_fn_3464c816_000136_8c07c14b>
  40d05a:	lea    r13,[r12+0x8]
  40d05f:	mov    rax,QWORD PTR [r13+0x0]
  40d063:	test   rax,rax
  40d066:	je     40d0be <__swc_fn_3464c816_000118_d3318640+0xde>
  40d068:	nop    DWORD PTR [rax+rax*1+0x0]
  40d070:	lea    rcx,[rax+0x1000]
  40d077:	cmp    rcx,rdi
  40d07a:	jne    40d0b2 <__swc_fn_3464c816_000118_d3318640+0xd2>
  40d07c:	cmp    QWORD PTR [rax+0x8],rsi
  40d080:	je     40d08c <__swc_fn_3464c816_000118_d3318640+0xac>
  40d082:	mov    rcx,r12
  40d085:	call   4105c0 <__swc_fn_3464c816_000137_715e84ff>
  40d08a:	jmp    40d0c6 <__swc_fn_3464c816_000118_d3318640+0xe6>
  40d08c:	mov    r14,QWORD PTR [rax]
  40d08f:	mov    rdi,rax
  40d092:	lea    rsi,[rsi+0x1000]
  40d099:	xor    eax,eax
  40d09b:	call   407020 <munmap@plt>
  40d0a0:	test   eax,eax
  40d0a2:	jne    40d0a8 <__swc_fn_3464c816_000118_d3318640+0xc8>
  40d0a4:	mov    QWORD PTR [r13+0x0],r14
  40d0a8:	mov    rcx,r12
  40d0ab:	call   4105c0 <__swc_fn_3464c816_000137_715e84ff>
  40d0b0:	jmp    40d0c6 <__swc_fn_3464c816_000118_d3318640+0xe6>
  40d0b2:	mov    r13,rax
  40d0b5:	mov    rax,QWORD PTR [r13+0x0]
  40d0b9:	test   rax,rax
  40d0bc:	jne    40d070 <__swc_fn_3464c816_000118_d3318640+0x90>
  40d0be:	mov    rcx,r12
  40d0c1:	call   4105c0 <__swc_fn_3464c816_000137_715e84ff>
  40d0c6:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40d0cc:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40d0d2:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40d0d8:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40d0de:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40d0e4:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40d0ed:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40d0f6:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40d0ff:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40d108:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40d111:	add    rsp,0xe0
  40d118:	pop    r14
  40d11a:	pop    r13
  40d11c:	pop    r12
  40d11e:	pop    rdi
  40d11f:	pop    rsi
  40d120:	ret
	...

000000000040d130 <__swc_fn_3464c816_000121_be2e2f68>:
  40d130:	push   rdi
  40d131:	push   rsi
  40d132:	sub    rsp,0xa8
  40d139:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d13f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d145:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d14b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d151:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d157:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d15d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d163:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d169:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d172:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d17b:	mov    rdi,0xfffffffffffffd66
  40d182:	xor    eax,eax
  40d184:	call   407040 <exit@plt>
  40d189:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d18f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d195:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d19b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d1a1:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d1a7:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d1ad:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d1b3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d1b9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d1c2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d1cb:	add    rsp,0xa8
  40d1d2:	pop    rsi
  40d1d3:	pop    rdi
  40d1d4:	ret
	...

000000000040d1e0 <__swc_fn_3464c816_000124_540bf7e8>:
  40d1e0:	push   rbx
  40d1e1:	push   rsi
  40d1e2:	push   rdi
  40d1e3:	sub    rsp,0x30
  40d1e7:	mov    rbx,rdx
  40d1ea:	mov    esi,ecx
  40d1ec:	test   ecx,ecx
  40d1ee:	je     40d2c3 <__swc_fn_3464c816_000124_540bf7e8+0xe3>
  40d1f4:	mov    rcx,rsi
  40d1f7:	shl    rcx,0x4
  40d1fb:	call   40c6f0 <__swc_fn_3464c816_000082_4a10c7e7>
  40d200:	test   rax,rax
  40d203:	je     40d2b2 <__swc_fn_3464c816_000124_540bf7e8+0xd2>
  40d209:	mov    rcx,rsi
  40d20c:	xor    edx,edx
  40d20e:	test   rsi,rsi
  40d211:	jbe    40d292 <__swc_fn_3464c816_000124_540bf7e8+0xb2>
  40d217:	nop    WORD PTR [rax+rax*1+0x0]
  40d220:	mov    r8d,edx
  40d223:	mov    r9,QWORD PTR [rbx+r8*8]
  40d227:	add    r8,r8
  40d22a:	lea    r8,[rax+r8*8]
  40d22e:	xor    r10d,r10d
  40d231:	test   r9,r9
  40d234:	je     40d270 <__swc_fn_3464c816_000124_540bf7e8+0x90>
  40d236:	mov    r11,r9
  40d239:	mov    dil,BYTE PTR [r11]
  40d23c:	test   dil,dil
  40d23f:	je     40d270 <__swc_fn_3464c816_000124_540bf7e8+0x90>
  40d241:	cs nop WORD PTR [rax+rax*1+0x0]
  40d24b:	cs nop WORD PTR [rax+rax*1+0x0]
  40d255:	cs nop WORD PTR [rax+rax*1+0x0]
  40d25f:	nop
  40d260:	add    r11,0x1
  40d264:	add    r10,0x1
  40d268:	mov    dil,BYTE PTR [r11]
  40d26b:	test   dil,dil
  40d26e:	jne    40d260 <__swc_fn_3464c816_000124_540bf7e8+0x80>
  40d270:	mov    QWORD PTR [rsp+0x18],r9
  40d275:	mov    QWORD PTR [rsp+0x20],r10
  40d27a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40d280:	vmovups XMMWORD PTR [r8],xmm0
  40d285:	add    rdx,0x1
  40d289:	cmp    rdx,rcx
  40d28c:	jb     40d220 <__swc_fn_3464c816_000124_540bf7e8+0x40>
  40d292:	lea    rcx,[rip+0x19aaf]        # 426d48 <__swc_bss_base_3464c816+0x2d08>
  40d299:	mov    QWORD PTR [rsp+0x8],rax
  40d29e:	mov    esi,esi
  40d2a0:	mov    QWORD PTR [rsp+0x10],rsi
  40d2a5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40d2ab:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d2b0:	jmp    40d2c3 <__swc_fn_3464c816_000124_540bf7e8+0xe3>
  40d2b2:	lea    rcx,[rip+0x6367]        # 413620 <__swc_rdata_base_3464c816+0x510>
  40d2b9:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  40d2be:	call   40d130 <__swc_fn_3464c816_000121_be2e2f68>
  40d2c3:	add    rsp,0x30
  40d2c7:	pop    rdi
  40d2c8:	pop    rsi
  40d2c9:	pop    rbx
  40d2ca:	ret
  40d2cb:	add    BYTE PTR [rax],al
  40d2cd:	add    BYTE PTR [rax],al
	...

000000000040d2d0 <__swc_fn_3464c816_000127_a481cb88>:
  40d2d0:	push   rdi
  40d2d1:	push   rsi
  40d2d2:	sub    rsp,0xa8
  40d2d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d2df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d2e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d2eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d2f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d2f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d2fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d303:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d309:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d312:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d31b:	mov    edi,ecx
  40d31d:	xor    eax,eax
  40d31f:	call   4070f0 <pthread_key_delete@plt>
  40d324:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d32a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d330:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d336:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d33c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d342:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d348:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d34e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d354:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d35d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d366:	add    rsp,0xa8
  40d36d:	pop    rsi
  40d36e:	pop    rdi
  40d36f:	ret

000000000040d370 <__swc_fn_3464c816_000130_a611b8c4>:
  40d370:	push   rdi
  40d371:	push   rsi
  40d372:	sub    rsp,0xa8
  40d379:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d37f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d385:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d38b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d391:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d397:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d39d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d3a3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d3a9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d3b2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d3bb:	test   rcx,rcx
  40d3be:	je     40d3cf <__swc_fn_3464c816_000130_a611b8c4+0x5f>
  40d3c0:	lea    rax,[rcx-0x1]
  40d3c4:	mov    eax,eax
  40d3c6:	mov    edi,eax
  40d3c8:	xor    eax,eax
  40d3ca:	call   4070f0 <pthread_key_delete@plt>
  40d3cf:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d3d5:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d3db:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d3e1:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d3e7:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d3ed:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d3f3:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d3f9:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d3ff:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d408:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d411:	add    rsp,0xa8
  40d418:	pop    rsi
  40d419:	pop    rdi
  40d41a:	ret
  40d41b:	add    BYTE PTR [rax],al
  40d41d:	add    BYTE PTR [rax],al
	...

000000000040d420 <__swc_fn_3464c816_000133_a9c1c700>:
  40d420:	push   rsi
  40d421:	push   rdi
  40d422:	sub    rsp,0xa8
  40d429:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d42f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d435:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d43b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d441:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d447:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d44d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d453:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d459:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d462:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d46b:	xor    eax,eax
  40d46d:	call   407100 <gettid@plt>
  40d472:	movsxd rax,eax
  40d475:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d47b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d481:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d487:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d48d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d493:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d499:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d49f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d4a5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d4ae:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d4b7:	add    rsp,0xa8
  40d4be:	pop    rdi
  40d4bf:	pop    rsi
  40d4c0:	ret
	...

000000000040d4d0 <__swc_fn_3464c816_000136_8c07c14b>:
  40d4d0:	push   rbx
  40d4d1:	push   rdi
  40d4d2:	push   rsi
  40d4d3:	sub    rsp,0xc0
  40d4da:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d4e0:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d4e6:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d4ec:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d4f2:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d4f8:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d4fe:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d504:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d50d:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d516:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d51f:	mov    rbx,rcx
  40d522:	cs nop WORD PTR [rax+rax*1+0x0]
  40d52c:	nop    DWORD PTR [rax+0x0]
  40d530:	mov    edx,0x80000000
  40d535:	xor    eax,eax
  40d537:	lock cmpxchg DWORD PTR [rbx],edx
  40d53b:	test   eax,eax
  40d53d:	je     40d574 <__swc_fn_3464c816_000136_8c07c14b+0xa4>
  40d53f:	mov    eax,DWORD PTR [rbx]
  40d541:	lea    rcx,[rsp+0x14]
  40d546:	mov    DWORD PTR [rsp+0x14],eax
  40d54a:	test   eax,eax
  40d54c:	je     40d530 <__swc_fn_3464c816_000136_8c07c14b+0x60>
  40d54e:	mov    QWORD PTR [rsp],0x0
  40d556:	mov    edi,0xca
  40d55b:	mov    rsi,rbx
  40d55e:	mov    edx,0x80
  40d563:	mov    ecx,DWORD PTR [rcx]
  40d565:	xor    r8d,r8d
  40d568:	xor    r9d,r9d
  40d56b:	xor    eax,eax
  40d56d:	call   407070 <syscall@plt>
  40d572:	jmp    40d530 <__swc_fn_3464c816_000136_8c07c14b+0x60>
  40d574:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d57a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d580:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d586:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d58c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d592:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d598:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d59e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d5a7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d5b0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d5b9:	add    rsp,0xc0
  40d5c0:	pop    rsi
  40d5c1:	pop    rdi
  40d5c2:	pop    rbx
  40d5c3:	ret
	...

000000000040d5d0 <__swc_fn_3464c816_000139_055b38a4>:
  40d5d0:	sub    rsp,0x8
  40d5d4:	call   4105c0 <__swc_fn_3464c816_000137_715e84ff>
  40d5d9:	add    rsp,0x8
  40d5dd:	ret
	...

000000000040d5e0 <__swc_fn_3464c816_000142_d299b428>:
  40d5e0:	push   rdi
  40d5e1:	push   rsi
  40d5e2:	sub    rsp,0xa8
  40d5e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d5ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d5f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d5fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d601:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d607:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d60d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d613:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d619:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d622:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d62b:	mov    edi,0x28
  40d630:	xor    eax,eax
  40d632:	call   4070d0 <malloc@plt>
  40d637:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d63d:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d643:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d649:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d64f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d655:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d65b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d661:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d667:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d670:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d679:	add    rsp,0xa8
  40d680:	pop    rsi
  40d681:	pop    rdi
  40d682:	ret
	...

000000000040d690 <__swc_fn_3464c816_000145_162f363d>:
  40d690:	mov    QWORD PTR [r8],0x0
  40d697:	cmp    rdx,0x10
  40d69b:	jae    40d6a0 <__swc_fn_3464c816_000145_162f363d+0x10>
  40d69d:	xor    eax,eax
  40d69f:	ret
  40d6a0:	mov    eax,DWORD PTR [rcx]
  40d6a2:	cmp    eax,0x42445753
  40d6a8:	jne    40d6b2 <__swc_fn_3464c816_000145_162f363d+0x22>
  40d6aa:	mov    eax,DWORD PTR [rcx+0x4]
  40d6ad:	cmp    eax,0x1
  40d6b0:	je     40d6b5 <__swc_fn_3464c816_000145_162f363d+0x25>
  40d6b2:	xor    eax,eax
  40d6b4:	ret
  40d6b5:	mov    QWORD PTR [r8],rdx
  40d6b8:	mov    rax,rcx
  40d6bb:	ret
  40d6bc:	add    BYTE PTR [rax],al
	...

000000000040d6c0 <__swc_fn_3464c816_000148_2eb804cc>:
  40d6c0:	push   rbx
  40d6c1:	sub    rsp,0xe0
  40d6c8:	lea    rbx,[rsp+0x8]
  40d6cd:	vxorps xmm0,xmm0,xmm0
  40d6d1:	vmovups YMMWORD PTR [rbx],ymm0
  40d6d5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40d6da:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40d6df:	vzeroupper
  40d6e2:	mov    DWORD PTR [rbx+0x60],0x0
  40d6e9:	mov    r8,rbx
  40d6ec:	mov    rdx,rcx
  40d6ef:	nop
  40d6f0:	mov    r9,rdx
  40d6f3:	movabs rdx,0x6666666666666667
  40d6fd:	mov    rax,r9
  40d700:	imul   rdx
  40d703:	sar    rdx,0x2
  40d707:	mov    r10,rdx
  40d70a:	shr    rdx,0x3f
  40d70e:	add    r10,rdx
  40d711:	mov    rdx,r10
  40d714:	imul   r11,r10,0xa
  40d718:	sub    r9,r11
  40d71b:	mov    r11,QWORD PTR [rip+0x5f1e]        # 413640 <__swc_rdata_base_3464c816+0x530>
  40d722:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40d727:	mov    BYTE PTR [r8],r9b
  40d72a:	lea    r9,[r8+0x1]
  40d72e:	mov    r8,r9
  40d731:	test   r10,r10
  40d734:	jne    40d6f0 <__swc_fn_3464c816_000148_2eb804cc+0x30>
  40d736:	test   rcx,rcx
  40d739:	jge    40d743 <__swc_fn_3464c816_000148_2eb804cc+0x83>
  40d73b:	mov    BYTE PTR [r9],0x2d
  40d73f:	add    r8,0x1
  40d743:	mov    BYTE PTR [r8],0x0
  40d747:	sub    r8,0x1
  40d74b:	mov    rax,rbx
  40d74e:	cmp    rax,r8
  40d751:	jae    40d776 <__swc_fn_3464c816_000148_2eb804cc+0xb6>
  40d753:	cs nop WORD PTR [rax+rax*1+0x0]
  40d75d:	nop    DWORD PTR [rax]
  40d760:	mov    cl,BYTE PTR [r8]
  40d763:	mov    dl,BYTE PTR [rax]
  40d765:	mov    BYTE PTR [r8],dl
  40d768:	sub    r8,0x1
  40d76c:	mov    BYTE PTR [rax],cl
  40d76e:	inc    rax
  40d771:	cmp    rax,r8
  40d774:	jb     40d760 <__swc_fn_3464c816_000148_2eb804cc+0xa0>
  40d776:	xor    eax,eax
  40d778:	test   rbx,rbx
  40d77b:	je     40d79e <__swc_fn_3464c816_000148_2eb804cc+0xde>
  40d77d:	mov    rcx,rbx
  40d780:	mov    dl,BYTE PTR [rcx]
  40d782:	test   dl,dl
  40d784:	je     40d79e <__swc_fn_3464c816_000148_2eb804cc+0xde>
  40d786:	cs nop WORD PTR [rax+rax*1+0x0]
  40d790:	add    rcx,0x1
  40d794:	add    rax,0x1
  40d798:	mov    dl,BYTE PTR [rcx]
  40d79a:	test   dl,dl
  40d79c:	jne    40d790 <__swc_fn_3464c816_000148_2eb804cc+0xd0>
  40d79e:	mov    QWORD PTR [rbx+0xa8],rbx
  40d7a5:	mov    QWORD PTR [rbx+0xb0],rax
  40d7ac:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d7b4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d7bc:	lea    rcx,[rbx+0xb8]
  40d7c3:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  40d7c8:	add    rsp,0xe0
  40d7cf:	pop    rbx
  40d7d0:	ret
	...

000000000040d7e0 <__swc_fn_3464c816_000151_86f1d437>:
  40d7e0:	vxorps xmm0,xmm0,xmm0
  40d7e4:	vmovups XMMWORD PTR [rcx],xmm0
  40d7e8:	mov    QWORD PTR [rcx+0x10],0x0
  40d7f0:	ret
	...

000000000040d800 <__swc_fn_3464c816_000154_86f1d437>:
  40d800:	vxorps xmm0,xmm0,xmm0
  40d804:	vmovups XMMWORD PTR [rcx],xmm0
  40d808:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d80d:	vxorps xmm0,xmm0,xmm0
  40d811:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d816:	vmovups xmm0,XMMWORD PTR [rip+0x5f1a]        # 413738 <__swc_rdata_base_3464c816+0x628>
  40d81e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d823:	vxorps xmm0,xmm0,xmm0
  40d827:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d82c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d831:	mov    QWORD PTR [rcx+0x60],0x0
  40d839:	ret
  40d83a:	add    BYTE PTR [rax],al
  40d83c:	add    BYTE PTR [rax],al
	...

000000000040d840 <__swc_fn_3464c816_000157_86f1d437>:
  40d840:	vxorps xmm0,xmm0,xmm0
  40d844:	vmovups XMMWORD PTR [rcx],xmm0
  40d848:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d84d:	vxorps xmm0,xmm0,xmm0
  40d851:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d856:	vmovups xmm0,XMMWORD PTR [rip+0x6002]        # 413860 <__swc_rdata_base_3464c816+0x750>
  40d85e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d863:	vxorps xmm0,xmm0,xmm0
  40d867:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d86c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d871:	vxorps xmm0,xmm0,xmm0
  40d875:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d87a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d87f:	vxorps xmm0,xmm0,xmm0
  40d883:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d88b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d893:	vxorps xmm0,xmm0,xmm0
  40d897:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d89f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d8a7:	vxorps xmm0,xmm0,xmm0
  40d8ab:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d8b3:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d8bb:	mov    QWORD PTR [rcx+0xe0],0x0
  40d8c6:	ret
	...

000000000040d8d0 <__swc_fn_3464c816_000160_13ead2ff>:
  40d8d0:	push   rbx
  40d8d1:	mov    rbx,rcx
  40d8d4:	call   411b50 <__swc_fn_3464c816_000161_e36363a8>
  40d8d9:	mov    rax,QWORD PTR [rbx+0x10]
  40d8dd:	test   rax,rax
  40d8e0:	je     40d8f1 <__swc_fn_3464c816_000160_13ead2ff+0x21>
  40d8e2:	mov    rcx,rbx
  40d8e5:	mov    rdx,rax
  40d8e8:	mov    r8,QWORD PTR [rbx+0x18]
  40d8ec:	call   40a630 <__swc_fn_3464c816_000159_47b270e1>
  40d8f1:	vxorps xmm0,xmm0,xmm0
  40d8f5:	vmovups XMMWORD PTR [rbx],xmm0
  40d8f9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d8fe:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d903:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d908:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d90d:	mov    QWORD PTR [rbx+0x50],0x0
  40d915:	pop    rbx
  40d916:	ret
	...

000000000040d920 <__swc_fn_3464c816_000163_72795826>:
  40d920:	sub    rsp,0x10
  40d924:	mov    eax,r8d
  40d927:	mov    r8d,r9d
  40d92a:	test   r9d,r9d
  40d92d:	jne    40d946 <__swc_fn_3464c816_000163_72795826+0x26>
  40d92f:	vmovups xmm0,XMMWORD PTR [rip+0x5fe1]        # 413918 <__swc_rdata_base_3464c816+0x808>
  40d937:	vmovups XMMWORD PTR [r10],xmm0
  40d93c:	mov    eax,0x1
  40d941:	add    rsp,0x10
  40d945:	ret
  40d946:	mov    r9,r8
  40d949:	cmp    r8,rax
  40d94c:	jb     40d953 <__swc_fn_3464c816_000163_72795826+0x33>
  40d94e:	cmp    r9,rdx
  40d951:	jb     40d95a <__swc_fn_3464c816_000163_72795826+0x3a>
  40d953:	xor    eax,eax
  40d955:	add    rsp,0x10
  40d959:	ret
  40d95a:	xor    eax,eax
  40d95c:	lea    r8,[r9+rax*1]
  40d960:	cmp    r8,rdx
  40d963:	jae    40d993 <__swc_fn_3464c816_000163_72795826+0x73>
  40d965:	cs nop WORD PTR [rax+rax*1+0x0]
  40d96f:	cs nop WORD PTR [rax+rax*1+0x0]
  40d979:	nop    DWORD PTR [rax+0x0]
  40d980:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d985:	je     40d993 <__swc_fn_3464c816_000163_72795826+0x73>
  40d987:	inc    rax
  40d98a:	lea    r8,[r9+rax*1]
  40d98e:	cmp    r8,rdx
  40d991:	jb     40d980 <__swc_fn_3464c816_000163_72795826+0x60>
  40d993:	cmp    r8,rdx
  40d996:	jne    40d99f <__swc_fn_3464c816_000163_72795826+0x7f>
  40d998:	xor    eax,eax
  40d99a:	add    rsp,0x10
  40d99e:	ret
  40d99f:	add    rcx,r9
  40d9a2:	mov    QWORD PTR [rsp],rcx
  40d9a6:	mov    QWORD PTR [rsp+0x8],rax
  40d9ab:	vmovups xmm0,XMMWORD PTR [rsp]
  40d9b0:	vmovups XMMWORD PTR [r10],xmm0
  40d9b5:	mov    eax,0x1
  40d9ba:	add    rsp,0x10
  40d9be:	ret
	...

000000000040d9c0 <__swc_fn_3464c816_000166_bcc835b8>:
  40d9c0:	push   rbp
  40d9c1:	push   rbx
  40d9c2:	push   rsi
  40d9c3:	push   rdi
  40d9c4:	push   r12
  40d9c6:	push   r13
  40d9c8:	push   r14
  40d9ca:	push   r15
  40d9cc:	sub    rsp,0x10
  40d9d0:	mov    rbp,rsp
  40d9d3:	vmovups XMMWORD PTR [rsp],xmm6
  40d9d8:	sub    rsp,0x50
  40d9dc:	mov    rbx,rsp
  40d9df:	mov    rsi,r8
  40d9e2:	mov    QWORD PTR [rsp+0x30],r8
  40d9e7:	mov    rdi,rcx
  40d9ea:	mov    QWORD PTR [rsp+0x38],rcx
  40d9ef:	mov    r12,rdx
  40d9f2:	xor    r13b,r13b
  40d9f5:	mov    r14,QWORD PTR [rdi+0x8]
  40d9f9:	mov    QWORD PTR [rsp+0x40],r14
  40d9fe:	xor    r15d,r15d
  40da01:	test   r14,r14
  40da04:	jbe    40dc5e <__swc_fn_3464c816_000166_bcc835b8+0x29e>
  40da0a:	mov    r14,QWORD PTR [rdi]
  40da0d:	mov    rax,QWORD PTR [rsp+0x40]
  40da12:	mov    QWORD PTR [rsp+0x48],r14
  40da17:	vmovups xmm6,XMMWORD PTR [rip+0x5b19]        # 413538 <__swc_rdata_base_3464c816+0x428>
  40da1f:	nop
  40da20:	cmp    QWORD PTR [r14+r15*8],0x0
  40da25:	jne    40da2f <__swc_fn_3464c816_000166_bcc835b8+0x6f>
  40da27:	mov    r14,rax
  40da2a:	jmp    40dc3e <__swc_fn_3464c816_000166_bcc835b8+0x27e>
  40da2f:	mov    rcx,QWORD PTR [rdi]
  40da32:	mov    rdx,QWORD PTR [rcx+r15*8]
  40da36:	mov    rdi,rbx
  40da39:	mov    rcx,rdi
  40da3c:	sub    rsp,0x8
  40da40:	mov    r14,rax
  40da43:	call   40a6b0 <__swc_fn_3464c816_000165_cc119975>
  40da48:	add    rsp,0x8
  40da4c:	mov    al,BYTE PTR [rbx]
  40da4e:	test   al,al
  40da50:	je     40dc3e <__swc_fn_3464c816_000166_bcc835b8+0x27e>
  40da56:	mov    al,BYTE PTR [rbx+0x1]
  40da59:	test   al,al
  40da5b:	jne    40da66 <__swc_fn_3464c816_000166_bcc835b8+0xa6>
  40da5d:	test   sil,sil
  40da60:	je     40dc3e <__swc_fn_3464c816_000166_bcc835b8+0x27e>
  40da66:	test   r13b,r13b
  40da69:	jne    40db27 <__swc_fn_3464c816_000166_bcc835b8+0x167>
  40da6f:	test   r12,r12
  40da72:	je     40db27 <__swc_fn_3464c816_000166_bcc835b8+0x167>
  40da78:	mov    al,BYTE PTR [rbx+0x1]
  40da7b:	test   al,al
  40da7d:	je     40dc3e <__swc_fn_3464c816_000166_bcc835b8+0x27e>
  40da83:	mov    eax,DWORD PTR [rbx+0x28]
  40da86:	cmp    DWORD PTR [r12+0x20],eax
  40da8b:	jne    40dc3e <__swc_fn_3464c816_000166_bcc835b8+0x27e>
  40da91:	mov    rax,QWORD PTR [r12]
  40da95:	mov    rcx,QWORD PTR [r12+0x8]
  40da9a:	cmp    QWORD PTR [rbx+0x20],rcx
  40da9e:	jne    40dc3e <__swc_fn_3464c816_000166_bcc835b8+0x27e>
  40daa4:	mov    cl,0x1
  40daa6:	test   rax,rax
  40daa9:	je     40db12 <__swc_fn_3464c816_000166_bcc835b8+0x152>
  40daaf:	mov    rdx,QWORD PTR [rbx+0x20]
  40dab3:	xor    r8d,r8d
  40dab6:	test   rdx,rdx
  40dab9:	jbe    40db12 <__swc_fn_3464c816_000166_bcc835b8+0x152>
  40dabb:	mov    r9,QWORD PTR [rbx+0x18]
  40dabf:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40dac4:	cs nop WORD PTR [rax+rax*1+0x0]
  40dace:	xchg   ax,ax
  40dad0:	mov    r10b,BYTE PTR [rax+r8*1]
  40dad4:	cmp    BYTE PTR [r9+r8*1],r10b
  40dad8:	je     40db09 <__swc_fn_3464c816_000166_bcc835b8+0x149>
  40dada:	vmovq  r10,xmm0
  40dadf:	cmp    BYTE PTR [r10+r8*1],0x5c
  40dae4:	jne    40daed <__swc_fn_3464c816_000166_bcc835b8+0x12d>
  40dae6:	cmp    BYTE PTR [rax+r8*1],0x2f
  40daeb:	je     40db09 <__swc_fn_3464c816_000166_bcc835b8+0x149>
  40daed:	vmovq  r10,xmm0
  40daf2:	cmp    BYTE PTR [r10+r8*1],0x2f
  40daf7:	jne    40db00 <__swc_fn_3464c816_000166_bcc835b8+0x140>
  40daf9:	cmp    BYTE PTR [rax+r8*1],0x5c
  40dafe:	je     40db09 <__swc_fn_3464c816_000166_bcc835b8+0x149>
  40db00:	xor    eax,eax
  40db02:	movzx  eax,al
  40db05:	mov    cl,al
  40db07:	jmp    40db12 <__swc_fn_3464c816_000166_bcc835b8+0x152>
  40db09:	add    r8,0x1
  40db0d:	cmp    r8,rdx
  40db10:	jb     40dad0 <__swc_fn_3464c816_000166_bcc835b8+0x110>
  40db12:	test   cl,cl
  40db14:	je     40dc3e <__swc_fn_3464c816_000166_bcc835b8+0x27e>
  40db1a:	mov    eax,0x1
  40db1f:	mov    r13b,al
  40db22:	jmp    40dc3e <__swc_fn_3464c816_000166_bcc835b8+0x27e>
  40db27:	mov    r13b,0x1
  40db2a:	sub    rsp,0x20
  40db2e:	mov    rax,rsp
  40db31:	lea    rcx,[rdi+0x8]
  40db35:	mov    QWORD PTR [rax],rcx
  40db38:	lea    rsi,[rip+0x55e1]        # 413120 <__swc_rdata_base_3464c816+0x10>
  40db3f:	mov    QWORD PTR [rax+0x8],rsi
  40db43:	mov    QWORD PTR [rax+0x10],rsp
  40db47:	mov    QWORD PTR [rax+0x18],0x1
  40db4f:	lea    rcx,[rsp+0x10]
  40db54:	sub    rsp,0x8
  40db58:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  40db5d:	add    rsp,0x8
  40db61:	add    rsp,0x20
  40db65:	mov    al,BYTE PTR [rbx+0x1]
  40db68:	test   al,al
  40db6a:	je     40dc07 <__swc_fn_3464c816_000166_bcc835b8+0x247>
  40db70:	lea    rax,[rip+0x5e41]        # 4139b8 <__swc_rdata_base_3464c816+0x8a8>
  40db77:	sub    rsp,0x20
  40db7b:	mov    rcx,rsp
  40db7e:	mov    QWORD PTR [rcx],rax
  40db81:	mov    QWORD PTR [rcx+0x8],rsi
  40db85:	mov    QWORD PTR [rcx+0x10],rsp
  40db89:	mov    QWORD PTR [rcx+0x18],0x1
  40db91:	lea    rcx,[rsp+0x10]
  40db96:	sub    rsp,0x8
  40db9a:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  40db9f:	add    rsp,0x8
  40dba3:	add    rsp,0x20
  40dba7:	mov    eax,DWORD PTR [rbx+0x28]
  40dbaa:	sub    rsp,0x60
  40dbae:	mov    rcx,rsp
  40dbb1:	lea    rdx,[rdi+0x18]
  40dbb5:	mov    QWORD PTR [rcx+0x18],rdx
  40dbb9:	mov    QWORD PTR [rcx+0x20],rsi
  40dbbd:	vmovups XMMWORD PTR [rcx],xmm6
  40dbc1:	mov    QWORD PTR [rcx+0x28],rsp
  40dbc5:	mov    QWORD PTR [rcx+0x30],rsi
  40dbc9:	mov    DWORD PTR [rcx+0x10],eax
  40dbcc:	lea    rax,[rsp+0x10]
  40dbd1:	mov    QWORD PTR [rcx+0x38],rax
  40dbd5:	lea    rax,[rip+0x58f4]        # 4134d0 <__swc_rdata_base_3464c816+0x3c0>
  40dbdc:	mov    QWORD PTR [rcx+0x40],rax
  40dbe0:	lea    rax,[rsp+0x18]
  40dbe5:	mov    QWORD PTR [rcx+0x48],rax
  40dbe9:	mov    QWORD PTR [rcx+0x50],0x3
  40dbf1:	lea    rcx,[rsp+0x48]
  40dbf6:	sub    rsp,0x8
  40dbfa:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  40dbff:	add    rsp,0x8
  40dc03:	add    rsp,0x60
  40dc07:	lea    rax,[rip+0x5502]        # 413110 <__swc_rdata_base_3464c816>
  40dc0e:	sub    rsp,0x20
  40dc12:	mov    rcx,rsp
  40dc15:	mov    QWORD PTR [rcx],rax
  40dc18:	mov    QWORD PTR [rcx+0x8],rsi
  40dc1c:	mov    QWORD PTR [rcx+0x10],rsp
  40dc20:	mov    QWORD PTR [rcx+0x18],0x1
  40dc28:	lea    rcx,[rsp+0x10]
  40dc2d:	sub    rsp,0x8
  40dc31:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  40dc36:	add    rsp,0x8
  40dc3a:	add    rsp,0x20
  40dc3e:	add    r15,0x1
  40dc42:	cmp    r15,r14
  40dc45:	jae    40dc5e <__swc_fn_3464c816_000166_bcc835b8+0x29e>
  40dc47:	mov    rsi,QWORD PTR [rsp+0x30]
  40dc4c:	mov    rdi,QWORD PTR [rsp+0x38]
  40dc51:	mov    rax,r14
  40dc54:	mov    r14,QWORD PTR [rsp+0x48]
  40dc59:	jmp    40da20 <__swc_fn_3464c816_000166_bcc835b8+0x60>
  40dc5e:	add    rsp,0x50
  40dc62:	vmovups xmm6,XMMWORD PTR [rsp]
  40dc67:	add    rsp,0x10
  40dc6b:	pop    r15
  40dc6d:	pop    r14
  40dc6f:	pop    r13
  40dc71:	pop    r12
  40dc73:	pop    rdi
  40dc74:	pop    rsi
  40dc75:	pop    rbx
  40dc76:	pop    rbp
  40dc77:	ret
	...

000000000040dc80 <__swc_fn_3464c816_000169_646fdf20>:
  40dc80:	sub    rsp,0x8
  40dc84:	call   410390 <__swc_fn_3464c816_000128_4bbe3f14>
  40dc89:	add    rsp,0x8
  40dc8d:	ret
	...

000000000040dc90 <__swc_fn_3464c816_000172_1e0ea8cf>:
  40dc90:	push   rsi
  40dc91:	sub    rsp,0x30
  40dc95:	lea    rsi,[rip+0x190fc]        # 426d98 <__swc_bss_base_3464c816+0x2d58>
  40dc9c:	mov    rax,QWORD PTR [rsi]
  40dc9f:	test   rax,rax
  40dca2:	je     40dcaa <__swc_fn_3464c816_000172_1e0ea8cf+0x1a>
  40dca4:	add    rsp,0x30
  40dca8:	pop    rsi
  40dca9:	ret
  40dcaa:	mov    ecx,0x2
  40dcaf:	mov    edx,0x8020
  40dcb4:	call   40fa30 <__swc_fn_3464c816_000110_6814119b>
  40dcb9:	test   rax,rax
  40dcbc:	jne    40dccd <__swc_fn_3464c816_000172_1e0ea8cf+0x3d>
  40dcbe:	mov    QWORD PTR [rsp+0x18],rax
  40dcc3:	call   40d130 <__swc_fn_3464c816_000121_be2e2f68>
  40dcc8:	mov    rax,QWORD PTR [rsp+0x18]
  40dccd:	mov    rcx,rax
  40dcd0:	xchg   QWORD PTR [rsi],rcx
  40dcd3:	add    rsp,0x30
  40dcd7:	pop    rsi
  40dcd8:	ret
  40dcd9:	add    BYTE PTR [rax],al
  40dcdb:	add    BYTE PTR [rax],al
  40dcdd:	add    BYTE PTR [rax],al
	...

000000000040dce0 <__swc_fn_3464c816_000175_4de704de>:
  40dce0:	push   rsi
  40dce1:	test   r8,r8
  40dce4:	jne    40dce8 <__swc_fn_3464c816_000175_4de704de+0x8>
  40dce6:	pop    rsi
  40dce7:	ret
  40dce8:	lea    rax,[rcx+0x18]
  40dcec:	mov    r10,QWORD PTR [rax]
  40dcef:	lea    r11,[r10+0x1]
  40dcf3:	mov    QWORD PTR [rax],r11
  40dcf6:	mov    r11,rdx
  40dcf9:	not    rdx
  40dcfc:	lea    rsi,[r8-0x1]
  40dd00:	cmp    rsi,rdx
  40dd03:	ja     40dd23 <__swc_fn_3464c816_000175_4de704de+0x43>
  40dd05:	lea    rdx,[r11+r8*1]
  40dd09:	dec    rdx
  40dd0c:	shr    rdx,0x6
  40dd10:	mov    r8,r11
  40dd13:	shr    r8,0x6
  40dd17:	mov    rsi,rdx
  40dd1a:	sub    rsi,r8
  40dd1d:	cmp    rsi,0x8
  40dd21:	jb     40dd39 <__swc_fn_3464c816_000175_4de704de+0x59>
  40dd23:	lea    rcx,[rcx+0x10]
  40dd27:	mov    rdx,QWORD PTR [rcx]
  40dd2a:	add    rdx,r9
  40dd2d:	mov    QWORD PTR [rcx],rdx
  40dd30:	lea    rcx,[r10+0x2]
  40dd34:	mov    QWORD PTR [rax],rcx
  40dd37:	pop    rsi
  40dd38:	ret
  40dd39:	shr    r11,0x6
  40dd3d:	nop    DWORD PTR [rax]
  40dd40:	cmp    r11,rdx
  40dd43:	ja     40dd83 <__swc_fn_3464c816_000175_4de704de+0xa3>
  40dd45:	jmp    40dd56 <__swc_fn_3464c816_000175_4de704de+0x76>
  40dd47:	nop    WORD PTR [rax+rax*1+0x0]
  40dd50:	add    r11,0x1
  40dd54:	jmp    40dd40 <__swc_fn_3464c816_000175_4de704de+0x60>
  40dd56:	mov    r8,r11
  40dd59:	shr    r8,0xc
  40dd5d:	mov    rsi,r11
  40dd60:	xor    rsi,r8
  40dd63:	mov    r8,r11
  40dd66:	shr    r8,0x18
  40dd6a:	xor    rsi,r8
  40dd6d:	and    esi,0xfff
  40dd73:	lea    r8,[rcx+rsi*8+0x20]
  40dd78:	mov    rsi,QWORD PTR [r8]
  40dd7b:	add    rsi,r9
  40dd7e:	mov    QWORD PTR [r8],rsi
  40dd81:	jmp    40dd50 <__swc_fn_3464c816_000175_4de704de+0x70>
  40dd83:	lea    rcx,[r10+0x2]
  40dd87:	mov    QWORD PTR [rax],rcx
  40dd8a:	pop    rsi
  40dd8b:	ret
	...

000000000040dda0 <__swc_fn_3464c816_000002_1ca87929>:
  40dda0:	push   rdi
  40dda1:	push   rsi
  40dda2:	sub    rsp,0xb8
  40dda9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ddaf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40ddb5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40ddbb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ddc1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ddc7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ddcd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40ddd3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40dddc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40dde5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ddee:	vxorps xmm0,xmm0,xmm0
  40ddf2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ddf8:	mov    edi,0x1
  40ddfd:	lea    rsi,[rsp+0x8]
  40de02:	xor    eax,eax
  40de04:	call   407110 <clock_gettime@plt>
  40de09:	vxorpd xmm0,xmm0,xmm0
  40de0d:	mov    rax,QWORD PTR [rsp+0x8]
  40de12:	vcvtsi2sd xmm0,xmm0,rax
  40de17:	vxorpd xmm1,xmm1,xmm1
  40de1b:	mov    rax,QWORD PTR [rsp+0x10]
  40de20:	vcvtsi2sd xmm1,xmm1,rax
  40de25:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x542e]        # 41325b <__swc_rdata_base_3464c816+0x14b>
  40de2d:	vaddsd xmm0,xmm0,xmm1
  40de31:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40de37:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40de3d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40de43:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40de49:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40de4f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40de55:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40de5b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40de64:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40de6d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40de76:	add    rsp,0xb8
  40de7d:	pop    rsi
  40de7e:	pop    rdi
  40de7f:	ret

000000000040de80 <__swc_fn_3464c816_000005_81d2e1e9>:
  40de80:	sub    rsp,0x8
  40de84:	call   40cd80 <__swc_fn_3464c816_000112_6b799b8d>
  40de89:	mov    rcx,rax
  40de8c:	test   rax,rax
  40de8f:	je     40deb6 <__swc_fn_3464c816_000005_81d2e1e9+0x36>
  40de91:	lea    rdx,[rip+0x161b0]        # 424048 <__swc_bss_base_3464c816+0x8>
  40de98:	mov    r8,QWORD PTR [rip+0x161a9]        # 424048 <__swc_bss_base_3464c816+0x8>
  40de9f:	nop
  40dea0:	lea    r9,[r8+0x1]
  40dea4:	mov    rax,r8
  40dea7:	lock cmpxchg QWORD PTR [rdx],r9
  40deac:	cmp    rax,r8
  40deaf:	je     40deb6 <__swc_fn_3464c816_000005_81d2e1e9+0x36>
  40deb1:	mov    r8,rax
  40deb4:	jmp    40dea0 <__swc_fn_3464c816_000005_81d2e1e9+0x20>
  40deb6:	mov    rax,rcx
  40deb9:	add    rsp,0x8
  40debd:	ret
	...

000000000040dec0 <__swc_fn_3464c816_000008_065ed5b1>:
  40dec0:	mov    r8d,edx
  40dec3:	xor    eax,eax
  40dec5:	tzcnt  eax,edx
  40dec9:	shrx   r9d,edx,eax
  40dece:	mov    DWORD PTR [rcx+0x2c],edx
  40ded1:	xor    eax,eax
  40ded3:	tzcnt  eax,edx
  40ded7:	mov    BYTE PTR [rcx+0x38],al
  40deda:	mov    eax,0xffffffff
  40dedf:	xor    edx,edx
  40dee1:	div    r8d
  40dee4:	mov    DWORD PTR [rcx+0x34],eax
  40dee7:	mov    eax,r9d
  40deea:	mov    edx,r9d
  40deed:	imul   edx,r9d
  40def1:	mov    r8d,0x2
  40def7:	sub    r8d,edx
  40defa:	imul   eax,r8d
  40defe:	mov    edx,r9d
  40df01:	imul   edx,eax
  40df04:	mov    r8d,0x2
  40df0a:	sub    r8d,edx
  40df0d:	imul   eax,r8d
  40df11:	mov    edx,r9d
  40df14:	imul   edx,eax
  40df17:	mov    r8d,0x2
  40df1d:	sub    r8d,edx
  40df20:	imul   eax,r8d
  40df24:	mov    edx,r9d
  40df27:	imul   edx,eax
  40df2a:	mov    r8d,0x2
  40df30:	sub    r8d,edx
  40df33:	imul   eax,r8d
  40df37:	imul   r9d,eax
  40df3b:	mov    edx,0x2
  40df40:	sub    edx,r9d
  40df43:	imul   eax,edx
  40df46:	mov    DWORD PTR [rcx+0x30],eax
  40df49:	ret
  40df4a:	add    BYTE PTR [rax],al
  40df4c:	add    BYTE PTR [rax],al
	...

000000000040df50 <__swc_fn_3464c816_000011_861b8b62>:
  40df50:	xor    eax,eax
  40df52:	mov    DWORD PTR [rcx+0x68],eax
  40df55:	ret
	...

000000000040df60 <__swc_fn_3464c816_000014_9dea5065>:
  40df60:	mov    eax,DWORD PTR [rcx+0x28]
  40df63:	shlx   eax,edx,eax
  40df68:	shl    rax,0x10
  40df6c:	lea    rdx,[rcx+rax*1]
  40df70:	lea    rax,[rcx+0x3000]
  40df77:	cmp    rdx,rax
  40df7a:	cmovae rax,rdx
  40df7e:	ret
	...

000000000040df80 <__swc_fn_3464c816_000017_283e2b5e>:
  40df80:	push   rsi
  40df81:	push   rdi
  40df82:	push   r12
  40df84:	push   r13
  40df86:	push   r14
  40df88:	mov    rsi,rdx
  40df8b:	mov    rdi,rcx
  40df8e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40df92:	mov    ecx,DWORD PTR [rdi+0x28]
  40df95:	shr    dl,cl
  40df97:	mov    r12d,0x1
  40df9d:	mov    ecx,edx
  40df9f:	shl    r12,cl
  40dfa2:	mov    r13d,DWORD PTR [rsi+0x3c]
  40dfa6:	rex mov BYTE PTR [rsi+0x3b],0x0
  40dfab:	mov    QWORD PTR [rsi+0x40],0x0
  40dfb3:	mov    QWORD PTR [rsi],0x0
  40dfba:	mov    rax,QWORD PTR [rsi+0x10]
  40dfbe:	mov    QWORD PTR [rsi+0x20],rax
  40dfc2:	lea    r14,[rip+0x16087]        # 424050 <__swc_bss_base_3464c816+0x10>
  40dfc9:	mov    rax,QWORD PTR [r14]
  40dfcc:	shr    rax,0x2
  40dfd0:	mov    rcx,rax
  40dfd3:	cmp    rax,0x800000
  40dfda:	mov    eax,0x800000
  40dfdf:	cmovb  rcx,rax
  40dfe3:	lea    r8,[rip+0x16076]        # 424060 <__swc_bss_base_3464c816+0x20>
  40dfea:	mov    rax,QWORD PTR [r8]
  40dfed:	mov    r9,rax
  40dff0:	lea    r10,[r9+r13*1]
  40dff4:	cmp    r10,rcx
  40dff7:	ja     40e01b <__swc_fn_3464c816_000017_283e2b5e+0x9b>
  40dff9:	mov    rax,r9
  40dffc:	lock cmpxchg QWORD PTR [r8],r10
  40e001:	cmp    rax,r9
  40e004:	je     40e00b <__swc_fn_3464c816_000017_283e2b5e+0x8b>
  40e006:	mov    r9,rax
  40e009:	jmp    40dff0 <__swc_fn_3464c816_000017_283e2b5e+0x70>
  40e00b:	mov    rcx,rdi
  40e00e:	mov    rdx,r12
  40e011:	call   40aeb0 <__swc_fn_3464c816_000019_de02dbdf>
  40e016:	jmp    40e09d <__swc_fn_3464c816_000017_283e2b5e+0x11d>
  40e01b:	mov    rcx,rdi
  40e01e:	movzx  edx,dl
  40e021:	call   40df60 <__swc_fn_3464c816_000014_9dea5065>
  40e026:	test   r13,r13
  40e029:	je     40e096 <__swc_fn_3464c816_000017_283e2b5e+0x116>
  40e02f:	mov    rcx,rax
  40e032:	mov    rdx,r13
  40e035:	call   40cf00 <__swc_fn_3464c816_000115_e9fc0224>
  40e03a:	mov    rcx,QWORD PTR [rip+0x1600f]        # 424050 <__swc_bss_base_3464c816+0x10>
  40e041:	cs nop WORD PTR [rax+rax*1+0x0]
  40e04b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e050:	mov    rdx,rcx
  40e053:	sub    rdx,r13
  40e056:	mov    rax,rcx
  40e059:	lock cmpxchg QWORD PTR [r14],rdx
  40e05e:	cmp    rax,rcx
  40e061:	je     40e068 <__swc_fn_3464c816_000017_283e2b5e+0xe8>
  40e063:	mov    rcx,rax
  40e066:	jmp    40e050 <__swc_fn_3464c816_000017_283e2b5e+0xd0>
  40e068:	lea    rcx,[rip+0x15ff9]        # 424068 <__swc_bss_base_3464c816+0x28>
  40e06f:	mov    rdx,QWORD PTR [rip+0x15ff2]        # 424068 <__swc_bss_base_3464c816+0x28>
  40e076:	cs nop WORD PTR [rax+rax*1+0x0]
  40e080:	lea    r8,[rdx+0x1]
  40e084:	mov    rax,rdx
  40e087:	lock cmpxchg QWORD PTR [rcx],r8
  40e08c:	cmp    rax,rdx
  40e08f:	je     40e096 <__swc_fn_3464c816_000017_283e2b5e+0x116>
  40e091:	mov    rdx,rax
  40e094:	jmp    40e080 <__swc_fn_3464c816_000017_283e2b5e+0x100>
  40e096:	mov    DWORD PTR [rsi+0x3c],0x0
  40e09d:	mov    rcx,rdi
  40e0a0:	mov    rdx,r12
  40e0a3:	call   407da0 <__swc_fn_3464c816_000021_c8f5f27c>
  40e0a8:	pop    r14
  40e0aa:	pop    r13
  40e0ac:	pop    r12
  40e0ae:	pop    rdi
  40e0af:	pop    rsi
  40e0b0:	ret
	...

000000000040e0c0 <__swc_fn_3464c816_000020_fd2b165c>:
  40e0c0:	mov    r8,QWORD PTR [rcx+0x48]
  40e0c4:	test   r8,rdx
  40e0c7:	je     40e0f8 <__swc_fn_3464c816_000020_fd2b165c+0x38>
  40e0c9:	nop    DWORD PTR [rax+0x0]
  40e0d0:	mov    rax,rdx
  40e0d3:	not    rax
  40e0d6:	mov    r9,r8
  40e0d9:	and    r9,rax
  40e0dc:	mov    rax,r8
  40e0df:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40e0e5:	cmp    rax,r8
  40e0e8:	jne    40e0f0 <__swc_fn_3464c816_000020_fd2b165c+0x30>
  40e0ea:	mov    eax,0x1
  40e0ef:	ret
  40e0f0:	mov    r8,rax
  40e0f3:	test   rax,rdx
  40e0f6:	jne    40e0d0 <__swc_fn_3464c816_000020_fd2b165c+0x10>
  40e0f8:	xor    eax,eax
  40e0fa:	ret
  40e0fb:	add    BYTE PTR [rax],al
  40e0fd:	add    BYTE PTR [rax],al
	...

000000000040e100 <__swc_fn_3464c816_000023_2685aade>:
  40e100:	push   rsi
  40e101:	push   rdi
  40e102:	push   r12
  40e104:	push   r13
  40e106:	sub    rsp,0x8
  40e10a:	mov    rsi,rdx
  40e10d:	mov    rdi,rcx
  40e110:	lea    r12,[rip+0x160e1]        # 4241f8 <__swc_bss_base_3464c816+0x1b8>
  40e117:	mov    rcx,r12
  40e11a:	call   40a040 <__swc_fn_3464c816_000138_86bb0f90>
  40e11f:	xor    eax,eax
  40e121:	mov    rcx,QWORD PTR [rip+0x160d8]        # 424200 <__swc_bss_base_3464c816+0x1c0>
  40e128:	mov    r13,rcx
  40e12b:	test   r13,r13
  40e12e:	je     40e17b <__swc_fn_3464c816_000023_2685aade+0x7b>
  40e130:	mov    rcx,QWORD PTR [r13+0x10]
  40e134:	cmp    DWORD PTR [r13+0x28],esi
  40e138:	jne    40e170 <__swc_fn_3464c816_000023_2685aade+0x70>
  40e13a:	test   rax,rax
  40e13d:	jne    40e148 <__swc_fn_3464c816_000023_2685aade+0x48>
  40e13f:	mov    QWORD PTR [rip+0x160ba],rcx        # 424200 <__swc_bss_base_3464c816+0x1c0>
  40e146:	jmp    40e14c <__swc_fn_3464c816_000023_2685aade+0x4c>
  40e148:	mov    QWORD PTR [rax+0x10],rcx
  40e14c:	vxorps xmm0,xmm0,xmm0
  40e150:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40e156:	mov    QWORD PTR [r13+0x8],rdi
  40e15a:	mov    rcx,r12
  40e15d:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40e162:	mov    rax,r13
  40e165:	add    rsp,0x8
  40e169:	pop    r13
  40e16b:	pop    r12
  40e16d:	pop    rdi
  40e16e:	pop    rsi
  40e16f:	ret
  40e170:	mov    rax,r13
  40e173:	mov    r13,rcx
  40e176:	test   rcx,rcx
  40e179:	jne    40e130 <__swc_fn_3464c816_000023_2685aade+0x30>
  40e17b:	mov    ecx,esi
  40e17d:	call   40aee0 <__swc_fn_3464c816_000022_2d0fcd2c>
  40e182:	mov    rsi,rax
  40e185:	test   rax,rax
  40e188:	jne    40e19f <__swc_fn_3464c816_000023_2685aade+0x9f>
  40e18a:	mov    rcx,r12
  40e18d:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40e192:	xor    eax,eax
  40e194:	add    rsp,0x8
  40e198:	pop    r13
  40e19a:	pop    r12
  40e19c:	pop    rdi
  40e19d:	pop    rsi
  40e19e:	ret
  40e19f:	mov    QWORD PTR [rsi+0x8],rdi
  40e1a3:	mov    rcx,r12
  40e1a6:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40e1ab:	mov    rax,rsi
  40e1ae:	add    rsp,0x8
  40e1b2:	pop    r13
  40e1b4:	pop    r12
  40e1b6:	pop    rdi
  40e1b7:	pop    rsi
  40e1b8:	ret
  40e1b9:	add    BYTE PTR [rax],al
  40e1bb:	add    BYTE PTR [rax],al
  40e1bd:	add    BYTE PTR [rax],al
	...

000000000040e1c0 <__swc_fn_3464c816_000026_9798fb47>:
  40e1c0:	vxorps xmm0,xmm0,xmm0
  40e1c4:	xor    eax,eax
  40e1c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e1d0:	cs nop WORD PTR [rax+rax*1+0x0]
  40e1da:	nop    WORD PTR [rax+rax*1+0x0]
  40e1e0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40e1e5:	add    rax,0x10
  40e1e9:	cmp    rax,0x2b00
  40e1f0:	jne    40e1e0 <__swc_fn_3464c816_000026_9798fb47+0x20>
  40e1f2:	ret
	...

000000000040e200 <__swc_fn_3464c816_000029_9798fb47>:
  40e200:	vxorps xmm0,xmm0,xmm0
  40e204:	vmovups XMMWORD PTR [rcx],xmm0
  40e208:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e20d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e212:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e217:	ret
	...

000000000040e220 <__swc_fn_3464c816_000032_9798fb47>:
  40e220:	vxorps xmm0,xmm0,xmm0
  40e224:	vmovups XMMWORD PTR [rcx],xmm0
  40e228:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e22d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e232:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e237:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40e23c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40e241:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40e246:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40e24b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40e253:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40e25b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40e263:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40e26b:	mov    QWORD PTR [rcx+0xc0],0x0
  40e276:	ret
	...

000000000040e280 <__swc_fn_3464c816_000035_92d9bbff>:
  40e280:	push   rsi
  40e281:	push   rdi
  40e282:	sub    rsp,0x8
  40e286:	mov    rsi,rcx
  40e289:	lea    rdi,[rip+0x13d78]        # 422008 <__swc_data_base_3464c816+0x8>
  40e290:	mov    rax,QWORD PTR [rdi]
  40e293:	cmp    rax,0xffffffffffffffff
  40e297:	je     40e29e <__swc_fn_3464c816_000035_92d9bbff+0x1e>
  40e299:	mov    rdi,rax
  40e29c:	jmp    40e2cb <__swc_fn_3464c816_000035_92d9bbff+0x4b>
  40e29e:	call   409d20 <__swc_fn_3464c816_000126_58f0f391>
  40e2a3:	mov    rcx,rax
  40e2a6:	cmp    rax,0xffffffffffffffff
  40e2aa:	je     40e2dc <__swc_fn_3464c816_000035_92d9bbff+0x5c>
  40e2ac:	mov    rax,0xffffffffffffffff
  40e2b3:	lock cmpxchg QWORD PTR [rdi],rcx
  40e2b8:	cmp    rax,0xffffffffffffffff
  40e2bc:	je     40e2c8 <__swc_fn_3464c816_000035_92d9bbff+0x48>
  40e2be:	mov    rdi,rax
  40e2c1:	call   40d2d0 <__swc_fn_3464c816_000127_a481cb88>
  40e2c6:	jmp    40e2cb <__swc_fn_3464c816_000035_92d9bbff+0x4b>
  40e2c8:	mov    rdi,rcx
  40e2cb:	cmp    rdi,0xffffffffffffffff
  40e2cf:	je     40e2dc <__swc_fn_3464c816_000035_92d9bbff+0x5c>
  40e2d1:	mov    rcx,rdi
  40e2d4:	mov    rdx,rsi
  40e2d7:	call   410390 <__swc_fn_3464c816_000128_4bbe3f14>
  40e2dc:	add    rsp,0x8
  40e2e0:	pop    rdi
  40e2e1:	pop    rsi
  40e2e2:	ret
	...

000000000040e2f0 <__swc_fn_3464c816_000038_03f1bf9a>:
  40e2f0:	sub    rsp,0x38
  40e2f4:	mov    rax,rdx
  40e2f7:	test   dl,dl
  40e2f9:	jne    40e311 <__swc_fn_3464c816_000038_03f1bf9a+0x21>
  40e2fb:	mov    rax,r8
  40e2fe:	test   r8b,r8b
  40e301:	cmove  eax,r9d
  40e305:	test   al,al
  40e307:	cmove  eax,r10d
  40e30b:	test   al,al
  40e30d:	cmove  eax,r11d
  40e311:	test   al,al
  40e313:	jne    40e31a <__swc_fn_3464c816_000038_03f1bf9a+0x2a>
  40e315:	add    rsp,0x38
  40e319:	ret
  40e31a:	lea    rcx,[rip+0x4f47]        # 413268 <__swc_rdata_base_3464c816+0x158>
  40e321:	vmovups xmm0,XMMWORD PTR [rip+0x4f4f]        # 413278 <__swc_rdata_base_3464c816+0x168>
  40e329:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e32f:	vmovups xmm0,XMMWORD PTR [rip+0x4f51]        # 413288 <__swc_rdata_base_3464c816+0x178>
  40e337:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e33d:	vmovups xmm0,XMMWORD PTR [rip+0x4f53]        # 413298 <__swc_rdata_base_3464c816+0x188>
  40e345:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e34b:	lea    rdx,[rsp+0x8]
  40e350:	call   40cb00 <__swc_fn_3464c816_000106_90faaa26>
  40e355:	jmp    40e315 <__swc_fn_3464c816_000038_03f1bf9a+0x25>
	...

000000000040e360 <__swc_fn_3464c816_000041_facd3e17>:
  40e360:	sub    rsp,0x8
  40e364:	mov    eax,0x1000
  40e369:	test   eax,eax
  40e36b:	mov    r8d,0x8
  40e371:	cmove  eax,r8d
  40e375:	dec    rax
  40e378:	mov    r8,0xffffffffffffffff
  40e37f:	sub    r8,rax
  40e382:	cmp    rdx,r8
  40e385:	ja     40e395 <__swc_fn_3464c816_000041_facd3e17+0x35>
  40e387:	add    rdx,rax
  40e38a:	not    rax
  40e38d:	mov    r8,rdx
  40e390:	and    r8,rax
  40e393:	jne    40e39c <__swc_fn_3464c816_000041_facd3e17+0x3c>
  40e395:	xor    eax,eax
  40e397:	add    rsp,0x8
  40e39b:	ret
  40e39c:	mov    rdx,r8
  40e39f:	call   40b200 <__swc_fn_3464c816_000040_c90d80c1>
  40e3a4:	add    rsp,0x8
  40e3a8:	ret
  40e3a9:	add    BYTE PTR [rax],al
  40e3ab:	add    BYTE PTR [rax],al
  40e3ad:	add    BYTE PTR [rax],al
	...

000000000040e3b0 <__swc_fn_3464c816_000044_d8bd27c3>:
  40e3b0:	push   rsi
  40e3b1:	push   rdi
  40e3b2:	sub    rsp,0x8
  40e3b6:	mov    rsi,rdx
  40e3b9:	mov    rdi,rcx
  40e3bc:	test   rdx,rdx
  40e3bf:	je     40e3db <__swc_fn_3464c816_000044_d8bd27c3+0x2b>
  40e3c1:	xor    ecx,ecx
  40e3c3:	call   407ec0 <__swc_fn_3464c816_000036_28d0e998>
  40e3c8:	mov    rax,QWORD PTR [rsi]
  40e3cb:	test   rax,rax
  40e3ce:	je     40e3db <__swc_fn_3464c816_000044_d8bd27c3+0x2b>
  40e3d0:	mov    rcx,rax
  40e3d3:	mov    rdx,rsi
  40e3d6:	call   407fe0 <__swc_fn_3464c816_000045_b30433d0>
  40e3db:	mov    rcx,rdi
  40e3de:	call   40b260 <__swc_fn_3464c816_000043_a78ae66b>
  40e3e3:	mov    rsi,rax
  40e3e6:	test   rax,rax
  40e3e9:	jne    40e3f4 <__swc_fn_3464c816_000044_d8bd27c3+0x44>
  40e3eb:	xor    eax,eax
  40e3ed:	add    rsp,0x8
  40e3f1:	pop    rdi
  40e3f2:	pop    rsi
  40e3f3:	ret
  40e3f4:	mov    rcx,rsi
  40e3f7:	call   407ec0 <__swc_fn_3464c816_000036_28d0e998>
  40e3fc:	mov    rax,rsi
  40e3ff:	add    rsp,0x8
  40e403:	pop    rdi
  40e404:	pop    rsi
  40e405:	ret
	...

000000000040e410 <__swc_fn_3464c816_000047_137687bb>:
  40e410:	movzx  eax,BYTE PTR [r8+0x39]
  40e415:	lea    rax,[rax+rax*4]
  40e419:	lea    rax,[rdx+rax*8+0x28]
  40e41e:	mov    ecx,DWORD PTR [r8+0x6c]
  40e422:	test   ecx,ecx
  40e424:	je     40e45d <__swc_fn_3464c816_000047_137687bb+0x4d>
  40e426:	mov    rcx,QWORD PTR [r8+0x50]
  40e42a:	test   rcx,rcx
  40e42d:	je     40e439 <__swc_fn_3464c816_000047_137687bb+0x29>
  40e42f:	mov    rax,QWORD PTR [r8+0x48]
  40e433:	mov    QWORD PTR [rcx+0x48],rax
  40e437:	jmp    40e441 <__swc_fn_3464c816_000047_137687bb+0x31>
  40e439:	mov    rcx,QWORD PTR [r8+0x48]
  40e43d:	mov    QWORD PTR [rax+0x18],rcx
  40e441:	mov    rax,QWORD PTR [r8+0x48]
  40e445:	test   rax,rax
  40e448:	je     40e452 <__swc_fn_3464c816_000047_137687bb+0x42>
  40e44a:	mov    rcx,QWORD PTR [r8+0x50]
  40e44e:	mov    QWORD PTR [rax+0x50],rcx
  40e452:	vxorps xmm0,xmm0,xmm0
  40e456:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e45c:	ret
  40e45d:	mov    rcx,QWORD PTR [r8+0x50]
  40e461:	test   rcx,rcx
  40e464:	je     40e470 <__swc_fn_3464c816_000047_137687bb+0x60>
  40e466:	mov    rdx,QWORD PTR [r8+0x48]
  40e46a:	mov    QWORD PTR [rcx+0x48],rdx
  40e46e:	jmp    40e478 <__swc_fn_3464c816_000047_137687bb+0x68>
  40e470:	mov    rcx,QWORD PTR [r8+0x48]
  40e474:	mov    QWORD PTR [rax+0x8],rcx
  40e478:	mov    rcx,QWORD PTR [r8+0x48]
  40e47c:	test   rcx,rcx
  40e47f:	je     40e48b <__swc_fn_3464c816_000047_137687bb+0x7b>
  40e481:	mov    rdx,QWORD PTR [r8+0x50]
  40e485:	mov    QWORD PTR [rcx+0x50],rdx
  40e489:	jmp    40e493 <__swc_fn_3464c816_000047_137687bb+0x83>
  40e48b:	mov    rcx,QWORD PTR [r8+0x50]
  40e48f:	mov    QWORD PTR [rax+0x10],rcx
  40e493:	cmp    QWORD PTR [rax],r8
  40e496:	jne    40e49f <__swc_fn_3464c816_000047_137687bb+0x8f>
  40e498:	mov    QWORD PTR [rax],0x0
  40e49f:	vxorps xmm0,xmm0,xmm0
  40e4a3:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e4a9:	ret
  40e4aa:	add    BYTE PTR [rax],al
  40e4ac:	add    BYTE PTR [rax],al
	...

000000000040e4b0 <__swc_fn_3464c816_000050_e072b516>:
  40e4b0:	sub    rsp,0x8
  40e4b4:	mov    r9,r8
  40e4b7:	mov    r10,rdx
  40e4ba:	call   40e410 <__swc_fn_3464c816_000047_137687bb>
  40e4bf:	mov    DWORD PTR [r9+0x6c],0x0
  40e4c7:	movzx  eax,BYTE PTR [r9+0x39]
  40e4cc:	lea    rax,[rax+rax*4]
  40e4d0:	lea    rax,[r10+rax*8+0x28]
  40e4d5:	mov    rcx,QWORD PTR [rax+0x10]
  40e4d9:	mov    QWORD PTR [r9+0x50],rcx
  40e4dd:	mov    QWORD PTR [r9+0x48],0x0
  40e4e5:	mov    rcx,QWORD PTR [rax+0x10]
  40e4e9:	test   rcx,rcx
  40e4ec:	je     40e4f4 <__swc_fn_3464c816_000050_e072b516+0x44>
  40e4ee:	mov    QWORD PTR [rcx+0x48],r9
  40e4f2:	jmp    40e4f8 <__swc_fn_3464c816_000050_e072b516+0x48>
  40e4f4:	mov    QWORD PTR [rax+0x8],r9
  40e4f8:	mov    QWORD PTR [rax+0x10],r9
  40e4fc:	add    rsp,0x8
  40e500:	ret
	...

000000000040e520 <__swc_fn_3464c816_000053_faa92dcc>:
  40e520:	push   rsi
  40e521:	push   rdi
  40e522:	push   r12
  40e524:	push   r13
  40e526:	push   r14
  40e528:	push   r15
  40e52a:	sub    rsp,0x1f8
  40e531:	mov    esi,r8d
  40e534:	mov    QWORD PTR [rsp+0x1e8],rsi
  40e53c:	mov    rdi,rcx
  40e53f:	mov    r12,rdx
  40e542:	lea    r13,[rsi+rsi*4]
  40e546:	lea    r13,[rdx+r13*8+0x28]
  40e54b:	call   408440 <__swc_fn_3464c816_000051_d846b172>
  40e550:	add    DWORD PTR [r12+0x24],0x1
  40e556:	test   BYTE PTR [r12+0x24],0x3f
  40e55c:	jne    40e566 <__swc_fn_3464c816_000053_faa92dcc+0x46>
  40e55e:	mov    rcx,rdi
  40e561:	call   40b3e0 <__swc_fn_3464c816_000052_3af34d7f>
  40e566:	mov    rax,QWORD PTR [r13+0x8]
  40e56a:	mov    r14,rax
  40e56d:	nop    DWORD PTR [rax]
  40e570:	test   r14,r14
  40e573:	jne    40e582 <__swc_fn_3464c816_000053_faa92dcc+0x62>
  40e575:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40e57d:	jmp    40e689 <__swc_fn_3464c816_000053_faa92dcc+0x169>
  40e582:	mov    r15,QWORD PTR [r14+0x48]
  40e586:	mov    rcx,r14
  40e589:	call   407b90 <__swc_fn_3464c816_000012_e4b0ddfc>
  40e58e:	mov    rax,QWORD PTR [r14]
  40e591:	test   rax,rax
  40e594:	je     40e5a6 <__swc_fn_3464c816_000053_faa92dcc+0x86>
  40e596:	mov    rcx,QWORD PTR [rax]
  40e599:	mov    QWORD PTR [r14],rcx
  40e59c:	add    DWORD PTR [r14+0x28],0x1
  40e5a1:	mov    rsi,rax
  40e5a4:	jmp    40e5c5 <__swc_fn_3464c816_000053_faa92dcc+0xa5>
  40e5a6:	mov    rax,QWORD PTR [r14+0x18]
  40e5aa:	cmp    QWORD PTR [r14+0x20],rax
  40e5ae:	jae    40e5c3 <__swc_fn_3464c816_000053_faa92dcc+0xa3>
  40e5b0:	mov    rsi,QWORD PTR [r14+0x20]
  40e5b4:	mov    eax,DWORD PTR [r14+0x2c]
  40e5b8:	add    QWORD PTR [r14+0x20],rax
  40e5bc:	add    DWORD PTR [r14+0x28],0x1
  40e5c1:	jmp    40e5c5 <__swc_fn_3464c816_000053_faa92dcc+0xa5>
  40e5c3:	xor    esi,esi
  40e5c5:	test   rsi,rsi
  40e5c8:	jne    40e60d <__swc_fn_3464c816_000053_faa92dcc+0xed>
  40e5ca:	mov    rcx,r14
  40e5cd:	call   407ac0 <__swc_fn_3464c816_000009_24a20786>
  40e5d2:	test   al,al
  40e5d4:	je     40e60d <__swc_fn_3464c816_000053_faa92dcc+0xed>
  40e5d6:	mov    rax,QWORD PTR [r14]
  40e5d9:	test   rax,rax
  40e5dc:	je     40e5eb <__swc_fn_3464c816_000053_faa92dcc+0xcb>
  40e5de:	mov    rcx,QWORD PTR [rax]
  40e5e1:	mov    QWORD PTR [r14],rcx
  40e5e4:	add    DWORD PTR [r14+0x28],0x1
  40e5e9:	jmp    40e60a <__swc_fn_3464c816_000053_faa92dcc+0xea>
  40e5eb:	mov    rax,QWORD PTR [r14+0x18]
  40e5ef:	cmp    QWORD PTR [r14+0x20],rax
  40e5f3:	jae    40e608 <__swc_fn_3464c816_000053_faa92dcc+0xe8>
  40e5f5:	mov    rax,QWORD PTR [r14+0x20]
  40e5f9:	mov    ecx,DWORD PTR [r14+0x2c]
  40e5fd:	add    QWORD PTR [r14+0x20],rcx
  40e601:	add    DWORD PTR [r14+0x28],0x1
  40e606:	jmp    40e60a <__swc_fn_3464c816_000053_faa92dcc+0xea>
  40e608:	xor    eax,eax
  40e60a:	mov    rsi,rax
  40e60d:	test   rsi,rsi
  40e610:	jne    40e663 <__swc_fn_3464c816_000053_faa92dcc+0x143>
  40e612:	mov    rcx,rdi
  40e615:	mov    rdx,r12
  40e618:	mov    r8,r14
  40e61b:	call   40b340 <__swc_fn_3464c816_000049_129b9bf4>
  40e620:	test   al,al
  40e622:	jne    40e663 <__swc_fn_3464c816_000053_faa92dcc+0x143>
  40e624:	mov    rcx,r14
  40e627:	call   407b90 <__swc_fn_3464c816_000012_e4b0ddfc>
  40e62c:	mov    rax,QWORD PTR [r14]
  40e62f:	test   rax,rax
  40e632:	je     40e641 <__swc_fn_3464c816_000053_faa92dcc+0x121>
  40e634:	mov    rcx,QWORD PTR [rax]
  40e637:	mov    QWORD PTR [r14],rcx
  40e63a:	add    DWORD PTR [r14+0x28],0x1
  40e63f:	jmp    40e660 <__swc_fn_3464c816_000053_faa92dcc+0x140>
  40e641:	mov    rax,QWORD PTR [r14+0x18]
  40e645:	cmp    QWORD PTR [r14+0x20],rax
  40e649:	jae    40e65e <__swc_fn_3464c816_000053_faa92dcc+0x13e>
  40e64b:	mov    rax,QWORD PTR [r14+0x20]
  40e64f:	mov    ecx,DWORD PTR [r14+0x2c]
  40e653:	add    QWORD PTR [r14+0x20],rcx
  40e657:	add    DWORD PTR [r14+0x28],0x1
  40e65c:	jmp    40e660 <__swc_fn_3464c816_000053_faa92dcc+0x140>
  40e65e:	xor    eax,eax
  40e660:	mov    rsi,rax
  40e663:	test   rsi,rsi
  40e666:	je     40e681 <__swc_fn_3464c816_000053_faa92dcc+0x161>
  40e668:	mov    QWORD PTR [r13+0x0],r14
  40e66c:	mov    rax,rsi
  40e66f:	add    rsp,0x1f8
  40e676:	pop    r15
  40e678:	pop    r14
  40e67a:	pop    r13
  40e67c:	pop    r12
  40e67e:	pop    rdi
  40e67f:	pop    rsi
  40e680:	ret
  40e681:	mov    r14,r15
  40e684:	jmp    40e570 <__swc_fn_3464c816_000053_faa92dcc+0x50>
  40e689:	cs nop WORD PTR [rax+rax*1+0x0]
  40e693:	cs nop WORD PTR [rax+rax*1+0x0]
  40e69d:	nop    DWORD PTR [rax]
  40e6a0:	mov    rcx,rdi
  40e6a3:	mov    rdx,r12
  40e6a6:	mov    r8d,esi
  40e6a9:	call   408180 <__swc_fn_3464c816_000048_ad48ec88>
  40e6ae:	mov    r14,rax
  40e6b1:	test   rax,rax
  40e6b4:	jne    40e6ca <__swc_fn_3464c816_000053_faa92dcc+0x1aa>
  40e6b6:	xor    eax,eax
  40e6b8:	add    rsp,0x1f8
  40e6bf:	pop    r15
  40e6c1:	pop    r14
  40e6c3:	pop    r13
  40e6c5:	pop    r12
  40e6c7:	pop    rdi
  40e6c8:	pop    rsi
  40e6c9:	ret
  40e6ca:	mov    QWORD PTR [r13+0x0],r14
  40e6ce:	mov    rax,QWORD PTR [r14]
  40e6d1:	test   rax,rax
  40e6d4:	je     40e6e6 <__swc_fn_3464c816_000053_faa92dcc+0x1c6>
  40e6d6:	mov    rcx,QWORD PTR [rax]
  40e6d9:	mov    QWORD PTR [r14],rcx
  40e6dc:	add    DWORD PTR [r14+0x28],0x1
  40e6e1:	mov    r15,rax
  40e6e4:	jmp    40e706 <__swc_fn_3464c816_000053_faa92dcc+0x1e6>
  40e6e6:	mov    rax,QWORD PTR [r14+0x18]
  40e6ea:	cmp    QWORD PTR [r14+0x20],rax
  40e6ee:	jae    40e703 <__swc_fn_3464c816_000053_faa92dcc+0x1e3>
  40e6f0:	mov    r15,QWORD PTR [r14+0x20]
  40e6f4:	mov    eax,DWORD PTR [r14+0x2c]
  40e6f8:	add    QWORD PTR [r14+0x20],rax
  40e6fc:	add    DWORD PTR [r14+0x28],0x1
  40e701:	jmp    40e706 <__swc_fn_3464c816_000053_faa92dcc+0x1e6>
  40e703:	xor    r15d,r15d
  40e706:	test   r15,r15
  40e709:	jne    40e74e <__swc_fn_3464c816_000053_faa92dcc+0x22e>
  40e70b:	mov    rcx,r14
  40e70e:	call   407ac0 <__swc_fn_3464c816_000009_24a20786>
  40e713:	test   al,al
  40e715:	je     40e74e <__swc_fn_3464c816_000053_faa92dcc+0x22e>
  40e717:	mov    rax,QWORD PTR [r14]
  40e71a:	test   rax,rax
  40e71d:	je     40e72c <__swc_fn_3464c816_000053_faa92dcc+0x20c>
  40e71f:	mov    rcx,QWORD PTR [rax]
  40e722:	mov    QWORD PTR [r14],rcx
  40e725:	add    DWORD PTR [r14+0x28],0x1
  40e72a:	jmp    40e74b <__swc_fn_3464c816_000053_faa92dcc+0x22b>
  40e72c:	mov    rax,QWORD PTR [r14+0x18]
  40e730:	cmp    QWORD PTR [r14+0x20],rax
  40e734:	jae    40e749 <__swc_fn_3464c816_000053_faa92dcc+0x229>
  40e736:	mov    rax,QWORD PTR [r14+0x20]
  40e73a:	mov    ecx,DWORD PTR [r14+0x2c]
  40e73e:	add    QWORD PTR [r14+0x20],rcx
  40e742:	add    DWORD PTR [r14+0x28],0x1
  40e747:	jmp    40e74b <__swc_fn_3464c816_000053_faa92dcc+0x22b>
  40e749:	xor    eax,eax
  40e74b:	mov    r15,rax
  40e74e:	test   r15,r15
  40e751:	je     40e6a0 <__swc_fn_3464c816_000053_faa92dcc+0x180>
  40e757:	mov    rax,r15
  40e75a:	add    rsp,0x1f8
  40e761:	pop    r15
  40e763:	pop    r14
  40e765:	pop    r13
  40e767:	pop    r12
  40e769:	pop    rdi
  40e76a:	pop    rsi
  40e76b:	ret
  40e76c:	add    BYTE PTR [rax],al
	...

000000000040e770 <__swc_fn_3464c816_000056_7e1dbcb0>:
  40e770:	push   rsi
  40e771:	push   rdi
  40e772:	push   r12
  40e774:	mov    rsi,rdx
  40e777:	mov    rax,rdx
  40e77a:	shr    rax,0xc
  40e77e:	movabs rdx,0x9e3779b97f4a7c15
  40e788:	imul   rax,rdx
  40e78c:	shr    rax,0x20
  40e790:	lea    rax,[rax*8+0x0]
  40e798:	shr    rax,0x20
  40e79c:	lea    rax,[rax*8+0x0]
  40e7a4:	lea    rax,[rcx+rax*8+0x40]
  40e7a9:	xor    edx,edx
  40e7ab:	test   dl,dl
  40e7ad:	lea    rdi,[rcx+0x8]
  40e7b1:	cmove  rdi,rax
  40e7b5:	xor    edx,edx
  40e7b7:	test   dl,dl
  40e7b9:	lea    r12,[rcx+0x30]
  40e7bd:	lea    rax,[rax+0x8]
  40e7c1:	cmove  r12,rax
  40e7c5:	mov    rcx,rdi
  40e7c8:	call   40a040 <__swc_fn_3464c816_000138_86bb0f90>
  40e7cd:	mov    QWORD PTR [rsi+0x30],0x0
  40e7d5:	mov    rax,QWORD PTR [r12]
  40e7d9:	mov    QWORD PTR [rsi+0x38],rax
  40e7dd:	test   rax,rax
  40e7e0:	je     40e7ea <__swc_fn_3464c816_000056_7e1dbcb0+0x7a>
  40e7e2:	mov    rax,QWORD PTR [rsi+0x38]
  40e7e6:	mov    QWORD PTR [rax+0x30],rsi
  40e7ea:	mov    QWORD PTR [r12],rsi
  40e7ee:	mov    rcx,rdi
  40e7f1:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40e7f6:	pop    r12
  40e7f8:	pop    rdi
  40e7f9:	pop    rsi
  40e7fa:	ret
  40e7fb:	add    BYTE PTR [rax],al
  40e7fd:	add    BYTE PTR [rax],al
	...

000000000040e800 <__swc_fn_3464c816_000059_15c28ca7>:
  40e800:	lea    rax,[rdx+rdx*4]
  40e804:	lea    rax,[rcx+rax*8+0x268]
  40e80c:	mov    rdx,QWORD PTR [rax+0x10]
  40e810:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e817:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e81f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e826:	lea    rdx,[rdx+rdx*4]
  40e82a:	lea    rdx,[rcx+rdx*8+0x268]
  40e832:	vmovups xmm0,XMMWORD PTR [rdx]
  40e836:	vmovups XMMWORD PTR [rax],xmm0
  40e83a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e83f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e844:	mov    rcx,QWORD PTR [rdx+0x20]
  40e848:	mov    QWORD PTR [rax+0x20],rcx
  40e84c:	ret
  40e84d:	add    BYTE PTR [rax],al
	...

000000000040e850 <__swc_fn_3464c816_000062_dea90857>:
  40e850:	push   rsi
  40e851:	push   rdi
  40e852:	push   r12
  40e854:	push   r13
  40e856:	sub    rsp,0x8
  40e85a:	mov    rsi,r8
  40e85d:	mov    rdi,rcx
  40e860:	mov    r12,rdx
  40e863:	xor    r13d,r13d
  40e866:	cs nop WORD PTR [rax+rax*1+0x0]
  40e870:	mov    eax,DWORD PTR [r12+0x730]
  40e878:	cmp    r13d,eax
  40e87b:	jae    40e8e1 <__swc_fn_3464c816_000062_dea90857+0x91>
  40e87d:	lea    rax,[r13+r13*4+0x0]
  40e882:	lea    rax,[r12+rax*8+0x738]
  40e88a:	mov    rdx,QWORD PTR [rax]
  40e88d:	mov    r8,QWORD PTR [rax+0x8]
  40e891:	mov    r9,QWORD PTR [rax+0x10]
  40e895:	cmp    QWORD PTR [rax+0x20],rsi
  40e899:	jb     40e8a0 <__swc_fn_3464c816_000062_dea90857+0x50>
  40e89b:	inc    r13d
  40e89e:	jmp    40e870 <__swc_fn_3464c816_000062_dea90857+0x20>
  40e8a0:	sub    DWORD PTR [r12+0x730],0x1
  40e8a9:	mov    ecx,DWORD PTR [r12+0x730]
  40e8b1:	lea    rcx,[rcx+rcx*4]
  40e8b5:	lea    rcx,[r12+rcx*8+0x738]
  40e8bd:	vmovups xmm0,XMMWORD PTR [rcx]
  40e8c1:	vmovups XMMWORD PTR [rax],xmm0
  40e8c5:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e8ca:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e8cf:	mov    rcx,QWORD PTR [rcx+0x20]
  40e8d3:	mov    QWORD PTR [rax+0x20],rcx
  40e8d7:	mov    rcx,rdi
  40e8da:	call   407ef0 <__swc_fn_3464c816_000042_d3c2ab54>
  40e8df:	jmp    40e870 <__swc_fn_3464c816_000062_dea90857+0x20>
  40e8e1:	add    rsp,0x8
  40e8e5:	pop    r13
  40e8e7:	pop    r12
  40e8e9:	pop    rdi
  40e8ea:	pop    rsi
  40e8eb:	ret
  40e8ec:	add    BYTE PTR [rax],al
	...

000000000040e8f0 <__swc_fn_3464c816_000065_de167e8d>:
  40e8f0:	push   rsi
  40e8f1:	push   rdi
  40e8f2:	push   r12
  40e8f4:	push   r13
  40e8f6:	push   r14
  40e8f8:	mov    rsi,rcx
  40e8fb:	mov    rdi,rdx
  40e8fe:	mov    r12,QWORD PTR [rdi]
  40e901:	mov    r13,QWORD PTR [rdi+0x18]
  40e905:	mov    rax,r12
  40e908:	add    rax,QWORD PTR [rdi+0x8]
  40e90c:	sub    rax,r13
  40e90f:	cmp    r8,rax
  40e912:	jbe    40e91d <__swc_fn_3464c816_000065_de167e8d+0x2d>
  40e914:	pop    r14
  40e916:	pop    r13
  40e918:	pop    r12
  40e91a:	pop    rdi
  40e91b:	pop    rsi
  40e91c:	ret
  40e91d:	lea    rax,[r13+r8*1+0x0]
  40e922:	sub    rax,r12
  40e925:	mov    ecx,0x1000
  40e92a:	test   ecx,ecx
  40e92c:	mov    edx,0x8
  40e931:	cmove  ecx,edx
  40e934:	dec    rcx
  40e937:	mov    rdx,0xffffffffffffffff
  40e93e:	sub    rdx,rcx
  40e941:	cmp    rax,rdx
  40e944:	jbe    40e94b <__swc_fn_3464c816_000065_de167e8d+0x5b>
  40e946:	xor    r14d,r14d
  40e949:	jmp    40e956 <__swc_fn_3464c816_000065_de167e8d+0x66>
  40e94b:	add    rax,rcx
  40e94e:	andn   rax,rcx,rax
  40e953:	mov    r14,rax
  40e956:	mov    rax,QWORD PTR [rdi+0x10]
  40e95a:	cmp    r14,rax
  40e95d:	ja     40e968 <__swc_fn_3464c816_000065_de167e8d+0x78>
  40e95f:	pop    r14
  40e961:	pop    r13
  40e963:	pop    r12
  40e965:	pop    rdi
  40e966:	pop    rsi
  40e967:	ret
  40e968:	mov    rax,r12
  40e96b:	add    rax,QWORD PTR [rdi+0x10]
  40e96f:	mov    rdx,r14
  40e972:	sub    rdx,QWORD PTR [rdi+0x10]
  40e976:	mov    rcx,rax
  40e979:	call   407a40 <__swc_fn_3464c816_000006_f7acedb0>
  40e97e:	test   al,al
  40e980:	jne    40e98b <__swc_fn_3464c816_000065_de167e8d+0x9b>
  40e982:	pop    r14
  40e984:	pop    r13
  40e986:	pop    r12
  40e988:	pop    rdi
  40e989:	pop    rsi
  40e98a:	ret
  40e98b:	add    r12,r14
  40e98e:	sub    r12,r13
  40e991:	mov    rcx,r12
  40e994:	sub    rcx,QWORD PTR [rdi+0x28]
  40e998:	mov    rdx,QWORD PTR [rsi+0x250]
  40e99f:	nop
  40e9a0:	lea    r8,[rdx+rcx*1]
  40e9a4:	mov    rax,rdx
  40e9a7:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40e9b0:	cmp    rax,rdx
  40e9b3:	je     40e9ba <__swc_fn_3464c816_000065_de167e8d+0xca>
  40e9b5:	mov    rdx,rax
  40e9b8:	jmp    40e9a0 <__swc_fn_3464c816_000065_de167e8d+0xb0>
  40e9ba:	mov    QWORD PTR [rdi+0x10],r14
  40e9be:	mov    QWORD PTR [rdi+0x28],r12
  40e9c2:	pop    r14
  40e9c4:	pop    r13
  40e9c6:	pop    r12
  40e9c8:	pop    rdi
  40e9c9:	pop    rsi
  40e9ca:	ret
  40e9cb:	add    BYTE PTR [rax],al
  40e9cd:	add    BYTE PTR [rax],al
	...

000000000040e9d0 <__swc_fn_3464c816_000068_7130736e>:
  40e9d0:	push   rbx
  40e9d1:	push   rsi
  40e9d2:	push   rdi
  40e9d3:	push   r12
  40e9d5:	push   r13
  40e9d7:	sub    rsp,0xe0
  40e9de:	mov    rbx,rdx
  40e9e1:	mov    rsi,rcx
  40e9e4:	cmp    DWORD PTR [rbx+0x58],0x0
  40e9e8:	je     40ea0c <__swc_fn_3464c816_000068_7130736e+0x3c>
  40e9ea:	mov    eax,DWORD PTR [rbx+0x58]
  40e9ed:	sub    eax,0x1
  40e9f0:	test   DWORD PTR [rbx+0x58],eax
  40e9f3:	je     40ea0c <__swc_fn_3464c816_000068_7130736e+0x3c>
  40e9f5:	mov    QWORD PTR [rbx+0x40],0x0
  40e9fd:	add    rsp,0xe0
  40ea04:	pop    r13
  40ea06:	pop    r12
  40ea08:	pop    rdi
  40ea09:	pop    rsi
  40ea0a:	pop    rbx
  40ea0b:	ret
  40ea0c:	mov    rax,QWORD PTR [rbx+0x40]
  40ea10:	test   rax,rax
  40ea13:	jne    40ea2f <__swc_fn_3464c816_000068_7130736e+0x5f>
  40ea15:	mov    rcx,rsi
  40ea18:	mov    rdx,rbx
  40ea1b:	call   40bff0 <__swc_fn_3464c816_000067_f3aa21af>
  40ea20:	add    rsp,0xe0
  40ea27:	pop    r13
  40ea29:	pop    r12
  40ea2b:	pop    rdi
  40ea2c:	pop    rsi
  40ea2d:	pop    rbx
  40ea2e:	ret
  40ea2f:	cmp    QWORD PTR [rbx+0x48],0x0
  40ea34:	jne    40ea50 <__swc_fn_3464c816_000068_7130736e+0x80>
  40ea36:	mov    rcx,rsi
  40ea39:	mov    rdx,rbx
  40ea3c:	call   408730 <__swc_fn_3464c816_000069_97813b89>
  40ea41:	add    rsp,0xe0
  40ea48:	pop    r13
  40ea4a:	pop    r12
  40ea4c:	pop    rdi
  40ea4d:	pop    rsi
  40ea4e:	pop    rbx
  40ea4f:	ret
  40ea50:	mov    rdi,QWORD PTR [rbx+0x40]
  40ea54:	lea    rax,[rip+0x1561d]        # 424078 <__swc_bss_base_3464c816+0x38>
  40ea5b:	mov    rcx,rdi
  40ea5e:	sub    rcx,QWORD PTR [rax+0x8]
  40ea62:	mov    rax,QWORD PTR [rip+0x1561f]        # 424088 <__swc_bss_base_3464c816+0x48>
  40ea69:	cmp    rcx,rax
  40ea6c:	jae    40ea98 <__swc_fn_3464c816_000068_7130736e+0xc8>
  40ea6e:	mov    rax,rdi
  40ea71:	and    rax,0xffffffffffc00000
  40ea78:	mov    rcx,rdi
  40ea7b:	shr    rcx,0x10
  40ea7f:	and    ecx,0x3f
  40ea82:	mov    edx,DWORD PTR [rax+0x28]
  40ea85:	shrx   ecx,ecx,edx
  40ea8a:	shl    rcx,0x4
  40ea8e:	lea    r12,[rax+rcx*8+0x80]
  40ea96:	jmp    40eaa3 <__swc_fn_3464c816_000068_7130736e+0xd3>
  40ea98:	mov    rcx,rdi
  40ea9b:	call   40b070 <__swc_fn_3464c816_000025_bcdc5519>
  40eaa0:	mov    r12,rax
  40eaa3:	test   r12,r12
  40eaa6:	je     40eab5 <__swc_fn_3464c816_000068_7130736e+0xe5>
  40eaa8:	mov    eax,DWORD PTR [r12+0x2c]
  40eaad:	mov    r9d,eax
  40eab0:	mov    r13,rax
  40eab3:	jmp    40eb34 <__swc_fn_3464c816_000068_7130736e+0x164>
  40eab5:	mov    rcx,rsi
  40eab8:	mov    rdx,rdi
  40eabb:	call   40b680 <__swc_fn_3464c816_000055_df0696cd>
  40eac0:	mov    rcx,QWORD PTR [rax+0x28]
  40eac4:	mov    r9,rcx
  40eac7:	mov    rdx,QWORD PTR [rax+0x20]
  40eacb:	mov    r13,rdx
  40eace:	cmp    QWORD PTR [rbx+0x48],rcx
  40ead2:	jbe    40eb0b <__swc_fn_3464c816_000068_7130736e+0x13b>
  40ead4:	mov    ecx,DWORD PTR [rax+0x48]
  40ead7:	cmp    DWORD PTR [rbx+0x58],ecx
  40eada:	ja     40eb0b <__swc_fn_3464c816_000068_7130736e+0x13b>
  40eadc:	mov    rcx,rsi
  40eadf:	mov    rdx,rax
  40eae2:	mov    r8,QWORD PTR [rbx+0x48]
  40eae6:	mov    QWORD PTR [rsp+0xc8],r9
  40eaee:	mov    QWORD PTR [rsp+0xd0],rax
  40eaf6:	call   40e8f0 <__swc_fn_3464c816_000065_de167e8d>
  40eafb:	mov    r9,QWORD PTR [rsp+0xc8]
  40eb03:	mov    rax,QWORD PTR [rsp+0xd0]
  40eb0b:	mov    rcx,QWORD PTR [rax+0x28]
  40eb0f:	cmp    QWORD PTR [rbx+0x48],rcx
  40eb13:	ja     40eb34 <__swc_fn_3464c816_000068_7130736e+0x164>
  40eb15:	mov    ecx,DWORD PTR [rax+0x48]
  40eb18:	cmp    DWORD PTR [rbx+0x58],ecx
  40eb1b:	ja     40eb34 <__swc_fn_3464c816_000068_7130736e+0x164>
  40eb1d:	mov    rcx,QWORD PTR [rbx+0x48]
  40eb21:	mov    QWORD PTR [rax+0x20],rcx
  40eb25:	add    rsp,0xe0
  40eb2c:	pop    r13
  40eb2e:	pop    r12
  40eb30:	pop    rdi
  40eb31:	pop    rsi
  40eb32:	pop    rbx
  40eb33:	ret
  40eb34:	test   r12,r12
  40eb37:	je     40eb69 <__swc_fn_3464c816_000068_7130736e+0x199>
  40eb39:	cmp    QWORD PTR [rbx+0x48],r9
  40eb3d:	ja     40eb69 <__swc_fn_3464c816_000068_7130736e+0x199>
  40eb3f:	cmp    DWORD PTR [rbx+0x58],0x40
  40eb43:	ja     40eb69 <__swc_fn_3464c816_000068_7130736e+0x199>
  40eb45:	cmp    DWORD PTR [rbx+0x58],0x0
  40eb49:	je     40eb56 <__swc_fn_3464c816_000068_7130736e+0x186>
  40eb4b:	mov    ecx,DWORD PTR [rbx+0x58]
  40eb4e:	dec    rcx
  40eb51:	test   rdi,rcx
  40eb54:	jne    40eb69 <__swc_fn_3464c816_000068_7130736e+0x199>
  40eb56:	mov    QWORD PTR [rbx+0x40],rdi
  40eb5a:	add    rsp,0xe0
  40eb61:	pop    r13
  40eb63:	pop    r12
  40eb65:	pop    rdi
  40eb66:	pop    rsi
  40eb67:	pop    rbx
  40eb68:	ret
  40eb69:	vmovups xmm0,XMMWORD PTR [rbx]
  40eb6d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40eb73:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40eb78:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40eb7e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40eb83:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40eb89:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40eb8e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40eb94:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40eb99:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40eb9f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40eba4:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40ebaa:	mov    QWORD PTR [rsp+0x48],0x0
  40ebb3:	mov    rcx,rsi
  40ebb6:	lea    rdx,[rsp+0x8]
  40ebbb:	call   40bff0 <__swc_fn_3464c816_000067_f3aa21af>
  40ebc0:	mov    rax,QWORD PTR [rsp+0x48]
  40ebc5:	test   rax,rax
  40ebc8:	jne    40ebe1 <__swc_fn_3464c816_000068_7130736e+0x211>
  40ebca:	mov    QWORD PTR [rbx+0x40],0x0
  40ebd2:	add    rsp,0xe0
  40ebd9:	pop    r13
  40ebdb:	pop    r12
  40ebdd:	pop    rdi
  40ebde:	pop    rsi
  40ebdf:	pop    rbx
  40ebe0:	ret
  40ebe1:	mov    rax,QWORD PTR [rbx+0x48]
  40ebe5:	cmp    r13,rax
  40ebe8:	cmovbe rax,r13
  40ebec:	mov    rcx,QWORD PTR [rsp+0x48]
  40ebf1:	mov    rdx,rdi
  40ebf4:	mov    r8,rax
  40ebf7:	call   409880 <__swc_fn_3464c816_000108_7c204aac>
  40ebfc:	vmovups xmm0,XMMWORD PTR [rbx]
  40ec00:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40ec06:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40ec0b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40ec11:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40ec16:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40ec1f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40ec24:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40ec2d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40ec32:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40ec3b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40ec40:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40ec49:	mov    QWORD PTR [rsp+0xa8],rdi
  40ec51:	mov    rcx,rsi
  40ec54:	lea    rdx,[rsp+0x68]
  40ec59:	call   408730 <__swc_fn_3464c816_000069_97813b89>
  40ec5e:	mov    rax,QWORD PTR [rsp+0x48]
  40ec63:	mov    QWORD PTR [rbx+0x40],rax
  40ec67:	add    rsp,0xe0
  40ec6e:	pop    r13
  40ec70:	pop    r12
  40ec72:	pop    rdi
  40ec73:	pop    rsi
  40ec74:	pop    rbx
  40ec75:	ret
	...

000000000040ec80 <__swc_fn_3464c816_000071_61e60aab>:
  40ec80:	push   r12
  40ec82:	push   rdi
  40ec83:	push   rsi
  40ec84:	push   r13
  40ec86:	push   r14
  40ec88:	sub    rsp,0x190
  40ec8f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40ec98:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40eca1:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40ecaa:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40ecb3:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40ecbc:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40ecc5:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40ecce:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40ecd7:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40ece0:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40ece9:	mov    r12,rcx
  40ecec:	lea    rax,[rip+0x13315]        # 422008 <__swc_data_base_3464c816+0x8>
  40ecf3:	mov    rax,QWORD PTR [rax]
  40ecf6:	cmp    rax,0xffffffffffffffff
  40ecfa:	je     40ed09 <__swc_fn_3464c816_000071_61e60aab+0x89>
  40ecfc:	mov    eax,eax
  40ecfe:	mov    edi,eax
  40ed00:	xor    eax,eax
  40ed02:	call   407000 <pthread_getspecific@plt>
  40ed07:	jmp    40ed0b <__swc_fn_3464c816_000071_61e60aab+0x8b>
  40ed09:	xor    eax,eax
  40ed0b:	test   rax,rax
  40ed0e:	jne    40ed1d <__swc_fn_3464c816_000071_61e60aab+0x9d>
  40ed10:	call   40b140 <__swc_fn_3464c816_000034_cd1a4e8c>
  40ed15:	mov    rcx,rax
  40ed18:	call   410440 <__swc_fn_3464c816_000131_5f757033>
  40ed1d:	test   rax,rax
  40ed20:	je     40ed46 <__swc_fn_3464c816_000071_61e60aab+0xc6>
  40ed22:	cmp    QWORD PTR [rax],r12
  40ed25:	jne    40ed46 <__swc_fn_3464c816_000071_61e60aab+0xc6>
  40ed27:	xor    ecx,ecx
  40ed29:	mov    QWORD PTR [rsp+0xc8],rax
  40ed31:	call   407ec0 <__swc_fn_3464c816_000036_28d0e998>
  40ed36:	mov    rdx,QWORD PTR [rsp+0xc8]
  40ed3e:	mov    rcx,r12
  40ed41:	call   407fe0 <__swc_fn_3464c816_000045_b30433d0>
  40ed46:	lea    rsi,[r12+0x10]
  40ed4b:	mov    rcx,rsi
  40ed4e:	call   40a040 <__swc_fn_3464c816_000138_86bb0f90>
  40ed53:	mov    rdi,QWORD PTR [r12+0x20]
  40ed58:	test   rdi,rdi
  40ed5b:	je     40ed9e <__swc_fn_3464c816_000071_61e60aab+0x11e>
  40ed5d:	nop    DWORD PTR [rax]
  40ed60:	mov    rcx,r12
  40ed63:	mov    rdx,rdi
  40ed66:	call   40b300 <__swc_fn_3464c816_000046_6e7a8d58>
  40ed6b:	mov    rcx,r12
  40ed6e:	mov    rdx,rdi
  40ed71:	mov    r8,0xffffffffffffffff
  40ed78:	call   40e850 <__swc_fn_3464c816_000062_dea90857>
  40ed7d:	mov    rcx,r12
  40ed80:	mov    rdx,rdi
  40ed83:	mov    r8d,0x9b8
  40ed89:	mov    r9d,0x9b8
  40ed8f:	call   407ef0 <__swc_fn_3464c816_000042_d3c2ab54>
  40ed94:	mov    rdi,QWORD PTR [r12+0x20]
  40ed99:	test   rdi,rdi
  40ed9c:	jne    40ed60 <__swc_fn_3464c816_000071_61e60aab+0xe0>
  40ed9e:	xor    eax,eax
  40eda0:	xchg   QWORD PTR [r12+0x2a80],rax
  40eda8:	test   rax,rax
  40edab:	je     40edd1 <__swc_fn_3464c816_000071_61e60aab+0x151>
  40edad:	cs nop WORD PTR [rax+rax*1+0x0]
  40edb7:	nop    WORD PTR [rax+rax*1+0x0]
  40edc0:	mov    rcx,rax
  40edc3:	mov    rax,QWORD PTR [rax+0x78]
  40edc7:	xor    edx,edx
  40edc9:	xchg   DWORD PTR [rcx+0x70],edx
  40edcc:	test   rax,rax
  40edcf:	jne    40edc0 <__swc_fn_3464c816_000071_61e60aab+0x140>
  40edd1:	mov    rax,QWORD PTR [r12+0x18]
  40edd6:	mov    rdi,rax
  40edd9:	test   rdi,rdi
  40eddc:	je     40ee71 <__swc_fn_3464c816_000071_61e60aab+0x1f1>
  40ede2:	cs nop WORD PTR [rax+rax*1+0x0]
  40edec:	nop    DWORD PTR [rax+0x0]
  40edf0:	mov    rax,QWORD PTR [rdi+0x10]
  40edf4:	mov    r8d,DWORD PTR [rdi+0x2c]
  40edf8:	xor    r9d,r9d
  40edfb:	test   r8,r8
  40edfe:	jbe    40ee5d <__swc_fn_3464c816_000071_61e60aab+0x1dd>
  40ee00:	mov    ecx,r9d
  40ee03:	shl    rcx,0x4
  40ee07:	lea    rdx,[rdi+rcx*8+0x80]
  40ee0f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40ee13:	je     40ee54 <__swc_fn_3464c816_000071_61e60aab+0x1d4>
  40ee15:	mov    DWORD PTR [rdx+0x28],0x0
  40ee1c:	mov    rcx,rdi
  40ee1f:	mov    QWORD PTR [rsp+0xd0],rax
  40ee27:	mov    QWORD PTR [rsp+0xd8],r8
  40ee2f:	mov    QWORD PTR [rsp+0xe0],r9
  40ee37:	call   40df80 <__swc_fn_3464c816_000017_283e2b5e>
  40ee3c:	mov    rax,QWORD PTR [rsp+0xd0]
  40ee44:	mov    r8,QWORD PTR [rsp+0xd8]
  40ee4c:	mov    r9,QWORD PTR [rsp+0xe0]
  40ee54:	add    r9,0x1
  40ee58:	cmp    r9,r8
  40ee5b:	jb     40ee00 <__swc_fn_3464c816_000071_61e60aab+0x180>
  40ee5d:	mov    rcx,rdi
  40ee60:	mov    rdi,rax
  40ee63:	call   407dd0 <__swc_fn_3464c816_000024_aa910677>
  40ee68:	test   rdi,rdi
  40ee6b:	jne    40edf0 <__swc_fn_3464c816_000071_61e60aab+0x170>
  40ee71:	mov    QWORD PTR [r12+0x18],0x0
  40ee7a:	mov    QWORD PTR [r12+0x28],0x0
  40ee83:	mov    rcx,rsi
  40ee86:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  40ee8b:	mov    esi,0x8
  40ee90:	xor    edi,edi
  40ee92:	test   rsi,rsi
  40ee95:	je     40eef2 <__swc_fn_3464c816_000071_61e60aab+0x272>
  40ee9b:	nop    DWORD PTR [rax+rax*1+0x0]
  40eea0:	lea    r13,[rdi*8+0x0]
  40eea8:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40eead:	test   r14,r14
  40eeb0:	je     40eee8 <__swc_fn_3464c816_000071_61e60aab+0x268>
  40eeb2:	cs nop WORD PTR [rax+rax*1+0x0]
  40eebc:	nop    DWORD PTR [rax+0x0]
  40eec0:	mov    rcx,r12
  40eec3:	mov    rdx,r14
  40eec6:	call   408590 <__swc_fn_3464c816_000057_1bb23e77>
  40eecb:	mov    rcx,r12
  40eece:	mov    rdx,QWORD PTR [r14]
  40eed1:	mov    r8,QWORD PTR [r14+0x8]
  40eed5:	mov    r9,QWORD PTR [r14+0x10]
  40eed9:	call   407ef0 <__swc_fn_3464c816_000042_d3c2ab54>
  40eede:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40eee3:	test   r14,r14
  40eee6:	jne    40eec0 <__swc_fn_3464c816_000071_61e60aab+0x240>
  40eee8:	add    rdi,0x1
  40eeec:	sub    rsi,0x1
  40eef0:	jne    40eea0 <__swc_fn_3464c816_000071_61e60aab+0x220>
  40eef2:	mov    rcx,r12
  40eef5:	call   408660 <__swc_fn_3464c816_000063_ffcd96eb>
  40eefa:	lea    rcx,[r12+0x250]
  40ef02:	mov    rdx,QWORD PTR [rcx]
  40ef05:	mov    r8,QWORD PTR [r12+0x250]
  40ef0d:	nop    DWORD PTR [rax]
  40ef10:	mov    r9,r8
  40ef13:	sub    r9,rdx
  40ef16:	mov    rax,r8
  40ef19:	lock cmpxchg QWORD PTR [rcx],r9
  40ef1e:	cmp    rax,r8
  40ef21:	je     40ef28 <__swc_fn_3464c816_000071_61e60aab+0x2a8>
  40ef23:	mov    r8,rax
  40ef26:	jmp    40ef10 <__swc_fn_3464c816_000071_61e60aab+0x290>
  40ef28:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40ef31:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40ef3a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40ef43:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40ef4c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40ef55:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40ef5e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40ef67:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40ef70:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40ef79:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40ef82:	add    rsp,0x190
  40ef89:	pop    r14
  40ef8b:	pop    r13
  40ef8d:	pop    rsi
  40ef8e:	pop    rdi
  40ef8f:	pop    r12
  40ef91:	ret
	...

000000000040efa0 <__swc_fn_3464c816_000074_64d36d78>:
  40efa0:	sub    rsp,0x8
  40efa4:	mov    QWORD PTR [rdx+0x40],0x0
  40efac:	call   40bff0 <__swc_fn_3464c816_000067_f3aa21af>
  40efb1:	add    rsp,0x8
  40efb5:	ret
	...

000000000040efc0 <__swc_fn_3464c816_000077_1966ae2e>:
  40efc0:	sub    rsp,0x8
  40efc4:	call   408730 <__swc_fn_3464c816_000069_97813b89>
  40efc9:	add    rsp,0x8
  40efcd:	ret
	...

000000000040efd0 <__swc_fn_3464c816_000080_5cc7acfc>:
  40efd0:	push   rbx
  40efd1:	push   rsi
  40efd2:	push   rdi
  40efd3:	push   r12
  40efd5:	push   r13
  40efd7:	push   r14
  40efd9:	push   r15
  40efdb:	sub    rsp,0x20
  40efdf:	mov    rbx,r11
  40efe2:	mov    rsi,rcx
  40efe5:	mov    rdi,rdx
  40efe8:	mov    r12,r8
  40efeb:	mov    r13,r9
  40efee:	mov    r14,r10
  40eff1:	mov    rcx,QWORD PTR [rip+0x15048]        # 424040 <__swc_bss_base_3464c816>
  40eff8:	test   rcx,rcx
  40effb:	jne    40f00d <__swc_fn_3464c816_000080_5cc7acfc+0x3d>
  40effd:	call   40a940 <__swc_fn_3464c816_000168_994c8876>
  40f002:	lea    rcx,[rax+0x1]
  40f006:	mov    QWORD PTR [rip+0x15033],rcx        # 424040 <__swc_bss_base_3464c816>
  40f00d:	dec    rcx
  40f010:	call   411ec0 <__swc_fn_3464c816_000170_360af05d>
  40f015:	mov    r15,rax
  40f018:	lea    r11,[rip+0x15221]        # 424240 <__swc_bss_base_3464c816+0x200>
  40f01f:	mov    rcx,r11
  40f022:	call   407ee0 <__swc_fn_3464c816_000039_eb6108f2>
  40f027:	test   al,al
  40f029:	jne    40f03a <__swc_fn_3464c816_000080_5cc7acfc+0x6a>
  40f02b:	mov    rcx,r11
  40f02e:	call   40b1a0 <__swc_fn_3464c816_000037_14f56618>
  40f033:	lea    r11,[rip+0x15206]        # 424240 <__swc_bss_base_3464c816+0x200>
  40f03a:	mov    rcx,r11
  40f03d:	mov    rdx,rsi
  40f040:	mov    r8,rdi
  40f043:	mov    r9,r12
  40f046:	mov    r10,r13
  40f049:	mov    rsi,r11
  40f04c:	mov    r11,r14
  40f04f:	call   40e2f0 <__swc_fn_3464c816_000038_03f1bf9a>
  40f054:	test   bl,bl
  40f056:	je     40f07d <__swc_fn_3464c816_000080_5cc7acfc+0xad>
  40f058:	mov    QWORD PTR [rsp+0x8],rsi
  40f05d:	lea    rax,[rip+0x4244]        # 4132a8 <__swc_rdata_base_3464c816+0x198>
  40f064:	mov    QWORD PTR [rsp+0x10],rax
  40f069:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f06f:	vmovups XMMWORD PTR [r15],xmm0
  40f074:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40f07d:	mov    rax,rsi
  40f080:	add    rsp,0x20
  40f084:	pop    r15
  40f086:	pop    r14
  40f088:	pop    r13
  40f08a:	pop    r12
  40f08c:	pop    rdi
  40f08d:	pop    rsi
  40f08e:	pop    rbx
  40f08f:	ret

000000000040f090 <__swc_fn_3464c816_000083_cf82995a>:
  40f090:	sub    rsp,0x8
  40f094:	mov    rax,rcx
  40f097:	test   rcx,rcx
  40f09a:	jne    40f0a1 <__swc_fn_3464c816_000083_cf82995a+0x11>
  40f09c:	add    rsp,0x8
  40f0a0:	ret
  40f0a1:	lea    rcx,[rax-0x10]
  40f0a5:	mov    rax,QWORD PTR [rax-0x10]
  40f0a9:	mov    rdx,rax
  40f0ac:	call   4100f0 <__swc_fn_3464c816_000116_ed2d8fed>
  40f0b1:	add    rsp,0x8
  40f0b5:	ret
	...

000000000040f0c0 <__swc_fn_3464c816_000086_ef55f6e4>:
  40f0c0:	sub    rsp,0x8
  40f0c4:	xor    r11d,r11d
  40f0c7:	call   4089f0 <__swc_fn_3464c816_000087_0d280354>
  40f0cc:	add    rsp,0x8
  40f0d0:	ret
	...

000000000040f0e0 <__swc_fn_3464c816_000089_23214800>:
  40f0e0:	push   rsi
  40f0e1:	push   rdi
  40f0e2:	push   r12
  40f0e4:	push   r13
  40f0e6:	push   r14
  40f0e8:	push   r15
  40f0ea:	sub    rsp,0x68
  40f0ee:	mov    rsi,r9
  40f0f1:	mov    rdi,rcx
  40f0f4:	mov    r12,rdx
  40f0f7:	mov    r13,r8
  40f0fa:	cmp    r8,r9
  40f0fd:	jne    40f125 <__swc_fn_3464c816_000089_23214800+0x45>
  40f0ff:	mov    rcx,rdi
  40f102:	mov    rdx,r12
  40f105:	xor    r8d,r8d
  40f108:	call   408d40 <__swc_fn_3464c816_000093_63c1827b>
  40f10d:	test   al,al
  40f10f:	je     40f125 <__swc_fn_3464c816_000089_23214800+0x45>
  40f111:	mov    eax,0x1
  40f116:	add    rsp,0x68
  40f11a:	pop    r15
  40f11c:	pop    r14
  40f11e:	pop    r13
  40f120:	pop    r12
  40f122:	pop    rdi
  40f123:	pop    rsi
  40f124:	ret
  40f125:	cmp    BYTE PTR [r12+0x2c],0xe
  40f12b:	je     40f13e <__swc_fn_3464c816_000089_23214800+0x5e>
  40f12d:	xor    eax,eax
  40f12f:	add    rsp,0x68
  40f133:	pop    r15
  40f135:	pop    r14
  40f137:	pop    r13
  40f139:	pop    r12
  40f13b:	pop    rdi
  40f13c:	pop    rsi
  40f13d:	ret
  40f13e:	mov    r14,QWORD PTR [r12+0x98]
  40f146:	mov    rax,QWORD PTR [r12+0xa0]
  40f14e:	mov    r12,rax
  40f151:	xor    r15d,r15d
  40f154:	test   r12,r12
  40f157:	je     40f1bf <__swc_fn_3464c816_000089_23214800+0xdf>
  40f159:	nop    DWORD PTR [rax+0x0]
  40f160:	mov    QWORD PTR [rsp+0x58],r12
  40f165:	lea    r12,[r15*8+0x0]
  40f16d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40f172:	mov    rcx,rax
  40f175:	call   40c780 <__swc_fn_3464c816_000085_3953ef98>
  40f17a:	cmp    BYTE PTR [rax+0x2c],0xe
  40f17e:	jne    40f1b0 <__swc_fn_3464c816_000089_23214800+0xd0>
  40f180:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40f185:	lea    r8,[r13+rcx*1+0x0]
  40f18a:	mov    rcx,rdi
  40f18d:	mov    rdx,rax
  40f190:	mov    r9,rsi
  40f193:	call   40f0e0 <__swc_fn_3464c816_000089_23214800>
  40f198:	test   al,al
  40f19a:	je     40f1b0 <__swc_fn_3464c816_000089_23214800+0xd0>
  40f19c:	mov    eax,0x1
  40f1a1:	add    rsp,0x68
  40f1a5:	pop    r15
  40f1a7:	pop    r14
  40f1a9:	pop    r13
  40f1ab:	pop    r12
  40f1ad:	pop    rdi
  40f1ae:	pop    rsi
  40f1af:	ret
  40f1b0:	add    r15,0x1
  40f1b4:	mov    r12,QWORD PTR [rsp+0x58]
  40f1b9:	sub    r12,0x1
  40f1bd:	jne    40f160 <__swc_fn_3464c816_000089_23214800+0x80>
  40f1bf:	xor    eax,eax
  40f1c1:	add    rsp,0x68
  40f1c5:	pop    r15
  40f1c7:	pop    r14
  40f1c9:	pop    r13
  40f1cb:	pop    r12
  40f1cd:	pop    rdi
  40f1ce:	pop    rsi
  40f1cf:	ret

000000000040f1d0 <__swc_fn_3464c816_000092_c2567a3b>:
  40f1d0:	push   rbp
  40f1d1:	push   rbx
  40f1d2:	push   rsi
  40f1d3:	push   rdi
  40f1d4:	push   r12
  40f1d6:	push   r13
  40f1d8:	push   r14
  40f1da:	push   r15
  40f1dc:	sub    rsp,0x38
  40f1e0:	mov    rbp,rsp
  40f1e3:	mov    rbx,r11
  40f1e6:	mov    rsi,rdx
  40f1e9:	mov    rdi,r8
  40f1ec:	mov    r12,r9
  40f1ef:	mov    QWORD PTR [rsp+0x18],r9
  40f1f4:	mov    r13,r10
  40f1f7:	movzx  r14d,BYTE PTR [rbp+0x80]
  40f1ff:	movzx  r15d,BYTE PTR [rbp+0x88]
  40f207:	test   r11,r11
  40f20a:	je     40f210 <__swc_fn_3464c816_000092_c2567a3b+0x40>
  40f20c:	xor    eax,eax
  40f20e:	mov    BYTE PTR [rbx],al
  40f210:	test   r12,r12
  40f213:	je     40f21e <__swc_fn_3464c816_000092_c2567a3b+0x4e>
  40f215:	mov    QWORD PTR [r12+0x8],0x0
  40f21e:	test   rcx,rcx
  40f221:	je     40f228 <__swc_fn_3464c816_000092_c2567a3b+0x58>
  40f223:	test   rsi,rsi
  40f226:	jne    40f23b <__swc_fn_3464c816_000092_c2567a3b+0x6b>
  40f228:	xor    eax,eax
  40f22a:	add    rsp,0x38
  40f22e:	pop    r15
  40f230:	pop    r14
  40f232:	pop    r13
  40f234:	pop    r12
  40f236:	pop    rdi
  40f237:	pop    rsi
  40f238:	pop    rbx
  40f239:	pop    rbp
  40f23a:	ret
  40f23b:	call   40c780 <__swc_fn_3464c816_000085_3953ef98>
  40f240:	mov    r12,rax
  40f243:	mov    al,r15b
  40f246:	test   r15b,r15b
  40f249:	jne    40f259 <__swc_fn_3464c816_000092_c2567a3b+0x89>
  40f24b:	mov    eax,DWORD PTR [r12+0x28]
  40f250:	and    eax,0x10000
  40f256:	setne  al
  40f259:	lea    r15,[rsp+0x8]
  40f25e:	mov    QWORD PTR [rsp+0x20],r15
  40f263:	rex mov BYTE PTR [rsp+0x8],al
  40f268:	test   DWORD PTR [rsi+0x28],0x400000
  40f26f:	je     40f2a7 <__swc_fn_3464c816_000092_c2567a3b+0xd7>
  40f271:	test   rsi,rsi
  40f274:	je     40f294 <__swc_fn_3464c816_000092_c2567a3b+0xc4>
  40f276:	mov    rax,QWORD PTR [rsi+0x38]
  40f27a:	cmp    QWORD PTR [rax+0x10],rsi
  40f27e:	jne    40f294 <__swc_fn_3464c816_000092_c2567a3b+0xc4>
  40f280:	rex mov al,BYTE PTR [rsp+0x8]
  40f285:	test   al,al
  40f287:	sete   al
  40f28a:	test   r14b,r14b
  40f28d:	sete   cl
  40f290:	test   al,cl
  40f292:	je     40f2a7 <__swc_fn_3464c816_000092_c2567a3b+0xd7>
  40f294:	xor    eax,eax
  40f296:	add    rsp,0x38
  40f29a:	pop    r15
  40f29c:	pop    r14
  40f29e:	pop    r13
  40f2a0:	pop    r12
  40f2a2:	pop    rdi
  40f2a3:	pop    rsi
  40f2a4:	pop    rbx
  40f2a5:	pop    rbp
  40f2a6:	ret
  40f2a7:	mov    r15,r12
  40f2aa:	test   r14b,r14b
  40f2ad:	jne    40f2c4 <__swc_fn_3464c816_000092_c2567a3b+0xf4>
  40f2af:	cmp    BYTE PTR [r12+0x2c],0x6
  40f2b5:	jne    40f2c4 <__swc_fn_3464c816_000092_c2567a3b+0xf4>
  40f2b7:	mov    rcx,QWORD PTR [r12+0x40]
  40f2bc:	call   40c780 <__swc_fn_3464c816_000085_3953ef98>
  40f2c1:	mov    r15,rax
  40f2c4:	test   r14b,r14b
  40f2c7:	je     40f2cd <__swc_fn_3464c816_000092_c2567a3b+0xfd>
  40f2c9:	mov    r15,QWORD PTR [r15+0x30]
  40f2cd:	mov    rcx,rsi
  40f2d0:	call   40c780 <__swc_fn_3464c816_000085_3953ef98>
  40f2d5:	mov    rsi,rax
  40f2d8:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f2dd:	je     40f314 <__swc_fn_3464c816_000092_c2567a3b+0x144>
  40f2df:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f2e4:	je     40f314 <__swc_fn_3464c816_000092_c2567a3b+0x144>
  40f2e6:	mov    eax,DWORD PTR [rsi+0x28]
  40f2e9:	and    eax,0x10000
  40f2ef:	je     40f314 <__swc_fn_3464c816_000092_c2567a3b+0x144>
  40f2f1:	rex mov al,BYTE PTR [rsp+0x8]
  40f2f6:	test   al,al
  40f2f8:	jne    40f30d <__swc_fn_3464c816_000092_c2567a3b+0x13d>
  40f2fa:	xor    eax,eax
  40f2fc:	add    rsp,0x38
  40f300:	pop    r15
  40f302:	pop    r14
  40f304:	pop    r13
  40f306:	pop    r12
  40f308:	pop    rdi
  40f309:	pop    rsi
  40f30a:	pop    rbx
  40f30b:	pop    rbp
  40f30c:	ret
  40f30d:	mov    rax,QWORD PTR [rsi+0x30]
  40f311:	mov    rsi,rax
  40f314:	mov    r14b,r13b
  40f317:	test   rbx,rbx
  40f31a:	je     40f350 <__swc_fn_3464c816_000092_c2567a3b+0x180>
  40f31c:	cmp    BYTE PTR [r12+0x2c],0x6
  40f322:	jne    40f350 <__swc_fn_3464c816_000092_c2567a3b+0x180>
  40f324:	lea    rdx,[rip+0x3fad]        # 4132d8 <__swc_rdata_base_3464c816+0x1c8>
  40f32b:	mov    rcx,rsi
  40f32e:	xor    r8d,r8d
  40f331:	call   408d40 <__swc_fn_3464c816_000093_63c1827b>
  40f336:	test   al,al
  40f338:	je     40f350 <__swc_fn_3464c816_000092_c2567a3b+0x180>
  40f33a:	mov    BYTE PTR [rbx],0x1
  40f33d:	xor    eax,eax
  40f33f:	add    rsp,0x38
  40f343:	pop    r15
  40f345:	pop    r14
  40f347:	pop    r13
  40f349:	pop    r12
  40f34b:	pop    rdi
  40f34c:	pop    rsi
  40f34d:	pop    rbx
  40f34e:	pop    rbp
  40f34f:	ret
  40f350:	test   rdi,rdi
  40f353:	jne    40f36d <__swc_fn_3464c816_000092_c2567a3b+0x19d>
  40f355:	test   r13b,r13b
  40f358:	jne    40f36d <__swc_fn_3464c816_000092_c2567a3b+0x19d>
  40f35a:	xor    eax,eax
  40f35c:	add    rsp,0x38
  40f360:	pop    r15
  40f362:	pop    r14
  40f364:	pop    r13
  40f366:	pop    r12
  40f368:	pop    rdi
  40f369:	pop    rsi
  40f36a:	pop    rbx
  40f36b:	pop    rbp
  40f36c:	ret
  40f36d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f372:	jne    40f428 <__swc_fn_3464c816_000092_c2567a3b+0x258>
  40f378:	mov    rcx,r15
  40f37b:	mov    rdx,rsi
  40f37e:	xor    r8d,r8d
  40f381:	call   408d40 <__swc_fn_3464c816_000093_63c1827b>
  40f386:	test   al,al
  40f388:	jne    40f428 <__swc_fn_3464c816_000092_c2567a3b+0x258>
  40f38e:	test   DWORD PTR [rsi+0x28],0x10000
  40f395:	je     40f3b3 <__swc_fn_3464c816_000092_c2567a3b+0x1e3>
  40f397:	rex mov al,BYTE PTR [rsp+0x8]
  40f39c:	test   al,al
  40f39e:	jne    40f3b3 <__swc_fn_3464c816_000092_c2567a3b+0x1e3>
  40f3a0:	xor    eax,eax
  40f3a2:	add    rsp,0x38
  40f3a6:	pop    r15
  40f3a8:	pop    r14
  40f3aa:	pop    r13
  40f3ac:	pop    r12
  40f3ae:	pop    rdi
  40f3af:	pop    rsi
  40f3b0:	pop    rbx
  40f3b1:	pop    rbp
  40f3b2:	ret
  40f3b3:	test   rdi,rdi
  40f3b6:	jne    40f3cb <__swc_fn_3464c816_000092_c2567a3b+0x1fb>
  40f3b8:	xor    eax,eax
  40f3ba:	add    rsp,0x38
  40f3be:	pop    r15
  40f3c0:	pop    r14
  40f3c2:	pop    r13
  40f3c4:	pop    r12
  40f3c6:	pop    rdi
  40f3c7:	pop    rsi
  40f3c8:	pop    rbx
  40f3c9:	pop    rbp
  40f3ca:	ret
  40f3cb:	mov    rcx,QWORD PTR [rsi+0x40]
  40f3cf:	call   40c780 <__swc_fn_3464c816_000085_3953ef98>
  40f3d4:	mov    rsi,rax
  40f3d7:	mov    rax,QWORD PTR [rdi]
  40f3da:	mov    rdi,rax
  40f3dd:	test   rax,rax
  40f3e0:	jne    40f423 <__swc_fn_3464c816_000092_c2567a3b+0x253>
  40f3e2:	test   rbx,rbx
  40f3e5:	je     40f423 <__swc_fn_3464c816_000092_c2567a3b+0x253>
  40f3e7:	mov    rcx,r15
  40f3ea:	mov    rdx,rsi
  40f3ed:	xor    r8d,r8d
  40f3f0:	call   408d40 <__swc_fn_3464c816_000093_63c1827b>
  40f3f5:	mov    rcx,rax
  40f3f8:	test   al,al
  40f3fa:	jne    40f41c <__swc_fn_3464c816_000092_c2567a3b+0x24c>
  40f3fc:	mov    rcx,r15
  40f3ff:	mov    rdx,rsi
  40f402:	call   40c7c0 <__swc_fn_3464c816_000088_d182c4dc>
  40f407:	mov    rcx,rax
  40f40a:	test   al,al
  40f40c:	jne    40f41c <__swc_fn_3464c816_000092_c2567a3b+0x24c>
  40f40e:	mov    rcx,rsi
  40f411:	mov    rdx,r15
  40f414:	call   40c7c0 <__swc_fn_3464c816_000088_d182c4dc>
  40f419:	mov    rcx,rax
  40f41c:	test   cl,cl
  40f41e:	setne  al
  40f421:	mov    BYTE PTR [rbx],al
  40f423:	xor    eax,eax
  40f425:	mov    r14b,al
  40f428:	test   rdi,rdi
  40f42b:	jne    40f445 <__swc_fn_3464c816_000092_c2567a3b+0x275>
  40f42d:	test   r14b,r14b
  40f430:	jne    40f445 <__swc_fn_3464c816_000092_c2567a3b+0x275>
  40f432:	xor    eax,eax
  40f434:	add    rsp,0x38
  40f438:	pop    r15
  40f43a:	pop    r14
  40f43c:	pop    r13
  40f43e:	pop    r12
  40f440:	pop    rdi
  40f441:	pop    rsi
  40f442:	pop    rbx
  40f443:	pop    rbp
  40f444:	ret
  40f445:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f44a:	je     40f456 <__swc_fn_3464c816_000092_c2567a3b+0x286>
  40f44c:	mov    r12,QWORD PTR [rsp+0x18]
  40f451:	jmp    40f4de <__swc_fn_3464c816_000092_c2567a3b+0x30e>
  40f456:	mov    r12,QWORD PTR [rsp+0x18]
  40f45b:	test   r12,r12
  40f45e:	jne    40f472 <__swc_fn_3464c816_000092_c2567a3b+0x2a2>
  40f460:	mov    rcx,r15
  40f463:	mov    rdx,rsi
  40f466:	xor    r8d,r8d
  40f469:	call   408d40 <__swc_fn_3464c816_000093_63c1827b>
  40f46e:	test   al,al
  40f470:	jne    40f4de <__swc_fn_3464c816_000092_c2567a3b+0x30e>
  40f472:	test   DWORD PTR [rsi+0x28],0x10000
  40f479:	je     40f497 <__swc_fn_3464c816_000092_c2567a3b+0x2c7>
  40f47b:	rex mov al,BYTE PTR [rsp+0x8]
  40f480:	test   al,al
  40f482:	jne    40f497 <__swc_fn_3464c816_000092_c2567a3b+0x2c7>
  40f484:	xor    eax,eax
  40f486:	add    rsp,0x38
  40f48a:	pop    r15
  40f48c:	pop    r14
  40f48e:	pop    r13
  40f490:	pop    r12
  40f492:	pop    rdi
  40f493:	pop    rsi
  40f494:	pop    rbx
  40f495:	pop    rbp
  40f496:	ret
  40f497:	test   rdi,rdi
  40f49a:	jne    40f4af <__swc_fn_3464c816_000092_c2567a3b+0x2df>
  40f49c:	xor    eax,eax
  40f49e:	add    rsp,0x38
  40f4a2:	pop    r15
  40f4a4:	pop    r14
  40f4a6:	pop    r13
  40f4a8:	pop    r12
  40f4aa:	pop    rdi
  40f4ab:	pop    rsi
  40f4ac:	pop    rbx
  40f4ad:	pop    rbp
  40f4ae:	ret
  40f4af:	cmp    QWORD PTR [rdi+0x8],0x0
  40f4b4:	jne    40f4c9 <__swc_fn_3464c816_000092_c2567a3b+0x2f9>
  40f4b6:	xor    eax,eax
  40f4b8:	add    rsp,0x38
  40f4bc:	pop    r15
  40f4be:	pop    r14
  40f4c0:	pop    r13
  40f4c2:	pop    r12
  40f4c4:	pop    rdi
  40f4c5:	pop    rsi
  40f4c6:	pop    rbx
  40f4c7:	pop    rbp
  40f4c8:	ret
  40f4c9:	mov    rax,QWORD PTR [rdi+0x8]
  40f4cd:	mov    rax,QWORD PTR [rax]
  40f4d0:	mov    rsi,rax
  40f4d3:	mov    rdi,QWORD PTR [rdi]
  40f4d6:	mov    eax,0x1
  40f4db:	mov    r14b,al
  40f4de:	test   rdi,rdi
  40f4e1:	mov    rbx,QWORD PTR [rsp+0x20]
  40f4e6:	jne    40f530 <__swc_fn_3464c816_000092_c2567a3b+0x360>
  40f4e8:	test   r14b,r14b
  40f4eb:	je     40f51d <__swc_fn_3464c816_000092_c2567a3b+0x34d>
  40f4ed:	test   r12,r12
  40f4f0:	je     40f51d <__swc_fn_3464c816_000092_c2567a3b+0x34d>
  40f4f2:	mov    rcx,r15
  40f4f5:	mov    rdx,rsi
  40f4f8:	xor    r8d,r8d
  40f4fb:	mov    r9,r12
  40f4fe:	mov    rbx,QWORD PTR [rsp+0x20]
  40f503:	movzx  r10d,BYTE PTR [rbx]
  40f507:	call   40f0c0 <__swc_fn_3464c816_000086_ef55f6e4>
  40f50c:	add    rsp,0x38
  40f510:	pop    r15
  40f512:	pop    r14
  40f514:	pop    r13
  40f516:	pop    r12
  40f518:	pop    rdi
  40f519:	pop    rsi
  40f51a:	pop    rbx
  40f51b:	pop    rbp
  40f51c:	ret
  40f51d:	xor    eax,eax
  40f51f:	add    rsp,0x38
  40f523:	pop    r15
  40f525:	pop    r14
  40f527:	pop    r13
  40f529:	pop    r12
  40f52b:	pop    rdi
  40f52c:	pop    rsi
  40f52d:	pop    rbx
  40f52e:	pop    rbp
  40f52f:	ret
  40f530:	mov    r13,rsi
  40f533:	mov    QWORD PTR [rsp+0x28],rdi
  40f538:	cmp    BYTE PTR [r15+0x2c],0xe
  40f53d:	sete   al
  40f540:	mov    r14b,al
  40f543:	jne    40f557 <__swc_fn_3464c816_000092_c2567a3b+0x387>
  40f545:	mov    rcx,rsi
  40f548:	mov    rdx,r15
  40f54b:	call   40c7c0 <__swc_fn_3464c816_000088_d182c4dc>
  40f550:	mov    r14b,al
  40f553:	test   al,al
  40f555:	jne    40f58c <__swc_fn_3464c816_000092_c2567a3b+0x3bc>
  40f557:	cmp    BYTE PTR [r15+0x2c],0x12
  40f55c:	je     40f58c <__swc_fn_3464c816_000092_c2567a3b+0x3bc>
  40f55e:	mov    rcx,r15
  40f561:	mov    rdx,rsi
  40f564:	mov    r8,rdi
  40f567:	mov    r9,r12
  40f56a:	mov    rax,rbx
  40f56d:	movzx  r10d,BYTE PTR [rax]
  40f571:	call   40f0c0 <__swc_fn_3464c816_000086_ef55f6e4>
  40f576:	test   rax,rax
  40f579:	je     40f58c <__swc_fn_3464c816_000092_c2567a3b+0x3bc>
  40f57b:	add    rsp,0x38
  40f57f:	pop    r15
  40f581:	pop    r14
  40f583:	pop    r13
  40f585:	pop    r12
  40f587:	pop    rdi
  40f588:	pop    rsi
  40f589:	pop    rbx
  40f58a:	pop    rbp
  40f58b:	ret
  40f58c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40f591:	jne    40f5b0 <__swc_fn_3464c816_000092_c2567a3b+0x3e0>
  40f593:	mov    rax,QWORD PTR [rsi+0xd8]
  40f59a:	test   rax,rax
  40f59d:	je     40f5b0 <__swc_fn_3464c816_000092_c2567a3b+0x3e0>
  40f59f:	add    rdi,QWORD PTR [rax+0x8]
  40f5a3:	mov    rax,QWORD PTR [rdi]
  40f5a6:	sub    rdi,QWORD PTR [rax+0x8]
  40f5aa:	mov    rax,QWORD PTR [rax]
  40f5ad:	mov    rsi,rax
  40f5b0:	test   r14b,r14b
  40f5b3:	je     40f5df <__swc_fn_3464c816_000092_c2567a3b+0x40f>
  40f5b5:	mov    rcx,r15
  40f5b8:	mov    rdx,rsi
  40f5bb:	mov    r8,rdi
  40f5be:	mov    r9,r13
  40f5c1:	mov    r14,QWORD PTR [rsp+0x28]
  40f5c6:	mov    r10,r14
  40f5c9:	call   408c20 <__swc_fn_3464c816_000090_c1c9085b>
  40f5ce:	add    rsp,0x38
  40f5d2:	pop    r15
  40f5d4:	pop    r14
  40f5d6:	pop    r13
  40f5d8:	pop    r12
  40f5da:	pop    rdi
  40f5db:	pop    rsi
  40f5dc:	pop    rbx
  40f5dd:	pop    rbp
  40f5de:	ret
  40f5df:	mov    rcx,r15
  40f5e2:	mov    rdx,rsi
  40f5e5:	mov    r8,rdi
  40f5e8:	mov    r9,r12
  40f5eb:	movzx  r10d,BYTE PTR [rbx]
  40f5ef:	call   40f0c0 <__swc_fn_3464c816_000086_ef55f6e4>
  40f5f4:	add    rsp,0x38
  40f5f8:	pop    r15
  40f5fa:	pop    r14
  40f5fc:	pop    r13
  40f5fe:	pop    r12
  40f600:	pop    rdi
  40f601:	pop    rsi
  40f602:	pop    rbx
  40f603:	pop    rbp
  40f604:	ret
	...

000000000040f610 <__swc_fn_3464c816_000095_93bfe675>:
  40f610:	push   rbx
  40f611:	push   rsi
  40f612:	sub    rsp,0x18
  40f616:	mov    rbx,rcx
  40f619:	mov    rcx,QWORD PTR [rip+0x14a20]        # 424040 <__swc_bss_base_3464c816>
  40f620:	test   rcx,rcx
  40f623:	jne    40f635 <__swc_fn_3464c816_000095_93bfe675+0x25>
  40f625:	call   40a940 <__swc_fn_3464c816_000168_994c8876>
  40f62a:	lea    rcx,[rax+0x1]
  40f62e:	mov    QWORD PTR [rip+0x14a0b],rcx        # 424040 <__swc_bss_base_3464c816>
  40f635:	dec    rcx
  40f638:	call   411ec0 <__swc_fn_3464c816_000170_360af05d>
  40f63d:	mov    rsi,rax
  40f640:	mov    rax,QWORD PTR [rsi+0x8]
  40f644:	test   rax,rax
  40f647:	jne    40f697 <__swc_fn_3464c816_000095_93bfe675+0x87>
  40f649:	call   40c8b0 <__swc_fn_3464c816_000094_ad13d15c>
  40f64e:	test   al,al
  40f650:	jne    40f697 <__swc_fn_3464c816_000095_93bfe675+0x87>
  40f652:	lea    rdx,[rip+0x14be7]        # 424240 <__swc_bss_base_3464c816+0x200>
  40f659:	mov    rcx,rdx
  40f65c:	call   407ee0 <__swc_fn_3464c816_000039_eb6108f2>
  40f661:	test   al,al
  40f663:	jne    40f674 <__swc_fn_3464c816_000095_93bfe675+0x64>
  40f665:	mov    rcx,rdx
  40f668:	call   40b1a0 <__swc_fn_3464c816_000037_14f56618>
  40f66d:	lea    rdx,[rip+0x14bcc]        # 424240 <__swc_bss_base_3464c816+0x200>
  40f674:	mov    QWORD PTR [rsp+0x8],rdx
  40f679:	lea    rax,[rip+0x3c28]        # 4132a8 <__swc_rdata_base_3464c816+0x198>
  40f680:	mov    QWORD PTR [rsp+0x10],rax
  40f685:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f68b:	vmovups XMMWORD PTR [rsi],xmm0
  40f68f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f697:	vmovups xmm0,XMMWORD PTR [rsi]
  40f69b:	vmovups XMMWORD PTR [rbx],xmm0
  40f69f:	mov    rax,rbx
  40f6a2:	add    rsp,0x18
  40f6a6:	pop    rsi
  40f6a7:	pop    rbx
  40f6a8:	ret
  40f6a9:	add    BYTE PTR [rax],al
  40f6ab:	add    BYTE PTR [rax],al
  40f6ad:	add    BYTE PTR [rax],al
	...

000000000040f6b0 <__swc_fn_3464c816_000098_65137b72>:
  40f6b0:	sub    rsp,0x8
  40f6b4:	call   409ae0 <__swc_fn_3464c816_000120_0a5fa85a>
  40f6b9:	add    rsp,0x8
  40f6bd:	ret
	...

000000000040f6c0 <__swc_fn_3464c816_000101_e34f54dc>:
  40f6c0:	push   rbx
  40f6c1:	push   rsi
  40f6c2:	sub    rsp,0x28
  40f6c6:	mov    rbx,rcx
  40f6c9:	xor    esi,esi
  40f6cb:	jmp    40f6e0 <__swc_fn_3464c816_000101_e34f54dc+0x20>
  40f6cd:	nop    DWORD PTR [rax]
  40f6d0:	mov    QWORD PTR [rbx+0x28],rsi
  40f6d4:	mov    rsi,rbx
  40f6d7:	mov    rbx,rax
  40f6da:	nop    WORD PTR [rax+rax*1+0x0]
  40f6e0:	test   rbx,rbx
  40f6e3:	je     40f743 <__swc_fn_3464c816_000101_e34f54dc+0x83>
  40f6e5:	mov    rcx,rbx
  40f6e8:	mov    edx,0x1
  40f6ed:	call   4089a0 <__swc_fn_3464c816_000081_63a67586>
  40f6f2:	cmp    rax,0x1
  40f6f6:	jne    40f743 <__swc_fn_3464c816_000101_e34f54dc+0x83>
  40f6f8:	mov    r10,QWORD PTR [rbx+0x18]
  40f6fc:	mov    rcx,r10
  40f6ff:	mov    edx,0x1
  40f704:	call   4089a0 <__swc_fn_3464c816_000081_63a67586>
  40f709:	cmp    rax,0x1
  40f70d:	jne    40f71c <__swc_fn_3464c816_000101_e34f54dc+0x5c>
  40f70f:	mov    rcx,r10
  40f712:	call   40ca50 <__swc_fn_3464c816_000100_d0b19c14>
  40f717:	test   rax,rax
  40f71a:	jne    40f6d0 <__swc_fn_3464c816_000101_e34f54dc+0x10>
  40f71c:	mov    rax,QWORD PTR [rbx+0x20]
  40f720:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f725:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f72b:	lea    rcx,[rsp+0x8]
  40f730:	mov    rdx,rbx
  40f733:	mov    r8d,0x30
  40f739:	mov    rbx,rax
  40f73c:	call   409100 <__swc_fn_3464c816_000099_d4bdcaa4>
  40f741:	jmp    40f6e0 <__swc_fn_3464c816_000101_e34f54dc+0x20>
  40f743:	test   rsi,rsi
  40f746:	jne    40f74f <__swc_fn_3464c816_000101_e34f54dc+0x8f>
  40f748:	add    rsp,0x28
  40f74c:	pop    rsi
  40f74d:	pop    rbx
  40f74e:	ret
  40f74f:	mov    rax,rsi
  40f752:	mov    rsi,QWORD PTR [rsi+0x28]
  40f756:	mov    rbx,QWORD PTR [rax+0x20]
  40f75a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f75f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f765:	lea    rcx,[rsp+0x18]
  40f76a:	mov    rdx,rax
  40f76d:	mov    r8d,0x30
  40f773:	call   409100 <__swc_fn_3464c816_000099_d4bdcaa4>
  40f778:	jmp    40f6e0 <__swc_fn_3464c816_000101_e34f54dc+0x20>
  40f77d:	add    BYTE PTR [rax],al
	...

000000000040f780 <__swc_fn_3464c816_000104_5a85fcf5>:
  40f780:	push   rbx
  40f781:	push   rsi
  40f782:	push   rdi
  40f783:	push   r12
  40f785:	push   r13
  40f787:	sub    rsp,0x20
  40f78b:	mov    rbx,rcx
  40f78e:	lea    rsi,[rcx+0x6f8]
  40f795:	mov    edi,0x4
  40f79a:	mov    r12,rsi
  40f79d:	test   rdi,rdi
  40f7a0:	je     40f7ea <__swc_fn_3464c816_000104_5a85fcf5+0x6a>
  40f7a2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f7ac:	nop    DWORD PTR [rax+0x0]
  40f7b0:	mov    rcx,QWORD PTR [r12+0x10]
  40f7b5:	mov    QWORD PTR [r12+0x10],0x0
  40f7be:	vxorps xmm0,xmm0,xmm0
  40f7c2:	vmovups XMMWORD PTR [r12],xmm0
  40f7c8:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f7cf:	mov    DWORD PTR [r12+0x20],0x0
  40f7d8:	call   409150 <__swc_fn_3464c816_000102_2fdd2c61>
  40f7dd:	add    r12,0x90
  40f7e4:	sub    rdi,0x1
  40f7e8:	jne    40f7b0 <__swc_fn_3464c816_000104_5a85fcf5+0x30>
  40f7ea:	mov    rax,QWORD PTR [rbx+0x938]
  40f7f1:	mov    rdi,rax
  40f7f4:	test   rdi,rdi
  40f7f7:	je     40f851 <__swc_fn_3464c816_000104_5a85fcf5+0xd1>
  40f7f9:	nop    DWORD PTR [rax+0x0]
  40f800:	mov    r12d,0x10
  40f806:	lea    r13,[rdi+0x18]
  40f80a:	test   r12,r12
  40f80d:	je     40f846 <__swc_fn_3464c816_000104_5a85fcf5+0xc6>
  40f80f:	nop
  40f810:	mov    rcx,QWORD PTR [r13+0x10]
  40f814:	mov    QWORD PTR [r13+0x10],0x0
  40f81c:	vxorps xmm0,xmm0,xmm0
  40f820:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f826:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f82c:	mov    DWORD PTR [r13+0x20],0x0
  40f834:	call   409150 <__swc_fn_3464c816_000102_2fdd2c61>
  40f839:	add    r13,0x90
  40f840:	sub    r12,0x1
  40f844:	jne    40f810 <__swc_fn_3464c816_000104_5a85fcf5+0x90>
  40f846:	mov    rax,QWORD PTR [rdi]
  40f849:	mov    rdi,rax
  40f84c:	test   rax,rax
  40f84f:	jne    40f800 <__swc_fn_3464c816_000104_5a85fcf5+0x80>
  40f851:	vxorps xmm0,xmm0,xmm0
  40f855:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f85d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f867:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f871:	mov    edi,0x4
  40f876:	mov    r12,rsi
  40f879:	lea    rsi,[rsi+0x38]
  40f87d:	test   rdi,rdi
  40f880:	je     40f8ac <__swc_fn_3464c816_000104_5a85fcf5+0x12c>
  40f882:	cs nop WORD PTR [rax+rax*1+0x0]
  40f88c:	nop    DWORD PTR [rax+0x0]
  40f890:	mov    rcx,rsi
  40f893:	call   40d8d0 <__swc_fn_3464c816_000160_13ead2ff>
  40f898:	add    rsi,0x90
  40f89f:	add    r12,0x90
  40f8a6:	sub    rdi,0x1
  40f8aa:	jne    40f890 <__swc_fn_3464c816_000104_5a85fcf5+0x110>
  40f8ac:	mov    rax,QWORD PTR [rbx+0x938]
  40f8b3:	mov    rdi,rax
  40f8b6:	mov    QWORD PTR [rbx+0x938],0x0
  40f8c1:	test   rdi,rdi
  40f8c4:	je     40f935 <__swc_fn_3464c816_000104_5a85fcf5+0x1b5>
  40f8ca:	nop    WORD PTR [rax+rax*1+0x0]
  40f8d0:	mov    esi,0x10
  40f8d5:	lea    r12,[rdi+0x18]
  40f8d9:	lea    r13,[rdi+0x50]
  40f8dd:	test   rsi,rsi
  40f8e0:	je     40f90c <__swc_fn_3464c816_000104_5a85fcf5+0x18c>
  40f8e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f8ec:	nop    DWORD PTR [rax+0x0]
  40f8f0:	mov    rcx,r13
  40f8f3:	call   40d8d0 <__swc_fn_3464c816_000160_13ead2ff>
  40f8f8:	add    r13,0x90
  40f8ff:	add    r12,0x90
  40f906:	sub    rsi,0x1
  40f90a:	jne    40f8f0 <__swc_fn_3464c816_000104_5a85fcf5+0x170>
  40f90c:	mov    rax,QWORD PTR [rdi]
  40f90f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f914:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f91a:	lea    rcx,[rsp+0x8]
  40f91f:	mov    rdx,rdi
  40f922:	mov    r8d,0x918
  40f928:	mov    rdi,rax
  40f92b:	call   409100 <__swc_fn_3464c816_000099_d4bdcaa4>
  40f930:	test   rdi,rdi
  40f933:	jne    40f8d0 <__swc_fn_3464c816_000104_5a85fcf5+0x150>
  40f935:	lea    rcx,[rbx+0x68]
  40f939:	call   40d8d0 <__swc_fn_3464c816_000160_13ead2ff>
  40f93e:	add    rsp,0x20
  40f942:	pop    r13
  40f944:	pop    r12
  40f946:	pop    rdi
  40f947:	pop    rsi
  40f948:	pop    rbx
  40f949:	ret
  40f94a:	add    BYTE PTR [rax],al
  40f94c:	add    BYTE PTR [rax],al
	...

000000000040f950 <__swc_fn_3464c816_000107_c51c3158>:
  40f950:	xor    eax,eax
  40f952:	cs nop WORD PTR [rax+rax*1+0x0]
  40f95c:	nop    DWORD PTR [rax+0x0]
  40f960:	mov    r9,r8
  40f963:	sub    r9,rax
  40f966:	cmp    r9,0x40
  40f96a:	jb     40f9a8 <__swc_fn_3464c816_000107_c51c3158+0x58>
  40f96c:	lea    r9,[rcx+rax*1]
  40f970:	lea    r10,[rdx+rax*1]
  40f974:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f97a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40f980:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40f986:	vmovups xmm3,XMMWORD PTR [r10]
  40f98b:	vmovups XMMWORD PTR [r9],xmm3
  40f990:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40f996:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40f99c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40f9a2:	lea    rax,[rax+0x40]
  40f9a6:	jmp    40f960 <__swc_fn_3464c816_000107_c51c3158+0x10>
  40f9a8:	nop    DWORD PTR [rax+rax*1+0x0]
  40f9b0:	mov    r9,r8
  40f9b3:	sub    r9,rax
  40f9b6:	cmp    r9,0x10
  40f9ba:	jb     40f9d4 <__swc_fn_3464c816_000107_c51c3158+0x84>
  40f9bc:	lea    r9,[rdx+rax*1]
  40f9c0:	lea    r10,[rcx+rax*1]
  40f9c4:	vmovups xmm0,XMMWORD PTR [r9]
  40f9c9:	vmovups XMMWORD PTR [r10],xmm0
  40f9ce:	lea    rax,[rax+0x10]
  40f9d2:	jmp    40f9b0 <__swc_fn_3464c816_000107_c51c3158+0x60>
  40f9d4:	cs nop WORD PTR [rax+rax*1+0x0]
  40f9de:	xchg   ax,ax
  40f9e0:	mov    r9,r8
  40f9e3:	sub    r9,rax
  40f9e6:	cmp    r9,0x8
  40f9ea:	jb     40f9fd <__swc_fn_3464c816_000107_c51c3158+0xad>
  40f9ec:	lea    r9,[rcx+rax*1]
  40f9f0:	mov    r10,QWORD PTR [rdx+rax*1]
  40f9f4:	mov    QWORD PTR [r9],r10
  40f9f7:	lea    rax,[rax+0x8]
  40f9fb:	jmp    40f9e0 <__swc_fn_3464c816_000107_c51c3158+0x90>
  40f9fd:	cmp    rax,r8
  40fa00:	jae    40fa20 <__swc_fn_3464c816_000107_c51c3158+0xd0>
  40fa02:	cs nop WORD PTR [rax+rax*1+0x0]
  40fa0c:	nop    DWORD PTR [rax+0x0]
  40fa10:	mov    r9b,BYTE PTR [rdx+rax*1]
  40fa14:	mov    BYTE PTR [rcx+rax*1],r9b
  40fa18:	inc    rax
  40fa1b:	cmp    rax,r8
  40fa1e:	jb     40fa10 <__swc_fn_3464c816_000107_c51c3158+0xc0>
  40fa20:	ret
	...

000000000040fa30 <__swc_fn_3464c816_000110_6814119b>:
  40fa30:	push   rbx
  40fa31:	push   r12
  40fa33:	push   rdi
  40fa34:	push   rsi
  40fa35:	push   r13
  40fa37:	push   r14
  40fa39:	push   r15
  40fa3b:	sub    rsp,0x170
  40fa42:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40fa4b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40fa54:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40fa5d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40fa66:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40fa6f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40fa78:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40fa81:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40fa8a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40fa93:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40fa9c:	mov    ebx,edx
  40fa9e:	mov    QWORD PTR [rsp+0xa8],rbx
  40faa6:	mov    r12d,ecx
  40faa9:	test   edx,edx
  40faab:	jne    40fac2 <__swc_fn_3464c816_000110_6814119b+0x92>
  40faad:	xor    eax,eax
  40faaf:	add    rsp,0x170
  40fab6:	pop    r15
  40fab8:	pop    r14
  40faba:	pop    r13
  40fabc:	pop    rsi
  40fabd:	pop    rdi
  40fabe:	pop    r12
  40fac0:	pop    rbx
  40fac1:	ret
  40fac2:	lea    rdi,[rip+0x3ae7]        # 4135b0 <__swc_rdata_base_3464c816+0x4a0>
  40fac9:	mov    esi,0x90000
  40face:	xor    eax,eax
  40fad0:	call   407090 <open@plt>
  40fad5:	mov    r13,rax
  40fad8:	mov    QWORD PTR [rsp+0xb0],rax
  40fae0:	test   eax,eax
  40fae2:	jge    40faeb <__swc_fn_3464c816_000110_6814119b+0xbb>
  40fae4:	xor    eax,eax
  40fae6:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40faeb:	nop    DWORD PTR [rax+rax*1+0x0]
  40faf0:	movsxd rdi,r13d
  40faf3:	mov    esi,0x2
  40faf8:	xor    eax,eax
  40fafa:	call   407120 <flock@plt>
  40faff:	test   eax,eax
  40fb01:	je     40fb20 <__swc_fn_3464c816_000110_6814119b+0xf0>
  40fb03:	xor    eax,eax
  40fb05:	call   407130 <__errno_location@plt>
  40fb0a:	cmp    DWORD PTR [rax],0x4
  40fb0d:	je     40faf0 <__swc_fn_3464c816_000110_6814119b+0xc0>
  40fb0f:	movsxd rdi,r13d
  40fb12:	xor    eax,eax
  40fb14:	call   4070b0 <close@plt>
  40fb19:	xor    eax,eax
  40fb1b:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40fb20:	lea    r14,[rsp+0x8]
  40fb25:	mov    QWORD PTR [rsp+0xb8],r14
  40fb2d:	vxorps xmm0,xmm0,xmm0
  40fb31:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fb37:	mov    QWORD PTR [rsp+0x18],0x0
  40fb40:	mov    WORD PTR [rsp+0x20],0x0
  40fb47:	mov    DWORD PTR [r14],0x67617753
  40fb4e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40fb56:	xor    eax,eax
  40fb58:	call   407010 <getpid@plt>
  40fb5d:	mov    ecx,eax
  40fb5f:	mov    eax,0x1c
  40fb64:	shrx   eax,ecx,eax
  40fb69:	and    eax,0xf
  40fb6c:	mov    rdx,QWORD PTR [rip+0x3a5d]        # 4135d0 <__swc_rdata_base_3464c816+0x4c0>
  40fb73:	mov    al,BYTE PTR [rdx+rax*1]
  40fb76:	rex mov BYTE PTR [rsp+0x10],al
  40fb7b:	mov    eax,0x1c
  40fb80:	shrx   eax,r12d,eax
  40fb85:	and    eax,0xf
  40fb88:	mov    al,BYTE PTR [rdx+rax*1]
  40fb8b:	rex mov BYTE PTR [rsp+0x19],al
  40fb90:	mov    eax,0x18
  40fb95:	shrx   eax,ecx,eax
  40fb9a:	and    eax,0xf
  40fb9d:	mov    al,BYTE PTR [rdx+rax*1]
  40fba0:	rex mov BYTE PTR [rsp+0x11],al
  40fba5:	mov    eax,0x18
  40fbaa:	shrx   eax,r12d,eax
  40fbaf:	and    eax,0xf
  40fbb2:	mov    al,BYTE PTR [rdx+rax*1]
  40fbb5:	rex mov BYTE PTR [rsp+0x1a],al
  40fbba:	mov    eax,0x14
  40fbbf:	shrx   eax,ecx,eax
  40fbc4:	and    eax,0xf
  40fbc7:	mov    al,BYTE PTR [rdx+rax*1]
  40fbca:	rex mov BYTE PTR [rsp+0x12],al
  40fbcf:	mov    eax,0x14
  40fbd4:	shrx   eax,r12d,eax
  40fbd9:	and    eax,0xf
  40fbdc:	mov    al,BYTE PTR [rdx+rax*1]
  40fbdf:	rex mov BYTE PTR [rsp+0x1b],al
  40fbe4:	mov    eax,0x10
  40fbe9:	shrx   eax,ecx,eax
  40fbee:	and    eax,0xf
  40fbf1:	mov    al,BYTE PTR [rdx+rax*1]
  40fbf4:	rex mov BYTE PTR [rsp+0x13],al
  40fbf9:	mov    eax,0x10
  40fbfe:	shrx   eax,r12d,eax
  40fc03:	and    eax,0xf
  40fc06:	mov    al,BYTE PTR [rdx+rax*1]
  40fc09:	rex mov BYTE PTR [rsp+0x1c],al
  40fc0e:	mov    eax,0xc
  40fc13:	shrx   eax,ecx,eax
  40fc18:	and    eax,0xf
  40fc1b:	mov    al,BYTE PTR [rdx+rax*1]
  40fc1e:	rex mov BYTE PTR [rsp+0x14],al
  40fc23:	mov    eax,0xc
  40fc28:	shrx   eax,r12d,eax
  40fc2d:	and    eax,0xf
  40fc30:	mov    al,BYTE PTR [rdx+rax*1]
  40fc33:	rex mov BYTE PTR [rsp+0x1d],al
  40fc38:	mov    eax,0x8
  40fc3d:	shrx   eax,ecx,eax
  40fc42:	and    eax,0xf
  40fc45:	mov    al,BYTE PTR [rdx+rax*1]
  40fc48:	rex mov BYTE PTR [rsp+0x15],al
  40fc4d:	mov    eax,0x8
  40fc52:	shrx   eax,r12d,eax
  40fc57:	and    eax,0xf
  40fc5a:	mov    al,BYTE PTR [rdx+rax*1]
  40fc5d:	rex mov BYTE PTR [rsp+0x1e],al
  40fc62:	mov    eax,0x4
  40fc67:	shrx   eax,ecx,eax
  40fc6c:	and    eax,0xf
  40fc6f:	mov    al,BYTE PTR [rdx+rax*1]
  40fc72:	rex mov BYTE PTR [rsp+0x16],al
  40fc77:	mov    eax,0x4
  40fc7c:	shrx   eax,r12d,eax
  40fc81:	and    eax,0xf
  40fc84:	mov    al,BYTE PTR [rdx+rax*1]
  40fc87:	rex mov BYTE PTR [rsp+0x1f],al
  40fc8c:	xor    eax,eax
  40fc8e:	shrx   eax,ecx,eax
  40fc93:	and    eax,0xf
  40fc96:	mov    al,BYTE PTR [rdx+rax*1]
  40fc99:	rex mov BYTE PTR [rsp+0x17],al
  40fc9e:	xor    eax,eax
  40fca0:	shrx   eax,r12d,eax
  40fca5:	and    eax,0xf
  40fca8:	mov    al,BYTE PTR [rdx+rax*1]
  40fcab:	rex mov BYTE PTR [rsp+0x20],al
  40fcb0:	mov    BYTE PTR [r14+0x10],0x2e
  40fcb5:	lea    r12,[rsp+0x22]
  40fcba:	vxorps xmm0,xmm0,xmm0
  40fcbe:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40fcc4:	mov    DWORD PTR [r12],0x6d656d2f
  40fccc:	mov    WORD PTR [r12+0x4],0x6466
  40fcd4:	mov    BYTE PTR [r12+0x6],0x3a
  40fcda:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40fce0:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40fce6:	mov    rax,QWORD PTR [rsp+0x18]
  40fceb:	mov    QWORD PTR [rsp+0x39],rax
  40fcf0:	rex mov al,BYTE PTR [rsp+0x20]
  40fcf5:	rex mov BYTE PTR [rsp+0x41],al
  40fcfa:	mov    DWORD PTR [r12+0x20],0x65642820
  40fd03:	mov    DWORD PTR [r12+0x24],0x6574656c
  40fd0c:	mov    WORD PTR [r12+0x28],0x2964
  40fd14:	lea    rdi,[rip+0x38a0]        # 4135bb <__swc_rdata_base_3464c816+0x4ab>
  40fd1b:	xor    eax,eax
  40fd1d:	call   407140 <opendir@plt>
  40fd22:	mov    r15,rax
  40fd25:	test   rax,rax
  40fd28:	jne    40fd3b <__swc_fn_3464c816_000110_6814119b+0x30b>
  40fd2a:	movsxd rdi,r13d
  40fd2d:	xor    eax,eax
  40fd2f:	call   4070b0 <close@plt>
  40fd34:	xor    eax,eax
  40fd36:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40fd3b:	mov    rdi,r15
  40fd3e:	xor    eax,eax
  40fd40:	call   407150 <dirfd@plt>
  40fd45:	lea    r14,[rsp+0x54]
  40fd4a:	mov    DWORD PTR [rsp+0x54],eax
  40fd4e:	lea    rbx,[rsp+0x58]
  40fd53:	cs nop WORD PTR [rax+rax*1+0x0]
  40fd5d:	nop    DWORD PTR [rax]
  40fd60:	mov    rdi,r15
  40fd63:	xor    eax,eax
  40fd65:	call   407160 <readdir@plt>
  40fd6a:	test   rax,rax
  40fd6d:	jne    40fd84 <__swc_fn_3464c816_000110_6814119b+0x354>
  40fd6f:	mov    r12,QWORD PTR [rsp+0xa8]
  40fd77:	mov    r13,QWORD PTR [rsp+0xb0]
  40fd7f:	jmp    40ff0a <__swc_fn_3464c816_000110_6814119b+0x4da>
  40fd84:	vxorps xmm0,xmm0,xmm0
  40fd88:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40fd8e:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40fd94:	vzeroupper
  40fd97:	lea    r13,[rax+0x13]
  40fd9b:	mov    rax,r14
  40fd9e:	movsxd rdi,DWORD PTR [rax]
  40fda1:	mov    rsi,r13
  40fda4:	mov    rdx,rbx
  40fda7:	mov    ecx,0x40
  40fdac:	xor    eax,eax
  40fdae:	call   407170 <readlinkat@plt>
  40fdb3:	cmp    rax,0x2a
  40fdb7:	jne    40fd60 <__swc_fn_3464c816_000110_6814119b+0x330>
  40fdb9:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40fdbf:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40fdc5:	vptest xmm0,xmm0
  40fdca:	jne    40fdfa <__swc_fn_3464c816_000110_6814119b+0x3ca>
  40fdcc:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40fdd2:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40fdd8:	vptest xmm0,xmm0
  40fddd:	jne    40fdfa <__swc_fn_3464c816_000110_6814119b+0x3ca>
  40fddf:	mov    rcx,QWORD PTR [rsp+0x42]
  40fde4:	cmp    QWORD PTR [rsp+0x78],rcx
  40fde9:	jne    40fdfa <__swc_fn_3464c816_000110_6814119b+0x3ca>
  40fdeb:	mov    cx,WORD PTR [rsp+0x4a]
  40fdf0:	cmp    WORD PTR [rsp+0x80],cx
  40fdf8:	je     40fe24 <__swc_fn_3464c816_000110_6814119b+0x3f4>
  40fdfa:	mov    rax,rbx
  40fdfd:	mov    rcx,r12
  40fe00:	movzx  edx,BYTE PTR [rax]
  40fe03:	movzx  r8d,BYTE PTR [rcx]
  40fe07:	cmp    rdx,r8
  40fe0a:	jne    40fe16 <__swc_fn_3464c816_000110_6814119b+0x3e6>
  40fe0c:	add    rax,0x1
  40fe10:	add    rcx,0x1
  40fe14:	jmp    40fe00 <__swc_fn_3464c816_000110_6814119b+0x3d0>
  40fe16:	mov    rax,rdx
  40fe19:	sub    rax,r8
  40fe1c:	test   eax,eax
  40fe1e:	jne    40fd60 <__swc_fn_3464c816_000110_6814119b+0x330>
  40fe24:	movsxd rdi,DWORD PTR [r14]
  40fe27:	mov    rsi,r13
  40fe2a:	mov    edx,0x80002
  40fe2f:	xor    eax,eax
  40fe31:	call   407180 <openat@plt>
  40fe36:	lea    rbx,[rsp+0x98]
  40fe3e:	mov    DWORD PTR [rsp+0x98],eax
  40fe45:	test   eax,eax
  40fe47:	mov    r13,QWORD PTR [rsp+0xb0]
  40fe4f:	jge    40fe74 <__swc_fn_3464c816_000110_6814119b+0x444>
  40fe51:	mov    rdi,r15
  40fe54:	xor    eax,eax
  40fe56:	call   407190 <closedir@plt>
  40fe5b:	mov    r13,QWORD PTR [rsp+0xb0]
  40fe63:	movsxd rdi,r13d
  40fe66:	xor    eax,eax
  40fe68:	call   4070b0 <close@plt>
  40fe6d:	xor    eax,eax
  40fe6f:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40fe74:	mov    rax,rbx
  40fe77:	movsxd rdi,DWORD PTR [rax]
  40fe7a:	xor    esi,esi
  40fe7c:	mov    edx,0x2
  40fe81:	xor    eax,eax
  40fe83:	call   4070a0 <lseek@plt>
  40fe88:	mov    r12,QWORD PTR [rsp+0xa8]
  40fe90:	cmp    rax,r12
  40fe93:	je     40feba <__swc_fn_3464c816_000110_6814119b+0x48a>
  40fe95:	movsxd rdi,DWORD PTR [rbx]
  40fe98:	xor    eax,eax
  40fe9a:	call   4070b0 <close@plt>
  40fe9f:	mov    rdi,r15
  40fea2:	xor    eax,eax
  40fea4:	call   407190 <closedir@plt>
  40fea9:	movsxd rdi,r13d
  40feac:	xor    eax,eax
  40feae:	call   4070b0 <close@plt>
  40feb3:	xor    eax,eax
  40feb5:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40feba:	xor    edi,edi
  40febc:	mov    rsi,r12
  40febf:	mov    edx,0x3
  40fec4:	mov    ecx,0x1
  40fec9:	mov    rax,rbx
  40fecc:	movsxd r8,DWORD PTR [rax]
  40fecf:	xor    r9d,r9d
  40fed2:	xor    eax,eax
  40fed4:	call   4070c0 <mmap@plt>
  40fed9:	xor    r12d,r12d
  40fedc:	cmp    rax,0xffffffffffffffff
  40fee0:	cmovne r12,rax
  40fee4:	movsxd rdi,DWORD PTR [rbx]
  40fee7:	xor    eax,eax
  40fee9:	call   4070b0 <close@plt>
  40feee:	mov    rdi,r15
  40fef1:	xor    eax,eax
  40fef3:	call   407190 <closedir@plt>
  40fef8:	movsxd rdi,r13d
  40fefb:	xor    eax,eax
  40fefd:	call   4070b0 <close@plt>
  40ff02:	mov    rax,r12
  40ff05:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40ff0a:	mov    r14,QWORD PTR [rsp+0xb8]
  40ff12:	mov    rdi,r14
  40ff15:	mov    esi,0x1
  40ff1a:	xor    eax,eax
  40ff1c:	call   4071a0 <memfd_create@plt>
  40ff21:	lea    rbx,[rsp+0x9c]
  40ff29:	mov    DWORD PTR [rsp+0x9c],eax
  40ff30:	test   eax,eax
  40ff32:	jge    40ff4f <__swc_fn_3464c816_000110_6814119b+0x51f>
  40ff34:	mov    rdi,r15
  40ff37:	xor    eax,eax
  40ff39:	call   407190 <closedir@plt>
  40ff3e:	movsxd rdi,r13d
  40ff41:	xor    eax,eax
  40ff43:	call   4070b0 <close@plt>
  40ff48:	xor    eax,eax
  40ff4a:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40ff4f:	mov    rax,rbx
  40ff52:	movsxd rdi,DWORD PTR [rax]
  40ff55:	mov    rsi,r12
  40ff58:	xor    eax,eax
  40ff5a:	call   4071b0 <ftruncate@plt>
  40ff5f:	test   eax,eax
  40ff61:	je     40ff85 <__swc_fn_3464c816_000110_6814119b+0x555>
  40ff63:	movsxd rdi,DWORD PTR [rbx]
  40ff66:	xor    eax,eax
  40ff68:	call   4070b0 <close@plt>
  40ff6d:	mov    rdi,r15
  40ff70:	xor    eax,eax
  40ff72:	call   407190 <closedir@plt>
  40ff77:	movsxd rdi,r13d
  40ff7a:	xor    eax,eax
  40ff7c:	call   4070b0 <close@plt>
  40ff81:	xor    eax,eax
  40ff83:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40ff85:	xor    edi,edi
  40ff87:	mov    rsi,r12
  40ff8a:	mov    edx,0x3
  40ff8f:	mov    ecx,0x1
  40ff94:	mov    rax,rbx
  40ff97:	movsxd r8,DWORD PTR [rax]
  40ff9a:	xor    r9d,r9d
  40ff9d:	xor    eax,eax
  40ff9f:	call   4070c0 <mmap@plt>
  40ffa4:	mov    r12,rax
  40ffa7:	cmp    rax,0xffffffffffffffff
  40ffab:	jne    40ffcf <__swc_fn_3464c816_000110_6814119b+0x59f>
  40ffad:	movsxd rdi,DWORD PTR [rbx]
  40ffb0:	xor    eax,eax
  40ffb2:	call   4070b0 <close@plt>
  40ffb7:	mov    rdi,r15
  40ffba:	xor    eax,eax
  40ffbc:	call   407190 <closedir@plt>
  40ffc1:	movsxd rdi,r13d
  40ffc4:	xor    eax,eax
  40ffc6:	call   4070b0 <close@plt>
  40ffcb:	xor    eax,eax
  40ffcd:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40ffcf:	mov    rdi,r15
  40ffd2:	xor    eax,eax
  40ffd4:	call   407190 <closedir@plt>
  40ffd9:	movsxd rdi,r13d
  40ffdc:	xor    eax,eax
  40ffde:	call   4070b0 <close@plt>
  40ffe3:	mov    rax,r12
  40ffe6:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40ffef:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40fff8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  410001:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  41000a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  410013:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  41001c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  410025:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  41002e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  410037:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  410040:	add    rsp,0x170
  410047:	pop    r15
  410049:	pop    r14
  41004b:	pop    r13
  41004d:	pop    rsi
  41004e:	pop    rdi
  41004f:	pop    r12
  410051:	pop    rbx
  410052:	ret
	...

0000000000410060 <__swc_fn_3464c816_000113_5f48311c>:
  410060:	push   rsi
  410061:	push   rdi
  410062:	push   r12
  410064:	push   r13
  410066:	sub    rsp,0x8
  41006a:	mov    rsi,r8
  41006d:	mov    rdi,rcx
  410070:	mov    r12,rdx
  410073:	call   4098a0 <__swc_fn_3464c816_000111_126150d1>
  410078:	mov    r13,rax
  41007b:	test   rax,rax
  41007e:	jne    41008b <__swc_fn_3464c816_000113_5f48311c+0x2b>
  410080:	add    rsp,0x8
  410084:	pop    r13
  410086:	pop    r12
  410088:	pop    rdi
  410089:	pop    rsi
  41008a:	ret
  41008b:	mov    rcx,r13
  41008e:	call   40d4d0 <__swc_fn_3464c816_000136_8c07c14b>
  410093:	mov    rax,QWORD PTR [r13+0x8]
  410097:	test   rax,rax
  41009a:	je     4100d9 <__swc_fn_3464c816_000113_5f48311c+0x79>
  41009c:	nop    DWORD PTR [rax+0x0]
  4100a0:	lea    rcx,[rax+0x1000]
  4100a7:	cmp    rdi,rcx
  4100aa:	jne    4100d1 <__swc_fn_3464c816_000113_5f48311c+0x71>
  4100ac:	cmp    r12,0x1000
  4100b3:	jb     4100d1 <__swc_fn_3464c816_000113_5f48311c+0x71>
  4100b5:	test   sil,sil
  4100b8:	setne  cl
  4100bb:	mov    BYTE PTR [rax+0x10],cl
  4100be:	mov    rcx,r13
  4100c1:	call   4105c0 <__swc_fn_3464c816_000137_715e84ff>
  4100c6:	add    rsp,0x8
  4100ca:	pop    r13
  4100cc:	pop    r12
  4100ce:	pop    rdi
  4100cf:	pop    rsi
  4100d0:	ret
  4100d1:	mov    rax,QWORD PTR [rax]
  4100d4:	test   rax,rax
  4100d7:	jne    4100a0 <__swc_fn_3464c816_000113_5f48311c+0x40>
  4100d9:	mov    rcx,r13
  4100dc:	call   4105c0 <__swc_fn_3464c816_000137_715e84ff>
  4100e1:	add    rsp,0x8
  4100e5:	pop    r13
  4100e7:	pop    r12
  4100e9:	pop    rdi
  4100ea:	pop    rsi
  4100eb:	ret
  4100ec:	add    BYTE PTR [rax],al
	...

00000000004100f0 <__swc_fn_3464c816_000116_ed2d8fed>:
  4100f0:	sub    rsp,0x8
  4100f4:	test   rcx,rcx
  4100f7:	jne    4100fe <__swc_fn_3464c816_000116_ed2d8fed+0xe>
  4100f9:	add    rsp,0x8
  4100fd:	ret
  4100fe:	call   40cfe0 <__swc_fn_3464c816_000118_d3318640>
  410103:	add    rsp,0x8
  410107:	ret
	...

0000000000410110 <__swc_fn_3464c816_000119_2648f149>:
  410110:	push   r12
  410112:	push   r13
  410114:	push   r14
  410116:	push   rdi
  410117:	push   rsi
  410118:	sub    rsp,0xc0
  41011f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410125:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  41012b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  410131:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410137:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  41013d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  410143:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410149:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  410152:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  41015b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  410164:	mov    r12,QWORD PTR [rcx]
  410167:	test   r12,r12
  41016a:	jne    41017c <__swc_fn_3464c816_000119_2648f149+0x6c>
  41016c:	add    rsp,0xc0
  410173:	pop    rsi
  410174:	pop    rdi
  410175:	pop    r14
  410177:	pop    r13
  410179:	pop    r12
  41017b:	ret
  41017c:	xor    r13d,r13d
  41017f:	mov    r14,QWORD PTR [rcx+0x8]
  410183:	cs nop WORD PTR [rax+rax*1+0x0]
  41018d:	nop    DWORD PTR [rax]
  410190:	cmp    r13,r14
  410193:	jae    4101cb <__swc_fn_3464c816_000119_2648f149+0xbb>
  410195:	lea    rax,[r12+r13*1]
  410199:	mov    rcx,r14
  41019c:	sub    rcx,r13
  41019f:	mov    edi,0x1
  4101a4:	mov    rsi,rax
  4101a7:	mov    rdx,rcx
  4101aa:	xor    eax,eax
  4101ac:	call   4071c0 <write@plt>
  4101b1:	test   rax,rax
  4101b4:	jle    4101bb <__swc_fn_3464c816_000119_2648f149+0xab>
  4101b6:	add    r13,rax
  4101b9:	jmp    410190 <__swc_fn_3464c816_000119_2648f149+0x80>
  4101bb:	je     4101c9 <__swc_fn_3464c816_000119_2648f149+0xb9>
  4101bd:	xor    eax,eax
  4101bf:	call   407130 <__errno_location@plt>
  4101c4:	cmp    DWORD PTR [rax],0x4
  4101c7:	je     410190 <__swc_fn_3464c816_000119_2648f149+0x80>
  4101c9:	jmp    4101cb <__swc_fn_3464c816_000119_2648f149+0xbb>
  4101cb:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4101d1:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4101d7:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4101dd:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4101e3:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4101e9:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4101ef:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4101f5:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4101fe:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410207:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410210:	add    rsp,0xc0
  410217:	pop    rsi
  410218:	pop    rdi
  410219:	pop    r14
  41021b:	pop    r13
  41021d:	pop    r12
  41021f:	ret

0000000000410220 <__swc_fn_3464c816_000122_4f256d58>:
  410220:	push   rbx
  410221:	push   r12
  410223:	push   rdi
  410224:	push   rsi
  410225:	sub    rsp,0x4a8
  41022c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  410235:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  41023e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  410247:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  410250:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  410259:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  410262:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  41026b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  410274:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  41027d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  410286:	mov    rbx,rdx
  410289:	mov    r12d,ecx
  41028c:	vxorps xmm0,xmm0,xmm0
  410290:	xor    eax,eax
  410292:	cs nop WORD PTR [rax+rax*1+0x0]
  41029c:	nop    DWORD PTR [rax+0x0]
  4102a0:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  4102a6:	add    rax,0x10
  4102aa:	cmp    rax,0x400
  4102b1:	jne    4102a0 <__swc_fn_3464c816_000122_4f256d58+0x80>
  4102b3:	lea    rdi,[rsp+0x8]
  4102b8:	mov    esi,0x80
  4102bd:	xor    eax,eax
  4102bf:	call   4071d0 <backtrace@plt>
  4102c4:	test   eax,eax
  4102c6:	jle    4102d5 <__swc_fn_3464c816_000122_4f256d58+0xb5>
  4102c8:	movsxd rax,eax
  4102cb:	lea    rcx,[r12+0x1]
  4102d0:	cmp    rcx,rax
  4102d3:	jb     4102d9 <__swc_fn_3464c816_000122_4f256d58+0xb9>
  4102d5:	xor    eax,eax
  4102d7:	jmp    41030a <__swc_fn_3464c816_000122_4f256d58+0xea>
  4102d9:	mov    rcx,QWORD PTR [rbx+0x8]
  4102dd:	sub    rax,r12
  4102e0:	lea    rsi,[rax-0x1]
  4102e4:	cmp    rcx,rsi
  4102e7:	cmovbe rsi,rcx
  4102eb:	lea    eax,[r12+0x1]
  4102f0:	lea    rax,[rsp+rax*8+0x8]
  4102f5:	mov    rcx,QWORD PTR [rbx]
  4102f8:	mov    rdx,rax
  4102fb:	lea    r8,[rsi*8+0x0]
  410303:	call   409880 <__swc_fn_3464c816_000108_7c204aac>
  410308:	mov    eax,esi
  41030a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  410313:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  41031c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  410325:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  41032e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  410337:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  410340:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  410349:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  410352:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  41035b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  410364:	add    rsp,0x4a8
  41036b:	pop    rsi
  41036c:	pop    rdi
  41036d:	pop    r12
  41036f:	pop    rbx
  410370:	ret
	...

0000000000410380 <__swc_fn_3464c816_000125_fcd5a289>:
  410380:	mov    QWORD PTR [rcx],0x0
  410387:	ret
	...

0000000000410390 <__swc_fn_3464c816_000128_4bbe3f14>:
  410390:	push   rdi
  410391:	push   rsi
  410392:	sub    rsp,0xa8
  410399:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41039f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4103a5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4103ab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4103b1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4103b7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4103bd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4103c3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4103c9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4103d2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4103db:	mov    edi,ecx
  4103dd:	mov    rsi,rdx
  4103e0:	xor    eax,eax
  4103e2:	call   407060 <pthread_setspecific@plt>
  4103e7:	test   eax,eax
  4103e9:	sete   al
  4103ec:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4103f2:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4103f8:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4103fe:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410404:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41040a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410410:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410416:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41041c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410425:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41042e:	add    rsp,0xa8
  410435:	pop    rsi
  410436:	pop    rdi
  410437:	ret
	...

0000000000410440 <__swc_fn_3464c816_000131_5f757033>:
  410440:	push   rdi
  410441:	push   rsi
  410442:	sub    rsp,0xa8
  410449:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41044f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410455:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41045b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410461:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410467:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41046d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410473:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410479:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410482:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41048b:	test   rcx,rcx
  41048e:	je     4104a1 <__swc_fn_3464c816_000131_5f757033+0x61>
  410490:	lea    rax,[rcx-0x1]
  410494:	mov    eax,eax
  410496:	mov    edi,eax
  410498:	xor    eax,eax
  41049a:	call   407000 <pthread_getspecific@plt>
  41049f:	jmp    4104a3 <__swc_fn_3464c816_000131_5f757033+0x63>
  4104a1:	xor    eax,eax
  4104a3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4104a9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4104af:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4104b5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4104bb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4104c1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4104c7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4104cd:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4104d3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4104dc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4104e5:	add    rsp,0xa8
  4104ec:	pop    rsi
  4104ed:	pop    rdi
  4104ee:	ret
	...

00000000004104f0 <__swc_fn_3464c816_000134_07d76562>:
  4104f0:	push   rdi
  4104f1:	push   rsi
  4104f2:	sub    rsp,0xb8
  4104f9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4104ff:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410505:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41050b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410511:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410517:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41051d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410523:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41052c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410535:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41053e:	vxorps xmm0,xmm0,xmm0
  410542:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410548:	mov    edi,0x1
  41054d:	lea    rsi,[rsp+0x8]
  410552:	xor    eax,eax
  410554:	call   407110 <clock_gettime@plt>
  410559:	mov    rax,QWORD PTR [rsp+0x8]
  41055e:	imul   rax,rax,0x3b9aca00
  410565:	add    rax,QWORD PTR [rsp+0x10]
  41056a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410570:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410576:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  41057c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410582:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410588:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41058e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410594:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41059d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4105a6:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4105af:	add    rsp,0xb8
  4105b6:	pop    rsi
  4105b7:	pop    rdi
  4105b8:	ret
  4105b9:	add    BYTE PTR [rax],al
  4105bb:	add    BYTE PTR [rax],al
  4105bd:	add    BYTE PTR [rax],al
	...

00000000004105c0 <__swc_fn_3464c816_000137_715e84ff>:
  4105c0:	sub    rsp,0x8
  4105c4:	xor    eax,eax
  4105c6:	mov    DWORD PTR [rcx],eax
  4105c8:	mov    edx,0x7fffffff
  4105cd:	call   409f80 <__swc_fn_3464c816_000135_865f5106>
  4105d2:	add    rsp,0x8
  4105d6:	ret
	...

00000000004105e0 <__swc_fn_3464c816_000140_519fdf94>:
  4105e0:	push   rdi
  4105e1:	push   rsi
  4105e2:	sub    rsp,0xb8
  4105e9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4105ef:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4105f5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4105fb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410601:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410607:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41060d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410613:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41061c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410625:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41062e:	mov    edi,0x1
  410633:	xor    eax,eax
  410635:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  41063a:	mov    eax,DWORD PTR [rax+0x14]
  41063d:	and    eax,0x20
  410640:	setne  al
  410643:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410649:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41064f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410655:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41065b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410661:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  410667:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41066d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  410676:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  41067f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410688:	add    rsp,0xb8
  41068f:	pop    rsi
  410690:	pop    rdi
  410691:	ret
	...

00000000004106a0 <__swc_fn_3464c816_000143_d5d4d43f>:
  4106a0:	push   rsi
  4106a1:	push   rdi
  4106a2:	push   r12
  4106a4:	push   r13
  4106a6:	push   r14
  4106a8:	push   r15
  4106aa:	cmp    rdx,0x40
  4106ae:	jae    4106bd <__swc_fn_3464c816_000143_d5d4d43f+0x1d>
  4106b0:	xor    eax,eax
  4106b2:	pop    r15
  4106b4:	pop    r14
  4106b6:	pop    r13
  4106b8:	pop    r12
  4106ba:	pop    rdi
  4106bb:	pop    rsi
  4106bc:	ret
  4106bd:	cmp    BYTE PTR [rcx],0x7f
  4106c0:	jne    410704 <__swc_fn_3464c816_000143_d5d4d43f+0x64>
  4106c2:	movzx  eax,BYTE PTR [rcx+0x1]
  4106c6:	cmp    eax,0x45
  4106c9:	setne  al
  4106cc:	jne    410700 <__swc_fn_3464c816_000143_d5d4d43f+0x60>
  4106ce:	movzx  eax,BYTE PTR [rcx+0x2]
  4106d2:	cmp    eax,0x4c
  4106d5:	setne  al
  4106d8:	jne    410700 <__swc_fn_3464c816_000143_d5d4d43f+0x60>
  4106da:	movzx  eax,BYTE PTR [rcx+0x3]
  4106de:	cmp    eax,0x46
  4106e1:	setne  al
  4106e4:	jne    410700 <__swc_fn_3464c816_000143_d5d4d43f+0x60>
  4106e6:	cmp    BYTE PTR [rcx+0x4],0x2
  4106ea:	setne  al
  4106ed:	jne    410700 <__swc_fn_3464c816_000143_d5d4d43f+0x60>
  4106ef:	cmp    BYTE PTR [rcx+0x5],0x1
  4106f3:	setne  al
  4106f6:	jne    410700 <__swc_fn_3464c816_000143_d5d4d43f+0x60>
  4106f8:	cmp    WORD PTR [rcx+0x12],0x3e
  4106fd:	setne  al
  410700:	test   al,al
  410702:	je     410711 <__swc_fn_3464c816_000143_d5d4d43f+0x71>
  410704:	xor    eax,eax
  410706:	pop    r15
  410708:	pop    r14
  41070a:	pop    r13
  41070c:	pop    r12
  41070e:	pop    rdi
  41070f:	pop    rsi
  410710:	ret
  410711:	cmp    WORD PTR [rcx+0x3a],0x40
  410716:	jne    410731 <__swc_fn_3464c816_000143_d5d4d43f+0x91>
  410718:	cmp    WORD PTR [rcx+0x3c],0x0
  41071d:	sete   al
  410720:	je     41072d <__swc_fn_3464c816_000143_d5d4d43f+0x8d>
  410722:	mov    ax,WORD PTR [rcx+0x3c]
  410726:	cmp    WORD PTR [rcx+0x3e],ax
  41072a:	setae  al
  41072d:	test   al,al
  41072f:	je     41073e <__swc_fn_3464c816_000143_d5d4d43f+0x9e>
  410731:	xor    eax,eax
  410733:	pop    r15
  410735:	pop    r14
  410737:	pop    r13
  410739:	pop    r12
  41073b:	pop    rdi
  41073c:	pop    rsi
  41073d:	ret
  41073e:	movzx  eax,WORD PTR [rcx+0x3c]
  410742:	shl    rax,0x6
  410746:	cmp    rax,rdx
  410749:	ja     410757 <__swc_fn_3464c816_000143_d5d4d43f+0xb7>
  41074b:	mov    r9,rdx
  41074e:	sub    r9,rax
  410751:	cmp    QWORD PTR [rcx+0x28],r9
  410755:	jbe    410764 <__swc_fn_3464c816_000143_d5d4d43f+0xc4>
  410757:	xor    eax,eax
  410759:	pop    r15
  41075b:	pop    r14
  41075d:	pop    r13
  41075f:	pop    r12
  410761:	pop    rdi
  410762:	pop    rsi
  410763:	ret
  410764:	mov    rax,QWORD PTR [rcx+0x28]
  410768:	add    rax,rcx
  41076b:	movzx  r9d,WORD PTR [rcx+0x3e]
  410770:	lea    r9,[r9*8+0x0]
  410778:	lea    r10,[rax+r9*8]
  41077c:	cmp    QWORD PTR [r10+0x20],rdx
  410780:	ja     4107a2 <__swc_fn_3464c816_000143_d5d4d43f+0x102>
  410782:	mov    r11,rdx
  410785:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  41078a:	cmp    QWORD PTR [r10+0x18],r11
  41078e:	seta   r9b
  410792:	ja     41079d <__swc_fn_3464c816_000143_d5d4d43f+0xfd>
  410794:	cmp    QWORD PTR [r10+0x20],0x9
  410799:	setb   r9b
  41079d:	test   r9b,r9b
  4107a0:	je     4107af <__swc_fn_3464c816_000143_d5d4d43f+0x10f>
  4107a2:	xor    eax,eax
  4107a4:	pop    r15
  4107a6:	pop    r14
  4107a8:	pop    r13
  4107aa:	pop    r12
  4107ac:	pop    rdi
  4107ad:	pop    rsi
  4107ae:	ret
  4107af:	movzx  r9d,WORD PTR [rcx+0x3c]
  4107b4:	xor    r11d,r11d
  4107b7:	test   r9,r9
  4107ba:	jbe    4108b5 <__swc_fn_3464c816_000143_d5d4d43f+0x215>
  4107c0:	mov    rsi,QWORD PTR [r10+0x20]
  4107c4:	sub    rsi,0x9
  4107c8:	cs nop WORD PTR [rax+rax*1+0x0]
  4107d2:	cs nop WORD PTR [rax+rax*1+0x0]
  4107dc:	nop    DWORD PTR [rax+0x0]
  4107e0:	movzx  edi,r11w
  4107e4:	lea    rdi,[rdi*8+0x0]
  4107ec:	lea    r12,[rax+rdi*8]
  4107f0:	rex mov edi,DWORD PTR [rax+rdi*8]
  4107f4:	cmp    rdi,rsi
  4107f7:	ja     4108a8 <__swc_fn_3464c816_000143_d5d4d43f+0x208>
  4107fd:	mov    r13,QWORD PTR [r10+0x18]
  410801:	add    r13,rdi
  410804:	lea    rdi,[rcx+r13*1]
  410808:	lea    r13,[rip+0x2e21]        # 413630 <__swc_rdata_base_3464c816+0x520>
  41080f:	movabs r14,0x676264676177732e
  410819:	cmp    QWORD PTR [rdi],r14
  41081c:	jne    410825 <__swc_fn_3464c816_000143_d5d4d43f+0x185>
  41081e:	rex cmp BYTE PTR [rdi+0x8],0x0
  410823:	je     410852 <__swc_fn_3464c816_000143_d5d4d43f+0x1b2>
  410825:	cs nop WORD PTR [rax+rax*1+0x0]
  41082f:	nop
  410830:	movzx  r14d,BYTE PTR [rdi]
  410834:	movzx  r15d,BYTE PTR [r13+0x0]
  410839:	cmp    r14,r15
  41083c:	jne    410848 <__swc_fn_3464c816_000143_d5d4d43f+0x1a8>
  41083e:	add    rdi,0x1
  410842:	add    r13,0x1
  410846:	jmp    410830 <__swc_fn_3464c816_000143_d5d4d43f+0x190>
  410848:	mov    rdi,r14
  41084b:	sub    rdi,r15
  41084e:	test   edi,edi
  410850:	jne    4108a8 <__swc_fn_3464c816_000143_d5d4d43f+0x208>
  410852:	cmp    DWORD PTR [r12+0x4],0x1
  410858:	jne    410880 <__swc_fn_3464c816_000143_d5d4d43f+0x1e0>
  41085a:	cmp    QWORD PTR [r12+0x20],0x10
  410860:	setb   al
  410863:	jb     41087c <__swc_fn_3464c816_000143_d5d4d43f+0x1dc>
  410865:	cmp    QWORD PTR [r12+0x20],rdx
  41086a:	seta   al
  41086d:	ja     41087c <__swc_fn_3464c816_000143_d5d4d43f+0x1dc>
  41086f:	sub    rdx,QWORD PTR [r12+0x20]
  410874:	cmp    QWORD PTR [r12+0x18],rdx
  410879:	seta   al
  41087c:	test   al,al
  41087e:	je     41088d <__swc_fn_3464c816_000143_d5d4d43f+0x1ed>
  410880:	xor    eax,eax
  410882:	pop    r15
  410884:	pop    r14
  410886:	pop    r13
  410888:	pop    r12
  41088a:	pop    rdi
  41088b:	pop    rsi
  41088c:	ret
  41088d:	mov    rax,QWORD PTR [r12+0x20]
  410892:	mov    QWORD PTR [r8],rax
  410895:	mov    rax,QWORD PTR [r12+0x18]
  41089a:	add    rax,rcx
  41089d:	pop    r15
  41089f:	pop    r14
  4108a1:	pop    r13
  4108a3:	pop    r12
  4108a5:	pop    rdi
  4108a6:	pop    rsi
  4108a7:	ret
  4108a8:	add    r11,0x1
  4108ac:	cmp    r11,r9
  4108af:	jb     4107e0 <__swc_fn_3464c816_000143_d5d4d43f+0x140>
  4108b5:	xor    eax,eax
  4108b7:	pop    r15
  4108b9:	pop    r14
  4108bb:	pop    r13
  4108bd:	pop    r12
  4108bf:	pop    rdi
  4108c0:	pop    rsi
  4108c1:	ret
	...

00000000004108d0 <__swc_fn_3464c816_000146_d7edc04f>:
  4108d0:	push   rdi
  4108d1:	push   rsi
  4108d2:	sub    rsp,0xa8
  4108d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4108df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4108e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4108eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4108f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4108f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4108fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410903:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410909:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410912:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41091b:	mov    rdi,rcx
  41091e:	xor    eax,eax
  410920:	call   4071f0 <free@plt>
  410925:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41092b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410931:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410937:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41093d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410943:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410949:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41094f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410955:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41095e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410967:	add    rsp,0xa8
  41096e:	pop    rsi
  41096f:	pop    rdi
  410970:	ret
	...

0000000000410980 <__swc_fn_3464c816_000149_6203dca2>:
  410980:	push   rbx
  410981:	push   rsi
  410982:	push   rdi
  410983:	push   r12
  410985:	push   r13
  410987:	push   r15
  410989:	sub    rsp,0x4e8
  410990:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  410999:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  4109a2:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  4109ab:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  4109b4:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  4109bd:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  4109c6:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  4109cf:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  4109d8:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  4109e1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  4109ea:	mov    rbx,QWORD PTR [rcx]
  4109ed:	mov    rcx,QWORD PTR [rcx+0x8]
  4109f1:	mov    rsi,rcx
  4109f4:	xor    edi,edi
  4109f6:	vmovsd xmm6,QWORD PTR [rip+0x2c92]        # 413690 <__swc_rdata_base_3464c816+0x580>
  4109fe:	vmovsd xmm7,QWORD PTR [rip+0x2c93]        # 413699 <__swc_rdata_base_3464c816+0x589>
  410a06:	vmovsd xmm8,QWORD PTR [rip+0x2c94]        # 4136a2 <__swc_rdata_base_3464c816+0x592>
  410a0e:	vmovsd xmm9,QWORD PTR [rip+0x2c95]        # 4136ab <__swc_rdata_base_3464c816+0x59b>
  410a16:	vmovsd xmm10,QWORD PTR [rip+0x2c96]        # 4136b4 <__swc_rdata_base_3464c816+0x5a4>
  410a1e:	vmovups xmm11,xmm6
  410a22:	vmovsd QWORD PTR [rsp+0x418],xmm7
  410a2b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410a34:	vmovsd QWORD PTR [rsp+0x428],xmm9
  410a3d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410a46:	vmovsd xmm15,QWORD PTR [rip+0x2c6f]        # 4136bd <__swc_rdata_base_3464c816+0x5ad>
  410a4e:	vmovups xmm14,xmm15
  410a53:	vmovups xmm0,xmm9
  410a58:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410a61:	vmovups xmm13,xmm8
  410a66:	vmovsd QWORD PTR [rsp+0x440],xmm15
  410a6f:	test   rsi,rsi
  410a72:	je     411a63 <__swc_fn_3464c816_000149_6203dca2+0x10e3>
  410a78:	cs nop WORD PTR [rax+rax*1+0x0]
  410a82:	cs nop WORD PTR [rax+rax*1+0x0]
  410a8c:	nop    DWORD PTR [rax+0x0]
  410a90:	lea    rcx,[rdi+rdi*1]
  410a94:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410a99:	vpshufd xmm3,xmm2,0xee
  410a9e:	vmovq  rcx,xmm3
  410aa3:	test   rcx,rcx
  410aa6:	je     410abc <__swc_fn_3464c816_000149_6203dca2+0x13c>
  410aa8:	test   DWORD PTR [rcx+0x28],0x400000
  410aaf:	je     410abc <__swc_fn_3464c816_000149_6203dca2+0x13c>
  410ab1:	mov    rdx,QWORD PTR [rcx+0x30]
  410ab5:	test   rdx,rdx
  410ab8:	cmovne rcx,rdx
  410abc:	test   DWORD PTR [rcx+0x28],0x1000
  410ac3:	je     410ae4 <__swc_fn_3464c816_000149_6203dca2+0x164>
  410ac5:	mov    rdx,QWORD PTR [rcx+0x40]
  410ac9:	mov    rcx,rdx
  410acc:	vmovq  r8,xmm2
  410ad1:	mov    r8,QWORD PTR [r8]
  410ad4:	mov    QWORD PTR [rsp+0x60],r8
  410ad9:	mov    QWORD PTR [rsp+0x68],rdx
  410ade:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410ae4:	test   BYTE PTR [rcx+0x28],0x1
  410ae8:	jne    410af0 <__swc_fn_3464c816_000149_6203dca2+0x170>
  410aea:	vmovups xmm12,xmm0
  410aee:	jmp    410b0a <__swc_fn_3464c816_000149_6203dca2+0x18a>
  410af0:	vmovq  rax,xmm2
  410af5:	mov    rax,QWORD PTR [rax]
  410af8:	lea    rcx,[rax+0x10]
  410afc:	vmovups xmm12,xmm0
  410b00:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  410b05:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410b0a:	test   DWORD PTR [rcx+0x28],0x400
  410b11:	je     410b72 <__swc_fn_3464c816_000149_6203dca2+0x1f2>
  410b13:	vmovq  rax,xmm2
  410b18:	mov    rax,QWORD PTR [rax]
  410b1b:	xor    ecx,ecx
  410b1d:	test   rax,rax
  410b20:	je     410b50 <__swc_fn_3464c816_000149_6203dca2+0x1d0>
  410b22:	mov    rdx,rax
  410b25:	mov    r8b,BYTE PTR [rdx]
  410b28:	test   r8b,r8b
  410b2b:	je     410b50 <__swc_fn_3464c816_000149_6203dca2+0x1d0>
  410b2d:	cs nop WORD PTR [rax+rax*1+0x0]
  410b37:	nop    WORD PTR [rax+rax*1+0x0]
  410b40:	add    rdx,0x1
  410b44:	add    rcx,0x1
  410b48:	mov    r8b,BYTE PTR [rdx]
  410b4b:	test   r8b,r8b
  410b4e:	jne    410b40 <__swc_fn_3464c816_000149_6203dca2+0x1c0>
  410b50:	mov    QWORD PTR [rsp+0x88],rax
  410b58:	mov    QWORD PTR [rsp+0x90],rcx
  410b60:	lea    rcx,[rsp+0x88]
  410b68:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  410b6d:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410b72:	cmp    BYTE PTR [rcx+0x2c],0x6
  410b76:	jne    410b8d <__swc_fn_3464c816_000149_6203dca2+0x20d>
  410b78:	vmovq  rax,xmm2
  410b7d:	mov    rax,QWORD PTR [rax]
  410b80:	mov    rcx,rax
  410b83:	call   40a450 <__swc_fn_3464c816_000147_43c96957>
  410b88:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410b8d:	cmp    BYTE PTR [rcx+0x2c],0x1
  410b91:	jne    411a39 <__swc_fn_3464c816_000149_6203dca2+0x10b9>
  410b97:	vmovq  rdx,xmm2
  410b9c:	mov    cl,BYTE PTR [rcx+0x40]
  410b9f:	cmp    cl,0x7
  410ba2:	jb     410be5 <__swc_fn_3464c816_000149_6203dca2+0x265>
  410ba4:	je     410c58 <__swc_fn_3464c816_000149_6203dca2+0x2d8>
  410baa:	cmp    cl,0x8
  410bad:	je     410c64 <__swc_fn_3464c816_000149_6203dca2+0x2e4>
  410bb3:	cmp    cl,0x9
  410bb6:	je     410c7d <__swc_fn_3464c816_000149_6203dca2+0x2fd>
  410bbc:	cmp    cl,0xa
  410bbf:	je     411344 <__swc_fn_3464c816_000149_6203dca2+0x9c4>
  410bc5:	cmp    cl,0xb
  410bc8:	je     411a0b <__swc_fn_3464c816_000149_6203dca2+0x108b>
  410bce:	cmp    cl,0xc
  410bd1:	je     410c71 <__swc_fn_3464c816_000149_6203dca2+0x2f1>
  410bd7:	cmp    cl,0xd
  410bda:	je     411a01 <__swc_fn_3464c816_000149_6203dca2+0x1081>
  410be0:	jmp    411a2b <__swc_fn_3464c816_000149_6203dca2+0x10ab>
  410be5:	cmp    cl,0x1
  410be8:	je     410c08 <__swc_fn_3464c816_000149_6203dca2+0x288>
  410bea:	cmp    cl,0x2
  410bed:	je     410c16 <__swc_fn_3464c816_000149_6203dca2+0x296>
  410bef:	cmp    cl,0x3
  410bf2:	je     410c24 <__swc_fn_3464c816_000149_6203dca2+0x2a4>
  410bf4:	cmp    cl,0x4
  410bf7:	je     410c31 <__swc_fn_3464c816_000149_6203dca2+0x2b1>
  410bf9:	cmp    cl,0x5
  410bfc:	je     410c3e <__swc_fn_3464c816_000149_6203dca2+0x2be>
  410bfe:	cmp    cl,0x6
  410c01:	je     410c4b <__swc_fn_3464c816_000149_6203dca2+0x2cb>
  410c03:	jmp    411a2b <__swc_fn_3464c816_000149_6203dca2+0x10ab>
  410c08:	movsx  rcx,BYTE PTR [rdx]
  410c0c:	call   40d6c0 <__swc_fn_3464c816_000148_2eb804cc>
  410c11:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c16:	movsx  rcx,WORD PTR [rdx]
  410c1a:	call   40d6c0 <__swc_fn_3464c816_000148_2eb804cc>
  410c1f:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c24:	movsxd rcx,DWORD PTR [rdx]
  410c27:	call   40d6c0 <__swc_fn_3464c816_000148_2eb804cc>
  410c2c:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c31:	mov    rcx,QWORD PTR [rdx]
  410c34:	call   40d6c0 <__swc_fn_3464c816_000148_2eb804cc>
  410c39:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c3e:	movzx  ecx,BYTE PTR [rdx]
  410c41:	call   40a450 <__swc_fn_3464c816_000147_43c96957>
  410c46:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c4b:	movzx  ecx,WORD PTR [rdx]
  410c4e:	call   40a450 <__swc_fn_3464c816_000147_43c96957>
  410c53:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c58:	mov    ecx,DWORD PTR [rdx]
  410c5a:	call   40a450 <__swc_fn_3464c816_000147_43c96957>
  410c5f:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c64:	mov    rcx,QWORD PTR [rdx]
  410c67:	call   40a450 <__swc_fn_3464c816_000147_43c96957>
  410c6c:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c71:	mov    ecx,DWORD PTR [rdx]
  410c73:	call   40a450 <__swc_fn_3464c816_000147_43c96957>
  410c78:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c7d:	lea    rcx,[rsp+0xa8]
  410c85:	vxorps xmm0,xmm0,xmm0
  410c89:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  410c92:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  410c9b:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  410ca4:	vzeroupper
  410ca7:	mov    DWORD PTR [rsp+0x108],0x0
  410cb2:	vxorpd xmm0,xmm0,xmm0
  410cb6:	vmovss xmm1,DWORD PTR [rdx]
  410cba:	vcvtss2sd xmm0,xmm0,xmm1
  410cbe:	vmovsd xmm1,xmm1,xmm0
  410cc2:	vcomisd xmm0,xmm0
  410cc6:	setne  dl
  410cc9:	movzx  edx,dl
  410ccc:	setp   r8b
  410cd0:	movzx  r8d,r8b
  410cd4:	or     edx,r8d
  410cd7:	test   dl,dl
  410cd9:	je     410ce6 <__swc_fn_3464c816_000149_6203dca2+0x366>
  410cdb:	mov    DWORD PTR [rcx],0x6e616e
  410ce1:	jmp    4112d8 <__swc_fn_3464c816_000149_6203dca2+0x958>
  410ce6:	vcomisd xmm1,xmm6
  410cea:	ja     410cf2 <__swc_fn_3464c816_000149_6203dca2+0x372>
  410cec:	vcomisd xmm7,xmm1
  410cf0:	jbe    410d16 <__swc_fn_3464c816_000149_6203dca2+0x396>
  410cf2:	vxorpd xmm0,xmm0,xmm0
  410cf6:	vcomisd xmm0,xmm1
  410cfa:	jbe    410d0b <__swc_fn_3464c816_000149_6203dca2+0x38b>
  410cfc:	mov    DWORD PTR [rcx],0x666e692d
  410d02:	mov    BYTE PTR [rcx+0x4],0x0
  410d06:	jmp    4112d8 <__swc_fn_3464c816_000149_6203dca2+0x958>
  410d0b:	mov    DWORD PTR [rcx],0x666e69
  410d11:	jmp    4112d8 <__swc_fn_3464c816_000149_6203dca2+0x958>
  410d16:	vcomisd xmm1,xmm8
  410d1b:	jae    410d27 <__swc_fn_3464c816_000149_6203dca2+0x3a7>
  410d1d:	vcomisd xmm9,xmm1
  410d21:	jbe    41109e <__swc_fn_3464c816_000149_6203dca2+0x71e>
  410d27:	vmovups xmm0,xmm1
  410d2b:	vxorpd xmm2,xmm2,xmm2
  410d2f:	vcomisd xmm2,xmm1
  410d33:	jbe    410d43 <__swc_fn_3464c816_000149_6203dca2+0x3c3>
  410d35:	vmovsd xmm1,xmm1,xmm0
  410d39:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x290f]        # 413650 <__swc_rdata_base_3464c816+0x540>
  410d41:	jmp    410d47 <__swc_fn_3464c816_000149_6203dca2+0x3c7>
  410d43:	vmovsd xmm1,xmm1,xmm0
  410d47:	xor    r8d,r8d
  410d4a:	vcomisd xmm1,xmm15
  410d4f:	jb     410d70 <__swc_fn_3464c816_000149_6203dca2+0x3f0>
  410d51:	cs nop WORD PTR [rax+rax*1+0x0]
  410d5b:	nop    DWORD PTR [rax+rax*1+0x0]
  410d60:	vdivsd xmm1,xmm1,xmm15
  410d65:	add    r8,0x1
  410d69:	vcomisd xmm1,xmm15
  410d6e:	jae    410d60 <__swc_fn_3464c816_000149_6203dca2+0x3e0>
  410d70:	mov    r9,rcx
  410d73:	vxorpd xmm2,xmm2,xmm2
  410d77:	vcomisd xmm2,xmm0
  410d7b:	jbe    410d84 <__swc_fn_3464c816_000149_6203dca2+0x404>
  410d7d:	mov    BYTE PTR [rcx],0x2d
  410d80:	lea    r9,[rcx+0x1]
  410d84:	vcvttsd2si rdx,xmm1
  410d89:	mov    r10b,dl
  410d8c:	add    r10b,0x30
  410d90:	mov    BYTE PTR [r9],r10b
  410d93:	vxorpd xmm0,xmm0,xmm0
  410d97:	movzx  edx,dl
  410d9a:	vcvtsi2sd xmm0,xmm0,rdx
  410d9f:	vsubsd xmm0,xmm1,xmm0
  410da3:	vmulsd xmm1,xmm0,xmm15
  410da8:	mov    BYTE PTR [r9+0x1],0x2e
  410dad:	vcvttsd2si rdx,xmm1
  410db2:	mov    r10b,dl
  410db5:	add    r10b,0x30
  410db9:	mov    BYTE PTR [r9+0x2],r10b
  410dbd:	vxorpd xmm0,xmm0,xmm0
  410dc1:	movzx  edx,dl
  410dc4:	vcvtsi2sd xmm0,xmm0,rdx
  410dc9:	vsubsd xmm0,xmm1,xmm0
  410dcd:	vmulsd xmm1,xmm0,xmm15
  410dd2:	vcvttsd2si rdx,xmm1
  410dd7:	mov    r10b,dl
  410dda:	add    r10b,0x30
  410dde:	mov    BYTE PTR [r9+0x3],r10b
  410de2:	vxorpd xmm0,xmm0,xmm0
  410de6:	movzx  edx,dl
  410de9:	vcvtsi2sd xmm0,xmm0,rdx
  410dee:	vsubsd xmm0,xmm1,xmm0
  410df2:	vmulsd xmm1,xmm0,xmm15
  410df7:	vcvttsd2si rdx,xmm1
  410dfc:	mov    r10b,dl
  410dff:	add    r10b,0x30
  410e03:	mov    BYTE PTR [r9+0x4],r10b
  410e07:	vxorpd xmm0,xmm0,xmm0
  410e0b:	movzx  edx,dl
  410e0e:	vcvtsi2sd xmm0,xmm0,rdx
  410e13:	vsubsd xmm0,xmm1,xmm0
  410e17:	vmulsd xmm1,xmm0,xmm15
  410e1c:	vcvttsd2si rdx,xmm1
  410e21:	mov    r10b,dl
  410e24:	add    r10b,0x30
  410e28:	mov    BYTE PTR [r9+0x5],r10b
  410e2c:	vxorpd xmm0,xmm0,xmm0
  410e30:	movzx  edx,dl
  410e33:	vcvtsi2sd xmm0,xmm0,rdx
  410e38:	vsubsd xmm0,xmm1,xmm0
  410e3c:	vmulsd xmm1,xmm0,xmm15
  410e41:	vcvttsd2si rdx,xmm1
  410e46:	mov    r10b,dl
  410e49:	add    r10b,0x30
  410e4d:	mov    BYTE PTR [r9+0x6],r10b
  410e51:	vxorpd xmm0,xmm0,xmm0
  410e55:	movzx  edx,dl
  410e58:	vcvtsi2sd xmm0,xmm0,rdx
  410e5d:	vsubsd xmm0,xmm1,xmm0
  410e61:	vmulsd xmm1,xmm0,xmm15
  410e66:	vcvttsd2si rdx,xmm1
  410e6b:	mov    r10b,dl
  410e6e:	add    r10b,0x30
  410e72:	mov    BYTE PTR [r9+0x7],r10b
  410e76:	vxorpd xmm0,xmm0,xmm0
  410e7a:	movzx  edx,dl
  410e7d:	vcvtsi2sd xmm0,xmm0,rdx
  410e82:	vsubsd xmm0,xmm1,xmm0
  410e86:	vmulsd xmm1,xmm0,xmm15
  410e8b:	vcvttsd2si rdx,xmm1
  410e90:	mov    r10b,dl
  410e93:	add    r10b,0x30
  410e97:	mov    BYTE PTR [r9+0x8],r10b
  410e9b:	vxorpd xmm0,xmm0,xmm0
  410e9f:	movzx  edx,dl
  410ea2:	vcvtsi2sd xmm0,xmm0,rdx
  410ea7:	vsubsd xmm0,xmm1,xmm0
  410eab:	vmulsd xmm1,xmm0,xmm15
  410eb0:	vcvttsd2si rdx,xmm1
  410eb5:	mov    r10b,dl
  410eb8:	add    r10b,0x30
  410ebc:	mov    BYTE PTR [r9+0x9],r10b
  410ec0:	vxorpd xmm0,xmm0,xmm0
  410ec4:	movzx  edx,dl
  410ec7:	vcvtsi2sd xmm0,xmm0,rdx
  410ecc:	vsubsd xmm0,xmm1,xmm0
  410ed0:	vmulsd xmm1,xmm0,xmm15
  410ed5:	vcvttsd2si rdx,xmm1
  410eda:	mov    r10b,dl
  410edd:	add    r10b,0x30
  410ee1:	mov    BYTE PTR [r9+0xa],r10b
  410ee5:	vxorpd xmm0,xmm0,xmm0
  410ee9:	movzx  edx,dl
  410eec:	vcvtsi2sd xmm0,xmm0,rdx
  410ef1:	vsubsd xmm0,xmm1,xmm0
  410ef5:	vmulsd xmm1,xmm0,xmm15
  410efa:	vcvttsd2si rdx,xmm1
  410eff:	mov    r10b,dl
  410f02:	add    r10b,0x30
  410f06:	mov    BYTE PTR [r9+0xb],r10b
  410f0a:	lea    r10,[r9+0x4]
  410f0e:	vxorpd xmm0,xmm0,xmm0
  410f12:	movzx  edx,dl
  410f15:	vcvtsi2sd xmm0,xmm0,rdx
  410f1a:	vsubsd xmm0,xmm1,xmm0
  410f1e:	vmulsd xmm1,xmm0,xmm15
  410f23:	vcvttsd2si rdx,xmm1
  410f28:	mov    r11b,dl
  410f2b:	add    r11b,0x30
  410f2f:	mov    BYTE PTR [r9+0xc],r11b
  410f33:	vxorpd xmm0,xmm0,xmm0
  410f37:	movzx  edx,dl
  410f3a:	vcvtsi2sd xmm0,xmm0,rdx
  410f3f:	vsubsd xmm0,xmm1,xmm0
  410f43:	vmulsd xmm1,xmm0,xmm15
  410f48:	vcvttsd2si rdx,xmm1
  410f4d:	mov    r11b,dl
  410f50:	add    r11b,0x30
  410f54:	mov    BYTE PTR [r9+0xd],r11b
  410f58:	lea    r10,[r10+0x2]
  410f5c:	vxorpd xmm0,xmm0,xmm0
  410f60:	movzx  edx,dl
  410f63:	vcvtsi2sd xmm0,xmm0,rdx
  410f68:	vsubsd xmm0,xmm1,xmm0
  410f6c:	vmulsd xmm1,xmm0,xmm15
  410f71:	vcvttsd2si rdx,xmm1
  410f76:	mov    r11b,dl
  410f79:	add    r11b,0x30
  410f7d:	mov    BYTE PTR [r9+0xe],r11b
  410f81:	vxorpd xmm0,xmm0,xmm0
  410f85:	movzx  edx,dl
  410f88:	vcvtsi2sd xmm0,xmm0,rdx
  410f8d:	vsubsd xmm0,xmm1,xmm0
  410f91:	vmulsd xmm1,xmm0,xmm15
  410f96:	vcvttsd2si rdx,xmm1
  410f9b:	mov    r11b,dl
  410f9e:	add    r11b,0x30
  410fa2:	mov    BYTE PTR [r9+0xf],r11b
  410fa6:	lea    r10,[r10+0x2]
  410faa:	lea    r10,[r10+0x2]
  410fae:	lea    r10,[r10+0x2]
  410fb2:	lea    r10,[r10+0x2]
  410fb6:	lea    r10,[r10+0x2]
  410fba:	vxorpd xmm0,xmm0,xmm0
  410fbe:	movzx  edx,dl
  410fc1:	vcvtsi2sd xmm0,xmm0,rdx
  410fc6:	vsubsd xmm0,xmm1,xmm0
  410fca:	vmulsd xmm1,xmm0,xmm15
  410fcf:	vcvttsd2si rdx,xmm1
  410fd4:	mov    r11b,dl
  410fd7:	add    r11b,0x30
  410fdb:	mov    BYTE PTR [r9+0x10],r11b
  410fdf:	vxorpd xmm0,xmm0,xmm0
  410fe3:	movzx  edx,dl
  410fe6:	vcvtsi2sd xmm0,xmm0,rdx
  410feb:	vsubsd xmm0,xmm1,xmm0
  410fef:	vmulsd xmm1,xmm0,xmm15
  410ff4:	vcvttsd2si rdx,xmm1
  410ff9:	add    dl,0x30
  410ffc:	mov    BYTE PTR [r9+0x11],dl
  411000:	mov    BYTE PTR [r10+0x2],0x65
  411005:	lea    r9,[r10+0x3]
  411009:	test   r8,r8
  41100c:	jl     411015 <__swc_fn_3464c816_000149_6203dca2+0x695>
  41100e:	mov    BYTE PTR [r9],0x2b
  411012:	inc    r9
  411015:	mov    r10,r9
  411018:	mov    rdx,r8
  41101b:	nop    DWORD PTR [rax+rax*1+0x0]
  411020:	mov    r11,rdx
  411023:	movabs rdx,0x6666666666666667
  41102d:	mov    rax,r11
  411030:	imul   rdx
  411033:	sar    rdx,0x2
  411037:	mov    r12,rdx
  41103a:	shr    rdx,0x3f
  41103e:	add    r12,rdx
  411041:	mov    rdx,r12
  411044:	imul   r13,r12,0xa
  411048:	sub    r11,r13
  41104b:	mov    r13,QWORD PTR [rip+0x25ee]        # 413640 <__swc_rdata_base_3464c816+0x530>
  411052:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411057:	mov    BYTE PTR [r10],r11b
  41105a:	lea    r11,[r10+0x1]
  41105e:	mov    r10,r11
  411061:	test   r12,r12
  411064:	jne    411020 <__swc_fn_3464c816_000149_6203dca2+0x6a0>
  411066:	test   r8,r8
  411069:	jge    411073 <__swc_fn_3464c816_000149_6203dca2+0x6f3>
  41106b:	mov    BYTE PTR [r11],0x2d
  41106f:	lea    r10,[r11+0x1]
  411073:	mov    BYTE PTR [r10],0x0
  411077:	sub    r10,0x1
  41107b:	nop    DWORD PTR [rax+rax*1+0x0]
  411080:	cmp    r9,r10
  411083:	jae    4112d8 <__swc_fn_3464c816_000149_6203dca2+0x958>
  411089:	mov    al,BYTE PTR [r10]
  41108c:	mov    dl,BYTE PTR [r9]
  41108f:	mov    BYTE PTR [r10],dl
  411092:	sub    r10,0x1
  411096:	mov    BYTE PTR [r9],al
  411099:	inc    r9
  41109c:	jmp    411080 <__swc_fn_3464c816_000149_6203dca2+0x700>
  41109e:	vcvttsd2si rdx,xmm1
  4110a3:	mov    r8,rdx
  4110a6:	vxorpd xmm0,xmm0,xmm0
  4110aa:	vcvtsi2sd xmm0,xmm0,rdx
  4110af:	vsubsd xmm0,xmm1,xmm0
  4110b3:	mov    r9d,0x8
  4110b9:	vxorpd xmm2,xmm2,xmm2
  4110bd:	vcomisd xmm2,xmm0
  4110c1:	jbe    4110cb <__swc_fn_3464c816_000149_6203dca2+0x74b>
  4110c3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2585]        # 413650 <__swc_rdata_base_3464c816+0x540>
  4110cb:	test   r9d,r9d
  4110ce:	je     4110da <__swc_fn_3464c816_000149_6203dca2+0x75a>
  4110d0:	vmulsd xmm0,xmm0,xmm14
  4110d5:	dec    r9d
  4110d8:	jne    4110d0 <__swc_fn_3464c816_000149_6203dca2+0x750>
  4110da:	vcvttsd2si r9,xmm0
  4110df:	mov    r10,r9
  4110e2:	vxorpd xmm2,xmm2,xmm2
  4110e6:	vcvtsi2sd xmm2,xmm2,r9
  4110eb:	vsubsd xmm0,xmm0,xmm2
  4110ef:	vcomisd xmm0,xmm10
  4110f4:	lea    r9,[r9+0x1]
  4110f8:	cmova  r10,r9
  4110fc:	cmp    r10,0x5f5e100
  411103:	jne    41111c <__swc_fn_3464c816_000149_6203dca2+0x79c>
  411105:	lea    r8,[rdx-0x1]
  411109:	vxorpd xmm0,xmm0,xmm0
  41110d:	vcomisd xmm0,xmm1
  411111:	lea    rdx,[rdx+0x1]
  411115:	cmovbe r8,rdx
  411119:	xor    r10d,r10d
  41111c:	mov    r9,rcx
  41111f:	test   r8,r8
  411122:	jne    411142 <__swc_fn_3464c816_000149_6203dca2+0x7c2>
  411124:	vxorpd xmm0,xmm0,xmm0
  411128:	vcomisd xmm0,xmm1
  41112c:	jbe    411135 <__swc_fn_3464c816_000149_6203dca2+0x7b5>
  41112e:	mov    BYTE PTR [rcx],0x2d
  411131:	lea    r9,[rcx+0x1]
  411135:	mov    BYTE PTR [r9],0x30
  411139:	add    r9,0x1
  41113d:	jmp    4111db <__swc_fn_3464c816_000149_6203dca2+0x85b>
  411142:	mov    r9,rcx
  411145:	mov    rdx,r8
  411148:	nop    DWORD PTR [rax+rax*1+0x0]
  411150:	mov    r11,rdx
  411153:	movabs rdx,0x6666666666666667
  41115d:	mov    r15,rax
  411160:	mov    rax,r11
  411163:	imul   rdx
  411166:	mov    r12,rdx
  411169:	mov    rax,r15
  41116c:	sar    r12,0x2
  411170:	mov    rdx,r12
  411173:	shr    rdx,0x3f
  411177:	add    r12,rdx
  41117a:	mov    rdx,r12
  41117d:	imul   r13,r12,0xa
  411181:	sub    r11,r13
  411184:	mov    r13,QWORD PTR [rip+0x24b5]        # 413640 <__swc_rdata_base_3464c816+0x530>
  41118b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411190:	mov    BYTE PTR [r9],r11b
  411193:	lea    r11,[r9+0x1]
  411197:	mov    r9,r11
  41119a:	test   r12,r12
  41119d:	jne    411150 <__swc_fn_3464c816_000149_6203dca2+0x7d0>
  41119f:	test   r8,r8
  4111a2:	jge    4111ac <__swc_fn_3464c816_000149_6203dca2+0x82c>
  4111a4:	mov    BYTE PTR [r11],0x2d
  4111a8:	lea    r9,[r11+0x1]
  4111ac:	mov    rdx,r9
  4111af:	mov    BYTE PTR [r9],0x0
  4111b3:	sub    r9,0x1
  4111b7:	mov    r8,rcx
  4111ba:	cmp    r8,r9
  4111bd:	jae    4111d8 <__swc_fn_3464c816_000149_6203dca2+0x858>
  4111bf:	nop
  4111c0:	mov    r11b,BYTE PTR [r9]
  4111c3:	mov    r12b,BYTE PTR [r8]
  4111c6:	mov    BYTE PTR [r9],r12b
  4111c9:	sub    r9,0x1
  4111cd:	mov    BYTE PTR [r8],r11b
  4111d0:	inc    r8
  4111d3:	cmp    r8,r9
  4111d6:	jb     4111c0 <__swc_fn_3464c816_000149_6203dca2+0x840>
  4111d8:	mov    r9,rdx
  4111db:	mov    BYTE PTR [r9],0x2e
  4111df:	add    r9,0x1
  4111e3:	xor    r8d,r8d
  4111e6:	test   r10,r10
  4111e9:	je     41122f <__swc_fn_3464c816_000149_6203dca2+0x8af>
  4111eb:	mov    r11d,0x989680
  4111f1:	cmp    r10,r11
  4111f4:	jge    41122f <__swc_fn_3464c816_000149_6203dca2+0x8af>
  4111f6:	cs nop WORD PTR [rax+rax*1+0x0]
  411200:	inc    r8d
  411203:	movabs rdx,0x6666666666666667
  41120d:	mov    r15,rax
  411210:	mov    rax,r11
  411213:	imul   rdx
  411216:	mov    r11,rdx
  411219:	mov    rax,r15
  41121c:	sar    r11,0x2
  411220:	mov    rdx,r11
  411223:	shr    rdx,0x3f
  411227:	add    r11,rdx
  41122a:	cmp    r10,r11
  41122d:	jl     411200 <__swc_fn_3464c816_000149_6203dca2+0x880>
  41122f:	test   r8d,r8d
  411232:	je     41124d <__swc_fn_3464c816_000149_6203dca2+0x8cd>
  411234:	cs nop WORD PTR [rax+rax*1+0x0]
  41123e:	xchg   ax,ax
  411240:	mov    BYTE PTR [r9],0x30
  411244:	add    r9,0x1
  411248:	dec    r8d
  41124b:	jne    411240 <__swc_fn_3464c816_000149_6203dca2+0x8c0>
  41124d:	mov    r8,r9
  411250:	mov    rdx,r10
  411253:	cs nop WORD PTR [rax+rax*1+0x0]
  41125d:	nop    DWORD PTR [rax]
  411260:	mov    r11,rdx
  411263:	movabs rdx,0x6666666666666667
  41126d:	mov    rax,r11
  411270:	imul   rdx
  411273:	sar    rdx,0x2
  411277:	mov    r12,rdx
  41127a:	shr    rdx,0x3f
  41127e:	add    r12,rdx
  411281:	mov    rdx,r12
  411284:	imul   r13,r12,0xa
  411288:	sub    r11,r13
  41128b:	mov    r13,QWORD PTR [rip+0x23ae]        # 413640 <__swc_rdata_base_3464c816+0x530>
  411292:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411297:	mov    BYTE PTR [r8],r11b
  41129a:	lea    r11,[r8+0x1]
  41129e:	mov    r8,r11
  4112a1:	test   r12,r12
  4112a4:	jne    411260 <__swc_fn_3464c816_000149_6203dca2+0x8e0>
  4112a6:	test   r10,r10
  4112a9:	jge    4112b3 <__swc_fn_3464c816_000149_6203dca2+0x933>
  4112ab:	mov    BYTE PTR [r11],0x2d
  4112af:	lea    r8,[r11+0x1]
  4112b3:	mov    BYTE PTR [r8],0x0
  4112b7:	sub    r8,0x1
  4112bb:	cmp    r9,r8
  4112be:	jae    4112d8 <__swc_fn_3464c816_000149_6203dca2+0x958>
  4112c0:	mov    al,BYTE PTR [r8]
  4112c3:	mov    dl,BYTE PTR [r9]
  4112c6:	mov    BYTE PTR [r8],dl
  4112c9:	sub    r8,0x1
  4112cd:	mov    BYTE PTR [r9],al
  4112d0:	inc    r9
  4112d3:	cmp    r9,r8
  4112d6:	jb     4112c0 <__swc_fn_3464c816_000149_6203dca2+0x940>
  4112d8:	xor    eax,eax
  4112da:	test   rcx,rcx
  4112dd:	je     411310 <__swc_fn_3464c816_000149_6203dca2+0x990>
  4112df:	mov    rdx,rcx
  4112e2:	mov    r8b,BYTE PTR [rdx]
  4112e5:	test   r8b,r8b
  4112e8:	je     411310 <__swc_fn_3464c816_000149_6203dca2+0x990>
  4112ea:	cs nop WORD PTR [rax+rax*1+0x0]
  4112f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4112fe:	xchg   ax,ax
  411300:	add    rdx,0x1
  411304:	add    rax,0x1
  411308:	mov    r8b,BYTE PTR [rdx]
  41130b:	test   r8b,r8b
  41130e:	jne    411300 <__swc_fn_3464c816_000149_6203dca2+0x980>
  411310:	mov    QWORD PTR [rsp+0x240],rcx
  411318:	mov    QWORD PTR [rsp+0x248],rax
  411320:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  411329:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  411332:	lea    rcx,[rsp+0x250]
  41133a:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  41133f:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  411344:	lea    rcx,[rsp+0x260]
  41134c:	vxorps xmm0,xmm0,xmm0
  411350:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  411359:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  411362:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  41136b:	vzeroupper
  41136e:	mov    DWORD PTR [rsp+0x2c0],0x0
  411379:	vmovsd xmm0,QWORD PTR [rdx]
  41137d:	vcomisd xmm0,xmm0
  411381:	setne  dl
  411384:	movzx  edx,dl
  411387:	setp   r8b
  41138b:	movzx  r8d,r8b
  41138f:	or     edx,r8d
  411392:	test   dl,dl
  411394:	je     4113a1 <__swc_fn_3464c816_000149_6203dca2+0xa21>
  411396:	mov    DWORD PTR [rcx],0x6e616e
  41139c:	jmp    4119a8 <__swc_fn_3464c816_000149_6203dca2+0x1028>
  4113a1:	vcomisd xmm0,xmm11
  4113a6:	ja     4113b7 <__swc_fn_3464c816_000149_6203dca2+0xa37>
  4113a8:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  4113b1:	vcomisd xmm6,xmm0
  4113b5:	jbe    4113db <__swc_fn_3464c816_000149_6203dca2+0xa5b>
  4113b7:	vxorpd xmm1,xmm1,xmm1
  4113bb:	vcomisd xmm1,xmm0
  4113bf:	jbe    4113d0 <__swc_fn_3464c816_000149_6203dca2+0xa50>
  4113c1:	mov    DWORD PTR [rcx],0x666e692d
  4113c7:	mov    BYTE PTR [rcx+0x4],0x0
  4113cb:	jmp    4119a8 <__swc_fn_3464c816_000149_6203dca2+0x1028>
  4113d0:	mov    DWORD PTR [rcx],0x666e69
  4113d6:	jmp    4119a8 <__swc_fn_3464c816_000149_6203dca2+0x1028>
  4113db:	vcomisd xmm0,xmm13
  4113e0:	jae    4113ec <__swc_fn_3464c816_000149_6203dca2+0xa6c>
  4113e2:	vcomisd xmm12,xmm0
  4113e6:	jbe    41174e <__swc_fn_3464c816_000149_6203dca2+0xdce>
  4113ec:	vmovups xmm1,xmm0
  4113f0:	vxorpd xmm2,xmm2,xmm2
  4113f4:	vcomisd xmm2,xmm0
  4113f8:	jbe    411408 <__swc_fn_3464c816_000149_6203dca2+0xa88>
  4113fa:	vmovsd xmm0,xmm0,xmm1
  4113fe:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x224a]        # 413650 <__swc_rdata_base_3464c816+0x540>
  411406:	jmp    41140c <__swc_fn_3464c816_000149_6203dca2+0xa8c>
  411408:	vmovsd xmm0,xmm0,xmm1
  41140c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  411415:	xor    r8d,r8d
  411418:	vcomisd xmm0,xmm6
  41141c:	jb     41142e <__swc_fn_3464c816_000149_6203dca2+0xaae>
  41141e:	xchg   ax,ax
  411420:	vdivsd xmm0,xmm0,xmm6
  411424:	add    r8,0x1
  411428:	vcomisd xmm0,xmm6
  41142c:	jae    411420 <__swc_fn_3464c816_000149_6203dca2+0xaa0>
  41142e:	mov    r9,rcx
  411431:	vxorpd xmm2,xmm2,xmm2
  411435:	vcomisd xmm2,xmm1
  411439:	jbe    411442 <__swc_fn_3464c816_000149_6203dca2+0xac2>
  41143b:	mov    BYTE PTR [rcx],0x2d
  41143e:	lea    r9,[rcx+0x1]
  411442:	vcvttsd2si rdx,xmm0
  411447:	mov    r10b,dl
  41144a:	add    r10b,0x30
  41144e:	mov    BYTE PTR [r9],r10b
  411451:	vxorpd xmm1,xmm1,xmm1
  411455:	movzx  edx,dl
  411458:	vcvtsi2sd xmm1,xmm1,rdx
  41145d:	vsubsd xmm0,xmm0,xmm1
  411461:	vmulsd xmm0,xmm0,xmm6
  411465:	mov    BYTE PTR [r9+0x1],0x2e
  41146a:	vcvttsd2si rdx,xmm0
  41146f:	mov    r10b,dl
  411472:	add    r10b,0x30
  411476:	mov    BYTE PTR [r9+0x2],r10b
  41147a:	vxorpd xmm1,xmm1,xmm1
  41147e:	movzx  edx,dl
  411481:	vcvtsi2sd xmm1,xmm1,rdx
  411486:	vsubsd xmm0,xmm0,xmm1
  41148a:	vmulsd xmm0,xmm0,xmm6
  41148e:	vcvttsd2si rdx,xmm0
  411493:	mov    r10b,dl
  411496:	add    r10b,0x30
  41149a:	mov    BYTE PTR [r9+0x3],r10b
  41149e:	vxorpd xmm1,xmm1,xmm1
  4114a2:	movzx  edx,dl
  4114a5:	vcvtsi2sd xmm1,xmm1,rdx
  4114aa:	vsubsd xmm0,xmm0,xmm1
  4114ae:	vmulsd xmm0,xmm0,xmm6
  4114b2:	vcvttsd2si rdx,xmm0
  4114b7:	mov    r10b,dl
  4114ba:	add    r10b,0x30
  4114be:	mov    BYTE PTR [r9+0x4],r10b
  4114c2:	vxorpd xmm1,xmm1,xmm1
  4114c6:	movzx  edx,dl
  4114c9:	vcvtsi2sd xmm1,xmm1,rdx
  4114ce:	vsubsd xmm0,xmm0,xmm1
  4114d2:	vmulsd xmm0,xmm0,xmm6
  4114d6:	vcvttsd2si rdx,xmm0
  4114db:	mov    r10b,dl
  4114de:	add    r10b,0x30
  4114e2:	mov    BYTE PTR [r9+0x5],r10b
  4114e6:	vxorpd xmm1,xmm1,xmm1
  4114ea:	movzx  edx,dl
  4114ed:	vcvtsi2sd xmm1,xmm1,rdx
  4114f2:	vsubsd xmm0,xmm0,xmm1
  4114f6:	vmulsd xmm0,xmm0,xmm6
  4114fa:	vcvttsd2si rdx,xmm0
  4114ff:	mov    r10b,dl
  411502:	add    r10b,0x30
  411506:	mov    BYTE PTR [r9+0x6],r10b
  41150a:	vxorpd xmm1,xmm1,xmm1
  41150e:	movzx  edx,dl
  411511:	vcvtsi2sd xmm1,xmm1,rdx
  411516:	vsubsd xmm0,xmm0,xmm1
  41151a:	vmulsd xmm0,xmm0,xmm6
  41151e:	vcvttsd2si rdx,xmm0
  411523:	mov    r10b,dl
  411526:	add    r10b,0x30
  41152a:	mov    BYTE PTR [r9+0x7],r10b
  41152e:	vxorpd xmm1,xmm1,xmm1
  411532:	movzx  edx,dl
  411535:	vcvtsi2sd xmm1,xmm1,rdx
  41153a:	vsubsd xmm0,xmm0,xmm1
  41153e:	vmulsd xmm0,xmm0,xmm6
  411542:	vcvttsd2si rdx,xmm0
  411547:	mov    r10b,dl
  41154a:	add    r10b,0x30
  41154e:	mov    BYTE PTR [r9+0x8],r10b
  411552:	vxorpd xmm1,xmm1,xmm1
  411556:	movzx  edx,dl
  411559:	vcvtsi2sd xmm1,xmm1,rdx
  41155e:	vsubsd xmm0,xmm0,xmm1
  411562:	vmulsd xmm0,xmm0,xmm6
  411566:	vcvttsd2si rdx,xmm0
  41156b:	mov    r10b,dl
  41156e:	add    r10b,0x30
  411572:	mov    BYTE PTR [r9+0x9],r10b
  411576:	vxorpd xmm1,xmm1,xmm1
  41157a:	movzx  edx,dl
  41157d:	vcvtsi2sd xmm1,xmm1,rdx
  411582:	vsubsd xmm0,xmm0,xmm1
  411586:	vmulsd xmm0,xmm0,xmm6
  41158a:	vcvttsd2si rdx,xmm0
  41158f:	mov    r10b,dl
  411592:	add    r10b,0x30
  411596:	mov    BYTE PTR [r9+0xa],r10b
  41159a:	vxorpd xmm1,xmm1,xmm1
  41159e:	movzx  edx,dl
  4115a1:	vcvtsi2sd xmm1,xmm1,rdx
  4115a6:	vsubsd xmm0,xmm0,xmm1
  4115aa:	vmulsd xmm0,xmm0,xmm6
  4115ae:	vcvttsd2si rdx,xmm0
  4115b3:	mov    r10b,dl
  4115b6:	add    r10b,0x30
  4115ba:	mov    BYTE PTR [r9+0xb],r10b
  4115be:	lea    r10,[r9+0x4]
  4115c2:	vxorpd xmm1,xmm1,xmm1
  4115c6:	movzx  edx,dl
  4115c9:	vcvtsi2sd xmm1,xmm1,rdx
  4115ce:	vsubsd xmm0,xmm0,xmm1
  4115d2:	vmulsd xmm0,xmm0,xmm6
  4115d6:	vcvttsd2si rdx,xmm0
  4115db:	mov    r11b,dl
  4115de:	add    r11b,0x30
  4115e2:	mov    BYTE PTR [r9+0xc],r11b
  4115e6:	vxorpd xmm1,xmm1,xmm1
  4115ea:	movzx  edx,dl
  4115ed:	vcvtsi2sd xmm1,xmm1,rdx
  4115f2:	vsubsd xmm0,xmm0,xmm1
  4115f6:	vmulsd xmm0,xmm0,xmm6
  4115fa:	vcvttsd2si rdx,xmm0
  4115ff:	mov    r11b,dl
  411602:	add    r11b,0x30
  411606:	mov    BYTE PTR [r9+0xd],r11b
  41160a:	lea    r10,[r10+0x2]
  41160e:	vxorpd xmm1,xmm1,xmm1
  411612:	movzx  edx,dl
  411615:	vcvtsi2sd xmm1,xmm1,rdx
  41161a:	vsubsd xmm0,xmm0,xmm1
  41161e:	vmulsd xmm0,xmm0,xmm6
  411622:	vcvttsd2si rdx,xmm0
  411627:	mov    r11b,dl
  41162a:	add    r11b,0x30
  41162e:	mov    BYTE PTR [r9+0xe],r11b
  411632:	vxorpd xmm1,xmm1,xmm1
  411636:	movzx  edx,dl
  411639:	vcvtsi2sd xmm1,xmm1,rdx
  41163e:	vsubsd xmm0,xmm0,xmm1
  411642:	vmulsd xmm0,xmm0,xmm6
  411646:	vcvttsd2si rdx,xmm0
  41164b:	mov    r11b,dl
  41164e:	add    r11b,0x30
  411652:	mov    BYTE PTR [r9+0xf],r11b
  411656:	lea    r10,[r10+0x2]
  41165a:	lea    r10,[r10+0x2]
  41165e:	lea    r10,[r10+0x2]
  411662:	lea    r10,[r10+0x2]
  411666:	lea    r10,[r10+0x2]
  41166a:	vxorpd xmm1,xmm1,xmm1
  41166e:	movzx  edx,dl
  411671:	vcvtsi2sd xmm1,xmm1,rdx
  411676:	vsubsd xmm0,xmm0,xmm1
  41167a:	vmulsd xmm0,xmm0,xmm6
  41167e:	vcvttsd2si rdx,xmm0
  411683:	mov    r11b,dl
  411686:	add    r11b,0x30
  41168a:	mov    BYTE PTR [r9+0x10],r11b
  41168e:	vxorpd xmm1,xmm1,xmm1
  411692:	movzx  edx,dl
  411695:	vcvtsi2sd xmm1,xmm1,rdx
  41169a:	vsubsd xmm0,xmm0,xmm1
  41169e:	vmulsd xmm0,xmm0,xmm6
  4116a2:	vcvttsd2si rdx,xmm0
  4116a7:	add    dl,0x30
  4116aa:	mov    BYTE PTR [r9+0x11],dl
  4116ae:	mov    BYTE PTR [r10+0x2],0x65
  4116b3:	lea    r9,[r10+0x3]
  4116b7:	test   r8,r8
  4116ba:	jl     4116c3 <__swc_fn_3464c816_000149_6203dca2+0xd43>
  4116bc:	mov    BYTE PTR [r9],0x2b
  4116c0:	inc    r9
  4116c3:	mov    r10,r9
  4116c6:	mov    rdx,r8
  4116c9:	nop    DWORD PTR [rax+0x0]
  4116d0:	mov    r11,rdx
  4116d3:	movabs rdx,0x6666666666666667
  4116dd:	mov    rax,r11
  4116e0:	imul   rdx
  4116e3:	sar    rdx,0x2
  4116e7:	mov    r12,rdx
  4116ea:	shr    rdx,0x3f
  4116ee:	add    r12,rdx
  4116f1:	mov    rdx,r12
  4116f4:	imul   r13,r12,0xa
  4116f8:	sub    r11,r13
  4116fb:	mov    r13,QWORD PTR [rip+0x1f3e]        # 413640 <__swc_rdata_base_3464c816+0x530>
  411702:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411707:	mov    BYTE PTR [r10],r11b
  41170a:	lea    r11,[r10+0x1]
  41170e:	mov    r10,r11
  411711:	test   r12,r12
  411714:	jne    4116d0 <__swc_fn_3464c816_000149_6203dca2+0xd50>
  411716:	test   r8,r8
  411719:	jge    411723 <__swc_fn_3464c816_000149_6203dca2+0xda3>
  41171b:	mov    BYTE PTR [r11],0x2d
  41171f:	lea    r10,[r11+0x1]
  411723:	mov    BYTE PTR [r10],0x0
  411727:	sub    r10,0x1
  41172b:	nop    DWORD PTR [rax+rax*1+0x0]
  411730:	cmp    r9,r10
  411733:	jae    4119a8 <__swc_fn_3464c816_000149_6203dca2+0x1028>
  411739:	mov    al,BYTE PTR [r10]
  41173c:	mov    dl,BYTE PTR [r9]
  41173f:	mov    BYTE PTR [r10],dl
  411742:	sub    r10,0x1
  411746:	mov    BYTE PTR [r9],al
  411749:	inc    r9
  41174c:	jmp    411730 <__swc_fn_3464c816_000149_6203dca2+0xdb0>
  41174e:	vcvttsd2si rdx,xmm0
  411753:	mov    r8,rdx
  411756:	vxorpd xmm1,xmm1,xmm1
  41175a:	vcvtsi2sd xmm1,xmm1,rdx
  41175f:	vsubsd xmm1,xmm0,xmm1
  411763:	mov    r9d,0x8
  411769:	vxorpd xmm2,xmm2,xmm2
  41176d:	vcomisd xmm2,xmm1
  411771:	ja     41177e <__swc_fn_3464c816_000149_6203dca2+0xdfe>
  411773:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41177c:	jmp    41178f <__swc_fn_3464c816_000149_6203dca2+0xe0f>
  41177e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1eca]        # 413650 <__swc_rdata_base_3464c816+0x540>
  411786:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41178f:	test   r9d,r9d
  411792:	je     4117a9 <__swc_fn_3464c816_000149_6203dca2+0xe29>
  411794:	cs nop WORD PTR [rax+rax*1+0x0]
  41179e:	xchg   ax,ax
  4117a0:	vmulsd xmm1,xmm1,xmm6
  4117a4:	dec    r9d
  4117a7:	jne    4117a0 <__swc_fn_3464c816_000149_6203dca2+0xe20>
  4117a9:	vcvttsd2si r9,xmm1
  4117ae:	mov    r10,r9
  4117b1:	vxorpd xmm2,xmm2,xmm2
  4117b5:	vcvtsi2sd xmm2,xmm2,r9
  4117ba:	vsubsd xmm1,xmm1,xmm2
  4117be:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  4117c7:	vcomisd xmm1,xmm6
  4117cb:	lea    r9,[r9+0x1]
  4117cf:	cmova  r10,r9
  4117d3:	cmp    r10,0x5f5e100
  4117da:	jne    4117f3 <__swc_fn_3464c816_000149_6203dca2+0xe73>
  4117dc:	lea    r8,[rdx-0x1]
  4117e0:	vxorpd xmm1,xmm1,xmm1
  4117e4:	vcomisd xmm1,xmm0
  4117e8:	lea    rdx,[rdx+0x1]
  4117ec:	cmovbe r8,rdx
  4117f0:	xor    r10d,r10d
  4117f3:	mov    r9,rcx
  4117f6:	test   r8,r8
  4117f9:	jne    411819 <__swc_fn_3464c816_000149_6203dca2+0xe99>
  4117fb:	vxorpd xmm1,xmm1,xmm1
  4117ff:	vcomisd xmm1,xmm0
  411803:	jbe    41180c <__swc_fn_3464c816_000149_6203dca2+0xe8c>
  411805:	mov    BYTE PTR [rcx],0x2d
  411808:	lea    r9,[rcx+0x1]
  41180c:	mov    BYTE PTR [r9],0x30
  411810:	add    r9,0x1
  411814:	jmp    4118ab <__swc_fn_3464c816_000149_6203dca2+0xf2b>
  411819:	mov    r9,rcx
  41181c:	mov    rdx,r8
  41181f:	nop
  411820:	mov    r11,rdx
  411823:	movabs rdx,0x6666666666666667
  41182d:	mov    r15,rax
  411830:	mov    rax,r11
  411833:	imul   rdx
  411836:	mov    r12,rdx
  411839:	mov    rax,r15
  41183c:	sar    r12,0x2
  411840:	mov    rdx,r12
  411843:	shr    rdx,0x3f
  411847:	add    r12,rdx
  41184a:	mov    rdx,r12
  41184d:	imul   r13,r12,0xa
  411851:	sub    r11,r13
  411854:	mov    r13,QWORD PTR [rip+0x1de5]        # 413640 <__swc_rdata_base_3464c816+0x530>
  41185b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411860:	mov    BYTE PTR [r9],r11b
  411863:	lea    r11,[r9+0x1]
  411867:	mov    r9,r11
  41186a:	test   r12,r12
  41186d:	jne    411820 <__swc_fn_3464c816_000149_6203dca2+0xea0>
  41186f:	test   r8,r8
  411872:	jge    41187c <__swc_fn_3464c816_000149_6203dca2+0xefc>
  411874:	mov    BYTE PTR [r11],0x2d
  411878:	lea    r9,[r11+0x1]
  41187c:	mov    rdx,r9
  41187f:	mov    BYTE PTR [r9],0x0
  411883:	sub    r9,0x1
  411887:	mov    r8,rcx
  41188a:	cmp    r8,r9
  41188d:	jae    4118a8 <__swc_fn_3464c816_000149_6203dca2+0xf28>
  41188f:	nop
  411890:	mov    r11b,BYTE PTR [r9]
  411893:	mov    r12b,BYTE PTR [r8]
  411896:	mov    BYTE PTR [r9],r12b
  411899:	sub    r9,0x1
  41189d:	mov    BYTE PTR [r8],r11b
  4118a0:	inc    r8
  4118a3:	cmp    r8,r9
  4118a6:	jb     411890 <__swc_fn_3464c816_000149_6203dca2+0xf10>
  4118a8:	mov    r9,rdx
  4118ab:	mov    BYTE PTR [r9],0x2e
  4118af:	add    r9,0x1
  4118b3:	xor    r8d,r8d
  4118b6:	test   r10,r10
  4118b9:	je     4118ff <__swc_fn_3464c816_000149_6203dca2+0xf7f>
  4118bb:	mov    r11d,0x989680
  4118c1:	cmp    r10,r11
  4118c4:	jge    4118ff <__swc_fn_3464c816_000149_6203dca2+0xf7f>
  4118c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4118d0:	inc    r8d
  4118d3:	movabs rdx,0x6666666666666667
  4118dd:	mov    r15,rax
  4118e0:	mov    rax,r11
  4118e3:	imul   rdx
  4118e6:	mov    r11,rdx
  4118e9:	mov    rax,r15
  4118ec:	sar    r11,0x2
  4118f0:	mov    rdx,r11
  4118f3:	shr    rdx,0x3f
  4118f7:	add    r11,rdx
  4118fa:	cmp    r10,r11
  4118fd:	jl     4118d0 <__swc_fn_3464c816_000149_6203dca2+0xf50>
  4118ff:	test   r8d,r8d
  411902:	je     41191d <__swc_fn_3464c816_000149_6203dca2+0xf9d>
  411904:	cs nop WORD PTR [rax+rax*1+0x0]
  41190e:	xchg   ax,ax
  411910:	mov    BYTE PTR [r9],0x30
  411914:	add    r9,0x1
  411918:	dec    r8d
  41191b:	jne    411910 <__swc_fn_3464c816_000149_6203dca2+0xf90>
  41191d:	mov    r8,r9
  411920:	mov    rdx,r10
  411923:	cs nop WORD PTR [rax+rax*1+0x0]
  41192d:	nop    DWORD PTR [rax]
  411930:	mov    r11,rdx
  411933:	movabs rdx,0x6666666666666667
  41193d:	mov    rax,r11
  411940:	imul   rdx
  411943:	sar    rdx,0x2
  411947:	mov    r12,rdx
  41194a:	shr    rdx,0x3f
  41194e:	add    r12,rdx
  411951:	mov    rdx,r12
  411954:	imul   r13,r12,0xa
  411958:	sub    r11,r13
  41195b:	mov    r13,QWORD PTR [rip+0x1cde]        # 413640 <__swc_rdata_base_3464c816+0x530>
  411962:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411967:	mov    BYTE PTR [r8],r11b
  41196a:	lea    r11,[r8+0x1]
  41196e:	mov    r8,r11
  411971:	test   r12,r12
  411974:	jne    411930 <__swc_fn_3464c816_000149_6203dca2+0xfb0>
  411976:	test   r10,r10
  411979:	jge    411983 <__swc_fn_3464c816_000149_6203dca2+0x1003>
  41197b:	mov    BYTE PTR [r11],0x2d
  41197f:	lea    r8,[r11+0x1]
  411983:	mov    BYTE PTR [r8],0x0
  411987:	sub    r8,0x1
  41198b:	cmp    r9,r8
  41198e:	jae    4119a8 <__swc_fn_3464c816_000149_6203dca2+0x1028>
  411990:	mov    al,BYTE PTR [r8]
  411993:	mov    dl,BYTE PTR [r9]
  411996:	mov    BYTE PTR [r8],dl
  411999:	sub    r8,0x1
  41199d:	mov    BYTE PTR [r9],al
  4119a0:	inc    r9
  4119a3:	cmp    r9,r8
  4119a6:	jb     411990 <__swc_fn_3464c816_000149_6203dca2+0x1010>
  4119a8:	xor    eax,eax
  4119aa:	test   rcx,rcx
  4119ad:	je     4119d0 <__swc_fn_3464c816_000149_6203dca2+0x1050>
  4119af:	mov    rdx,rcx
  4119b2:	mov    r8b,BYTE PTR [rdx]
  4119b5:	test   r8b,r8b
  4119b8:	je     4119d0 <__swc_fn_3464c816_000149_6203dca2+0x1050>
  4119ba:	nop    WORD PTR [rax+rax*1+0x0]
  4119c0:	add    rdx,0x1
  4119c4:	add    rax,0x1
  4119c8:	mov    r8b,BYTE PTR [rdx]
  4119cb:	test   r8b,r8b
  4119ce:	jne    4119c0 <__swc_fn_3464c816_000149_6203dca2+0x1040>
  4119d0:	mov    QWORD PTR [rsp+0x3f8],rcx
  4119d8:	mov    QWORD PTR [rsp+0x400],rax
  4119e0:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  4119e9:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  4119f2:	lea    rcx,[rsp+0x408]
  4119fa:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  4119ff:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  411a01:	mov    rcx,rdx
  411a04:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  411a09:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  411a0b:	mov    al,BYTE PTR [rdx]
  411a0d:	test   al,al
  411a0f:	je     411a1a <__swc_fn_3464c816_000149_6203dca2+0x109a>
  411a11:	lea    rax,[rip+0x1c48]        # 413660 <__swc_rdata_base_3464c816+0x550>
  411a18:	jmp    411a21 <__swc_fn_3464c816_000149_6203dca2+0x10a1>
  411a1a:	lea    rax,[rip+0x1c4f]        # 413670 <__swc_rdata_base_3464c816+0x560>
  411a21:	mov    rcx,rax
  411a24:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  411a29:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  411a2b:	lea    rcx,[rip+0x1c4e]        # 413680 <__swc_rdata_base_3464c816+0x570>
  411a32:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  411a37:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  411a39:	lea    rcx,[rip+0x1c40]        # 413680 <__swc_rdata_base_3464c816+0x570>
  411a40:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  411a45:	add    rdi,0x1
  411a49:	sub    rsi,0x1
  411a4d:	vmovups xmm0,xmm12
  411a52:	vmovsd xmm6,QWORD PTR [rip+0x1c36]        # 413690 <__swc_rdata_base_3464c816+0x580>
  411a5a:	test   rsi,rsi
  411a5d:	jne    410a90 <__swc_fn_3464c816_000149_6203dca2+0x110>
  411a63:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  411a6c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411a75:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  411a7e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411a87:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411a90:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411a99:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411aa2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  411aab:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411ab4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  411abd:	add    rsp,0x4e8
  411ac4:	pop    r15
  411ac6:	pop    r13
  411ac8:	pop    r12
  411aca:	pop    rdi
  411acb:	pop    rsi
  411acc:	pop    rbx
  411acd:	ret
	...

0000000000411ad0 <__swc_fn_3464c816_000152_86f1d437>:
  411ad0:	vxorps xmm0,xmm0,xmm0
  411ad4:	vmovups XMMWORD PTR [rcx],xmm0
  411ad8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411add:	ret
	...

0000000000411ae0 <__swc_fn_3464c816_000155_86f1d437>:
  411ae0:	vxorps xmm0,xmm0,xmm0
  411ae4:	vmovups XMMWORD PTR [rcx],xmm0
  411ae8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411aed:	vxorps xmm0,xmm0,xmm0
  411af1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411af6:	vmovups xmm0,XMMWORD PTR [rip+0x1ca2]        # 4137a0 <__swc_rdata_base_3464c816+0x690>
  411afe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411b03:	vxorps xmm0,xmm0,xmm0
  411b07:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411b0c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411b11:	vxorps xmm0,xmm0,xmm0
  411b15:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411b1a:	mov    QWORD PTR [rcx+0x70],0x0
  411b22:	ret
	...

0000000000411b30 <__swc_fn_3464c816_000158_86f1d437>:
  411b30:	vxorps xmm0,xmm0,xmm0
  411b34:	vmovups XMMWORD PTR [rcx],xmm0
  411b38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411b3d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411b42:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411b47:	ret
	...

0000000000411b50 <__swc_fn_3464c816_000161_e36363a8>:
  411b50:	push   rsi
  411b51:	push   rdi
  411b52:	sub    rsp,0x8
  411b56:	mov    rsi,rcx
  411b59:	mov    rdi,QWORD PTR [rsi+0x50]
  411b5d:	test   rdi,rdi
  411b60:	je     411b67 <__swc_fn_3464c816_000161_e36363a8+0x17>
  411b62:	mov    rcx,rsi
  411b65:	call   rdi
  411b67:	mov    QWORD PTR [rsi+0x20],0x0
  411b6f:	mov    rax,QWORD PTR [rsi+0x30]
  411b73:	test   rax,rax
  411b76:	je     411ba4 <__swc_fn_3464c816_000161_e36363a8+0x54>
  411b78:	nop    DWORD PTR [rax+rax*1+0x0]
  411b80:	mov    rdi,QWORD PTR [rax+0x8]
  411b84:	mov    rcx,rsi
  411b87:	mov    rdx,QWORD PTR [rax+0x10]
  411b8b:	mov    rax,QWORD PTR [rax+0x18]
  411b8f:	mov    r8,rax
  411b92:	call   40a630 <__swc_fn_3464c816_000159_47b270e1>
  411b97:	mov    QWORD PTR [rsi+0x30],rdi
  411b9b:	mov    rax,QWORD PTR [rsi+0x30]
  411b9f:	test   rax,rax
  411ba2:	jne    411b80 <__swc_fn_3464c816_000161_e36363a8+0x30>
  411ba4:	mov    QWORD PTR [rsi+0x38],0x0
  411bac:	add    rsp,0x8
  411bb0:	pop    rdi
  411bb1:	pop    rsi
  411bb2:	ret
	...

0000000000411bc0 <__swc_fn_3464c816_000164_016ee66a>:
  411bc0:	push   rbx
  411bc1:	push   rsi
  411bc2:	push   rdi
  411bc3:	push   r12
  411bc5:	sub    rsp,0x188
  411bcc:	mov    rbx,rcx
  411bcf:	lea    rsi,[rip+0x151b2]        # 426d88 <__swc_bss_base_3464c816+0x2d48>
  411bd6:	mov    rcx,rsi
  411bd9:	call   40a040 <__swc_fn_3464c816_000138_86bb0f90>
  411bde:	mov    rax,QWORD PTR [rip+0x151ab]        # 426d90 <__swc_bss_base_3464c816+0x2d50>
  411be5:	mov    rdi,rax
  411be8:	test   rdi,rdi
  411beb:	je     411c19 <__swc_fn_3464c816_000164_016ee66a+0x59>
  411bed:	nop    DWORD PTR [rax]
  411bf0:	cmp    QWORD PTR [rdi+0x8],rbx
  411bf4:	jne    411c0e <__swc_fn_3464c816_000164_016ee66a+0x4e>
  411bf6:	mov    rcx,rsi
  411bf9:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  411bfe:	mov    rax,rdi
  411c01:	add    rsp,0x188
  411c08:	pop    r12
  411c0a:	pop    rdi
  411c0b:	pop    rsi
  411c0c:	pop    rbx
  411c0d:	ret
  411c0e:	mov    rax,QWORD PTR [rdi]
  411c11:	mov    rdi,rax
  411c14:	test   rax,rax
  411c17:	jne    411bf0 <__swc_fn_3464c816_000164_016ee66a+0x30>
  411c19:	call   40d5e0 <__swc_fn_3464c816_000142_d299b428>
  411c1e:	mov    rdi,rax
  411c21:	test   rax,rax
  411c24:	jne    411c3d <__swc_fn_3464c816_000164_016ee66a+0x7d>
  411c26:	mov    rcx,rsi
  411c29:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  411c2e:	xor    eax,eax
  411c30:	add    rsp,0x188
  411c37:	pop    r12
  411c39:	pop    rdi
  411c3a:	pop    rsi
  411c3b:	pop    rbx
  411c3c:	ret
  411c3d:	lea    rax,[rsp+0x18]
  411c42:	mov    QWORD PTR [rax+0x10],0x0
  411c4a:	mov    QWORD PTR [rax+0x18],0x0
  411c52:	mov    DWORD PTR [rax+0x20],0x0
  411c59:	mov    BYTE PTR [rax+0x24],0x0
  411c5d:	mov    rax,QWORD PTR [rip+0x1512c]        # 426d90 <__swc_bss_base_3464c816+0x2d50>
  411c64:	mov    QWORD PTR [rsp+0x18],rax
  411c69:	mov    QWORD PTR [rsp+0x20],rbx
  411c6e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411c74:	vmovups XMMWORD PTR [rdi],xmm0
  411c78:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411c7e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411c83:	mov    rax,QWORD PTR [rsp+0x38]
  411c88:	mov    QWORD PTR [rdi+0x20],rax
  411c8c:	mov    QWORD PTR [rip+0x150fd],rdi        # 426d90 <__swc_bss_base_3464c816+0x2d50>
  411c93:	lea    rax,[rsp+0x40]
  411c98:	mov    QWORD PTR [rax],0x0
  411c9f:	mov    rcx,rbx
  411ca2:	mov    rdx,rax
  411ca5:	call   40a120 <__swc_fn_3464c816_000144_1534de9a>
  411caa:	mov    rbx,rax
  411cad:	test   rax,rax
  411cb0:	jne    411cca <__swc_fn_3464c816_000164_016ee66a+0x10a>
  411cb2:	mov    rcx,rsi
  411cb5:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  411cba:	mov    rax,rdi
  411cbd:	add    rsp,0x188
  411cc4:	pop    r12
  411cc6:	pop    rdi
  411cc7:	pop    rsi
  411cc8:	pop    rbx
  411cc9:	ret
  411cca:	lea    r12,[rsp+0x50]
  411ccf:	mov    QWORD PTR [r12],0x0
  411cd7:	mov    rcx,rbx
  411cda:	mov    rdx,QWORD PTR [rsp+0x40]
  411cdf:	mov    r8,r12
  411ce2:	call   40d690 <__swc_fn_3464c816_000145_162f363d>
  411ce7:	test   rax,rax
  411cea:	jne    411d04 <__swc_fn_3464c816_000164_016ee66a+0x144>
  411cec:	mov    rcx,rsi
  411cef:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  411cf4:	mov    rax,rdi
  411cf7:	add    rsp,0x188
  411cfe:	pop    r12
  411d00:	pop    rdi
  411d01:	pop    rsi
  411d02:	pop    rbx
  411d03:	ret
  411d04:	cmp    QWORD PTR [r12],0x10
  411d09:	jb     411e0c <__swc_fn_3464c816_000164_016ee66a+0x24c>
  411d0f:	mov    ecx,DWORD PTR [rax]
  411d11:	cmp    ecx,0x42445753
  411d17:	jne    411e0c <__swc_fn_3464c816_000164_016ee66a+0x24c>
  411d1d:	mov    ecx,DWORD PTR [rax+0x4]
  411d20:	cmp    ecx,0x1
  411d23:	jne    411e0c <__swc_fn_3464c816_000164_016ee66a+0x24c>
  411d29:	mov    ecx,DWORD PTR [rax+0x8]
  411d2c:	mov    edx,DWORD PTR [rax+0xc]
  411d2f:	imul   r8,rcx,0x14
  411d33:	mov    r9,QWORD PTR [rsp+0x50]
  411d38:	sub    r9,0x10
  411d3c:	cmp    r8,r9
  411d3f:	ja     411e0c <__swc_fn_3464c816_000164_016ee66a+0x24c>
  411d45:	lea    r8,[r8+0x10]
  411d49:	cmp    rdx,r8
  411d4c:	jb     411e0c <__swc_fn_3464c816_000164_016ee66a+0x24c>
  411d52:	mov    r8,QWORD PTR [rsp+0x50]
  411d57:	cmp    rdx,r8
  411d5a:	ja     411e0c <__swc_fn_3464c816_000164_016ee66a+0x24c>
  411d60:	xor    r8d,r8d
  411d63:	test   rcx,rcx
  411d66:	jbe    411e32 <__swc_fn_3464c816_000164_016ee66a+0x272>
  411d6c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411d72:	cs nop WORD PTR [rax+rax*1+0x0]
  411d7c:	nop    DWORD PTR [rax+0x0]
  411d80:	imul   r9,r8,0x14
  411d84:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411d89:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  411d8e:	add    r10,r11
  411d91:	movabs r11,0x100000000
  411d9b:	cmp    r10,r11
  411d9e:	ja     411e0c <__swc_fn_3464c816_000164_016ee66a+0x24c>
  411da0:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411da5:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  411daa:	test   r10d,r10d
  411dad:	setne  r11b
  411db1:	je     411dcb <__swc_fn_3464c816_000164_016ee66a+0x20b>
  411db3:	cmp    r10d,edx
  411db6:	setb   r11b
  411dba:	jb     411dcb <__swc_fn_3464c816_000164_016ee66a+0x20b>
  411dbc:	vmovq  r11,xmm1
  411dc1:	cmp    r10,r11
  411dc4:	setae  r10b
  411dc8:	mov    r11b,r10b
  411dcb:	mov    r10,r11
  411dce:	test   r11b,r11b
  411dd1:	jne    411df8 <__swc_fn_3464c816_000164_016ee66a+0x238>
  411dd3:	test   r9d,r9d
  411dd6:	setne  r10b
  411dda:	je     411df8 <__swc_fn_3464c816_000164_016ee66a+0x238>
  411ddc:	cmp    r9d,edx
  411ddf:	setb   r10b
  411de3:	jb     411df8 <__swc_fn_3464c816_000164_016ee66a+0x238>
  411de5:	vmovq  r10,xmm1
  411dea:	cmp    r9,r10
  411ded:	setae  r9b
  411df1:	movzx  r9d,r9b
  411df5:	mov    r10b,r9b
  411df8:	test   r10b,r10b
  411dfb:	jne    411e0c <__swc_fn_3464c816_000164_016ee66a+0x24c>
  411dfd:	add    r8,0x1
  411e01:	cmp    r8,rcx
  411e04:	jb     411d80 <__swc_fn_3464c816_000164_016ee66a+0x1c0>
  411e0a:	jmp    411e32 <__swc_fn_3464c816_000164_016ee66a+0x272>
  411e0c:	xor    ecx,ecx
  411e0e:	cmp    rax,rbx
  411e11:	cmovne rcx,rax
  411e15:	call   4108d0 <__swc_fn_3464c816_000146_d7edc04f>
  411e1a:	mov    rcx,rsi
  411e1d:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  411e22:	mov    rax,rdi
  411e25:	add    rsp,0x188
  411e2c:	pop    r12
  411e2e:	pop    rdi
  411e2f:	pop    rsi
  411e30:	pop    rbx
  411e31:	ret
  411e32:	mov    QWORD PTR [rdi+0x10],rax
  411e36:	mov    rcx,QWORD PTR [rsp+0x50]
  411e3b:	mov    QWORD PTR [rdi+0x18],rcx
  411e3f:	mov    eax,DWORD PTR [rax+0x8]
  411e42:	mov    DWORD PTR [rdi+0x20],eax
  411e45:	rex mov BYTE PTR [rdi+0x24],0x1
  411e4a:	mov    rcx,rsi
  411e4d:	call   40d5d0 <__swc_fn_3464c816_000139_055b38a4>
  411e52:	mov    rax,rdi
  411e55:	add    rsp,0x188
  411e5c:	pop    r12
  411e5e:	pop    rdi
  411e5f:	pop    rsi
  411e60:	pop    rbx
  411e61:	ret
	...

0000000000411e70 <__swc_fn_3464c816_000167_3459066f>:
  411e70:	push   rsi
  411e71:	push   rdi
  411e72:	push   r12
  411e74:	mov    rsi,rdx
  411e77:	mov    rdi,rcx
  411e7a:	mov    rcx,QWORD PTR [rip+0x121bf]        # 424040 <__swc_bss_base_3464c816>
  411e81:	test   rcx,rcx
  411e84:	jne    411e96 <__swc_fn_3464c816_000167_3459066f+0x26>
  411e86:	call   40a940 <__swc_fn_3464c816_000168_994c8876>
  411e8b:	lea    rcx,[rax+0x1]
  411e8f:	mov    QWORD PTR [rip+0x121aa],rcx        # 424040 <__swc_bss_base_3464c816>
  411e96:	dec    rcx
  411e99:	call   411ec0 <__swc_fn_3464c816_000170_360af05d>
  411e9e:	mov    r12,QWORD PTR [rax+0xbe0]
  411ea5:	test   r12,r12
  411ea8:	setne  al
  411eab:	je     411eb6 <__swc_fn_3464c816_000167_3459066f+0x46>
  411ead:	mov    rcx,rdi
  411eb0:	mov    rdx,rsi
  411eb3:	call   r12
  411eb6:	pop    r12
  411eb8:	pop    rdi
  411eb9:	pop    rsi
  411eba:	ret
  411ebb:	add    BYTE PTR [rax],al
  411ebd:	add    BYTE PTR [rax],al
	...

0000000000411ec0 <__swc_fn_3464c816_000170_360af05d>:
  411ec0:	push   r12
  411ec2:	push   rdi
  411ec3:	push   rsi
  411ec4:	sub    rsp,0xd0
  411ecb:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411ed1:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411ed7:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  411edd:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  411ee3:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  411ee9:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  411eef:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411ef8:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  411f01:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  411f0a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  411f13:	mov    r12,rcx
  411f16:	mov    edi,ecx
  411f18:	xor    eax,eax
  411f1a:	call   407000 <pthread_getspecific@plt>
  411f1f:	test   rax,rax
  411f22:	je     411f26 <__swc_fn_3464c816_000170_360af05d+0x66>
  411f24:	jmp    411f2e <__swc_fn_3464c816_000170_360af05d+0x6e>
  411f26:	mov    rcx,r12
  411f29:	call   40a9a0 <__swc_fn_3464c816_000171_cbeff767>
  411f2e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  411f34:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  411f3a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411f40:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411f46:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  411f4c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411f52:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  411f5b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411f64:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  411f6d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411f76:	add    rsp,0xd0
  411f7d:	pop    rsi
  411f7e:	pop    rdi
  411f7f:	pop    r12
  411f81:	ret
	...

0000000000411f90 <__swc_fn_3464c816_000173_5eac0ab4>:
  411f90:	push   rsi
  411f91:	sub    rsp,0x30
  411f95:	lea    rsi,[rip+0x14e04]        # 426da0 <__swc_bss_base_3464c816+0x2d60>
  411f9c:	mov    rax,QWORD PTR [rsi]
  411f9f:	test   rax,rax
  411fa2:	je     411faa <__swc_fn_3464c816_000173_5eac0ab4+0x1a>
  411fa4:	add    rsp,0x30
  411fa8:	pop    rsi
  411fa9:	ret
  411faa:	mov    ecx,0x3
  411faf:	mov    edx,0x10
  411fb4:	call   40fa30 <__swc_fn_3464c816_000110_6814119b>
  411fb9:	test   rax,rax
  411fbc:	jne    411fcd <__swc_fn_3464c816_000173_5eac0ab4+0x3d>
  411fbe:	mov    QWORD PTR [rsp+0x18],rax
  411fc3:	call   40d130 <__swc_fn_3464c816_000121_be2e2f68>
  411fc8:	mov    rax,QWORD PTR [rsp+0x18]
  411fcd:	mov    rcx,rax
  411fd0:	xchg   QWORD PTR [rsi],rcx
  411fd3:	add    rsp,0x30
  411fd7:	pop    rsi
  411fd8:	ret
  411fd9:	add    BYTE PTR [rax],al
  411fdb:	add    BYTE PTR [rax],al
  411fdd:	add    BYTE PTR [rax],al
	...

0000000000411fe0 <__swc_fn_3464c816_000176_cf4ffedd>:
  411fe0:	push   rsi
  411fe1:	push   rdi
  411fe2:	sub    rsp,0x8
  411fe6:	mov    rsi,rdx
  411fe9:	mov    rdi,rcx
  411fec:	mov    rax,QWORD PTR [rsi+0x8]
  411ff0:	test   rax,rax
  411ff3:	je     411ffd <__swc_fn_3464c816_000176_cf4ffedd+0x1d>
  411ff5:	mov    rcx,QWORD PTR [rsi]
  411ff8:	mov    QWORD PTR [rax],rcx
  411ffb:	jmp    412004 <__swc_fn_3464c816_000176_cf4ffedd+0x24>
  411ffd:	mov    rax,QWORD PTR [rsi]
  412000:	mov    QWORD PTR [rdi+0x8],rax
  412004:	mov    rax,QWORD PTR [rsi]
  412007:	test   rax,rax
  41200a:	je     412014 <__swc_fn_3464c816_000176_cf4ffedd+0x34>
  41200c:	mov    rcx,QWORD PTR [rsi+0x8]
  412010:	mov    QWORD PTR [rax+0x8],rcx
  412014:	mov    rcx,rdi
  412017:	mov    rdx,QWORD PTR [rsi+0x10]
  41201b:	mov    r8,QWORD PTR [rsi+0x18]
  41201f:	mov    r9,0xffffffffffffffff
  412026:	call   40dce0 <__swc_fn_3464c816_000175_4de704de>
  41202b:	mov    QWORD PTR [rsi+0x18],0x0
  412033:	mov    rax,QWORD PTR [rdi+0x8]
  412037:	test   rax,rax
  41203a:	jne    41204c <__swc_fn_3464c816_000176_cf4ffedd+0x6c>
  41203c:	call   411f90 <__swc_fn_3464c816_000173_5eac0ab4>
  412041:	xor    ecx,ecx
  412043:	mov    QWORD PTR [rax+0x8],rcx
  412047:	xor    ecx,ecx
  412049:	mov    QWORD PTR [rax],rcx
  41204c:	add    rsp,0x8
  412050:	pop    rdi
  412051:	pop    rsi
  412052:	ret
