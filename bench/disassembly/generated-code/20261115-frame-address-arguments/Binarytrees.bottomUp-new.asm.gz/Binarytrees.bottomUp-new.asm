
/workspace/prompt2-20261115/batch2-final-micro/new/binarytrees/binarytrees:     file format elf64-x86-64


Disassembly of section .text:

0000000000407270 <__swc_fn_7dafa2b1_000000_82999b37>:
  407270:	push   rbx
  407271:	push   rsi
  407272:	sub    rsp,0x68
  407276:	mov    rbx,rcx
  407279:	vxorps xmm0,xmm0,xmm0
  40727d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  407283:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  407289:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40728f:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  407295:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40729b:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  4072a1:	mov    QWORD PTR [rsp+0x50],0x20
  4072aa:	mov    DWORD PTR [rsp+0x60],0x10
  4072b2:	mov    rcx,QWORD PTR [rip+0x1bd87]        # 423040 <__swc_bss_base_7dafa2b1>
  4072b9:	test   rcx,rcx
  4072bc:	jne    4072ce <__swc_fn_7dafa2b1_000000_82999b37+0x5e>
  4072be:	call   411ab0 <__swc_fn_7dafa2b1_000170_994c8876>
  4072c3:	lea    rcx,[rax+0x1]
  4072c7:	mov    QWORD PTR [rip+0x1bd72],rcx        # 423040 <__swc_bss_base_7dafa2b1>
  4072ce:	dec    rcx
  4072d1:	call   40e900 <__swc_fn_7dafa2b1_000172_360af05d>
  4072d6:	mov    rcx,QWORD PTR [rax]
  4072d9:	lea    rdx,[rsp+0x8]
  4072de:	mov    rsi,QWORD PTR [rax+0x8]
  4072e2:	mov    rsi,QWORD PTR [rsi+0x8]
  4072e6:	call   rsi
  4072e8:	mov    rax,QWORD PTR [rsp+0x48]
  4072ed:	test   rax,rax
  4072f0:	jne    4072f6 <__swc_fn_7dafa2b1_000000_82999b37+0x86>
  4072f2:	xor    esi,esi
  4072f4:	jmp    40730a <__swc_fn_7dafa2b1_000000_82999b37+0x9a>
  4072f6:	mov    rcx,QWORD PTR [rsp+0x50]
  4072fb:	mov    QWORD PTR [rax],rcx
  4072fe:	mov    QWORD PTR [rax+0x8],0x0
  407306:	lea    rsi,[rax+0x10]
  40730a:	test   ebx,ebx
  40730c:	jle    407327 <__swc_fn_7dafa2b1_000000_82999b37+0xb7>
  40730e:	dec    ebx
  407310:	mov    ecx,ebx
  407312:	call   407270 <__swc_fn_7dafa2b1_000000_82999b37>
  407317:	mov    QWORD PTR [rsi],rax
  40731a:	mov    ecx,ebx
  40731c:	call   407270 <__swc_fn_7dafa2b1_000000_82999b37>
  407321:	mov    QWORD PTR [rsi+0x8],rax
  407325:	jmp    40732f <__swc_fn_7dafa2b1_000000_82999b37+0xbf>
  407327:	vxorps xmm0,xmm0,xmm0
  40732b:	vmovdqu XMMWORD PTR [rsi],xmm0
  40732f:	mov    rax,rsi
  407332:	add    rsp,0x68
  407336:	pop    rsi
  407337:	pop    rbx
  407338:	ret
