
/workspace/prompt2-20261115/session-combined-micro/base/binarytrees/binarytrees:     file format elf64-x86-64


Disassembly of section .text:

000000000040a380 <__swc_fn_7dafa2b1_000177_6e6aee58>:
  40a380:	push   rbx
  40a381:	sub    rsp,0x80
  40a388:	mov    rax,rcx
  40a38b:	mov    rcx,QWORD PTR [rax]
  40a38e:	test   rcx,rcx
  40a391:	je     40a3b0 <__swc_fn_7dafa2b1_000177_6e6aee58+0x30>
  40a393:	mov    QWORD PTR [rsp+0x68],rax
  40a398:	call   40a380 <__swc_fn_7dafa2b1_000177_6e6aee58>
  40a39d:	mov    rax,QWORD PTR [rsp+0x68]
  40a3a2:	mov    rcx,QWORD PTR [rax+0x8]
  40a3a6:	call   40a380 <__swc_fn_7dafa2b1_000177_6e6aee58>
  40a3ab:	mov    rax,QWORD PTR [rsp+0x68]
  40a3b0:	test   rax,rax
  40a3b3:	je     40a422 <__swc_fn_7dafa2b1_000177_6e6aee58+0xa2>
  40a3b5:	lea    rbx,[rsp+0x8]
  40a3ba:	vxorps xmm0,xmm0,xmm0
  40a3be:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a3c4:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a3ca:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a3d0:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40a3d6:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40a3dc:	lea    rcx,[rax-0x10]
  40a3e0:	mov    QWORD PTR [rsp+0x48],rcx
  40a3e5:	mov    rax,QWORD PTR [rax-0x10]
  40a3e9:	mov    QWORD PTR [rsp+0x50],rax
  40a3ee:	mov    rcx,QWORD PTR [rip+0x1b94b]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40a3f5:	test   rcx,rcx
  40a3f8:	jne    40a40a <__swc_fn_7dafa2b1_000177_6e6aee58+0x8a>
  40a3fa:	call   40a1d0 <__swc_fn_7dafa2b1_000165_cf398896>
  40a3ff:	lea    rcx,[rax+0x1]
  40a403:	mov    QWORD PTR [rip+0x1b936],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40a40a:	dec    rcx
  40a40d:	call   4119a0 <__swc_fn_7dafa2b1_000167_fce60b2b>
  40a412:	mov    rcx,QWORD PTR [rax]
  40a415:	mov    rdx,rbx
  40a418:	mov    rbx,QWORD PTR [rax+0x8]
  40a41c:	mov    rbx,QWORD PTR [rbx+0x18]
  40a420:	call   rbx
  40a422:	add    rsp,0x80
  40a429:	pop    rbx
  40a42a:	ret
