
/workspace/prompt2-20261115/session-combined-micro/new/leven/leven:     file format elf64-x86-64


Disassembly of section .text:

000000000040d6e0 <__swc_fn_fc36583a_000002_aa67484d>:
  40d6e0:	push   rbp
  40d6e1:	push   rbx
  40d6e2:	push   r15
  40d6e4:	push   rsi
  40d6e5:	push   rdi
  40d6e6:	push   r12
  40d6e8:	push   r14
  40d6ea:	push   r13
  40d6ec:	sub    rsp,0x10
  40d6f0:	mov    rbp,rsp
  40d6f3:	vmovups XMMWORD PTR [rsp],xmm6
  40d6f8:	sub    rsp,0x610
  40d6ff:	mov    rbx,rsp
  40d702:	mov    ecx,0x17700
  40d707:	sub    rsp,0x8
  40d70b:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d710:	add    rsp,0x8
  40d714:	mov    QWORD PTR [rip+0x1692d],rax        # 424048 <__swc_bss_base_fc36583a+0x8>
  40d71b:	mov    ecx,0xbb80
  40d720:	sub    rsp,0x8
  40d724:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d729:	add    rsp,0x8
  40d72d:	mov    QWORD PTR [rip+0x1691c],rax        # 424050 <__swc_bss_base_fc36583a+0x10>
  40d734:	mov    ecx,0xbb80
  40d739:	sub    rsp,0x8
  40d73d:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d742:	add    rsp,0x8
  40d746:	mov    QWORD PTR [rip+0x1690b],rax        # 424058 <__swc_bss_base_fc36583a+0x18>
  40d74d:	xor    ecx,ecx
  40d74f:	xor    r8d,r8d
  40d752:	cs nop WORD PTR [rax+rax*1+0x0]
  40d75c:	cs nop WORD PTR [rax+rax*1+0x0]
  40d766:	cs nop WORD PTR [rax+rax*1+0x0]
  40d770:	lea    r9,[r8+0x1]
  40d774:	mov    r10,r9
  40d777:	movabs rdx,0x2492492492492493
  40d781:	mov    r15,rax
  40d784:	mov    rax,r8
  40d787:	mul    rdx
  40d78a:	mov    r11,rdx
  40d78d:	mov    rax,r15
  40d790:	mov    rdx,r8
  40d793:	sub    rdx,r11
  40d796:	shr    rdx,1
  40d799:	add    rdx,r11
  40d79c:	shr    rdx,0x2
  40d7a0:	imul   r11,rdx,0x7
  40d7a4:	mov    rdx,r8
  40d7a7:	sub    rdx,r11
  40d7aa:	lea    r11,[rdx+0x4]
  40d7ae:	mov    rdx,QWORD PTR [rip+0x1689b]        # 424050 <__swc_bss_base_fc36583a+0x10>
  40d7b5:	mov    QWORD PTR [rdx+r8*8],rcx
  40d7b9:	mov    rdx,QWORD PTR [rip+0x16898]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40d7c0:	mov    QWORD PTR [rdx+r8*8],r11
  40d7c4:	xor    r8d,r8d
  40d7c7:	test   r11,r11
  40d7ca:	jbe    40d834 <__swc_fn_fc36583a_000002_aa67484d+0x154>
  40d7d0:	xor    esi,esi
  40d7d2:	mov    rdi,QWORD PTR [rip+0x1686f]        # 424048 <__swc_bss_base_fc36583a+0x8>
  40d7d9:	cs nop WORD PTR [rax+rax*1+0x0]
  40d7e3:	cs nop WORD PTR [rax+rax*1+0x0]
  40d7ed:	nop    DWORD PTR [rax]
  40d7f0:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40d7fa:	mov    r15,rax
  40d7fd:	mov    rax,r10
  40d800:	mul    rdx
  40d803:	mov    r12,rdx
  40d806:	mov    rax,r15
  40d809:	shr    r12,0x3
  40d80d:	imul   r12,r12,0x1a
  40d811:	sub    r10,r12
  40d814:	lea    r10,[r10+0x61]
  40d818:	mov    BYTE PTR [rdi+rcx*1],r10b
  40d81c:	inc    rcx
  40d81f:	shr    rdx,0x3
  40d823:	lea    r10,[rdx+rsi*1]
  40d827:	add    r8,0x1
  40d82b:	add    rsi,0x7
  40d82f:	cmp    r8,r11
  40d832:	jb     40d7f0 <__swc_fn_fc36583a_000002_aa67484d+0x110>
  40d834:	mov    r8,r9
  40d837:	cmp    r9,0x1770
  40d83e:	jb     40d770 <__swc_fn_fc36583a_000002_aa67484d+0x90>
  40d844:	mov    ecx,0x500
  40d849:	sub    rsp,0x8
  40d84d:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d852:	add    rsp,0x8
  40d856:	mov    QWORD PTR [rip+0x16803],rax        # 424060 <__swc_bss_base_fc36583a+0x20>
  40d85d:	mov    ecx,0x140
  40d862:	sub    rsp,0x8
  40d866:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d86b:	add    rsp,0x8
  40d86f:	mov    QWORD PTR [rip+0x167f2],rax        # 424068 <__swc_bss_base_fc36583a+0x28>
  40d876:	mov    ecx,0x140
  40d87b:	sub    rsp,0x8
  40d87f:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d884:	add    rsp,0x8
  40d888:	mov    QWORD PTR [rip+0x167e1],rax        # 424070 <__swc_bss_base_fc36583a+0x30>
  40d88f:	xor    ecx,ecx
  40d891:	xor    r8d,r8d
  40d894:	lea    r9,[rbx+0x68]
  40d898:	vxorps xmm0,xmm0,xmm0
  40d89c:	cs nop WORD PTR [rax+rax*1+0x0]
  40d8a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40d8b0:	vmovups XMMWORD PTR [rbx+0x68],xmm0
  40d8b5:	vmovups XMMWORD PTR [rbx+0x78],xmm0
  40d8ba:	mov    r10,QWORD PTR [rip+0x1473f]        # 422000 <__swc_data_base_fc36583a>
  40d8c1:	imul   r10,r10,0x41a7
  40d8c8:	movabs rdx,0x200000005
  40d8d2:	mov    r15,rax
  40d8d5:	mov    rax,r10
  40d8d8:	mul    rdx
  40d8db:	mov    r11,rdx
  40d8de:	mov    rdx,r10
  40d8e1:	sub    rdx,r11
  40d8e4:	shr    rdx,1
  40d8e7:	add    rdx,r11
  40d8ea:	shr    rdx,0x1e
  40d8ee:	imul   r11,rdx,0x7fffffff
  40d8f5:	sub    r10,r11
  40d8f8:	mov    QWORD PTR [rip+0x14701],r10        # 422000 <__swc_data_base_fc36583a>
  40d8ff:	movabs rdx,0xaec33e1f671529a5
  40d909:	mov    rax,r10
  40d90c:	mul    rdx
  40d90f:	mov    rax,r15
  40d912:	shr    rdx,0xc
  40d916:	imul   rdx,rdx,0x1770
  40d91d:	sub    r10,rdx
  40d920:	mov    rdx,QWORD PTR [rip+0x16731]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40d927:	mov    rdx,QWORD PTR [rdx+r10*8]
  40d92b:	mov    r11,rdx
  40d92e:	xor    esi,esi
  40d930:	test   rdx,rdx
  40d933:	jbe    40d968 <__swc_fn_fc36583a_000002_aa67484d+0x288>
  40d935:	mov    rdi,QWORD PTR [rip+0x16714]        # 424050 <__swc_bss_base_fc36583a+0x10>
  40d93c:	mov    r12,QWORD PTR [rip+0x16705]        # 424048 <__swc_bss_base_fc36583a+0x8>
  40d943:	cs nop WORD PTR [rax+rax*1+0x0]
  40d94d:	nop    DWORD PTR [rax]
  40d950:	mov    r13,QWORD PTR [rdi+r10*8]
  40d954:	add    r13,rsi
  40d957:	mov    r13b,BYTE PTR [r12+r13*1]
  40d95b:	mov    BYTE PTR [r9+rsi*1],r13b
  40d95f:	add    rsi,0x1
  40d963:	cmp    rsi,rdx
  40d966:	jb     40d950 <__swc_fn_fc36583a_000002_aa67484d+0x270>
  40d968:	xor    r10d,r10d
  40d96b:	nop    DWORD PTR [rax+rax*1+0x0]
  40d970:	mov    rsi,QWORD PTR [rip+0x14689]        # 422000 <__swc_data_base_fc36583a>
  40d977:	imul   rsi,rsi,0x41a7
  40d97e:	movabs r12,0x200000005
  40d988:	mov    r14,rax
  40d98b:	mov    rax,rsi
  40d98e:	mul    r12
  40d991:	mov    r12,rsi
  40d994:	sub    r12,rdx
  40d997:	shr    r12,1
  40d99a:	add    r12,rdx
  40d99d:	shr    r12,0x1e
  40d9a1:	imul   rdi,r12,0x7fffffff
  40d9a8:	sub    rsi,rdi
  40d9ab:	mov    QWORD PTR [rip+0x1464e],rsi        # 422000 <__swc_data_base_fc36583a>
  40d9b2:	mov    rax,rsi
  40d9b5:	xor    edx,edx
  40d9b7:	div    r11
  40d9ba:	mov    rax,rdx
  40d9bd:	mov    r12,rax
  40d9c0:	imul   rsi,rsi,0x41a7
  40d9c7:	movabs rdx,0x200000005
  40d9d1:	mov    r15,r14
  40d9d4:	mov    rax,rsi
  40d9d7:	mul    rdx
  40d9da:	mov    rdi,rdx
  40d9dd:	mov    rdx,rsi
  40d9e0:	sub    rdx,rdi
  40d9e3:	shr    rdx,1
  40d9e6:	add    rdx,rdi
  40d9e9:	shr    rdx,0x1e
  40d9ed:	imul   rdi,rdx,0x7fffffff
  40d9f4:	sub    rsi,rdi
  40d9f7:	mov    QWORD PTR [rip+0x14602],rsi        # 422000 <__swc_data_base_fc36583a>
  40d9fe:	movabs rdx,0xaaaaaaaaaaaaaaab
  40da08:	mov    rax,rsi
  40da0b:	mul    rdx
  40da0e:	shr    rdx,1
  40da11:	lea    rdx,[rdx+rdx*2]
  40da15:	mov    r13,rsi
  40da18:	sub    r13,rdx
  40da1b:	imul   rsi,rsi,0x41a7
  40da22:	movabs rdx,0x200000005
  40da2c:	mov    rax,rsi
  40da2f:	mul    rdx
  40da32:	mov    rdi,rdx
  40da35:	mov    rdx,rsi
  40da38:	sub    rdx,rdi
  40da3b:	shr    rdx,1
  40da3e:	add    rdx,rdi
  40da41:	shr    rdx,0x1e
  40da45:	imul   rdi,rdx,0x7fffffff
  40da4c:	sub    rsi,rdi
  40da4f:	mov    QWORD PTR [rip+0x145aa],rsi        # 422000 <__swc_data_base_fc36583a>
  40da56:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40da60:	mov    rax,rsi
  40da63:	mul    rdx
  40da66:	mov    rax,r15
  40da69:	shr    rdx,0x3
  40da6d:	imul   rdx,rdx,0x1a
  40da71:	sub    rsi,rdx
  40da74:	lea    rdx,[rsi+0x61]
  40da78:	test   r13,r13
  40da7b:	jne    40da86 <__swc_fn_fc36583a_000002_aa67484d+0x3a6>
  40da7d:	mov    BYTE PTR [r9+r12*1],dl
  40da81:	jmp    40daf9 <__swc_fn_fc36583a_000002_aa67484d+0x419>
  40da86:	cmp    r13,0x1
  40da8a:	jne    40daba <__swc_fn_fc36583a_000002_aa67484d+0x3da>
  40da8c:	cmp    r11,0x2
  40da90:	jbe    40daf9 <__swc_fn_fc36583a_000002_aa67484d+0x419>
  40da96:	lea    rdx,[r12+0x1]
  40da9b:	cmp    rdx,r11
  40da9e:	jae    40dab4 <__swc_fn_fc36583a_000002_aa67484d+0x3d4>
  40daa0:	mov    sil,BYTE PTR [r9+r12*1+0x1]
  40daa5:	mov    BYTE PTR [r9+r12*1],sil
  40daa9:	mov    r12,rdx
  40daac:	inc    rdx
  40daaf:	cmp    rdx,r11
  40dab2:	jb     40daa0 <__swc_fn_fc36583a_000002_aa67484d+0x3c0>
  40dab4:	sub    r11,0x1
  40dab8:	jmp    40daf9 <__swc_fn_fc36583a_000002_aa67484d+0x419>
  40daba:	mov    rsi,r11
  40dabd:	cmp    rsi,r12
  40dac0:	jbe    40daf1 <__swc_fn_fc36583a_000002_aa67484d+0x411>
  40dac2:	cs nop WORD PTR [rax+rax*1+0x0]
  40dacc:	cs nop WORD PTR [rax+rax*1+0x0]
  40dad6:	cs nop WORD PTR [rax+rax*1+0x0]
  40dae0:	mov    dil,BYTE PTR [r9+rsi*1-0x1]
  40dae5:	mov    BYTE PTR [r9+rsi*1],dil
  40dae9:	dec    rsi
  40daec:	cmp    rsi,r12
  40daef:	ja     40dae0 <__swc_fn_fc36583a_000002_aa67484d+0x400>
  40daf1:	mov    BYTE PTR [r9+r12*1],dl
  40daf5:	add    r11,0x1
  40daf9:	add    r10,0x1
  40dafd:	cmp    r10,0x2
  40db01:	jb     40d970 <__swc_fn_fc36583a_000002_aa67484d+0x290>
  40db07:	mov    rdx,QWORD PTR [rip+0x1655a]        # 424068 <__swc_bss_base_fc36583a+0x28>
  40db0e:	mov    QWORD PTR [rdx+r8*8],rcx
  40db12:	mov    rdx,QWORD PTR [rip+0x16557]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40db19:	mov    QWORD PTR [rdx+r8*8],r11
  40db1d:	xor    edx,edx
  40db1f:	test   r11,r11
  40db22:	jbe    40db54 <__swc_fn_fc36583a_000002_aa67484d+0x474>
  40db24:	mov    r10,QWORD PTR [rip+0x16535]        # 424060 <__swc_bss_base_fc36583a+0x20>
  40db2b:	cs nop WORD PTR [rax+rax*1+0x0]
  40db35:	cs nop WORD PTR [rax+rax*1+0x0]
  40db3f:	nop
  40db40:	mov    sil,BYTE PTR [r9+rdx*1]
  40db44:	mov    BYTE PTR [r10+rcx*1],sil
  40db48:	inc    rcx
  40db4b:	add    rdx,0x1
  40db4f:	cmp    rdx,r11
  40db52:	jb     40db40 <__swc_fn_fc36583a_000002_aa67484d+0x460>
  40db54:	add    r8,0x1
  40db58:	cmp    r8,0x28
  40db5c:	jb     40d8b0 <__swc_fn_fc36583a_000002_aa67484d+0x1d0>
  40db62:	sub    rsp,0x8
  40db66:	call   40a400 <__swc_fn_fc36583a_000001_1ca87929>
  40db6b:	add    rsp,0x8
  40db6f:	vmovups xmm6,xmm0
  40db73:	lea    rax,[rbx+0xf8]
  40db7a:	vxorps xmm0,xmm0,xmm0
  40db7e:	xor    ecx,ecx
  40db80:	vmovdqu XMMWORD PTR [rax+rcx*1],xmm0
  40db85:	add    rcx,0x10
  40db89:	cmp    rcx,0x200
  40db90:	jne    40db80 <__swc_fn_fc36583a_000002_aa67484d+0x4a0>
  40db92:	lea    rcx,[rbx+0x2f8]
  40db99:	vxorps xmm0,xmm0,xmm0
  40db9d:	xor    edx,edx
  40db9f:	nop
  40dba0:	vmovdqu XMMWORD PTR [rcx+rdx*1],xmm0
  40dba5:	add    rdx,0x10
  40dba9:	cmp    rdx,0x200
  40dbb0:	jne    40dba0 <__swc_fn_fc36583a_000002_aa67484d+0x4c0>
  40dbb2:	xor    edx,edx
  40dbb4:	mov    r8,QWORD PTR [rip+0x164ad]        # 424068 <__swc_bss_base_fc36583a+0x28>
  40dbbb:	mov    QWORD PTR [rsp+0x5b0],r8
  40dbc3:	mov    r9,QWORD PTR [rip+0x164a6]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40dbca:	mov    QWORD PTR [rsp+0x5b8],r9
  40dbd2:	mov    r10,QWORD PTR [rip+0x16477]        # 424050 <__swc_bss_base_fc36583a+0x10>
  40dbd9:	mov    QWORD PTR [rsp+0x5a0],0x0
  40dbe5:	mov    QWORD PTR [rsp+0x5c0],r10
  40dbed:	mov    r11,QWORD PTR [rip+0x16464]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40dbf4:	mov    QWORD PTR [rsp+0x5c8],r11
  40dbfc:	jmp    40dc38 <__swc_fn_fc36583a_000002_aa67484d+0x558>
  40dbfe:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc08:	nop    DWORD PTR [rax+rax*1+0x0]
  40dc10:	mov    QWORD PTR [rsp+0x5a0],rsi
  40dc18:	mov    r8,QWORD PTR [rsp+0x5b0]
  40dc20:	mov    r9,QWORD PTR [rsp+0x5b8]
  40dc28:	mov    r10,QWORD PTR [rsp+0x5c0]
  40dc30:	mov    r11,QWORD PTR [rsp+0x5c8]
  40dc38:	mov    rdi,QWORD PTR [r8+rdx*8]
  40dc3c:	mov    QWORD PTR [rsp+0x5d0],rdi
  40dc44:	mov    r12,QWORD PTR [r9+rdx*8]
  40dc48:	mov    QWORD PTR [rsp+0x5d8],r12
  40dc50:	mov    r13d,0x40000000
  40dc56:	mov    r14,0xffffffffffffffff
  40dc5d:	xor    r15d,r15d
  40dc60:	mov    QWORD PTR [rsp+0x5a8],rdx
  40dc68:	vmovq  xmm3,r13
  40dc6d:	vmovq  xmm4,r14
  40dc72:	vmovq  xmm5,r15
  40dc77:	jmp    40dca2 <__swc_fn_fc36583a_000002_aa67484d+0x5c2>
  40dc79:	nop    DWORD PTR [rax+0x0]
  40dc80:	mov    r10,QWORD PTR [rsp+0x5c0]
  40dc88:	mov    r11,QWORD PTR [rsp+0x5c8]
  40dc90:	mov    rdi,QWORD PTR [rsp+0x5d0]
  40dc98:	vmovq  xmm3,r13
  40dc9d:	vmovq  xmm4,r14
  40dca2:	mov    r8,QWORD PTR [r10+r15*8]
  40dca6:	mov    QWORD PTR [rsp+0x5f8],r8
  40dcae:	mov    r9,QWORD PTR [r11+r15*8]
  40dcb2:	mov    rdx,r9
  40dcb5:	sub    rdx,r12
  40dcb8:	mov    rsi,r12
  40dcbb:	sub    rsi,r9
  40dcbe:	cmovbe rsi,rdx
  40dcc2:	cmp    rsi,0x3
  40dcc6:	jbe    40dcd7 <__swc_fn_fc36583a_000002_aa67484d+0x5f7>
  40dcc8:	vmovq  r13,xmm3
  40dccd:	vmovq  r14,xmm4
  40dcd2:	jmp    40de4b <__swc_fn_fc36583a_000002_aa67484d+0x76b>
  40dcd7:	lea    rdx,[r9+0x1]
  40dcdb:	xor    esi,esi
  40dcdd:	test   rdx,rdx
  40dce0:	jbe    40dcfd <__swc_fn_fc36583a_000002_aa67484d+0x61d>
  40dce2:	cs nop WORD PTR [rax+rax*1+0x0]
  40dcec:	nop    DWORD PTR [rax+0x0]
  40dcf0:	mov    QWORD PTR [rax+rsi*8],rsi
  40dcf4:	add    rsi,0x1
  40dcf8:	cmp    rsi,rdx
  40dcfb:	jb     40dcf0 <__swc_fn_fc36583a_000002_aa67484d+0x610>
  40dcfd:	xor    esi,esi
  40dcff:	test   r12,r12
  40dd02:	jbe    40de2d <__swc_fn_fc36583a_000002_aa67484d+0x74d>
  40dd08:	mov    r10,QWORD PTR [rip+0x16351]        # 424060 <__swc_bss_base_fc36583a+0x20>
  40dd0f:	add    r10,rdi
  40dd12:	vmovsd xmm0,QWORD PTR [rsp+0x5d8]
  40dd1b:	vmovsd xmm1,QWORD PTR [rsp+0x5f8]
  40dd24:	vmovq  xmm2,r10
  40dd29:	nop    DWORD PTR [rax+0x0]
  40dd30:	lea    r11,[rsi+0x1]
  40dd34:	mov    QWORD PTR [rbx+0x2f8],r11
  40dd3b:	mov    sil,BYTE PTR [r10+rsi*1]
  40dd3f:	xor    edi,edi
  40dd41:	test   r9,r9
  40dd44:	jbe    40dd96 <__swc_fn_fc36583a_000002_aa67484d+0x6b6>
  40dd46:	mov    r14,QWORD PTR [rip+0x162fb]        # 424048 <__swc_bss_base_fc36583a+0x8>
  40dd4d:	add    r14,r8
  40dd50:	mov    r15,QWORD PTR [rbx+0xf8]
  40dd57:	mov    r13,r11
  40dd5a:	nop    WORD PTR [rax+rax*1+0x0]
  40dd60:	xor    r8d,r8d
  40dd63:	cmp    BYTE PTR [r14+rdi*1],sil
  40dd67:	setne  r8b
  40dd6b:	add    r8,r15
  40dd6e:	mov    r15,QWORD PTR [rax+rdi*8+0x8]
  40dd73:	lea    r10,[r15+0x1]
  40dd77:	cmp    r10,r8
  40dd7a:	cmovb  r8,r10
  40dd7e:	inc    r13
  40dd81:	cmp    r13,r8
  40dd84:	cmovae r13,r8
  40dd88:	mov    QWORD PTR [rcx+rdi*8+0x8],r13
  40dd8d:	add    rdi,0x1
  40dd91:	cmp    rdi,r9
  40dd94:	jb     40dd60 <__swc_fn_fc36583a_000002_aa67484d+0x680>
  40dd96:	xor    r8d,r8d
  40dd99:	test   rdx,rdx
  40dd9c:	jbe    40de11 <__swc_fn_fc36583a_000002_aa67484d+0x731>
  40dda2:	cmp    rdx,0x4
  40dda6:	jb     40de00 <__swc_fn_fc36583a_000002_aa67484d+0x720>
  40dda8:	lea    r10,[rdx-0x3]
  40ddac:	nop    DWORD PTR [rax+0x0]
  40ddb0:	mov    rsi,QWORD PTR [rcx+r8*8]
  40ddb4:	mov    QWORD PTR [rax+r8*8],rsi
  40ddb8:	mov    rsi,QWORD PTR [rcx+r8*8+0x8]
  40ddbd:	mov    QWORD PTR [rax+r8*8+0x8],rsi
  40ddc2:	mov    rsi,QWORD PTR [rcx+r8*8+0x10]
  40ddc7:	mov    QWORD PTR [rax+r8*8+0x10],rsi
  40ddcc:	mov    rsi,QWORD PTR [rcx+r8*8+0x18]
  40ddd1:	mov    QWORD PTR [rax+r8*8+0x18],rsi
  40ddd6:	add    r8,0x4
  40ddda:	cmp    r8,r10
  40dddd:	jb     40ddb0 <__swc_fn_fc36583a_000002_aa67484d+0x6d0>
  40dddf:	cmp    r8,rdx
  40dde2:	jae    40de11 <__swc_fn_fc36583a_000002_aa67484d+0x731>
  40dde4:	cs nop WORD PTR [rax+rax*1+0x0]
  40ddee:	cs nop WORD PTR [rax+rax*1+0x0]
  40ddf8:	nop    DWORD PTR [rax+rax*1+0x0]
  40de00:	mov    rsi,QWORD PTR [rcx+r8*8]
  40de04:	mov    QWORD PTR [rax+r8*8],rsi
  40de08:	add    r8,0x1
  40de0c:	cmp    r8,rdx
  40de0f:	jb     40de00 <__swc_fn_fc36583a_000002_aa67484d+0x720>
  40de11:	mov    rsi,r11
  40de14:	vmovq  r12,xmm0
  40de19:	cmp    r11,r12
  40de1c:	jae    40de2d <__swc_fn_fc36583a_000002_aa67484d+0x74d>
  40de1e:	vmovq  r8,xmm1
  40de23:	vmovq  r10,xmm2
  40de28:	jmp    40dd30 <__swc_fn_fc36583a_000002_aa67484d+0x650>
  40de2d:	mov    rdx,QWORD PTR [rax+r9*8]
  40de31:	vmovq  r13,xmm3
  40de36:	cmp    rdx,r13
  40de39:	cmovb  r13,rdx
  40de3d:	vmovq  r14,xmm4
  40de42:	vmovq  r15,xmm5
  40de47:	cmovb  r14,r15
  40de4b:	add    r15,0x1
  40de4f:	vmovq  xmm5,r15
  40de54:	cmp    r15,0x1770
  40de5b:	jb     40dc80 <__swc_fn_fc36583a_000002_aa67484d+0x5a0>
  40de61:	imul   r13,r13,0x1f
  40de65:	add    r13,r14
  40de68:	mov    rsi,QWORD PTR [rsp+0x5a0]
  40de70:	add    rsi,r13
  40de73:	mov    rdx,QWORD PTR [rsp+0x5a8]
  40de7b:	add    rdx,0x1
  40de7f:	cmp    rdx,0x28
  40de83:	jb     40dc10 <__swc_fn_fc36583a_000002_aa67484d+0x530>
  40de89:	sub    rsp,0x8
  40de8d:	call   40a400 <__swc_fn_fc36583a_000001_1ca87929>
  40de92:	add    rsp,0x8
  40de96:	vsubsd xmm0,xmm0,xmm6
  40de9a:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x5386]        # 413228 <__swc_rdata_base_fc36583a+0x118>
  40dea2:	lea    rax,[rip+0x5277]        # 413120 <__swc_rdata_base_fc36583a+0x10>
  40dea9:	sub    rsp,0x90
  40deb0:	mov    rcx,rsp
  40deb3:	vmovups xmm1,XMMWORD PTR [rip+0x534d]        # 413208 <__swc_rdata_base_fc36583a+0xf8>
  40debb:	vmovups XMMWORD PTR [rcx],xmm1
  40debf:	mov    QWORD PTR [rcx+0x30],rsp
  40dec3:	lea    rdx,[rip+0x5266]        # 413130 <__swc_rdata_base_fc36583a+0x20>
  40deca:	mov    QWORD PTR [rcx+0x38],rdx
  40dece:	mov    QWORD PTR [rcx+0x10],rsi
  40ded2:	lea    r8,[rsp+0x10]
  40ded7:	mov    QWORD PTR [rcx+0x40],r8
  40dedb:	lea    r8,[rip+0x5296]        # 413178 <__swc_rdata_base_fc36583a+0x68>
  40dee2:	mov    QWORD PTR [rcx+0x48],r8
  40dee6:	vmovups xmm1,XMMWORD PTR [rip+0x532a]        # 413218 <__swc_rdata_base_fc36583a+0x108>
  40deee:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40def3:	lea    r8,[rsp+0x18]
  40def8:	mov    QWORD PTR [rcx+0x50],r8
  40defc:	mov    QWORD PTR [rcx+0x58],rdx
  40df00:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40df05:	lea    r8,[rcx+0x28]
  40df09:	mov    QWORD PTR [rcx+0x60],r8
  40df0d:	lea    r8,[rip+0x52ac]        # 4131c0 <__swc_rdata_base_fc36583a+0xb0>
  40df14:	mov    QWORD PTR [rcx+0x68],r8
  40df18:	mov    QWORD PTR [rcx+0x70],rax
  40df1c:	mov    QWORD PTR [rcx+0x78],rdx
  40df20:	lea    rax,[rcx+0x30]
  40df24:	mov    QWORD PTR [rcx+0x80],rax
  40df2b:	mov    QWORD PTR [rcx+0x88],0x5
  40df36:	lea    rcx,[rcx+0x80]
  40df3d:	sub    rsp,0x8
  40df41:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  40df46:	add    rsp,0x6a8
  40df4d:	vmovups xmm6,XMMWORD PTR [rsp]
  40df52:	add    rsp,0x10
  40df56:	pop    r13
  40df58:	pop    r14
  40df5a:	pop    r12
  40df5c:	pop    rdi
  40df5d:	pop    rsi
  40df5e:	pop    r15
  40df60:	pop    rbx
  40df61:	pop    rbp
  40df62:	ret
