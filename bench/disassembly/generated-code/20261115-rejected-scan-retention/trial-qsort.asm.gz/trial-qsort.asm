
/workspace/prompt2-20261115/batch8-final-micro/new/sort/sort:     file format elf64-x86-64


Disassembly of section .text:

0000000000407320 <__swc_fn_ff58629f_000003_2a1d71b4>:
  407320:	push   rsi
  407321:	push   rdi
  407322:	push   r12
  407324:	mov    rsi,rcx
  407327:	mov    rdi,rdx
  40732a:	mov    r12,r8
  40732d:	cs nop WORD PTR [rax+rax*1+0x0]
  407337:	nop    WORD PTR [rax+rax*1+0x0]
  407340:	mov    rax,r12
  407343:	sub    rax,rdi
  407346:	cmp    rax,0x10
  40734a:	jle    407434 <__swc_fn_ff58629f_000003_2a1d71b4+0x114>
  407350:	shr    rax,1
  407353:	lea    rcx,[rdi+rax*1]
  407357:	mov    rax,QWORD PTR [rsi+rcx*8]
  40735b:	mov    rdx,QWORD PTR [rsi+rdi*8]
  40735f:	cmp    rax,rdx
  407362:	jae    40736f <__swc_fn_ff58629f_000003_2a1d71b4+0x4f>
  407364:	mov    QWORD PTR [rsi+rdi*8],rax
  407368:	mov    QWORD PTR [rsi+rcx*8],rdx
  40736c:	mov    rdx,rax
  40736f:	mov    rax,QWORD PTR [rsi+r12*8]
  407373:	cmp    rax,rdx
  407376:	jae    407383 <__swc_fn_ff58629f_000003_2a1d71b4+0x63>
  407378:	mov    QWORD PTR [rsi+rdi*8],rax
  40737c:	mov    QWORD PTR [rsi+r12*8],rdx
  407380:	mov    rax,rdx
  407383:	mov    rdx,QWORD PTR [rsi+rcx*8]
  407387:	cmp    rax,rdx
  40738a:	jae    407394 <__swc_fn_ff58629f_000003_2a1d71b4+0x74>
  40738c:	mov    QWORD PTR [rsi+rcx*8],rax
  407390:	mov    QWORD PTR [rsi+r12*8],rdx
  407394:	mov    rax,QWORD PTR [rsi+rcx*8]
  407398:	mov    r9,rdi
  40739b:	mov    r10,r12
  40739e:	xchg   ax,ax
  4073a0:	mov    rcx,QWORD PTR [rsi+r9*8]
  4073a4:	cmp    rcx,rax
  4073a7:	jae    4073bd <__swc_fn_ff58629f_000003_2a1d71b4+0x9d>
  4073a9:	nop    DWORD PTR [rax+0x0]
  4073b0:	add    r9,0x1
  4073b4:	mov    rcx,QWORD PTR [rsi+r9*8]
  4073b8:	cmp    rcx,rax
  4073bb:	jb     4073b0 <__swc_fn_ff58629f_000003_2a1d71b4+0x90>
  4073bd:	mov    rdx,QWORD PTR [rsi+r10*8]
  4073c1:	cmp    rdx,rax
  4073c4:	jbe    4073dd <__swc_fn_ff58629f_000003_2a1d71b4+0xbd>
  4073c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4073d0:	sub    r10,0x1
  4073d4:	mov    rdx,QWORD PTR [rsi+r10*8]
  4073d8:	cmp    rdx,rax
  4073db:	ja     4073d0 <__swc_fn_ff58629f_000003_2a1d71b4+0xb0>
  4073dd:	cmp    r9,r10
  4073e0:	jg     4073f7 <__swc_fn_ff58629f_000003_2a1d71b4+0xd7>
  4073e2:	mov    QWORD PTR [rsi+r9*8],rdx
  4073e6:	mov    QWORD PTR [rsi+r10*8],rcx
  4073ea:	add    r9,0x1
  4073ee:	sub    r10,0x1
  4073f2:	cmp    r9,r10
  4073f5:	jle    4073a0 <__swc_fn_ff58629f_000003_2a1d71b4+0x80>
  4073f7:	mov    rax,r10
  4073fa:	sub    rax,rdi
  4073fd:	mov    rcx,r12
  407400:	sub    rcx,r9
  407403:	cmp    rax,rcx
  407406:	jge    40741e <__swc_fn_ff58629f_000003_2a1d71b4+0xfe>
  407408:	mov    rcx,rsi
  40740b:	mov    rdx,rdi
  40740e:	mov    r8,r10
  407411:	mov    rdi,r9
  407414:	call   407320 <__swc_fn_ff58629f_000003_2a1d71b4>
  407419:	jmp    407340 <__swc_fn_ff58629f_000003_2a1d71b4+0x20>
  40741e:	mov    rcx,rsi
  407421:	mov    rdx,r9
  407424:	mov    r8,r12
  407427:	mov    r12,r10
  40742a:	call   407320 <__swc_fn_ff58629f_000003_2a1d71b4>
  40742f:	jmp    407340 <__swc_fn_ff58629f_000003_2a1d71b4+0x20>
  407434:	lea    rax,[rdi+0x1]
  407438:	cmp    rax,r12
  40743b:	jg     407473 <__swc_fn_ff58629f_000003_2a1d71b4+0x153>
  40743d:	nop    DWORD PTR [rax]
  407440:	mov    rcx,QWORD PTR [rsi+rax*8]
  407444:	lea    rdx,[rax-0x1]
  407448:	cmp    rdx,rdi
  40744b:	jl     407466 <__swc_fn_ff58629f_000003_2a1d71b4+0x146>
  40744d:	nop    DWORD PTR [rax]
  407450:	mov    r8,QWORD PTR [rsi+rdx*8]
  407454:	cmp    r8,rcx
  407457:	jbe    407466 <__swc_fn_ff58629f_000003_2a1d71b4+0x146>
  407459:	mov    QWORD PTR [rsi+rdx*8+0x8],r8
  40745e:	dec    rdx
  407461:	cmp    rdx,rdi
  407464:	jge    407450 <__swc_fn_ff58629f_000003_2a1d71b4+0x130>
  407466:	mov    QWORD PTR [rsi+rdx*8+0x8],rcx
  40746b:	inc    rax
  40746e:	cmp    rax,r12
  407471:	jle    407440 <__swc_fn_ff58629f_000003_2a1d71b4+0x120>
  407473:	pop    r12
  407475:	pop    rdi
  407476:	pop    rsi
  407477:	ret
