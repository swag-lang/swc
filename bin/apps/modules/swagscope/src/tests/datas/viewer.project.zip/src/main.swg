// Fictional generated sample showing a small project source file.
func main()
{
    print("Loaded three field sites")
}
