
/workspace/prompt2-20261115/batch5-final-micro/base/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

000000000040d680 <__swc_fn_3464c816_000175_7f24d040>:
  40d680:	push   rbp
  40d681:	push   rbx
  40d682:	push   rsi
  40d683:	push   rdi
  40d684:	push   r12
  40d686:	push   r13
  40d688:	push   r15
  40d68a:	push   r14
  40d68c:	sub    rsp,0x50
  40d690:	mov    rbp,rsp
  40d693:	vmovups XMMWORD PTR [rsp],xmm6
  40d698:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  40d69e:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  40d6a4:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  40d6aa:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  40d6b0:	sub    rsp,0x70
  40d6b4:	mov    rbx,rsp
  40d6b7:	mov    ecx,0x1000000
  40d6bc:	sub    rsp,0x8
  40d6c0:	call   4120a0 <__swc_fn_3464c816_000176_2744b483>
  40d6c5:	add    rsp,0x8
  40d6c9:	mov    rsi,rax
  40d6cc:	mov    QWORD PTR [rsp+0x50],rax
  40d6d1:	xor    ecx,ecx
  40d6d3:	cs nop WORD PTR [rax+rax*1+0x0]
  40d6dd:	cs nop WORD PTR [rax+rax*1+0x0]
  40d6e7:	nop    WORD PTR [rax+rax*1+0x0]
  40d6f0:	mov    r8,QWORD PTR [rip+0x14919]        # 422010 <__swc_data_base_3464c816+0x10>
  40d6f7:	imul   r8,r8,0x41a7
  40d6fe:	movabs rdx,0x200000005
  40d708:	mov    r11,rax
  40d70b:	mov    rax,r8
  40d70e:	mul    rdx
  40d711:	mov    r9,rdx
  40d714:	mov    rdx,r8
  40d717:	sub    rdx,r9
  40d71a:	shr    rdx,1
  40d71d:	add    rdx,r9
  40d720:	shr    rdx,0x1e
  40d724:	imul   r9,rdx,0x7fffffff
  40d72b:	sub    r8,r9
  40d72e:	mov    QWORD PTR [rip+0x148db],r8        # 422010 <__swc_data_base_3464c816+0x10>
  40d735:	mov    DWORD PTR [rsi+rcx*4],r8d
  40d739:	add    rcx,0x1
  40d73d:	mov    r8,QWORD PTR [rip+0x148cc]        # 422010 <__swc_data_base_3464c816+0x10>
  40d744:	imul   r8,r8,0x41a7
  40d74b:	movabs rdx,0x200000005
  40d755:	mov    rax,r8
  40d758:	mul    rdx
  40d75b:	mov    r9,rdx
  40d75e:	mov    rax,r11
  40d761:	mov    rdx,r8
  40d764:	sub    rdx,r9
  40d767:	shr    rdx,1
  40d76a:	add    rdx,r9
  40d76d:	shr    rdx,0x1e
  40d771:	imul   rdx,rdx,0x7fffffff
  40d778:	sub    r8,rdx
  40d77b:	mov    QWORD PTR [rip+0x1488e],r8        # 422010 <__swc_data_base_3464c816+0x10>
  40d782:	mov    DWORD PTR [rsi+rcx*4],r8d
  40d786:	add    rcx,0x1
  40d78a:	cmp    rcx,0x400000
  40d791:	jb     40d6f0 <__swc_fn_3464c816_000175_7f24d040+0x70>
  40d797:	mov    rcx,QWORD PTR [rip+0x14872]        # 422010 <__swc_data_base_3464c816+0x10>
  40d79e:	imul   rcx,rcx,0x41a7
  40d7a5:	movabs rdx,0x200000005
  40d7af:	mov    rax,rcx
  40d7b2:	mul    rdx
  40d7b5:	mov    r8,rdx
  40d7b8:	mov    rdx,rcx
  40d7bb:	sub    rdx,r8
  40d7be:	shr    rdx,1
  40d7c1:	add    rdx,r8
  40d7c4:	shr    rdx,0x1e
  40d7c8:	imul   r8,rdx,0x7fffffff
  40d7cf:	mov    rdi,rcx
  40d7d2:	sub    rdi,r8
  40d7d5:	mov    QWORD PTR [rip+0x14834],rdi        # 422010 <__swc_data_base_3464c816+0x10>
  40d7dc:	imul   rcx,rdi,0x41a7
  40d7e3:	movabs rdx,0x200000005
  40d7ed:	mov    rax,rcx
  40d7f0:	mul    rdx
  40d7f3:	mov    r8,rdx
  40d7f6:	mov    rdx,rcx
  40d7f9:	sub    rdx,r8
  40d7fc:	shr    rdx,1
  40d7ff:	add    rdx,r8
  40d802:	shr    rdx,0x1e
  40d806:	imul   rdx,rdx,0x7fffffff
  40d80d:	mov    r12,rcx
  40d810:	sub    r12,rdx
  40d813:	mov    QWORD PTR [rip+0x147f6],r12        # 422010 <__swc_data_base_3464c816+0x10>
  40d81a:	imul   rcx,r12,0x41a7
  40d821:	movabs rdx,0x200000005
  40d82b:	mov    rax,rcx
  40d82e:	mul    rdx
  40d831:	mov    r8,rdx
  40d834:	mov    rdx,rcx
  40d837:	sub    rdx,r8
  40d83a:	shr    rdx,1
  40d83d:	add    rdx,r8
  40d840:	shr    rdx,0x1e
  40d844:	imul   rdx,rdx,0x7fffffff
  40d84b:	mov    r13,rcx
  40d84e:	sub    r13,rdx
  40d851:	mov    QWORD PTR [rip+0x147b8],r13        # 422010 <__swc_data_base_3464c816+0x10>
  40d858:	imul   rcx,r13,0x41a7
  40d85f:	movabs rdx,0x200000005
  40d869:	mov    rax,rcx
  40d86c:	mul    rdx
  40d86f:	mov    r8,rdx
  40d872:	mov    rdx,rcx
  40d875:	sub    rdx,r8
  40d878:	shr    rdx,1
  40d87b:	add    rdx,r8
  40d87e:	shr    rdx,0x1e
  40d882:	imul   rdx,rdx,0x7fffffff
  40d889:	mov    r14,rcx
  40d88c:	sub    r14,rdx
  40d88f:	mov    QWORD PTR [rip+0x1477a],r14        # 422010 <__swc_data_base_3464c816+0x10>
  40d896:	imul   rcx,r14,0x41a7
  40d89d:	movabs rdx,0x200000005
  40d8a7:	mov    rax,rcx
  40d8aa:	mul    rdx
  40d8ad:	mov    r8,rdx
  40d8b0:	mov    rdx,rcx
  40d8b3:	sub    rdx,r8
  40d8b6:	shr    rdx,1
  40d8b9:	add    rdx,r8
  40d8bc:	shr    rdx,0x1e
  40d8c0:	imul   rdx,rdx,0x7fffffff
  40d8c7:	mov    r15,rcx
  40d8ca:	sub    r15,rdx
  40d8cd:	mov    QWORD PTR [rip+0x1473c],r15        # 422010 <__swc_data_base_3464c816+0x10>
  40d8d4:	imul   rcx,r15,0x41a7
  40d8db:	movabs rdx,0x200000005
  40d8e5:	mov    rax,rcx
  40d8e8:	mul    rdx
  40d8eb:	mov    r8,rdx
  40d8ee:	mov    rdx,rcx
  40d8f1:	sub    rdx,r8
  40d8f4:	shr    rdx,1
  40d8f7:	add    rdx,r8
  40d8fa:	shr    rdx,0x1e
  40d8fe:	imul   rdx,rdx,0x7fffffff
  40d905:	mov    rsi,rcx
  40d908:	sub    rsi,rdx
  40d90b:	mov    QWORD PTR [rip+0x146fe],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40d912:	imul   rcx,rsi,0x41a7
  40d919:	movabs rdx,0x200000005
  40d923:	mov    rax,rcx
  40d926:	mul    rdx
  40d929:	mov    r8,rdx
  40d92c:	mov    rdx,rcx
  40d92f:	sub    rdx,r8
  40d932:	shr    rdx,1
  40d935:	add    rdx,r8
  40d938:	shr    rdx,0x1e
  40d93c:	imul   rdx,rdx,0x7fffffff
  40d943:	mov    QWORD PTR [rsp+0x58],rsi
  40d948:	mov    rsi,rcx
  40d94b:	sub    rsi,rdx
  40d94e:	mov    QWORD PTR [rip+0x146bb],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40d955:	imul   rcx,rsi,0x41a7
  40d95c:	movabs rdx,0x200000005
  40d966:	mov    rax,rcx
  40d969:	mul    rdx
  40d96c:	mov    r8,rdx
  40d96f:	mov    rdx,rcx
  40d972:	sub    rdx,r8
  40d975:	shr    rdx,1
  40d978:	add    rdx,r8
  40d97b:	shr    rdx,0x1e
  40d97f:	imul   rdx,rdx,0x7fffffff
  40d986:	mov    QWORD PTR [rsp+0x60],rsi
  40d98b:	mov    rsi,rcx
  40d98e:	sub    rsi,rdx
  40d991:	mov    QWORD PTR [rip+0x14678],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40d998:	mov    QWORD PTR [rbx],0x0
  40d99f:	mov    rcx,QWORD PTR [rip+0x1466a]        # 422010 <__swc_data_base_3464c816+0x10>
  40d9a6:	imul   rcx,rcx,0x41a7
  40d9ad:	movabs rdx,0x200000005
  40d9b7:	mov    rax,rcx
  40d9ba:	mul    rdx
  40d9bd:	mov    r8,rdx
  40d9c0:	mov    rdx,rcx
  40d9c3:	sub    rdx,r8
  40d9c6:	shr    rdx,1
  40d9c9:	add    rdx,r8
  40d9cc:	shr    rdx,0x1e
  40d9d0:	imul   r8,rdx,0x7fffffff
  40d9d7:	mov    QWORD PTR [rsp+0x68],rsi
  40d9dc:	mov    rsi,rcx
  40d9df:	sub    rsi,r8
  40d9e2:	mov    QWORD PTR [rip+0x14627],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40d9e9:	mov    DWORD PTR [rbx],esi
  40d9eb:	mov    rcx,QWORD PTR [rip+0x1461e]        # 422010 <__swc_data_base_3464c816+0x10>
  40d9f2:	imul   rcx,rcx,0x41a7
  40d9f9:	movabs rdx,0x200000005
  40da03:	mov    rax,rcx
  40da06:	mul    rdx
  40da09:	mov    r8,rdx
  40da0c:	mov    rdx,rcx
  40da0f:	sub    rdx,r8
  40da12:	shr    rdx,1
  40da15:	add    rdx,r8
  40da18:	shr    rdx,0x1e
  40da1c:	imul   r8,rdx,0x7fffffff
  40da23:	mov    rsi,rcx
  40da26:	sub    rsi,r8
  40da29:	mov    QWORD PTR [rip+0x145e0],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40da30:	mov    DWORD PTR [rbx+0x4],esi
  40da33:	mov    rcx,QWORD PTR [rip+0x145d6]        # 422010 <__swc_data_base_3464c816+0x10>
  40da3a:	imul   rcx,rcx,0x41a7
  40da41:	movabs rdx,0x200000005
  40da4b:	mov    rax,rcx
  40da4e:	mul    rdx
  40da51:	mov    r8,rdx
  40da54:	mov    rdx,rcx
  40da57:	sub    rdx,r8
  40da5a:	shr    rdx,1
  40da5d:	add    rdx,r8
  40da60:	shr    rdx,0x1e
  40da64:	imul   r8,rdx,0x7fffffff
  40da6b:	mov    rsi,rcx
  40da6e:	sub    rsi,r8
  40da71:	mov    QWORD PTR [rip+0x14598],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40da78:	sub    rsp,0x8
  40da7c:	call   40a380 <__swc_fn_3464c816_000177_1ca87929>
  40da81:	add    rsp,0x8
  40da85:	vmovups xmm6,xmm0
  40da89:	lea    rax,[rbx+0xc]
  40da8d:	vxorps xmm0,xmm0,xmm0
  40da91:	vmovups XMMWORD PTR [rbx+0xc],xmm0
  40da96:	vmovups XMMWORD PTR [rbx+0x1c],xmm0
  40da9b:	vmovups XMMWORD PTR [rbx+0x2c],xmm0
  40daa0:	vmovups XMMWORD PTR [rbx+0x3c],xmm0
  40daa5:	mov    DWORD PTR [rax],0x61707865
  40daab:	mov    DWORD PTR [rax+0x4],0x3320646e
  40dab2:	mov    DWORD PTR [rax+0x8],0x79622d32
  40dab9:	mov    DWORD PTR [rax+0xc],0x6b206574
  40dac0:	mov    DWORD PTR [rbx+0x1c],edi
  40dac3:	mov    DWORD PTR [rbx+0x20],r12d
  40dac7:	mov    DWORD PTR [rbx+0x24],r13d
  40dacb:	mov    DWORD PTR [rbx+0x28],r14d
  40dacf:	mov    DWORD PTR [rbx+0x2c],r15d
  40dad3:	mov    rax,QWORD PTR [rsp+0x58]
  40dad8:	mov    DWORD PTR [rbx+0x30],eax
  40dadb:	mov    rax,QWORD PTR [rsp+0x60]
  40dae0:	mov    DWORD PTR [rbx+0x34],eax
  40dae3:	mov    rax,QWORD PTR [rsp+0x68]
  40dae8:	mov    DWORD PTR [rbx+0x38],eax
  40daeb:	mov    eax,DWORD PTR [rbx]
  40daed:	mov    DWORD PTR [rbx+0x40],eax
  40daf0:	mov    eax,DWORD PTR [rbx+0x4]
  40daf3:	mov    DWORD PTR [rbx+0x44],eax
  40daf6:	mov    DWORD PTR [rbx+0x48],esi
  40daf9:	xor    eax,eax
  40dafb:	mov    ecx,0x1
  40db00:	vmovups xmm0,XMMWORD PTR [rip+0x5eb8]        # 4139c0 <__swc_rdata_base_3464c816+0x8b0>
  40db08:	mov    rsi,QWORD PTR [rsp+0x50]
  40db0d:	vmovups xmm1,XMMWORD PTR [rip+0x5ebb]        # 4139d0 <__swc_rdata_base_3464c816+0x8c0>
  40db15:	cmp    rax,0x400000
  40db1c:	jae    40dc9b <__swc_fn_3464c816_000175_7f24d040+0x61b>
  40db22:	cs nop WORD PTR [rax+rax*1+0x0]
  40db2c:	nop    DWORD PTR [rax+0x0]
  40db30:	mov    DWORD PTR [rbx+0x3c],ecx
  40db33:	vmovups xmm3,XMMWORD PTR [rbx+0xc]
  40db38:	vmovups xmm4,XMMWORD PTR [rbx+0x1c]
  40db3d:	vmovups xmm5,XMMWORD PTR [rbx+0x2c]
  40db42:	vmovups xmm2,XMMWORD PTR [rbx+0x3c]
  40db47:	xor    edx,edx
  40db49:	cs nop WORD PTR [rax+rax*1+0x0]
  40db53:	cs nop WORD PTR [rax+rax*1+0x0]
  40db5d:	nop    DWORD PTR [rax]
  40db60:	vpaddd xmm3,xmm3,xmm4
  40db64:	vpxor  xmm2,xmm2,xmm3
  40db68:	vpshufb xmm2,xmm2,xmm0
  40db6d:	vpaddd xmm5,xmm5,xmm2
  40db71:	vpxor  xmm4,xmm4,xmm5
  40db75:	vpslld xmm7,xmm4,0xc
  40db7a:	vpsrld xmm4,xmm4,0x14
  40db7f:	vpor   xmm4,xmm7,xmm4
  40db83:	vpaddd xmm3,xmm3,xmm4
  40db87:	vpshufd xmm7,xmm3,0x39
  40db8c:	vpshufd xmm2,xmm2,0x39
  40db91:	vpxor  xmm2,xmm2,xmm7
  40db95:	vpshufb xmm2,xmm2,xmm1
  40db9a:	vpshufd xmm5,xmm5,0x39
  40db9f:	vpaddd xmm5,xmm5,xmm2
  40dba3:	vpshufd xmm4,xmm4,0x39
  40dba8:	vpxor  xmm4,xmm4,xmm5
  40dbac:	vpslld xmm7,xmm4,0x7
  40dbb1:	vpsrld xmm4,xmm4,0x19
  40dbb6:	vpor   xmm4,xmm7,xmm4
  40dbba:	vpaddd xmm3,xmm3,xmm4
  40dbbe:	vpshufd xmm2,xmm2,0x4e
  40dbc3:	vpxor  xmm2,xmm2,xmm3
  40dbc7:	vpshufb xmm2,xmm2,xmm0
  40dbcc:	vpshufd xmm5,xmm5,0x39
  40dbd1:	vpaddd xmm5,xmm5,xmm2
  40dbd5:	vpxor  xmm4,xmm4,xmm5
  40dbd9:	vpslld xmm7,xmm4,0xc
  40dbde:	vpsrld xmm4,xmm4,0x14
  40dbe3:	vpor   xmm4,xmm7,xmm4
  40dbe7:	vpaddd xmm3,xmm3,xmm4
  40dbeb:	vpshufd xmm2,xmm2,0x93
  40dbf0:	vpshufd xmm7,xmm3,0x93
  40dbf5:	vpxor  xmm2,xmm2,xmm7
  40dbf9:	vpshufb xmm2,xmm2,xmm1
  40dbfe:	vpshufd xmm5,xmm5,0x93
  40dc03:	vpaddd xmm5,xmm5,xmm2
  40dc07:	vpshufd xmm4,xmm4,0x93
  40dc0c:	vpxor  xmm4,xmm4,xmm5
  40dc10:	vpslld xmm7,xmm4,0x7
  40dc15:	vpsrld xmm4,xmm4,0x19
  40dc1a:	vpor   xmm4,xmm7,xmm4
  40dc1e:	vpshufd xmm5,xmm5,0x93
  40dc23:	vpshufd xmm2,xmm2,0x4e
  40dc28:	add    rdx,0x1
  40dc2c:	cmp    rdx,0xa
  40dc30:	jb     40db60 <__swc_fn_3464c816_000175_7f24d040+0x4e0>
  40dc36:	lea    rdx,[rsi+rax*4]
  40dc3a:	vpaddd xmm3,xmm3,XMMWORD PTR [rsp+0xc]
  40dc40:	vpxor  xmm3,xmm3,XMMWORD PTR [rsi+rax*4]
  40dc45:	vpaddd xmm4,xmm4,XMMWORD PTR [rsp+0x1c]
  40dc4b:	vpxor  xmm4,xmm4,XMMWORD PTR [rsi+rax*4+0x10]
  40dc51:	vpaddd xmm5,xmm5,XMMWORD PTR [rsp+0x2c]
  40dc57:	vpxor  xmm5,xmm5,XMMWORD PTR [rsi+rax*4+0x20]
  40dc5d:	vpaddd xmm7,xmm2,XMMWORD PTR [rsp+0x3c]
  40dc63:	vpxor  xmm7,xmm7,XMMWORD PTR [rsi+rax*4+0x30]
  40dc69:	vmovdqu XMMWORD PTR [rdx],xmm3
  40dc6d:	vmovdqu XMMWORD PTR [rdx+0x10],xmm4
  40dc72:	vmovdqu XMMWORD PTR [rdx+0x20],xmm5
  40dc77:	vmovdqu XMMWORD PTR [rdx+0x30],xmm7
  40dc7c:	vpshufd xmm2,xmm2,0x3
  40dc81:	vmovd  edx,xmm2
  40dc85:	add    edx,DWORD PTR [rbx+0x48]
  40dc88:	lea    rax,[rax+0x10]
  40dc8c:	inc    ecx
  40dc8e:	cmp    rax,0x400000
  40dc95:	jb     40db30 <__swc_fn_3464c816_000175_7f24d040+0x4b0>
  40dc9b:	xor    edi,edi
  40dc9d:	xor    eax,eax
  40dc9f:	vxorps xmm0,xmm0,xmm0
  40dca3:	mov    ecx,0x1
  40dca8:	vpinsrd xmm0,xmm0,ecx,0x1
  40dcae:	mov    ecx,0x2
  40dcb3:	vpinsrd xmm0,xmm0,ecx,0x2
  40dcb9:	mov    ecx,0x3
  40dcbe:	vpinsrd xmm0,xmm0,ecx,0x3
  40dcc4:	vmovss xmm1,DWORD PTR [rip+0x5d14]        # 4139e0 <__swc_rdata_base_3464c816+0x8d0>
  40dccc:	vpshufd xmm1,xmm1,0x0
  40dcd1:	vpaddd xmm2,xmm0,xmm1
  40dcd5:	vmovss xmm1,DWORD PTR [rip+0x5d0c]        # 4139e9 <__swc_rdata_base_3464c816+0x8d9>
  40dcdd:	vpshufd xmm1,xmm1,0x0
  40dce2:	vxorps xmm3,xmm3,xmm3
  40dce6:	vxorps xmm4,xmm4,xmm4
  40dcea:	nop    WORD PTR [rax+rax*1+0x0]
  40dcf0:	vpaddd xmm5,xmm0,XMMWORD PTR [rsi+rax*4]
  40dcf5:	vpxor  xmm3,xmm3,xmm5
  40dcf9:	vpaddd xmm5,xmm2,XMMWORD PTR [rsi+rax*4+0x10]
  40dcff:	vpxor  xmm4,xmm4,xmm5
  40dd03:	vpaddd xmm2,xmm2,xmm1
  40dd07:	vpaddd xmm0,xmm0,xmm1
  40dd0b:	add    rax,0x8
  40dd0f:	cmp    rax,0x3ffff9
  40dd16:	jb     40dcf0 <__swc_fn_3464c816_000175_7f24d040+0x670>
  40dd18:	vpxor  xmm3,xmm3,xmm4
  40dd1c:	vpshufd xmm5,xmm3,0x4e
  40dd21:	vpxor  xmm3,xmm3,xmm5
  40dd25:	vpshufd xmm5,xmm3,0xb1
  40dd2a:	vpxor  xmm3,xmm3,xmm5
  40dd2e:	vmovd  eax,xmm3
  40dd32:	xor    rdi,rax
  40dd35:	sub    rsp,0x8
  40dd39:	call   40a380 <__swc_fn_3464c816_000177_1ca87929>
  40dd3e:	add    rsp,0x8
  40dd42:	vsubsd xmm0,xmm0,xmm6
  40dd46:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x5ca4]        # 4139f2 <__swc_rdata_base_3464c816+0x8e2>
  40dd4e:	lea    rax,[rip+0x5613]        # 413368 <__swc_rdata_base_3464c816+0x258>
  40dd55:	sub    rsp,0x90
  40dd5c:	mov    rcx,rsp
  40dd5f:	vmovups xmm1,XMMWORD PTR [rip+0x5c31]        # 413998 <__swc_rdata_base_3464c816+0x888>
  40dd67:	vmovups XMMWORD PTR [rcx],xmm1
  40dd6b:	mov    QWORD PTR [rcx+0x30],rsp
  40dd6f:	lea    rdx,[rip+0x559a]        # 413310 <__swc_rdata_base_3464c816+0x200>
  40dd76:	mov    QWORD PTR [rcx+0x38],rdx
  40dd7a:	mov    QWORD PTR [rcx+0x10],rdi
  40dd7e:	lea    r8,[rsp+0x10]
  40dd83:	mov    QWORD PTR [rcx+0x40],r8
  40dd87:	lea    r8,[rip+0x5b7a]        # 413908 <__swc_rdata_base_3464c816+0x7f8>
  40dd8e:	mov    QWORD PTR [rcx+0x48],r8
  40dd92:	vmovups xmm1,XMMWORD PTR [rip+0x5c0e]        # 4139a8 <__swc_rdata_base_3464c816+0x898>
  40dd9a:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40dd9f:	lea    r8,[rsp+0x18]
  40dda4:	mov    QWORD PTR [rcx+0x50],r8
  40dda8:	mov    QWORD PTR [rcx+0x58],rdx
  40ddac:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40ddb1:	lea    r8,[rcx+0x28]
  40ddb5:	mov    QWORD PTR [rcx+0x60],r8
  40ddb9:	lea    r8,[rip+0x5b90]        # 413950 <__swc_rdata_base_3464c816+0x840>
  40ddc0:	mov    QWORD PTR [rcx+0x68],r8
  40ddc4:	mov    QWORD PTR [rcx+0x70],rax
  40ddc8:	mov    QWORD PTR [rcx+0x78],rdx
  40ddcc:	lea    rax,[rcx+0x30]
  40ddd0:	mov    QWORD PTR [rcx+0x80],rax
  40ddd7:	mov    QWORD PTR [rcx+0x88],0x5
  40dde2:	lea    rcx,[rcx+0x80]
  40dde9:	sub    rsp,0x8
  40dded:	call   410980 <__swc_fn_3464c816_000146_4dba8c3c>
  40ddf2:	add    rsp,0x108
  40ddf9:	vmovups xmm6,XMMWORD PTR [rsp]
  40ddfe:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  40de04:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  40de0a:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  40de10:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  40de16:	add    rsp,0x50
  40de1a:	pop    r14
  40de1c:	pop    r15
  40de1e:	pop    r13
  40de20:	pop    r12
  40de22:	pop    rdi
  40de23:	pop    rsi
  40de24:	pop    rbx
  40de25:	pop    rbp
  40de26:	ret
