
/workspace/prompt2-20261115/session-combined-micro/base/fannkuch/fannkuch:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xb002]        # 412008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xaffa]        # 412010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xaff2]        # 412018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xafea]        # 412020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xafe2]        # 412028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xafda]        # 412030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xafd2]        # 412038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xafca]        # 412040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xafc2]        # 412048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xafba]        # 412050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xafb2]        # 412058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xafaa]        # 412060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xafa2]        # 412068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xaf9a]        # 412070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <clock_gettime@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xaf92]        # 412078 <clock_gettime@GLIBC_2.17>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <madvise@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xaf92]        # 412088 <madvise@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <pthread_key_delete@plt>:
  407100:	jmp    QWORD PTR [rip+0xaf8a]        # 412090 <pthread_key_delete@GLIBC_2.34>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <gettid@plt>:
  407110:	jmp    QWORD PTR [rip+0xaf82]        # 412098 <gettid@GLIBC_2.30>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <flock@plt>:
  407120:	jmp    QWORD PTR [rip+0xaf7a]        # 4120a0 <flock@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <__errno_location@plt>:
  407130:	jmp    QWORD PTR [rip+0xaf72]        # 4120a8 <__errno_location@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <opendir@plt>:
  407140:	jmp    QWORD PTR [rip+0xaf6a]        # 4120b0 <opendir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <dirfd@plt>:
  407150:	jmp    QWORD PTR [rip+0xaf62]        # 4120b8 <dirfd@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readdir@plt>:
  407160:	jmp    QWORD PTR [rip+0xaf5a]        # 4120c0 <readdir@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <readlinkat@plt>:
  407170:	jmp    QWORD PTR [rip+0xaf52]        # 4120c8 <readlinkat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <openat@plt>:
  407180:	jmp    QWORD PTR [rip+0xaf4a]        # 4120d0 <openat@GLIBC_2.4>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <closedir@plt>:
  407190:	jmp    QWORD PTR [rip+0xaf42]        # 4120d8 <closedir@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <memfd_create@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xaf3a]        # 4120e0 <memfd_create@GLIBC_2.27>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <ftruncate@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xaf32]        # 4120e8 <ftruncate@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <write@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xaf2a]        # 4120f0 <write@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <backtrace@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xaf22]        # 4120f8 <backtrace@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xaf1a]        # 412100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xaf12]        # 412108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xaddf]        # 412000 <__swc_fn_585f006d_000176_5d3d19bd+0x300>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40caa0 <__swc_fn_585f006d_000121_12b4ed22>
  40724e:	xor    ecx,ecx
  407250:	call   40c1c0 <__swc_fn_585f006d_000094_14db3cf9>
  407255:	call   40d720 <__swc_fn_585f006d_000178_8d3f617b>
  40725a:	call   40f2d0 <__swc_fn_585f006d_000095_337e587a>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_585f006d_000000_46f18a51>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_585f006d_000003_7ab4792e>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_585f006d_000003_7ab4792e+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409260 <__swc_fn_585f006d_000111_b25e3a45>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_585f006d_000003_7ab4792e+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1bd81]        # 423048 <__swc_bss_base_585f006d+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1bd7a]        # 423048 <__swc_bss_base_585f006d+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_585f006d_000003_7ab4792e+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_585f006d_000003_7ab4792e+0x30>
  4072e6:	lea    rcx,[rip+0x1bd63]        # 423050 <__swc_bss_base_585f006d+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1bd5c]        # 423050 <__swc_bss_base_585f006d+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_585f006d_000003_7ab4792e+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_585f006d_000003_7ab4792e+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_585f006d_000006_a23dca5f>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40db80 <__swc_fn_585f006d_000011_6493fbbc>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_585f006d_000012_c7df5d22>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_585f006d_000006_a23dca5f+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_585f006d_000003_7ab4792e>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_585f006d_000006_a23dca5f+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_585f006d_000009_d7e2bb25>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_585f006d_000009_d7e2bb25+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40a550 <__swc_fn_585f006d_000007_614a4804>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40db70 <__swc_fn_585f006d_000008_4e857afc>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_585f006d_000009_d7e2bb25+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_585f006d_000009_d7e2bb25+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_585f006d_000012_c7df5d22>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_585f006d_000015_07eb9884>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_585f006d_000015_07eb9884+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_585f006d_000015_07eb9884+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_585f006d_000015_07eb9884+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_585f006d_000015_07eb9884+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40dce0 <__swc_fn_585f006d_000017_4df2d1a0>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_585f006d_000015_07eb9884+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1bb3d]        # 423058 <__swc_bss_base_585f006d+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1bb36]        # 423058 <__swc_bss_base_585f006d+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_585f006d_000015_07eb9884+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_585f006d_000015_07eb9884+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40db80 <__swc_fn_585f006d_000011_6493fbbc>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_585f006d_000015_07eb9884+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40c7c0 <__swc_fn_585f006d_000112_759e9ceb>
  407569:	lea    rcx,[rip+0x1bad8]        # 423048 <__swc_bss_base_585f006d+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1bad1]        # 423048 <__swc_bss_base_585f006d+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_585f006d_000015_07eb9884+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_585f006d_000015_07eb9884+0x110>
  407598:	lea    rcx,[rip+0x1bac1]        # 423060 <__swc_bss_base_585f006d+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1baba]        # 423060 <__swc_bss_base_585f006d+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_585f006d_000015_07eb9884+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_585f006d_000015_07eb9884+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_585f006d_000018_7d1e8a10>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_585f006d_000015_07eb9884+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_585f006d_000018_7d1e8a10>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_585f006d_000018_7d1e8a10+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_585f006d_000018_7d1e8a10+0x10>

0000000000407630 <__swc_fn_585f006d_000021_491ac000>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_585f006d_000015_07eb9884>
  40763e:	lea    rdi,[rip+0x1bbab]        # 4231f0 <__swc_bss_base_585f006d+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098c0 <__swc_fn_585f006d_000135_e3032dc2>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1bb94]        # 4231f8 <__swc_bss_base_585f006d+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1bb89],rsi        # 4231f8 <__swc_bss_base_585f006d+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_585f006d_000024_4aca8b9e>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_585f006d_000027_4aca8b9e>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_585f006d_000030_06a93956>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_585f006d_000030_06a93956+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1992c]        # 421000 <__swc_data_base_585f006d>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_585f006d_000030_06a93956+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_585f006d_000030_06a93956+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_585f006d_000030_06a93956+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40dea0 <__swc_fn_585f006d_000032_84881cd8>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_585f006d_000030_06a93956+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_585f006d_000036_8d895ba1>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_585f006d_000030_06a93956+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_585f006d_000042_bab03645>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_585f006d_000033_7ca1566d>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40aa00 <__swc_fn_585f006d_000031_90860ff2>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409740 <__swc_fn_585f006d_000129_74b163fe>
  407734:	mov    rcx,rsi
  407737:	call   40dea0 <__swc_fn_585f006d_000032_84881cd8>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_585f006d_000036_8d895ba1>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_585f006d_000039_40d1e569>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_585f006d_000039_40d1e569+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_585f006d_000039_40d1e569+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_585f006d_000039_40d1e569+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_585f006d_000039_40d1e569+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_585f006d_000039_40d1e569+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409340 <__swc_fn_585f006d_000114_27d95464>
  4077ca:	lea    rcx,[rip+0x1b877]        # 423048 <__swc_bss_base_585f006d+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1b870]        # 423048 <__swc_bss_base_585f006d+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_585f006d_000039_40d1e569+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_585f006d_000039_40d1e569+0x90>
  4077f8:	lea    rcx,[rip+0x1b861]        # 423060 <__swc_bss_base_585f006d+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1b85a]        # 423060 <__swc_bss_base_585f006d+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_585f006d_000039_40d1e569+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_585f006d_000039_40d1e569+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_585f006d_000042_bab03645>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_585f006d_000042_bab03645+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e470 <__swc_fn_585f006d_000059_3ca3ac64>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098c0 <__swc_fn_585f006d_000135_e3032dc2>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_585f006d_000042_bab03645+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_585f006d_000042_bab03645+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_585f006d_000009_d7e2bb25>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_585f006d_000042_bab03645+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40dba0 <__swc_fn_585f006d_000014_afb279e2>
  40791e:	jmp    407941 <__swc_fn_585f006d_000042_bab03645+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_585f006d_000042_bab03645+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_585f006d_000042_bab03645+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_585f006d_000042_bab03645+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40abc0 <__swc_fn_585f006d_000043_957e4917>
  407997:	mov    rcx,rdi
  40799a:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_585f006d_000039_40d1e569>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_585f006d_000045_1fe0f4e2>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_585f006d_000045_1fe0f4e2+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_585f006d_000045_1fe0f4e2+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_585f006d_000045_1fe0f4e2+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_585f006d_000045_1fe0f4e2+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098c0 <__swc_fn_585f006d_000135_e3032dc2>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_585f006d_000045_1fe0f4e2+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_585f006d_000045_1fe0f4e2+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_585f006d_000045_1fe0f4e2+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_585f006d_000045_1fe0f4e2+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_585f006d_000009_d7e2bb25>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_585f006d_000045_1fe0f4e2+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_585f006d_000045_1fe0f4e2+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_585f006d_000045_1fe0f4e2+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_585f006d_000045_1fe0f4e2+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_585f006d_000045_1fe0f4e2+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40a600 <__swc_fn_585f006d_000013_9ba72deb>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_585f006d_000045_1fe0f4e2+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_585f006d_000045_1fe0f4e2+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_585f006d_000045_1fe0f4e2+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_585f006d_000045_1fe0f4e2+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40dd20 <__swc_fn_585f006d_000020_a66e8b97>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_585f006d_000045_1fe0f4e2+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40a600 <__swc_fn_585f006d_000013_9ba72deb>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_585f006d_000045_1fe0f4e2+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_585f006d_000021_491ac000>
  407c07:	mov    rcx,r14
  407c0a:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_585f006d_000045_1fe0f4e2+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_585f006d_000045_1fe0f4e2+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_585f006d_000045_1fe0f4e2+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_585f006d_000048_c877e9d2>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_585f006d_000048_c877e9d2+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_585f006d_000048_c877e9d2+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_585f006d_000048_c877e9d2+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_585f006d_000048_c877e9d2+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40e0d0 <__swc_fn_585f006d_000047_bc5ec610>
  407d14:	jmp    407ce0 <__swc_fn_585f006d_000048_c877e9d2+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_585f006d_000048_c877e9d2+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_585f006d_000048_c877e9d2+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_585f006d_000048_c877e9d2+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_585f006d_000048_c877e9d2+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_585f006d_000048_c877e9d2+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_585f006d_000048_c877e9d2+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_585f006d_000048_c877e9d2+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_585f006d_000051_f7021588>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_585f006d_000051_f7021588+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_585f006d_000051_f7021588+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_585f006d_000051_f7021588+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_585f006d_000051_f7021588+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40e030 <__swc_fn_585f006d_000044_9c2ade9b>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40dba0 <__swc_fn_585f006d_000014_afb279e2>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_585f006d_000054_ae20ea33>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098c0 <__swc_fn_585f006d_000135_e3032dc2>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_585f006d_000054_ae20ea33+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_585f006d_000054_ae20ea33+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_585f006d_000054_ae20ea33+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_585f006d_000057_5b81d8b6>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_585f006d_000060_e6407a0a>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_585f006d_000060_e6407a0a+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_585f006d_000039_40d1e569>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_585f006d_000060_e6407a0a+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_585f006d_000063_c8a062d6>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40af40 <__swc_fn_585f006d_000052_c7484fb0>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_585f006d_000054_ae20ea33>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_585f006d_000063_c8a062d6+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_585f006d_000063_c8a062d6+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40b060 <__swc_fn_585f006d_000058_8bd8d1d5>
  407f7f:	mov    rcx,rsi
  407f82:	call   40aca0 <__swc_fn_585f006d_000049_2ff013cc>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_585f006d_000066_254b71af>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_585f006d_000066_254b71af+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1b049]        # 423070 <__swc_bss_base_585f006d+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1b04b]        # 423080 <__swc_bss_base_585f006d+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_585f006d_000066_254b71af+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_585f006d_000066_254b71af+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40a930 <__swc_fn_585f006d_000022_3a2e2048>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_585f006d_000066_254b71af+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_585f006d_000063_c8a062d6>
  40808f:	jmp    408122 <__swc_fn_585f006d_000066_254b71af+0x192>
  408094:	lea    rax,[rip+0x18f65]        # 421000 <__swc_data_base_585f006d>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_585f006d_000066_254b71af+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_585f006d_000066_254b71af+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_585f006d_000066_254b71af+0x135>
  4080b8:	call   40aa00 <__swc_fn_585f006d_000031_90860ff2>
  4080bd:	mov    rcx,rax
  4080c0:	call   4100a0 <__swc_fn_585f006d_000128_41c3251c>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_585f006d_000066_254b71af+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_585f006d_000066_254b71af+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_585f006d_000066_254b71af+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40e0d0 <__swc_fn_585f006d_000047_bc5ec610>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_585f006d_000066_254b71af+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_585f006d_000051_f7021588>
  408115:	jmp    408122 <__swc_fn_585f006d_000066_254b71af+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40a570 <__swc_fn_585f006d_000010_395bb04b>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_585f006d_000069_e681a956>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_585f006d_000036_8d895ba1>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_585f006d_000069_e681a956+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1b09a]        # 423240 <__swc_bss_base_585f006d+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_585f006d_000069_e681a956+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098c0 <__swc_fn_585f006d_000135_e3032dc2>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40e8a0 <__swc_fn_585f006d_000068_7d4c42bf>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_585f006d_000072_bfa08900>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40e5f0 <__swc_fn_585f006d_000065_f9f4b610>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_585f006d_000075_524b0734>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40e8a0 <__swc_fn_585f006d_000068_7d4c42bf>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_585f006d_000078_a120bd2b>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_585f006d_000078_a120bd2b+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_585f006d_000078_a120bd2b+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_585f006d_000081_c25a0e73>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_585f006d_000084_ddf2b8a1>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_585f006d_000090_a2d50c23>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_585f006d_000084_ddf2b8a1+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_585f006d_000084_ddf2b8a1+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_585f006d_000084_ddf2b8a1+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_585f006d_000084_ddf2b8a1+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_585f006d_000090_a2d50c23>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_585f006d_000084_ddf2b8a1+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_585f006d_000084_ddf2b8a1+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_585f006d_000084_ddf2b8a1+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_585f006d_000084_ddf2b8a1+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_585f006d_000084_ddf2b8a1+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_585f006d_000084_ddf2b8a1+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_585f006d_000084_ddf2b8a1+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_585f006d_000084_ddf2b8a1+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_585f006d_000084_ddf2b8a1+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_585f006d_000084_ddf2b8a1+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40c040 <__swc_fn_585f006d_000082_754dcd57>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_585f006d_000084_ddf2b8a1+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_585f006d_000084_ddf2b8a1+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_585f006d_000084_ddf2b8a1+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40c040 <__swc_fn_585f006d_000082_754dcd57>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_585f006d_000084_ddf2b8a1+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_585f006d_000084_ddf2b8a1>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_585f006d_000084_ddf2b8a1+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_585f006d_000084_ddf2b8a1+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_585f006d_000087_ea575bb3>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_585f006d_000090_a2d50c23>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_585f006d_000087_ea575bb3+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40ed00 <__swc_fn_585f006d_000086_c45095aa>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_585f006d_000087_ea575bb3+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_585f006d_000087_ea575bb3+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_585f006d_000087_ea575bb3+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40c040 <__swc_fn_585f006d_000082_754dcd57>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_585f006d_000087_ea575bb3+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_585f006d_000087_ea575bb3>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_585f006d_000087_ea575bb3+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_585f006d_000087_ea575bb3+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_585f006d_000090_a2d50c23>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_585f006d_000090_a2d50c23+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_585f006d_000090_a2d50c23+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_585f006d_000090_a2d50c23+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_585f006d_000090_a2d50c23+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40c040 <__swc_fn_585f006d_000082_754dcd57>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40c040 <__swc_fn_585f006d_000082_754dcd57>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_585f006d_000090_a2d50c23+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_585f006d_000090_a2d50c23+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_585f006d_000090_a2d50c23+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_585f006d_000090_a2d50c23+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_585f006d_000090_a2d50c23>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_585f006d_000090_a2d50c23+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_585f006d_000090_a2d50c23+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_585f006d_000090_a2d50c23+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_585f006d_000090_a2d50c23+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_585f006d_000090_a2d50c23+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_585f006d_000090_a2d50c23+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_585f006d_000090_a2d50c23+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_585f006d_000090_a2d50c23+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_585f006d_000090_a2d50c23+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_585f006d_000090_a2d50c23+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_585f006d_000090_a2d50c23+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_585f006d_000090_a2d50c23+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_585f006d_000090_a2d50c23+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_585f006d_000090_a2d50c23+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_585f006d_000090_a2d50c23+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_585f006d_000090_a2d50c23+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409de0 <__swc_fn_585f006d_000147_32a497f3>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_585f006d_000090_a2d50c23+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_585f006d_000090_a2d50c23>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_585f006d_000090_a2d50c23+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_585f006d_000090_a2d50c23+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_585f006d_000090_a2d50c23+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409de0 <__swc_fn_585f006d_000147_32a497f3>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409de0 <__swc_fn_585f006d_000147_32a497f3>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_585f006d_000093_f8c16535>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c170 <__swc_fn_585f006d_000091_3d2f5a0d>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_585f006d_000093_f8c16535+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_585f006d_000093_f8c16535+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   410240 <__swc_fn_585f006d_000137_a4ba10ed>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_585f006d_000093_f8c16535+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0x9872]        # 4121c0 <__swc_rdata_base_585f006d+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   40fd60 <__swc_fn_585f006d_000116_035d76a1>
  408959:	call   40c9f0 <__swc_fn_585f006d_000118_7f430081>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_585f006d_000096_ad982b35>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40896f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408975:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40897b:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  408981:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  408987:	mov    QWORD PTR [rsp+0x48],rdx
  40898c:	mov    rax,r8
  40898f:	cmp    r8,0x1
  408993:	mov    edx,0x1
  408998:	cmovb  rax,rdx
  40899c:	mov    QWORD PTR [rsp+0x50],rax
  4089a1:	mov    rbx,QWORD PTR [rcx+0x8]
  4089a5:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a9:	mov    rcx,QWORD PTR [rcx]
  4089ac:	lea    rdx,[rsp+0x8]
  4089b1:	call   rbx
  4089b3:	add    rsp,0x70
  4089b7:	pop    rbx
  4089b8:	ret
  4089b9:	add    BYTE PTR [rax],al
  4089bb:	add    BYTE PTR [rax],al
  4089bd:	add    BYTE PTR [rax],al
	...

00000000004089c0 <__swc_fn_585f006d_000099_b4c6da83>:
  4089c0:	push   rbx
  4089c1:	push   rsi
  4089c2:	push   rdi
  4089c3:	sub    rsp,0x30
  4089c7:	mov    rbx,rcx
  4089ca:	test   rcx,rcx
  4089cd:	je     4089e2 <__swc_fn_585f006d_000099_b4c6da83+0x22>
  4089cf:	mov    rcx,rbx
  4089d2:	mov    edx,0x1
  4089d7:	call   408200 <__swc_fn_585f006d_000078_a120bd2b>
  4089dc:	cmp    rax,0x1
  4089e0:	je     4089ea <__swc_fn_585f006d_000099_b4c6da83+0x2a>
  4089e2:	add    rsp,0x30
  4089e6:	pop    rdi
  4089e7:	pop    rsi
  4089e8:	pop    rbx
  4089e9:	ret
  4089ea:	lea    rsi,[rsp+0x8]
  4089ef:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089f4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089fa:	lea    rax,[rsp+0x18]
  4089ff:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  408a04:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408a0a:	mov    rcx,QWORD PTR [rsp+0x20]
  408a0f:	test   rcx,rcx
  408a12:	je     408a28 <__swc_fn_585f006d_000099_b4c6da83+0x68>
  408a14:	test   DWORD PTR [rcx+0x28],0x400000
  408a1b:	je     408a28 <__swc_fn_585f006d_000099_b4c6da83+0x68>
  408a1d:	mov    rdx,QWORD PTR [rcx+0x30]
  408a21:	test   rdx,rdx
  408a24:	cmovne rcx,rdx
  408a28:	mov    edi,DWORD PTR [rcx+0x20]
  408a2b:	mov    rcx,rax
  408a2e:	call   40c350 <__swc_fn_585f006d_000100_3ed08774>
  408a33:	mov    rcx,rsi
  408a36:	mov    rdx,QWORD PTR [rsp+0x18]
  408a3b:	mov    r8,rdi
  408a3e:	call   408960 <__swc_fn_585f006d_000096_ad982b35>
  408a43:	mov    rcx,QWORD PTR [rbx+0x28]
  408a47:	call   40f2e0 <__swc_fn_585f006d_000098_00f01091>
  408a4c:	mov    rcx,rsi
  408a4f:	mov    rdx,rbx
  408a52:	mov    r8d,0x30
  408a58:	call   408960 <__swc_fn_585f006d_000096_ad982b35>
  408a5d:	add    rsp,0x30
  408a61:	pop    rdi
  408a62:	pop    rsi
  408a63:	pop    rbx
  408a64:	ret
	...

0000000000408a80 <__swc_fn_585f006d_000102_e9fdc18e>:
  408a80:	push   rbp
  408a81:	push   rbx
  408a82:	push   rsi
  408a83:	push   rdi
  408a84:	push   r12
  408a86:	push   r13
  408a88:	push   r14
  408a8a:	push   r15
  408a8c:	sub    rsp,0x500
  408a93:	mov    rbp,rsp
  408a96:	mov    rbx,rsp
  408a99:	mov    rsi,rdx
  408a9c:	mov    rdi,rcx
  408a9f:	mov    rcx,QWORD PTR [rip+0x1d29a]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  408aa6:	test   rcx,rcx
  408aa9:	jne    408ac3 <__swc_fn_585f006d_000102_e9fdc18e+0x43>
  408aab:	sub    rsp,0x8
  408aaf:	call   40a1d0 <__swc_fn_585f006d_000165_cf398896>
  408ab4:	add    rsp,0x8
  408ab8:	lea    rcx,[rax+0x1]
  408abc:	mov    QWORD PTR [rip+0x1d27d],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  408ac3:	dec    rcx
  408ac6:	sub    rsp,0x8
  408aca:	call   411b60 <__swc_fn_585f006d_000167_fce60b2b>
  408acf:	add    rsp,0x8
  408ad3:	mov    r12,rax
  408ad6:	mov    QWORD PTR [rsp+0x4f0],rax
  408ade:	lea    rax,[rip+0x981b]        # 412300 <__swc_rdata_base_585f006d+0x1f0>
  408ae5:	sub    rsp,0x20
  408ae9:	mov    rcx,rsp
  408aec:	mov    QWORD PTR [rcx],rax
  408aef:	lea    r13,[rip+0x981a]        # 412310 <__swc_rdata_base_585f006d+0x200>
  408af6:	mov    QWORD PTR [rcx+0x8],r13
  408afa:	mov    QWORD PTR [rcx+0x10],rsp
  408afe:	mov    QWORD PTR [rcx+0x18],0x1
  408b06:	lea    rcx,[rsp+0x10]
  408b0b:	sub    rsp,0x8
  408b0f:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  408b14:	add    rsp,0x8
  408b18:	add    rsp,0x20
  408b1c:	lea    rax,[rip+0x9835]        # 412358 <__swc_rdata_base_585f006d+0x248>
  408b23:	sub    rsp,0x20
  408b27:	mov    rcx,rsp
  408b2a:	mov    QWORD PTR [rcx],rax
  408b2d:	mov    QWORD PTR [rcx+0x8],r13
  408b31:	mov    QWORD PTR [rcx+0x10],rsp
  408b35:	mov    QWORD PTR [rcx+0x18],0x1
  408b3d:	lea    rcx,[rsp+0x10]
  408b42:	sub    rsp,0x8
  408b46:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  408b4b:	add    rsp,0x8
  408b4f:	add    rsp,0x20
  408b53:	lea    r14,[rip+0x980e]        # 412368 <__swc_rdata_base_585f006d+0x258>
  408b5a:	sub    rsp,0x50
  408b5e:	mov    rax,rsp
  408b61:	vmovups xmm0,XMMWORD PTR [rip+0x9937]        # 4124a0 <__swc_rdata_base_585f006d+0x390>
  408b69:	vmovups XMMWORD PTR [rax],xmm0
  408b6d:	mov    QWORD PTR [rax+0x10],rsp
  408b71:	mov    QWORD PTR [rax+0x18],r13
  408b75:	mov    QWORD PTR [rax+0x20],rdi
  408b79:	lea    rdi,[rip+0x97f8]        # 412378 <__swc_rdata_base_585f006d+0x268>
  408b80:	mov    QWORD PTR [rax+0x28],rdi
  408b84:	mov    QWORD PTR [rax+0x30],r14
  408b88:	mov    QWORD PTR [rax+0x38],r13
  408b8c:	lea    rcx,[rsp+0x10]
  408b91:	mov    QWORD PTR [rax+0x40],rcx
  408b95:	mov    QWORD PTR [rax+0x48],0x3
  408b9d:	lea    rcx,[rsp+0x40]
  408ba2:	sub    rsp,0x8
  408ba6:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  408bab:	add    rsp,0x8
  408baf:	add    rsp,0x50
  408bb3:	lea    rax,[rip+0x9806]        # 4123c0 <__swc_rdata_base_585f006d+0x2b0>
  408bba:	sub    rsp,0x20
  408bbe:	mov    rcx,rsp
  408bc1:	mov    QWORD PTR [rcx],rax
  408bc4:	mov    QWORD PTR [rcx+0x8],r13
  408bc8:	mov    QWORD PTR [rcx+0x10],rsp
  408bcc:	mov    QWORD PTR [rcx+0x18],0x1
  408bd4:	lea    rcx,[rsp+0x10]
  408bd9:	sub    rsp,0x8
  408bdd:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  408be2:	add    rsp,0x8
  408be6:	add    rsp,0x20
  408bea:	mov    eax,DWORD PTR [rsi+0x20]
  408bed:	mov    ecx,DWORD PTR [rsi+0x24]
  408bf0:	sub    rsp,0xa0
  408bf7:	mov    rdx,rsp
  408bfa:	mov    QWORD PTR [rdx+0x30],rsi
  408bfe:	mov    QWORD PTR [rdx+0x38],rdi
  408c02:	vmovups xmm0,XMMWORD PTR [rip+0x982e]        # 412438 <__swc_rdata_base_585f006d+0x328>
  408c0a:	vmovups XMMWORD PTR [rdx],xmm0
  408c0e:	mov    QWORD PTR [rdx+0x40],rsp
  408c12:	mov    QWORD PTR [rdx+0x48],r13
  408c16:	mov    DWORD PTR [rdx+0x10],eax
  408c19:	lea    rax,[rsp+0x10]
  408c1e:	mov    QWORD PTR [rdx+0x50],rax
  408c22:	lea    rax,[rip+0x97a7]        # 4123d0 <__swc_rdata_base_585f006d+0x2c0>
  408c29:	mov    QWORD PTR [rdx+0x58],rax
  408c2d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c32:	lea    r8,[rsp+0x18]
  408c37:	mov    QWORD PTR [rdx+0x60],r8
  408c3b:	mov    QWORD PTR [rdx+0x68],r13
  408c3f:	mov    DWORD PTR [rdx+0x28],ecx
  408c42:	lea    rcx,[rdx+0x28]
  408c46:	mov    QWORD PTR [rdx+0x70],rcx
  408c4a:	mov    QWORD PTR [rdx+0x78],rax
  408c4e:	mov    QWORD PTR [rdx+0x80],r14
  408c55:	mov    QWORD PTR [rdx+0x88],r13
  408c5c:	lea    rax,[rdx+0x30]
  408c60:	mov    QWORD PTR [rdx+0x90],rax
  408c67:	mov    QWORD PTR [rdx+0x98],0x6
  408c72:	lea    rcx,[rdx+0x90]
  408c79:	sub    rsp,0x8
  408c7d:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  408c82:	add    rsp,0x8
  408c86:	add    rsp,0xa0
  408c8d:	sub    rsp,0x20
  408c91:	mov    rax,rsp
  408c94:	mov    QWORD PTR [rax],r14
  408c97:	mov    QWORD PTR [rax+0x8],r13
  408c9b:	mov    QWORD PTR [rax+0x10],rsp
  408c9f:	mov    QWORD PTR [rax+0x18],0x1
  408ca7:	lea    rcx,[rsp+0x10]
  408cac:	sub    rsp,0x8
  408cb0:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  408cb5:	add    rsp,0x8
  408cb9:	add    rsp,0x20
  408cbd:	mov    eax,DWORD PTR [r12+0x9ac]
  408cc5:	test   eax,eax
  408cc7:	je     408f00 <__swc_fn_585f006d_000102_e9fdc18e+0x480>
  408ccd:	lea    rax,[rip+0x9744]        # 412418 <__swc_rdata_base_585f006d+0x308>
  408cd4:	sub    rsp,0x20
  408cd8:	mov    rcx,rsp
  408cdb:	mov    QWORD PTR [rcx],rax
  408cde:	mov    QWORD PTR [rcx+0x8],r13
  408ce2:	mov    QWORD PTR [rcx+0x10],rsp
  408ce6:	mov    QWORD PTR [rcx+0x18],0x1
  408cee:	lea    rcx,[rsp+0x10]
  408cf3:	sub    rsp,0x8
  408cf7:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  408cfc:	add    rsp,0x8
  408d00:	add    rsp,0x20
  408d04:	mov    eax,DWORD PTR [r12+0x9ac]
  408d0c:	dec    eax
  408d0e:	mov    esi,eax
  408d10:	test   esi,esi
  408d12:	jl     408ed0 <__swc_fn_585f006d_000102_e9fdc18e+0x450>
  408d18:	jmp    408d24 <__swc_fn_585f006d_000102_e9fdc18e+0x2a4>
  408d1a:	nop    WORD PTR [rax+rax*1+0x0]
  408d20:	dec    esi
  408d22:	jmp    408d10 <__swc_fn_585f006d_000102_e9fdc18e+0x290>
  408d24:	lea    rax,[rip+0x96fd]        # 412428 <__swc_rdata_base_585f006d+0x318>
  408d2b:	sub    rsp,0x20
  408d2f:	mov    rcx,rsp
  408d32:	mov    QWORD PTR [rcx],rax
  408d35:	mov    QWORD PTR [rcx+0x8],r13
  408d39:	mov    QWORD PTR [rcx+0x10],rsp
  408d3d:	mov    QWORD PTR [rcx+0x18],0x1
  408d45:	lea    rcx,[rsp+0x10]
  408d4a:	sub    rsp,0x8
  408d4e:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  408d53:	add    rsp,0x8
  408d57:	add    rsp,0x20
  408d5b:	movsxd rax,esi
  408d5e:	imul   r15,rax,0x30
  408d62:	add    r15,r12
  408d65:	add    r15,0xf8
  408d6c:	sub    rsp,0x20
  408d70:	mov    rax,rsp
  408d73:	mov    QWORD PTR [rax],r15
  408d76:	mov    QWORD PTR [rax+0x8],rdi
  408d7a:	mov    QWORD PTR [rax+0x10],rsp
  408d7e:	mov    QWORD PTR [rax+0x18],0x1
  408d86:	lea    rcx,[rsp+0x10]
  408d8b:	sub    rsp,0x8
  408d8f:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  408d94:	add    rsp,0x8
  408d98:	add    rsp,0x20
  408d9c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408da4:	lea    rsi,[rip+0x968d]        # 412438 <__swc_rdata_base_585f006d+0x328>
  408dab:	sub    rsp,0x20
  408daf:	mov    rax,rsp
  408db2:	mov    QWORD PTR [rax],rsi
  408db5:	mov    QWORD PTR [rax+0x8],r13
  408db9:	mov    QWORD PTR [rax+0x10],rsp
  408dbd:	mov    QWORD PTR [rax+0x18],0x1
  408dc5:	lea    rcx,[rsp+0x10]
  408dca:	sub    rsp,0x8
  408dce:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  408dd3:	add    rsp,0x8
  408dd7:	add    rsp,0x20
  408ddb:	sub    rsp,0x30
  408ddf:	mov    rax,rsp
  408de2:	mov    ecx,DWORD PTR [r15+0x20]
  408de6:	mov    QWORD PTR [rax],rcx
  408de9:	mov    QWORD PTR [rax+0x8],rsp
  408ded:	lea    rdi,[rip+0x9654]        # 412448 <__swc_rdata_base_585f006d+0x338>
  408df4:	mov    QWORD PTR [rax+0x10],rdi
  408df8:	lea    rcx,[rsp+0x8]
  408dfd:	mov    QWORD PTR [rax+0x18],rcx
  408e01:	mov    QWORD PTR [rax+0x20],0x1
  408e09:	lea    rcx,[rsp+0x18]
  408e0e:	sub    rsp,0x8
  408e12:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  408e17:	add    rsp,0x8
  408e1b:	add    rsp,0x30
  408e1f:	sub    rsp,0x20
  408e23:	mov    rax,rsp
  408e26:	mov    QWORD PTR [rax],rsi
  408e29:	mov    QWORD PTR [rax+0x8],r13
  408e2d:	mov    QWORD PTR [rax+0x10],rsp
  408e31:	mov    QWORD PTR [rax+0x18],0x1
  408e39:	lea    rcx,[rsp+0x10]
  408e3e:	sub    rsp,0x8
  408e42:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  408e47:	add    rsp,0x8
  408e4b:	add    rsp,0x20
  408e4f:	sub    rsp,0x30
  408e53:	mov    rax,rsp
  408e56:	mov    ecx,DWORD PTR [r15+0x24]
  408e5a:	mov    QWORD PTR [rax],rcx
  408e5d:	mov    QWORD PTR [rax+0x8],rsp
  408e61:	mov    QWORD PTR [rax+0x10],rdi
  408e65:	lea    rcx,[rsp+0x8]
  408e6a:	mov    QWORD PTR [rax+0x18],rcx
  408e6e:	mov    QWORD PTR [rax+0x20],0x1
  408e76:	lea    rcx,[rsp+0x18]
  408e7b:	sub    rsp,0x8
  408e7f:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  408e84:	add    rsp,0x8
  408e88:	add    rsp,0x30
  408e8c:	sub    rsp,0x20
  408e90:	mov    rax,rsp
  408e93:	mov    QWORD PTR [rax],r14
  408e96:	mov    QWORD PTR [rax+0x8],r13
  408e9a:	mov    QWORD PTR [rax+0x10],rsp
  408e9e:	mov    QWORD PTR [rax+0x18],0x1
  408ea6:	lea    rcx,[rsp+0x10]
  408eab:	sub    rsp,0x8
  408eaf:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  408eb4:	add    rsp,0x8
  408eb8:	add    rsp,0x20
  408ebc:	lea    rdi,[rip+0x94b5]        # 412378 <__swc_rdata_base_585f006d+0x268>
  408ec3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408ecb:	jmp    408d20 <__swc_fn_585f006d_000102_e9fdc18e+0x2a0>
  408ed0:	sub    rsp,0x20
  408ed4:	mov    rax,rsp
  408ed7:	mov    QWORD PTR [rax],r14
  408eda:	mov    QWORD PTR [rax+0x8],r13
  408ede:	mov    QWORD PTR [rax+0x10],rsp
  408ee2:	mov    QWORD PTR [rax+0x18],0x1
  408eea:	lea    rcx,[rsp+0x10]
  408eef:	sub    rsp,0x8
  408ef3:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  408ef8:	add    rsp,0x8
  408efc:	add    rsp,0x20
  408f00:	lea    rax,[rbx+0x28]
  408f04:	mov    rcx,rax
  408f07:	mov    QWORD PTR [rbx+0x28],0x0
  408f0f:	mov    QWORD PTR [rbx+0x30],0x0
  408f17:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408f1c:	add    rcx,0x10
  408f20:	mov    edx,0x1f
  408f25:	cs nop WORD PTR [rax+rax*1+0x0]
  408f2f:	nop
  408f30:	vmovups XMMWORD PTR [rcx],xmm0
  408f34:	add    rcx,0x10
  408f38:	sub    rdx,0x1
  408f3c:	jne    408f30 <__swc_fn_585f006d_000102_e9fdc18e+0x4b0>
  408f3e:	lea    rsi,[rbx+0x228]
  408f45:	xor    ecx,ecx
  408f47:	cs nop WORD PTR [rax+rax*1+0x0]
  408f51:	cs nop WORD PTR [rax+rax*1+0x0]
  408f5b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f60:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f65:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f6a:	add    rcx,0x10
  408f6e:	cmp    rcx,0x200
  408f75:	jne    408f60 <__swc_fn_585f006d_000102_e9fdc18e+0x4e0>
  408f77:	mov    eax,DWORD PTR [r12+0xbc8]
  408f7f:	lea    rcx,[r12+0x9c8]
  408f87:	mov    QWORD PTR [rbx+0x428],rcx
  408f8e:	mov    QWORD PTR [rbx+0x430],rax
  408f95:	lea    rdi,[rbx+0x438]
  408f9c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408fa4:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fac:	mov    eax,DWORD PTR [r12+0xbc8]
  408fb4:	test   eax,eax
  408fb6:	jne    409003 <__swc_fn_585f006d_000102_e9fdc18e+0x583>
  408fb8:	lea    rax,[rbx+0x448]
  408fbf:	mov    QWORD PTR [rbx+0x448],rsi
  408fc6:	mov    QWORD PTR [rax+0x8],0x40
  408fce:	mov    ecx,0x1
  408fd3:	mov    rdx,rax
  408fd6:	sub    rsp,0x8
  408fda:	call   40fe80 <__swc_fn_585f006d_000119_9175a56a>
  408fdf:	add    rsp,0x8
  408fe3:	mov    QWORD PTR [rbx+0x460],rsi
  408fea:	mov    ecx,eax
  408fec:	mov    QWORD PTR [rbx+0x468],rcx
  408ff3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408ffb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  409003:	mov    rsi,QWORD PTR [rbx+0x438]
  40900a:	mov    rax,QWORD PTR [rbx+0x440]
  409011:	mov    r15,rax
  409014:	xor    r12d,r12d
  409017:	test   r15,r15
  40901a:	je     4090d0 <__swc_fn_585f006d_000102_e9fdc18e+0x650>
  409020:	mov    rax,QWORD PTR [rsi+r12*8]
  409024:	test   rax,rax
  409027:	je     409046 <__swc_fn_585f006d_000102_e9fdc18e+0x5c6>
  409029:	lea    rcx,[rbx+0x4b8]
  409030:	mov    rdx,rax
  409033:	sub    rsp,0x8
  409037:	call   409f40 <__swc_fn_585f006d_000162_60216e69>
  40903c:	add    rsp,0x8
  409040:	mov    al,BYTE PTR [rax]
  409042:	test   al,al
  409044:	jne    409052 <__swc_fn_585f006d_000102_e9fdc18e+0x5d2>
  409046:	add    r12,0x1
  40904a:	sub    r15,0x1
  40904e:	jne    409020 <__swc_fn_585f006d_000102_e9fdc18e+0x5a0>
  409050:	jmp    4090d0 <__swc_fn_585f006d_000102_e9fdc18e+0x650>
  409052:	lea    rax,[rip+0x9437]        # 412490 <__swc_rdata_base_585f006d+0x380>
  409059:	sub    rsp,0x20
  40905d:	mov    rcx,rsp
  409060:	mov    QWORD PTR [rcx],rax
  409063:	mov    QWORD PTR [rcx+0x8],r13
  409067:	mov    QWORD PTR [rcx+0x10],rsp
  40906b:	mov    QWORD PTR [rcx+0x18],0x1
  409073:	lea    rcx,[rsp+0x10]
  409078:	sub    rsp,0x8
  40907c:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  409081:	add    rsp,0x8
  409085:	add    rsp,0x20
  409089:	mov    rcx,rdi
  40908c:	xor    edx,edx
  40908e:	mov    al,0x1
  409090:	mov    r8,rax
  409093:	sub    rsp,0x8
  409097:	call   40d2a0 <__swc_fn_585f006d_000163_8e41797b>
  40909c:	add    rsp,0x8
  4090a0:	sub    rsp,0x20
  4090a4:	mov    rax,rsp
  4090a7:	mov    QWORD PTR [rax],r14
  4090aa:	mov    QWORD PTR [rax+0x8],r13
  4090ae:	mov    QWORD PTR [rax+0x10],rsp
  4090b2:	mov    QWORD PTR [rax+0x18],0x1
  4090ba:	lea    rcx,[rsp+0x10]
  4090bf:	sub    rsp,0x8
  4090c3:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  4090c8:	add    rsp,0x8
  4090cc:	add    rsp,0x20
  4090d0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090d8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090e4:	add    rsp,0x500
  4090eb:	pop    r15
  4090ed:	pop    r14
  4090ef:	pop    r13
  4090f1:	pop    r12
  4090f3:	pop    rdi
  4090f4:	pop    rsi
  4090f5:	pop    rbx
  4090f6:	pop    rbp
  4090f7:	ret
	...

0000000000409100 <__swc_fn_585f006d_000105_6fd80914>:
  409100:	sub    rsp,0x8
  409104:	test   r8,r8
  409107:	je     40910e <__swc_fn_585f006d_000105_6fd80914+0xe>
  409109:	call   40f570 <__swc_fn_585f006d_000104_5589fdbd>
  40910e:	add    rsp,0x8
  409112:	ret
	...

0000000000409120 <__swc_fn_585f006d_000108_84af7666>:
  409120:	push   rsi
  409121:	push   rdi
  409122:	push   r12
  409124:	push   r13
  409126:	sub    rsp,0xd8
  40912d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409133:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409139:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40913f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409145:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40914b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409154:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40915d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409166:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40916f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409178:	xor    eax,eax
  40917a:	call   407010 <getpid@plt>
  40917f:	mov    rsi,rax
  409182:	lea    rdi,[rip+0x1cbbf]        # 425d48 <__swc_bss_base_585f006d+0x2d08>
  409189:	mov    r12,QWORD PTR [rdi]
  40918c:	test   r12,r12
  40918f:	je     40919d <__swc_fn_585f006d_000108_84af7666+0x7d>
  409191:	cmp    DWORD PTR [r12+0x10],esi
  409196:	jne    40919d <__swc_fn_585f006d_000108_84af7666+0x7d>
  409198:	mov    rax,r12
  40919b:	jmp    409200 <__swc_fn_585f006d_000108_84af7666+0xe0>
  40919d:	mov    ecx,0x4
  4091a2:	mov    edx,0x18
  4091a7:	call   40f660 <__swc_fn_585f006d_000107_4796e893>
  4091ac:	mov    rcx,rax
  4091af:	test   rax,rax
  4091b2:	jne    4091b8 <__swc_fn_585f006d_000108_84af7666+0x98>
  4091b4:	xor    eax,eax
  4091b6:	jmp    409200 <__swc_fn_585f006d_000108_84af7666+0xe0>
  4091b8:	mov    DWORD PTR [rcx+0x10],esi
  4091bb:	mov    rax,r12
  4091be:	lock cmpxchg QWORD PTR [rdi],rcx
  4091c3:	mov    r13,rax
  4091c6:	cmp    rax,r12
  4091c9:	je     4091df <__swc_fn_585f006d_000108_84af7666+0xbf>
  4091cb:	mov    rdi,rcx
  4091ce:	mov    esi,0x18
  4091d3:	xor    eax,eax
  4091d5:	call   407020 <munmap@plt>
  4091da:	mov    rax,r13
  4091dd:	jmp    409200 <__swc_fn_585f006d_000108_84af7666+0xe0>
  4091df:	test   r12,r12
  4091e2:	je     4091fd <__swc_fn_585f006d_000108_84af7666+0xdd>
  4091e4:	mov    rdi,r12
  4091e7:	mov    esi,0x18
  4091ec:	xor    eax,eax
  4091ee:	mov    QWORD PTR [rsp+0x28],rcx
  4091f3:	call   407020 <munmap@plt>
  4091f8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091fd:	mov    rax,rcx
  409200:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  409206:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40920c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  409212:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  409218:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40921e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409227:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409230:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409239:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409242:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40924b:	add    rsp,0xd8
  409252:	pop    r13
  409254:	pop    r12
  409256:	pop    rdi
  409257:	pop    rsi
  409258:	ret
  409259:	add    BYTE PTR [rax],al
  40925b:	add    BYTE PTR [rax],al
  40925d:	add    BYTE PTR [rax],al
	...

0000000000409260 <__swc_fn_585f006d_000111_b25e3a45>:
  409260:	push   rbx
  409261:	push   r12
  409263:	push   rdi
  409264:	push   rsi
  409265:	sub    rsp,0xa8
  40926c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409272:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409278:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40927e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409284:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40928a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409290:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409296:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40929c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4092a5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4092ae:	mov    rbx,rdx
  4092b1:	mov    r12,rcx
  4092b4:	mov    rdi,rcx
  4092b7:	mov    rsi,rdx
  4092ba:	mov    edx,0x3
  4092bf:	xor    eax,eax
  4092c1:	call   407030 <mprotect@plt>
  4092c6:	test   eax,eax
  4092c8:	je     4092ce <__swc_fn_585f006d_000111_b25e3a45+0x6e>
  4092ca:	xor    eax,eax
  4092cc:	jmp    4092e3 <__swc_fn_585f006d_000111_b25e3a45+0x83>
  4092ce:	mov    rcx,r12
  4092d1:	mov    rdx,rbx
  4092d4:	mov    al,0x1
  4092d6:	mov    r8,rax
  4092d9:	call   40fcb0 <__swc_fn_585f006d_000110_a808fe76>
  4092de:	mov    eax,0x1
  4092e3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092e9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092ef:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092f5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092fb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409301:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409307:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40930d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409313:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40931c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409325:	add    rsp,0xa8
  40932c:	pop    rsi
  40932d:	pop    rdi
  40932e:	pop    r12
  409330:	pop    rbx
  409331:	ret
	...

0000000000409340 <__swc_fn_585f006d_000114_27d95464>:
  409340:	sub    rsp,0x8
  409344:	test   rcx,rcx
  409347:	jne    40934e <__swc_fn_585f006d_000114_27d95464+0xe>
  409349:	add    rsp,0x8
  40934d:	ret
  40934e:	call   40c8a0 <__swc_fn_585f006d_000115_1ba33335>
  409353:	add    rsp,0x8
  409357:	ret
	...

0000000000409360 <__swc_fn_585f006d_000117_86a7fb9e>:
  409360:	push   rdi
  409361:	push   rsi
  409362:	sub    rsp,0xa8
  409369:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40936f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409375:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40937b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409381:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409387:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40938d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409393:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409399:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4093a2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4093ab:	xor    edi,edi
  4093ad:	xor    eax,eax
  4093af:	call   407040 <exit@plt>
  4093b4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4093ba:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093c0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093c6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093cc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093d2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093d8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093de:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093e4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093ed:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093f6:	add    rsp,0xa8
  4093fd:	pop    rsi
  4093fe:	pop    rdi
  4093ff:	ret

0000000000409400 <__swc_fn_585f006d_000120_ea68f292>:
  409400:	push   rbx
  409401:	push   rsi
  409402:	push   rdi
  409403:	push   r12
  409405:	sub    rsp,0x18
  409409:	mov    rbx,r8
  40940c:	mov    rsi,rcx
  40940f:	mov    rdi,rdx
  409412:	mov    rcx,QWORD PTR [rip+0x1c927]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  409419:	test   rcx,rcx
  40941c:	jne    40942e <__swc_fn_585f006d_000120_ea68f292+0x2e>
  40941e:	call   40a1d0 <__swc_fn_585f006d_000165_cf398896>
  409423:	lea    rcx,[rax+0x1]
  409427:	mov    QWORD PTR [rip+0x1c912],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40942e:	dec    rcx
  409431:	call   411b60 <__swc_fn_585f006d_000167_fce60b2b>
  409436:	mov    r12,rax
  409439:	cmp    ebx,0x3
  40943c:	jne    40944f <__swc_fn_585f006d_000120_ea68f292+0x4f>
  40943e:	mov    rax,QWORD PTR [r12+0xbd0]
  409446:	test   rax,rax
  409449:	jne    40958f <__swc_fn_585f006d_000120_ea68f292+0x18f>
  40944f:	cmp    ebx,0x5
  409452:	jne    409476 <__swc_fn_585f006d_000120_ea68f292+0x76>
  409454:	call   40c170 <__swc_fn_585f006d_000091_3d2f5a0d>
  409459:	test   al,al
  40945b:	jne    409476 <__swc_fn_585f006d_000120_ea68f292+0x76>
  40945d:	mov    rcx,rsi
  409460:	mov    rdx,rdi
  409463:	call   411b10 <__swc_fn_585f006d_000164_1962e12a>
  409468:	test   al,al
  40946a:	je     409476 <__swc_fn_585f006d_000120_ea68f292+0x76>
  40946c:	add    rsp,0x18
  409470:	pop    r12
  409472:	pop    rdi
  409473:	pop    rsi
  409474:	pop    rbx
  409475:	ret
  409476:	call   40c170 <__swc_fn_585f006d_000091_3d2f5a0d>
  40947b:	test   al,al
  40947d:	jne    4094f2 <__swc_fn_585f006d_000120_ea68f292+0xf2>
  40947f:	lea    rax,[rsp+0x8]
  409484:	vmovups xmm0,XMMWORD PTR [rsi]
  409488:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40948e:	mov    rcx,QWORD PTR [rsp+0x8]
  409493:	test   rcx,rcx
  409496:	jne    4094e7 <__swc_fn_585f006d_000120_ea68f292+0xe7>
  409498:	cmp    ebx,0x3
  40949b:	je     4094a9 <__swc_fn_585f006d_000120_ea68f292+0xa9>
  40949d:	cmp    ebx,0x4
  4094a0:	je     4094b9 <__swc_fn_585f006d_000120_ea68f292+0xb9>
  4094a2:	cmp    ebx,0x5
  4094a5:	je     4094c9 <__swc_fn_585f006d_000120_ea68f292+0xc9>
  4094a7:	jmp    4094d9 <__swc_fn_585f006d_000120_ea68f292+0xd9>
  4094a9:	vmovups xmm0,XMMWORD PTR [rip+0x902f]        # 4124e0 <__swc_rdata_base_585f006d+0x3d0>
  4094b1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b7:	jmp    4094e7 <__swc_fn_585f006d_000120_ea68f292+0xe7>
  4094b9:	vmovups xmm0,XMMWORD PTR [rip+0x902f]        # 4124f0 <__swc_rdata_base_585f006d+0x3e0>
  4094c1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c7:	jmp    4094e7 <__swc_fn_585f006d_000120_ea68f292+0xe7>
  4094c9:	vmovups xmm0,XMMWORD PTR [rip+0x902f]        # 412500 <__swc_rdata_base_585f006d+0x3f0>
  4094d1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094d7:	jmp    4094e7 <__swc_fn_585f006d_000120_ea68f292+0xe7>
  4094d9:	vmovups xmm0,XMMWORD PTR [rip+0x902f]        # 412510 <__swc_rdata_base_585f006d+0x400>
  4094e1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094e7:	mov    rcx,rax
  4094ea:	mov    rdx,rdi
  4094ed:	call   40c3c0 <__swc_fn_585f006d_000103_67100064>
  4094f2:	vmovups xmm0,XMMWORD PTR [rdi]
  4094f6:	vmovups XMMWORD PTR [r12+0x940],xmm0
  409500:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  409505:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40950f:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  409514:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40951e:	lea    rax,[r12+0x940]
  409526:	mov    QWORD PTR [r12+0x970],rax
  40952e:	mov    rax,QWORD PTR [rsi]
  409531:	mov    QWORD PTR [r12+0x978],rax
  409539:	mov    rax,QWORD PTR [rsi+0x8]
  40953d:	mov    QWORD PTR [r12+0x980],rax
  409545:	movsxd rax,ebx
  409548:	mov    QWORD PTR [r12+0x988],rax
  409550:	cmp    ebx,0x5
  409553:	je     40955c <__swc_fn_585f006d_000120_ea68f292+0x15c>
  409555:	xor    ecx,ecx
  409557:	call   40a300 <__swc_fn_585f006d_000174_176517f9>
  40955c:	mov    rbx,QWORD PTR [r12+0xbe8]
  409564:	test   rbx,rbx
  409567:	je     409578 <__swc_fn_585f006d_000120_ea68f292+0x178>
  409569:	mov    rcx,r12
  40956c:	call   rbx
  40956e:	add    rsp,0x18
  409572:	pop    r12
  409574:	pop    rdi
  409575:	pop    rsi
  409576:	pop    rbx
  409577:	ret
  409578:	mov    rcx,rsi
  40957b:	call   40fd60 <__swc_fn_585f006d_000116_035d76a1>
  409580:	call   40c9f0 <__swc_fn_585f006d_000118_7f430081>
  409585:	add    rsp,0x18
  409589:	pop    r12
  40958b:	pop    rdi
  40958c:	pop    rsi
  40958d:	pop    rbx
  40958e:	ret
  40958f:	mov    rcx,rsi
  409592:	mov    rdx,rdi
  409595:	call   40c3c0 <__swc_fn_585f006d_000103_67100064>
  40959a:	jmp    40944f <__swc_fn_585f006d_000120_ea68f292+0x4f>
	...

00000000004095a0 <__swc_fn_585f006d_000123_9d2cbd72>:
  4095a0:	push   rdi
  4095a1:	push   rsi
  4095a2:	sub    rsp,0xb8
  4095a9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4095af:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4095b5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4095bb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095c1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095c7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095cd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095d3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095dc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095e5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ee:	mov    DWORD PTR [rsp+0x8],0x0
  4095f6:	lea    rdi,[rsp+0x8]
  4095fb:	xor    esi,esi
  4095fd:	xor    eax,eax
  4095ff:	call   407050 <pthread_key_create@plt>
  409604:	test   eax,eax
  409606:	jne    40960e <__swc_fn_585f006d_000123_9d2cbd72+0x6e>
  409608:	mov    eax,DWORD PTR [rsp+0x8]
  40960c:	jmp    409615 <__swc_fn_585f006d_000123_9d2cbd72+0x75>
  40960e:	mov    rax,0xffffffffffffffff
  409615:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40961b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409621:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409627:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40962d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409633:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409639:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40963f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409648:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409651:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40965a:	add    rsp,0xb8
  409661:	pop    rsi
  409662:	pop    rdi
  409663:	ret
	...

0000000000409670 <__swc_fn_585f006d_000126_102fe7b9>:
  409670:	push   rdi
  409671:	push   rsi
  409672:	sub    rsp,0xb8
  409679:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40967f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409685:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40968b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409691:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409697:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40969d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4096a3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4096ac:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4096b5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4096be:	mov    DWORD PTR [rsp+0x8],0x0
  4096c6:	lea    rdi,[rsp+0x8]
  4096cb:	mov    rsi,rcx
  4096ce:	xor    eax,eax
  4096d0:	call   407050 <pthread_key_create@plt>
  4096d5:	test   eax,eax
  4096d7:	jne    4096e2 <__swc_fn_585f006d_000126_102fe7b9+0x72>
  4096d9:	mov    eax,DWORD PTR [rsp+0x8]
  4096dd:	inc    rax
  4096e0:	jmp    4096e4 <__swc_fn_585f006d_000126_102fe7b9+0x74>
  4096e2:	xor    eax,eax
  4096e4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ea:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096f0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096f6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096fc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409702:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409708:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40970e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409717:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409720:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409729:	add    rsp,0xb8
  409730:	pop    rsi
  409731:	pop    rdi
  409732:	ret
	...

0000000000409740 <__swc_fn_585f006d_000129_74b163fe>:
  409740:	push   rdi
  409741:	push   rsi
  409742:	sub    rsp,0xa8
  409749:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40974f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409755:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40975b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409761:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409767:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40976d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409773:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409779:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409782:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40978b:	test   rcx,rcx
  40978e:	setne  al
  409791:	je     4097aa <__swc_fn_585f006d_000129_74b163fe+0x6a>
  409793:	lea    rax,[rcx-0x1]
  409797:	mov    eax,eax
  409799:	mov    edi,eax
  40979b:	mov    rsi,rdx
  40979e:	xor    eax,eax
  4097a0:	call   407060 <pthread_setspecific@plt>
  4097a5:	test   eax,eax
  4097a7:	sete   al
  4097aa:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4097b0:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4097b6:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4097bc:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097c2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097c8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ce:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097d4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097da:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097e3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097ec:	add    rsp,0xa8
  4097f3:	pop    rsi
  4097f4:	pop    rdi
  4097f5:	ret
	...

0000000000409800 <__swc_fn_585f006d_000132_f908e7f9>:
  409800:	push   rdi
  409801:	push   rsi
  409802:	sub    rsp,0xa8
  409809:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40980f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409815:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40981b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409821:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409827:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40982d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409833:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409839:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409842:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40984b:	mov    rax,rdx
  40984e:	mov    QWORD PTR [rsp],0x0
  409856:	mov    edi,0xca
  40985b:	mov    rsi,rcx
  40985e:	mov    edx,0x81
  409863:	mov    eax,eax
  409865:	mov    ecx,eax
  409867:	xor    r8d,r8d
  40986a:	xor    r9d,r9d
  40986d:	xor    eax,eax
  40986f:	call   407070 <syscall@plt>
  409874:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40987a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409880:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409886:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40988c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409892:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409898:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40989e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4098a4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4098ad:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4098b6:	add    rsp,0xa8
  4098bd:	pop    rsi
  4098be:	pop    rdi
  4098bf:	ret

00000000004098c0 <__swc_fn_585f006d_000135_e3032dc2>:
  4098c0:	sub    rsp,0x8
  4098c4:	call   40cd90 <__swc_fn_585f006d_000133_4b2af8da>
  4098c9:	add    rsp,0x8
  4098cd:	ret
	...

00000000004098d0 <__swc_fn_585f006d_000138_0c00232f>:
  4098d0:	push   rdi
  4098d1:	push   rsi
  4098d2:	sub    rsp,0xc8
  4098d9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098df:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098e5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098eb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098f1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098f7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098fd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  409906:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40990f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  409918:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409921:	vxorps xmm0,xmm0,xmm0
  409925:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40992b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409931:	mov    rdi,rcx
  409934:	lea    rsi,[rsp+0x8]
  409939:	xor    eax,eax
  40993b:	call   407080 <dladdr@plt>
  409940:	xor    ecx,ecx
  409942:	test   eax,eax
  409944:	je     40994b <__swc_fn_585f006d_000138_0c00232f+0x7b>
  409946:	mov    rcx,QWORD PTR [rsp+0x10]
  40994b:	mov    rax,rcx
  40994e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409954:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40995a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409960:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409966:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40996c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409972:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40997b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409984:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40998d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409996:	add    rsp,0xc8
  40999d:	pop    rsi
  40999e:	pop    rdi
  40999f:	ret

00000000004099a0 <__swc_fn_585f006d_000141_2ce79e3b>:
  4099a0:	push   rbx
  4099a1:	push   r12
  4099a3:	push   r13
  4099a5:	push   rdi
  4099a6:	push   rsi
  4099a7:	push   r14
  4099a9:	push   r15
  4099ab:	sub    rsp,0x150
  4099b2:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  4099bb:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099c4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099cd:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099d6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099df:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099e8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099f1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099fa:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  409a03:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  409a0c:	mov    rbx,rdx
  409a0f:	mov    QWORD PTR [rsp+0x98],rdx
  409a17:	mov    r12,rcx
  409a1a:	mov    QWORD PTR [rsp+0xa0],rcx
  409a22:	mov    QWORD PTR [rbx],0x0
  409a29:	lea    r13,[rip+0x1c350]        # 425d80 <__swc_bss_base_585f006d+0x2d40>
  409a30:	mov    rcx,r13
  409a33:	call   4098c0 <__swc_fn_585f006d_000135_e3032dc2>
  409a38:	mov    rax,QWORD PTR [rip+0x1c349]        # 425d88 <__swc_bss_base_585f006d+0x2d48>
  409a3f:	test   rax,rax
  409a42:	je     409a79 <__swc_fn_585f006d_000141_2ce79e3b+0xd9>
  409a44:	cs nop WORD PTR [rax+rax*1+0x0]
  409a4e:	xchg   ax,ax
  409a50:	cmp    QWORD PTR [rax+0x8],r12
  409a54:	jne    409a71 <__swc_fn_585f006d_000141_2ce79e3b+0xd1>
  409a56:	mov    rcx,QWORD PTR [rax+0x18]
  409a5a:	mov    QWORD PTR [rbx],rcx
  409a5d:	mov    rbx,QWORD PTR [rax+0x10]
  409a61:	mov    rcx,r13
  409a64:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  409a69:	mov    rax,rbx
  409a6c:	jmp    409c5b <__swc_fn_585f006d_000141_2ce79e3b+0x2bb>
  409a71:	mov    rax,QWORD PTR [rax]
  409a74:	test   rax,rax
  409a77:	jne    409a50 <__swc_fn_585f006d_000141_2ce79e3b+0xb0>
  409a79:	vxorps xmm0,xmm0,xmm0
  409a7d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a83:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a89:	mov    rdi,r12
  409a8c:	lea    rsi,[rsp+0x10]
  409a91:	xor    eax,eax
  409a93:	call   407080 <dladdr@plt>
  409a98:	test   eax,eax
  409a9a:	sete   al
  409a9d:	je     409aaa <__swc_fn_585f006d_000141_2ce79e3b+0x10a>
  409a9f:	mov    rax,QWORD PTR [rsp+0x10]
  409aa4:	test   rax,rax
  409aa7:	sete   al
  409aaa:	test   al,al
  409aac:	je     409abd <__swc_fn_585f006d_000141_2ce79e3b+0x11d>
  409aae:	mov    rcx,r13
  409ab1:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  409ab6:	xor    eax,eax
  409ab8:	jmp    409c5b <__swc_fn_585f006d_000141_2ce79e3b+0x2bb>
  409abd:	mov    rdi,QWORD PTR [rsp+0x10]
  409ac2:	mov    esi,0x80000
  409ac7:	xor    eax,eax
  409ac9:	call   407090 <open@plt>
  409ace:	lea    r14,[rsp+0x30]
  409ad3:	mov    DWORD PTR [rsp+0x30],eax
  409ad7:	cmp    DWORD PTR [r14],0x0
  409adb:	jge    409aec <__swc_fn_585f006d_000141_2ce79e3b+0x14c>
  409add:	mov    rcx,r13
  409ae0:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  409ae5:	xor    eax,eax
  409ae7:	jmp    409c5b <__swc_fn_585f006d_000141_2ce79e3b+0x2bb>
  409aec:	mov    rax,r14
  409aef:	movsxd rdi,DWORD PTR [rax]
  409af2:	xor    esi,esi
  409af4:	mov    edx,0x2
  409af9:	xor    eax,eax
  409afb:	call   4070a0 <lseek@plt>
  409b00:	mov    r15,rax
  409b03:	test   rax,rax
  409b06:	jg     409b21 <__swc_fn_585f006d_000141_2ce79e3b+0x181>
  409b08:	movsxd rdi,DWORD PTR [r14]
  409b0b:	xor    eax,eax
  409b0d:	call   4070b0 <close@plt>
  409b12:	mov    rcx,r13
  409b15:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  409b1a:	xor    eax,eax
  409b1c:	jmp    409c5b <__swc_fn_585f006d_000141_2ce79e3b+0x2bb>
  409b21:	xor    edi,edi
  409b23:	mov    rsi,r15
  409b26:	mov    edx,0x1
  409b2b:	mov    ecx,0x2
  409b30:	mov    rax,r14
  409b33:	movsxd r8,DWORD PTR [rax]
  409b36:	xor    r9d,r9d
  409b39:	xor    eax,eax
  409b3b:	call   4070c0 <mmap@plt>
  409b40:	mov    rbx,rax
  409b43:	test   rax,rax
  409b46:	sete   al
  409b49:	cmp    rbx,0xffffffffffffffff
  409b4d:	sete   cl
  409b50:	or     al,cl
  409b52:	je     409b6d <__swc_fn_585f006d_000141_2ce79e3b+0x1cd>
  409b54:	movsxd rdi,DWORD PTR [r14]
  409b57:	xor    eax,eax
  409b59:	call   4070b0 <close@plt>
  409b5e:	mov    rcx,r13
  409b61:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  409b66:	xor    eax,eax
  409b68:	jmp    409c5b <__swc_fn_585f006d_000141_2ce79e3b+0x2bb>
  409b6d:	lea    rax,[rsp+0x50]
  409b72:	mov    QWORD PTR [rax],0x0
  409b79:	mov    rcx,rbx
  409b7c:	mov    rdx,r15
  409b7f:	mov    r8,rax
  409b82:	call   410300 <__swc_fn_585f006d_000140_c6b99a56>
  409b87:	mov    r12,rax
  409b8a:	test   rax,rax
  409b8d:	jne    409bb5 <__swc_fn_585f006d_000141_2ce79e3b+0x215>
  409b8f:	mov    rdi,rbx
  409b92:	mov    rsi,r15
  409b95:	xor    eax,eax
  409b97:	call   407020 <munmap@plt>
  409b9c:	movsxd rdi,DWORD PTR [r14]
  409b9f:	xor    eax,eax
  409ba1:	call   4070b0 <close@plt>
  409ba6:	mov    rcx,r13
  409ba9:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  409bae:	xor    eax,eax
  409bb0:	jmp    409c5b <__swc_fn_585f006d_000141_2ce79e3b+0x2bb>
  409bb5:	mov    edi,0x20
  409bba:	xor    eax,eax
  409bbc:	call   4070d0 <malloc@plt>
  409bc1:	test   rax,rax
  409bc4:	jne    409be9 <__swc_fn_585f006d_000141_2ce79e3b+0x249>
  409bc6:	mov    rdi,rbx
  409bc9:	mov    rsi,r15
  409bcc:	xor    eax,eax
  409bce:	call   407020 <munmap@plt>
  409bd3:	movsxd rdi,DWORD PTR [r14]
  409bd6:	xor    eax,eax
  409bd8:	call   4070b0 <close@plt>
  409bdd:	mov    rcx,r13
  409be0:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  409be5:	xor    eax,eax
  409be7:	jmp    409c5b <__swc_fn_585f006d_000141_2ce79e3b+0x2bb>
  409be9:	mov    rcx,QWORD PTR [rip+0x1c198]        # 425d88 <__swc_bss_base_585f006d+0x2d48>
  409bf0:	mov    QWORD PTR [rsp+0x70],rcx
  409bf5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bfd:	mov    QWORD PTR [rsp+0x78],rcx
  409c02:	mov    QWORD PTR [rsp+0x80],r12
  409c0a:	mov    rcx,QWORD PTR [rsp+0x50]
  409c0f:	mov    QWORD PTR [rsp+0x88],rcx
  409c17:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409c1d:	vmovups XMMWORD PTR [rax],xmm0
  409c21:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c2a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c2f:	mov    QWORD PTR [rip+0x1c152],rax        # 425d88 <__swc_bss_base_585f006d+0x2d48>
  409c36:	mov    rax,QWORD PTR [rsp+0x50]
  409c3b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c43:	mov    QWORD PTR [rbx],rax
  409c46:	movsxd rdi,DWORD PTR [r14]
  409c49:	xor    eax,eax
  409c4b:	call   4070b0 <close@plt>
  409c50:	mov    rcx,r13
  409c53:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  409c58:	mov    rax,r12
  409c5b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c64:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c6d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c76:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c7f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c88:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c91:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c9a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409ca3:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409cac:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409cb5:	add    rsp,0x150
  409cbc:	pop    r15
  409cbe:	pop    r14
  409cc0:	pop    rsi
  409cc1:	pop    rdi
  409cc2:	pop    r13
  409cc4:	pop    r12
  409cc6:	pop    rbx
  409cc7:	ret
	...

0000000000409cd0 <__swc_fn_585f006d_000144_72996a5b>:
  409cd0:	push   rbx
  409cd1:	sub    rsp,0xe0
  409cd8:	lea    rbx,[rsp+0x8]
  409cdd:	vxorps xmm0,xmm0,xmm0
  409ce1:	vmovups XMMWORD PTR [rbx],xmm0
  409ce5:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409cea:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409cef:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  409cf4:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  409cf9:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  409cfe:	mov    DWORD PTR [rbx+0x60],0x0
  409d05:	mov    r8,rbx
  409d08:	nop    DWORD PTR [rax+rax*1+0x0]
  409d10:	mov    r9,rcx
  409d13:	movabs rcx,0xcccccccccccccccd
  409d1d:	mov    rax,r9
  409d20:	mul    rcx
  409d23:	mov    r10,rdx
  409d26:	shr    r10,0x3
  409d2a:	mov    rcx,r10
  409d2d:	imul   rdx,r10,0xa
  409d31:	sub    r9,rdx
  409d34:	mov    rdx,QWORD PTR [rip+0x8805]        # 412540 <__swc_rdata_base_585f006d+0x430>
  409d3b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d40:	mov    BYTE PTR [r8],dl
  409d43:	lea    rdx,[r8+0x1]
  409d47:	mov    r8,rdx
  409d4a:	test   r10,r10
  409d4d:	jne    409d10 <__swc_fn_585f006d_000144_72996a5b+0x40>
  409d4f:	mov    BYTE PTR [rdx],0x0
  409d52:	sub    r8,0x1
  409d56:	mov    rax,rbx
  409d59:	cmp    rax,r8
  409d5c:	jae    409d76 <__swc_fn_585f006d_000144_72996a5b+0xa6>
  409d5e:	xchg   ax,ax
  409d60:	mov    cl,BYTE PTR [r8]
  409d63:	mov    dl,BYTE PTR [rax]
  409d65:	mov    BYTE PTR [r8],dl
  409d68:	sub    r8,0x1
  409d6c:	mov    BYTE PTR [rax],cl
  409d6e:	inc    rax
  409d71:	cmp    rax,r8
  409d74:	jb     409d60 <__swc_fn_585f006d_000144_72996a5b+0x90>
  409d76:	xor    eax,eax
  409d78:	test   rbx,rbx
  409d7b:	je     409d9e <__swc_fn_585f006d_000144_72996a5b+0xce>
  409d7d:	mov    rcx,rbx
  409d80:	mov    dl,BYTE PTR [rcx]
  409d82:	test   dl,dl
  409d84:	je     409d9e <__swc_fn_585f006d_000144_72996a5b+0xce>
  409d86:	cs nop WORD PTR [rax+rax*1+0x0]
  409d90:	add    rcx,0x1
  409d94:	add    rax,0x1
  409d98:	mov    dl,BYTE PTR [rcx]
  409d9a:	test   dl,dl
  409d9c:	jne    409d90 <__swc_fn_585f006d_000144_72996a5b+0xc0>
  409d9e:	mov    QWORD PTR [rbx+0xa8],rbx
  409da5:	mov    QWORD PTR [rbx+0xb0],rax
  409dac:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409db4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409dbc:	lea    rcx,[rbx+0xb8]
  409dc3:	call   40fd60 <__swc_fn_585f006d_000116_035d76a1>
  409dc8:	add    rsp,0xe0
  409dcf:	pop    rbx
  409dd0:	ret
	...

0000000000409de0 <__swc_fn_585f006d_000147_32a497f3>:
  409de0:	sub    rsp,0x8
  409de4:	mov    rax,QWORD PTR [rcx+0x8]
  409de8:	mov    r8,QWORD PTR [rdx+0x8]
  409dec:	cmp    rax,r8
  409def:	je     409df8 <__swc_fn_585f006d_000147_32a497f3+0x18>
  409df1:	xor    eax,eax
  409df3:	add    rsp,0x8
  409df7:	ret
  409df8:	test   rax,rax
  409dfb:	jne    409e0c <__swc_fn_585f006d_000147_32a497f3+0x2c>
  409dfd:	test   r8,r8
  409e00:	jne    409e0c <__swc_fn_585f006d_000147_32a497f3+0x2c>
  409e02:	mov    eax,0x1
  409e07:	add    rsp,0x8
  409e0b:	ret
  409e0c:	mov    rcx,QWORD PTR [rcx]
  409e0f:	mov    rdx,QWORD PTR [rdx]
  409e12:	test   rcx,rcx
  409e15:	sete   r8b
  409e19:	test   rdx,rdx
  409e1c:	sete   r9b
  409e20:	or     r8b,r9b
  409e23:	je     409e30 <__swc_fn_585f006d_000147_32a497f3+0x50>
  409e25:	cmp    rcx,rdx
  409e28:	sete   al
  409e2b:	add    rsp,0x8
  409e2f:	ret
  409e30:	cmp    rcx,rdx
  409e33:	jne    409e3f <__swc_fn_585f006d_000147_32a497f3+0x5f>
  409e35:	mov    eax,0x1
  409e3a:	add    rsp,0x8
  409e3e:	ret
  409e3f:	mov    r8,rax
  409e42:	call   40c480 <__swc_fn_585f006d_000106_ed4b1681>
  409e47:	test   eax,eax
  409e49:	sete   al
  409e4c:	add    rsp,0x8
  409e50:	ret
	...

0000000000409e60 <__swc_fn_585f006d_000150_9e4bc402>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x877a]        # 4125f8 <__swc_rdata_base_585f006d+0x4e8>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	ret
	...

0000000000409e90 <__swc_fn_585f006d_000153_9e4bc402>:
  409e90:	vxorps xmm0,xmm0,xmm0
  409e94:	vmovups XMMWORD PTR [rcx],xmm0
  409e98:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e9d:	vxorps xmm0,xmm0,xmm0
  409ea1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409ea6:	vmovups xmm0,XMMWORD PTR [rip+0x886a]        # 412718 <__swc_rdata_base_585f006d+0x608>
  409eae:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409eb3:	mov    QWORD PTR [rcx+0x40],0x0
  409ebb:	ret
  409ebc:	add    BYTE PTR [rax],al
	...

0000000000409ec0 <__swc_fn_585f006d_000156_2745c4a5>:
  409ec0:	push   rbx
  409ec1:	sub    rsp,0x70
  409ec5:	mov    rax,QWORD PTR [rcx]
  409ec8:	mov    rbx,QWORD PTR [rcx+0x8]
  409ecc:	vxorps xmm0,xmm0,xmm0
  409ed0:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409ed6:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409edc:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409ee2:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  409ee8:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eee:	mov    QWORD PTR [rsp+0x48],rdx
  409ef3:	mov    QWORD PTR [rsp+0x50],r8
  409ef8:	mov    rcx,rax
  409efb:	lea    rdx,[rsp+0x8]
  409f00:	mov    rbx,QWORD PTR [rbx+0x18]
  409f04:	call   rbx
  409f06:	add    rsp,0x70
  409f0a:	pop    rbx
  409f0b:	ret
  409f0c:	add    BYTE PTR [rax],al
	...

0000000000409f10 <__swc_fn_585f006d_000159_d8afac28>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	mov    rbx,r8
  409f16:	mov    rsi,rcx
  409f19:	mov    rdi,rdx
  409f1c:	call   40d1a0 <__swc_fn_585f006d_000157_232ffa22>
  409f21:	vmovups xmm0,XMMWORD PTR [rbx]
  409f25:	vmovups XMMWORD PTR [rsi],xmm0
  409f29:	mov    QWORD PTR [rsi+0x18],rdi
  409f2d:	pop    rdi
  409f2e:	pop    rsi
  409f2f:	pop    rbx
  409f30:	ret
	...

0000000000409f40 <__swc_fn_585f006d_000162_60216e69>:
  409f40:	push   rbx
  409f41:	push   rsi
  409f42:	push   rdi
  409f43:	push   r12
  409f45:	push   r13
  409f47:	sub    rsp,0x50
  409f4b:	mov    rbx,rcx
  409f4e:	mov    rsi,rdx
  409f51:	vmovups xmm0,XMMWORD PTR [rip+0x88cf]        # 412828 <__swc_rdata_base_585f006d+0x718>
  409f59:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f5f:	vmovups xmm0,XMMWORD PTR [rip+0x88d1]        # 412838 <__swc_rdata_base_585f006d+0x728>
  409f67:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f6d:	vxorps xmm0,xmm0,xmm0
  409f71:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f77:	mov    rcx,rdx
  409f7a:	call   4098d0 <__swc_fn_585f006d_000138_0c00232f>
  409f7f:	mov    rdi,rax
  409f82:	test   rax,rax
  409f85:	jne    409fb6 <__swc_fn_585f006d_000162_60216e69+0x76>
  409f87:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f8d:	vmovups XMMWORD PTR [rbx],xmm0
  409f91:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f97:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f9c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fa2:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fa7:	mov    rax,rbx
  409faa:	add    rsp,0x50
  409fae:	pop    r13
  409fb0:	pop    r12
  409fb2:	pop    rdi
  409fb3:	pop    rsi
  409fb4:	pop    rbx
  409fb5:	ret
  409fb6:	mov    rcx,rdi
  409fb9:	call   411860 <__swc_fn_585f006d_000161_b5a9d657>
  409fbe:	mov    r11,rax
  409fc1:	test   rax,rax
  409fc4:	je     409fce <__swc_fn_585f006d_000162_60216e69+0x8e>
  409fc6:	mov    al,BYTE PTR [r11+0x24]
  409fca:	test   al,al
  409fcc:	jne    409ffd <__swc_fn_585f006d_000162_60216e69+0xbd>
  409fce:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fd4:	vmovups XMMWORD PTR [rbx],xmm0
  409fd8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fde:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fe3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fe9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fee:	mov    rax,rbx
  409ff1:	add    rsp,0x50
  409ff5:	pop    r13
  409ff7:	pop    r12
  409ff9:	pop    rdi
  409ffa:	pop    rsi
  409ffb:	pop    rbx
  409ffc:	ret
  409ffd:	sub    rsi,rdi
  40a000:	mov    eax,0xffffffff
  40a005:	cmp    rsi,rax
  40a008:	jbe    40a039 <__swc_fn_585f006d_000162_60216e69+0xf9>
  40a00a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a010:	vmovups XMMWORD PTR [rbx],xmm0
  40a014:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a01a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a01f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a025:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a02a:	mov    rax,rbx
  40a02d:	add    rsp,0x50
  40a031:	pop    r13
  40a033:	pop    r12
  40a035:	pop    rdi
  40a036:	pop    rsi
  40a037:	pop    rbx
  40a038:	ret
  40a039:	mov    rdi,QWORD PTR [r11+0x10]
  40a03d:	mov    eax,DWORD PTR [r11+0x20]
  40a041:	xor    ecx,ecx
  40a043:	test   rax,rax
  40a046:	jbe    40a198 <__swc_fn_585f006d_000162_60216e69+0x258>
  40a04c:	nop    DWORD PTR [rax+0x0]
  40a050:	mov    edx,ecx
  40a052:	imul   r12,rdx,0x14
  40a056:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a05b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a060:	mov    r9d,esi
  40a063:	cmp    r9,rdx
  40a066:	jb     40a18b <__swc_fn_585f006d_000162_60216e69+0x24b>
  40a06c:	add    rdx,r8
  40a06f:	mov    r8d,esi
  40a072:	cmp    r8,rdx
  40a075:	jae    40a18b <__swc_fn_585f006d_000162_60216e69+0x24b>
  40a07b:	lea    rsi,[rsp+0x38]
  40a080:	mov    eax,DWORD PTR [rdi+0xc]
  40a083:	mov    DWORD PTR [rsp+0x38],eax
  40a087:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a08c:	mov    rcx,rdi
  40a08f:	mov    rdx,QWORD PTR [r11+0x18]
  40a093:	mov    r8,rsi
  40a096:	mov    r8d,DWORD PTR [r8]
  40a099:	mov    r9,rax
  40a09c:	lea    r10,[rsp+0x10]
  40a0a1:	call   40d200 <__swc_fn_585f006d_000160_01cbb887>
  40a0a6:	test   al,al
  40a0a8:	jne    40a0db <__swc_fn_585f006d_000162_60216e69+0x19b>
  40a0aa:	vmovups xmm0,XMMWORD PTR [rip+0x87a6]        # 412858 <__swc_rdata_base_585f006d+0x748>
  40a0b2:	vmovups XMMWORD PTR [rbx],xmm0
  40a0b6:	vmovups xmm0,XMMWORD PTR [rip+0x87aa]        # 412868 <__swc_rdata_base_585f006d+0x758>
  40a0be:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0c3:	vxorps xmm0,xmm0,xmm0
  40a0c7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0cc:	mov    rax,rbx
  40a0cf:	add    rsp,0x50
  40a0d3:	pop    r13
  40a0d5:	pop    r12
  40a0d7:	pop    rdi
  40a0d8:	pop    rsi
  40a0d9:	pop    rbx
  40a0da:	ret
  40a0db:	lea    r13,[rsp+0x3c]
  40a0e0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0e5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0e9:	test   eax,eax
  40a0eb:	je     40a13c <__swc_fn_585f006d_000162_60216e69+0x1fc>
  40a0ed:	mov    rcx,rdi
  40a0f0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0f4:	mov    r8d,DWORD PTR [rsi]
  40a0f7:	mov    rax,r13
  40a0fa:	mov    r9d,DWORD PTR [rax]
  40a0fd:	lea    r10,[rsp+0x20]
  40a102:	call   40d200 <__swc_fn_585f006d_000160_01cbb887>
  40a107:	test   al,al
  40a109:	jne    40a13c <__swc_fn_585f006d_000162_60216e69+0x1fc>
  40a10b:	vmovups xmm0,XMMWORD PTR [rip+0x8775]        # 412888 <__swc_rdata_base_585f006d+0x778>
  40a113:	vmovups XMMWORD PTR [rbx],xmm0
  40a117:	vmovups xmm0,XMMWORD PTR [rip+0x8779]        # 412898 <__swc_rdata_base_585f006d+0x788>
  40a11f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a124:	vxorps xmm0,xmm0,xmm0
  40a128:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a12d:	mov    rax,rbx
  40a130:	add    rsp,0x50
  40a134:	pop    r13
  40a136:	pop    r12
  40a138:	pop    rdi
  40a139:	pop    rsi
  40a13a:	pop    rbx
  40a13b:	ret
  40a13c:	mov    eax,0x1
  40a141:	rex mov BYTE PTR [rsp+0x8],al
  40a146:	cmp    DWORD PTR [r13+0x0],0x0
  40a14b:	je     40a15c <__swc_fn_585f006d_000162_60216e69+0x21c>
  40a14d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a153:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a158:	mov    DWORD PTR [rsp+0x30],eax
  40a15c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a162:	vmovups XMMWORD PTR [rbx],xmm0
  40a166:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a16c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a171:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a177:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a17c:	mov    rax,rbx
  40a17f:	add    rsp,0x50
  40a183:	pop    r13
  40a185:	pop    r12
  40a187:	pop    rdi
  40a188:	pop    rsi
  40a189:	pop    rbx
  40a18a:	ret
  40a18b:	add    rcx,0x1
  40a18f:	cmp    rcx,rax
  40a192:	jb     40a050 <__swc_fn_585f006d_000162_60216e69+0x110>
  40a198:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a19e:	vmovups XMMWORD PTR [rbx],xmm0
  40a1a2:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a1a8:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a1ad:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a1b3:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a1b8:	mov    rax,rbx
  40a1bb:	add    rsp,0x50
  40a1bf:	pop    r13
  40a1c1:	pop    r12
  40a1c3:	pop    rdi
  40a1c4:	pop    rsi
  40a1c5:	pop    rbx
  40a1c6:	ret
	...

000000000040a1d0 <__swc_fn_585f006d_000165_cf398896>:
  40a1d0:	sub    rsp,0x48
  40a1d4:	call   4095a0 <__swc_fn_585f006d_000123_9d2cbd72>
  40a1d9:	cmp    rax,0xffffffffffffffff
  40a1dd:	je     40a1e4 <__swc_fn_585f006d_000165_cf398896+0x14>
  40a1df:	add    rsp,0x48
  40a1e3:	ret
  40a1e4:	lea    rcx,[rip+0x86dd]        # 4128c8 <__swc_rdata_base_585f006d+0x7b8>
  40a1eb:	vmovups xmm0,XMMWORD PTR [rip+0x86e5]        # 4128d8 <__swc_rdata_base_585f006d+0x7c8>
  40a1f3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1f9:	vmovups xmm0,XMMWORD PTR [rip+0x86e7]        # 4128e8 <__swc_rdata_base_585f006d+0x7d8>
  40a201:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a207:	vmovups xmm0,XMMWORD PTR [rip+0x86e9]        # 4128f8 <__swc_rdata_base_585f006d+0x7e8>
  40a20f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a215:	lea    rdx,[rsp+0x8]
  40a21a:	mov    QWORD PTR [rsp+0x38],rax
  40a21f:	call   40c3c0 <__swc_fn_585f006d_000103_67100064>
  40a224:	mov    rax,QWORD PTR [rsp+0x38]
  40a229:	jmp    40a1df <__swc_fn_585f006d_000165_cf398896+0xf>
  40a22b:	add    BYTE PTR [rax],al
  40a22d:	add    BYTE PTR [rax],al
	...

000000000040a230 <__swc_fn_585f006d_000168_92b7d63c>:
  40a230:	push   rbx
  40a231:	push   rsi
  40a232:	sub    rsp,0x28
  40a236:	mov    rbx,rcx
  40a239:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a241:	mov    ecx,0xbf0
  40a246:	call   40bfb0 <__swc_fn_585f006d_000079_34776ded>
  40a24b:	mov    rsi,rax
  40a24e:	test   rax,rax
  40a251:	jne    40a25c <__swc_fn_585f006d_000168_92b7d63c+0x2c>
  40a253:	xor    eax,eax
  40a255:	add    rsp,0x28
  40a259:	pop    rsi
  40a25a:	pop    rbx
  40a25b:	ret
  40a25c:	vxorps xmm0,xmm0,xmm0
  40a260:	xor    eax,eax
  40a262:	cs nop WORD PTR [rax+rax*1+0x0]
  40a26c:	nop    DWORD PTR [rax+0x0]
  40a270:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a275:	add    rax,0x10
  40a279:	cmp    rax,0xbf0
  40a280:	jne    40a270 <__swc_fn_585f006d_000168_92b7d63c+0x40>
  40a282:	lea    rax,[rbx+0x1]
  40a286:	mov    QWORD PTR [rsi+0x9c0],rax
  40a28d:	mov    rcx,rbx
  40a290:	mov    rdx,rsi
  40a293:	call   40d560 <__swc_fn_585f006d_000166_f6173642>
  40a298:	test   al,al
  40a29a:	jne    40a2ad <__swc_fn_585f006d_000168_92b7d63c+0x7d>
  40a29c:	mov    rcx,rsi
  40a29f:	call   40ecb0 <__swc_fn_585f006d_000080_c1514492>
  40a2a4:	xor    eax,eax
  40a2a6:	add    rsp,0x28
  40a2aa:	pop    rsi
  40a2ab:	pop    rbx
  40a2ac:	ret
  40a2ad:	lea    rcx,[rsp+0x18]
  40a2b2:	call   40f230 <__swc_fn_585f006d_000092_8252f8c0>
  40a2b7:	mov    rax,rsi
  40a2ba:	add    rsp,0x28
  40a2be:	pop    rsi
  40a2bf:	pop    rbx
  40a2c0:	ret
	...

000000000040a2d0 <__swc_fn_585f006d_000171_c0e8acb1>:
  40a2d0:	xor    eax,eax
  40a2d2:	mov    edx,0x1
  40a2d7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2dc:	test   rax,rax
  40a2df:	jne    40a2e2 <__swc_fn_585f006d_000171_c0e8acb1+0x12>
  40a2e1:	ret
  40a2e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2ec:	nop    DWORD PTR [rax+0x0]
  40a2f0:	mov    rax,QWORD PTR [rcx]
  40a2f3:	test   rax,rax
  40a2f6:	je     40a2d0 <__swc_fn_585f006d_000171_c0e8acb1>
  40a2f8:	jmp    40a2f0 <__swc_fn_585f006d_000171_c0e8acb1+0x20>
  40a2fa:	add    BYTE PTR [rax],al
  40a2fc:	add    BYTE PTR [rax],al
	...

000000000040a300 <__swc_fn_585f006d_000174_176517f9>:
  40a300:	push   rsi
  40a301:	push   rdi
  40a302:	sub    rsp,0x38
  40a306:	mov    rsi,rcx
  40a309:	call   40d570 <__swc_fn_585f006d_000169_4579a84c>
  40a30e:	mov    rdi,rax
  40a311:	call   40cce0 <__swc_fn_585f006d_000130_c1196dfb>
  40a316:	mov    r8,rax
  40a319:	mov    rcx,rdi
  40a31c:	call   40a2d0 <__swc_fn_585f006d_000171_c0e8acb1>
  40a321:	mov    rax,QWORD PTR [rdi+0x8]
  40a325:	test   rax,rax
  40a328:	je     40a365 <__swc_fn_585f006d_000174_176517f9+0x65>
  40a32a:	nop    WORD PTR [rax+rax*1+0x0]
  40a330:	cmp    rax,rsi
  40a333:	je     40a365 <__swc_fn_585f006d_000174_176517f9+0x65>
  40a335:	mov    r9,QWORD PTR [rax]
  40a338:	cmp    QWORD PTR [rax+0x20],r8
  40a33c:	jne    40a35d <__swc_fn_585f006d_000174_176517f9+0x5d>
  40a33e:	mov    rcx,rdi
  40a341:	mov    rdx,rax
  40a344:	mov    QWORD PTR [rsp+0x28],r8
  40a349:	mov    QWORD PTR [rsp+0x30],r9
  40a34e:	call   411c80 <__swc_fn_585f006d_000173_f69b1f05>
  40a353:	mov    r8,QWORD PTR [rsp+0x28]
  40a358:	mov    r9,QWORD PTR [rsp+0x30]
  40a35d:	mov    rax,r9
  40a360:	test   r9,r9
  40a363:	jne    40a330 <__swc_fn_585f006d_000174_176517f9+0x30>
  40a365:	xor    eax,eax
  40a367:	mov    QWORD PTR [rdi],rax
  40a36a:	add    rsp,0x38
  40a36e:	pop    rdi
  40a36f:	pop    rsi
  40a370:	ret
	...

000000000040a380 <__swc_fn_585f006d_000177_1ca87929>:
  40a380:	push   rdi
  40a381:	push   rsi
  40a382:	sub    rsp,0xb8
  40a389:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a38f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a395:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a39b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a3a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a3a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a3ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a3b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a3bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a3c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a3ce:	vxorps xmm0,xmm0,xmm0
  40a3d2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a3d8:	mov    edi,0x1
  40a3dd:	lea    rsi,[rsp+0x8]
  40a3e2:	xor    eax,eax
  40a3e4:	call   4070e0 <clock_gettime@plt>
  40a3e9:	vxorpd xmm0,xmm0,xmm0
  40a3ed:	mov    rax,QWORD PTR [rsp+0x8]
  40a3f2:	vcvtsi2sd xmm0,xmm0,rax
  40a3f7:	vxorpd xmm1,xmm1,xmm1
  40a3fb:	mov    rax,QWORD PTR [rsp+0x10]
  40a400:	vcvtsi2sd xmm1,xmm1,rax
  40a405:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x84fb]        # 412908 <__swc_rdata_base_585f006d+0x7f8>
  40a40d:	vaddsd xmm0,xmm0,xmm1
  40a411:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a417:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a41d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a423:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a429:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a42f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a435:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a43b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a444:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a44d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a456:	add    rsp,0xb8
  40a45d:	pop    rsi
  40a45e:	pop    rdi
  40a45f:	ret

000000000040a460 <__swc_fn_585f006d_000001_46f18a51>:
  40a460:	vxorps xmm0,xmm0,xmm0
  40a464:	xor    eax,eax
  40a466:	cs nop WORD PTR [rax+rax*1+0x0]
  40a470:	cs nop WORD PTR [rax+rax*1+0x0]
  40a47a:	nop    WORD PTR [rax+rax*1+0x0]
  40a480:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a485:	add    rax,0x10
  40a489:	cmp    rax,0x2080
  40a490:	jne    40a480 <__swc_fn_585f006d_000001_46f18a51+0x20>
  40a492:	ret
	...

000000000040a4a0 <__swc_fn_585f006d_000004_1acc36a6>:
  40a4a0:	push   rsi
  40a4a1:	push   rdi
  40a4a2:	push   r12
  40a4a4:	push   r13
  40a4a6:	push   r14
  40a4a8:	mov    rsi,rcx
  40a4ab:	mov    edi,r10d
  40a4ae:	mov    r12,rcx
  40a4b1:	mov    r13,r9
  40a4b4:	mov    ecx,DWORD PTR [rdx+0x28]
  40a4b7:	shlx   r14d,r8d,ecx
  40a4bc:	mov    rcx,rdx
  40a4bf:	mov    edx,r8d
  40a4c2:	call   40db80 <__swc_fn_585f006d_000011_6493fbbc>
  40a4c7:	mov    rcx,rax
  40a4ca:	mov    eax,DWORD PTR [r12+0x3c]
  40a4cf:	xor    edx,edx
  40a4d1:	div    rdi
  40a4d4:	vxorps xmm0,xmm0,xmm0
  40a4d8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40a4dc:	mov    QWORD PTR [r12+0x60],0x0
  40a4e5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40a4ea:	mov    QWORD PTR [r12+0x10],rcx
  40a4ef:	imul   rax,rdi
  40a4f3:	lea    rdx,[rcx+rax*1]
  40a4f7:	mov    QWORD PTR [r12+0x18],rdx
  40a4fc:	mov    QWORD PTR [r12+0x20],rcx
  40a501:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40a506:	mov    DWORD PTR [r12+0x28],0x0
  40a50f:	mov    DWORD PTR [r12+0x68],0x0
  40a518:	mov    BYTE PTR [r12+0x39],r13b
  40a51d:	mov    BYTE PTR [r12+0x3a],r14b
  40a522:	mov    BYTE PTR [r12+0x3b],0x1
  40a528:	mov    DWORD PTR [r12+0x6c],0x0
  40a531:	mov    rcx,r12
  40a534:	mov    edx,edi
  40a536:	call   40dae0 <__swc_fn_585f006d_000005_b2240b56>
  40a53b:	pop    r14
  40a53d:	pop    r13
  40a53f:	pop    r12
  40a541:	pop    rdi
  40a542:	pop    rsi
  40a543:	ret
	...

000000000040a550 <__swc_fn_585f006d_000007_614a4804>:
  40a550:	mov    r8d,0x1
  40a556:	xor    eax,eax
  40a558:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40a55e:	test   eax,eax
  40a560:	jne    40a550 <__swc_fn_585f006d_000007_614a4804>
  40a562:	ret
	...

000000000040a570 <__swc_fn_585f006d_000010_395bb04b>:
  40a570:	lea    r8,[rcx+0x60]
  40a574:	mov    rax,QWORD PTR [r8]
  40a577:	mov    r9,rax
  40a57a:	nop    WORD PTR [rax+rax*1+0x0]
  40a580:	mov    QWORD PTR [rdx],r9
  40a583:	mov    rax,r9
  40a586:	lock cmpxchg QWORD PTR [r8],rdx
  40a58b:	cmp    rax,r9
  40a58e:	jne    40a5f7 <__swc_fn_585f006d_000010_395bb04b+0x87>
  40a590:	mov    eax,DWORD PTR [rcx+0x6c]
  40a593:	test   eax,eax
  40a595:	je     40a5f6 <__swc_fn_585f006d_000010_395bb04b+0x86>
  40a597:	lea    rdx,[rcx+0x70]
  40a59b:	mov    r9d,0x1
  40a5a1:	xor    eax,eax
  40a5a3:	lock cmpxchg DWORD PTR [rdx],r9d
  40a5a8:	test   eax,eax
  40a5aa:	jne    40a5f6 <__swc_fn_585f006d_000010_395bb04b+0x86>
  40a5ac:	mov    rax,rcx
  40a5af:	and    rax,0xffffffffffc00000
  40a5b6:	mov    rax,QWORD PTR [rax+0x8]
  40a5ba:	test   rax,rax
  40a5bd:	jne    40a5c5 <__swc_fn_585f006d_000010_395bb04b+0x55>
  40a5bf:	xor    eax,eax
  40a5c1:	xchg   DWORD PTR [rdx],eax
  40a5c3:	jmp    40a5f6 <__swc_fn_585f006d_000010_395bb04b+0x86>
  40a5c5:	lea    rdx,[rax+0x2a80]
  40a5cc:	mov    rax,QWORD PTR [rdx]
  40a5cf:	mov    r8,rax
  40a5d2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5dc:	nop    DWORD PTR [rax+0x0]
  40a5e0:	mov    QWORD PTR [rcx+0x78],r8
  40a5e4:	mov    rax,r8
  40a5e7:	lock cmpxchg QWORD PTR [rdx],rcx
  40a5ec:	cmp    rax,r8
  40a5ef:	je     40a5f6 <__swc_fn_585f006d_000010_395bb04b+0x86>
  40a5f1:	mov    r8,rax
  40a5f4:	jmp    40a5e0 <__swc_fn_585f006d_000010_395bb04b+0x70>
  40a5f6:	ret
  40a5f7:	mov    r9,rax
  40a5fa:	jmp    40a580 <__swc_fn_585f006d_000010_395bb04b+0x10>
	...

000000000040a600 <__swc_fn_585f006d_000013_9ba72deb>:
  40a600:	push   rsi
  40a601:	push   rdi
  40a602:	push   r12
  40a604:	push   r13
  40a606:	push   r14
  40a608:	push   r15
  40a60a:	push   rbx
  40a60b:	sub    rsp,0x30
  40a60f:	mov    QWORD PTR [rsp+0x18],r8
  40a614:	mov    rsi,rcx
  40a617:	mov    rdi,rdx
  40a61a:	mov    rdx,QWORD PTR [rsi+0x40]
  40a61e:	xchg   ax,ax
  40a620:	mov    rax,rdx
  40a623:	not    rax
  40a626:	and    rax,QWORD PTR [rsi+0x20]
  40a62a:	test   rax,rax
  40a62d:	jne    40a641 <__swc_fn_585f006d_000013_9ba72deb+0x41>
  40a62f:	xor    eax,eax
  40a631:	add    rsp,0x30
  40a635:	pop    rbx
  40a636:	pop    r15
  40a638:	pop    r14
  40a63a:	pop    r13
  40a63c:	pop    r12
  40a63e:	pop    rdi
  40a63f:	pop    rsi
  40a640:	ret
  40a641:	xor    ecx,ecx
  40a643:	tzcnt  rcx,rax
  40a648:	lea    r12,[rsp+0x8]
  40a64d:	mov    DWORD PTR [rsp+0x8],ecx
  40a651:	mov    r13d,0x1
  40a657:	shl    r13,cl
  40a65a:	mov    rcx,rdx
  40a65d:	or     rcx,r13
  40a660:	mov    rax,rdx
  40a663:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40a669:	cmp    rax,rdx
  40a66c:	je     40a673 <__swc_fn_585f006d_000013_9ba72deb+0x73>
  40a66e:	mov    rdx,rax
  40a671:	jmp    40a620 <__swc_fn_585f006d_000013_9ba72deb+0x20>
  40a673:	mov    eax,DWORD PTR [r12]
  40a677:	shl    rax,0x4
  40a67b:	lea    r14,[rsi+rax*8+0x80]
  40a683:	mov    rcx,rsi
  40a686:	mov    rax,r12
  40a689:	mov    edx,DWORD PTR [rax]
  40a68b:	call   40db80 <__swc_fn_585f006d_000011_6493fbbc>
  40a690:	mov    r15,rax
  40a693:	mov    rcx,rsi
  40a696:	mov    rdx,r13
  40a699:	call   40dce0 <__swc_fn_585f006d_000017_4df2d1a0>
  40a69e:	test   al,al
  40a6a0:	je     40a6d8 <__swc_fn_585f006d_000013_9ba72deb+0xd8>
  40a6a2:	mov    ecx,DWORD PTR [r14+0x3c]
  40a6a6:	lea    rdx,[rip+0x189ab]        # 423058 <__swc_bss_base_585f006d+0x18>
  40a6ad:	mov    r8,QWORD PTR [rip+0x189a4]        # 423058 <__swc_bss_base_585f006d+0x18>
  40a6b4:	cs nop WORD PTR [rax+rax*1+0x0]
  40a6be:	xchg   ax,ax
  40a6c0:	mov    r9,r8
  40a6c3:	sub    r9,rcx
  40a6c6:	mov    rax,r8
  40a6c9:	lock cmpxchg QWORD PTR [rdx],r9
  40a6ce:	cmp    rax,r8
  40a6d1:	je     40a739 <__swc_fn_585f006d_000013_9ba72deb+0x139>
  40a6d3:	mov    r8,rax
  40a6d6:	jmp    40a6c0 <__swc_fn_585f006d_000013_9ba72deb+0xc0>
  40a6d8:	mov    rcx,rsi
  40a6db:	mov    rax,r12
  40a6de:	mov    edx,DWORD PTR [rax]
  40a6e0:	call   407450 <__swc_fn_585f006d_000012_c7df5d22>
  40a6e5:	mov    rcx,r15
  40a6e8:	and    rcx,0xffffffffffff0000
  40a6ef:	lea    rcx,[rcx+0x10000]
  40a6f6:	mov    rbx,rax
  40a6f9:	cmp    rax,rcx
  40a6fc:	cmova  rbx,rcx
  40a700:	mov    rax,rbx
  40a703:	sub    rax,r15
  40a706:	mov    rcx,r15
  40a709:	mov    rdx,rax
  40a70c:	call   4072a0 <__swc_fn_585f006d_000003_7ab4792e>
  40a711:	test   al,al
  40a713:	jne    40a732 <__swc_fn_585f006d_000013_9ba72deb+0x132>
  40a715:	mov    rcx,rsi
  40a718:	mov    rdx,r13
  40a71b:	call   407600 <__swc_fn_585f006d_000018_7d1e8a10>
  40a720:	xor    eax,eax
  40a722:	add    rsp,0x30
  40a726:	pop    rbx
  40a727:	pop    r15
  40a729:	pop    r14
  40a72b:	pop    r13
  40a72d:	pop    r12
  40a72f:	pop    rdi
  40a730:	pop    rsi
  40a731:	ret
  40a732:	sub    rbx,r15
  40a735:	mov    DWORD PTR [r14+0x3c],ebx
  40a739:	mov    rcx,r14
  40a73c:	mov    rdx,rsi
  40a73f:	mov    r8d,DWORD PTR [r12]
  40a743:	mov    r9d,edi
  40a746:	mov    rbx,QWORD PTR [rsp+0x18]
  40a74b:	mov    r10d,ebx
  40a74e:	call   40a4a0 <__swc_fn_585f006d_000004_1acc36a6>
  40a753:	mov    rax,r14
  40a756:	add    rsp,0x30
  40a75a:	pop    rbx
  40a75b:	pop    r15
  40a75d:	pop    r14
  40a75f:	pop    r13
  40a761:	pop    r12
  40a763:	pop    rdi
  40a764:	pop    rsi
  40a765:	ret
	...

000000000040a770 <__swc_fn_585f006d_000016_4b207b58>:
  40a770:	mov    r8,QWORD PTR [rcx+0x48]
  40a774:	cs nop WORD PTR [rax+rax*1+0x0]
  40a77e:	xchg   ax,ax
  40a780:	mov    r9,r8
  40a783:	or     r9,rdx
  40a786:	mov    rax,r8
  40a789:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40a78f:	cmp    rax,r8
  40a792:	jne    40a795 <__swc_fn_585f006d_000016_4b207b58+0x25>
  40a794:	ret
  40a795:	mov    r8,rax
  40a798:	jmp    40a780 <__swc_fn_585f006d_000016_4b207b58+0x10>
  40a79a:	add    BYTE PTR [rax],al
  40a79c:	add    BYTE PTR [rax],al
	...

000000000040a7a0 <__swc_fn_585f006d_000019_2cc1532c>:
  40a7a0:	push   rsi
  40a7a1:	push   rdi
  40a7a2:	push   r12
  40a7a4:	mov    rsi,rcx
  40a7a7:	xor    edi,edi
  40a7a9:	lea    r12,[rip+0x188b8]        # 423068 <__swc_bss_base_585f006d+0x28>
  40a7b0:	mov    eax,DWORD PTR [r12]
  40a7b4:	xor    ecx,ecx
  40a7b6:	test   rax,rax
  40a7b9:	jbe    40a7f4 <__swc_fn_585f006d_000019_2cc1532c+0x54>
  40a7bb:	nop    DWORD PTR [rax+rax*1+0x0]
  40a7c0:	lea    rdx,[rip+0x188a9]        # 423070 <__swc_bss_base_585f006d+0x30>
  40a7c7:	mov    r8d,ecx
  40a7ca:	lea    r8,[r8+r8*2]
  40a7ce:	lea    r8,[rdx+r8*8]
  40a7d2:	mov    rdx,QWORD PTR [r8+0x10]
  40a7d6:	add    rdx,0x400000
  40a7dd:	cmp    rdx,0x40000000
  40a7e4:	ja     40a7eb <__swc_fn_585f006d_000019_2cc1532c+0x4b>
  40a7e6:	mov    rdi,r8
  40a7e9:	jmp    40a7f4 <__swc_fn_585f006d_000019_2cc1532c+0x54>
  40a7eb:	add    rcx,0x1
  40a7ef:	cmp    rcx,rax
  40a7f2:	jb     40a7c0 <__swc_fn_585f006d_000019_2cc1532c+0x20>
  40a7f4:	test   rdi,rdi
  40a7f7:	jne    40a883 <__swc_fn_585f006d_000019_2cc1532c+0xe3>
  40a7fd:	cmp    DWORD PTR [r12],0x10
  40a802:	jae    40a86b <__swc_fn_585f006d_000019_2cc1532c+0xcb>
  40a804:	mov    ecx,0x40400000
  40a809:	call   40daa0 <__swc_fn_585f006d_000002_884bb5c0>
  40a80e:	test   rax,rax
  40a811:	je     40a86b <__swc_fn_585f006d_000019_2cc1532c+0xcb>
  40a813:	lea    rcx,[rip+0x18856]        # 423070 <__swc_bss_base_585f006d+0x30>
  40a81a:	mov    edx,DWORD PTR [r12]
  40a81e:	lea    rdx,[rdx+rdx*2]
  40a822:	lea    rdx,[rcx+rdx*8]
  40a826:	mov    QWORD PTR [rdx],rax
  40a829:	lea    rax,[rax+0x3fffff]
  40a830:	and    rax,0xffffffffffc00000
  40a837:	mov    QWORD PTR [rdx+0x8],rax
  40a83b:	mov    QWORD PTR [rdx+0x10],0x0
  40a843:	mov    edx,DWORD PTR [rip+0x1881f]        # 423068 <__swc_bss_base_585f006d+0x28>
  40a849:	nop    DWORD PTR [rax+0x0]
  40a850:	lea    r9d,[rdx+0x1]
  40a854:	mov    rax,rdx
  40a857:	lock cmpxchg DWORD PTR [r12],r9d
  40a85d:	mov    r8d,eax
  40a860:	cmp    eax,edx
  40a862:	je     40a872 <__swc_fn_585f006d_000019_2cc1532c+0xd2>
  40a864:	mov    rdx,r8
  40a867:	jmp    40a850 <__swc_fn_585f006d_000019_2cc1532c+0xb0>
  40a869:	jmp    40a872 <__swc_fn_585f006d_000019_2cc1532c+0xd2>
  40a86b:	xor    eax,eax
  40a86d:	pop    r12
  40a86f:	pop    rdi
  40a870:	pop    rsi
  40a871:	ret
  40a872:	mov    eax,DWORD PTR [rip+0x187f0]        # 423068 <__swc_bss_base_585f006d+0x28>
  40a878:	sub    eax,0x1
  40a87b:	lea    rdi,[rax+rax*2]
  40a87f:	lea    rdi,[rcx+rdi*8]
  40a883:	mov    r12,QWORD PTR [rdi+0x8]
  40a887:	add    r12,QWORD PTR [rdi+0x10]
  40a88b:	mov    rcx,r12
  40a88e:	mov    edx,0x3000
  40a893:	call   4072a0 <__swc_fn_585f006d_000003_7ab4792e>
  40a898:	test   al,al
  40a89a:	jne    40a8a3 <__swc_fn_585f006d_000019_2cc1532c+0x103>
  40a89c:	xor    eax,eax
  40a89e:	pop    r12
  40a8a0:	pop    rdi
  40a8a1:	pop    rsi
  40a8a2:	ret
  40a8a3:	vxorps xmm0,xmm0,xmm0
  40a8a7:	xor    eax,eax
  40a8a9:	cs nop WORD PTR [rax+rax*1+0x0]
  40a8b3:	cs nop WORD PTR [rax+rax*1+0x0]
  40a8bd:	nop    DWORD PTR [rax]
  40a8c0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40a8c6:	add    rax,0x10
  40a8ca:	cmp    rax,0x3000
  40a8d1:	jne    40a8c0 <__swc_fn_585f006d_000019_2cc1532c+0x120>
  40a8d3:	mov    DWORD PTR [r12+0x28],esi
  40a8d8:	mov    eax,0x40
  40a8dd:	mov    ecx,esi
  40a8df:	shr    eax,cl
  40a8e1:	mov    DWORD PTR [r12+0x2c],eax
  40a8e6:	cmp    DWORD PTR [r12+0x2c],0x40
  40a8ec:	jb     40a8f7 <__swc_fn_585f006d_000019_2cc1532c+0x157>
  40a8ee:	mov    rax,0xffffffffffffffff
  40a8f5:	jmp    40a907 <__swc_fn_585f006d_000019_2cc1532c+0x167>
  40a8f7:	mov    eax,0x1
  40a8fc:	mov    ecx,DWORD PTR [r12+0x2c]
  40a901:	shl    rax,cl
  40a904:	dec    rax
  40a907:	mov    QWORD PTR [r12+0x20],rax
  40a90c:	mov    DWORD PTR [r12],0x4e540001
  40a914:	mov    DWORD PTR [r12+0x4],0x53474d45
  40a91d:	add    QWORD PTR [rdi+0x10],0x400000
  40a925:	mov    rax,r12
  40a928:	pop    r12
  40a92a:	pop    rdi
  40a92b:	pop    rsi
  40a92c:	ret
  40a92d:	add    BYTE PTR [rax],al
	...

000000000040a930 <__swc_fn_585f006d_000022_3a2e2048>:
  40a930:	mov    eax,0x1
  40a935:	mov    edx,DWORD PTR [rip+0x1872d]        # 423068 <__swc_bss_base_585f006d+0x28>
  40a93b:	cmp    eax,edx
  40a93d:	jae    40a98b <__swc_fn_585f006d_000022_3a2e2048+0x5b>
  40a93f:	nop
  40a940:	lea    r8,[rip+0x18729]        # 423070 <__swc_bss_base_585f006d+0x30>
  40a947:	lea    r9,[rax+rax*2]
  40a94b:	lea    r9,[r8+r9*8]
  40a94f:	mov    r8,rcx
  40a952:	sub    r8,QWORD PTR [r9+0x8]
  40a956:	mov    r9,QWORD PTR [r9+0x10]
  40a95a:	cmp    r8,r9
  40a95d:	jae    40a985 <__swc_fn_585f006d_000022_3a2e2048+0x55>
  40a95f:	mov    rax,rcx
  40a962:	and    rax,0xffffffffffc00000
  40a969:	shr    rcx,0x10
  40a96d:	and    ecx,0x3f
  40a970:	mov    edx,DWORD PTR [rax+0x28]
  40a973:	shrx   ecx,ecx,edx
  40a978:	shl    rcx,0x4
  40a97c:	lea    rax,[rax+rcx*8+0x80]
  40a984:	ret
  40a985:	inc    eax
  40a987:	cmp    eax,edx
  40a989:	jb     40a940 <__swc_fn_585f006d_000022_3a2e2048+0x10>
  40a98b:	xor    eax,eax
  40a98d:	ret
	...

000000000040a990 <__swc_fn_585f006d_000025_4aca8b9e>:
  40a990:	vxorps xmm0,xmm0,xmm0
  40a994:	vmovups XMMWORD PTR [rcx],xmm0
  40a998:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a99d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a9a2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a9a7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a9ac:	mov    QWORD PTR [rcx+0x50],0x0
  40a9b4:	ret
	...

000000000040a9c0 <__swc_fn_585f006d_000028_4aca8b9e>:
  40a9c0:	vxorps xmm0,xmm0,xmm0
  40a9c4:	xor    eax,eax
  40a9c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9d0:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9da:	nop    WORD PTR [rax+rax*1+0x0]
  40a9e0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a9e5:	add    rax,0x10
  40a9e9:	cmp    rax,0x9b0
  40a9f0:	jne    40a9e0 <__swc_fn_585f006d_000028_4aca8b9e+0x20>
  40a9f2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40a9fd:	ret
	...

000000000040aa00 <__swc_fn_585f006d_000031_90860ff2>:
  40aa00:	push   rsi
  40aa01:	push   rdi
  40aa02:	sub    rsp,0x8
  40aa06:	lea    rsi,[rip+0x165fb]        # 421008 <__swc_data_base_585f006d+0x8>
  40aa0d:	mov    rax,QWORD PTR [rsi]
  40aa10:	mov    ecx,0xffffffff
  40aa15:	cmp    rax,rcx
  40aa18:	je     40aa21 <__swc_fn_585f006d_000031_90860ff2+0x21>
  40aa1a:	add    rsp,0x8
  40aa1e:	pop    rdi
  40aa1f:	pop    rsi
  40aa20:	ret
  40aa21:	mov    rcx,QWORD PTR [rip+0x7658]        # 412080 <__swc_fn_585f006d_000176_5d3d19bd+0x380>
  40aa28:	call   409670 <__swc_fn_585f006d_000126_102fe7b9>
  40aa2d:	mov    rcx,rax
  40aa30:	mov    eax,0xffffffff
  40aa35:	lock cmpxchg QWORD PTR [rsi],rcx
  40aa3a:	mov    rdi,rax
  40aa3d:	mov    eax,0xffffffff
  40aa42:	cmp    rdi,rax
  40aa45:	je     40aa56 <__swc_fn_585f006d_000031_90860ff2+0x56>
  40aa47:	call   40cc30 <__swc_fn_585f006d_000127_8dffa290>
  40aa4c:	mov    rax,rdi
  40aa4f:	add    rsp,0x8
  40aa53:	pop    rdi
  40aa54:	pop    rsi
  40aa55:	ret
  40aa56:	mov    rax,rcx
  40aa59:	add    rsp,0x8
  40aa5d:	pop    rdi
  40aa5e:	pop    rsi
  40aa5f:	ret

000000000040aa60 <__swc_fn_585f006d_000034_25f19556>:
  40aa60:	sub    rsp,0x8
  40aa64:	vxorps xmm0,xmm0,xmm0
  40aa68:	xor    eax,eax
  40aa6a:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa74:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa7e:	xchg   ax,ax
  40aa80:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40aa85:	add    rax,0x10
  40aa89:	cmp    rax,0x2b00
  40aa90:	jne    40aa80 <__swc_fn_585f006d_000034_25f19556+0x20>
  40aa92:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40aa9c:	xor    al,al
  40aa9e:	mov    rdx,rax
  40aaa1:	xor    al,al
  40aaa3:	mov    r8,rax
  40aaa6:	xor    al,al
  40aaa8:	mov    r9,rax
  40aaab:	xor    al,al
  40aaad:	mov    r10,rax
  40aab0:	xor    al,al
  40aab2:	mov    r11,rax
  40aab5:	call   40df10 <__swc_fn_585f006d_000035_95622a2b>
  40aaba:	add    rsp,0x8
  40aabe:	ret
	...

000000000040aac0 <__swc_fn_585f006d_000037_b4982903>:
  40aac0:	push   rsi
  40aac1:	push   rdi
  40aac2:	push   r12
  40aac4:	mov    rsi,r8
  40aac7:	mov    rdi,rdx
  40aaca:	mov    rcx,rdx
  40aacd:	call   40daa0 <__swc_fn_585f006d_000002_884bb5c0>
  40aad2:	mov    r12,rax
  40aad5:	test   rax,rax
  40aad8:	jne    40aae1 <__swc_fn_585f006d_000037_b4982903+0x21>
  40aada:	xor    eax,eax
  40aadc:	pop    r12
  40aade:	pop    rdi
  40aadf:	pop    rsi
  40aae0:	ret
  40aae1:	mov    rcx,r12
  40aae4:	mov    rdx,rsi
  40aae7:	call   4072a0 <__swc_fn_585f006d_000003_7ab4792e>
  40aaec:	test   al,al
  40aaee:	jne    40ab02 <__swc_fn_585f006d_000037_b4982903+0x42>
  40aaf0:	mov    rcx,r12
  40aaf3:	mov    rdx,rdi
  40aaf6:	call   40fd40 <__swc_fn_585f006d_000113_49b378a9>
  40aafb:	xor    eax,eax
  40aafd:	pop    r12
  40aaff:	pop    rdi
  40ab00:	pop    rsi
  40ab01:	ret
  40ab02:	mov    rax,r12
  40ab05:	pop    r12
  40ab07:	pop    rdi
  40ab08:	pop    rsi
  40ab09:	ret
	...

000000000040ab20 <__swc_fn_585f006d_000040_6895916d>:
  40ab20:	push   rsi
  40ab21:	push   rdi
  40ab22:	push   r12
  40ab24:	mov    rsi,rcx
  40ab27:	mov    edx,0x9b8
  40ab2c:	call   40df80 <__swc_fn_585f006d_000038_788ceb38>
  40ab31:	mov    rdi,rax
  40ab34:	test   rax,rax
  40ab37:	jne    40ab40 <__swc_fn_585f006d_000040_6895916d+0x20>
  40ab39:	xor    eax,eax
  40ab3b:	pop    r12
  40ab3d:	pop    rdi
  40ab3e:	pop    rsi
  40ab3f:	ret
  40ab40:	vxorps xmm0,xmm0,xmm0
  40ab44:	xor    eax,eax
  40ab46:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab50:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab5a:	nop    WORD PTR [rax+rax*1+0x0]
  40ab60:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40ab65:	add    rax,0x10
  40ab69:	cmp    rax,0x9b0
  40ab70:	jne    40ab60 <__swc_fn_585f006d_000040_6895916d+0x40>
  40ab72:	mov    QWORD PTR [rdi+0x9b0],0x0
  40ab7d:	mov    QWORD PTR [rdi],rsi
  40ab80:	call   40cce0 <__swc_fn_585f006d_000130_c1196dfb>
  40ab85:	mov    QWORD PTR [rdi+0x18],rax
  40ab89:	lea    r12,[rsi+0x10]
  40ab8d:	mov    rcx,r12
  40ab90:	call   4098c0 <__swc_fn_585f006d_000135_e3032dc2>
  40ab95:	mov    rax,QWORD PTR [rsi+0x20]
  40ab99:	mov    QWORD PTR [rdi+0x8],rax
  40ab9d:	mov    rax,QWORD PTR [rsi+0x20]
  40aba1:	test   rax,rax
  40aba4:	je     40abaa <__swc_fn_585f006d_000040_6895916d+0x8a>
  40aba6:	mov    QWORD PTR [rax+0x10],rdi
  40abaa:	mov    QWORD PTR [rsi+0x20],rdi
  40abae:	mov    rcx,r12
  40abb1:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  40abb6:	mov    rax,rdi
  40abb9:	pop    r12
  40abbb:	pop    rdi
  40abbc:	pop    rsi
  40abbd:	ret
	...

000000000040abc0 <__swc_fn_585f006d_000043_957e4917>:
  40abc0:	mov    rax,QWORD PTR [rdx+0x10]
  40abc4:	test   rax,rax
  40abc7:	je     40abd3 <__swc_fn_585f006d_000043_957e4917+0x13>
  40abc9:	mov    rcx,QWORD PTR [rdx+0x8]
  40abcd:	mov    QWORD PTR [rax+0x8],rcx
  40abd1:	jmp    40abdb <__swc_fn_585f006d_000043_957e4917+0x1b>
  40abd3:	mov    rax,QWORD PTR [rdx+0x8]
  40abd7:	mov    QWORD PTR [rcx+0x20],rax
  40abdb:	mov    rax,QWORD PTR [rdx+0x8]
  40abdf:	test   rax,rax
  40abe2:	je     40abec <__swc_fn_585f006d_000043_957e4917+0x2c>
  40abe4:	mov    rcx,QWORD PTR [rdx+0x10]
  40abe8:	mov    QWORD PTR [rax+0x10],rcx
  40abec:	vxorps xmm0,xmm0,xmm0
  40abf0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40abf5:	ret
	...

000000000040ac00 <__swc_fn_585f006d_000046_88f44774>:
  40ac00:	sub    rsp,0x8
  40ac04:	mov    r9,r8
  40ac07:	mov    r10,rdx
  40ac0a:	call   40e030 <__swc_fn_585f006d_000044_9c2ade9b>
  40ac0f:	mov    eax,0x1
  40ac14:	xchg   DWORD PTR [r9+0x6c],eax
  40ac18:	mov    rax,QWORD PTR [r9+0x60]
  40ac1c:	test   rax,rax
  40ac1f:	je     40ac63 <__swc_fn_585f006d_000046_88f44774+0x63>
  40ac21:	xor    eax,eax
  40ac23:	xchg   DWORD PTR [r9+0x6c],eax
  40ac27:	movzx  eax,BYTE PTR [r9+0x39]
  40ac2c:	lea    rax,[rax+rax*4]
  40ac30:	lea    rax,[r10+rax*8+0x28]
  40ac35:	mov    QWORD PTR [r9+0x50],0x0
  40ac3d:	mov    rcx,QWORD PTR [rax+0x8]
  40ac41:	mov    QWORD PTR [r9+0x48],rcx
  40ac45:	mov    rcx,QWORD PTR [rax+0x8]
  40ac49:	test   rcx,rcx
  40ac4c:	je     40ac54 <__swc_fn_585f006d_000046_88f44774+0x54>
  40ac4e:	mov    QWORD PTR [rcx+0x50],r9
  40ac52:	jmp    40ac58 <__swc_fn_585f006d_000046_88f44774+0x58>
  40ac54:	mov    QWORD PTR [rax+0x10],r9
  40ac58:	mov    QWORD PTR [rax+0x8],r9
  40ac5c:	xor    eax,eax
  40ac5e:	add    rsp,0x8
  40ac62:	ret
  40ac63:	movzx  eax,BYTE PTR [r9+0x39]
  40ac68:	lea    rax,[rax+rax*4]
  40ac6c:	lea    rax,[r10+rax*8+0x28]
  40ac71:	mov    QWORD PTR [r9+0x50],0x0
  40ac79:	mov    rcx,QWORD PTR [rax+0x18]
  40ac7d:	mov    QWORD PTR [r9+0x48],rcx
  40ac81:	mov    rcx,QWORD PTR [rax+0x18]
  40ac85:	test   rcx,rcx
  40ac88:	je     40ac8e <__swc_fn_585f006d_000046_88f44774+0x8e>
  40ac8a:	mov    QWORD PTR [rcx+0x50],r9
  40ac8e:	mov    QWORD PTR [rax+0x18],r9
  40ac92:	mov    eax,0x1
  40ac97:	add    rsp,0x8
  40ac9b:	ret
  40ac9c:	add    BYTE PTR [rax],al
	...

000000000040aca0 <__swc_fn_585f006d_000049_2ff013cc>:
  40aca0:	push   r12
  40aca2:	push   r13
  40aca4:	push   rdi
  40aca5:	push   rsi
  40aca6:	push   r14
  40aca8:	push   r15
  40acaa:	sub    rsp,0x178
  40acb1:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40acba:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40acc3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40accc:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40acd5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40acde:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40ace7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40acf0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40acf9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40ad02:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40ad0b:	mov    r12,rcx
  40ad0e:	lea    rax,[rip+0x184eb]        # 423200 <__swc_bss_base_585f006d+0x1c0>
  40ad15:	mov    rcx,QWORD PTR [rax]
  40ad18:	mov    r13,rcx
  40ad1b:	test   rcx,rcx
  40ad1e:	jne    40ad2e <__swc_fn_585f006d_000049_2ff013cc+0x8e>
  40ad20:	mov    r13d,0x1dcd6500
  40ad26:	mov    ecx,0x1dcd6500
  40ad2b:	xchg   QWORD PTR [rax],rcx
  40ad2e:	lea    rax,[rip+0x162cb]        # 421000 <__swc_data_base_585f006d>
  40ad35:	mov    rax,QWORD PTR [rax]
  40ad38:	cmp    rax,0xffffffffffffffff
  40ad3c:	je     40ad4b <__swc_fn_585f006d_000049_2ff013cc+0xab>
  40ad3e:	mov    eax,eax
  40ad40:	mov    edi,eax
  40ad42:	xor    eax,eax
  40ad44:	call   407000 <pthread_getspecific@plt>
  40ad49:	jmp    40ad4d <__swc_fn_585f006d_000049_2ff013cc+0xad>
  40ad4b:	xor    eax,eax
  40ad4d:	test   rax,rax
  40ad50:	jne    40ad5f <__swc_fn_585f006d_000049_2ff013cc+0xbf>
  40ad52:	call   40aa00 <__swc_fn_585f006d_000031_90860ff2>
  40ad57:	mov    rcx,rax
  40ad5a:	call   4100a0 <__swc_fn_585f006d_000128_41c3251c>
  40ad5f:	test   rax,rax
  40ad62:	je     40ad74 <__swc_fn_585f006d_000049_2ff013cc+0xd4>
  40ad64:	cmp    QWORD PTR [rax],r12
  40ad67:	jne    40ad74 <__swc_fn_585f006d_000049_2ff013cc+0xd4>
  40ad69:	cmp    DWORD PTR [rax+0x20],0x0
  40ad6d:	jne    40ad74 <__swc_fn_585f006d_000049_2ff013cc+0xd4>
  40ad6f:	mov    rsi,rax
  40ad72:	jmp    40ad76 <__swc_fn_585f006d_000049_2ff013cc+0xd6>
  40ad74:	xor    esi,esi
  40ad76:	lea    rdi,[r12+0x2a88]
  40ad7e:	mov    r14,QWORD PTR [rdi]
  40ad81:	test   r14,r14
  40ad84:	jne    40add3 <__swc_fn_585f006d_000049_2ff013cc+0x133>
  40ad86:	lea    rax,[rip+0x182cb]        # 423058 <__swc_bss_base_585f006d+0x18>
  40ad8d:	mov    rax,QWORD PTR [rax]
  40ad90:	test   rax,rax
  40ad93:	setne  al
  40ad96:	jne    40adba <__swc_fn_585f006d_000049_2ff013cc+0x11a>
  40ad98:	mov    rax,QWORD PTR [r12+0x2a70]
  40ada0:	test   rax,rax
  40ada3:	setne  al
  40ada6:	jne    40adba <__swc_fn_585f006d_000049_2ff013cc+0x11a>
  40ada8:	test   rsi,rsi
  40adab:	setne  al
  40adae:	je     40adba <__swc_fn_585f006d_000049_2ff013cc+0x11a>
  40adb0:	cmp    DWORD PTR [rsi+0x730],0x0
  40adb7:	setne  al
  40adba:	test   al,al
  40adbc:	je     40adce <__swc_fn_585f006d_000049_2ff013cc+0x12e>
  40adbe:	call   410150 <__swc_fn_585f006d_000131_944f555b>
  40adc3:	lea    rcx,[rax+r13*1]
  40adc7:	xor    eax,eax
  40adc9:	lock cmpxchg QWORD PTR [rdi],rcx
  40adce:	jmp    40aed3 <__swc_fn_585f006d_000049_2ff013cc+0x233>
  40add3:	call   410150 <__swc_fn_585f006d_000131_944f555b>
  40add8:	mov    r15,rax
  40addb:	cmp    rax,r14
  40adde:	jb     40adef <__swc_fn_585f006d_000049_2ff013cc+0x14f>
  40ade0:	xor    ecx,ecx
  40ade2:	mov    rax,r14
  40ade5:	lock cmpxchg QWORD PTR [rdi],rcx
  40adea:	cmp    rax,r14
  40aded:	je     40adf4 <__swc_fn_585f006d_000049_2ff013cc+0x154>
  40adef:	jmp    40aed3 <__swc_fn_585f006d_000049_2ff013cc+0x233>
  40adf4:	test   rsi,rsi
  40adf7:	je     40ae12 <__swc_fn_585f006d_000049_2ff013cc+0x172>
  40adf9:	cmp    r15,r13
  40adfc:	jb     40ae12 <__swc_fn_585f006d_000049_2ff013cc+0x172>
  40adfe:	mov    rax,r15
  40ae01:	sub    rax,r13
  40ae04:	mov    rcx,r12
  40ae07:	mov    rdx,rsi
  40ae0a:	mov    r8,rax
  40ae0d:	call   40e470 <__swc_fn_585f006d_000059_3ca3ac64>
  40ae12:	lea    rsi,[r12+0x10]
  40ae17:	mov    rcx,rsi
  40ae1a:	call   4098c0 <__swc_fn_585f006d_000135_e3032dc2>
  40ae1f:	mov    rax,QWORD PTR [r12+0x18]
  40ae24:	mov    rdi,rax
  40ae27:	test   rdi,rdi
  40ae2a:	je     40ae54 <__swc_fn_585f006d_000049_2ff013cc+0x1b4>
  40ae2c:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae36:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae40:	mov    rcx,rdi
  40ae43:	call   407470 <__swc_fn_585f006d_000015_07eb9884>
  40ae48:	mov    rax,QWORD PTR [rdi+0x10]
  40ae4c:	mov    rdi,rax
  40ae4f:	test   rax,rax
  40ae52:	jne    40ae40 <__swc_fn_585f006d_000049_2ff013cc+0x1a0>
  40ae54:	mov    rcx,rsi
  40ae57:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  40ae5c:	mov    rcx,r12
  40ae5f:	call   4098c0 <__swc_fn_585f006d_000135_e3032dc2>
  40ae64:	xor    esi,esi
  40ae66:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae70:	mov    rax,QWORD PTR [r12+0x2a70]
  40ae78:	cmp    rsi,rax
  40ae7b:	jae    40aecb <__swc_fn_585f006d_000049_2ff013cc+0x22b>
  40ae7d:	lea    rax,[rsi+rsi*4]
  40ae81:	lea    rax,[r12+rax*8+0x268]
  40ae89:	mov    r8,QWORD PTR [rax]
  40ae8c:	mov    r9,QWORD PTR [rax+0x8]
  40ae90:	mov    r10,QWORD PTR [rax+0x10]
  40ae94:	mov    rax,QWORD PTR [rax+0x20]
  40ae98:	cmp    rax,r15
  40ae9b:	jae    40aea8 <__swc_fn_585f006d_000049_2ff013cc+0x208>
  40ae9d:	mov    rcx,r15
  40aea0:	sub    rcx,rax
  40aea3:	cmp    rcx,r13
  40aea6:	jae    40aead <__swc_fn_585f006d_000049_2ff013cc+0x20d>
  40aea8:	inc    rsi
  40aeab:	jmp    40ae70 <__swc_fn_585f006d_000049_2ff013cc+0x1d0>
  40aead:	mov    rcx,r12
  40aeb0:	mov    rdx,rsi
  40aeb3:	call   40e420 <__swc_fn_585f006d_000056_38b21f11>
  40aeb8:	mov    rcx,r12
  40aebb:	mov    rdx,r8
  40aebe:	mov    r8,r9
  40aec1:	mov    r9,r10
  40aec4:	call   407750 <__swc_fn_585f006d_000039_40d1e569>
  40aec9:	jmp    40ae70 <__swc_fn_585f006d_000049_2ff013cc+0x1d0>
  40aecb:	mov    rcx,r12
  40aece:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  40aed3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40aedc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40aee5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40aeee:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40aef7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40af00:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40af09:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40af12:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40af1b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40af24:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40af2d:	add    rsp,0x178
  40af34:	pop    r15
  40af36:	pop    r14
  40af38:	pop    rsi
  40af39:	pop    rdi
  40af3a:	pop    r13
  40af3c:	pop    r12
  40af3e:	ret
	...

000000000040af40 <__swc_fn_585f006d_000052_c7484fb0>:
  40af40:	lea    rax,[rdx-0x58]
  40af44:	ret
	...

000000000040af50 <__swc_fn_585f006d_000055_81f7713d>:
  40af50:	push   rsi
  40af51:	push   rdi
  40af52:	push   r12
  40af54:	push   r13
  40af56:	sub    rsp,0x68
  40af5a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40af60:	mov    rsi,r9
  40af63:	mov    rdi,rcx
  40af66:	mov    r12,rdx
  40af69:	mov    r13,r8
  40af6c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40af74:	jne    40af83 <__swc_fn_585f006d_000055_81f7713d+0x33>
  40af76:	xor    eax,eax
  40af78:	add    rsp,0x68
  40af7c:	pop    r13
  40af7e:	pop    r12
  40af80:	pop    rdi
  40af81:	pop    rsi
  40af82:	ret
  40af83:	mov    rcx,rdi
  40af86:	call   4098c0 <__swc_fn_585f006d_000135_e3032dc2>
  40af8b:	movabs rax,0x7fffffffffffffff
  40af95:	cmp    r12,rax
  40af98:	mov    rax,0xffffffffffffffff
  40af9f:	lea    rcx,[r12+r12*1]
  40afa3:	cmovbe rax,rcx
  40afa7:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40afae:	mov    rdx,rcx
  40afb1:	sub    rax,r12
  40afb4:	inc    rax
  40afb7:	xor    r8d,r8d
  40afba:	test   rcx,rcx
  40afbd:	jbe    40afe8 <__swc_fn_585f006d_000055_81f7713d+0x98>
  40afbf:	nop
  40afc0:	lea    r9,[r8+r8*4]
  40afc4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40afcc:	sub    r9,r12
  40afcf:	cmp    r9,rax
  40afd2:	jae    40afdf <__swc_fn_585f006d_000055_81f7713d+0x8f>
  40afd4:	mov    rdx,r8
  40afd7:	mov    rax,r9
  40afda:	test   r9,r9
  40afdd:	je     40afe8 <__swc_fn_585f006d_000055_81f7713d+0x98>
  40afdf:	add    r8,0x1
  40afe3:	cmp    r8,rcx
  40afe6:	jb     40afc0 <__swc_fn_585f006d_000055_81f7713d+0x70>
  40afe8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40afef:	cmp    rdx,rax
  40aff2:	jne    40b00f <__swc_fn_585f006d_000055_81f7713d+0xbf>
  40aff4:	mov    rcx,rdi
  40aff7:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  40affc:	xor    eax,eax
  40affe:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b004:	add    rsp,0x68
  40b008:	pop    r13
  40b00a:	pop    r12
  40b00c:	pop    rdi
  40b00d:	pop    rsi
  40b00e:	ret
  40b00f:	lea    rax,[rdx+rdx*4]
  40b013:	lea    rax,[rdi+rax*8+0x268]
  40b01b:	vmovups xmm6,XMMWORD PTR [rax]
  40b01f:	mov    r8,QWORD PTR [rax+0x10]
  40b023:	mov    rcx,rdi
  40b026:	call   40e420 <__swc_fn_585f006d_000056_38b21f11>
  40b02b:	vpshufd xmm0,xmm6,0xee
  40b030:	vmovsd QWORD PTR [r13+0x0],xmm0
  40b036:	mov    QWORD PTR [rsi],r8
  40b039:	mov    rcx,rdi
  40b03c:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  40b041:	vmovq  rax,xmm6
  40b046:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b04c:	add    rsp,0x68
  40b050:	pop    r13
  40b052:	pop    r12
  40b054:	pop    rdi
  40b055:	pop    rsi
  40b056:	ret
	...

000000000040b060 <__swc_fn_585f006d_000058_8bd8d1d5>:
  40b060:	push   r12
  40b062:	push   r13
  40b064:	push   r14
  40b066:	push   r15
  40b068:	push   rdi
  40b069:	push   rsi
  40b06a:	sub    rsp,0x148
  40b071:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b07a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b083:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b08c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b095:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b09e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b0a7:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b0b0:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b0b9:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b0c2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b0cb:	mov    r12,r9
  40b0ce:	mov    r13,rcx
  40b0d1:	mov    r14,rdx
  40b0d4:	mov    r15,r8
  40b0d7:	test   rdx,rdx
  40b0da:	jne    40b0ee <__swc_fn_585f006d_000058_8bd8d1d5+0x8e>
  40b0dc:	add    rsp,0x148
  40b0e3:	pop    rsi
  40b0e4:	pop    rdi
  40b0e5:	pop    r15
  40b0e7:	pop    r14
  40b0e9:	pop    r13
  40b0eb:	pop    r12
  40b0ed:	ret
  40b0ee:	cmp    r12,0x200000
  40b0f5:	ja     40b187 <__swc_fn_585f006d_000058_8bd8d1d5+0x127>
  40b0fb:	lea    rax,[rip+0x15efe]        # 421000 <__swc_data_base_585f006d>
  40b102:	mov    rax,QWORD PTR [rax]
  40b105:	cmp    rax,0xffffffffffffffff
  40b109:	je     40b118 <__swc_fn_585f006d_000058_8bd8d1d5+0xb8>
  40b10b:	mov    eax,eax
  40b10d:	mov    edi,eax
  40b10f:	xor    eax,eax
  40b111:	call   407000 <pthread_getspecific@plt>
  40b116:	jmp    40b11a <__swc_fn_585f006d_000058_8bd8d1d5+0xba>
  40b118:	xor    eax,eax
  40b11a:	test   rax,rax
  40b11d:	je     40b124 <__swc_fn_585f006d_000058_8bd8d1d5+0xc4>
  40b11f:	mov    rsi,rax
  40b122:	jmp    40b134 <__swc_fn_585f006d_000058_8bd8d1d5+0xd4>
  40b124:	call   40aa00 <__swc_fn_585f006d_000031_90860ff2>
  40b129:	mov    rcx,rax
  40b12c:	call   4100a0 <__swc_fn_585f006d_000128_41c3251c>
  40b131:	mov    rsi,rax
  40b134:	test   rsi,rsi
  40b137:	je     40b187 <__swc_fn_585f006d_000058_8bd8d1d5+0x127>
  40b139:	cmp    QWORD PTR [rsi],r13
  40b13c:	jne    40b187 <__swc_fn_585f006d_000058_8bd8d1d5+0x127>
  40b13e:	cmp    DWORD PTR [rsi+0x20],0x0
  40b142:	jne    40b187 <__swc_fn_585f006d_000058_8bd8d1d5+0x127>
  40b144:	cmp    DWORD PTR [rsi+0x730],0x10
  40b14b:	jae    40b187 <__swc_fn_585f006d_000058_8bd8d1d5+0x127>
  40b14d:	mov    eax,DWORD PTR [rsi+0x730]
  40b153:	lea    rdi,[rax+rax*4]
  40b157:	lea    rdi,[rsi+rdi*8+0x738]
  40b15f:	mov    QWORD PTR [rdi],r14
  40b162:	mov    QWORD PTR [rdi+0x8],r15
  40b166:	mov    QWORD PTR [rdi+0x10],r12
  40b16a:	mov    QWORD PTR [rdi+0x18],0x0
  40b172:	call   410150 <__swc_fn_585f006d_000131_944f555b>
  40b177:	mov    QWORD PTR [rdi+0x20],rax
  40b17b:	add    DWORD PTR [rsi+0x730],0x1
  40b182:	jmp    40b2e6 <__swc_fn_585f006d_000058_8bd8d1d5+0x286>
  40b187:	mov    rcx,r13
  40b18a:	call   407e90 <__swc_fn_585f006d_000057_5b81d8b6>
  40b18f:	mov    rsi,rax
  40b192:	cmp    r12,rax
  40b195:	jbe    40b1ca <__swc_fn_585f006d_000058_8bd8d1d5+0x16a>
  40b197:	cmp    r12,0x10000000
  40b19e:	seta   al
  40b1a1:	ja     40b1b0 <__swc_fn_585f006d_000058_8bd8d1d5+0x150>
  40b1a3:	mov    rax,QWORD PTR [r13+0x2a70]
  40b1aa:	test   rax,rax
  40b1ad:	setne  al
  40b1b0:	test   al,al
  40b1b2:	je     40b1ca <__swc_fn_585f006d_000058_8bd8d1d5+0x16a>
  40b1b4:	mov    rcx,r13
  40b1b7:	mov    rdx,r14
  40b1ba:	mov    r8,r15
  40b1bd:	mov    r9,r12
  40b1c0:	call   407750 <__swc_fn_585f006d_000039_40d1e569>
  40b1c5:	jmp    40b2e6 <__swc_fn_585f006d_000058_8bd8d1d5+0x286>
  40b1ca:	call   410150 <__swc_fn_585f006d_000131_944f555b>
  40b1cf:	mov    rdi,rax
  40b1d2:	mov    rcx,r13
  40b1d5:	call   4098c0 <__swc_fn_585f006d_000135_e3032dc2>
  40b1da:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b1e2:	je     40b29a <__swc_fn_585f006d_000058_8bd8d1d5+0x23a>
  40b1e8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b1f0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b1fb:	jae    40b210 <__swc_fn_585f006d_000058_8bd8d1d5+0x1b0>
  40b1fd:	mov    rax,QWORD PTR [r13+0x2a68]
  40b204:	add    rax,r12
  40b207:	cmp    rax,rsi
  40b20a:	jbe    40b29a <__swc_fn_585f006d_000058_8bd8d1d5+0x23a>
  40b210:	xor    eax,eax
  40b212:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b219:	mov    edx,0x1
  40b21e:	cmp    rcx,0x1
  40b222:	jbe    40b259 <__swc_fn_585f006d_000058_8bd8d1d5+0x1f9>
  40b224:	cs nop WORD PTR [rax+rax*1+0x0]
  40b22e:	xchg   ax,ax
  40b230:	lea    r8,[rdx+rdx*4]
  40b234:	lea    r8,[r13+r8*8+0x268]
  40b23c:	lea    r9,[rax+rax*4]
  40b240:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b248:	cmp    QWORD PTR [r8+0x18],r9
  40b24c:	cmovb  rax,rdx
  40b250:	add    rdx,0x1
  40b254:	cmp    rdx,rcx
  40b257:	jb     40b230 <__swc_fn_585f006d_000058_8bd8d1d5+0x1d0>
  40b259:	lea    rcx,[rax+rax*4]
  40b25d:	lea    rcx,[r13+rcx*8+0x268]
  40b265:	mov    r8,QWORD PTR [rcx]
  40b268:	mov    r9,QWORD PTR [rcx+0x8]
  40b26c:	mov    r10,QWORD PTR [rcx+0x10]
  40b270:	mov    rcx,r13
  40b273:	mov    rdx,rax
  40b276:	call   40e420 <__swc_fn_585f006d_000056_38b21f11>
  40b27b:	mov    rcx,r13
  40b27e:	mov    rdx,r8
  40b281:	mov    r8,r9
  40b284:	mov    r9,r10
  40b287:	call   407750 <__swc_fn_585f006d_000039_40d1e569>
  40b28c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b294:	jne    40b1f0 <__swc_fn_585f006d_000058_8bd8d1d5+0x190>
  40b29a:	add    QWORD PTR [r13+0x2a78],0x1
  40b2a2:	mov    rax,QWORD PTR [r13+0x2a70]
  40b2a9:	lea    rax,[rax+rax*4]
  40b2ad:	lea    rax,[r13+rax*8+0x268]
  40b2b5:	mov    QWORD PTR [rax],r14
  40b2b8:	mov    QWORD PTR [rax+0x8],r15
  40b2bc:	mov    QWORD PTR [rax+0x10],r12
  40b2c0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40b2c7:	mov    QWORD PTR [rax+0x18],rcx
  40b2cb:	mov    QWORD PTR [rax+0x20],rdi
  40b2cf:	add    QWORD PTR [r13+0x2a68],r12
  40b2d6:	add    QWORD PTR [r13+0x2a70],0x1
  40b2de:	mov    rcx,r13
  40b2e1:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  40b2e6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40b2ef:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40b2f8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40b301:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40b30a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40b313:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40b31c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40b325:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40b32e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40b337:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40b340:	add    rsp,0x148
  40b347:	pop    rsi
  40b348:	pop    rdi
  40b349:	pop    r15
  40b34b:	pop    r14
  40b34d:	pop    r13
  40b34f:	pop    r12
  40b351:	ret
	...

000000000040b360 <__swc_fn_585f006d_000061_0a7f67d9>:
  40b360:	push   rbx
  40b361:	push   r12
  40b363:	push   r13
  40b365:	push   r14
  40b367:	push   r15
  40b369:	push   rdi
  40b36a:	push   rsi
  40b36b:	sub    rsp,0xf0
  40b372:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40b378:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40b37e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40b384:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40b38a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40b393:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40b39c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40b3a5:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40b3ae:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40b3b7:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40b3c0:	mov    eax,r8d
  40b3c3:	mov    rbx,rcx
  40b3c6:	mov    r12,rdx
  40b3c9:	mov    QWORD PTR [rsp+0x18],rdx
  40b3ce:	mov    ecx,DWORD PTR [r12+0x58]
  40b3d3:	mov    r13d,ecx
  40b3d6:	cmp    ecx,0x10
  40b3d9:	mov    ecx,0x10
  40b3de:	cmovb  r13d,ecx
  40b3e2:	test   r13d,r13d
  40b3e5:	mov    rcx,r13
  40b3e8:	mov    edx,0x8
  40b3ed:	cmove  ecx,edx
  40b3f0:	dec    rcx
  40b3f3:	mov    rdx,0xffffffffffffffff
  40b3fa:	sub    rdx,rcx
  40b3fd:	xor    r14d,r14d
  40b400:	mov    r8,rcx
  40b403:	not    r8
  40b406:	lea    rcx,[rcx+0x58]
  40b40a:	and    rcx,r8
  40b40d:	cmp    rdx,0x58
  40b411:	cmovae r14,rcx
  40b415:	cmp    eax,0xffffffff
  40b418:	jne    40b421 <__swc_fn_585f006d_000061_0a7f67d9+0xc1>
  40b41a:	mov    r15,QWORD PTR [r12+0x48]
  40b41f:	jmp    40b453 <__swc_fn_585f006d_000061_0a7f67d9+0xf3>
  40b421:	test   eax,eax
  40b423:	jne    40b42c <__swc_fn_585f006d_000061_0a7f67d9+0xcc>
  40b425:	mov    eax,0x8
  40b42a:	jmp    40b450 <__swc_fn_585f006d_000061_0a7f67d9+0xf0>
  40b42c:	cmp    eax,0x8
  40b42f:	ja     40b437 <__swc_fn_585f006d_000061_0a7f67d9+0xd7>
  40b431:	shl    rax,0x4
  40b435:	jmp    40b450 <__swc_fn_585f006d_000061_0a7f67d9+0xf0>
  40b437:	lea    eax,[rax-0x9]
  40b43a:	mov    ecx,eax
  40b43c:	shr    ecx,0x2
  40b43f:	and    eax,0x3
  40b442:	lea    ecx,[rcx+0x7]
  40b445:	lea    ecx,[rcx-0x2]
  40b448:	lea    eax,[rax+0x5]
  40b44b:	shlx   rax,rax,rcx
  40b450:	mov    r15,rax
  40b453:	lea    rax,[r14+r13*1]
  40b457:	mov    rcx,0xffffffffffffffff
  40b45e:	sub    rcx,rax
  40b461:	cmp    r15,rcx
  40b464:	jbe    40b474 <__swc_fn_585f006d_000061_0a7f67d9+0x114>
  40b466:	mov    QWORD PTR [r12+0x40],0x0
  40b46f:	jmp    40b846 <__swc_fn_585f006d_000061_0a7f67d9+0x4e6>
  40b474:	mov    QWORD PTR [rsp+0x20],r13
  40b479:	lea    r13,[rsp+0x8]
  40b47e:	add    rax,r15
  40b481:	mov    ecx,0x1000
  40b486:	test   ecx,ecx
  40b488:	mov    edx,0x8
  40b48d:	cmove  ecx,edx
  40b490:	dec    rcx
  40b493:	mov    rdx,0xffffffffffffffff
  40b49a:	sub    rdx,rcx
  40b49d:	cmp    rax,rdx
  40b4a0:	jbe    40b4ac <__swc_fn_585f006d_000061_0a7f67d9+0x14c>
  40b4a2:	mov    QWORD PTR [r13+0x0],0x0
  40b4aa:	jmp    40b4b9 <__swc_fn_585f006d_000061_0a7f67d9+0x159>
  40b4ac:	add    rax,rcx
  40b4af:	andn   rax,rcx,rax
  40b4b4:	mov    QWORD PTR [rsp+0x8],rax
  40b4b9:	cmp    QWORD PTR [r13+0x0],0x0
  40b4be:	jne    40b4ce <__swc_fn_585f006d_000061_0a7f67d9+0x16e>
  40b4c0:	mov    QWORD PTR [r12+0x40],0x0
  40b4c9:	jmp    40b846 <__swc_fn_585f006d_000061_0a7f67d9+0x4e6>
  40b4ce:	mov    QWORD PTR [rsp+0x30],r15
  40b4d3:	xor    r15d,r15d
  40b4d6:	mov    QWORD PTR [rsp+0x38],0x0
  40b4df:	lea    r12,[rsp+0x10]
  40b4e4:	mov    QWORD PTR [rsp+0x28],r14
  40b4e9:	mov    r14,QWORD PTR [rsp+0x8]
  40b4ee:	mov    QWORD PTR [rsp+0x10],r14
  40b4f3:	cmp    r14,0x10000
  40b4fa:	ja     40b501 <__swc_fn_585f006d_000061_0a7f67d9+0x1a1>
  40b4fc:	mov    rax,r14
  40b4ff:	jmp    40b552 <__swc_fn_585f006d_000061_0a7f67d9+0x1f2>
  40b501:	xor    eax,eax
  40b503:	lea    rcx,[r14-0x1]
  40b507:	lzcnt  rax,rcx
  40b50c:	mov    ecx,0x3f
  40b511:	sub    rcx,rax
  40b514:	mov    eax,0x1
  40b519:	lea    rcx,[rcx-0x3]
  40b51d:	shl    rax,cl
  40b520:	mov    rcx,rax
  40b523:	cmp    rax,0x1000
  40b52a:	mov    eax,0x1000
  40b52f:	cmovb  rcx,rax
  40b533:	mov    rdx,0xffffffffffffffff
  40b53a:	sub    rdx,rcx
  40b53d:	mov    rax,r14
  40b540:	lea    r8,[r14+rcx*1-0x1]
  40b545:	neg    rcx
  40b548:	and    r8,rcx
  40b54b:	cmp    r14,rdx
  40b54e:	cmovbe rax,r8
  40b552:	mov    QWORD PTR [rsp+0x8],rax
  40b557:	lea    rax,[rip+0x15aa2]        # 421000 <__swc_data_base_585f006d>
  40b55e:	mov    rax,QWORD PTR [rax]
  40b561:	cmp    rax,0xffffffffffffffff
  40b565:	je     40b574 <__swc_fn_585f006d_000061_0a7f67d9+0x214>
  40b567:	mov    eax,eax
  40b569:	mov    edi,eax
  40b56b:	xor    eax,eax
  40b56d:	call   407000 <pthread_getspecific@plt>
  40b572:	jmp    40b576 <__swc_fn_585f006d_000061_0a7f67d9+0x216>
  40b574:	xor    eax,eax
  40b576:	test   rax,rax
  40b579:	jne    40b588 <__swc_fn_585f006d_000061_0a7f67d9+0x228>
  40b57b:	call   40aa00 <__swc_fn_585f006d_000031_90860ff2>
  40b580:	mov    rcx,rax
  40b583:	call   4100a0 <__swc_fn_585f006d_000128_41c3251c>
  40b588:	test   rax,rax
  40b58b:	je     40b67c <__swc_fn_585f006d_000061_0a7f67d9+0x31c>
  40b591:	cmp    QWORD PTR [rax],rbx
  40b594:	jne    40b67c <__swc_fn_585f006d_000061_0a7f67d9+0x31c>
  40b59a:	cmp    DWORD PTR [rax+0x20],0x0
  40b59e:	jne    40b67c <__swc_fn_585f006d_000061_0a7f67d9+0x31c>
  40b5a4:	mov    rcx,QWORD PTR [rsp+0x8]
  40b5a9:	movabs rdx,0x7fffffffffffffff
  40b5b3:	cmp    rcx,rdx
  40b5b6:	mov    rdx,0xffffffffffffffff
  40b5bd:	lea    r8,[rcx+rcx*1]
  40b5c1:	cmovbe rdx,r8
  40b5c5:	mov    r8d,DWORD PTR [rax+0x730]
  40b5cc:	mov    r9d,r8d
  40b5cf:	sub    rdx,rcx
  40b5d2:	inc    rdx
  40b5d5:	xor    r10d,r10d
  40b5d8:	test   r8,r8
  40b5db:	jbe    40b60b <__swc_fn_585f006d_000061_0a7f67d9+0x2ab>
  40b5dd:	nop    DWORD PTR [rax]
  40b5e0:	mov    r11d,r10d
  40b5e3:	lea    r11,[r11+r11*4]
  40b5e7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40b5ef:	sub    r11,rcx
  40b5f2:	cmp    r11,rdx
  40b5f5:	jae    40b602 <__swc_fn_585f006d_000061_0a7f67d9+0x2a2>
  40b5f7:	mov    r9d,r10d
  40b5fa:	mov    rdx,r11
  40b5fd:	test   r11,r11
  40b600:	je     40b60b <__swc_fn_585f006d_000061_0a7f67d9+0x2ab>
  40b602:	add    r10,0x1
  40b606:	cmp    r10,r8
  40b609:	jb     40b5e0 <__swc_fn_585f006d_000061_0a7f67d9+0x280>
  40b60b:	mov    ecx,DWORD PTR [rax+0x730]
  40b611:	cmp    r9d,ecx
  40b614:	jne    40b61a <__swc_fn_585f006d_000061_0a7f67d9+0x2ba>
  40b616:	xor    eax,eax
  40b618:	jmp    40b679 <__swc_fn_585f006d_000061_0a7f67d9+0x319>
  40b61a:	lea    rcx,[r9+r9*4]
  40b61e:	lea    rcx,[rax+rcx*8+0x738]
  40b626:	vmovups xmm0,XMMWORD PTR [rcx]
  40b62a:	mov    rdx,QWORD PTR [rcx+0x10]
  40b62e:	sub    DWORD PTR [rax+0x730],0x1
  40b635:	mov    r8d,DWORD PTR [rax+0x730]
  40b63c:	lea    r8,[r8+r8*4]
  40b640:	lea    r8,[rax+r8*8+0x738]
  40b648:	vmovups xmm1,XMMWORD PTR [r8]
  40b64d:	vmovups XMMWORD PTR [rcx],xmm1
  40b651:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40b657:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40b65c:	mov    rax,QWORD PTR [r8+0x20]
  40b660:	mov    QWORD PTR [rcx+0x20],rax
  40b664:	vpshufd xmm1,xmm0,0xee
  40b669:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40b66f:	mov    QWORD PTR [rsp+0x10],rdx
  40b674:	vmovq  rax,xmm0
  40b679:	mov    r15,rax
  40b67c:	test   r15,r15
  40b67f:	jne    40b697 <__swc_fn_585f006d_000061_0a7f67d9+0x337>
  40b681:	mov    rcx,rbx
  40b684:	mov    rdx,QWORD PTR [rsp+0x8]
  40b689:	mov    r8,r13
  40b68c:	mov    r9,r12
  40b68f:	call   40af50 <__swc_fn_585f006d_000055_81f7713d>
  40b694:	mov    r15,rax
  40b697:	test   r15,r15
  40b69a:	je     40b6db <__swc_fn_585f006d_000061_0a7f67d9+0x37b>
  40b69c:	cmp    QWORD PTR [r12],r14
  40b6a0:	jae    40b6db <__swc_fn_585f006d_000061_0a7f67d9+0x37b>
  40b6a2:	mov    rax,r15
  40b6a5:	add    rax,QWORD PTR [r12]
  40b6a9:	mov    rdx,r14
  40b6ac:	sub    rdx,QWORD PTR [r12]
  40b6b0:	mov    rcx,rax
  40b6b3:	call   4072a0 <__swc_fn_585f006d_000003_7ab4792e>
  40b6b8:	test   al,al
  40b6ba:	je     40b6c3 <__swc_fn_585f006d_000061_0a7f67d9+0x363>
  40b6bc:	mov    QWORD PTR [rsp+0x10],r14
  40b6c1:	jmp    40b6db <__swc_fn_585f006d_000061_0a7f67d9+0x37b>
  40b6c3:	mov    rcx,rbx
  40b6c6:	mov    rdx,r15
  40b6c9:	mov    r8,QWORD PTR [rsp+0x8]
  40b6ce:	mov    r9,QWORD PTR [rsp+0x10]
  40b6d3:	call   40b060 <__swc_fn_585f006d_000058_8bd8d1d5>
  40b6d8:	xor    r15d,r15d
  40b6db:	test   r15,r15
  40b6de:	jne    40b75a <__swc_fn_585f006d_000061_0a7f67d9+0x3fa>
  40b6e0:	cmp    r14,0x10000
  40b6e7:	ja     40b6ee <__swc_fn_585f006d_000061_0a7f67d9+0x38e>
  40b6e9:	mov    rax,r14
  40b6ec:	jmp    40b73f <__swc_fn_585f006d_000061_0a7f67d9+0x3df>
  40b6ee:	xor    eax,eax
  40b6f0:	lea    rcx,[r14-0x1]
  40b6f4:	lzcnt  rax,rcx
  40b6f9:	mov    ecx,0x3f
  40b6fe:	sub    rcx,rax
  40b701:	mov    eax,0x1
  40b706:	lea    rcx,[rcx-0x3]
  40b70a:	shl    rax,cl
  40b70d:	mov    rcx,rax
  40b710:	cmp    rax,0x1000
  40b717:	mov    eax,0x1000
  40b71c:	cmovb  rcx,rax
  40b720:	mov    rdx,0xffffffffffffffff
  40b727:	sub    rdx,rcx
  40b72a:	mov    rax,r14
  40b72d:	lea    r8,[r14+rcx*1-0x1]
  40b732:	neg    rcx
  40b735:	and    r8,rcx
  40b738:	cmp    r14,rdx
  40b73b:	cmovbe rax,r8
  40b73f:	mov    QWORD PTR [rsp+0x8],rax
  40b744:	mov    QWORD PTR [rsp+0x10],r14
  40b749:	mov    rcx,rbx
  40b74c:	mov    rdx,rax
  40b74f:	mov    r8,r14
  40b752:	call   40aac0 <__swc_fn_585f006d_000037_b4982903>
  40b757:	mov    r15,rax
  40b75a:	test   r15,r15
  40b75d:	jne    40b76b <__swc_fn_585f006d_000061_0a7f67d9+0x40b>
  40b75f:	mov    r13,QWORD PTR [rsp+0x20]
  40b764:	mov    rsi,QWORD PTR [rsp+0x38]
  40b769:	jmp    40b7a7 <__swc_fn_585f006d_000061_0a7f67d9+0x447>
  40b76b:	mov    rax,r15
  40b76e:	add    rax,QWORD PTR [rsp+0x28]
  40b773:	mov    r13,QWORD PTR [rsp+0x20]
  40b778:	test   r13d,r13d
  40b77b:	mov    rcx,r13
  40b77e:	mov    edx,0x8
  40b783:	cmove  ecx,edx
  40b786:	dec    rcx
  40b789:	mov    rdx,0xffffffffffffffff
  40b790:	sub    rdx,rcx
  40b793:	cmp    rax,rdx
  40b796:	jbe    40b79c <__swc_fn_585f006d_000061_0a7f67d9+0x43c>
  40b798:	xor    eax,eax
  40b79a:	jmp    40b7a4 <__swc_fn_585f006d_000061_0a7f67d9+0x444>
  40b79c:	add    rax,rcx
  40b79f:	andn   rax,rcx,rax
  40b7a4:	mov    rsi,rax
  40b7a7:	mov    rax,QWORD PTR [rsp+0x8]
  40b7ac:	test   r15,r15
  40b7af:	je     40b7b8 <__swc_fn_585f006d_000061_0a7f67d9+0x458>
  40b7b1:	mov    rdi,QWORD PTR [rsp+0x18]
  40b7b6:	jmp    40b7ca <__swc_fn_585f006d_000061_0a7f67d9+0x46a>
  40b7b8:	mov    rdi,QWORD PTR [rsp+0x18]
  40b7bd:	mov    QWORD PTR [rdi+0x40],0x0
  40b7c5:	jmp    40b846 <__swc_fn_585f006d_000061_0a7f67d9+0x4e6>
  40b7ca:	lea    rdx,[rsi-0x58]
  40b7ce:	mov    QWORD PTR [rsi-0x58],r15
  40b7d2:	mov    QWORD PTR [rsi-0x50],rax
  40b7d6:	mov    rax,QWORD PTR [rsp+0x10]
  40b7db:	mov    QWORD PTR [rsi-0x48],rax
  40b7df:	mov    QWORD PTR [rsi-0x40],rsi
  40b7e3:	mov    rax,QWORD PTR [rdi+0x48]
  40b7e7:	mov    QWORD PTR [rsi-0x38],rax
  40b7eb:	mov    rax,QWORD PTR [rsp+0x30]
  40b7f0:	mov    QWORD PTR [rsi-0x30],rax
  40b7f4:	mov    DWORD PTR [rsi-0x10],r13d
  40b7f8:	mov    QWORD PTR [rsi-0x28],0x0
  40b800:	mov    QWORD PTR [rsi-0x20],0x0
  40b808:	add    r15,QWORD PTR [r12]
  40b80c:	sub    r15,rsi
  40b80f:	mov    QWORD PTR [rsi-0x30],r15
  40b813:	mov    rcx,QWORD PTR [rbx+0x250]
  40b81a:	nop    WORD PTR [rax+rax*1+0x0]
  40b820:	lea    r8,[rcx+r15*1]
  40b824:	mov    rax,rcx
  40b827:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40b830:	cmp    rax,rcx
  40b833:	je     40b83a <__swc_fn_585f006d_000061_0a7f67d9+0x4da>
  40b835:	mov    rcx,rax
  40b838:	jmp    40b820 <__swc_fn_585f006d_000061_0a7f67d9+0x4c0>
  40b83a:	mov    rcx,rbx
  40b83d:	call   40e390 <__swc_fn_585f006d_000053_82546d94>
  40b842:	mov    QWORD PTR [rdi+0x40],rsi
  40b846:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40b84c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40b852:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40b858:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40b85e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40b867:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40b870:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40b879:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40b882:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40b88b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40b894:	add    rsp,0xf0
  40b89b:	pop    rsi
  40b89c:	pop    rdi
  40b89d:	pop    r15
  40b89f:	pop    r14
  40b8a1:	pop    r13
  40b8a3:	pop    r12
  40b8a5:	pop    rbx
  40b8a6:	ret
	...

000000000040b8b0 <__swc_fn_585f006d_000064_b0d63361>:
  40b8b0:	push   rbx
  40b8b1:	push   r12
  40b8b3:	push   rdi
  40b8b4:	push   rsi
  40b8b5:	sub    rsp,0xb8
  40b8bc:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40b8c2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40b8c8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40b8ce:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40b8d4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40b8da:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40b8e0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40b8e6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40b8ef:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40b8f8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40b901:	mov    rbx,rdx
  40b904:	mov    r12,rcx
  40b907:	cmp    DWORD PTR [rbx+0x58],0x0
  40b90b:	je     40b925 <__swc_fn_585f006d_000064_b0d63361+0x75>
  40b90d:	mov    eax,DWORD PTR [rbx+0x58]
  40b910:	sub    eax,0x1
  40b913:	test   DWORD PTR [rbx+0x58],eax
  40b916:	je     40b925 <__swc_fn_585f006d_000064_b0d63361+0x75>
  40b918:	mov    QWORD PTR [rbx+0x40],0x0
  40b920:	jmp    40bb37 <__swc_fn_585f006d_000064_b0d63361+0x287>
  40b925:	cmp    QWORD PTR [rbx+0x48],0x0
  40b92a:	jne    40b939 <__swc_fn_585f006d_000064_b0d63361+0x89>
  40b92c:	mov    QWORD PTR [rbx+0x40],0x0
  40b934:	jmp    40bb37 <__swc_fn_585f006d_000064_b0d63361+0x287>
  40b939:	lea    rax,[rsp+0x8]
  40b93e:	mov    rcx,QWORD PTR [rbx+0x48]
  40b942:	cmp    rcx,0x8
  40b946:	ja     40b950 <__swc_fn_585f006d_000064_b0d63361+0xa0>
  40b948:	mov    DWORD PTR [rax],0x0
  40b94e:	jmp    40b9ab <__swc_fn_585f006d_000064_b0d63361+0xfb>
  40b950:	cmp    rcx,0x80
  40b957:	ja     40b967 <__swc_fn_585f006d_000064_b0d63361+0xb7>
  40b959:	lea    rcx,[rcx+0xf]
  40b95d:	shr    rcx,0x4
  40b961:	mov    DWORD PTR [rsp+0x8],ecx
  40b965:	jmp    40b9ab <__swc_fn_585f006d_000064_b0d63361+0xfb>
  40b967:	cmp    rcx,0x10000
  40b96e:	jbe    40b978 <__swc_fn_585f006d_000064_b0d63361+0xc8>
  40b970:	mov    DWORD PTR [rax],0xffffffff
  40b976:	jmp    40b9ab <__swc_fn_585f006d_000064_b0d63361+0xfb>
  40b978:	dec    rcx
  40b97b:	xor    edx,edx
  40b97d:	lzcnt  rdx,rcx
  40b982:	mov    r8d,0x3f
  40b988:	sub    r8d,edx
  40b98b:	lea    edx,[r8-0x2]
  40b98f:	shrx   rcx,rcx,rdx
  40b994:	and    ecx,0x3
  40b997:	lea    edx,[r8-0x7]
  40b99b:	lea    edx,[rdx*4+0x0]
  40b9a2:	lea    edx,[rdx+0x9]
  40b9a5:	add    edx,ecx
  40b9a7:	mov    DWORD PTR [rsp+0x8],edx
  40b9ab:	cmp    DWORD PTR [rax],0x0
  40b9ae:	jne    40b9be <__swc_fn_585f006d_000064_b0d63361+0x10e>
  40b9b0:	cmp    DWORD PTR [rbx+0x58],0x8
  40b9b4:	jbe    40b9be <__swc_fn_585f006d_000064_b0d63361+0x10e>
  40b9b6:	mov    DWORD PTR [rsp+0x8],0x1
  40b9be:	cmp    DWORD PTR [rbx+0x58],0x10
  40b9c2:	jbe    40ba41 <__swc_fn_585f006d_000064_b0d63361+0x191>
  40b9c8:	cmp    DWORD PTR [rbx+0x58],0x40
  40b9cc:	ja     40ba41 <__swc_fn_585f006d_000064_b0d63361+0x191>
  40b9ce:	cmp    DWORD PTR [rax],0xffffffff
  40b9d1:	je     40ba41 <__swc_fn_585f006d_000064_b0d63361+0x191>
  40b9d3:	mov    ecx,DWORD PTR [rsp+0x8]
  40b9d7:	mov    edx,DWORD PTR [rbx+0x58]
  40b9da:	dec    rdx
  40b9dd:	cmp    ecx,0x2d
  40b9e0:	jae    40ba38 <__swc_fn_585f006d_000064_b0d63361+0x188>
  40b9e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b9ec:	nop    DWORD PTR [rax+0x0]
  40b9f0:	mov    r8d,ecx
  40b9f3:	test   ecx,ecx
  40b9f5:	jne    40b9ff <__swc_fn_585f006d_000064_b0d63361+0x14f>
  40b9f7:	mov    r8d,0x8
  40b9fd:	jmp    40ba2b <__swc_fn_585f006d_000064_b0d63361+0x17b>
  40b9ff:	cmp    r8d,0x8
  40ba03:	ja     40ba0b <__swc_fn_585f006d_000064_b0d63361+0x15b>
  40ba05:	shl    r8,0x4
  40ba09:	jmp    40ba2b <__swc_fn_585f006d_000064_b0d63361+0x17b>
  40ba0b:	lea    r8d,[r8-0x9]
  40ba0f:	mov    r9d,r8d
  40ba12:	shr    r9d,0x2
  40ba16:	and    r8d,0x3
  40ba1a:	lea    r9d,[r9+0x7]
  40ba1e:	lea    r9d,[r9-0x2]
  40ba22:	lea    r8d,[r8+0x5]
  40ba26:	shlx   r8,r8,r9
  40ba2b:	test   r8,rdx
  40ba2e:	je     40ba3d <__swc_fn_585f006d_000064_b0d63361+0x18d>
  40ba30:	add    ecx,0x1
  40ba33:	cmp    ecx,0x2d
  40ba36:	jb     40b9f0 <__swc_fn_585f006d_000064_b0d63361+0x140>
  40ba38:	mov    ecx,0xffffffff
  40ba3d:	mov    DWORD PTR [rsp+0x8],ecx
  40ba41:	mov    ecx,DWORD PTR [rsp+0x8]
  40ba45:	cmp    ecx,0xffffffff
  40ba48:	je     40ba50 <__swc_fn_585f006d_000064_b0d63361+0x1a0>
  40ba4a:	cmp    DWORD PTR [rbx+0x58],0x40
  40ba4e:	jbe    40ba63 <__swc_fn_585f006d_000064_b0d63361+0x1b3>
  40ba50:	mov    rcx,r12
  40ba53:	mov    rdx,rbx
  40ba56:	mov    r8d,DWORD PTR [rax]
  40ba59:	call   40b360 <__swc_fn_585f006d_000061_0a7f67d9>
  40ba5e:	jmp    40bb37 <__swc_fn_585f006d_000064_b0d63361+0x287>
  40ba63:	lea    rax,[rip+0x15596]        # 421000 <__swc_data_base_585f006d>
  40ba6a:	mov    rax,QWORD PTR [rax]
  40ba6d:	cmp    rax,0xffffffffffffffff
  40ba71:	je     40ba80 <__swc_fn_585f006d_000064_b0d63361+0x1d0>
  40ba73:	mov    eax,eax
  40ba75:	mov    edi,eax
  40ba77:	xor    eax,eax
  40ba79:	call   407000 <pthread_getspecific@plt>
  40ba7e:	jmp    40ba82 <__swc_fn_585f006d_000064_b0d63361+0x1d2>
  40ba80:	xor    eax,eax
  40ba82:	test   rax,rax
  40ba85:	jne    40ba94 <__swc_fn_585f006d_000064_b0d63361+0x1e4>
  40ba87:	call   40aa00 <__swc_fn_585f006d_000031_90860ff2>
  40ba8c:	mov    rcx,rax
  40ba8f:	call   4100a0 <__swc_fn_585f006d_000128_41c3251c>
  40ba94:	test   rax,rax
  40ba97:	je     40baa4 <__swc_fn_585f006d_000064_b0d63361+0x1f4>
  40ba99:	cmp    QWORD PTR [rax],r12
  40ba9c:	jne    40baa4 <__swc_fn_585f006d_000064_b0d63361+0x1f4>
  40ba9e:	cmp    DWORD PTR [rax+0x20],0x0
  40baa2:	je     40baaf <__swc_fn_585f006d_000064_b0d63361+0x1ff>
  40baa4:	mov    rcx,r12
  40baa7:	mov    rdx,rax
  40baaa:	call   40dfd0 <__swc_fn_585f006d_000041_414cc921>
  40baaf:	test   rax,rax
  40bab2:	jne    40babe <__swc_fn_585f006d_000064_b0d63361+0x20e>
  40bab4:	mov    QWORD PTR [rbx+0x40],0x0
  40babc:	jmp    40bb37 <__swc_fn_585f006d_000064_b0d63361+0x287>
  40babe:	lea    r8,[rsp+0xc]
  40bac3:	mov    ecx,DWORD PTR [rsp+0x8]
  40bac7:	mov    DWORD PTR [rsp+0xc],ecx
  40bacb:	mov    ecx,DWORD PTR [r8]
  40bace:	lea    rcx,[rcx+rcx*4]
  40bad2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40bad7:	test   rcx,rcx
  40bada:	je     40bb13 <__swc_fn_585f006d_000064_b0d63361+0x263>
  40badc:	mov    rdx,QWORD PTR [rcx]
  40badf:	test   rdx,rdx
  40bae2:	je     40baf0 <__swc_fn_585f006d_000064_b0d63361+0x240>
  40bae4:	mov    r9,QWORD PTR [rdx]
  40bae7:	mov    QWORD PTR [rcx],r9
  40baea:	add    DWORD PTR [rcx+0x28],0x1
  40baee:	jmp    40bb0e <__swc_fn_585f006d_000064_b0d63361+0x25e>
  40baf0:	mov    rdx,QWORD PTR [rcx+0x18]
  40baf4:	cmp    QWORD PTR [rcx+0x20],rdx
  40baf8:	jae    40bb0c <__swc_fn_585f006d_000064_b0d63361+0x25c>
  40bafa:	mov    rdx,QWORD PTR [rcx+0x20]
  40bafe:	mov    r9d,DWORD PTR [rcx+0x2c]
  40bb02:	add    QWORD PTR [rcx+0x20],r9
  40bb06:	add    DWORD PTR [rcx+0x28],0x1
  40bb0a:	jmp    40bb0e <__swc_fn_585f006d_000064_b0d63361+0x25e>
  40bb0c:	xor    edx,edx
  40bb0e:	test   rdx,rdx
  40bb11:	jne    40bb24 <__swc_fn_585f006d_000064_b0d63361+0x274>
  40bb13:	mov    rcx,r12
  40bb16:	mov    rdx,rax
  40bb19:	mov    r8d,DWORD PTR [r8]
  40bb1c:	call   40e140 <__swc_fn_585f006d_000050_ab8077df>
  40bb21:	mov    rdx,rax
  40bb24:	test   rdx,rdx
  40bb27:	jne    40bb33 <__swc_fn_585f006d_000064_b0d63361+0x283>
  40bb29:	mov    QWORD PTR [rbx+0x40],0x0
  40bb31:	jmp    40bb37 <__swc_fn_585f006d_000064_b0d63361+0x287>
  40bb33:	mov    QWORD PTR [rbx+0x40],rdx
  40bb37:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40bb3d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40bb43:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40bb49:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40bb4f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40bb55:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40bb5b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40bb61:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40bb6a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40bb73:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40bb7c:	add    rsp,0xb8
  40bb83:	pop    rsi
  40bb84:	pop    rdi
  40bb85:	pop    r12
  40bb87:	pop    rbx
  40bb88:	ret
  40bb89:	add    BYTE PTR [rax],al
  40bb8b:	add    BYTE PTR [rax],al
  40bb8d:	add    BYTE PTR [rax],al
	...

000000000040bb90 <__swc_fn_585f006d_000067_94a51053>:
  40bb90:	ret
	...

000000000040bba0 <__swc_fn_585f006d_000070_3181d86c>:
  40bba0:	push   r12
  40bba2:	push   r13
  40bba4:	push   r14
  40bba6:	push   rdi
  40bba7:	push   rsi
  40bba8:	sub    rsp,0x1a0
  40bbaf:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40bbb8:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40bbc1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40bbca:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40bbd3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40bbdc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40bbe5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40bbee:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40bbf7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40bc00:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40bc09:	mov    r12,rdx
  40bc0c:	mov    r13,rcx
  40bc0f:	mov    rax,QWORD PTR [r12+0x48]
  40bc14:	mov    ecx,DWORD PTR [r12+0x58]
  40bc19:	lea    rdx,[rax-0x1]
  40bc1d:	cmp    rdx,0x10000
  40bc24:	jae    40bd1e <__swc_fn_585f006d_000070_3181d86c+0x17e>
  40bc2a:	cmp    rax,0x8
  40bc2e:	ja     40bc35 <__swc_fn_585f006d_000070_3181d86c+0x95>
  40bc30:	xor    r14d,r14d
  40bc33:	jmp    40bc87 <__swc_fn_585f006d_000070_3181d86c+0xe7>
  40bc35:	cmp    rax,0x80
  40bc3c:	ja     40bc48 <__swc_fn_585f006d_000070_3181d86c+0xa8>
  40bc3e:	lea    r14,[rax+0xf]
  40bc42:	shr    r14,0x4
  40bc46:	jmp    40bc87 <__swc_fn_585f006d_000070_3181d86c+0xe7>
  40bc48:	cmp    rax,0x10000
  40bc4f:	jbe    40bc59 <__swc_fn_585f006d_000070_3181d86c+0xb9>
  40bc51:	mov    r14d,0xffffffff
  40bc57:	jmp    40bc87 <__swc_fn_585f006d_000070_3181d86c+0xe7>
  40bc59:	xor    eax,eax
  40bc5b:	lzcnt  rax,rdx
  40bc60:	mov    r8d,0x3f
  40bc66:	sub    r8d,eax
  40bc69:	lea    eax,[r8-0x2]
  40bc6d:	shrx   rax,rdx,rax
  40bc72:	and    eax,0x3
  40bc75:	lea    edx,[r8-0x7]
  40bc79:	lea    edx,[rdx*4+0x0]
  40bc80:	lea    edx,[rdx+0x9]
  40bc83:	lea    r14d,[rdx+rax*1]
  40bc87:	cmp    ecx,0x8
  40bc8a:	jbe    40bca3 <__swc_fn_585f006d_000070_3181d86c+0x103>
  40bc8c:	cmp    ecx,0x10
  40bc8f:	jne    40bd1e <__swc_fn_585f006d_000070_3181d86c+0x17e>
  40bc95:	test   r14d,r14d
  40bc98:	mov    eax,0x1
  40bc9d:	cmove  r14d,eax
  40bca1:	jmp    40bcaa <__swc_fn_585f006d_000070_3181d86c+0x10a>
  40bca3:	lea    eax,[rcx-0x1]
  40bca6:	test   eax,ecx
  40bca8:	jne    40bd1e <__swc_fn_585f006d_000070_3181d86c+0x17e>
  40bcaa:	lea    rax,[rip+0x1534f]        # 421000 <__swc_data_base_585f006d>
  40bcb1:	mov    rax,QWORD PTR [rax]
  40bcb4:	cmp    rax,0xffffffffffffffff
  40bcb8:	je     40bcc7 <__swc_fn_585f006d_000070_3181d86c+0x127>
  40bcba:	mov    eax,eax
  40bcbc:	mov    edi,eax
  40bcbe:	xor    eax,eax
  40bcc0:	call   407000 <pthread_getspecific@plt>
  40bcc5:	jmp    40bcc9 <__swc_fn_585f006d_000070_3181d86c+0x129>
  40bcc7:	xor    eax,eax
  40bcc9:	test   rax,rax
  40bccc:	je     40bd1e <__swc_fn_585f006d_000070_3181d86c+0x17e>
  40bcce:	cmp    QWORD PTR [rax],r13
  40bcd1:	jne    40bd1e <__swc_fn_585f006d_000070_3181d86c+0x17e>
  40bcd3:	lea    rcx,[r14+r14*4]
  40bcd7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40bcdc:	test   rax,rax
  40bcdf:	je     40bd1e <__swc_fn_585f006d_000070_3181d86c+0x17e>
  40bce1:	mov    rcx,QWORD PTR [rax]
  40bce4:	test   rcx,rcx
  40bce7:	je     40bcf5 <__swc_fn_585f006d_000070_3181d86c+0x155>
  40bce9:	mov    rdx,QWORD PTR [rcx]
  40bcec:	mov    QWORD PTR [rax],rdx
  40bcef:	add    DWORD PTR [rax+0x28],0x1
  40bcf3:	jmp    40bd12 <__swc_fn_585f006d_000070_3181d86c+0x172>
  40bcf5:	mov    rcx,QWORD PTR [rax+0x18]
  40bcf9:	cmp    QWORD PTR [rax+0x20],rcx
  40bcfd:	jae    40bd10 <__swc_fn_585f006d_000070_3181d86c+0x170>
  40bcff:	mov    rcx,QWORD PTR [rax+0x20]
  40bd03:	mov    edx,DWORD PTR [rax+0x2c]
  40bd06:	add    QWORD PTR [rax+0x20],rdx
  40bd0a:	add    DWORD PTR [rax+0x28],0x1
  40bd0e:	jmp    40bd12 <__swc_fn_585f006d_000070_3181d86c+0x172>
  40bd10:	xor    ecx,ecx
  40bd12:	test   rcx,rcx
  40bd15:	je     40bd1e <__swc_fn_585f006d_000070_3181d86c+0x17e>
  40bd17:	mov    QWORD PTR [r12+0x40],rcx
  40bd1c:	jmp    40bd29 <__swc_fn_585f006d_000070_3181d86c+0x189>
  40bd1e:	mov    rcx,r13
  40bd21:	mov    rdx,r12
  40bd24:	call   40ebc0 <__swc_fn_585f006d_000071_0d1ef36f>
  40bd29:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40bd32:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40bd3b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40bd44:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40bd4d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40bd56:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40bd5f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40bd68:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40bd71:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40bd7a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40bd83:	add    rsp,0x1a0
  40bd8a:	pop    rsi
  40bd8b:	pop    rdi
  40bd8c:	pop    r14
  40bd8e:	pop    r13
  40bd90:	pop    r12
  40bd92:	ret
	...

000000000040bda0 <__swc_fn_585f006d_000073_c6c71bf7>:
  40bda0:	push   r12
  40bda2:	push   r13
  40bda4:	push   r14
  40bda6:	push   r15
  40bda8:	push   rdi
  40bda9:	push   rsi
  40bdaa:	sub    rsp,0x188
  40bdb1:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40bdba:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40bdc3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40bdcc:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40bdd5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40bdde:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40bde7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40bdf0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40bdf9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40be02:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40be0b:	mov    r12,rdx
  40be0e:	mov    r13,rcx
  40be11:	mov    r14,QWORD PTR [r12+0x40]
  40be16:	lea    rax,[rip+0x17253]        # 423070 <__swc_bss_base_585f006d+0x30>
  40be1d:	mov    rcx,r14
  40be20:	sub    rcx,QWORD PTR [rax+0x8]
  40be24:	mov    rax,QWORD PTR [rip+0x17255]        # 423080 <__swc_bss_base_585f006d+0x40>
  40be2b:	cmp    rcx,rax
  40be2e:	jae    40be5a <__swc_fn_585f006d_000073_c6c71bf7+0xba>
  40be30:	mov    rax,r14
  40be33:	and    rax,0xffffffffffc00000
  40be3a:	mov    rcx,r14
  40be3d:	shr    rcx,0x10
  40be41:	and    ecx,0x3f
  40be44:	mov    edx,DWORD PTR [rax+0x28]
  40be47:	shrx   ecx,ecx,edx
  40be4c:	shl    rcx,0x4
  40be50:	lea    r15,[rax+rcx*8+0x80]
  40be58:	jmp    40be65 <__swc_fn_585f006d_000073_c6c71bf7+0xc5>
  40be5a:	mov    rcx,r14
  40be5d:	call   40a930 <__swc_fn_585f006d_000022_3a2e2048>
  40be62:	mov    r15,rax
  40be65:	test   r15,r15
  40be68:	je     40bf0f <__swc_fn_585f006d_000073_c6c71bf7+0x16f>
  40be6e:	lea    rax,[rip+0x1518b]        # 421000 <__swc_data_base_585f006d>
  40be75:	mov    rax,QWORD PTR [rax]
  40be78:	cmp    rax,0xffffffffffffffff
  40be7c:	je     40be8b <__swc_fn_585f006d_000073_c6c71bf7+0xeb>
  40be7e:	mov    eax,eax
  40be80:	mov    edi,eax
  40be82:	xor    eax,eax
  40be84:	call   407000 <pthread_getspecific@plt>
  40be89:	jmp    40be8d <__swc_fn_585f006d_000073_c6c71bf7+0xed>
  40be8b:	xor    eax,eax
  40be8d:	mov    rcx,QWORD PTR [r15+0x40]
  40be91:	cmp    rcx,rax
  40be94:	jne    40bef4 <__swc_fn_585f006d_000073_c6c71bf7+0x154>
  40be96:	test   rax,rax
  40be99:	je     40bf0f <__swc_fn_585f006d_000073_c6c71bf7+0x16f>
  40be9b:	mov    ecx,DWORD PTR [r15+0x6c]
  40be9f:	test   ecx,ecx
  40bea1:	je     40bec1 <__swc_fn_585f006d_000073_c6c71bf7+0x121>
  40bea3:	mov    rcx,r13
  40bea6:	mov    rdx,rax
  40bea9:	mov    r8,r15
  40beac:	mov    QWORD PTR [rsp+0xd8],rax
  40beb4:	call   40e0d0 <__swc_fn_585f006d_000047_bc5ec610>
  40beb9:	mov    rax,QWORD PTR [rsp+0xd8]
  40bec1:	mov    rcx,QWORD PTR [r15]
  40bec4:	mov    QWORD PTR [r14],rcx
  40bec7:	mov    QWORD PTR [r15],r14
  40beca:	sub    DWORD PTR [r15+0x28],0x1
  40becf:	jne    40bf04 <__swc_fn_585f006d_000073_c6c71bf7+0x164>
  40bed1:	movzx  ecx,BYTE PTR [r15+0x39]
  40bed6:	lea    rcx,[rcx+rcx*4]
  40beda:	lea    rcx,[rax+rcx*8+0x28]
  40bedf:	cmp    QWORD PTR [rcx],r15
  40bee2:	je     40bf04 <__swc_fn_585f006d_000073_c6c71bf7+0x164>
  40bee4:	mov    rcx,r13
  40bee7:	mov    rdx,rax
  40beea:	mov    r8,r15
  40beed:	call   407d80 <__swc_fn_585f006d_000051_f7021588>
  40bef2:	jmp    40bf04 <__swc_fn_585f006d_000073_c6c71bf7+0x164>
  40bef4:	test   rcx,rcx
  40bef7:	je     40bf0f <__swc_fn_585f006d_000073_c6c71bf7+0x16f>
  40bef9:	mov    rcx,r15
  40befc:	mov    rdx,r14
  40beff:	call   40a570 <__swc_fn_585f006d_000010_395bb04b>
  40bf04:	mov    QWORD PTR [r12+0x40],0x0
  40bf0d:	jmp    40bf1a <__swc_fn_585f006d_000073_c6c71bf7+0x17a>
  40bf0f:	mov    rcx,r13
  40bf12:	mov    rdx,r12
  40bf15:	call   40ebe0 <__swc_fn_585f006d_000074_518516c2>
  40bf1a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40bf23:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40bf2c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40bf35:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40bf3e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40bf47:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40bf50:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40bf59:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40bf62:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40bf6b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40bf74:	add    rsp,0x188
  40bf7b:	pop    rsi
  40bf7c:	pop    rdi
  40bf7d:	pop    r15
  40bf7f:	pop    r14
  40bf81:	pop    r13
  40bf83:	pop    r12
  40bf85:	ret
	...

000000000040bf90 <__swc_fn_585f006d_000076_9f0c6acf>:
  40bf90:	sub    rsp,0x8
  40bf94:	mov    rax,rdx
  40bf97:	mov    rdx,QWORD PTR [rax+0x40]
  40bf9b:	mov    r8,rax
  40bf9e:	call   40bb90 <__swc_fn_585f006d_000067_94a51053>
  40bfa3:	add    rsp,0x8
  40bfa7:	ret
	...

000000000040bfb0 <__swc_fn_585f006d_000079_34776ded>:
  40bfb0:	push   rsi
  40bfb1:	push   rdi
  40bfb2:	sub    rsp,0x8
  40bfb6:	cmp    rcx,0xffffffffffffffef
  40bfba:	ja     40bfe0 <__swc_fn_585f006d_000079_34776ded+0x30>
  40bfbc:	xor    esi,esi
  40bfbe:	lea    rax,[rcx+0x100f]
  40bfc5:	and    rax,0xfffffffffffff000
  40bfcc:	lea    rcx,[rcx+0x10]
  40bfd0:	cmp    rcx,0xfffffffffffff000
  40bfd7:	cmovbe rsi,rax
  40bfdb:	test   rsi,rsi
  40bfde:	jne    40bfe9 <__swc_fn_585f006d_000079_34776ded+0x39>
  40bfe0:	xor    eax,eax
  40bfe2:	add    rsp,0x8
  40bfe6:	pop    rdi
  40bfe7:	pop    rsi
  40bfe8:	ret
  40bfe9:	mov    rcx,rsi
  40bfec:	call   40c640 <__swc_fn_585f006d_000109_8d425bd3>
  40bff1:	mov    rdi,rax
  40bff4:	test   rax,rax
  40bff7:	jne    40c002 <__swc_fn_585f006d_000079_34776ded+0x52>
  40bff9:	xor    eax,eax
  40bffb:	add    rsp,0x8
  40bfff:	pop    rdi
  40c000:	pop    rsi
  40c001:	ret
  40c002:	mov    rcx,rdi
  40c005:	mov    rdx,rsi
  40c008:	call   409260 <__swc_fn_585f006d_000111_b25e3a45>
  40c00d:	test   al,al
  40c00f:	jne    40c025 <__swc_fn_585f006d_000079_34776ded+0x75>
  40c011:	mov    rcx,rdi
  40c014:	mov    rdx,rsi
  40c017:	call   40fd40 <__swc_fn_585f006d_000113_49b378a9>
  40c01c:	xor    eax,eax
  40c01e:	add    rsp,0x8
  40c022:	pop    rdi
  40c023:	pop    rsi
  40c024:	ret
  40c025:	mov    QWORD PTR [rdi],rsi
  40c028:	mov    QWORD PTR [rdi+0x8],0x0
  40c030:	lea    rax,[rdi+0x10]
  40c034:	add    rsp,0x8
  40c038:	pop    rdi
  40c039:	pop    rsi
  40c03a:	ret
  40c03b:	add    BYTE PTR [rax],al
  40c03d:	add    BYTE PTR [rax],al
	...

000000000040c040 <__swc_fn_585f006d_000082_754dcd57>:
  40c040:	sub    rsp,0x8
  40c044:	cmp    BYTE PTR [rcx+0x2c],0x10
  40c048:	jne    40c053 <__swc_fn_585f006d_000082_754dcd57+0x13>
  40c04a:	test   DWORD PTR [rcx+0x28],0x80
  40c051:	je     40c05b <__swc_fn_585f006d_000082_754dcd57+0x1b>
  40c053:	mov    rax,rcx
  40c056:	add    rsp,0x8
  40c05a:	ret
  40c05b:	mov    rcx,QWORD PTR [rcx+0x40]
  40c05f:	call   40c040 <__swc_fn_585f006d_000082_754dcd57>
  40c064:	add    rsp,0x8
  40c068:	ret
	...

000000000040c080 <__swc_fn_585f006d_000085_1edf7c76>:
  40c080:	push   rsi
  40c081:	push   rdi
  40c082:	push   r12
  40c084:	push   r13
  40c086:	sub    rsp,0x8
  40c08a:	mov    rsi,rdx
  40c08d:	mov    rdi,rcx
  40c090:	xor    r8d,r8d
  40c093:	call   4085a0 <__swc_fn_585f006d_000090_a2d50c23>
  40c098:	test   al,al
  40c09a:	je     40c0ac <__swc_fn_585f006d_000085_1edf7c76+0x2c>
  40c09c:	mov    eax,0x1
  40c0a1:	add    rsp,0x8
  40c0a5:	pop    r13
  40c0a7:	pop    r12
  40c0a9:	pop    rdi
  40c0aa:	pop    rsi
  40c0ab:	ret
  40c0ac:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c0b1:	je     40c0c0 <__swc_fn_585f006d_000085_1edf7c76+0x40>
  40c0b3:	xor    eax,eax
  40c0b5:	add    rsp,0x8
  40c0b9:	pop    r13
  40c0bb:	pop    r12
  40c0bd:	pop    rdi
  40c0be:	pop    rsi
  40c0bf:	ret
  40c0c0:	mov    r12,QWORD PTR [rsi+0x98]
  40c0c7:	mov    rax,QWORD PTR [rsi+0xa0]
  40c0ce:	mov    rsi,rax
  40c0d1:	xor    r13d,r13d
  40c0d4:	test   rsi,rsi
  40c0d7:	je     40c134 <__swc_fn_585f006d_000085_1edf7c76+0xb4>
  40c0d9:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0e3:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0ed:	nop    DWORD PTR [rax]
  40c0f0:	lea    rax,[r13*8+0x0]
  40c0f8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c0fd:	mov    rcx,rax
  40c100:	call   40c040 <__swc_fn_585f006d_000082_754dcd57>
  40c105:	cmp    BYTE PTR [rax+0x2c],0xe
  40c109:	jne    40c12a <__swc_fn_585f006d_000085_1edf7c76+0xaa>
  40c10b:	mov    rcx,rdi
  40c10e:	mov    rdx,rax
  40c111:	call   40c080 <__swc_fn_585f006d_000085_1edf7c76>
  40c116:	test   al,al
  40c118:	je     40c12a <__swc_fn_585f006d_000085_1edf7c76+0xaa>
  40c11a:	mov    eax,0x1
  40c11f:	add    rsp,0x8
  40c123:	pop    r13
  40c125:	pop    r12
  40c127:	pop    rdi
  40c128:	pop    rsi
  40c129:	ret
  40c12a:	add    r13,0x1
  40c12e:	sub    rsi,0x1
  40c132:	jne    40c0f0 <__swc_fn_585f006d_000085_1edf7c76+0x70>
  40c134:	xor    eax,eax
  40c136:	add    rsp,0x8
  40c13a:	pop    r13
  40c13c:	pop    r12
  40c13e:	pop    rdi
  40c13f:	pop    rsi
  40c140:	ret
	...

000000000040c150 <__swc_fn_585f006d_000088_fcb34f6a>:
  40c150:	sub    rsp,0x18
  40c154:	vxorps xmm0,xmm0,xmm0
  40c158:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c15d:	call   40edf0 <__swc_fn_585f006d_000089_386582f3>
  40c162:	add    rsp,0x18
  40c166:	ret
	...

000000000040c170 <__swc_fn_585f006d_000091_3d2f5a0d>:
  40c170:	sub    rsp,0x8
  40c174:	mov    rcx,QWORD PTR [rip+0x19bc5]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c17b:	test   rcx,rcx
  40c17e:	jne    40c190 <__swc_fn_585f006d_000091_3d2f5a0d+0x20>
  40c180:	call   40a1d0 <__swc_fn_585f006d_000165_cf398896>
  40c185:	lea    rcx,[rax+0x1]
  40c189:	mov    QWORD PTR [rip+0x19bb0],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c190:	dec    rcx
  40c193:	call   411b60 <__swc_fn_585f006d_000167_fce60b2b>
  40c198:	mov    rax,QWORD PTR [rax+0xc0]
  40c19f:	and    eax,0x1
  40c1a2:	setne  al
  40c1a5:	add    rsp,0x8
  40c1a9:	ret
	...

000000000040c1c0 <__swc_fn_585f006d_000094_14db3cf9>:
  40c1c0:	push   rbx
  40c1c1:	push   rsi
  40c1c2:	push   rdi
  40c1c3:	push   r12
  40c1c5:	sub    rsp,0x28
  40c1c9:	mov    rbx,rcx
  40c1cc:	call   408900 <__swc_fn_585f006d_000093_f8c16535>
  40c1d1:	mov    rcx,QWORD PTR [rip+0x19b68]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c1d8:	test   rcx,rcx
  40c1db:	jne    40c1ed <__swc_fn_585f006d_000094_14db3cf9+0x2d>
  40c1dd:	call   40a1d0 <__swc_fn_585f006d_000165_cf398896>
  40c1e2:	lea    rcx,[rax+0x1]
  40c1e6:	mov    QWORD PTR [rip+0x19b53],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c1ed:	dec    rcx
  40c1f0:	call   411b60 <__swc_fn_585f006d_000167_fce60b2b>
  40c1f5:	mov    rsi,rax
  40c1f8:	lea    rcx,[rsp+0x8]
  40c1fd:	call   40f230 <__swc_fn_585f006d_000092_8252f8c0>
  40c202:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c209:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c210:	lea    rcx,[rsi+0x10]
  40c214:	call   40d1a0 <__swc_fn_585f006d_000157_232ffa22>
  40c219:	mov    rcx,rsi
  40c21c:	call   40f3a0 <__swc_fn_585f006d_000101_eab3874f>
  40c221:	vxorps xmm0,xmm0,xmm0
  40c225:	xor    eax,eax
  40c227:	cs nop WORD PTR [rax+rax*1+0x0]
  40c231:	cs nop WORD PTR [rax+rax*1+0x0]
  40c23b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c240:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c245:	add    rax,0x10
  40c249:	cmp    rax,0xbf0
  40c250:	jne    40c240 <__swc_fn_585f006d_000094_14db3cf9+0x80>
  40c252:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c258:	vmovups XMMWORD PTR [rsi],xmm0
  40c25c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c262:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c26a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c271:	mov    QWORD PTR [rsi+0xbe8],r12
  40c278:	mov    rcx,QWORD PTR [rip+0x19ac1]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c27f:	test   rcx,rcx
  40c282:	jne    40c294 <__swc_fn_585f006d_000094_14db3cf9+0xd4>
  40c284:	call   40a1d0 <__swc_fn_585f006d_000165_cf398896>
  40c289:	lea    rcx,[rax+0x1]
  40c28d:	mov    QWORD PTR [rip+0x19aac],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c294:	dec    rcx
  40c297:	call   411b60 <__swc_fn_585f006d_000167_fce60b2b>
  40c29c:	mov    rsi,rax
  40c29f:	mov    QWORD PTR [rsi+0xc0],rbx
  40c2a6:	and    ebx,0x1
  40c2a9:	jne    40c2ad <__swc_fn_585f006d_000094_14db3cf9+0xed>
  40c2ab:	xor    eax,eax
  40c2ad:	test   rbx,rbx
  40c2b0:	sete   al
  40c2b3:	xor    cl,cl
  40c2b5:	xor    dl,dl
  40c2b7:	xor    r8b,r8b
  40c2ba:	xor    r9b,r9b
  40c2bd:	xor    r10b,r10b
  40c2c0:	mov    r11,rax
  40c2c3:	call   40ebf0 <__swc_fn_585f006d_000077_8b8614a7>
  40c2c8:	lea    rbx,[rsp+0x18]
  40c2cd:	mov    rcx,rbx
  40c2d0:	call   40f230 <__swc_fn_585f006d_000092_8252f8c0>
  40c2d5:	lea    rcx,[rsi+0x10]
  40c2d9:	mov    edx,0x400000
  40c2de:	mov    r8,rbx
  40c2e1:	call   409f10 <__swc_fn_585f006d_000159_d8afac28>
  40c2e6:	lea    rcx,[rsi+0x68]
  40c2ea:	mov    edx,0x4000
  40c2ef:	mov    r8,rbx
  40c2f2:	call   409f10 <__swc_fn_585f006d_000159_d8afac28>
  40c2f7:	add    rsp,0x28
  40c2fb:	pop    r12
  40c2fd:	pop    rdi
  40c2fe:	pop    rsi
  40c2ff:	pop    rbx
  40c300:	ret
	...

000000000040c310 <__swc_fn_585f006d_000097_4c97e0db>:
  40c310:	push   rbx
  40c311:	push   rsi
  40c312:	sub    rsp,0x18
  40c316:	mov    rbx,rcx
  40c319:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c31e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c324:	mov    rsi,QWORD PTR [rbx+0x70]
  40c328:	lea    rcx,[rcx+0x18]
  40c32c:	call   40d1a0 <__swc_fn_585f006d_000157_232ffa22>
  40c331:	lea    rcx,[rsp+0x8]
  40c336:	mov    rdx,rbx
  40c339:	mov    r8d,0x78
  40c33f:	call   408960 <__swc_fn_585f006d_000096_ad982b35>
  40c344:	mov    rax,rsi
  40c347:	add    rsp,0x18
  40c34b:	pop    rsi
  40c34c:	pop    rbx
  40c34d:	ret
	...

000000000040c350 <__swc_fn_585f006d_000100_3ed08774>:
  40c350:	push   rsi
  40c351:	push   rdi
  40c352:	sub    rsp,0x8
  40c356:	cmp    QWORD PTR [rcx],0x0
  40c35a:	jne    40c363 <__swc_fn_585f006d_000100_3ed08774+0x13>
  40c35c:	add    rsp,0x8
  40c360:	pop    rdi
  40c361:	pop    rsi
  40c362:	ret
  40c363:	mov    rsi,QWORD PTR [rcx]
  40c366:	mov    rax,QWORD PTR [rcx+0x8]
  40c36a:	test   rax,rax
  40c36d:	je     40c383 <__swc_fn_585f006d_000100_3ed08774+0x33>
  40c36f:	test   DWORD PTR [rax+0x28],0x400000
  40c376:	je     40c383 <__swc_fn_585f006d_000100_3ed08774+0x33>
  40c378:	mov    rcx,QWORD PTR [rax+0x30]
  40c37c:	test   rcx,rcx
  40c37f:	cmovne rax,rcx
  40c383:	lea    rdx,[rip+0x5e46]        # 4121d0 <__swc_rdata_base_585f006d+0xc0>
  40c38a:	lea    rcx,[rip+0x5f27]        # 4122b8 <__swc_rdata_base_585f006d+0x1a8>
  40c391:	mov    r8,rax
  40c394:	xor    r9d,r9d
  40c397:	xor    al,al
  40c399:	mov    r10,rax
  40c39c:	xor    r11d,r11d
  40c39f:	call   40c150 <__swc_fn_585f006d_000088_fcb34f6a>
  40c3a4:	test   rax,rax
  40c3a7:	je     40c3b7 <__swc_fn_585f006d_000100_3ed08774+0x67>
  40c3a9:	mov    rdi,QWORD PTR [rax+0x48]
  40c3ad:	test   rdi,rdi
  40c3b0:	je     40c3b7 <__swc_fn_585f006d_000100_3ed08774+0x67>
  40c3b2:	mov    rcx,rsi
  40c3b5:	call   rdi
  40c3b7:	add    rsp,0x8
  40c3bb:	pop    rdi
  40c3bc:	pop    rsi
  40c3bd:	ret
	...

000000000040c3c0 <__swc_fn_585f006d_000103_67100064>:
  40c3c0:	push   rbx
  40c3c1:	push   rsi
  40c3c2:	push   rdi
  40c3c3:	sub    rsp,0x20
  40c3c7:	mov    rbx,rdx
  40c3ca:	mov    rsi,rcx
  40c3cd:	mov    rcx,QWORD PTR [rip+0x1996c]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c3d4:	test   rcx,rcx
  40c3d7:	jne    40c3e9 <__swc_fn_585f006d_000103_67100064+0x29>
  40c3d9:	call   40a1d0 <__swc_fn_585f006d_000165_cf398896>
  40c3de:	lea    rcx,[rax+0x1]
  40c3e2:	mov    QWORD PTR [rip+0x19957],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c3e9:	dec    rcx
  40c3ec:	call   411b60 <__swc_fn_585f006d_000167_fce60b2b>
  40c3f1:	mov    rdi,rax
  40c3f4:	mov    rax,QWORD PTR [rdi+0xbd0]
  40c3fb:	xor    ecx,ecx
  40c3fd:	test   rax,rax
  40c400:	je     40c405 <__swc_fn_585f006d_000103_67100064+0x45>
  40c402:	mov    rcx,QWORD PTR [rax]
  40c405:	call   40a300 <__swc_fn_585f006d_000174_176517f9>
  40c40a:	lea    rax,[rsp+0x8]
  40c40f:	lea    rcx,[rdi+0x9c8]
  40c416:	mov    QWORD PTR [rsp+0x8],rcx
  40c41b:	mov    QWORD PTR [rax+0x8],0x40
  40c423:	xor    ecx,ecx
  40c425:	mov    rdx,rax
  40c428:	call   40fe80 <__swc_fn_585f006d_000119_9175a56a>
  40c42d:	mov    DWORD PTR [rdi+0xbc8],eax
  40c433:	mov    rdi,QWORD PTR [rdi+0x990]
  40c43a:	test   rdi,rdi
  40c43d:	je     40c447 <__swc_fn_585f006d_000103_67100064+0x87>
  40c43f:	mov    rcx,rsi
  40c442:	mov    rdx,rbx
  40c445:	call   rdi
  40c447:	call   40c170 <__swc_fn_585f006d_000091_3d2f5a0d>
  40c44c:	test   al,al
  40c44e:	je     40c45e <__swc_fn_585f006d_000103_67100064+0x9e>
  40c450:	mov    rcx,rsi
  40c453:	mov    rdx,rbx
  40c456:	xor    r8d,r8d
  40c459:	call   409400 <__swc_fn_585f006d_000120_ea68f292>
  40c45e:	mov    rcx,rsi
  40c461:	mov    rdx,rbx
  40c464:	call   408a80 <__swc_fn_585f006d_000102_e9fdc18e>
  40c469:	call   40c9f0 <__swc_fn_585f006d_000118_7f430081>
  40c46e:	add    rsp,0x20
  40c472:	pop    rdi
  40c473:	pop    rsi
  40c474:	pop    rbx
  40c475:	ret
	...

000000000040c480 <__swc_fn_585f006d_000106_ed4b1681>:
  40c480:	test   r8,r8
  40c483:	jne    40c488 <__swc_fn_585f006d_000106_ed4b1681+0x8>
  40c485:	xor    eax,eax
  40c487:	ret
  40c488:	xor    eax,eax
  40c48a:	nop    WORD PTR [rax+rax*1+0x0]
  40c490:	mov    r9,r8
  40c493:	sub    r9,rax
  40c496:	cmp    r9,0x10
  40c49a:	jb     40c4e4 <__swc_fn_585f006d_000106_ed4b1681+0x64>
  40c49c:	lea    r9,[rcx+rax*1]
  40c4a0:	lea    r10,[rdx+rax*1]
  40c4a4:	vmovups xmm0,XMMWORD PTR [r10]
  40c4a9:	vmovups xmm1,XMMWORD PTR [r9]
  40c4ae:	vpcmpeqb xmm0,xmm1,xmm0
  40c4b2:	vpmovmskb r9d,xmm0
  40c4b6:	cmp    r9d,0xffff
  40c4bd:	je     40c4de <__swc_fn_585f006d_000106_ed4b1681+0x5e>
  40c4bf:	not    r9d
  40c4c2:	xor    r8d,r8d
  40c4c5:	movzx  r9d,r9w
  40c4c9:	tzcnt  r8d,r9d
  40c4ce:	add    rax,r8
  40c4d1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4d5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4d9:	sub    ecx,eax
  40c4db:	mov    eax,ecx
  40c4dd:	ret
  40c4de:	lea    rax,[rax+0x10]
  40c4e2:	jmp    40c490 <__swc_fn_585f006d_000106_ed4b1681+0x10>
  40c4e4:	cmp    r9,0x8
  40c4e8:	jb     40c55b <__swc_fn_585f006d_000106_ed4b1681+0xdb>
  40c4ea:	lea    r9,[rcx+rax*1]
  40c4ee:	lea    r10,[rdx+rax*1]
  40c4f2:	mov    r9,QWORD PTR [r9]
  40c4f5:	xor    r9,QWORD PTR [r10]
  40c4f8:	test   r9,r9
  40c4fb:	je     40c519 <__swc_fn_585f006d_000106_ed4b1681+0x99>
  40c4fd:	xor    r8d,r8d
  40c500:	tzcnt  r8,r9
  40c505:	shr    r8,0x3
  40c509:	add    rax,r8
  40c50c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c510:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c514:	sub    ecx,eax
  40c516:	mov    eax,ecx
  40c518:	ret
  40c519:	lea    rax,[rax+0x8]
  40c51d:	cmp    rax,r8
  40c520:	jne    40c525 <__swc_fn_585f006d_000106_ed4b1681+0xa5>
  40c522:	xor    eax,eax
  40c524:	ret
  40c525:	lea    rax,[r8-0x8]
  40c529:	lea    r8,[rcx+rax*1]
  40c52d:	lea    r9,[rdx+rax*1]
  40c531:	mov    r8,QWORD PTR [r8]
  40c534:	xor    r8,QWORD PTR [r9]
  40c537:	test   r8,r8
  40c53a:	je     40c558 <__swc_fn_585f006d_000106_ed4b1681+0xd8>
  40c53c:	xor    r9d,r9d
  40c53f:	tzcnt  r9,r8
  40c544:	shr    r9,0x3
  40c548:	add    rax,r9
  40c54b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c54f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c553:	sub    ecx,eax
  40c555:	mov    eax,ecx
  40c557:	ret
  40c558:	xor    eax,eax
  40c55a:	ret
  40c55b:	cmp    r9,0x4
  40c55f:	jb     40c5d2 <__swc_fn_585f006d_000106_ed4b1681+0x152>
  40c561:	lea    r9,[rcx+rax*1]
  40c565:	lea    r10,[rdx+rax*1]
  40c569:	mov    r9d,DWORD PTR [r9]
  40c56c:	xor    r9d,DWORD PTR [r10]
  40c56f:	test   r9d,r9d
  40c572:	je     40c590 <__swc_fn_585f006d_000106_ed4b1681+0x110>
  40c574:	xor    r8d,r8d
  40c577:	tzcnt  r8,r9
  40c57c:	shr    r8,0x3
  40c580:	add    rax,r8
  40c583:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c587:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c58b:	sub    ecx,eax
  40c58d:	mov    eax,ecx
  40c58f:	ret
  40c590:	lea    rax,[rax+0x4]
  40c594:	cmp    rax,r8
  40c597:	jne    40c59c <__swc_fn_585f006d_000106_ed4b1681+0x11c>
  40c599:	xor    eax,eax
  40c59b:	ret
  40c59c:	lea    rax,[r8-0x4]
  40c5a0:	lea    r8,[rcx+rax*1]
  40c5a4:	lea    r9,[rdx+rax*1]
  40c5a8:	mov    r8d,DWORD PTR [r8]
  40c5ab:	xor    r8d,DWORD PTR [r9]
  40c5ae:	test   r8d,r8d
  40c5b1:	je     40c5cf <__swc_fn_585f006d_000106_ed4b1681+0x14f>
  40c5b3:	xor    r9d,r9d
  40c5b6:	tzcnt  r9,r8
  40c5bb:	shr    r9,0x3
  40c5bf:	add    rax,r9
  40c5c2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5c6:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5ca:	sub    ecx,eax
  40c5cc:	mov    eax,ecx
  40c5ce:	ret
  40c5cf:	xor    eax,eax
  40c5d1:	ret
  40c5d2:	cmp    r9,0x2
  40c5d6:	jb     40c629 <__swc_fn_585f006d_000106_ed4b1681+0x1a9>
  40c5d8:	lea    r9,[rcx+rax*1]
  40c5dc:	lea    r10,[rdx+rax*1]
  40c5e0:	mov    r9w,WORD PTR [r9]
  40c5e4:	xor    r9w,WORD PTR [r10]
  40c5e8:	test   r9w,r9w
  40c5ec:	je     40c60e <__swc_fn_585f006d_000106_ed4b1681+0x18e>
  40c5ee:	xor    r8d,r8d
  40c5f1:	movzx  r9d,r9w
  40c5f5:	tzcnt  r8,r9
  40c5fa:	shr    r8,0x3
  40c5fe:	add    rax,r8
  40c601:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c605:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c609:	sub    ecx,eax
  40c60b:	mov    eax,ecx
  40c60d:	ret
  40c60e:	lea    rax,[rax+0x2]
  40c612:	cmp    rax,r8
  40c615:	jne    40c61a <__swc_fn_585f006d_000106_ed4b1681+0x19a>
  40c617:	xor    eax,eax
  40c619:	ret
  40c61a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40c620:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40c626:	sub    eax,ecx
  40c628:	ret
  40c629:	test   r9,r9
  40c62c:	je     40c63b <__swc_fn_585f006d_000106_ed4b1681+0x1bb>
  40c62e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c632:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c636:	sub    ecx,eax
  40c638:	mov    eax,ecx
  40c63a:	ret
  40c63b:	xor    eax,eax
  40c63d:	ret
	...

000000000040c640 <__swc_fn_585f006d_000109_8d425bd3>:
  40c640:	push   r12
  40c642:	push   r13
  40c644:	push   r14
  40c646:	push   rdi
  40c647:	push   rsi
  40c648:	push   r15
  40c64a:	sub    rsp,0xd8
  40c651:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c657:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c65d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c663:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c669:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c66f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c678:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c681:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c68a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c693:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c69c:	mov    r12,rcx
  40c69f:	test   rcx,rcx
  40c6a2:	je     40c6be <__swc_fn_585f006d_000109_8d425bd3+0x7e>
  40c6a4:	mov    eax,r12d
  40c6a7:	and    eax,0xfff
  40c6ad:	setne  al
  40c6b0:	cmp    r12,0xffffffffffffefff
  40c6b7:	seta   cl
  40c6ba:	or     al,cl
  40c6bc:	je     40c6c5 <__swc_fn_585f006d_000109_8d425bd3+0x85>
  40c6be:	xor    eax,eax
  40c6c0:	jmp    40c75b <__swc_fn_585f006d_000109_8d425bd3+0x11b>
  40c6c5:	call   409120 <__swc_fn_585f006d_000108_84af7666>
  40c6ca:	mov    r13,rax
  40c6cd:	test   rax,rax
  40c6d0:	jne    40c6d9 <__swc_fn_585f006d_000109_8d425bd3+0x99>
  40c6d2:	xor    eax,eax
  40c6d4:	jmp    40c75b <__swc_fn_585f006d_000109_8d425bd3+0x11b>
  40c6d9:	lea    r14,[r12+0x1000]
  40c6e1:	xor    edi,edi
  40c6e3:	mov    rsi,r14
  40c6e6:	xor    edx,edx
  40c6e8:	mov    ecx,0x22
  40c6ed:	mov    eax,0xffffffff
  40c6f2:	movsxd r8,eax
  40c6f5:	xor    r9d,r9d
  40c6f8:	xor    eax,eax
  40c6fa:	call   4070c0 <mmap@plt>
  40c6ff:	mov    r15,rax
  40c702:	cmp    rax,0xffffffffffffffff
  40c706:	jne    40c70c <__swc_fn_585f006d_000109_8d425bd3+0xcc>
  40c708:	xor    eax,eax
  40c70a:	jmp    40c75b <__swc_fn_585f006d_000109_8d425bd3+0x11b>
  40c70c:	mov    rdi,r15
  40c70f:	mov    esi,0x1000
  40c714:	mov    edx,0x3
  40c719:	xor    eax,eax
  40c71b:	call   407030 <mprotect@plt>
  40c720:	test   eax,eax
  40c722:	je     40c735 <__swc_fn_585f006d_000109_8d425bd3+0xf5>
  40c724:	mov    rdi,r15
  40c727:	mov    rsi,r14
  40c72a:	xor    eax,eax
  40c72c:	call   407020 <munmap@plt>
  40c731:	xor    eax,eax
  40c733:	jmp    40c75b <__swc_fn_585f006d_000109_8d425bd3+0x11b>
  40c735:	mov    QWORD PTR [r15+0x8],r12
  40c739:	mov    rcx,r13
  40c73c:	call   40cd90 <__swc_fn_585f006d_000133_4b2af8da>
  40c741:	mov    rax,QWORD PTR [r13+0x8]
  40c745:	mov    QWORD PTR [r15],rax
  40c748:	mov    QWORD PTR [r13+0x8],r15
  40c74c:	mov    rcx,r13
  40c74f:	call   410220 <__swc_fn_585f006d_000134_29412410>
  40c754:	lea    rax,[r15+0x1000]
  40c75b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c761:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c767:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c76d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c773:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c779:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c782:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c78b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c794:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c79d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c7a6:	add    rsp,0xd8
  40c7ad:	pop    r15
  40c7af:	pop    rsi
  40c7b0:	pop    rdi
  40c7b1:	pop    r14
  40c7b3:	pop    r13
  40c7b5:	pop    r12
  40c7b7:	ret
	...

000000000040c7c0 <__swc_fn_585f006d_000112_759e9ceb>:
  40c7c0:	push   rbx
  40c7c1:	push   r12
  40c7c3:	push   rdi
  40c7c4:	push   rsi
  40c7c5:	sub    rsp,0xa8
  40c7cc:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c7d2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c7d8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c7de:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c7e4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c7ea:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c7f0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c7f6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c7fc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c805:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c80e:	mov    rbx,rdx
  40c811:	mov    r12,rcx
  40c814:	mov    rdi,rcx
  40c817:	mov    rsi,rdx
  40c81a:	xor    edx,edx
  40c81c:	xor    eax,eax
  40c81e:	call   407030 <mprotect@plt>
  40c823:	test   eax,eax
  40c825:	jne    40c849 <__swc_fn_585f006d_000112_759e9ceb+0x89>
  40c827:	mov    rcx,r12
  40c82a:	mov    rdx,rbx
  40c82d:	xor    al,al
  40c82f:	mov    r8,rax
  40c832:	call   40fcb0 <__swc_fn_585f006d_000110_a808fe76>
  40c837:	mov    rdi,r12
  40c83a:	mov    rsi,rbx
  40c83d:	mov    edx,0x4
  40c842:	xor    eax,eax
  40c844:	call   4070f0 <madvise@plt>
  40c849:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c84f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c855:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c85b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40c861:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40c867:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40c86d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40c873:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40c879:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40c882:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40c88b:	add    rsp,0xa8
  40c892:	pop    rsi
  40c893:	pop    rdi
  40c894:	pop    r12
  40c896:	pop    rbx
  40c897:	ret
	...

000000000040c8a0 <__swc_fn_585f006d_000115_1ba33335>:
  40c8a0:	push   rsi
  40c8a1:	push   rdi
  40c8a2:	push   r12
  40c8a4:	push   r13
  40c8a6:	push   r14
  40c8a8:	sub    rsp,0xe0
  40c8af:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c8b5:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c8bb:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c8c1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c8c7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c8cd:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c8d6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c8df:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c8e8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c8f1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c8fa:	mov    rsi,rdx
  40c8fd:	mov    rdi,rcx
  40c900:	call   409120 <__swc_fn_585f006d_000108_84af7666>
  40c905:	mov    r12,rax
  40c908:	test   rax,rax
  40c90b:	jne    40c912 <__swc_fn_585f006d_000115_1ba33335+0x72>
  40c90d:	jmp    40c986 <__swc_fn_585f006d_000115_1ba33335+0xe6>
  40c912:	mov    rcx,r12
  40c915:	call   40cd90 <__swc_fn_585f006d_000133_4b2af8da>
  40c91a:	lea    r13,[r12+0x8]
  40c91f:	mov    rax,QWORD PTR [r13+0x0]
  40c923:	test   rax,rax
  40c926:	je     40c97e <__swc_fn_585f006d_000115_1ba33335+0xde>
  40c928:	nop    DWORD PTR [rax+rax*1+0x0]
  40c930:	lea    rcx,[rax+0x1000]
  40c937:	cmp    rcx,rdi
  40c93a:	jne    40c972 <__swc_fn_585f006d_000115_1ba33335+0xd2>
  40c93c:	cmp    QWORD PTR [rax+0x8],rsi
  40c940:	je     40c94c <__swc_fn_585f006d_000115_1ba33335+0xac>
  40c942:	mov    rcx,r12
  40c945:	call   410220 <__swc_fn_585f006d_000134_29412410>
  40c94a:	jmp    40c986 <__swc_fn_585f006d_000115_1ba33335+0xe6>
  40c94c:	mov    r14,QWORD PTR [rax]
  40c94f:	mov    rdi,rax
  40c952:	lea    rsi,[rsi+0x1000]
  40c959:	xor    eax,eax
  40c95b:	call   407020 <munmap@plt>
  40c960:	test   eax,eax
  40c962:	jne    40c968 <__swc_fn_585f006d_000115_1ba33335+0xc8>
  40c964:	mov    QWORD PTR [r13+0x0],r14
  40c968:	mov    rcx,r12
  40c96b:	call   410220 <__swc_fn_585f006d_000134_29412410>
  40c970:	jmp    40c986 <__swc_fn_585f006d_000115_1ba33335+0xe6>
  40c972:	mov    r13,rax
  40c975:	mov    rax,QWORD PTR [r13+0x0]
  40c979:	test   rax,rax
  40c97c:	jne    40c930 <__swc_fn_585f006d_000115_1ba33335+0x90>
  40c97e:	mov    rcx,r12
  40c981:	call   410220 <__swc_fn_585f006d_000134_29412410>
  40c986:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c98c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c992:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c998:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c99e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c9a4:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c9ad:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c9b6:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c9bf:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c9c8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c9d1:	add    rsp,0xe0
  40c9d8:	pop    r14
  40c9da:	pop    r13
  40c9dc:	pop    r12
  40c9de:	pop    rdi
  40c9df:	pop    rsi
  40c9e0:	ret
	...

000000000040c9f0 <__swc_fn_585f006d_000118_7f430081>:
  40c9f0:	push   rdi
  40c9f1:	push   rsi
  40c9f2:	sub    rsp,0xa8
  40c9f9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c9ff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ca05:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ca0b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40ca11:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ca17:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40ca1d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ca23:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ca29:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ca32:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ca3b:	mov    rdi,0xfffffffffffffd66
  40ca42:	xor    eax,eax
  40ca44:	call   407040 <exit@plt>
  40ca49:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ca4f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ca55:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ca5b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ca61:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ca67:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ca6d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ca73:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ca79:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ca82:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ca8b:	add    rsp,0xa8
  40ca92:	pop    rsi
  40ca93:	pop    rdi
  40ca94:	ret
	...

000000000040caa0 <__swc_fn_585f006d_000121_12b4ed22>:
  40caa0:	push   rbx
  40caa1:	push   rsi
  40caa2:	push   rdi
  40caa3:	sub    rsp,0x30
  40caa7:	mov    rbx,rdx
  40caaa:	mov    esi,ecx
  40caac:	test   ecx,ecx
  40caae:	je     40cb83 <__swc_fn_585f006d_000121_12b4ed22+0xe3>
  40cab4:	mov    rcx,rsi
  40cab7:	shl    rcx,0x4
  40cabb:	call   40bfb0 <__swc_fn_585f006d_000079_34776ded>
  40cac0:	test   rax,rax
  40cac3:	je     40cb72 <__swc_fn_585f006d_000121_12b4ed22+0xd2>
  40cac9:	mov    rcx,rsi
  40cacc:	xor    edx,edx
  40cace:	test   rsi,rsi
  40cad1:	jbe    40cb52 <__swc_fn_585f006d_000121_12b4ed22+0xb2>
  40cad7:	nop    WORD PTR [rax+rax*1+0x0]
  40cae0:	mov    r8d,edx
  40cae3:	mov    r9,QWORD PTR [rbx+r8*8]
  40cae7:	add    r8,r8
  40caea:	lea    r8,[rax+r8*8]
  40caee:	xor    r10d,r10d
  40caf1:	test   r9,r9
  40caf4:	je     40cb30 <__swc_fn_585f006d_000121_12b4ed22+0x90>
  40caf6:	mov    r11,r9
  40caf9:	mov    dil,BYTE PTR [r11]
  40cafc:	test   dil,dil
  40caff:	je     40cb30 <__swc_fn_585f006d_000121_12b4ed22+0x90>
  40cb01:	cs nop WORD PTR [rax+rax*1+0x0]
  40cb0b:	cs nop WORD PTR [rax+rax*1+0x0]
  40cb15:	cs nop WORD PTR [rax+rax*1+0x0]
  40cb1f:	nop
  40cb20:	add    r11,0x1
  40cb24:	add    r10,0x1
  40cb28:	mov    dil,BYTE PTR [r11]
  40cb2b:	test   dil,dil
  40cb2e:	jne    40cb20 <__swc_fn_585f006d_000121_12b4ed22+0x80>
  40cb30:	mov    QWORD PTR [rsp+0x18],r9
  40cb35:	mov    QWORD PTR [rsp+0x20],r10
  40cb3a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40cb40:	vmovups XMMWORD PTR [r8],xmm0
  40cb45:	add    rdx,0x1
  40cb49:	cmp    rdx,rcx
  40cb4c:	jb     40cae0 <__swc_fn_585f006d_000121_12b4ed22+0x40>
  40cb52:	lea    rcx,[rip+0x191f7]        # 425d50 <__swc_bss_base_585f006d+0x2d10>
  40cb59:	mov    QWORD PTR [rsp+0x8],rax
  40cb5e:	mov    esi,esi
  40cb60:	mov    QWORD PTR [rsp+0x10],rsi
  40cb65:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40cb6b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cb70:	jmp    40cb83 <__swc_fn_585f006d_000121_12b4ed22+0xe3>
  40cb72:	lea    rcx,[rip+0x59a7]        # 412520 <__swc_rdata_base_585f006d+0x410>
  40cb79:	call   40fd60 <__swc_fn_585f006d_000116_035d76a1>
  40cb7e:	call   40c9f0 <__swc_fn_585f006d_000118_7f430081>
  40cb83:	add    rsp,0x30
  40cb87:	pop    rdi
  40cb88:	pop    rsi
  40cb89:	pop    rbx
  40cb8a:	ret
  40cb8b:	add    BYTE PTR [rax],al
  40cb8d:	add    BYTE PTR [rax],al
	...

000000000040cb90 <__swc_fn_585f006d_000124_667fbf24>:
  40cb90:	push   rdi
  40cb91:	push   rsi
  40cb92:	sub    rsp,0xa8
  40cb99:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cb9f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cba5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cbab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cbb1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cbb7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cbbd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cbc3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cbc9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cbd2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cbdb:	mov    edi,ecx
  40cbdd:	xor    eax,eax
  40cbdf:	call   407100 <pthread_key_delete@plt>
  40cbe4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cbea:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cbf0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cbf6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cbfc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cc02:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cc08:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cc0e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cc14:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cc1d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cc26:	add    rsp,0xa8
  40cc2d:	pop    rsi
  40cc2e:	pop    rdi
  40cc2f:	ret

000000000040cc30 <__swc_fn_585f006d_000127_8dffa290>:
  40cc30:	push   rdi
  40cc31:	push   rsi
  40cc32:	sub    rsp,0xa8
  40cc39:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cc3f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cc45:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cc4b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cc51:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cc57:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cc5d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cc63:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cc69:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cc72:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cc7b:	test   rcx,rcx
  40cc7e:	je     40cc8f <__swc_fn_585f006d_000127_8dffa290+0x5f>
  40cc80:	lea    rax,[rcx-0x1]
  40cc84:	mov    eax,eax
  40cc86:	mov    edi,eax
  40cc88:	xor    eax,eax
  40cc8a:	call   407100 <pthread_key_delete@plt>
  40cc8f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cc95:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cc9b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cca1:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cca7:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ccad:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ccb3:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ccb9:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ccbf:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ccc8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ccd1:	add    rsp,0xa8
  40ccd8:	pop    rsi
  40ccd9:	pop    rdi
  40ccda:	ret
  40ccdb:	add    BYTE PTR [rax],al
  40ccdd:	add    BYTE PTR [rax],al
	...

000000000040cce0 <__swc_fn_585f006d_000130_c1196dfb>:
  40cce0:	push   rsi
  40cce1:	push   rdi
  40cce2:	sub    rsp,0xa8
  40cce9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ccef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ccf5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ccfb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cd01:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cd07:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cd0d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cd13:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cd19:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cd22:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cd2b:	xor    eax,eax
  40cd2d:	call   407110 <gettid@plt>
  40cd32:	movsxd rax,eax
  40cd35:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cd3b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cd41:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cd47:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cd4d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cd53:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cd59:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cd5f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cd65:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cd6e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cd77:	add    rsp,0xa8
  40cd7e:	pop    rdi
  40cd7f:	pop    rsi
  40cd80:	ret
	...

000000000040cd90 <__swc_fn_585f006d_000133_4b2af8da>:
  40cd90:	push   rbx
  40cd91:	push   rdi
  40cd92:	push   rsi
  40cd93:	sub    rsp,0xc0
  40cd9a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40cda0:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40cda6:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cdac:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40cdb2:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40cdb8:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cdbe:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cdc4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cdcd:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40cdd6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cddf:	mov    rbx,rcx
  40cde2:	cs nop WORD PTR [rax+rax*1+0x0]
  40cdec:	nop    DWORD PTR [rax+0x0]
  40cdf0:	mov    edx,0x80000000
  40cdf5:	xor    eax,eax
  40cdf7:	lock cmpxchg DWORD PTR [rbx],edx
  40cdfb:	test   eax,eax
  40cdfd:	je     40ce34 <__swc_fn_585f006d_000133_4b2af8da+0xa4>
  40cdff:	mov    eax,DWORD PTR [rbx]
  40ce01:	lea    rcx,[rsp+0x14]
  40ce06:	mov    DWORD PTR [rsp+0x14],eax
  40ce0a:	test   eax,eax
  40ce0c:	je     40cdf0 <__swc_fn_585f006d_000133_4b2af8da+0x60>
  40ce0e:	mov    QWORD PTR [rsp],0x0
  40ce16:	mov    edi,0xca
  40ce1b:	mov    rsi,rbx
  40ce1e:	mov    edx,0x80
  40ce23:	mov    ecx,DWORD PTR [rcx]
  40ce25:	xor    r8d,r8d
  40ce28:	xor    r9d,r9d
  40ce2b:	xor    eax,eax
  40ce2d:	call   407070 <syscall@plt>
  40ce32:	jmp    40cdf0 <__swc_fn_585f006d_000133_4b2af8da+0x60>
  40ce34:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ce3a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ce40:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ce46:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ce4c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ce52:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ce58:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ce5e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ce67:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ce70:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ce79:	add    rsp,0xc0
  40ce80:	pop    rsi
  40ce81:	pop    rdi
  40ce82:	pop    rbx
  40ce83:	ret
	...

000000000040ce90 <__swc_fn_585f006d_000136_3e875c27>:
  40ce90:	sub    rsp,0x8
  40ce94:	call   410220 <__swc_fn_585f006d_000134_29412410>
  40ce99:	add    rsp,0x8
  40ce9d:	ret
	...

000000000040cea0 <__swc_fn_585f006d_000139_7c02fe26>:
  40cea0:	push   rdi
  40cea1:	push   rsi
  40cea2:	sub    rsp,0xa8
  40cea9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ceaf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ceb5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cebb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cec1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cec7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cecd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ced3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ced9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cee2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ceeb:	mov    edi,0x28
  40cef0:	xor    eax,eax
  40cef2:	call   4070d0 <malloc@plt>
  40cef7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cefd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cf03:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cf09:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cf0f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cf15:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cf1b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cf21:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cf27:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cf30:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cf39:	add    rsp,0xa8
  40cf40:	pop    rsi
  40cf41:	pop    rdi
  40cf42:	ret
	...

000000000040cf50 <__swc_fn_585f006d_000142_56e56812>:
  40cf50:	mov    QWORD PTR [r8],0x0
  40cf57:	cmp    rdx,0x10
  40cf5b:	jae    40cf60 <__swc_fn_585f006d_000142_56e56812+0x10>
  40cf5d:	xor    eax,eax
  40cf5f:	ret
  40cf60:	mov    eax,DWORD PTR [rcx]
  40cf62:	cmp    eax,0x42445753
  40cf68:	jne    40cf72 <__swc_fn_585f006d_000142_56e56812+0x22>
  40cf6a:	mov    eax,DWORD PTR [rcx+0x4]
  40cf6d:	cmp    eax,0x1
  40cf70:	je     40cf75 <__swc_fn_585f006d_000142_56e56812+0x25>
  40cf72:	xor    eax,eax
  40cf74:	ret
  40cf75:	mov    QWORD PTR [r8],rdx
  40cf78:	mov    rax,rcx
  40cf7b:	ret
  40cf7c:	add    BYTE PTR [rax],al
	...

000000000040cf80 <__swc_fn_585f006d_000145_863755b5>:
  40cf80:	push   rbx
  40cf81:	sub    rsp,0xe0
  40cf88:	lea    rbx,[rsp+0x8]
  40cf8d:	vxorps xmm0,xmm0,xmm0
  40cf91:	vmovups XMMWORD PTR [rbx],xmm0
  40cf95:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40cf9a:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40cf9f:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40cfa4:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40cfa9:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  40cfae:	mov    DWORD PTR [rbx+0x60],0x0
  40cfb5:	mov    r8,rbx
  40cfb8:	mov    rdx,rcx
  40cfbb:	nop    DWORD PTR [rax+rax*1+0x0]
  40cfc0:	mov    r9,rdx
  40cfc3:	movabs rdx,0x6666666666666667
  40cfcd:	mov    rax,r9
  40cfd0:	imul   rdx
  40cfd3:	sar    rdx,0x2
  40cfd7:	mov    r10,rdx
  40cfda:	shr    rdx,0x3f
  40cfde:	add    r10,rdx
  40cfe1:	mov    rdx,r10
  40cfe4:	imul   r11,r10,0xa
  40cfe8:	sub    r9,r11
  40cfeb:	mov    r11,QWORD PTR [rip+0x554e]        # 412540 <__swc_rdata_base_585f006d+0x430>
  40cff2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40cff7:	mov    BYTE PTR [r8],r9b
  40cffa:	lea    r9,[r8+0x1]
  40cffe:	mov    r8,r9
  40d001:	test   r10,r10
  40d004:	jne    40cfc0 <__swc_fn_585f006d_000145_863755b5+0x40>
  40d006:	test   rcx,rcx
  40d009:	jge    40d013 <__swc_fn_585f006d_000145_863755b5+0x93>
  40d00b:	mov    BYTE PTR [r9],0x2d
  40d00f:	add    r8,0x1
  40d013:	mov    BYTE PTR [r8],0x0
  40d017:	sub    r8,0x1
  40d01b:	mov    rax,rbx
  40d01e:	cmp    rax,r8
  40d021:	jae    40d046 <__swc_fn_585f006d_000145_863755b5+0xc6>
  40d023:	cs nop WORD PTR [rax+rax*1+0x0]
  40d02d:	nop    DWORD PTR [rax]
  40d030:	mov    cl,BYTE PTR [r8]
  40d033:	mov    dl,BYTE PTR [rax]
  40d035:	mov    BYTE PTR [r8],dl
  40d038:	sub    r8,0x1
  40d03c:	mov    BYTE PTR [rax],cl
  40d03e:	inc    rax
  40d041:	cmp    rax,r8
  40d044:	jb     40d030 <__swc_fn_585f006d_000145_863755b5+0xb0>
  40d046:	xor    eax,eax
  40d048:	test   rbx,rbx
  40d04b:	je     40d06e <__swc_fn_585f006d_000145_863755b5+0xee>
  40d04d:	mov    rcx,rbx
  40d050:	mov    dl,BYTE PTR [rcx]
  40d052:	test   dl,dl
  40d054:	je     40d06e <__swc_fn_585f006d_000145_863755b5+0xee>
  40d056:	cs nop WORD PTR [rax+rax*1+0x0]
  40d060:	add    rcx,0x1
  40d064:	add    rax,0x1
  40d068:	mov    dl,BYTE PTR [rcx]
  40d06a:	test   dl,dl
  40d06c:	jne    40d060 <__swc_fn_585f006d_000145_863755b5+0xe0>
  40d06e:	mov    QWORD PTR [rbx+0xa8],rbx
  40d075:	mov    QWORD PTR [rbx+0xb0],rax
  40d07c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d084:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d08c:	lea    rcx,[rbx+0xb8]
  40d093:	call   40fd60 <__swc_fn_585f006d_000116_035d76a1>
  40d098:	add    rsp,0xe0
  40d09f:	pop    rbx
  40d0a0:	ret
	...

000000000040d0b0 <__swc_fn_585f006d_000148_9e4bc402>:
  40d0b0:	vxorps xmm0,xmm0,xmm0
  40d0b4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0b8:	mov    QWORD PTR [rcx+0x10],0x0
  40d0c0:	ret
	...

000000000040d0d0 <__swc_fn_585f006d_000151_9e4bc402>:
  40d0d0:	vxorps xmm0,xmm0,xmm0
  40d0d4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0dd:	vxorps xmm0,xmm0,xmm0
  40d0e1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0e6:	vmovups xmm0,XMMWORD PTR [rip+0x554a]        # 412638 <__swc_rdata_base_585f006d+0x528>
  40d0ee:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d0f3:	vxorps xmm0,xmm0,xmm0
  40d0f7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d0fc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d101:	mov    QWORD PTR [rcx+0x60],0x0
  40d109:	ret
  40d10a:	add    BYTE PTR [rax],al
  40d10c:	add    BYTE PTR [rax],al
	...

000000000040d110 <__swc_fn_585f006d_000154_9e4bc402>:
  40d110:	vxorps xmm0,xmm0,xmm0
  40d114:	vmovups XMMWORD PTR [rcx],xmm0
  40d118:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d11d:	vxorps xmm0,xmm0,xmm0
  40d121:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d126:	vmovups xmm0,XMMWORD PTR [rip+0x5632]        # 412760 <__swc_rdata_base_585f006d+0x650>
  40d12e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d133:	vxorps xmm0,xmm0,xmm0
  40d137:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d13c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d141:	vxorps xmm0,xmm0,xmm0
  40d145:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d14a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d14f:	vxorps xmm0,xmm0,xmm0
  40d153:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d15b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d163:	vxorps xmm0,xmm0,xmm0
  40d167:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d16f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d177:	vxorps xmm0,xmm0,xmm0
  40d17b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d183:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d18b:	mov    QWORD PTR [rcx+0xe0],0x0
  40d196:	ret
	...

000000000040d1a0 <__swc_fn_585f006d_000157_232ffa22>:
  40d1a0:	push   rbx
  40d1a1:	mov    rbx,rcx
  40d1a4:	call   4117f0 <__swc_fn_585f006d_000158_b43b2f96>
  40d1a9:	mov    rax,QWORD PTR [rbx+0x10]
  40d1ad:	test   rax,rax
  40d1b0:	je     40d1c1 <__swc_fn_585f006d_000157_232ffa22+0x21>
  40d1b2:	mov    rcx,rbx
  40d1b5:	mov    rdx,rax
  40d1b8:	mov    r8,QWORD PTR [rbx+0x18]
  40d1bc:	call   409ec0 <__swc_fn_585f006d_000156_2745c4a5>
  40d1c1:	vxorps xmm0,xmm0,xmm0
  40d1c5:	vmovups XMMWORD PTR [rbx],xmm0
  40d1c9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d1ce:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d1d3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d1d8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d1dd:	mov    QWORD PTR [rbx+0x50],0x0
  40d1e5:	pop    rbx
  40d1e6:	ret
	...

000000000040d200 <__swc_fn_585f006d_000160_01cbb887>:
  40d200:	sub    rsp,0x10
  40d204:	mov    eax,r8d
  40d207:	mov    r8d,r9d
  40d20a:	test   r9d,r9d
  40d20d:	jne    40d226 <__swc_fn_585f006d_000160_01cbb887+0x26>
  40d20f:	vmovups xmm0,XMMWORD PTR [rip+0x5601]        # 412818 <__swc_rdata_base_585f006d+0x708>
  40d217:	vmovups XMMWORD PTR [r10],xmm0
  40d21c:	mov    eax,0x1
  40d221:	add    rsp,0x10
  40d225:	ret
  40d226:	mov    r9,r8
  40d229:	cmp    r8,rax
  40d22c:	jb     40d233 <__swc_fn_585f006d_000160_01cbb887+0x33>
  40d22e:	cmp    r9,rdx
  40d231:	jb     40d23a <__swc_fn_585f006d_000160_01cbb887+0x3a>
  40d233:	xor    eax,eax
  40d235:	add    rsp,0x10
  40d239:	ret
  40d23a:	xor    eax,eax
  40d23c:	lea    r8,[r9+rax*1]
  40d240:	cmp    r8,rdx
  40d243:	jae    40d273 <__swc_fn_585f006d_000160_01cbb887+0x73>
  40d245:	cs nop WORD PTR [rax+rax*1+0x0]
  40d24f:	cs nop WORD PTR [rax+rax*1+0x0]
  40d259:	nop    DWORD PTR [rax+0x0]
  40d260:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d265:	je     40d273 <__swc_fn_585f006d_000160_01cbb887+0x73>
  40d267:	inc    rax
  40d26a:	lea    r8,[r9+rax*1]
  40d26e:	cmp    r8,rdx
  40d271:	jb     40d260 <__swc_fn_585f006d_000160_01cbb887+0x60>
  40d273:	cmp    r8,rdx
  40d276:	jne    40d27f <__swc_fn_585f006d_000160_01cbb887+0x7f>
  40d278:	xor    eax,eax
  40d27a:	add    rsp,0x10
  40d27e:	ret
  40d27f:	add    rcx,r9
  40d282:	mov    QWORD PTR [rsp],rcx
  40d286:	mov    QWORD PTR [rsp+0x8],rax
  40d28b:	vmovups xmm0,XMMWORD PTR [rsp]
  40d290:	vmovups XMMWORD PTR [r10],xmm0
  40d295:	mov    eax,0x1
  40d29a:	add    rsp,0x10
  40d29e:	ret
	...

000000000040d2a0 <__swc_fn_585f006d_000163_8e41797b>:
  40d2a0:	push   rbp
  40d2a1:	push   rbx
  40d2a2:	push   rsi
  40d2a3:	push   rdi
  40d2a4:	push   r12
  40d2a6:	push   r13
  40d2a8:	push   r14
  40d2aa:	push   r15
  40d2ac:	sub    rsp,0x10
  40d2b0:	mov    rbp,rsp
  40d2b3:	vmovups XMMWORD PTR [rsp],xmm6
  40d2b8:	sub    rsp,0x50
  40d2bc:	mov    rbx,rsp
  40d2bf:	mov    rsi,r8
  40d2c2:	mov    QWORD PTR [rsp+0x30],r8
  40d2c7:	mov    rdi,rcx
  40d2ca:	mov    QWORD PTR [rsp+0x38],rcx
  40d2cf:	mov    r12,rdx
  40d2d2:	xor    r13b,r13b
  40d2d5:	mov    r14,QWORD PTR [rdi+0x8]
  40d2d9:	mov    QWORD PTR [rsp+0x40],r14
  40d2de:	xor    r15d,r15d
  40d2e1:	test   r14,r14
  40d2e4:	jbe    40d53e <__swc_fn_585f006d_000163_8e41797b+0x29e>
  40d2ea:	mov    r14,QWORD PTR [rdi]
  40d2ed:	mov    rax,QWORD PTR [rsp+0x40]
  40d2f2:	mov    QWORD PTR [rsp+0x48],r14
  40d2f7:	vmovups xmm6,XMMWORD PTR [rip+0x5139]        # 412438 <__swc_rdata_base_585f006d+0x328>
  40d2ff:	nop
  40d300:	cmp    QWORD PTR [r14+r15*8],0x0
  40d305:	jne    40d30f <__swc_fn_585f006d_000163_8e41797b+0x6f>
  40d307:	mov    r14,rax
  40d30a:	jmp    40d51e <__swc_fn_585f006d_000163_8e41797b+0x27e>
  40d30f:	mov    rcx,QWORD PTR [rdi]
  40d312:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d316:	mov    rdi,rbx
  40d319:	mov    rcx,rdi
  40d31c:	sub    rsp,0x8
  40d320:	mov    r14,rax
  40d323:	call   409f40 <__swc_fn_585f006d_000162_60216e69>
  40d328:	add    rsp,0x8
  40d32c:	mov    al,BYTE PTR [rbx]
  40d32e:	test   al,al
  40d330:	je     40d51e <__swc_fn_585f006d_000163_8e41797b+0x27e>
  40d336:	mov    al,BYTE PTR [rbx+0x1]
  40d339:	test   al,al
  40d33b:	jne    40d346 <__swc_fn_585f006d_000163_8e41797b+0xa6>
  40d33d:	test   sil,sil
  40d340:	je     40d51e <__swc_fn_585f006d_000163_8e41797b+0x27e>
  40d346:	test   r13b,r13b
  40d349:	jne    40d407 <__swc_fn_585f006d_000163_8e41797b+0x167>
  40d34f:	test   r12,r12
  40d352:	je     40d407 <__swc_fn_585f006d_000163_8e41797b+0x167>
  40d358:	mov    al,BYTE PTR [rbx+0x1]
  40d35b:	test   al,al
  40d35d:	je     40d51e <__swc_fn_585f006d_000163_8e41797b+0x27e>
  40d363:	mov    eax,DWORD PTR [rbx+0x28]
  40d366:	cmp    DWORD PTR [r12+0x20],eax
  40d36b:	jne    40d51e <__swc_fn_585f006d_000163_8e41797b+0x27e>
  40d371:	mov    rax,QWORD PTR [r12]
  40d375:	mov    rcx,QWORD PTR [r12+0x8]
  40d37a:	cmp    QWORD PTR [rbx+0x20],rcx
  40d37e:	jne    40d51e <__swc_fn_585f006d_000163_8e41797b+0x27e>
  40d384:	mov    cl,0x1
  40d386:	test   rax,rax
  40d389:	je     40d3f2 <__swc_fn_585f006d_000163_8e41797b+0x152>
  40d38f:	mov    rdx,QWORD PTR [rbx+0x20]
  40d393:	xor    r8d,r8d
  40d396:	test   rdx,rdx
  40d399:	jbe    40d3f2 <__swc_fn_585f006d_000163_8e41797b+0x152>
  40d39b:	mov    r9,QWORD PTR [rbx+0x18]
  40d39f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40d3a4:	cs nop WORD PTR [rax+rax*1+0x0]
  40d3ae:	xchg   ax,ax
  40d3b0:	mov    r10b,BYTE PTR [rax+r8*1]
  40d3b4:	cmp    BYTE PTR [r9+r8*1],r10b
  40d3b8:	je     40d3e9 <__swc_fn_585f006d_000163_8e41797b+0x149>
  40d3ba:	vmovq  r10,xmm0
  40d3bf:	cmp    BYTE PTR [r10+r8*1],0x5c
  40d3c4:	jne    40d3cd <__swc_fn_585f006d_000163_8e41797b+0x12d>
  40d3c6:	cmp    BYTE PTR [rax+r8*1],0x2f
  40d3cb:	je     40d3e9 <__swc_fn_585f006d_000163_8e41797b+0x149>
  40d3cd:	vmovq  r10,xmm0
  40d3d2:	cmp    BYTE PTR [r10+r8*1],0x2f
  40d3d7:	jne    40d3e0 <__swc_fn_585f006d_000163_8e41797b+0x140>
  40d3d9:	cmp    BYTE PTR [rax+r8*1],0x5c
  40d3de:	je     40d3e9 <__swc_fn_585f006d_000163_8e41797b+0x149>
  40d3e0:	xor    eax,eax
  40d3e2:	movzx  eax,al
  40d3e5:	mov    cl,al
  40d3e7:	jmp    40d3f2 <__swc_fn_585f006d_000163_8e41797b+0x152>
  40d3e9:	add    r8,0x1
  40d3ed:	cmp    r8,rdx
  40d3f0:	jb     40d3b0 <__swc_fn_585f006d_000163_8e41797b+0x110>
  40d3f2:	test   cl,cl
  40d3f4:	je     40d51e <__swc_fn_585f006d_000163_8e41797b+0x27e>
  40d3fa:	mov    eax,0x1
  40d3ff:	mov    r13b,al
  40d402:	jmp    40d51e <__swc_fn_585f006d_000163_8e41797b+0x27e>
  40d407:	mov    r13b,0x1
  40d40a:	sub    rsp,0x20
  40d40e:	mov    rax,rsp
  40d411:	lea    rcx,[rdi+0x8]
  40d415:	mov    QWORD PTR [rax],rcx
  40d418:	lea    rsi,[rip+0x4ef1]        # 412310 <__swc_rdata_base_585f006d+0x200>
  40d41f:	mov    QWORD PTR [rax+0x8],rsi
  40d423:	mov    QWORD PTR [rax+0x10],rsp
  40d427:	mov    QWORD PTR [rax+0x18],0x1
  40d42f:	lea    rcx,[rsp+0x10]
  40d434:	sub    rsp,0x8
  40d438:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  40d43d:	add    rsp,0x8
  40d441:	add    rsp,0x20
  40d445:	mov    al,BYTE PTR [rbx+0x1]
  40d448:	test   al,al
  40d44a:	je     40d4e7 <__swc_fn_585f006d_000163_8e41797b+0x247>
  40d450:	lea    rax,[rip+0x5461]        # 4128b8 <__swc_rdata_base_585f006d+0x7a8>
  40d457:	sub    rsp,0x20
  40d45b:	mov    rcx,rsp
  40d45e:	mov    QWORD PTR [rcx],rax
  40d461:	mov    QWORD PTR [rcx+0x8],rsi
  40d465:	mov    QWORD PTR [rcx+0x10],rsp
  40d469:	mov    QWORD PTR [rcx+0x18],0x1
  40d471:	lea    rcx,[rsp+0x10]
  40d476:	sub    rsp,0x8
  40d47a:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  40d47f:	add    rsp,0x8
  40d483:	add    rsp,0x20
  40d487:	mov    eax,DWORD PTR [rbx+0x28]
  40d48a:	sub    rsp,0x60
  40d48e:	mov    rcx,rsp
  40d491:	lea    rdx,[rdi+0x18]
  40d495:	mov    QWORD PTR [rcx+0x18],rdx
  40d499:	mov    QWORD PTR [rcx+0x20],rsi
  40d49d:	vmovups XMMWORD PTR [rcx],xmm6
  40d4a1:	mov    QWORD PTR [rcx+0x28],rsp
  40d4a5:	mov    QWORD PTR [rcx+0x30],rsi
  40d4a9:	mov    DWORD PTR [rcx+0x10],eax
  40d4ac:	lea    rax,[rsp+0x10]
  40d4b1:	mov    QWORD PTR [rcx+0x38],rax
  40d4b5:	lea    rax,[rip+0x4f14]        # 4123d0 <__swc_rdata_base_585f006d+0x2c0>
  40d4bc:	mov    QWORD PTR [rcx+0x40],rax
  40d4c0:	lea    rax,[rsp+0x18]
  40d4c5:	mov    QWORD PTR [rcx+0x48],rax
  40d4c9:	mov    QWORD PTR [rcx+0x50],0x3
  40d4d1:	lea    rcx,[rsp+0x48]
  40d4d6:	sub    rsp,0x8
  40d4da:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  40d4df:	add    rsp,0x8
  40d4e3:	add    rsp,0x60
  40d4e7:	lea    rax,[rip+0x4e7a]        # 412368 <__swc_rdata_base_585f006d+0x258>
  40d4ee:	sub    rsp,0x20
  40d4f2:	mov    rcx,rsp
  40d4f5:	mov    QWORD PTR [rcx],rax
  40d4f8:	mov    QWORD PTR [rcx+0x8],rsi
  40d4fc:	mov    QWORD PTR [rcx+0x10],rsp
  40d500:	mov    QWORD PTR [rcx+0x18],0x1
  40d508:	lea    rcx,[rsp+0x10]
  40d50d:	sub    rsp,0x8
  40d511:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  40d516:	add    rsp,0x8
  40d51a:	add    rsp,0x20
  40d51e:	add    r15,0x1
  40d522:	cmp    r15,r14
  40d525:	jae    40d53e <__swc_fn_585f006d_000163_8e41797b+0x29e>
  40d527:	mov    rsi,QWORD PTR [rsp+0x30]
  40d52c:	mov    rdi,QWORD PTR [rsp+0x38]
  40d531:	mov    rax,r14
  40d534:	mov    r14,QWORD PTR [rsp+0x48]
  40d539:	jmp    40d300 <__swc_fn_585f006d_000163_8e41797b+0x60>
  40d53e:	add    rsp,0x50
  40d542:	vmovups xmm6,XMMWORD PTR [rsp]
  40d547:	add    rsp,0x10
  40d54b:	pop    r15
  40d54d:	pop    r14
  40d54f:	pop    r13
  40d551:	pop    r12
  40d553:	pop    rdi
  40d554:	pop    rsi
  40d555:	pop    rbx
  40d556:	pop    rbp
  40d557:	ret
	...

000000000040d560 <__swc_fn_585f006d_000166_f6173642>:
  40d560:	sub    rsp,0x8
  40d564:	call   40fff0 <__swc_fn_585f006d_000125_ce762363>
  40d569:	add    rsp,0x8
  40d56d:	ret
	...

000000000040d570 <__swc_fn_585f006d_000169_4579a84c>:
  40d570:	push   rsi
  40d571:	sub    rsp,0x30
  40d575:	lea    rsi,[rip+0x18824]        # 425da0 <__swc_bss_base_585f006d+0x2d60>
  40d57c:	mov    rax,QWORD PTR [rsi]
  40d57f:	test   rax,rax
  40d582:	je     40d58a <__swc_fn_585f006d_000169_4579a84c+0x1a>
  40d584:	add    rsp,0x30
  40d588:	pop    rsi
  40d589:	ret
  40d58a:	mov    ecx,0x2
  40d58f:	mov    edx,0x8020
  40d594:	call   40f660 <__swc_fn_585f006d_000107_4796e893>
  40d599:	test   rax,rax
  40d59c:	jne    40d5ad <__swc_fn_585f006d_000169_4579a84c+0x3d>
  40d59e:	mov    QWORD PTR [rsp+0x18],rax
  40d5a3:	call   40c9f0 <__swc_fn_585f006d_000118_7f430081>
  40d5a8:	mov    rax,QWORD PTR [rsp+0x18]
  40d5ad:	mov    rcx,rax
  40d5b0:	xchg   QWORD PTR [rsi],rcx
  40d5b3:	add    rsp,0x30
  40d5b7:	pop    rsi
  40d5b8:	ret
  40d5b9:	add    BYTE PTR [rax],al
  40d5bb:	add    BYTE PTR [rax],al
  40d5bd:	add    BYTE PTR [rax],al
	...

000000000040d5c0 <__swc_fn_585f006d_000172_97fbc432>:
  40d5c0:	push   rsi
  40d5c1:	test   r8,r8
  40d5c4:	jne    40d5c8 <__swc_fn_585f006d_000172_97fbc432+0x8>
  40d5c6:	pop    rsi
  40d5c7:	ret
  40d5c8:	lea    rax,[rcx+0x18]
  40d5cc:	mov    r10,QWORD PTR [rax]
  40d5cf:	lea    r11,[r10+0x1]
  40d5d3:	mov    QWORD PTR [rax],r11
  40d5d6:	mov    r11,rdx
  40d5d9:	not    rdx
  40d5dc:	lea    rsi,[r8-0x1]
  40d5e0:	cmp    rsi,rdx
  40d5e3:	ja     40d603 <__swc_fn_585f006d_000172_97fbc432+0x43>
  40d5e5:	lea    rdx,[r11+r8*1]
  40d5e9:	dec    rdx
  40d5ec:	shr    rdx,0x6
  40d5f0:	mov    r8,r11
  40d5f3:	shr    r8,0x6
  40d5f7:	mov    rsi,rdx
  40d5fa:	sub    rsi,r8
  40d5fd:	cmp    rsi,0x8
  40d601:	jb     40d619 <__swc_fn_585f006d_000172_97fbc432+0x59>
  40d603:	lea    rcx,[rcx+0x10]
  40d607:	mov    rdx,QWORD PTR [rcx]
  40d60a:	add    rdx,r9
  40d60d:	mov    QWORD PTR [rcx],rdx
  40d610:	lea    rcx,[r10+0x2]
  40d614:	mov    QWORD PTR [rax],rcx
  40d617:	pop    rsi
  40d618:	ret
  40d619:	shr    r11,0x6
  40d61d:	nop    DWORD PTR [rax]
  40d620:	cmp    r11,rdx
  40d623:	ja     40d663 <__swc_fn_585f006d_000172_97fbc432+0xa3>
  40d625:	jmp    40d636 <__swc_fn_585f006d_000172_97fbc432+0x76>
  40d627:	nop    WORD PTR [rax+rax*1+0x0]
  40d630:	add    r11,0x1
  40d634:	jmp    40d620 <__swc_fn_585f006d_000172_97fbc432+0x60>
  40d636:	mov    r8,r11
  40d639:	shr    r8,0xc
  40d63d:	mov    rsi,r11
  40d640:	xor    rsi,r8
  40d643:	mov    r8,r11
  40d646:	shr    r8,0x18
  40d64a:	xor    rsi,r8
  40d64d:	and    esi,0xfff
  40d653:	lea    r8,[rcx+rsi*8+0x20]
  40d658:	mov    rsi,QWORD PTR [r8]
  40d65b:	add    rsi,r9
  40d65e:	mov    QWORD PTR [r8],rsi
  40d661:	jmp    40d630 <__swc_fn_585f006d_000172_97fbc432+0x70>
  40d663:	lea    rcx,[r10+0x2]
  40d667:	mov    QWORD PTR [rax],rcx
  40d66a:	pop    rsi
  40d66b:	ret
  40d66c:	add    BYTE PTR [rax],al
	...

000000000040d670 <__swc_fn_585f006d_000175_2744b483>:
  40d670:	push   rbx
  40d671:	sub    rsp,0x70
  40d675:	cmp    rcx,0xffffffffffffffef
  40d679:	jbe    40d683 <__swc_fn_585f006d_000175_2744b483+0x13>
  40d67b:	xor    eax,eax
  40d67d:	add    rsp,0x70
  40d681:	pop    rbx
  40d682:	ret
  40d683:	vxorps xmm0,xmm0,xmm0
  40d687:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d68d:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40d693:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40d699:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40d69f:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40d6a5:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40d6ab:	lea    rax,[rcx+0x10]
  40d6af:	mov    QWORD PTR [rsp+0x50],rax
  40d6b4:	mov    DWORD PTR [rsp+0x60],0x10
  40d6bc:	mov    rcx,QWORD PTR [rip+0x1867d]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40d6c3:	test   rcx,rcx
  40d6c6:	jne    40d6d8 <__swc_fn_585f006d_000175_2744b483+0x68>
  40d6c8:	call   40a1d0 <__swc_fn_585f006d_000165_cf398896>
  40d6cd:	lea    rcx,[rax+0x1]
  40d6d1:	mov    QWORD PTR [rip+0x18668],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40d6d8:	dec    rcx
  40d6db:	call   411b60 <__swc_fn_585f006d_000167_fce60b2b>
  40d6e0:	mov    rcx,QWORD PTR [rax]
  40d6e3:	lea    rdx,[rsp+0x8]
  40d6e8:	mov    rbx,QWORD PTR [rax+0x8]
  40d6ec:	mov    rbx,QWORD PTR [rbx+0x8]
  40d6f0:	call   rbx
  40d6f2:	mov    rax,QWORD PTR [rsp+0x48]
  40d6f7:	test   rax,rax
  40d6fa:	jne    40d704 <__swc_fn_585f006d_000175_2744b483+0x94>
  40d6fc:	xor    eax,eax
  40d6fe:	add    rsp,0x70
  40d702:	pop    rbx
  40d703:	ret
  40d704:	mov    rcx,QWORD PTR [rsp+0x50]
  40d709:	mov    QWORD PTR [rax],rcx
  40d70c:	mov    QWORD PTR [rax+0x8],0x0
  40d714:	lea    rax,[rax+0x10]
  40d718:	add    rsp,0x70
  40d71c:	pop    rbx
  40d71d:	ret
	...

000000000040d720 <__swc_fn_585f006d_000178_8d3f617b>:
  40d720:	push   rbp
  40d721:	push   rsi
  40d722:	push   rdi
  40d723:	push   r12
  40d725:	push   r13
  40d727:	push   r14
  40d729:	sub    rsp,0x10
  40d72d:	mov    rbp,rsp
  40d730:	vmovups XMMWORD PTR [rsp],xmm6
  40d735:	sub    rsp,0xc0
  40d73c:	mov    ecx,0x48
  40d741:	sub    rsp,0x8
  40d745:	call   40d670 <__swc_fn_585f006d_000175_2744b483>
  40d74a:	add    rsp,0x8
  40d74e:	mov    rsi,rax
  40d751:	mov    ecx,0x48
  40d756:	sub    rsp,0x8
  40d75a:	call   40d670 <__swc_fn_585f006d_000175_2744b483>
  40d75f:	add    rsp,0x8
  40d763:	mov    rdi,rax
  40d766:	mov    ecx,0x48
  40d76b:	sub    rsp,0x8
  40d76f:	call   40d670 <__swc_fn_585f006d_000175_2744b483>
  40d774:	add    rsp,0x8
  40d778:	mov    r12,rax
  40d77b:	sub    rsp,0x8
  40d77f:	call   40a380 <__swc_fn_585f006d_000177_1ca87929>
  40d784:	add    rsp,0x8
  40d788:	vmovups xmm6,xmm0
  40d78c:	mov    QWORD PTR [rdi],0x0
  40d793:	mov    QWORD PTR [rdi+0x8],0x1
  40d79b:	mov    QWORD PTR [rdi+0x10],0x2
  40d7a3:	mov    QWORD PTR [rdi+0x18],0x3
  40d7ab:	mov    QWORD PTR [rdi+0x20],0x4
  40d7b3:	mov    QWORD PTR [rdi+0x28],0x5
  40d7bb:	mov    QWORD PTR [rdi+0x30],0x6
  40d7c3:	mov    QWORD PTR [rdi+0x38],0x7
  40d7cb:	mov    QWORD PTR [rdi+0x40],0x8
  40d7d3:	xor    eax,eax
  40d7d5:	xor    ecx,ecx
  40d7d7:	xor    edx,edx
  40d7d9:	mov    r8d,0x9
  40d7df:	nop
  40d7e0:	cmp    r8,0x1
  40d7e4:	je     40d7fe <__swc_fn_585f006d_000178_8d3f617b+0xde>
  40d7e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40d7f0:	mov    QWORD PTR [r12+r8*8-0x8],r8
  40d7f5:	dec    r8
  40d7f8:	cmp    r8,0x1
  40d7fc:	jne    40d7f0 <__swc_fn_585f006d_000178_8d3f617b+0xd0>
  40d7fe:	mov    r9,QWORD PTR [rdi]
  40d801:	mov    QWORD PTR [rsi],r9
  40d804:	mov    r10,QWORD PTR [rdi+0x8]
  40d808:	mov    QWORD PTR [rsi+0x8],r10
  40d80c:	mov    r10,QWORD PTR [rdi+0x10]
  40d810:	mov    QWORD PTR [rsi+0x10],r10
  40d814:	mov    r10,QWORD PTR [rdi+0x18]
  40d818:	mov    QWORD PTR [rsi+0x18],r10
  40d81c:	mov    r10,QWORD PTR [rdi+0x20]
  40d820:	mov    QWORD PTR [rsi+0x20],r10
  40d824:	mov    r10,QWORD PTR [rdi+0x28]
  40d828:	mov    QWORD PTR [rsi+0x28],r10
  40d82c:	mov    r10,QWORD PTR [rdi+0x30]
  40d830:	mov    QWORD PTR [rsi+0x30],r10
  40d834:	mov    r10,QWORD PTR [rdi+0x38]
  40d838:	mov    QWORD PTR [rsi+0x38],r10
  40d83c:	mov    r10,QWORD PTR [rdi+0x40]
  40d840:	mov    QWORD PTR [rsi+0x40],r10
  40d844:	xor    r10d,r10d
  40d847:	test   r9,r9
  40d84a:	je     40d8fa <__swc_fn_585f006d_000178_8d3f617b+0x1da>
  40d850:	test   r9,r9
  40d853:	jle    40d8eb <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d859:	mov    r14,QWORD PTR [rsi+r9*8]
  40d85d:	mov    QWORD PTR [rsi],r14
  40d860:	mov    QWORD PTR [rsi+r9*8],r9
  40d864:	dec    r9
  40d867:	cmp    r9,0x1
  40d86b:	jle    40d8eb <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d871:	mov    r13,QWORD PTR [rsi+0x8]
  40d875:	mov    r14,QWORD PTR [rsi+r9*8]
  40d879:	mov    QWORD PTR [rsi+0x8],r14
  40d87d:	mov    QWORD PTR [rsi+r9*8],r13
  40d881:	dec    r9
  40d884:	cmp    r9,0x2
  40d888:	jle    40d8eb <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d88a:	mov    r13,QWORD PTR [rsi+0x10]
  40d88e:	mov    r14,QWORD PTR [rsi+r9*8]
  40d892:	mov    QWORD PTR [rsi+0x10],r14
  40d896:	mov    QWORD PTR [rsi+r9*8],r13
  40d89a:	dec    r9
  40d89d:	cmp    r9,0x3
  40d8a1:	jle    40d8eb <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d8a3:	mov    r13,QWORD PTR [rsi+0x18]
  40d8a7:	mov    r14,QWORD PTR [rsi+r9*8]
  40d8ab:	mov    QWORD PTR [rsi+0x18],r14
  40d8af:	mov    QWORD PTR [rsi+r9*8],r13
  40d8b3:	dec    r9
  40d8b6:	cmp    r9,0x4
  40d8ba:	jle    40d8eb <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d8bc:	mov    r11d,0x4
  40d8c2:	jmp    40d8d0 <__swc_fn_585f006d_000178_8d3f617b+0x1b0>
  40d8c4:	cmp    r11,r9
  40d8c7:	jge    40d8eb <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d8c9:	nop    DWORD PTR [rax+0x0]
  40d8d0:	mov    r13,QWORD PTR [rsi+r11*8]
  40d8d4:	mov    r14,QWORD PTR [rsi+r9*8]
  40d8d8:	mov    QWORD PTR [rsi+r11*8],r14
  40d8dc:	mov    QWORD PTR [rsi+r9*8],r13
  40d8e0:	inc    r11
  40d8e3:	dec    r9
  40d8e6:	cmp    r11,r9
  40d8e9:	jl     40d8d0 <__swc_fn_585f006d_000178_8d3f617b+0x1b0>
  40d8eb:	inc    r10
  40d8ee:	mov    r9,QWORD PTR [rsi]
  40d8f1:	test   r9,r9
  40d8f4:	jne    40d850 <__swc_fn_585f006d_000178_8d3f617b+0x130>
  40d8fa:	cmp    r10,rcx
  40d8fd:	cmovg  rcx,r10
  40d901:	test   dl,0x1
  40d904:	jne    40d90b <__swc_fn_585f006d_000178_8d3f617b+0x1eb>
  40d906:	add    rax,r10
  40d909:	jmp    40d90e <__swc_fn_585f006d_000178_8d3f617b+0x1ee>
  40d90b:	sub    rax,r10
  40d90e:	xchg   ax,ax
  40d910:	cmp    r8,0x9
  40d914:	je     40d96b <__swc_fn_585f006d_000178_8d3f617b+0x24b>
  40d916:	mov    r10,QWORD PTR [rdi]
  40d919:	xor    r11d,r11d
  40d91c:	test   r8,r8
  40d91f:	jle    40d952 <__swc_fn_585f006d_000178_8d3f617b+0x232>
  40d921:	cs nop WORD PTR [rax+rax*1+0x0]
  40d92b:	cs nop WORD PTR [rax+rax*1+0x0]
  40d935:	cs nop WORD PTR [rax+rax*1+0x0]
  40d93f:	nop
  40d940:	mov    r13,QWORD PTR [rdi+r11*8+0x8]
  40d945:	mov    QWORD PTR [rdi+r11*8],r13
  40d949:	add    r11,0x1
  40d94d:	cmp    r11,r8
  40d950:	jl     40d940 <__swc_fn_585f006d_000178_8d3f617b+0x220>
  40d952:	mov    QWORD PTR [rdi+r8*8],r10
  40d956:	dec    QWORD PTR [r12+r8*8]
  40d95a:	je     40d95e <__swc_fn_585f006d_000178_8d3f617b+0x23e>
  40d95c:	jns    40d963 <__swc_fn_585f006d_000178_8d3f617b+0x243>
  40d95e:	inc    r8
  40d961:	jmp    40d910 <__swc_fn_585f006d_000178_8d3f617b+0x1f0>
  40d963:	inc    rdx
  40d966:	jmp    40d7e0 <__swc_fn_585f006d_000178_8d3f617b+0xc0>
  40d96b:	imul   r13,rax,0x3e8
  40d972:	add    r13,rcx
  40d975:	sub    rsp,0x8
  40d979:	call   40a380 <__swc_fn_585f006d_000177_1ca87929>
  40d97e:	add    rsp,0x8
  40d982:	vsubsd xmm0,xmm0,xmm6
  40d986:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x503a]        # 4129c8 <__swc_rdata_base_585f006d+0x8b8>
  40d98e:	lea    rax,[rip+0x49d3]        # 412368 <__swc_rdata_base_585f006d+0x258>
  40d995:	sub    rsp,0x90
  40d99c:	mov    rcx,rsp
  40d99f:	vmovups xmm1,XMMWORD PTR [rip+0x5001]        # 4129a8 <__swc_rdata_base_585f006d+0x898>
  40d9a7:	vmovups XMMWORD PTR [rcx],xmm1
  40d9ab:	mov    QWORD PTR [rcx+0x30],rsp
  40d9af:	lea    rdx,[rip+0x495a]        # 412310 <__swc_rdata_base_585f006d+0x200>
  40d9b6:	mov    QWORD PTR [rcx+0x38],rdx
  40d9ba:	mov    QWORD PTR [rcx+0x10],r13
  40d9be:	lea    r8,[rsp+0x10]
  40d9c3:	mov    QWORD PTR [rcx+0x40],r8
  40d9c7:	lea    r8,[rip+0x4f4a]        # 412918 <__swc_rdata_base_585f006d+0x808>
  40d9ce:	mov    QWORD PTR [rcx+0x48],r8
  40d9d2:	vmovups xmm1,XMMWORD PTR [rip+0x4fde]        # 4129b8 <__swc_rdata_base_585f006d+0x8a8>
  40d9da:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40d9df:	lea    r8,[rsp+0x18]
  40d9e4:	mov    QWORD PTR [rcx+0x50],r8
  40d9e8:	mov    QWORD PTR [rcx+0x58],rdx
  40d9ec:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40d9f1:	lea    r8,[rcx+0x28]
  40d9f5:	mov    QWORD PTR [rcx+0x60],r8
  40d9f9:	lea    r8,[rip+0x4f60]        # 412960 <__swc_rdata_base_585f006d+0x850>
  40da00:	mov    QWORD PTR [rcx+0x68],r8
  40da04:	mov    QWORD PTR [rcx+0x70],rax
  40da08:	mov    QWORD PTR [rcx+0x78],rdx
  40da0c:	lea    rax,[rcx+0x30]
  40da10:	mov    QWORD PTR [rcx+0x80],rax
  40da17:	mov    QWORD PTR [rcx+0x88],0x5
  40da22:	lea    rcx,[rcx+0x80]
  40da29:	sub    rsp,0x8
  40da2d:	call   4105e0 <__swc_fn_585f006d_000146_43f4fdca>
  40da32:	add    rsp,0x8
  40da36:	add    rsp,0x90
  40da3d:	mov    rcx,r12
  40da40:	sub    rsp,0x8
  40da44:	call   411d00 <__swc_fn_585f006d_000176_5d3d19bd>
  40da49:	add    rsp,0x8
  40da4d:	mov    rcx,rdi
  40da50:	sub    rsp,0x8
  40da54:	call   411d00 <__swc_fn_585f006d_000176_5d3d19bd>
  40da59:	add    rsp,0x8
  40da5d:	mov    rcx,rsi
  40da60:	sub    rsp,0x8
  40da64:	call   411d00 <__swc_fn_585f006d_000176_5d3d19bd>
  40da69:	add    rsp,0xc8
  40da70:	vmovups xmm6,XMMWORD PTR [rsp]
  40da75:	add    rsp,0x10
  40da79:	pop    r14
  40da7b:	pop    r13
  40da7d:	pop    r12
  40da7f:	pop    rdi
  40da80:	pop    rsi
  40da81:	pop    rbp
  40da82:	ret
	...

000000000040daa0 <__swc_fn_585f006d_000002_884bb5c0>:
  40daa0:	sub    rsp,0x8
  40daa4:	call   40c640 <__swc_fn_585f006d_000109_8d425bd3>
  40daa9:	mov    rcx,rax
  40daac:	test   rax,rax
  40daaf:	je     40dad6 <__swc_fn_585f006d_000002_884bb5c0+0x36>
  40dab1:	lea    rdx,[rip+0x15588]        # 423040 <__swc_bss_base_585f006d>
  40dab8:	mov    r8,QWORD PTR [rip+0x15581]        # 423040 <__swc_bss_base_585f006d>
  40dabf:	nop
  40dac0:	lea    r9,[r8+0x1]
  40dac4:	mov    rax,r8
  40dac7:	lock cmpxchg QWORD PTR [rdx],r9
  40dacc:	cmp    rax,r8
  40dacf:	je     40dad6 <__swc_fn_585f006d_000002_884bb5c0+0x36>
  40dad1:	mov    r8,rax
  40dad4:	jmp    40dac0 <__swc_fn_585f006d_000002_884bb5c0+0x20>
  40dad6:	mov    rax,rcx
  40dad9:	add    rsp,0x8
  40dadd:	ret
	...

000000000040dae0 <__swc_fn_585f006d_000005_b2240b56>:
  40dae0:	mov    r8d,edx
  40dae3:	xor    eax,eax
  40dae5:	tzcnt  eax,edx
  40dae9:	shrx   r9d,edx,eax
  40daee:	mov    DWORD PTR [rcx+0x2c],edx
  40daf1:	xor    eax,eax
  40daf3:	tzcnt  eax,edx
  40daf7:	mov    BYTE PTR [rcx+0x38],al
  40dafa:	mov    eax,0xffffffff
  40daff:	xor    edx,edx
  40db01:	div    r8d
  40db04:	mov    DWORD PTR [rcx+0x34],eax
  40db07:	mov    eax,r9d
  40db0a:	mov    edx,r9d
  40db0d:	imul   edx,r9d
  40db11:	mov    r8d,0x2
  40db17:	sub    r8d,edx
  40db1a:	imul   eax,r8d
  40db1e:	mov    edx,r9d
  40db21:	imul   edx,eax
  40db24:	mov    r8d,0x2
  40db2a:	sub    r8d,edx
  40db2d:	imul   eax,r8d
  40db31:	mov    edx,r9d
  40db34:	imul   edx,eax
  40db37:	mov    r8d,0x2
  40db3d:	sub    r8d,edx
  40db40:	imul   eax,r8d
  40db44:	mov    edx,r9d
  40db47:	imul   edx,eax
  40db4a:	mov    r8d,0x2
  40db50:	sub    r8d,edx
  40db53:	imul   eax,r8d
  40db57:	imul   r9d,eax
  40db5b:	mov    edx,0x2
  40db60:	sub    edx,r9d
  40db63:	imul   eax,edx
  40db66:	mov    DWORD PTR [rcx+0x30],eax
  40db69:	ret
  40db6a:	add    BYTE PTR [rax],al
  40db6c:	add    BYTE PTR [rax],al
	...

000000000040db70 <__swc_fn_585f006d_000008_4e857afc>:
  40db70:	xor    eax,eax
  40db72:	mov    DWORD PTR [rcx+0x68],eax
  40db75:	ret
	...

000000000040db80 <__swc_fn_585f006d_000011_6493fbbc>:
  40db80:	mov    eax,DWORD PTR [rcx+0x28]
  40db83:	shlx   eax,edx,eax
  40db88:	shl    rax,0x10
  40db8c:	lea    rdx,[rcx+rax*1]
  40db90:	lea    rax,[rcx+0x3000]
  40db97:	cmp    rdx,rax
  40db9a:	cmovae rax,rdx
  40db9e:	ret
	...

000000000040dba0 <__swc_fn_585f006d_000014_afb279e2>:
  40dba0:	push   rsi
  40dba1:	push   rdi
  40dba2:	push   r12
  40dba4:	push   r13
  40dba6:	push   r14
  40dba8:	mov    rsi,rdx
  40dbab:	mov    rdi,rcx
  40dbae:	rex mov dl,BYTE PTR [rsi+0x3a]
  40dbb2:	mov    ecx,DWORD PTR [rdi+0x28]
  40dbb5:	shr    dl,cl
  40dbb7:	mov    r12d,0x1
  40dbbd:	mov    ecx,edx
  40dbbf:	shl    r12,cl
  40dbc2:	mov    r13d,DWORD PTR [rsi+0x3c]
  40dbc6:	rex mov BYTE PTR [rsi+0x3b],0x0
  40dbcb:	mov    QWORD PTR [rsi+0x40],0x0
  40dbd3:	mov    QWORD PTR [rsi],0x0
  40dbda:	mov    rax,QWORD PTR [rsi+0x10]
  40dbde:	mov    QWORD PTR [rsi+0x20],rax
  40dbe2:	lea    r14,[rip+0x1545f]        # 423048 <__swc_bss_base_585f006d+0x8>
  40dbe9:	mov    rax,QWORD PTR [r14]
  40dbec:	shr    rax,0x2
  40dbf0:	mov    rcx,rax
  40dbf3:	cmp    rax,0x800000
  40dbfa:	mov    eax,0x800000
  40dbff:	cmovb  rcx,rax
  40dc03:	lea    r8,[rip+0x1544e]        # 423058 <__swc_bss_base_585f006d+0x18>
  40dc0a:	mov    rax,QWORD PTR [r8]
  40dc0d:	mov    r9,rax
  40dc10:	lea    r10,[r9+r13*1]
  40dc14:	cmp    r10,rcx
  40dc17:	ja     40dc3b <__swc_fn_585f006d_000014_afb279e2+0x9b>
  40dc19:	mov    rax,r9
  40dc1c:	lock cmpxchg QWORD PTR [r8],r10
  40dc21:	cmp    rax,r9
  40dc24:	je     40dc2b <__swc_fn_585f006d_000014_afb279e2+0x8b>
  40dc26:	mov    r9,rax
  40dc29:	jmp    40dc10 <__swc_fn_585f006d_000014_afb279e2+0x70>
  40dc2b:	mov    rcx,rdi
  40dc2e:	mov    rdx,r12
  40dc31:	call   40a770 <__swc_fn_585f006d_000016_4b207b58>
  40dc36:	jmp    40dcbd <__swc_fn_585f006d_000014_afb279e2+0x11d>
  40dc3b:	mov    rcx,rdi
  40dc3e:	movzx  edx,dl
  40dc41:	call   40db80 <__swc_fn_585f006d_000011_6493fbbc>
  40dc46:	test   r13,r13
  40dc49:	je     40dcb6 <__swc_fn_585f006d_000014_afb279e2+0x116>
  40dc4f:	mov    rcx,rax
  40dc52:	mov    rdx,r13
  40dc55:	call   40c7c0 <__swc_fn_585f006d_000112_759e9ceb>
  40dc5a:	mov    rcx,QWORD PTR [rip+0x153e7]        # 423048 <__swc_bss_base_585f006d+0x8>
  40dc61:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc6b:	nop    DWORD PTR [rax+rax*1+0x0]
  40dc70:	mov    rdx,rcx
  40dc73:	sub    rdx,r13
  40dc76:	mov    rax,rcx
  40dc79:	lock cmpxchg QWORD PTR [r14],rdx
  40dc7e:	cmp    rax,rcx
  40dc81:	je     40dc88 <__swc_fn_585f006d_000014_afb279e2+0xe8>
  40dc83:	mov    rcx,rax
  40dc86:	jmp    40dc70 <__swc_fn_585f006d_000014_afb279e2+0xd0>
  40dc88:	lea    rcx,[rip+0x153d1]        # 423060 <__swc_bss_base_585f006d+0x20>
  40dc8f:	mov    rdx,QWORD PTR [rip+0x153ca]        # 423060 <__swc_bss_base_585f006d+0x20>
  40dc96:	cs nop WORD PTR [rax+rax*1+0x0]
  40dca0:	lea    r8,[rdx+0x1]
  40dca4:	mov    rax,rdx
  40dca7:	lock cmpxchg QWORD PTR [rcx],r8
  40dcac:	cmp    rax,rdx
  40dcaf:	je     40dcb6 <__swc_fn_585f006d_000014_afb279e2+0x116>
  40dcb1:	mov    rdx,rax
  40dcb4:	jmp    40dca0 <__swc_fn_585f006d_000014_afb279e2+0x100>
  40dcb6:	mov    DWORD PTR [rsi+0x3c],0x0
  40dcbd:	mov    rcx,rdi
  40dcc0:	mov    rdx,r12
  40dcc3:	call   407600 <__swc_fn_585f006d_000018_7d1e8a10>
  40dcc8:	pop    r14
  40dcca:	pop    r13
  40dccc:	pop    r12
  40dcce:	pop    rdi
  40dccf:	pop    rsi
  40dcd0:	ret
	...

000000000040dce0 <__swc_fn_585f006d_000017_4df2d1a0>:
  40dce0:	mov    r8,QWORD PTR [rcx+0x48]
  40dce4:	test   r8,rdx
  40dce7:	je     40dd18 <__swc_fn_585f006d_000017_4df2d1a0+0x38>
  40dce9:	nop    DWORD PTR [rax+0x0]
  40dcf0:	mov    rax,rdx
  40dcf3:	not    rax
  40dcf6:	mov    r9,r8
  40dcf9:	and    r9,rax
  40dcfc:	mov    rax,r8
  40dcff:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40dd05:	cmp    rax,r8
  40dd08:	jne    40dd10 <__swc_fn_585f006d_000017_4df2d1a0+0x30>
  40dd0a:	mov    eax,0x1
  40dd0f:	ret
  40dd10:	mov    r8,rax
  40dd13:	test   rax,rdx
  40dd16:	jne    40dcf0 <__swc_fn_585f006d_000017_4df2d1a0+0x10>
  40dd18:	xor    eax,eax
  40dd1a:	ret
  40dd1b:	add    BYTE PTR [rax],al
  40dd1d:	add    BYTE PTR [rax],al
	...

000000000040dd20 <__swc_fn_585f006d_000020_a66e8b97>:
  40dd20:	push   rsi
  40dd21:	push   rdi
  40dd22:	push   r12
  40dd24:	push   r13
  40dd26:	sub    rsp,0x8
  40dd2a:	mov    rsi,rdx
  40dd2d:	mov    rdi,rcx
  40dd30:	lea    r12,[rip+0x154b9]        # 4231f0 <__swc_bss_base_585f006d+0x1b0>
  40dd37:	mov    rcx,r12
  40dd3a:	call   4098c0 <__swc_fn_585f006d_000135_e3032dc2>
  40dd3f:	xor    eax,eax
  40dd41:	mov    rcx,QWORD PTR [rip+0x154b0]        # 4231f8 <__swc_bss_base_585f006d+0x1b8>
  40dd48:	mov    r13,rcx
  40dd4b:	test   r13,r13
  40dd4e:	je     40dd9b <__swc_fn_585f006d_000020_a66e8b97+0x7b>
  40dd50:	mov    rcx,QWORD PTR [r13+0x10]
  40dd54:	cmp    DWORD PTR [r13+0x28],esi
  40dd58:	jne    40dd90 <__swc_fn_585f006d_000020_a66e8b97+0x70>
  40dd5a:	test   rax,rax
  40dd5d:	jne    40dd68 <__swc_fn_585f006d_000020_a66e8b97+0x48>
  40dd5f:	mov    QWORD PTR [rip+0x15492],rcx        # 4231f8 <__swc_bss_base_585f006d+0x1b8>
  40dd66:	jmp    40dd6c <__swc_fn_585f006d_000020_a66e8b97+0x4c>
  40dd68:	mov    QWORD PTR [rax+0x10],rcx
  40dd6c:	vxorps xmm0,xmm0,xmm0
  40dd70:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40dd76:	mov    QWORD PTR [r13+0x8],rdi
  40dd7a:	mov    rcx,r12
  40dd7d:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  40dd82:	mov    rax,r13
  40dd85:	add    rsp,0x8
  40dd89:	pop    r13
  40dd8b:	pop    r12
  40dd8d:	pop    rdi
  40dd8e:	pop    rsi
  40dd8f:	ret
  40dd90:	mov    rax,r13
  40dd93:	mov    r13,rcx
  40dd96:	test   rcx,rcx
  40dd99:	jne    40dd50 <__swc_fn_585f006d_000020_a66e8b97+0x30>
  40dd9b:	mov    ecx,esi
  40dd9d:	call   40a7a0 <__swc_fn_585f006d_000019_2cc1532c>
  40dda2:	mov    rsi,rax
  40dda5:	test   rax,rax
  40dda8:	jne    40ddbf <__swc_fn_585f006d_000020_a66e8b97+0x9f>
  40ddaa:	mov    rcx,r12
  40ddad:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  40ddb2:	xor    eax,eax
  40ddb4:	add    rsp,0x8
  40ddb8:	pop    r13
  40ddba:	pop    r12
  40ddbc:	pop    rdi
  40ddbd:	pop    rsi
  40ddbe:	ret
  40ddbf:	mov    QWORD PTR [rsi+0x8],rdi
  40ddc3:	mov    rcx,r12
  40ddc6:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  40ddcb:	mov    rax,rsi
  40ddce:	add    rsp,0x8
  40ddd2:	pop    r13
  40ddd4:	pop    r12
  40ddd6:	pop    rdi
  40ddd7:	pop    rsi
  40ddd8:	ret
  40ddd9:	add    BYTE PTR [rax],al
  40dddb:	add    BYTE PTR [rax],al
  40dddd:	add    BYTE PTR [rax],al
	...

000000000040dde0 <__swc_fn_585f006d_000023_4aca8b9e>:
  40dde0:	vxorps xmm0,xmm0,xmm0
  40dde4:	xor    eax,eax
  40dde6:	cs nop WORD PTR [rax+rax*1+0x0]
  40ddf0:	cs nop WORD PTR [rax+rax*1+0x0]
  40ddfa:	nop    WORD PTR [rax+rax*1+0x0]
  40de00:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40de05:	add    rax,0x10
  40de09:	cmp    rax,0x2b00
  40de10:	jne    40de00 <__swc_fn_585f006d_000023_4aca8b9e+0x20>
  40de12:	ret
	...

000000000040de20 <__swc_fn_585f006d_000026_4aca8b9e>:
  40de20:	vxorps xmm0,xmm0,xmm0
  40de24:	vmovups XMMWORD PTR [rcx],xmm0
  40de28:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40de2d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40de32:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40de37:	ret
	...

000000000040de40 <__swc_fn_585f006d_000029_4aca8b9e>:
  40de40:	vxorps xmm0,xmm0,xmm0
  40de44:	vmovups XMMWORD PTR [rcx],xmm0
  40de48:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40de4d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40de52:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40de57:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40de5c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40de61:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40de66:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40de6b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40de73:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40de7b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40de83:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40de8b:	mov    QWORD PTR [rcx+0xc0],0x0
  40de96:	ret
	...

000000000040dea0 <__swc_fn_585f006d_000032_84881cd8>:
  40dea0:	push   rsi
  40dea1:	push   rdi
  40dea2:	sub    rsp,0x8
  40dea6:	mov    rsi,rcx
  40dea9:	lea    rdi,[rip+0x13150]        # 421000 <__swc_data_base_585f006d>
  40deb0:	mov    rax,QWORD PTR [rdi]
  40deb3:	cmp    rax,0xffffffffffffffff
  40deb7:	je     40debe <__swc_fn_585f006d_000032_84881cd8+0x1e>
  40deb9:	mov    rdi,rax
  40debc:	jmp    40deeb <__swc_fn_585f006d_000032_84881cd8+0x4b>
  40debe:	call   4095a0 <__swc_fn_585f006d_000123_9d2cbd72>
  40dec3:	mov    rcx,rax
  40dec6:	cmp    rax,0xffffffffffffffff
  40deca:	je     40defc <__swc_fn_585f006d_000032_84881cd8+0x5c>
  40decc:	mov    rax,0xffffffffffffffff
  40ded3:	lock cmpxchg QWORD PTR [rdi],rcx
  40ded8:	cmp    rax,0xffffffffffffffff
  40dedc:	je     40dee8 <__swc_fn_585f006d_000032_84881cd8+0x48>
  40dede:	mov    rdi,rax
  40dee1:	call   40cb90 <__swc_fn_585f006d_000124_667fbf24>
  40dee6:	jmp    40deeb <__swc_fn_585f006d_000032_84881cd8+0x4b>
  40dee8:	mov    rdi,rcx
  40deeb:	cmp    rdi,0xffffffffffffffff
  40deef:	je     40defc <__swc_fn_585f006d_000032_84881cd8+0x5c>
  40def1:	mov    rcx,rdi
  40def4:	mov    rdx,rsi
  40def7:	call   40fff0 <__swc_fn_585f006d_000125_ce762363>
  40defc:	add    rsp,0x8
  40df00:	pop    rdi
  40df01:	pop    rsi
  40df02:	ret
	...

000000000040df10 <__swc_fn_585f006d_000035_95622a2b>:
  40df10:	sub    rsp,0x38
  40df14:	mov    rax,rdx
  40df17:	test   dl,dl
  40df19:	jne    40df31 <__swc_fn_585f006d_000035_95622a2b+0x21>
  40df1b:	mov    rax,r8
  40df1e:	test   r8b,r8b
  40df21:	cmove  eax,r9d
  40df25:	test   al,al
  40df27:	cmove  eax,r10d
  40df2b:	test   al,al
  40df2d:	cmove  eax,r11d
  40df31:	test   al,al
  40df33:	jne    40df3a <__swc_fn_585f006d_000035_95622a2b+0x2a>
  40df35:	add    rsp,0x38
  40df39:	ret
  40df3a:	lea    rcx,[rip+0x41cf]        # 412110 <__swc_rdata_base_585f006d>
  40df41:	vmovups xmm0,XMMWORD PTR [rip+0x41d7]        # 412120 <__swc_rdata_base_585f006d+0x10>
  40df49:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40df4f:	vmovups xmm0,XMMWORD PTR [rip+0x41d9]        # 412130 <__swc_rdata_base_585f006d+0x20>
  40df57:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40df5d:	vmovups xmm0,XMMWORD PTR [rip+0x41db]        # 412140 <__swc_rdata_base_585f006d+0x30>
  40df65:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40df6b:	lea    rdx,[rsp+0x8]
  40df70:	call   40c3c0 <__swc_fn_585f006d_000103_67100064>
  40df75:	jmp    40df35 <__swc_fn_585f006d_000035_95622a2b+0x25>
	...

000000000040df80 <__swc_fn_585f006d_000038_788ceb38>:
  40df80:	sub    rsp,0x8
  40df84:	mov    eax,0x1000
  40df89:	test   eax,eax
  40df8b:	mov    r8d,0x8
  40df91:	cmove  eax,r8d
  40df95:	dec    rax
  40df98:	mov    r8,0xffffffffffffffff
  40df9f:	sub    r8,rax
  40dfa2:	cmp    rdx,r8
  40dfa5:	ja     40dfb5 <__swc_fn_585f006d_000038_788ceb38+0x35>
  40dfa7:	add    rdx,rax
  40dfaa:	not    rax
  40dfad:	mov    r8,rdx
  40dfb0:	and    r8,rax
  40dfb3:	jne    40dfbc <__swc_fn_585f006d_000038_788ceb38+0x3c>
  40dfb5:	xor    eax,eax
  40dfb7:	add    rsp,0x8
  40dfbb:	ret
  40dfbc:	mov    rdx,r8
  40dfbf:	call   40aac0 <__swc_fn_585f006d_000037_b4982903>
  40dfc4:	add    rsp,0x8
  40dfc8:	ret
  40dfc9:	add    BYTE PTR [rax],al
  40dfcb:	add    BYTE PTR [rax],al
  40dfcd:	add    BYTE PTR [rax],al
	...

000000000040dfd0 <__swc_fn_585f006d_000041_414cc921>:
  40dfd0:	push   rsi
  40dfd1:	push   rdi
  40dfd2:	sub    rsp,0x8
  40dfd6:	mov    rsi,rdx
  40dfd9:	mov    rdi,rcx
  40dfdc:	test   rdx,rdx
  40dfdf:	je     40dffb <__swc_fn_585f006d_000041_414cc921+0x2b>
  40dfe1:	xor    ecx,ecx
  40dfe3:	call   407720 <__swc_fn_585f006d_000033_7ca1566d>
  40dfe8:	mov    rax,QWORD PTR [rsi]
  40dfeb:	test   rax,rax
  40dfee:	je     40dffb <__swc_fn_585f006d_000041_414cc921+0x2b>
  40dff0:	mov    rcx,rax
  40dff3:	mov    rdx,rsi
  40dff6:	call   407840 <__swc_fn_585f006d_000042_bab03645>
  40dffb:	mov    rcx,rdi
  40dffe:	call   40ab20 <__swc_fn_585f006d_000040_6895916d>
  40e003:	mov    rsi,rax
  40e006:	test   rax,rax
  40e009:	jne    40e014 <__swc_fn_585f006d_000041_414cc921+0x44>
  40e00b:	xor    eax,eax
  40e00d:	add    rsp,0x8
  40e011:	pop    rdi
  40e012:	pop    rsi
  40e013:	ret
  40e014:	mov    rcx,rsi
  40e017:	call   407720 <__swc_fn_585f006d_000033_7ca1566d>
  40e01c:	mov    rax,rsi
  40e01f:	add    rsp,0x8
  40e023:	pop    rdi
  40e024:	pop    rsi
  40e025:	ret
	...

000000000040e030 <__swc_fn_585f006d_000044_9c2ade9b>:
  40e030:	movzx  eax,BYTE PTR [r8+0x39]
  40e035:	lea    rax,[rax+rax*4]
  40e039:	lea    rax,[rdx+rax*8+0x28]
  40e03e:	mov    ecx,DWORD PTR [r8+0x6c]
  40e042:	test   ecx,ecx
  40e044:	je     40e07d <__swc_fn_585f006d_000044_9c2ade9b+0x4d>
  40e046:	mov    rcx,QWORD PTR [r8+0x50]
  40e04a:	test   rcx,rcx
  40e04d:	je     40e059 <__swc_fn_585f006d_000044_9c2ade9b+0x29>
  40e04f:	mov    rax,QWORD PTR [r8+0x48]
  40e053:	mov    QWORD PTR [rcx+0x48],rax
  40e057:	jmp    40e061 <__swc_fn_585f006d_000044_9c2ade9b+0x31>
  40e059:	mov    rcx,QWORD PTR [r8+0x48]
  40e05d:	mov    QWORD PTR [rax+0x18],rcx
  40e061:	mov    rax,QWORD PTR [r8+0x48]
  40e065:	test   rax,rax
  40e068:	je     40e072 <__swc_fn_585f006d_000044_9c2ade9b+0x42>
  40e06a:	mov    rcx,QWORD PTR [r8+0x50]
  40e06e:	mov    QWORD PTR [rax+0x50],rcx
  40e072:	vxorps xmm0,xmm0,xmm0
  40e076:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e07c:	ret
  40e07d:	mov    rcx,QWORD PTR [r8+0x50]
  40e081:	test   rcx,rcx
  40e084:	je     40e090 <__swc_fn_585f006d_000044_9c2ade9b+0x60>
  40e086:	mov    rdx,QWORD PTR [r8+0x48]
  40e08a:	mov    QWORD PTR [rcx+0x48],rdx
  40e08e:	jmp    40e098 <__swc_fn_585f006d_000044_9c2ade9b+0x68>
  40e090:	mov    rcx,QWORD PTR [r8+0x48]
  40e094:	mov    QWORD PTR [rax+0x8],rcx
  40e098:	mov    rcx,QWORD PTR [r8+0x48]
  40e09c:	test   rcx,rcx
  40e09f:	je     40e0ab <__swc_fn_585f006d_000044_9c2ade9b+0x7b>
  40e0a1:	mov    rdx,QWORD PTR [r8+0x50]
  40e0a5:	mov    QWORD PTR [rcx+0x50],rdx
  40e0a9:	jmp    40e0b3 <__swc_fn_585f006d_000044_9c2ade9b+0x83>
  40e0ab:	mov    rcx,QWORD PTR [r8+0x50]
  40e0af:	mov    QWORD PTR [rax+0x10],rcx
  40e0b3:	cmp    QWORD PTR [rax],r8
  40e0b6:	jne    40e0bf <__swc_fn_585f006d_000044_9c2ade9b+0x8f>
  40e0b8:	mov    QWORD PTR [rax],0x0
  40e0bf:	vxorps xmm0,xmm0,xmm0
  40e0c3:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e0c9:	ret
  40e0ca:	add    BYTE PTR [rax],al
  40e0cc:	add    BYTE PTR [rax],al
	...

000000000040e0d0 <__swc_fn_585f006d_000047_bc5ec610>:
  40e0d0:	sub    rsp,0x8
  40e0d4:	mov    r9,r8
  40e0d7:	mov    r10,rdx
  40e0da:	call   40e030 <__swc_fn_585f006d_000044_9c2ade9b>
  40e0df:	mov    DWORD PTR [r9+0x6c],0x0
  40e0e7:	movzx  eax,BYTE PTR [r9+0x39]
  40e0ec:	lea    rax,[rax+rax*4]
  40e0f0:	lea    rax,[r10+rax*8+0x28]
  40e0f5:	mov    rcx,QWORD PTR [rax+0x10]
  40e0f9:	mov    QWORD PTR [r9+0x50],rcx
  40e0fd:	mov    QWORD PTR [r9+0x48],0x0
  40e105:	mov    rcx,QWORD PTR [rax+0x10]
  40e109:	test   rcx,rcx
  40e10c:	je     40e114 <__swc_fn_585f006d_000047_bc5ec610+0x44>
  40e10e:	mov    QWORD PTR [rcx+0x48],r9
  40e112:	jmp    40e118 <__swc_fn_585f006d_000047_bc5ec610+0x48>
  40e114:	mov    QWORD PTR [rax+0x8],r9
  40e118:	mov    QWORD PTR [rax+0x10],r9
  40e11c:	add    rsp,0x8
  40e120:	ret
	...

000000000040e140 <__swc_fn_585f006d_000050_ab8077df>:
  40e140:	push   rsi
  40e141:	push   rdi
  40e142:	push   r12
  40e144:	push   r13
  40e146:	push   r14
  40e148:	push   r15
  40e14a:	sub    rsp,0x1f8
  40e151:	mov    esi,r8d
  40e154:	mov    QWORD PTR [rsp+0x1e8],rsi
  40e15c:	mov    rdi,rcx
  40e15f:	mov    r12,rdx
  40e162:	lea    r13,[rsi+rsi*4]
  40e166:	lea    r13,[rdx+r13*8+0x28]
  40e16b:	call   407ca0 <__swc_fn_585f006d_000048_c877e9d2>
  40e170:	add    DWORD PTR [r12+0x24],0x1
  40e176:	test   BYTE PTR [r12+0x24],0x3f
  40e17c:	jne    40e186 <__swc_fn_585f006d_000050_ab8077df+0x46>
  40e17e:	mov    rcx,rdi
  40e181:	call   40aca0 <__swc_fn_585f006d_000049_2ff013cc>
  40e186:	mov    rax,QWORD PTR [r13+0x8]
  40e18a:	mov    r14,rax
  40e18d:	nop    DWORD PTR [rax]
  40e190:	test   r14,r14
  40e193:	jne    40e1a2 <__swc_fn_585f006d_000050_ab8077df+0x62>
  40e195:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40e19d:	jmp    40e2a9 <__swc_fn_585f006d_000050_ab8077df+0x169>
  40e1a2:	mov    r15,QWORD PTR [r14+0x48]
  40e1a6:	mov    rcx,r14
  40e1a9:	call   4073f0 <__swc_fn_585f006d_000009_d7e2bb25>
  40e1ae:	mov    rax,QWORD PTR [r14]
  40e1b1:	test   rax,rax
  40e1b4:	je     40e1c6 <__swc_fn_585f006d_000050_ab8077df+0x86>
  40e1b6:	mov    rcx,QWORD PTR [rax]
  40e1b9:	mov    QWORD PTR [r14],rcx
  40e1bc:	add    DWORD PTR [r14+0x28],0x1
  40e1c1:	mov    rsi,rax
  40e1c4:	jmp    40e1e5 <__swc_fn_585f006d_000050_ab8077df+0xa5>
  40e1c6:	mov    rax,QWORD PTR [r14+0x18]
  40e1ca:	cmp    QWORD PTR [r14+0x20],rax
  40e1ce:	jae    40e1e3 <__swc_fn_585f006d_000050_ab8077df+0xa3>
  40e1d0:	mov    rsi,QWORD PTR [r14+0x20]
  40e1d4:	mov    eax,DWORD PTR [r14+0x2c]
  40e1d8:	add    QWORD PTR [r14+0x20],rax
  40e1dc:	add    DWORD PTR [r14+0x28],0x1
  40e1e1:	jmp    40e1e5 <__swc_fn_585f006d_000050_ab8077df+0xa5>
  40e1e3:	xor    esi,esi
  40e1e5:	test   rsi,rsi
  40e1e8:	jne    40e22d <__swc_fn_585f006d_000050_ab8077df+0xed>
  40e1ea:	mov    rcx,r14
  40e1ed:	call   407320 <__swc_fn_585f006d_000006_a23dca5f>
  40e1f2:	test   al,al
  40e1f4:	je     40e22d <__swc_fn_585f006d_000050_ab8077df+0xed>
  40e1f6:	mov    rax,QWORD PTR [r14]
  40e1f9:	test   rax,rax
  40e1fc:	je     40e20b <__swc_fn_585f006d_000050_ab8077df+0xcb>
  40e1fe:	mov    rcx,QWORD PTR [rax]
  40e201:	mov    QWORD PTR [r14],rcx
  40e204:	add    DWORD PTR [r14+0x28],0x1
  40e209:	jmp    40e22a <__swc_fn_585f006d_000050_ab8077df+0xea>
  40e20b:	mov    rax,QWORD PTR [r14+0x18]
  40e20f:	cmp    QWORD PTR [r14+0x20],rax
  40e213:	jae    40e228 <__swc_fn_585f006d_000050_ab8077df+0xe8>
  40e215:	mov    rax,QWORD PTR [r14+0x20]
  40e219:	mov    ecx,DWORD PTR [r14+0x2c]
  40e21d:	add    QWORD PTR [r14+0x20],rcx
  40e221:	add    DWORD PTR [r14+0x28],0x1
  40e226:	jmp    40e22a <__swc_fn_585f006d_000050_ab8077df+0xea>
  40e228:	xor    eax,eax
  40e22a:	mov    rsi,rax
  40e22d:	test   rsi,rsi
  40e230:	jne    40e283 <__swc_fn_585f006d_000050_ab8077df+0x143>
  40e232:	mov    rcx,rdi
  40e235:	mov    rdx,r12
  40e238:	mov    r8,r14
  40e23b:	call   40ac00 <__swc_fn_585f006d_000046_88f44774>
  40e240:	test   al,al
  40e242:	jne    40e283 <__swc_fn_585f006d_000050_ab8077df+0x143>
  40e244:	mov    rcx,r14
  40e247:	call   4073f0 <__swc_fn_585f006d_000009_d7e2bb25>
  40e24c:	mov    rax,QWORD PTR [r14]
  40e24f:	test   rax,rax
  40e252:	je     40e261 <__swc_fn_585f006d_000050_ab8077df+0x121>
  40e254:	mov    rcx,QWORD PTR [rax]
  40e257:	mov    QWORD PTR [r14],rcx
  40e25a:	add    DWORD PTR [r14+0x28],0x1
  40e25f:	jmp    40e280 <__swc_fn_585f006d_000050_ab8077df+0x140>
  40e261:	mov    rax,QWORD PTR [r14+0x18]
  40e265:	cmp    QWORD PTR [r14+0x20],rax
  40e269:	jae    40e27e <__swc_fn_585f006d_000050_ab8077df+0x13e>
  40e26b:	mov    rax,QWORD PTR [r14+0x20]
  40e26f:	mov    ecx,DWORD PTR [r14+0x2c]
  40e273:	add    QWORD PTR [r14+0x20],rcx
  40e277:	add    DWORD PTR [r14+0x28],0x1
  40e27c:	jmp    40e280 <__swc_fn_585f006d_000050_ab8077df+0x140>
  40e27e:	xor    eax,eax
  40e280:	mov    rsi,rax
  40e283:	test   rsi,rsi
  40e286:	je     40e2a1 <__swc_fn_585f006d_000050_ab8077df+0x161>
  40e288:	mov    QWORD PTR [r13+0x0],r14
  40e28c:	mov    rax,rsi
  40e28f:	add    rsp,0x1f8
  40e296:	pop    r15
  40e298:	pop    r14
  40e29a:	pop    r13
  40e29c:	pop    r12
  40e29e:	pop    rdi
  40e29f:	pop    rsi
  40e2a0:	ret
  40e2a1:	mov    r14,r15
  40e2a4:	jmp    40e190 <__swc_fn_585f006d_000050_ab8077df+0x50>
  40e2a9:	cs nop WORD PTR [rax+rax*1+0x0]
  40e2b3:	cs nop WORD PTR [rax+rax*1+0x0]
  40e2bd:	nop    DWORD PTR [rax]
  40e2c0:	mov    rcx,rdi
  40e2c3:	mov    rdx,r12
  40e2c6:	mov    r8d,esi
  40e2c9:	call   4079e0 <__swc_fn_585f006d_000045_1fe0f4e2>
  40e2ce:	mov    r14,rax
  40e2d1:	test   rax,rax
  40e2d4:	jne    40e2ea <__swc_fn_585f006d_000050_ab8077df+0x1aa>
  40e2d6:	xor    eax,eax
  40e2d8:	add    rsp,0x1f8
  40e2df:	pop    r15
  40e2e1:	pop    r14
  40e2e3:	pop    r13
  40e2e5:	pop    r12
  40e2e7:	pop    rdi
  40e2e8:	pop    rsi
  40e2e9:	ret
  40e2ea:	mov    QWORD PTR [r13+0x0],r14
  40e2ee:	mov    rax,QWORD PTR [r14]
  40e2f1:	test   rax,rax
  40e2f4:	je     40e306 <__swc_fn_585f006d_000050_ab8077df+0x1c6>
  40e2f6:	mov    rcx,QWORD PTR [rax]
  40e2f9:	mov    QWORD PTR [r14],rcx
  40e2fc:	add    DWORD PTR [r14+0x28],0x1
  40e301:	mov    r15,rax
  40e304:	jmp    40e326 <__swc_fn_585f006d_000050_ab8077df+0x1e6>
  40e306:	mov    rax,QWORD PTR [r14+0x18]
  40e30a:	cmp    QWORD PTR [r14+0x20],rax
  40e30e:	jae    40e323 <__swc_fn_585f006d_000050_ab8077df+0x1e3>
  40e310:	mov    r15,QWORD PTR [r14+0x20]
  40e314:	mov    eax,DWORD PTR [r14+0x2c]
  40e318:	add    QWORD PTR [r14+0x20],rax
  40e31c:	add    DWORD PTR [r14+0x28],0x1
  40e321:	jmp    40e326 <__swc_fn_585f006d_000050_ab8077df+0x1e6>
  40e323:	xor    r15d,r15d
  40e326:	test   r15,r15
  40e329:	jne    40e36e <__swc_fn_585f006d_000050_ab8077df+0x22e>
  40e32b:	mov    rcx,r14
  40e32e:	call   407320 <__swc_fn_585f006d_000006_a23dca5f>
  40e333:	test   al,al
  40e335:	je     40e36e <__swc_fn_585f006d_000050_ab8077df+0x22e>
  40e337:	mov    rax,QWORD PTR [r14]
  40e33a:	test   rax,rax
  40e33d:	je     40e34c <__swc_fn_585f006d_000050_ab8077df+0x20c>
  40e33f:	mov    rcx,QWORD PTR [rax]
  40e342:	mov    QWORD PTR [r14],rcx
  40e345:	add    DWORD PTR [r14+0x28],0x1
  40e34a:	jmp    40e36b <__swc_fn_585f006d_000050_ab8077df+0x22b>
  40e34c:	mov    rax,QWORD PTR [r14+0x18]
  40e350:	cmp    QWORD PTR [r14+0x20],rax
  40e354:	jae    40e369 <__swc_fn_585f006d_000050_ab8077df+0x229>
  40e356:	mov    rax,QWORD PTR [r14+0x20]
  40e35a:	mov    ecx,DWORD PTR [r14+0x2c]
  40e35e:	add    QWORD PTR [r14+0x20],rcx
  40e362:	add    DWORD PTR [r14+0x28],0x1
  40e367:	jmp    40e36b <__swc_fn_585f006d_000050_ab8077df+0x22b>
  40e369:	xor    eax,eax
  40e36b:	mov    r15,rax
  40e36e:	test   r15,r15
  40e371:	je     40e2c0 <__swc_fn_585f006d_000050_ab8077df+0x180>
  40e377:	mov    rax,r15
  40e37a:	add    rsp,0x1f8
  40e381:	pop    r15
  40e383:	pop    r14
  40e385:	pop    r13
  40e387:	pop    r12
  40e389:	pop    rdi
  40e38a:	pop    rsi
  40e38b:	ret
  40e38c:	add    BYTE PTR [rax],al
	...

000000000040e390 <__swc_fn_585f006d_000053_82546d94>:
  40e390:	push   rsi
  40e391:	push   rdi
  40e392:	push   r12
  40e394:	mov    rsi,rdx
  40e397:	mov    rax,rdx
  40e39a:	shr    rax,0xc
  40e39e:	movabs rdx,0x9e3779b97f4a7c15
  40e3a8:	imul   rax,rdx
  40e3ac:	shr    rax,0x20
  40e3b0:	lea    rax,[rax*8+0x0]
  40e3b8:	shr    rax,0x20
  40e3bc:	lea    rax,[rax*8+0x0]
  40e3c4:	lea    rax,[rcx+rax*8+0x40]
  40e3c9:	xor    edx,edx
  40e3cb:	test   dl,dl
  40e3cd:	lea    rdi,[rcx+0x8]
  40e3d1:	cmove  rdi,rax
  40e3d5:	xor    edx,edx
  40e3d7:	test   dl,dl
  40e3d9:	lea    r12,[rcx+0x30]
  40e3dd:	lea    rax,[rax+0x8]
  40e3e1:	cmove  r12,rax
  40e3e5:	mov    rcx,rdi
  40e3e8:	call   4098c0 <__swc_fn_585f006d_000135_e3032dc2>
  40e3ed:	mov    QWORD PTR [rsi+0x30],0x0
  40e3f5:	mov    rax,QWORD PTR [r12]
  40e3f9:	mov    QWORD PTR [rsi+0x38],rax
  40e3fd:	test   rax,rax
  40e400:	je     40e40a <__swc_fn_585f006d_000053_82546d94+0x7a>
  40e402:	mov    rax,QWORD PTR [rsi+0x38]
  40e406:	mov    QWORD PTR [rax+0x30],rsi
  40e40a:	mov    QWORD PTR [r12],rsi
  40e40e:	mov    rcx,rdi
  40e411:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  40e416:	pop    r12
  40e418:	pop    rdi
  40e419:	pop    rsi
  40e41a:	ret
  40e41b:	add    BYTE PTR [rax],al
  40e41d:	add    BYTE PTR [rax],al
	...

000000000040e420 <__swc_fn_585f006d_000056_38b21f11>:
  40e420:	lea    rax,[rdx+rdx*4]
  40e424:	lea    rax,[rcx+rax*8+0x268]
  40e42c:	mov    rdx,QWORD PTR [rax+0x10]
  40e430:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e437:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e43f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e446:	lea    rdx,[rdx+rdx*4]
  40e44a:	lea    rdx,[rcx+rdx*8+0x268]
  40e452:	vmovups xmm0,XMMWORD PTR [rdx]
  40e456:	vmovups XMMWORD PTR [rax],xmm0
  40e45a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e45f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e464:	mov    rcx,QWORD PTR [rdx+0x20]
  40e468:	mov    QWORD PTR [rax+0x20],rcx
  40e46c:	ret
  40e46d:	add    BYTE PTR [rax],al
	...

000000000040e470 <__swc_fn_585f006d_000059_3ca3ac64>:
  40e470:	push   rsi
  40e471:	push   rdi
  40e472:	push   r12
  40e474:	push   r13
  40e476:	sub    rsp,0x8
  40e47a:	mov    rsi,r8
  40e47d:	mov    rdi,rcx
  40e480:	mov    r12,rdx
  40e483:	xor    r13d,r13d
  40e486:	cs nop WORD PTR [rax+rax*1+0x0]
  40e490:	mov    eax,DWORD PTR [r12+0x730]
  40e498:	cmp    r13d,eax
  40e49b:	jae    40e501 <__swc_fn_585f006d_000059_3ca3ac64+0x91>
  40e49d:	lea    rax,[r13+r13*4+0x0]
  40e4a2:	lea    rax,[r12+rax*8+0x738]
  40e4aa:	mov    rdx,QWORD PTR [rax]
  40e4ad:	mov    r8,QWORD PTR [rax+0x8]
  40e4b1:	mov    r9,QWORD PTR [rax+0x10]
  40e4b5:	cmp    QWORD PTR [rax+0x20],rsi
  40e4b9:	jb     40e4c0 <__swc_fn_585f006d_000059_3ca3ac64+0x50>
  40e4bb:	inc    r13d
  40e4be:	jmp    40e490 <__swc_fn_585f006d_000059_3ca3ac64+0x20>
  40e4c0:	sub    DWORD PTR [r12+0x730],0x1
  40e4c9:	mov    ecx,DWORD PTR [r12+0x730]
  40e4d1:	lea    rcx,[rcx+rcx*4]
  40e4d5:	lea    rcx,[r12+rcx*8+0x738]
  40e4dd:	vmovups xmm0,XMMWORD PTR [rcx]
  40e4e1:	vmovups XMMWORD PTR [rax],xmm0
  40e4e5:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e4ea:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e4ef:	mov    rcx,QWORD PTR [rcx+0x20]
  40e4f3:	mov    QWORD PTR [rax+0x20],rcx
  40e4f7:	mov    rcx,rdi
  40e4fa:	call   407750 <__swc_fn_585f006d_000039_40d1e569>
  40e4ff:	jmp    40e490 <__swc_fn_585f006d_000059_3ca3ac64+0x20>
  40e501:	add    rsp,0x8
  40e505:	pop    r13
  40e507:	pop    r12
  40e509:	pop    rdi
  40e50a:	pop    rsi
  40e50b:	ret
  40e50c:	add    BYTE PTR [rax],al
	...

000000000040e510 <__swc_fn_585f006d_000062_7e482c5f>:
  40e510:	push   rsi
  40e511:	push   rdi
  40e512:	push   r12
  40e514:	push   r13
  40e516:	push   r14
  40e518:	mov    rsi,rcx
  40e51b:	mov    rdi,rdx
  40e51e:	mov    r12,QWORD PTR [rdi]
  40e521:	mov    r13,QWORD PTR [rdi+0x18]
  40e525:	mov    rax,r12
  40e528:	add    rax,QWORD PTR [rdi+0x8]
  40e52c:	sub    rax,r13
  40e52f:	cmp    r8,rax
  40e532:	jbe    40e53d <__swc_fn_585f006d_000062_7e482c5f+0x2d>
  40e534:	pop    r14
  40e536:	pop    r13
  40e538:	pop    r12
  40e53a:	pop    rdi
  40e53b:	pop    rsi
  40e53c:	ret
  40e53d:	lea    rax,[r13+r8*1+0x0]
  40e542:	sub    rax,r12
  40e545:	mov    ecx,0x1000
  40e54a:	test   ecx,ecx
  40e54c:	mov    edx,0x8
  40e551:	cmove  ecx,edx
  40e554:	dec    rcx
  40e557:	mov    rdx,0xffffffffffffffff
  40e55e:	sub    rdx,rcx
  40e561:	cmp    rax,rdx
  40e564:	jbe    40e56b <__swc_fn_585f006d_000062_7e482c5f+0x5b>
  40e566:	xor    r14d,r14d
  40e569:	jmp    40e576 <__swc_fn_585f006d_000062_7e482c5f+0x66>
  40e56b:	add    rax,rcx
  40e56e:	andn   rax,rcx,rax
  40e573:	mov    r14,rax
  40e576:	mov    rax,QWORD PTR [rdi+0x10]
  40e57a:	cmp    r14,rax
  40e57d:	ja     40e588 <__swc_fn_585f006d_000062_7e482c5f+0x78>
  40e57f:	pop    r14
  40e581:	pop    r13
  40e583:	pop    r12
  40e585:	pop    rdi
  40e586:	pop    rsi
  40e587:	ret
  40e588:	mov    rax,r12
  40e58b:	add    rax,QWORD PTR [rdi+0x10]
  40e58f:	mov    rdx,r14
  40e592:	sub    rdx,QWORD PTR [rdi+0x10]
  40e596:	mov    rcx,rax
  40e599:	call   4072a0 <__swc_fn_585f006d_000003_7ab4792e>
  40e59e:	test   al,al
  40e5a0:	jne    40e5ab <__swc_fn_585f006d_000062_7e482c5f+0x9b>
  40e5a2:	pop    r14
  40e5a4:	pop    r13
  40e5a6:	pop    r12
  40e5a8:	pop    rdi
  40e5a9:	pop    rsi
  40e5aa:	ret
  40e5ab:	add    r12,r14
  40e5ae:	sub    r12,r13
  40e5b1:	mov    rcx,r12
  40e5b4:	sub    rcx,QWORD PTR [rdi+0x28]
  40e5b8:	mov    rdx,QWORD PTR [rsi+0x250]
  40e5bf:	nop
  40e5c0:	lea    r8,[rdx+rcx*1]
  40e5c4:	mov    rax,rdx
  40e5c7:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40e5d0:	cmp    rax,rdx
  40e5d3:	je     40e5da <__swc_fn_585f006d_000062_7e482c5f+0xca>
  40e5d5:	mov    rdx,rax
  40e5d8:	jmp    40e5c0 <__swc_fn_585f006d_000062_7e482c5f+0xb0>
  40e5da:	mov    QWORD PTR [rdi+0x10],r14
  40e5de:	mov    QWORD PTR [rdi+0x28],r12
  40e5e2:	pop    r14
  40e5e4:	pop    r13
  40e5e6:	pop    r12
  40e5e8:	pop    rdi
  40e5e9:	pop    rsi
  40e5ea:	ret
  40e5eb:	add    BYTE PTR [rax],al
  40e5ed:	add    BYTE PTR [rax],al
	...

000000000040e5f0 <__swc_fn_585f006d_000065_f9f4b610>:
  40e5f0:	push   rbx
  40e5f1:	push   rsi
  40e5f2:	push   rdi
  40e5f3:	push   r12
  40e5f5:	push   r13
  40e5f7:	sub    rsp,0xe0
  40e5fe:	mov    rbx,rdx
  40e601:	mov    rsi,rcx
  40e604:	cmp    DWORD PTR [rbx+0x58],0x0
  40e608:	je     40e62c <__swc_fn_585f006d_000065_f9f4b610+0x3c>
  40e60a:	mov    eax,DWORD PTR [rbx+0x58]
  40e60d:	sub    eax,0x1
  40e610:	test   DWORD PTR [rbx+0x58],eax
  40e613:	je     40e62c <__swc_fn_585f006d_000065_f9f4b610+0x3c>
  40e615:	mov    QWORD PTR [rbx+0x40],0x0
  40e61d:	add    rsp,0xe0
  40e624:	pop    r13
  40e626:	pop    r12
  40e628:	pop    rdi
  40e629:	pop    rsi
  40e62a:	pop    rbx
  40e62b:	ret
  40e62c:	mov    rax,QWORD PTR [rbx+0x40]
  40e630:	test   rax,rax
  40e633:	jne    40e64f <__swc_fn_585f006d_000065_f9f4b610+0x5f>
  40e635:	mov    rcx,rsi
  40e638:	mov    rdx,rbx
  40e63b:	call   40b8b0 <__swc_fn_585f006d_000064_b0d63361>
  40e640:	add    rsp,0xe0
  40e647:	pop    r13
  40e649:	pop    r12
  40e64b:	pop    rdi
  40e64c:	pop    rsi
  40e64d:	pop    rbx
  40e64e:	ret
  40e64f:	cmp    QWORD PTR [rbx+0x48],0x0
  40e654:	jne    40e670 <__swc_fn_585f006d_000065_f9f4b610+0x80>
  40e656:	mov    rcx,rsi
  40e659:	mov    rdx,rbx
  40e65c:	call   407f90 <__swc_fn_585f006d_000066_254b71af>
  40e661:	add    rsp,0xe0
  40e668:	pop    r13
  40e66a:	pop    r12
  40e66c:	pop    rdi
  40e66d:	pop    rsi
  40e66e:	pop    rbx
  40e66f:	ret
  40e670:	mov    rdi,QWORD PTR [rbx+0x40]
  40e674:	lea    rax,[rip+0x149f5]        # 423070 <__swc_bss_base_585f006d+0x30>
  40e67b:	mov    rcx,rdi
  40e67e:	sub    rcx,QWORD PTR [rax+0x8]
  40e682:	mov    rax,QWORD PTR [rip+0x149f7]        # 423080 <__swc_bss_base_585f006d+0x40>
  40e689:	cmp    rcx,rax
  40e68c:	jae    40e6b8 <__swc_fn_585f006d_000065_f9f4b610+0xc8>
  40e68e:	mov    rax,rdi
  40e691:	and    rax,0xffffffffffc00000
  40e698:	mov    rcx,rdi
  40e69b:	shr    rcx,0x10
  40e69f:	and    ecx,0x3f
  40e6a2:	mov    edx,DWORD PTR [rax+0x28]
  40e6a5:	shrx   ecx,ecx,edx
  40e6aa:	shl    rcx,0x4
  40e6ae:	lea    r12,[rax+rcx*8+0x80]
  40e6b6:	jmp    40e6c3 <__swc_fn_585f006d_000065_f9f4b610+0xd3>
  40e6b8:	mov    rcx,rdi
  40e6bb:	call   40a930 <__swc_fn_585f006d_000022_3a2e2048>
  40e6c0:	mov    r12,rax
  40e6c3:	test   r12,r12
  40e6c6:	je     40e6d5 <__swc_fn_585f006d_000065_f9f4b610+0xe5>
  40e6c8:	mov    eax,DWORD PTR [r12+0x2c]
  40e6cd:	mov    r9d,eax
  40e6d0:	mov    r13,rax
  40e6d3:	jmp    40e754 <__swc_fn_585f006d_000065_f9f4b610+0x164>
  40e6d5:	mov    rcx,rsi
  40e6d8:	mov    rdx,rdi
  40e6db:	call   40af40 <__swc_fn_585f006d_000052_c7484fb0>
  40e6e0:	mov    rcx,QWORD PTR [rax+0x28]
  40e6e4:	mov    r9,rcx
  40e6e7:	mov    rdx,QWORD PTR [rax+0x20]
  40e6eb:	mov    r13,rdx
  40e6ee:	cmp    QWORD PTR [rbx+0x48],rcx
  40e6f2:	jbe    40e72b <__swc_fn_585f006d_000065_f9f4b610+0x13b>
  40e6f4:	mov    ecx,DWORD PTR [rax+0x48]
  40e6f7:	cmp    DWORD PTR [rbx+0x58],ecx
  40e6fa:	ja     40e72b <__swc_fn_585f006d_000065_f9f4b610+0x13b>
  40e6fc:	mov    rcx,rsi
  40e6ff:	mov    rdx,rax
  40e702:	mov    r8,QWORD PTR [rbx+0x48]
  40e706:	mov    QWORD PTR [rsp+0xc8],r9
  40e70e:	mov    QWORD PTR [rsp+0xd0],rax
  40e716:	call   40e510 <__swc_fn_585f006d_000062_7e482c5f>
  40e71b:	mov    r9,QWORD PTR [rsp+0xc8]
  40e723:	mov    rax,QWORD PTR [rsp+0xd0]
  40e72b:	mov    rcx,QWORD PTR [rax+0x28]
  40e72f:	cmp    QWORD PTR [rbx+0x48],rcx
  40e733:	ja     40e754 <__swc_fn_585f006d_000065_f9f4b610+0x164>
  40e735:	mov    ecx,DWORD PTR [rax+0x48]
  40e738:	cmp    DWORD PTR [rbx+0x58],ecx
  40e73b:	ja     40e754 <__swc_fn_585f006d_000065_f9f4b610+0x164>
  40e73d:	mov    rcx,QWORD PTR [rbx+0x48]
  40e741:	mov    QWORD PTR [rax+0x20],rcx
  40e745:	add    rsp,0xe0
  40e74c:	pop    r13
  40e74e:	pop    r12
  40e750:	pop    rdi
  40e751:	pop    rsi
  40e752:	pop    rbx
  40e753:	ret
  40e754:	test   r12,r12
  40e757:	je     40e789 <__swc_fn_585f006d_000065_f9f4b610+0x199>
  40e759:	cmp    QWORD PTR [rbx+0x48],r9
  40e75d:	ja     40e789 <__swc_fn_585f006d_000065_f9f4b610+0x199>
  40e75f:	cmp    DWORD PTR [rbx+0x58],0x40
  40e763:	ja     40e789 <__swc_fn_585f006d_000065_f9f4b610+0x199>
  40e765:	cmp    DWORD PTR [rbx+0x58],0x0
  40e769:	je     40e776 <__swc_fn_585f006d_000065_f9f4b610+0x186>
  40e76b:	mov    ecx,DWORD PTR [rbx+0x58]
  40e76e:	dec    rcx
  40e771:	test   rdi,rcx
  40e774:	jne    40e789 <__swc_fn_585f006d_000065_f9f4b610+0x199>
  40e776:	mov    QWORD PTR [rbx+0x40],rdi
  40e77a:	add    rsp,0xe0
  40e781:	pop    r13
  40e783:	pop    r12
  40e785:	pop    rdi
  40e786:	pop    rsi
  40e787:	pop    rbx
  40e788:	ret
  40e789:	vmovups xmm0,XMMWORD PTR [rbx]
  40e78d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e793:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e798:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e79e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e7a3:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e7a9:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e7ae:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40e7b4:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e7b9:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40e7bf:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e7c4:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40e7ca:	mov    QWORD PTR [rsp+0x48],0x0
  40e7d3:	mov    rcx,rsi
  40e7d6:	lea    rdx,[rsp+0x8]
  40e7db:	call   40b8b0 <__swc_fn_585f006d_000064_b0d63361>
  40e7e0:	mov    rax,QWORD PTR [rsp+0x48]
  40e7e5:	test   rax,rax
  40e7e8:	jne    40e801 <__swc_fn_585f006d_000065_f9f4b610+0x211>
  40e7ea:	mov    QWORD PTR [rbx+0x40],0x0
  40e7f2:	add    rsp,0xe0
  40e7f9:	pop    r13
  40e7fb:	pop    r12
  40e7fd:	pop    rdi
  40e7fe:	pop    rsi
  40e7ff:	pop    rbx
  40e800:	ret
  40e801:	mov    rax,QWORD PTR [rbx+0x48]
  40e805:	cmp    r13,rax
  40e808:	cmovbe rax,r13
  40e80c:	mov    rcx,QWORD PTR [rsp+0x48]
  40e811:	mov    rdx,rdi
  40e814:	mov    r8,rax
  40e817:	call   409100 <__swc_fn_585f006d_000105_6fd80914>
  40e81c:	vmovups xmm0,XMMWORD PTR [rbx]
  40e820:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40e826:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e82b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40e831:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e836:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40e83f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e844:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40e84d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e852:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40e85b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e860:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40e869:	mov    QWORD PTR [rsp+0xa8],rdi
  40e871:	mov    rcx,rsi
  40e874:	lea    rdx,[rsp+0x68]
  40e879:	call   407f90 <__swc_fn_585f006d_000066_254b71af>
  40e87e:	mov    rax,QWORD PTR [rsp+0x48]
  40e883:	mov    QWORD PTR [rbx+0x40],rax
  40e887:	add    rsp,0xe0
  40e88e:	pop    r13
  40e890:	pop    r12
  40e892:	pop    rdi
  40e893:	pop    rsi
  40e894:	pop    rbx
  40e895:	ret
	...

000000000040e8a0 <__swc_fn_585f006d_000068_7d4c42bf>:
  40e8a0:	push   r12
  40e8a2:	push   rdi
  40e8a3:	push   rsi
  40e8a4:	push   r13
  40e8a6:	push   r14
  40e8a8:	sub    rsp,0x190
  40e8af:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40e8b8:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40e8c1:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40e8ca:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40e8d3:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40e8dc:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40e8e5:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40e8ee:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40e8f7:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40e900:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40e909:	mov    r12,rcx
  40e90c:	lea    rax,[rip+0x126ed]        # 421000 <__swc_data_base_585f006d>
  40e913:	mov    rax,QWORD PTR [rax]
  40e916:	cmp    rax,0xffffffffffffffff
  40e91a:	je     40e929 <__swc_fn_585f006d_000068_7d4c42bf+0x89>
  40e91c:	mov    eax,eax
  40e91e:	mov    edi,eax
  40e920:	xor    eax,eax
  40e922:	call   407000 <pthread_getspecific@plt>
  40e927:	jmp    40e92b <__swc_fn_585f006d_000068_7d4c42bf+0x8b>
  40e929:	xor    eax,eax
  40e92b:	test   rax,rax
  40e92e:	jne    40e93d <__swc_fn_585f006d_000068_7d4c42bf+0x9d>
  40e930:	call   40aa00 <__swc_fn_585f006d_000031_90860ff2>
  40e935:	mov    rcx,rax
  40e938:	call   4100a0 <__swc_fn_585f006d_000128_41c3251c>
  40e93d:	test   rax,rax
  40e940:	je     40e966 <__swc_fn_585f006d_000068_7d4c42bf+0xc6>
  40e942:	cmp    QWORD PTR [rax],r12
  40e945:	jne    40e966 <__swc_fn_585f006d_000068_7d4c42bf+0xc6>
  40e947:	xor    ecx,ecx
  40e949:	mov    QWORD PTR [rsp+0xc8],rax
  40e951:	call   407720 <__swc_fn_585f006d_000033_7ca1566d>
  40e956:	mov    rdx,QWORD PTR [rsp+0xc8]
  40e95e:	mov    rcx,r12
  40e961:	call   407840 <__swc_fn_585f006d_000042_bab03645>
  40e966:	lea    rsi,[r12+0x10]
  40e96b:	mov    rcx,rsi
  40e96e:	call   4098c0 <__swc_fn_585f006d_000135_e3032dc2>
  40e973:	mov    rdi,QWORD PTR [r12+0x20]
  40e978:	test   rdi,rdi
  40e97b:	je     40e9be <__swc_fn_585f006d_000068_7d4c42bf+0x11e>
  40e97d:	nop    DWORD PTR [rax]
  40e980:	mov    rcx,r12
  40e983:	mov    rdx,rdi
  40e986:	call   40abc0 <__swc_fn_585f006d_000043_957e4917>
  40e98b:	mov    rcx,r12
  40e98e:	mov    rdx,rdi
  40e991:	mov    r8,0xffffffffffffffff
  40e998:	call   40e470 <__swc_fn_585f006d_000059_3ca3ac64>
  40e99d:	mov    rcx,r12
  40e9a0:	mov    rdx,rdi
  40e9a3:	mov    r8d,0x9b8
  40e9a9:	mov    r9d,0x9b8
  40e9af:	call   407750 <__swc_fn_585f006d_000039_40d1e569>
  40e9b4:	mov    rdi,QWORD PTR [r12+0x20]
  40e9b9:	test   rdi,rdi
  40e9bc:	jne    40e980 <__swc_fn_585f006d_000068_7d4c42bf+0xe0>
  40e9be:	xor    eax,eax
  40e9c0:	xchg   QWORD PTR [r12+0x2a80],rax
  40e9c8:	test   rax,rax
  40e9cb:	je     40e9f1 <__swc_fn_585f006d_000068_7d4c42bf+0x151>
  40e9cd:	cs nop WORD PTR [rax+rax*1+0x0]
  40e9d7:	nop    WORD PTR [rax+rax*1+0x0]
  40e9e0:	mov    rcx,rax
  40e9e3:	mov    rax,QWORD PTR [rax+0x78]
  40e9e7:	xor    edx,edx
  40e9e9:	xchg   DWORD PTR [rcx+0x70],edx
  40e9ec:	test   rax,rax
  40e9ef:	jne    40e9e0 <__swc_fn_585f006d_000068_7d4c42bf+0x140>
  40e9f1:	mov    rax,QWORD PTR [r12+0x18]
  40e9f6:	mov    rdi,rax
  40e9f9:	test   rdi,rdi
  40e9fc:	je     40ea91 <__swc_fn_585f006d_000068_7d4c42bf+0x1f1>
  40ea02:	cs nop WORD PTR [rax+rax*1+0x0]
  40ea0c:	nop    DWORD PTR [rax+0x0]
  40ea10:	mov    rax,QWORD PTR [rdi+0x10]
  40ea14:	mov    r8d,DWORD PTR [rdi+0x2c]
  40ea18:	xor    r9d,r9d
  40ea1b:	test   r8,r8
  40ea1e:	jbe    40ea7d <__swc_fn_585f006d_000068_7d4c42bf+0x1dd>
  40ea20:	mov    ecx,r9d
  40ea23:	shl    rcx,0x4
  40ea27:	lea    rdx,[rdi+rcx*8+0x80]
  40ea2f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40ea33:	je     40ea74 <__swc_fn_585f006d_000068_7d4c42bf+0x1d4>
  40ea35:	mov    DWORD PTR [rdx+0x28],0x0
  40ea3c:	mov    rcx,rdi
  40ea3f:	mov    QWORD PTR [rsp+0xd0],rax
  40ea47:	mov    QWORD PTR [rsp+0xd8],r8
  40ea4f:	mov    QWORD PTR [rsp+0xe0],r9
  40ea57:	call   40dba0 <__swc_fn_585f006d_000014_afb279e2>
  40ea5c:	mov    rax,QWORD PTR [rsp+0xd0]
  40ea64:	mov    r8,QWORD PTR [rsp+0xd8]
  40ea6c:	mov    r9,QWORD PTR [rsp+0xe0]
  40ea74:	add    r9,0x1
  40ea78:	cmp    r9,r8
  40ea7b:	jb     40ea20 <__swc_fn_585f006d_000068_7d4c42bf+0x180>
  40ea7d:	mov    rcx,rdi
  40ea80:	mov    rdi,rax
  40ea83:	call   407630 <__swc_fn_585f006d_000021_491ac000>
  40ea88:	test   rdi,rdi
  40ea8b:	jne    40ea10 <__swc_fn_585f006d_000068_7d4c42bf+0x170>
  40ea91:	mov    QWORD PTR [r12+0x18],0x0
  40ea9a:	mov    QWORD PTR [r12+0x28],0x0
  40eaa3:	mov    rcx,rsi
  40eaa6:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  40eaab:	mov    esi,0x8
  40eab0:	xor    edi,edi
  40eab2:	test   rsi,rsi
  40eab5:	je     40eb12 <__swc_fn_585f006d_000068_7d4c42bf+0x272>
  40eabb:	nop    DWORD PTR [rax+rax*1+0x0]
  40eac0:	lea    r13,[rdi*8+0x0]
  40eac8:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40eacd:	test   r14,r14
  40ead0:	je     40eb08 <__swc_fn_585f006d_000068_7d4c42bf+0x268>
  40ead2:	cs nop WORD PTR [rax+rax*1+0x0]
  40eadc:	nop    DWORD PTR [rax+0x0]
  40eae0:	mov    rcx,r12
  40eae3:	mov    rdx,r14
  40eae6:	call   407df0 <__swc_fn_585f006d_000054_ae20ea33>
  40eaeb:	mov    rcx,r12
  40eaee:	mov    rdx,QWORD PTR [r14]
  40eaf1:	mov    r8,QWORD PTR [r14+0x8]
  40eaf5:	mov    r9,QWORD PTR [r14+0x10]
  40eaf9:	call   407750 <__swc_fn_585f006d_000039_40d1e569>
  40eafe:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40eb03:	test   r14,r14
  40eb06:	jne    40eae0 <__swc_fn_585f006d_000068_7d4c42bf+0x240>
  40eb08:	add    rdi,0x1
  40eb0c:	sub    rsi,0x1
  40eb10:	jne    40eac0 <__swc_fn_585f006d_000068_7d4c42bf+0x220>
  40eb12:	mov    rcx,r12
  40eb15:	call   407ec0 <__swc_fn_585f006d_000060_e6407a0a>
  40eb1a:	lea    rcx,[r12+0x250]
  40eb22:	mov    rdx,QWORD PTR [rcx]
  40eb25:	mov    r8,QWORD PTR [r12+0x250]
  40eb2d:	nop    DWORD PTR [rax]
  40eb30:	mov    r9,r8
  40eb33:	sub    r9,rdx
  40eb36:	mov    rax,r8
  40eb39:	lock cmpxchg QWORD PTR [rcx],r9
  40eb3e:	cmp    rax,r8
  40eb41:	je     40eb48 <__swc_fn_585f006d_000068_7d4c42bf+0x2a8>
  40eb43:	mov    r8,rax
  40eb46:	jmp    40eb30 <__swc_fn_585f006d_000068_7d4c42bf+0x290>
  40eb48:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40eb51:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40eb5a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40eb63:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40eb6c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40eb75:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40eb7e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40eb87:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40eb90:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40eb99:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40eba2:	add    rsp,0x190
  40eba9:	pop    r14
  40ebab:	pop    r13
  40ebad:	pop    rsi
  40ebae:	pop    rdi
  40ebaf:	pop    r12
  40ebb1:	ret
	...

000000000040ebc0 <__swc_fn_585f006d_000071_0d1ef36f>:
  40ebc0:	sub    rsp,0x8
  40ebc4:	mov    QWORD PTR [rdx+0x40],0x0
  40ebcc:	call   40b8b0 <__swc_fn_585f006d_000064_b0d63361>
  40ebd1:	add    rsp,0x8
  40ebd5:	ret
	...

000000000040ebe0 <__swc_fn_585f006d_000074_518516c2>:
  40ebe0:	sub    rsp,0x8
  40ebe4:	call   407f90 <__swc_fn_585f006d_000066_254b71af>
  40ebe9:	add    rsp,0x8
  40ebed:	ret
	...

000000000040ebf0 <__swc_fn_585f006d_000077_8b8614a7>:
  40ebf0:	push   rbx
  40ebf1:	push   rsi
  40ebf2:	push   rdi
  40ebf3:	push   r12
  40ebf5:	push   r13
  40ebf7:	push   r14
  40ebf9:	push   r15
  40ebfb:	sub    rsp,0x20
  40ebff:	mov    rbx,r11
  40ec02:	mov    rsi,rcx
  40ec05:	mov    rdi,rdx
  40ec08:	mov    r12,r8
  40ec0b:	mov    r13,r9
  40ec0e:	mov    r14,r10
  40ec11:	mov    rcx,QWORD PTR [rip+0x17128]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40ec18:	test   rcx,rcx
  40ec1b:	jne    40ec2d <__swc_fn_585f006d_000077_8b8614a7+0x3d>
  40ec1d:	call   40a1d0 <__swc_fn_585f006d_000165_cf398896>
  40ec22:	lea    rcx,[rax+0x1]
  40ec26:	mov    QWORD PTR [rip+0x17113],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40ec2d:	dec    rcx
  40ec30:	call   411b60 <__swc_fn_585f006d_000167_fce60b2b>
  40ec35:	mov    r15,rax
  40ec38:	lea    r11,[rip+0x14601]        # 423240 <__swc_bss_base_585f006d+0x200>
  40ec3f:	mov    rcx,r11
  40ec42:	call   407740 <__swc_fn_585f006d_000036_8d895ba1>
  40ec47:	test   al,al
  40ec49:	jne    40ec5a <__swc_fn_585f006d_000077_8b8614a7+0x6a>
  40ec4b:	mov    rcx,r11
  40ec4e:	call   40aa60 <__swc_fn_585f006d_000034_25f19556>
  40ec53:	lea    r11,[rip+0x145e6]        # 423240 <__swc_bss_base_585f006d+0x200>
  40ec5a:	mov    rcx,r11
  40ec5d:	mov    rdx,rsi
  40ec60:	mov    r8,rdi
  40ec63:	mov    r9,r12
  40ec66:	mov    r10,r13
  40ec69:	mov    rsi,r11
  40ec6c:	mov    r11,r14
  40ec6f:	call   40df10 <__swc_fn_585f006d_000035_95622a2b>
  40ec74:	test   bl,bl
  40ec76:	je     40ec9d <__swc_fn_585f006d_000077_8b8614a7+0xad>
  40ec78:	mov    QWORD PTR [rsp+0x8],rsi
  40ec7d:	lea    rax,[rip+0x34cc]        # 412150 <__swc_rdata_base_585f006d+0x40>
  40ec84:	mov    QWORD PTR [rsp+0x10],rax
  40ec89:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ec8f:	vmovups XMMWORD PTR [r15],xmm0
  40ec94:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40ec9d:	mov    rax,rsi
  40eca0:	add    rsp,0x20
  40eca4:	pop    r15
  40eca6:	pop    r14
  40eca8:	pop    r13
  40ecaa:	pop    r12
  40ecac:	pop    rdi
  40ecad:	pop    rsi
  40ecae:	pop    rbx
  40ecaf:	ret

000000000040ecb0 <__swc_fn_585f006d_000080_c1514492>:
  40ecb0:	sub    rsp,0x8
  40ecb4:	mov    rax,rcx
  40ecb7:	test   rcx,rcx
  40ecba:	jne    40ecc1 <__swc_fn_585f006d_000080_c1514492+0x11>
  40ecbc:	add    rsp,0x8
  40ecc0:	ret
  40ecc1:	lea    rcx,[rax-0x10]
  40ecc5:	mov    rax,QWORD PTR [rax-0x10]
  40ecc9:	mov    rdx,rax
  40eccc:	call   40fd40 <__swc_fn_585f006d_000113_49b378a9>
  40ecd1:	add    rsp,0x8
  40ecd5:	ret
	...

000000000040ece0 <__swc_fn_585f006d_000083_31b501f2>:
  40ece0:	sub    rsp,0x8
  40ece4:	xor    r11d,r11d
  40ece7:	call   408250 <__swc_fn_585f006d_000084_ddf2b8a1>
  40ecec:	add    rsp,0x8
  40ecf0:	ret
	...

000000000040ed00 <__swc_fn_585f006d_000086_c45095aa>:
  40ed00:	push   rsi
  40ed01:	push   rdi
  40ed02:	push   r12
  40ed04:	push   r13
  40ed06:	push   r14
  40ed08:	push   r15
  40ed0a:	sub    rsp,0x68
  40ed0e:	mov    rsi,r9
  40ed11:	mov    rdi,rcx
  40ed14:	mov    r12,rdx
  40ed17:	mov    r13,r8
  40ed1a:	cmp    r8,r9
  40ed1d:	jne    40ed45 <__swc_fn_585f006d_000086_c45095aa+0x45>
  40ed1f:	mov    rcx,rdi
  40ed22:	mov    rdx,r12
  40ed25:	xor    r8d,r8d
  40ed28:	call   4085a0 <__swc_fn_585f006d_000090_a2d50c23>
  40ed2d:	test   al,al
  40ed2f:	je     40ed45 <__swc_fn_585f006d_000086_c45095aa+0x45>
  40ed31:	mov    eax,0x1
  40ed36:	add    rsp,0x68
  40ed3a:	pop    r15
  40ed3c:	pop    r14
  40ed3e:	pop    r13
  40ed40:	pop    r12
  40ed42:	pop    rdi
  40ed43:	pop    rsi
  40ed44:	ret
  40ed45:	cmp    BYTE PTR [r12+0x2c],0xe
  40ed4b:	je     40ed5e <__swc_fn_585f006d_000086_c45095aa+0x5e>
  40ed4d:	xor    eax,eax
  40ed4f:	add    rsp,0x68
  40ed53:	pop    r15
  40ed55:	pop    r14
  40ed57:	pop    r13
  40ed59:	pop    r12
  40ed5b:	pop    rdi
  40ed5c:	pop    rsi
  40ed5d:	ret
  40ed5e:	mov    r14,QWORD PTR [r12+0x98]
  40ed66:	mov    rax,QWORD PTR [r12+0xa0]
  40ed6e:	mov    r12,rax
  40ed71:	xor    r15d,r15d
  40ed74:	test   r12,r12
  40ed77:	je     40eddf <__swc_fn_585f006d_000086_c45095aa+0xdf>
  40ed79:	nop    DWORD PTR [rax+0x0]
  40ed80:	mov    QWORD PTR [rsp+0x58],r12
  40ed85:	lea    r12,[r15*8+0x0]
  40ed8d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40ed92:	mov    rcx,rax
  40ed95:	call   40c040 <__swc_fn_585f006d_000082_754dcd57>
  40ed9a:	cmp    BYTE PTR [rax+0x2c],0xe
  40ed9e:	jne    40edd0 <__swc_fn_585f006d_000086_c45095aa+0xd0>
  40eda0:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40eda5:	lea    r8,[r13+rcx*1+0x0]
  40edaa:	mov    rcx,rdi
  40edad:	mov    rdx,rax
  40edb0:	mov    r9,rsi
  40edb3:	call   40ed00 <__swc_fn_585f006d_000086_c45095aa>
  40edb8:	test   al,al
  40edba:	je     40edd0 <__swc_fn_585f006d_000086_c45095aa+0xd0>
  40edbc:	mov    eax,0x1
  40edc1:	add    rsp,0x68
  40edc5:	pop    r15
  40edc7:	pop    r14
  40edc9:	pop    r13
  40edcb:	pop    r12
  40edcd:	pop    rdi
  40edce:	pop    rsi
  40edcf:	ret
  40edd0:	add    r15,0x1
  40edd4:	mov    r12,QWORD PTR [rsp+0x58]
  40edd9:	sub    r12,0x1
  40eddd:	jne    40ed80 <__swc_fn_585f006d_000086_c45095aa+0x80>
  40eddf:	xor    eax,eax
  40ede1:	add    rsp,0x68
  40ede5:	pop    r15
  40ede7:	pop    r14
  40ede9:	pop    r13
  40edeb:	pop    r12
  40eded:	pop    rdi
  40edee:	pop    rsi
  40edef:	ret

000000000040edf0 <__swc_fn_585f006d_000089_386582f3>:
  40edf0:	push   rbp
  40edf1:	push   rbx
  40edf2:	push   rsi
  40edf3:	push   rdi
  40edf4:	push   r12
  40edf6:	push   r13
  40edf8:	push   r14
  40edfa:	push   r15
  40edfc:	sub    rsp,0x38
  40ee00:	mov    rbp,rsp
  40ee03:	mov    rbx,r11
  40ee06:	mov    rsi,rdx
  40ee09:	mov    rdi,r8
  40ee0c:	mov    r12,r9
  40ee0f:	mov    QWORD PTR [rsp+0x18],r9
  40ee14:	mov    r13,r10
  40ee17:	movzx  r14d,BYTE PTR [rbp+0x80]
  40ee1f:	movzx  r15d,BYTE PTR [rbp+0x88]
  40ee27:	test   r11,r11
  40ee2a:	je     40ee30 <__swc_fn_585f006d_000089_386582f3+0x40>
  40ee2c:	xor    eax,eax
  40ee2e:	mov    BYTE PTR [rbx],al
  40ee30:	test   r12,r12
  40ee33:	je     40ee3e <__swc_fn_585f006d_000089_386582f3+0x4e>
  40ee35:	mov    QWORD PTR [r12+0x8],0x0
  40ee3e:	test   rcx,rcx
  40ee41:	je     40ee48 <__swc_fn_585f006d_000089_386582f3+0x58>
  40ee43:	test   rsi,rsi
  40ee46:	jne    40ee5b <__swc_fn_585f006d_000089_386582f3+0x6b>
  40ee48:	xor    eax,eax
  40ee4a:	add    rsp,0x38
  40ee4e:	pop    r15
  40ee50:	pop    r14
  40ee52:	pop    r13
  40ee54:	pop    r12
  40ee56:	pop    rdi
  40ee57:	pop    rsi
  40ee58:	pop    rbx
  40ee59:	pop    rbp
  40ee5a:	ret
  40ee5b:	call   40c040 <__swc_fn_585f006d_000082_754dcd57>
  40ee60:	mov    r12,rax
  40ee63:	mov    al,r15b
  40ee66:	test   r15b,r15b
  40ee69:	jne    40ee79 <__swc_fn_585f006d_000089_386582f3+0x89>
  40ee6b:	mov    eax,DWORD PTR [r12+0x28]
  40ee70:	and    eax,0x10000
  40ee76:	setne  al
  40ee79:	lea    r15,[rsp+0x8]
  40ee7e:	mov    QWORD PTR [rsp+0x20],r15
  40ee83:	rex mov BYTE PTR [rsp+0x8],al
  40ee88:	test   DWORD PTR [rsi+0x28],0x400000
  40ee8f:	je     40eec7 <__swc_fn_585f006d_000089_386582f3+0xd7>
  40ee91:	test   rsi,rsi
  40ee94:	je     40eeb4 <__swc_fn_585f006d_000089_386582f3+0xc4>
  40ee96:	mov    rax,QWORD PTR [rsi+0x38]
  40ee9a:	cmp    QWORD PTR [rax+0x10],rsi
  40ee9e:	jne    40eeb4 <__swc_fn_585f006d_000089_386582f3+0xc4>
  40eea0:	rex mov al,BYTE PTR [rsp+0x8]
  40eea5:	test   al,al
  40eea7:	sete   al
  40eeaa:	test   r14b,r14b
  40eead:	sete   cl
  40eeb0:	test   al,cl
  40eeb2:	je     40eec7 <__swc_fn_585f006d_000089_386582f3+0xd7>
  40eeb4:	xor    eax,eax
  40eeb6:	add    rsp,0x38
  40eeba:	pop    r15
  40eebc:	pop    r14
  40eebe:	pop    r13
  40eec0:	pop    r12
  40eec2:	pop    rdi
  40eec3:	pop    rsi
  40eec4:	pop    rbx
  40eec5:	pop    rbp
  40eec6:	ret
  40eec7:	mov    r15,r12
  40eeca:	test   r14b,r14b
  40eecd:	jne    40eee4 <__swc_fn_585f006d_000089_386582f3+0xf4>
  40eecf:	cmp    BYTE PTR [r12+0x2c],0x6
  40eed5:	jne    40eee4 <__swc_fn_585f006d_000089_386582f3+0xf4>
  40eed7:	mov    rcx,QWORD PTR [r12+0x40]
  40eedc:	call   40c040 <__swc_fn_585f006d_000082_754dcd57>
  40eee1:	mov    r15,rax
  40eee4:	test   r14b,r14b
  40eee7:	je     40eeed <__swc_fn_585f006d_000089_386582f3+0xfd>
  40eee9:	mov    r15,QWORD PTR [r15+0x30]
  40eeed:	mov    rcx,rsi
  40eef0:	call   40c040 <__swc_fn_585f006d_000082_754dcd57>
  40eef5:	mov    rsi,rax
  40eef8:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40eefd:	je     40ef34 <__swc_fn_585f006d_000089_386582f3+0x144>
  40eeff:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40ef04:	je     40ef34 <__swc_fn_585f006d_000089_386582f3+0x144>
  40ef06:	mov    eax,DWORD PTR [rsi+0x28]
  40ef09:	and    eax,0x10000
  40ef0f:	je     40ef34 <__swc_fn_585f006d_000089_386582f3+0x144>
  40ef11:	rex mov al,BYTE PTR [rsp+0x8]
  40ef16:	test   al,al
  40ef18:	jne    40ef2d <__swc_fn_585f006d_000089_386582f3+0x13d>
  40ef1a:	xor    eax,eax
  40ef1c:	add    rsp,0x38
  40ef20:	pop    r15
  40ef22:	pop    r14
  40ef24:	pop    r13
  40ef26:	pop    r12
  40ef28:	pop    rdi
  40ef29:	pop    rsi
  40ef2a:	pop    rbx
  40ef2b:	pop    rbp
  40ef2c:	ret
  40ef2d:	mov    rax,QWORD PTR [rsi+0x30]
  40ef31:	mov    rsi,rax
  40ef34:	mov    r14b,r13b
  40ef37:	test   rbx,rbx
  40ef3a:	je     40ef70 <__swc_fn_585f006d_000089_386582f3+0x180>
  40ef3c:	cmp    BYTE PTR [r12+0x2c],0x6
  40ef42:	jne    40ef70 <__swc_fn_585f006d_000089_386582f3+0x180>
  40ef44:	lea    rdx,[rip+0x3235]        # 412180 <__swc_rdata_base_585f006d+0x70>
  40ef4b:	mov    rcx,rsi
  40ef4e:	xor    r8d,r8d
  40ef51:	call   4085a0 <__swc_fn_585f006d_000090_a2d50c23>
  40ef56:	test   al,al
  40ef58:	je     40ef70 <__swc_fn_585f006d_000089_386582f3+0x180>
  40ef5a:	mov    BYTE PTR [rbx],0x1
  40ef5d:	xor    eax,eax
  40ef5f:	add    rsp,0x38
  40ef63:	pop    r15
  40ef65:	pop    r14
  40ef67:	pop    r13
  40ef69:	pop    r12
  40ef6b:	pop    rdi
  40ef6c:	pop    rsi
  40ef6d:	pop    rbx
  40ef6e:	pop    rbp
  40ef6f:	ret
  40ef70:	test   rdi,rdi
  40ef73:	jne    40ef8d <__swc_fn_585f006d_000089_386582f3+0x19d>
  40ef75:	test   r13b,r13b
  40ef78:	jne    40ef8d <__swc_fn_585f006d_000089_386582f3+0x19d>
  40ef7a:	xor    eax,eax
  40ef7c:	add    rsp,0x38
  40ef80:	pop    r15
  40ef82:	pop    r14
  40ef84:	pop    r13
  40ef86:	pop    r12
  40ef88:	pop    rdi
  40ef89:	pop    rsi
  40ef8a:	pop    rbx
  40ef8b:	pop    rbp
  40ef8c:	ret
  40ef8d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40ef92:	jne    40f048 <__swc_fn_585f006d_000089_386582f3+0x258>
  40ef98:	mov    rcx,r15
  40ef9b:	mov    rdx,rsi
  40ef9e:	xor    r8d,r8d
  40efa1:	call   4085a0 <__swc_fn_585f006d_000090_a2d50c23>
  40efa6:	test   al,al
  40efa8:	jne    40f048 <__swc_fn_585f006d_000089_386582f3+0x258>
  40efae:	test   DWORD PTR [rsi+0x28],0x10000
  40efb5:	je     40efd3 <__swc_fn_585f006d_000089_386582f3+0x1e3>
  40efb7:	rex mov al,BYTE PTR [rsp+0x8]
  40efbc:	test   al,al
  40efbe:	jne    40efd3 <__swc_fn_585f006d_000089_386582f3+0x1e3>
  40efc0:	xor    eax,eax
  40efc2:	add    rsp,0x38
  40efc6:	pop    r15
  40efc8:	pop    r14
  40efca:	pop    r13
  40efcc:	pop    r12
  40efce:	pop    rdi
  40efcf:	pop    rsi
  40efd0:	pop    rbx
  40efd1:	pop    rbp
  40efd2:	ret
  40efd3:	test   rdi,rdi
  40efd6:	jne    40efeb <__swc_fn_585f006d_000089_386582f3+0x1fb>
  40efd8:	xor    eax,eax
  40efda:	add    rsp,0x38
  40efde:	pop    r15
  40efe0:	pop    r14
  40efe2:	pop    r13
  40efe4:	pop    r12
  40efe6:	pop    rdi
  40efe7:	pop    rsi
  40efe8:	pop    rbx
  40efe9:	pop    rbp
  40efea:	ret
  40efeb:	mov    rcx,QWORD PTR [rsi+0x40]
  40efef:	call   40c040 <__swc_fn_585f006d_000082_754dcd57>
  40eff4:	mov    rsi,rax
  40eff7:	mov    rax,QWORD PTR [rdi]
  40effa:	mov    rdi,rax
  40effd:	test   rax,rax
  40f000:	jne    40f043 <__swc_fn_585f006d_000089_386582f3+0x253>
  40f002:	test   rbx,rbx
  40f005:	je     40f043 <__swc_fn_585f006d_000089_386582f3+0x253>
  40f007:	mov    rcx,r15
  40f00a:	mov    rdx,rsi
  40f00d:	xor    r8d,r8d
  40f010:	call   4085a0 <__swc_fn_585f006d_000090_a2d50c23>
  40f015:	mov    rcx,rax
  40f018:	test   al,al
  40f01a:	jne    40f03c <__swc_fn_585f006d_000089_386582f3+0x24c>
  40f01c:	mov    rcx,r15
  40f01f:	mov    rdx,rsi
  40f022:	call   40c080 <__swc_fn_585f006d_000085_1edf7c76>
  40f027:	mov    rcx,rax
  40f02a:	test   al,al
  40f02c:	jne    40f03c <__swc_fn_585f006d_000089_386582f3+0x24c>
  40f02e:	mov    rcx,rsi
  40f031:	mov    rdx,r15
  40f034:	call   40c080 <__swc_fn_585f006d_000085_1edf7c76>
  40f039:	mov    rcx,rax
  40f03c:	test   cl,cl
  40f03e:	setne  al
  40f041:	mov    BYTE PTR [rbx],al
  40f043:	xor    eax,eax
  40f045:	mov    r14b,al
  40f048:	test   rdi,rdi
  40f04b:	jne    40f065 <__swc_fn_585f006d_000089_386582f3+0x275>
  40f04d:	test   r14b,r14b
  40f050:	jne    40f065 <__swc_fn_585f006d_000089_386582f3+0x275>
  40f052:	xor    eax,eax
  40f054:	add    rsp,0x38
  40f058:	pop    r15
  40f05a:	pop    r14
  40f05c:	pop    r13
  40f05e:	pop    r12
  40f060:	pop    rdi
  40f061:	pop    rsi
  40f062:	pop    rbx
  40f063:	pop    rbp
  40f064:	ret
  40f065:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f06a:	je     40f076 <__swc_fn_585f006d_000089_386582f3+0x286>
  40f06c:	mov    r12,QWORD PTR [rsp+0x18]
  40f071:	jmp    40f0fe <__swc_fn_585f006d_000089_386582f3+0x30e>
  40f076:	mov    r12,QWORD PTR [rsp+0x18]
  40f07b:	test   r12,r12
  40f07e:	jne    40f092 <__swc_fn_585f006d_000089_386582f3+0x2a2>
  40f080:	mov    rcx,r15
  40f083:	mov    rdx,rsi
  40f086:	xor    r8d,r8d
  40f089:	call   4085a0 <__swc_fn_585f006d_000090_a2d50c23>
  40f08e:	test   al,al
  40f090:	jne    40f0fe <__swc_fn_585f006d_000089_386582f3+0x30e>
  40f092:	test   DWORD PTR [rsi+0x28],0x10000
  40f099:	je     40f0b7 <__swc_fn_585f006d_000089_386582f3+0x2c7>
  40f09b:	rex mov al,BYTE PTR [rsp+0x8]
  40f0a0:	test   al,al
  40f0a2:	jne    40f0b7 <__swc_fn_585f006d_000089_386582f3+0x2c7>
  40f0a4:	xor    eax,eax
  40f0a6:	add    rsp,0x38
  40f0aa:	pop    r15
  40f0ac:	pop    r14
  40f0ae:	pop    r13
  40f0b0:	pop    r12
  40f0b2:	pop    rdi
  40f0b3:	pop    rsi
  40f0b4:	pop    rbx
  40f0b5:	pop    rbp
  40f0b6:	ret
  40f0b7:	test   rdi,rdi
  40f0ba:	jne    40f0cf <__swc_fn_585f006d_000089_386582f3+0x2df>
  40f0bc:	xor    eax,eax
  40f0be:	add    rsp,0x38
  40f0c2:	pop    r15
  40f0c4:	pop    r14
  40f0c6:	pop    r13
  40f0c8:	pop    r12
  40f0ca:	pop    rdi
  40f0cb:	pop    rsi
  40f0cc:	pop    rbx
  40f0cd:	pop    rbp
  40f0ce:	ret
  40f0cf:	cmp    QWORD PTR [rdi+0x8],0x0
  40f0d4:	jne    40f0e9 <__swc_fn_585f006d_000089_386582f3+0x2f9>
  40f0d6:	xor    eax,eax
  40f0d8:	add    rsp,0x38
  40f0dc:	pop    r15
  40f0de:	pop    r14
  40f0e0:	pop    r13
  40f0e2:	pop    r12
  40f0e4:	pop    rdi
  40f0e5:	pop    rsi
  40f0e6:	pop    rbx
  40f0e7:	pop    rbp
  40f0e8:	ret
  40f0e9:	mov    rax,QWORD PTR [rdi+0x8]
  40f0ed:	mov    rax,QWORD PTR [rax]
  40f0f0:	mov    rsi,rax
  40f0f3:	mov    rdi,QWORD PTR [rdi]
  40f0f6:	mov    eax,0x1
  40f0fb:	mov    r14b,al
  40f0fe:	test   rdi,rdi
  40f101:	mov    rbx,QWORD PTR [rsp+0x20]
  40f106:	jne    40f150 <__swc_fn_585f006d_000089_386582f3+0x360>
  40f108:	test   r14b,r14b
  40f10b:	je     40f13d <__swc_fn_585f006d_000089_386582f3+0x34d>
  40f10d:	test   r12,r12
  40f110:	je     40f13d <__swc_fn_585f006d_000089_386582f3+0x34d>
  40f112:	mov    rcx,r15
  40f115:	mov    rdx,rsi
  40f118:	xor    r8d,r8d
  40f11b:	mov    r9,r12
  40f11e:	mov    rbx,QWORD PTR [rsp+0x20]
  40f123:	movzx  r10d,BYTE PTR [rbx]
  40f127:	call   40ece0 <__swc_fn_585f006d_000083_31b501f2>
  40f12c:	add    rsp,0x38
  40f130:	pop    r15
  40f132:	pop    r14
  40f134:	pop    r13
  40f136:	pop    r12
  40f138:	pop    rdi
  40f139:	pop    rsi
  40f13a:	pop    rbx
  40f13b:	pop    rbp
  40f13c:	ret
  40f13d:	xor    eax,eax
  40f13f:	add    rsp,0x38
  40f143:	pop    r15
  40f145:	pop    r14
  40f147:	pop    r13
  40f149:	pop    r12
  40f14b:	pop    rdi
  40f14c:	pop    rsi
  40f14d:	pop    rbx
  40f14e:	pop    rbp
  40f14f:	ret
  40f150:	mov    r13,rsi
  40f153:	mov    QWORD PTR [rsp+0x28],rdi
  40f158:	cmp    BYTE PTR [r15+0x2c],0xe
  40f15d:	sete   al
  40f160:	mov    r14b,al
  40f163:	jne    40f177 <__swc_fn_585f006d_000089_386582f3+0x387>
  40f165:	mov    rcx,rsi
  40f168:	mov    rdx,r15
  40f16b:	call   40c080 <__swc_fn_585f006d_000085_1edf7c76>
  40f170:	mov    r14b,al
  40f173:	test   al,al
  40f175:	jne    40f1ac <__swc_fn_585f006d_000089_386582f3+0x3bc>
  40f177:	cmp    BYTE PTR [r15+0x2c],0x12
  40f17c:	je     40f1ac <__swc_fn_585f006d_000089_386582f3+0x3bc>
  40f17e:	mov    rcx,r15
  40f181:	mov    rdx,rsi
  40f184:	mov    r8,rdi
  40f187:	mov    r9,r12
  40f18a:	mov    rax,rbx
  40f18d:	movzx  r10d,BYTE PTR [rax]
  40f191:	call   40ece0 <__swc_fn_585f006d_000083_31b501f2>
  40f196:	test   rax,rax
  40f199:	je     40f1ac <__swc_fn_585f006d_000089_386582f3+0x3bc>
  40f19b:	add    rsp,0x38
  40f19f:	pop    r15
  40f1a1:	pop    r14
  40f1a3:	pop    r13
  40f1a5:	pop    r12
  40f1a7:	pop    rdi
  40f1a8:	pop    rsi
  40f1a9:	pop    rbx
  40f1aa:	pop    rbp
  40f1ab:	ret
  40f1ac:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40f1b1:	jne    40f1d0 <__swc_fn_585f006d_000089_386582f3+0x3e0>
  40f1b3:	mov    rax,QWORD PTR [rsi+0xd8]
  40f1ba:	test   rax,rax
  40f1bd:	je     40f1d0 <__swc_fn_585f006d_000089_386582f3+0x3e0>
  40f1bf:	add    rdi,QWORD PTR [rax+0x8]
  40f1c3:	mov    rax,QWORD PTR [rdi]
  40f1c6:	sub    rdi,QWORD PTR [rax+0x8]
  40f1ca:	mov    rax,QWORD PTR [rax]
  40f1cd:	mov    rsi,rax
  40f1d0:	test   r14b,r14b
  40f1d3:	je     40f1ff <__swc_fn_585f006d_000089_386582f3+0x40f>
  40f1d5:	mov    rcx,r15
  40f1d8:	mov    rdx,rsi
  40f1db:	mov    r8,rdi
  40f1de:	mov    r9,r13
  40f1e1:	mov    r14,QWORD PTR [rsp+0x28]
  40f1e6:	mov    r10,r14
  40f1e9:	call   408480 <__swc_fn_585f006d_000087_ea575bb3>
  40f1ee:	add    rsp,0x38
  40f1f2:	pop    r15
  40f1f4:	pop    r14
  40f1f6:	pop    r13
  40f1f8:	pop    r12
  40f1fa:	pop    rdi
  40f1fb:	pop    rsi
  40f1fc:	pop    rbx
  40f1fd:	pop    rbp
  40f1fe:	ret
  40f1ff:	mov    rcx,r15
  40f202:	mov    rdx,rsi
  40f205:	mov    r8,rdi
  40f208:	mov    r9,r12
  40f20b:	movzx  r10d,BYTE PTR [rbx]
  40f20f:	call   40ece0 <__swc_fn_585f006d_000083_31b501f2>
  40f214:	add    rsp,0x38
  40f218:	pop    r15
  40f21a:	pop    r14
  40f21c:	pop    r13
  40f21e:	pop    r12
  40f220:	pop    rdi
  40f221:	pop    rsi
  40f222:	pop    rbx
  40f223:	pop    rbp
  40f224:	ret
	...

000000000040f230 <__swc_fn_585f006d_000092_8252f8c0>:
  40f230:	push   rbx
  40f231:	push   rsi
  40f232:	sub    rsp,0x18
  40f236:	mov    rbx,rcx
  40f239:	mov    rcx,QWORD PTR [rip+0x16b00]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40f240:	test   rcx,rcx
  40f243:	jne    40f255 <__swc_fn_585f006d_000092_8252f8c0+0x25>
  40f245:	call   40a1d0 <__swc_fn_585f006d_000165_cf398896>
  40f24a:	lea    rcx,[rax+0x1]
  40f24e:	mov    QWORD PTR [rip+0x16aeb],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40f255:	dec    rcx
  40f258:	call   411b60 <__swc_fn_585f006d_000167_fce60b2b>
  40f25d:	mov    rsi,rax
  40f260:	mov    rax,QWORD PTR [rsi+0x8]
  40f264:	test   rax,rax
  40f267:	jne    40f2b7 <__swc_fn_585f006d_000092_8252f8c0+0x87>
  40f269:	call   40c170 <__swc_fn_585f006d_000091_3d2f5a0d>
  40f26e:	test   al,al
  40f270:	jne    40f2b7 <__swc_fn_585f006d_000092_8252f8c0+0x87>
  40f272:	lea    rdx,[rip+0x13fc7]        # 423240 <__swc_bss_base_585f006d+0x200>
  40f279:	mov    rcx,rdx
  40f27c:	call   407740 <__swc_fn_585f006d_000036_8d895ba1>
  40f281:	test   al,al
  40f283:	jne    40f294 <__swc_fn_585f006d_000092_8252f8c0+0x64>
  40f285:	mov    rcx,rdx
  40f288:	call   40aa60 <__swc_fn_585f006d_000034_25f19556>
  40f28d:	lea    rdx,[rip+0x13fac]        # 423240 <__swc_bss_base_585f006d+0x200>
  40f294:	mov    QWORD PTR [rsp+0x8],rdx
  40f299:	lea    rax,[rip+0x2eb0]        # 412150 <__swc_rdata_base_585f006d+0x40>
  40f2a0:	mov    QWORD PTR [rsp+0x10],rax
  40f2a5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f2ab:	vmovups XMMWORD PTR [rsi],xmm0
  40f2af:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f2b7:	vmovups xmm0,XMMWORD PTR [rsi]
  40f2bb:	vmovups XMMWORD PTR [rbx],xmm0
  40f2bf:	mov    rax,rbx
  40f2c2:	add    rsp,0x18
  40f2c6:	pop    rsi
  40f2c7:	pop    rbx
  40f2c8:	ret
  40f2c9:	add    BYTE PTR [rax],al
  40f2cb:	add    BYTE PTR [rax],al
  40f2cd:	add    BYTE PTR [rax],al
	...

000000000040f2d0 <__swc_fn_585f006d_000095_337e587a>:
  40f2d0:	sub    rsp,0x8
  40f2d4:	call   409360 <__swc_fn_585f006d_000117_86a7fb9e>
  40f2d9:	add    rsp,0x8
  40f2dd:	ret
	...

000000000040f2e0 <__swc_fn_585f006d_000098_00f01091>:
  40f2e0:	push   rbx
  40f2e1:	push   rsi
  40f2e2:	sub    rsp,0x28
  40f2e6:	mov    rbx,rcx
  40f2e9:	xor    esi,esi
  40f2eb:	jmp    40f300 <__swc_fn_585f006d_000098_00f01091+0x20>
  40f2ed:	nop    DWORD PTR [rax]
  40f2f0:	mov    QWORD PTR [rbx+0x28],rsi
  40f2f4:	mov    rsi,rbx
  40f2f7:	mov    rbx,rax
  40f2fa:	nop    WORD PTR [rax+rax*1+0x0]
  40f300:	test   rbx,rbx
  40f303:	je     40f363 <__swc_fn_585f006d_000098_00f01091+0x83>
  40f305:	mov    rcx,rbx
  40f308:	mov    edx,0x1
  40f30d:	call   408200 <__swc_fn_585f006d_000078_a120bd2b>
  40f312:	cmp    rax,0x1
  40f316:	jne    40f363 <__swc_fn_585f006d_000098_00f01091+0x83>
  40f318:	mov    r10,QWORD PTR [rbx+0x18]
  40f31c:	mov    rcx,r10
  40f31f:	mov    edx,0x1
  40f324:	call   408200 <__swc_fn_585f006d_000078_a120bd2b>
  40f329:	cmp    rax,0x1
  40f32d:	jne    40f33c <__swc_fn_585f006d_000098_00f01091+0x5c>
  40f32f:	mov    rcx,r10
  40f332:	call   40c310 <__swc_fn_585f006d_000097_4c97e0db>
  40f337:	test   rax,rax
  40f33a:	jne    40f2f0 <__swc_fn_585f006d_000098_00f01091+0x10>
  40f33c:	mov    rax,QWORD PTR [rbx+0x20]
  40f340:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f345:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f34b:	lea    rcx,[rsp+0x8]
  40f350:	mov    rdx,rbx
  40f353:	mov    r8d,0x30
  40f359:	mov    rbx,rax
  40f35c:	call   408960 <__swc_fn_585f006d_000096_ad982b35>
  40f361:	jmp    40f300 <__swc_fn_585f006d_000098_00f01091+0x20>
  40f363:	test   rsi,rsi
  40f366:	jne    40f36f <__swc_fn_585f006d_000098_00f01091+0x8f>
  40f368:	add    rsp,0x28
  40f36c:	pop    rsi
  40f36d:	pop    rbx
  40f36e:	ret
  40f36f:	mov    rax,rsi
  40f372:	mov    rsi,QWORD PTR [rsi+0x28]
  40f376:	mov    rbx,QWORD PTR [rax+0x20]
  40f37a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f37f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f385:	lea    rcx,[rsp+0x18]
  40f38a:	mov    rdx,rax
  40f38d:	mov    r8d,0x30
  40f393:	call   408960 <__swc_fn_585f006d_000096_ad982b35>
  40f398:	jmp    40f300 <__swc_fn_585f006d_000098_00f01091+0x20>
  40f39d:	add    BYTE PTR [rax],al
	...

000000000040f3a0 <__swc_fn_585f006d_000101_eab3874f>:
  40f3a0:	push   rbx
  40f3a1:	push   rsi
  40f3a2:	push   rdi
  40f3a3:	push   r12
  40f3a5:	push   r13
  40f3a7:	sub    rsp,0x20
  40f3ab:	mov    rbx,rcx
  40f3ae:	lea    rsi,[rcx+0x6f8]
  40f3b5:	mov    edi,0x4
  40f3ba:	mov    r12,rsi
  40f3bd:	test   rdi,rdi
  40f3c0:	je     40f40a <__swc_fn_585f006d_000101_eab3874f+0x6a>
  40f3c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f3cc:	nop    DWORD PTR [rax+0x0]
  40f3d0:	mov    rcx,QWORD PTR [r12+0x10]
  40f3d5:	mov    QWORD PTR [r12+0x10],0x0
  40f3de:	vxorps xmm0,xmm0,xmm0
  40f3e2:	vmovups XMMWORD PTR [r12],xmm0
  40f3e8:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f3ef:	mov    DWORD PTR [r12+0x20],0x0
  40f3f8:	call   4089c0 <__swc_fn_585f006d_000099_b4c6da83>
  40f3fd:	add    r12,0x90
  40f404:	sub    rdi,0x1
  40f408:	jne    40f3d0 <__swc_fn_585f006d_000101_eab3874f+0x30>
  40f40a:	mov    rax,QWORD PTR [rbx+0x938]
  40f411:	mov    rdi,rax
  40f414:	test   rdi,rdi
  40f417:	je     40f471 <__swc_fn_585f006d_000101_eab3874f+0xd1>
  40f419:	nop    DWORD PTR [rax+0x0]
  40f420:	mov    r12d,0x10
  40f426:	lea    r13,[rdi+0x18]
  40f42a:	test   r12,r12
  40f42d:	je     40f466 <__swc_fn_585f006d_000101_eab3874f+0xc6>
  40f42f:	nop
  40f430:	mov    rcx,QWORD PTR [r13+0x10]
  40f434:	mov    QWORD PTR [r13+0x10],0x0
  40f43c:	vxorps xmm0,xmm0,xmm0
  40f440:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f446:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f44c:	mov    DWORD PTR [r13+0x20],0x0
  40f454:	call   4089c0 <__swc_fn_585f006d_000099_b4c6da83>
  40f459:	add    r13,0x90
  40f460:	sub    r12,0x1
  40f464:	jne    40f430 <__swc_fn_585f006d_000101_eab3874f+0x90>
  40f466:	mov    rax,QWORD PTR [rdi]
  40f469:	mov    rdi,rax
  40f46c:	test   rax,rax
  40f46f:	jne    40f420 <__swc_fn_585f006d_000101_eab3874f+0x80>
  40f471:	vxorps xmm0,xmm0,xmm0
  40f475:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f47d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f487:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f491:	mov    edi,0x4
  40f496:	mov    r12,rsi
  40f499:	lea    rsi,[rsi+0x38]
  40f49d:	test   rdi,rdi
  40f4a0:	je     40f4cc <__swc_fn_585f006d_000101_eab3874f+0x12c>
  40f4a2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f4ac:	nop    DWORD PTR [rax+0x0]
  40f4b0:	mov    rcx,rsi
  40f4b3:	call   40d1a0 <__swc_fn_585f006d_000157_232ffa22>
  40f4b8:	add    rsi,0x90
  40f4bf:	add    r12,0x90
  40f4c6:	sub    rdi,0x1
  40f4ca:	jne    40f4b0 <__swc_fn_585f006d_000101_eab3874f+0x110>
  40f4cc:	mov    rax,QWORD PTR [rbx+0x938]
  40f4d3:	mov    rdi,rax
  40f4d6:	mov    QWORD PTR [rbx+0x938],0x0
  40f4e1:	test   rdi,rdi
  40f4e4:	je     40f555 <__swc_fn_585f006d_000101_eab3874f+0x1b5>
  40f4ea:	nop    WORD PTR [rax+rax*1+0x0]
  40f4f0:	mov    esi,0x10
  40f4f5:	lea    r12,[rdi+0x18]
  40f4f9:	lea    r13,[rdi+0x50]
  40f4fd:	test   rsi,rsi
  40f500:	je     40f52c <__swc_fn_585f006d_000101_eab3874f+0x18c>
  40f502:	cs nop WORD PTR [rax+rax*1+0x0]
  40f50c:	nop    DWORD PTR [rax+0x0]
  40f510:	mov    rcx,r13
  40f513:	call   40d1a0 <__swc_fn_585f006d_000157_232ffa22>
  40f518:	add    r13,0x90
  40f51f:	add    r12,0x90
  40f526:	sub    rsi,0x1
  40f52a:	jne    40f510 <__swc_fn_585f006d_000101_eab3874f+0x170>
  40f52c:	mov    rax,QWORD PTR [rdi]
  40f52f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f534:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f53a:	lea    rcx,[rsp+0x8]
  40f53f:	mov    rdx,rdi
  40f542:	mov    r8d,0x918
  40f548:	mov    rdi,rax
  40f54b:	call   408960 <__swc_fn_585f006d_000096_ad982b35>
  40f550:	test   rdi,rdi
  40f553:	jne    40f4f0 <__swc_fn_585f006d_000101_eab3874f+0x150>
  40f555:	lea    rcx,[rbx+0x68]
  40f559:	call   40d1a0 <__swc_fn_585f006d_000157_232ffa22>
  40f55e:	add    rsp,0x20
  40f562:	pop    r13
  40f564:	pop    r12
  40f566:	pop    rdi
  40f567:	pop    rsi
  40f568:	pop    rbx
  40f569:	ret
  40f56a:	add    BYTE PTR [rax],al
  40f56c:	add    BYTE PTR [rax],al
	...

000000000040f570 <__swc_fn_585f006d_000104_5589fdbd>:
  40f570:	xor    eax,eax
  40f572:	cs nop WORD PTR [rax+rax*1+0x0]
  40f57c:	nop    DWORD PTR [rax+0x0]
  40f580:	mov    r9,r8
  40f583:	sub    r9,rax
  40f586:	cmp    r9,0x40
  40f58a:	jb     40f5c8 <__swc_fn_585f006d_000104_5589fdbd+0x58>
  40f58c:	lea    r9,[rcx+rax*1]
  40f590:	lea    r10,[rdx+rax*1]
  40f594:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f59a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40f5a0:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40f5a6:	vmovups xmm3,XMMWORD PTR [r10]
  40f5ab:	vmovups XMMWORD PTR [r9],xmm3
  40f5b0:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40f5b6:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40f5bc:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40f5c2:	lea    rax,[rax+0x40]
  40f5c6:	jmp    40f580 <__swc_fn_585f006d_000104_5589fdbd+0x10>
  40f5c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40f5d0:	mov    r9,r8
  40f5d3:	sub    r9,rax
  40f5d6:	cmp    r9,0x10
  40f5da:	jb     40f5f4 <__swc_fn_585f006d_000104_5589fdbd+0x84>
  40f5dc:	lea    r9,[rdx+rax*1]
  40f5e0:	lea    r10,[rcx+rax*1]
  40f5e4:	vmovups xmm0,XMMWORD PTR [r9]
  40f5e9:	vmovups XMMWORD PTR [r10],xmm0
  40f5ee:	lea    rax,[rax+0x10]
  40f5f2:	jmp    40f5d0 <__swc_fn_585f006d_000104_5589fdbd+0x60>
  40f5f4:	cs nop WORD PTR [rax+rax*1+0x0]
  40f5fe:	xchg   ax,ax
  40f600:	mov    r9,r8
  40f603:	sub    r9,rax
  40f606:	cmp    r9,0x8
  40f60a:	jb     40f61d <__swc_fn_585f006d_000104_5589fdbd+0xad>
  40f60c:	lea    r9,[rcx+rax*1]
  40f610:	mov    r10,QWORD PTR [rdx+rax*1]
  40f614:	mov    QWORD PTR [r9],r10
  40f617:	lea    rax,[rax+0x8]
  40f61b:	jmp    40f600 <__swc_fn_585f006d_000104_5589fdbd+0x90>
  40f61d:	cmp    rax,r8
  40f620:	jae    40f640 <__swc_fn_585f006d_000104_5589fdbd+0xd0>
  40f622:	cs nop WORD PTR [rax+rax*1+0x0]
  40f62c:	nop    DWORD PTR [rax+0x0]
  40f630:	mov    r9b,BYTE PTR [rdx+rax*1]
  40f634:	mov    BYTE PTR [rcx+rax*1],r9b
  40f638:	inc    rax
  40f63b:	cmp    rax,r8
  40f63e:	jb     40f630 <__swc_fn_585f006d_000104_5589fdbd+0xc0>
  40f640:	ret
	...

000000000040f660 <__swc_fn_585f006d_000107_4796e893>:
  40f660:	push   rbx
  40f661:	push   r12
  40f663:	push   rdi
  40f664:	push   rsi
  40f665:	push   r13
  40f667:	push   r14
  40f669:	push   r15
  40f66b:	sub    rsp,0x170
  40f672:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40f67b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40f684:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40f68d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40f696:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40f69f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40f6a8:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40f6b1:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40f6ba:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40f6c3:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40f6cc:	mov    ebx,edx
  40f6ce:	mov    QWORD PTR [rsp+0xa8],rbx
  40f6d6:	mov    r12d,ecx
  40f6d9:	test   edx,edx
  40f6db:	jne    40f6f2 <__swc_fn_585f006d_000107_4796e893+0x92>
  40f6dd:	xor    eax,eax
  40f6df:	add    rsp,0x170
  40f6e6:	pop    r15
  40f6e8:	pop    r14
  40f6ea:	pop    r13
  40f6ec:	pop    rsi
  40f6ed:	pop    rdi
  40f6ee:	pop    r12
  40f6f0:	pop    rbx
  40f6f1:	ret
  40f6f2:	lea    rdi,[rip+0x2db7]        # 4124b0 <__swc_rdata_base_585f006d+0x3a0>
  40f6f9:	mov    esi,0x90000
  40f6fe:	xor    eax,eax
  40f700:	call   407090 <open@plt>
  40f705:	mov    r13,rax
  40f708:	mov    QWORD PTR [rsp+0xb0],rax
  40f710:	test   eax,eax
  40f712:	jge    40f71b <__swc_fn_585f006d_000107_4796e893+0xbb>
  40f714:	xor    eax,eax
  40f716:	jmp    40fc36 <__swc_fn_585f006d_000107_4796e893+0x5d6>
  40f71b:	nop    DWORD PTR [rax+rax*1+0x0]
  40f720:	movsxd rdi,r13d
  40f723:	mov    esi,0x2
  40f728:	xor    eax,eax
  40f72a:	call   407120 <flock@plt>
  40f72f:	test   eax,eax
  40f731:	je     40f750 <__swc_fn_585f006d_000107_4796e893+0xf0>
  40f733:	xor    eax,eax
  40f735:	call   407130 <__errno_location@plt>
  40f73a:	cmp    DWORD PTR [rax],0x4
  40f73d:	je     40f720 <__swc_fn_585f006d_000107_4796e893+0xc0>
  40f73f:	movsxd rdi,r13d
  40f742:	xor    eax,eax
  40f744:	call   4070b0 <close@plt>
  40f749:	xor    eax,eax
  40f74b:	jmp    40fc36 <__swc_fn_585f006d_000107_4796e893+0x5d6>
  40f750:	lea    r14,[rsp+0x8]
  40f755:	mov    QWORD PTR [rsp+0xb8],r14
  40f75d:	vxorps xmm0,xmm0,xmm0
  40f761:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f767:	mov    QWORD PTR [rsp+0x18],0x0
  40f770:	mov    WORD PTR [rsp+0x20],0x0
  40f777:	mov    DWORD PTR [r14],0x67617753
  40f77e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40f786:	xor    eax,eax
  40f788:	call   407010 <getpid@plt>
  40f78d:	mov    ecx,eax
  40f78f:	mov    eax,0x1c
  40f794:	shrx   eax,ecx,eax
  40f799:	and    eax,0xf
  40f79c:	mov    rdx,QWORD PTR [rip+0x2d2d]        # 4124d0 <__swc_rdata_base_585f006d+0x3c0>
  40f7a3:	mov    al,BYTE PTR [rdx+rax*1]
  40f7a6:	rex mov BYTE PTR [rsp+0x10],al
  40f7ab:	mov    eax,0x1c
  40f7b0:	shrx   eax,r12d,eax
  40f7b5:	and    eax,0xf
  40f7b8:	mov    al,BYTE PTR [rdx+rax*1]
  40f7bb:	rex mov BYTE PTR [rsp+0x19],al
  40f7c0:	mov    eax,0x18
  40f7c5:	shrx   eax,ecx,eax
  40f7ca:	and    eax,0xf
  40f7cd:	mov    al,BYTE PTR [rdx+rax*1]
  40f7d0:	rex mov BYTE PTR [rsp+0x11],al
  40f7d5:	mov    eax,0x18
  40f7da:	shrx   eax,r12d,eax
  40f7df:	and    eax,0xf
  40f7e2:	mov    al,BYTE PTR [rdx+rax*1]
  40f7e5:	rex mov BYTE PTR [rsp+0x1a],al
  40f7ea:	mov    eax,0x14
  40f7ef:	shrx   eax,ecx,eax
  40f7f4:	and    eax,0xf
  40f7f7:	mov    al,BYTE PTR [rdx+rax*1]
  40f7fa:	rex mov BYTE PTR [rsp+0x12],al
  40f7ff:	mov    eax,0x14
  40f804:	shrx   eax,r12d,eax
  40f809:	and    eax,0xf
  40f80c:	mov    al,BYTE PTR [rdx+rax*1]
  40f80f:	rex mov BYTE PTR [rsp+0x1b],al
  40f814:	mov    eax,0x10
  40f819:	shrx   eax,ecx,eax
  40f81e:	and    eax,0xf
  40f821:	mov    al,BYTE PTR [rdx+rax*1]
  40f824:	rex mov BYTE PTR [rsp+0x13],al
  40f829:	mov    eax,0x10
  40f82e:	shrx   eax,r12d,eax
  40f833:	and    eax,0xf
  40f836:	mov    al,BYTE PTR [rdx+rax*1]
  40f839:	rex mov BYTE PTR [rsp+0x1c],al
  40f83e:	mov    eax,0xc
  40f843:	shrx   eax,ecx,eax
  40f848:	and    eax,0xf
  40f84b:	mov    al,BYTE PTR [rdx+rax*1]
  40f84e:	rex mov BYTE PTR [rsp+0x14],al
  40f853:	mov    eax,0xc
  40f858:	shrx   eax,r12d,eax
  40f85d:	and    eax,0xf
  40f860:	mov    al,BYTE PTR [rdx+rax*1]
  40f863:	rex mov BYTE PTR [rsp+0x1d],al
  40f868:	mov    eax,0x8
  40f86d:	shrx   eax,ecx,eax
  40f872:	and    eax,0xf
  40f875:	mov    al,BYTE PTR [rdx+rax*1]
  40f878:	rex mov BYTE PTR [rsp+0x15],al
  40f87d:	mov    eax,0x8
  40f882:	shrx   eax,r12d,eax
  40f887:	and    eax,0xf
  40f88a:	mov    al,BYTE PTR [rdx+rax*1]
  40f88d:	rex mov BYTE PTR [rsp+0x1e],al
  40f892:	mov    eax,0x4
  40f897:	shrx   eax,ecx,eax
  40f89c:	and    eax,0xf
  40f89f:	mov    al,BYTE PTR [rdx+rax*1]
  40f8a2:	rex mov BYTE PTR [rsp+0x16],al
  40f8a7:	mov    eax,0x4
  40f8ac:	shrx   eax,r12d,eax
  40f8b1:	and    eax,0xf
  40f8b4:	mov    al,BYTE PTR [rdx+rax*1]
  40f8b7:	rex mov BYTE PTR [rsp+0x1f],al
  40f8bc:	xor    eax,eax
  40f8be:	shrx   eax,ecx,eax
  40f8c3:	and    eax,0xf
  40f8c6:	mov    al,BYTE PTR [rdx+rax*1]
  40f8c9:	rex mov BYTE PTR [rsp+0x17],al
  40f8ce:	xor    eax,eax
  40f8d0:	shrx   eax,r12d,eax
  40f8d5:	and    eax,0xf
  40f8d8:	mov    al,BYTE PTR [rdx+rax*1]
  40f8db:	rex mov BYTE PTR [rsp+0x20],al
  40f8e0:	mov    BYTE PTR [r14+0x10],0x2e
  40f8e5:	lea    r12,[rsp+0x22]
  40f8ea:	vxorps xmm0,xmm0,xmm0
  40f8ee:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40f8f4:	mov    DWORD PTR [r12],0x6d656d2f
  40f8fc:	mov    WORD PTR [r12+0x4],0x6466
  40f904:	mov    BYTE PTR [r12+0x6],0x3a
  40f90a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f910:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40f916:	mov    rax,QWORD PTR [rsp+0x18]
  40f91b:	mov    QWORD PTR [rsp+0x39],rax
  40f920:	rex mov al,BYTE PTR [rsp+0x20]
  40f925:	rex mov BYTE PTR [rsp+0x41],al
  40f92a:	mov    DWORD PTR [r12+0x20],0x65642820
  40f933:	mov    DWORD PTR [r12+0x24],0x6574656c
  40f93c:	mov    WORD PTR [r12+0x28],0x2964
  40f944:	lea    rdi,[rip+0x2b70]        # 4124bb <__swc_rdata_base_585f006d+0x3ab>
  40f94b:	xor    eax,eax
  40f94d:	call   407140 <opendir@plt>
  40f952:	mov    r15,rax
  40f955:	test   rax,rax
  40f958:	jne    40f96b <__swc_fn_585f006d_000107_4796e893+0x30b>
  40f95a:	movsxd rdi,r13d
  40f95d:	xor    eax,eax
  40f95f:	call   4070b0 <close@plt>
  40f964:	xor    eax,eax
  40f966:	jmp    40fc36 <__swc_fn_585f006d_000107_4796e893+0x5d6>
  40f96b:	mov    rdi,r15
  40f96e:	xor    eax,eax
  40f970:	call   407150 <dirfd@plt>
  40f975:	lea    r14,[rsp+0x54]
  40f97a:	mov    DWORD PTR [rsp+0x54],eax
  40f97e:	lea    rbx,[rsp+0x58]
  40f983:	cs nop WORD PTR [rax+rax*1+0x0]
  40f98d:	cs nop WORD PTR [rax+rax*1+0x0]
  40f997:	nop    WORD PTR [rax+rax*1+0x0]
  40f9a0:	mov    rdi,r15
  40f9a3:	xor    eax,eax
  40f9a5:	call   407160 <readdir@plt>
  40f9aa:	test   rax,rax
  40f9ad:	jne    40f9c4 <__swc_fn_585f006d_000107_4796e893+0x364>
  40f9af:	mov    r12,QWORD PTR [rsp+0xa8]
  40f9b7:	mov    r13,QWORD PTR [rsp+0xb0]
  40f9bf:	jmp    40fb5a <__swc_fn_585f006d_000107_4796e893+0x4fa>
  40f9c4:	vxorps xmm0,xmm0,xmm0
  40f9c8:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40f9ce:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40f9d4:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40f9da:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40f9e3:	lea    r13,[rax+0x13]
  40f9e7:	mov    rax,r14
  40f9ea:	movsxd rdi,DWORD PTR [rax]
  40f9ed:	mov    rsi,r13
  40f9f0:	mov    rdx,rbx
  40f9f3:	mov    ecx,0x40
  40f9f8:	xor    eax,eax
  40f9fa:	call   407170 <readlinkat@plt>
  40f9ff:	cmp    rax,0x2a
  40fa03:	jne    40f9a0 <__swc_fn_585f006d_000107_4796e893+0x340>
  40fa05:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40fa0b:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40fa11:	vptest xmm0,xmm0
  40fa16:	jne    40fa46 <__swc_fn_585f006d_000107_4796e893+0x3e6>
  40fa18:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40fa1e:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40fa24:	vptest xmm0,xmm0
  40fa29:	jne    40fa46 <__swc_fn_585f006d_000107_4796e893+0x3e6>
  40fa2b:	mov    rcx,QWORD PTR [rsp+0x42]
  40fa30:	cmp    QWORD PTR [rsp+0x78],rcx
  40fa35:	jne    40fa46 <__swc_fn_585f006d_000107_4796e893+0x3e6>
  40fa37:	mov    cx,WORD PTR [rsp+0x4a]
  40fa3c:	cmp    WORD PTR [rsp+0x80],cx
  40fa44:	je     40fa74 <__swc_fn_585f006d_000107_4796e893+0x414>
  40fa46:	mov    rax,rbx
  40fa49:	mov    rcx,r12
  40fa4c:	nop    DWORD PTR [rax+0x0]
  40fa50:	movzx  edx,BYTE PTR [rax]
  40fa53:	movzx  r8d,BYTE PTR [rcx]
  40fa57:	cmp    rdx,r8
  40fa5a:	jne    40fa66 <__swc_fn_585f006d_000107_4796e893+0x406>
  40fa5c:	add    rax,0x1
  40fa60:	add    rcx,0x1
  40fa64:	jmp    40fa50 <__swc_fn_585f006d_000107_4796e893+0x3f0>
  40fa66:	mov    rax,rdx
  40fa69:	sub    rax,r8
  40fa6c:	test   eax,eax
  40fa6e:	jne    40f9a0 <__swc_fn_585f006d_000107_4796e893+0x340>
  40fa74:	movsxd rdi,DWORD PTR [r14]
  40fa77:	mov    rsi,r13
  40fa7a:	mov    edx,0x80002
  40fa7f:	xor    eax,eax
  40fa81:	call   407180 <openat@plt>
  40fa86:	lea    rbx,[rsp+0x98]
  40fa8e:	mov    DWORD PTR [rsp+0x98],eax
  40fa95:	test   eax,eax
  40fa97:	mov    r13,QWORD PTR [rsp+0xb0]
  40fa9f:	jge    40fac4 <__swc_fn_585f006d_000107_4796e893+0x464>
  40faa1:	mov    rdi,r15
  40faa4:	xor    eax,eax
  40faa6:	call   407190 <closedir@plt>
  40faab:	mov    r13,QWORD PTR [rsp+0xb0]
  40fab3:	movsxd rdi,r13d
  40fab6:	xor    eax,eax
  40fab8:	call   4070b0 <close@plt>
  40fabd:	xor    eax,eax
  40fabf:	jmp    40fc36 <__swc_fn_585f006d_000107_4796e893+0x5d6>
  40fac4:	mov    rax,rbx
  40fac7:	movsxd rdi,DWORD PTR [rax]
  40faca:	xor    esi,esi
  40facc:	mov    edx,0x2
  40fad1:	xor    eax,eax
  40fad3:	call   4070a0 <lseek@plt>
  40fad8:	mov    r12,QWORD PTR [rsp+0xa8]
  40fae0:	cmp    rax,r12
  40fae3:	je     40fb0a <__swc_fn_585f006d_000107_4796e893+0x4aa>
  40fae5:	movsxd rdi,DWORD PTR [rbx]
  40fae8:	xor    eax,eax
  40faea:	call   4070b0 <close@plt>
  40faef:	mov    rdi,r15
  40faf2:	xor    eax,eax
  40faf4:	call   407190 <closedir@plt>
  40faf9:	movsxd rdi,r13d
  40fafc:	xor    eax,eax
  40fafe:	call   4070b0 <close@plt>
  40fb03:	xor    eax,eax
  40fb05:	jmp    40fc36 <__swc_fn_585f006d_000107_4796e893+0x5d6>
  40fb0a:	xor    edi,edi
  40fb0c:	mov    rsi,r12
  40fb0f:	mov    edx,0x3
  40fb14:	mov    ecx,0x1
  40fb19:	mov    rax,rbx
  40fb1c:	movsxd r8,DWORD PTR [rax]
  40fb1f:	xor    r9d,r9d
  40fb22:	xor    eax,eax
  40fb24:	call   4070c0 <mmap@plt>
  40fb29:	xor    r12d,r12d
  40fb2c:	cmp    rax,0xffffffffffffffff
  40fb30:	cmovne r12,rax
  40fb34:	movsxd rdi,DWORD PTR [rbx]
  40fb37:	xor    eax,eax
  40fb39:	call   4070b0 <close@plt>
  40fb3e:	mov    rdi,r15
  40fb41:	xor    eax,eax
  40fb43:	call   407190 <closedir@plt>
  40fb48:	movsxd rdi,r13d
  40fb4b:	xor    eax,eax
  40fb4d:	call   4070b0 <close@plt>
  40fb52:	mov    rax,r12
  40fb55:	jmp    40fc36 <__swc_fn_585f006d_000107_4796e893+0x5d6>
  40fb5a:	mov    r14,QWORD PTR [rsp+0xb8]
  40fb62:	mov    rdi,r14
  40fb65:	mov    esi,0x1
  40fb6a:	xor    eax,eax
  40fb6c:	call   4071a0 <memfd_create@plt>
  40fb71:	lea    rbx,[rsp+0x9c]
  40fb79:	mov    DWORD PTR [rsp+0x9c],eax
  40fb80:	test   eax,eax
  40fb82:	jge    40fb9f <__swc_fn_585f006d_000107_4796e893+0x53f>
  40fb84:	mov    rdi,r15
  40fb87:	xor    eax,eax
  40fb89:	call   407190 <closedir@plt>
  40fb8e:	movsxd rdi,r13d
  40fb91:	xor    eax,eax
  40fb93:	call   4070b0 <close@plt>
  40fb98:	xor    eax,eax
  40fb9a:	jmp    40fc36 <__swc_fn_585f006d_000107_4796e893+0x5d6>
  40fb9f:	mov    rax,rbx
  40fba2:	movsxd rdi,DWORD PTR [rax]
  40fba5:	mov    rsi,r12
  40fba8:	xor    eax,eax
  40fbaa:	call   4071b0 <ftruncate@plt>
  40fbaf:	test   eax,eax
  40fbb1:	je     40fbd5 <__swc_fn_585f006d_000107_4796e893+0x575>
  40fbb3:	movsxd rdi,DWORD PTR [rbx]
  40fbb6:	xor    eax,eax
  40fbb8:	call   4070b0 <close@plt>
  40fbbd:	mov    rdi,r15
  40fbc0:	xor    eax,eax
  40fbc2:	call   407190 <closedir@plt>
  40fbc7:	movsxd rdi,r13d
  40fbca:	xor    eax,eax
  40fbcc:	call   4070b0 <close@plt>
  40fbd1:	xor    eax,eax
  40fbd3:	jmp    40fc36 <__swc_fn_585f006d_000107_4796e893+0x5d6>
  40fbd5:	xor    edi,edi
  40fbd7:	mov    rsi,r12
  40fbda:	mov    edx,0x3
  40fbdf:	mov    ecx,0x1
  40fbe4:	mov    rax,rbx
  40fbe7:	movsxd r8,DWORD PTR [rax]
  40fbea:	xor    r9d,r9d
  40fbed:	xor    eax,eax
  40fbef:	call   4070c0 <mmap@plt>
  40fbf4:	mov    r12,rax
  40fbf7:	cmp    rax,0xffffffffffffffff
  40fbfb:	jne    40fc1f <__swc_fn_585f006d_000107_4796e893+0x5bf>
  40fbfd:	movsxd rdi,DWORD PTR [rbx]
  40fc00:	xor    eax,eax
  40fc02:	call   4070b0 <close@plt>
  40fc07:	mov    rdi,r15
  40fc0a:	xor    eax,eax
  40fc0c:	call   407190 <closedir@plt>
  40fc11:	movsxd rdi,r13d
  40fc14:	xor    eax,eax
  40fc16:	call   4070b0 <close@plt>
  40fc1b:	xor    eax,eax
  40fc1d:	jmp    40fc36 <__swc_fn_585f006d_000107_4796e893+0x5d6>
  40fc1f:	mov    rdi,r15
  40fc22:	xor    eax,eax
  40fc24:	call   407190 <closedir@plt>
  40fc29:	movsxd rdi,r13d
  40fc2c:	xor    eax,eax
  40fc2e:	call   4070b0 <close@plt>
  40fc33:	mov    rax,r12
  40fc36:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40fc3f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40fc48:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40fc51:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40fc5a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40fc63:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40fc6c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40fc75:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40fc7e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40fc87:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40fc90:	add    rsp,0x170
  40fc97:	pop    r15
  40fc99:	pop    r14
  40fc9b:	pop    r13
  40fc9d:	pop    rsi
  40fc9e:	pop    rdi
  40fc9f:	pop    r12
  40fca1:	pop    rbx
  40fca2:	ret
	...

000000000040fcb0 <__swc_fn_585f006d_000110_a808fe76>:
  40fcb0:	push   rsi
  40fcb1:	push   rdi
  40fcb2:	push   r12
  40fcb4:	push   r13
  40fcb6:	sub    rsp,0x8
  40fcba:	mov    rsi,r8
  40fcbd:	mov    rdi,rcx
  40fcc0:	mov    r12,rdx
  40fcc3:	call   409120 <__swc_fn_585f006d_000108_84af7666>
  40fcc8:	mov    r13,rax
  40fccb:	test   rax,rax
  40fcce:	jne    40fcdb <__swc_fn_585f006d_000110_a808fe76+0x2b>
  40fcd0:	add    rsp,0x8
  40fcd4:	pop    r13
  40fcd6:	pop    r12
  40fcd8:	pop    rdi
  40fcd9:	pop    rsi
  40fcda:	ret
  40fcdb:	mov    rcx,r13
  40fcde:	call   40cd90 <__swc_fn_585f006d_000133_4b2af8da>
  40fce3:	mov    rax,QWORD PTR [r13+0x8]
  40fce7:	test   rax,rax
  40fcea:	je     40fd29 <__swc_fn_585f006d_000110_a808fe76+0x79>
  40fcec:	nop    DWORD PTR [rax+0x0]
  40fcf0:	lea    rcx,[rax+0x1000]
  40fcf7:	cmp    rdi,rcx
  40fcfa:	jne    40fd21 <__swc_fn_585f006d_000110_a808fe76+0x71>
  40fcfc:	cmp    r12,0x1000
  40fd03:	jb     40fd21 <__swc_fn_585f006d_000110_a808fe76+0x71>
  40fd05:	test   sil,sil
  40fd08:	setne  cl
  40fd0b:	mov    BYTE PTR [rax+0x10],cl
  40fd0e:	mov    rcx,r13
  40fd11:	call   410220 <__swc_fn_585f006d_000134_29412410>
  40fd16:	add    rsp,0x8
  40fd1a:	pop    r13
  40fd1c:	pop    r12
  40fd1e:	pop    rdi
  40fd1f:	pop    rsi
  40fd20:	ret
  40fd21:	mov    rax,QWORD PTR [rax]
  40fd24:	test   rax,rax
  40fd27:	jne    40fcf0 <__swc_fn_585f006d_000110_a808fe76+0x40>
  40fd29:	mov    rcx,r13
  40fd2c:	call   410220 <__swc_fn_585f006d_000134_29412410>
  40fd31:	add    rsp,0x8
  40fd35:	pop    r13
  40fd37:	pop    r12
  40fd39:	pop    rdi
  40fd3a:	pop    rsi
  40fd3b:	ret
  40fd3c:	add    BYTE PTR [rax],al
	...

000000000040fd40 <__swc_fn_585f006d_000113_49b378a9>:
  40fd40:	sub    rsp,0x8
  40fd44:	test   rcx,rcx
  40fd47:	jne    40fd4e <__swc_fn_585f006d_000113_49b378a9+0xe>
  40fd49:	add    rsp,0x8
  40fd4d:	ret
  40fd4e:	call   40c8a0 <__swc_fn_585f006d_000115_1ba33335>
  40fd53:	add    rsp,0x8
  40fd57:	ret
	...

000000000040fd60 <__swc_fn_585f006d_000116_035d76a1>:
  40fd60:	push   r12
  40fd62:	push   r13
  40fd64:	push   r14
  40fd66:	push   rdi
  40fd67:	push   rsi
  40fd68:	sub    rsp,0xc0
  40fd6f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40fd75:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40fd7b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40fd81:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40fd87:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40fd8d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40fd93:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40fd99:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40fda2:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40fdab:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40fdb4:	mov    r12,QWORD PTR [rcx]
  40fdb7:	test   r12,r12
  40fdba:	jne    40fdcc <__swc_fn_585f006d_000116_035d76a1+0x6c>
  40fdbc:	add    rsp,0xc0
  40fdc3:	pop    rsi
  40fdc4:	pop    rdi
  40fdc5:	pop    r14
  40fdc7:	pop    r13
  40fdc9:	pop    r12
  40fdcb:	ret
  40fdcc:	xor    r13d,r13d
  40fdcf:	mov    r14,QWORD PTR [rcx+0x8]
  40fdd3:	cs nop WORD PTR [rax+rax*1+0x0]
  40fddd:	nop    DWORD PTR [rax]
  40fde0:	cmp    r13,r14
  40fde3:	jae    40fe1e <__swc_fn_585f006d_000116_035d76a1+0xbe>
  40fde5:	lea    rax,[r12+r13*1]
  40fde9:	mov    rcx,r14
  40fdec:	sub    rcx,r13
  40fdef:	mov    edi,0x1
  40fdf4:	mov    rsi,rax
  40fdf7:	mov    rdx,rcx
  40fdfa:	xor    eax,eax
  40fdfc:	call   4071c0 <write@plt>
  40fe01:	test   rax,rax
  40fe04:	jle    40fe0b <__swc_fn_585f006d_000116_035d76a1+0xab>
  40fe06:	add    r13,rax
  40fe09:	jmp    40fde0 <__swc_fn_585f006d_000116_035d76a1+0x80>
  40fe0b:	test   rax,rax
  40fe0e:	je     40fe1c <__swc_fn_585f006d_000116_035d76a1+0xbc>
  40fe10:	xor    eax,eax
  40fe12:	call   407130 <__errno_location@plt>
  40fe17:	cmp    DWORD PTR [rax],0x4
  40fe1a:	je     40fde0 <__swc_fn_585f006d_000116_035d76a1+0x80>
  40fe1c:	jmp    40fe1e <__swc_fn_585f006d_000116_035d76a1+0xbe>
  40fe1e:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40fe24:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40fe2a:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40fe30:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40fe36:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40fe3c:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40fe42:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40fe48:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40fe51:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40fe5a:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40fe63:	add    rsp,0xc0
  40fe6a:	pop    rsi
  40fe6b:	pop    rdi
  40fe6c:	pop    r14
  40fe6e:	pop    r13
  40fe70:	pop    r12
  40fe72:	ret
	...

000000000040fe80 <__swc_fn_585f006d_000119_9175a56a>:
  40fe80:	push   rbx
  40fe81:	push   r12
  40fe83:	push   rdi
  40fe84:	push   rsi
  40fe85:	sub    rsp,0x4a8
  40fe8c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  40fe95:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  40fe9e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  40fea7:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  40feb0:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  40feb9:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  40fec2:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  40fecb:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  40fed4:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  40fedd:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  40fee6:	mov    rbx,rdx
  40fee9:	mov    r12d,ecx
  40feec:	vxorps xmm0,xmm0,xmm0
  40fef0:	xor    eax,eax
  40fef2:	cs nop WORD PTR [rax+rax*1+0x0]
  40fefc:	nop    DWORD PTR [rax+0x0]
  40ff00:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  40ff06:	add    rax,0x10
  40ff0a:	cmp    rax,0x400
  40ff11:	jne    40ff00 <__swc_fn_585f006d_000119_9175a56a+0x80>
  40ff13:	lea    rdi,[rsp+0x8]
  40ff18:	mov    esi,0x80
  40ff1d:	xor    eax,eax
  40ff1f:	call   4071d0 <backtrace@plt>
  40ff24:	test   eax,eax
  40ff26:	jle    40ff35 <__swc_fn_585f006d_000119_9175a56a+0xb5>
  40ff28:	movsxd rax,eax
  40ff2b:	lea    rcx,[r12+0x1]
  40ff30:	cmp    rcx,rax
  40ff33:	jb     40ff39 <__swc_fn_585f006d_000119_9175a56a+0xb9>
  40ff35:	xor    eax,eax
  40ff37:	jmp    40ff6a <__swc_fn_585f006d_000119_9175a56a+0xea>
  40ff39:	mov    rcx,QWORD PTR [rbx+0x8]
  40ff3d:	sub    rax,r12
  40ff40:	lea    rsi,[rax-0x1]
  40ff44:	cmp    rcx,rsi
  40ff47:	cmovbe rsi,rcx
  40ff4b:	lea    eax,[r12+0x1]
  40ff50:	lea    rax,[rsp+rax*8+0x8]
  40ff55:	mov    rcx,QWORD PTR [rbx]
  40ff58:	mov    rdx,rax
  40ff5b:	lea    r8,[rsi*8+0x0]
  40ff63:	call   409100 <__swc_fn_585f006d_000105_6fd80914>
  40ff68:	mov    eax,esi
  40ff6a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  40ff73:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  40ff7c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  40ff85:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  40ff8e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  40ff97:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  40ffa0:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  40ffa9:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  40ffb2:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  40ffbb:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  40ffc4:	add    rsp,0x4a8
  40ffcb:	pop    rsi
  40ffcc:	pop    rdi
  40ffcd:	pop    r12
  40ffcf:	pop    rbx
  40ffd0:	ret
	...

000000000040ffe0 <__swc_fn_585f006d_000122_e09461fd>:
  40ffe0:	mov    QWORD PTR [rcx],0x0
  40ffe7:	ret
	...

000000000040fff0 <__swc_fn_585f006d_000125_ce762363>:
  40fff0:	push   rdi
  40fff1:	push   rsi
  40fff2:	sub    rsp,0xa8
  40fff9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ffff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410005:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41000b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410011:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410017:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41001d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410023:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410029:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410032:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41003b:	mov    edi,ecx
  41003d:	mov    rsi,rdx
  410040:	xor    eax,eax
  410042:	call   407060 <pthread_setspecific@plt>
  410047:	test   eax,eax
  410049:	sete   al
  41004c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410052:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410058:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41005e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410064:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41006a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410070:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410076:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41007c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410085:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41008e:	add    rsp,0xa8
  410095:	pop    rsi
  410096:	pop    rdi
  410097:	ret
	...

00000000004100a0 <__swc_fn_585f006d_000128_41c3251c>:
  4100a0:	push   rdi
  4100a1:	push   rsi
  4100a2:	sub    rsp,0xa8
  4100a9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4100af:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4100b5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4100bb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4100c1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4100c7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4100cd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4100d3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4100d9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4100e2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4100eb:	test   rcx,rcx
  4100ee:	je     410101 <__swc_fn_585f006d_000128_41c3251c+0x61>
  4100f0:	lea    rax,[rcx-0x1]
  4100f4:	mov    eax,eax
  4100f6:	mov    edi,eax
  4100f8:	xor    eax,eax
  4100fa:	call   407000 <pthread_getspecific@plt>
  4100ff:	jmp    410103 <__swc_fn_585f006d_000128_41c3251c+0x63>
  410101:	xor    eax,eax
  410103:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410109:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  41010f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410115:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41011b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410121:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410127:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41012d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410133:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41013c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410145:	add    rsp,0xa8
  41014c:	pop    rsi
  41014d:	pop    rdi
  41014e:	ret
	...

0000000000410150 <__swc_fn_585f006d_000131_944f555b>:
  410150:	push   rdi
  410151:	push   rsi
  410152:	sub    rsp,0xb8
  410159:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41015f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410165:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41016b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410171:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410177:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41017d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410183:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41018c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410195:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41019e:	vxorps xmm0,xmm0,xmm0
  4101a2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4101a8:	mov    edi,0x1
  4101ad:	lea    rsi,[rsp+0x8]
  4101b2:	xor    eax,eax
  4101b4:	call   4070e0 <clock_gettime@plt>
  4101b9:	mov    rax,QWORD PTR [rsp+0x8]
  4101be:	imul   rax,rax,0x3b9aca00
  4101c5:	add    rax,QWORD PTR [rsp+0x10]
  4101ca:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4101d0:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4101d6:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4101dc:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4101e2:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4101e8:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4101ee:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4101f4:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4101fd:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410206:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  41020f:	add    rsp,0xb8
  410216:	pop    rsi
  410217:	pop    rdi
  410218:	ret
  410219:	add    BYTE PTR [rax],al
  41021b:	add    BYTE PTR [rax],al
  41021d:	add    BYTE PTR [rax],al
	...

0000000000410220 <__swc_fn_585f006d_000134_29412410>:
  410220:	sub    rsp,0x8
  410224:	xor    eax,eax
  410226:	mov    DWORD PTR [rcx],eax
  410228:	mov    edx,0x7fffffff
  41022d:	call   409800 <__swc_fn_585f006d_000132_f908e7f9>
  410232:	add    rsp,0x8
  410236:	ret
	...

0000000000410240 <__swc_fn_585f006d_000137_a4ba10ed>:
  410240:	push   rdi
  410241:	push   rsi
  410242:	sub    rsp,0xb8
  410249:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41024f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410255:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41025b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410261:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410267:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41026d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410273:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41027c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410285:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41028e:	mov    edi,0x1
  410293:	xor    eax,eax
  410295:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  41029a:	mov    eax,DWORD PTR [rax+0x14]
  41029d:	and    eax,0x20
  4102a0:	setne  al
  4102a3:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4102a9:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4102af:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4102b5:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4102bb:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4102c1:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4102c7:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4102cd:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4102d6:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4102df:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4102e8:	add    rsp,0xb8
  4102ef:	pop    rsi
  4102f0:	pop    rdi
  4102f1:	ret
	...

0000000000410300 <__swc_fn_585f006d_000140_c6b99a56>:
  410300:	push   rsi
  410301:	push   rdi
  410302:	push   r12
  410304:	push   r13
  410306:	push   r14
  410308:	push   r15
  41030a:	cmp    rdx,0x40
  41030e:	jae    41031d <__swc_fn_585f006d_000140_c6b99a56+0x1d>
  410310:	xor    eax,eax
  410312:	pop    r15
  410314:	pop    r14
  410316:	pop    r13
  410318:	pop    r12
  41031a:	pop    rdi
  41031b:	pop    rsi
  41031c:	ret
  41031d:	cmp    BYTE PTR [rcx],0x7f
  410320:	jne    410364 <__swc_fn_585f006d_000140_c6b99a56+0x64>
  410322:	movzx  eax,BYTE PTR [rcx+0x1]
  410326:	cmp    eax,0x45
  410329:	setne  al
  41032c:	jne    410360 <__swc_fn_585f006d_000140_c6b99a56+0x60>
  41032e:	movzx  eax,BYTE PTR [rcx+0x2]
  410332:	cmp    eax,0x4c
  410335:	setne  al
  410338:	jne    410360 <__swc_fn_585f006d_000140_c6b99a56+0x60>
  41033a:	movzx  eax,BYTE PTR [rcx+0x3]
  41033e:	cmp    eax,0x46
  410341:	setne  al
  410344:	jne    410360 <__swc_fn_585f006d_000140_c6b99a56+0x60>
  410346:	cmp    BYTE PTR [rcx+0x4],0x2
  41034a:	setne  al
  41034d:	jne    410360 <__swc_fn_585f006d_000140_c6b99a56+0x60>
  41034f:	cmp    BYTE PTR [rcx+0x5],0x1
  410353:	setne  al
  410356:	jne    410360 <__swc_fn_585f006d_000140_c6b99a56+0x60>
  410358:	cmp    WORD PTR [rcx+0x12],0x3e
  41035d:	setne  al
  410360:	test   al,al
  410362:	je     410371 <__swc_fn_585f006d_000140_c6b99a56+0x71>
  410364:	xor    eax,eax
  410366:	pop    r15
  410368:	pop    r14
  41036a:	pop    r13
  41036c:	pop    r12
  41036e:	pop    rdi
  41036f:	pop    rsi
  410370:	ret
  410371:	cmp    WORD PTR [rcx+0x3a],0x40
  410376:	jne    410391 <__swc_fn_585f006d_000140_c6b99a56+0x91>
  410378:	cmp    WORD PTR [rcx+0x3c],0x0
  41037d:	sete   al
  410380:	je     41038d <__swc_fn_585f006d_000140_c6b99a56+0x8d>
  410382:	mov    ax,WORD PTR [rcx+0x3c]
  410386:	cmp    WORD PTR [rcx+0x3e],ax
  41038a:	setae  al
  41038d:	test   al,al
  41038f:	je     41039e <__swc_fn_585f006d_000140_c6b99a56+0x9e>
  410391:	xor    eax,eax
  410393:	pop    r15
  410395:	pop    r14
  410397:	pop    r13
  410399:	pop    r12
  41039b:	pop    rdi
  41039c:	pop    rsi
  41039d:	ret
  41039e:	movzx  eax,WORD PTR [rcx+0x3c]
  4103a2:	shl    rax,0x6
  4103a6:	cmp    rax,rdx
  4103a9:	ja     4103b7 <__swc_fn_585f006d_000140_c6b99a56+0xb7>
  4103ab:	mov    r9,rdx
  4103ae:	sub    r9,rax
  4103b1:	cmp    QWORD PTR [rcx+0x28],r9
  4103b5:	jbe    4103c4 <__swc_fn_585f006d_000140_c6b99a56+0xc4>
  4103b7:	xor    eax,eax
  4103b9:	pop    r15
  4103bb:	pop    r14
  4103bd:	pop    r13
  4103bf:	pop    r12
  4103c1:	pop    rdi
  4103c2:	pop    rsi
  4103c3:	ret
  4103c4:	mov    rax,QWORD PTR [rcx+0x28]
  4103c8:	add    rax,rcx
  4103cb:	movzx  r9d,WORD PTR [rcx+0x3e]
  4103d0:	lea    r9,[r9*8+0x0]
  4103d8:	lea    r10,[rax+r9*8]
  4103dc:	cmp    QWORD PTR [r10+0x20],rdx
  4103e0:	ja     410402 <__swc_fn_585f006d_000140_c6b99a56+0x102>
  4103e2:	mov    r11,rdx
  4103e5:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  4103ea:	cmp    QWORD PTR [r10+0x18],r11
  4103ee:	seta   r9b
  4103f2:	ja     4103fd <__swc_fn_585f006d_000140_c6b99a56+0xfd>
  4103f4:	cmp    QWORD PTR [r10+0x20],0x9
  4103f9:	setb   r9b
  4103fd:	test   r9b,r9b
  410400:	je     41040f <__swc_fn_585f006d_000140_c6b99a56+0x10f>
  410402:	xor    eax,eax
  410404:	pop    r15
  410406:	pop    r14
  410408:	pop    r13
  41040a:	pop    r12
  41040c:	pop    rdi
  41040d:	pop    rsi
  41040e:	ret
  41040f:	movzx  r9d,WORD PTR [rcx+0x3c]
  410414:	xor    r11d,r11d
  410417:	test   r9,r9
  41041a:	jbe    410515 <__swc_fn_585f006d_000140_c6b99a56+0x215>
  410420:	mov    rsi,QWORD PTR [r10+0x20]
  410424:	sub    rsi,0x9
  410428:	cs nop WORD PTR [rax+rax*1+0x0]
  410432:	cs nop WORD PTR [rax+rax*1+0x0]
  41043c:	nop    DWORD PTR [rax+0x0]
  410440:	movzx  edi,r11w
  410444:	lea    rdi,[rdi*8+0x0]
  41044c:	lea    r12,[rax+rdi*8]
  410450:	rex mov edi,DWORD PTR [rax+rdi*8]
  410454:	cmp    rdi,rsi
  410457:	ja     410508 <__swc_fn_585f006d_000140_c6b99a56+0x208>
  41045d:	mov    r13,QWORD PTR [r10+0x18]
  410461:	add    r13,rdi
  410464:	lea    rdi,[rcx+r13*1]
  410468:	lea    r13,[rip+0x20c1]        # 412530 <__swc_rdata_base_585f006d+0x420>
  41046f:	movabs r14,0x676264676177732e
  410479:	cmp    QWORD PTR [rdi],r14
  41047c:	jne    410485 <__swc_fn_585f006d_000140_c6b99a56+0x185>
  41047e:	rex cmp BYTE PTR [rdi+0x8],0x0
  410483:	je     4104b2 <__swc_fn_585f006d_000140_c6b99a56+0x1b2>
  410485:	cs nop WORD PTR [rax+rax*1+0x0]
  41048f:	nop
  410490:	movzx  r14d,BYTE PTR [rdi]
  410494:	movzx  r15d,BYTE PTR [r13+0x0]
  410499:	cmp    r14,r15
  41049c:	jne    4104a8 <__swc_fn_585f006d_000140_c6b99a56+0x1a8>
  41049e:	add    rdi,0x1
  4104a2:	add    r13,0x1
  4104a6:	jmp    410490 <__swc_fn_585f006d_000140_c6b99a56+0x190>
  4104a8:	mov    rdi,r14
  4104ab:	sub    rdi,r15
  4104ae:	test   edi,edi
  4104b0:	jne    410508 <__swc_fn_585f006d_000140_c6b99a56+0x208>
  4104b2:	cmp    DWORD PTR [r12+0x4],0x1
  4104b8:	jne    4104e0 <__swc_fn_585f006d_000140_c6b99a56+0x1e0>
  4104ba:	cmp    QWORD PTR [r12+0x20],0x10
  4104c0:	setb   al
  4104c3:	jb     4104dc <__swc_fn_585f006d_000140_c6b99a56+0x1dc>
  4104c5:	cmp    QWORD PTR [r12+0x20],rdx
  4104ca:	seta   al
  4104cd:	ja     4104dc <__swc_fn_585f006d_000140_c6b99a56+0x1dc>
  4104cf:	sub    rdx,QWORD PTR [r12+0x20]
  4104d4:	cmp    QWORD PTR [r12+0x18],rdx
  4104d9:	seta   al
  4104dc:	test   al,al
  4104de:	je     4104ed <__swc_fn_585f006d_000140_c6b99a56+0x1ed>
  4104e0:	xor    eax,eax
  4104e2:	pop    r15
  4104e4:	pop    r14
  4104e6:	pop    r13
  4104e8:	pop    r12
  4104ea:	pop    rdi
  4104eb:	pop    rsi
  4104ec:	ret
  4104ed:	mov    rax,QWORD PTR [r12+0x20]
  4104f2:	mov    QWORD PTR [r8],rax
  4104f5:	mov    rax,QWORD PTR [r12+0x18]
  4104fa:	add    rax,rcx
  4104fd:	pop    r15
  4104ff:	pop    r14
  410501:	pop    r13
  410503:	pop    r12
  410505:	pop    rdi
  410506:	pop    rsi
  410507:	ret
  410508:	add    r11,0x1
  41050c:	cmp    r11,r9
  41050f:	jb     410440 <__swc_fn_585f006d_000140_c6b99a56+0x140>
  410515:	xor    eax,eax
  410517:	pop    r15
  410519:	pop    r14
  41051b:	pop    r13
  41051d:	pop    r12
  41051f:	pop    rdi
  410520:	pop    rsi
  410521:	ret
	...

0000000000410530 <__swc_fn_585f006d_000143_81c0d993>:
  410530:	push   rdi
  410531:	push   rsi
  410532:	sub    rsp,0xa8
  410539:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41053f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410545:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41054b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410551:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410557:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41055d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410563:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410569:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410572:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41057b:	mov    rdi,rcx
  41057e:	xor    eax,eax
  410580:	call   4071f0 <free@plt>
  410585:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41058b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410591:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410597:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41059d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4105a3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4105a9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4105af:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4105b5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4105be:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4105c7:	add    rsp,0xa8
  4105ce:	pop    rsi
  4105cf:	pop    rdi
  4105d0:	ret
	...

00000000004105e0 <__swc_fn_585f006d_000146_43f4fdca>:
  4105e0:	push   rbx
  4105e1:	push   rsi
  4105e2:	push   rdi
  4105e3:	push   r12
  4105e5:	push   r13
  4105e7:	push   r15
  4105e9:	sub    rsp,0x4e8
  4105f0:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  4105f9:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  410602:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  41060b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  410614:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  41061d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  410626:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  41062f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  410638:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  410641:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  41064a:	mov    rbx,QWORD PTR [rcx]
  41064d:	mov    rcx,QWORD PTR [rcx+0x8]
  410651:	mov    rsi,rcx
  410654:	xor    edi,edi
  410656:	vmovsd xmm6,QWORD PTR [rip+0x1f32]        # 412590 <__swc_rdata_base_585f006d+0x480>
  41065e:	vmovsd xmm7,QWORD PTR [rip+0x1f33]        # 412599 <__swc_rdata_base_585f006d+0x489>
  410666:	vmovsd xmm8,QWORD PTR [rip+0x1f34]        # 4125a2 <__swc_rdata_base_585f006d+0x492>
  41066e:	vmovsd xmm9,QWORD PTR [rip+0x1f35]        # 4125ab <__swc_rdata_base_585f006d+0x49b>
  410676:	vmovsd xmm10,QWORD PTR [rip+0x1f36]        # 4125b4 <__swc_rdata_base_585f006d+0x4a4>
  41067e:	vmovups xmm11,xmm6
  410682:	vmovsd QWORD PTR [rsp+0x418],xmm7
  41068b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410694:	vmovsd QWORD PTR [rsp+0x428],xmm9
  41069d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  4106a6:	vmovsd xmm15,QWORD PTR [rip+0x1f0f]        # 4125bd <__swc_rdata_base_585f006d+0x4ad>
  4106ae:	vmovups xmm14,xmm15
  4106b3:	vmovups xmm0,xmm9
  4106b8:	vmovsd QWORD PTR [rsp+0x438],xmm15
  4106c1:	vmovups xmm13,xmm8
  4106c6:	vmovsd QWORD PTR [rsp+0x440],xmm15
  4106cf:	test   rsi,rsi
  4106d2:	je     411703 <__swc_fn_585f006d_000146_43f4fdca+0x1123>
  4106d8:	cs nop WORD PTR [rax+rax*1+0x0]
  4106e2:	cs nop WORD PTR [rax+rax*1+0x0]
  4106ec:	nop    DWORD PTR [rax+0x0]
  4106f0:	lea    rcx,[rdi+rdi*1]
  4106f4:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  4106f9:	vpshufd xmm3,xmm2,0xee
  4106fe:	vmovq  rcx,xmm3
  410703:	test   rcx,rcx
  410706:	je     41071c <__swc_fn_585f006d_000146_43f4fdca+0x13c>
  410708:	test   DWORD PTR [rcx+0x28],0x400000
  41070f:	je     41071c <__swc_fn_585f006d_000146_43f4fdca+0x13c>
  410711:	mov    rdx,QWORD PTR [rcx+0x30]
  410715:	test   rdx,rdx
  410718:	cmovne rcx,rdx
  41071c:	test   DWORD PTR [rcx+0x28],0x1000
  410723:	je     410744 <__swc_fn_585f006d_000146_43f4fdca+0x164>
  410725:	mov    rdx,QWORD PTR [rcx+0x40]
  410729:	mov    rcx,rdx
  41072c:	vmovq  r8,xmm2
  410731:	mov    r8,QWORD PTR [r8]
  410734:	mov    QWORD PTR [rsp+0x60],r8
  410739:	mov    QWORD PTR [rsp+0x68],rdx
  41073e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410744:	test   BYTE PTR [rcx+0x28],0x1
  410748:	jne    410750 <__swc_fn_585f006d_000146_43f4fdca+0x170>
  41074a:	vmovups xmm12,xmm0
  41074e:	jmp    41076a <__swc_fn_585f006d_000146_43f4fdca+0x18a>
  410750:	vmovq  rax,xmm2
  410755:	mov    rax,QWORD PTR [rax]
  410758:	lea    rcx,[rax+0x10]
  41075c:	vmovups xmm12,xmm0
  410760:	call   40fd60 <__swc_fn_585f006d_000116_035d76a1>
  410765:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  41076a:	test   DWORD PTR [rcx+0x28],0x400
  410771:	je     4107d2 <__swc_fn_585f006d_000146_43f4fdca+0x1f2>
  410773:	vmovq  rax,xmm2
  410778:	mov    rax,QWORD PTR [rax]
  41077b:	xor    ecx,ecx
  41077d:	test   rax,rax
  410780:	je     4107b0 <__swc_fn_585f006d_000146_43f4fdca+0x1d0>
  410782:	mov    rdx,rax
  410785:	mov    r8b,BYTE PTR [rdx]
  410788:	test   r8b,r8b
  41078b:	je     4107b0 <__swc_fn_585f006d_000146_43f4fdca+0x1d0>
  41078d:	cs nop WORD PTR [rax+rax*1+0x0]
  410797:	nop    WORD PTR [rax+rax*1+0x0]
  4107a0:	add    rdx,0x1
  4107a4:	add    rcx,0x1
  4107a8:	mov    r8b,BYTE PTR [rdx]
  4107ab:	test   r8b,r8b
  4107ae:	jne    4107a0 <__swc_fn_585f006d_000146_43f4fdca+0x1c0>
  4107b0:	mov    QWORD PTR [rsp+0x88],rax
  4107b8:	mov    QWORD PTR [rsp+0x90],rcx
  4107c0:	lea    rcx,[rsp+0x88]
  4107c8:	call   40fd60 <__swc_fn_585f006d_000116_035d76a1>
  4107cd:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  4107d2:	cmp    BYTE PTR [rcx+0x2c],0x6
  4107d6:	jne    4107ed <__swc_fn_585f006d_000146_43f4fdca+0x20d>
  4107d8:	vmovq  rax,xmm2
  4107dd:	mov    rax,QWORD PTR [rax]
  4107e0:	mov    rcx,rax
  4107e3:	call   409cd0 <__swc_fn_585f006d_000144_72996a5b>
  4107e8:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  4107ed:	cmp    BYTE PTR [rcx+0x2c],0x1
  4107f1:	jne    4116d9 <__swc_fn_585f006d_000146_43f4fdca+0x10f9>
  4107f7:	vmovq  rdx,xmm2
  4107fc:	mov    cl,BYTE PTR [rcx+0x40]
  4107ff:	cmp    cl,0x7
  410802:	jb     410845 <__swc_fn_585f006d_000146_43f4fdca+0x265>
  410804:	je     4108b8 <__swc_fn_585f006d_000146_43f4fdca+0x2d8>
  41080a:	cmp    cl,0x8
  41080d:	je     4108c4 <__swc_fn_585f006d_000146_43f4fdca+0x2e4>
  410813:	cmp    cl,0x9
  410816:	je     4108dd <__swc_fn_585f006d_000146_43f4fdca+0x2fd>
  41081c:	cmp    cl,0xa
  41081f:	je     410fc4 <__swc_fn_585f006d_000146_43f4fdca+0x9e4>
  410825:	cmp    cl,0xb
  410828:	je     4116ab <__swc_fn_585f006d_000146_43f4fdca+0x10cb>
  41082e:	cmp    cl,0xc
  410831:	je     4108d1 <__swc_fn_585f006d_000146_43f4fdca+0x2f1>
  410837:	cmp    cl,0xd
  41083a:	je     4116a1 <__swc_fn_585f006d_000146_43f4fdca+0x10c1>
  410840:	jmp    4116cb <__swc_fn_585f006d_000146_43f4fdca+0x10eb>
  410845:	cmp    cl,0x1
  410848:	je     410868 <__swc_fn_585f006d_000146_43f4fdca+0x288>
  41084a:	cmp    cl,0x2
  41084d:	je     410876 <__swc_fn_585f006d_000146_43f4fdca+0x296>
  41084f:	cmp    cl,0x3
  410852:	je     410884 <__swc_fn_585f006d_000146_43f4fdca+0x2a4>
  410854:	cmp    cl,0x4
  410857:	je     410891 <__swc_fn_585f006d_000146_43f4fdca+0x2b1>
  410859:	cmp    cl,0x5
  41085c:	je     41089e <__swc_fn_585f006d_000146_43f4fdca+0x2be>
  41085e:	cmp    cl,0x6
  410861:	je     4108ab <__swc_fn_585f006d_000146_43f4fdca+0x2cb>
  410863:	jmp    4116cb <__swc_fn_585f006d_000146_43f4fdca+0x10eb>
  410868:	movsx  rcx,BYTE PTR [rdx]
  41086c:	call   40cf80 <__swc_fn_585f006d_000145_863755b5>
  410871:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  410876:	movsx  rcx,WORD PTR [rdx]
  41087a:	call   40cf80 <__swc_fn_585f006d_000145_863755b5>
  41087f:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  410884:	movsxd rcx,DWORD PTR [rdx]
  410887:	call   40cf80 <__swc_fn_585f006d_000145_863755b5>
  41088c:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  410891:	mov    rcx,QWORD PTR [rdx]
  410894:	call   40cf80 <__swc_fn_585f006d_000145_863755b5>
  410899:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  41089e:	movzx  ecx,BYTE PTR [rdx]
  4108a1:	call   409cd0 <__swc_fn_585f006d_000144_72996a5b>
  4108a6:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  4108ab:	movzx  ecx,WORD PTR [rdx]
  4108ae:	call   409cd0 <__swc_fn_585f006d_000144_72996a5b>
  4108b3:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  4108b8:	mov    ecx,DWORD PTR [rdx]
  4108ba:	call   409cd0 <__swc_fn_585f006d_000144_72996a5b>
  4108bf:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  4108c4:	mov    rcx,QWORD PTR [rdx]
  4108c7:	call   409cd0 <__swc_fn_585f006d_000144_72996a5b>
  4108cc:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  4108d1:	mov    ecx,DWORD PTR [rdx]
  4108d3:	call   409cd0 <__swc_fn_585f006d_000144_72996a5b>
  4108d8:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  4108dd:	lea    rcx,[rsp+0xa8]
  4108e5:	vxorps xmm0,xmm0,xmm0
  4108e9:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4108f2:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4108fb:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  410904:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  41090d:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  410916:	vmovups XMMWORD PTR [rsp+0xf8],xmm0
  41091f:	mov    DWORD PTR [rsp+0x108],0x0
  41092a:	vxorpd xmm0,xmm0,xmm0
  41092e:	vmovss xmm1,DWORD PTR [rdx]
  410932:	vcvtss2sd xmm0,xmm0,xmm1
  410936:	vmovsd xmm1,xmm1,xmm0
  41093a:	vcomisd xmm0,xmm0
  41093e:	setne  dl
  410941:	movzx  edx,dl
  410944:	setp   r8b
  410948:	movzx  r8d,r8b
  41094c:	or     edx,r8d
  41094f:	test   dl,dl
  410951:	je     41095e <__swc_fn_585f006d_000146_43f4fdca+0x37e>
  410953:	mov    DWORD PTR [rcx],0x6e616e
  410959:	jmp    410f58 <__swc_fn_585f006d_000146_43f4fdca+0x978>
  41095e:	vcomisd xmm1,xmm6
  410962:	ja     41096a <__swc_fn_585f006d_000146_43f4fdca+0x38a>
  410964:	vcomisd xmm7,xmm1
  410968:	jbe    41098e <__swc_fn_585f006d_000146_43f4fdca+0x3ae>
  41096a:	vxorpd xmm0,xmm0,xmm0
  41096e:	vcomisd xmm0,xmm1
  410972:	jbe    410983 <__swc_fn_585f006d_000146_43f4fdca+0x3a3>
  410974:	mov    DWORD PTR [rcx],0x666e692d
  41097a:	mov    BYTE PTR [rcx+0x4],0x0
  41097e:	jmp    410f58 <__swc_fn_585f006d_000146_43f4fdca+0x978>
  410983:	mov    DWORD PTR [rcx],0x666e69
  410989:	jmp    410f58 <__swc_fn_585f006d_000146_43f4fdca+0x978>
  41098e:	vcomisd xmm1,xmm8
  410993:	jae    41099f <__swc_fn_585f006d_000146_43f4fdca+0x3bf>
  410995:	vcomisd xmm9,xmm1
  410999:	jbe    410d1e <__swc_fn_585f006d_000146_43f4fdca+0x73e>
  41099f:	vmovups xmm0,xmm1
  4109a3:	vxorpd xmm2,xmm2,xmm2
  4109a7:	vcomisd xmm2,xmm1
  4109ab:	jbe    4109bb <__swc_fn_585f006d_000146_43f4fdca+0x3db>
  4109ad:	vmovsd xmm1,xmm1,xmm0
  4109b1:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1b97]        # 412550 <__swc_rdata_base_585f006d+0x440>
  4109b9:	jmp    4109bf <__swc_fn_585f006d_000146_43f4fdca+0x3df>
  4109bb:	vmovsd xmm1,xmm1,xmm0
  4109bf:	xor    r8d,r8d
  4109c2:	vcomisd xmm1,xmm15
  4109c7:	jb     4109f0 <__swc_fn_585f006d_000146_43f4fdca+0x410>
  4109c9:	cs nop WORD PTR [rax+rax*1+0x0]
  4109d3:	cs nop WORD PTR [rax+rax*1+0x0]
  4109dd:	nop    DWORD PTR [rax]
  4109e0:	vdivsd xmm1,xmm1,xmm15
  4109e5:	add    r8,0x1
  4109e9:	vcomisd xmm1,xmm15
  4109ee:	jae    4109e0 <__swc_fn_585f006d_000146_43f4fdca+0x400>
  4109f0:	mov    r9,rcx
  4109f3:	vxorpd xmm2,xmm2,xmm2
  4109f7:	vcomisd xmm2,xmm0
  4109fb:	jbe    410a04 <__swc_fn_585f006d_000146_43f4fdca+0x424>
  4109fd:	mov    BYTE PTR [rcx],0x2d
  410a00:	lea    r9,[rcx+0x1]
  410a04:	vcvttsd2si rdx,xmm1
  410a09:	mov    r10b,dl
  410a0c:	add    r10b,0x30
  410a10:	mov    BYTE PTR [r9],r10b
  410a13:	vxorpd xmm0,xmm0,xmm0
  410a17:	movzx  edx,dl
  410a1a:	vcvtsi2sd xmm0,xmm0,rdx
  410a1f:	vsubsd xmm0,xmm1,xmm0
  410a23:	vmulsd xmm1,xmm0,xmm15
  410a28:	mov    BYTE PTR [r9+0x1],0x2e
  410a2d:	vcvttsd2si rdx,xmm1
  410a32:	mov    r10b,dl
  410a35:	add    r10b,0x30
  410a39:	mov    BYTE PTR [r9+0x2],r10b
  410a3d:	vxorpd xmm0,xmm0,xmm0
  410a41:	movzx  edx,dl
  410a44:	vcvtsi2sd xmm0,xmm0,rdx
  410a49:	vsubsd xmm0,xmm1,xmm0
  410a4d:	vmulsd xmm1,xmm0,xmm15
  410a52:	vcvttsd2si rdx,xmm1
  410a57:	mov    r10b,dl
  410a5a:	add    r10b,0x30
  410a5e:	mov    BYTE PTR [r9+0x3],r10b
  410a62:	vxorpd xmm0,xmm0,xmm0
  410a66:	movzx  edx,dl
  410a69:	vcvtsi2sd xmm0,xmm0,rdx
  410a6e:	vsubsd xmm0,xmm1,xmm0
  410a72:	vmulsd xmm1,xmm0,xmm15
  410a77:	vcvttsd2si rdx,xmm1
  410a7c:	mov    r10b,dl
  410a7f:	add    r10b,0x30
  410a83:	mov    BYTE PTR [r9+0x4],r10b
  410a87:	vxorpd xmm0,xmm0,xmm0
  410a8b:	movzx  edx,dl
  410a8e:	vcvtsi2sd xmm0,xmm0,rdx
  410a93:	vsubsd xmm0,xmm1,xmm0
  410a97:	vmulsd xmm1,xmm0,xmm15
  410a9c:	vcvttsd2si rdx,xmm1
  410aa1:	mov    r10b,dl
  410aa4:	add    r10b,0x30
  410aa8:	mov    BYTE PTR [r9+0x5],r10b
  410aac:	vxorpd xmm0,xmm0,xmm0
  410ab0:	movzx  edx,dl
  410ab3:	vcvtsi2sd xmm0,xmm0,rdx
  410ab8:	vsubsd xmm0,xmm1,xmm0
  410abc:	vmulsd xmm1,xmm0,xmm15
  410ac1:	vcvttsd2si rdx,xmm1
  410ac6:	mov    r10b,dl
  410ac9:	add    r10b,0x30
  410acd:	mov    BYTE PTR [r9+0x6],r10b
  410ad1:	vxorpd xmm0,xmm0,xmm0
  410ad5:	movzx  edx,dl
  410ad8:	vcvtsi2sd xmm0,xmm0,rdx
  410add:	vsubsd xmm0,xmm1,xmm0
  410ae1:	vmulsd xmm1,xmm0,xmm15
  410ae6:	vcvttsd2si rdx,xmm1
  410aeb:	mov    r10b,dl
  410aee:	add    r10b,0x30
  410af2:	mov    BYTE PTR [r9+0x7],r10b
  410af6:	vxorpd xmm0,xmm0,xmm0
  410afa:	movzx  edx,dl
  410afd:	vcvtsi2sd xmm0,xmm0,rdx
  410b02:	vsubsd xmm0,xmm1,xmm0
  410b06:	vmulsd xmm1,xmm0,xmm15
  410b0b:	vcvttsd2si rdx,xmm1
  410b10:	mov    r10b,dl
  410b13:	add    r10b,0x30
  410b17:	mov    BYTE PTR [r9+0x8],r10b
  410b1b:	vxorpd xmm0,xmm0,xmm0
  410b1f:	movzx  edx,dl
  410b22:	vcvtsi2sd xmm0,xmm0,rdx
  410b27:	vsubsd xmm0,xmm1,xmm0
  410b2b:	vmulsd xmm1,xmm0,xmm15
  410b30:	vcvttsd2si rdx,xmm1
  410b35:	mov    r10b,dl
  410b38:	add    r10b,0x30
  410b3c:	mov    BYTE PTR [r9+0x9],r10b
  410b40:	vxorpd xmm0,xmm0,xmm0
  410b44:	movzx  edx,dl
  410b47:	vcvtsi2sd xmm0,xmm0,rdx
  410b4c:	vsubsd xmm0,xmm1,xmm0
  410b50:	vmulsd xmm1,xmm0,xmm15
  410b55:	vcvttsd2si rdx,xmm1
  410b5a:	mov    r10b,dl
  410b5d:	add    r10b,0x30
  410b61:	mov    BYTE PTR [r9+0xa],r10b
  410b65:	vxorpd xmm0,xmm0,xmm0
  410b69:	movzx  edx,dl
  410b6c:	vcvtsi2sd xmm0,xmm0,rdx
  410b71:	vsubsd xmm0,xmm1,xmm0
  410b75:	vmulsd xmm1,xmm0,xmm15
  410b7a:	vcvttsd2si rdx,xmm1
  410b7f:	mov    r10b,dl
  410b82:	add    r10b,0x30
  410b86:	mov    BYTE PTR [r9+0xb],r10b
  410b8a:	lea    r10,[r9+0x4]
  410b8e:	vxorpd xmm0,xmm0,xmm0
  410b92:	movzx  edx,dl
  410b95:	vcvtsi2sd xmm0,xmm0,rdx
  410b9a:	vsubsd xmm0,xmm1,xmm0
  410b9e:	vmulsd xmm1,xmm0,xmm15
  410ba3:	vcvttsd2si rdx,xmm1
  410ba8:	mov    r11b,dl
  410bab:	add    r11b,0x30
  410baf:	mov    BYTE PTR [r9+0xc],r11b
  410bb3:	vxorpd xmm0,xmm0,xmm0
  410bb7:	movzx  edx,dl
  410bba:	vcvtsi2sd xmm0,xmm0,rdx
  410bbf:	vsubsd xmm0,xmm1,xmm0
  410bc3:	vmulsd xmm1,xmm0,xmm15
  410bc8:	vcvttsd2si rdx,xmm1
  410bcd:	mov    r11b,dl
  410bd0:	add    r11b,0x30
  410bd4:	mov    BYTE PTR [r9+0xd],r11b
  410bd8:	lea    r10,[r10+0x2]
  410bdc:	vxorpd xmm0,xmm0,xmm0
  410be0:	movzx  edx,dl
  410be3:	vcvtsi2sd xmm0,xmm0,rdx
  410be8:	vsubsd xmm0,xmm1,xmm0
  410bec:	vmulsd xmm1,xmm0,xmm15
  410bf1:	vcvttsd2si rdx,xmm1
  410bf6:	mov    r11b,dl
  410bf9:	add    r11b,0x30
  410bfd:	mov    BYTE PTR [r9+0xe],r11b
  410c01:	vxorpd xmm0,xmm0,xmm0
  410c05:	movzx  edx,dl
  410c08:	vcvtsi2sd xmm0,xmm0,rdx
  410c0d:	vsubsd xmm0,xmm1,xmm0
  410c11:	vmulsd xmm1,xmm0,xmm15
  410c16:	vcvttsd2si rdx,xmm1
  410c1b:	mov    r11b,dl
  410c1e:	add    r11b,0x30
  410c22:	mov    BYTE PTR [r9+0xf],r11b
  410c26:	lea    r10,[r10+0x2]
  410c2a:	lea    r10,[r10+0x2]
  410c2e:	lea    r10,[r10+0x2]
  410c32:	lea    r10,[r10+0x2]
  410c36:	lea    r10,[r10+0x2]
  410c3a:	vxorpd xmm0,xmm0,xmm0
  410c3e:	movzx  edx,dl
  410c41:	vcvtsi2sd xmm0,xmm0,rdx
  410c46:	vsubsd xmm0,xmm1,xmm0
  410c4a:	vmulsd xmm1,xmm0,xmm15
  410c4f:	vcvttsd2si rdx,xmm1
  410c54:	mov    r11b,dl
  410c57:	add    r11b,0x30
  410c5b:	mov    BYTE PTR [r9+0x10],r11b
  410c5f:	vxorpd xmm0,xmm0,xmm0
  410c63:	movzx  edx,dl
  410c66:	vcvtsi2sd xmm0,xmm0,rdx
  410c6b:	vsubsd xmm0,xmm1,xmm0
  410c6f:	vmulsd xmm1,xmm0,xmm15
  410c74:	vcvttsd2si rdx,xmm1
  410c79:	add    dl,0x30
  410c7c:	mov    BYTE PTR [r9+0x11],dl
  410c80:	mov    BYTE PTR [r10+0x2],0x65
  410c85:	lea    r9,[r10+0x3]
  410c89:	test   r8,r8
  410c8c:	jl     410c95 <__swc_fn_585f006d_000146_43f4fdca+0x6b5>
  410c8e:	mov    BYTE PTR [r9],0x2b
  410c92:	inc    r9
  410c95:	mov    r10,r9
  410c98:	mov    rdx,r8
  410c9b:	nop    DWORD PTR [rax+rax*1+0x0]
  410ca0:	mov    r11,rdx
  410ca3:	movabs rdx,0x6666666666666667
  410cad:	mov    rax,r11
  410cb0:	imul   rdx
  410cb3:	sar    rdx,0x2
  410cb7:	mov    r12,rdx
  410cba:	shr    rdx,0x3f
  410cbe:	add    r12,rdx
  410cc1:	mov    rdx,r12
  410cc4:	imul   r13,r12,0xa
  410cc8:	sub    r11,r13
  410ccb:	mov    r13,QWORD PTR [rip+0x186e]        # 412540 <__swc_rdata_base_585f006d+0x430>
  410cd2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410cd7:	mov    BYTE PTR [r10],r11b
  410cda:	lea    r11,[r10+0x1]
  410cde:	mov    r10,r11
  410ce1:	test   r12,r12
  410ce4:	jne    410ca0 <__swc_fn_585f006d_000146_43f4fdca+0x6c0>
  410ce6:	test   r8,r8
  410ce9:	jge    410cf3 <__swc_fn_585f006d_000146_43f4fdca+0x713>
  410ceb:	mov    BYTE PTR [r11],0x2d
  410cef:	lea    r10,[r11+0x1]
  410cf3:	mov    BYTE PTR [r10],0x0
  410cf7:	sub    r10,0x1
  410cfb:	nop    DWORD PTR [rax+rax*1+0x0]
  410d00:	cmp    r9,r10
  410d03:	jae    410f58 <__swc_fn_585f006d_000146_43f4fdca+0x978>
  410d09:	mov    al,BYTE PTR [r10]
  410d0c:	mov    dl,BYTE PTR [r9]
  410d0f:	mov    BYTE PTR [r10],dl
  410d12:	sub    r10,0x1
  410d16:	mov    BYTE PTR [r9],al
  410d19:	inc    r9
  410d1c:	jmp    410d00 <__swc_fn_585f006d_000146_43f4fdca+0x720>
  410d1e:	vcvttsd2si rdx,xmm1
  410d23:	mov    r8,rdx
  410d26:	vxorpd xmm0,xmm0,xmm0
  410d2a:	vcvtsi2sd xmm0,xmm0,rdx
  410d2f:	vsubsd xmm0,xmm1,xmm0
  410d33:	mov    r9d,0x8
  410d39:	vxorpd xmm2,xmm2,xmm2
  410d3d:	vcomisd xmm2,xmm0
  410d41:	jbe    410d4b <__swc_fn_585f006d_000146_43f4fdca+0x76b>
  410d43:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x1805]        # 412550 <__swc_rdata_base_585f006d+0x440>
  410d4b:	test   r9d,r9d
  410d4e:	je     410d5a <__swc_fn_585f006d_000146_43f4fdca+0x77a>
  410d50:	vmulsd xmm0,xmm0,xmm14
  410d55:	dec    r9d
  410d58:	jne    410d50 <__swc_fn_585f006d_000146_43f4fdca+0x770>
  410d5a:	vcvttsd2si r9,xmm0
  410d5f:	mov    r10,r9
  410d62:	vxorpd xmm2,xmm2,xmm2
  410d66:	vcvtsi2sd xmm2,xmm2,r9
  410d6b:	vsubsd xmm0,xmm0,xmm2
  410d6f:	vcomisd xmm0,xmm10
  410d74:	lea    r9,[r9+0x1]
  410d78:	cmova  r10,r9
  410d7c:	cmp    r10,0x5f5e100
  410d83:	jne    410d9c <__swc_fn_585f006d_000146_43f4fdca+0x7bc>
  410d85:	lea    r8,[rdx-0x1]
  410d89:	vxorpd xmm0,xmm0,xmm0
  410d8d:	vcomisd xmm0,xmm1
  410d91:	lea    rdx,[rdx+0x1]
  410d95:	cmovbe r8,rdx
  410d99:	xor    r10d,r10d
  410d9c:	mov    r9,rcx
  410d9f:	test   r8,r8
  410da2:	jne    410dc2 <__swc_fn_585f006d_000146_43f4fdca+0x7e2>
  410da4:	vxorpd xmm0,xmm0,xmm0
  410da8:	vcomisd xmm0,xmm1
  410dac:	jbe    410db5 <__swc_fn_585f006d_000146_43f4fdca+0x7d5>
  410dae:	mov    BYTE PTR [rcx],0x2d
  410db1:	lea    r9,[rcx+0x1]
  410db5:	mov    BYTE PTR [r9],0x30
  410db9:	add    r9,0x1
  410dbd:	jmp    410e5b <__swc_fn_585f006d_000146_43f4fdca+0x87b>
  410dc2:	mov    r9,rcx
  410dc5:	mov    rdx,r8
  410dc8:	nop    DWORD PTR [rax+rax*1+0x0]
  410dd0:	mov    r11,rdx
  410dd3:	movabs rdx,0x6666666666666667
  410ddd:	mov    r15,rax
  410de0:	mov    rax,r11
  410de3:	imul   rdx
  410de6:	mov    r12,rdx
  410de9:	mov    rax,r15
  410dec:	sar    r12,0x2
  410df0:	mov    rdx,r12
  410df3:	shr    rdx,0x3f
  410df7:	add    r12,rdx
  410dfa:	mov    rdx,r12
  410dfd:	imul   r13,r12,0xa
  410e01:	sub    r11,r13
  410e04:	mov    r13,QWORD PTR [rip+0x1735]        # 412540 <__swc_rdata_base_585f006d+0x430>
  410e0b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410e10:	mov    BYTE PTR [r9],r11b
  410e13:	lea    r11,[r9+0x1]
  410e17:	mov    r9,r11
  410e1a:	test   r12,r12
  410e1d:	jne    410dd0 <__swc_fn_585f006d_000146_43f4fdca+0x7f0>
  410e1f:	test   r8,r8
  410e22:	jge    410e2c <__swc_fn_585f006d_000146_43f4fdca+0x84c>
  410e24:	mov    BYTE PTR [r11],0x2d
  410e28:	lea    r9,[r11+0x1]
  410e2c:	mov    rdx,r9
  410e2f:	mov    BYTE PTR [r9],0x0
  410e33:	sub    r9,0x1
  410e37:	mov    r8,rcx
  410e3a:	cmp    r8,r9
  410e3d:	jae    410e58 <__swc_fn_585f006d_000146_43f4fdca+0x878>
  410e3f:	nop
  410e40:	mov    r11b,BYTE PTR [r9]
  410e43:	mov    r12b,BYTE PTR [r8]
  410e46:	mov    BYTE PTR [r9],r12b
  410e49:	sub    r9,0x1
  410e4d:	mov    BYTE PTR [r8],r11b
  410e50:	inc    r8
  410e53:	cmp    r8,r9
  410e56:	jb     410e40 <__swc_fn_585f006d_000146_43f4fdca+0x860>
  410e58:	mov    r9,rdx
  410e5b:	mov    BYTE PTR [r9],0x2e
  410e5f:	add    r9,0x1
  410e63:	xor    r8d,r8d
  410e66:	test   r10,r10
  410e69:	je     410eaf <__swc_fn_585f006d_000146_43f4fdca+0x8cf>
  410e6b:	mov    r11d,0x989680
  410e71:	cmp    r10,r11
  410e74:	jge    410eaf <__swc_fn_585f006d_000146_43f4fdca+0x8cf>
  410e76:	cs nop WORD PTR [rax+rax*1+0x0]
  410e80:	inc    r8d
  410e83:	movabs rdx,0x6666666666666667
  410e8d:	mov    r15,rax
  410e90:	mov    rax,r11
  410e93:	imul   rdx
  410e96:	mov    r11,rdx
  410e99:	mov    rax,r15
  410e9c:	sar    r11,0x2
  410ea0:	mov    rdx,r11
  410ea3:	shr    rdx,0x3f
  410ea7:	add    r11,rdx
  410eaa:	cmp    r10,r11
  410ead:	jl     410e80 <__swc_fn_585f006d_000146_43f4fdca+0x8a0>
  410eaf:	test   r8d,r8d
  410eb2:	je     410ecd <__swc_fn_585f006d_000146_43f4fdca+0x8ed>
  410eb4:	cs nop WORD PTR [rax+rax*1+0x0]
  410ebe:	xchg   ax,ax
  410ec0:	mov    BYTE PTR [r9],0x30
  410ec4:	add    r9,0x1
  410ec8:	dec    r8d
  410ecb:	jne    410ec0 <__swc_fn_585f006d_000146_43f4fdca+0x8e0>
  410ecd:	mov    r8,r9
  410ed0:	mov    rdx,r10
  410ed3:	cs nop WORD PTR [rax+rax*1+0x0]
  410edd:	nop    DWORD PTR [rax]
  410ee0:	mov    r11,rdx
  410ee3:	movabs rdx,0x6666666666666667
  410eed:	mov    rax,r11
  410ef0:	imul   rdx
  410ef3:	sar    rdx,0x2
  410ef7:	mov    r12,rdx
  410efa:	shr    rdx,0x3f
  410efe:	add    r12,rdx
  410f01:	mov    rdx,r12
  410f04:	imul   r13,r12,0xa
  410f08:	sub    r11,r13
  410f0b:	mov    r13,QWORD PTR [rip+0x162e]        # 412540 <__swc_rdata_base_585f006d+0x430>
  410f12:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410f17:	mov    BYTE PTR [r8],r11b
  410f1a:	lea    r11,[r8+0x1]
  410f1e:	mov    r8,r11
  410f21:	test   r12,r12
  410f24:	jne    410ee0 <__swc_fn_585f006d_000146_43f4fdca+0x900>
  410f26:	test   r10,r10
  410f29:	jge    410f33 <__swc_fn_585f006d_000146_43f4fdca+0x953>
  410f2b:	mov    BYTE PTR [r11],0x2d
  410f2f:	lea    r8,[r11+0x1]
  410f33:	mov    BYTE PTR [r8],0x0
  410f37:	sub    r8,0x1
  410f3b:	cmp    r9,r8
  410f3e:	jae    410f58 <__swc_fn_585f006d_000146_43f4fdca+0x978>
  410f40:	mov    al,BYTE PTR [r8]
  410f43:	mov    dl,BYTE PTR [r9]
  410f46:	mov    BYTE PTR [r8],dl
  410f49:	sub    r8,0x1
  410f4d:	mov    BYTE PTR [r9],al
  410f50:	inc    r9
  410f53:	cmp    r9,r8
  410f56:	jb     410f40 <__swc_fn_585f006d_000146_43f4fdca+0x960>
  410f58:	xor    eax,eax
  410f5a:	test   rcx,rcx
  410f5d:	je     410f90 <__swc_fn_585f006d_000146_43f4fdca+0x9b0>
  410f5f:	mov    rdx,rcx
  410f62:	mov    r8b,BYTE PTR [rdx]
  410f65:	test   r8b,r8b
  410f68:	je     410f90 <__swc_fn_585f006d_000146_43f4fdca+0x9b0>
  410f6a:	cs nop WORD PTR [rax+rax*1+0x0]
  410f74:	cs nop WORD PTR [rax+rax*1+0x0]
  410f7e:	xchg   ax,ax
  410f80:	add    rdx,0x1
  410f84:	add    rax,0x1
  410f88:	mov    r8b,BYTE PTR [rdx]
  410f8b:	test   r8b,r8b
  410f8e:	jne    410f80 <__swc_fn_585f006d_000146_43f4fdca+0x9a0>
  410f90:	mov    QWORD PTR [rsp+0x240],rcx
  410f98:	mov    QWORD PTR [rsp+0x248],rax
  410fa0:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  410fa9:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  410fb2:	lea    rcx,[rsp+0x250]
  410fba:	call   40fd60 <__swc_fn_585f006d_000116_035d76a1>
  410fbf:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  410fc4:	lea    rcx,[rsp+0x260]
  410fcc:	vxorps xmm0,xmm0,xmm0
  410fd0:	vmovups XMMWORD PTR [rsp+0x260],xmm0
  410fd9:	vmovups XMMWORD PTR [rsp+0x270],xmm0
  410fe2:	vmovups XMMWORD PTR [rsp+0x280],xmm0
  410feb:	vmovups XMMWORD PTR [rsp+0x290],xmm0
  410ff4:	vmovups XMMWORD PTR [rsp+0x2a0],xmm0
  410ffd:	vmovups XMMWORD PTR [rsp+0x2b0],xmm0
  411006:	mov    DWORD PTR [rsp+0x2c0],0x0
  411011:	vmovsd xmm0,QWORD PTR [rdx]
  411015:	vcomisd xmm0,xmm0
  411019:	setne  dl
  41101c:	movzx  edx,dl
  41101f:	setp   r8b
  411023:	movzx  r8d,r8b
  411027:	or     edx,r8d
  41102a:	test   dl,dl
  41102c:	je     411039 <__swc_fn_585f006d_000146_43f4fdca+0xa59>
  41102e:	mov    DWORD PTR [rcx],0x6e616e
  411034:	jmp    411648 <__swc_fn_585f006d_000146_43f4fdca+0x1068>
  411039:	vcomisd xmm0,xmm11
  41103e:	ja     41104f <__swc_fn_585f006d_000146_43f4fdca+0xa6f>
  411040:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  411049:	vcomisd xmm6,xmm0
  41104d:	jbe    411073 <__swc_fn_585f006d_000146_43f4fdca+0xa93>
  41104f:	vxorpd xmm1,xmm1,xmm1
  411053:	vcomisd xmm1,xmm0
  411057:	jbe    411068 <__swc_fn_585f006d_000146_43f4fdca+0xa88>
  411059:	mov    DWORD PTR [rcx],0x666e692d
  41105f:	mov    BYTE PTR [rcx+0x4],0x0
  411063:	jmp    411648 <__swc_fn_585f006d_000146_43f4fdca+0x1068>
  411068:	mov    DWORD PTR [rcx],0x666e69
  41106e:	jmp    411648 <__swc_fn_585f006d_000146_43f4fdca+0x1068>
  411073:	vcomisd xmm0,xmm13
  411078:	jae    411084 <__swc_fn_585f006d_000146_43f4fdca+0xaa4>
  41107a:	vcomisd xmm12,xmm0
  41107e:	jbe    4113ee <__swc_fn_585f006d_000146_43f4fdca+0xe0e>
  411084:	vmovups xmm1,xmm0
  411088:	vxorpd xmm2,xmm2,xmm2
  41108c:	vcomisd xmm2,xmm0
  411090:	jbe    4110a0 <__swc_fn_585f006d_000146_43f4fdca+0xac0>
  411092:	vmovsd xmm0,xmm0,xmm1
  411096:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x14b2]        # 412550 <__swc_rdata_base_585f006d+0x440>
  41109e:	jmp    4110a4 <__swc_fn_585f006d_000146_43f4fdca+0xac4>
  4110a0:	vmovsd xmm0,xmm0,xmm1
  4110a4:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  4110ad:	xor    r8d,r8d
  4110b0:	vcomisd xmm0,xmm6
  4110b4:	jb     4110ce <__swc_fn_585f006d_000146_43f4fdca+0xaee>
  4110b6:	cs nop WORD PTR [rax+rax*1+0x0]
  4110c0:	vdivsd xmm0,xmm0,xmm6
  4110c4:	add    r8,0x1
  4110c8:	vcomisd xmm0,xmm6
  4110cc:	jae    4110c0 <__swc_fn_585f006d_000146_43f4fdca+0xae0>
  4110ce:	mov    r9,rcx
  4110d1:	vxorpd xmm2,xmm2,xmm2
  4110d5:	vcomisd xmm2,xmm1
  4110d9:	jbe    4110e2 <__swc_fn_585f006d_000146_43f4fdca+0xb02>
  4110db:	mov    BYTE PTR [rcx],0x2d
  4110de:	lea    r9,[rcx+0x1]
  4110e2:	vcvttsd2si rdx,xmm0
  4110e7:	mov    r10b,dl
  4110ea:	add    r10b,0x30
  4110ee:	mov    BYTE PTR [r9],r10b
  4110f1:	vxorpd xmm1,xmm1,xmm1
  4110f5:	movzx  edx,dl
  4110f8:	vcvtsi2sd xmm1,xmm1,rdx
  4110fd:	vsubsd xmm0,xmm0,xmm1
  411101:	vmulsd xmm0,xmm0,xmm6
  411105:	mov    BYTE PTR [r9+0x1],0x2e
  41110a:	vcvttsd2si rdx,xmm0
  41110f:	mov    r10b,dl
  411112:	add    r10b,0x30
  411116:	mov    BYTE PTR [r9+0x2],r10b
  41111a:	vxorpd xmm1,xmm1,xmm1
  41111e:	movzx  edx,dl
  411121:	vcvtsi2sd xmm1,xmm1,rdx
  411126:	vsubsd xmm0,xmm0,xmm1
  41112a:	vmulsd xmm0,xmm0,xmm6
  41112e:	vcvttsd2si rdx,xmm0
  411133:	mov    r10b,dl
  411136:	add    r10b,0x30
  41113a:	mov    BYTE PTR [r9+0x3],r10b
  41113e:	vxorpd xmm1,xmm1,xmm1
  411142:	movzx  edx,dl
  411145:	vcvtsi2sd xmm1,xmm1,rdx
  41114a:	vsubsd xmm0,xmm0,xmm1
  41114e:	vmulsd xmm0,xmm0,xmm6
  411152:	vcvttsd2si rdx,xmm0
  411157:	mov    r10b,dl
  41115a:	add    r10b,0x30
  41115e:	mov    BYTE PTR [r9+0x4],r10b
  411162:	vxorpd xmm1,xmm1,xmm1
  411166:	movzx  edx,dl
  411169:	vcvtsi2sd xmm1,xmm1,rdx
  41116e:	vsubsd xmm0,xmm0,xmm1
  411172:	vmulsd xmm0,xmm0,xmm6
  411176:	vcvttsd2si rdx,xmm0
  41117b:	mov    r10b,dl
  41117e:	add    r10b,0x30
  411182:	mov    BYTE PTR [r9+0x5],r10b
  411186:	vxorpd xmm1,xmm1,xmm1
  41118a:	movzx  edx,dl
  41118d:	vcvtsi2sd xmm1,xmm1,rdx
  411192:	vsubsd xmm0,xmm0,xmm1
  411196:	vmulsd xmm0,xmm0,xmm6
  41119a:	vcvttsd2si rdx,xmm0
  41119f:	mov    r10b,dl
  4111a2:	add    r10b,0x30
  4111a6:	mov    BYTE PTR [r9+0x6],r10b
  4111aa:	vxorpd xmm1,xmm1,xmm1
  4111ae:	movzx  edx,dl
  4111b1:	vcvtsi2sd xmm1,xmm1,rdx
  4111b6:	vsubsd xmm0,xmm0,xmm1
  4111ba:	vmulsd xmm0,xmm0,xmm6
  4111be:	vcvttsd2si rdx,xmm0
  4111c3:	mov    r10b,dl
  4111c6:	add    r10b,0x30
  4111ca:	mov    BYTE PTR [r9+0x7],r10b
  4111ce:	vxorpd xmm1,xmm1,xmm1
  4111d2:	movzx  edx,dl
  4111d5:	vcvtsi2sd xmm1,xmm1,rdx
  4111da:	vsubsd xmm0,xmm0,xmm1
  4111de:	vmulsd xmm0,xmm0,xmm6
  4111e2:	vcvttsd2si rdx,xmm0
  4111e7:	mov    r10b,dl
  4111ea:	add    r10b,0x30
  4111ee:	mov    BYTE PTR [r9+0x8],r10b
  4111f2:	vxorpd xmm1,xmm1,xmm1
  4111f6:	movzx  edx,dl
  4111f9:	vcvtsi2sd xmm1,xmm1,rdx
  4111fe:	vsubsd xmm0,xmm0,xmm1
  411202:	vmulsd xmm0,xmm0,xmm6
  411206:	vcvttsd2si rdx,xmm0
  41120b:	mov    r10b,dl
  41120e:	add    r10b,0x30
  411212:	mov    BYTE PTR [r9+0x9],r10b
  411216:	vxorpd xmm1,xmm1,xmm1
  41121a:	movzx  edx,dl
  41121d:	vcvtsi2sd xmm1,xmm1,rdx
  411222:	vsubsd xmm0,xmm0,xmm1
  411226:	vmulsd xmm0,xmm0,xmm6
  41122a:	vcvttsd2si rdx,xmm0
  41122f:	mov    r10b,dl
  411232:	add    r10b,0x30
  411236:	mov    BYTE PTR [r9+0xa],r10b
  41123a:	vxorpd xmm1,xmm1,xmm1
  41123e:	movzx  edx,dl
  411241:	vcvtsi2sd xmm1,xmm1,rdx
  411246:	vsubsd xmm0,xmm0,xmm1
  41124a:	vmulsd xmm0,xmm0,xmm6
  41124e:	vcvttsd2si rdx,xmm0
  411253:	mov    r10b,dl
  411256:	add    r10b,0x30
  41125a:	mov    BYTE PTR [r9+0xb],r10b
  41125e:	lea    r10,[r9+0x4]
  411262:	vxorpd xmm1,xmm1,xmm1
  411266:	movzx  edx,dl
  411269:	vcvtsi2sd xmm1,xmm1,rdx
  41126e:	vsubsd xmm0,xmm0,xmm1
  411272:	vmulsd xmm0,xmm0,xmm6
  411276:	vcvttsd2si rdx,xmm0
  41127b:	mov    r11b,dl
  41127e:	add    r11b,0x30
  411282:	mov    BYTE PTR [r9+0xc],r11b
  411286:	vxorpd xmm1,xmm1,xmm1
  41128a:	movzx  edx,dl
  41128d:	vcvtsi2sd xmm1,xmm1,rdx
  411292:	vsubsd xmm0,xmm0,xmm1
  411296:	vmulsd xmm0,xmm0,xmm6
  41129a:	vcvttsd2si rdx,xmm0
  41129f:	mov    r11b,dl
  4112a2:	add    r11b,0x30
  4112a6:	mov    BYTE PTR [r9+0xd],r11b
  4112aa:	lea    r10,[r10+0x2]
  4112ae:	vxorpd xmm1,xmm1,xmm1
  4112b2:	movzx  edx,dl
  4112b5:	vcvtsi2sd xmm1,xmm1,rdx
  4112ba:	vsubsd xmm0,xmm0,xmm1
  4112be:	vmulsd xmm0,xmm0,xmm6
  4112c2:	vcvttsd2si rdx,xmm0
  4112c7:	mov    r11b,dl
  4112ca:	add    r11b,0x30
  4112ce:	mov    BYTE PTR [r9+0xe],r11b
  4112d2:	vxorpd xmm1,xmm1,xmm1
  4112d6:	movzx  edx,dl
  4112d9:	vcvtsi2sd xmm1,xmm1,rdx
  4112de:	vsubsd xmm0,xmm0,xmm1
  4112e2:	vmulsd xmm0,xmm0,xmm6
  4112e6:	vcvttsd2si rdx,xmm0
  4112eb:	mov    r11b,dl
  4112ee:	add    r11b,0x30
  4112f2:	mov    BYTE PTR [r9+0xf],r11b
  4112f6:	lea    r10,[r10+0x2]
  4112fa:	lea    r10,[r10+0x2]
  4112fe:	lea    r10,[r10+0x2]
  411302:	lea    r10,[r10+0x2]
  411306:	lea    r10,[r10+0x2]
  41130a:	vxorpd xmm1,xmm1,xmm1
  41130e:	movzx  edx,dl
  411311:	vcvtsi2sd xmm1,xmm1,rdx
  411316:	vsubsd xmm0,xmm0,xmm1
  41131a:	vmulsd xmm0,xmm0,xmm6
  41131e:	vcvttsd2si rdx,xmm0
  411323:	mov    r11b,dl
  411326:	add    r11b,0x30
  41132a:	mov    BYTE PTR [r9+0x10],r11b
  41132e:	vxorpd xmm1,xmm1,xmm1
  411332:	movzx  edx,dl
  411335:	vcvtsi2sd xmm1,xmm1,rdx
  41133a:	vsubsd xmm0,xmm0,xmm1
  41133e:	vmulsd xmm0,xmm0,xmm6
  411342:	vcvttsd2si rdx,xmm0
  411347:	add    dl,0x30
  41134a:	mov    BYTE PTR [r9+0x11],dl
  41134e:	mov    BYTE PTR [r10+0x2],0x65
  411353:	lea    r9,[r10+0x3]
  411357:	test   r8,r8
  41135a:	jl     411363 <__swc_fn_585f006d_000146_43f4fdca+0xd83>
  41135c:	mov    BYTE PTR [r9],0x2b
  411360:	inc    r9
  411363:	mov    r10,r9
  411366:	mov    rdx,r8
  411369:	nop    DWORD PTR [rax+0x0]
  411370:	mov    r11,rdx
  411373:	movabs rdx,0x6666666666666667
  41137d:	mov    rax,r11
  411380:	imul   rdx
  411383:	sar    rdx,0x2
  411387:	mov    r12,rdx
  41138a:	shr    rdx,0x3f
  41138e:	add    r12,rdx
  411391:	mov    rdx,r12
  411394:	imul   r13,r12,0xa
  411398:	sub    r11,r13
  41139b:	mov    r13,QWORD PTR [rip+0x119e]        # 412540 <__swc_rdata_base_585f006d+0x430>
  4113a2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4113a7:	mov    BYTE PTR [r10],r11b
  4113aa:	lea    r11,[r10+0x1]
  4113ae:	mov    r10,r11
  4113b1:	test   r12,r12
  4113b4:	jne    411370 <__swc_fn_585f006d_000146_43f4fdca+0xd90>
  4113b6:	test   r8,r8
  4113b9:	jge    4113c3 <__swc_fn_585f006d_000146_43f4fdca+0xde3>
  4113bb:	mov    BYTE PTR [r11],0x2d
  4113bf:	lea    r10,[r11+0x1]
  4113c3:	mov    BYTE PTR [r10],0x0
  4113c7:	sub    r10,0x1
  4113cb:	nop    DWORD PTR [rax+rax*1+0x0]
  4113d0:	cmp    r9,r10
  4113d3:	jae    411648 <__swc_fn_585f006d_000146_43f4fdca+0x1068>
  4113d9:	mov    al,BYTE PTR [r10]
  4113dc:	mov    dl,BYTE PTR [r9]
  4113df:	mov    BYTE PTR [r10],dl
  4113e2:	sub    r10,0x1
  4113e6:	mov    BYTE PTR [r9],al
  4113e9:	inc    r9
  4113ec:	jmp    4113d0 <__swc_fn_585f006d_000146_43f4fdca+0xdf0>
  4113ee:	vcvttsd2si rdx,xmm0
  4113f3:	mov    r8,rdx
  4113f6:	vxorpd xmm1,xmm1,xmm1
  4113fa:	vcvtsi2sd xmm1,xmm1,rdx
  4113ff:	vsubsd xmm1,xmm0,xmm1
  411403:	mov    r9d,0x8
  411409:	vxorpd xmm2,xmm2,xmm2
  41140d:	vcomisd xmm2,xmm1
  411411:	ja     41141e <__swc_fn_585f006d_000146_43f4fdca+0xe3e>
  411413:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41141c:	jmp    41142f <__swc_fn_585f006d_000146_43f4fdca+0xe4f>
  41141e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x112a]        # 412550 <__swc_rdata_base_585f006d+0x440>
  411426:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41142f:	test   r9d,r9d
  411432:	je     411449 <__swc_fn_585f006d_000146_43f4fdca+0xe69>
  411434:	cs nop WORD PTR [rax+rax*1+0x0]
  41143e:	xchg   ax,ax
  411440:	vmulsd xmm1,xmm1,xmm6
  411444:	dec    r9d
  411447:	jne    411440 <__swc_fn_585f006d_000146_43f4fdca+0xe60>
  411449:	vcvttsd2si r9,xmm1
  41144e:	mov    r10,r9
  411451:	vxorpd xmm2,xmm2,xmm2
  411455:	vcvtsi2sd xmm2,xmm2,r9
  41145a:	vsubsd xmm1,xmm1,xmm2
  41145e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  411467:	vcomisd xmm1,xmm6
  41146b:	lea    r9,[r9+0x1]
  41146f:	cmova  r10,r9
  411473:	cmp    r10,0x5f5e100
  41147a:	jne    411493 <__swc_fn_585f006d_000146_43f4fdca+0xeb3>
  41147c:	lea    r8,[rdx-0x1]
  411480:	vxorpd xmm1,xmm1,xmm1
  411484:	vcomisd xmm1,xmm0
  411488:	lea    rdx,[rdx+0x1]
  41148c:	cmovbe r8,rdx
  411490:	xor    r10d,r10d
  411493:	mov    r9,rcx
  411496:	test   r8,r8
  411499:	jne    4114b9 <__swc_fn_585f006d_000146_43f4fdca+0xed9>
  41149b:	vxorpd xmm1,xmm1,xmm1
  41149f:	vcomisd xmm1,xmm0
  4114a3:	jbe    4114ac <__swc_fn_585f006d_000146_43f4fdca+0xecc>
  4114a5:	mov    BYTE PTR [rcx],0x2d
  4114a8:	lea    r9,[rcx+0x1]
  4114ac:	mov    BYTE PTR [r9],0x30
  4114b0:	add    r9,0x1
  4114b4:	jmp    41154b <__swc_fn_585f006d_000146_43f4fdca+0xf6b>
  4114b9:	mov    r9,rcx
  4114bc:	mov    rdx,r8
  4114bf:	nop
  4114c0:	mov    r11,rdx
  4114c3:	movabs rdx,0x6666666666666667
  4114cd:	mov    r15,rax
  4114d0:	mov    rax,r11
  4114d3:	imul   rdx
  4114d6:	mov    r12,rdx
  4114d9:	mov    rax,r15
  4114dc:	sar    r12,0x2
  4114e0:	mov    rdx,r12
  4114e3:	shr    rdx,0x3f
  4114e7:	add    r12,rdx
  4114ea:	mov    rdx,r12
  4114ed:	imul   r13,r12,0xa
  4114f1:	sub    r11,r13
  4114f4:	mov    r13,QWORD PTR [rip+0x1045]        # 412540 <__swc_rdata_base_585f006d+0x430>
  4114fb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411500:	mov    BYTE PTR [r9],r11b
  411503:	lea    r11,[r9+0x1]
  411507:	mov    r9,r11
  41150a:	test   r12,r12
  41150d:	jne    4114c0 <__swc_fn_585f006d_000146_43f4fdca+0xee0>
  41150f:	test   r8,r8
  411512:	jge    41151c <__swc_fn_585f006d_000146_43f4fdca+0xf3c>
  411514:	mov    BYTE PTR [r11],0x2d
  411518:	lea    r9,[r11+0x1]
  41151c:	mov    rdx,r9
  41151f:	mov    BYTE PTR [r9],0x0
  411523:	sub    r9,0x1
  411527:	mov    r8,rcx
  41152a:	cmp    r8,r9
  41152d:	jae    411548 <__swc_fn_585f006d_000146_43f4fdca+0xf68>
  41152f:	nop
  411530:	mov    r11b,BYTE PTR [r9]
  411533:	mov    r12b,BYTE PTR [r8]
  411536:	mov    BYTE PTR [r9],r12b
  411539:	sub    r9,0x1
  41153d:	mov    BYTE PTR [r8],r11b
  411540:	inc    r8
  411543:	cmp    r8,r9
  411546:	jb     411530 <__swc_fn_585f006d_000146_43f4fdca+0xf50>
  411548:	mov    r9,rdx
  41154b:	mov    BYTE PTR [r9],0x2e
  41154f:	add    r9,0x1
  411553:	xor    r8d,r8d
  411556:	test   r10,r10
  411559:	je     41159f <__swc_fn_585f006d_000146_43f4fdca+0xfbf>
  41155b:	mov    r11d,0x989680
  411561:	cmp    r10,r11
  411564:	jge    41159f <__swc_fn_585f006d_000146_43f4fdca+0xfbf>
  411566:	cs nop WORD PTR [rax+rax*1+0x0]
  411570:	inc    r8d
  411573:	movabs rdx,0x6666666666666667
  41157d:	mov    r15,rax
  411580:	mov    rax,r11
  411583:	imul   rdx
  411586:	mov    r11,rdx
  411589:	mov    rax,r15
  41158c:	sar    r11,0x2
  411590:	mov    rdx,r11
  411593:	shr    rdx,0x3f
  411597:	add    r11,rdx
  41159a:	cmp    r10,r11
  41159d:	jl     411570 <__swc_fn_585f006d_000146_43f4fdca+0xf90>
  41159f:	test   r8d,r8d
  4115a2:	je     4115bd <__swc_fn_585f006d_000146_43f4fdca+0xfdd>
  4115a4:	cs nop WORD PTR [rax+rax*1+0x0]
  4115ae:	xchg   ax,ax
  4115b0:	mov    BYTE PTR [r9],0x30
  4115b4:	add    r9,0x1
  4115b8:	dec    r8d
  4115bb:	jne    4115b0 <__swc_fn_585f006d_000146_43f4fdca+0xfd0>
  4115bd:	mov    r8,r9
  4115c0:	mov    rdx,r10
  4115c3:	cs nop WORD PTR [rax+rax*1+0x0]
  4115cd:	nop    DWORD PTR [rax]
  4115d0:	mov    r11,rdx
  4115d3:	movabs rdx,0x6666666666666667
  4115dd:	mov    rax,r11
  4115e0:	imul   rdx
  4115e3:	sar    rdx,0x2
  4115e7:	mov    r12,rdx
  4115ea:	shr    rdx,0x3f
  4115ee:	add    r12,rdx
  4115f1:	mov    rdx,r12
  4115f4:	imul   r13,r12,0xa
  4115f8:	sub    r11,r13
  4115fb:	mov    r13,QWORD PTR [rip+0xf3e]        # 412540 <__swc_rdata_base_585f006d+0x430>
  411602:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411607:	mov    BYTE PTR [r8],r11b
  41160a:	lea    r11,[r8+0x1]
  41160e:	mov    r8,r11
  411611:	test   r12,r12
  411614:	jne    4115d0 <__swc_fn_585f006d_000146_43f4fdca+0xff0>
  411616:	test   r10,r10
  411619:	jge    411623 <__swc_fn_585f006d_000146_43f4fdca+0x1043>
  41161b:	mov    BYTE PTR [r11],0x2d
  41161f:	lea    r8,[r11+0x1]
  411623:	mov    BYTE PTR [r8],0x0
  411627:	sub    r8,0x1
  41162b:	cmp    r9,r8
  41162e:	jae    411648 <__swc_fn_585f006d_000146_43f4fdca+0x1068>
  411630:	mov    al,BYTE PTR [r8]
  411633:	mov    dl,BYTE PTR [r9]
  411636:	mov    BYTE PTR [r8],dl
  411639:	sub    r8,0x1
  41163d:	mov    BYTE PTR [r9],al
  411640:	inc    r9
  411643:	cmp    r9,r8
  411646:	jb     411630 <__swc_fn_585f006d_000146_43f4fdca+0x1050>
  411648:	xor    eax,eax
  41164a:	test   rcx,rcx
  41164d:	je     411670 <__swc_fn_585f006d_000146_43f4fdca+0x1090>
  41164f:	mov    rdx,rcx
  411652:	mov    r8b,BYTE PTR [rdx]
  411655:	test   r8b,r8b
  411658:	je     411670 <__swc_fn_585f006d_000146_43f4fdca+0x1090>
  41165a:	nop    WORD PTR [rax+rax*1+0x0]
  411660:	add    rdx,0x1
  411664:	add    rax,0x1
  411668:	mov    r8b,BYTE PTR [rdx]
  41166b:	test   r8b,r8b
  41166e:	jne    411660 <__swc_fn_585f006d_000146_43f4fdca+0x1080>
  411670:	mov    QWORD PTR [rsp+0x3f8],rcx
  411678:	mov    QWORD PTR [rsp+0x400],rax
  411680:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  411689:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  411692:	lea    rcx,[rsp+0x408]
  41169a:	call   40fd60 <__swc_fn_585f006d_000116_035d76a1>
  41169f:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  4116a1:	mov    rcx,rdx
  4116a4:	call   40fd60 <__swc_fn_585f006d_000116_035d76a1>
  4116a9:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  4116ab:	mov    al,BYTE PTR [rdx]
  4116ad:	test   al,al
  4116af:	je     4116ba <__swc_fn_585f006d_000146_43f4fdca+0x10da>
  4116b1:	lea    rax,[rip+0xea8]        # 412560 <__swc_rdata_base_585f006d+0x450>
  4116b8:	jmp    4116c1 <__swc_fn_585f006d_000146_43f4fdca+0x10e1>
  4116ba:	lea    rax,[rip+0xeaf]        # 412570 <__swc_rdata_base_585f006d+0x460>
  4116c1:	mov    rcx,rax
  4116c4:	call   40fd60 <__swc_fn_585f006d_000116_035d76a1>
  4116c9:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  4116cb:	lea    rcx,[rip+0xeae]        # 412580 <__swc_rdata_base_585f006d+0x470>
  4116d2:	call   40fd60 <__swc_fn_585f006d_000116_035d76a1>
  4116d7:	jmp    4116e5 <__swc_fn_585f006d_000146_43f4fdca+0x1105>
  4116d9:	lea    rcx,[rip+0xea0]        # 412580 <__swc_rdata_base_585f006d+0x470>
  4116e0:	call   40fd60 <__swc_fn_585f006d_000116_035d76a1>
  4116e5:	add    rdi,0x1
  4116e9:	sub    rsi,0x1
  4116ed:	vmovups xmm0,xmm12
  4116f2:	vmovsd xmm6,QWORD PTR [rip+0xe96]        # 412590 <__swc_rdata_base_585f006d+0x480>
  4116fa:	test   rsi,rsi
  4116fd:	jne    4106f0 <__swc_fn_585f006d_000146_43f4fdca+0x110>
  411703:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  41170c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411715:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  41171e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411727:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411730:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411739:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411742:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  41174b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411754:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  41175d:	add    rsp,0x4e8
  411764:	pop    r15
  411766:	pop    r13
  411768:	pop    r12
  41176a:	pop    rdi
  41176b:	pop    rsi
  41176c:	pop    rbx
  41176d:	ret
	...

0000000000411770 <__swc_fn_585f006d_000149_9e4bc402>:
  411770:	vxorps xmm0,xmm0,xmm0
  411774:	vmovups XMMWORD PTR [rcx],xmm0
  411778:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41177d:	ret
	...

0000000000411780 <__swc_fn_585f006d_000152_9e4bc402>:
  411780:	vxorps xmm0,xmm0,xmm0
  411784:	vmovups XMMWORD PTR [rcx],xmm0
  411788:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41178d:	vxorps xmm0,xmm0,xmm0
  411791:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411796:	vmovups xmm0,XMMWORD PTR [rip+0xf02]        # 4126a0 <__swc_rdata_base_585f006d+0x590>
  41179e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4117a3:	vxorps xmm0,xmm0,xmm0
  4117a7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  4117ac:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  4117b1:	vxorps xmm0,xmm0,xmm0
  4117b5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  4117ba:	mov    QWORD PTR [rcx+0x70],0x0
  4117c2:	ret
	...

00000000004117d0 <__swc_fn_585f006d_000155_9e4bc402>:
  4117d0:	vxorps xmm0,xmm0,xmm0
  4117d4:	vmovups XMMWORD PTR [rcx],xmm0
  4117d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4117dd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4117e2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4117e7:	ret
	...

00000000004117f0 <__swc_fn_585f006d_000158_b43b2f96>:
  4117f0:	push   rsi
  4117f1:	push   rdi
  4117f2:	sub    rsp,0x8
  4117f6:	mov    rsi,rcx
  4117f9:	mov    rdi,QWORD PTR [rsi+0x50]
  4117fd:	test   rdi,rdi
  411800:	je     411807 <__swc_fn_585f006d_000158_b43b2f96+0x17>
  411802:	mov    rcx,rsi
  411805:	call   rdi
  411807:	mov    QWORD PTR [rsi+0x20],0x0
  41180f:	mov    rax,QWORD PTR [rsi+0x30]
  411813:	test   rax,rax
  411816:	je     411844 <__swc_fn_585f006d_000158_b43b2f96+0x54>
  411818:	nop    DWORD PTR [rax+rax*1+0x0]
  411820:	mov    rdi,QWORD PTR [rax+0x8]
  411824:	mov    rcx,rsi
  411827:	mov    rdx,QWORD PTR [rax+0x10]
  41182b:	mov    rax,QWORD PTR [rax+0x18]
  41182f:	mov    r8,rax
  411832:	call   409ec0 <__swc_fn_585f006d_000156_2745c4a5>
  411837:	mov    QWORD PTR [rsi+0x30],rdi
  41183b:	mov    rax,QWORD PTR [rsi+0x30]
  41183f:	test   rax,rax
  411842:	jne    411820 <__swc_fn_585f006d_000158_b43b2f96+0x30>
  411844:	mov    QWORD PTR [rsi+0x38],0x0
  41184c:	add    rsp,0x8
  411850:	pop    rdi
  411851:	pop    rsi
  411852:	ret
	...

0000000000411860 <__swc_fn_585f006d_000161_b5a9d657>:
  411860:	push   rbx
  411861:	push   rsi
  411862:	push   rdi
  411863:	push   r12
  411865:	sub    rsp,0x188
  41186c:	mov    rbx,rcx
  41186f:	lea    rsi,[rip+0x1451a]        # 425d90 <__swc_bss_base_585f006d+0x2d50>
  411876:	mov    rcx,rsi
  411879:	call   4098c0 <__swc_fn_585f006d_000135_e3032dc2>
  41187e:	mov    rax,QWORD PTR [rip+0x14513]        # 425d98 <__swc_bss_base_585f006d+0x2d58>
  411885:	mov    rdi,rax
  411888:	test   rdi,rdi
  41188b:	je     4118b9 <__swc_fn_585f006d_000161_b5a9d657+0x59>
  41188d:	nop    DWORD PTR [rax]
  411890:	cmp    QWORD PTR [rdi+0x8],rbx
  411894:	jne    4118ae <__swc_fn_585f006d_000161_b5a9d657+0x4e>
  411896:	mov    rcx,rsi
  411899:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  41189e:	mov    rax,rdi
  4118a1:	add    rsp,0x188
  4118a8:	pop    r12
  4118aa:	pop    rdi
  4118ab:	pop    rsi
  4118ac:	pop    rbx
  4118ad:	ret
  4118ae:	mov    rax,QWORD PTR [rdi]
  4118b1:	mov    rdi,rax
  4118b4:	test   rax,rax
  4118b7:	jne    411890 <__swc_fn_585f006d_000161_b5a9d657+0x30>
  4118b9:	call   40cea0 <__swc_fn_585f006d_000139_7c02fe26>
  4118be:	mov    rdi,rax
  4118c1:	test   rax,rax
  4118c4:	jne    4118dd <__swc_fn_585f006d_000161_b5a9d657+0x7d>
  4118c6:	mov    rcx,rsi
  4118c9:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  4118ce:	xor    eax,eax
  4118d0:	add    rsp,0x188
  4118d7:	pop    r12
  4118d9:	pop    rdi
  4118da:	pop    rsi
  4118db:	pop    rbx
  4118dc:	ret
  4118dd:	lea    rax,[rsp+0x18]
  4118e2:	mov    QWORD PTR [rax+0x10],0x0
  4118ea:	mov    QWORD PTR [rax+0x18],0x0
  4118f2:	mov    DWORD PTR [rax+0x20],0x0
  4118f9:	mov    BYTE PTR [rax+0x24],0x0
  4118fd:	mov    rax,QWORD PTR [rip+0x14494]        # 425d98 <__swc_bss_base_585f006d+0x2d58>
  411904:	mov    QWORD PTR [rsp+0x18],rax
  411909:	mov    QWORD PTR [rsp+0x20],rbx
  41190e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411914:	vmovups XMMWORD PTR [rdi],xmm0
  411918:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  41191e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411923:	mov    rax,QWORD PTR [rsp+0x38]
  411928:	mov    QWORD PTR [rdi+0x20],rax
  41192c:	mov    QWORD PTR [rip+0x14465],rdi        # 425d98 <__swc_bss_base_585f006d+0x2d58>
  411933:	lea    rax,[rsp+0x40]
  411938:	mov    QWORD PTR [rax],0x0
  41193f:	mov    rcx,rbx
  411942:	mov    rdx,rax
  411945:	call   4099a0 <__swc_fn_585f006d_000141_2ce79e3b>
  41194a:	mov    rbx,rax
  41194d:	test   rax,rax
  411950:	jne    41196a <__swc_fn_585f006d_000161_b5a9d657+0x10a>
  411952:	mov    rcx,rsi
  411955:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  41195a:	mov    rax,rdi
  41195d:	add    rsp,0x188
  411964:	pop    r12
  411966:	pop    rdi
  411967:	pop    rsi
  411968:	pop    rbx
  411969:	ret
  41196a:	lea    r12,[rsp+0x50]
  41196f:	mov    QWORD PTR [r12],0x0
  411977:	mov    rcx,rbx
  41197a:	mov    rdx,QWORD PTR [rsp+0x40]
  41197f:	mov    r8,r12
  411982:	call   40cf50 <__swc_fn_585f006d_000142_56e56812>
  411987:	test   rax,rax
  41198a:	jne    4119a4 <__swc_fn_585f006d_000161_b5a9d657+0x144>
  41198c:	mov    rcx,rsi
  41198f:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  411994:	mov    rax,rdi
  411997:	add    rsp,0x188
  41199e:	pop    r12
  4119a0:	pop    rdi
  4119a1:	pop    rsi
  4119a2:	pop    rbx
  4119a3:	ret
  4119a4:	cmp    QWORD PTR [r12],0x10
  4119a9:	jb     411aac <__swc_fn_585f006d_000161_b5a9d657+0x24c>
  4119af:	mov    ecx,DWORD PTR [rax]
  4119b1:	cmp    ecx,0x42445753
  4119b7:	jne    411aac <__swc_fn_585f006d_000161_b5a9d657+0x24c>
  4119bd:	mov    ecx,DWORD PTR [rax+0x4]
  4119c0:	cmp    ecx,0x1
  4119c3:	jne    411aac <__swc_fn_585f006d_000161_b5a9d657+0x24c>
  4119c9:	mov    ecx,DWORD PTR [rax+0x8]
  4119cc:	mov    edx,DWORD PTR [rax+0xc]
  4119cf:	imul   r8,rcx,0x14
  4119d3:	mov    r9,QWORD PTR [rsp+0x50]
  4119d8:	sub    r9,0x10
  4119dc:	cmp    r8,r9
  4119df:	ja     411aac <__swc_fn_585f006d_000161_b5a9d657+0x24c>
  4119e5:	lea    r8,[r8+0x10]
  4119e9:	cmp    rdx,r8
  4119ec:	jb     411aac <__swc_fn_585f006d_000161_b5a9d657+0x24c>
  4119f2:	mov    r8,QWORD PTR [rsp+0x50]
  4119f7:	cmp    rdx,r8
  4119fa:	ja     411aac <__swc_fn_585f006d_000161_b5a9d657+0x24c>
  411a00:	xor    r8d,r8d
  411a03:	test   rcx,rcx
  411a06:	jbe    411ad2 <__swc_fn_585f006d_000161_b5a9d657+0x272>
  411a0c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411a12:	cs nop WORD PTR [rax+rax*1+0x0]
  411a1c:	nop    DWORD PTR [rax+0x0]
  411a20:	imul   r9,r8,0x14
  411a24:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411a29:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  411a2e:	add    r10,r11
  411a31:	movabs r11,0x100000000
  411a3b:	cmp    r10,r11
  411a3e:	ja     411aac <__swc_fn_585f006d_000161_b5a9d657+0x24c>
  411a40:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411a45:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  411a4a:	test   r10d,r10d
  411a4d:	setne  r11b
  411a51:	je     411a6b <__swc_fn_585f006d_000161_b5a9d657+0x20b>
  411a53:	cmp    r10d,edx
  411a56:	setb   r11b
  411a5a:	jb     411a6b <__swc_fn_585f006d_000161_b5a9d657+0x20b>
  411a5c:	vmovq  r11,xmm1
  411a61:	cmp    r10,r11
  411a64:	setae  r10b
  411a68:	mov    r11b,r10b
  411a6b:	mov    r10,r11
  411a6e:	test   r11b,r11b
  411a71:	jne    411a98 <__swc_fn_585f006d_000161_b5a9d657+0x238>
  411a73:	test   r9d,r9d
  411a76:	setne  r10b
  411a7a:	je     411a98 <__swc_fn_585f006d_000161_b5a9d657+0x238>
  411a7c:	cmp    r9d,edx
  411a7f:	setb   r10b
  411a83:	jb     411a98 <__swc_fn_585f006d_000161_b5a9d657+0x238>
  411a85:	vmovq  r10,xmm1
  411a8a:	cmp    r9,r10
  411a8d:	setae  r9b
  411a91:	movzx  r9d,r9b
  411a95:	mov    r10b,r9b
  411a98:	test   r10b,r10b
  411a9b:	jne    411aac <__swc_fn_585f006d_000161_b5a9d657+0x24c>
  411a9d:	add    r8,0x1
  411aa1:	cmp    r8,rcx
  411aa4:	jb     411a20 <__swc_fn_585f006d_000161_b5a9d657+0x1c0>
  411aaa:	jmp    411ad2 <__swc_fn_585f006d_000161_b5a9d657+0x272>
  411aac:	xor    ecx,ecx
  411aae:	cmp    rax,rbx
  411ab1:	cmovne rcx,rax
  411ab5:	call   410530 <__swc_fn_585f006d_000143_81c0d993>
  411aba:	mov    rcx,rsi
  411abd:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  411ac2:	mov    rax,rdi
  411ac5:	add    rsp,0x188
  411acc:	pop    r12
  411ace:	pop    rdi
  411acf:	pop    rsi
  411ad0:	pop    rbx
  411ad1:	ret
  411ad2:	mov    QWORD PTR [rdi+0x10],rax
  411ad6:	mov    rcx,QWORD PTR [rsp+0x50]
  411adb:	mov    QWORD PTR [rdi+0x18],rcx
  411adf:	mov    eax,DWORD PTR [rax+0x8]
  411ae2:	mov    DWORD PTR [rdi+0x20],eax
  411ae5:	rex mov BYTE PTR [rdi+0x24],0x1
  411aea:	mov    rcx,rsi
  411aed:	call   40ce90 <__swc_fn_585f006d_000136_3e875c27>
  411af2:	mov    rax,rdi
  411af5:	add    rsp,0x188
  411afc:	pop    r12
  411afe:	pop    rdi
  411aff:	pop    rsi
  411b00:	pop    rbx
  411b01:	ret
	...

0000000000411b10 <__swc_fn_585f006d_000164_1962e12a>:
  411b10:	push   rsi
  411b11:	push   rdi
  411b12:	push   r12
  411b14:	mov    rsi,rdx
  411b17:	mov    rdi,rcx
  411b1a:	mov    rcx,QWORD PTR [rip+0x1421f]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  411b21:	test   rcx,rcx
  411b24:	jne    411b36 <__swc_fn_585f006d_000164_1962e12a+0x26>
  411b26:	call   40a1d0 <__swc_fn_585f006d_000165_cf398896>
  411b2b:	lea    rcx,[rax+0x1]
  411b2f:	mov    QWORD PTR [rip+0x1420a],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  411b36:	dec    rcx
  411b39:	call   411b60 <__swc_fn_585f006d_000167_fce60b2b>
  411b3e:	mov    r12,QWORD PTR [rax+0xbe0]
  411b45:	test   r12,r12
  411b48:	setne  al
  411b4b:	je     411b56 <__swc_fn_585f006d_000164_1962e12a+0x46>
  411b4d:	mov    rcx,rdi
  411b50:	mov    rdx,rsi
  411b53:	call   r12
  411b56:	pop    r12
  411b58:	pop    rdi
  411b59:	pop    rsi
  411b5a:	ret
  411b5b:	add    BYTE PTR [rax],al
  411b5d:	add    BYTE PTR [rax],al
	...

0000000000411b60 <__swc_fn_585f006d_000167_fce60b2b>:
  411b60:	push   r12
  411b62:	push   rdi
  411b63:	push   rsi
  411b64:	sub    rsp,0xd0
  411b6b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411b71:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411b77:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  411b7d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  411b83:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  411b89:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  411b8f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411b98:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  411ba1:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  411baa:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  411bb3:	mov    r12,rcx
  411bb6:	mov    edi,ecx
  411bb8:	xor    eax,eax
  411bba:	call   407000 <pthread_getspecific@plt>
  411bbf:	test   rax,rax
  411bc2:	je     411bc6 <__swc_fn_585f006d_000167_fce60b2b+0x66>
  411bc4:	jmp    411bce <__swc_fn_585f006d_000167_fce60b2b+0x6e>
  411bc6:	mov    rcx,r12
  411bc9:	call   40a230 <__swc_fn_585f006d_000168_92b7d63c>
  411bce:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  411bd4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  411bda:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411be0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411be6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  411bec:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411bf2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  411bfb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411c04:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  411c0d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411c16:	add    rsp,0xd0
  411c1d:	pop    rsi
  411c1e:	pop    rdi
  411c1f:	pop    r12
  411c21:	ret
	...

0000000000411c30 <__swc_fn_585f006d_000170_fa3003e2>:
  411c30:	push   rsi
  411c31:	sub    rsp,0x30
  411c35:	lea    rsi,[rip+0x1416c]        # 425da8 <__swc_bss_base_585f006d+0x2d68>
  411c3c:	mov    rax,QWORD PTR [rsi]
  411c3f:	test   rax,rax
  411c42:	je     411c4a <__swc_fn_585f006d_000170_fa3003e2+0x1a>
  411c44:	add    rsp,0x30
  411c48:	pop    rsi
  411c49:	ret
  411c4a:	mov    ecx,0x3
  411c4f:	mov    edx,0x10
  411c54:	call   40f660 <__swc_fn_585f006d_000107_4796e893>
  411c59:	test   rax,rax
  411c5c:	jne    411c6d <__swc_fn_585f006d_000170_fa3003e2+0x3d>
  411c5e:	mov    QWORD PTR [rsp+0x18],rax
  411c63:	call   40c9f0 <__swc_fn_585f006d_000118_7f430081>
  411c68:	mov    rax,QWORD PTR [rsp+0x18]
  411c6d:	mov    rcx,rax
  411c70:	xchg   QWORD PTR [rsi],rcx
  411c73:	add    rsp,0x30
  411c77:	pop    rsi
  411c78:	ret
  411c79:	add    BYTE PTR [rax],al
  411c7b:	add    BYTE PTR [rax],al
  411c7d:	add    BYTE PTR [rax],al
	...

0000000000411c80 <__swc_fn_585f006d_000173_f69b1f05>:
  411c80:	push   rsi
  411c81:	push   rdi
  411c82:	sub    rsp,0x8
  411c86:	mov    rsi,rdx
  411c89:	mov    rdi,rcx
  411c8c:	mov    rax,QWORD PTR [rsi+0x8]
  411c90:	test   rax,rax
  411c93:	je     411c9d <__swc_fn_585f006d_000173_f69b1f05+0x1d>
  411c95:	mov    rcx,QWORD PTR [rsi]
  411c98:	mov    QWORD PTR [rax],rcx
  411c9b:	jmp    411ca4 <__swc_fn_585f006d_000173_f69b1f05+0x24>
  411c9d:	mov    rax,QWORD PTR [rsi]
  411ca0:	mov    QWORD PTR [rdi+0x8],rax
  411ca4:	mov    rax,QWORD PTR [rsi]
  411ca7:	test   rax,rax
  411caa:	je     411cb4 <__swc_fn_585f006d_000173_f69b1f05+0x34>
  411cac:	mov    rcx,QWORD PTR [rsi+0x8]
  411cb0:	mov    QWORD PTR [rax+0x8],rcx
  411cb4:	mov    rcx,rdi
  411cb7:	mov    rdx,QWORD PTR [rsi+0x10]
  411cbb:	mov    r8,QWORD PTR [rsi+0x18]
  411cbf:	mov    r9,0xffffffffffffffff
  411cc6:	call   40d5c0 <__swc_fn_585f006d_000172_97fbc432>
  411ccb:	mov    QWORD PTR [rsi+0x18],0x0
  411cd3:	mov    rax,QWORD PTR [rdi+0x8]
  411cd7:	test   rax,rax
  411cda:	jne    411cec <__swc_fn_585f006d_000173_f69b1f05+0x6c>
  411cdc:	call   411c30 <__swc_fn_585f006d_000170_fa3003e2>
  411ce1:	xor    ecx,ecx
  411ce3:	mov    QWORD PTR [rax+0x8],rcx
  411ce7:	xor    ecx,ecx
  411ce9:	mov    QWORD PTR [rax],rcx
  411cec:	add    rsp,0x8
  411cf0:	pop    rdi
  411cf1:	pop    rsi
  411cf2:	ret
	...

0000000000411d00 <__swc_fn_585f006d_000176_5d3d19bd>:
  411d00:	push   rbx
  411d01:	sub    rsp,0x70
  411d05:	test   rcx,rcx
  411d08:	jne    411d10 <__swc_fn_585f006d_000176_5d3d19bd+0x10>
  411d0a:	add    rsp,0x70
  411d0e:	pop    rbx
  411d0f:	ret
  411d10:	lea    rbx,[rsp+0x8]
  411d15:	vxorps xmm0,xmm0,xmm0
  411d19:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411d1f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  411d25:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  411d2b:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  411d31:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  411d37:	lea    rax,[rcx-0x10]
  411d3b:	mov    QWORD PTR [rsp+0x48],rax
  411d40:	mov    rax,QWORD PTR [rcx-0x10]
  411d44:	mov    QWORD PTR [rsp+0x50],rax
  411d49:	mov    rcx,QWORD PTR [rip+0x13ff0]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  411d50:	test   rcx,rcx
  411d53:	jne    411d65 <__swc_fn_585f006d_000176_5d3d19bd+0x65>
  411d55:	call   40a1d0 <__swc_fn_585f006d_000165_cf398896>
  411d5a:	lea    rcx,[rax+0x1]
  411d5e:	mov    QWORD PTR [rip+0x13fdb],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  411d65:	dec    rcx
  411d68:	call   411b60 <__swc_fn_585f006d_000167_fce60b2b>
  411d6d:	mov    rcx,QWORD PTR [rax]
  411d70:	mov    rdx,rbx
  411d73:	mov    rbx,QWORD PTR [rax+0x8]
  411d77:	mov    rbx,QWORD PTR [rbx+0x18]
  411d7b:	call   rbx
  411d7d:	add    rsp,0x70
  411d81:	pop    rbx
  411d82:	ret
