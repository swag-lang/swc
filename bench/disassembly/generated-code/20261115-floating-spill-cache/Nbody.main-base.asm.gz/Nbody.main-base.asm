
/workspace/prompt2-20261115/batch3-final-micro/base/nbody/nbody:     file format elf64-x86-64


Disassembly of section .text:

00000000004118e0 <__swc_fn_6b1cf01f_000176_0ce64436>:
  4118e0:	push   rbp
  4118e1:	push   rbx
  4118e2:	push   rsi
  4118e3:	sub    rsp,0xa8
  4118ea:	mov    rbp,rsp
  4118ed:	vmovups XMMWORD PTR [rsp],xmm6
  4118f2:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  4118f8:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  4118fe:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  411904:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  41190a:	vmovups XMMWORD PTR [rsp+0x50],xmm11
  411910:	vmovups XMMWORD PTR [rsp+0x60],xmm12
  411916:	vmovups XMMWORD PTR [rsp+0x70],xmm13
  41191c:	vmovups XMMWORD PTR [rsp+0x80],xmm14
  411925:	vmovups XMMWORD PTR [rsp+0x90],xmm15
  41192e:	sub    rsp,0x510
  411935:	mov    rbx,rsp
  411938:	lea    rax,[rip+0x1fd9]        # 413918 <__swc_rdata_base_6b1cf01f+0x808>
  41193f:	xor    ecx,ecx
  411941:	cs nop WORD PTR [rax+rax*1+0x0]
  41194b:	cs nop WORD PTR [rax+rax*1+0x0]
  411955:	cs nop WORD PTR [rax+rax*1+0x0]
  41195f:	nop
  411960:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  411965:	vmovdqu XMMWORD PTR [rbx+rcx*1],xmm0
  41196a:	add    rcx,0x10
  41196e:	cmp    rcx,0x110
  411975:	jne    411960 <__swc_fn_6b1cf01f_000176_0ce64436+0x80>
  411977:	mov    DWORD PTR [rbx+0x110],0x531799ac
  411981:	mov    DWORD PTR [rbx+0x114],0x3f60a8f3
  41198b:	sub    rsp,0x8
  41198f:	call   40d590 <__swc_fn_6b1cf01f_000175_1ca87929>
  411994:	add    rsp,0x8
  411998:	vmovsd QWORD PTR [rsp+0x2d0],xmm0
  4119a1:	vxorpd xmm0,xmm0,xmm0
  4119a5:	vmovups xmm2,xmm0
  4119a9:	mov    rax,rbx
  4119ac:	vmovsd xmm3,QWORD PTR [rbx+0x18]
  4119b1:	vmovsd xmm4,QWORD PTR [rbx+0x30]
  4119b6:	vmulsd xmm3,xmm3,xmm4
  4119ba:	vaddsd xmm1,xmm0,xmm3
  4119be:	vmovsd xmm3,QWORD PTR [rbx+0x20]
  4119c3:	vfmadd231sd xmm2,xmm3,xmm4
  4119c8:	vmovsd xmm3,QWORD PTR [rbx+0x28]
  4119cd:	vfmadd231sd xmm0,xmm3,xmm4
  4119d2:	add    rax,0x38
  4119d6:	vmovsd xmm3,QWORD PTR [rax+0x18]
  4119db:	vmovsd xmm4,QWORD PTR [rax+0x30]
  4119e0:	vfmadd231sd xmm1,xmm3,xmm4
  4119e5:	vmovsd xmm3,QWORD PTR [rax+0x20]
  4119ea:	vfmadd231sd xmm2,xmm3,xmm4
  4119ef:	vmovsd xmm3,QWORD PTR [rax+0x28]
  4119f4:	vfmadd231sd xmm0,xmm3,xmm4
  4119f9:	vmovsd xmm3,QWORD PTR [rax+0x50]
  4119fe:	vmovsd xmm4,QWORD PTR [rax+0x68]
  411a03:	vfmadd231sd xmm1,xmm3,xmm4
  411a08:	vmovsd xmm3,QWORD PTR [rax+0x58]
  411a0d:	vfmadd231sd xmm2,xmm3,xmm4
  411a12:	vmovsd xmm3,QWORD PTR [rax+0x60]
  411a17:	vfmadd231sd xmm0,xmm3,xmm4
  411a1c:	vmovsd xmm3,QWORD PTR [rax+0x88]
  411a24:	vmovsd xmm4,QWORD PTR [rax+0xa0]
  411a2c:	vfmadd231sd xmm1,xmm3,xmm4
  411a31:	vmovsd xmm3,QWORD PTR [rax+0x90]
  411a39:	vfmadd231sd xmm2,xmm3,xmm4
  411a3e:	vmovsd xmm3,QWORD PTR [rax+0x98]
  411a46:	vfmadd231sd xmm0,xmm3,xmm4
  411a4b:	vmovsd xmm3,QWORD PTR [rax+0xc0]
  411a53:	vmovsd xmm4,QWORD PTR [rax+0xd8]
  411a5b:	vfmadd231sd xmm1,xmm3,xmm4
  411a60:	vmovsd xmm3,QWORD PTR [rax+0xc8]
  411a68:	vfmadd231sd xmm2,xmm3,xmm4
  411a6d:	vmovsd xmm3,QWORD PTR [rax+0xd0]
  411a75:	vfmadd231sd xmm0,xmm3,xmm4
  411a7a:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1ace]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  411a82:	vmovsd xmm3,QWORD PTR [rip+0x2056]        # 413ae0 <__swc_rdata_base_6b1cf01f+0x9d0>
  411a8a:	vdivsd xmm1,xmm1,xmm3
  411a8e:	vmovsd QWORD PTR [rbx+0x18],xmm1
  411a93:	vxorpd xmm2,xmm2,XMMWORD PTR [rip+0x1ab5]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  411a9b:	vdivsd xmm1,xmm2,xmm3
  411a9f:	vmovsd QWORD PTR [rbx+0x20],xmm1
  411aa4:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x1aa4]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  411aac:	vdivsd xmm0,xmm0,xmm3
  411ab0:	vmovsd QWORD PTR [rbx+0x28],xmm0
  411ab5:	xor    eax,eax
  411ab7:	vmovsd xmm0,QWORD PTR [rip+0x202a]        # 413ae9 <__swc_rdata_base_6b1cf01f+0x9d9>
  411abf:	vpshufd xmm1,xmm0,0x44
  411ac4:	vmovups XMMWORD PTR [rsp+0x2e0],xmm1
  411acd:	vpunpcklqdq xmm2,xmm0,xmm0
  411ad1:	vmovups XMMWORD PTR [rsp+0x2f0],xmm2
  411ada:	vmovdqu xmm3,XMMWORD PTR [rsp]
  411adf:	vmovdqu xmm4,XMMWORD PTR [rsp+0x18]
  411ae5:	vmovdqu xmm5,XMMWORD PTR [rsp+0x38]
  411aeb:	vmovups XMMWORD PTR [rsp+0x320],xmm5
  411af4:	vmovdqu xmm7,XMMWORD PTR [rsp+0x50]
  411afa:	vmovdqu xmm8,XMMWORD PTR [rsp+0x70]
  411b00:	vmovups XMMWORD PTR [rsp+0x340],xmm8
  411b09:	vmovdqu xmm9,XMMWORD PTR [rsp+0x88]
  411b12:	vmovdqu xmm10,XMMWORD PTR [rsp+0xa8]
  411b1b:	vmovups XMMWORD PTR [rsp+0x350],xmm10
  411b24:	vmovdqu xmm11,XMMWORD PTR [rsp+0xc0]
  411b2d:	vmovdqu xmm12,XMMWORD PTR [rsp+0xe0]
  411b36:	vmovups XMMWORD PTR [rsp+0x360],xmm11
  411b3f:	vmovups XMMWORD PTR [rsp+0x370],xmm12
  411b48:	vmovdqu xmm13,XMMWORD PTR [rsp+0xf8]
  411b51:	mov    rcx,QWORD PTR [rsp+0x68]
  411b56:	mov    rdx,QWORD PTR [rsp+0x30]
  411b5b:	mov    r8,QWORD PTR [rsp+0xa0]
  411b63:	mov    r9,QWORD PTR [rsp+0xd8]
  411b6b:	mov    r10,QWORD PTR [rsp+0x110]
  411b73:	jmp    411bd4 <__swc_fn_6b1cf01f_000176_0ce64436+0x2f4>
  411b75:	cs nop WORD PTR [rax+rax*1+0x0]
  411b7f:	cs nop WORD PTR [rax+rax*1+0x0]
  411b89:	nop    DWORD PTR [rax+0x0]
  411b90:	vmovups xmm2,XMMWORD PTR [rsp+0x2f0]
  411b99:	vmovups xmm4,XMMWORD PTR [rsp+0x310]
  411ba2:	vmovups xmm5,XMMWORD PTR [rsp+0x320]
  411bab:	vmovups xmm10,xmm13
  411bb0:	vmovups XMMWORD PTR [rsp+0x360],xmm7
  411bb9:	vmovups xmm12,xmm11
  411bbe:	vmovups xmm13,xmm3
  411bc2:	vmovups xmm3,XMMWORD PTR [rsp+0x300]
  411bcb:	vmovups xmm7,XMMWORD PTR [rsp+0x330]
  411bd4:	vsubpd xmm14,xmm3,xmm5
  411bd8:	vpsrldq xmm6,xmm14,0x8
  411bde:	vmovsd xmm15,QWORD PTR [rbx+0x10]
  411be3:	vmovsd QWORD PTR [rsp+0x390],xmm15
  411bec:	vmovsd xmm0,QWORD PTR [rbx+0x48]
  411bf1:	vmovsd QWORD PTR [rsp+0x398],xmm0
  411bfa:	vsubsd xmm5,xmm15,xmm0
  411bfe:	vmulsd xmm0,xmm14,xmm14
  411c03:	vfmadd231sd xmm0,xmm6,xmm6
  411c08:	vfmadd231sd xmm0,xmm5,xmm5
  411c0d:	vsubpd xmm6,xmm3,xmm8
  411c12:	vmulsd xmm8,xmm6,xmm6
  411c16:	vmovups XMMWORD PTR [rsp+0x380],xmm13
  411c1f:	vpsrldq xmm13,xmm6,0x8
  411c24:	vfmadd231sd xmm8,xmm13,xmm13
  411c29:	vmovsd xmm13,QWORD PTR [rbx+0x80]
  411c31:	vmovsd QWORD PTR [rsp+0x3a0],xmm13
  411c3a:	vsubsd xmm1,xmm15,xmm13
  411c3f:	vfmadd231sd xmm8,xmm1,xmm1
  411c44:	vpunpcklqdq xmm0,xmm0,xmm8
  411c49:	vsqrtpd xmm8,xmm0
  411c4d:	vmulpd xmm0,xmm0,xmm8
  411c52:	vdivpd xmm0,xmm2,xmm0
  411c56:	vpshufd xmm8,xmm0,0x44
  411c5b:	vmovq  xmm13,rcx
  411c60:	vpshufd xmm13,xmm13,0x44
  411c66:	vmulpd xmm11,xmm14,xmm13
  411c6b:	vmovups XMMWORD PTR [rsp+0x3b0],xmm13
  411c74:	vmovq  xmm13,rcx
  411c79:	vmovsd QWORD PTR [rsp+0x3c0],xmm13
  411c82:	vfnmadd231pd xmm4,xmm11,xmm8
  411c87:	vmulsd xmm11,xmm5,xmm13
  411c8c:	vfnmadd213sd xmm11,xmm0,QWORD PTR [rbx+0x28]
  411c92:	vmovq  xmm13,rdx
  411c97:	vpshufd xmm13,xmm13,0x44
  411c9d:	vmulpd xmm14,xmm14,xmm13
  411ca2:	vmulpd xmm8,xmm14,xmm8
  411ca7:	vmovq  xmm14,rdx
  411cac:	vaddpd xmm7,xmm7,xmm8
  411cb1:	vmovups XMMWORD PTR [rsp+0x3d0],xmm7
  411cba:	vmulsd xmm5,xmm5,xmm14
  411cbf:	vfmadd213sd xmm5,xmm0,QWORD PTR [rbx+0x60]
  411cc5:	vmovsd QWORD PTR [rsp+0x3e0],xmm5
  411cce:	vmulpd xmm8,xmm6,xmm13
  411cd3:	vpsrldq xmm0,xmm0,0x8
  411cd8:	vpshufd xmm5,xmm0,0x44
  411cdd:	vmulpd xmm8,xmm8,xmm5
  411ce1:	vmovq  xmm2,r8
  411ce6:	vpshufd xmm2,xmm2,0x44
  411ceb:	vmulpd xmm6,xmm6,xmm2
  411cef:	vfnmadd231pd xmm4,xmm6,xmm5
  411cf4:	vmovq  xmm5,r8
  411cf9:	vmovsd QWORD PTR [rsp+0x400],xmm5
  411d02:	vmulsd xmm6,xmm1,xmm5
  411d06:	vfnmadd213sd xmm6,xmm0,xmm11
  411d0b:	vaddpd xmm8,xmm9,xmm8
  411d10:	vmovups XMMWORD PTR [rsp+0x410],xmm8
  411d19:	vmulsd xmm1,xmm1,xmm14
  411d1e:	vmulsd xmm0,xmm1,xmm0
  411d22:	vaddsd xmm0,xmm0,QWORD PTR [rbx+0x98]
  411d2a:	vmovsd QWORD PTR [rsp+0x420],xmm0
  411d33:	vsubpd xmm1,xmm3,xmm10
  411d38:	vmulpd xmm9,xmm1,xmm13
  411d3d:	vpsrldq xmm0,xmm1,0x8
  411d42:	vmovsd xmm11,QWORD PTR [rbx+0xb8]
  411d4a:	vmovsd QWORD PTR [rsp+0x428],xmm11
  411d53:	vsubsd xmm5,xmm15,xmm11
  411d58:	vmulsd xmm8,xmm1,xmm1
  411d5c:	vfmadd213sd xmm0,xmm0,xmm8
  411d61:	vfmadd231sd xmm0,xmm5,xmm5
  411d66:	vsubpd xmm8,xmm3,xmm12
  411d6b:	vmulsd xmm12,xmm8,xmm8
  411d70:	vpsrldq xmm7,xmm8,0x8
  411d76:	vmulsd xmm7,xmm7,xmm7
  411d7a:	vaddsd xmm7,xmm12,xmm7
  411d7e:	vmovsd xmm12,QWORD PTR [rbx+0xf0]
  411d86:	vmovsd QWORD PTR [rsp+0x430],xmm12
  411d8f:	vsubsd xmm11,xmm15,xmm12
  411d94:	vfmadd231sd xmm7,xmm11,xmm11
  411d99:	vpunpcklqdq xmm0,xmm0,xmm7
  411d9d:	vsqrtpd xmm7,xmm0
  411da1:	vmulpd xmm0,xmm0,xmm7
  411da5:	vmovups xmm15,XMMWORD PTR [rsp+0x2f0]
  411dae:	vdivpd xmm0,xmm15,xmm0
  411db2:	vpshufd xmm7,xmm0,0x44
  411db7:	vmulpd xmm9,xmm9,xmm7
  411dbb:	vmovq  xmm12,r9
  411dc0:	vpshufd xmm12,xmm12,0x44
  411dc6:	vmulpd xmm1,xmm1,xmm12
  411dcb:	vfnmadd213pd xmm1,xmm7,xmm4
  411dd0:	vmovq  xmm7,r9
  411dd5:	vmovsd QWORD PTR [rsp+0x450],xmm7
  411dde:	vmulsd xmm4,xmm5,xmm7
  411de2:	vfnmadd231sd xmm6,xmm4,xmm0
  411de7:	vaddpd xmm9,xmm9,XMMWORD PTR [rsp+0x360]
  411df0:	vmulsd xmm4,xmm5,xmm14
  411df5:	vmovsd xmm5,QWORD PTR [rbx+0xd0]
  411dfd:	vfmadd231sd xmm5,xmm4,xmm0
  411e02:	vmovsd QWORD PTR [rsp+0x458],xmm5
  411e0b:	vmulpd xmm4,xmm8,xmm13
  411e10:	vpsrldq xmm0,xmm0,0x8
  411e15:	vpshufd xmm13,xmm0,0x44
  411e1a:	vmulpd xmm4,xmm4,xmm13
  411e1f:	vmovq  xmm5,r10
  411e24:	vpshufd xmm5,xmm5,0x44
  411e29:	vmovups XMMWORD PTR [rsp+0x460],xmm5
  411e32:	vmulpd xmm8,xmm8,xmm5
  411e36:	vmulpd xmm8,xmm8,xmm13
  411e3b:	vmovups xmm13,xmm4
  411e3f:	vsubpd xmm4,xmm1,xmm8
  411e44:	vfmadd231pd xmm3,xmm4,XMMWORD PTR [rsp+0x2e0]
  411e4e:	vmovq  xmm8,r10
  411e53:	vmovups XMMWORD PTR [rsp+0x300],xmm3
  411e5c:	vmovsd QWORD PTR [rsp+0x470],xmm8
  411e65:	vaddpd xmm3,xmm13,XMMWORD PTR [rsp+0x380]
  411e6e:	vmovups XMMWORD PTR [rsp+0x480],xmm3
  411e77:	vmulsd xmm13,xmm11,xmm8
  411e7c:	vfnmadd231sd xmm6,xmm13,xmm0
  411e81:	vmovsd QWORD PTR [rbx+0x28],xmm6
  411e86:	vmulsd xmm11,xmm11,xmm14
  411e8b:	vmulsd xmm0,xmm11,xmm0
  411e8f:	vaddsd xmm0,xmm0,QWORD PTR [rbx+0x108]
  411e97:	vmovups xmm13,XMMWORD PTR [rsp+0x320]
  411ea0:	vmovsd QWORD PTR [rsp+0x498],xmm0
  411ea9:	vsubpd xmm14,xmm13,XMMWORD PTR [rsp+0x340]
  411eb2:	vmovups XMMWORD PTR [rsp+0x310],xmm4
  411ebb:	vmulpd xmm4,xmm14,xmm2
  411ebf:	vmovups xmm6,XMMWORD PTR [rsp+0x3b0]
  411ec8:	vmovups XMMWORD PTR [rsp+0x3f0],xmm2
  411ed1:	vmulpd xmm2,xmm14,xmm6
  411ed5:	vpsrldq xmm8,xmm14,0x8
  411edb:	vmovsd xmm0,QWORD PTR [rsp+0x398]
  411ee4:	vsubsd xmm1,xmm0,QWORD PTR [rsp+0x3a0]
  411eed:	vmulsd xmm3,xmm14,xmm14
  411ef2:	vfmadd231sd xmm3,xmm8,xmm8
  411ef7:	vfmadd231sd xmm3,xmm1,xmm1
  411efc:	vsubpd xmm8,xmm13,xmm10
  411f01:	vmulsd xmm14,xmm8,xmm8
  411f06:	vpsrldq xmm10,xmm8,0x8
  411f0c:	vmulsd xmm10,xmm10,xmm10
  411f11:	vaddsd xmm10,xmm14,xmm10
  411f16:	vsubsd xmm11,xmm0,QWORD PTR [rsp+0x428]
  411f1f:	vfmadd231sd xmm10,xmm11,xmm11
  411f24:	vpunpcklqdq xmm3,xmm3,xmm10
  411f29:	vsqrtpd xmm10,xmm3
  411f2d:	vmulpd xmm3,xmm3,xmm10
  411f32:	vdivpd xmm3,xmm15,xmm3
  411f36:	vpshufd xmm10,xmm3,0x44
  411f3b:	vfnmadd213pd xmm4,xmm10,XMMWORD PTR [rsp+0x3d0]
  411f45:	vmulpd xmm2,xmm2,xmm10
  411f4a:	vaddpd xmm2,xmm2,XMMWORD PTR [rsp+0x410]
  411f53:	vmovups XMMWORD PTR [rsp+0x4a0],xmm2
  411f5c:	vmulsd xmm14,xmm1,QWORD PTR [rsp+0x400]
  411f65:	vmovsd xmm10,QWORD PTR [rsp+0x3e0]
  411f6e:	vfnmadd231sd xmm10,xmm14,xmm3
  411f73:	vmovsd xmm14,QWORD PTR [rsp+0x3c0]
  411f7c:	vmulsd xmm1,xmm1,xmm14
  411f81:	vfmadd213sd xmm1,xmm3,QWORD PTR [rsp+0x420]
  411f8b:	vmovsd QWORD PTR [rsp+0x4b0],xmm1
  411f94:	vmulpd xmm2,xmm8,xmm12
  411f99:	vmulpd xmm8,xmm8,xmm6
  411f9d:	vpsrldq xmm3,xmm3,0x8
  411fa2:	vpshufd xmm1,xmm3,0x44
  411fa7:	vfnmadd213pd xmm2,xmm1,xmm4
  411fac:	vfmadd213pd xmm1,xmm8,xmm9
  411fb1:	vmulsd xmm4,xmm11,xmm7
  411fb5:	vfnmadd213sd xmm4,xmm3,xmm10
  411fba:	vmulsd xmm8,xmm11,xmm14
  411fbf:	vmulsd xmm3,xmm8,xmm3
  411fc3:	vaddsd xmm3,xmm3,QWORD PTR [rsp+0x458]
  411fcc:	vmovsd QWORD PTR [rsp+0x4b8],xmm3
  411fd5:	vsubpd xmm9,xmm13,XMMWORD PTR [rsp+0x370]
  411fde:	vmulpd xmm10,xmm9,xmm5
  411fe2:	vmulpd xmm6,xmm9,xmm6
  411fe6:	vpsrldq xmm7,xmm9,0x8
  411fec:	vsubsd xmm5,xmm0,QWORD PTR [rsp+0x430]
  411ff5:	vmulsd xmm0,xmm9,xmm9
  411ffa:	vfmadd231sd xmm0,xmm7,xmm7
  411fff:	vfmadd231sd xmm0,xmm5,xmm5
  412004:	vmovups xmm9,XMMWORD PTR [rsp+0x340]
  41200d:	vsubpd xmm11,xmm9,XMMWORD PTR [rsp+0x350]
  412016:	vmulsd xmm7,xmm11,xmm11
  41201b:	vpsrldq xmm8,xmm11,0x8
  412021:	vfmadd231sd xmm7,xmm8,xmm8
  412026:	vmovsd xmm8,QWORD PTR [rsp+0x3a0]
  41202f:	vsubsd xmm3,xmm8,QWORD PTR [rsp+0x428]
  412038:	vfmadd231sd xmm7,xmm3,xmm3
  41203d:	vpunpcklqdq xmm0,xmm0,xmm7
  412041:	vsqrtpd xmm7,xmm0
  412045:	vmulpd xmm0,xmm0,xmm7
  412049:	vdivpd xmm0,xmm15,xmm0
  41204d:	vpshufd xmm9,xmm0,0x44
  412052:	vmulpd xmm7,xmm10,xmm9
  412057:	vmovsd xmm15,QWORD PTR [rsp+0x450]
  412060:	vsubpd xmm7,xmm2,xmm7
  412064:	vmovups xmm2,XMMWORD PTR [rsp+0x2e0]
  41206d:	vfmadd231pd xmm13,xmm7,xmm2
  412072:	vmovups XMMWORD PTR [rsp+0x320],xmm13
  41207b:	vmulpd xmm6,xmm6,xmm9
  412080:	vaddpd xmm6,xmm6,XMMWORD PTR [rsp+0x480]
  412089:	vmovsd xmm10,QWORD PTR [rsp+0x470]
  412092:	vmulsd xmm9,xmm5,xmm10
  412097:	vfnmadd231sd xmm4,xmm9,xmm0
  41209c:	vmovsd QWORD PTR [rbx+0x60],xmm4
  4120a1:	vmulsd xmm5,xmm5,xmm14
  4120a6:	vfmadd213sd xmm5,xmm0,QWORD PTR [rsp+0x498]
  4120b0:	vmulpd xmm9,xmm11,xmm12
  4120b5:	vmovups xmm14,XMMWORD PTR [rsp+0x3f0]
  4120be:	vmulpd xmm11,xmm11,xmm14
  4120c3:	vpsrldq xmm0,xmm0,0x8
  4120c8:	vpshufd xmm13,xmm0,0x44
  4120cd:	vmovups XMMWORD PTR [rsp+0x330],xmm7
  4120d6:	vmovups xmm7,XMMWORD PTR [rsp+0x4a0]
  4120df:	vfnmadd231pd xmm7,xmm9,xmm13
  4120e4:	vfmadd231pd xmm1,xmm11,xmm13
  4120e9:	vmovups XMMWORD PTR [rsp+0x4d0],xmm1
  4120f2:	vmulsd xmm9,xmm3,xmm15
  4120f7:	vmovsd xmm11,QWORD PTR [rsp+0x4b0]
  412100:	vfnmadd231sd xmm11,xmm9,xmm0
  412105:	vmovsd xmm13,QWORD PTR [rsp+0x400]
  41210e:	vmulsd xmm3,xmm3,xmm13
  412113:	vmulsd xmm0,xmm3,xmm0
  412117:	vaddsd xmm0,xmm0,QWORD PTR [rsp+0x4b8]
  412120:	vmovups xmm9,XMMWORD PTR [rsp+0x340]
  412129:	vmovups xmm3,XMMWORD PTR [rsp+0x370]
  412132:	vmovsd QWORD PTR [rsp+0x4e0],xmm0
  41213b:	vsubpd xmm4,xmm9,xmm3
  41213f:	vmulpd xmm15,xmm4,XMMWORD PTR [rsp+0x460]
  412148:	vmulpd xmm14,xmm4,xmm14
  41214d:	vpsrldq xmm0,xmm4,0x8
  412152:	vmovsd xmm9,QWORD PTR [rsp+0x430]
  41215b:	vsubsd xmm1,xmm8,xmm9
  412160:	vmulsd xmm4,xmm4,xmm4
  412164:	vfmadd213sd xmm0,xmm0,xmm4
  412169:	vfmadd231sd xmm0,xmm1,xmm1
  41216e:	vmovups xmm4,XMMWORD PTR [rsp+0x350]
  412177:	vsubpd xmm8,xmm4,xmm3
  41217b:	vmovups XMMWORD PTR [rsp+0x4f0],xmm8
  412184:	vmulsd xmm3,xmm8,xmm8
  412189:	vpsrldq xmm4,xmm8,0x8
  41218f:	vfmadd231sd xmm3,xmm4,xmm4
  412194:	vmovsd xmm4,QWORD PTR [rsp+0x428]
  41219d:	vmovups XMMWORD PTR [rsp+0x440],xmm12
  4121a6:	vsubsd xmm12,xmm4,xmm9
  4121ab:	vmovsd QWORD PTR [rsp+0x500],xmm12
  4121b4:	vfmadd231sd xmm3,xmm12,xmm12
  4121b9:	vpunpcklqdq xmm0,xmm0,xmm3
  4121bd:	vsqrtpd xmm3,xmm0
  4121c1:	vmulpd xmm0,xmm0,xmm3
  4121c5:	vmovups xmm4,XMMWORD PTR [rsp+0x2f0]
  4121ce:	vdivpd xmm0,xmm4,xmm0
  4121d2:	vpshufd xmm3,xmm0,0x44
  4121d7:	vmulpd xmm15,xmm15,xmm3
  4121db:	vmovups xmm8,XMMWORD PTR [rsp+0x340]
  4121e4:	vmovups xmm4,xmm9
  4121e9:	vmovups xmm12,XMMWORD PTR [rsp+0x460]
  4121f2:	vsubpd xmm9,xmm7,xmm15
  4121f7:	vfmadd231pd xmm8,xmm9,xmm2
  4121fc:	vmovups XMMWORD PTR [rsp+0x340],xmm8
  412205:	vfmadd213pd xmm3,xmm14,xmm6
  41220a:	vmulsd xmm6,xmm1,xmm10
  41220f:	vfnmadd213sd xmm6,xmm0,xmm11
  412214:	vmovsd QWORD PTR [rbx+0x98],xmm6
  41221c:	vmulsd xmm1,xmm1,xmm13
  412221:	vfmadd213sd xmm1,xmm0,xmm5
  412226:	vmovups xmm5,XMMWORD PTR [rsp+0x4f0]
  41222f:	vmulpd xmm7,xmm5,xmm12
  412234:	vmulpd xmm5,xmm5,XMMWORD PTR [rsp+0x440]
  41223d:	vpsrldq xmm0,xmm0,0x8
  412242:	vpshufd xmm11,xmm0,0x44
  412247:	vfnmadd213pd xmm7,xmm11,XMMWORD PTR [rsp+0x4d0]
  412251:	vmovups xmm13,XMMWORD PTR [rsp+0x350]
  41225a:	vfmadd231pd xmm13,xmm7,xmm2
  41225f:	vmovups XMMWORD PTR [rsp+0x350],xmm13
  412268:	vmulpd xmm5,xmm5,xmm11
  41226d:	vmovups xmm11,XMMWORD PTR [rsp+0x370]
  412276:	vmovsd xmm12,QWORD PTR [rsp+0x3a0]
  41227f:	vaddpd xmm3,xmm3,xmm5
  412283:	vfmadd231pd xmm11,xmm3,xmm2
  412288:	vmovsd xmm5,QWORD PTR [rsp+0x500]
  412291:	vmovups XMMWORD PTR [rsp+0x370],xmm11
  41229a:	vmulsd xmm10,xmm5,xmm10
  41229f:	vfnmadd213sd xmm10,xmm0,QWORD PTR [rsp+0x4e0]
  4122a9:	vmovsd QWORD PTR [rbx+0xd0],xmm10
  4122b1:	vmulsd xmm5,xmm5,QWORD PTR [rsp+0x450]
  4122ba:	vfmadd213sd xmm0,xmm5,xmm1
  4122bf:	vmovsd QWORD PTR [rbx+0x108],xmm0
  4122c7:	vmovsd xmm5,QWORD PTR [rip+0x181a]        # 413ae9 <__swc_rdata_base_6b1cf01f+0x9d9>
  4122cf:	vmovsd xmm1,QWORD PTR [rbx+0x28]
  4122d4:	vfmadd213sd xmm1,xmm5,QWORD PTR [rsp+0x390]
  4122de:	vmovsd QWORD PTR [rbx+0x10],xmm1
  4122e3:	vmovsd xmm1,QWORD PTR [rbx+0x60]
  4122e8:	vfmadd213sd xmm1,xmm5,QWORD PTR [rsp+0x398]
  4122f2:	vmovsd QWORD PTR [rbx+0x48],xmm1
  4122f7:	vmulsd xmm1,xmm6,xmm5
  4122fb:	vaddsd xmm1,xmm12,xmm1
  4122ff:	vmovsd QWORD PTR [rbx+0x80],xmm1
  412307:	vmulsd xmm1,xmm10,xmm5
  41230b:	vaddsd xmm1,xmm1,QWORD PTR [rsp+0x428]
  412314:	vmovsd QWORD PTR [rbx+0xb8],xmm1
  41231c:	vfmadd213sd xmm0,xmm5,xmm4
  412321:	vmovsd QWORD PTR [rbx+0xf0],xmm0
  412329:	add    rax,0x1
  41232d:	cmp    rax,0x7a120
  412334:	jl     411b90 <__swc_fn_6b1cf01f_000176_0ce64436+0x2b0>
  41233a:	vmovdqu XMMWORD PTR [rsp+0xa8],xmm13
  412343:	vmovdqu XMMWORD PTR [rsp+0xc0],xmm7
  41234c:	vmovdqu XMMWORD PTR [rsp+0xe0],xmm11
  412355:	vmovdqu XMMWORD PTR [rsp+0xf8],xmm3
  41235e:	vmovups xmm3,XMMWORD PTR [rsp+0x300]
  412367:	vmovdqu XMMWORD PTR [rsp],xmm3
  41236c:	vmovups xmm4,XMMWORD PTR [rsp+0x310]
  412375:	vmovdqu XMMWORD PTR [rsp+0x18],xmm4
  41237b:	vmovups xmm13,XMMWORD PTR [rsp+0x320]
  412384:	vmovdqu XMMWORD PTR [rsp+0x38],xmm13
  41238a:	vmovups xmm7,XMMWORD PTR [rsp+0x330]
  412393:	vmovdqu XMMWORD PTR [rsp+0x50],xmm7
  412399:	vmovdqu XMMWORD PTR [rsp+0x70],xmm8
  41239f:	vmovdqu XMMWORD PTR [rsp+0x88],xmm9
  4123a8:	mov    QWORD PTR [rbx+0x258],0x5
  4123b3:	vxorpd xmm0,xmm0,xmm0
  4123b7:	vmovsd xmm1,QWORD PTR [rip+0x11f5]        # 4135b4 <__swc_rdata_base_6b1cf01f+0x4a4>
  4123bf:	vmovsd xmm3,QWORD PTR [rbx+0x30]
  4123c4:	vmulsd xmm2,xmm1,xmm3
  4123c8:	vmovsd xmm4,QWORD PTR [rbx+0x18]
  4123cd:	vmulsd xmm4,xmm4,xmm4
  4123d1:	vmovsd xmm5,QWORD PTR [rbx+0x20]
  4123d6:	vfmadd231sd xmm4,xmm5,xmm5
  4123db:	vmovsd xmm5,QWORD PTR [rbx+0x28]
  4123e0:	vfmadd231sd xmm4,xmm5,xmm5
  4123e5:	vfmadd231sd xmm0,xmm2,xmm4
  4123ea:	vmovsd xmm2,QWORD PTR [rbx]
  4123ee:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x38]
  4123f3:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  4123f8:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x40]
  4123fd:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  412402:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x48]
  412407:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x68]
  41240c:	vmulsd xmm2,xmm2,xmm2
  412410:	vfmadd231sd xmm2,xmm4,xmm4
  412415:	vfmadd231sd xmm2,xmm5,xmm5
  41241a:	vsqrtsd xmm2,xmm2,xmm2
  41241e:	vdivsd xmm2,xmm9,xmm2
  412422:	vsubsd xmm0,xmm0,xmm2
  412426:	vmovsd xmm2,QWORD PTR [rbx]
  41242a:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x70]
  41242f:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  412434:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x78]
  412439:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  41243e:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x80]
  412446:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xa0]
  41244e:	vmulsd xmm2,xmm2,xmm2
  412452:	vfmadd231sd xmm2,xmm4,xmm4
  412457:	vfmadd231sd xmm2,xmm5,xmm5
  41245c:	vsqrtsd xmm2,xmm2,xmm2
  412460:	vdivsd xmm2,xmm9,xmm2
  412464:	vsubsd xmm0,xmm0,xmm2
  412468:	vmovsd xmm2,QWORD PTR [rbx]
  41246c:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  412474:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  412479:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  412481:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  412486:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  41248e:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  412496:	vmulsd xmm2,xmm2,xmm2
  41249a:	vfmadd231sd xmm2,xmm4,xmm4
  41249f:	vfmadd231sd xmm2,xmm5,xmm5
  4124a4:	vsqrtsd xmm2,xmm2,xmm2
  4124a8:	vdivsd xmm2,xmm9,xmm2
  4124ac:	vsubsd xmm0,xmm0,xmm2
  4124b0:	vmovsd xmm2,QWORD PTR [rbx]
  4124b4:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xe0]
  4124bc:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  4124c1:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xe8]
  4124c9:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  4124ce:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xf0]
  4124d6:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x110]
  4124de:	vmulsd xmm2,xmm2,xmm2
  4124e2:	vfmadd231sd xmm2,xmm4,xmm4
  4124e7:	vfmadd231sd xmm2,xmm5,xmm5
  4124ec:	vsqrtsd xmm2,xmm2,xmm2
  4124f0:	vdivsd xmm2,xmm9,xmm2
  4124f4:	vsubsd xmm0,xmm0,xmm2
  4124f8:	vmovsd xmm3,QWORD PTR [rbx+0x68]
  4124fd:	vmulsd xmm2,xmm1,xmm3
  412501:	vmovsd xmm4,QWORD PTR [rbx+0x50]
  412506:	vmulsd xmm4,xmm4,xmm4
  41250a:	vmovsd xmm5,QWORD PTR [rbx+0x58]
  41250f:	vfmadd231sd xmm4,xmm5,xmm5
  412514:	vmovsd xmm5,QWORD PTR [rbx+0x60]
  412519:	vfmadd231sd xmm4,xmm5,xmm5
  41251e:	vfmadd231sd xmm0,xmm2,xmm4
  412523:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  412528:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x70]
  41252d:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  412532:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x78]
  412537:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  41253c:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x80]
  412544:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xa0]
  41254c:	vmulsd xmm2,xmm2,xmm2
  412550:	vfmadd231sd xmm2,xmm4,xmm4
  412555:	vfmadd231sd xmm2,xmm5,xmm5
  41255a:	vsqrtsd xmm2,xmm2,xmm2
  41255e:	vdivsd xmm2,xmm9,xmm2
  412562:	vsubsd xmm0,xmm0,xmm2
  412566:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  41256b:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  412573:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  412578:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  412580:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  412585:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  41258d:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  412595:	vmulsd xmm2,xmm2,xmm2
  412599:	vfmadd231sd xmm2,xmm4,xmm4
  41259e:	vfmadd231sd xmm2,xmm5,xmm5
  4125a3:	vsqrtsd xmm2,xmm2,xmm2
  4125a7:	vdivsd xmm2,xmm9,xmm2
  4125ab:	vsubsd xmm0,xmm0,xmm2
  4125af:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  4125b4:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xe0]
  4125bc:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  4125c1:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xe8]
  4125c9:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  4125ce:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xf0]
  4125d6:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x110]
  4125de:	vmulsd xmm2,xmm2,xmm2
  4125e2:	vfmadd231sd xmm2,xmm4,xmm4
  4125e7:	vfmadd231sd xmm2,xmm5,xmm5
  4125ec:	vsqrtsd xmm2,xmm2,xmm2
  4125f0:	vdivsd xmm2,xmm9,xmm2
  4125f4:	vsubsd xmm0,xmm0,xmm2
  4125f8:	vmovsd xmm3,QWORD PTR [rbx+0xa0]
  412600:	vmulsd xmm2,xmm1,xmm3
  412604:	vmovsd xmm4,QWORD PTR [rbx+0x88]
  41260c:	vmulsd xmm4,xmm4,xmm4
  412610:	vmovsd xmm5,QWORD PTR [rbx+0x90]
  412618:	vfmadd231sd xmm4,xmm5,xmm5
  41261d:	vmovsd xmm5,QWORD PTR [rbx+0x98]
  412625:	vfmadd231sd xmm4,xmm5,xmm5
  41262a:	vfmadd231sd xmm0,xmm2,xmm4
  41262f:	vmovsd xmm2,QWORD PTR [rbx+0x70]
  412634:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  41263c:	vmovsd xmm4,QWORD PTR [rbx+0x78]
  412641:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  412649:	vmovsd xmm5,QWORD PTR [rbx+0x80]
  412651:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  412659:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  412661:	vmulsd xmm2,xmm2,xmm2
  412665:	vfmadd231sd xmm2,xmm4,xmm4
  41266a:	vfmadd231sd xmm2,xmm5,xmm5
  41266f:	vsqrtsd xmm2,xmm2,xmm2
  412673:	vdivsd xmm2,xmm9,xmm2
  412677:	vsubsd xmm0,xmm0,xmm2
  41267b:	vmovsd xmm2,QWORD PTR [rbx+0x70]
  412680:	vmovsd xmm6,QWORD PTR [rbx+0xe0]
  412688:	vsubsd xmm2,xmm2,xmm6
  41268c:	vmovsd xmm4,QWORD PTR [rbx+0x78]
  412691:	vmovsd xmm7,QWORD PTR [rbx+0xe8]
  412699:	vsubsd xmm4,xmm4,xmm7
  41269d:	vmovsd xmm5,QWORD PTR [rbx+0x80]
  4126a5:	vmovsd xmm8,QWORD PTR [rbx+0xf0]
  4126ad:	vsubsd xmm5,xmm5,xmm8
  4126b2:	vmovsd xmm10,QWORD PTR [rbx+0x110]
  4126ba:	vmulsd xmm9,xmm3,xmm10
  4126bf:	vmulsd xmm2,xmm2,xmm2
  4126c3:	vfmadd231sd xmm2,xmm4,xmm4
  4126c8:	vfmadd231sd xmm2,xmm5,xmm5
  4126cd:	vsqrtsd xmm2,xmm2,xmm2
  4126d1:	vdivsd xmm2,xmm9,xmm2
  4126d5:	vsubsd xmm0,xmm0,xmm2
  4126d9:	vmovsd xmm3,QWORD PTR [rbx+0xd8]
  4126e1:	vmulsd xmm2,xmm1,xmm3
  4126e5:	vmovsd xmm4,QWORD PTR [rbx+0xc0]
  4126ed:	vmulsd xmm4,xmm4,xmm4
  4126f1:	vmovsd xmm5,QWORD PTR [rbx+0xc8]
  4126f9:	vfmadd231sd xmm4,xmm5,xmm5
  4126fe:	vmovsd xmm5,QWORD PTR [rbx+0xd0]
  412706:	vfmadd231sd xmm4,xmm5,xmm5
  41270b:	vfmadd231sd xmm0,xmm2,xmm4
  412710:	vmovsd xmm2,QWORD PTR [rbx+0xa8]
  412718:	vsubsd xmm2,xmm2,xmm6
  41271c:	vmovsd xmm4,QWORD PTR [rbx+0xb0]
  412724:	vsubsd xmm4,xmm4,xmm7
  412728:	vmovsd xmm5,QWORD PTR [rbx+0xb8]
  412730:	vsubsd xmm5,xmm5,xmm8
  412735:	vmulsd xmm9,xmm3,xmm10
  41273a:	vmulsd xmm2,xmm2,xmm2
  41273e:	vfmadd231sd xmm2,xmm4,xmm4
  412743:	vfmadd231sd xmm2,xmm5,xmm5
  412748:	vsqrtsd xmm2,xmm2,xmm2
  41274c:	vdivsd xmm2,xmm9,xmm2
  412750:	vsubsd xmm0,xmm0,xmm2
  412754:	vmulsd xmm2,xmm10,xmm1
  412758:	vmovsd xmm4,QWORD PTR [rbx+0xf8]
  412760:	vmulsd xmm4,xmm4,xmm4
  412764:	vmovsd xmm5,QWORD PTR [rbx+0x100]
  41276c:	vfmadd231sd xmm4,xmm5,xmm5
  412771:	vmovsd xmm5,QWORD PTR [rbx+0x108]
  412779:	vfmadd231sd xmm4,xmm5,xmm5
  41277e:	vfmadd231sd xmm0,xmm2,xmm4
  412783:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0xdc5]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  41278b:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x135f]        # 413af2 <__swc_rdata_base_6b1cf01f+0x9e2>
  412793:	vroundsd xmm0,xmm0,xmm0,0x1
  412799:	vmovsd xmm1,QWORD PTR [rip+0xe01]        # 4135a2 <__swc_rdata_base_6b1cf01f+0x492>
  4127a1:	vcomisd xmm0,xmm1
  4127a5:	jb     4127bf <__swc_fn_6b1cf01f_000176_0ce64436+0xedf>
  4127a7:	vsubsd xmm0,xmm0,xmm1
  4127ab:	vcvttsd2si rsi,xmm0
  4127b0:	movabs rax,0x8000000000000000
  4127ba:	xor    rsi,rax
  4127bd:	jmp    4127c4 <__swc_fn_6b1cf01f_000176_0ce64436+0xee4>
  4127bf:	vcvttsd2si rsi,xmm0
  4127c4:	sub    rsp,0x8
  4127c8:	call   40d590 <__swc_fn_6b1cf01f_000175_1ca87929>
  4127cd:	add    rsp,0x8
  4127d1:	vsubsd xmm0,xmm0,QWORD PTR [rsp+0x2d0]
  4127da:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x1319]        # 413afb <__swc_rdata_base_6b1cf01f+0x9eb>
  4127e2:	lea    rax,[rip+0xb7f]        # 413368 <__swc_rdata_base_6b1cf01f+0x258>
  4127e9:	sub    rsp,0x90
  4127f0:	mov    rcx,rsp
  4127f3:	vmovups xmm1,XMMWORD PTR [rip+0x12c5]        # 413ac0 <__swc_rdata_base_6b1cf01f+0x9b0>
  4127fb:	vmovups XMMWORD PTR [rcx],xmm1
  4127ff:	mov    QWORD PTR [rcx+0x30],rsp
  412803:	lea    rdx,[rip+0xb06]        # 413310 <__swc_rdata_base_6b1cf01f+0x200>
  41280a:	mov    QWORD PTR [rcx+0x38],rdx
  41280e:	mov    QWORD PTR [rcx+0x10],rsi
  412812:	lea    r8,[rsp+0x10]
  412817:	mov    QWORD PTR [rcx+0x40],r8
  41281b:	lea    r8,[rip+0x120e]        # 413a30 <__swc_rdata_base_6b1cf01f+0x920>
  412822:	mov    QWORD PTR [rcx+0x48],r8
  412826:	vmovups xmm1,XMMWORD PTR [rip+0x12a2]        # 413ad0 <__swc_rdata_base_6b1cf01f+0x9c0>
  41282e:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  412833:	lea    r8,[rsp+0x18]
  412838:	mov    QWORD PTR [rcx+0x50],r8
  41283c:	mov    QWORD PTR [rcx+0x58],rdx
  412840:	vmovsd QWORD PTR [rcx+0x28],xmm0
  412845:	lea    r8,[rcx+0x28]
  412849:	mov    QWORD PTR [rcx+0x60],r8
  41284d:	lea    r8,[rip+0x1224]        # 413a78 <__swc_rdata_base_6b1cf01f+0x968>
  412854:	mov    QWORD PTR [rcx+0x68],r8
  412858:	mov    QWORD PTR [rcx+0x70],rax
  41285c:	mov    QWORD PTR [rcx+0x78],rdx
  412860:	lea    rax,[rcx+0x30]
  412864:	mov    QWORD PTR [rcx+0x80],rax
  41286b:	mov    QWORD PTR [rcx+0x88],0x5
  412876:	lea    rcx,[rcx+0x80]
  41287d:	sub    rsp,0x8
  412881:	call   4101c0 <__swc_fn_6b1cf01f_000146_585e4cc4>
  412886:	add    rsp,0x5a8
  41288d:	vmovups xmm6,XMMWORD PTR [rsp]
  412892:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  412898:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  41289e:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  4128a4:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  4128aa:	vmovups xmm11,XMMWORD PTR [rsp+0x50]
  4128b0:	vmovups xmm12,XMMWORD PTR [rsp+0x60]
  4128b6:	vmovups xmm13,XMMWORD PTR [rsp+0x70]
  4128bc:	vmovups xmm14,XMMWORD PTR [rsp+0x80]
  4128c5:	vmovups xmm15,XMMWORD PTR [rsp+0x90]
  4128ce:	add    rsp,0xa8
  4128d5:	pop    rsi
  4128d6:	pop    rbx
  4128d7:	pop    rbp
  4128d8:	ret
