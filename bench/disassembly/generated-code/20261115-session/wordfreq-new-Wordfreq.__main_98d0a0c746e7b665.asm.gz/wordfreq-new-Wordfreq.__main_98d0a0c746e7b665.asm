
/workspace/prompt2-20261115/session-combined-micro/new/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

000000000040a8c0 <__swc_fn_4fa09e82_000004_913db40c>:
  40a8c0:	push   rbp
  40a8c1:	push   rbx
  40a8c2:	push   rsi
  40a8c3:	push   rdi
  40a8c4:	push   r12
  40a8c6:	push   r15
  40a8c8:	push   r13
  40a8ca:	push   r14
  40a8cc:	sub    rsp,0x10
  40a8d0:	mov    rbp,rsp
  40a8d3:	vmovups XMMWORD PTR [rsp],xmm6
  40a8d8:	sub    rsp,0x50
  40a8dc:	mov    rbx,rsp
  40a8df:	sub    rsp,0x8
  40a8e3:	mov    ecx,0x13880
  40a8e8:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40a8ed:	mov    rsi,rax
  40a8f0:	mov    ecx,0x9c40
  40a8f5:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40a8fa:	mov    rdi,rax
  40a8fd:	mov    ecx,0x9c40
  40a902:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40a907:	mov    r12,rax
  40a90a:	xor    ecx,ecx
  40a90c:	xor    r8d,r8d
  40a90f:	cs nop WORD PTR [rax+rax*1+0x0]
  40a919:	nop    DWORD PTR [rax+0x0]
  40a920:	lea    r9,[r8+0x1]
  40a924:	mov    r10,r9
  40a927:	movabs rdx,0xaaaaaaaaaaaaaaab
  40a931:	mov    r15,rax
  40a934:	mov    rax,r8
  40a937:	mul    rdx
  40a93a:	mov    r11,rdx
  40a93d:	mov    rax,r15
  40a940:	shr    r11,0x2
  40a944:	imul   r11,r11,0x6
  40a948:	mov    rdx,r8
  40a94b:	sub    rdx,r11
  40a94e:	lea    r11,[rdx+0x3]
  40a952:	mov    QWORD PTR [rdi+r8*8],rcx
  40a956:	mov    QWORD PTR [r12+r8*8],r11
  40a95a:	xor    r8d,r8d
  40a95d:	test   r11,r11
  40a960:	jbe    40a9b4 <__swc_fn_4fa09e82_000004_913db40c+0xf4>
  40a962:	xor    r13d,r13d
  40a965:	cs nop WORD PTR [rax+rax*1+0x0]
  40a96f:	nop
  40a970:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40a97a:	mov    r15,rax
  40a97d:	mov    rax,r10
  40a980:	mul    rdx
  40a983:	mov    r14,rdx
  40a986:	mov    rax,r15
  40a989:	shr    r14,0x3
  40a98d:	imul   r14,r14,0x1a
  40a991:	sub    r10,r14
  40a994:	lea    r10,[r10+0x61]
  40a998:	mov    BYTE PTR [rsi+rcx*1],r10b
  40a99c:	inc    rcx
  40a99f:	shr    rdx,0x3
  40a9a3:	lea    r10,[rdx+r13*1]
  40a9a7:	add    r8,0x1
  40a9ab:	add    r13,0x7
  40a9af:	cmp    r8,r11
  40a9b2:	jb     40a970 <__swc_fn_4fa09e82_000004_913db40c+0xb0>
  40a9b4:	mov    r8,r9
  40a9b7:	cmp    r9,0x1388
  40a9be:	jb     40a920 <__swc_fn_4fa09e82_000004_913db40c+0x60>
  40a9c4:	mov    ecx,0x16e3600
  40a9c9:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40a9ce:	mov    QWORD PTR [rip+0x19693],rax        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40a9d5:	xor    ecx,ecx
  40a9d7:	xor    r8d,r8d
  40a9da:	nop    WORD PTR [rax+rax*1+0x0]
  40a9e0:	mov    r9,QWORD PTR [rip+0x17619]        # 422000 <__swc_data_base_4fa09e82>
  40a9e7:	imul   r9,r9,0x41a7
  40a9ee:	movabs rdx,0x200000005
  40a9f8:	mov    r11,rax
  40a9fb:	mov    rax,r9
  40a9fe:	mul    rdx
  40aa01:	mov    r10,rdx
  40aa04:	mov    rdx,r9
  40aa07:	sub    rdx,r10
  40aa0a:	shr    rdx,1
  40aa0d:	add    rdx,r10
  40aa10:	shr    rdx,0x1e
  40aa14:	imul   r10,rdx,0x7fffffff
  40aa1b:	sub    r9,r10
  40aa1e:	mov    QWORD PTR [rip+0x175db],r9        # 422000 <__swc_data_base_4fa09e82>
  40aa25:	movabs rdx,0x346dc5d63886594b
  40aa2f:	mov    rax,r9
  40aa32:	mul    rdx
  40aa35:	mov    rax,r11
  40aa38:	shr    rdx,0xa
  40aa3c:	imul   rdx,rdx,0x1388
  40aa43:	sub    r9,rdx
  40aa46:	mov    rdx,QWORD PTR [rdi+r9*8]
  40aa4a:	mov    r9,QWORD PTR [r12+r9*8]
  40aa4e:	xor    r10d,r10d
  40aa51:	test   r9,r9
  40aa54:	jbe    40aa74 <__swc_fn_4fa09e82_000004_913db40c+0x1b4>
  40aa56:	mov    r11,QWORD PTR [rip+0x1960b]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40aa5d:	add    rdx,rsi
  40aa60:	mov    r13b,BYTE PTR [rdx+r10*1]
  40aa64:	mov    BYTE PTR [r11+rcx*1],r13b
  40aa68:	inc    rcx
  40aa6b:	add    r10,0x1
  40aa6f:	cmp    r10,r9
  40aa72:	jb     40aa60 <__swc_fn_4fa09e82_000004_913db40c+0x1a0>
  40aa74:	lea    r9,[r8+0x1]
  40aa78:	movabs rdx,0xaaaaaaaaaaaaaaab
  40aa82:	mov    r11,rax
  40aa85:	mov    rax,r9
  40aa88:	mul    rdx
  40aa8b:	mov    r8,rdx
  40aa8e:	mov    rax,r11
  40aa91:	shr    r8,0x3
  40aa95:	imul   r8,r8,0xc
  40aa99:	mov    rdx,r9
  40aa9c:	sub    rdx,r8
  40aa9f:	jne    40aaae <__swc_fn_4fa09e82_000004_913db40c+0x1ee>
  40aaa1:	mov    rdx,QWORD PTR [rip+0x195c0]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40aaa8:	mov    BYTE PTR [rdx+rcx*1],0xa
  40aaac:	jmp    40aab9 <__swc_fn_4fa09e82_000004_913db40c+0x1f9>
  40aaae:	mov    rdx,QWORD PTR [rip+0x195b3]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40aab5:	mov    BYTE PTR [rdx+rcx*1],0x20
  40aab9:	lea    r13,[rcx+0x1]
  40aabd:	mov    r15,r13
  40aac0:	mov    rcx,r13
  40aac3:	mov    r8,r9
  40aac6:	cmp    r9,0x1e8480
  40aacd:	jb     40a9e0 <__swc_fn_4fa09e82_000004_913db40c+0x120>
  40aad3:	mov    QWORD PTR [rsp+0x48],r15
  40aad8:	call   40dd60 <__swc_fn_4fa09e82_000002_1ca87929>
  40aadd:	vmovups xmm6,xmm0
  40aae1:	mov    rsi,rbx
  40aae4:	mov    QWORD PTR [rsp+0x50],rsi
  40aae9:	vxorps xmm0,xmm0,xmm0
  40aaed:	vmovups XMMWORD PTR [rbx],xmm0
  40aaf1:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40aaf6:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40aafb:	mov    QWORD PTR [rbx+0x30],0x0
  40ab03:	mov    r8,QWORD PTR [rip+0x1955e]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40ab0a:	mov    rcx,rsi
  40ab0d:	mov    edx,0x4000
  40ab12:	call   407270 <__swc_fn_4fa09e82_000000_e7f0b636>
  40ab17:	xor    edi,edi
  40ab19:	xor    al,al
  40ab1b:	xor    r12d,r12d
  40ab1e:	cmp    r12,r13
  40ab21:	jae    40acaf <__swc_fn_4fa09e82_000004_913db40c+0x3ef>
  40ab27:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab31:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab3b:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab45:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab4f:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab59:	nop    DWORD PTR [rax+0x0]
  40ab60:	mov    rcx,QWORD PTR [rip+0x19501]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40ab67:	mov    cl,BYTE PTR [rcx+r12*1]
  40ab6b:	sub    cl,0x61
  40ab6e:	cmp    cl,0x19
  40ab71:	ja     40ab88 <__swc_fn_4fa09e82_000004_913db40c+0x2c8>
  40ab73:	test   al,al
  40ab75:	jne    40ac9e <__swc_fn_4fa09e82_000004_913db40c+0x3de>
  40ab7b:	mov    rdi,r12
  40ab7e:	mov    eax,0x1
  40ab83:	jmp    40ac9e <__swc_fn_4fa09e82_000004_913db40c+0x3de>
  40ab88:	test   al,al
  40ab8a:	je     40ac9e <__swc_fn_4fa09e82_000004_913db40c+0x3de>
  40ab90:	mov    r14,r12
  40ab93:	sub    r14,rdi
  40ab96:	mov    eax,0x811c9dc5
  40ab9b:	xor    ecx,ecx
  40ab9d:	test   r14,r14
  40aba0:	jbe    40ac12 <__swc_fn_4fa09e82_000004_913db40c+0x352>
  40aba6:	mov    rdx,QWORD PTR [rbx+0x20]
  40abaa:	add    rdx,rdi
  40abad:	cmp    r14,0x4
  40abb1:	jb     40ac00 <__swc_fn_4fa09e82_000004_913db40c+0x340>
  40abb7:	lea    r8,[r14-0x3]
  40abbb:	nop    DWORD PTR [rax+rax*1+0x0]
  40abc0:	xor    al,BYTE PTR [rdx+rcx*1]
  40abc3:	imul   eax,eax,0x1000193
  40abc9:	xor    al,BYTE PTR [rdx+rcx*1+0x1]
  40abcd:	imul   eax,eax,0x1000193
  40abd3:	xor    al,BYTE PTR [rdx+rcx*1+0x2]
  40abd7:	imul   eax,eax,0x1000193
  40abdd:	xor    al,BYTE PTR [rdx+rcx*1+0x3]
  40abe1:	imul   eax,eax,0x1000193
  40abe7:	add    rcx,0x4
  40abeb:	cmp    rcx,r8
  40abee:	jb     40abc0 <__swc_fn_4fa09e82_000004_913db40c+0x300>
  40abf0:	cmp    rcx,r14
  40abf3:	jae    40ac12 <__swc_fn_4fa09e82_000004_913db40c+0x352>
  40abf5:	cs nop WORD PTR [rax+rax*1+0x0]
  40abff:	nop
  40ac00:	xor    al,BYTE PTR [rdx+rcx*1]
  40ac03:	imul   eax,eax,0x1000193
  40ac09:	add    rcx,0x1
  40ac0d:	cmp    rcx,r14
  40ac10:	jb     40ac00 <__swc_fn_4fa09e82_000004_913db40c+0x340>
  40ac12:	and    rax,QWORD PTR [rbx+0x28]
  40ac16:	mov    r15,rax
  40ac19:	mov    rsi,QWORD PTR [rbx+0x18]
  40ac1d:	mov    r13,QWORD PTR [rbx+0x8]
  40ac21:	cmp    BYTE PTR [rsi+r15*1],0x0
  40ac26:	je     40ac66 <__swc_fn_4fa09e82_000004_913db40c+0x3a6>
  40ac28:	nop    DWORD PTR [rax+rax*1+0x0]
  40ac30:	cmp    QWORD PTR [r13+r15*8+0x0],r14
  40ac35:	jne    40ac58 <__swc_fn_4fa09e82_000004_913db40c+0x398>
  40ac37:	mov    rax,QWORD PTR [rbx]
  40ac3a:	mov    rax,QWORD PTR [rax+r15*8]
  40ac3e:	mov    rcx,QWORD PTR [rbx+0x20]
  40ac42:	add    rax,rcx
  40ac45:	lea    rdx,[rcx+rdi*1]
  40ac49:	mov    rcx,rax
  40ac4c:	mov    r8,r14
  40ac4f:	call   40cb70 <__swc_fn_4fa09e82_000112_3dc01326>
  40ac54:	test   eax,eax
  40ac56:	je     40ac66 <__swc_fn_4fa09e82_000004_913db40c+0x3a6>
  40ac58:	inc    r15
  40ac5b:	and    r15,QWORD PTR [rbx+0x28]
  40ac5f:	cmp    BYTE PTR [rsi+r15*1],0x0
  40ac64:	jne    40ac30 <__swc_fn_4fa09e82_000004_913db40c+0x370>
  40ac66:	cmp    BYTE PTR [rsi+r15*1],0x0
  40ac6b:	jne    40ac94 <__swc_fn_4fa09e82_000004_913db40c+0x3d4>
  40ac6d:	mov    BYTE PTR [rsi+r15*1],0x1
  40ac72:	mov    rax,QWORD PTR [rbx]
  40ac75:	mov    QWORD PTR [rax+r15*8],rdi
  40ac79:	mov    rax,QWORD PTR [rbx+0x8]
  40ac7d:	mov    QWORD PTR [rax+r15*8],r14
  40ac81:	mov    rax,QWORD PTR [rbx+0x10]
  40ac85:	mov    QWORD PTR [rax+r15*8],0x1
  40ac8d:	add    QWORD PTR [rbx+0x30],0x1
  40ac92:	jmp    40ac9c <__swc_fn_4fa09e82_000004_913db40c+0x3dc>
  40ac94:	mov    rax,QWORD PTR [rbx+0x10]
  40ac98:	inc    QWORD PTR [rax+r15*8]
  40ac9c:	xor    eax,eax
  40ac9e:	inc    r12
  40aca1:	mov    r13,QWORD PTR [rsp+0x48]
  40aca6:	cmp    r12,r13
  40aca9:	jb     40ab60 <__swc_fn_4fa09e82_000004_913db40c+0x2a0>
  40acaf:	test   al,al
  40acb1:	je     40addb <__swc_fn_4fa09e82_000004_913db40c+0x51b>
  40acb7:	mov    r13,QWORD PTR [rsp+0x48]
  40acbc:	sub    r13,rdi
  40acbf:	mov    eax,0x811c9dc5
  40acc4:	xor    ecx,ecx
  40acc6:	test   r13,r13
  40acc9:	jbe    40ad52 <__swc_fn_4fa09e82_000004_913db40c+0x492>
  40accf:	mov    rdx,QWORD PTR [rbx+0x20]
  40acd3:	add    rdx,rdi
  40acd6:	cmp    r13,0x4
  40acda:	jb     40ad40 <__swc_fn_4fa09e82_000004_913db40c+0x480>
  40ace0:	lea    r8,[r13-0x3]
  40ace4:	cs nop WORD PTR [rax+rax*1+0x0]
  40acee:	cs nop WORD PTR [rax+rax*1+0x0]
  40acf8:	nop    DWORD PTR [rax+rax*1+0x0]
  40ad00:	xor    al,BYTE PTR [rdx+rcx*1]
  40ad03:	imul   eax,eax,0x1000193
  40ad09:	xor    al,BYTE PTR [rdx+rcx*1+0x1]
  40ad0d:	imul   eax,eax,0x1000193
  40ad13:	xor    al,BYTE PTR [rdx+rcx*1+0x2]
  40ad17:	imul   eax,eax,0x1000193
  40ad1d:	xor    al,BYTE PTR [rdx+rcx*1+0x3]
  40ad21:	imul   eax,eax,0x1000193
  40ad27:	add    rcx,0x4
  40ad2b:	cmp    rcx,r8
  40ad2e:	jb     40ad00 <__swc_fn_4fa09e82_000004_913db40c+0x440>
  40ad30:	cmp    rcx,r13
  40ad33:	jae    40ad52 <__swc_fn_4fa09e82_000004_913db40c+0x492>
  40ad35:	cs nop WORD PTR [rax+rax*1+0x0]
  40ad3f:	nop
  40ad40:	xor    al,BYTE PTR [rdx+rcx*1]
  40ad43:	imul   eax,eax,0x1000193
  40ad49:	add    rcx,0x1
  40ad4d:	cmp    rcx,r13
  40ad50:	jb     40ad40 <__swc_fn_4fa09e82_000004_913db40c+0x480>
  40ad52:	mov    rsi,QWORD PTR [rsp+0x50]
  40ad57:	and    rax,QWORD PTR [rsi+0x28]
  40ad5b:	mov    r12,rax
  40ad5e:	mov    r14,QWORD PTR [rbx+0x18]
  40ad62:	mov    r15,QWORD PTR [rbx+0x8]
  40ad66:	cmp    BYTE PTR [r14+r12*1],0x0
  40ad6b:	je     40ada5 <__swc_fn_4fa09e82_000004_913db40c+0x4e5>
  40ad6d:	nop    DWORD PTR [rax]
  40ad70:	cmp    QWORD PTR [r15+r12*8],r13
  40ad74:	jne    40ad97 <__swc_fn_4fa09e82_000004_913db40c+0x4d7>
  40ad76:	mov    rax,QWORD PTR [rbx]
  40ad79:	mov    rax,QWORD PTR [rax+r12*8]
  40ad7d:	mov    rcx,QWORD PTR [rbx+0x20]
  40ad81:	add    rax,rcx
  40ad84:	lea    rdx,[rcx+rdi*1]
  40ad88:	mov    rcx,rax
  40ad8b:	mov    r8,r13
  40ad8e:	call   40cb70 <__swc_fn_4fa09e82_000112_3dc01326>
  40ad93:	test   eax,eax
  40ad95:	je     40ada5 <__swc_fn_4fa09e82_000004_913db40c+0x4e5>
  40ad97:	inc    r12
  40ad9a:	and    r12,QWORD PTR [rbx+0x28]
  40ad9e:	cmp    BYTE PTR [r14+r12*1],0x0
  40ada3:	jne    40ad70 <__swc_fn_4fa09e82_000004_913db40c+0x4b0>
  40ada5:	cmp    BYTE PTR [r14+r12*1],0x0
  40adaa:	jne    40add3 <__swc_fn_4fa09e82_000004_913db40c+0x513>
  40adac:	mov    BYTE PTR [r14+r12*1],0x1
  40adb1:	mov    rax,QWORD PTR [rbx]
  40adb4:	mov    QWORD PTR [rax+r12*8],rdi
  40adb8:	mov    rax,QWORD PTR [rbx+0x8]
  40adbc:	mov    QWORD PTR [rax+r12*8],r13
  40adc0:	mov    rax,QWORD PTR [rbx+0x10]
  40adc4:	mov    QWORD PTR [rax+r12*8],0x1
  40adcc:	add    QWORD PTR [rsi+0x30],0x1
  40add1:	jmp    40addb <__swc_fn_4fa09e82_000004_913db40c+0x51b>
  40add3:	mov    rax,QWORD PTR [rbx+0x10]
  40add7:	inc    QWORD PTR [rax+r12*8]
  40addb:	mov    rsi,QWORD PTR [rbx+0x30]
  40addf:	lea    rdi,[rsi*8+0x0]
  40ade7:	mov    rcx,rdi
  40adea:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40adef:	mov    QWORD PTR [rip+0x1925a],rax        # 424050 <__swc_bss_base_4fa09e82+0x10>
  40adf6:	mov    rcx,rdi
  40adf9:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40adfe:	mov    QWORD PTR [rip+0x1925b],rax        # 424060 <__swc_bss_base_4fa09e82+0x20>
  40ae05:	mov    rcx,rdi
  40ae08:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40ae0d:	mov    QWORD PTR [rip+0x19244],rax        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40ae14:	mov    rcx,rdi
  40ae17:	call   40a800 <__swc_fn_4fa09e82_000001_2744b483>
  40ae1c:	mov    QWORD PTR [rip+0x19225],rax        # 424048 <__swc_bss_base_4fa09e82+0x8>
  40ae23:	xor    ecx,ecx
  40ae25:	xor    edx,edx
  40ae27:	mov    r8,QWORD PTR [rip+0x19222]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  40ae2e:	mov    r9,QWORD PTR [rip+0x1922b]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  40ae35:	mov    r10,QWORD PTR [rip+0x1921c]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40ae3c:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae46:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae50:	mov    r11,QWORD PTR [rbx+0x18]
  40ae54:	cmp    BYTE PTR [r11+rdx*1],0x0
  40ae59:	je     40ae85 <__swc_fn_4fa09e82_000004_913db40c+0x5c5>
  40ae5b:	mov    r11,QWORD PTR [rbx+0x10]
  40ae5f:	mov    r11,QWORD PTR [r11+rdx*8]
  40ae63:	mov    QWORD PTR [r8+rcx*8],r11
  40ae67:	mov    r11,QWORD PTR [rbx]
  40ae6a:	mov    r11,QWORD PTR [r11+rdx*8]
  40ae6e:	mov    QWORD PTR [r9+rcx*8],r11
  40ae72:	mov    r11,QWORD PTR [rbx+0x8]
  40ae76:	mov    r11,QWORD PTR [r11+rdx*8]
  40ae7a:	mov    QWORD PTR [r10+rcx*8],r11
  40ae7e:	mov    QWORD PTR [rax+rcx*8],rcx
  40ae82:	inc    rcx
  40ae85:	add    rdx,0x1
  40ae89:	cmp    rdx,0x4000
  40ae90:	jb     40ae50 <__swc_fn_4fa09e82_000004_913db40c+0x590>
  40ae92:	xor    ecx,ecx
  40ae94:	lea    rdx,[rsi-0x1]
  40ae98:	call   4072f0 <__swc_fn_4fa09e82_000003_6937fe70>
  40ae9d:	imul   rsi,rsi,0x7
  40aea1:	xor    eax,eax
  40aea3:	mov    rcx,QWORD PTR [rip+0x1919e]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  40aeaa:	mov    rdx,QWORD PTR [rip+0x1919f]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  40aeb1:	cs nop WORD PTR [rax+rax*1+0x0]
  40aebb:	nop    DWORD PTR [rax+rax*1+0x0]
  40aec0:	lea    r8,[rax+0x1]
  40aec4:	mov    rax,QWORD PTR [rcx+rax*8]
  40aec8:	mov    r9,r8
  40aecb:	imul   r9,QWORD PTR [rdx+rax*8]
  40aed0:	add    rsi,r9
  40aed3:	mov    rax,r8
  40aed6:	cmp    r8,0x14
  40aeda:	jb     40aec0 <__swc_fn_4fa09e82_000004_913db40c+0x600>
  40aedc:	call   40dd60 <__swc_fn_4fa09e82_000002_1ca87929>
  40aee1:	vsubsd xmm0,xmm0,xmm6
  40aee5:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x833b]        # 413228 <__swc_rdata_base_4fa09e82+0x118>
  40aeed:	lea    rax,[rip+0x822c]        # 413120 <__swc_rdata_base_4fa09e82+0x10>
  40aef4:	sub    rsp,0x88
  40aefb:	mov    rcx,rsp
  40aefe:	vmovups xmm1,XMMWORD PTR [rip+0x8302]        # 413208 <__swc_rdata_base_4fa09e82+0xf8>
  40af06:	vmovups XMMWORD PTR [rcx],xmm1
  40af0a:	mov    QWORD PTR [rcx+0x30],rsp
  40af0e:	lea    rdx,[rip+0x821b]        # 413130 <__swc_rdata_base_4fa09e82+0x20>
  40af15:	mov    QWORD PTR [rcx+0x38],rdx
  40af19:	mov    QWORD PTR [rcx+0x10],rsi
  40af1d:	lea    r8,[rsp+0x10]
  40af22:	mov    QWORD PTR [rcx+0x40],r8
  40af26:	lea    r8,[rip+0x824b]        # 413178 <__swc_rdata_base_4fa09e82+0x68>
  40af2d:	mov    QWORD PTR [rcx+0x48],r8
  40af31:	vmovups xmm1,XMMWORD PTR [rip+0x82df]        # 413218 <__swc_rdata_base_4fa09e82+0x108>
  40af39:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40af3e:	lea    r8,[rsp+0x18]
  40af43:	mov    QWORD PTR [rcx+0x50],r8
  40af47:	mov    QWORD PTR [rcx+0x58],rdx
  40af4b:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40af50:	lea    r8,[rcx+0x28]
  40af54:	mov    QWORD PTR [rcx+0x60],r8
  40af58:	lea    r8,[rip+0x8261]        # 4131c0 <__swc_rdata_base_4fa09e82+0xb0>
  40af5f:	mov    QWORD PTR [rcx+0x68],r8
  40af63:	mov    QWORD PTR [rcx+0x70],rax
  40af67:	mov    QWORD PTR [rcx+0x78],rdx
  40af6b:	lea    rax,[rcx+0x30]
  40af6f:	mov    QWORD PTR [rcx+0x80],rax
  40af76:	mov    QWORD PTR [rcx+0x88],0x5
  40af81:	lea    rcx,[rcx+0x80]
  40af88:	sub    rsp,0x8
  40af8c:	call   410ca0 <__swc_fn_4fa09e82_000152_6203dca2>
  40af91:	add    rsp,0xe8
  40af98:	vmovups xmm6,XMMWORD PTR [rsp]
  40af9d:	add    rsp,0x10
  40afa1:	pop    r14
  40afa3:	pop    r13
  40afa5:	pop    r15
  40afa7:	pop    r12
  40afa9:	pop    rdi
  40afaa:	pop    rsi
  40afab:	pop    rbx
  40afac:	pop    rbp
  40afad:	ret
