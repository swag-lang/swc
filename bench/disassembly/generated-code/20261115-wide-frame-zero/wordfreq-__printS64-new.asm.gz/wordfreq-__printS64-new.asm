
/workspace/prompt2-20261115/batch5-final-micro/new/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

000000000040d620 <__swc_fn_4fa09e82_000151_2eb804cc>:
  40d620:	push   rbx
  40d621:	sub    rsp,0xe0
  40d628:	lea    rbx,[rsp+0x8]
  40d62d:	vxorps xmm0,xmm0,xmm0
  40d631:	vmovups YMMWORD PTR [rbx],ymm0
  40d635:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40d63a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40d63f:	vzeroupper
  40d642:	mov    DWORD PTR [rbx+0x60],0x0
  40d649:	mov    r8,rbx
  40d64c:	mov    rdx,rcx
  40d64f:	nop
  40d650:	mov    r9,rdx
  40d653:	movabs rdx,0x6666666666666667
  40d65d:	mov    rax,r9
  40d660:	imul   rdx
  40d663:	sar    rdx,0x2
  40d667:	mov    r10,rdx
  40d66a:	shr    rdx,0x3f
  40d66e:	add    r10,rdx
  40d671:	mov    rdx,r10
  40d674:	imul   r11,r10,0xa
  40d678:	sub    r9,r11
  40d67b:	mov    r11,QWORD PTR [rip+0x5f8e]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  40d682:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40d687:	mov    BYTE PTR [r8],r9b
  40d68a:	lea    r9,[r8+0x1]
  40d68e:	mov    r8,r9
  40d691:	test   r10,r10
  40d694:	jne    40d650 <__swc_fn_4fa09e82_000151_2eb804cc+0x30>
  40d696:	test   rcx,rcx
  40d699:	jge    40d6a3 <__swc_fn_4fa09e82_000151_2eb804cc+0x83>
  40d69b:	mov    BYTE PTR [r9],0x2d
  40d69f:	add    r8,0x1
  40d6a3:	mov    BYTE PTR [r8],0x0
  40d6a7:	sub    r8,0x1
  40d6ab:	mov    rax,rbx
  40d6ae:	cmp    rax,r8
  40d6b1:	jae    40d6d6 <__swc_fn_4fa09e82_000151_2eb804cc+0xb6>
  40d6b3:	cs nop WORD PTR [rax+rax*1+0x0]
  40d6bd:	nop    DWORD PTR [rax]
  40d6c0:	mov    cl,BYTE PTR [r8]
  40d6c3:	mov    dl,BYTE PTR [rax]
  40d6c5:	mov    BYTE PTR [r8],dl
  40d6c8:	sub    r8,0x1
  40d6cc:	mov    BYTE PTR [rax],cl
  40d6ce:	inc    rax
  40d6d1:	cmp    rax,r8
  40d6d4:	jb     40d6c0 <__swc_fn_4fa09e82_000151_2eb804cc+0xa0>
  40d6d6:	xor    eax,eax
  40d6d8:	test   rbx,rbx
  40d6db:	je     40d6fe <__swc_fn_4fa09e82_000151_2eb804cc+0xde>
  40d6dd:	mov    rcx,rbx
  40d6e0:	mov    dl,BYTE PTR [rcx]
  40d6e2:	test   dl,dl
  40d6e4:	je     40d6fe <__swc_fn_4fa09e82_000151_2eb804cc+0xde>
  40d6e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40d6f0:	add    rcx,0x1
  40d6f4:	add    rax,0x1
  40d6f8:	mov    dl,BYTE PTR [rcx]
  40d6fa:	test   dl,dl
  40d6fc:	jne    40d6f0 <__swc_fn_4fa09e82_000151_2eb804cc+0xd0>
  40d6fe:	mov    QWORD PTR [rbx+0xa8],rbx
  40d705:	mov    QWORD PTR [rbx+0xb0],rax
  40d70c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d714:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d71c:	lea    rcx,[rbx+0xb8]
  40d723:	call   4103d0 <__swc_fn_4fa09e82_000122_2648f149>
  40d728:	add    rsp,0xe0
  40d72f:	pop    rbx
  40d730:	ret
