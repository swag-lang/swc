
/workspace/prompt2-20261115/batch4-final-micro/new/fannkuch/fannkuch:     file format elf64-x86-64


Disassembly of section .text:

0000000000407320 <__swc_fn_585f006d_000003_8d3f617b>:
  407320:	push   rbp
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	push   r13
  407327:	push   r14
  407329:	sub    rsp,0x10
  40732d:	mov    rbp,rsp
  407330:	vmovups XMMWORD PTR [rsp],xmm6
  407335:	sub    rsp,0xc0
  40733c:	mov    ecx,0x48
  407341:	sub    rsp,0x8
  407345:	call   407270 <__swc_fn_585f006d_000000_2744b483>
  40734a:	add    rsp,0x8
  40734e:	mov    rsi,rax
  407351:	mov    ecx,0x48
  407356:	sub    rsp,0x8
  40735a:	call   407270 <__swc_fn_585f006d_000000_2744b483>
  40735f:	add    rsp,0x8
  407363:	mov    rdi,rax
  407366:	mov    ecx,0x48
  40736b:	sub    rsp,0x8
  40736f:	call   407270 <__swc_fn_585f006d_000000_2744b483>
  407374:	add    rsp,0x8
  407378:	mov    r12,rax
  40737b:	sub    rsp,0x8
  40737f:	call   40ea80 <__swc_fn_585f006d_000002_1ca87929>
  407384:	add    rsp,0x8
  407388:	vmovups xmm6,xmm0
  40738c:	mov    QWORD PTR [rdi],0x0
  407393:	mov    QWORD PTR [rdi+0x8],0x1
  40739b:	mov    QWORD PTR [rdi+0x10],0x2
  4073a3:	mov    QWORD PTR [rdi+0x18],0x3
  4073ab:	mov    QWORD PTR [rdi+0x20],0x4
  4073b3:	mov    QWORD PTR [rdi+0x28],0x5
  4073bb:	mov    QWORD PTR [rdi+0x30],0x6
  4073c3:	mov    QWORD PTR [rdi+0x38],0x7
  4073cb:	mov    QWORD PTR [rdi+0x40],0x8
  4073d3:	xor    eax,eax
  4073d5:	xor    ecx,ecx
  4073d7:	xor    edx,edx
  4073d9:	mov    r8d,0x9
  4073df:	nop
  4073e0:	cmp    r8,0x1
  4073e4:	je     4073fe <__swc_fn_585f006d_000003_8d3f617b+0xde>
  4073e6:	cs nop WORD PTR [rax+rax*1+0x0]
  4073f0:	mov    QWORD PTR [r12+r8*8-0x8],r8
  4073f5:	dec    r8
  4073f8:	cmp    r8,0x1
  4073fc:	jne    4073f0 <__swc_fn_585f006d_000003_8d3f617b+0xd0>
  4073fe:	mov    r9,QWORD PTR [rdi]
  407401:	mov    QWORD PTR [rsi],r9
  407404:	mov    r10,QWORD PTR [rdi+0x8]
  407408:	mov    QWORD PTR [rsi+0x8],r10
  40740c:	mov    r10,QWORD PTR [rdi+0x10]
  407410:	mov    QWORD PTR [rsi+0x10],r10
  407414:	mov    r10,QWORD PTR [rdi+0x18]
  407418:	mov    QWORD PTR [rsi+0x18],r10
  40741c:	mov    r10,QWORD PTR [rdi+0x20]
  407420:	mov    QWORD PTR [rsi+0x20],r10
  407424:	mov    r10,QWORD PTR [rdi+0x28]
  407428:	mov    QWORD PTR [rsi+0x28],r10
  40742c:	mov    r10,QWORD PTR [rdi+0x30]
  407430:	mov    QWORD PTR [rsi+0x30],r10
  407434:	mov    r10,QWORD PTR [rdi+0x38]
  407438:	mov    QWORD PTR [rsi+0x38],r10
  40743c:	mov    r10,QWORD PTR [rdi+0x40]
  407440:	mov    QWORD PTR [rsi+0x40],r10
  407444:	xor    r10d,r10d
  407447:	test   r9,r9
  40744a:	je     4074fa <__swc_fn_585f006d_000003_8d3f617b+0x1da>
  407450:	jle    4074eb <__swc_fn_585f006d_000003_8d3f617b+0x1cb>
  407456:	mov    r14,QWORD PTR [rsi+r9*8]
  40745a:	mov    QWORD PTR [rsi],r14
  40745d:	mov    QWORD PTR [rsi+r9*8],r9
  407461:	dec    r9
  407464:	cmp    r9,0x1
  407468:	jle    4074eb <__swc_fn_585f006d_000003_8d3f617b+0x1cb>
  40746e:	mov    r13,QWORD PTR [rsi+0x8]
  407472:	mov    r14,QWORD PTR [rsi+r9*8]
  407476:	mov    QWORD PTR [rsi+0x8],r14
  40747a:	mov    QWORD PTR [rsi+r9*8],r13
  40747e:	dec    r9
  407481:	cmp    r9,0x2
  407485:	jle    4074eb <__swc_fn_585f006d_000003_8d3f617b+0x1cb>
  407487:	mov    r13,QWORD PTR [rsi+0x10]
  40748b:	mov    r14,QWORD PTR [rsi+r9*8]
  40748f:	mov    QWORD PTR [rsi+0x10],r14
  407493:	mov    QWORD PTR [rsi+r9*8],r13
  407497:	dec    r9
  40749a:	cmp    r9,0x3
  40749e:	jle    4074eb <__swc_fn_585f006d_000003_8d3f617b+0x1cb>
  4074a0:	mov    r13,QWORD PTR [rsi+0x18]
  4074a4:	mov    r14,QWORD PTR [rsi+r9*8]
  4074a8:	mov    QWORD PTR [rsi+0x18],r14
  4074ac:	mov    QWORD PTR [rsi+r9*8],r13
  4074b0:	dec    r9
  4074b3:	cmp    r9,0x4
  4074b7:	jle    4074eb <__swc_fn_585f006d_000003_8d3f617b+0x1cb>
  4074b9:	mov    r11d,0x4
  4074bf:	jmp    4074d0 <__swc_fn_585f006d_000003_8d3f617b+0x1b0>
  4074c1:	cmp    r11,r9
  4074c4:	jge    4074eb <__swc_fn_585f006d_000003_8d3f617b+0x1cb>
  4074c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4074d0:	mov    r13,QWORD PTR [rsi+r11*8]
  4074d4:	mov    r14,QWORD PTR [rsi+r9*8]
  4074d8:	mov    QWORD PTR [rsi+r11*8],r14
  4074dc:	mov    QWORD PTR [rsi+r9*8],r13
  4074e0:	inc    r11
  4074e3:	dec    r9
  4074e6:	cmp    r11,r9
  4074e9:	jl     4074d0 <__swc_fn_585f006d_000003_8d3f617b+0x1b0>
  4074eb:	inc    r10
  4074ee:	mov    r9,QWORD PTR [rsi]
  4074f1:	test   r9,r9
  4074f4:	jne    407450 <__swc_fn_585f006d_000003_8d3f617b+0x130>
  4074fa:	cmp    r10,rcx
  4074fd:	cmovg  rcx,r10
  407501:	test   dl,0x1
  407504:	jne    40750b <__swc_fn_585f006d_000003_8d3f617b+0x1eb>
  407506:	add    rax,r10
  407509:	jmp    40750e <__swc_fn_585f006d_000003_8d3f617b+0x1ee>
  40750b:	sub    rax,r10
  40750e:	xchg   ax,ax
  407510:	cmp    r8,0x9
  407514:	je     40756b <__swc_fn_585f006d_000003_8d3f617b+0x24b>
  407516:	mov    r10,QWORD PTR [rdi]
  407519:	xor    r11d,r11d
  40751c:	test   r8,r8
  40751f:	jle    407552 <__swc_fn_585f006d_000003_8d3f617b+0x232>
  407521:	cs nop WORD PTR [rax+rax*1+0x0]
  40752b:	cs nop WORD PTR [rax+rax*1+0x0]
  407535:	cs nop WORD PTR [rax+rax*1+0x0]
  40753f:	nop
  407540:	mov    r13,QWORD PTR [rdi+r11*8+0x8]
  407545:	mov    QWORD PTR [rdi+r11*8],r13
  407549:	add    r11,0x1
  40754d:	cmp    r11,r8
  407550:	jl     407540 <__swc_fn_585f006d_000003_8d3f617b+0x220>
  407552:	mov    QWORD PTR [rdi+r8*8],r10
  407556:	dec    QWORD PTR [r12+r8*8]
  40755a:	je     40755e <__swc_fn_585f006d_000003_8d3f617b+0x23e>
  40755c:	jns    407563 <__swc_fn_585f006d_000003_8d3f617b+0x243>
  40755e:	inc    r8
  407561:	jmp    407510 <__swc_fn_585f006d_000003_8d3f617b+0x1f0>
  407563:	inc    rdx
  407566:	jmp    4073e0 <__swc_fn_585f006d_000003_8d3f617b+0xc0>
  40756b:	imul   r13,rax,0x3e8
  407572:	add    r13,rcx
  407575:	sub    rsp,0x8
  407579:	call   40ea80 <__swc_fn_585f006d_000002_1ca87929>
  40757e:	add    rsp,0x8
  407582:	vsubsd xmm0,xmm0,xmm6
  407586:	vmulsd xmm0,xmm0,QWORD PTR [rip+0xac9a]        # 412228 <__swc_rdata_base_585f006d+0x118>
  40758e:	lea    rax,[rip+0xab8b]        # 412120 <__swc_rdata_base_585f006d+0x10>
  407595:	sub    rsp,0x90
  40759c:	mov    rcx,rsp
  40759f:	vmovups xmm1,XMMWORD PTR [rip+0xac61]        # 412208 <__swc_rdata_base_585f006d+0xf8>
  4075a7:	vmovups XMMWORD PTR [rcx],xmm1
  4075ab:	mov    QWORD PTR [rcx+0x30],rsp
  4075af:	lea    rdx,[rip+0xab7a]        # 412130 <__swc_rdata_base_585f006d+0x20>
  4075b6:	mov    QWORD PTR [rcx+0x38],rdx
  4075ba:	mov    QWORD PTR [rcx+0x10],r13
  4075be:	lea    r8,[rsp+0x10]
  4075c3:	mov    QWORD PTR [rcx+0x40],r8
  4075c7:	lea    r8,[rip+0xabaa]        # 412178 <__swc_rdata_base_585f006d+0x68>
  4075ce:	mov    QWORD PTR [rcx+0x48],r8
  4075d2:	vmovups xmm1,XMMWORD PTR [rip+0xac3e]        # 412218 <__swc_rdata_base_585f006d+0x108>
  4075da:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  4075df:	lea    r8,[rsp+0x18]
  4075e4:	mov    QWORD PTR [rcx+0x50],r8
  4075e8:	mov    QWORD PTR [rcx+0x58],rdx
  4075ec:	vmovsd QWORD PTR [rcx+0x28],xmm0
  4075f1:	lea    r8,[rcx+0x28]
  4075f5:	mov    QWORD PTR [rcx+0x60],r8
  4075f9:	lea    r8,[rip+0xabc0]        # 4121c0 <__swc_rdata_base_585f006d+0xb0>
  407600:	mov    QWORD PTR [rcx+0x68],r8
  407604:	mov    QWORD PTR [rcx+0x70],rax
  407608:	mov    QWORD PTR [rcx+0x78],rdx
  40760c:	lea    rax,[rcx+0x30]
  407610:	mov    QWORD PTR [rcx+0x80],rax
  407617:	mov    QWORD PTR [rcx+0x88],0x5
  407622:	lea    rcx,[rcx+0x80]
  407629:	sub    rsp,0x8
  40762d:	call   40a1e0 <__swc_fn_585f006d_000150_6203dca2>
  407632:	add    rsp,0x8
  407636:	add    rsp,0x90
  40763d:	mov    rcx,r12
  407640:	sub    rsp,0x8
  407644:	call   40b900 <__swc_fn_585f006d_000001_5d3d19bd>
  407649:	add    rsp,0x8
  40764d:	mov    rcx,rdi
  407650:	sub    rsp,0x8
  407654:	call   40b900 <__swc_fn_585f006d_000001_5d3d19bd>
  407659:	add    rsp,0x8
  40765d:	mov    rcx,rsi
  407660:	sub    rsp,0x8
  407664:	call   40b900 <__swc_fn_585f006d_000001_5d3d19bd>
  407669:	add    rsp,0xc8
  407670:	vmovups xmm6,XMMWORD PTR [rsp]
  407675:	add    rsp,0x10
  407679:	pop    r14
  40767b:	pop    r13
  40767d:	pop    r12
  40767f:	pop    rdi
  407680:	pop    rsi
  407681:	pop    rbp
  407682:	ret
