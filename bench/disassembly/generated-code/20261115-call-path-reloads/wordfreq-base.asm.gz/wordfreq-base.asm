
/workspace/prompt2-20261115/batch9-audited-micro/base/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <open@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <open@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <flock@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <flock@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <__errno_location@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <__errno_location@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <close@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <close@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <getpid@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <getpid@GLIBC_2.2.5>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <opendir@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <opendir@GLIBC_2.2.5>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <dirfd@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <dirfd@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <readdir@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <readdir@GLIBC_2.2.5>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <readlinkat@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <readlinkat@GLIBC_2.4>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <openat@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <openat@GLIBC_2.4>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <closedir@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <closedir@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <lseek@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <lseek@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <mmap@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <mmap@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <memfd_create@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <memfd_create@GLIBC_2.27>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <ftruncate@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf8a]        # 413080 <ftruncate@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <write@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf82]        # 413088 <write@GLIBC_2.2.5>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <backtrace@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf7a]        # 413090 <backtrace@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <pthread_setspecific@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf72]        # 413098 <pthread_setspecific@GLIBC_2.34>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <clock_gettime@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf6a]        # 4130a0 <clock_gettime@GLIBC_2.17>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <__x86_get_cpuid_feature_leaf@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf62]        # 4130a8 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <free@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf5a]        # 4130b0 <free@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <munmap@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <munmap@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <mprotect@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <mprotect@GLIBC_2.2.5>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <exit@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <exit@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <pthread_key_create@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <pthread_key_create@GLIBC_2.34>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <syscall@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <syscall@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <dladdr@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <dladdr@GLIBC_2.34>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <malloc@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <malloc@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <madvise@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <madvise@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <pthread_key_delete@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <pthread_key_delete@GLIBC_2.34>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <gettid@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <gettid@GLIBC_2.30>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_4fa09e82_000179_6937fe70+0xef0>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   4114e0 <__swc_fn_4fa09e82_000122_71a5b1cd>
  40724e:	xor    ecx,ecx
  407250:	call   40dce0 <__swc_fn_4fa09e82_000094_335e9a12>
  407255:	call   40b880 <__swc_fn_4fa09e82_000180_913db40c>
  40725a:	call   410b30 <__swc_fn_4fa09e82_000095_a3245f7e>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_4fa09e82_000000_29b04951>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_4fa09e82_000003_644dadb7>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_4fa09e82_000003_644dadb7+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   40e100 <__swc_fn_4fa09e82_000112_e724f834>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_4fa09e82_000003_644dadb7+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_4fa09e82_000003_644dadb7+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_4fa09e82_000003_644dadb7+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_4fa09e82_000003_644dadb7+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_4fa09e82_000003_644dadb7+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_4fa09e82_000006_12cb36a2>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40f3e0 <__swc_fn_4fa09e82_000011_e75d466d>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_4fa09e82_000012_39679ef8>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_4fa09e82_000006_12cb36a2+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_4fa09e82_000003_644dadb7>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_4fa09e82_000006_12cb36a2+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_4fa09e82_000009_2417e911>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_4fa09e82_000009_2417e911+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40c070 <__swc_fn_4fa09e82_000007_635028f3>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40f3d0 <__swc_fn_4fa09e82_000008_578f1784>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_4fa09e82_000009_2417e911+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_4fa09e82_000009_2417e911+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_4fa09e82_000012_39679ef8>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_4fa09e82_000015_aa8c841a>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_4fa09e82_000015_aa8c841a+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_4fa09e82_000015_aa8c841a+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_4fa09e82_000015_aa8c841a+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_4fa09e82_000015_aa8c841a+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40f540 <__swc_fn_4fa09e82_000017_e238d24c>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_4fa09e82_000015_aa8c841a+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_4fa09e82_000015_aa8c841a+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_4fa09e82_000015_aa8c841a+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40f3e0 <__swc_fn_4fa09e82_000011_e75d466d>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_4fa09e82_000015_aa8c841a+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   4111f0 <__swc_fn_4fa09e82_000113_cb2656be>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_4fa09e82_000015_aa8c841a+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_4fa09e82_000015_aa8c841a+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_4fa09e82_000015_aa8c841a+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_4fa09e82_000015_aa8c841a+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_4fa09e82_000018_e2e8e4b0>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_4fa09e82_000015_aa8c841a+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_4fa09e82_000018_e2e8e4b0>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_4fa09e82_000018_e2e8e4b0+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_4fa09e82_000018_e2e8e4b0+0x10>

0000000000407630 <__swc_fn_4fa09e82_000021_fe13ecad>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_4fa09e82_000015_aa8c841a>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_4fa09e82+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   40e760 <__swc_fn_4fa09e82_000136_1fec60ac>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_4fa09e82+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_4fa09e82+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_4fa09e82_000024_7e9350e1>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_4fa09e82_000027_7e9350e1>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_4fa09e82_000030_686c93a8>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_4fa09e82_000030_686c93a8+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_4fa09e82>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_4fa09e82_000030_686c93a8+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_4fa09e82_000030_686c93a8+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_4fa09e82_000030_686c93a8+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40f700 <__swc_fn_4fa09e82_000032_8c89735c>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_4fa09e82_000030_686c93a8+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_4fa09e82_000036_62160bb3>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_4fa09e82_000030_686c93a8+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_4fa09e82_000042_70d5ab54>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_4fa09e82_000033_7d7574b6>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40c520 <__swc_fn_4fa09e82_000031_ed8d61a9>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   40e5e0 <__swc_fn_4fa09e82_000130_0672cd48>
  407734:	mov    rcx,rsi
  407737:	call   40f700 <__swc_fn_4fa09e82_000032_8c89735c>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_4fa09e82_000036_62160bb3>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_4fa09e82_000039_05a50673>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_4fa09e82_000039_05a50673+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_4fa09e82_000039_05a50673+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_4fa09e82_000039_05a50673+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_4fa09e82_000039_05a50673+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_4fa09e82_000039_05a50673+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   40e1e0 <__swc_fn_4fa09e82_000115_0575f585>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_4fa09e82_000039_05a50673+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_4fa09e82_000039_05a50673+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_4fa09e82_000039_05a50673+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_4fa09e82_000039_05a50673+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_4fa09e82_000042_70d5ab54>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_4fa09e82_000042_70d5ab54+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40fcd0 <__swc_fn_4fa09e82_000059_c8e1ff6b>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   40e760 <__swc_fn_4fa09e82_000136_1fec60ac>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_4fa09e82_000042_70d5ab54+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_4fa09e82_000042_70d5ab54+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_4fa09e82_000009_2417e911>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_4fa09e82_000042_70d5ab54+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40f400 <__swc_fn_4fa09e82_000014_1acdaf22>
  40791e:	jmp    407941 <__swc_fn_4fa09e82_000042_70d5ab54+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_4fa09e82_000042_70d5ab54+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_4fa09e82_000042_70d5ab54+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_4fa09e82_000042_70d5ab54+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40c6e0 <__swc_fn_4fa09e82_000043_3755033a>
  407997:	mov    rcx,rdi
  40799a:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_4fa09e82_000039_05a50673>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_4fa09e82_000045_06cec934>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_4fa09e82_000045_06cec934+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_4fa09e82_000045_06cec934+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_4fa09e82_000045_06cec934+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_4fa09e82_000045_06cec934+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   40e760 <__swc_fn_4fa09e82_000136_1fec60ac>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_4fa09e82_000045_06cec934+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_4fa09e82_000045_06cec934+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_4fa09e82_000045_06cec934+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_4fa09e82_000045_06cec934+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_4fa09e82_000009_2417e911>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_4fa09e82_000045_06cec934+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_4fa09e82_000045_06cec934+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_4fa09e82_000045_06cec934+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_4fa09e82_000045_06cec934+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_4fa09e82_000045_06cec934+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40c120 <__swc_fn_4fa09e82_000013_d15d37c6>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_4fa09e82_000045_06cec934+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_4fa09e82_000045_06cec934+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_4fa09e82_000045_06cec934+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_4fa09e82_000045_06cec934+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40f580 <__swc_fn_4fa09e82_000020_4135c89a>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_4fa09e82_000045_06cec934+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40c120 <__swc_fn_4fa09e82_000013_d15d37c6>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_4fa09e82_000045_06cec934+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_4fa09e82_000021_fe13ecad>
  407c07:	mov    rcx,r14
  407c0a:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_4fa09e82_000045_06cec934+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_4fa09e82_000045_06cec934+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_4fa09e82_000045_06cec934+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_4fa09e82_000048_18a95c9b>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_4fa09e82_000048_18a95c9b+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_4fa09e82_000048_18a95c9b+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_4fa09e82_000048_18a95c9b+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_4fa09e82_000048_18a95c9b+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40f930 <__swc_fn_4fa09e82_000047_3d3eceb4>
  407d14:	jmp    407ce0 <__swc_fn_4fa09e82_000048_18a95c9b+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_4fa09e82_000048_18a95c9b+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_4fa09e82_000048_18a95c9b+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_4fa09e82_000048_18a95c9b+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_4fa09e82_000048_18a95c9b+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_4fa09e82_000048_18a95c9b+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_4fa09e82_000048_18a95c9b+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_4fa09e82_000048_18a95c9b+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_4fa09e82_000051_5b91e689>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_4fa09e82_000051_5b91e689+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_4fa09e82_000051_5b91e689+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_4fa09e82_000051_5b91e689+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_4fa09e82_000051_5b91e689+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40f890 <__swc_fn_4fa09e82_000044_cac7f504>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40f400 <__swc_fn_4fa09e82_000014_1acdaf22>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_4fa09e82_000054_1dfec8f6>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   40e760 <__swc_fn_4fa09e82_000136_1fec60ac>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_4fa09e82_000054_1dfec8f6+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_4fa09e82_000054_1dfec8f6+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_4fa09e82_000054_1dfec8f6+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_4fa09e82_000057_8be0372b>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_4fa09e82_000060_9d59636e>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_4fa09e82_000060_9d59636e+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_4fa09e82_000039_05a50673>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_4fa09e82_000060_9d59636e+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_4fa09e82_000063_3509a564>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40ca60 <__swc_fn_4fa09e82_000052_26c6c1c4>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_4fa09e82_000054_1dfec8f6>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_4fa09e82_000063_3509a564+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_4fa09e82_000063_3509a564+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40cb80 <__swc_fn_4fa09e82_000058_033ce1da>
  407f7f:	mov    rcx,rsi
  407f82:	call   40c7c0 <__swc_fn_4fa09e82_000049_781177b4>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_4fa09e82_000066_77c6e829>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_4fa09e82_000066_77c6e829+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_4fa09e82+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_4fa09e82_000066_77c6e829+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_4fa09e82_000066_77c6e829+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40c450 <__swc_fn_4fa09e82_000022_77c2d682>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_4fa09e82_000066_77c6e829+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_4fa09e82_000063_3509a564>
  40808f:	jmp    408122 <__swc_fn_4fa09e82_000066_77c6e829+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_4fa09e82>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_4fa09e82_000066_77c6e829+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_4fa09e82_000066_77c6e829+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_4fa09e82_000066_77c6e829+0x135>
  4080b8:	call   40c520 <__swc_fn_4fa09e82_000031_ed8d61a9>
  4080bd:	mov    rcx,rax
  4080c0:	call   409ba0 <__swc_fn_4fa09e82_000129_9c45d2d7>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_4fa09e82_000066_77c6e829+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_4fa09e82_000066_77c6e829+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_4fa09e82_000066_77c6e829+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40f930 <__swc_fn_4fa09e82_000047_3d3eceb4>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_4fa09e82_000066_77c6e829+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_4fa09e82_000051_5b91e689>
  408115:	jmp    408122 <__swc_fn_4fa09e82_000066_77c6e829+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40c090 <__swc_fn_4fa09e82_000010_186cd0c2>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_4fa09e82_000069_165b6301>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_4fa09e82_000036_62160bb3>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_4fa09e82_000069_165b6301+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_4fa09e82_000069_165b6301+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   40e760 <__swc_fn_4fa09e82_000136_1fec60ac>
  4081b5:	mov    rcx,rsi
  4081b8:	call   410100 <__swc_fn_4fa09e82_000068_557d6092>
  4081bd:	mov    rcx,rsi
  4081c0:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_4fa09e82_000072_b2caea81>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40fe50 <__swc_fn_4fa09e82_000065_cd9dd53e>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_4fa09e82_000075_104c4b5d>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   410100 <__swc_fn_4fa09e82_000068_557d6092>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_4fa09e82_000078_5a70c27a>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_4fa09e82_000078_5a70c27a+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_4fa09e82_000078_5a70c27a+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_4fa09e82_000081_85585149>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_4fa09e82_000084_746bf146>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_4fa09e82_000090_9a1d717d>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_4fa09e82_000084_746bf146+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_4fa09e82_000084_746bf146+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_4fa09e82_000084_746bf146+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_4fa09e82_000084_746bf146+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_4fa09e82_000090_9a1d717d>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_4fa09e82_000084_746bf146+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_4fa09e82_000084_746bf146+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_4fa09e82_000084_746bf146+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_4fa09e82_000084_746bf146+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_4fa09e82_000084_746bf146+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_4fa09e82_000084_746bf146+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_4fa09e82_000084_746bf146+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_4fa09e82_000084_746bf146+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_4fa09e82_000084_746bf146+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_4fa09e82_000084_746bf146+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40db60 <__swc_fn_4fa09e82_000082_9f4f5092>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_4fa09e82_000084_746bf146+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_4fa09e82_000084_746bf146+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_4fa09e82_000084_746bf146+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40db60 <__swc_fn_4fa09e82_000082_9f4f5092>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_4fa09e82_000084_746bf146+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_4fa09e82_000084_746bf146>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_4fa09e82_000084_746bf146+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_4fa09e82_000084_746bf146+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_4fa09e82_000087_1fb4fcfe>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_4fa09e82_000090_9a1d717d>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_4fa09e82_000087_1fb4fcfe+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   410560 <__swc_fn_4fa09e82_000086_ac8c6565>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_4fa09e82_000087_1fb4fcfe+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_4fa09e82_000087_1fb4fcfe+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_4fa09e82_000087_1fb4fcfe+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40db60 <__swc_fn_4fa09e82_000082_9f4f5092>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_4fa09e82_000087_1fb4fcfe+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_4fa09e82_000087_1fb4fcfe>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_4fa09e82_000087_1fb4fcfe+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_4fa09e82_000087_1fb4fcfe+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_4fa09e82_000090_9a1d717d>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_4fa09e82_000090_9a1d717d+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_4fa09e82_000090_9a1d717d+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_4fa09e82_000090_9a1d717d+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_4fa09e82_000090_9a1d717d+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40db60 <__swc_fn_4fa09e82_000082_9f4f5092>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40db60 <__swc_fn_4fa09e82_000082_9f4f5092>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_4fa09e82_000090_9a1d717d+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_4fa09e82_000090_9a1d717d+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_4fa09e82_000090_9a1d717d+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_4fa09e82_000090_9a1d717d+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_4fa09e82_000090_9a1d717d>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_4fa09e82_000090_9a1d717d+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_4fa09e82_000090_9a1d717d+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_4fa09e82_000090_9a1d717d+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_4fa09e82_000090_9a1d717d+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_4fa09e82_000090_9a1d717d+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_4fa09e82_000090_9a1d717d+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_4fa09e82_000090_9a1d717d+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_4fa09e82_000090_9a1d717d+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_4fa09e82_000090_9a1d717d+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_4fa09e82_000090_9a1d717d+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_4fa09e82_000090_9a1d717d+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_4fa09e82_000090_9a1d717d+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_4fa09e82_000090_9a1d717d+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_4fa09e82_000090_9a1d717d+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_4fa09e82_000090_9a1d717d+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_4fa09e82_000090_9a1d717d+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   40ec70 <__swc_fn_4fa09e82_000148_c9c6528e>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_4fa09e82_000090_9a1d717d+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_4fa09e82_000090_9a1d717d>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_4fa09e82_000090_9a1d717d+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_4fa09e82_000090_9a1d717d+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_4fa09e82_000090_9a1d717d+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   40ec70 <__swc_fn_4fa09e82_000148_c9c6528e>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   40ec70 <__swc_fn_4fa09e82_000148_c9c6528e>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_4fa09e82_000093_344f5089>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40dc90 <__swc_fn_4fa09e82_000091_e6773530>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_4fa09e82_000093_344f5089+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_4fa09e82_000093_344f5089+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   409d40 <__swc_fn_4fa09e82_000138_899a611e>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_4fa09e82_000093_344f5089+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_4fa09e82+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   409870 <__swc_fn_4fa09e82_000117_3499f7d6>
  408959:	call   411420 <__swc_fn_4fa09e82_000119_2b35b5e0>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_4fa09e82_000096_f879630a>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40896f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  408975:	vzeroupper
  408978:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40897e:	mov    QWORD PTR [rsp+0x48],rdx
  408983:	mov    rax,r8
  408986:	cmp    r8,0x1
  40898a:	mov    edx,0x1
  40898f:	cmovb  rax,rdx
  408993:	mov    QWORD PTR [rsp+0x50],rax
  408998:	mov    rbx,QWORD PTR [rcx+0x8]
  40899c:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a0:	mov    rcx,QWORD PTR [rcx]
  4089a3:	lea    rdx,[rsp+0x8]
  4089a8:	call   rbx
  4089aa:	add    rsp,0x70
  4089ae:	pop    rbx
  4089af:	ret

00000000004089b0 <__swc_fn_4fa09e82_000099_6e0faaee>:
  4089b0:	push   rbx
  4089b1:	push   rsi
  4089b2:	push   rdi
  4089b3:	sub    rsp,0x30
  4089b7:	mov    rbx,rcx
  4089ba:	test   rcx,rcx
  4089bd:	je     4089d2 <__swc_fn_4fa09e82_000099_6e0faaee+0x22>
  4089bf:	mov    rcx,rbx
  4089c2:	mov    edx,0x1
  4089c7:	call   408200 <__swc_fn_4fa09e82_000078_5a70c27a>
  4089cc:	cmp    rax,0x1
  4089d0:	je     4089da <__swc_fn_4fa09e82_000099_6e0faaee+0x2a>
  4089d2:	add    rsp,0x30
  4089d6:	pop    rdi
  4089d7:	pop    rsi
  4089d8:	pop    rbx
  4089d9:	ret
  4089da:	lea    rsi,[rsp+0x8]
  4089df:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089e4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089ea:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  4089ef:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4089f5:	mov    rax,QWORD PTR [rsp+0x20]
  4089fa:	test   rax,rax
  4089fd:	je     408a13 <__swc_fn_4fa09e82_000099_6e0faaee+0x63>
  4089ff:	test   DWORD PTR [rax+0x28],0x400000
  408a06:	je     408a13 <__swc_fn_4fa09e82_000099_6e0faaee+0x63>
  408a08:	mov    rcx,QWORD PTR [rax+0x30]
  408a0c:	test   rcx,rcx
  408a0f:	cmovne rax,rcx
  408a13:	mov    edi,DWORD PTR [rax+0x20]
  408a16:	lea    rcx,[rsp+0x18]
  408a1b:	call   40de70 <__swc_fn_4fa09e82_000100_2ef16a3e>
  408a20:	mov    rcx,rsi
  408a23:	mov    rdx,QWORD PTR [rsp+0x18]
  408a28:	mov    r8,rdi
  408a2b:	call   408960 <__swc_fn_4fa09e82_000096_f879630a>
  408a30:	mov    rcx,QWORD PTR [rbx+0x28]
  408a34:	call   410b40 <__swc_fn_4fa09e82_000098_d9d80f1a>
  408a39:	mov    rcx,rsi
  408a3c:	mov    rdx,rbx
  408a3f:	mov    r8d,0x30
  408a45:	call   408960 <__swc_fn_4fa09e82_000096_f879630a>
  408a4a:	add    rsp,0x30
  408a4e:	pop    rdi
  408a4f:	pop    rsi
  408a50:	pop    rbx
  408a51:	ret
	...

0000000000408a60 <__swc_fn_4fa09e82_000102_29a1093a>:
  408a60:	push   rbp
  408a61:	push   rbx
  408a62:	push   rsi
  408a63:	push   rdi
  408a64:	push   r12
  408a66:	push   r13
  408a68:	push   r14
  408a6a:	push   r15
  408a6c:	sub    rsp,0x500
  408a73:	mov    rbp,rsp
  408a76:	mov    rbx,rsp
  408a79:	mov    rsi,rdx
  408a7c:	mov    rdi,rcx
  408a7f:	mov    rcx,QWORD PTR [rip+0x1e2ba]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  408a86:	test   rcx,rcx
  408a89:	jne    408aa3 <__swc_fn_4fa09e82_000102_29a1093a+0x43>
  408a8b:	sub    rsp,0x8
  408a8f:	call   40f060 <__swc_fn_4fa09e82_000166_e09accff>
  408a94:	add    rsp,0x8
  408a98:	lea    rcx,[rax+0x1]
  408a9c:	mov    QWORD PTR [rip+0x1e29d],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  408aa3:	dec    rcx
  408aa6:	sub    rsp,0x8
  408aaa:	call   40b620 <__swc_fn_4fa09e82_000168_3130645d>
  408aaf:	add    rsp,0x8
  408ab3:	mov    r12,rax
  408ab6:	mov    QWORD PTR [rsp+0x4f0],rax
  408abe:	lea    rax,[rip+0xa83b]        # 413300 <__swc_rdata_base_4fa09e82+0x1f0>
  408ac5:	sub    rsp,0x20
  408ac9:	mov    rcx,rsp
  408acc:	mov    QWORD PTR [rcx],rax
  408acf:	lea    r13,[rip+0xa83a]        # 413310 <__swc_rdata_base_4fa09e82+0x200>
  408ad6:	mov    QWORD PTR [rcx+0x8],r13
  408ada:	mov    QWORD PTR [rcx+0x10],rsp
  408ade:	mov    QWORD PTR [rcx+0x18],0x1
  408ae6:	lea    rcx,[rsp+0x10]
  408aeb:	sub    rsp,0x8
  408aef:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  408af4:	add    rsp,0x8
  408af8:	add    rsp,0x20
  408afc:	lea    rax,[rip+0xa855]        # 413358 <__swc_rdata_base_4fa09e82+0x248>
  408b03:	sub    rsp,0x20
  408b07:	mov    rcx,rsp
  408b0a:	mov    QWORD PTR [rcx],rax
  408b0d:	mov    QWORD PTR [rcx+0x8],r13
  408b11:	mov    QWORD PTR [rcx+0x10],rsp
  408b15:	mov    QWORD PTR [rcx+0x18],0x1
  408b1d:	lea    rcx,[rsp+0x10]
  408b22:	sub    rsp,0x8
  408b26:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  408b2b:	add    rsp,0x8
  408b2f:	add    rsp,0x20
  408b33:	lea    r14,[rip+0xa82e]        # 413368 <__swc_rdata_base_4fa09e82+0x258>
  408b3a:	sub    rsp,0x50
  408b3e:	mov    rax,rsp
  408b41:	vmovups xmm0,XMMWORD PTR [rip+0xa957]        # 4134a0 <__swc_rdata_base_4fa09e82+0x390>
  408b49:	vmovups XMMWORD PTR [rax],xmm0
  408b4d:	mov    QWORD PTR [rax+0x10],rsp
  408b51:	mov    QWORD PTR [rax+0x18],r13
  408b55:	mov    QWORD PTR [rax+0x20],rdi
  408b59:	lea    rdi,[rip+0xa818]        # 413378 <__swc_rdata_base_4fa09e82+0x268>
  408b60:	mov    QWORD PTR [rax+0x28],rdi
  408b64:	mov    QWORD PTR [rax+0x30],r14
  408b68:	mov    QWORD PTR [rax+0x38],r13
  408b6c:	lea    rcx,[rsp+0x10]
  408b71:	mov    QWORD PTR [rax+0x40],rcx
  408b75:	mov    QWORD PTR [rax+0x48],0x3
  408b7d:	lea    rcx,[rsp+0x40]
  408b82:	sub    rsp,0x8
  408b86:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  408b8b:	add    rsp,0x8
  408b8f:	add    rsp,0x50
  408b93:	lea    rax,[rip+0xa826]        # 4133c0 <__swc_rdata_base_4fa09e82+0x2b0>
  408b9a:	sub    rsp,0x20
  408b9e:	mov    rcx,rsp
  408ba1:	mov    QWORD PTR [rcx],rax
  408ba4:	mov    QWORD PTR [rcx+0x8],r13
  408ba8:	mov    QWORD PTR [rcx+0x10],rsp
  408bac:	mov    QWORD PTR [rcx+0x18],0x1
  408bb4:	lea    rcx,[rsp+0x10]
  408bb9:	sub    rsp,0x8
  408bbd:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  408bc2:	add    rsp,0x8
  408bc6:	add    rsp,0x20
  408bca:	mov    eax,DWORD PTR [rsi+0x20]
  408bcd:	mov    ecx,DWORD PTR [rsi+0x24]
  408bd0:	sub    rsp,0xa0
  408bd7:	mov    rdx,rsp
  408bda:	mov    QWORD PTR [rdx+0x30],rsi
  408bde:	mov    QWORD PTR [rdx+0x38],rdi
  408be2:	vmovups xmm0,XMMWORD PTR [rip+0xa84e]        # 413438 <__swc_rdata_base_4fa09e82+0x328>
  408bea:	vmovups XMMWORD PTR [rdx],xmm0
  408bee:	mov    QWORD PTR [rdx+0x40],rsp
  408bf2:	mov    QWORD PTR [rdx+0x48],r13
  408bf6:	mov    DWORD PTR [rdx+0x10],eax
  408bf9:	lea    rax,[rsp+0x10]
  408bfe:	mov    QWORD PTR [rdx+0x50],rax
  408c02:	lea    rax,[rip+0xa7c7]        # 4133d0 <__swc_rdata_base_4fa09e82+0x2c0>
  408c09:	mov    QWORD PTR [rdx+0x58],rax
  408c0d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c12:	lea    r8,[rsp+0x18]
  408c17:	mov    QWORD PTR [rdx+0x60],r8
  408c1b:	mov    QWORD PTR [rdx+0x68],r13
  408c1f:	mov    DWORD PTR [rdx+0x28],ecx
  408c22:	lea    rcx,[rdx+0x28]
  408c26:	mov    QWORD PTR [rdx+0x70],rcx
  408c2a:	mov    QWORD PTR [rdx+0x78],rax
  408c2e:	mov    QWORD PTR [rdx+0x80],r14
  408c35:	mov    QWORD PTR [rdx+0x88],r13
  408c3c:	lea    rax,[rdx+0x30]
  408c40:	mov    QWORD PTR [rdx+0x90],rax
  408c47:	mov    QWORD PTR [rdx+0x98],0x6
  408c52:	lea    rcx,[rdx+0x90]
  408c59:	sub    rsp,0x8
  408c5d:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  408c62:	add    rsp,0x8
  408c66:	add    rsp,0xa0
  408c6d:	sub    rsp,0x20
  408c71:	mov    rax,rsp
  408c74:	mov    QWORD PTR [rax],r14
  408c77:	mov    QWORD PTR [rax+0x8],r13
  408c7b:	mov    QWORD PTR [rax+0x10],rsp
  408c7f:	mov    QWORD PTR [rax+0x18],0x1
  408c87:	lea    rcx,[rsp+0x10]
  408c8c:	sub    rsp,0x8
  408c90:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  408c95:	add    rsp,0x8
  408c99:	add    rsp,0x20
  408c9d:	mov    eax,DWORD PTR [r12+0x9ac]
  408ca5:	test   eax,eax
  408ca7:	je     408ee0 <__swc_fn_4fa09e82_000102_29a1093a+0x480>
  408cad:	lea    rax,[rip+0xa764]        # 413418 <__swc_rdata_base_4fa09e82+0x308>
  408cb4:	sub    rsp,0x20
  408cb8:	mov    rcx,rsp
  408cbb:	mov    QWORD PTR [rcx],rax
  408cbe:	mov    QWORD PTR [rcx+0x8],r13
  408cc2:	mov    QWORD PTR [rcx+0x10],rsp
  408cc6:	mov    QWORD PTR [rcx+0x18],0x1
  408cce:	lea    rcx,[rsp+0x10]
  408cd3:	sub    rsp,0x8
  408cd7:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  408cdc:	add    rsp,0x8
  408ce0:	add    rsp,0x20
  408ce4:	mov    eax,DWORD PTR [r12+0x9ac]
  408cec:	dec    eax
  408cee:	mov    esi,eax
  408cf0:	test   esi,esi
  408cf2:	jl     408eb0 <__swc_fn_4fa09e82_000102_29a1093a+0x450>
  408cf8:	jmp    408d04 <__swc_fn_4fa09e82_000102_29a1093a+0x2a4>
  408cfa:	nop    WORD PTR [rax+rax*1+0x0]
  408d00:	dec    esi
  408d02:	jmp    408cf0 <__swc_fn_4fa09e82_000102_29a1093a+0x290>
  408d04:	lea    rax,[rip+0xa71d]        # 413428 <__swc_rdata_base_4fa09e82+0x318>
  408d0b:	sub    rsp,0x20
  408d0f:	mov    rcx,rsp
  408d12:	mov    QWORD PTR [rcx],rax
  408d15:	mov    QWORD PTR [rcx+0x8],r13
  408d19:	mov    QWORD PTR [rcx+0x10],rsp
  408d1d:	mov    QWORD PTR [rcx+0x18],0x1
  408d25:	lea    rcx,[rsp+0x10]
  408d2a:	sub    rsp,0x8
  408d2e:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  408d33:	add    rsp,0x8
  408d37:	add    rsp,0x20
  408d3b:	movsxd rax,esi
  408d3e:	imul   r15,rax,0x30
  408d42:	add    r15,r12
  408d45:	add    r15,0xf8
  408d4c:	sub    rsp,0x20
  408d50:	mov    rax,rsp
  408d53:	mov    QWORD PTR [rax],r15
  408d56:	mov    QWORD PTR [rax+0x8],rdi
  408d5a:	mov    QWORD PTR [rax+0x10],rsp
  408d5e:	mov    QWORD PTR [rax+0x18],0x1
  408d66:	lea    rcx,[rsp+0x10]
  408d6b:	sub    rsp,0x8
  408d6f:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  408d74:	add    rsp,0x8
  408d78:	add    rsp,0x20
  408d7c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408d84:	lea    rsi,[rip+0xa6ad]        # 413438 <__swc_rdata_base_4fa09e82+0x328>
  408d8b:	sub    rsp,0x20
  408d8f:	mov    rax,rsp
  408d92:	mov    QWORD PTR [rax],rsi
  408d95:	mov    QWORD PTR [rax+0x8],r13
  408d99:	mov    QWORD PTR [rax+0x10],rsp
  408d9d:	mov    QWORD PTR [rax+0x18],0x1
  408da5:	lea    rcx,[rsp+0x10]
  408daa:	sub    rsp,0x8
  408dae:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  408db3:	add    rsp,0x8
  408db7:	add    rsp,0x20
  408dbb:	sub    rsp,0x30
  408dbf:	mov    rax,rsp
  408dc2:	mov    ecx,DWORD PTR [r15+0x20]
  408dc6:	mov    QWORD PTR [rax],rcx
  408dc9:	mov    QWORD PTR [rax+0x8],rsp
  408dcd:	lea    rdi,[rip+0xa674]        # 413448 <__swc_rdata_base_4fa09e82+0x338>
  408dd4:	mov    QWORD PTR [rax+0x10],rdi
  408dd8:	lea    rcx,[rsp+0x8]
  408ddd:	mov    QWORD PTR [rax+0x18],rcx
  408de1:	mov    QWORD PTR [rax+0x20],0x1
  408de9:	lea    rcx,[rsp+0x18]
  408dee:	sub    rsp,0x8
  408df2:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  408df7:	add    rsp,0x8
  408dfb:	add    rsp,0x30
  408dff:	sub    rsp,0x20
  408e03:	mov    rax,rsp
  408e06:	mov    QWORD PTR [rax],rsi
  408e09:	mov    QWORD PTR [rax+0x8],r13
  408e0d:	mov    QWORD PTR [rax+0x10],rsp
  408e11:	mov    QWORD PTR [rax+0x18],0x1
  408e19:	lea    rcx,[rsp+0x10]
  408e1e:	sub    rsp,0x8
  408e22:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  408e27:	add    rsp,0x8
  408e2b:	add    rsp,0x20
  408e2f:	sub    rsp,0x30
  408e33:	mov    rax,rsp
  408e36:	mov    ecx,DWORD PTR [r15+0x24]
  408e3a:	mov    QWORD PTR [rax],rcx
  408e3d:	mov    QWORD PTR [rax+0x8],rsp
  408e41:	mov    QWORD PTR [rax+0x10],rdi
  408e45:	lea    rcx,[rsp+0x8]
  408e4a:	mov    QWORD PTR [rax+0x18],rcx
  408e4e:	mov    QWORD PTR [rax+0x20],0x1
  408e56:	lea    rcx,[rsp+0x18]
  408e5b:	sub    rsp,0x8
  408e5f:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  408e64:	add    rsp,0x8
  408e68:	add    rsp,0x30
  408e6c:	sub    rsp,0x20
  408e70:	mov    rax,rsp
  408e73:	mov    QWORD PTR [rax],r14
  408e76:	mov    QWORD PTR [rax+0x8],r13
  408e7a:	mov    QWORD PTR [rax+0x10],rsp
  408e7e:	mov    QWORD PTR [rax+0x18],0x1
  408e86:	lea    rcx,[rsp+0x10]
  408e8b:	sub    rsp,0x8
  408e8f:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  408e94:	add    rsp,0x8
  408e98:	add    rsp,0x20
  408e9c:	lea    rdi,[rip+0xa4d5]        # 413378 <__swc_rdata_base_4fa09e82+0x268>
  408ea3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408eab:	jmp    408d00 <__swc_fn_4fa09e82_000102_29a1093a+0x2a0>
  408eb0:	sub    rsp,0x20
  408eb4:	mov    rax,rsp
  408eb7:	mov    QWORD PTR [rax],r14
  408eba:	mov    QWORD PTR [rax+0x8],r13
  408ebe:	mov    QWORD PTR [rax+0x10],rsp
  408ec2:	mov    QWORD PTR [rax+0x18],0x1
  408eca:	lea    rcx,[rsp+0x10]
  408ecf:	sub    rsp,0x8
  408ed3:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  408ed8:	add    rsp,0x8
  408edc:	add    rsp,0x20
  408ee0:	lea    rax,[rbx+0x28]
  408ee4:	mov    rcx,rax
  408ee7:	mov    QWORD PTR [rbx+0x28],0x0
  408eef:	mov    QWORD PTR [rbx+0x30],0x0
  408ef7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408efc:	add    rcx,0x10
  408f00:	mov    edx,0x1f
  408f05:	cs nop WORD PTR [rax+rax*1+0x0]
  408f0f:	nop
  408f10:	vmovups XMMWORD PTR [rcx],xmm0
  408f14:	add    rcx,0x10
  408f18:	sub    rdx,0x1
  408f1c:	jne    408f10 <__swc_fn_4fa09e82_000102_29a1093a+0x4b0>
  408f1e:	lea    rsi,[rbx+0x228]
  408f25:	xor    ecx,ecx
  408f27:	cs nop WORD PTR [rax+rax*1+0x0]
  408f31:	cs nop WORD PTR [rax+rax*1+0x0]
  408f3b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f40:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f45:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f4a:	add    rcx,0x10
  408f4e:	cmp    rcx,0x200
  408f55:	jne    408f40 <__swc_fn_4fa09e82_000102_29a1093a+0x4e0>
  408f57:	mov    eax,DWORD PTR [r12+0xbc8]
  408f5f:	lea    rcx,[r12+0x9c8]
  408f67:	mov    QWORD PTR [rbx+0x428],rcx
  408f6e:	mov    QWORD PTR [rbx+0x430],rax
  408f75:	lea    rdi,[rbx+0x438]
  408f7c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408f84:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408f8c:	mov    eax,DWORD PTR [r12+0xbc8]
  408f94:	test   eax,eax
  408f96:	jne    408fe3 <__swc_fn_4fa09e82_000102_29a1093a+0x583>
  408f98:	lea    rax,[rbx+0x448]
  408f9f:	mov    QWORD PTR [rbx+0x448],rsi
  408fa6:	mov    QWORD PTR [rax+0x8],0x40
  408fae:	mov    ecx,0x1
  408fb3:	mov    rdx,rax
  408fb6:	sub    rsp,0x8
  408fba:	call   409980 <__swc_fn_4fa09e82_000120_18cd3882>
  408fbf:	add    rsp,0x8
  408fc3:	mov    QWORD PTR [rbx+0x460],rsi
  408fca:	mov    ecx,eax
  408fcc:	mov    QWORD PTR [rbx+0x468],rcx
  408fd3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408fdb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fe3:	mov    rsi,QWORD PTR [rbx+0x438]
  408fea:	mov    rax,QWORD PTR [rbx+0x440]
  408ff1:	mov    r15,rax
  408ff4:	xor    r12d,r12d
  408ff7:	test   r15,r15
  408ffa:	je     4090b0 <__swc_fn_4fa09e82_000102_29a1093a+0x650>
  409000:	mov    rax,QWORD PTR [rsi+r12*8]
  409004:	test   rax,rax
  409007:	je     409026 <__swc_fn_4fa09e82_000102_29a1093a+0x5c6>
  409009:	lea    rcx,[rbx+0x4b8]
  409010:	mov    rdx,rax
  409013:	sub    rsp,0x8
  409017:	call   40edd0 <__swc_fn_4fa09e82_000163_edb9cf73>
  40901c:	add    rsp,0x8
  409020:	mov    al,BYTE PTR [rax]
  409022:	test   al,al
  409024:	jne    409032 <__swc_fn_4fa09e82_000102_29a1093a+0x5d2>
  409026:	add    r12,0x1
  40902a:	sub    r15,0x1
  40902e:	jne    409000 <__swc_fn_4fa09e82_000102_29a1093a+0x5a0>
  409030:	jmp    4090b0 <__swc_fn_4fa09e82_000102_29a1093a+0x650>
  409032:	lea    rax,[rip+0xa457]        # 413490 <__swc_rdata_base_4fa09e82+0x380>
  409039:	sub    rsp,0x20
  40903d:	mov    rcx,rsp
  409040:	mov    QWORD PTR [rcx],rax
  409043:	mov    QWORD PTR [rcx+0x8],r13
  409047:	mov    QWORD PTR [rcx+0x10],rsp
  40904b:	mov    QWORD PTR [rcx+0x18],0x1
  409053:	lea    rcx,[rsp+0x10]
  409058:	sub    rsp,0x8
  40905c:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  409061:	add    rsp,0x8
  409065:	add    rsp,0x20
  409069:	mov    rcx,rdi
  40906c:	xor    edx,edx
  40906e:	mov    al,0x1
  409070:	mov    r8,rax
  409073:	sub    rsp,0x8
  409077:	call   411cc0 <__swc_fn_4fa09e82_000164_5fbed98a>
  40907c:	add    rsp,0x8
  409080:	sub    rsp,0x20
  409084:	mov    rax,rsp
  409087:	mov    QWORD PTR [rax],r14
  40908a:	mov    QWORD PTR [rax+0x8],r13
  40908e:	mov    QWORD PTR [rax+0x10],rsp
  409092:	mov    QWORD PTR [rax+0x18],0x1
  40909a:	lea    rcx,[rsp+0x10]
  40909f:	sub    rsp,0x8
  4090a3:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  4090a8:	add    rsp,0x8
  4090ac:	add    rsp,0x20
  4090b0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090b8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090c4:	add    rsp,0x500
  4090cb:	pop    r15
  4090cd:	pop    r14
  4090cf:	pop    r13
  4090d1:	pop    r12
  4090d3:	pop    rdi
  4090d4:	pop    rsi
  4090d5:	pop    rbx
  4090d6:	pop    rbp
  4090d7:	ret
	...

00000000004090e0 <__swc_fn_4fa09e82_000105_84094be1>:
  4090e0:	test   r8,r8
  4090e3:	jne    4090e6 <__swc_fn_4fa09e82_000105_84094be1+0x6>
  4090e5:	ret
  4090e6:	xor    eax,eax
  4090e8:	movzx  r9d,dl
  4090ec:	movabs r10,0x101010101010101
  4090f6:	imul   r9,r10
  4090fa:	vmovq  xmm0,r9
  4090ff:	vpshufd xmm0,xmm0,0x44
  409104:	cs nop WORD PTR [rax+rax*1+0x0]
  40910e:	xchg   ax,ax
  409110:	mov    r10,r8
  409113:	sub    r10,rax
  409116:	cmp    r10,0x40
  40911a:	jb     40913d <__swc_fn_4fa09e82_000105_84094be1+0x5d>
  40911c:	lea    r10,[rcx+rax*1]
  409120:	vmovups XMMWORD PTR [r10],xmm0
  409125:	vmovups XMMWORD PTR [r10+0x10],xmm0
  40912b:	vmovups XMMWORD PTR [r10+0x20],xmm0
  409131:	vmovups XMMWORD PTR [r10+0x30],xmm0
  409137:	lea    rax,[rax+0x40]
  40913b:	jmp    409110 <__swc_fn_4fa09e82_000105_84094be1+0x30>
  40913d:	nop    DWORD PTR [rax]
  409140:	mov    r10,r8
  409143:	sub    r10,rax
  409146:	cmp    r10,0x10
  40914a:	jb     40915b <__swc_fn_4fa09e82_000105_84094be1+0x7b>
  40914c:	lea    r10,[rcx+rax*1]
  409150:	vmovups XMMWORD PTR [r10],xmm0
  409155:	lea    rax,[rax+0x10]
  409159:	jmp    409140 <__swc_fn_4fa09e82_000105_84094be1+0x60>
  40915b:	nop    DWORD PTR [rax+rax*1+0x0]
  409160:	mov    r10,r8
  409163:	sub    r10,rax
  409166:	cmp    r10,0x8
  40916a:	jb     409179 <__swc_fn_4fa09e82_000105_84094be1+0x99>
  40916c:	lea    r10,[rcx+rax*1]
  409170:	mov    QWORD PTR [r10],r9
  409173:	lea    rax,[rax+0x8]
  409177:	jmp    409160 <__swc_fn_4fa09e82_000105_84094be1+0x80>
  409179:	cmp    rax,r8
  40917c:	jae    40918b <__swc_fn_4fa09e82_000105_84094be1+0xab>
  40917e:	xchg   ax,ax
  409180:	mov    BYTE PTR [rcx+rax*1],dl
  409183:	inc    rax
  409186:	cmp    rax,r8
  409189:	jb     409180 <__swc_fn_4fa09e82_000105_84094be1+0xa0>
  40918b:	ret
  40918c:	add    BYTE PTR [rax],al
	...

0000000000409190 <__swc_fn_4fa09e82_000108_ff529476>:
  409190:	push   rbx
  409191:	push   r12
  409193:	push   rdi
  409194:	push   rsi
  409195:	push   r13
  409197:	push   r14
  409199:	push   r15
  40919b:	sub    rsp,0x170
  4091a2:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  4091ab:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  4091b4:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  4091bd:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  4091c6:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  4091cf:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  4091d8:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  4091e1:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  4091ea:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  4091f3:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  4091fc:	mov    ebx,edx
  4091fe:	mov    QWORD PTR [rsp+0xa8],rbx
  409206:	mov    r12d,ecx
  409209:	test   edx,edx
  40920b:	jne    409222 <__swc_fn_4fa09e82_000108_ff529476+0x92>
  40920d:	xor    eax,eax
  40920f:	add    rsp,0x170
  409216:	pop    r15
  409218:	pop    r14
  40921a:	pop    r13
  40921c:	pop    rsi
  40921d:	pop    rdi
  40921e:	pop    r12
  409220:	pop    rbx
  409221:	ret
  409222:	lea    rdi,[rip+0xa287]        # 4134b0 <__swc_rdata_base_4fa09e82+0x3a0>
  409229:	mov    esi,0x90000
  40922e:	xor    eax,eax
  409230:	call   407010 <open@plt>
  409235:	mov    r13,rax
  409238:	mov    QWORD PTR [rsp+0xb0],rax
  409240:	test   eax,eax
  409242:	jge    40924b <__swc_fn_4fa09e82_000108_ff529476+0xbb>
  409244:	xor    eax,eax
  409246:	jmp    409746 <__swc_fn_4fa09e82_000108_ff529476+0x5b6>
  40924b:	nop    DWORD PTR [rax+rax*1+0x0]
  409250:	movsxd rdi,r13d
  409253:	mov    esi,0x2
  409258:	xor    eax,eax
  40925a:	call   407020 <flock@plt>
  40925f:	test   eax,eax
  409261:	je     409280 <__swc_fn_4fa09e82_000108_ff529476+0xf0>
  409263:	xor    eax,eax
  409265:	call   407030 <__errno_location@plt>
  40926a:	cmp    DWORD PTR [rax],0x4
  40926d:	je     409250 <__swc_fn_4fa09e82_000108_ff529476+0xc0>
  40926f:	movsxd rdi,r13d
  409272:	xor    eax,eax
  409274:	call   407040 <close@plt>
  409279:	xor    eax,eax
  40927b:	jmp    409746 <__swc_fn_4fa09e82_000108_ff529476+0x5b6>
  409280:	lea    r14,[rsp+0x8]
  409285:	mov    QWORD PTR [rsp+0xb8],r14
  40928d:	vxorps xmm0,xmm0,xmm0
  409291:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409297:	mov    QWORD PTR [rsp+0x18],0x0
  4092a0:	mov    WORD PTR [rsp+0x20],0x0
  4092a7:	mov    DWORD PTR [r14],0x67617753
  4092ae:	mov    DWORD PTR [r14+0x4],0x2e74522e
  4092b6:	xor    eax,eax
  4092b8:	call   407050 <getpid@plt>
  4092bd:	mov    ecx,eax
  4092bf:	mov    eax,0x1c
  4092c4:	shrx   eax,ecx,eax
  4092c9:	and    eax,0xf
  4092cc:	mov    rdx,QWORD PTR [rip+0xa1fd]        # 4134d0 <__swc_rdata_base_4fa09e82+0x3c0>
  4092d3:	mov    al,BYTE PTR [rdx+rax*1]
  4092d6:	rex mov BYTE PTR [rsp+0x10],al
  4092db:	mov    eax,0x1c
  4092e0:	shrx   eax,r12d,eax
  4092e5:	and    eax,0xf
  4092e8:	mov    al,BYTE PTR [rdx+rax*1]
  4092eb:	rex mov BYTE PTR [rsp+0x19],al
  4092f0:	mov    eax,0x18
  4092f5:	shrx   eax,ecx,eax
  4092fa:	and    eax,0xf
  4092fd:	mov    al,BYTE PTR [rdx+rax*1]
  409300:	rex mov BYTE PTR [rsp+0x11],al
  409305:	mov    eax,0x18
  40930a:	shrx   eax,r12d,eax
  40930f:	and    eax,0xf
  409312:	mov    al,BYTE PTR [rdx+rax*1]
  409315:	rex mov BYTE PTR [rsp+0x1a],al
  40931a:	mov    eax,0x14
  40931f:	shrx   eax,ecx,eax
  409324:	and    eax,0xf
  409327:	mov    al,BYTE PTR [rdx+rax*1]
  40932a:	rex mov BYTE PTR [rsp+0x12],al
  40932f:	mov    eax,0x14
  409334:	shrx   eax,r12d,eax
  409339:	and    eax,0xf
  40933c:	mov    al,BYTE PTR [rdx+rax*1]
  40933f:	rex mov BYTE PTR [rsp+0x1b],al
  409344:	mov    eax,0x10
  409349:	shrx   eax,ecx,eax
  40934e:	and    eax,0xf
  409351:	mov    al,BYTE PTR [rdx+rax*1]
  409354:	rex mov BYTE PTR [rsp+0x13],al
  409359:	mov    eax,0x10
  40935e:	shrx   eax,r12d,eax
  409363:	and    eax,0xf
  409366:	mov    al,BYTE PTR [rdx+rax*1]
  409369:	rex mov BYTE PTR [rsp+0x1c],al
  40936e:	mov    eax,0xc
  409373:	shrx   eax,ecx,eax
  409378:	and    eax,0xf
  40937b:	mov    al,BYTE PTR [rdx+rax*1]
  40937e:	rex mov BYTE PTR [rsp+0x14],al
  409383:	mov    eax,0xc
  409388:	shrx   eax,r12d,eax
  40938d:	and    eax,0xf
  409390:	mov    al,BYTE PTR [rdx+rax*1]
  409393:	rex mov BYTE PTR [rsp+0x1d],al
  409398:	mov    eax,0x8
  40939d:	shrx   eax,ecx,eax
  4093a2:	and    eax,0xf
  4093a5:	mov    al,BYTE PTR [rdx+rax*1]
  4093a8:	rex mov BYTE PTR [rsp+0x15],al
  4093ad:	mov    eax,0x8
  4093b2:	shrx   eax,r12d,eax
  4093b7:	and    eax,0xf
  4093ba:	mov    al,BYTE PTR [rdx+rax*1]
  4093bd:	rex mov BYTE PTR [rsp+0x1e],al
  4093c2:	mov    eax,0x4
  4093c7:	shrx   eax,ecx,eax
  4093cc:	and    eax,0xf
  4093cf:	mov    al,BYTE PTR [rdx+rax*1]
  4093d2:	rex mov BYTE PTR [rsp+0x16],al
  4093d7:	mov    eax,0x4
  4093dc:	shrx   eax,r12d,eax
  4093e1:	and    eax,0xf
  4093e4:	mov    al,BYTE PTR [rdx+rax*1]
  4093e7:	rex mov BYTE PTR [rsp+0x1f],al
  4093ec:	xor    eax,eax
  4093ee:	shrx   eax,ecx,eax
  4093f3:	and    eax,0xf
  4093f6:	mov    al,BYTE PTR [rdx+rax*1]
  4093f9:	rex mov BYTE PTR [rsp+0x17],al
  4093fe:	xor    eax,eax
  409400:	shrx   eax,r12d,eax
  409405:	and    eax,0xf
  409408:	mov    al,BYTE PTR [rdx+rax*1]
  40940b:	rex mov BYTE PTR [rsp+0x20],al
  409410:	mov    BYTE PTR [r14+0x10],0x2e
  409415:	lea    r12,[rsp+0x22]
  40941a:	vxorps xmm0,xmm0,xmm0
  40941e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  409424:	mov    DWORD PTR [r12],0x6d656d2f
  40942c:	mov    WORD PTR [r12+0x4],0x6466
  409434:	mov    BYTE PTR [r12+0x6],0x3a
  40943a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409440:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  409446:	mov    rax,QWORD PTR [rsp+0x18]
  40944b:	mov    QWORD PTR [rsp+0x39],rax
  409450:	rex mov al,BYTE PTR [rsp+0x20]
  409455:	rex mov BYTE PTR [rsp+0x41],al
  40945a:	mov    DWORD PTR [r12+0x20],0x65642820
  409463:	mov    DWORD PTR [r12+0x24],0x6574656c
  40946c:	mov    WORD PTR [r12+0x28],0x2964
  409474:	lea    rdi,[rip+0xa040]        # 4134bb <__swc_rdata_base_4fa09e82+0x3ab>
  40947b:	xor    eax,eax
  40947d:	call   407060 <opendir@plt>
  409482:	mov    r15,rax
  409485:	test   rax,rax
  409488:	jne    40949b <__swc_fn_4fa09e82_000108_ff529476+0x30b>
  40948a:	movsxd rdi,r13d
  40948d:	xor    eax,eax
  40948f:	call   407040 <close@plt>
  409494:	xor    eax,eax
  409496:	jmp    409746 <__swc_fn_4fa09e82_000108_ff529476+0x5b6>
  40949b:	mov    rdi,r15
  40949e:	xor    eax,eax
  4094a0:	call   407070 <dirfd@plt>
  4094a5:	lea    r14,[rsp+0x54]
  4094aa:	mov    DWORD PTR [rsp+0x54],eax
  4094ae:	lea    rbx,[rsp+0x58]
  4094b3:	cs nop WORD PTR [rax+rax*1+0x0]
  4094bd:	nop    DWORD PTR [rax]
  4094c0:	mov    rdi,r15
  4094c3:	xor    eax,eax
  4094c5:	call   407080 <readdir@plt>
  4094ca:	test   rax,rax
  4094cd:	jne    4094e4 <__swc_fn_4fa09e82_000108_ff529476+0x354>
  4094cf:	mov    r12,QWORD PTR [rsp+0xa8]
  4094d7:	mov    r13,QWORD PTR [rsp+0xb0]
  4094df:	jmp    40966a <__swc_fn_4fa09e82_000108_ff529476+0x4da>
  4094e4:	vxorps xmm0,xmm0,xmm0
  4094e8:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  4094ee:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  4094f4:	vzeroupper
  4094f7:	lea    r13,[rax+0x13]
  4094fb:	mov    rax,r14
  4094fe:	movsxd rdi,DWORD PTR [rax]
  409501:	mov    rsi,r13
  409504:	mov    rdx,rbx
  409507:	mov    ecx,0x40
  40950c:	xor    eax,eax
  40950e:	call   407090 <readlinkat@plt>
  409513:	cmp    rax,0x2a
  409517:	jne    4094c0 <__swc_fn_4fa09e82_000108_ff529476+0x330>
  409519:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40951f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  409525:	vptest xmm0,xmm0
  40952a:	jne    40955a <__swc_fn_4fa09e82_000108_ff529476+0x3ca>
  40952c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  409532:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  409538:	vptest xmm0,xmm0
  40953d:	jne    40955a <__swc_fn_4fa09e82_000108_ff529476+0x3ca>
  40953f:	mov    rcx,QWORD PTR [rsp+0x42]
  409544:	cmp    QWORD PTR [rsp+0x78],rcx
  409549:	jne    40955a <__swc_fn_4fa09e82_000108_ff529476+0x3ca>
  40954b:	mov    cx,WORD PTR [rsp+0x4a]
  409550:	cmp    WORD PTR [rsp+0x80],cx
  409558:	je     409584 <__swc_fn_4fa09e82_000108_ff529476+0x3f4>
  40955a:	mov    rax,rbx
  40955d:	mov    rcx,r12
  409560:	movzx  edx,BYTE PTR [rax]
  409563:	movzx  r8d,BYTE PTR [rcx]
  409567:	cmp    rdx,r8
  40956a:	jne    409576 <__swc_fn_4fa09e82_000108_ff529476+0x3e6>
  40956c:	add    rax,0x1
  409570:	add    rcx,0x1
  409574:	jmp    409560 <__swc_fn_4fa09e82_000108_ff529476+0x3d0>
  409576:	mov    rax,rdx
  409579:	sub    rax,r8
  40957c:	test   eax,eax
  40957e:	jne    4094c0 <__swc_fn_4fa09e82_000108_ff529476+0x330>
  409584:	movsxd rdi,DWORD PTR [r14]
  409587:	mov    rsi,r13
  40958a:	mov    edx,0x80002
  40958f:	xor    eax,eax
  409591:	call   4070a0 <openat@plt>
  409596:	lea    rbx,[rsp+0x98]
  40959e:	mov    DWORD PTR [rsp+0x98],eax
  4095a5:	test   eax,eax
  4095a7:	mov    r13,QWORD PTR [rsp+0xb0]
  4095af:	jge    4095d4 <__swc_fn_4fa09e82_000108_ff529476+0x444>
  4095b1:	mov    rdi,r15
  4095b4:	xor    eax,eax
  4095b6:	call   4070b0 <closedir@plt>
  4095bb:	mov    r13,QWORD PTR [rsp+0xb0]
  4095c3:	movsxd rdi,r13d
  4095c6:	xor    eax,eax
  4095c8:	call   407040 <close@plt>
  4095cd:	xor    eax,eax
  4095cf:	jmp    409746 <__swc_fn_4fa09e82_000108_ff529476+0x5b6>
  4095d4:	mov    rax,rbx
  4095d7:	movsxd rdi,DWORD PTR [rax]
  4095da:	xor    esi,esi
  4095dc:	mov    edx,0x2
  4095e1:	xor    eax,eax
  4095e3:	call   4070c0 <lseek@plt>
  4095e8:	mov    r12,QWORD PTR [rsp+0xa8]
  4095f0:	cmp    rax,r12
  4095f3:	je     40961a <__swc_fn_4fa09e82_000108_ff529476+0x48a>
  4095f5:	movsxd rdi,DWORD PTR [rbx]
  4095f8:	xor    eax,eax
  4095fa:	call   407040 <close@plt>
  4095ff:	mov    rdi,r15
  409602:	xor    eax,eax
  409604:	call   4070b0 <closedir@plt>
  409609:	movsxd rdi,r13d
  40960c:	xor    eax,eax
  40960e:	call   407040 <close@plt>
  409613:	xor    eax,eax
  409615:	jmp    409746 <__swc_fn_4fa09e82_000108_ff529476+0x5b6>
  40961a:	xor    edi,edi
  40961c:	mov    rsi,r12
  40961f:	mov    edx,0x3
  409624:	mov    ecx,0x1
  409629:	mov    rax,rbx
  40962c:	movsxd r8,DWORD PTR [rax]
  40962f:	xor    r9d,r9d
  409632:	xor    eax,eax
  409634:	call   4070d0 <mmap@plt>
  409639:	xor    r12d,r12d
  40963c:	cmp    rax,0xffffffffffffffff
  409640:	cmovne r12,rax
  409644:	movsxd rdi,DWORD PTR [rbx]
  409647:	xor    eax,eax
  409649:	call   407040 <close@plt>
  40964e:	mov    rdi,r15
  409651:	xor    eax,eax
  409653:	call   4070b0 <closedir@plt>
  409658:	movsxd rdi,r13d
  40965b:	xor    eax,eax
  40965d:	call   407040 <close@plt>
  409662:	mov    rax,r12
  409665:	jmp    409746 <__swc_fn_4fa09e82_000108_ff529476+0x5b6>
  40966a:	mov    r14,QWORD PTR [rsp+0xb8]
  409672:	mov    rdi,r14
  409675:	mov    esi,0x1
  40967a:	xor    eax,eax
  40967c:	call   4070e0 <memfd_create@plt>
  409681:	lea    rbx,[rsp+0x9c]
  409689:	mov    DWORD PTR [rsp+0x9c],eax
  409690:	test   eax,eax
  409692:	jge    4096af <__swc_fn_4fa09e82_000108_ff529476+0x51f>
  409694:	mov    rdi,r15
  409697:	xor    eax,eax
  409699:	call   4070b0 <closedir@plt>
  40969e:	movsxd rdi,r13d
  4096a1:	xor    eax,eax
  4096a3:	call   407040 <close@plt>
  4096a8:	xor    eax,eax
  4096aa:	jmp    409746 <__swc_fn_4fa09e82_000108_ff529476+0x5b6>
  4096af:	mov    rax,rbx
  4096b2:	movsxd rdi,DWORD PTR [rax]
  4096b5:	mov    rsi,r12
  4096b8:	xor    eax,eax
  4096ba:	call   4070f0 <ftruncate@plt>
  4096bf:	test   eax,eax
  4096c1:	je     4096e5 <__swc_fn_4fa09e82_000108_ff529476+0x555>
  4096c3:	movsxd rdi,DWORD PTR [rbx]
  4096c6:	xor    eax,eax
  4096c8:	call   407040 <close@plt>
  4096cd:	mov    rdi,r15
  4096d0:	xor    eax,eax
  4096d2:	call   4070b0 <closedir@plt>
  4096d7:	movsxd rdi,r13d
  4096da:	xor    eax,eax
  4096dc:	call   407040 <close@plt>
  4096e1:	xor    eax,eax
  4096e3:	jmp    409746 <__swc_fn_4fa09e82_000108_ff529476+0x5b6>
  4096e5:	xor    edi,edi
  4096e7:	mov    rsi,r12
  4096ea:	mov    edx,0x3
  4096ef:	mov    ecx,0x1
  4096f4:	mov    rax,rbx
  4096f7:	movsxd r8,DWORD PTR [rax]
  4096fa:	xor    r9d,r9d
  4096fd:	xor    eax,eax
  4096ff:	call   4070d0 <mmap@plt>
  409704:	mov    r12,rax
  409707:	cmp    rax,0xffffffffffffffff
  40970b:	jne    40972f <__swc_fn_4fa09e82_000108_ff529476+0x59f>
  40970d:	movsxd rdi,DWORD PTR [rbx]
  409710:	xor    eax,eax
  409712:	call   407040 <close@plt>
  409717:	mov    rdi,r15
  40971a:	xor    eax,eax
  40971c:	call   4070b0 <closedir@plt>
  409721:	movsxd rdi,r13d
  409724:	xor    eax,eax
  409726:	call   407040 <close@plt>
  40972b:	xor    eax,eax
  40972d:	jmp    409746 <__swc_fn_4fa09e82_000108_ff529476+0x5b6>
  40972f:	mov    rdi,r15
  409732:	xor    eax,eax
  409734:	call   4070b0 <closedir@plt>
  409739:	movsxd rdi,r13d
  40973c:	xor    eax,eax
  40973e:	call   407040 <close@plt>
  409743:	mov    rax,r12
  409746:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40974f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  409758:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  409761:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40976a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  409773:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40977c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  409785:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40978e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  409797:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  4097a0:	add    rsp,0x170
  4097a7:	pop    r15
  4097a9:	pop    r14
  4097ab:	pop    r13
  4097ad:	pop    rsi
  4097ae:	pop    rdi
  4097af:	pop    r12
  4097b1:	pop    rbx
  4097b2:	ret
	...

00000000004097c0 <__swc_fn_4fa09e82_000111_e606239a>:
  4097c0:	push   rsi
  4097c1:	push   rdi
  4097c2:	push   r12
  4097c4:	push   r13
  4097c6:	sub    rsp,0x8
  4097ca:	mov    rsi,r8
  4097cd:	mov    rdi,rcx
  4097d0:	mov    r12,rdx
  4097d3:	call   40dfc0 <__swc_fn_4fa09e82_000109_32416b9e>
  4097d8:	mov    r13,rax
  4097db:	test   rax,rax
  4097de:	jne    4097eb <__swc_fn_4fa09e82_000111_e606239a+0x2b>
  4097e0:	add    rsp,0x8
  4097e4:	pop    r13
  4097e6:	pop    r12
  4097e8:	pop    rdi
  4097e9:	pop    rsi
  4097ea:	ret
  4097eb:	mov    rcx,r13
  4097ee:	call   4117d0 <__swc_fn_4fa09e82_000134_c6de0049>
  4097f3:	mov    rax,QWORD PTR [r13+0x8]
  4097f7:	test   rax,rax
  4097fa:	je     409839 <__swc_fn_4fa09e82_000111_e606239a+0x79>
  4097fc:	nop    DWORD PTR [rax+0x0]
  409800:	lea    rcx,[rax+0x1000]
  409807:	cmp    rdi,rcx
  40980a:	jne    409831 <__swc_fn_4fa09e82_000111_e606239a+0x71>
  40980c:	cmp    r12,0x1000
  409813:	jb     409831 <__swc_fn_4fa09e82_000111_e606239a+0x71>
  409815:	test   sil,sil
  409818:	setne  cl
  40981b:	mov    BYTE PTR [rax+0x10],cl
  40981e:	mov    rcx,r13
  409821:	call   409d20 <__swc_fn_4fa09e82_000135_5696c87e>
  409826:	add    rsp,0x8
  40982a:	pop    r13
  40982c:	pop    r12
  40982e:	pop    rdi
  40982f:	pop    rsi
  409830:	ret
  409831:	mov    rax,QWORD PTR [rax]
  409834:	test   rax,rax
  409837:	jne    409800 <__swc_fn_4fa09e82_000111_e606239a+0x40>
  409839:	mov    rcx,r13
  40983c:	call   409d20 <__swc_fn_4fa09e82_000135_5696c87e>
  409841:	add    rsp,0x8
  409845:	pop    r13
  409847:	pop    r12
  409849:	pop    rdi
  40984a:	pop    rsi
  40984b:	ret
  40984c:	add    BYTE PTR [rax],al
	...

0000000000409850 <__swc_fn_4fa09e82_000114_25e345b1>:
  409850:	sub    rsp,0x8
  409854:	test   rcx,rcx
  409857:	jne    40985e <__swc_fn_4fa09e82_000114_25e345b1+0xe>
  409859:	add    rsp,0x8
  40985d:	ret
  40985e:	call   4112d0 <__swc_fn_4fa09e82_000116_259b5d5a>
  409863:	add    rsp,0x8
  409867:	ret
	...

0000000000409870 <__swc_fn_4fa09e82_000117_3499f7d6>:
  409870:	push   r12
  409872:	push   r13
  409874:	push   r14
  409876:	push   rdi
  409877:	push   rsi
  409878:	sub    rsp,0xc0
  40987f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409885:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40988b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409891:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409897:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40989d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4098a3:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4098a9:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4098b2:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4098bb:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4098c4:	mov    r12,QWORD PTR [rcx]
  4098c7:	test   r12,r12
  4098ca:	jne    4098dc <__swc_fn_4fa09e82_000117_3499f7d6+0x6c>
  4098cc:	add    rsp,0xc0
  4098d3:	pop    rsi
  4098d4:	pop    rdi
  4098d5:	pop    r14
  4098d7:	pop    r13
  4098d9:	pop    r12
  4098db:	ret
  4098dc:	xor    r13d,r13d
  4098df:	mov    r14,QWORD PTR [rcx+0x8]
  4098e3:	cs nop WORD PTR [rax+rax*1+0x0]
  4098ed:	nop    DWORD PTR [rax]
  4098f0:	cmp    r13,r14
  4098f3:	jae    40992b <__swc_fn_4fa09e82_000117_3499f7d6+0xbb>
  4098f5:	lea    rax,[r12+r13*1]
  4098f9:	mov    rcx,r14
  4098fc:	sub    rcx,r13
  4098ff:	mov    edi,0x1
  409904:	mov    rsi,rax
  409907:	mov    rdx,rcx
  40990a:	xor    eax,eax
  40990c:	call   407100 <write@plt>
  409911:	test   rax,rax
  409914:	jle    40991b <__swc_fn_4fa09e82_000117_3499f7d6+0xab>
  409916:	add    r13,rax
  409919:	jmp    4098f0 <__swc_fn_4fa09e82_000117_3499f7d6+0x80>
  40991b:	je     409929 <__swc_fn_4fa09e82_000117_3499f7d6+0xb9>
  40991d:	xor    eax,eax
  40991f:	call   407030 <__errno_location@plt>
  409924:	cmp    DWORD PTR [rax],0x4
  409927:	je     4098f0 <__swc_fn_4fa09e82_000117_3499f7d6+0x80>
  409929:	jmp    40992b <__swc_fn_4fa09e82_000117_3499f7d6+0xbb>
  40992b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409931:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409937:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40993d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409943:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409949:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40994f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409955:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40995e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409967:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409970:	add    rsp,0xc0
  409977:	pop    rsi
  409978:	pop    rdi
  409979:	pop    r14
  40997b:	pop    r13
  40997d:	pop    r12
  40997f:	ret

0000000000409980 <__swc_fn_4fa09e82_000120_18cd3882>:
  409980:	push   rbx
  409981:	push   r12
  409983:	push   rdi
  409984:	push   rsi
  409985:	sub    rsp,0x4a8
  40998c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  409995:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  40999e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  4099a7:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  4099b0:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  4099b9:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  4099c2:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  4099cb:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  4099d4:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  4099dd:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  4099e6:	mov    rbx,rdx
  4099e9:	mov    r12d,ecx
  4099ec:	vxorps xmm0,xmm0,xmm0
  4099f0:	xor    eax,eax
  4099f2:	cs nop WORD PTR [rax+rax*1+0x0]
  4099fc:	nop    DWORD PTR [rax+0x0]
  409a00:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  409a06:	add    rax,0x10
  409a0a:	cmp    rax,0x400
  409a11:	jne    409a00 <__swc_fn_4fa09e82_000120_18cd3882+0x80>
  409a13:	lea    rdi,[rsp+0x8]
  409a18:	mov    esi,0x80
  409a1d:	xor    eax,eax
  409a1f:	call   407110 <backtrace@plt>
  409a24:	test   eax,eax
  409a26:	jle    409a35 <__swc_fn_4fa09e82_000120_18cd3882+0xb5>
  409a28:	movsxd rax,eax
  409a2b:	lea    rcx,[r12+0x1]
  409a30:	cmp    rcx,rax
  409a33:	jb     409a39 <__swc_fn_4fa09e82_000120_18cd3882+0xb9>
  409a35:	xor    eax,eax
  409a37:	jmp    409a6a <__swc_fn_4fa09e82_000120_18cd3882+0xea>
  409a39:	mov    rcx,QWORD PTR [rbx+0x8]
  409a3d:	sub    rax,r12
  409a40:	lea    rsi,[rax-0x1]
  409a44:	cmp    rcx,rsi
  409a47:	cmovbe rsi,rcx
  409a4b:	lea    eax,[r12+0x1]
  409a50:	lea    rax,[rsp+rax*8+0x8]
  409a55:	mov    rcx,QWORD PTR [rbx]
  409a58:	mov    rdx,rax
  409a5b:	lea    r8,[rsi*8+0x0]
  409a63:	call   40dfa0 <__swc_fn_4fa09e82_000106_b7aef7c0>
  409a68:	mov    eax,esi
  409a6a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  409a73:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  409a7c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  409a85:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  409a8e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  409a97:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  409aa0:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  409aa9:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  409ab2:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  409abb:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  409ac4:	add    rsp,0x4a8
  409acb:	pop    rsi
  409acc:	pop    rdi
  409acd:	pop    r12
  409acf:	pop    rbx
  409ad0:	ret
	...

0000000000409ae0 <__swc_fn_4fa09e82_000123_c37da69c>:
  409ae0:	mov    QWORD PTR [rcx],0x0
  409ae7:	ret
	...

0000000000409af0 <__swc_fn_4fa09e82_000126_e19c72b3>:
  409af0:	push   rdi
  409af1:	push   rsi
  409af2:	sub    rsp,0xa8
  409af9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409aff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409b05:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409b0b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409b11:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409b17:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409b1d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409b23:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409b29:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409b32:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409b3b:	mov    edi,ecx
  409b3d:	mov    rsi,rdx
  409b40:	xor    eax,eax
  409b42:	call   407120 <pthread_setspecific@plt>
  409b47:	test   eax,eax
  409b49:	sete   al
  409b4c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409b52:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409b58:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409b5e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409b64:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409b6a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409b70:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409b76:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409b7c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409b85:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409b8e:	add    rsp,0xa8
  409b95:	pop    rsi
  409b96:	pop    rdi
  409b97:	ret
	...

0000000000409ba0 <__swc_fn_4fa09e82_000129_9c45d2d7>:
  409ba0:	push   rdi
  409ba1:	push   rsi
  409ba2:	sub    rsp,0xa8
  409ba9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409baf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409bb5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409bbb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409bc1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409bc7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409bcd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409bd3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409bd9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409be2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409beb:	test   rcx,rcx
  409bee:	je     409c01 <__swc_fn_4fa09e82_000129_9c45d2d7+0x61>
  409bf0:	lea    rax,[rcx-0x1]
  409bf4:	mov    eax,eax
  409bf6:	mov    edi,eax
  409bf8:	xor    eax,eax
  409bfa:	call   407000 <pthread_getspecific@plt>
  409bff:	jmp    409c03 <__swc_fn_4fa09e82_000129_9c45d2d7+0x63>
  409c01:	xor    eax,eax
  409c03:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409c09:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409c0f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409c15:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409c1b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409c21:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409c27:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409c2d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409c33:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409c3c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409c45:	add    rsp,0xa8
  409c4c:	pop    rsi
  409c4d:	pop    rdi
  409c4e:	ret
	...

0000000000409c50 <__swc_fn_4fa09e82_000132_dc04d759>:
  409c50:	push   rdi
  409c51:	push   rsi
  409c52:	sub    rsp,0xb8
  409c59:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409c5f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409c65:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409c6b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409c71:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409c77:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409c7d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409c83:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409c8c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409c95:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409c9e:	vxorps xmm0,xmm0,xmm0
  409ca2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409ca8:	mov    edi,0x1
  409cad:	lea    rsi,[rsp+0x8]
  409cb2:	xor    eax,eax
  409cb4:	call   407130 <clock_gettime@plt>
  409cb9:	mov    rax,QWORD PTR [rsp+0x8]
  409cbe:	imul   rax,rax,0x3b9aca00
  409cc5:	add    rax,QWORD PTR [rsp+0x10]
  409cca:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409cd0:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409cd6:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409cdc:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409ce2:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409ce8:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409cee:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409cf4:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409cfd:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409d06:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409d0f:	add    rsp,0xb8
  409d16:	pop    rsi
  409d17:	pop    rdi
  409d18:	ret
  409d19:	add    BYTE PTR [rax],al
  409d1b:	add    BYTE PTR [rax],al
  409d1d:	add    BYTE PTR [rax],al
	...

0000000000409d20 <__swc_fn_4fa09e82_000135_5696c87e>:
  409d20:	sub    rsp,0x8
  409d24:	xor    eax,eax
  409d26:	mov    DWORD PTR [rcx],eax
  409d28:	mov    edx,0x7fffffff
  409d2d:	call   40e6a0 <__swc_fn_4fa09e82_000133_2b60f756>
  409d32:	add    rsp,0x8
  409d36:	ret
	...

0000000000409d40 <__swc_fn_4fa09e82_000138_899a611e>:
  409d40:	push   rdi
  409d41:	push   rsi
  409d42:	sub    rsp,0xb8
  409d49:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409d4f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409d55:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409d5b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409d61:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409d67:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409d6d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409d73:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409d7c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409d85:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409d8e:	mov    edi,0x1
  409d93:	xor    eax,eax
  409d95:	call   407140 <__x86_get_cpuid_feature_leaf@plt>
  409d9a:	mov    eax,DWORD PTR [rax+0x14]
  409d9d:	and    eax,0x20
  409da0:	setne  al
  409da3:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409da9:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409daf:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409db5:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409dbb:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409dc1:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409dc7:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409dcd:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409dd6:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409ddf:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409de8:	add    rsp,0xb8
  409def:	pop    rsi
  409df0:	pop    rdi
  409df1:	ret
	...

0000000000409e00 <__swc_fn_4fa09e82_000141_81b740ca>:
  409e00:	push   rsi
  409e01:	push   rdi
  409e02:	push   r12
  409e04:	push   r13
  409e06:	push   r14
  409e08:	push   r15
  409e0a:	cmp    rdx,0x40
  409e0e:	jae    409e1d <__swc_fn_4fa09e82_000141_81b740ca+0x1d>
  409e10:	xor    eax,eax
  409e12:	pop    r15
  409e14:	pop    r14
  409e16:	pop    r13
  409e18:	pop    r12
  409e1a:	pop    rdi
  409e1b:	pop    rsi
  409e1c:	ret
  409e1d:	cmp    BYTE PTR [rcx],0x7f
  409e20:	jne    409e64 <__swc_fn_4fa09e82_000141_81b740ca+0x64>
  409e22:	movzx  eax,BYTE PTR [rcx+0x1]
  409e26:	cmp    eax,0x45
  409e29:	setne  al
  409e2c:	jne    409e60 <__swc_fn_4fa09e82_000141_81b740ca+0x60>
  409e2e:	movzx  eax,BYTE PTR [rcx+0x2]
  409e32:	cmp    eax,0x4c
  409e35:	setne  al
  409e38:	jne    409e60 <__swc_fn_4fa09e82_000141_81b740ca+0x60>
  409e3a:	movzx  eax,BYTE PTR [rcx+0x3]
  409e3e:	cmp    eax,0x46
  409e41:	setne  al
  409e44:	jne    409e60 <__swc_fn_4fa09e82_000141_81b740ca+0x60>
  409e46:	cmp    BYTE PTR [rcx+0x4],0x2
  409e4a:	setne  al
  409e4d:	jne    409e60 <__swc_fn_4fa09e82_000141_81b740ca+0x60>
  409e4f:	cmp    BYTE PTR [rcx+0x5],0x1
  409e53:	setne  al
  409e56:	jne    409e60 <__swc_fn_4fa09e82_000141_81b740ca+0x60>
  409e58:	cmp    WORD PTR [rcx+0x12],0x3e
  409e5d:	setne  al
  409e60:	test   al,al
  409e62:	je     409e71 <__swc_fn_4fa09e82_000141_81b740ca+0x71>
  409e64:	xor    eax,eax
  409e66:	pop    r15
  409e68:	pop    r14
  409e6a:	pop    r13
  409e6c:	pop    r12
  409e6e:	pop    rdi
  409e6f:	pop    rsi
  409e70:	ret
  409e71:	cmp    WORD PTR [rcx+0x3a],0x40
  409e76:	jne    409e91 <__swc_fn_4fa09e82_000141_81b740ca+0x91>
  409e78:	cmp    WORD PTR [rcx+0x3c],0x0
  409e7d:	sete   al
  409e80:	je     409e8d <__swc_fn_4fa09e82_000141_81b740ca+0x8d>
  409e82:	mov    ax,WORD PTR [rcx+0x3c]
  409e86:	cmp    WORD PTR [rcx+0x3e],ax
  409e8a:	setae  al
  409e8d:	test   al,al
  409e8f:	je     409e9e <__swc_fn_4fa09e82_000141_81b740ca+0x9e>
  409e91:	xor    eax,eax
  409e93:	pop    r15
  409e95:	pop    r14
  409e97:	pop    r13
  409e99:	pop    r12
  409e9b:	pop    rdi
  409e9c:	pop    rsi
  409e9d:	ret
  409e9e:	movzx  eax,WORD PTR [rcx+0x3c]
  409ea2:	shl    rax,0x6
  409ea6:	cmp    rax,rdx
  409ea9:	ja     409eb7 <__swc_fn_4fa09e82_000141_81b740ca+0xb7>
  409eab:	mov    r9,rdx
  409eae:	sub    r9,rax
  409eb1:	cmp    QWORD PTR [rcx+0x28],r9
  409eb5:	jbe    409ec4 <__swc_fn_4fa09e82_000141_81b740ca+0xc4>
  409eb7:	xor    eax,eax
  409eb9:	pop    r15
  409ebb:	pop    r14
  409ebd:	pop    r13
  409ebf:	pop    r12
  409ec1:	pop    rdi
  409ec2:	pop    rsi
  409ec3:	ret
  409ec4:	mov    rax,QWORD PTR [rcx+0x28]
  409ec8:	add    rax,rcx
  409ecb:	movzx  r9d,WORD PTR [rcx+0x3e]
  409ed0:	lea    r9,[r9*8+0x0]
  409ed8:	lea    r10,[rax+r9*8]
  409edc:	cmp    QWORD PTR [r10+0x20],rdx
  409ee0:	ja     409f02 <__swc_fn_4fa09e82_000141_81b740ca+0x102>
  409ee2:	mov    r11,rdx
  409ee5:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  409eea:	cmp    QWORD PTR [r10+0x18],r11
  409eee:	seta   r9b
  409ef2:	ja     409efd <__swc_fn_4fa09e82_000141_81b740ca+0xfd>
  409ef4:	cmp    QWORD PTR [r10+0x20],0x9
  409ef9:	setb   r9b
  409efd:	test   r9b,r9b
  409f00:	je     409f0f <__swc_fn_4fa09e82_000141_81b740ca+0x10f>
  409f02:	xor    eax,eax
  409f04:	pop    r15
  409f06:	pop    r14
  409f08:	pop    r13
  409f0a:	pop    r12
  409f0c:	pop    rdi
  409f0d:	pop    rsi
  409f0e:	ret
  409f0f:	movzx  r9d,WORD PTR [rcx+0x3c]
  409f14:	xor    r11d,r11d
  409f17:	test   r9,r9
  409f1a:	jbe    40a015 <__swc_fn_4fa09e82_000141_81b740ca+0x215>
  409f20:	mov    rsi,QWORD PTR [r10+0x20]
  409f24:	sub    rsi,0x9
  409f28:	cs nop WORD PTR [rax+rax*1+0x0]
  409f32:	cs nop WORD PTR [rax+rax*1+0x0]
  409f3c:	nop    DWORD PTR [rax+0x0]
  409f40:	movzx  edi,r11w
  409f44:	lea    rdi,[rdi*8+0x0]
  409f4c:	lea    r12,[rax+rdi*8]
  409f50:	rex mov edi,DWORD PTR [rax+rdi*8]
  409f54:	cmp    rdi,rsi
  409f57:	ja     40a008 <__swc_fn_4fa09e82_000141_81b740ca+0x208>
  409f5d:	mov    r13,QWORD PTR [r10+0x18]
  409f61:	add    r13,rdi
  409f64:	lea    rdi,[rcx+r13*1]
  409f68:	lea    r13,[rip+0x95c1]        # 413530 <__swc_rdata_base_4fa09e82+0x420>
  409f6f:	movabs r14,0x676264676177732e
  409f79:	cmp    QWORD PTR [rdi],r14
  409f7c:	jne    409f85 <__swc_fn_4fa09e82_000141_81b740ca+0x185>
  409f7e:	rex cmp BYTE PTR [rdi+0x8],0x0
  409f83:	je     409fb2 <__swc_fn_4fa09e82_000141_81b740ca+0x1b2>
  409f85:	cs nop WORD PTR [rax+rax*1+0x0]
  409f8f:	nop
  409f90:	movzx  r14d,BYTE PTR [rdi]
  409f94:	movzx  r15d,BYTE PTR [r13+0x0]
  409f99:	cmp    r14,r15
  409f9c:	jne    409fa8 <__swc_fn_4fa09e82_000141_81b740ca+0x1a8>
  409f9e:	add    rdi,0x1
  409fa2:	add    r13,0x1
  409fa6:	jmp    409f90 <__swc_fn_4fa09e82_000141_81b740ca+0x190>
  409fa8:	mov    rdi,r14
  409fab:	sub    rdi,r15
  409fae:	test   edi,edi
  409fb0:	jne    40a008 <__swc_fn_4fa09e82_000141_81b740ca+0x208>
  409fb2:	cmp    DWORD PTR [r12+0x4],0x1
  409fb8:	jne    409fe0 <__swc_fn_4fa09e82_000141_81b740ca+0x1e0>
  409fba:	cmp    QWORD PTR [r12+0x20],0x10
  409fc0:	setb   al
  409fc3:	jb     409fdc <__swc_fn_4fa09e82_000141_81b740ca+0x1dc>
  409fc5:	cmp    QWORD PTR [r12+0x20],rdx
  409fca:	seta   al
  409fcd:	ja     409fdc <__swc_fn_4fa09e82_000141_81b740ca+0x1dc>
  409fcf:	sub    rdx,QWORD PTR [r12+0x20]
  409fd4:	cmp    QWORD PTR [r12+0x18],rdx
  409fd9:	seta   al
  409fdc:	test   al,al
  409fde:	je     409fed <__swc_fn_4fa09e82_000141_81b740ca+0x1ed>
  409fe0:	xor    eax,eax
  409fe2:	pop    r15
  409fe4:	pop    r14
  409fe6:	pop    r13
  409fe8:	pop    r12
  409fea:	pop    rdi
  409feb:	pop    rsi
  409fec:	ret
  409fed:	mov    rax,QWORD PTR [r12+0x20]
  409ff2:	mov    QWORD PTR [r8],rax
  409ff5:	mov    rax,QWORD PTR [r12+0x18]
  409ffa:	add    rax,rcx
  409ffd:	pop    r15
  409fff:	pop    r14
  40a001:	pop    r13
  40a003:	pop    r12
  40a005:	pop    rdi
  40a006:	pop    rsi
  40a007:	ret
  40a008:	add    r11,0x1
  40a00c:	cmp    r11,r9
  40a00f:	jb     409f40 <__swc_fn_4fa09e82_000141_81b740ca+0x140>
  40a015:	xor    eax,eax
  40a017:	pop    r15
  40a019:	pop    r14
  40a01b:	pop    r13
  40a01d:	pop    r12
  40a01f:	pop    rdi
  40a020:	pop    rsi
  40a021:	ret
	...

000000000040a030 <__swc_fn_4fa09e82_000144_afffe963>:
  40a030:	push   rdi
  40a031:	push   rsi
  40a032:	sub    rsp,0xa8
  40a039:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a03f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a045:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a04b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a051:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a057:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a05d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a063:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a069:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a072:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a07b:	mov    rdi,rcx
  40a07e:	xor    eax,eax
  40a080:	call   407150 <free@plt>
  40a085:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a08b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a091:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a097:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a09d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a0a3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a0a9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a0af:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a0b5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a0be:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a0c7:	add    rsp,0xa8
  40a0ce:	pop    rsi
  40a0cf:	pop    rdi
  40a0d0:	ret
	...

000000000040a0e0 <__swc_fn_4fa09e82_000147_e9d46966>:
  40a0e0:	push   rbx
  40a0e1:	push   rsi
  40a0e2:	push   rdi
  40a0e3:	push   r12
  40a0e5:	push   r13
  40a0e7:	push   r15
  40a0e9:	sub    rsp,0x4e8
  40a0f0:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  40a0f9:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  40a102:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  40a10b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  40a114:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  40a11d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  40a126:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  40a12f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  40a138:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  40a141:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  40a14a:	mov    rbx,QWORD PTR [rcx]
  40a14d:	mov    rcx,QWORD PTR [rcx+0x8]
  40a151:	mov    rsi,rcx
  40a154:	xor    edi,edi
  40a156:	vmovsd xmm6,QWORD PTR [rip+0x9432]        # 413590 <__swc_rdata_base_4fa09e82+0x480>
  40a15e:	vmovsd xmm7,QWORD PTR [rip+0x9433]        # 413599 <__swc_rdata_base_4fa09e82+0x489>
  40a166:	vmovsd xmm8,QWORD PTR [rip+0x9434]        # 4135a2 <__swc_rdata_base_4fa09e82+0x492>
  40a16e:	vmovsd xmm9,QWORD PTR [rip+0x9435]        # 4135ab <__swc_rdata_base_4fa09e82+0x49b>
  40a176:	vmovsd xmm10,QWORD PTR [rip+0x9436]        # 4135b4 <__swc_rdata_base_4fa09e82+0x4a4>
  40a17e:	vmovups xmm11,xmm6
  40a182:	vmovsd QWORD PTR [rsp+0x418],xmm7
  40a18b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  40a194:	vmovsd QWORD PTR [rsp+0x428],xmm9
  40a19d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  40a1a6:	vmovsd xmm15,QWORD PTR [rip+0x940f]        # 4135bd <__swc_rdata_base_4fa09e82+0x4ad>
  40a1ae:	vmovups xmm14,xmm15
  40a1b3:	vmovups xmm0,xmm9
  40a1b8:	vmovsd QWORD PTR [rsp+0x438],xmm15
  40a1c1:	vmovups xmm13,xmm8
  40a1c6:	vmovsd QWORD PTR [rsp+0x440],xmm15
  40a1cf:	test   rsi,rsi
  40a1d2:	je     40b1c3 <__swc_fn_4fa09e82_000147_e9d46966+0x10e3>
  40a1d8:	cs nop WORD PTR [rax+rax*1+0x0]
  40a1e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a1ec:	nop    DWORD PTR [rax+0x0]
  40a1f0:	lea    rcx,[rdi+rdi*1]
  40a1f4:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  40a1f9:	vpshufd xmm3,xmm2,0xee
  40a1fe:	vmovq  rcx,xmm3
  40a203:	test   rcx,rcx
  40a206:	je     40a21c <__swc_fn_4fa09e82_000147_e9d46966+0x13c>
  40a208:	test   DWORD PTR [rcx+0x28],0x400000
  40a20f:	je     40a21c <__swc_fn_4fa09e82_000147_e9d46966+0x13c>
  40a211:	mov    rdx,QWORD PTR [rcx+0x30]
  40a215:	test   rdx,rdx
  40a218:	cmovne rcx,rdx
  40a21c:	test   DWORD PTR [rcx+0x28],0x1000
  40a223:	je     40a244 <__swc_fn_4fa09e82_000147_e9d46966+0x164>
  40a225:	mov    rdx,QWORD PTR [rcx+0x40]
  40a229:	mov    rcx,rdx
  40a22c:	vmovq  r8,xmm2
  40a231:	mov    r8,QWORD PTR [r8]
  40a234:	mov    QWORD PTR [rsp+0x60],r8
  40a239:	mov    QWORD PTR [rsp+0x68],rdx
  40a23e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  40a244:	test   BYTE PTR [rcx+0x28],0x1
  40a248:	jne    40a250 <__swc_fn_4fa09e82_000147_e9d46966+0x170>
  40a24a:	vmovups xmm12,xmm0
  40a24e:	jmp    40a26a <__swc_fn_4fa09e82_000147_e9d46966+0x18a>
  40a250:	vmovq  rax,xmm2
  40a255:	mov    rax,QWORD PTR [rax]
  40a258:	lea    rcx,[rax+0x10]
  40a25c:	vmovups xmm12,xmm0
  40a260:	call   409870 <__swc_fn_4fa09e82_000117_3499f7d6>
  40a265:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40a26a:	test   DWORD PTR [rcx+0x28],0x400
  40a271:	je     40a2d2 <__swc_fn_4fa09e82_000147_e9d46966+0x1f2>
  40a273:	vmovq  rax,xmm2
  40a278:	mov    rax,QWORD PTR [rax]
  40a27b:	xor    ecx,ecx
  40a27d:	test   rax,rax
  40a280:	je     40a2b0 <__swc_fn_4fa09e82_000147_e9d46966+0x1d0>
  40a282:	mov    rdx,rax
  40a285:	mov    r8b,BYTE PTR [rdx]
  40a288:	test   r8b,r8b
  40a28b:	je     40a2b0 <__swc_fn_4fa09e82_000147_e9d46966+0x1d0>
  40a28d:	cs nop WORD PTR [rax+rax*1+0x0]
  40a297:	nop    WORD PTR [rax+rax*1+0x0]
  40a2a0:	add    rdx,0x1
  40a2a4:	add    rcx,0x1
  40a2a8:	mov    r8b,BYTE PTR [rdx]
  40a2ab:	test   r8b,r8b
  40a2ae:	jne    40a2a0 <__swc_fn_4fa09e82_000147_e9d46966+0x1c0>
  40a2b0:	mov    QWORD PTR [rsp+0x88],rax
  40a2b8:	mov    QWORD PTR [rsp+0x90],rcx
  40a2c0:	lea    rcx,[rsp+0x88]
  40a2c8:	call   409870 <__swc_fn_4fa09e82_000117_3499f7d6>
  40a2cd:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40a2d2:	cmp    BYTE PTR [rcx+0x2c],0x6
  40a2d6:	jne    40a2ed <__swc_fn_4fa09e82_000147_e9d46966+0x20d>
  40a2d8:	vmovq  rax,xmm2
  40a2dd:	mov    rax,QWORD PTR [rax]
  40a2e0:	mov    rcx,rax
  40a2e3:	call   40eb70 <__swc_fn_4fa09e82_000145_364559f5>
  40a2e8:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40a2ed:	cmp    BYTE PTR [rcx+0x2c],0x1
  40a2f1:	jne    40b199 <__swc_fn_4fa09e82_000147_e9d46966+0x10b9>
  40a2f7:	vmovq  rdx,xmm2
  40a2fc:	mov    cl,BYTE PTR [rcx+0x40]
  40a2ff:	cmp    cl,0x7
  40a302:	jb     40a345 <__swc_fn_4fa09e82_000147_e9d46966+0x265>
  40a304:	je     40a3b8 <__swc_fn_4fa09e82_000147_e9d46966+0x2d8>
  40a30a:	cmp    cl,0x8
  40a30d:	je     40a3c4 <__swc_fn_4fa09e82_000147_e9d46966+0x2e4>
  40a313:	cmp    cl,0x9
  40a316:	je     40a3dd <__swc_fn_4fa09e82_000147_e9d46966+0x2fd>
  40a31c:	cmp    cl,0xa
  40a31f:	je     40aaa4 <__swc_fn_4fa09e82_000147_e9d46966+0x9c4>
  40a325:	cmp    cl,0xb
  40a328:	je     40b16b <__swc_fn_4fa09e82_000147_e9d46966+0x108b>
  40a32e:	cmp    cl,0xc
  40a331:	je     40a3d1 <__swc_fn_4fa09e82_000147_e9d46966+0x2f1>
  40a337:	cmp    cl,0xd
  40a33a:	je     40b161 <__swc_fn_4fa09e82_000147_e9d46966+0x1081>
  40a340:	jmp    40b18b <__swc_fn_4fa09e82_000147_e9d46966+0x10ab>
  40a345:	cmp    cl,0x1
  40a348:	je     40a368 <__swc_fn_4fa09e82_000147_e9d46966+0x288>
  40a34a:	cmp    cl,0x2
  40a34d:	je     40a376 <__swc_fn_4fa09e82_000147_e9d46966+0x296>
  40a34f:	cmp    cl,0x3
  40a352:	je     40a384 <__swc_fn_4fa09e82_000147_e9d46966+0x2a4>
  40a354:	cmp    cl,0x4
  40a357:	je     40a391 <__swc_fn_4fa09e82_000147_e9d46966+0x2b1>
  40a359:	cmp    cl,0x5
  40a35c:	je     40a39e <__swc_fn_4fa09e82_000147_e9d46966+0x2be>
  40a35e:	cmp    cl,0x6
  40a361:	je     40a3ab <__swc_fn_4fa09e82_000147_e9d46966+0x2cb>
  40a363:	jmp    40b18b <__swc_fn_4fa09e82_000147_e9d46966+0x10ab>
  40a368:	movsx  rcx,BYTE PTR [rdx]
  40a36c:	call   4119c0 <__swc_fn_4fa09e82_000146_071b4f4c>
  40a371:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40a376:	movsx  rcx,WORD PTR [rdx]
  40a37a:	call   4119c0 <__swc_fn_4fa09e82_000146_071b4f4c>
  40a37f:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40a384:	movsxd rcx,DWORD PTR [rdx]
  40a387:	call   4119c0 <__swc_fn_4fa09e82_000146_071b4f4c>
  40a38c:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40a391:	mov    rcx,QWORD PTR [rdx]
  40a394:	call   4119c0 <__swc_fn_4fa09e82_000146_071b4f4c>
  40a399:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40a39e:	movzx  ecx,BYTE PTR [rdx]
  40a3a1:	call   40eb70 <__swc_fn_4fa09e82_000145_364559f5>
  40a3a6:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40a3ab:	movzx  ecx,WORD PTR [rdx]
  40a3ae:	call   40eb70 <__swc_fn_4fa09e82_000145_364559f5>
  40a3b3:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40a3b8:	mov    ecx,DWORD PTR [rdx]
  40a3ba:	call   40eb70 <__swc_fn_4fa09e82_000145_364559f5>
  40a3bf:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40a3c4:	mov    rcx,QWORD PTR [rdx]
  40a3c7:	call   40eb70 <__swc_fn_4fa09e82_000145_364559f5>
  40a3cc:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40a3d1:	mov    ecx,DWORD PTR [rdx]
  40a3d3:	call   40eb70 <__swc_fn_4fa09e82_000145_364559f5>
  40a3d8:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40a3dd:	lea    rcx,[rsp+0xa8]
  40a3e5:	vxorps xmm0,xmm0,xmm0
  40a3e9:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  40a3f2:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  40a3fb:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  40a404:	vzeroupper
  40a407:	mov    DWORD PTR [rsp+0x108],0x0
  40a412:	vxorpd xmm0,xmm0,xmm0
  40a416:	vmovss xmm1,DWORD PTR [rdx]
  40a41a:	vcvtss2sd xmm0,xmm0,xmm1
  40a41e:	vmovsd xmm1,xmm1,xmm0
  40a422:	vcomisd xmm0,xmm0
  40a426:	setne  dl
  40a429:	movzx  edx,dl
  40a42c:	setp   r8b
  40a430:	movzx  r8d,r8b
  40a434:	or     edx,r8d
  40a437:	test   dl,dl
  40a439:	je     40a446 <__swc_fn_4fa09e82_000147_e9d46966+0x366>
  40a43b:	mov    DWORD PTR [rcx],0x6e616e
  40a441:	jmp    40aa38 <__swc_fn_4fa09e82_000147_e9d46966+0x958>
  40a446:	vcomisd xmm1,xmm6
  40a44a:	ja     40a452 <__swc_fn_4fa09e82_000147_e9d46966+0x372>
  40a44c:	vcomisd xmm7,xmm1
  40a450:	jbe    40a476 <__swc_fn_4fa09e82_000147_e9d46966+0x396>
  40a452:	vxorpd xmm0,xmm0,xmm0
  40a456:	vcomisd xmm0,xmm1
  40a45a:	jbe    40a46b <__swc_fn_4fa09e82_000147_e9d46966+0x38b>
  40a45c:	mov    DWORD PTR [rcx],0x666e692d
  40a462:	mov    BYTE PTR [rcx+0x4],0x0
  40a466:	jmp    40aa38 <__swc_fn_4fa09e82_000147_e9d46966+0x958>
  40a46b:	mov    DWORD PTR [rcx],0x666e69
  40a471:	jmp    40aa38 <__swc_fn_4fa09e82_000147_e9d46966+0x958>
  40a476:	vcomisd xmm1,xmm8
  40a47b:	jae    40a487 <__swc_fn_4fa09e82_000147_e9d46966+0x3a7>
  40a47d:	vcomisd xmm9,xmm1
  40a481:	jbe    40a7fe <__swc_fn_4fa09e82_000147_e9d46966+0x71e>
  40a487:	vmovups xmm0,xmm1
  40a48b:	vxorpd xmm2,xmm2,xmm2
  40a48f:	vcomisd xmm2,xmm1
  40a493:	jbe    40a4a3 <__swc_fn_4fa09e82_000147_e9d46966+0x3c3>
  40a495:	vmovsd xmm1,xmm1,xmm0
  40a499:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x90af]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40a4a1:	jmp    40a4a7 <__swc_fn_4fa09e82_000147_e9d46966+0x3c7>
  40a4a3:	vmovsd xmm1,xmm1,xmm0
  40a4a7:	xor    r8d,r8d
  40a4aa:	vcomisd xmm1,xmm15
  40a4af:	jb     40a4d0 <__swc_fn_4fa09e82_000147_e9d46966+0x3f0>
  40a4b1:	cs nop WORD PTR [rax+rax*1+0x0]
  40a4bb:	nop    DWORD PTR [rax+rax*1+0x0]
  40a4c0:	vdivsd xmm1,xmm1,xmm15
  40a4c5:	add    r8,0x1
  40a4c9:	vcomisd xmm1,xmm15
  40a4ce:	jae    40a4c0 <__swc_fn_4fa09e82_000147_e9d46966+0x3e0>
  40a4d0:	mov    r9,rcx
  40a4d3:	vxorpd xmm2,xmm2,xmm2
  40a4d7:	vcomisd xmm2,xmm0
  40a4db:	jbe    40a4e4 <__swc_fn_4fa09e82_000147_e9d46966+0x404>
  40a4dd:	mov    BYTE PTR [rcx],0x2d
  40a4e0:	lea    r9,[rcx+0x1]
  40a4e4:	vcvttsd2si rdx,xmm1
  40a4e9:	mov    r10b,dl
  40a4ec:	add    r10b,0x30
  40a4f0:	mov    BYTE PTR [r9],r10b
  40a4f3:	vxorpd xmm0,xmm0,xmm0
  40a4f7:	movzx  edx,dl
  40a4fa:	vcvtsi2sd xmm0,xmm0,rdx
  40a4ff:	vsubsd xmm0,xmm1,xmm0
  40a503:	vmulsd xmm1,xmm0,xmm15
  40a508:	mov    BYTE PTR [r9+0x1],0x2e
  40a50d:	vcvttsd2si rdx,xmm1
  40a512:	mov    r10b,dl
  40a515:	add    r10b,0x30
  40a519:	mov    BYTE PTR [r9+0x2],r10b
  40a51d:	vxorpd xmm0,xmm0,xmm0
  40a521:	movzx  edx,dl
  40a524:	vcvtsi2sd xmm0,xmm0,rdx
  40a529:	vsubsd xmm0,xmm1,xmm0
  40a52d:	vmulsd xmm1,xmm0,xmm15
  40a532:	vcvttsd2si rdx,xmm1
  40a537:	mov    r10b,dl
  40a53a:	add    r10b,0x30
  40a53e:	mov    BYTE PTR [r9+0x3],r10b
  40a542:	vxorpd xmm0,xmm0,xmm0
  40a546:	movzx  edx,dl
  40a549:	vcvtsi2sd xmm0,xmm0,rdx
  40a54e:	vsubsd xmm0,xmm1,xmm0
  40a552:	vmulsd xmm1,xmm0,xmm15
  40a557:	vcvttsd2si rdx,xmm1
  40a55c:	mov    r10b,dl
  40a55f:	add    r10b,0x30
  40a563:	mov    BYTE PTR [r9+0x4],r10b
  40a567:	vxorpd xmm0,xmm0,xmm0
  40a56b:	movzx  edx,dl
  40a56e:	vcvtsi2sd xmm0,xmm0,rdx
  40a573:	vsubsd xmm0,xmm1,xmm0
  40a577:	vmulsd xmm1,xmm0,xmm15
  40a57c:	vcvttsd2si rdx,xmm1
  40a581:	mov    r10b,dl
  40a584:	add    r10b,0x30
  40a588:	mov    BYTE PTR [r9+0x5],r10b
  40a58c:	vxorpd xmm0,xmm0,xmm0
  40a590:	movzx  edx,dl
  40a593:	vcvtsi2sd xmm0,xmm0,rdx
  40a598:	vsubsd xmm0,xmm1,xmm0
  40a59c:	vmulsd xmm1,xmm0,xmm15
  40a5a1:	vcvttsd2si rdx,xmm1
  40a5a6:	mov    r10b,dl
  40a5a9:	add    r10b,0x30
  40a5ad:	mov    BYTE PTR [r9+0x6],r10b
  40a5b1:	vxorpd xmm0,xmm0,xmm0
  40a5b5:	movzx  edx,dl
  40a5b8:	vcvtsi2sd xmm0,xmm0,rdx
  40a5bd:	vsubsd xmm0,xmm1,xmm0
  40a5c1:	vmulsd xmm1,xmm0,xmm15
  40a5c6:	vcvttsd2si rdx,xmm1
  40a5cb:	mov    r10b,dl
  40a5ce:	add    r10b,0x30
  40a5d2:	mov    BYTE PTR [r9+0x7],r10b
  40a5d6:	vxorpd xmm0,xmm0,xmm0
  40a5da:	movzx  edx,dl
  40a5dd:	vcvtsi2sd xmm0,xmm0,rdx
  40a5e2:	vsubsd xmm0,xmm1,xmm0
  40a5e6:	vmulsd xmm1,xmm0,xmm15
  40a5eb:	vcvttsd2si rdx,xmm1
  40a5f0:	mov    r10b,dl
  40a5f3:	add    r10b,0x30
  40a5f7:	mov    BYTE PTR [r9+0x8],r10b
  40a5fb:	vxorpd xmm0,xmm0,xmm0
  40a5ff:	movzx  edx,dl
  40a602:	vcvtsi2sd xmm0,xmm0,rdx
  40a607:	vsubsd xmm0,xmm1,xmm0
  40a60b:	vmulsd xmm1,xmm0,xmm15
  40a610:	vcvttsd2si rdx,xmm1
  40a615:	mov    r10b,dl
  40a618:	add    r10b,0x30
  40a61c:	mov    BYTE PTR [r9+0x9],r10b
  40a620:	vxorpd xmm0,xmm0,xmm0
  40a624:	movzx  edx,dl
  40a627:	vcvtsi2sd xmm0,xmm0,rdx
  40a62c:	vsubsd xmm0,xmm1,xmm0
  40a630:	vmulsd xmm1,xmm0,xmm15
  40a635:	vcvttsd2si rdx,xmm1
  40a63a:	mov    r10b,dl
  40a63d:	add    r10b,0x30
  40a641:	mov    BYTE PTR [r9+0xa],r10b
  40a645:	vxorpd xmm0,xmm0,xmm0
  40a649:	movzx  edx,dl
  40a64c:	vcvtsi2sd xmm0,xmm0,rdx
  40a651:	vsubsd xmm0,xmm1,xmm0
  40a655:	vmulsd xmm1,xmm0,xmm15
  40a65a:	vcvttsd2si rdx,xmm1
  40a65f:	mov    r10b,dl
  40a662:	add    r10b,0x30
  40a666:	mov    BYTE PTR [r9+0xb],r10b
  40a66a:	lea    r10,[r9+0x4]
  40a66e:	vxorpd xmm0,xmm0,xmm0
  40a672:	movzx  edx,dl
  40a675:	vcvtsi2sd xmm0,xmm0,rdx
  40a67a:	vsubsd xmm0,xmm1,xmm0
  40a67e:	vmulsd xmm1,xmm0,xmm15
  40a683:	vcvttsd2si rdx,xmm1
  40a688:	mov    r11b,dl
  40a68b:	add    r11b,0x30
  40a68f:	mov    BYTE PTR [r9+0xc],r11b
  40a693:	vxorpd xmm0,xmm0,xmm0
  40a697:	movzx  edx,dl
  40a69a:	vcvtsi2sd xmm0,xmm0,rdx
  40a69f:	vsubsd xmm0,xmm1,xmm0
  40a6a3:	vmulsd xmm1,xmm0,xmm15
  40a6a8:	vcvttsd2si rdx,xmm1
  40a6ad:	mov    r11b,dl
  40a6b0:	add    r11b,0x30
  40a6b4:	mov    BYTE PTR [r9+0xd],r11b
  40a6b8:	lea    r10,[r10+0x2]
  40a6bc:	vxorpd xmm0,xmm0,xmm0
  40a6c0:	movzx  edx,dl
  40a6c3:	vcvtsi2sd xmm0,xmm0,rdx
  40a6c8:	vsubsd xmm0,xmm1,xmm0
  40a6cc:	vmulsd xmm1,xmm0,xmm15
  40a6d1:	vcvttsd2si rdx,xmm1
  40a6d6:	mov    r11b,dl
  40a6d9:	add    r11b,0x30
  40a6dd:	mov    BYTE PTR [r9+0xe],r11b
  40a6e1:	vxorpd xmm0,xmm0,xmm0
  40a6e5:	movzx  edx,dl
  40a6e8:	vcvtsi2sd xmm0,xmm0,rdx
  40a6ed:	vsubsd xmm0,xmm1,xmm0
  40a6f1:	vmulsd xmm1,xmm0,xmm15
  40a6f6:	vcvttsd2si rdx,xmm1
  40a6fb:	mov    r11b,dl
  40a6fe:	add    r11b,0x30
  40a702:	mov    BYTE PTR [r9+0xf],r11b
  40a706:	lea    r10,[r10+0x2]
  40a70a:	lea    r10,[r10+0x2]
  40a70e:	lea    r10,[r10+0x2]
  40a712:	lea    r10,[r10+0x2]
  40a716:	lea    r10,[r10+0x2]
  40a71a:	vxorpd xmm0,xmm0,xmm0
  40a71e:	movzx  edx,dl
  40a721:	vcvtsi2sd xmm0,xmm0,rdx
  40a726:	vsubsd xmm0,xmm1,xmm0
  40a72a:	vmulsd xmm1,xmm0,xmm15
  40a72f:	vcvttsd2si rdx,xmm1
  40a734:	mov    r11b,dl
  40a737:	add    r11b,0x30
  40a73b:	mov    BYTE PTR [r9+0x10],r11b
  40a73f:	vxorpd xmm0,xmm0,xmm0
  40a743:	movzx  edx,dl
  40a746:	vcvtsi2sd xmm0,xmm0,rdx
  40a74b:	vsubsd xmm0,xmm1,xmm0
  40a74f:	vmulsd xmm1,xmm0,xmm15
  40a754:	vcvttsd2si rdx,xmm1
  40a759:	add    dl,0x30
  40a75c:	mov    BYTE PTR [r9+0x11],dl
  40a760:	mov    BYTE PTR [r10+0x2],0x65
  40a765:	lea    r9,[r10+0x3]
  40a769:	test   r8,r8
  40a76c:	jl     40a775 <__swc_fn_4fa09e82_000147_e9d46966+0x695>
  40a76e:	mov    BYTE PTR [r9],0x2b
  40a772:	inc    r9
  40a775:	mov    r10,r9
  40a778:	mov    rdx,r8
  40a77b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a780:	mov    r11,rdx
  40a783:	movabs rdx,0x6666666666666667
  40a78d:	mov    rax,r11
  40a790:	imul   rdx
  40a793:	sar    rdx,0x2
  40a797:	mov    r12,rdx
  40a79a:	shr    rdx,0x3f
  40a79e:	add    r12,rdx
  40a7a1:	mov    rdx,r12
  40a7a4:	imul   r13,r12,0xa
  40a7a8:	sub    r11,r13
  40a7ab:	mov    r13,QWORD PTR [rip+0x8d8e]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40a7b2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a7b7:	mov    BYTE PTR [r10],r11b
  40a7ba:	lea    r11,[r10+0x1]
  40a7be:	mov    r10,r11
  40a7c1:	test   r12,r12
  40a7c4:	jne    40a780 <__swc_fn_4fa09e82_000147_e9d46966+0x6a0>
  40a7c6:	test   r8,r8
  40a7c9:	jge    40a7d3 <__swc_fn_4fa09e82_000147_e9d46966+0x6f3>
  40a7cb:	mov    BYTE PTR [r11],0x2d
  40a7cf:	lea    r10,[r11+0x1]
  40a7d3:	mov    BYTE PTR [r10],0x0
  40a7d7:	sub    r10,0x1
  40a7db:	nop    DWORD PTR [rax+rax*1+0x0]
  40a7e0:	cmp    r9,r10
  40a7e3:	jae    40aa38 <__swc_fn_4fa09e82_000147_e9d46966+0x958>
  40a7e9:	mov    al,BYTE PTR [r10]
  40a7ec:	mov    dl,BYTE PTR [r9]
  40a7ef:	mov    BYTE PTR [r10],dl
  40a7f2:	sub    r10,0x1
  40a7f6:	mov    BYTE PTR [r9],al
  40a7f9:	inc    r9
  40a7fc:	jmp    40a7e0 <__swc_fn_4fa09e82_000147_e9d46966+0x700>
  40a7fe:	vcvttsd2si rdx,xmm1
  40a803:	mov    r8,rdx
  40a806:	vxorpd xmm0,xmm0,xmm0
  40a80a:	vcvtsi2sd xmm0,xmm0,rdx
  40a80f:	vsubsd xmm0,xmm1,xmm0
  40a813:	mov    r9d,0x8
  40a819:	vxorpd xmm2,xmm2,xmm2
  40a81d:	vcomisd xmm2,xmm0
  40a821:	jbe    40a82b <__swc_fn_4fa09e82_000147_e9d46966+0x74b>
  40a823:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x8d25]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40a82b:	test   r9d,r9d
  40a82e:	je     40a83a <__swc_fn_4fa09e82_000147_e9d46966+0x75a>
  40a830:	vmulsd xmm0,xmm0,xmm14
  40a835:	dec    r9d
  40a838:	jne    40a830 <__swc_fn_4fa09e82_000147_e9d46966+0x750>
  40a83a:	vcvttsd2si r9,xmm0
  40a83f:	mov    r10,r9
  40a842:	vxorpd xmm2,xmm2,xmm2
  40a846:	vcvtsi2sd xmm2,xmm2,r9
  40a84b:	vsubsd xmm0,xmm0,xmm2
  40a84f:	vcomisd xmm0,xmm10
  40a854:	lea    r9,[r9+0x1]
  40a858:	cmova  r10,r9
  40a85c:	cmp    r10,0x5f5e100
  40a863:	jne    40a87c <__swc_fn_4fa09e82_000147_e9d46966+0x79c>
  40a865:	lea    r8,[rdx-0x1]
  40a869:	vxorpd xmm0,xmm0,xmm0
  40a86d:	vcomisd xmm0,xmm1
  40a871:	lea    rdx,[rdx+0x1]
  40a875:	cmovbe r8,rdx
  40a879:	xor    r10d,r10d
  40a87c:	mov    r9,rcx
  40a87f:	test   r8,r8
  40a882:	jne    40a8a2 <__swc_fn_4fa09e82_000147_e9d46966+0x7c2>
  40a884:	vxorpd xmm0,xmm0,xmm0
  40a888:	vcomisd xmm0,xmm1
  40a88c:	jbe    40a895 <__swc_fn_4fa09e82_000147_e9d46966+0x7b5>
  40a88e:	mov    BYTE PTR [rcx],0x2d
  40a891:	lea    r9,[rcx+0x1]
  40a895:	mov    BYTE PTR [r9],0x30
  40a899:	add    r9,0x1
  40a89d:	jmp    40a93b <__swc_fn_4fa09e82_000147_e9d46966+0x85b>
  40a8a2:	mov    r9,rcx
  40a8a5:	mov    rdx,r8
  40a8a8:	nop    DWORD PTR [rax+rax*1+0x0]
  40a8b0:	mov    r11,rdx
  40a8b3:	movabs rdx,0x6666666666666667
  40a8bd:	mov    r15,rax
  40a8c0:	mov    rax,r11
  40a8c3:	imul   rdx
  40a8c6:	mov    r12,rdx
  40a8c9:	mov    rax,r15
  40a8cc:	sar    r12,0x2
  40a8d0:	mov    rdx,r12
  40a8d3:	shr    rdx,0x3f
  40a8d7:	add    r12,rdx
  40a8da:	mov    rdx,r12
  40a8dd:	imul   r13,r12,0xa
  40a8e1:	sub    r11,r13
  40a8e4:	mov    r13,QWORD PTR [rip+0x8c55]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40a8eb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a8f0:	mov    BYTE PTR [r9],r11b
  40a8f3:	lea    r11,[r9+0x1]
  40a8f7:	mov    r9,r11
  40a8fa:	test   r12,r12
  40a8fd:	jne    40a8b0 <__swc_fn_4fa09e82_000147_e9d46966+0x7d0>
  40a8ff:	test   r8,r8
  40a902:	jge    40a90c <__swc_fn_4fa09e82_000147_e9d46966+0x82c>
  40a904:	mov    BYTE PTR [r11],0x2d
  40a908:	lea    r9,[r11+0x1]
  40a90c:	mov    rdx,r9
  40a90f:	mov    BYTE PTR [r9],0x0
  40a913:	sub    r9,0x1
  40a917:	mov    r8,rcx
  40a91a:	cmp    r8,r9
  40a91d:	jae    40a938 <__swc_fn_4fa09e82_000147_e9d46966+0x858>
  40a91f:	nop
  40a920:	mov    r11b,BYTE PTR [r9]
  40a923:	mov    r12b,BYTE PTR [r8]
  40a926:	mov    BYTE PTR [r9],r12b
  40a929:	sub    r9,0x1
  40a92d:	mov    BYTE PTR [r8],r11b
  40a930:	inc    r8
  40a933:	cmp    r8,r9
  40a936:	jb     40a920 <__swc_fn_4fa09e82_000147_e9d46966+0x840>
  40a938:	mov    r9,rdx
  40a93b:	mov    BYTE PTR [r9],0x2e
  40a93f:	add    r9,0x1
  40a943:	xor    r8d,r8d
  40a946:	test   r10,r10
  40a949:	je     40a98f <__swc_fn_4fa09e82_000147_e9d46966+0x8af>
  40a94b:	mov    r11d,0x989680
  40a951:	cmp    r10,r11
  40a954:	jge    40a98f <__swc_fn_4fa09e82_000147_e9d46966+0x8af>
  40a956:	cs nop WORD PTR [rax+rax*1+0x0]
  40a960:	inc    r8d
  40a963:	movabs rdx,0x6666666666666667
  40a96d:	mov    r15,rax
  40a970:	mov    rax,r11
  40a973:	imul   rdx
  40a976:	mov    r11,rdx
  40a979:	mov    rax,r15
  40a97c:	sar    r11,0x2
  40a980:	mov    rdx,r11
  40a983:	shr    rdx,0x3f
  40a987:	add    r11,rdx
  40a98a:	cmp    r10,r11
  40a98d:	jl     40a960 <__swc_fn_4fa09e82_000147_e9d46966+0x880>
  40a98f:	test   r8d,r8d
  40a992:	je     40a9ad <__swc_fn_4fa09e82_000147_e9d46966+0x8cd>
  40a994:	cs nop WORD PTR [rax+rax*1+0x0]
  40a99e:	xchg   ax,ax
  40a9a0:	mov    BYTE PTR [r9],0x30
  40a9a4:	add    r9,0x1
  40a9a8:	dec    r8d
  40a9ab:	jne    40a9a0 <__swc_fn_4fa09e82_000147_e9d46966+0x8c0>
  40a9ad:	mov    r8,r9
  40a9b0:	mov    rdx,r10
  40a9b3:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9bd:	nop    DWORD PTR [rax]
  40a9c0:	mov    r11,rdx
  40a9c3:	movabs rdx,0x6666666666666667
  40a9cd:	mov    rax,r11
  40a9d0:	imul   rdx
  40a9d3:	sar    rdx,0x2
  40a9d7:	mov    r12,rdx
  40a9da:	shr    rdx,0x3f
  40a9de:	add    r12,rdx
  40a9e1:	mov    rdx,r12
  40a9e4:	imul   r13,r12,0xa
  40a9e8:	sub    r11,r13
  40a9eb:	mov    r13,QWORD PTR [rip+0x8b4e]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40a9f2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a9f7:	mov    BYTE PTR [r8],r11b
  40a9fa:	lea    r11,[r8+0x1]
  40a9fe:	mov    r8,r11
  40aa01:	test   r12,r12
  40aa04:	jne    40a9c0 <__swc_fn_4fa09e82_000147_e9d46966+0x8e0>
  40aa06:	test   r10,r10
  40aa09:	jge    40aa13 <__swc_fn_4fa09e82_000147_e9d46966+0x933>
  40aa0b:	mov    BYTE PTR [r11],0x2d
  40aa0f:	lea    r8,[r11+0x1]
  40aa13:	mov    BYTE PTR [r8],0x0
  40aa17:	sub    r8,0x1
  40aa1b:	cmp    r9,r8
  40aa1e:	jae    40aa38 <__swc_fn_4fa09e82_000147_e9d46966+0x958>
  40aa20:	mov    al,BYTE PTR [r8]
  40aa23:	mov    dl,BYTE PTR [r9]
  40aa26:	mov    BYTE PTR [r8],dl
  40aa29:	sub    r8,0x1
  40aa2d:	mov    BYTE PTR [r9],al
  40aa30:	inc    r9
  40aa33:	cmp    r9,r8
  40aa36:	jb     40aa20 <__swc_fn_4fa09e82_000147_e9d46966+0x940>
  40aa38:	xor    eax,eax
  40aa3a:	test   rcx,rcx
  40aa3d:	je     40aa70 <__swc_fn_4fa09e82_000147_e9d46966+0x990>
  40aa3f:	mov    rdx,rcx
  40aa42:	mov    r8b,BYTE PTR [rdx]
  40aa45:	test   r8b,r8b
  40aa48:	je     40aa70 <__swc_fn_4fa09e82_000147_e9d46966+0x990>
  40aa4a:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa54:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa5e:	xchg   ax,ax
  40aa60:	add    rdx,0x1
  40aa64:	add    rax,0x1
  40aa68:	mov    r8b,BYTE PTR [rdx]
  40aa6b:	test   r8b,r8b
  40aa6e:	jne    40aa60 <__swc_fn_4fa09e82_000147_e9d46966+0x980>
  40aa70:	mov    QWORD PTR [rsp+0x240],rcx
  40aa78:	mov    QWORD PTR [rsp+0x248],rax
  40aa80:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  40aa89:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  40aa92:	lea    rcx,[rsp+0x250]
  40aa9a:	call   409870 <__swc_fn_4fa09e82_000117_3499f7d6>
  40aa9f:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40aaa4:	lea    rcx,[rsp+0x260]
  40aaac:	vxorps xmm0,xmm0,xmm0
  40aab0:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  40aab9:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  40aac2:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  40aacb:	vzeroupper
  40aace:	mov    DWORD PTR [rsp+0x2c0],0x0
  40aad9:	vmovsd xmm0,QWORD PTR [rdx]
  40aadd:	vcomisd xmm0,xmm0
  40aae1:	setne  dl
  40aae4:	movzx  edx,dl
  40aae7:	setp   r8b
  40aaeb:	movzx  r8d,r8b
  40aaef:	or     edx,r8d
  40aaf2:	test   dl,dl
  40aaf4:	je     40ab01 <__swc_fn_4fa09e82_000147_e9d46966+0xa21>
  40aaf6:	mov    DWORD PTR [rcx],0x6e616e
  40aafc:	jmp    40b108 <__swc_fn_4fa09e82_000147_e9d46966+0x1028>
  40ab01:	vcomisd xmm0,xmm11
  40ab06:	ja     40ab17 <__swc_fn_4fa09e82_000147_e9d46966+0xa37>
  40ab08:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  40ab11:	vcomisd xmm6,xmm0
  40ab15:	jbe    40ab3b <__swc_fn_4fa09e82_000147_e9d46966+0xa5b>
  40ab17:	vxorpd xmm1,xmm1,xmm1
  40ab1b:	vcomisd xmm1,xmm0
  40ab1f:	jbe    40ab30 <__swc_fn_4fa09e82_000147_e9d46966+0xa50>
  40ab21:	mov    DWORD PTR [rcx],0x666e692d
  40ab27:	mov    BYTE PTR [rcx+0x4],0x0
  40ab2b:	jmp    40b108 <__swc_fn_4fa09e82_000147_e9d46966+0x1028>
  40ab30:	mov    DWORD PTR [rcx],0x666e69
  40ab36:	jmp    40b108 <__swc_fn_4fa09e82_000147_e9d46966+0x1028>
  40ab3b:	vcomisd xmm0,xmm13
  40ab40:	jae    40ab4c <__swc_fn_4fa09e82_000147_e9d46966+0xa6c>
  40ab42:	vcomisd xmm12,xmm0
  40ab46:	jbe    40aeae <__swc_fn_4fa09e82_000147_e9d46966+0xdce>
  40ab4c:	vmovups xmm1,xmm0
  40ab50:	vxorpd xmm2,xmm2,xmm2
  40ab54:	vcomisd xmm2,xmm0
  40ab58:	jbe    40ab68 <__swc_fn_4fa09e82_000147_e9d46966+0xa88>
  40ab5a:	vmovsd xmm0,xmm0,xmm1
  40ab5e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x89ea]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40ab66:	jmp    40ab6c <__swc_fn_4fa09e82_000147_e9d46966+0xa8c>
  40ab68:	vmovsd xmm0,xmm0,xmm1
  40ab6c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  40ab75:	xor    r8d,r8d
  40ab78:	vcomisd xmm0,xmm6
  40ab7c:	jb     40ab8e <__swc_fn_4fa09e82_000147_e9d46966+0xaae>
  40ab7e:	xchg   ax,ax
  40ab80:	vdivsd xmm0,xmm0,xmm6
  40ab84:	add    r8,0x1
  40ab88:	vcomisd xmm0,xmm6
  40ab8c:	jae    40ab80 <__swc_fn_4fa09e82_000147_e9d46966+0xaa0>
  40ab8e:	mov    r9,rcx
  40ab91:	vxorpd xmm2,xmm2,xmm2
  40ab95:	vcomisd xmm2,xmm1
  40ab99:	jbe    40aba2 <__swc_fn_4fa09e82_000147_e9d46966+0xac2>
  40ab9b:	mov    BYTE PTR [rcx],0x2d
  40ab9e:	lea    r9,[rcx+0x1]
  40aba2:	vcvttsd2si rdx,xmm0
  40aba7:	mov    r10b,dl
  40abaa:	add    r10b,0x30
  40abae:	mov    BYTE PTR [r9],r10b
  40abb1:	vxorpd xmm1,xmm1,xmm1
  40abb5:	movzx  edx,dl
  40abb8:	vcvtsi2sd xmm1,xmm1,rdx
  40abbd:	vsubsd xmm0,xmm0,xmm1
  40abc1:	vmulsd xmm0,xmm0,xmm6
  40abc5:	mov    BYTE PTR [r9+0x1],0x2e
  40abca:	vcvttsd2si rdx,xmm0
  40abcf:	mov    r10b,dl
  40abd2:	add    r10b,0x30
  40abd6:	mov    BYTE PTR [r9+0x2],r10b
  40abda:	vxorpd xmm1,xmm1,xmm1
  40abde:	movzx  edx,dl
  40abe1:	vcvtsi2sd xmm1,xmm1,rdx
  40abe6:	vsubsd xmm0,xmm0,xmm1
  40abea:	vmulsd xmm0,xmm0,xmm6
  40abee:	vcvttsd2si rdx,xmm0
  40abf3:	mov    r10b,dl
  40abf6:	add    r10b,0x30
  40abfa:	mov    BYTE PTR [r9+0x3],r10b
  40abfe:	vxorpd xmm1,xmm1,xmm1
  40ac02:	movzx  edx,dl
  40ac05:	vcvtsi2sd xmm1,xmm1,rdx
  40ac0a:	vsubsd xmm0,xmm0,xmm1
  40ac0e:	vmulsd xmm0,xmm0,xmm6
  40ac12:	vcvttsd2si rdx,xmm0
  40ac17:	mov    r10b,dl
  40ac1a:	add    r10b,0x30
  40ac1e:	mov    BYTE PTR [r9+0x4],r10b
  40ac22:	vxorpd xmm1,xmm1,xmm1
  40ac26:	movzx  edx,dl
  40ac29:	vcvtsi2sd xmm1,xmm1,rdx
  40ac2e:	vsubsd xmm0,xmm0,xmm1
  40ac32:	vmulsd xmm0,xmm0,xmm6
  40ac36:	vcvttsd2si rdx,xmm0
  40ac3b:	mov    r10b,dl
  40ac3e:	add    r10b,0x30
  40ac42:	mov    BYTE PTR [r9+0x5],r10b
  40ac46:	vxorpd xmm1,xmm1,xmm1
  40ac4a:	movzx  edx,dl
  40ac4d:	vcvtsi2sd xmm1,xmm1,rdx
  40ac52:	vsubsd xmm0,xmm0,xmm1
  40ac56:	vmulsd xmm0,xmm0,xmm6
  40ac5a:	vcvttsd2si rdx,xmm0
  40ac5f:	mov    r10b,dl
  40ac62:	add    r10b,0x30
  40ac66:	mov    BYTE PTR [r9+0x6],r10b
  40ac6a:	vxorpd xmm1,xmm1,xmm1
  40ac6e:	movzx  edx,dl
  40ac71:	vcvtsi2sd xmm1,xmm1,rdx
  40ac76:	vsubsd xmm0,xmm0,xmm1
  40ac7a:	vmulsd xmm0,xmm0,xmm6
  40ac7e:	vcvttsd2si rdx,xmm0
  40ac83:	mov    r10b,dl
  40ac86:	add    r10b,0x30
  40ac8a:	mov    BYTE PTR [r9+0x7],r10b
  40ac8e:	vxorpd xmm1,xmm1,xmm1
  40ac92:	movzx  edx,dl
  40ac95:	vcvtsi2sd xmm1,xmm1,rdx
  40ac9a:	vsubsd xmm0,xmm0,xmm1
  40ac9e:	vmulsd xmm0,xmm0,xmm6
  40aca2:	vcvttsd2si rdx,xmm0
  40aca7:	mov    r10b,dl
  40acaa:	add    r10b,0x30
  40acae:	mov    BYTE PTR [r9+0x8],r10b
  40acb2:	vxorpd xmm1,xmm1,xmm1
  40acb6:	movzx  edx,dl
  40acb9:	vcvtsi2sd xmm1,xmm1,rdx
  40acbe:	vsubsd xmm0,xmm0,xmm1
  40acc2:	vmulsd xmm0,xmm0,xmm6
  40acc6:	vcvttsd2si rdx,xmm0
  40accb:	mov    r10b,dl
  40acce:	add    r10b,0x30
  40acd2:	mov    BYTE PTR [r9+0x9],r10b
  40acd6:	vxorpd xmm1,xmm1,xmm1
  40acda:	movzx  edx,dl
  40acdd:	vcvtsi2sd xmm1,xmm1,rdx
  40ace2:	vsubsd xmm0,xmm0,xmm1
  40ace6:	vmulsd xmm0,xmm0,xmm6
  40acea:	vcvttsd2si rdx,xmm0
  40acef:	mov    r10b,dl
  40acf2:	add    r10b,0x30
  40acf6:	mov    BYTE PTR [r9+0xa],r10b
  40acfa:	vxorpd xmm1,xmm1,xmm1
  40acfe:	movzx  edx,dl
  40ad01:	vcvtsi2sd xmm1,xmm1,rdx
  40ad06:	vsubsd xmm0,xmm0,xmm1
  40ad0a:	vmulsd xmm0,xmm0,xmm6
  40ad0e:	vcvttsd2si rdx,xmm0
  40ad13:	mov    r10b,dl
  40ad16:	add    r10b,0x30
  40ad1a:	mov    BYTE PTR [r9+0xb],r10b
  40ad1e:	lea    r10,[r9+0x4]
  40ad22:	vxorpd xmm1,xmm1,xmm1
  40ad26:	movzx  edx,dl
  40ad29:	vcvtsi2sd xmm1,xmm1,rdx
  40ad2e:	vsubsd xmm0,xmm0,xmm1
  40ad32:	vmulsd xmm0,xmm0,xmm6
  40ad36:	vcvttsd2si rdx,xmm0
  40ad3b:	mov    r11b,dl
  40ad3e:	add    r11b,0x30
  40ad42:	mov    BYTE PTR [r9+0xc],r11b
  40ad46:	vxorpd xmm1,xmm1,xmm1
  40ad4a:	movzx  edx,dl
  40ad4d:	vcvtsi2sd xmm1,xmm1,rdx
  40ad52:	vsubsd xmm0,xmm0,xmm1
  40ad56:	vmulsd xmm0,xmm0,xmm6
  40ad5a:	vcvttsd2si rdx,xmm0
  40ad5f:	mov    r11b,dl
  40ad62:	add    r11b,0x30
  40ad66:	mov    BYTE PTR [r9+0xd],r11b
  40ad6a:	lea    r10,[r10+0x2]
  40ad6e:	vxorpd xmm1,xmm1,xmm1
  40ad72:	movzx  edx,dl
  40ad75:	vcvtsi2sd xmm1,xmm1,rdx
  40ad7a:	vsubsd xmm0,xmm0,xmm1
  40ad7e:	vmulsd xmm0,xmm0,xmm6
  40ad82:	vcvttsd2si rdx,xmm0
  40ad87:	mov    r11b,dl
  40ad8a:	add    r11b,0x30
  40ad8e:	mov    BYTE PTR [r9+0xe],r11b
  40ad92:	vxorpd xmm1,xmm1,xmm1
  40ad96:	movzx  edx,dl
  40ad99:	vcvtsi2sd xmm1,xmm1,rdx
  40ad9e:	vsubsd xmm0,xmm0,xmm1
  40ada2:	vmulsd xmm0,xmm0,xmm6
  40ada6:	vcvttsd2si rdx,xmm0
  40adab:	mov    r11b,dl
  40adae:	add    r11b,0x30
  40adb2:	mov    BYTE PTR [r9+0xf],r11b
  40adb6:	lea    r10,[r10+0x2]
  40adba:	lea    r10,[r10+0x2]
  40adbe:	lea    r10,[r10+0x2]
  40adc2:	lea    r10,[r10+0x2]
  40adc6:	lea    r10,[r10+0x2]
  40adca:	vxorpd xmm1,xmm1,xmm1
  40adce:	movzx  edx,dl
  40add1:	vcvtsi2sd xmm1,xmm1,rdx
  40add6:	vsubsd xmm0,xmm0,xmm1
  40adda:	vmulsd xmm0,xmm0,xmm6
  40adde:	vcvttsd2si rdx,xmm0
  40ade3:	mov    r11b,dl
  40ade6:	add    r11b,0x30
  40adea:	mov    BYTE PTR [r9+0x10],r11b
  40adee:	vxorpd xmm1,xmm1,xmm1
  40adf2:	movzx  edx,dl
  40adf5:	vcvtsi2sd xmm1,xmm1,rdx
  40adfa:	vsubsd xmm0,xmm0,xmm1
  40adfe:	vmulsd xmm0,xmm0,xmm6
  40ae02:	vcvttsd2si rdx,xmm0
  40ae07:	add    dl,0x30
  40ae0a:	mov    BYTE PTR [r9+0x11],dl
  40ae0e:	mov    BYTE PTR [r10+0x2],0x65
  40ae13:	lea    r9,[r10+0x3]
  40ae17:	test   r8,r8
  40ae1a:	jl     40ae23 <__swc_fn_4fa09e82_000147_e9d46966+0xd43>
  40ae1c:	mov    BYTE PTR [r9],0x2b
  40ae20:	inc    r9
  40ae23:	mov    r10,r9
  40ae26:	mov    rdx,r8
  40ae29:	nop    DWORD PTR [rax+0x0]
  40ae30:	mov    r11,rdx
  40ae33:	movabs rdx,0x6666666666666667
  40ae3d:	mov    rax,r11
  40ae40:	imul   rdx
  40ae43:	sar    rdx,0x2
  40ae47:	mov    r12,rdx
  40ae4a:	shr    rdx,0x3f
  40ae4e:	add    r12,rdx
  40ae51:	mov    rdx,r12
  40ae54:	imul   r13,r12,0xa
  40ae58:	sub    r11,r13
  40ae5b:	mov    r13,QWORD PTR [rip+0x86de]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40ae62:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40ae67:	mov    BYTE PTR [r10],r11b
  40ae6a:	lea    r11,[r10+0x1]
  40ae6e:	mov    r10,r11
  40ae71:	test   r12,r12
  40ae74:	jne    40ae30 <__swc_fn_4fa09e82_000147_e9d46966+0xd50>
  40ae76:	test   r8,r8
  40ae79:	jge    40ae83 <__swc_fn_4fa09e82_000147_e9d46966+0xda3>
  40ae7b:	mov    BYTE PTR [r11],0x2d
  40ae7f:	lea    r10,[r11+0x1]
  40ae83:	mov    BYTE PTR [r10],0x0
  40ae87:	sub    r10,0x1
  40ae8b:	nop    DWORD PTR [rax+rax*1+0x0]
  40ae90:	cmp    r9,r10
  40ae93:	jae    40b108 <__swc_fn_4fa09e82_000147_e9d46966+0x1028>
  40ae99:	mov    al,BYTE PTR [r10]
  40ae9c:	mov    dl,BYTE PTR [r9]
  40ae9f:	mov    BYTE PTR [r10],dl
  40aea2:	sub    r10,0x1
  40aea6:	mov    BYTE PTR [r9],al
  40aea9:	inc    r9
  40aeac:	jmp    40ae90 <__swc_fn_4fa09e82_000147_e9d46966+0xdb0>
  40aeae:	vcvttsd2si rdx,xmm0
  40aeb3:	mov    r8,rdx
  40aeb6:	vxorpd xmm1,xmm1,xmm1
  40aeba:	vcvtsi2sd xmm1,xmm1,rdx
  40aebf:	vsubsd xmm1,xmm0,xmm1
  40aec3:	mov    r9d,0x8
  40aec9:	vxorpd xmm2,xmm2,xmm2
  40aecd:	vcomisd xmm2,xmm1
  40aed1:	ja     40aede <__swc_fn_4fa09e82_000147_e9d46966+0xdfe>
  40aed3:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40aedc:	jmp    40aeef <__swc_fn_4fa09e82_000147_e9d46966+0xe0f>
  40aede:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x866a]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40aee6:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40aeef:	test   r9d,r9d
  40aef2:	je     40af09 <__swc_fn_4fa09e82_000147_e9d46966+0xe29>
  40aef4:	cs nop WORD PTR [rax+rax*1+0x0]
  40aefe:	xchg   ax,ax
  40af00:	vmulsd xmm1,xmm1,xmm6
  40af04:	dec    r9d
  40af07:	jne    40af00 <__swc_fn_4fa09e82_000147_e9d46966+0xe20>
  40af09:	vcvttsd2si r9,xmm1
  40af0e:	mov    r10,r9
  40af11:	vxorpd xmm2,xmm2,xmm2
  40af15:	vcvtsi2sd xmm2,xmm2,r9
  40af1a:	vsubsd xmm1,xmm1,xmm2
  40af1e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  40af27:	vcomisd xmm1,xmm6
  40af2b:	lea    r9,[r9+0x1]
  40af2f:	cmova  r10,r9
  40af33:	cmp    r10,0x5f5e100
  40af3a:	jne    40af53 <__swc_fn_4fa09e82_000147_e9d46966+0xe73>
  40af3c:	lea    r8,[rdx-0x1]
  40af40:	vxorpd xmm1,xmm1,xmm1
  40af44:	vcomisd xmm1,xmm0
  40af48:	lea    rdx,[rdx+0x1]
  40af4c:	cmovbe r8,rdx
  40af50:	xor    r10d,r10d
  40af53:	mov    r9,rcx
  40af56:	test   r8,r8
  40af59:	jne    40af79 <__swc_fn_4fa09e82_000147_e9d46966+0xe99>
  40af5b:	vxorpd xmm1,xmm1,xmm1
  40af5f:	vcomisd xmm1,xmm0
  40af63:	jbe    40af6c <__swc_fn_4fa09e82_000147_e9d46966+0xe8c>
  40af65:	mov    BYTE PTR [rcx],0x2d
  40af68:	lea    r9,[rcx+0x1]
  40af6c:	mov    BYTE PTR [r9],0x30
  40af70:	add    r9,0x1
  40af74:	jmp    40b00b <__swc_fn_4fa09e82_000147_e9d46966+0xf2b>
  40af79:	mov    r9,rcx
  40af7c:	mov    rdx,r8
  40af7f:	nop
  40af80:	mov    r11,rdx
  40af83:	movabs rdx,0x6666666666666667
  40af8d:	mov    r15,rax
  40af90:	mov    rax,r11
  40af93:	imul   rdx
  40af96:	mov    r12,rdx
  40af99:	mov    rax,r15
  40af9c:	sar    r12,0x2
  40afa0:	mov    rdx,r12
  40afa3:	shr    rdx,0x3f
  40afa7:	add    r12,rdx
  40afaa:	mov    rdx,r12
  40afad:	imul   r13,r12,0xa
  40afb1:	sub    r11,r13
  40afb4:	mov    r13,QWORD PTR [rip+0x8585]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40afbb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40afc0:	mov    BYTE PTR [r9],r11b
  40afc3:	lea    r11,[r9+0x1]
  40afc7:	mov    r9,r11
  40afca:	test   r12,r12
  40afcd:	jne    40af80 <__swc_fn_4fa09e82_000147_e9d46966+0xea0>
  40afcf:	test   r8,r8
  40afd2:	jge    40afdc <__swc_fn_4fa09e82_000147_e9d46966+0xefc>
  40afd4:	mov    BYTE PTR [r11],0x2d
  40afd8:	lea    r9,[r11+0x1]
  40afdc:	mov    rdx,r9
  40afdf:	mov    BYTE PTR [r9],0x0
  40afe3:	sub    r9,0x1
  40afe7:	mov    r8,rcx
  40afea:	cmp    r8,r9
  40afed:	jae    40b008 <__swc_fn_4fa09e82_000147_e9d46966+0xf28>
  40afef:	nop
  40aff0:	mov    r11b,BYTE PTR [r9]
  40aff3:	mov    r12b,BYTE PTR [r8]
  40aff6:	mov    BYTE PTR [r9],r12b
  40aff9:	sub    r9,0x1
  40affd:	mov    BYTE PTR [r8],r11b
  40b000:	inc    r8
  40b003:	cmp    r8,r9
  40b006:	jb     40aff0 <__swc_fn_4fa09e82_000147_e9d46966+0xf10>
  40b008:	mov    r9,rdx
  40b00b:	mov    BYTE PTR [r9],0x2e
  40b00f:	add    r9,0x1
  40b013:	xor    r8d,r8d
  40b016:	test   r10,r10
  40b019:	je     40b05f <__swc_fn_4fa09e82_000147_e9d46966+0xf7f>
  40b01b:	mov    r11d,0x989680
  40b021:	cmp    r10,r11
  40b024:	jge    40b05f <__swc_fn_4fa09e82_000147_e9d46966+0xf7f>
  40b026:	cs nop WORD PTR [rax+rax*1+0x0]
  40b030:	inc    r8d
  40b033:	movabs rdx,0x6666666666666667
  40b03d:	mov    r15,rax
  40b040:	mov    rax,r11
  40b043:	imul   rdx
  40b046:	mov    r11,rdx
  40b049:	mov    rax,r15
  40b04c:	sar    r11,0x2
  40b050:	mov    rdx,r11
  40b053:	shr    rdx,0x3f
  40b057:	add    r11,rdx
  40b05a:	cmp    r10,r11
  40b05d:	jl     40b030 <__swc_fn_4fa09e82_000147_e9d46966+0xf50>
  40b05f:	test   r8d,r8d
  40b062:	je     40b07d <__swc_fn_4fa09e82_000147_e9d46966+0xf9d>
  40b064:	cs nop WORD PTR [rax+rax*1+0x0]
  40b06e:	xchg   ax,ax
  40b070:	mov    BYTE PTR [r9],0x30
  40b074:	add    r9,0x1
  40b078:	dec    r8d
  40b07b:	jne    40b070 <__swc_fn_4fa09e82_000147_e9d46966+0xf90>
  40b07d:	mov    r8,r9
  40b080:	mov    rdx,r10
  40b083:	cs nop WORD PTR [rax+rax*1+0x0]
  40b08d:	nop    DWORD PTR [rax]
  40b090:	mov    r11,rdx
  40b093:	movabs rdx,0x6666666666666667
  40b09d:	mov    rax,r11
  40b0a0:	imul   rdx
  40b0a3:	sar    rdx,0x2
  40b0a7:	mov    r12,rdx
  40b0aa:	shr    rdx,0x3f
  40b0ae:	add    r12,rdx
  40b0b1:	mov    rdx,r12
  40b0b4:	imul   r13,r12,0xa
  40b0b8:	sub    r11,r13
  40b0bb:	mov    r13,QWORD PTR [rip+0x847e]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40b0c2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b0c7:	mov    BYTE PTR [r8],r11b
  40b0ca:	lea    r11,[r8+0x1]
  40b0ce:	mov    r8,r11
  40b0d1:	test   r12,r12
  40b0d4:	jne    40b090 <__swc_fn_4fa09e82_000147_e9d46966+0xfb0>
  40b0d6:	test   r10,r10
  40b0d9:	jge    40b0e3 <__swc_fn_4fa09e82_000147_e9d46966+0x1003>
  40b0db:	mov    BYTE PTR [r11],0x2d
  40b0df:	lea    r8,[r11+0x1]
  40b0e3:	mov    BYTE PTR [r8],0x0
  40b0e7:	sub    r8,0x1
  40b0eb:	cmp    r9,r8
  40b0ee:	jae    40b108 <__swc_fn_4fa09e82_000147_e9d46966+0x1028>
  40b0f0:	mov    al,BYTE PTR [r8]
  40b0f3:	mov    dl,BYTE PTR [r9]
  40b0f6:	mov    BYTE PTR [r8],dl
  40b0f9:	sub    r8,0x1
  40b0fd:	mov    BYTE PTR [r9],al
  40b100:	inc    r9
  40b103:	cmp    r9,r8
  40b106:	jb     40b0f0 <__swc_fn_4fa09e82_000147_e9d46966+0x1010>
  40b108:	xor    eax,eax
  40b10a:	test   rcx,rcx
  40b10d:	je     40b130 <__swc_fn_4fa09e82_000147_e9d46966+0x1050>
  40b10f:	mov    rdx,rcx
  40b112:	mov    r8b,BYTE PTR [rdx]
  40b115:	test   r8b,r8b
  40b118:	je     40b130 <__swc_fn_4fa09e82_000147_e9d46966+0x1050>
  40b11a:	nop    WORD PTR [rax+rax*1+0x0]
  40b120:	add    rdx,0x1
  40b124:	add    rax,0x1
  40b128:	mov    r8b,BYTE PTR [rdx]
  40b12b:	test   r8b,r8b
  40b12e:	jne    40b120 <__swc_fn_4fa09e82_000147_e9d46966+0x1040>
  40b130:	mov    QWORD PTR [rsp+0x3f8],rcx
  40b138:	mov    QWORD PTR [rsp+0x400],rax
  40b140:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  40b149:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  40b152:	lea    rcx,[rsp+0x408]
  40b15a:	call   409870 <__swc_fn_4fa09e82_000117_3499f7d6>
  40b15f:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40b161:	mov    rcx,rdx
  40b164:	call   409870 <__swc_fn_4fa09e82_000117_3499f7d6>
  40b169:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40b16b:	mov    al,BYTE PTR [rdx]
  40b16d:	test   al,al
  40b16f:	je     40b17a <__swc_fn_4fa09e82_000147_e9d46966+0x109a>
  40b171:	lea    rax,[rip+0x83e8]        # 413560 <__swc_rdata_base_4fa09e82+0x450>
  40b178:	jmp    40b181 <__swc_fn_4fa09e82_000147_e9d46966+0x10a1>
  40b17a:	lea    rax,[rip+0x83ef]        # 413570 <__swc_rdata_base_4fa09e82+0x460>
  40b181:	mov    rcx,rax
  40b184:	call   409870 <__swc_fn_4fa09e82_000117_3499f7d6>
  40b189:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40b18b:	lea    rcx,[rip+0x83ee]        # 413580 <__swc_rdata_base_4fa09e82+0x470>
  40b192:	call   409870 <__swc_fn_4fa09e82_000117_3499f7d6>
  40b197:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_e9d46966+0x10c5>
  40b199:	lea    rcx,[rip+0x83e0]        # 413580 <__swc_rdata_base_4fa09e82+0x470>
  40b1a0:	call   409870 <__swc_fn_4fa09e82_000117_3499f7d6>
  40b1a5:	add    rdi,0x1
  40b1a9:	sub    rsi,0x1
  40b1ad:	vmovups xmm0,xmm12
  40b1b2:	vmovsd xmm6,QWORD PTR [rip+0x83d6]        # 413590 <__swc_rdata_base_4fa09e82+0x480>
  40b1ba:	test   rsi,rsi
  40b1bd:	jne    40a1f0 <__swc_fn_4fa09e82_000147_e9d46966+0x110>
  40b1c3:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  40b1cc:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  40b1d5:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  40b1de:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  40b1e7:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  40b1f0:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  40b1f9:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  40b202:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  40b20b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  40b214:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  40b21d:	add    rsp,0x4e8
  40b224:	pop    r15
  40b226:	pop    r13
  40b228:	pop    r12
  40b22a:	pop    rdi
  40b22b:	pop    rsi
  40b22c:	pop    rbx
  40b22d:	ret
	...

000000000040b230 <__swc_fn_4fa09e82_000150_33e5e24f>:
  40b230:	vxorps xmm0,xmm0,xmm0
  40b234:	vmovups XMMWORD PTR [rcx],xmm0
  40b238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b23d:	ret
	...

000000000040b240 <__swc_fn_4fa09e82_000153_33e5e24f>:
  40b240:	vxorps xmm0,xmm0,xmm0
  40b244:	vmovups XMMWORD PTR [rcx],xmm0
  40b248:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b24d:	vxorps xmm0,xmm0,xmm0
  40b251:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b256:	vmovups xmm0,XMMWORD PTR [rip+0x8442]        # 4136a0 <__swc_rdata_base_4fa09e82+0x590>
  40b25e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b263:	vxorps xmm0,xmm0,xmm0
  40b267:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b26c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40b271:	vxorps xmm0,xmm0,xmm0
  40b275:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40b27a:	mov    QWORD PTR [rcx+0x70],0x0
  40b282:	ret
	...

000000000040b290 <__swc_fn_4fa09e82_000156_33e5e24f>:
  40b290:	vxorps xmm0,xmm0,xmm0
  40b294:	vmovups XMMWORD PTR [rcx],xmm0
  40b298:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b29d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b2a2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b2a7:	ret
	...

000000000040b2b0 <__swc_fn_4fa09e82_000159_6741c23b>:
  40b2b0:	push   rsi
  40b2b1:	push   rdi
  40b2b2:	sub    rsp,0x8
  40b2b6:	mov    rsi,rcx
  40b2b9:	mov    rdi,QWORD PTR [rsi+0x50]
  40b2bd:	test   rdi,rdi
  40b2c0:	je     40b2c7 <__swc_fn_4fa09e82_000159_6741c23b+0x17>
  40b2c2:	mov    rcx,rsi
  40b2c5:	call   rdi
  40b2c7:	mov    QWORD PTR [rsi+0x20],0x0
  40b2cf:	mov    rax,QWORD PTR [rsi+0x30]
  40b2d3:	test   rax,rax
  40b2d6:	je     40b304 <__swc_fn_4fa09e82_000159_6741c23b+0x54>
  40b2d8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b2e0:	mov    rdi,QWORD PTR [rax+0x8]
  40b2e4:	mov    rcx,rsi
  40b2e7:	mov    rdx,QWORD PTR [rax+0x10]
  40b2eb:	mov    rax,QWORD PTR [rax+0x18]
  40b2ef:	mov    r8,rax
  40b2f2:	call   40ed50 <__swc_fn_4fa09e82_000157_312df05a>
  40b2f7:	mov    QWORD PTR [rsi+0x30],rdi
  40b2fb:	mov    rax,QWORD PTR [rsi+0x30]
  40b2ff:	test   rax,rax
  40b302:	jne    40b2e0 <__swc_fn_4fa09e82_000159_6741c23b+0x30>
  40b304:	mov    QWORD PTR [rsi+0x38],0x0
  40b30c:	add    rsp,0x8
  40b310:	pop    rdi
  40b311:	pop    rsi
  40b312:	ret
	...

000000000040b320 <__swc_fn_4fa09e82_000162_9e36e814>:
  40b320:	push   rbx
  40b321:	push   rsi
  40b322:	push   rdi
  40b323:	push   r12
  40b325:	sub    rsp,0x188
  40b32c:	mov    rbx,rcx
  40b32f:	lea    rsi,[rip+0x1ba5a]        # 426d90 <__swc_bss_base_4fa09e82+0x2d50>
  40b336:	mov    rcx,rsi
  40b339:	call   40e760 <__swc_fn_4fa09e82_000136_1fec60ac>
  40b33e:	mov    rax,QWORD PTR [rip+0x1ba53]        # 426d98 <__swc_bss_base_4fa09e82+0x2d58>
  40b345:	mov    rdi,rax
  40b348:	test   rdi,rdi
  40b34b:	je     40b379 <__swc_fn_4fa09e82_000162_9e36e814+0x59>
  40b34d:	nop    DWORD PTR [rax]
  40b350:	cmp    QWORD PTR [rdi+0x8],rbx
  40b354:	jne    40b36e <__swc_fn_4fa09e82_000162_9e36e814+0x4e>
  40b356:	mov    rcx,rsi
  40b359:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40b35e:	mov    rax,rdi
  40b361:	add    rsp,0x188
  40b368:	pop    r12
  40b36a:	pop    rdi
  40b36b:	pop    rsi
  40b36c:	pop    rbx
  40b36d:	ret
  40b36e:	mov    rax,QWORD PTR [rdi]
  40b371:	mov    rdi,rax
  40b374:	test   rax,rax
  40b377:	jne    40b350 <__swc_fn_4fa09e82_000162_9e36e814+0x30>
  40b379:	call   4118e0 <__swc_fn_4fa09e82_000140_20e2e2c7>
  40b37e:	mov    rdi,rax
  40b381:	test   rax,rax
  40b384:	jne    40b39d <__swc_fn_4fa09e82_000162_9e36e814+0x7d>
  40b386:	mov    rcx,rsi
  40b389:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40b38e:	xor    eax,eax
  40b390:	add    rsp,0x188
  40b397:	pop    r12
  40b399:	pop    rdi
  40b39a:	pop    rsi
  40b39b:	pop    rbx
  40b39c:	ret
  40b39d:	lea    rax,[rsp+0x18]
  40b3a2:	mov    QWORD PTR [rax+0x10],0x0
  40b3aa:	mov    QWORD PTR [rax+0x18],0x0
  40b3b2:	mov    DWORD PTR [rax+0x20],0x0
  40b3b9:	mov    BYTE PTR [rax+0x24],0x0
  40b3bd:	mov    rax,QWORD PTR [rip+0x1b9d4]        # 426d98 <__swc_bss_base_4fa09e82+0x2d58>
  40b3c4:	mov    QWORD PTR [rsp+0x18],rax
  40b3c9:	mov    QWORD PTR [rsp+0x20],rbx
  40b3ce:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40b3d4:	vmovups XMMWORD PTR [rdi],xmm0
  40b3d8:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40b3de:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  40b3e3:	mov    rax,QWORD PTR [rsp+0x38]
  40b3e8:	mov    QWORD PTR [rdi+0x20],rax
  40b3ec:	mov    QWORD PTR [rip+0x1b9a5],rdi        # 426d98 <__swc_bss_base_4fa09e82+0x2d58>
  40b3f3:	lea    rax,[rsp+0x40]
  40b3f8:	mov    QWORD PTR [rax],0x0
  40b3ff:	mov    rcx,rbx
  40b402:	mov    rdx,rax
  40b405:	call   40e840 <__swc_fn_4fa09e82_000142_376d5f6d>
  40b40a:	mov    rbx,rax
  40b40d:	test   rax,rax
  40b410:	jne    40b42a <__swc_fn_4fa09e82_000162_9e36e814+0x10a>
  40b412:	mov    rcx,rsi
  40b415:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40b41a:	mov    rax,rdi
  40b41d:	add    rsp,0x188
  40b424:	pop    r12
  40b426:	pop    rdi
  40b427:	pop    rsi
  40b428:	pop    rbx
  40b429:	ret
  40b42a:	lea    r12,[rsp+0x50]
  40b42f:	mov    QWORD PTR [r12],0x0
  40b437:	mov    rcx,rbx
  40b43a:	mov    rdx,QWORD PTR [rsp+0x40]
  40b43f:	mov    r8,r12
  40b442:	call   411990 <__swc_fn_4fa09e82_000143_e0543f36>
  40b447:	test   rax,rax
  40b44a:	jne    40b464 <__swc_fn_4fa09e82_000162_9e36e814+0x144>
  40b44c:	mov    rcx,rsi
  40b44f:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40b454:	mov    rax,rdi
  40b457:	add    rsp,0x188
  40b45e:	pop    r12
  40b460:	pop    rdi
  40b461:	pop    rsi
  40b462:	pop    rbx
  40b463:	ret
  40b464:	cmp    QWORD PTR [r12],0x10
  40b469:	jb     40b56c <__swc_fn_4fa09e82_000162_9e36e814+0x24c>
  40b46f:	mov    ecx,DWORD PTR [rax]
  40b471:	cmp    ecx,0x42445753
  40b477:	jne    40b56c <__swc_fn_4fa09e82_000162_9e36e814+0x24c>
  40b47d:	mov    ecx,DWORD PTR [rax+0x4]
  40b480:	cmp    ecx,0x1
  40b483:	jne    40b56c <__swc_fn_4fa09e82_000162_9e36e814+0x24c>
  40b489:	mov    ecx,DWORD PTR [rax+0x8]
  40b48c:	mov    edx,DWORD PTR [rax+0xc]
  40b48f:	imul   r8,rcx,0x14
  40b493:	mov    r9,QWORD PTR [rsp+0x50]
  40b498:	sub    r9,0x10
  40b49c:	cmp    r8,r9
  40b49f:	ja     40b56c <__swc_fn_4fa09e82_000162_9e36e814+0x24c>
  40b4a5:	lea    r8,[r8+0x10]
  40b4a9:	cmp    rdx,r8
  40b4ac:	jb     40b56c <__swc_fn_4fa09e82_000162_9e36e814+0x24c>
  40b4b2:	mov    r8,QWORD PTR [rsp+0x50]
  40b4b7:	cmp    rdx,r8
  40b4ba:	ja     40b56c <__swc_fn_4fa09e82_000162_9e36e814+0x24c>
  40b4c0:	xor    r8d,r8d
  40b4c3:	test   rcx,rcx
  40b4c6:	jbe    40b592 <__swc_fn_4fa09e82_000162_9e36e814+0x272>
  40b4cc:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  40b4d2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b4dc:	nop    DWORD PTR [rax+0x0]
  40b4e0:	imul   r9,r8,0x14
  40b4e4:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  40b4e9:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  40b4ee:	add    r10,r11
  40b4f1:	movabs r11,0x100000000
  40b4fb:	cmp    r10,r11
  40b4fe:	ja     40b56c <__swc_fn_4fa09e82_000162_9e36e814+0x24c>
  40b500:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  40b505:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  40b50a:	test   r10d,r10d
  40b50d:	setne  r11b
  40b511:	je     40b52b <__swc_fn_4fa09e82_000162_9e36e814+0x20b>
  40b513:	cmp    r10d,edx
  40b516:	setb   r11b
  40b51a:	jb     40b52b <__swc_fn_4fa09e82_000162_9e36e814+0x20b>
  40b51c:	vmovq  r11,xmm1
  40b521:	cmp    r10,r11
  40b524:	setae  r10b
  40b528:	mov    r11b,r10b
  40b52b:	mov    r10,r11
  40b52e:	test   r11b,r11b
  40b531:	jne    40b558 <__swc_fn_4fa09e82_000162_9e36e814+0x238>
  40b533:	test   r9d,r9d
  40b536:	setne  r10b
  40b53a:	je     40b558 <__swc_fn_4fa09e82_000162_9e36e814+0x238>
  40b53c:	cmp    r9d,edx
  40b53f:	setb   r10b
  40b543:	jb     40b558 <__swc_fn_4fa09e82_000162_9e36e814+0x238>
  40b545:	vmovq  r10,xmm1
  40b54a:	cmp    r9,r10
  40b54d:	setae  r9b
  40b551:	movzx  r9d,r9b
  40b555:	mov    r10b,r9b
  40b558:	test   r10b,r10b
  40b55b:	jne    40b56c <__swc_fn_4fa09e82_000162_9e36e814+0x24c>
  40b55d:	add    r8,0x1
  40b561:	cmp    r8,rcx
  40b564:	jb     40b4e0 <__swc_fn_4fa09e82_000162_9e36e814+0x1c0>
  40b56a:	jmp    40b592 <__swc_fn_4fa09e82_000162_9e36e814+0x272>
  40b56c:	xor    ecx,ecx
  40b56e:	cmp    rax,rbx
  40b571:	cmovne rcx,rax
  40b575:	call   40a030 <__swc_fn_4fa09e82_000144_afffe963>
  40b57a:	mov    rcx,rsi
  40b57d:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40b582:	mov    rax,rdi
  40b585:	add    rsp,0x188
  40b58c:	pop    r12
  40b58e:	pop    rdi
  40b58f:	pop    rsi
  40b590:	pop    rbx
  40b591:	ret
  40b592:	mov    QWORD PTR [rdi+0x10],rax
  40b596:	mov    rcx,QWORD PTR [rsp+0x50]
  40b59b:	mov    QWORD PTR [rdi+0x18],rcx
  40b59f:	mov    eax,DWORD PTR [rax+0x8]
  40b5a2:	mov    DWORD PTR [rdi+0x20],eax
  40b5a5:	rex mov BYTE PTR [rdi+0x24],0x1
  40b5aa:	mov    rcx,rsi
  40b5ad:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40b5b2:	mov    rax,rdi
  40b5b5:	add    rsp,0x188
  40b5bc:	pop    r12
  40b5be:	pop    rdi
  40b5bf:	pop    rsi
  40b5c0:	pop    rbx
  40b5c1:	ret
	...

000000000040b5d0 <__swc_fn_4fa09e82_000165_15b66a30>:
  40b5d0:	push   rsi
  40b5d1:	push   rdi
  40b5d2:	push   r12
  40b5d4:	mov    rsi,rdx
  40b5d7:	mov    rdi,rcx
  40b5da:	mov    rcx,QWORD PTR [rip+0x1b75f]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40b5e1:	test   rcx,rcx
  40b5e4:	jne    40b5f6 <__swc_fn_4fa09e82_000165_15b66a30+0x26>
  40b5e6:	call   40f060 <__swc_fn_4fa09e82_000166_e09accff>
  40b5eb:	lea    rcx,[rax+0x1]
  40b5ef:	mov    QWORD PTR [rip+0x1b74a],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40b5f6:	dec    rcx
  40b5f9:	call   40b620 <__swc_fn_4fa09e82_000168_3130645d>
  40b5fe:	mov    r12,QWORD PTR [rax+0xbe0]
  40b605:	test   r12,r12
  40b608:	setne  al
  40b60b:	je     40b616 <__swc_fn_4fa09e82_000165_15b66a30+0x46>
  40b60d:	mov    rcx,rdi
  40b610:	mov    rdx,rsi
  40b613:	call   r12
  40b616:	pop    r12
  40b618:	pop    rdi
  40b619:	pop    rsi
  40b61a:	ret
  40b61b:	add    BYTE PTR [rax],al
  40b61d:	add    BYTE PTR [rax],al
	...

000000000040b620 <__swc_fn_4fa09e82_000168_3130645d>:
  40b620:	push   r12
  40b622:	push   rdi
  40b623:	push   rsi
  40b624:	sub    rsp,0xd0
  40b62b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40b631:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40b637:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40b63d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40b643:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40b649:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40b64f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40b658:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40b661:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40b66a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40b673:	mov    r12,rcx
  40b676:	mov    edi,ecx
  40b678:	xor    eax,eax
  40b67a:	call   407000 <pthread_getspecific@plt>
  40b67f:	test   rax,rax
  40b682:	je     40b686 <__swc_fn_4fa09e82_000168_3130645d+0x66>
  40b684:	jmp    40b68e <__swc_fn_4fa09e82_000168_3130645d+0x6e>
  40b686:	mov    rcx,r12
  40b689:	call   40f0c0 <__swc_fn_4fa09e82_000169_0ff0458f>
  40b68e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40b694:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40b69a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40b6a0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40b6a6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40b6ac:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40b6b2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40b6bb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40b6c4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40b6cd:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40b6d6:	add    rsp,0xd0
  40b6dd:	pop    rsi
  40b6de:	pop    rdi
  40b6df:	pop    r12
  40b6e1:	ret
	...

000000000040b6f0 <__swc_fn_4fa09e82_000171_8b7c1b80>:
  40b6f0:	push   rsi
  40b6f1:	sub    rsp,0x30
  40b6f5:	lea    rsi,[rip+0x1b6ac]        # 426da8 <__swc_bss_base_4fa09e82+0x2d68>
  40b6fc:	mov    rax,QWORD PTR [rsi]
  40b6ff:	test   rax,rax
  40b702:	je     40b70a <__swc_fn_4fa09e82_000171_8b7c1b80+0x1a>
  40b704:	add    rsp,0x30
  40b708:	pop    rsi
  40b709:	ret
  40b70a:	mov    ecx,0x3
  40b70f:	mov    edx,0x10
  40b714:	call   409190 <__swc_fn_4fa09e82_000108_ff529476>
  40b719:	test   rax,rax
  40b71c:	jne    40b72d <__swc_fn_4fa09e82_000171_8b7c1b80+0x3d>
  40b71e:	mov    QWORD PTR [rsp+0x18],rax
  40b723:	call   411420 <__swc_fn_4fa09e82_000119_2b35b5e0>
  40b728:	mov    rax,QWORD PTR [rsp+0x18]
  40b72d:	mov    rcx,rax
  40b730:	xchg   QWORD PTR [rsi],rcx
  40b733:	add    rsp,0x30
  40b737:	pop    rsi
  40b738:	ret
  40b739:	add    BYTE PTR [rax],al
  40b73b:	add    BYTE PTR [rax],al
  40b73d:	add    BYTE PTR [rax],al
	...

000000000040b740 <__swc_fn_4fa09e82_000174_156cb9fe>:
  40b740:	push   rsi
  40b741:	push   rdi
  40b742:	sub    rsp,0x8
  40b746:	mov    rsi,rdx
  40b749:	mov    rdi,rcx
  40b74c:	mov    rax,QWORD PTR [rsi+0x8]
  40b750:	test   rax,rax
  40b753:	je     40b75d <__swc_fn_4fa09e82_000174_156cb9fe+0x1d>
  40b755:	mov    rcx,QWORD PTR [rsi]
  40b758:	mov    QWORD PTR [rax],rcx
  40b75b:	jmp    40b764 <__swc_fn_4fa09e82_000174_156cb9fe+0x24>
  40b75d:	mov    rax,QWORD PTR [rsi]
  40b760:	mov    QWORD PTR [rdi+0x8],rax
  40b764:	mov    rax,QWORD PTR [rsi]
  40b767:	test   rax,rax
  40b76a:	je     40b774 <__swc_fn_4fa09e82_000174_156cb9fe+0x34>
  40b76c:	mov    rcx,QWORD PTR [rsi+0x8]
  40b770:	mov    QWORD PTR [rax+0x8],rcx
  40b774:	mov    rcx,rdi
  40b777:	mov    rdx,QWORD PTR [rsi+0x10]
  40b77b:	mov    r8,QWORD PTR [rsi+0x18]
  40b77f:	mov    r9,0xffffffffffffffff
  40b786:	call   411fe0 <__swc_fn_4fa09e82_000173_9a88b1d5>
  40b78b:	mov    QWORD PTR [rsi+0x18],0x0
  40b793:	mov    rax,QWORD PTR [rdi+0x8]
  40b797:	test   rax,rax
  40b79a:	jne    40b7ac <__swc_fn_4fa09e82_000174_156cb9fe+0x6c>
  40b79c:	call   40b6f0 <__swc_fn_4fa09e82_000171_8b7c1b80>
  40b7a1:	xor    ecx,ecx
  40b7a3:	mov    QWORD PTR [rax+0x8],rcx
  40b7a7:	xor    ecx,ecx
  40b7a9:	mov    QWORD PTR [rax],rcx
  40b7ac:	add    rsp,0x8
  40b7b0:	pop    rdi
  40b7b1:	pop    rsi
  40b7b2:	ret
	...

000000000040b7c0 <__swc_fn_4fa09e82_000177_2744b483>:
  40b7c0:	push   rbx
  40b7c1:	sub    rsp,0x70
  40b7c5:	cmp    rcx,0xffffffffffffffef
  40b7c9:	jbe    40b7d3 <__swc_fn_4fa09e82_000177_2744b483+0x13>
  40b7cb:	xor    eax,eax
  40b7cd:	add    rsp,0x70
  40b7d1:	pop    rbx
  40b7d2:	ret
  40b7d3:	vxorps xmm0,xmm0,xmm0
  40b7d7:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40b7dd:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40b7e3:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40b7e9:	vzeroupper
  40b7ec:	lea    rax,[rcx+0x10]
  40b7f0:	mov    QWORD PTR [rsp+0x50],rax
  40b7f5:	mov    DWORD PTR [rsp+0x60],0x10
  40b7fd:	mov    rcx,QWORD PTR [rip+0x1b53c]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40b804:	test   rcx,rcx
  40b807:	jne    40b819 <__swc_fn_4fa09e82_000177_2744b483+0x59>
  40b809:	call   40f060 <__swc_fn_4fa09e82_000166_e09accff>
  40b80e:	lea    rcx,[rax+0x1]
  40b812:	mov    QWORD PTR [rip+0x1b527],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40b819:	dec    rcx
  40b81c:	call   40b620 <__swc_fn_4fa09e82_000168_3130645d>
  40b821:	mov    rcx,QWORD PTR [rax]
  40b824:	lea    rdx,[rsp+0x8]
  40b829:	mov    rbx,QWORD PTR [rax+0x8]
  40b82d:	mov    rbx,QWORD PTR [rbx+0x8]
  40b831:	call   rbx
  40b833:	mov    rax,QWORD PTR [rsp+0x48]
  40b838:	test   rax,rax
  40b83b:	jne    40b845 <__swc_fn_4fa09e82_000177_2744b483+0x85>
  40b83d:	xor    eax,eax
  40b83f:	add    rsp,0x70
  40b843:	pop    rbx
  40b844:	ret
  40b845:	mov    rcx,QWORD PTR [rsp+0x50]
  40b84a:	mov    QWORD PTR [rax],rcx
  40b84d:	mov    QWORD PTR [rax+0x8],0x0
  40b855:	lea    rax,[rax+0x10]
  40b859:	add    rsp,0x70
  40b85d:	pop    rbx
  40b85e:	ret
	...

000000000040b880 <__swc_fn_4fa09e82_000180_913db40c>:
  40b880:	push   rbp
  40b881:	push   rbx
  40b882:	push   rsi
  40b883:	push   rdi
  40b884:	push   r12
  40b886:	push   r15
  40b888:	push   r13
  40b88a:	push   r14
  40b88c:	sub    rsp,0x10
  40b890:	mov    rbp,rsp
  40b893:	vmovups XMMWORD PTR [rsp],xmm6
  40b898:	sub    rsp,0x50
  40b89c:	mov    rbx,rsp
  40b89f:	sub    rsp,0x8
  40b8a3:	mov    ecx,0x13880
  40b8a8:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40b8ad:	mov    rsi,rax
  40b8b0:	mov    ecx,0x9c40
  40b8b5:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40b8ba:	mov    rdi,rax
  40b8bd:	mov    ecx,0x9c40
  40b8c2:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40b8c7:	mov    r12,rax
  40b8ca:	xor    ecx,ecx
  40b8cc:	xor    r8d,r8d
  40b8cf:	cs nop WORD PTR [rax+rax*1+0x0]
  40b8d9:	nop    DWORD PTR [rax+0x0]
  40b8e0:	lea    r9,[r8+0x1]
  40b8e4:	mov    r10,r9
  40b8e7:	movabs rdx,0xaaaaaaaaaaaaaaab
  40b8f1:	mov    r15,rax
  40b8f4:	mov    rax,r8
  40b8f7:	mul    rdx
  40b8fa:	mov    r11,rdx
  40b8fd:	mov    rax,r15
  40b900:	shr    r11,0x2
  40b904:	imul   r11,r11,0x6
  40b908:	mov    rdx,r8
  40b90b:	sub    rdx,r11
  40b90e:	lea    r11,[rdx+0x3]
  40b912:	mov    QWORD PTR [rdi+r8*8],rcx
  40b916:	mov    QWORD PTR [r12+r8*8],r11
  40b91a:	xor    r8d,r8d
  40b91d:	test   r11,r11
  40b920:	jbe    40b974 <__swc_fn_4fa09e82_000180_913db40c+0xf4>
  40b922:	xor    r13d,r13d
  40b925:	cs nop WORD PTR [rax+rax*1+0x0]
  40b92f:	nop
  40b930:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40b93a:	mov    r15,rax
  40b93d:	mov    rax,r10
  40b940:	mul    rdx
  40b943:	mov    r14,rdx
  40b946:	mov    rax,r15
  40b949:	shr    r14,0x3
  40b94d:	imul   r14,r14,0x1a
  40b951:	sub    r10,r14
  40b954:	lea    r10,[r10+0x61]
  40b958:	mov    BYTE PTR [rsi+rcx*1],r10b
  40b95c:	inc    rcx
  40b95f:	shr    rdx,0x3
  40b963:	lea    r10,[rdx+r13*1]
  40b967:	add    r8,0x1
  40b96b:	add    r13,0x7
  40b96f:	cmp    r8,r11
  40b972:	jb     40b930 <__swc_fn_4fa09e82_000180_913db40c+0xb0>
  40b974:	mov    r8,r9
  40b977:	cmp    r9,0x1388
  40b97e:	jb     40b8e0 <__swc_fn_4fa09e82_000180_913db40c+0x60>
  40b984:	mov    ecx,0x16e3600
  40b989:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40b98e:	mov    QWORD PTR [rip+0x1b43b],rax        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40b995:	xor    ecx,ecx
  40b997:	xor    r8d,r8d
  40b99a:	nop    WORD PTR [rax+rax*1+0x0]
  40b9a0:	mov    r9,QWORD PTR [rip+0x16669]        # 422010 <__swc_data_base_4fa09e82+0x10>
  40b9a7:	imul   r9,r9,0x41a7
  40b9ae:	movabs rdx,0x200000005
  40b9b8:	mov    r11,rax
  40b9bb:	mov    rax,r9
  40b9be:	mul    rdx
  40b9c1:	mov    r10,rdx
  40b9c4:	mov    rdx,r9
  40b9c7:	sub    rdx,r10
  40b9ca:	shr    rdx,1
  40b9cd:	add    rdx,r10
  40b9d0:	shr    rdx,0x1e
  40b9d4:	imul   r10,rdx,0x7fffffff
  40b9db:	sub    r9,r10
  40b9de:	mov    QWORD PTR [rip+0x1662b],r9        # 422010 <__swc_data_base_4fa09e82+0x10>
  40b9e5:	movabs rdx,0x346dc5d63886594b
  40b9ef:	mov    rax,r9
  40b9f2:	mul    rdx
  40b9f5:	mov    rax,r11
  40b9f8:	shr    rdx,0xa
  40b9fc:	imul   rdx,rdx,0x1388
  40ba03:	sub    r9,rdx
  40ba06:	mov    rdx,QWORD PTR [rdi+r9*8]
  40ba0a:	mov    r9,QWORD PTR [r12+r9*8]
  40ba0e:	xor    r10d,r10d
  40ba11:	test   r9,r9
  40ba14:	jbe    40ba34 <__swc_fn_4fa09e82_000180_913db40c+0x1b4>
  40ba16:	mov    r11,QWORD PTR [rip+0x1b3b3]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40ba1d:	add    rdx,rsi
  40ba20:	mov    r13b,BYTE PTR [rdx+r10*1]
  40ba24:	mov    BYTE PTR [r11+rcx*1],r13b
  40ba28:	inc    rcx
  40ba2b:	add    r10,0x1
  40ba2f:	cmp    r10,r9
  40ba32:	jb     40ba20 <__swc_fn_4fa09e82_000180_913db40c+0x1a0>
  40ba34:	lea    r9,[r8+0x1]
  40ba38:	movabs rdx,0xaaaaaaaaaaaaaaab
  40ba42:	mov    r11,rax
  40ba45:	mov    rax,r9
  40ba48:	mul    rdx
  40ba4b:	mov    r8,rdx
  40ba4e:	mov    rax,r11
  40ba51:	shr    r8,0x3
  40ba55:	imul   r8,r8,0xc
  40ba59:	mov    rdx,r9
  40ba5c:	sub    rdx,r8
  40ba5f:	jne    40ba6e <__swc_fn_4fa09e82_000180_913db40c+0x1ee>
  40ba61:	mov    rdx,QWORD PTR [rip+0x1b368]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40ba68:	mov    BYTE PTR [rdx+rcx*1],0xa
  40ba6c:	jmp    40ba79 <__swc_fn_4fa09e82_000180_913db40c+0x1f9>
  40ba6e:	mov    rdx,QWORD PTR [rip+0x1b35b]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40ba75:	mov    BYTE PTR [rdx+rcx*1],0x20
  40ba79:	lea    r13,[rcx+0x1]
  40ba7d:	mov    r15,r13
  40ba80:	mov    rcx,r13
  40ba83:	mov    r8,r9
  40ba86:	cmp    r9,0x1e8480
  40ba8d:	jb     40b9a0 <__swc_fn_4fa09e82_000180_913db40c+0x120>
  40ba93:	mov    QWORD PTR [rsp+0x48],r15
  40ba98:	call   40f210 <__swc_fn_4fa09e82_000178_1ca87929>
  40ba9d:	vmovups xmm6,xmm0
  40baa1:	mov    rsi,rbx
  40baa4:	mov    QWORD PTR [rsp+0x50],rsi
  40baa9:	vxorps xmm0,xmm0,xmm0
  40baad:	vmovups XMMWORD PTR [rbx],xmm0
  40bab1:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40bab6:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40babb:	mov    QWORD PTR [rbx+0x30],0x0
  40bac3:	mov    r8,QWORD PTR [rip+0x1b306]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40baca:	mov    rcx,rsi
  40bacd:	mov    edx,0x4000
  40bad2:	call   412090 <__swc_fn_4fa09e82_000176_e7f0b636>
  40bad7:	xor    edi,edi
  40bad9:	xor    al,al
  40badb:	xor    r12d,r12d
  40bade:	cmp    r12,r13
  40bae1:	jae    40bc6f <__swc_fn_4fa09e82_000180_913db40c+0x3ef>
  40bae7:	cs nop WORD PTR [rax+rax*1+0x0]
  40baf1:	cs nop WORD PTR [rax+rax*1+0x0]
  40bafb:	cs nop WORD PTR [rax+rax*1+0x0]
  40bb05:	cs nop WORD PTR [rax+rax*1+0x0]
  40bb0f:	cs nop WORD PTR [rax+rax*1+0x0]
  40bb19:	nop    DWORD PTR [rax+0x0]
  40bb20:	mov    rcx,QWORD PTR [rip+0x1b2a9]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40bb27:	mov    cl,BYTE PTR [rcx+r12*1]
  40bb2b:	sub    cl,0x61
  40bb2e:	cmp    cl,0x19
  40bb31:	ja     40bb48 <__swc_fn_4fa09e82_000180_913db40c+0x2c8>
  40bb33:	test   al,al
  40bb35:	jne    40bc5e <__swc_fn_4fa09e82_000180_913db40c+0x3de>
  40bb3b:	mov    rdi,r12
  40bb3e:	mov    eax,0x1
  40bb43:	jmp    40bc5e <__swc_fn_4fa09e82_000180_913db40c+0x3de>
  40bb48:	test   al,al
  40bb4a:	je     40bc5e <__swc_fn_4fa09e82_000180_913db40c+0x3de>
  40bb50:	mov    r14,r12
  40bb53:	sub    r14,rdi
  40bb56:	mov    eax,0x811c9dc5
  40bb5b:	xor    ecx,ecx
  40bb5d:	test   r14,r14
  40bb60:	jbe    40bbd2 <__swc_fn_4fa09e82_000180_913db40c+0x352>
  40bb66:	mov    rdx,QWORD PTR [rbx+0x20]
  40bb6a:	add    rdx,rdi
  40bb6d:	cmp    r14,0x4
  40bb71:	jb     40bbc0 <__swc_fn_4fa09e82_000180_913db40c+0x340>
  40bb77:	lea    r8,[r14-0x3]
  40bb7b:	nop    DWORD PTR [rax+rax*1+0x0]
  40bb80:	xor    al,BYTE PTR [rdx+rcx*1]
  40bb83:	imul   eax,eax,0x1000193
  40bb89:	xor    al,BYTE PTR [rdx+rcx*1+0x1]
  40bb8d:	imul   eax,eax,0x1000193
  40bb93:	xor    al,BYTE PTR [rdx+rcx*1+0x2]
  40bb97:	imul   eax,eax,0x1000193
  40bb9d:	xor    al,BYTE PTR [rdx+rcx*1+0x3]
  40bba1:	imul   eax,eax,0x1000193
  40bba7:	add    rcx,0x4
  40bbab:	cmp    rcx,r8
  40bbae:	jb     40bb80 <__swc_fn_4fa09e82_000180_913db40c+0x300>
  40bbb0:	cmp    rcx,r14
  40bbb3:	jae    40bbd2 <__swc_fn_4fa09e82_000180_913db40c+0x352>
  40bbb5:	cs nop WORD PTR [rax+rax*1+0x0]
  40bbbf:	nop
  40bbc0:	xor    al,BYTE PTR [rdx+rcx*1]
  40bbc3:	imul   eax,eax,0x1000193
  40bbc9:	add    rcx,0x1
  40bbcd:	cmp    rcx,r14
  40bbd0:	jb     40bbc0 <__swc_fn_4fa09e82_000180_913db40c+0x340>
  40bbd2:	and    rax,QWORD PTR [rbx+0x28]
  40bbd6:	mov    r15,rax
  40bbd9:	mov    rsi,QWORD PTR [rbx+0x18]
  40bbdd:	mov    r13,QWORD PTR [rbx+0x8]
  40bbe1:	cmp    BYTE PTR [rsi+r15*1],0x0
  40bbe6:	je     40bc26 <__swc_fn_4fa09e82_000180_913db40c+0x3a6>
  40bbe8:	nop    DWORD PTR [rax+rax*1+0x0]
  40bbf0:	cmp    QWORD PTR [r13+r15*8+0x0],r14
  40bbf5:	jne    40bc18 <__swc_fn_4fa09e82_000180_913db40c+0x398>
  40bbf7:	mov    rax,QWORD PTR [rbx]
  40bbfa:	mov    rax,QWORD PTR [rax+r15*8]
  40bbfe:	mov    rcx,QWORD PTR [rbx+0x20]
  40bc02:	add    rax,rcx
  40bc05:	lea    rdx,[rcx+rdi*1]
  40bc09:	mov    rcx,rax
  40bc0c:	mov    r8,r14
  40bc0f:	call   410eb0 <__swc_fn_4fa09e82_000107_77a5d54a>
  40bc14:	test   eax,eax
  40bc16:	je     40bc26 <__swc_fn_4fa09e82_000180_913db40c+0x3a6>
  40bc18:	inc    r15
  40bc1b:	and    r15,QWORD PTR [rbx+0x28]
  40bc1f:	cmp    BYTE PTR [rsi+r15*1],0x0
  40bc24:	jne    40bbf0 <__swc_fn_4fa09e82_000180_913db40c+0x370>
  40bc26:	cmp    BYTE PTR [rsi+r15*1],0x0
  40bc2b:	jne    40bc54 <__swc_fn_4fa09e82_000180_913db40c+0x3d4>
  40bc2d:	mov    BYTE PTR [rsi+r15*1],0x1
  40bc32:	mov    rax,QWORD PTR [rbx]
  40bc35:	mov    QWORD PTR [rax+r15*8],rdi
  40bc39:	mov    rax,QWORD PTR [rbx+0x8]
  40bc3d:	mov    QWORD PTR [rax+r15*8],r14
  40bc41:	mov    rax,QWORD PTR [rbx+0x10]
  40bc45:	mov    QWORD PTR [rax+r15*8],0x1
  40bc4d:	add    QWORD PTR [rbx+0x30],0x1
  40bc52:	jmp    40bc5c <__swc_fn_4fa09e82_000180_913db40c+0x3dc>
  40bc54:	mov    rax,QWORD PTR [rbx+0x10]
  40bc58:	inc    QWORD PTR [rax+r15*8]
  40bc5c:	xor    eax,eax
  40bc5e:	inc    r12
  40bc61:	mov    r13,QWORD PTR [rsp+0x48]
  40bc66:	cmp    r12,r13
  40bc69:	jb     40bb20 <__swc_fn_4fa09e82_000180_913db40c+0x2a0>
  40bc6f:	test   al,al
  40bc71:	je     40bd9b <__swc_fn_4fa09e82_000180_913db40c+0x51b>
  40bc77:	mov    r13,QWORD PTR [rsp+0x48]
  40bc7c:	sub    r13,rdi
  40bc7f:	mov    eax,0x811c9dc5
  40bc84:	xor    ecx,ecx
  40bc86:	test   r13,r13
  40bc89:	jbe    40bd12 <__swc_fn_4fa09e82_000180_913db40c+0x492>
  40bc8f:	mov    rdx,QWORD PTR [rbx+0x20]
  40bc93:	add    rdx,rdi
  40bc96:	cmp    r13,0x4
  40bc9a:	jb     40bd00 <__swc_fn_4fa09e82_000180_913db40c+0x480>
  40bca0:	lea    r8,[r13-0x3]
  40bca4:	cs nop WORD PTR [rax+rax*1+0x0]
  40bcae:	cs nop WORD PTR [rax+rax*1+0x0]
  40bcb8:	nop    DWORD PTR [rax+rax*1+0x0]
  40bcc0:	xor    al,BYTE PTR [rdx+rcx*1]
  40bcc3:	imul   eax,eax,0x1000193
  40bcc9:	xor    al,BYTE PTR [rdx+rcx*1+0x1]
  40bccd:	imul   eax,eax,0x1000193
  40bcd3:	xor    al,BYTE PTR [rdx+rcx*1+0x2]
  40bcd7:	imul   eax,eax,0x1000193
  40bcdd:	xor    al,BYTE PTR [rdx+rcx*1+0x3]
  40bce1:	imul   eax,eax,0x1000193
  40bce7:	add    rcx,0x4
  40bceb:	cmp    rcx,r8
  40bcee:	jb     40bcc0 <__swc_fn_4fa09e82_000180_913db40c+0x440>
  40bcf0:	cmp    rcx,r13
  40bcf3:	jae    40bd12 <__swc_fn_4fa09e82_000180_913db40c+0x492>
  40bcf5:	cs nop WORD PTR [rax+rax*1+0x0]
  40bcff:	nop
  40bd00:	xor    al,BYTE PTR [rdx+rcx*1]
  40bd03:	imul   eax,eax,0x1000193
  40bd09:	add    rcx,0x1
  40bd0d:	cmp    rcx,r13
  40bd10:	jb     40bd00 <__swc_fn_4fa09e82_000180_913db40c+0x480>
  40bd12:	mov    rsi,QWORD PTR [rsp+0x50]
  40bd17:	and    rax,QWORD PTR [rsi+0x28]
  40bd1b:	mov    r12,rax
  40bd1e:	mov    r14,QWORD PTR [rbx+0x18]
  40bd22:	mov    r15,QWORD PTR [rbx+0x8]
  40bd26:	cmp    BYTE PTR [r14+r12*1],0x0
  40bd2b:	je     40bd65 <__swc_fn_4fa09e82_000180_913db40c+0x4e5>
  40bd2d:	nop    DWORD PTR [rax]
  40bd30:	cmp    QWORD PTR [r15+r12*8],r13
  40bd34:	jne    40bd57 <__swc_fn_4fa09e82_000180_913db40c+0x4d7>
  40bd36:	mov    rax,QWORD PTR [rbx]
  40bd39:	mov    rax,QWORD PTR [rax+r12*8]
  40bd3d:	mov    rcx,QWORD PTR [rbx+0x20]
  40bd41:	add    rax,rcx
  40bd44:	lea    rdx,[rcx+rdi*1]
  40bd48:	mov    rcx,rax
  40bd4b:	mov    r8,r13
  40bd4e:	call   410eb0 <__swc_fn_4fa09e82_000107_77a5d54a>
  40bd53:	test   eax,eax
  40bd55:	je     40bd65 <__swc_fn_4fa09e82_000180_913db40c+0x4e5>
  40bd57:	inc    r12
  40bd5a:	and    r12,QWORD PTR [rbx+0x28]
  40bd5e:	cmp    BYTE PTR [r14+r12*1],0x0
  40bd63:	jne    40bd30 <__swc_fn_4fa09e82_000180_913db40c+0x4b0>
  40bd65:	cmp    BYTE PTR [r14+r12*1],0x0
  40bd6a:	jne    40bd93 <__swc_fn_4fa09e82_000180_913db40c+0x513>
  40bd6c:	mov    BYTE PTR [r14+r12*1],0x1
  40bd71:	mov    rax,QWORD PTR [rbx]
  40bd74:	mov    QWORD PTR [rax+r12*8],rdi
  40bd78:	mov    rax,QWORD PTR [rbx+0x8]
  40bd7c:	mov    QWORD PTR [rax+r12*8],r13
  40bd80:	mov    rax,QWORD PTR [rbx+0x10]
  40bd84:	mov    QWORD PTR [rax+r12*8],0x1
  40bd8c:	add    QWORD PTR [rsi+0x30],0x1
  40bd91:	jmp    40bd9b <__swc_fn_4fa09e82_000180_913db40c+0x51b>
  40bd93:	mov    rax,QWORD PTR [rbx+0x10]
  40bd97:	inc    QWORD PTR [rax+r12*8]
  40bd9b:	mov    rsi,QWORD PTR [rbx+0x30]
  40bd9f:	lea    rdi,[rsi*8+0x0]
  40bda7:	mov    rcx,rdi
  40bdaa:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40bdaf:	mov    QWORD PTR [rip+0x1b002],rax        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  40bdb6:	mov    rcx,rdi
  40bdb9:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40bdbe:	mov    QWORD PTR [rip+0x1b003],rax        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  40bdc5:	mov    rcx,rdi
  40bdc8:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40bdcd:	mov    QWORD PTR [rip+0x1afec],rax        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  40bdd4:	mov    rcx,rdi
  40bdd7:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40bddc:	mov    QWORD PTR [rip+0x1afcd],rax        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  40bde3:	xor    ecx,ecx
  40bde5:	xor    edx,edx
  40bde7:	mov    r8,QWORD PTR [rip+0x1afca]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  40bdee:	mov    r9,QWORD PTR [rip+0x1afd3]        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  40bdf5:	mov    r10,QWORD PTR [rip+0x1afc4]        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  40bdfc:	cs nop WORD PTR [rax+rax*1+0x0]
  40be06:	cs nop WORD PTR [rax+rax*1+0x0]
  40be10:	mov    r11,QWORD PTR [rbx+0x18]
  40be14:	cmp    BYTE PTR [r11+rdx*1],0x0
  40be19:	je     40be45 <__swc_fn_4fa09e82_000180_913db40c+0x5c5>
  40be1b:	mov    r11,QWORD PTR [rbx+0x10]
  40be1f:	mov    r11,QWORD PTR [r11+rdx*8]
  40be23:	mov    QWORD PTR [r8+rcx*8],r11
  40be27:	mov    r11,QWORD PTR [rbx]
  40be2a:	mov    r11,QWORD PTR [r11+rdx*8]
  40be2e:	mov    QWORD PTR [r9+rcx*8],r11
  40be32:	mov    r11,QWORD PTR [rbx+0x8]
  40be36:	mov    r11,QWORD PTR [r11+rdx*8]
  40be3a:	mov    QWORD PTR [r10+rcx*8],r11
  40be3e:	mov    QWORD PTR [rax+rcx*8],rcx
  40be42:	inc    rcx
  40be45:	add    rdx,0x1
  40be49:	cmp    rdx,0x4000
  40be50:	jb     40be10 <__swc_fn_4fa09e82_000180_913db40c+0x590>
  40be52:	xor    ecx,ecx
  40be54:	lea    rdx,[rsi-0x1]
  40be58:	call   412110 <__swc_fn_4fa09e82_000179_6937fe70>
  40be5d:	imul   rsi,rsi,0x7
  40be61:	xor    eax,eax
  40be63:	mov    rcx,QWORD PTR [rip+0x1af46]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  40be6a:	mov    rdx,QWORD PTR [rip+0x1af47]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  40be71:	cs nop WORD PTR [rax+rax*1+0x0]
  40be7b:	nop    DWORD PTR [rax+rax*1+0x0]
  40be80:	lea    r8,[rax+0x1]
  40be84:	mov    rax,QWORD PTR [rcx+rax*8]
  40be88:	mov    r9,r8
  40be8b:	imul   r9,QWORD PTR [rdx+rax*8]
  40be90:	add    rsi,r9
  40be93:	mov    rax,r8
  40be96:	cmp    r8,0x14
  40be9a:	jb     40be80 <__swc_fn_4fa09e82_000180_913db40c+0x600>
  40be9c:	call   40f210 <__swc_fn_4fa09e82_000178_1ca87929>
  40bea1:	vsubsd xmm0,xmm0,xmm6
  40bea5:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x7b1b]        # 4139c8 <__swc_rdata_base_4fa09e82+0x8b8>
  40bead:	lea    rax,[rip+0x74b4]        # 413368 <__swc_rdata_base_4fa09e82+0x258>
  40beb4:	sub    rsp,0x88
  40bebb:	mov    rcx,rsp
  40bebe:	vmovups xmm1,XMMWORD PTR [rip+0x7ae2]        # 4139a8 <__swc_rdata_base_4fa09e82+0x898>
  40bec6:	vmovups XMMWORD PTR [rcx],xmm1
  40beca:	mov    QWORD PTR [rcx+0x30],rsp
  40bece:	lea    rdx,[rip+0x743b]        # 413310 <__swc_rdata_base_4fa09e82+0x200>
  40bed5:	mov    QWORD PTR [rcx+0x38],rdx
  40bed9:	mov    QWORD PTR [rcx+0x10],rsi
  40bedd:	lea    r8,[rsp+0x10]
  40bee2:	mov    QWORD PTR [rcx+0x40],r8
  40bee6:	lea    r8,[rip+0x7a2b]        # 413918 <__swc_rdata_base_4fa09e82+0x808>
  40beed:	mov    QWORD PTR [rcx+0x48],r8
  40bef1:	vmovups xmm1,XMMWORD PTR [rip+0x7abf]        # 4139b8 <__swc_rdata_base_4fa09e82+0x8a8>
  40bef9:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40befe:	lea    r8,[rsp+0x18]
  40bf03:	mov    QWORD PTR [rcx+0x50],r8
  40bf07:	mov    QWORD PTR [rcx+0x58],rdx
  40bf0b:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40bf10:	lea    r8,[rcx+0x28]
  40bf14:	mov    QWORD PTR [rcx+0x60],r8
  40bf18:	lea    r8,[rip+0x7a41]        # 413960 <__swc_rdata_base_4fa09e82+0x850>
  40bf1f:	mov    QWORD PTR [rcx+0x68],r8
  40bf23:	mov    QWORD PTR [rcx+0x70],rax
  40bf27:	mov    QWORD PTR [rcx+0x78],rdx
  40bf2b:	lea    rax,[rcx+0x30]
  40bf2f:	mov    QWORD PTR [rcx+0x80],rax
  40bf36:	mov    QWORD PTR [rcx+0x88],0x5
  40bf41:	lea    rcx,[rcx+0x80]
  40bf48:	sub    rsp,0x8
  40bf4c:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  40bf51:	add    rsp,0xe8
  40bf58:	vmovups xmm6,XMMWORD PTR [rsp]
  40bf5d:	add    rsp,0x10
  40bf61:	pop    r14
  40bf63:	pop    r13
  40bf65:	pop    r15
  40bf67:	pop    r12
  40bf69:	pop    rdi
  40bf6a:	pop    rsi
  40bf6b:	pop    rbx
  40bf6c:	pop    rbp
  40bf6d:	ret
	...

000000000040bf80 <__swc_fn_4fa09e82_000001_29b04951>:
  40bf80:	vxorps xmm0,xmm0,xmm0
  40bf84:	xor    eax,eax
  40bf86:	cs nop WORD PTR [rax+rax*1+0x0]
  40bf90:	cs nop WORD PTR [rax+rax*1+0x0]
  40bf9a:	nop    WORD PTR [rax+rax*1+0x0]
  40bfa0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40bfa5:	add    rax,0x10
  40bfa9:	cmp    rax,0x2080
  40bfb0:	jne    40bfa0 <__swc_fn_4fa09e82_000001_29b04951+0x20>
  40bfb2:	ret
	...

000000000040bfc0 <__swc_fn_4fa09e82_000004_2fa5c690>:
  40bfc0:	push   rsi
  40bfc1:	push   rdi
  40bfc2:	push   r12
  40bfc4:	push   r13
  40bfc6:	push   r14
  40bfc8:	mov    rsi,rcx
  40bfcb:	mov    edi,r10d
  40bfce:	mov    r12,rcx
  40bfd1:	mov    r13,r9
  40bfd4:	mov    ecx,DWORD PTR [rdx+0x28]
  40bfd7:	shlx   r14d,r8d,ecx
  40bfdc:	mov    rcx,rdx
  40bfdf:	mov    edx,r8d
  40bfe2:	call   40f3e0 <__swc_fn_4fa09e82_000011_e75d466d>
  40bfe7:	mov    rcx,rax
  40bfea:	mov    eax,DWORD PTR [r12+0x3c]
  40bfef:	xor    edx,edx
  40bff1:	div    rdi
  40bff4:	vxorps xmm0,xmm0,xmm0
  40bff8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40bffc:	mov    QWORD PTR [r12+0x60],0x0
  40c005:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40c00a:	mov    QWORD PTR [r12+0x10],rcx
  40c00f:	imul   rax,rdi
  40c013:	lea    rdx,[rcx+rax*1]
  40c017:	mov    QWORD PTR [r12+0x18],rdx
  40c01c:	mov    QWORD PTR [r12+0x20],rcx
  40c021:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40c026:	mov    DWORD PTR [r12+0x28],0x0
  40c02f:	mov    DWORD PTR [r12+0x68],0x0
  40c038:	mov    BYTE PTR [r12+0x39],r13b
  40c03d:	mov    BYTE PTR [r12+0x3a],r14b
  40c042:	mov    BYTE PTR [r12+0x3b],0x1
  40c048:	mov    DWORD PTR [r12+0x6c],0x0
  40c051:	mov    rcx,r12
  40c054:	mov    edx,edi
  40c056:	call   40f340 <__swc_fn_4fa09e82_000005_bcc5b80b>
  40c05b:	pop    r14
  40c05d:	pop    r13
  40c05f:	pop    r12
  40c061:	pop    rdi
  40c062:	pop    rsi
  40c063:	ret
	...

000000000040c070 <__swc_fn_4fa09e82_000007_635028f3>:
  40c070:	mov    r8d,0x1
  40c076:	xor    eax,eax
  40c078:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40c07e:	test   eax,eax
  40c080:	jne    40c070 <__swc_fn_4fa09e82_000007_635028f3>
  40c082:	ret
	...

000000000040c090 <__swc_fn_4fa09e82_000010_186cd0c2>:
  40c090:	lea    r8,[rcx+0x60]
  40c094:	mov    rax,QWORD PTR [r8]
  40c097:	mov    r9,rax
  40c09a:	nop    WORD PTR [rax+rax*1+0x0]
  40c0a0:	mov    QWORD PTR [rdx],r9
  40c0a3:	mov    rax,r9
  40c0a6:	lock cmpxchg QWORD PTR [r8],rdx
  40c0ab:	cmp    rax,r9
  40c0ae:	jne    40c117 <__swc_fn_4fa09e82_000010_186cd0c2+0x87>
  40c0b0:	mov    eax,DWORD PTR [rcx+0x6c]
  40c0b3:	test   eax,eax
  40c0b5:	je     40c116 <__swc_fn_4fa09e82_000010_186cd0c2+0x86>
  40c0b7:	lea    rdx,[rcx+0x70]
  40c0bb:	mov    r9d,0x1
  40c0c1:	xor    eax,eax
  40c0c3:	lock cmpxchg DWORD PTR [rdx],r9d
  40c0c8:	test   eax,eax
  40c0ca:	jne    40c116 <__swc_fn_4fa09e82_000010_186cd0c2+0x86>
  40c0cc:	mov    rax,rcx
  40c0cf:	and    rax,0xffffffffffc00000
  40c0d6:	mov    rax,QWORD PTR [rax+0x8]
  40c0da:	test   rax,rax
  40c0dd:	jne    40c0e5 <__swc_fn_4fa09e82_000010_186cd0c2+0x55>
  40c0df:	xor    eax,eax
  40c0e1:	xchg   DWORD PTR [rdx],eax
  40c0e3:	jmp    40c116 <__swc_fn_4fa09e82_000010_186cd0c2+0x86>
  40c0e5:	lea    rdx,[rax+0x2a80]
  40c0ec:	mov    rax,QWORD PTR [rdx]
  40c0ef:	mov    r8,rax
  40c0f2:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0fc:	nop    DWORD PTR [rax+0x0]
  40c100:	mov    QWORD PTR [rcx+0x78],r8
  40c104:	mov    rax,r8
  40c107:	lock cmpxchg QWORD PTR [rdx],rcx
  40c10c:	cmp    rax,r8
  40c10f:	je     40c116 <__swc_fn_4fa09e82_000010_186cd0c2+0x86>
  40c111:	mov    r8,rax
  40c114:	jmp    40c100 <__swc_fn_4fa09e82_000010_186cd0c2+0x70>
  40c116:	ret
  40c117:	mov    r9,rax
  40c11a:	jmp    40c0a0 <__swc_fn_4fa09e82_000010_186cd0c2+0x10>
	...

000000000040c120 <__swc_fn_4fa09e82_000013_d15d37c6>:
  40c120:	push   rsi
  40c121:	push   rdi
  40c122:	push   r12
  40c124:	push   r13
  40c126:	push   r14
  40c128:	push   r15
  40c12a:	push   rbx
  40c12b:	sub    rsp,0x30
  40c12f:	mov    QWORD PTR [rsp+0x18],r8
  40c134:	mov    rsi,rcx
  40c137:	mov    rdi,rdx
  40c13a:	mov    rdx,QWORD PTR [rsi+0x40]
  40c13e:	xchg   ax,ax
  40c140:	mov    rax,rdx
  40c143:	not    rax
  40c146:	and    rax,QWORD PTR [rsi+0x20]
  40c14a:	test   rax,rax
  40c14d:	jne    40c161 <__swc_fn_4fa09e82_000013_d15d37c6+0x41>
  40c14f:	xor    eax,eax
  40c151:	add    rsp,0x30
  40c155:	pop    rbx
  40c156:	pop    r15
  40c158:	pop    r14
  40c15a:	pop    r13
  40c15c:	pop    r12
  40c15e:	pop    rdi
  40c15f:	pop    rsi
  40c160:	ret
  40c161:	xor    ecx,ecx
  40c163:	tzcnt  rcx,rax
  40c168:	lea    r12,[rsp+0x8]
  40c16d:	mov    DWORD PTR [rsp+0x8],ecx
  40c171:	mov    r13d,0x1
  40c177:	shl    r13,cl
  40c17a:	mov    rcx,rdx
  40c17d:	or     rcx,r13
  40c180:	mov    rax,rdx
  40c183:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40c189:	cmp    rax,rdx
  40c18c:	je     40c193 <__swc_fn_4fa09e82_000013_d15d37c6+0x73>
  40c18e:	mov    rdx,rax
  40c191:	jmp    40c140 <__swc_fn_4fa09e82_000013_d15d37c6+0x20>
  40c193:	mov    eax,DWORD PTR [r12]
  40c197:	shl    rax,0x4
  40c19b:	lea    r14,[rsi+rax*8+0x80]
  40c1a3:	mov    rcx,rsi
  40c1a6:	mov    rax,r12
  40c1a9:	mov    edx,DWORD PTR [rax]
  40c1ab:	call   40f3e0 <__swc_fn_4fa09e82_000011_e75d466d>
  40c1b0:	mov    r15,rax
  40c1b3:	mov    rcx,rsi
  40c1b6:	mov    rdx,r13
  40c1b9:	call   40f540 <__swc_fn_4fa09e82_000017_e238d24c>
  40c1be:	test   al,al
  40c1c0:	je     40c1f8 <__swc_fn_4fa09e82_000013_d15d37c6+0xd8>
  40c1c2:	mov    ecx,DWORD PTR [r14+0x3c]
  40c1c6:	lea    rdx,[rip+0x17e8b]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40c1cd:	mov    r8,QWORD PTR [rip+0x17e84]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40c1d4:	cs nop WORD PTR [rax+rax*1+0x0]
  40c1de:	xchg   ax,ax
  40c1e0:	mov    r9,r8
  40c1e3:	sub    r9,rcx
  40c1e6:	mov    rax,r8
  40c1e9:	lock cmpxchg QWORD PTR [rdx],r9
  40c1ee:	cmp    rax,r8
  40c1f1:	je     40c259 <__swc_fn_4fa09e82_000013_d15d37c6+0x139>
  40c1f3:	mov    r8,rax
  40c1f6:	jmp    40c1e0 <__swc_fn_4fa09e82_000013_d15d37c6+0xc0>
  40c1f8:	mov    rcx,rsi
  40c1fb:	mov    rax,r12
  40c1fe:	mov    edx,DWORD PTR [rax]
  40c200:	call   407450 <__swc_fn_4fa09e82_000012_39679ef8>
  40c205:	mov    rcx,r15
  40c208:	and    rcx,0xffffffffffff0000
  40c20f:	lea    rcx,[rcx+0x10000]
  40c216:	mov    rbx,rax
  40c219:	cmp    rax,rcx
  40c21c:	cmova  rbx,rcx
  40c220:	mov    rax,rbx
  40c223:	sub    rax,r15
  40c226:	mov    rcx,r15
  40c229:	mov    rdx,rax
  40c22c:	call   4072a0 <__swc_fn_4fa09e82_000003_644dadb7>
  40c231:	test   al,al
  40c233:	jne    40c252 <__swc_fn_4fa09e82_000013_d15d37c6+0x132>
  40c235:	mov    rcx,rsi
  40c238:	mov    rdx,r13
  40c23b:	call   407600 <__swc_fn_4fa09e82_000018_e2e8e4b0>
  40c240:	xor    eax,eax
  40c242:	add    rsp,0x30
  40c246:	pop    rbx
  40c247:	pop    r15
  40c249:	pop    r14
  40c24b:	pop    r13
  40c24d:	pop    r12
  40c24f:	pop    rdi
  40c250:	pop    rsi
  40c251:	ret
  40c252:	sub    rbx,r15
  40c255:	mov    DWORD PTR [r14+0x3c],ebx
  40c259:	mov    rcx,r14
  40c25c:	mov    rdx,rsi
  40c25f:	mov    r8d,DWORD PTR [r12]
  40c263:	mov    r9d,edi
  40c266:	mov    rbx,QWORD PTR [rsp+0x18]
  40c26b:	mov    r10d,ebx
  40c26e:	call   40bfc0 <__swc_fn_4fa09e82_000004_2fa5c690>
  40c273:	mov    rax,r14
  40c276:	add    rsp,0x30
  40c27a:	pop    rbx
  40c27b:	pop    r15
  40c27d:	pop    r14
  40c27f:	pop    r13
  40c281:	pop    r12
  40c283:	pop    rdi
  40c284:	pop    rsi
  40c285:	ret
	...

000000000040c290 <__swc_fn_4fa09e82_000016_89da4d6e>:
  40c290:	mov    r8,QWORD PTR [rcx+0x48]
  40c294:	cs nop WORD PTR [rax+rax*1+0x0]
  40c29e:	xchg   ax,ax
  40c2a0:	mov    r9,r8
  40c2a3:	or     r9,rdx
  40c2a6:	mov    rax,r8
  40c2a9:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40c2af:	cmp    rax,r8
  40c2b2:	jne    40c2b5 <__swc_fn_4fa09e82_000016_89da4d6e+0x25>
  40c2b4:	ret
  40c2b5:	mov    r8,rax
  40c2b8:	jmp    40c2a0 <__swc_fn_4fa09e82_000016_89da4d6e+0x10>
  40c2ba:	add    BYTE PTR [rax],al
  40c2bc:	add    BYTE PTR [rax],al
	...

000000000040c2c0 <__swc_fn_4fa09e82_000019_60e50998>:
  40c2c0:	push   rsi
  40c2c1:	push   rdi
  40c2c2:	push   r12
  40c2c4:	mov    rsi,rcx
  40c2c7:	xor    edi,edi
  40c2c9:	lea    r12,[rip+0x17d98]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40c2d0:	mov    eax,DWORD PTR [r12]
  40c2d4:	xor    ecx,ecx
  40c2d6:	test   rax,rax
  40c2d9:	jbe    40c314 <__swc_fn_4fa09e82_000019_60e50998+0x54>
  40c2db:	nop    DWORD PTR [rax+rax*1+0x0]
  40c2e0:	lea    rdx,[rip+0x17d89]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40c2e7:	mov    r8d,ecx
  40c2ea:	lea    r8,[r8+r8*2]
  40c2ee:	lea    r8,[rdx+r8*8]
  40c2f2:	mov    rdx,QWORD PTR [r8+0x10]
  40c2f6:	add    rdx,0x400000
  40c2fd:	cmp    rdx,0x40000000
  40c304:	ja     40c30b <__swc_fn_4fa09e82_000019_60e50998+0x4b>
  40c306:	mov    rdi,r8
  40c309:	jmp    40c314 <__swc_fn_4fa09e82_000019_60e50998+0x54>
  40c30b:	add    rcx,0x1
  40c30f:	cmp    rcx,rax
  40c312:	jb     40c2e0 <__swc_fn_4fa09e82_000019_60e50998+0x20>
  40c314:	test   rdi,rdi
  40c317:	jne    40c3a3 <__swc_fn_4fa09e82_000019_60e50998+0xe3>
  40c31d:	cmp    DWORD PTR [r12],0x10
  40c322:	jae    40c38b <__swc_fn_4fa09e82_000019_60e50998+0xcb>
  40c324:	mov    ecx,0x40400000
  40c329:	call   40f300 <__swc_fn_4fa09e82_000002_390d5093>
  40c32e:	test   rax,rax
  40c331:	je     40c38b <__swc_fn_4fa09e82_000019_60e50998+0xcb>
  40c333:	lea    rcx,[rip+0x17d36]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40c33a:	mov    edx,DWORD PTR [r12]
  40c33e:	lea    rdx,[rdx+rdx*2]
  40c342:	lea    rdx,[rcx+rdx*8]
  40c346:	mov    QWORD PTR [rdx],rax
  40c349:	lea    rax,[rax+0x3fffff]
  40c350:	and    rax,0xffffffffffc00000
  40c357:	mov    QWORD PTR [rdx+0x8],rax
  40c35b:	mov    QWORD PTR [rdx+0x10],0x0
  40c363:	mov    edx,DWORD PTR [rip+0x17cff]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40c369:	nop    DWORD PTR [rax+0x0]
  40c370:	lea    r9d,[rdx+0x1]
  40c374:	mov    rax,rdx
  40c377:	lock cmpxchg DWORD PTR [r12],r9d
  40c37d:	mov    r8d,eax
  40c380:	cmp    eax,edx
  40c382:	je     40c392 <__swc_fn_4fa09e82_000019_60e50998+0xd2>
  40c384:	mov    rdx,r8
  40c387:	jmp    40c370 <__swc_fn_4fa09e82_000019_60e50998+0xb0>
  40c389:	jmp    40c392 <__swc_fn_4fa09e82_000019_60e50998+0xd2>
  40c38b:	xor    eax,eax
  40c38d:	pop    r12
  40c38f:	pop    rdi
  40c390:	pop    rsi
  40c391:	ret
  40c392:	mov    eax,DWORD PTR [rip+0x17cd0]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40c398:	sub    eax,0x1
  40c39b:	lea    rdi,[rax+rax*2]
  40c39f:	lea    rdi,[rcx+rdi*8]
  40c3a3:	mov    r12,QWORD PTR [rdi+0x8]
  40c3a7:	add    r12,QWORD PTR [rdi+0x10]
  40c3ab:	mov    rcx,r12
  40c3ae:	mov    edx,0x3000
  40c3b3:	call   4072a0 <__swc_fn_4fa09e82_000003_644dadb7>
  40c3b8:	test   al,al
  40c3ba:	jne    40c3c3 <__swc_fn_4fa09e82_000019_60e50998+0x103>
  40c3bc:	xor    eax,eax
  40c3be:	pop    r12
  40c3c0:	pop    rdi
  40c3c1:	pop    rsi
  40c3c2:	ret
  40c3c3:	vxorps xmm0,xmm0,xmm0
  40c3c7:	xor    eax,eax
  40c3c9:	cs nop WORD PTR [rax+rax*1+0x0]
  40c3d3:	cs nop WORD PTR [rax+rax*1+0x0]
  40c3dd:	nop    DWORD PTR [rax]
  40c3e0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40c3e6:	add    rax,0x10
  40c3ea:	cmp    rax,0x3000
  40c3f1:	jne    40c3e0 <__swc_fn_4fa09e82_000019_60e50998+0x120>
  40c3f3:	mov    DWORD PTR [r12+0x28],esi
  40c3f8:	mov    eax,0x40
  40c3fd:	mov    ecx,esi
  40c3ff:	shr    eax,cl
  40c401:	mov    DWORD PTR [r12+0x2c],eax
  40c406:	cmp    DWORD PTR [r12+0x2c],0x40
  40c40c:	jb     40c417 <__swc_fn_4fa09e82_000019_60e50998+0x157>
  40c40e:	mov    rax,0xffffffffffffffff
  40c415:	jmp    40c427 <__swc_fn_4fa09e82_000019_60e50998+0x167>
  40c417:	mov    eax,0x1
  40c41c:	mov    ecx,DWORD PTR [r12+0x2c]
  40c421:	shl    rax,cl
  40c424:	dec    rax
  40c427:	mov    QWORD PTR [r12+0x20],rax
  40c42c:	mov    DWORD PTR [r12],0x4e540001
  40c434:	mov    DWORD PTR [r12+0x4],0x53474d45
  40c43d:	add    QWORD PTR [rdi+0x10],0x400000
  40c445:	mov    rax,r12
  40c448:	pop    r12
  40c44a:	pop    rdi
  40c44b:	pop    rsi
  40c44c:	ret
  40c44d:	add    BYTE PTR [rax],al
	...

000000000040c450 <__swc_fn_4fa09e82_000022_77c2d682>:
  40c450:	mov    eax,0x1
  40c455:	mov    edx,DWORD PTR [rip+0x17c0d]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40c45b:	cmp    eax,edx
  40c45d:	jae    40c4ab <__swc_fn_4fa09e82_000022_77c2d682+0x5b>
  40c45f:	nop
  40c460:	lea    r8,[rip+0x17c09]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40c467:	lea    r9,[rax+rax*2]
  40c46b:	lea    r9,[r8+r9*8]
  40c46f:	mov    r8,rcx
  40c472:	sub    r8,QWORD PTR [r9+0x8]
  40c476:	mov    r9,QWORD PTR [r9+0x10]
  40c47a:	cmp    r8,r9
  40c47d:	jae    40c4a5 <__swc_fn_4fa09e82_000022_77c2d682+0x55>
  40c47f:	mov    rax,rcx
  40c482:	and    rax,0xffffffffffc00000
  40c489:	shr    rcx,0x10
  40c48d:	and    ecx,0x3f
  40c490:	mov    edx,DWORD PTR [rax+0x28]
  40c493:	shrx   ecx,ecx,edx
  40c498:	shl    rcx,0x4
  40c49c:	lea    rax,[rax+rcx*8+0x80]
  40c4a4:	ret
  40c4a5:	inc    eax
  40c4a7:	cmp    eax,edx
  40c4a9:	jb     40c460 <__swc_fn_4fa09e82_000022_77c2d682+0x10>
  40c4ab:	xor    eax,eax
  40c4ad:	ret
	...

000000000040c4b0 <__swc_fn_4fa09e82_000025_7e9350e1>:
  40c4b0:	vxorps xmm0,xmm0,xmm0
  40c4b4:	vmovups XMMWORD PTR [rcx],xmm0
  40c4b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40c4bd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40c4c2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40c4c7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40c4cc:	mov    QWORD PTR [rcx+0x50],0x0
  40c4d4:	ret
	...

000000000040c4e0 <__swc_fn_4fa09e82_000028_7e9350e1>:
  40c4e0:	vxorps xmm0,xmm0,xmm0
  40c4e4:	xor    eax,eax
  40c4e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c4f0:	cs nop WORD PTR [rax+rax*1+0x0]
  40c4fa:	nop    WORD PTR [rax+rax*1+0x0]
  40c500:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40c505:	add    rax,0x10
  40c509:	cmp    rax,0x9b0
  40c510:	jne    40c500 <__swc_fn_4fa09e82_000028_7e9350e1+0x20>
  40c512:	mov    QWORD PTR [rcx+0x9b0],0x0
  40c51d:	ret
	...

000000000040c520 <__swc_fn_4fa09e82_000031_ed8d61a9>:
  40c520:	push   rsi
  40c521:	push   rdi
  40c522:	sub    rsp,0x8
  40c526:	lea    rsi,[rip+0x15adb]        # 422008 <__swc_data_base_4fa09e82+0x8>
  40c52d:	mov    rax,QWORD PTR [rsi]
  40c530:	mov    ecx,0xffffffff
  40c535:	cmp    rax,rcx
  40c538:	je     40c541 <__swc_fn_4fa09e82_000031_ed8d61a9+0x21>
  40c53a:	add    rsp,0x8
  40c53e:	pop    rdi
  40c53f:	pop    rsi
  40c540:	ret
  40c541:	mov    rcx,QWORD PTR [rip+0x6b70]        # 4130b8 <__swc_fn_4fa09e82_000179_6937fe70+0xfa8>
  40c548:	call   40e510 <__swc_fn_4fa09e82_000127_5fb20c72>
  40c54d:	mov    rcx,rax
  40c550:	mov    eax,0xffffffff
  40c555:	lock cmpxchg QWORD PTR [rsi],rcx
  40c55a:	mov    rdi,rax
  40c55d:	mov    eax,0xffffffff
  40c562:	cmp    rdi,rax
  40c565:	je     40c576 <__swc_fn_4fa09e82_000031_ed8d61a9+0x56>
  40c567:	call   411670 <__swc_fn_4fa09e82_000128_75f8ab5c>
  40c56c:	mov    rax,rdi
  40c56f:	add    rsp,0x8
  40c573:	pop    rdi
  40c574:	pop    rsi
  40c575:	ret
  40c576:	mov    rax,rcx
  40c579:	add    rsp,0x8
  40c57d:	pop    rdi
  40c57e:	pop    rsi
  40c57f:	ret

000000000040c580 <__swc_fn_4fa09e82_000034_c72914a2>:
  40c580:	sub    rsp,0x8
  40c584:	vxorps xmm0,xmm0,xmm0
  40c588:	xor    eax,eax
  40c58a:	cs nop WORD PTR [rax+rax*1+0x0]
  40c594:	cs nop WORD PTR [rax+rax*1+0x0]
  40c59e:	xchg   ax,ax
  40c5a0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40c5a5:	add    rax,0x10
  40c5a9:	cmp    rax,0x2b00
  40c5b0:	jne    40c5a0 <__swc_fn_4fa09e82_000034_c72914a2+0x20>
  40c5b2:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40c5bc:	xor    al,al
  40c5be:	mov    rdx,rax
  40c5c1:	xor    al,al
  40c5c3:	mov    r8,rax
  40c5c6:	xor    al,al
  40c5c8:	mov    r9,rax
  40c5cb:	xor    al,al
  40c5cd:	mov    r10,rax
  40c5d0:	xor    al,al
  40c5d2:	mov    r11,rax
  40c5d5:	call   40f770 <__swc_fn_4fa09e82_000035_6105596e>
  40c5da:	add    rsp,0x8
  40c5de:	ret
	...

000000000040c5e0 <__swc_fn_4fa09e82_000037_92e867c2>:
  40c5e0:	push   rsi
  40c5e1:	push   rdi
  40c5e2:	push   r12
  40c5e4:	mov    rsi,r8
  40c5e7:	mov    rdi,rdx
  40c5ea:	mov    rcx,rdx
  40c5ed:	call   40f300 <__swc_fn_4fa09e82_000002_390d5093>
  40c5f2:	mov    r12,rax
  40c5f5:	test   rax,rax
  40c5f8:	jne    40c601 <__swc_fn_4fa09e82_000037_92e867c2+0x21>
  40c5fa:	xor    eax,eax
  40c5fc:	pop    r12
  40c5fe:	pop    rdi
  40c5ff:	pop    rsi
  40c600:	ret
  40c601:	mov    rcx,r12
  40c604:	mov    rdx,rsi
  40c607:	call   4072a0 <__swc_fn_4fa09e82_000003_644dadb7>
  40c60c:	test   al,al
  40c60e:	jne    40c622 <__swc_fn_4fa09e82_000037_92e867c2+0x42>
  40c610:	mov    rcx,r12
  40c613:	mov    rdx,rdi
  40c616:	call   409850 <__swc_fn_4fa09e82_000114_25e345b1>
  40c61b:	xor    eax,eax
  40c61d:	pop    r12
  40c61f:	pop    rdi
  40c620:	pop    rsi
  40c621:	ret
  40c622:	mov    rax,r12
  40c625:	pop    r12
  40c627:	pop    rdi
  40c628:	pop    rsi
  40c629:	ret
	...

000000000040c640 <__swc_fn_4fa09e82_000040_7a225310>:
  40c640:	push   rsi
  40c641:	push   rdi
  40c642:	push   r12
  40c644:	mov    rsi,rcx
  40c647:	mov    edx,0x9b8
  40c64c:	call   40f7e0 <__swc_fn_4fa09e82_000038_c7591393>
  40c651:	mov    rdi,rax
  40c654:	test   rax,rax
  40c657:	jne    40c660 <__swc_fn_4fa09e82_000040_7a225310+0x20>
  40c659:	xor    eax,eax
  40c65b:	pop    r12
  40c65d:	pop    rdi
  40c65e:	pop    rsi
  40c65f:	ret
  40c660:	vxorps xmm0,xmm0,xmm0
  40c664:	xor    eax,eax
  40c666:	cs nop WORD PTR [rax+rax*1+0x0]
  40c670:	cs nop WORD PTR [rax+rax*1+0x0]
  40c67a:	nop    WORD PTR [rax+rax*1+0x0]
  40c680:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40c685:	add    rax,0x10
  40c689:	cmp    rax,0x9b0
  40c690:	jne    40c680 <__swc_fn_4fa09e82_000040_7a225310+0x40>
  40c692:	mov    QWORD PTR [rdi+0x9b0],0x0
  40c69d:	mov    QWORD PTR [rdi],rsi
  40c6a0:	call   411720 <__swc_fn_4fa09e82_000131_d2d78689>
  40c6a5:	mov    QWORD PTR [rdi+0x18],rax
  40c6a9:	lea    r12,[rsi+0x10]
  40c6ad:	mov    rcx,r12
  40c6b0:	call   40e760 <__swc_fn_4fa09e82_000136_1fec60ac>
  40c6b5:	mov    rax,QWORD PTR [rsi+0x20]
  40c6b9:	mov    QWORD PTR [rdi+0x8],rax
  40c6bd:	mov    rax,QWORD PTR [rsi+0x20]
  40c6c1:	test   rax,rax
  40c6c4:	je     40c6ca <__swc_fn_4fa09e82_000040_7a225310+0x8a>
  40c6c6:	mov    QWORD PTR [rax+0x10],rdi
  40c6ca:	mov    QWORD PTR [rsi+0x20],rdi
  40c6ce:	mov    rcx,r12
  40c6d1:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40c6d6:	mov    rax,rdi
  40c6d9:	pop    r12
  40c6db:	pop    rdi
  40c6dc:	pop    rsi
  40c6dd:	ret
	...

000000000040c6e0 <__swc_fn_4fa09e82_000043_3755033a>:
  40c6e0:	mov    rax,QWORD PTR [rdx+0x10]
  40c6e4:	test   rax,rax
  40c6e7:	je     40c6f3 <__swc_fn_4fa09e82_000043_3755033a+0x13>
  40c6e9:	mov    rcx,QWORD PTR [rdx+0x8]
  40c6ed:	mov    QWORD PTR [rax+0x8],rcx
  40c6f1:	jmp    40c6fb <__swc_fn_4fa09e82_000043_3755033a+0x1b>
  40c6f3:	mov    rax,QWORD PTR [rdx+0x8]
  40c6f7:	mov    QWORD PTR [rcx+0x20],rax
  40c6fb:	mov    rax,QWORD PTR [rdx+0x8]
  40c6ff:	test   rax,rax
  40c702:	je     40c70c <__swc_fn_4fa09e82_000043_3755033a+0x2c>
  40c704:	mov    rcx,QWORD PTR [rdx+0x10]
  40c708:	mov    QWORD PTR [rax+0x10],rcx
  40c70c:	vxorps xmm0,xmm0,xmm0
  40c710:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40c715:	ret
	...

000000000040c720 <__swc_fn_4fa09e82_000046_49300800>:
  40c720:	sub    rsp,0x8
  40c724:	mov    r9,r8
  40c727:	mov    r10,rdx
  40c72a:	call   40f890 <__swc_fn_4fa09e82_000044_cac7f504>
  40c72f:	mov    eax,0x1
  40c734:	xchg   DWORD PTR [r9+0x6c],eax
  40c738:	mov    rax,QWORD PTR [r9+0x60]
  40c73c:	test   rax,rax
  40c73f:	je     40c783 <__swc_fn_4fa09e82_000046_49300800+0x63>
  40c741:	xor    eax,eax
  40c743:	xchg   DWORD PTR [r9+0x6c],eax
  40c747:	movzx  eax,BYTE PTR [r9+0x39]
  40c74c:	lea    rax,[rax+rax*4]
  40c750:	lea    rax,[r10+rax*8+0x28]
  40c755:	mov    QWORD PTR [r9+0x50],0x0
  40c75d:	mov    rcx,QWORD PTR [rax+0x8]
  40c761:	mov    QWORD PTR [r9+0x48],rcx
  40c765:	mov    rcx,QWORD PTR [rax+0x8]
  40c769:	test   rcx,rcx
  40c76c:	je     40c774 <__swc_fn_4fa09e82_000046_49300800+0x54>
  40c76e:	mov    QWORD PTR [rcx+0x50],r9
  40c772:	jmp    40c778 <__swc_fn_4fa09e82_000046_49300800+0x58>
  40c774:	mov    QWORD PTR [rax+0x10],r9
  40c778:	mov    QWORD PTR [rax+0x8],r9
  40c77c:	xor    eax,eax
  40c77e:	add    rsp,0x8
  40c782:	ret
  40c783:	movzx  eax,BYTE PTR [r9+0x39]
  40c788:	lea    rax,[rax+rax*4]
  40c78c:	lea    rax,[r10+rax*8+0x28]
  40c791:	mov    QWORD PTR [r9+0x50],0x0
  40c799:	mov    rcx,QWORD PTR [rax+0x18]
  40c79d:	mov    QWORD PTR [r9+0x48],rcx
  40c7a1:	mov    rcx,QWORD PTR [rax+0x18]
  40c7a5:	test   rcx,rcx
  40c7a8:	je     40c7ae <__swc_fn_4fa09e82_000046_49300800+0x8e>
  40c7aa:	mov    QWORD PTR [rcx+0x50],r9
  40c7ae:	mov    QWORD PTR [rax+0x18],r9
  40c7b2:	mov    eax,0x1
  40c7b7:	add    rsp,0x8
  40c7bb:	ret
  40c7bc:	add    BYTE PTR [rax],al
	...

000000000040c7c0 <__swc_fn_4fa09e82_000049_781177b4>:
  40c7c0:	push   r12
  40c7c2:	push   r13
  40c7c4:	push   rdi
  40c7c5:	push   rsi
  40c7c6:	push   r14
  40c7c8:	push   r15
  40c7ca:	sub    rsp,0x178
  40c7d1:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40c7da:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40c7e3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40c7ec:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40c7f5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40c7fe:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40c807:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40c810:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40c819:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40c822:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40c82b:	mov    r12,rcx
  40c82e:	lea    rax,[rip+0x179cb]        # 424200 <__swc_bss_base_4fa09e82+0x1c0>
  40c835:	mov    rcx,QWORD PTR [rax]
  40c838:	mov    r13,rcx
  40c83b:	test   rcx,rcx
  40c83e:	jne    40c84e <__swc_fn_4fa09e82_000049_781177b4+0x8e>
  40c840:	mov    r13d,0x1dcd6500
  40c846:	mov    ecx,0x1dcd6500
  40c84b:	xchg   QWORD PTR [rax],rcx
  40c84e:	lea    rax,[rip+0x157ab]        # 422000 <__swc_data_base_4fa09e82>
  40c855:	mov    rax,QWORD PTR [rax]
  40c858:	cmp    rax,0xffffffffffffffff
  40c85c:	je     40c86b <__swc_fn_4fa09e82_000049_781177b4+0xab>
  40c85e:	mov    eax,eax
  40c860:	mov    edi,eax
  40c862:	xor    eax,eax
  40c864:	call   407000 <pthread_getspecific@plt>
  40c869:	jmp    40c86d <__swc_fn_4fa09e82_000049_781177b4+0xad>
  40c86b:	xor    eax,eax
  40c86d:	test   rax,rax
  40c870:	jne    40c87f <__swc_fn_4fa09e82_000049_781177b4+0xbf>
  40c872:	call   40c520 <__swc_fn_4fa09e82_000031_ed8d61a9>
  40c877:	mov    rcx,rax
  40c87a:	call   409ba0 <__swc_fn_4fa09e82_000129_9c45d2d7>
  40c87f:	test   rax,rax
  40c882:	je     40c894 <__swc_fn_4fa09e82_000049_781177b4+0xd4>
  40c884:	cmp    QWORD PTR [rax],r12
  40c887:	jne    40c894 <__swc_fn_4fa09e82_000049_781177b4+0xd4>
  40c889:	cmp    DWORD PTR [rax+0x20],0x0
  40c88d:	jne    40c894 <__swc_fn_4fa09e82_000049_781177b4+0xd4>
  40c88f:	mov    rsi,rax
  40c892:	jmp    40c896 <__swc_fn_4fa09e82_000049_781177b4+0xd6>
  40c894:	xor    esi,esi
  40c896:	lea    rdi,[r12+0x2a88]
  40c89e:	mov    r14,QWORD PTR [rdi]
  40c8a1:	test   r14,r14
  40c8a4:	jne    40c8f3 <__swc_fn_4fa09e82_000049_781177b4+0x133>
  40c8a6:	lea    rax,[rip+0x177ab]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40c8ad:	mov    rax,QWORD PTR [rax]
  40c8b0:	test   rax,rax
  40c8b3:	setne  al
  40c8b6:	jne    40c8da <__swc_fn_4fa09e82_000049_781177b4+0x11a>
  40c8b8:	mov    rax,QWORD PTR [r12+0x2a70]
  40c8c0:	test   rax,rax
  40c8c3:	setne  al
  40c8c6:	jne    40c8da <__swc_fn_4fa09e82_000049_781177b4+0x11a>
  40c8c8:	test   rsi,rsi
  40c8cb:	setne  al
  40c8ce:	je     40c8da <__swc_fn_4fa09e82_000049_781177b4+0x11a>
  40c8d0:	cmp    DWORD PTR [rsi+0x730],0x0
  40c8d7:	setne  al
  40c8da:	test   al,al
  40c8dc:	je     40c8ee <__swc_fn_4fa09e82_000049_781177b4+0x12e>
  40c8de:	call   409c50 <__swc_fn_4fa09e82_000132_dc04d759>
  40c8e3:	lea    rcx,[rax+r13*1]
  40c8e7:	xor    eax,eax
  40c8e9:	lock cmpxchg QWORD PTR [rdi],rcx
  40c8ee:	jmp    40c9f3 <__swc_fn_4fa09e82_000049_781177b4+0x233>
  40c8f3:	call   409c50 <__swc_fn_4fa09e82_000132_dc04d759>
  40c8f8:	mov    r15,rax
  40c8fb:	cmp    rax,r14
  40c8fe:	jb     40c90f <__swc_fn_4fa09e82_000049_781177b4+0x14f>
  40c900:	xor    ecx,ecx
  40c902:	mov    rax,r14
  40c905:	lock cmpxchg QWORD PTR [rdi],rcx
  40c90a:	cmp    rax,r14
  40c90d:	je     40c914 <__swc_fn_4fa09e82_000049_781177b4+0x154>
  40c90f:	jmp    40c9f3 <__swc_fn_4fa09e82_000049_781177b4+0x233>
  40c914:	test   rsi,rsi
  40c917:	je     40c932 <__swc_fn_4fa09e82_000049_781177b4+0x172>
  40c919:	cmp    r15,r13
  40c91c:	jb     40c932 <__swc_fn_4fa09e82_000049_781177b4+0x172>
  40c91e:	mov    rax,r15
  40c921:	sub    rax,r13
  40c924:	mov    rcx,r12
  40c927:	mov    rdx,rsi
  40c92a:	mov    r8,rax
  40c92d:	call   40fcd0 <__swc_fn_4fa09e82_000059_c8e1ff6b>
  40c932:	lea    rsi,[r12+0x10]
  40c937:	mov    rcx,rsi
  40c93a:	call   40e760 <__swc_fn_4fa09e82_000136_1fec60ac>
  40c93f:	mov    rax,QWORD PTR [r12+0x18]
  40c944:	mov    rdi,rax
  40c947:	test   rdi,rdi
  40c94a:	je     40c974 <__swc_fn_4fa09e82_000049_781177b4+0x1b4>
  40c94c:	cs nop WORD PTR [rax+rax*1+0x0]
  40c956:	cs nop WORD PTR [rax+rax*1+0x0]
  40c960:	mov    rcx,rdi
  40c963:	call   407470 <__swc_fn_4fa09e82_000015_aa8c841a>
  40c968:	mov    rax,QWORD PTR [rdi+0x10]
  40c96c:	mov    rdi,rax
  40c96f:	test   rax,rax
  40c972:	jne    40c960 <__swc_fn_4fa09e82_000049_781177b4+0x1a0>
  40c974:	mov    rcx,rsi
  40c977:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40c97c:	mov    rcx,r12
  40c97f:	call   40e760 <__swc_fn_4fa09e82_000136_1fec60ac>
  40c984:	xor    esi,esi
  40c986:	cs nop WORD PTR [rax+rax*1+0x0]
  40c990:	mov    rax,QWORD PTR [r12+0x2a70]
  40c998:	cmp    rsi,rax
  40c99b:	jae    40c9eb <__swc_fn_4fa09e82_000049_781177b4+0x22b>
  40c99d:	lea    rax,[rsi+rsi*4]
  40c9a1:	lea    rax,[r12+rax*8+0x268]
  40c9a9:	mov    r8,QWORD PTR [rax]
  40c9ac:	mov    r9,QWORD PTR [rax+0x8]
  40c9b0:	mov    r10,QWORD PTR [rax+0x10]
  40c9b4:	mov    rax,QWORD PTR [rax+0x20]
  40c9b8:	cmp    rax,r15
  40c9bb:	jae    40c9c8 <__swc_fn_4fa09e82_000049_781177b4+0x208>
  40c9bd:	mov    rcx,r15
  40c9c0:	sub    rcx,rax
  40c9c3:	cmp    rcx,r13
  40c9c6:	jae    40c9cd <__swc_fn_4fa09e82_000049_781177b4+0x20d>
  40c9c8:	inc    rsi
  40c9cb:	jmp    40c990 <__swc_fn_4fa09e82_000049_781177b4+0x1d0>
  40c9cd:	mov    rcx,r12
  40c9d0:	mov    rdx,rsi
  40c9d3:	call   40fc80 <__swc_fn_4fa09e82_000056_cfedf3f4>
  40c9d8:	mov    rcx,r12
  40c9db:	mov    rdx,r8
  40c9de:	mov    r8,r9
  40c9e1:	mov    r9,r10
  40c9e4:	call   407750 <__swc_fn_4fa09e82_000039_05a50673>
  40c9e9:	jmp    40c990 <__swc_fn_4fa09e82_000049_781177b4+0x1d0>
  40c9eb:	mov    rcx,r12
  40c9ee:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40c9f3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40c9fc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40ca05:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40ca0e:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40ca17:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40ca20:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40ca29:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40ca32:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40ca3b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40ca44:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40ca4d:	add    rsp,0x178
  40ca54:	pop    r15
  40ca56:	pop    r14
  40ca58:	pop    rsi
  40ca59:	pop    rdi
  40ca5a:	pop    r13
  40ca5c:	pop    r12
  40ca5e:	ret
	...

000000000040ca60 <__swc_fn_4fa09e82_000052_26c6c1c4>:
  40ca60:	lea    rax,[rdx-0x58]
  40ca64:	ret
	...

000000000040ca70 <__swc_fn_4fa09e82_000055_da36318f>:
  40ca70:	push   rsi
  40ca71:	push   rdi
  40ca72:	push   r12
  40ca74:	push   r13
  40ca76:	sub    rsp,0x68
  40ca7a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40ca80:	mov    rsi,r9
  40ca83:	mov    rdi,rcx
  40ca86:	mov    r12,rdx
  40ca89:	mov    r13,r8
  40ca8c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40ca94:	jne    40caa3 <__swc_fn_4fa09e82_000055_da36318f+0x33>
  40ca96:	xor    eax,eax
  40ca98:	add    rsp,0x68
  40ca9c:	pop    r13
  40ca9e:	pop    r12
  40caa0:	pop    rdi
  40caa1:	pop    rsi
  40caa2:	ret
  40caa3:	mov    rcx,rdi
  40caa6:	call   40e760 <__swc_fn_4fa09e82_000136_1fec60ac>
  40caab:	movabs rax,0x7fffffffffffffff
  40cab5:	cmp    r12,rax
  40cab8:	mov    rax,0xffffffffffffffff
  40cabf:	lea    rcx,[r12+r12*1]
  40cac3:	cmovbe rax,rcx
  40cac7:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40cace:	mov    rdx,rcx
  40cad1:	sub    rax,r12
  40cad4:	inc    rax
  40cad7:	xor    r8d,r8d
  40cada:	test   rcx,rcx
  40cadd:	jbe    40cb08 <__swc_fn_4fa09e82_000055_da36318f+0x98>
  40cadf:	nop
  40cae0:	lea    r9,[r8+r8*4]
  40cae4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40caec:	sub    r9,r12
  40caef:	cmp    r9,rax
  40caf2:	jae    40caff <__swc_fn_4fa09e82_000055_da36318f+0x8f>
  40caf4:	mov    rdx,r8
  40caf7:	mov    rax,r9
  40cafa:	test   r9,r9
  40cafd:	je     40cb08 <__swc_fn_4fa09e82_000055_da36318f+0x98>
  40caff:	add    r8,0x1
  40cb03:	cmp    r8,rcx
  40cb06:	jb     40cae0 <__swc_fn_4fa09e82_000055_da36318f+0x70>
  40cb08:	mov    rax,QWORD PTR [rdi+0x2a70]
  40cb0f:	cmp    rdx,rax
  40cb12:	jne    40cb2f <__swc_fn_4fa09e82_000055_da36318f+0xbf>
  40cb14:	mov    rcx,rdi
  40cb17:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40cb1c:	xor    eax,eax
  40cb1e:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40cb24:	add    rsp,0x68
  40cb28:	pop    r13
  40cb2a:	pop    r12
  40cb2c:	pop    rdi
  40cb2d:	pop    rsi
  40cb2e:	ret
  40cb2f:	lea    rax,[rdx+rdx*4]
  40cb33:	lea    rax,[rdi+rax*8+0x268]
  40cb3b:	vmovups xmm6,XMMWORD PTR [rax]
  40cb3f:	mov    r8,QWORD PTR [rax+0x10]
  40cb43:	mov    rcx,rdi
  40cb46:	call   40fc80 <__swc_fn_4fa09e82_000056_cfedf3f4>
  40cb4b:	vpshufd xmm0,xmm6,0xee
  40cb50:	vmovsd QWORD PTR [r13+0x0],xmm0
  40cb56:	mov    QWORD PTR [rsi],r8
  40cb59:	mov    rcx,rdi
  40cb5c:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40cb61:	vmovq  rax,xmm6
  40cb66:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40cb6c:	add    rsp,0x68
  40cb70:	pop    r13
  40cb72:	pop    r12
  40cb74:	pop    rdi
  40cb75:	pop    rsi
  40cb76:	ret
	...

000000000040cb80 <__swc_fn_4fa09e82_000058_033ce1da>:
  40cb80:	push   r12
  40cb82:	push   r13
  40cb84:	push   r14
  40cb86:	push   r15
  40cb88:	push   rdi
  40cb89:	push   rsi
  40cb8a:	sub    rsp,0x148
  40cb91:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40cb9a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40cba3:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40cbac:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40cbb5:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40cbbe:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40cbc7:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40cbd0:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40cbd9:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40cbe2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40cbeb:	mov    r12,r9
  40cbee:	mov    r13,rcx
  40cbf1:	mov    r14,rdx
  40cbf4:	mov    r15,r8
  40cbf7:	test   rdx,rdx
  40cbfa:	jne    40cc0e <__swc_fn_4fa09e82_000058_033ce1da+0x8e>
  40cbfc:	add    rsp,0x148
  40cc03:	pop    rsi
  40cc04:	pop    rdi
  40cc05:	pop    r15
  40cc07:	pop    r14
  40cc09:	pop    r13
  40cc0b:	pop    r12
  40cc0d:	ret
  40cc0e:	cmp    r12,0x200000
  40cc15:	ja     40cca7 <__swc_fn_4fa09e82_000058_033ce1da+0x127>
  40cc1b:	lea    rax,[rip+0x153de]        # 422000 <__swc_data_base_4fa09e82>
  40cc22:	mov    rax,QWORD PTR [rax]
  40cc25:	cmp    rax,0xffffffffffffffff
  40cc29:	je     40cc38 <__swc_fn_4fa09e82_000058_033ce1da+0xb8>
  40cc2b:	mov    eax,eax
  40cc2d:	mov    edi,eax
  40cc2f:	xor    eax,eax
  40cc31:	call   407000 <pthread_getspecific@plt>
  40cc36:	jmp    40cc3a <__swc_fn_4fa09e82_000058_033ce1da+0xba>
  40cc38:	xor    eax,eax
  40cc3a:	test   rax,rax
  40cc3d:	je     40cc44 <__swc_fn_4fa09e82_000058_033ce1da+0xc4>
  40cc3f:	mov    rsi,rax
  40cc42:	jmp    40cc54 <__swc_fn_4fa09e82_000058_033ce1da+0xd4>
  40cc44:	call   40c520 <__swc_fn_4fa09e82_000031_ed8d61a9>
  40cc49:	mov    rcx,rax
  40cc4c:	call   409ba0 <__swc_fn_4fa09e82_000129_9c45d2d7>
  40cc51:	mov    rsi,rax
  40cc54:	test   rsi,rsi
  40cc57:	je     40cca7 <__swc_fn_4fa09e82_000058_033ce1da+0x127>
  40cc59:	cmp    QWORD PTR [rsi],r13
  40cc5c:	jne    40cca7 <__swc_fn_4fa09e82_000058_033ce1da+0x127>
  40cc5e:	cmp    DWORD PTR [rsi+0x20],0x0
  40cc62:	jne    40cca7 <__swc_fn_4fa09e82_000058_033ce1da+0x127>
  40cc64:	cmp    DWORD PTR [rsi+0x730],0x10
  40cc6b:	jae    40cca7 <__swc_fn_4fa09e82_000058_033ce1da+0x127>
  40cc6d:	mov    eax,DWORD PTR [rsi+0x730]
  40cc73:	lea    rdi,[rax+rax*4]
  40cc77:	lea    rdi,[rsi+rdi*8+0x738]
  40cc7f:	mov    QWORD PTR [rdi],r14
  40cc82:	mov    QWORD PTR [rdi+0x8],r15
  40cc86:	mov    QWORD PTR [rdi+0x10],r12
  40cc8a:	mov    QWORD PTR [rdi+0x18],0x0
  40cc92:	call   409c50 <__swc_fn_4fa09e82_000132_dc04d759>
  40cc97:	mov    QWORD PTR [rdi+0x20],rax
  40cc9b:	add    DWORD PTR [rsi+0x730],0x1
  40cca2:	jmp    40ce06 <__swc_fn_4fa09e82_000058_033ce1da+0x286>
  40cca7:	mov    rcx,r13
  40ccaa:	call   407e90 <__swc_fn_4fa09e82_000057_8be0372b>
  40ccaf:	mov    rsi,rax
  40ccb2:	cmp    r12,rax
  40ccb5:	jbe    40ccea <__swc_fn_4fa09e82_000058_033ce1da+0x16a>
  40ccb7:	cmp    r12,0x10000000
  40ccbe:	seta   al
  40ccc1:	ja     40ccd0 <__swc_fn_4fa09e82_000058_033ce1da+0x150>
  40ccc3:	mov    rax,QWORD PTR [r13+0x2a70]
  40ccca:	test   rax,rax
  40cccd:	setne  al
  40ccd0:	test   al,al
  40ccd2:	je     40ccea <__swc_fn_4fa09e82_000058_033ce1da+0x16a>
  40ccd4:	mov    rcx,r13
  40ccd7:	mov    rdx,r14
  40ccda:	mov    r8,r15
  40ccdd:	mov    r9,r12
  40cce0:	call   407750 <__swc_fn_4fa09e82_000039_05a50673>
  40cce5:	jmp    40ce06 <__swc_fn_4fa09e82_000058_033ce1da+0x286>
  40ccea:	call   409c50 <__swc_fn_4fa09e82_000132_dc04d759>
  40ccef:	mov    rdi,rax
  40ccf2:	mov    rcx,r13
  40ccf5:	call   40e760 <__swc_fn_4fa09e82_000136_1fec60ac>
  40ccfa:	cmp    QWORD PTR [r13+0x2a70],0x0
  40cd02:	je     40cdba <__swc_fn_4fa09e82_000058_033ce1da+0x23a>
  40cd08:	nop    DWORD PTR [rax+rax*1+0x0]
  40cd10:	cmp    QWORD PTR [r13+0x2a70],0x100
  40cd1b:	jae    40cd30 <__swc_fn_4fa09e82_000058_033ce1da+0x1b0>
  40cd1d:	mov    rax,QWORD PTR [r13+0x2a68]
  40cd24:	add    rax,r12
  40cd27:	cmp    rax,rsi
  40cd2a:	jbe    40cdba <__swc_fn_4fa09e82_000058_033ce1da+0x23a>
  40cd30:	xor    eax,eax
  40cd32:	mov    rcx,QWORD PTR [r13+0x2a70]
  40cd39:	mov    edx,0x1
  40cd3e:	cmp    rcx,0x1
  40cd42:	jbe    40cd79 <__swc_fn_4fa09e82_000058_033ce1da+0x1f9>
  40cd44:	cs nop WORD PTR [rax+rax*1+0x0]
  40cd4e:	xchg   ax,ax
  40cd50:	lea    r8,[rdx+rdx*4]
  40cd54:	lea    r8,[r13+r8*8+0x268]
  40cd5c:	lea    r9,[rax+rax*4]
  40cd60:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40cd68:	cmp    QWORD PTR [r8+0x18],r9
  40cd6c:	cmovb  rax,rdx
  40cd70:	add    rdx,0x1
  40cd74:	cmp    rdx,rcx
  40cd77:	jb     40cd50 <__swc_fn_4fa09e82_000058_033ce1da+0x1d0>
  40cd79:	lea    rcx,[rax+rax*4]
  40cd7d:	lea    rcx,[r13+rcx*8+0x268]
  40cd85:	mov    r8,QWORD PTR [rcx]
  40cd88:	mov    r9,QWORD PTR [rcx+0x8]
  40cd8c:	mov    r10,QWORD PTR [rcx+0x10]
  40cd90:	mov    rcx,r13
  40cd93:	mov    rdx,rax
  40cd96:	call   40fc80 <__swc_fn_4fa09e82_000056_cfedf3f4>
  40cd9b:	mov    rcx,r13
  40cd9e:	mov    rdx,r8
  40cda1:	mov    r8,r9
  40cda4:	mov    r9,r10
  40cda7:	call   407750 <__swc_fn_4fa09e82_000039_05a50673>
  40cdac:	cmp    QWORD PTR [r13+0x2a70],0x0
  40cdb4:	jne    40cd10 <__swc_fn_4fa09e82_000058_033ce1da+0x190>
  40cdba:	add    QWORD PTR [r13+0x2a78],0x1
  40cdc2:	mov    rax,QWORD PTR [r13+0x2a70]
  40cdc9:	lea    rax,[rax+rax*4]
  40cdcd:	lea    rax,[r13+rax*8+0x268]
  40cdd5:	mov    QWORD PTR [rax],r14
  40cdd8:	mov    QWORD PTR [rax+0x8],r15
  40cddc:	mov    QWORD PTR [rax+0x10],r12
  40cde0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40cde7:	mov    QWORD PTR [rax+0x18],rcx
  40cdeb:	mov    QWORD PTR [rax+0x20],rdi
  40cdef:	add    QWORD PTR [r13+0x2a68],r12
  40cdf6:	add    QWORD PTR [r13+0x2a70],0x1
  40cdfe:	mov    rcx,r13
  40ce01:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40ce06:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40ce0f:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40ce18:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40ce21:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40ce2a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40ce33:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40ce3c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40ce45:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40ce4e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40ce57:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40ce60:	add    rsp,0x148
  40ce67:	pop    rsi
  40ce68:	pop    rdi
  40ce69:	pop    r15
  40ce6b:	pop    r14
  40ce6d:	pop    r13
  40ce6f:	pop    r12
  40ce71:	ret
	...

000000000040ce80 <__swc_fn_4fa09e82_000061_1badc238>:
  40ce80:	push   rbx
  40ce81:	push   r12
  40ce83:	push   r13
  40ce85:	push   r14
  40ce87:	push   r15
  40ce89:	push   rdi
  40ce8a:	push   rsi
  40ce8b:	sub    rsp,0xf0
  40ce92:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40ce98:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40ce9e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40cea4:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40ceaa:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40ceb3:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40cebc:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40cec5:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40cece:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40ced7:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40cee0:	mov    eax,r8d
  40cee3:	mov    rbx,rcx
  40cee6:	mov    r12,rdx
  40cee9:	mov    QWORD PTR [rsp+0x18],rdx
  40ceee:	mov    ecx,DWORD PTR [r12+0x58]
  40cef3:	mov    r13d,ecx
  40cef6:	cmp    ecx,0x10
  40cef9:	mov    ecx,0x10
  40cefe:	cmovb  r13d,ecx
  40cf02:	test   r13d,r13d
  40cf05:	mov    rcx,r13
  40cf08:	mov    edx,0x8
  40cf0d:	cmove  ecx,edx
  40cf10:	dec    rcx
  40cf13:	mov    rdx,0xffffffffffffffff
  40cf1a:	sub    rdx,rcx
  40cf1d:	xor    r14d,r14d
  40cf20:	mov    r8,rcx
  40cf23:	not    r8
  40cf26:	lea    rcx,[rcx+0x58]
  40cf2a:	and    rcx,r8
  40cf2d:	cmp    rdx,0x58
  40cf31:	cmovae r14,rcx
  40cf35:	cmp    eax,0xffffffff
  40cf38:	jne    40cf41 <__swc_fn_4fa09e82_000061_1badc238+0xc1>
  40cf3a:	mov    r15,QWORD PTR [r12+0x48]
  40cf3f:	jmp    40cf73 <__swc_fn_4fa09e82_000061_1badc238+0xf3>
  40cf41:	test   eax,eax
  40cf43:	jne    40cf4c <__swc_fn_4fa09e82_000061_1badc238+0xcc>
  40cf45:	mov    eax,0x8
  40cf4a:	jmp    40cf70 <__swc_fn_4fa09e82_000061_1badc238+0xf0>
  40cf4c:	cmp    eax,0x8
  40cf4f:	ja     40cf57 <__swc_fn_4fa09e82_000061_1badc238+0xd7>
  40cf51:	shl    rax,0x4
  40cf55:	jmp    40cf70 <__swc_fn_4fa09e82_000061_1badc238+0xf0>
  40cf57:	lea    eax,[rax-0x9]
  40cf5a:	mov    ecx,eax
  40cf5c:	shr    ecx,0x2
  40cf5f:	and    eax,0x3
  40cf62:	lea    ecx,[rcx+0x7]
  40cf65:	lea    ecx,[rcx-0x2]
  40cf68:	lea    eax,[rax+0x5]
  40cf6b:	shlx   rax,rax,rcx
  40cf70:	mov    r15,rax
  40cf73:	lea    rax,[r14+r13*1]
  40cf77:	mov    rcx,0xffffffffffffffff
  40cf7e:	sub    rcx,rax
  40cf81:	cmp    r15,rcx
  40cf84:	jbe    40cf94 <__swc_fn_4fa09e82_000061_1badc238+0x114>
  40cf86:	mov    QWORD PTR [r12+0x40],0x0
  40cf8f:	jmp    40d366 <__swc_fn_4fa09e82_000061_1badc238+0x4e6>
  40cf94:	mov    QWORD PTR [rsp+0x20],r13
  40cf99:	lea    r13,[rsp+0x8]
  40cf9e:	add    rax,r15
  40cfa1:	mov    ecx,0x1000
  40cfa6:	test   ecx,ecx
  40cfa8:	mov    edx,0x8
  40cfad:	cmove  ecx,edx
  40cfb0:	dec    rcx
  40cfb3:	mov    rdx,0xffffffffffffffff
  40cfba:	sub    rdx,rcx
  40cfbd:	cmp    rax,rdx
  40cfc0:	jbe    40cfcc <__swc_fn_4fa09e82_000061_1badc238+0x14c>
  40cfc2:	mov    QWORD PTR [r13+0x0],0x0
  40cfca:	jmp    40cfd9 <__swc_fn_4fa09e82_000061_1badc238+0x159>
  40cfcc:	add    rax,rcx
  40cfcf:	andn   rax,rcx,rax
  40cfd4:	mov    QWORD PTR [rsp+0x8],rax
  40cfd9:	cmp    QWORD PTR [r13+0x0],0x0
  40cfde:	jne    40cfee <__swc_fn_4fa09e82_000061_1badc238+0x16e>
  40cfe0:	mov    QWORD PTR [r12+0x40],0x0
  40cfe9:	jmp    40d366 <__swc_fn_4fa09e82_000061_1badc238+0x4e6>
  40cfee:	mov    QWORD PTR [rsp+0x30],r15
  40cff3:	xor    r15d,r15d
  40cff6:	mov    QWORD PTR [rsp+0x38],0x0
  40cfff:	lea    r12,[rsp+0x10]
  40d004:	mov    QWORD PTR [rsp+0x28],r14
  40d009:	mov    r14,QWORD PTR [rsp+0x8]
  40d00e:	mov    QWORD PTR [rsp+0x10],r14
  40d013:	cmp    r14,0x10000
  40d01a:	ja     40d021 <__swc_fn_4fa09e82_000061_1badc238+0x1a1>
  40d01c:	mov    rax,r14
  40d01f:	jmp    40d072 <__swc_fn_4fa09e82_000061_1badc238+0x1f2>
  40d021:	xor    eax,eax
  40d023:	lea    rcx,[r14-0x1]
  40d027:	lzcnt  rax,rcx
  40d02c:	mov    ecx,0x3f
  40d031:	sub    rcx,rax
  40d034:	mov    eax,0x1
  40d039:	lea    rcx,[rcx-0x3]
  40d03d:	shl    rax,cl
  40d040:	mov    rcx,rax
  40d043:	cmp    rax,0x1000
  40d04a:	mov    eax,0x1000
  40d04f:	cmovb  rcx,rax
  40d053:	mov    rdx,0xffffffffffffffff
  40d05a:	sub    rdx,rcx
  40d05d:	mov    rax,r14
  40d060:	lea    r8,[r14+rcx*1-0x1]
  40d065:	neg    rcx
  40d068:	and    r8,rcx
  40d06b:	cmp    r14,rdx
  40d06e:	cmovbe rax,r8
  40d072:	mov    QWORD PTR [rsp+0x8],rax
  40d077:	lea    rax,[rip+0x14f82]        # 422000 <__swc_data_base_4fa09e82>
  40d07e:	mov    rax,QWORD PTR [rax]
  40d081:	cmp    rax,0xffffffffffffffff
  40d085:	je     40d094 <__swc_fn_4fa09e82_000061_1badc238+0x214>
  40d087:	mov    eax,eax
  40d089:	mov    edi,eax
  40d08b:	xor    eax,eax
  40d08d:	call   407000 <pthread_getspecific@plt>
  40d092:	jmp    40d096 <__swc_fn_4fa09e82_000061_1badc238+0x216>
  40d094:	xor    eax,eax
  40d096:	test   rax,rax
  40d099:	jne    40d0a8 <__swc_fn_4fa09e82_000061_1badc238+0x228>
  40d09b:	call   40c520 <__swc_fn_4fa09e82_000031_ed8d61a9>
  40d0a0:	mov    rcx,rax
  40d0a3:	call   409ba0 <__swc_fn_4fa09e82_000129_9c45d2d7>
  40d0a8:	test   rax,rax
  40d0ab:	je     40d19c <__swc_fn_4fa09e82_000061_1badc238+0x31c>
  40d0b1:	cmp    QWORD PTR [rax],rbx
  40d0b4:	jne    40d19c <__swc_fn_4fa09e82_000061_1badc238+0x31c>
  40d0ba:	cmp    DWORD PTR [rax+0x20],0x0
  40d0be:	jne    40d19c <__swc_fn_4fa09e82_000061_1badc238+0x31c>
  40d0c4:	mov    rcx,QWORD PTR [rsp+0x8]
  40d0c9:	movabs rdx,0x7fffffffffffffff
  40d0d3:	cmp    rcx,rdx
  40d0d6:	mov    rdx,0xffffffffffffffff
  40d0dd:	lea    r8,[rcx+rcx*1]
  40d0e1:	cmovbe rdx,r8
  40d0e5:	mov    r8d,DWORD PTR [rax+0x730]
  40d0ec:	mov    r9d,r8d
  40d0ef:	sub    rdx,rcx
  40d0f2:	inc    rdx
  40d0f5:	xor    r10d,r10d
  40d0f8:	test   r8,r8
  40d0fb:	jbe    40d12b <__swc_fn_4fa09e82_000061_1badc238+0x2ab>
  40d0fd:	nop    DWORD PTR [rax]
  40d100:	mov    r11d,r10d
  40d103:	lea    r11,[r11+r11*4]
  40d107:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40d10f:	sub    r11,rcx
  40d112:	cmp    r11,rdx
  40d115:	jae    40d122 <__swc_fn_4fa09e82_000061_1badc238+0x2a2>
  40d117:	mov    r9d,r10d
  40d11a:	mov    rdx,r11
  40d11d:	test   r11,r11
  40d120:	je     40d12b <__swc_fn_4fa09e82_000061_1badc238+0x2ab>
  40d122:	add    r10,0x1
  40d126:	cmp    r10,r8
  40d129:	jb     40d100 <__swc_fn_4fa09e82_000061_1badc238+0x280>
  40d12b:	mov    ecx,DWORD PTR [rax+0x730]
  40d131:	cmp    r9d,ecx
  40d134:	jne    40d13a <__swc_fn_4fa09e82_000061_1badc238+0x2ba>
  40d136:	xor    eax,eax
  40d138:	jmp    40d199 <__swc_fn_4fa09e82_000061_1badc238+0x319>
  40d13a:	lea    rcx,[r9+r9*4]
  40d13e:	lea    rcx,[rax+rcx*8+0x738]
  40d146:	vmovups xmm0,XMMWORD PTR [rcx]
  40d14a:	mov    rdx,QWORD PTR [rcx+0x10]
  40d14e:	sub    DWORD PTR [rax+0x730],0x1
  40d155:	mov    r8d,DWORD PTR [rax+0x730]
  40d15c:	lea    r8,[r8+r8*4]
  40d160:	lea    r8,[rax+r8*8+0x738]
  40d168:	vmovups xmm1,XMMWORD PTR [r8]
  40d16d:	vmovups XMMWORD PTR [rcx],xmm1
  40d171:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40d177:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40d17c:	mov    rax,QWORD PTR [r8+0x20]
  40d180:	mov    QWORD PTR [rcx+0x20],rax
  40d184:	vpshufd xmm1,xmm0,0xee
  40d189:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40d18f:	mov    QWORD PTR [rsp+0x10],rdx
  40d194:	vmovq  rax,xmm0
  40d199:	mov    r15,rax
  40d19c:	test   r15,r15
  40d19f:	jne    40d1b7 <__swc_fn_4fa09e82_000061_1badc238+0x337>
  40d1a1:	mov    rcx,rbx
  40d1a4:	mov    rdx,QWORD PTR [rsp+0x8]
  40d1a9:	mov    r8,r13
  40d1ac:	mov    r9,r12
  40d1af:	call   40ca70 <__swc_fn_4fa09e82_000055_da36318f>
  40d1b4:	mov    r15,rax
  40d1b7:	test   r15,r15
  40d1ba:	je     40d1fb <__swc_fn_4fa09e82_000061_1badc238+0x37b>
  40d1bc:	cmp    QWORD PTR [r12],r14
  40d1c0:	jae    40d1fb <__swc_fn_4fa09e82_000061_1badc238+0x37b>
  40d1c2:	mov    rax,r15
  40d1c5:	add    rax,QWORD PTR [r12]
  40d1c9:	mov    rdx,r14
  40d1cc:	sub    rdx,QWORD PTR [r12]
  40d1d0:	mov    rcx,rax
  40d1d3:	call   4072a0 <__swc_fn_4fa09e82_000003_644dadb7>
  40d1d8:	test   al,al
  40d1da:	je     40d1e3 <__swc_fn_4fa09e82_000061_1badc238+0x363>
  40d1dc:	mov    QWORD PTR [rsp+0x10],r14
  40d1e1:	jmp    40d1fb <__swc_fn_4fa09e82_000061_1badc238+0x37b>
  40d1e3:	mov    rcx,rbx
  40d1e6:	mov    rdx,r15
  40d1e9:	mov    r8,QWORD PTR [rsp+0x8]
  40d1ee:	mov    r9,QWORD PTR [rsp+0x10]
  40d1f3:	call   40cb80 <__swc_fn_4fa09e82_000058_033ce1da>
  40d1f8:	xor    r15d,r15d
  40d1fb:	test   r15,r15
  40d1fe:	jne    40d27a <__swc_fn_4fa09e82_000061_1badc238+0x3fa>
  40d200:	cmp    r14,0x10000
  40d207:	ja     40d20e <__swc_fn_4fa09e82_000061_1badc238+0x38e>
  40d209:	mov    rax,r14
  40d20c:	jmp    40d25f <__swc_fn_4fa09e82_000061_1badc238+0x3df>
  40d20e:	xor    eax,eax
  40d210:	lea    rcx,[r14-0x1]
  40d214:	lzcnt  rax,rcx
  40d219:	mov    ecx,0x3f
  40d21e:	sub    rcx,rax
  40d221:	mov    eax,0x1
  40d226:	lea    rcx,[rcx-0x3]
  40d22a:	shl    rax,cl
  40d22d:	mov    rcx,rax
  40d230:	cmp    rax,0x1000
  40d237:	mov    eax,0x1000
  40d23c:	cmovb  rcx,rax
  40d240:	mov    rdx,0xffffffffffffffff
  40d247:	sub    rdx,rcx
  40d24a:	mov    rax,r14
  40d24d:	lea    r8,[r14+rcx*1-0x1]
  40d252:	neg    rcx
  40d255:	and    r8,rcx
  40d258:	cmp    r14,rdx
  40d25b:	cmovbe rax,r8
  40d25f:	mov    QWORD PTR [rsp+0x8],rax
  40d264:	mov    QWORD PTR [rsp+0x10],r14
  40d269:	mov    rcx,rbx
  40d26c:	mov    rdx,rax
  40d26f:	mov    r8,r14
  40d272:	call   40c5e0 <__swc_fn_4fa09e82_000037_92e867c2>
  40d277:	mov    r15,rax
  40d27a:	test   r15,r15
  40d27d:	jne    40d28b <__swc_fn_4fa09e82_000061_1badc238+0x40b>
  40d27f:	mov    r13,QWORD PTR [rsp+0x20]
  40d284:	mov    rsi,QWORD PTR [rsp+0x38]
  40d289:	jmp    40d2c7 <__swc_fn_4fa09e82_000061_1badc238+0x447>
  40d28b:	mov    rax,r15
  40d28e:	add    rax,QWORD PTR [rsp+0x28]
  40d293:	mov    r13,QWORD PTR [rsp+0x20]
  40d298:	test   r13d,r13d
  40d29b:	mov    rcx,r13
  40d29e:	mov    edx,0x8
  40d2a3:	cmove  ecx,edx
  40d2a6:	dec    rcx
  40d2a9:	mov    rdx,0xffffffffffffffff
  40d2b0:	sub    rdx,rcx
  40d2b3:	cmp    rax,rdx
  40d2b6:	jbe    40d2bc <__swc_fn_4fa09e82_000061_1badc238+0x43c>
  40d2b8:	xor    eax,eax
  40d2ba:	jmp    40d2c4 <__swc_fn_4fa09e82_000061_1badc238+0x444>
  40d2bc:	add    rax,rcx
  40d2bf:	andn   rax,rcx,rax
  40d2c4:	mov    rsi,rax
  40d2c7:	mov    rax,QWORD PTR [rsp+0x8]
  40d2cc:	test   r15,r15
  40d2cf:	je     40d2d8 <__swc_fn_4fa09e82_000061_1badc238+0x458>
  40d2d1:	mov    rdi,QWORD PTR [rsp+0x18]
  40d2d6:	jmp    40d2ea <__swc_fn_4fa09e82_000061_1badc238+0x46a>
  40d2d8:	mov    rdi,QWORD PTR [rsp+0x18]
  40d2dd:	mov    QWORD PTR [rdi+0x40],0x0
  40d2e5:	jmp    40d366 <__swc_fn_4fa09e82_000061_1badc238+0x4e6>
  40d2ea:	lea    rdx,[rsi-0x58]
  40d2ee:	mov    QWORD PTR [rsi-0x58],r15
  40d2f2:	mov    QWORD PTR [rsi-0x50],rax
  40d2f6:	mov    rax,QWORD PTR [rsp+0x10]
  40d2fb:	mov    QWORD PTR [rsi-0x48],rax
  40d2ff:	mov    QWORD PTR [rsi-0x40],rsi
  40d303:	mov    rax,QWORD PTR [rdi+0x48]
  40d307:	mov    QWORD PTR [rsi-0x38],rax
  40d30b:	mov    rax,QWORD PTR [rsp+0x30]
  40d310:	mov    QWORD PTR [rsi-0x30],rax
  40d314:	mov    DWORD PTR [rsi-0x10],r13d
  40d318:	mov    QWORD PTR [rsi-0x28],0x0
  40d320:	mov    QWORD PTR [rsi-0x20],0x0
  40d328:	add    r15,QWORD PTR [r12]
  40d32c:	sub    r15,rsi
  40d32f:	mov    QWORD PTR [rsi-0x30],r15
  40d333:	mov    rcx,QWORD PTR [rbx+0x250]
  40d33a:	nop    WORD PTR [rax+rax*1+0x0]
  40d340:	lea    r8,[rcx+r15*1]
  40d344:	mov    rax,rcx
  40d347:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40d350:	cmp    rax,rcx
  40d353:	je     40d35a <__swc_fn_4fa09e82_000061_1badc238+0x4da>
  40d355:	mov    rcx,rax
  40d358:	jmp    40d340 <__swc_fn_4fa09e82_000061_1badc238+0x4c0>
  40d35a:	mov    rcx,rbx
  40d35d:	call   40fbf0 <__swc_fn_4fa09e82_000053_a8a124d6>
  40d362:	mov    QWORD PTR [rdi+0x40],rsi
  40d366:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40d36c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40d372:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40d378:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40d37e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40d387:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40d390:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40d399:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40d3a2:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40d3ab:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40d3b4:	add    rsp,0xf0
  40d3bb:	pop    rsi
  40d3bc:	pop    rdi
  40d3bd:	pop    r15
  40d3bf:	pop    r14
  40d3c1:	pop    r13
  40d3c3:	pop    r12
  40d3c5:	pop    rbx
  40d3c6:	ret
	...

000000000040d3d0 <__swc_fn_4fa09e82_000064_6905bec4>:
  40d3d0:	push   rbx
  40d3d1:	push   r12
  40d3d3:	push   rdi
  40d3d4:	push   rsi
  40d3d5:	sub    rsp,0xb8
  40d3dc:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d3e2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d3e8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d3ee:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d3f4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d3fa:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d400:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d406:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d40f:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d418:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d421:	mov    rbx,rdx
  40d424:	mov    r12,rcx
  40d427:	cmp    DWORD PTR [rbx+0x58],0x0
  40d42b:	je     40d445 <__swc_fn_4fa09e82_000064_6905bec4+0x75>
  40d42d:	mov    eax,DWORD PTR [rbx+0x58]
  40d430:	sub    eax,0x1
  40d433:	test   DWORD PTR [rbx+0x58],eax
  40d436:	je     40d445 <__swc_fn_4fa09e82_000064_6905bec4+0x75>
  40d438:	mov    QWORD PTR [rbx+0x40],0x0
  40d440:	jmp    40d657 <__swc_fn_4fa09e82_000064_6905bec4+0x287>
  40d445:	cmp    QWORD PTR [rbx+0x48],0x0
  40d44a:	jne    40d459 <__swc_fn_4fa09e82_000064_6905bec4+0x89>
  40d44c:	mov    QWORD PTR [rbx+0x40],0x0
  40d454:	jmp    40d657 <__swc_fn_4fa09e82_000064_6905bec4+0x287>
  40d459:	lea    rax,[rsp+0x8]
  40d45e:	mov    rcx,QWORD PTR [rbx+0x48]
  40d462:	cmp    rcx,0x8
  40d466:	ja     40d470 <__swc_fn_4fa09e82_000064_6905bec4+0xa0>
  40d468:	mov    DWORD PTR [rax],0x0
  40d46e:	jmp    40d4cb <__swc_fn_4fa09e82_000064_6905bec4+0xfb>
  40d470:	cmp    rcx,0x80
  40d477:	ja     40d487 <__swc_fn_4fa09e82_000064_6905bec4+0xb7>
  40d479:	lea    rcx,[rcx+0xf]
  40d47d:	shr    rcx,0x4
  40d481:	mov    DWORD PTR [rsp+0x8],ecx
  40d485:	jmp    40d4cb <__swc_fn_4fa09e82_000064_6905bec4+0xfb>
  40d487:	cmp    rcx,0x10000
  40d48e:	jbe    40d498 <__swc_fn_4fa09e82_000064_6905bec4+0xc8>
  40d490:	mov    DWORD PTR [rax],0xffffffff
  40d496:	jmp    40d4cb <__swc_fn_4fa09e82_000064_6905bec4+0xfb>
  40d498:	dec    rcx
  40d49b:	xor    edx,edx
  40d49d:	lzcnt  rdx,rcx
  40d4a2:	mov    r8d,0x3f
  40d4a8:	sub    r8d,edx
  40d4ab:	lea    edx,[r8-0x2]
  40d4af:	shrx   rcx,rcx,rdx
  40d4b4:	and    ecx,0x3
  40d4b7:	lea    edx,[r8-0x7]
  40d4bb:	lea    edx,[rdx*4+0x0]
  40d4c2:	lea    edx,[rdx+0x9]
  40d4c5:	add    edx,ecx
  40d4c7:	mov    DWORD PTR [rsp+0x8],edx
  40d4cb:	cmp    DWORD PTR [rax],0x0
  40d4ce:	jne    40d4de <__swc_fn_4fa09e82_000064_6905bec4+0x10e>
  40d4d0:	cmp    DWORD PTR [rbx+0x58],0x8
  40d4d4:	jbe    40d4de <__swc_fn_4fa09e82_000064_6905bec4+0x10e>
  40d4d6:	mov    DWORD PTR [rsp+0x8],0x1
  40d4de:	cmp    DWORD PTR [rbx+0x58],0x10
  40d4e2:	jbe    40d561 <__swc_fn_4fa09e82_000064_6905bec4+0x191>
  40d4e8:	cmp    DWORD PTR [rbx+0x58],0x40
  40d4ec:	ja     40d561 <__swc_fn_4fa09e82_000064_6905bec4+0x191>
  40d4ee:	cmp    DWORD PTR [rax],0xffffffff
  40d4f1:	je     40d561 <__swc_fn_4fa09e82_000064_6905bec4+0x191>
  40d4f3:	mov    ecx,DWORD PTR [rsp+0x8]
  40d4f7:	mov    edx,DWORD PTR [rbx+0x58]
  40d4fa:	dec    rdx
  40d4fd:	cmp    ecx,0x2d
  40d500:	jae    40d558 <__swc_fn_4fa09e82_000064_6905bec4+0x188>
  40d502:	cs nop WORD PTR [rax+rax*1+0x0]
  40d50c:	nop    DWORD PTR [rax+0x0]
  40d510:	mov    r8d,ecx
  40d513:	test   ecx,ecx
  40d515:	jne    40d51f <__swc_fn_4fa09e82_000064_6905bec4+0x14f>
  40d517:	mov    r8d,0x8
  40d51d:	jmp    40d54b <__swc_fn_4fa09e82_000064_6905bec4+0x17b>
  40d51f:	cmp    r8d,0x8
  40d523:	ja     40d52b <__swc_fn_4fa09e82_000064_6905bec4+0x15b>
  40d525:	shl    r8,0x4
  40d529:	jmp    40d54b <__swc_fn_4fa09e82_000064_6905bec4+0x17b>
  40d52b:	lea    r8d,[r8-0x9]
  40d52f:	mov    r9d,r8d
  40d532:	shr    r9d,0x2
  40d536:	and    r8d,0x3
  40d53a:	lea    r9d,[r9+0x7]
  40d53e:	lea    r9d,[r9-0x2]
  40d542:	lea    r8d,[r8+0x5]
  40d546:	shlx   r8,r8,r9
  40d54b:	test   r8,rdx
  40d54e:	je     40d55d <__swc_fn_4fa09e82_000064_6905bec4+0x18d>
  40d550:	add    ecx,0x1
  40d553:	cmp    ecx,0x2d
  40d556:	jb     40d510 <__swc_fn_4fa09e82_000064_6905bec4+0x140>
  40d558:	mov    ecx,0xffffffff
  40d55d:	mov    DWORD PTR [rsp+0x8],ecx
  40d561:	mov    ecx,DWORD PTR [rsp+0x8]
  40d565:	cmp    ecx,0xffffffff
  40d568:	je     40d570 <__swc_fn_4fa09e82_000064_6905bec4+0x1a0>
  40d56a:	cmp    DWORD PTR [rbx+0x58],0x40
  40d56e:	jbe    40d583 <__swc_fn_4fa09e82_000064_6905bec4+0x1b3>
  40d570:	mov    rcx,r12
  40d573:	mov    rdx,rbx
  40d576:	mov    r8d,DWORD PTR [rax]
  40d579:	call   40ce80 <__swc_fn_4fa09e82_000061_1badc238>
  40d57e:	jmp    40d657 <__swc_fn_4fa09e82_000064_6905bec4+0x287>
  40d583:	lea    rax,[rip+0x14a76]        # 422000 <__swc_data_base_4fa09e82>
  40d58a:	mov    rax,QWORD PTR [rax]
  40d58d:	cmp    rax,0xffffffffffffffff
  40d591:	je     40d5a0 <__swc_fn_4fa09e82_000064_6905bec4+0x1d0>
  40d593:	mov    eax,eax
  40d595:	mov    edi,eax
  40d597:	xor    eax,eax
  40d599:	call   407000 <pthread_getspecific@plt>
  40d59e:	jmp    40d5a2 <__swc_fn_4fa09e82_000064_6905bec4+0x1d2>
  40d5a0:	xor    eax,eax
  40d5a2:	test   rax,rax
  40d5a5:	jne    40d5b4 <__swc_fn_4fa09e82_000064_6905bec4+0x1e4>
  40d5a7:	call   40c520 <__swc_fn_4fa09e82_000031_ed8d61a9>
  40d5ac:	mov    rcx,rax
  40d5af:	call   409ba0 <__swc_fn_4fa09e82_000129_9c45d2d7>
  40d5b4:	test   rax,rax
  40d5b7:	je     40d5c4 <__swc_fn_4fa09e82_000064_6905bec4+0x1f4>
  40d5b9:	cmp    QWORD PTR [rax],r12
  40d5bc:	jne    40d5c4 <__swc_fn_4fa09e82_000064_6905bec4+0x1f4>
  40d5be:	cmp    DWORD PTR [rax+0x20],0x0
  40d5c2:	je     40d5cf <__swc_fn_4fa09e82_000064_6905bec4+0x1ff>
  40d5c4:	mov    rcx,r12
  40d5c7:	mov    rdx,rax
  40d5ca:	call   40f830 <__swc_fn_4fa09e82_000041_ed1cda78>
  40d5cf:	test   rax,rax
  40d5d2:	jne    40d5de <__swc_fn_4fa09e82_000064_6905bec4+0x20e>
  40d5d4:	mov    QWORD PTR [rbx+0x40],0x0
  40d5dc:	jmp    40d657 <__swc_fn_4fa09e82_000064_6905bec4+0x287>
  40d5de:	lea    r8,[rsp+0xc]
  40d5e3:	mov    ecx,DWORD PTR [rsp+0x8]
  40d5e7:	mov    DWORD PTR [rsp+0xc],ecx
  40d5eb:	mov    ecx,DWORD PTR [r8]
  40d5ee:	lea    rcx,[rcx+rcx*4]
  40d5f2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40d5f7:	test   rcx,rcx
  40d5fa:	je     40d633 <__swc_fn_4fa09e82_000064_6905bec4+0x263>
  40d5fc:	mov    rdx,QWORD PTR [rcx]
  40d5ff:	test   rdx,rdx
  40d602:	je     40d610 <__swc_fn_4fa09e82_000064_6905bec4+0x240>
  40d604:	mov    r9,QWORD PTR [rdx]
  40d607:	mov    QWORD PTR [rcx],r9
  40d60a:	add    DWORD PTR [rcx+0x28],0x1
  40d60e:	jmp    40d62e <__swc_fn_4fa09e82_000064_6905bec4+0x25e>
  40d610:	mov    rdx,QWORD PTR [rcx+0x18]
  40d614:	cmp    QWORD PTR [rcx+0x20],rdx
  40d618:	jae    40d62c <__swc_fn_4fa09e82_000064_6905bec4+0x25c>
  40d61a:	mov    rdx,QWORD PTR [rcx+0x20]
  40d61e:	mov    r9d,DWORD PTR [rcx+0x2c]
  40d622:	add    QWORD PTR [rcx+0x20],r9
  40d626:	add    DWORD PTR [rcx+0x28],0x1
  40d62a:	jmp    40d62e <__swc_fn_4fa09e82_000064_6905bec4+0x25e>
  40d62c:	xor    edx,edx
  40d62e:	test   rdx,rdx
  40d631:	jne    40d644 <__swc_fn_4fa09e82_000064_6905bec4+0x274>
  40d633:	mov    rcx,r12
  40d636:	mov    rdx,rax
  40d639:	mov    r8d,DWORD PTR [r8]
  40d63c:	call   40f9a0 <__swc_fn_4fa09e82_000050_e33921d7>
  40d641:	mov    rdx,rax
  40d644:	test   rdx,rdx
  40d647:	jne    40d653 <__swc_fn_4fa09e82_000064_6905bec4+0x283>
  40d649:	mov    QWORD PTR [rbx+0x40],0x0
  40d651:	jmp    40d657 <__swc_fn_4fa09e82_000064_6905bec4+0x287>
  40d653:	mov    QWORD PTR [rbx+0x40],rdx
  40d657:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d65d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d663:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d669:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d66f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d675:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d67b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d681:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d68a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d693:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d69c:	add    rsp,0xb8
  40d6a3:	pop    rsi
  40d6a4:	pop    rdi
  40d6a5:	pop    r12
  40d6a7:	pop    rbx
  40d6a8:	ret
  40d6a9:	add    BYTE PTR [rax],al
  40d6ab:	add    BYTE PTR [rax],al
  40d6ad:	add    BYTE PTR [rax],al
	...

000000000040d6b0 <__swc_fn_4fa09e82_000067_381f5b88>:
  40d6b0:	ret
	...

000000000040d6c0 <__swc_fn_4fa09e82_000070_2cd83140>:
  40d6c0:	push   r12
  40d6c2:	push   r13
  40d6c4:	push   r14
  40d6c6:	push   rdi
  40d6c7:	push   rsi
  40d6c8:	sub    rsp,0x1a0
  40d6cf:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40d6d8:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40d6e1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40d6ea:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40d6f3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40d6fc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40d705:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40d70e:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40d717:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40d720:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40d729:	mov    r12,rdx
  40d72c:	mov    r13,rcx
  40d72f:	mov    rax,QWORD PTR [r12+0x48]
  40d734:	mov    ecx,DWORD PTR [r12+0x58]
  40d739:	lea    rdx,[rax-0x1]
  40d73d:	cmp    rdx,0x10000
  40d744:	jae    40d83e <__swc_fn_4fa09e82_000070_2cd83140+0x17e>
  40d74a:	cmp    rax,0x8
  40d74e:	ja     40d755 <__swc_fn_4fa09e82_000070_2cd83140+0x95>
  40d750:	xor    r14d,r14d
  40d753:	jmp    40d7a7 <__swc_fn_4fa09e82_000070_2cd83140+0xe7>
  40d755:	cmp    rax,0x80
  40d75c:	ja     40d768 <__swc_fn_4fa09e82_000070_2cd83140+0xa8>
  40d75e:	lea    r14,[rax+0xf]
  40d762:	shr    r14,0x4
  40d766:	jmp    40d7a7 <__swc_fn_4fa09e82_000070_2cd83140+0xe7>
  40d768:	cmp    rax,0x10000
  40d76f:	jbe    40d779 <__swc_fn_4fa09e82_000070_2cd83140+0xb9>
  40d771:	mov    r14d,0xffffffff
  40d777:	jmp    40d7a7 <__swc_fn_4fa09e82_000070_2cd83140+0xe7>
  40d779:	xor    eax,eax
  40d77b:	lzcnt  rax,rdx
  40d780:	mov    r8d,0x3f
  40d786:	sub    r8d,eax
  40d789:	lea    eax,[r8-0x2]
  40d78d:	shrx   rax,rdx,rax
  40d792:	and    eax,0x3
  40d795:	lea    edx,[r8-0x7]
  40d799:	lea    edx,[rdx*4+0x0]
  40d7a0:	lea    edx,[rdx+0x9]
  40d7a3:	lea    r14d,[rdx+rax*1]
  40d7a7:	cmp    ecx,0x8
  40d7aa:	jbe    40d7c3 <__swc_fn_4fa09e82_000070_2cd83140+0x103>
  40d7ac:	cmp    ecx,0x10
  40d7af:	jne    40d83e <__swc_fn_4fa09e82_000070_2cd83140+0x17e>
  40d7b5:	test   r14d,r14d
  40d7b8:	mov    eax,0x1
  40d7bd:	cmove  r14d,eax
  40d7c1:	jmp    40d7ca <__swc_fn_4fa09e82_000070_2cd83140+0x10a>
  40d7c3:	lea    eax,[rcx-0x1]
  40d7c6:	test   eax,ecx
  40d7c8:	jne    40d83e <__swc_fn_4fa09e82_000070_2cd83140+0x17e>
  40d7ca:	lea    rax,[rip+0x1482f]        # 422000 <__swc_data_base_4fa09e82>
  40d7d1:	mov    rax,QWORD PTR [rax]
  40d7d4:	cmp    rax,0xffffffffffffffff
  40d7d8:	je     40d7e7 <__swc_fn_4fa09e82_000070_2cd83140+0x127>
  40d7da:	mov    eax,eax
  40d7dc:	mov    edi,eax
  40d7de:	xor    eax,eax
  40d7e0:	call   407000 <pthread_getspecific@plt>
  40d7e5:	jmp    40d7e9 <__swc_fn_4fa09e82_000070_2cd83140+0x129>
  40d7e7:	xor    eax,eax
  40d7e9:	test   rax,rax
  40d7ec:	je     40d83e <__swc_fn_4fa09e82_000070_2cd83140+0x17e>
  40d7ee:	cmp    QWORD PTR [rax],r13
  40d7f1:	jne    40d83e <__swc_fn_4fa09e82_000070_2cd83140+0x17e>
  40d7f3:	lea    rcx,[r14+r14*4]
  40d7f7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40d7fc:	test   rax,rax
  40d7ff:	je     40d83e <__swc_fn_4fa09e82_000070_2cd83140+0x17e>
  40d801:	mov    rcx,QWORD PTR [rax]
  40d804:	test   rcx,rcx
  40d807:	je     40d815 <__swc_fn_4fa09e82_000070_2cd83140+0x155>
  40d809:	mov    rdx,QWORD PTR [rcx]
  40d80c:	mov    QWORD PTR [rax],rdx
  40d80f:	add    DWORD PTR [rax+0x28],0x1
  40d813:	jmp    40d832 <__swc_fn_4fa09e82_000070_2cd83140+0x172>
  40d815:	mov    rcx,QWORD PTR [rax+0x18]
  40d819:	cmp    QWORD PTR [rax+0x20],rcx
  40d81d:	jae    40d830 <__swc_fn_4fa09e82_000070_2cd83140+0x170>
  40d81f:	mov    rcx,QWORD PTR [rax+0x20]
  40d823:	mov    edx,DWORD PTR [rax+0x2c]
  40d826:	add    QWORD PTR [rax+0x20],rdx
  40d82a:	add    DWORD PTR [rax+0x28],0x1
  40d82e:	jmp    40d832 <__swc_fn_4fa09e82_000070_2cd83140+0x172>
  40d830:	xor    ecx,ecx
  40d832:	test   rcx,rcx
  40d835:	je     40d83e <__swc_fn_4fa09e82_000070_2cd83140+0x17e>
  40d837:	mov    QWORD PTR [r12+0x40],rcx
  40d83c:	jmp    40d849 <__swc_fn_4fa09e82_000070_2cd83140+0x189>
  40d83e:	mov    rcx,r13
  40d841:	mov    rdx,r12
  40d844:	call   410420 <__swc_fn_4fa09e82_000071_7e144e9b>
  40d849:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40d852:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40d85b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40d864:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40d86d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40d876:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40d87f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40d888:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40d891:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40d89a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40d8a3:	add    rsp,0x1a0
  40d8aa:	pop    rsi
  40d8ab:	pop    rdi
  40d8ac:	pop    r14
  40d8ae:	pop    r13
  40d8b0:	pop    r12
  40d8b2:	ret
	...

000000000040d8c0 <__swc_fn_4fa09e82_000073_c77adf75>:
  40d8c0:	push   r12
  40d8c2:	push   r13
  40d8c4:	push   r14
  40d8c6:	push   r15
  40d8c8:	push   rdi
  40d8c9:	push   rsi
  40d8ca:	sub    rsp,0x188
  40d8d1:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40d8da:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40d8e3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40d8ec:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40d8f5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40d8fe:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40d907:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40d910:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40d919:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40d922:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40d92b:	mov    r12,rdx
  40d92e:	mov    r13,rcx
  40d931:	mov    r14,QWORD PTR [r12+0x40]
  40d936:	lea    rax,[rip+0x16733]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40d93d:	mov    rcx,r14
  40d940:	sub    rcx,QWORD PTR [rax+0x8]
  40d944:	mov    rax,QWORD PTR [rip+0x16735]        # 424080 <__swc_bss_base_4fa09e82+0x40>
  40d94b:	cmp    rcx,rax
  40d94e:	jae    40d97a <__swc_fn_4fa09e82_000073_c77adf75+0xba>
  40d950:	mov    rax,r14
  40d953:	and    rax,0xffffffffffc00000
  40d95a:	mov    rcx,r14
  40d95d:	shr    rcx,0x10
  40d961:	and    ecx,0x3f
  40d964:	mov    edx,DWORD PTR [rax+0x28]
  40d967:	shrx   ecx,ecx,edx
  40d96c:	shl    rcx,0x4
  40d970:	lea    r15,[rax+rcx*8+0x80]
  40d978:	jmp    40d985 <__swc_fn_4fa09e82_000073_c77adf75+0xc5>
  40d97a:	mov    rcx,r14
  40d97d:	call   40c450 <__swc_fn_4fa09e82_000022_77c2d682>
  40d982:	mov    r15,rax
  40d985:	test   r15,r15
  40d988:	je     40da2f <__swc_fn_4fa09e82_000073_c77adf75+0x16f>
  40d98e:	lea    rax,[rip+0x1466b]        # 422000 <__swc_data_base_4fa09e82>
  40d995:	mov    rax,QWORD PTR [rax]
  40d998:	cmp    rax,0xffffffffffffffff
  40d99c:	je     40d9ab <__swc_fn_4fa09e82_000073_c77adf75+0xeb>
  40d99e:	mov    eax,eax
  40d9a0:	mov    edi,eax
  40d9a2:	xor    eax,eax
  40d9a4:	call   407000 <pthread_getspecific@plt>
  40d9a9:	jmp    40d9ad <__swc_fn_4fa09e82_000073_c77adf75+0xed>
  40d9ab:	xor    eax,eax
  40d9ad:	mov    rcx,QWORD PTR [r15+0x40]
  40d9b1:	cmp    rcx,rax
  40d9b4:	jne    40da14 <__swc_fn_4fa09e82_000073_c77adf75+0x154>
  40d9b6:	test   rax,rax
  40d9b9:	je     40da2f <__swc_fn_4fa09e82_000073_c77adf75+0x16f>
  40d9bb:	mov    ecx,DWORD PTR [r15+0x6c]
  40d9bf:	test   ecx,ecx
  40d9c1:	je     40d9e1 <__swc_fn_4fa09e82_000073_c77adf75+0x121>
  40d9c3:	mov    rcx,r13
  40d9c6:	mov    rdx,rax
  40d9c9:	mov    r8,r15
  40d9cc:	mov    QWORD PTR [rsp+0xd8],rax
  40d9d4:	call   40f930 <__swc_fn_4fa09e82_000047_3d3eceb4>
  40d9d9:	mov    rax,QWORD PTR [rsp+0xd8]
  40d9e1:	mov    rcx,QWORD PTR [r15]
  40d9e4:	mov    QWORD PTR [r14],rcx
  40d9e7:	mov    QWORD PTR [r15],r14
  40d9ea:	sub    DWORD PTR [r15+0x28],0x1
  40d9ef:	jne    40da24 <__swc_fn_4fa09e82_000073_c77adf75+0x164>
  40d9f1:	movzx  ecx,BYTE PTR [r15+0x39]
  40d9f6:	lea    rcx,[rcx+rcx*4]
  40d9fa:	lea    rcx,[rax+rcx*8+0x28]
  40d9ff:	cmp    QWORD PTR [rcx],r15
  40da02:	je     40da24 <__swc_fn_4fa09e82_000073_c77adf75+0x164>
  40da04:	mov    rcx,r13
  40da07:	mov    rdx,rax
  40da0a:	mov    r8,r15
  40da0d:	call   407d80 <__swc_fn_4fa09e82_000051_5b91e689>
  40da12:	jmp    40da24 <__swc_fn_4fa09e82_000073_c77adf75+0x164>
  40da14:	test   rcx,rcx
  40da17:	je     40da2f <__swc_fn_4fa09e82_000073_c77adf75+0x16f>
  40da19:	mov    rcx,r15
  40da1c:	mov    rdx,r14
  40da1f:	call   40c090 <__swc_fn_4fa09e82_000010_186cd0c2>
  40da24:	mov    QWORD PTR [r12+0x40],0x0
  40da2d:	jmp    40da3a <__swc_fn_4fa09e82_000073_c77adf75+0x17a>
  40da2f:	mov    rcx,r13
  40da32:	mov    rdx,r12
  40da35:	call   410440 <__swc_fn_4fa09e82_000074_9eaf4878>
  40da3a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40da43:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40da4c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40da55:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40da5e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40da67:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40da70:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40da79:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40da82:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40da8b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40da94:	add    rsp,0x188
  40da9b:	pop    rsi
  40da9c:	pop    rdi
  40da9d:	pop    r15
  40da9f:	pop    r14
  40daa1:	pop    r13
  40daa3:	pop    r12
  40daa5:	ret
	...

000000000040dab0 <__swc_fn_4fa09e82_000076_d8e626b0>:
  40dab0:	sub    rsp,0x8
  40dab4:	mov    rax,rdx
  40dab7:	mov    rdx,QWORD PTR [rax+0x40]
  40dabb:	mov    r8,rax
  40dabe:	call   40d6b0 <__swc_fn_4fa09e82_000067_381f5b88>
  40dac3:	add    rsp,0x8
  40dac7:	ret
	...

000000000040dad0 <__swc_fn_4fa09e82_000079_29fad089>:
  40dad0:	push   rsi
  40dad1:	push   rdi
  40dad2:	sub    rsp,0x8
  40dad6:	cmp    rcx,0xffffffffffffffef
  40dada:	ja     40db00 <__swc_fn_4fa09e82_000079_29fad089+0x30>
  40dadc:	xor    esi,esi
  40dade:	lea    rax,[rcx+0x100f]
  40dae5:	and    rax,0xfffffffffffff000
  40daec:	lea    rcx,[rcx+0x10]
  40daf0:	cmp    rcx,0xfffffffffffff000
  40daf7:	cmovbe rsi,rax
  40dafb:	test   rsi,rsi
  40dafe:	jne    40db09 <__swc_fn_4fa09e82_000079_29fad089+0x39>
  40db00:	xor    eax,eax
  40db02:	add    rsp,0x8
  40db06:	pop    rdi
  40db07:	pop    rsi
  40db08:	ret
  40db09:	mov    rcx,rsi
  40db0c:	call   411070 <__swc_fn_4fa09e82_000110_aa570b2b>
  40db11:	mov    rdi,rax
  40db14:	test   rax,rax
  40db17:	jne    40db22 <__swc_fn_4fa09e82_000079_29fad089+0x52>
  40db19:	xor    eax,eax
  40db1b:	add    rsp,0x8
  40db1f:	pop    rdi
  40db20:	pop    rsi
  40db21:	ret
  40db22:	mov    rcx,rdi
  40db25:	mov    rdx,rsi
  40db28:	call   40e100 <__swc_fn_4fa09e82_000112_e724f834>
  40db2d:	test   al,al
  40db2f:	jne    40db45 <__swc_fn_4fa09e82_000079_29fad089+0x75>
  40db31:	mov    rcx,rdi
  40db34:	mov    rdx,rsi
  40db37:	call   409850 <__swc_fn_4fa09e82_000114_25e345b1>
  40db3c:	xor    eax,eax
  40db3e:	add    rsp,0x8
  40db42:	pop    rdi
  40db43:	pop    rsi
  40db44:	ret
  40db45:	mov    QWORD PTR [rdi],rsi
  40db48:	mov    QWORD PTR [rdi+0x8],0x0
  40db50:	lea    rax,[rdi+0x10]
  40db54:	add    rsp,0x8
  40db58:	pop    rdi
  40db59:	pop    rsi
  40db5a:	ret
  40db5b:	add    BYTE PTR [rax],al
  40db5d:	add    BYTE PTR [rax],al
	...

000000000040db60 <__swc_fn_4fa09e82_000082_9f4f5092>:
  40db60:	sub    rsp,0x8
  40db64:	cmp    BYTE PTR [rcx+0x2c],0x10
  40db68:	jne    40db73 <__swc_fn_4fa09e82_000082_9f4f5092+0x13>
  40db6a:	test   DWORD PTR [rcx+0x28],0x80
  40db71:	je     40db7b <__swc_fn_4fa09e82_000082_9f4f5092+0x1b>
  40db73:	mov    rax,rcx
  40db76:	add    rsp,0x8
  40db7a:	ret
  40db7b:	mov    rcx,QWORD PTR [rcx+0x40]
  40db7f:	call   40db60 <__swc_fn_4fa09e82_000082_9f4f5092>
  40db84:	add    rsp,0x8
  40db88:	ret
	...

000000000040dba0 <__swc_fn_4fa09e82_000085_88128f21>:
  40dba0:	push   rsi
  40dba1:	push   rdi
  40dba2:	push   r12
  40dba4:	push   r13
  40dba6:	sub    rsp,0x8
  40dbaa:	mov    rsi,rdx
  40dbad:	mov    rdi,rcx
  40dbb0:	xor    r8d,r8d
  40dbb3:	call   4085a0 <__swc_fn_4fa09e82_000090_9a1d717d>
  40dbb8:	test   al,al
  40dbba:	je     40dbcc <__swc_fn_4fa09e82_000085_88128f21+0x2c>
  40dbbc:	mov    eax,0x1
  40dbc1:	add    rsp,0x8
  40dbc5:	pop    r13
  40dbc7:	pop    r12
  40dbc9:	pop    rdi
  40dbca:	pop    rsi
  40dbcb:	ret
  40dbcc:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40dbd1:	je     40dbe0 <__swc_fn_4fa09e82_000085_88128f21+0x40>
  40dbd3:	xor    eax,eax
  40dbd5:	add    rsp,0x8
  40dbd9:	pop    r13
  40dbdb:	pop    r12
  40dbdd:	pop    rdi
  40dbde:	pop    rsi
  40dbdf:	ret
  40dbe0:	mov    r12,QWORD PTR [rsi+0x98]
  40dbe7:	mov    rax,QWORD PTR [rsi+0xa0]
  40dbee:	mov    rsi,rax
  40dbf1:	xor    r13d,r13d
  40dbf4:	test   rsi,rsi
  40dbf7:	je     40dc54 <__swc_fn_4fa09e82_000085_88128f21+0xb4>
  40dbf9:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc03:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc0d:	nop    DWORD PTR [rax]
  40dc10:	lea    rax,[r13*8+0x0]
  40dc18:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40dc1d:	mov    rcx,rax
  40dc20:	call   40db60 <__swc_fn_4fa09e82_000082_9f4f5092>
  40dc25:	cmp    BYTE PTR [rax+0x2c],0xe
  40dc29:	jne    40dc4a <__swc_fn_4fa09e82_000085_88128f21+0xaa>
  40dc2b:	mov    rcx,rdi
  40dc2e:	mov    rdx,rax
  40dc31:	call   40dba0 <__swc_fn_4fa09e82_000085_88128f21>
  40dc36:	test   al,al
  40dc38:	je     40dc4a <__swc_fn_4fa09e82_000085_88128f21+0xaa>
  40dc3a:	mov    eax,0x1
  40dc3f:	add    rsp,0x8
  40dc43:	pop    r13
  40dc45:	pop    r12
  40dc47:	pop    rdi
  40dc48:	pop    rsi
  40dc49:	ret
  40dc4a:	add    r13,0x1
  40dc4e:	sub    rsi,0x1
  40dc52:	jne    40dc10 <__swc_fn_4fa09e82_000085_88128f21+0x70>
  40dc54:	xor    eax,eax
  40dc56:	add    rsp,0x8
  40dc5a:	pop    r13
  40dc5c:	pop    r12
  40dc5e:	pop    rdi
  40dc5f:	pop    rsi
  40dc60:	ret
	...

000000000040dc70 <__swc_fn_4fa09e82_000088_17711411>:
  40dc70:	sub    rsp,0x18
  40dc74:	vxorps xmm0,xmm0,xmm0
  40dc78:	vmovdqu XMMWORD PTR [rsp],xmm0
  40dc7d:	call   410650 <__swc_fn_4fa09e82_000089_157b05de>
  40dc82:	add    rsp,0x18
  40dc86:	ret
	...

000000000040dc90 <__swc_fn_4fa09e82_000091_e6773530>:
  40dc90:	sub    rsp,0x8
  40dc94:	mov    rcx,QWORD PTR [rip+0x190a5]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dc9b:	test   rcx,rcx
  40dc9e:	jne    40dcb0 <__swc_fn_4fa09e82_000091_e6773530+0x20>
  40dca0:	call   40f060 <__swc_fn_4fa09e82_000166_e09accff>
  40dca5:	lea    rcx,[rax+0x1]
  40dca9:	mov    QWORD PTR [rip+0x19090],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dcb0:	dec    rcx
  40dcb3:	call   40b620 <__swc_fn_4fa09e82_000168_3130645d>
  40dcb8:	mov    rax,QWORD PTR [rax+0xc0]
  40dcbf:	and    eax,0x1
  40dcc2:	setne  al
  40dcc5:	add    rsp,0x8
  40dcc9:	ret
	...

000000000040dce0 <__swc_fn_4fa09e82_000094_335e9a12>:
  40dce0:	push   rbx
  40dce1:	push   rsi
  40dce2:	push   rdi
  40dce3:	push   r12
  40dce5:	sub    rsp,0x28
  40dce9:	mov    rbx,rcx
  40dcec:	call   408900 <__swc_fn_4fa09e82_000093_344f5089>
  40dcf1:	mov    rcx,QWORD PTR [rip+0x19048]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dcf8:	test   rcx,rcx
  40dcfb:	jne    40dd0d <__swc_fn_4fa09e82_000094_335e9a12+0x2d>
  40dcfd:	call   40f060 <__swc_fn_4fa09e82_000166_e09accff>
  40dd02:	lea    rcx,[rax+0x1]
  40dd06:	mov    QWORD PTR [rip+0x19033],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dd0d:	dec    rcx
  40dd10:	call   40b620 <__swc_fn_4fa09e82_000168_3130645d>
  40dd15:	mov    rsi,rax
  40dd18:	lea    rcx,[rsp+0x8]
  40dd1d:	call   410a90 <__swc_fn_4fa09e82_000092_17e20532>
  40dd22:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40dd29:	mov    r12,QWORD PTR [rsi+0xbe8]
  40dd30:	lea    rcx,[rsi+0x10]
  40dd34:	call   411bd0 <__swc_fn_4fa09e82_000158_5c8b11d8>
  40dd39:	mov    rcx,rsi
  40dd3c:	call   410c00 <__swc_fn_4fa09e82_000101_295ddd7c>
  40dd41:	vxorps xmm0,xmm0,xmm0
  40dd45:	xor    eax,eax
  40dd47:	cs nop WORD PTR [rax+rax*1+0x0]
  40dd51:	cs nop WORD PTR [rax+rax*1+0x0]
  40dd5b:	nop    DWORD PTR [rax+rax*1+0x0]
  40dd60:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40dd65:	add    rax,0x10
  40dd69:	cmp    rax,0xbf0
  40dd70:	jne    40dd60 <__swc_fn_4fa09e82_000094_335e9a12+0x80>
  40dd72:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40dd78:	vmovups XMMWORD PTR [rsi],xmm0
  40dd7c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40dd82:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40dd8a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40dd91:	mov    QWORD PTR [rsi+0xbe8],r12
  40dd98:	mov    rcx,QWORD PTR [rip+0x18fa1]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dd9f:	test   rcx,rcx
  40dda2:	jne    40ddb4 <__swc_fn_4fa09e82_000094_335e9a12+0xd4>
  40dda4:	call   40f060 <__swc_fn_4fa09e82_000166_e09accff>
  40dda9:	lea    rcx,[rax+0x1]
  40ddad:	mov    QWORD PTR [rip+0x18f8c],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40ddb4:	dec    rcx
  40ddb7:	call   40b620 <__swc_fn_4fa09e82_000168_3130645d>
  40ddbc:	mov    rsi,rax
  40ddbf:	mov    QWORD PTR [rsi+0xc0],rbx
  40ddc6:	and    ebx,0x1
  40ddc9:	jne    40ddcd <__swc_fn_4fa09e82_000094_335e9a12+0xed>
  40ddcb:	xor    eax,eax
  40ddcd:	test   rbx,rbx
  40ddd0:	sete   al
  40ddd3:	xor    cl,cl
  40ddd5:	xor    dl,dl
  40ddd7:	xor    r8b,r8b
  40ddda:	xor    r9b,r9b
  40dddd:	xor    r10b,r10b
  40dde0:	mov    r11,rax
  40dde3:	call   410450 <__swc_fn_4fa09e82_000077_e793b5e1>
  40dde8:	lea    rbx,[rsp+0x18]
  40dded:	mov    rcx,rbx
  40ddf0:	call   410a90 <__swc_fn_4fa09e82_000092_17e20532>
  40ddf5:	lea    rcx,[rsi+0x10]
  40ddf9:	mov    edx,0x400000
  40ddfe:	mov    r8,rbx
  40de01:	call   40eda0 <__swc_fn_4fa09e82_000160_9d602c76>
  40de06:	lea    rcx,[rsi+0x68]
  40de0a:	mov    edx,0x4000
  40de0f:	mov    r8,rbx
  40de12:	call   40eda0 <__swc_fn_4fa09e82_000160_9d602c76>
  40de17:	add    rsp,0x28
  40de1b:	pop    r12
  40de1d:	pop    rdi
  40de1e:	pop    rsi
  40de1f:	pop    rbx
  40de20:	ret
	...

000000000040de30 <__swc_fn_4fa09e82_000097_8b4a07e9>:
  40de30:	push   rbx
  40de31:	push   rsi
  40de32:	sub    rsp,0x18
  40de36:	mov    rbx,rcx
  40de39:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40de3e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40de44:	mov    rsi,QWORD PTR [rbx+0x70]
  40de48:	lea    rcx,[rcx+0x18]
  40de4c:	call   411bd0 <__swc_fn_4fa09e82_000158_5c8b11d8>
  40de51:	lea    rcx,[rsp+0x8]
  40de56:	mov    rdx,rbx
  40de59:	mov    r8d,0x78
  40de5f:	call   408960 <__swc_fn_4fa09e82_000096_f879630a>
  40de64:	mov    rax,rsi
  40de67:	add    rsp,0x18
  40de6b:	pop    rsi
  40de6c:	pop    rbx
  40de6d:	ret
	...

000000000040de70 <__swc_fn_4fa09e82_000100_2ef16a3e>:
  40de70:	push   rsi
  40de71:	push   rdi
  40de72:	sub    rsp,0x8
  40de76:	cmp    QWORD PTR [rcx],0x0
  40de7a:	jne    40de83 <__swc_fn_4fa09e82_000100_2ef16a3e+0x13>
  40de7c:	add    rsp,0x8
  40de80:	pop    rdi
  40de81:	pop    rsi
  40de82:	ret
  40de83:	mov    rsi,QWORD PTR [rcx]
  40de86:	mov    rax,QWORD PTR [rcx+0x8]
  40de8a:	test   rax,rax
  40de8d:	je     40dea3 <__swc_fn_4fa09e82_000100_2ef16a3e+0x33>
  40de8f:	test   DWORD PTR [rax+0x28],0x400000
  40de96:	je     40dea3 <__swc_fn_4fa09e82_000100_2ef16a3e+0x33>
  40de98:	mov    rcx,QWORD PTR [rax+0x30]
  40de9c:	test   rcx,rcx
  40de9f:	cmovne rax,rcx
  40dea3:	lea    rdx,[rip+0x5326]        # 4131d0 <__swc_rdata_base_4fa09e82+0xc0>
  40deaa:	lea    rcx,[rip+0x5407]        # 4132b8 <__swc_rdata_base_4fa09e82+0x1a8>
  40deb1:	mov    r8,rax
  40deb4:	xor    r9d,r9d
  40deb7:	xor    al,al
  40deb9:	mov    r10,rax
  40debc:	xor    r11d,r11d
  40debf:	call   40dc70 <__swc_fn_4fa09e82_000088_17711411>
  40dec4:	test   rax,rax
  40dec7:	je     40ded7 <__swc_fn_4fa09e82_000100_2ef16a3e+0x67>
  40dec9:	mov    rdi,QWORD PTR [rax+0x48]
  40decd:	test   rdi,rdi
  40ded0:	je     40ded7 <__swc_fn_4fa09e82_000100_2ef16a3e+0x67>
  40ded2:	mov    rcx,rsi
  40ded5:	call   rdi
  40ded7:	add    rsp,0x8
  40dedb:	pop    rdi
  40dedc:	pop    rsi
  40dedd:	ret
	...

000000000040dee0 <__swc_fn_4fa09e82_000103_2ed36338>:
  40dee0:	push   rbx
  40dee1:	push   rsi
  40dee2:	push   rdi
  40dee3:	sub    rsp,0x20
  40dee7:	mov    rbx,rdx
  40deea:	mov    rsi,rcx
  40deed:	mov    rcx,QWORD PTR [rip+0x18e4c]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40def4:	test   rcx,rcx
  40def7:	jne    40df09 <__swc_fn_4fa09e82_000103_2ed36338+0x29>
  40def9:	call   40f060 <__swc_fn_4fa09e82_000166_e09accff>
  40defe:	lea    rcx,[rax+0x1]
  40df02:	mov    QWORD PTR [rip+0x18e37],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40df09:	dec    rcx
  40df0c:	call   40b620 <__swc_fn_4fa09e82_000168_3130645d>
  40df11:	mov    rdi,rax
  40df14:	mov    rax,QWORD PTR [rdi+0xbd0]
  40df1b:	xor    ecx,ecx
  40df1d:	test   rax,rax
  40df20:	je     40df25 <__swc_fn_4fa09e82_000103_2ed36338+0x45>
  40df22:	mov    rcx,QWORD PTR [rax]
  40df25:	call   40f190 <__swc_fn_4fa09e82_000175_738eec22>
  40df2a:	lea    rax,[rsp+0x8]
  40df2f:	lea    rcx,[rdi+0x9c8]
  40df36:	mov    QWORD PTR [rsp+0x8],rcx
  40df3b:	mov    QWORD PTR [rax+0x8],0x40
  40df43:	xor    ecx,ecx
  40df45:	mov    rdx,rax
  40df48:	call   409980 <__swc_fn_4fa09e82_000120_18cd3882>
  40df4d:	mov    DWORD PTR [rdi+0xbc8],eax
  40df53:	mov    rdi,QWORD PTR [rdi+0x990]
  40df5a:	test   rdi,rdi
  40df5d:	je     40df67 <__swc_fn_4fa09e82_000103_2ed36338+0x87>
  40df5f:	mov    rcx,rsi
  40df62:	mov    rdx,rbx
  40df65:	call   rdi
  40df67:	call   40dc90 <__swc_fn_4fa09e82_000091_e6773530>
  40df6c:	test   al,al
  40df6e:	je     40df7e <__swc_fn_4fa09e82_000103_2ed36338+0x9e>
  40df70:	mov    rcx,rsi
  40df73:	mov    rdx,rbx
  40df76:	xor    r8d,r8d
  40df79:	call   40e2a0 <__swc_fn_4fa09e82_000121_1601f378>
  40df7e:	mov    rcx,rsi
  40df81:	mov    rdx,rbx
  40df84:	call   408a60 <__swc_fn_4fa09e82_000102_29a1093a>
  40df89:	call   411420 <__swc_fn_4fa09e82_000119_2b35b5e0>
  40df8e:	add    rsp,0x20
  40df92:	pop    rdi
  40df93:	pop    rsi
  40df94:	pop    rbx
  40df95:	ret
	...

000000000040dfa0 <__swc_fn_4fa09e82_000106_b7aef7c0>:
  40dfa0:	sub    rsp,0x8
  40dfa4:	test   r8,r8
  40dfa7:	je     40dfae <__swc_fn_4fa09e82_000106_b7aef7c0+0xe>
  40dfa9:	call   410dd0 <__swc_fn_4fa09e82_000104_baf871f8>
  40dfae:	add    rsp,0x8
  40dfb2:	ret
	...

000000000040dfc0 <__swc_fn_4fa09e82_000109_32416b9e>:
  40dfc0:	push   rsi
  40dfc1:	push   rdi
  40dfc2:	push   r12
  40dfc4:	push   r13
  40dfc6:	sub    rsp,0xd8
  40dfcd:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40dfd3:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40dfd9:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40dfdf:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40dfe5:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40dfeb:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40dff4:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40dffd:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40e006:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40e00f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40e018:	xor    eax,eax
  40e01a:	call   407050 <getpid@plt>
  40e01f:	mov    rsi,rax
  40e022:	lea    rdi,[rip+0x18d1f]        # 426d48 <__swc_bss_base_4fa09e82+0x2d08>
  40e029:	mov    r12,QWORD PTR [rdi]
  40e02c:	test   r12,r12
  40e02f:	je     40e03d <__swc_fn_4fa09e82_000109_32416b9e+0x7d>
  40e031:	cmp    DWORD PTR [r12+0x10],esi
  40e036:	jne    40e03d <__swc_fn_4fa09e82_000109_32416b9e+0x7d>
  40e038:	mov    rax,r12
  40e03b:	jmp    40e0a0 <__swc_fn_4fa09e82_000109_32416b9e+0xe0>
  40e03d:	mov    ecx,0x4
  40e042:	mov    edx,0x18
  40e047:	call   409190 <__swc_fn_4fa09e82_000108_ff529476>
  40e04c:	mov    rcx,rax
  40e04f:	test   rax,rax
  40e052:	jne    40e058 <__swc_fn_4fa09e82_000109_32416b9e+0x98>
  40e054:	xor    eax,eax
  40e056:	jmp    40e0a0 <__swc_fn_4fa09e82_000109_32416b9e+0xe0>
  40e058:	mov    DWORD PTR [rcx+0x10],esi
  40e05b:	mov    rax,r12
  40e05e:	lock cmpxchg QWORD PTR [rdi],rcx
  40e063:	mov    r13,rax
  40e066:	cmp    rax,r12
  40e069:	je     40e07f <__swc_fn_4fa09e82_000109_32416b9e+0xbf>
  40e06b:	mov    rdi,rcx
  40e06e:	mov    esi,0x18
  40e073:	xor    eax,eax
  40e075:	call   407160 <munmap@plt>
  40e07a:	mov    rax,r13
  40e07d:	jmp    40e0a0 <__swc_fn_4fa09e82_000109_32416b9e+0xe0>
  40e07f:	test   r12,r12
  40e082:	je     40e09d <__swc_fn_4fa09e82_000109_32416b9e+0xdd>
  40e084:	mov    rdi,r12
  40e087:	mov    esi,0x18
  40e08c:	xor    eax,eax
  40e08e:	mov    QWORD PTR [rsp+0x28],rcx
  40e093:	call   407160 <munmap@plt>
  40e098:	mov    rcx,QWORD PTR [rsp+0x28]
  40e09d:	mov    rax,rcx
  40e0a0:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40e0a6:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40e0ac:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40e0b2:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40e0b8:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40e0be:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40e0c7:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40e0d0:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40e0d9:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40e0e2:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40e0eb:	add    rsp,0xd8
  40e0f2:	pop    r13
  40e0f4:	pop    r12
  40e0f6:	pop    rdi
  40e0f7:	pop    rsi
  40e0f8:	ret
  40e0f9:	add    BYTE PTR [rax],al
  40e0fb:	add    BYTE PTR [rax],al
  40e0fd:	add    BYTE PTR [rax],al
	...

000000000040e100 <__swc_fn_4fa09e82_000112_e724f834>:
  40e100:	push   rbx
  40e101:	push   r12
  40e103:	push   rdi
  40e104:	push   rsi
  40e105:	sub    rsp,0xa8
  40e10c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e112:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e118:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e11e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e124:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e12a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e130:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e136:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e13c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e145:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e14e:	mov    rbx,rdx
  40e151:	mov    r12,rcx
  40e154:	mov    rdi,rcx
  40e157:	mov    rsi,rdx
  40e15a:	mov    edx,0x3
  40e15f:	xor    eax,eax
  40e161:	call   407170 <mprotect@plt>
  40e166:	test   eax,eax
  40e168:	je     40e16e <__swc_fn_4fa09e82_000112_e724f834+0x6e>
  40e16a:	xor    eax,eax
  40e16c:	jmp    40e183 <__swc_fn_4fa09e82_000112_e724f834+0x83>
  40e16e:	mov    rcx,r12
  40e171:	mov    rdx,rbx
  40e174:	mov    al,0x1
  40e176:	mov    r8,rax
  40e179:	call   4097c0 <__swc_fn_4fa09e82_000111_e606239a>
  40e17e:	mov    eax,0x1
  40e183:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e189:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e18f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e195:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e19b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e1a1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e1a7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e1ad:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e1b3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e1bc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e1c5:	add    rsp,0xa8
  40e1cc:	pop    rsi
  40e1cd:	pop    rdi
  40e1ce:	pop    r12
  40e1d0:	pop    rbx
  40e1d1:	ret
	...

000000000040e1e0 <__swc_fn_4fa09e82_000115_0575f585>:
  40e1e0:	sub    rsp,0x8
  40e1e4:	test   rcx,rcx
  40e1e7:	jne    40e1ee <__swc_fn_4fa09e82_000115_0575f585+0xe>
  40e1e9:	add    rsp,0x8
  40e1ed:	ret
  40e1ee:	call   4112d0 <__swc_fn_4fa09e82_000116_259b5d5a>
  40e1f3:	add    rsp,0x8
  40e1f7:	ret
	...

000000000040e200 <__swc_fn_4fa09e82_000118_76ff2f0a>:
  40e200:	push   rdi
  40e201:	push   rsi
  40e202:	sub    rsp,0xa8
  40e209:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e20f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e215:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e21b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e221:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e227:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e22d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e233:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e239:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e242:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e24b:	xor    edi,edi
  40e24d:	xor    eax,eax
  40e24f:	call   407180 <exit@plt>
  40e254:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e25a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e260:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e266:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e26c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e272:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e278:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e27e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e284:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e28d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e296:	add    rsp,0xa8
  40e29d:	pop    rsi
  40e29e:	pop    rdi
  40e29f:	ret

000000000040e2a0 <__swc_fn_4fa09e82_000121_1601f378>:
  40e2a0:	push   rbx
  40e2a1:	push   rsi
  40e2a2:	push   rdi
  40e2a3:	push   r12
  40e2a5:	sub    rsp,0x18
  40e2a9:	mov    rbx,r8
  40e2ac:	mov    rsi,rcx
  40e2af:	mov    rdi,rdx
  40e2b2:	mov    rcx,QWORD PTR [rip+0x18a87]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40e2b9:	test   rcx,rcx
  40e2bc:	jne    40e2ce <__swc_fn_4fa09e82_000121_1601f378+0x2e>
  40e2be:	call   40f060 <__swc_fn_4fa09e82_000166_e09accff>
  40e2c3:	lea    rcx,[rax+0x1]
  40e2c7:	mov    QWORD PTR [rip+0x18a72],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40e2ce:	dec    rcx
  40e2d1:	call   40b620 <__swc_fn_4fa09e82_000168_3130645d>
  40e2d6:	mov    r12,rax
  40e2d9:	cmp    ebx,0x3
  40e2dc:	jne    40e2ef <__swc_fn_4fa09e82_000121_1601f378+0x4f>
  40e2de:	mov    rax,QWORD PTR [r12+0xbd0]
  40e2e6:	test   rax,rax
  40e2e9:	jne    40e42c <__swc_fn_4fa09e82_000121_1601f378+0x18c>
  40e2ef:	cmp    ebx,0x5
  40e2f2:	jne    40e316 <__swc_fn_4fa09e82_000121_1601f378+0x76>
  40e2f4:	call   40dc90 <__swc_fn_4fa09e82_000091_e6773530>
  40e2f9:	test   al,al
  40e2fb:	jne    40e316 <__swc_fn_4fa09e82_000121_1601f378+0x76>
  40e2fd:	mov    rcx,rsi
  40e300:	mov    rdx,rdi
  40e303:	call   40b5d0 <__swc_fn_4fa09e82_000165_15b66a30>
  40e308:	test   al,al
  40e30a:	je     40e316 <__swc_fn_4fa09e82_000121_1601f378+0x76>
  40e30c:	add    rsp,0x18
  40e310:	pop    r12
  40e312:	pop    rdi
  40e313:	pop    rsi
  40e314:	pop    rbx
  40e315:	ret
  40e316:	call   40dc90 <__swc_fn_4fa09e82_000091_e6773530>
  40e31b:	test   al,al
  40e31d:	jne    40e38f <__swc_fn_4fa09e82_000121_1601f378+0xef>
  40e31f:	vmovups xmm0,XMMWORD PTR [rsi]
  40e323:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e329:	mov    rax,QWORD PTR [rsp+0x8]
  40e32e:	test   rax,rax
  40e331:	jne    40e382 <__swc_fn_4fa09e82_000121_1601f378+0xe2>
  40e333:	cmp    ebx,0x3
  40e336:	je     40e344 <__swc_fn_4fa09e82_000121_1601f378+0xa4>
  40e338:	cmp    ebx,0x4
  40e33b:	je     40e354 <__swc_fn_4fa09e82_000121_1601f378+0xb4>
  40e33d:	cmp    ebx,0x5
  40e340:	je     40e364 <__swc_fn_4fa09e82_000121_1601f378+0xc4>
  40e342:	jmp    40e374 <__swc_fn_4fa09e82_000121_1601f378+0xd4>
  40e344:	vmovups xmm0,XMMWORD PTR [rip+0x5194]        # 4134e0 <__swc_rdata_base_4fa09e82+0x3d0>
  40e34c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e352:	jmp    40e382 <__swc_fn_4fa09e82_000121_1601f378+0xe2>
  40e354:	vmovups xmm0,XMMWORD PTR [rip+0x5194]        # 4134f0 <__swc_rdata_base_4fa09e82+0x3e0>
  40e35c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e362:	jmp    40e382 <__swc_fn_4fa09e82_000121_1601f378+0xe2>
  40e364:	vmovups xmm0,XMMWORD PTR [rip+0x5194]        # 413500 <__swc_rdata_base_4fa09e82+0x3f0>
  40e36c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e372:	jmp    40e382 <__swc_fn_4fa09e82_000121_1601f378+0xe2>
  40e374:	vmovups xmm0,XMMWORD PTR [rip+0x5194]        # 413510 <__swc_rdata_base_4fa09e82+0x400>
  40e37c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e382:	lea    rcx,[rsp+0x8]
  40e387:	mov    rdx,rdi
  40e38a:	call   40dee0 <__swc_fn_4fa09e82_000103_2ed36338>
  40e38f:	vmovups xmm0,XMMWORD PTR [rdi]
  40e393:	vmovups XMMWORD PTR [r12+0x940],xmm0
  40e39d:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  40e3a2:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40e3ac:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  40e3b1:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40e3bb:	lea    rax,[r12+0x940]
  40e3c3:	mov    QWORD PTR [r12+0x970],rax
  40e3cb:	mov    rax,QWORD PTR [rsi]
  40e3ce:	mov    QWORD PTR [r12+0x978],rax
  40e3d6:	mov    rax,QWORD PTR [rsi+0x8]
  40e3da:	mov    QWORD PTR [r12+0x980],rax
  40e3e2:	movsxd rax,ebx
  40e3e5:	mov    QWORD PTR [r12+0x988],rax
  40e3ed:	cmp    ebx,0x5
  40e3f0:	je     40e3f9 <__swc_fn_4fa09e82_000121_1601f378+0x159>
  40e3f2:	xor    ecx,ecx
  40e3f4:	call   40f190 <__swc_fn_4fa09e82_000175_738eec22>
  40e3f9:	mov    rbx,QWORD PTR [r12+0xbe8]
  40e401:	test   rbx,rbx
  40e404:	je     40e415 <__swc_fn_4fa09e82_000121_1601f378+0x175>
  40e406:	mov    rcx,r12
  40e409:	call   rbx
  40e40b:	add    rsp,0x18
  40e40f:	pop    r12
  40e411:	pop    rdi
  40e412:	pop    rsi
  40e413:	pop    rbx
  40e414:	ret
  40e415:	mov    rcx,rsi
  40e418:	call   409870 <__swc_fn_4fa09e82_000117_3499f7d6>
  40e41d:	call   411420 <__swc_fn_4fa09e82_000119_2b35b5e0>
  40e422:	add    rsp,0x18
  40e426:	pop    r12
  40e428:	pop    rdi
  40e429:	pop    rsi
  40e42a:	pop    rbx
  40e42b:	ret
  40e42c:	mov    rcx,rsi
  40e42f:	mov    rdx,rdi
  40e432:	call   40dee0 <__swc_fn_4fa09e82_000103_2ed36338>
  40e437:	jmp    40e2ef <__swc_fn_4fa09e82_000121_1601f378+0x4f>
  40e43c:	add    BYTE PTR [rax],al
	...

000000000040e440 <__swc_fn_4fa09e82_000124_e9227a3e>:
  40e440:	push   rdi
  40e441:	push   rsi
  40e442:	sub    rsp,0xb8
  40e449:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40e44f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40e455:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40e45b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40e461:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40e467:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40e46d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40e473:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40e47c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40e485:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40e48e:	mov    DWORD PTR [rsp+0x8],0x0
  40e496:	lea    rdi,[rsp+0x8]
  40e49b:	xor    esi,esi
  40e49d:	xor    eax,eax
  40e49f:	call   407190 <pthread_key_create@plt>
  40e4a4:	test   eax,eax
  40e4a6:	jne    40e4ae <__swc_fn_4fa09e82_000124_e9227a3e+0x6e>
  40e4a8:	mov    eax,DWORD PTR [rsp+0x8]
  40e4ac:	jmp    40e4b5 <__swc_fn_4fa09e82_000124_e9227a3e+0x75>
  40e4ae:	mov    rax,0xffffffffffffffff
  40e4b5:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40e4bb:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40e4c1:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40e4c7:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40e4cd:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40e4d3:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40e4d9:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40e4df:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40e4e8:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40e4f1:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40e4fa:	add    rsp,0xb8
  40e501:	pop    rsi
  40e502:	pop    rdi
  40e503:	ret
	...

000000000040e510 <__swc_fn_4fa09e82_000127_5fb20c72>:
  40e510:	push   rdi
  40e511:	push   rsi
  40e512:	sub    rsp,0xb8
  40e519:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40e51f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40e525:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40e52b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40e531:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40e537:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40e53d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40e543:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40e54c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40e555:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40e55e:	mov    DWORD PTR [rsp+0x8],0x0
  40e566:	lea    rdi,[rsp+0x8]
  40e56b:	mov    rsi,rcx
  40e56e:	xor    eax,eax
  40e570:	call   407190 <pthread_key_create@plt>
  40e575:	test   eax,eax
  40e577:	jne    40e582 <__swc_fn_4fa09e82_000127_5fb20c72+0x72>
  40e579:	mov    eax,DWORD PTR [rsp+0x8]
  40e57d:	inc    rax
  40e580:	jmp    40e584 <__swc_fn_4fa09e82_000127_5fb20c72+0x74>
  40e582:	xor    eax,eax
  40e584:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40e58a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40e590:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40e596:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40e59c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40e5a2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40e5a8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40e5ae:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40e5b7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40e5c0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40e5c9:	add    rsp,0xb8
  40e5d0:	pop    rsi
  40e5d1:	pop    rdi
  40e5d2:	ret
	...

000000000040e5e0 <__swc_fn_4fa09e82_000130_0672cd48>:
  40e5e0:	push   rdi
  40e5e1:	push   rsi
  40e5e2:	sub    rsp,0xa8
  40e5e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e5ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e5f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e5fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e601:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e607:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e60d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e613:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e619:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e622:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e62b:	test   rcx,rcx
  40e62e:	setne  al
  40e631:	je     40e64a <__swc_fn_4fa09e82_000130_0672cd48+0x6a>
  40e633:	lea    rax,[rcx-0x1]
  40e637:	mov    eax,eax
  40e639:	mov    edi,eax
  40e63b:	mov    rsi,rdx
  40e63e:	xor    eax,eax
  40e640:	call   407120 <pthread_setspecific@plt>
  40e645:	test   eax,eax
  40e647:	sete   al
  40e64a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e650:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e656:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e65c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e662:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e668:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e66e:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e674:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e67a:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e683:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e68c:	add    rsp,0xa8
  40e693:	pop    rsi
  40e694:	pop    rdi
  40e695:	ret
	...

000000000040e6a0 <__swc_fn_4fa09e82_000133_2b60f756>:
  40e6a0:	push   rdi
  40e6a1:	push   rsi
  40e6a2:	sub    rsp,0xa8
  40e6a9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e6af:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e6b5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e6bb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e6c1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e6c7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e6cd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e6d3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e6d9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e6e2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e6eb:	mov    rax,rdx
  40e6ee:	mov    QWORD PTR [rsp],0x0
  40e6f6:	mov    edi,0xca
  40e6fb:	mov    rsi,rcx
  40e6fe:	mov    edx,0x81
  40e703:	mov    eax,eax
  40e705:	mov    ecx,eax
  40e707:	xor    r8d,r8d
  40e70a:	xor    r9d,r9d
  40e70d:	xor    eax,eax
  40e70f:	call   4071a0 <syscall@plt>
  40e714:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e71a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e720:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e726:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e72c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e732:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e738:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e73e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e744:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e74d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e756:	add    rsp,0xa8
  40e75d:	pop    rsi
  40e75e:	pop    rdi
  40e75f:	ret

000000000040e760 <__swc_fn_4fa09e82_000136_1fec60ac>:
  40e760:	sub    rsp,0x8
  40e764:	call   4117d0 <__swc_fn_4fa09e82_000134_c6de0049>
  40e769:	add    rsp,0x8
  40e76d:	ret
	...

000000000040e770 <__swc_fn_4fa09e82_000139_2214b637>:
  40e770:	push   rdi
  40e771:	push   rsi
  40e772:	sub    rsp,0xc8
  40e779:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40e77f:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40e785:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40e78b:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40e791:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40e797:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40e79d:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40e7a6:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40e7af:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40e7b8:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40e7c1:	vxorps xmm0,xmm0,xmm0
  40e7c5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e7cb:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e7d1:	mov    rdi,rcx
  40e7d4:	lea    rsi,[rsp+0x8]
  40e7d9:	xor    eax,eax
  40e7db:	call   4071b0 <dladdr@plt>
  40e7e0:	xor    ecx,ecx
  40e7e2:	test   eax,eax
  40e7e4:	je     40e7eb <__swc_fn_4fa09e82_000139_2214b637+0x7b>
  40e7e6:	mov    rcx,QWORD PTR [rsp+0x10]
  40e7eb:	mov    rax,rcx
  40e7ee:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40e7f4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40e7fa:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40e800:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40e806:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40e80c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40e812:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40e81b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40e824:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40e82d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40e836:	add    rsp,0xc8
  40e83d:	pop    rsi
  40e83e:	pop    rdi
  40e83f:	ret

000000000040e840 <__swc_fn_4fa09e82_000142_376d5f6d>:
  40e840:	push   rbx
  40e841:	push   r12
  40e843:	push   r13
  40e845:	push   rdi
  40e846:	push   rsi
  40e847:	push   r14
  40e849:	push   r15
  40e84b:	sub    rsp,0x150
  40e852:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40e85b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40e864:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40e86d:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40e876:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40e87f:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40e888:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40e891:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40e89a:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40e8a3:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40e8ac:	mov    rbx,rdx
  40e8af:	mov    QWORD PTR [rsp+0x98],rdx
  40e8b7:	mov    r12,rcx
  40e8ba:	mov    QWORD PTR [rsp+0xa0],rcx
  40e8c2:	mov    QWORD PTR [rbx],0x0
  40e8c9:	lea    r13,[rip+0x184b0]        # 426d80 <__swc_bss_base_4fa09e82+0x2d40>
  40e8d0:	mov    rcx,r13
  40e8d3:	call   40e760 <__swc_fn_4fa09e82_000136_1fec60ac>
  40e8d8:	mov    rax,QWORD PTR [rip+0x184a9]        # 426d88 <__swc_bss_base_4fa09e82+0x2d48>
  40e8df:	test   rax,rax
  40e8e2:	je     40e919 <__swc_fn_4fa09e82_000142_376d5f6d+0xd9>
  40e8e4:	cs nop WORD PTR [rax+rax*1+0x0]
  40e8ee:	xchg   ax,ax
  40e8f0:	cmp    QWORD PTR [rax+0x8],r12
  40e8f4:	jne    40e911 <__swc_fn_4fa09e82_000142_376d5f6d+0xd1>
  40e8f6:	mov    rcx,QWORD PTR [rax+0x18]
  40e8fa:	mov    QWORD PTR [rbx],rcx
  40e8fd:	mov    rbx,QWORD PTR [rax+0x10]
  40e901:	mov    rcx,r13
  40e904:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40e909:	mov    rax,rbx
  40e90c:	jmp    40eafb <__swc_fn_4fa09e82_000142_376d5f6d+0x2bb>
  40e911:	mov    rax,QWORD PTR [rax]
  40e914:	test   rax,rax
  40e917:	jne    40e8f0 <__swc_fn_4fa09e82_000142_376d5f6d+0xb0>
  40e919:	vxorps xmm0,xmm0,xmm0
  40e91d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  40e923:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  40e929:	mov    rdi,r12
  40e92c:	lea    rsi,[rsp+0x10]
  40e931:	xor    eax,eax
  40e933:	call   4071b0 <dladdr@plt>
  40e938:	test   eax,eax
  40e93a:	sete   al
  40e93d:	je     40e94a <__swc_fn_4fa09e82_000142_376d5f6d+0x10a>
  40e93f:	mov    rax,QWORD PTR [rsp+0x10]
  40e944:	test   rax,rax
  40e947:	sete   al
  40e94a:	test   al,al
  40e94c:	je     40e95d <__swc_fn_4fa09e82_000142_376d5f6d+0x11d>
  40e94e:	mov    rcx,r13
  40e951:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40e956:	xor    eax,eax
  40e958:	jmp    40eafb <__swc_fn_4fa09e82_000142_376d5f6d+0x2bb>
  40e95d:	mov    rdi,QWORD PTR [rsp+0x10]
  40e962:	mov    esi,0x80000
  40e967:	xor    eax,eax
  40e969:	call   407010 <open@plt>
  40e96e:	lea    r14,[rsp+0x30]
  40e973:	mov    DWORD PTR [rsp+0x30],eax
  40e977:	cmp    DWORD PTR [r14],0x0
  40e97b:	jge    40e98c <__swc_fn_4fa09e82_000142_376d5f6d+0x14c>
  40e97d:	mov    rcx,r13
  40e980:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40e985:	xor    eax,eax
  40e987:	jmp    40eafb <__swc_fn_4fa09e82_000142_376d5f6d+0x2bb>
  40e98c:	mov    rax,r14
  40e98f:	movsxd rdi,DWORD PTR [rax]
  40e992:	xor    esi,esi
  40e994:	mov    edx,0x2
  40e999:	xor    eax,eax
  40e99b:	call   4070c0 <lseek@plt>
  40e9a0:	mov    r15,rax
  40e9a3:	test   rax,rax
  40e9a6:	jg     40e9c1 <__swc_fn_4fa09e82_000142_376d5f6d+0x181>
  40e9a8:	movsxd rdi,DWORD PTR [r14]
  40e9ab:	xor    eax,eax
  40e9ad:	call   407040 <close@plt>
  40e9b2:	mov    rcx,r13
  40e9b5:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40e9ba:	xor    eax,eax
  40e9bc:	jmp    40eafb <__swc_fn_4fa09e82_000142_376d5f6d+0x2bb>
  40e9c1:	xor    edi,edi
  40e9c3:	mov    rsi,r15
  40e9c6:	mov    edx,0x1
  40e9cb:	mov    ecx,0x2
  40e9d0:	mov    rax,r14
  40e9d3:	movsxd r8,DWORD PTR [rax]
  40e9d6:	xor    r9d,r9d
  40e9d9:	xor    eax,eax
  40e9db:	call   4070d0 <mmap@plt>
  40e9e0:	mov    rbx,rax
  40e9e3:	test   rax,rax
  40e9e6:	sete   al
  40e9e9:	cmp    rbx,0xffffffffffffffff
  40e9ed:	sete   cl
  40e9f0:	or     al,cl
  40e9f2:	je     40ea0d <__swc_fn_4fa09e82_000142_376d5f6d+0x1cd>
  40e9f4:	movsxd rdi,DWORD PTR [r14]
  40e9f7:	xor    eax,eax
  40e9f9:	call   407040 <close@plt>
  40e9fe:	mov    rcx,r13
  40ea01:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40ea06:	xor    eax,eax
  40ea08:	jmp    40eafb <__swc_fn_4fa09e82_000142_376d5f6d+0x2bb>
  40ea0d:	lea    rax,[rsp+0x50]
  40ea12:	mov    QWORD PTR [rax],0x0
  40ea19:	mov    rcx,rbx
  40ea1c:	mov    rdx,r15
  40ea1f:	mov    r8,rax
  40ea22:	call   409e00 <__swc_fn_4fa09e82_000141_81b740ca>
  40ea27:	mov    r12,rax
  40ea2a:	test   rax,rax
  40ea2d:	jne    40ea55 <__swc_fn_4fa09e82_000142_376d5f6d+0x215>
  40ea2f:	mov    rdi,rbx
  40ea32:	mov    rsi,r15
  40ea35:	xor    eax,eax
  40ea37:	call   407160 <munmap@plt>
  40ea3c:	movsxd rdi,DWORD PTR [r14]
  40ea3f:	xor    eax,eax
  40ea41:	call   407040 <close@plt>
  40ea46:	mov    rcx,r13
  40ea49:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40ea4e:	xor    eax,eax
  40ea50:	jmp    40eafb <__swc_fn_4fa09e82_000142_376d5f6d+0x2bb>
  40ea55:	mov    edi,0x20
  40ea5a:	xor    eax,eax
  40ea5c:	call   4071c0 <malloc@plt>
  40ea61:	test   rax,rax
  40ea64:	jne    40ea89 <__swc_fn_4fa09e82_000142_376d5f6d+0x249>
  40ea66:	mov    rdi,rbx
  40ea69:	mov    rsi,r15
  40ea6c:	xor    eax,eax
  40ea6e:	call   407160 <munmap@plt>
  40ea73:	movsxd rdi,DWORD PTR [r14]
  40ea76:	xor    eax,eax
  40ea78:	call   407040 <close@plt>
  40ea7d:	mov    rcx,r13
  40ea80:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40ea85:	xor    eax,eax
  40ea87:	jmp    40eafb <__swc_fn_4fa09e82_000142_376d5f6d+0x2bb>
  40ea89:	mov    rcx,QWORD PTR [rip+0x182f8]        # 426d88 <__swc_bss_base_4fa09e82+0x2d48>
  40ea90:	mov    QWORD PTR [rsp+0x70],rcx
  40ea95:	mov    rcx,QWORD PTR [rsp+0xa0]
  40ea9d:	mov    QWORD PTR [rsp+0x78],rcx
  40eaa2:	mov    QWORD PTR [rsp+0x80],r12
  40eaaa:	mov    rcx,QWORD PTR [rsp+0x50]
  40eaaf:	mov    QWORD PTR [rsp+0x88],rcx
  40eab7:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  40eabd:	vmovups XMMWORD PTR [rax],xmm0
  40eac1:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  40eaca:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40eacf:	mov    QWORD PTR [rip+0x182b2],rax        # 426d88 <__swc_bss_base_4fa09e82+0x2d48>
  40ead6:	mov    rax,QWORD PTR [rsp+0x50]
  40eadb:	mov    rbx,QWORD PTR [rsp+0x98]
  40eae3:	mov    QWORD PTR [rbx],rax
  40eae6:	movsxd rdi,DWORD PTR [r14]
  40eae9:	xor    eax,eax
  40eaeb:	call   407040 <close@plt>
  40eaf0:	mov    rcx,r13
  40eaf3:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40eaf8:	mov    rax,r12
  40eafb:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40eb04:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40eb0d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40eb16:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40eb1f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40eb28:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40eb31:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40eb3a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40eb43:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40eb4c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40eb55:	add    rsp,0x150
  40eb5c:	pop    r15
  40eb5e:	pop    r14
  40eb60:	pop    rsi
  40eb61:	pop    rdi
  40eb62:	pop    r13
  40eb64:	pop    r12
  40eb66:	pop    rbx
  40eb67:	ret
	...

000000000040eb70 <__swc_fn_4fa09e82_000145_364559f5>:
  40eb70:	push   rbx
  40eb71:	sub    rsp,0xe0
  40eb78:	lea    rbx,[rsp+0x8]
  40eb7d:	vxorps xmm0,xmm0,xmm0
  40eb81:	vmovups YMMWORD PTR [rbx],ymm0
  40eb85:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40eb8a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40eb8f:	vzeroupper
  40eb92:	mov    DWORD PTR [rbx+0x60],0x0
  40eb99:	mov    r8,rbx
  40eb9c:	nop    DWORD PTR [rax+0x0]
  40eba0:	mov    r9,rcx
  40eba3:	movabs rcx,0xcccccccccccccccd
  40ebad:	mov    rax,r9
  40ebb0:	mul    rcx
  40ebb3:	mov    r10,rdx
  40ebb6:	shr    r10,0x3
  40ebba:	mov    rcx,r10
  40ebbd:	imul   rdx,r10,0xa
  40ebc1:	sub    r9,rdx
  40ebc4:	mov    rdx,QWORD PTR [rip+0x4975]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40ebcb:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  40ebd0:	mov    BYTE PTR [r8],dl
  40ebd3:	lea    rdx,[r8+0x1]
  40ebd7:	mov    r8,rdx
  40ebda:	test   r10,r10
  40ebdd:	jne    40eba0 <__swc_fn_4fa09e82_000145_364559f5+0x30>
  40ebdf:	mov    BYTE PTR [rdx],0x0
  40ebe2:	sub    r8,0x1
  40ebe6:	mov    rax,rbx
  40ebe9:	cmp    rax,r8
  40ebec:	jae    40ec06 <__swc_fn_4fa09e82_000145_364559f5+0x96>
  40ebee:	xchg   ax,ax
  40ebf0:	mov    cl,BYTE PTR [r8]
  40ebf3:	mov    dl,BYTE PTR [rax]
  40ebf5:	mov    BYTE PTR [r8],dl
  40ebf8:	sub    r8,0x1
  40ebfc:	mov    BYTE PTR [rax],cl
  40ebfe:	inc    rax
  40ec01:	cmp    rax,r8
  40ec04:	jb     40ebf0 <__swc_fn_4fa09e82_000145_364559f5+0x80>
  40ec06:	xor    eax,eax
  40ec08:	test   rbx,rbx
  40ec0b:	je     40ec2e <__swc_fn_4fa09e82_000145_364559f5+0xbe>
  40ec0d:	mov    rcx,rbx
  40ec10:	mov    dl,BYTE PTR [rcx]
  40ec12:	test   dl,dl
  40ec14:	je     40ec2e <__swc_fn_4fa09e82_000145_364559f5+0xbe>
  40ec16:	cs nop WORD PTR [rax+rax*1+0x0]
  40ec20:	add    rcx,0x1
  40ec24:	add    rax,0x1
  40ec28:	mov    dl,BYTE PTR [rcx]
  40ec2a:	test   dl,dl
  40ec2c:	jne    40ec20 <__swc_fn_4fa09e82_000145_364559f5+0xb0>
  40ec2e:	mov    QWORD PTR [rbx+0xa8],rbx
  40ec35:	mov    QWORD PTR [rbx+0xb0],rax
  40ec3c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40ec44:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40ec4c:	lea    rcx,[rbx+0xb8]
  40ec53:	call   409870 <__swc_fn_4fa09e82_000117_3499f7d6>
  40ec58:	add    rsp,0xe0
  40ec5f:	pop    rbx
  40ec60:	ret
	...

000000000040ec70 <__swc_fn_4fa09e82_000148_c9c6528e>:
  40ec70:	sub    rsp,0x8
  40ec74:	mov    rax,QWORD PTR [rcx+0x8]
  40ec78:	mov    r8,QWORD PTR [rdx+0x8]
  40ec7c:	cmp    rax,r8
  40ec7f:	je     40ec88 <__swc_fn_4fa09e82_000148_c9c6528e+0x18>
  40ec81:	xor    eax,eax
  40ec83:	add    rsp,0x8
  40ec87:	ret
  40ec88:	test   rax,rax
  40ec8b:	jne    40ec9c <__swc_fn_4fa09e82_000148_c9c6528e+0x2c>
  40ec8d:	test   r8,r8
  40ec90:	jne    40ec9c <__swc_fn_4fa09e82_000148_c9c6528e+0x2c>
  40ec92:	mov    eax,0x1
  40ec97:	add    rsp,0x8
  40ec9b:	ret
  40ec9c:	mov    rcx,QWORD PTR [rcx]
  40ec9f:	mov    rdx,QWORD PTR [rdx]
  40eca2:	test   rcx,rcx
  40eca5:	sete   r8b
  40eca9:	test   rdx,rdx
  40ecac:	sete   r9b
  40ecb0:	or     r8b,r9b
  40ecb3:	je     40ecc0 <__swc_fn_4fa09e82_000148_c9c6528e+0x50>
  40ecb5:	cmp    rcx,rdx
  40ecb8:	sete   al
  40ecbb:	add    rsp,0x8
  40ecbf:	ret
  40ecc0:	cmp    rcx,rdx
  40ecc3:	jne    40eccf <__swc_fn_4fa09e82_000148_c9c6528e+0x5f>
  40ecc5:	mov    eax,0x1
  40ecca:	add    rsp,0x8
  40ecce:	ret
  40eccf:	mov    r8,rax
  40ecd2:	call   410eb0 <__swc_fn_4fa09e82_000107_77a5d54a>
  40ecd7:	test   eax,eax
  40ecd9:	sete   al
  40ecdc:	add    rsp,0x8
  40ece0:	ret
	...

000000000040ecf0 <__swc_fn_4fa09e82_000151_33e5e24f>:
  40ecf0:	vxorps xmm0,xmm0,xmm0
  40ecf4:	vmovups XMMWORD PTR [rcx],xmm0
  40ecf8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40ecfd:	vxorps xmm0,xmm0,xmm0
  40ed01:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ed06:	vmovups xmm0,XMMWORD PTR [rip+0x48ea]        # 4135f8 <__swc_rdata_base_4fa09e82+0x4e8>
  40ed0e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ed13:	ret
	...

000000000040ed20 <__swc_fn_4fa09e82_000154_33e5e24f>:
  40ed20:	vxorps xmm0,xmm0,xmm0
  40ed24:	vmovups XMMWORD PTR [rcx],xmm0
  40ed28:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40ed2d:	vxorps xmm0,xmm0,xmm0
  40ed31:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ed36:	vmovups xmm0,XMMWORD PTR [rip+0x49da]        # 413718 <__swc_rdata_base_4fa09e82+0x608>
  40ed3e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ed43:	mov    QWORD PTR [rcx+0x40],0x0
  40ed4b:	ret
  40ed4c:	add    BYTE PTR [rax],al
	...

000000000040ed50 <__swc_fn_4fa09e82_000157_312df05a>:
  40ed50:	push   rbx
  40ed51:	sub    rsp,0x70
  40ed55:	mov    rax,QWORD PTR [rcx]
  40ed58:	mov    rbx,QWORD PTR [rcx+0x8]
  40ed5c:	vxorps xmm0,xmm0,xmm0
  40ed60:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40ed66:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40ed6c:	vzeroupper
  40ed6f:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40ed75:	mov    QWORD PTR [rsp+0x48],rdx
  40ed7a:	mov    QWORD PTR [rsp+0x50],r8
  40ed7f:	mov    rcx,rax
  40ed82:	lea    rdx,[rsp+0x8]
  40ed87:	mov    rbx,QWORD PTR [rbx+0x18]
  40ed8b:	call   rbx
  40ed8d:	add    rsp,0x70
  40ed91:	pop    rbx
  40ed92:	ret
	...

000000000040eda0 <__swc_fn_4fa09e82_000160_9d602c76>:
  40eda0:	push   rbx
  40eda1:	push   rsi
  40eda2:	push   rdi
  40eda3:	mov    rbx,r8
  40eda6:	mov    rsi,rcx
  40eda9:	mov    rdi,rdx
  40edac:	call   411bd0 <__swc_fn_4fa09e82_000158_5c8b11d8>
  40edb1:	vmovups xmm0,XMMWORD PTR [rbx]
  40edb5:	vmovups XMMWORD PTR [rsi],xmm0
  40edb9:	mov    QWORD PTR [rsi+0x18],rdi
  40edbd:	pop    rdi
  40edbe:	pop    rsi
  40edbf:	pop    rbx
  40edc0:	ret
	...

000000000040edd0 <__swc_fn_4fa09e82_000163_edb9cf73>:
  40edd0:	push   rbx
  40edd1:	push   rsi
  40edd2:	push   rdi
  40edd3:	push   r12
  40edd5:	push   r13
  40edd7:	sub    rsp,0x50
  40eddb:	mov    rbx,rcx
  40edde:	mov    rsi,rdx
  40ede1:	vmovups xmm0,XMMWORD PTR [rip+0x4a3f]        # 413828 <__swc_rdata_base_4fa09e82+0x718>
  40ede9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40edef:	vmovups xmm0,XMMWORD PTR [rip+0x4a41]        # 413838 <__swc_rdata_base_4fa09e82+0x728>
  40edf7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40edfd:	vxorps xmm0,xmm0,xmm0
  40ee01:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ee07:	mov    rcx,rdx
  40ee0a:	call   40e770 <__swc_fn_4fa09e82_000139_2214b637>
  40ee0f:	mov    rdi,rax
  40ee12:	test   rax,rax
  40ee15:	jne    40ee46 <__swc_fn_4fa09e82_000163_edb9cf73+0x76>
  40ee17:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ee1d:	vmovups XMMWORD PTR [rbx],xmm0
  40ee21:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ee27:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ee2c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40ee32:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ee37:	mov    rax,rbx
  40ee3a:	add    rsp,0x50
  40ee3e:	pop    r13
  40ee40:	pop    r12
  40ee42:	pop    rdi
  40ee43:	pop    rsi
  40ee44:	pop    rbx
  40ee45:	ret
  40ee46:	mov    rcx,rdi
  40ee49:	call   40b320 <__swc_fn_4fa09e82_000162_9e36e814>
  40ee4e:	mov    r11,rax
  40ee51:	test   rax,rax
  40ee54:	je     40ee5e <__swc_fn_4fa09e82_000163_edb9cf73+0x8e>
  40ee56:	mov    al,BYTE PTR [r11+0x24]
  40ee5a:	test   al,al
  40ee5c:	jne    40ee8d <__swc_fn_4fa09e82_000163_edb9cf73+0xbd>
  40ee5e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ee64:	vmovups XMMWORD PTR [rbx],xmm0
  40ee68:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ee6e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ee73:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40ee79:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ee7e:	mov    rax,rbx
  40ee81:	add    rsp,0x50
  40ee85:	pop    r13
  40ee87:	pop    r12
  40ee89:	pop    rdi
  40ee8a:	pop    rsi
  40ee8b:	pop    rbx
  40ee8c:	ret
  40ee8d:	sub    rsi,rdi
  40ee90:	mov    eax,0xffffffff
  40ee95:	cmp    rsi,rax
  40ee98:	jbe    40eec9 <__swc_fn_4fa09e82_000163_edb9cf73+0xf9>
  40ee9a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40eea0:	vmovups XMMWORD PTR [rbx],xmm0
  40eea4:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40eeaa:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40eeaf:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40eeb5:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40eeba:	mov    rax,rbx
  40eebd:	add    rsp,0x50
  40eec1:	pop    r13
  40eec3:	pop    r12
  40eec5:	pop    rdi
  40eec6:	pop    rsi
  40eec7:	pop    rbx
  40eec8:	ret
  40eec9:	mov    rdi,QWORD PTR [r11+0x10]
  40eecd:	mov    eax,DWORD PTR [r11+0x20]
  40eed1:	xor    ecx,ecx
  40eed3:	test   rax,rax
  40eed6:	jbe    40f028 <__swc_fn_4fa09e82_000163_edb9cf73+0x258>
  40eedc:	nop    DWORD PTR [rax+0x0]
  40eee0:	mov    edx,ecx
  40eee2:	imul   r12,rdx,0x14
  40eee6:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40eeeb:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40eef0:	mov    r9d,esi
  40eef3:	cmp    r9,rdx
  40eef6:	jb     40f01b <__swc_fn_4fa09e82_000163_edb9cf73+0x24b>
  40eefc:	add    rdx,r8
  40eeff:	mov    r8d,esi
  40ef02:	cmp    r8,rdx
  40ef05:	jae    40f01b <__swc_fn_4fa09e82_000163_edb9cf73+0x24b>
  40ef0b:	lea    rsi,[rsp+0x38]
  40ef10:	mov    eax,DWORD PTR [rdi+0xc]
  40ef13:	mov    DWORD PTR [rsp+0x38],eax
  40ef17:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40ef1c:	mov    rcx,rdi
  40ef1f:	mov    rdx,QWORD PTR [r11+0x18]
  40ef23:	mov    r8,rsi
  40ef26:	mov    r8d,DWORD PTR [r8]
  40ef29:	mov    r9,rax
  40ef2c:	lea    r10,[rsp+0x10]
  40ef31:	call   411c20 <__swc_fn_4fa09e82_000161_e25d06b9>
  40ef36:	test   al,al
  40ef38:	jne    40ef6b <__swc_fn_4fa09e82_000163_edb9cf73+0x19b>
  40ef3a:	vmovups xmm0,XMMWORD PTR [rip+0x4916]        # 413858 <__swc_rdata_base_4fa09e82+0x748>
  40ef42:	vmovups XMMWORD PTR [rbx],xmm0
  40ef46:	vmovups xmm0,XMMWORD PTR [rip+0x491a]        # 413868 <__swc_rdata_base_4fa09e82+0x758>
  40ef4e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ef53:	vxorps xmm0,xmm0,xmm0
  40ef57:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ef5c:	mov    rax,rbx
  40ef5f:	add    rsp,0x50
  40ef63:	pop    r13
  40ef65:	pop    r12
  40ef67:	pop    rdi
  40ef68:	pop    rsi
  40ef69:	pop    rbx
  40ef6a:	ret
  40ef6b:	lea    r13,[rsp+0x3c]
  40ef70:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40ef75:	mov    DWORD PTR [rsp+0x3c],eax
  40ef79:	test   eax,eax
  40ef7b:	je     40efcc <__swc_fn_4fa09e82_000163_edb9cf73+0x1fc>
  40ef7d:	mov    rcx,rdi
  40ef80:	mov    rdx,QWORD PTR [r11+0x18]
  40ef84:	mov    r8d,DWORD PTR [rsi]
  40ef87:	mov    rax,r13
  40ef8a:	mov    r9d,DWORD PTR [rax]
  40ef8d:	lea    r10,[rsp+0x20]
  40ef92:	call   411c20 <__swc_fn_4fa09e82_000161_e25d06b9>
  40ef97:	test   al,al
  40ef99:	jne    40efcc <__swc_fn_4fa09e82_000163_edb9cf73+0x1fc>
  40ef9b:	vmovups xmm0,XMMWORD PTR [rip+0x48e5]        # 413888 <__swc_rdata_base_4fa09e82+0x778>
  40efa3:	vmovups XMMWORD PTR [rbx],xmm0
  40efa7:	vmovups xmm0,XMMWORD PTR [rip+0x48e9]        # 413898 <__swc_rdata_base_4fa09e82+0x788>
  40efaf:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40efb4:	vxorps xmm0,xmm0,xmm0
  40efb8:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40efbd:	mov    rax,rbx
  40efc0:	add    rsp,0x50
  40efc4:	pop    r13
  40efc6:	pop    r12
  40efc8:	pop    rdi
  40efc9:	pop    rsi
  40efca:	pop    rbx
  40efcb:	ret
  40efcc:	mov    eax,0x1
  40efd1:	rex mov BYTE PTR [rsp+0x8],al
  40efd6:	cmp    DWORD PTR [r13+0x0],0x0
  40efdb:	je     40efec <__swc_fn_4fa09e82_000163_edb9cf73+0x21c>
  40efdd:	rex mov BYTE PTR [rsp+0x9],0x1
  40efe3:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40efe8:	mov    DWORD PTR [rsp+0x30],eax
  40efec:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40eff2:	vmovups XMMWORD PTR [rbx],xmm0
  40eff6:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40effc:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40f001:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40f007:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40f00c:	mov    rax,rbx
  40f00f:	add    rsp,0x50
  40f013:	pop    r13
  40f015:	pop    r12
  40f017:	pop    rdi
  40f018:	pop    rsi
  40f019:	pop    rbx
  40f01a:	ret
  40f01b:	add    rcx,0x1
  40f01f:	cmp    rcx,rax
  40f022:	jb     40eee0 <__swc_fn_4fa09e82_000163_edb9cf73+0x110>
  40f028:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f02e:	vmovups XMMWORD PTR [rbx],xmm0
  40f032:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40f038:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40f03d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40f043:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40f048:	mov    rax,rbx
  40f04b:	add    rsp,0x50
  40f04f:	pop    r13
  40f051:	pop    r12
  40f053:	pop    rdi
  40f054:	pop    rsi
  40f055:	pop    rbx
  40f056:	ret
	...

000000000040f060 <__swc_fn_4fa09e82_000166_e09accff>:
  40f060:	sub    rsp,0x48
  40f064:	call   40e440 <__swc_fn_4fa09e82_000124_e9227a3e>
  40f069:	cmp    rax,0xffffffffffffffff
  40f06d:	je     40f074 <__swc_fn_4fa09e82_000166_e09accff+0x14>
  40f06f:	add    rsp,0x48
  40f073:	ret
  40f074:	lea    rcx,[rip+0x484d]        # 4138c8 <__swc_rdata_base_4fa09e82+0x7b8>
  40f07b:	vmovups xmm0,XMMWORD PTR [rip+0x4855]        # 4138d8 <__swc_rdata_base_4fa09e82+0x7c8>
  40f083:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f089:	vmovups xmm0,XMMWORD PTR [rip+0x4857]        # 4138e8 <__swc_rdata_base_4fa09e82+0x7d8>
  40f091:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f097:	vmovups xmm0,XMMWORD PTR [rip+0x4859]        # 4138f8 <__swc_rdata_base_4fa09e82+0x7e8>
  40f09f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40f0a5:	lea    rdx,[rsp+0x8]
  40f0aa:	mov    QWORD PTR [rsp+0x38],rax
  40f0af:	call   40dee0 <__swc_fn_4fa09e82_000103_2ed36338>
  40f0b4:	mov    rax,QWORD PTR [rsp+0x38]
  40f0b9:	jmp    40f06f <__swc_fn_4fa09e82_000166_e09accff+0xf>
  40f0bb:	add    BYTE PTR [rax],al
  40f0bd:	add    BYTE PTR [rax],al
	...

000000000040f0c0 <__swc_fn_4fa09e82_000169_0ff0458f>:
  40f0c0:	push   rbx
  40f0c1:	push   rsi
  40f0c2:	sub    rsp,0x28
  40f0c6:	mov    rbx,rcx
  40f0c9:	mov    DWORD PTR [rsp+0x8],0xbf0
  40f0d1:	mov    ecx,0xbf0
  40f0d6:	call   40dad0 <__swc_fn_4fa09e82_000079_29fad089>
  40f0db:	mov    rsi,rax
  40f0de:	test   rax,rax
  40f0e1:	jne    40f0ec <__swc_fn_4fa09e82_000169_0ff0458f+0x2c>
  40f0e3:	xor    eax,eax
  40f0e5:	add    rsp,0x28
  40f0e9:	pop    rsi
  40f0ea:	pop    rbx
  40f0eb:	ret
  40f0ec:	vxorps xmm0,xmm0,xmm0
  40f0f0:	xor    eax,eax
  40f0f2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f0fc:	nop    DWORD PTR [rax+0x0]
  40f100:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40f105:	add    rax,0x10
  40f109:	cmp    rax,0xbf0
  40f110:	jne    40f100 <__swc_fn_4fa09e82_000169_0ff0458f+0x40>
  40f112:	lea    rax,[rbx+0x1]
  40f116:	mov    QWORD PTR [rsi+0x9c0],rax
  40f11d:	mov    rcx,rbx
  40f120:	mov    rdx,rsi
  40f123:	call   411f80 <__swc_fn_4fa09e82_000167_31ca4f53>
  40f128:	test   al,al
  40f12a:	jne    40f13d <__swc_fn_4fa09e82_000169_0ff0458f+0x7d>
  40f12c:	mov    rcx,rsi
  40f12f:	call   410510 <__swc_fn_4fa09e82_000080_851c599a>
  40f134:	xor    eax,eax
  40f136:	add    rsp,0x28
  40f13a:	pop    rsi
  40f13b:	pop    rbx
  40f13c:	ret
  40f13d:	lea    rcx,[rsp+0x18]
  40f142:	call   410a90 <__swc_fn_4fa09e82_000092_17e20532>
  40f147:	mov    rax,rsi
  40f14a:	add    rsp,0x28
  40f14e:	pop    rsi
  40f14f:	pop    rbx
  40f150:	ret
	...

000000000040f160 <__swc_fn_4fa09e82_000172_06b64c88>:
  40f160:	xor    eax,eax
  40f162:	mov    edx,0x1
  40f167:	lock cmpxchg QWORD PTR [rcx],rdx
  40f16c:	test   rax,rax
  40f16f:	jne    40f172 <__swc_fn_4fa09e82_000172_06b64c88+0x12>
  40f171:	ret
  40f172:	cs nop WORD PTR [rax+rax*1+0x0]
  40f17c:	nop    DWORD PTR [rax+0x0]
  40f180:	mov    rax,QWORD PTR [rcx]
  40f183:	test   rax,rax
  40f186:	je     40f160 <__swc_fn_4fa09e82_000172_06b64c88>
  40f188:	jmp    40f180 <__swc_fn_4fa09e82_000172_06b64c88+0x20>
  40f18a:	add    BYTE PTR [rax],al
  40f18c:	add    BYTE PTR [rax],al
	...

000000000040f190 <__swc_fn_4fa09e82_000175_738eec22>:
  40f190:	push   rsi
  40f191:	push   rdi
  40f192:	sub    rsp,0x38
  40f196:	mov    rsi,rcx
  40f199:	call   411f90 <__swc_fn_4fa09e82_000170_aabbfb4c>
  40f19e:	mov    rdi,rax
  40f1a1:	call   411720 <__swc_fn_4fa09e82_000131_d2d78689>
  40f1a6:	mov    r8,rax
  40f1a9:	mov    rcx,rdi
  40f1ac:	call   40f160 <__swc_fn_4fa09e82_000172_06b64c88>
  40f1b1:	mov    rax,QWORD PTR [rdi+0x8]
  40f1b5:	test   rax,rax
  40f1b8:	je     40f1f5 <__swc_fn_4fa09e82_000175_738eec22+0x65>
  40f1ba:	nop    WORD PTR [rax+rax*1+0x0]
  40f1c0:	cmp    rax,rsi
  40f1c3:	je     40f1f5 <__swc_fn_4fa09e82_000175_738eec22+0x65>
  40f1c5:	mov    r9,QWORD PTR [rax]
  40f1c8:	cmp    QWORD PTR [rax+0x20],r8
  40f1cc:	jne    40f1ed <__swc_fn_4fa09e82_000175_738eec22+0x5d>
  40f1ce:	mov    rcx,rdi
  40f1d1:	mov    rdx,rax
  40f1d4:	mov    QWORD PTR [rsp+0x28],r8
  40f1d9:	mov    QWORD PTR [rsp+0x30],r9
  40f1de:	call   40b740 <__swc_fn_4fa09e82_000174_156cb9fe>
  40f1e3:	mov    r8,QWORD PTR [rsp+0x28]
  40f1e8:	mov    r9,QWORD PTR [rsp+0x30]
  40f1ed:	mov    rax,r9
  40f1f0:	test   r9,r9
  40f1f3:	jne    40f1c0 <__swc_fn_4fa09e82_000175_738eec22+0x30>
  40f1f5:	xor    eax,eax
  40f1f7:	mov    QWORD PTR [rdi],rax
  40f1fa:	add    rsp,0x38
  40f1fe:	pop    rdi
  40f1ff:	pop    rsi
  40f200:	ret
	...

000000000040f210 <__swc_fn_4fa09e82_000178_1ca87929>:
  40f210:	push   rdi
  40f211:	push   rsi
  40f212:	sub    rsp,0xb8
  40f219:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40f21f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40f225:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40f22b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40f231:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40f237:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40f23d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40f243:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40f24c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40f255:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40f25e:	vxorps xmm0,xmm0,xmm0
  40f262:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f268:	mov    edi,0x1
  40f26d:	lea    rsi,[rsp+0x8]
  40f272:	xor    eax,eax
  40f274:	call   407130 <clock_gettime@plt>
  40f279:	vxorpd xmm0,xmm0,xmm0
  40f27d:	mov    rax,QWORD PTR [rsp+0x8]
  40f282:	vcvtsi2sd xmm0,xmm0,rax
  40f287:	vxorpd xmm1,xmm1,xmm1
  40f28b:	mov    rax,QWORD PTR [rsp+0x10]
  40f290:	vcvtsi2sd xmm1,xmm1,rax
  40f295:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x466b]        # 413908 <__swc_rdata_base_4fa09e82+0x7f8>
  40f29d:	vaddsd xmm0,xmm0,xmm1
  40f2a1:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40f2a7:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40f2ad:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40f2b3:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40f2b9:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40f2bf:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40f2c5:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40f2cb:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40f2d4:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40f2dd:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40f2e6:	add    rsp,0xb8
  40f2ed:	pop    rsi
  40f2ee:	pop    rdi
  40f2ef:	ret
	...

000000000040f300 <__swc_fn_4fa09e82_000002_390d5093>:
  40f300:	sub    rsp,0x8
  40f304:	call   411070 <__swc_fn_4fa09e82_000110_aa570b2b>
  40f309:	mov    rcx,rax
  40f30c:	test   rax,rax
  40f30f:	je     40f336 <__swc_fn_4fa09e82_000002_390d5093+0x36>
  40f311:	lea    rdx,[rip+0x14d28]        # 424040 <__swc_bss_base_4fa09e82>
  40f318:	mov    r8,QWORD PTR [rip+0x14d21]        # 424040 <__swc_bss_base_4fa09e82>
  40f31f:	nop
  40f320:	lea    r9,[r8+0x1]
  40f324:	mov    rax,r8
  40f327:	lock cmpxchg QWORD PTR [rdx],r9
  40f32c:	cmp    rax,r8
  40f32f:	je     40f336 <__swc_fn_4fa09e82_000002_390d5093+0x36>
  40f331:	mov    r8,rax
  40f334:	jmp    40f320 <__swc_fn_4fa09e82_000002_390d5093+0x20>
  40f336:	mov    rax,rcx
  40f339:	add    rsp,0x8
  40f33d:	ret
	...

000000000040f340 <__swc_fn_4fa09e82_000005_bcc5b80b>:
  40f340:	mov    r8d,edx
  40f343:	xor    eax,eax
  40f345:	tzcnt  eax,edx
  40f349:	shrx   r9d,edx,eax
  40f34e:	mov    DWORD PTR [rcx+0x2c],edx
  40f351:	xor    eax,eax
  40f353:	tzcnt  eax,edx
  40f357:	mov    BYTE PTR [rcx+0x38],al
  40f35a:	mov    eax,0xffffffff
  40f35f:	xor    edx,edx
  40f361:	div    r8d
  40f364:	mov    DWORD PTR [rcx+0x34],eax
  40f367:	mov    eax,r9d
  40f36a:	mov    edx,r9d
  40f36d:	imul   edx,r9d
  40f371:	mov    r8d,0x2
  40f377:	sub    r8d,edx
  40f37a:	imul   eax,r8d
  40f37e:	mov    edx,r9d
  40f381:	imul   edx,eax
  40f384:	mov    r8d,0x2
  40f38a:	sub    r8d,edx
  40f38d:	imul   eax,r8d
  40f391:	mov    edx,r9d
  40f394:	imul   edx,eax
  40f397:	mov    r8d,0x2
  40f39d:	sub    r8d,edx
  40f3a0:	imul   eax,r8d
  40f3a4:	mov    edx,r9d
  40f3a7:	imul   edx,eax
  40f3aa:	mov    r8d,0x2
  40f3b0:	sub    r8d,edx
  40f3b3:	imul   eax,r8d
  40f3b7:	imul   r9d,eax
  40f3bb:	mov    edx,0x2
  40f3c0:	sub    edx,r9d
  40f3c3:	imul   eax,edx
  40f3c6:	mov    DWORD PTR [rcx+0x30],eax
  40f3c9:	ret
  40f3ca:	add    BYTE PTR [rax],al
  40f3cc:	add    BYTE PTR [rax],al
	...

000000000040f3d0 <__swc_fn_4fa09e82_000008_578f1784>:
  40f3d0:	xor    eax,eax
  40f3d2:	mov    DWORD PTR [rcx+0x68],eax
  40f3d5:	ret
	...

000000000040f3e0 <__swc_fn_4fa09e82_000011_e75d466d>:
  40f3e0:	mov    eax,DWORD PTR [rcx+0x28]
  40f3e3:	shlx   eax,edx,eax
  40f3e8:	shl    rax,0x10
  40f3ec:	lea    rdx,[rcx+rax*1]
  40f3f0:	lea    rax,[rcx+0x3000]
  40f3f7:	cmp    rdx,rax
  40f3fa:	cmovae rax,rdx
  40f3fe:	ret
	...

000000000040f400 <__swc_fn_4fa09e82_000014_1acdaf22>:
  40f400:	push   rsi
  40f401:	push   rdi
  40f402:	push   r12
  40f404:	push   r13
  40f406:	push   r14
  40f408:	mov    rsi,rdx
  40f40b:	mov    rdi,rcx
  40f40e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40f412:	mov    ecx,DWORD PTR [rdi+0x28]
  40f415:	shr    dl,cl
  40f417:	mov    r12d,0x1
  40f41d:	mov    ecx,edx
  40f41f:	shl    r12,cl
  40f422:	mov    r13d,DWORD PTR [rsi+0x3c]
  40f426:	rex mov BYTE PTR [rsi+0x3b],0x0
  40f42b:	mov    QWORD PTR [rsi+0x40],0x0
  40f433:	mov    QWORD PTR [rsi],0x0
  40f43a:	mov    rax,QWORD PTR [rsi+0x10]
  40f43e:	mov    QWORD PTR [rsi+0x20],rax
  40f442:	lea    r14,[rip+0x14bff]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  40f449:	mov    rax,QWORD PTR [r14]
  40f44c:	shr    rax,0x2
  40f450:	mov    rcx,rax
  40f453:	cmp    rax,0x800000
  40f45a:	mov    eax,0x800000
  40f45f:	cmovb  rcx,rax
  40f463:	lea    r8,[rip+0x14bee]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40f46a:	mov    rax,QWORD PTR [r8]
  40f46d:	mov    r9,rax
  40f470:	lea    r10,[r9+r13*1]
  40f474:	cmp    r10,rcx
  40f477:	ja     40f49b <__swc_fn_4fa09e82_000014_1acdaf22+0x9b>
  40f479:	mov    rax,r9
  40f47c:	lock cmpxchg QWORD PTR [r8],r10
  40f481:	cmp    rax,r9
  40f484:	je     40f48b <__swc_fn_4fa09e82_000014_1acdaf22+0x8b>
  40f486:	mov    r9,rax
  40f489:	jmp    40f470 <__swc_fn_4fa09e82_000014_1acdaf22+0x70>
  40f48b:	mov    rcx,rdi
  40f48e:	mov    rdx,r12
  40f491:	call   40c290 <__swc_fn_4fa09e82_000016_89da4d6e>
  40f496:	jmp    40f51d <__swc_fn_4fa09e82_000014_1acdaf22+0x11d>
  40f49b:	mov    rcx,rdi
  40f49e:	movzx  edx,dl
  40f4a1:	call   40f3e0 <__swc_fn_4fa09e82_000011_e75d466d>
  40f4a6:	test   r13,r13
  40f4a9:	je     40f516 <__swc_fn_4fa09e82_000014_1acdaf22+0x116>
  40f4af:	mov    rcx,rax
  40f4b2:	mov    rdx,r13
  40f4b5:	call   4111f0 <__swc_fn_4fa09e82_000113_cb2656be>
  40f4ba:	mov    rcx,QWORD PTR [rip+0x14b87]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  40f4c1:	cs nop WORD PTR [rax+rax*1+0x0]
  40f4cb:	nop    DWORD PTR [rax+rax*1+0x0]
  40f4d0:	mov    rdx,rcx
  40f4d3:	sub    rdx,r13
  40f4d6:	mov    rax,rcx
  40f4d9:	lock cmpxchg QWORD PTR [r14],rdx
  40f4de:	cmp    rax,rcx
  40f4e1:	je     40f4e8 <__swc_fn_4fa09e82_000014_1acdaf22+0xe8>
  40f4e3:	mov    rcx,rax
  40f4e6:	jmp    40f4d0 <__swc_fn_4fa09e82_000014_1acdaf22+0xd0>
  40f4e8:	lea    rcx,[rip+0x14b71]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  40f4ef:	mov    rdx,QWORD PTR [rip+0x14b6a]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  40f4f6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f500:	lea    r8,[rdx+0x1]
  40f504:	mov    rax,rdx
  40f507:	lock cmpxchg QWORD PTR [rcx],r8
  40f50c:	cmp    rax,rdx
  40f50f:	je     40f516 <__swc_fn_4fa09e82_000014_1acdaf22+0x116>
  40f511:	mov    rdx,rax
  40f514:	jmp    40f500 <__swc_fn_4fa09e82_000014_1acdaf22+0x100>
  40f516:	mov    DWORD PTR [rsi+0x3c],0x0
  40f51d:	mov    rcx,rdi
  40f520:	mov    rdx,r12
  40f523:	call   407600 <__swc_fn_4fa09e82_000018_e2e8e4b0>
  40f528:	pop    r14
  40f52a:	pop    r13
  40f52c:	pop    r12
  40f52e:	pop    rdi
  40f52f:	pop    rsi
  40f530:	ret
	...

000000000040f540 <__swc_fn_4fa09e82_000017_e238d24c>:
  40f540:	mov    r8,QWORD PTR [rcx+0x48]
  40f544:	test   r8,rdx
  40f547:	je     40f578 <__swc_fn_4fa09e82_000017_e238d24c+0x38>
  40f549:	nop    DWORD PTR [rax+0x0]
  40f550:	mov    rax,rdx
  40f553:	not    rax
  40f556:	mov    r9,r8
  40f559:	and    r9,rax
  40f55c:	mov    rax,r8
  40f55f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40f565:	cmp    rax,r8
  40f568:	jne    40f570 <__swc_fn_4fa09e82_000017_e238d24c+0x30>
  40f56a:	mov    eax,0x1
  40f56f:	ret
  40f570:	mov    r8,rax
  40f573:	test   rax,rdx
  40f576:	jne    40f550 <__swc_fn_4fa09e82_000017_e238d24c+0x10>
  40f578:	xor    eax,eax
  40f57a:	ret
  40f57b:	add    BYTE PTR [rax],al
  40f57d:	add    BYTE PTR [rax],al
	...

000000000040f580 <__swc_fn_4fa09e82_000020_4135c89a>:
  40f580:	push   rsi
  40f581:	push   rdi
  40f582:	push   r12
  40f584:	push   r13
  40f586:	sub    rsp,0x8
  40f58a:	mov    rsi,rdx
  40f58d:	mov    rdi,rcx
  40f590:	lea    r12,[rip+0x14c59]        # 4241f0 <__swc_bss_base_4fa09e82+0x1b0>
  40f597:	mov    rcx,r12
  40f59a:	call   40e760 <__swc_fn_4fa09e82_000136_1fec60ac>
  40f59f:	xor    eax,eax
  40f5a1:	mov    rcx,QWORD PTR [rip+0x14c50]        # 4241f8 <__swc_bss_base_4fa09e82+0x1b8>
  40f5a8:	mov    r13,rcx
  40f5ab:	test   r13,r13
  40f5ae:	je     40f5fb <__swc_fn_4fa09e82_000020_4135c89a+0x7b>
  40f5b0:	mov    rcx,QWORD PTR [r13+0x10]
  40f5b4:	cmp    DWORD PTR [r13+0x28],esi
  40f5b8:	jne    40f5f0 <__swc_fn_4fa09e82_000020_4135c89a+0x70>
  40f5ba:	test   rax,rax
  40f5bd:	jne    40f5c8 <__swc_fn_4fa09e82_000020_4135c89a+0x48>
  40f5bf:	mov    QWORD PTR [rip+0x14c32],rcx        # 4241f8 <__swc_bss_base_4fa09e82+0x1b8>
  40f5c6:	jmp    40f5cc <__swc_fn_4fa09e82_000020_4135c89a+0x4c>
  40f5c8:	mov    QWORD PTR [rax+0x10],rcx
  40f5cc:	vxorps xmm0,xmm0,xmm0
  40f5d0:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40f5d6:	mov    QWORD PTR [r13+0x8],rdi
  40f5da:	mov    rcx,r12
  40f5dd:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40f5e2:	mov    rax,r13
  40f5e5:	add    rsp,0x8
  40f5e9:	pop    r13
  40f5eb:	pop    r12
  40f5ed:	pop    rdi
  40f5ee:	pop    rsi
  40f5ef:	ret
  40f5f0:	mov    rax,r13
  40f5f3:	mov    r13,rcx
  40f5f6:	test   rcx,rcx
  40f5f9:	jne    40f5b0 <__swc_fn_4fa09e82_000020_4135c89a+0x30>
  40f5fb:	mov    ecx,esi
  40f5fd:	call   40c2c0 <__swc_fn_4fa09e82_000019_60e50998>
  40f602:	mov    rsi,rax
  40f605:	test   rax,rax
  40f608:	jne    40f61f <__swc_fn_4fa09e82_000020_4135c89a+0x9f>
  40f60a:	mov    rcx,r12
  40f60d:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40f612:	xor    eax,eax
  40f614:	add    rsp,0x8
  40f618:	pop    r13
  40f61a:	pop    r12
  40f61c:	pop    rdi
  40f61d:	pop    rsi
  40f61e:	ret
  40f61f:	mov    QWORD PTR [rsi+0x8],rdi
  40f623:	mov    rcx,r12
  40f626:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40f62b:	mov    rax,rsi
  40f62e:	add    rsp,0x8
  40f632:	pop    r13
  40f634:	pop    r12
  40f636:	pop    rdi
  40f637:	pop    rsi
  40f638:	ret
  40f639:	add    BYTE PTR [rax],al
  40f63b:	add    BYTE PTR [rax],al
  40f63d:	add    BYTE PTR [rax],al
	...

000000000040f640 <__swc_fn_4fa09e82_000023_7e9350e1>:
  40f640:	vxorps xmm0,xmm0,xmm0
  40f644:	xor    eax,eax
  40f646:	cs nop WORD PTR [rax+rax*1+0x0]
  40f650:	cs nop WORD PTR [rax+rax*1+0x0]
  40f65a:	nop    WORD PTR [rax+rax*1+0x0]
  40f660:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40f665:	add    rax,0x10
  40f669:	cmp    rax,0x2b00
  40f670:	jne    40f660 <__swc_fn_4fa09e82_000023_7e9350e1+0x20>
  40f672:	ret
	...

000000000040f680 <__swc_fn_4fa09e82_000026_7e9350e1>:
  40f680:	vxorps xmm0,xmm0,xmm0
  40f684:	vmovups XMMWORD PTR [rcx],xmm0
  40f688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f68d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f692:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f697:	ret
	...

000000000040f6a0 <__swc_fn_4fa09e82_000029_7e9350e1>:
  40f6a0:	vxorps xmm0,xmm0,xmm0
  40f6a4:	vmovups XMMWORD PTR [rcx],xmm0
  40f6a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f6ad:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f6b2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f6b7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40f6bc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40f6c1:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40f6c6:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40f6cb:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40f6d3:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40f6db:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40f6e3:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40f6eb:	mov    QWORD PTR [rcx+0xc0],0x0
  40f6f6:	ret
	...

000000000040f700 <__swc_fn_4fa09e82_000032_8c89735c>:
  40f700:	push   rsi
  40f701:	push   rdi
  40f702:	sub    rsp,0x8
  40f706:	mov    rsi,rcx
  40f709:	lea    rdi,[rip+0x128f0]        # 422000 <__swc_data_base_4fa09e82>
  40f710:	mov    rax,QWORD PTR [rdi]
  40f713:	cmp    rax,0xffffffffffffffff
  40f717:	je     40f71e <__swc_fn_4fa09e82_000032_8c89735c+0x1e>
  40f719:	mov    rdi,rax
  40f71c:	jmp    40f74b <__swc_fn_4fa09e82_000032_8c89735c+0x4b>
  40f71e:	call   40e440 <__swc_fn_4fa09e82_000124_e9227a3e>
  40f723:	mov    rcx,rax
  40f726:	cmp    rax,0xffffffffffffffff
  40f72a:	je     40f75c <__swc_fn_4fa09e82_000032_8c89735c+0x5c>
  40f72c:	mov    rax,0xffffffffffffffff
  40f733:	lock cmpxchg QWORD PTR [rdi],rcx
  40f738:	cmp    rax,0xffffffffffffffff
  40f73c:	je     40f748 <__swc_fn_4fa09e82_000032_8c89735c+0x48>
  40f73e:	mov    rdi,rax
  40f741:	call   4115d0 <__swc_fn_4fa09e82_000125_df97aa0a>
  40f746:	jmp    40f74b <__swc_fn_4fa09e82_000032_8c89735c+0x4b>
  40f748:	mov    rdi,rcx
  40f74b:	cmp    rdi,0xffffffffffffffff
  40f74f:	je     40f75c <__swc_fn_4fa09e82_000032_8c89735c+0x5c>
  40f751:	mov    rcx,rdi
  40f754:	mov    rdx,rsi
  40f757:	call   409af0 <__swc_fn_4fa09e82_000126_e19c72b3>
  40f75c:	add    rsp,0x8
  40f760:	pop    rdi
  40f761:	pop    rsi
  40f762:	ret
	...

000000000040f770 <__swc_fn_4fa09e82_000035_6105596e>:
  40f770:	sub    rsp,0x38
  40f774:	mov    rax,rdx
  40f777:	test   dl,dl
  40f779:	jne    40f791 <__swc_fn_4fa09e82_000035_6105596e+0x21>
  40f77b:	mov    rax,r8
  40f77e:	test   r8b,r8b
  40f781:	cmove  eax,r9d
  40f785:	test   al,al
  40f787:	cmove  eax,r10d
  40f78b:	test   al,al
  40f78d:	cmove  eax,r11d
  40f791:	test   al,al
  40f793:	jne    40f79a <__swc_fn_4fa09e82_000035_6105596e+0x2a>
  40f795:	add    rsp,0x38
  40f799:	ret
  40f79a:	lea    rcx,[rip+0x396f]        # 413110 <__swc_rdata_base_4fa09e82>
  40f7a1:	vmovups xmm0,XMMWORD PTR [rip+0x3977]        # 413120 <__swc_rdata_base_4fa09e82+0x10>
  40f7a9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f7af:	vmovups xmm0,XMMWORD PTR [rip+0x3979]        # 413130 <__swc_rdata_base_4fa09e82+0x20>
  40f7b7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f7bd:	vmovups xmm0,XMMWORD PTR [rip+0x397b]        # 413140 <__swc_rdata_base_4fa09e82+0x30>
  40f7c5:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40f7cb:	lea    rdx,[rsp+0x8]
  40f7d0:	call   40dee0 <__swc_fn_4fa09e82_000103_2ed36338>
  40f7d5:	jmp    40f795 <__swc_fn_4fa09e82_000035_6105596e+0x25>
	...

000000000040f7e0 <__swc_fn_4fa09e82_000038_c7591393>:
  40f7e0:	sub    rsp,0x8
  40f7e4:	mov    eax,0x1000
  40f7e9:	test   eax,eax
  40f7eb:	mov    r8d,0x8
  40f7f1:	cmove  eax,r8d
  40f7f5:	dec    rax
  40f7f8:	mov    r8,0xffffffffffffffff
  40f7ff:	sub    r8,rax
  40f802:	cmp    rdx,r8
  40f805:	ja     40f815 <__swc_fn_4fa09e82_000038_c7591393+0x35>
  40f807:	add    rdx,rax
  40f80a:	not    rax
  40f80d:	mov    r8,rdx
  40f810:	and    r8,rax
  40f813:	jne    40f81c <__swc_fn_4fa09e82_000038_c7591393+0x3c>
  40f815:	xor    eax,eax
  40f817:	add    rsp,0x8
  40f81b:	ret
  40f81c:	mov    rdx,r8
  40f81f:	call   40c5e0 <__swc_fn_4fa09e82_000037_92e867c2>
  40f824:	add    rsp,0x8
  40f828:	ret
  40f829:	add    BYTE PTR [rax],al
  40f82b:	add    BYTE PTR [rax],al
  40f82d:	add    BYTE PTR [rax],al
	...

000000000040f830 <__swc_fn_4fa09e82_000041_ed1cda78>:
  40f830:	push   rsi
  40f831:	push   rdi
  40f832:	sub    rsp,0x8
  40f836:	mov    rsi,rdx
  40f839:	mov    rdi,rcx
  40f83c:	test   rdx,rdx
  40f83f:	je     40f85b <__swc_fn_4fa09e82_000041_ed1cda78+0x2b>
  40f841:	xor    ecx,ecx
  40f843:	call   407720 <__swc_fn_4fa09e82_000033_7d7574b6>
  40f848:	mov    rax,QWORD PTR [rsi]
  40f84b:	test   rax,rax
  40f84e:	je     40f85b <__swc_fn_4fa09e82_000041_ed1cda78+0x2b>
  40f850:	mov    rcx,rax
  40f853:	mov    rdx,rsi
  40f856:	call   407840 <__swc_fn_4fa09e82_000042_70d5ab54>
  40f85b:	mov    rcx,rdi
  40f85e:	call   40c640 <__swc_fn_4fa09e82_000040_7a225310>
  40f863:	mov    rsi,rax
  40f866:	test   rax,rax
  40f869:	jne    40f874 <__swc_fn_4fa09e82_000041_ed1cda78+0x44>
  40f86b:	xor    eax,eax
  40f86d:	add    rsp,0x8
  40f871:	pop    rdi
  40f872:	pop    rsi
  40f873:	ret
  40f874:	mov    rcx,rsi
  40f877:	call   407720 <__swc_fn_4fa09e82_000033_7d7574b6>
  40f87c:	mov    rax,rsi
  40f87f:	add    rsp,0x8
  40f883:	pop    rdi
  40f884:	pop    rsi
  40f885:	ret
	...

000000000040f890 <__swc_fn_4fa09e82_000044_cac7f504>:
  40f890:	movzx  eax,BYTE PTR [r8+0x39]
  40f895:	lea    rax,[rax+rax*4]
  40f899:	lea    rax,[rdx+rax*8+0x28]
  40f89e:	mov    ecx,DWORD PTR [r8+0x6c]
  40f8a2:	test   ecx,ecx
  40f8a4:	je     40f8dd <__swc_fn_4fa09e82_000044_cac7f504+0x4d>
  40f8a6:	mov    rcx,QWORD PTR [r8+0x50]
  40f8aa:	test   rcx,rcx
  40f8ad:	je     40f8b9 <__swc_fn_4fa09e82_000044_cac7f504+0x29>
  40f8af:	mov    rax,QWORD PTR [r8+0x48]
  40f8b3:	mov    QWORD PTR [rcx+0x48],rax
  40f8b7:	jmp    40f8c1 <__swc_fn_4fa09e82_000044_cac7f504+0x31>
  40f8b9:	mov    rcx,QWORD PTR [r8+0x48]
  40f8bd:	mov    QWORD PTR [rax+0x18],rcx
  40f8c1:	mov    rax,QWORD PTR [r8+0x48]
  40f8c5:	test   rax,rax
  40f8c8:	je     40f8d2 <__swc_fn_4fa09e82_000044_cac7f504+0x42>
  40f8ca:	mov    rcx,QWORD PTR [r8+0x50]
  40f8ce:	mov    QWORD PTR [rax+0x50],rcx
  40f8d2:	vxorps xmm0,xmm0,xmm0
  40f8d6:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40f8dc:	ret
  40f8dd:	mov    rcx,QWORD PTR [r8+0x50]
  40f8e1:	test   rcx,rcx
  40f8e4:	je     40f8f0 <__swc_fn_4fa09e82_000044_cac7f504+0x60>
  40f8e6:	mov    rdx,QWORD PTR [r8+0x48]
  40f8ea:	mov    QWORD PTR [rcx+0x48],rdx
  40f8ee:	jmp    40f8f8 <__swc_fn_4fa09e82_000044_cac7f504+0x68>
  40f8f0:	mov    rcx,QWORD PTR [r8+0x48]
  40f8f4:	mov    QWORD PTR [rax+0x8],rcx
  40f8f8:	mov    rcx,QWORD PTR [r8+0x48]
  40f8fc:	test   rcx,rcx
  40f8ff:	je     40f90b <__swc_fn_4fa09e82_000044_cac7f504+0x7b>
  40f901:	mov    rdx,QWORD PTR [r8+0x50]
  40f905:	mov    QWORD PTR [rcx+0x50],rdx
  40f909:	jmp    40f913 <__swc_fn_4fa09e82_000044_cac7f504+0x83>
  40f90b:	mov    rcx,QWORD PTR [r8+0x50]
  40f90f:	mov    QWORD PTR [rax+0x10],rcx
  40f913:	cmp    QWORD PTR [rax],r8
  40f916:	jne    40f91f <__swc_fn_4fa09e82_000044_cac7f504+0x8f>
  40f918:	mov    QWORD PTR [rax],0x0
  40f91f:	vxorps xmm0,xmm0,xmm0
  40f923:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40f929:	ret
  40f92a:	add    BYTE PTR [rax],al
  40f92c:	add    BYTE PTR [rax],al
	...

000000000040f930 <__swc_fn_4fa09e82_000047_3d3eceb4>:
  40f930:	sub    rsp,0x8
  40f934:	mov    r9,r8
  40f937:	mov    r10,rdx
  40f93a:	call   40f890 <__swc_fn_4fa09e82_000044_cac7f504>
  40f93f:	mov    DWORD PTR [r9+0x6c],0x0
  40f947:	movzx  eax,BYTE PTR [r9+0x39]
  40f94c:	lea    rax,[rax+rax*4]
  40f950:	lea    rax,[r10+rax*8+0x28]
  40f955:	mov    rcx,QWORD PTR [rax+0x10]
  40f959:	mov    QWORD PTR [r9+0x50],rcx
  40f95d:	mov    QWORD PTR [r9+0x48],0x0
  40f965:	mov    rcx,QWORD PTR [rax+0x10]
  40f969:	test   rcx,rcx
  40f96c:	je     40f974 <__swc_fn_4fa09e82_000047_3d3eceb4+0x44>
  40f96e:	mov    QWORD PTR [rcx+0x48],r9
  40f972:	jmp    40f978 <__swc_fn_4fa09e82_000047_3d3eceb4+0x48>
  40f974:	mov    QWORD PTR [rax+0x8],r9
  40f978:	mov    QWORD PTR [rax+0x10],r9
  40f97c:	add    rsp,0x8
  40f980:	ret
	...

000000000040f9a0 <__swc_fn_4fa09e82_000050_e33921d7>:
  40f9a0:	push   rsi
  40f9a1:	push   rdi
  40f9a2:	push   r12
  40f9a4:	push   r13
  40f9a6:	push   r14
  40f9a8:	push   r15
  40f9aa:	sub    rsp,0x1f8
  40f9b1:	mov    esi,r8d
  40f9b4:	mov    QWORD PTR [rsp+0x1e8],rsi
  40f9bc:	mov    rdi,rcx
  40f9bf:	mov    r12,rdx
  40f9c2:	lea    r13,[rsi+rsi*4]
  40f9c6:	lea    r13,[rdx+r13*8+0x28]
  40f9cb:	call   407ca0 <__swc_fn_4fa09e82_000048_18a95c9b>
  40f9d0:	add    DWORD PTR [r12+0x24],0x1
  40f9d6:	test   BYTE PTR [r12+0x24],0x3f
  40f9dc:	jne    40f9e6 <__swc_fn_4fa09e82_000050_e33921d7+0x46>
  40f9de:	mov    rcx,rdi
  40f9e1:	call   40c7c0 <__swc_fn_4fa09e82_000049_781177b4>
  40f9e6:	mov    rax,QWORD PTR [r13+0x8]
  40f9ea:	mov    r14,rax
  40f9ed:	nop    DWORD PTR [rax]
  40f9f0:	test   r14,r14
  40f9f3:	jne    40fa02 <__swc_fn_4fa09e82_000050_e33921d7+0x62>
  40f9f5:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40f9fd:	jmp    40fb09 <__swc_fn_4fa09e82_000050_e33921d7+0x169>
  40fa02:	mov    r15,QWORD PTR [r14+0x48]
  40fa06:	mov    rcx,r14
  40fa09:	call   4073f0 <__swc_fn_4fa09e82_000009_2417e911>
  40fa0e:	mov    rax,QWORD PTR [r14]
  40fa11:	test   rax,rax
  40fa14:	je     40fa26 <__swc_fn_4fa09e82_000050_e33921d7+0x86>
  40fa16:	mov    rcx,QWORD PTR [rax]
  40fa19:	mov    QWORD PTR [r14],rcx
  40fa1c:	add    DWORD PTR [r14+0x28],0x1
  40fa21:	mov    rsi,rax
  40fa24:	jmp    40fa45 <__swc_fn_4fa09e82_000050_e33921d7+0xa5>
  40fa26:	mov    rax,QWORD PTR [r14+0x18]
  40fa2a:	cmp    QWORD PTR [r14+0x20],rax
  40fa2e:	jae    40fa43 <__swc_fn_4fa09e82_000050_e33921d7+0xa3>
  40fa30:	mov    rsi,QWORD PTR [r14+0x20]
  40fa34:	mov    eax,DWORD PTR [r14+0x2c]
  40fa38:	add    QWORD PTR [r14+0x20],rax
  40fa3c:	add    DWORD PTR [r14+0x28],0x1
  40fa41:	jmp    40fa45 <__swc_fn_4fa09e82_000050_e33921d7+0xa5>
  40fa43:	xor    esi,esi
  40fa45:	test   rsi,rsi
  40fa48:	jne    40fa8d <__swc_fn_4fa09e82_000050_e33921d7+0xed>
  40fa4a:	mov    rcx,r14
  40fa4d:	call   407320 <__swc_fn_4fa09e82_000006_12cb36a2>
  40fa52:	test   al,al
  40fa54:	je     40fa8d <__swc_fn_4fa09e82_000050_e33921d7+0xed>
  40fa56:	mov    rax,QWORD PTR [r14]
  40fa59:	test   rax,rax
  40fa5c:	je     40fa6b <__swc_fn_4fa09e82_000050_e33921d7+0xcb>
  40fa5e:	mov    rcx,QWORD PTR [rax]
  40fa61:	mov    QWORD PTR [r14],rcx
  40fa64:	add    DWORD PTR [r14+0x28],0x1
  40fa69:	jmp    40fa8a <__swc_fn_4fa09e82_000050_e33921d7+0xea>
  40fa6b:	mov    rax,QWORD PTR [r14+0x18]
  40fa6f:	cmp    QWORD PTR [r14+0x20],rax
  40fa73:	jae    40fa88 <__swc_fn_4fa09e82_000050_e33921d7+0xe8>
  40fa75:	mov    rax,QWORD PTR [r14+0x20]
  40fa79:	mov    ecx,DWORD PTR [r14+0x2c]
  40fa7d:	add    QWORD PTR [r14+0x20],rcx
  40fa81:	add    DWORD PTR [r14+0x28],0x1
  40fa86:	jmp    40fa8a <__swc_fn_4fa09e82_000050_e33921d7+0xea>
  40fa88:	xor    eax,eax
  40fa8a:	mov    rsi,rax
  40fa8d:	test   rsi,rsi
  40fa90:	jne    40fae3 <__swc_fn_4fa09e82_000050_e33921d7+0x143>
  40fa92:	mov    rcx,rdi
  40fa95:	mov    rdx,r12
  40fa98:	mov    r8,r14
  40fa9b:	call   40c720 <__swc_fn_4fa09e82_000046_49300800>
  40faa0:	test   al,al
  40faa2:	jne    40fae3 <__swc_fn_4fa09e82_000050_e33921d7+0x143>
  40faa4:	mov    rcx,r14
  40faa7:	call   4073f0 <__swc_fn_4fa09e82_000009_2417e911>
  40faac:	mov    rax,QWORD PTR [r14]
  40faaf:	test   rax,rax
  40fab2:	je     40fac1 <__swc_fn_4fa09e82_000050_e33921d7+0x121>
  40fab4:	mov    rcx,QWORD PTR [rax]
  40fab7:	mov    QWORD PTR [r14],rcx
  40faba:	add    DWORD PTR [r14+0x28],0x1
  40fabf:	jmp    40fae0 <__swc_fn_4fa09e82_000050_e33921d7+0x140>
  40fac1:	mov    rax,QWORD PTR [r14+0x18]
  40fac5:	cmp    QWORD PTR [r14+0x20],rax
  40fac9:	jae    40fade <__swc_fn_4fa09e82_000050_e33921d7+0x13e>
  40facb:	mov    rax,QWORD PTR [r14+0x20]
  40facf:	mov    ecx,DWORD PTR [r14+0x2c]
  40fad3:	add    QWORD PTR [r14+0x20],rcx
  40fad7:	add    DWORD PTR [r14+0x28],0x1
  40fadc:	jmp    40fae0 <__swc_fn_4fa09e82_000050_e33921d7+0x140>
  40fade:	xor    eax,eax
  40fae0:	mov    rsi,rax
  40fae3:	test   rsi,rsi
  40fae6:	je     40fb01 <__swc_fn_4fa09e82_000050_e33921d7+0x161>
  40fae8:	mov    QWORD PTR [r13+0x0],r14
  40faec:	mov    rax,rsi
  40faef:	add    rsp,0x1f8
  40faf6:	pop    r15
  40faf8:	pop    r14
  40fafa:	pop    r13
  40fafc:	pop    r12
  40fafe:	pop    rdi
  40faff:	pop    rsi
  40fb00:	ret
  40fb01:	mov    r14,r15
  40fb04:	jmp    40f9f0 <__swc_fn_4fa09e82_000050_e33921d7+0x50>
  40fb09:	cs nop WORD PTR [rax+rax*1+0x0]
  40fb13:	cs nop WORD PTR [rax+rax*1+0x0]
  40fb1d:	nop    DWORD PTR [rax]
  40fb20:	mov    rcx,rdi
  40fb23:	mov    rdx,r12
  40fb26:	mov    r8d,esi
  40fb29:	call   4079e0 <__swc_fn_4fa09e82_000045_06cec934>
  40fb2e:	mov    r14,rax
  40fb31:	test   rax,rax
  40fb34:	jne    40fb4a <__swc_fn_4fa09e82_000050_e33921d7+0x1aa>
  40fb36:	xor    eax,eax
  40fb38:	add    rsp,0x1f8
  40fb3f:	pop    r15
  40fb41:	pop    r14
  40fb43:	pop    r13
  40fb45:	pop    r12
  40fb47:	pop    rdi
  40fb48:	pop    rsi
  40fb49:	ret
  40fb4a:	mov    QWORD PTR [r13+0x0],r14
  40fb4e:	mov    rax,QWORD PTR [r14]
  40fb51:	test   rax,rax
  40fb54:	je     40fb66 <__swc_fn_4fa09e82_000050_e33921d7+0x1c6>
  40fb56:	mov    rcx,QWORD PTR [rax]
  40fb59:	mov    QWORD PTR [r14],rcx
  40fb5c:	add    DWORD PTR [r14+0x28],0x1
  40fb61:	mov    r15,rax
  40fb64:	jmp    40fb86 <__swc_fn_4fa09e82_000050_e33921d7+0x1e6>
  40fb66:	mov    rax,QWORD PTR [r14+0x18]
  40fb6a:	cmp    QWORD PTR [r14+0x20],rax
  40fb6e:	jae    40fb83 <__swc_fn_4fa09e82_000050_e33921d7+0x1e3>
  40fb70:	mov    r15,QWORD PTR [r14+0x20]
  40fb74:	mov    eax,DWORD PTR [r14+0x2c]
  40fb78:	add    QWORD PTR [r14+0x20],rax
  40fb7c:	add    DWORD PTR [r14+0x28],0x1
  40fb81:	jmp    40fb86 <__swc_fn_4fa09e82_000050_e33921d7+0x1e6>
  40fb83:	xor    r15d,r15d
  40fb86:	test   r15,r15
  40fb89:	jne    40fbce <__swc_fn_4fa09e82_000050_e33921d7+0x22e>
  40fb8b:	mov    rcx,r14
  40fb8e:	call   407320 <__swc_fn_4fa09e82_000006_12cb36a2>
  40fb93:	test   al,al
  40fb95:	je     40fbce <__swc_fn_4fa09e82_000050_e33921d7+0x22e>
  40fb97:	mov    rax,QWORD PTR [r14]
  40fb9a:	test   rax,rax
  40fb9d:	je     40fbac <__swc_fn_4fa09e82_000050_e33921d7+0x20c>
  40fb9f:	mov    rcx,QWORD PTR [rax]
  40fba2:	mov    QWORD PTR [r14],rcx
  40fba5:	add    DWORD PTR [r14+0x28],0x1
  40fbaa:	jmp    40fbcb <__swc_fn_4fa09e82_000050_e33921d7+0x22b>
  40fbac:	mov    rax,QWORD PTR [r14+0x18]
  40fbb0:	cmp    QWORD PTR [r14+0x20],rax
  40fbb4:	jae    40fbc9 <__swc_fn_4fa09e82_000050_e33921d7+0x229>
  40fbb6:	mov    rax,QWORD PTR [r14+0x20]
  40fbba:	mov    ecx,DWORD PTR [r14+0x2c]
  40fbbe:	add    QWORD PTR [r14+0x20],rcx
  40fbc2:	add    DWORD PTR [r14+0x28],0x1
  40fbc7:	jmp    40fbcb <__swc_fn_4fa09e82_000050_e33921d7+0x22b>
  40fbc9:	xor    eax,eax
  40fbcb:	mov    r15,rax
  40fbce:	test   r15,r15
  40fbd1:	je     40fb20 <__swc_fn_4fa09e82_000050_e33921d7+0x180>
  40fbd7:	mov    rax,r15
  40fbda:	add    rsp,0x1f8
  40fbe1:	pop    r15
  40fbe3:	pop    r14
  40fbe5:	pop    r13
  40fbe7:	pop    r12
  40fbe9:	pop    rdi
  40fbea:	pop    rsi
  40fbeb:	ret
  40fbec:	add    BYTE PTR [rax],al
	...

000000000040fbf0 <__swc_fn_4fa09e82_000053_a8a124d6>:
  40fbf0:	push   rsi
  40fbf1:	push   rdi
  40fbf2:	push   r12
  40fbf4:	mov    rsi,rdx
  40fbf7:	mov    rax,rdx
  40fbfa:	shr    rax,0xc
  40fbfe:	movabs rdx,0x9e3779b97f4a7c15
  40fc08:	imul   rax,rdx
  40fc0c:	shr    rax,0x20
  40fc10:	lea    rax,[rax*8+0x0]
  40fc18:	shr    rax,0x20
  40fc1c:	lea    rax,[rax*8+0x0]
  40fc24:	lea    rax,[rcx+rax*8+0x40]
  40fc29:	xor    edx,edx
  40fc2b:	test   dl,dl
  40fc2d:	lea    rdi,[rcx+0x8]
  40fc31:	cmove  rdi,rax
  40fc35:	xor    edx,edx
  40fc37:	test   dl,dl
  40fc39:	lea    r12,[rcx+0x30]
  40fc3d:	lea    rax,[rax+0x8]
  40fc41:	cmove  r12,rax
  40fc45:	mov    rcx,rdi
  40fc48:	call   40e760 <__swc_fn_4fa09e82_000136_1fec60ac>
  40fc4d:	mov    QWORD PTR [rsi+0x30],0x0
  40fc55:	mov    rax,QWORD PTR [r12]
  40fc59:	mov    QWORD PTR [rsi+0x38],rax
  40fc5d:	test   rax,rax
  40fc60:	je     40fc6a <__swc_fn_4fa09e82_000053_a8a124d6+0x7a>
  40fc62:	mov    rax,QWORD PTR [rsi+0x38]
  40fc66:	mov    QWORD PTR [rax+0x30],rsi
  40fc6a:	mov    QWORD PTR [r12],rsi
  40fc6e:	mov    rcx,rdi
  40fc71:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  40fc76:	pop    r12
  40fc78:	pop    rdi
  40fc79:	pop    rsi
  40fc7a:	ret
  40fc7b:	add    BYTE PTR [rax],al
  40fc7d:	add    BYTE PTR [rax],al
	...

000000000040fc80 <__swc_fn_4fa09e82_000056_cfedf3f4>:
  40fc80:	lea    rax,[rdx+rdx*4]
  40fc84:	lea    rax,[rcx+rax*8+0x268]
  40fc8c:	mov    rdx,QWORD PTR [rax+0x10]
  40fc90:	sub    QWORD PTR [rcx+0x2a68],rdx
  40fc97:	sub    QWORD PTR [rcx+0x2a70],0x1
  40fc9f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40fca6:	lea    rdx,[rdx+rdx*4]
  40fcaa:	lea    rdx,[rcx+rdx*8+0x268]
  40fcb2:	vmovups xmm0,XMMWORD PTR [rdx]
  40fcb6:	vmovups XMMWORD PTR [rax],xmm0
  40fcba:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40fcbf:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40fcc4:	mov    rcx,QWORD PTR [rdx+0x20]
  40fcc8:	mov    QWORD PTR [rax+0x20],rcx
  40fccc:	ret
  40fccd:	add    BYTE PTR [rax],al
	...

000000000040fcd0 <__swc_fn_4fa09e82_000059_c8e1ff6b>:
  40fcd0:	push   rsi
  40fcd1:	push   rdi
  40fcd2:	push   r12
  40fcd4:	push   r13
  40fcd6:	sub    rsp,0x8
  40fcda:	mov    rsi,r8
  40fcdd:	mov    rdi,rcx
  40fce0:	mov    r12,rdx
  40fce3:	xor    r13d,r13d
  40fce6:	cs nop WORD PTR [rax+rax*1+0x0]
  40fcf0:	mov    eax,DWORD PTR [r12+0x730]
  40fcf8:	cmp    r13d,eax
  40fcfb:	jae    40fd61 <__swc_fn_4fa09e82_000059_c8e1ff6b+0x91>
  40fcfd:	lea    rax,[r13+r13*4+0x0]
  40fd02:	lea    rax,[r12+rax*8+0x738]
  40fd0a:	mov    rdx,QWORD PTR [rax]
  40fd0d:	mov    r8,QWORD PTR [rax+0x8]
  40fd11:	mov    r9,QWORD PTR [rax+0x10]
  40fd15:	cmp    QWORD PTR [rax+0x20],rsi
  40fd19:	jb     40fd20 <__swc_fn_4fa09e82_000059_c8e1ff6b+0x50>
  40fd1b:	inc    r13d
  40fd1e:	jmp    40fcf0 <__swc_fn_4fa09e82_000059_c8e1ff6b+0x20>
  40fd20:	sub    DWORD PTR [r12+0x730],0x1
  40fd29:	mov    ecx,DWORD PTR [r12+0x730]
  40fd31:	lea    rcx,[rcx+rcx*4]
  40fd35:	lea    rcx,[r12+rcx*8+0x738]
  40fd3d:	vmovups xmm0,XMMWORD PTR [rcx]
  40fd41:	vmovups XMMWORD PTR [rax],xmm0
  40fd45:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40fd4a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40fd4f:	mov    rcx,QWORD PTR [rcx+0x20]
  40fd53:	mov    QWORD PTR [rax+0x20],rcx
  40fd57:	mov    rcx,rdi
  40fd5a:	call   407750 <__swc_fn_4fa09e82_000039_05a50673>
  40fd5f:	jmp    40fcf0 <__swc_fn_4fa09e82_000059_c8e1ff6b+0x20>
  40fd61:	add    rsp,0x8
  40fd65:	pop    r13
  40fd67:	pop    r12
  40fd69:	pop    rdi
  40fd6a:	pop    rsi
  40fd6b:	ret
  40fd6c:	add    BYTE PTR [rax],al
	...

000000000040fd70 <__swc_fn_4fa09e82_000062_baa48dba>:
  40fd70:	push   rsi
  40fd71:	push   rdi
  40fd72:	push   r12
  40fd74:	push   r13
  40fd76:	push   r14
  40fd78:	mov    rsi,rcx
  40fd7b:	mov    rdi,rdx
  40fd7e:	mov    r12,QWORD PTR [rdi]
  40fd81:	mov    r13,QWORD PTR [rdi+0x18]
  40fd85:	mov    rax,r12
  40fd88:	add    rax,QWORD PTR [rdi+0x8]
  40fd8c:	sub    rax,r13
  40fd8f:	cmp    r8,rax
  40fd92:	jbe    40fd9d <__swc_fn_4fa09e82_000062_baa48dba+0x2d>
  40fd94:	pop    r14
  40fd96:	pop    r13
  40fd98:	pop    r12
  40fd9a:	pop    rdi
  40fd9b:	pop    rsi
  40fd9c:	ret
  40fd9d:	lea    rax,[r13+r8*1+0x0]
  40fda2:	sub    rax,r12
  40fda5:	mov    ecx,0x1000
  40fdaa:	test   ecx,ecx
  40fdac:	mov    edx,0x8
  40fdb1:	cmove  ecx,edx
  40fdb4:	dec    rcx
  40fdb7:	mov    rdx,0xffffffffffffffff
  40fdbe:	sub    rdx,rcx
  40fdc1:	cmp    rax,rdx
  40fdc4:	jbe    40fdcb <__swc_fn_4fa09e82_000062_baa48dba+0x5b>
  40fdc6:	xor    r14d,r14d
  40fdc9:	jmp    40fdd6 <__swc_fn_4fa09e82_000062_baa48dba+0x66>
  40fdcb:	add    rax,rcx
  40fdce:	andn   rax,rcx,rax
  40fdd3:	mov    r14,rax
  40fdd6:	mov    rax,QWORD PTR [rdi+0x10]
  40fdda:	cmp    r14,rax
  40fddd:	ja     40fde8 <__swc_fn_4fa09e82_000062_baa48dba+0x78>
  40fddf:	pop    r14
  40fde1:	pop    r13
  40fde3:	pop    r12
  40fde5:	pop    rdi
  40fde6:	pop    rsi
  40fde7:	ret
  40fde8:	mov    rax,r12
  40fdeb:	add    rax,QWORD PTR [rdi+0x10]
  40fdef:	mov    rdx,r14
  40fdf2:	sub    rdx,QWORD PTR [rdi+0x10]
  40fdf6:	mov    rcx,rax
  40fdf9:	call   4072a0 <__swc_fn_4fa09e82_000003_644dadb7>
  40fdfe:	test   al,al
  40fe00:	jne    40fe0b <__swc_fn_4fa09e82_000062_baa48dba+0x9b>
  40fe02:	pop    r14
  40fe04:	pop    r13
  40fe06:	pop    r12
  40fe08:	pop    rdi
  40fe09:	pop    rsi
  40fe0a:	ret
  40fe0b:	add    r12,r14
  40fe0e:	sub    r12,r13
  40fe11:	mov    rcx,r12
  40fe14:	sub    rcx,QWORD PTR [rdi+0x28]
  40fe18:	mov    rdx,QWORD PTR [rsi+0x250]
  40fe1f:	nop
  40fe20:	lea    r8,[rdx+rcx*1]
  40fe24:	mov    rax,rdx
  40fe27:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40fe30:	cmp    rax,rdx
  40fe33:	je     40fe3a <__swc_fn_4fa09e82_000062_baa48dba+0xca>
  40fe35:	mov    rdx,rax
  40fe38:	jmp    40fe20 <__swc_fn_4fa09e82_000062_baa48dba+0xb0>
  40fe3a:	mov    QWORD PTR [rdi+0x10],r14
  40fe3e:	mov    QWORD PTR [rdi+0x28],r12
  40fe42:	pop    r14
  40fe44:	pop    r13
  40fe46:	pop    r12
  40fe48:	pop    rdi
  40fe49:	pop    rsi
  40fe4a:	ret
  40fe4b:	add    BYTE PTR [rax],al
  40fe4d:	add    BYTE PTR [rax],al
	...

000000000040fe50 <__swc_fn_4fa09e82_000065_cd9dd53e>:
  40fe50:	push   rbx
  40fe51:	push   rsi
  40fe52:	push   rdi
  40fe53:	push   r12
  40fe55:	push   r13
  40fe57:	sub    rsp,0xe0
  40fe5e:	mov    rbx,rdx
  40fe61:	mov    rsi,rcx
  40fe64:	cmp    DWORD PTR [rbx+0x58],0x0
  40fe68:	je     40fe8c <__swc_fn_4fa09e82_000065_cd9dd53e+0x3c>
  40fe6a:	mov    eax,DWORD PTR [rbx+0x58]
  40fe6d:	sub    eax,0x1
  40fe70:	test   DWORD PTR [rbx+0x58],eax
  40fe73:	je     40fe8c <__swc_fn_4fa09e82_000065_cd9dd53e+0x3c>
  40fe75:	mov    QWORD PTR [rbx+0x40],0x0
  40fe7d:	add    rsp,0xe0
  40fe84:	pop    r13
  40fe86:	pop    r12
  40fe88:	pop    rdi
  40fe89:	pop    rsi
  40fe8a:	pop    rbx
  40fe8b:	ret
  40fe8c:	mov    rax,QWORD PTR [rbx+0x40]
  40fe90:	test   rax,rax
  40fe93:	jne    40feaf <__swc_fn_4fa09e82_000065_cd9dd53e+0x5f>
  40fe95:	mov    rcx,rsi
  40fe98:	mov    rdx,rbx
  40fe9b:	call   40d3d0 <__swc_fn_4fa09e82_000064_6905bec4>
  40fea0:	add    rsp,0xe0
  40fea7:	pop    r13
  40fea9:	pop    r12
  40feab:	pop    rdi
  40feac:	pop    rsi
  40fead:	pop    rbx
  40feae:	ret
  40feaf:	cmp    QWORD PTR [rbx+0x48],0x0
  40feb4:	jne    40fed0 <__swc_fn_4fa09e82_000065_cd9dd53e+0x80>
  40feb6:	mov    rcx,rsi
  40feb9:	mov    rdx,rbx
  40febc:	call   407f90 <__swc_fn_4fa09e82_000066_77c6e829>
  40fec1:	add    rsp,0xe0
  40fec8:	pop    r13
  40feca:	pop    r12
  40fecc:	pop    rdi
  40fecd:	pop    rsi
  40fece:	pop    rbx
  40fecf:	ret
  40fed0:	mov    rdi,QWORD PTR [rbx+0x40]
  40fed4:	lea    rax,[rip+0x14195]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40fedb:	mov    rcx,rdi
  40fede:	sub    rcx,QWORD PTR [rax+0x8]
  40fee2:	mov    rax,QWORD PTR [rip+0x14197]        # 424080 <__swc_bss_base_4fa09e82+0x40>
  40fee9:	cmp    rcx,rax
  40feec:	jae    40ff18 <__swc_fn_4fa09e82_000065_cd9dd53e+0xc8>
  40feee:	mov    rax,rdi
  40fef1:	and    rax,0xffffffffffc00000
  40fef8:	mov    rcx,rdi
  40fefb:	shr    rcx,0x10
  40feff:	and    ecx,0x3f
  40ff02:	mov    edx,DWORD PTR [rax+0x28]
  40ff05:	shrx   ecx,ecx,edx
  40ff0a:	shl    rcx,0x4
  40ff0e:	lea    r12,[rax+rcx*8+0x80]
  40ff16:	jmp    40ff23 <__swc_fn_4fa09e82_000065_cd9dd53e+0xd3>
  40ff18:	mov    rcx,rdi
  40ff1b:	call   40c450 <__swc_fn_4fa09e82_000022_77c2d682>
  40ff20:	mov    r12,rax
  40ff23:	test   r12,r12
  40ff26:	je     40ff35 <__swc_fn_4fa09e82_000065_cd9dd53e+0xe5>
  40ff28:	mov    eax,DWORD PTR [r12+0x2c]
  40ff2d:	mov    r9d,eax
  40ff30:	mov    r13,rax
  40ff33:	jmp    40ffb4 <__swc_fn_4fa09e82_000065_cd9dd53e+0x164>
  40ff35:	mov    rcx,rsi
  40ff38:	mov    rdx,rdi
  40ff3b:	call   40ca60 <__swc_fn_4fa09e82_000052_26c6c1c4>
  40ff40:	mov    rcx,QWORD PTR [rax+0x28]
  40ff44:	mov    r9,rcx
  40ff47:	mov    rdx,QWORD PTR [rax+0x20]
  40ff4b:	mov    r13,rdx
  40ff4e:	cmp    QWORD PTR [rbx+0x48],rcx
  40ff52:	jbe    40ff8b <__swc_fn_4fa09e82_000065_cd9dd53e+0x13b>
  40ff54:	mov    ecx,DWORD PTR [rax+0x48]
  40ff57:	cmp    DWORD PTR [rbx+0x58],ecx
  40ff5a:	ja     40ff8b <__swc_fn_4fa09e82_000065_cd9dd53e+0x13b>
  40ff5c:	mov    rcx,rsi
  40ff5f:	mov    rdx,rax
  40ff62:	mov    r8,QWORD PTR [rbx+0x48]
  40ff66:	mov    QWORD PTR [rsp+0xc8],r9
  40ff6e:	mov    QWORD PTR [rsp+0xd0],rax
  40ff76:	call   40fd70 <__swc_fn_4fa09e82_000062_baa48dba>
  40ff7b:	mov    r9,QWORD PTR [rsp+0xc8]
  40ff83:	mov    rax,QWORD PTR [rsp+0xd0]
  40ff8b:	mov    rcx,QWORD PTR [rax+0x28]
  40ff8f:	cmp    QWORD PTR [rbx+0x48],rcx
  40ff93:	ja     40ffb4 <__swc_fn_4fa09e82_000065_cd9dd53e+0x164>
  40ff95:	mov    ecx,DWORD PTR [rax+0x48]
  40ff98:	cmp    DWORD PTR [rbx+0x58],ecx
  40ff9b:	ja     40ffb4 <__swc_fn_4fa09e82_000065_cd9dd53e+0x164>
  40ff9d:	mov    rcx,QWORD PTR [rbx+0x48]
  40ffa1:	mov    QWORD PTR [rax+0x20],rcx
  40ffa5:	add    rsp,0xe0
  40ffac:	pop    r13
  40ffae:	pop    r12
  40ffb0:	pop    rdi
  40ffb1:	pop    rsi
  40ffb2:	pop    rbx
  40ffb3:	ret
  40ffb4:	test   r12,r12
  40ffb7:	je     40ffe9 <__swc_fn_4fa09e82_000065_cd9dd53e+0x199>
  40ffb9:	cmp    QWORD PTR [rbx+0x48],r9
  40ffbd:	ja     40ffe9 <__swc_fn_4fa09e82_000065_cd9dd53e+0x199>
  40ffbf:	cmp    DWORD PTR [rbx+0x58],0x40
  40ffc3:	ja     40ffe9 <__swc_fn_4fa09e82_000065_cd9dd53e+0x199>
  40ffc5:	cmp    DWORD PTR [rbx+0x58],0x0
  40ffc9:	je     40ffd6 <__swc_fn_4fa09e82_000065_cd9dd53e+0x186>
  40ffcb:	mov    ecx,DWORD PTR [rbx+0x58]
  40ffce:	dec    rcx
  40ffd1:	test   rdi,rcx
  40ffd4:	jne    40ffe9 <__swc_fn_4fa09e82_000065_cd9dd53e+0x199>
  40ffd6:	mov    QWORD PTR [rbx+0x40],rdi
  40ffda:	add    rsp,0xe0
  40ffe1:	pop    r13
  40ffe3:	pop    r12
  40ffe5:	pop    rdi
  40ffe6:	pop    rsi
  40ffe7:	pop    rbx
  40ffe8:	ret
  40ffe9:	vmovups xmm0,XMMWORD PTR [rbx]
  40ffed:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fff3:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40fff8:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40fffe:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  410003:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  410009:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  41000e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  410014:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  410019:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  41001f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  410024:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  41002a:	mov    QWORD PTR [rsp+0x48],0x0
  410033:	mov    rcx,rsi
  410036:	lea    rdx,[rsp+0x8]
  41003b:	call   40d3d0 <__swc_fn_4fa09e82_000064_6905bec4>
  410040:	mov    rax,QWORD PTR [rsp+0x48]
  410045:	test   rax,rax
  410048:	jne    410061 <__swc_fn_4fa09e82_000065_cd9dd53e+0x211>
  41004a:	mov    QWORD PTR [rbx+0x40],0x0
  410052:	add    rsp,0xe0
  410059:	pop    r13
  41005b:	pop    r12
  41005d:	pop    rdi
  41005e:	pop    rsi
  41005f:	pop    rbx
  410060:	ret
  410061:	mov    rax,QWORD PTR [rbx+0x48]
  410065:	cmp    r13,rax
  410068:	cmovbe rax,r13
  41006c:	mov    rcx,QWORD PTR [rsp+0x48]
  410071:	mov    rdx,rdi
  410074:	mov    r8,rax
  410077:	call   40dfa0 <__swc_fn_4fa09e82_000106_b7aef7c0>
  41007c:	vmovups xmm0,XMMWORD PTR [rbx]
  410080:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  410086:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  41008b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  410091:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  410096:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  41009f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  4100a4:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4100ad:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  4100b2:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4100bb:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  4100c0:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4100c9:	mov    QWORD PTR [rsp+0xa8],rdi
  4100d1:	mov    rcx,rsi
  4100d4:	lea    rdx,[rsp+0x68]
  4100d9:	call   407f90 <__swc_fn_4fa09e82_000066_77c6e829>
  4100de:	mov    rax,QWORD PTR [rsp+0x48]
  4100e3:	mov    QWORD PTR [rbx+0x40],rax
  4100e7:	add    rsp,0xe0
  4100ee:	pop    r13
  4100f0:	pop    r12
  4100f2:	pop    rdi
  4100f3:	pop    rsi
  4100f4:	pop    rbx
  4100f5:	ret
	...

0000000000410100 <__swc_fn_4fa09e82_000068_557d6092>:
  410100:	push   r12
  410102:	push   rdi
  410103:	push   rsi
  410104:	push   r13
  410106:	push   r14
  410108:	sub    rsp,0x190
  41010f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  410118:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  410121:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  41012a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  410133:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  41013c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  410145:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  41014e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  410157:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  410160:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  410169:	mov    r12,rcx
  41016c:	lea    rax,[rip+0x11e8d]        # 422000 <__swc_data_base_4fa09e82>
  410173:	mov    rax,QWORD PTR [rax]
  410176:	cmp    rax,0xffffffffffffffff
  41017a:	je     410189 <__swc_fn_4fa09e82_000068_557d6092+0x89>
  41017c:	mov    eax,eax
  41017e:	mov    edi,eax
  410180:	xor    eax,eax
  410182:	call   407000 <pthread_getspecific@plt>
  410187:	jmp    41018b <__swc_fn_4fa09e82_000068_557d6092+0x8b>
  410189:	xor    eax,eax
  41018b:	test   rax,rax
  41018e:	jne    41019d <__swc_fn_4fa09e82_000068_557d6092+0x9d>
  410190:	call   40c520 <__swc_fn_4fa09e82_000031_ed8d61a9>
  410195:	mov    rcx,rax
  410198:	call   409ba0 <__swc_fn_4fa09e82_000129_9c45d2d7>
  41019d:	test   rax,rax
  4101a0:	je     4101c6 <__swc_fn_4fa09e82_000068_557d6092+0xc6>
  4101a2:	cmp    QWORD PTR [rax],r12
  4101a5:	jne    4101c6 <__swc_fn_4fa09e82_000068_557d6092+0xc6>
  4101a7:	xor    ecx,ecx
  4101a9:	mov    QWORD PTR [rsp+0xc8],rax
  4101b1:	call   407720 <__swc_fn_4fa09e82_000033_7d7574b6>
  4101b6:	mov    rdx,QWORD PTR [rsp+0xc8]
  4101be:	mov    rcx,r12
  4101c1:	call   407840 <__swc_fn_4fa09e82_000042_70d5ab54>
  4101c6:	lea    rsi,[r12+0x10]
  4101cb:	mov    rcx,rsi
  4101ce:	call   40e760 <__swc_fn_4fa09e82_000136_1fec60ac>
  4101d3:	mov    rdi,QWORD PTR [r12+0x20]
  4101d8:	test   rdi,rdi
  4101db:	je     41021e <__swc_fn_4fa09e82_000068_557d6092+0x11e>
  4101dd:	nop    DWORD PTR [rax]
  4101e0:	mov    rcx,r12
  4101e3:	mov    rdx,rdi
  4101e6:	call   40c6e0 <__swc_fn_4fa09e82_000043_3755033a>
  4101eb:	mov    rcx,r12
  4101ee:	mov    rdx,rdi
  4101f1:	mov    r8,0xffffffffffffffff
  4101f8:	call   40fcd0 <__swc_fn_4fa09e82_000059_c8e1ff6b>
  4101fd:	mov    rcx,r12
  410200:	mov    rdx,rdi
  410203:	mov    r8d,0x9b8
  410209:	mov    r9d,0x9b8
  41020f:	call   407750 <__swc_fn_4fa09e82_000039_05a50673>
  410214:	mov    rdi,QWORD PTR [r12+0x20]
  410219:	test   rdi,rdi
  41021c:	jne    4101e0 <__swc_fn_4fa09e82_000068_557d6092+0xe0>
  41021e:	xor    eax,eax
  410220:	xchg   QWORD PTR [r12+0x2a80],rax
  410228:	test   rax,rax
  41022b:	je     410251 <__swc_fn_4fa09e82_000068_557d6092+0x151>
  41022d:	cs nop WORD PTR [rax+rax*1+0x0]
  410237:	nop    WORD PTR [rax+rax*1+0x0]
  410240:	mov    rcx,rax
  410243:	mov    rax,QWORD PTR [rax+0x78]
  410247:	xor    edx,edx
  410249:	xchg   DWORD PTR [rcx+0x70],edx
  41024c:	test   rax,rax
  41024f:	jne    410240 <__swc_fn_4fa09e82_000068_557d6092+0x140>
  410251:	mov    rax,QWORD PTR [r12+0x18]
  410256:	mov    rdi,rax
  410259:	test   rdi,rdi
  41025c:	je     4102f1 <__swc_fn_4fa09e82_000068_557d6092+0x1f1>
  410262:	cs nop WORD PTR [rax+rax*1+0x0]
  41026c:	nop    DWORD PTR [rax+0x0]
  410270:	mov    rax,QWORD PTR [rdi+0x10]
  410274:	mov    r8d,DWORD PTR [rdi+0x2c]
  410278:	xor    r9d,r9d
  41027b:	test   r8,r8
  41027e:	jbe    4102dd <__swc_fn_4fa09e82_000068_557d6092+0x1dd>
  410280:	mov    ecx,r9d
  410283:	shl    rcx,0x4
  410287:	lea    rdx,[rdi+rcx*8+0x80]
  41028f:	cmp    BYTE PTR [rdx+0x3b],0x0
  410293:	je     4102d4 <__swc_fn_4fa09e82_000068_557d6092+0x1d4>
  410295:	mov    DWORD PTR [rdx+0x28],0x0
  41029c:	mov    rcx,rdi
  41029f:	mov    QWORD PTR [rsp+0xd0],rax
  4102a7:	mov    QWORD PTR [rsp+0xd8],r8
  4102af:	mov    QWORD PTR [rsp+0xe0],r9
  4102b7:	call   40f400 <__swc_fn_4fa09e82_000014_1acdaf22>
  4102bc:	mov    rax,QWORD PTR [rsp+0xd0]
  4102c4:	mov    r8,QWORD PTR [rsp+0xd8]
  4102cc:	mov    r9,QWORD PTR [rsp+0xe0]
  4102d4:	add    r9,0x1
  4102d8:	cmp    r9,r8
  4102db:	jb     410280 <__swc_fn_4fa09e82_000068_557d6092+0x180>
  4102dd:	mov    rcx,rdi
  4102e0:	mov    rdi,rax
  4102e3:	call   407630 <__swc_fn_4fa09e82_000021_fe13ecad>
  4102e8:	test   rdi,rdi
  4102eb:	jne    410270 <__swc_fn_4fa09e82_000068_557d6092+0x170>
  4102f1:	mov    QWORD PTR [r12+0x18],0x0
  4102fa:	mov    QWORD PTR [r12+0x28],0x0
  410303:	mov    rcx,rsi
  410306:	call   4118d0 <__swc_fn_4fa09e82_000137_5589b4a1>
  41030b:	mov    esi,0x8
  410310:	xor    edi,edi
  410312:	test   rsi,rsi
  410315:	je     410372 <__swc_fn_4fa09e82_000068_557d6092+0x272>
  41031b:	nop    DWORD PTR [rax+rax*1+0x0]
  410320:	lea    r13,[rdi*8+0x0]
  410328:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  41032d:	test   r14,r14
  410330:	je     410368 <__swc_fn_4fa09e82_000068_557d6092+0x268>
  410332:	cs nop WORD PTR [rax+rax*1+0x0]
  41033c:	nop    DWORD PTR [rax+0x0]
  410340:	mov    rcx,r12
  410343:	mov    rdx,r14
  410346:	call   407df0 <__swc_fn_4fa09e82_000054_1dfec8f6>
  41034b:	mov    rcx,r12
  41034e:	mov    rdx,QWORD PTR [r14]
  410351:	mov    r8,QWORD PTR [r14+0x8]
  410355:	mov    r9,QWORD PTR [r14+0x10]
  410359:	call   407750 <__swc_fn_4fa09e82_000039_05a50673>
  41035e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  410363:	test   r14,r14
  410366:	jne    410340 <__swc_fn_4fa09e82_000068_557d6092+0x240>
  410368:	add    rdi,0x1
  41036c:	sub    rsi,0x1
  410370:	jne    410320 <__swc_fn_4fa09e82_000068_557d6092+0x220>
  410372:	mov    rcx,r12
  410375:	call   407ec0 <__swc_fn_4fa09e82_000060_9d59636e>
  41037a:	lea    rcx,[r12+0x250]
  410382:	mov    rdx,QWORD PTR [rcx]
  410385:	mov    r8,QWORD PTR [r12+0x250]
  41038d:	nop    DWORD PTR [rax]
  410390:	mov    r9,r8
  410393:	sub    r9,rdx
  410396:	mov    rax,r8
  410399:	lock cmpxchg QWORD PTR [rcx],r9
  41039e:	cmp    rax,r8
  4103a1:	je     4103a8 <__swc_fn_4fa09e82_000068_557d6092+0x2a8>
  4103a3:	mov    r8,rax
  4103a6:	jmp    410390 <__swc_fn_4fa09e82_000068_557d6092+0x290>
  4103a8:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  4103b1:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  4103ba:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  4103c3:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  4103cc:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  4103d5:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  4103de:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  4103e7:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  4103f0:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  4103f9:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  410402:	add    rsp,0x190
  410409:	pop    r14
  41040b:	pop    r13
  41040d:	pop    rsi
  41040e:	pop    rdi
  41040f:	pop    r12
  410411:	ret
	...

0000000000410420 <__swc_fn_4fa09e82_000071_7e144e9b>:
  410420:	sub    rsp,0x8
  410424:	mov    QWORD PTR [rdx+0x40],0x0
  41042c:	call   40d3d0 <__swc_fn_4fa09e82_000064_6905bec4>
  410431:	add    rsp,0x8
  410435:	ret
	...

0000000000410440 <__swc_fn_4fa09e82_000074_9eaf4878>:
  410440:	sub    rsp,0x8
  410444:	call   407f90 <__swc_fn_4fa09e82_000066_77c6e829>
  410449:	add    rsp,0x8
  41044d:	ret
	...

0000000000410450 <__swc_fn_4fa09e82_000077_e793b5e1>:
  410450:	push   rbx
  410451:	push   rsi
  410452:	push   rdi
  410453:	push   r12
  410455:	push   r13
  410457:	push   r14
  410459:	push   r15
  41045b:	sub    rsp,0x20
  41045f:	mov    rbx,r11
  410462:	mov    rsi,rcx
  410465:	mov    rdi,rdx
  410468:	mov    r12,r8
  41046b:	mov    r13,r9
  41046e:	mov    r14,r10
  410471:	mov    rcx,QWORD PTR [rip+0x168c8]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  410478:	test   rcx,rcx
  41047b:	jne    41048d <__swc_fn_4fa09e82_000077_e793b5e1+0x3d>
  41047d:	call   40f060 <__swc_fn_4fa09e82_000166_e09accff>
  410482:	lea    rcx,[rax+0x1]
  410486:	mov    QWORD PTR [rip+0x168b3],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  41048d:	dec    rcx
  410490:	call   40b620 <__swc_fn_4fa09e82_000168_3130645d>
  410495:	mov    r15,rax
  410498:	lea    r11,[rip+0x13da1]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  41049f:	mov    rcx,r11
  4104a2:	call   407740 <__swc_fn_4fa09e82_000036_62160bb3>
  4104a7:	test   al,al
  4104a9:	jne    4104ba <__swc_fn_4fa09e82_000077_e793b5e1+0x6a>
  4104ab:	mov    rcx,r11
  4104ae:	call   40c580 <__swc_fn_4fa09e82_000034_c72914a2>
  4104b3:	lea    r11,[rip+0x13d86]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  4104ba:	mov    rcx,r11
  4104bd:	mov    rdx,rsi
  4104c0:	mov    r8,rdi
  4104c3:	mov    r9,r12
  4104c6:	mov    r10,r13
  4104c9:	mov    rsi,r11
  4104cc:	mov    r11,r14
  4104cf:	call   40f770 <__swc_fn_4fa09e82_000035_6105596e>
  4104d4:	test   bl,bl
  4104d6:	je     4104fd <__swc_fn_4fa09e82_000077_e793b5e1+0xad>
  4104d8:	mov    QWORD PTR [rsp+0x8],rsi
  4104dd:	lea    rax,[rip+0x2c6c]        # 413150 <__swc_rdata_base_4fa09e82+0x40>
  4104e4:	mov    QWORD PTR [rsp+0x10],rax
  4104e9:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4104ef:	vmovups XMMWORD PTR [r15],xmm0
  4104f4:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  4104fd:	mov    rax,rsi
  410500:	add    rsp,0x20
  410504:	pop    r15
  410506:	pop    r14
  410508:	pop    r13
  41050a:	pop    r12
  41050c:	pop    rdi
  41050d:	pop    rsi
  41050e:	pop    rbx
  41050f:	ret

0000000000410510 <__swc_fn_4fa09e82_000080_851c599a>:
  410510:	sub    rsp,0x8
  410514:	mov    rax,rcx
  410517:	test   rcx,rcx
  41051a:	jne    410521 <__swc_fn_4fa09e82_000080_851c599a+0x11>
  41051c:	add    rsp,0x8
  410520:	ret
  410521:	lea    rcx,[rax-0x10]
  410525:	mov    rax,QWORD PTR [rax-0x10]
  410529:	mov    rdx,rax
  41052c:	call   409850 <__swc_fn_4fa09e82_000114_25e345b1>
  410531:	add    rsp,0x8
  410535:	ret
	...

0000000000410540 <__swc_fn_4fa09e82_000083_fb84e43e>:
  410540:	sub    rsp,0x8
  410544:	xor    r11d,r11d
  410547:	call   408250 <__swc_fn_4fa09e82_000084_746bf146>
  41054c:	add    rsp,0x8
  410550:	ret
	...

0000000000410560 <__swc_fn_4fa09e82_000086_ac8c6565>:
  410560:	push   rsi
  410561:	push   rdi
  410562:	push   r12
  410564:	push   r13
  410566:	push   r14
  410568:	push   r15
  41056a:	sub    rsp,0x68
  41056e:	mov    rsi,r9
  410571:	mov    rdi,rcx
  410574:	mov    r12,rdx
  410577:	mov    r13,r8
  41057a:	cmp    r8,r9
  41057d:	jne    4105a5 <__swc_fn_4fa09e82_000086_ac8c6565+0x45>
  41057f:	mov    rcx,rdi
  410582:	mov    rdx,r12
  410585:	xor    r8d,r8d
  410588:	call   4085a0 <__swc_fn_4fa09e82_000090_9a1d717d>
  41058d:	test   al,al
  41058f:	je     4105a5 <__swc_fn_4fa09e82_000086_ac8c6565+0x45>
  410591:	mov    eax,0x1
  410596:	add    rsp,0x68
  41059a:	pop    r15
  41059c:	pop    r14
  41059e:	pop    r13
  4105a0:	pop    r12
  4105a2:	pop    rdi
  4105a3:	pop    rsi
  4105a4:	ret
  4105a5:	cmp    BYTE PTR [r12+0x2c],0xe
  4105ab:	je     4105be <__swc_fn_4fa09e82_000086_ac8c6565+0x5e>
  4105ad:	xor    eax,eax
  4105af:	add    rsp,0x68
  4105b3:	pop    r15
  4105b5:	pop    r14
  4105b7:	pop    r13
  4105b9:	pop    r12
  4105bb:	pop    rdi
  4105bc:	pop    rsi
  4105bd:	ret
  4105be:	mov    r14,QWORD PTR [r12+0x98]
  4105c6:	mov    rax,QWORD PTR [r12+0xa0]
  4105ce:	mov    r12,rax
  4105d1:	xor    r15d,r15d
  4105d4:	test   r12,r12
  4105d7:	je     41063f <__swc_fn_4fa09e82_000086_ac8c6565+0xdf>
  4105d9:	nop    DWORD PTR [rax+0x0]
  4105e0:	mov    QWORD PTR [rsp+0x58],r12
  4105e5:	lea    r12,[r15*8+0x0]
  4105ed:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  4105f2:	mov    rcx,rax
  4105f5:	call   40db60 <__swc_fn_4fa09e82_000082_9f4f5092>
  4105fa:	cmp    BYTE PTR [rax+0x2c],0xe
  4105fe:	jne    410630 <__swc_fn_4fa09e82_000086_ac8c6565+0xd0>
  410600:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  410605:	lea    r8,[r13+rcx*1+0x0]
  41060a:	mov    rcx,rdi
  41060d:	mov    rdx,rax
  410610:	mov    r9,rsi
  410613:	call   410560 <__swc_fn_4fa09e82_000086_ac8c6565>
  410618:	test   al,al
  41061a:	je     410630 <__swc_fn_4fa09e82_000086_ac8c6565+0xd0>
  41061c:	mov    eax,0x1
  410621:	add    rsp,0x68
  410625:	pop    r15
  410627:	pop    r14
  410629:	pop    r13
  41062b:	pop    r12
  41062d:	pop    rdi
  41062e:	pop    rsi
  41062f:	ret
  410630:	add    r15,0x1
  410634:	mov    r12,QWORD PTR [rsp+0x58]
  410639:	sub    r12,0x1
  41063d:	jne    4105e0 <__swc_fn_4fa09e82_000086_ac8c6565+0x80>
  41063f:	xor    eax,eax
  410641:	add    rsp,0x68
  410645:	pop    r15
  410647:	pop    r14
  410649:	pop    r13
  41064b:	pop    r12
  41064d:	pop    rdi
  41064e:	pop    rsi
  41064f:	ret

0000000000410650 <__swc_fn_4fa09e82_000089_157b05de>:
  410650:	push   rbp
  410651:	push   rbx
  410652:	push   rsi
  410653:	push   rdi
  410654:	push   r12
  410656:	push   r13
  410658:	push   r14
  41065a:	push   r15
  41065c:	sub    rsp,0x38
  410660:	mov    rbp,rsp
  410663:	mov    rbx,r11
  410666:	mov    rsi,rdx
  410669:	mov    rdi,r8
  41066c:	mov    r12,r9
  41066f:	mov    QWORD PTR [rsp+0x18],r9
  410674:	mov    r13,r10
  410677:	movzx  r14d,BYTE PTR [rbp+0x80]
  41067f:	movzx  r15d,BYTE PTR [rbp+0x88]
  410687:	test   r11,r11
  41068a:	je     410690 <__swc_fn_4fa09e82_000089_157b05de+0x40>
  41068c:	xor    eax,eax
  41068e:	mov    BYTE PTR [rbx],al
  410690:	test   r12,r12
  410693:	je     41069e <__swc_fn_4fa09e82_000089_157b05de+0x4e>
  410695:	mov    QWORD PTR [r12+0x8],0x0
  41069e:	test   rcx,rcx
  4106a1:	je     4106a8 <__swc_fn_4fa09e82_000089_157b05de+0x58>
  4106a3:	test   rsi,rsi
  4106a6:	jne    4106bb <__swc_fn_4fa09e82_000089_157b05de+0x6b>
  4106a8:	xor    eax,eax
  4106aa:	add    rsp,0x38
  4106ae:	pop    r15
  4106b0:	pop    r14
  4106b2:	pop    r13
  4106b4:	pop    r12
  4106b6:	pop    rdi
  4106b7:	pop    rsi
  4106b8:	pop    rbx
  4106b9:	pop    rbp
  4106ba:	ret
  4106bb:	call   40db60 <__swc_fn_4fa09e82_000082_9f4f5092>
  4106c0:	mov    r12,rax
  4106c3:	mov    al,r15b
  4106c6:	test   r15b,r15b
  4106c9:	jne    4106d9 <__swc_fn_4fa09e82_000089_157b05de+0x89>
  4106cb:	mov    eax,DWORD PTR [r12+0x28]
  4106d0:	and    eax,0x10000
  4106d6:	setne  al
  4106d9:	lea    r15,[rsp+0x8]
  4106de:	mov    QWORD PTR [rsp+0x20],r15
  4106e3:	rex mov BYTE PTR [rsp+0x8],al
  4106e8:	test   DWORD PTR [rsi+0x28],0x400000
  4106ef:	je     410727 <__swc_fn_4fa09e82_000089_157b05de+0xd7>
  4106f1:	test   rsi,rsi
  4106f4:	je     410714 <__swc_fn_4fa09e82_000089_157b05de+0xc4>
  4106f6:	mov    rax,QWORD PTR [rsi+0x38]
  4106fa:	cmp    QWORD PTR [rax+0x10],rsi
  4106fe:	jne    410714 <__swc_fn_4fa09e82_000089_157b05de+0xc4>
  410700:	rex mov al,BYTE PTR [rsp+0x8]
  410705:	test   al,al
  410707:	sete   al
  41070a:	test   r14b,r14b
  41070d:	sete   cl
  410710:	test   al,cl
  410712:	je     410727 <__swc_fn_4fa09e82_000089_157b05de+0xd7>
  410714:	xor    eax,eax
  410716:	add    rsp,0x38
  41071a:	pop    r15
  41071c:	pop    r14
  41071e:	pop    r13
  410720:	pop    r12
  410722:	pop    rdi
  410723:	pop    rsi
  410724:	pop    rbx
  410725:	pop    rbp
  410726:	ret
  410727:	mov    r15,r12
  41072a:	test   r14b,r14b
  41072d:	jne    410744 <__swc_fn_4fa09e82_000089_157b05de+0xf4>
  41072f:	cmp    BYTE PTR [r12+0x2c],0x6
  410735:	jne    410744 <__swc_fn_4fa09e82_000089_157b05de+0xf4>
  410737:	mov    rcx,QWORD PTR [r12+0x40]
  41073c:	call   40db60 <__swc_fn_4fa09e82_000082_9f4f5092>
  410741:	mov    r15,rax
  410744:	test   r14b,r14b
  410747:	je     41074d <__swc_fn_4fa09e82_000089_157b05de+0xfd>
  410749:	mov    r15,QWORD PTR [r15+0x30]
  41074d:	mov    rcx,rsi
  410750:	call   40db60 <__swc_fn_4fa09e82_000082_9f4f5092>
  410755:	mov    rsi,rax
  410758:	rex cmp BYTE PTR [rsi+0x2c],0x6
  41075d:	je     410794 <__swc_fn_4fa09e82_000089_157b05de+0x144>
  41075f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  410764:	je     410794 <__swc_fn_4fa09e82_000089_157b05de+0x144>
  410766:	mov    eax,DWORD PTR [rsi+0x28]
  410769:	and    eax,0x10000
  41076f:	je     410794 <__swc_fn_4fa09e82_000089_157b05de+0x144>
  410771:	rex mov al,BYTE PTR [rsp+0x8]
  410776:	test   al,al
  410778:	jne    41078d <__swc_fn_4fa09e82_000089_157b05de+0x13d>
  41077a:	xor    eax,eax
  41077c:	add    rsp,0x38
  410780:	pop    r15
  410782:	pop    r14
  410784:	pop    r13
  410786:	pop    r12
  410788:	pop    rdi
  410789:	pop    rsi
  41078a:	pop    rbx
  41078b:	pop    rbp
  41078c:	ret
  41078d:	mov    rax,QWORD PTR [rsi+0x30]
  410791:	mov    rsi,rax
  410794:	mov    r14b,r13b
  410797:	test   rbx,rbx
  41079a:	je     4107d0 <__swc_fn_4fa09e82_000089_157b05de+0x180>
  41079c:	cmp    BYTE PTR [r12+0x2c],0x6
  4107a2:	jne    4107d0 <__swc_fn_4fa09e82_000089_157b05de+0x180>
  4107a4:	lea    rdx,[rip+0x29d5]        # 413180 <__swc_rdata_base_4fa09e82+0x70>
  4107ab:	mov    rcx,rsi
  4107ae:	xor    r8d,r8d
  4107b1:	call   4085a0 <__swc_fn_4fa09e82_000090_9a1d717d>
  4107b6:	test   al,al
  4107b8:	je     4107d0 <__swc_fn_4fa09e82_000089_157b05de+0x180>
  4107ba:	mov    BYTE PTR [rbx],0x1
  4107bd:	xor    eax,eax
  4107bf:	add    rsp,0x38
  4107c3:	pop    r15
  4107c5:	pop    r14
  4107c7:	pop    r13
  4107c9:	pop    r12
  4107cb:	pop    rdi
  4107cc:	pop    rsi
  4107cd:	pop    rbx
  4107ce:	pop    rbp
  4107cf:	ret
  4107d0:	test   rdi,rdi
  4107d3:	jne    4107ed <__swc_fn_4fa09e82_000089_157b05de+0x19d>
  4107d5:	test   r13b,r13b
  4107d8:	jne    4107ed <__swc_fn_4fa09e82_000089_157b05de+0x19d>
  4107da:	xor    eax,eax
  4107dc:	add    rsp,0x38
  4107e0:	pop    r15
  4107e2:	pop    r14
  4107e4:	pop    r13
  4107e6:	pop    r12
  4107e8:	pop    rdi
  4107e9:	pop    rsi
  4107ea:	pop    rbx
  4107eb:	pop    rbp
  4107ec:	ret
  4107ed:	rex cmp BYTE PTR [rsi+0x2c],0x6
  4107f2:	jne    4108a8 <__swc_fn_4fa09e82_000089_157b05de+0x258>
  4107f8:	mov    rcx,r15
  4107fb:	mov    rdx,rsi
  4107fe:	xor    r8d,r8d
  410801:	call   4085a0 <__swc_fn_4fa09e82_000090_9a1d717d>
  410806:	test   al,al
  410808:	jne    4108a8 <__swc_fn_4fa09e82_000089_157b05de+0x258>
  41080e:	test   DWORD PTR [rsi+0x28],0x10000
  410815:	je     410833 <__swc_fn_4fa09e82_000089_157b05de+0x1e3>
  410817:	rex mov al,BYTE PTR [rsp+0x8]
  41081c:	test   al,al
  41081e:	jne    410833 <__swc_fn_4fa09e82_000089_157b05de+0x1e3>
  410820:	xor    eax,eax
  410822:	add    rsp,0x38
  410826:	pop    r15
  410828:	pop    r14
  41082a:	pop    r13
  41082c:	pop    r12
  41082e:	pop    rdi
  41082f:	pop    rsi
  410830:	pop    rbx
  410831:	pop    rbp
  410832:	ret
  410833:	test   rdi,rdi
  410836:	jne    41084b <__swc_fn_4fa09e82_000089_157b05de+0x1fb>
  410838:	xor    eax,eax
  41083a:	add    rsp,0x38
  41083e:	pop    r15
  410840:	pop    r14
  410842:	pop    r13
  410844:	pop    r12
  410846:	pop    rdi
  410847:	pop    rsi
  410848:	pop    rbx
  410849:	pop    rbp
  41084a:	ret
  41084b:	mov    rcx,QWORD PTR [rsi+0x40]
  41084f:	call   40db60 <__swc_fn_4fa09e82_000082_9f4f5092>
  410854:	mov    rsi,rax
  410857:	mov    rax,QWORD PTR [rdi]
  41085a:	mov    rdi,rax
  41085d:	test   rax,rax
  410860:	jne    4108a3 <__swc_fn_4fa09e82_000089_157b05de+0x253>
  410862:	test   rbx,rbx
  410865:	je     4108a3 <__swc_fn_4fa09e82_000089_157b05de+0x253>
  410867:	mov    rcx,r15
  41086a:	mov    rdx,rsi
  41086d:	xor    r8d,r8d
  410870:	call   4085a0 <__swc_fn_4fa09e82_000090_9a1d717d>
  410875:	mov    rcx,rax
  410878:	test   al,al
  41087a:	jne    41089c <__swc_fn_4fa09e82_000089_157b05de+0x24c>
  41087c:	mov    rcx,r15
  41087f:	mov    rdx,rsi
  410882:	call   40dba0 <__swc_fn_4fa09e82_000085_88128f21>
  410887:	mov    rcx,rax
  41088a:	test   al,al
  41088c:	jne    41089c <__swc_fn_4fa09e82_000089_157b05de+0x24c>
  41088e:	mov    rcx,rsi
  410891:	mov    rdx,r15
  410894:	call   40dba0 <__swc_fn_4fa09e82_000085_88128f21>
  410899:	mov    rcx,rax
  41089c:	test   cl,cl
  41089e:	setne  al
  4108a1:	mov    BYTE PTR [rbx],al
  4108a3:	xor    eax,eax
  4108a5:	mov    r14b,al
  4108a8:	test   rdi,rdi
  4108ab:	jne    4108c5 <__swc_fn_4fa09e82_000089_157b05de+0x275>
  4108ad:	test   r14b,r14b
  4108b0:	jne    4108c5 <__swc_fn_4fa09e82_000089_157b05de+0x275>
  4108b2:	xor    eax,eax
  4108b4:	add    rsp,0x38
  4108b8:	pop    r15
  4108ba:	pop    r14
  4108bc:	pop    r13
  4108be:	pop    r12
  4108c0:	pop    rdi
  4108c1:	pop    rsi
  4108c2:	pop    rbx
  4108c3:	pop    rbp
  4108c4:	ret
  4108c5:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4108ca:	je     4108d6 <__swc_fn_4fa09e82_000089_157b05de+0x286>
  4108cc:	mov    r12,QWORD PTR [rsp+0x18]
  4108d1:	jmp    41095e <__swc_fn_4fa09e82_000089_157b05de+0x30e>
  4108d6:	mov    r12,QWORD PTR [rsp+0x18]
  4108db:	test   r12,r12
  4108de:	jne    4108f2 <__swc_fn_4fa09e82_000089_157b05de+0x2a2>
  4108e0:	mov    rcx,r15
  4108e3:	mov    rdx,rsi
  4108e6:	xor    r8d,r8d
  4108e9:	call   4085a0 <__swc_fn_4fa09e82_000090_9a1d717d>
  4108ee:	test   al,al
  4108f0:	jne    41095e <__swc_fn_4fa09e82_000089_157b05de+0x30e>
  4108f2:	test   DWORD PTR [rsi+0x28],0x10000
  4108f9:	je     410917 <__swc_fn_4fa09e82_000089_157b05de+0x2c7>
  4108fb:	rex mov al,BYTE PTR [rsp+0x8]
  410900:	test   al,al
  410902:	jne    410917 <__swc_fn_4fa09e82_000089_157b05de+0x2c7>
  410904:	xor    eax,eax
  410906:	add    rsp,0x38
  41090a:	pop    r15
  41090c:	pop    r14
  41090e:	pop    r13
  410910:	pop    r12
  410912:	pop    rdi
  410913:	pop    rsi
  410914:	pop    rbx
  410915:	pop    rbp
  410916:	ret
  410917:	test   rdi,rdi
  41091a:	jne    41092f <__swc_fn_4fa09e82_000089_157b05de+0x2df>
  41091c:	xor    eax,eax
  41091e:	add    rsp,0x38
  410922:	pop    r15
  410924:	pop    r14
  410926:	pop    r13
  410928:	pop    r12
  41092a:	pop    rdi
  41092b:	pop    rsi
  41092c:	pop    rbx
  41092d:	pop    rbp
  41092e:	ret
  41092f:	cmp    QWORD PTR [rdi+0x8],0x0
  410934:	jne    410949 <__swc_fn_4fa09e82_000089_157b05de+0x2f9>
  410936:	xor    eax,eax
  410938:	add    rsp,0x38
  41093c:	pop    r15
  41093e:	pop    r14
  410940:	pop    r13
  410942:	pop    r12
  410944:	pop    rdi
  410945:	pop    rsi
  410946:	pop    rbx
  410947:	pop    rbp
  410948:	ret
  410949:	mov    rax,QWORD PTR [rdi+0x8]
  41094d:	mov    rax,QWORD PTR [rax]
  410950:	mov    rsi,rax
  410953:	mov    rdi,QWORD PTR [rdi]
  410956:	mov    eax,0x1
  41095b:	mov    r14b,al
  41095e:	test   rdi,rdi
  410961:	mov    rbx,QWORD PTR [rsp+0x20]
  410966:	jne    4109b0 <__swc_fn_4fa09e82_000089_157b05de+0x360>
  410968:	test   r14b,r14b
  41096b:	je     41099d <__swc_fn_4fa09e82_000089_157b05de+0x34d>
  41096d:	test   r12,r12
  410970:	je     41099d <__swc_fn_4fa09e82_000089_157b05de+0x34d>
  410972:	mov    rcx,r15
  410975:	mov    rdx,rsi
  410978:	xor    r8d,r8d
  41097b:	mov    r9,r12
  41097e:	mov    rbx,QWORD PTR [rsp+0x20]
  410983:	movzx  r10d,BYTE PTR [rbx]
  410987:	call   410540 <__swc_fn_4fa09e82_000083_fb84e43e>
  41098c:	add    rsp,0x38
  410990:	pop    r15
  410992:	pop    r14
  410994:	pop    r13
  410996:	pop    r12
  410998:	pop    rdi
  410999:	pop    rsi
  41099a:	pop    rbx
  41099b:	pop    rbp
  41099c:	ret
  41099d:	xor    eax,eax
  41099f:	add    rsp,0x38
  4109a3:	pop    r15
  4109a5:	pop    r14
  4109a7:	pop    r13
  4109a9:	pop    r12
  4109ab:	pop    rdi
  4109ac:	pop    rsi
  4109ad:	pop    rbx
  4109ae:	pop    rbp
  4109af:	ret
  4109b0:	mov    r13,rsi
  4109b3:	mov    QWORD PTR [rsp+0x28],rdi
  4109b8:	cmp    BYTE PTR [r15+0x2c],0xe
  4109bd:	sete   al
  4109c0:	mov    r14b,al
  4109c3:	jne    4109d7 <__swc_fn_4fa09e82_000089_157b05de+0x387>
  4109c5:	mov    rcx,rsi
  4109c8:	mov    rdx,r15
  4109cb:	call   40dba0 <__swc_fn_4fa09e82_000085_88128f21>
  4109d0:	mov    r14b,al
  4109d3:	test   al,al
  4109d5:	jne    410a0c <__swc_fn_4fa09e82_000089_157b05de+0x3bc>
  4109d7:	cmp    BYTE PTR [r15+0x2c],0x12
  4109dc:	je     410a0c <__swc_fn_4fa09e82_000089_157b05de+0x3bc>
  4109de:	mov    rcx,r15
  4109e1:	mov    rdx,rsi
  4109e4:	mov    r8,rdi
  4109e7:	mov    r9,r12
  4109ea:	mov    rax,rbx
  4109ed:	movzx  r10d,BYTE PTR [rax]
  4109f1:	call   410540 <__swc_fn_4fa09e82_000083_fb84e43e>
  4109f6:	test   rax,rax
  4109f9:	je     410a0c <__swc_fn_4fa09e82_000089_157b05de+0x3bc>
  4109fb:	add    rsp,0x38
  4109ff:	pop    r15
  410a01:	pop    r14
  410a03:	pop    r13
  410a05:	pop    r12
  410a07:	pop    rdi
  410a08:	pop    rsi
  410a09:	pop    rbx
  410a0a:	pop    rbp
  410a0b:	ret
  410a0c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  410a11:	jne    410a30 <__swc_fn_4fa09e82_000089_157b05de+0x3e0>
  410a13:	mov    rax,QWORD PTR [rsi+0xd8]
  410a1a:	test   rax,rax
  410a1d:	je     410a30 <__swc_fn_4fa09e82_000089_157b05de+0x3e0>
  410a1f:	add    rdi,QWORD PTR [rax+0x8]
  410a23:	mov    rax,QWORD PTR [rdi]
  410a26:	sub    rdi,QWORD PTR [rax+0x8]
  410a2a:	mov    rax,QWORD PTR [rax]
  410a2d:	mov    rsi,rax
  410a30:	test   r14b,r14b
  410a33:	je     410a5f <__swc_fn_4fa09e82_000089_157b05de+0x40f>
  410a35:	mov    rcx,r15
  410a38:	mov    rdx,rsi
  410a3b:	mov    r8,rdi
  410a3e:	mov    r9,r13
  410a41:	mov    r14,QWORD PTR [rsp+0x28]
  410a46:	mov    r10,r14
  410a49:	call   408480 <__swc_fn_4fa09e82_000087_1fb4fcfe>
  410a4e:	add    rsp,0x38
  410a52:	pop    r15
  410a54:	pop    r14
  410a56:	pop    r13
  410a58:	pop    r12
  410a5a:	pop    rdi
  410a5b:	pop    rsi
  410a5c:	pop    rbx
  410a5d:	pop    rbp
  410a5e:	ret
  410a5f:	mov    rcx,r15
  410a62:	mov    rdx,rsi
  410a65:	mov    r8,rdi
  410a68:	mov    r9,r12
  410a6b:	movzx  r10d,BYTE PTR [rbx]
  410a6f:	call   410540 <__swc_fn_4fa09e82_000083_fb84e43e>
  410a74:	add    rsp,0x38
  410a78:	pop    r15
  410a7a:	pop    r14
  410a7c:	pop    r13
  410a7e:	pop    r12
  410a80:	pop    rdi
  410a81:	pop    rsi
  410a82:	pop    rbx
  410a83:	pop    rbp
  410a84:	ret
	...

0000000000410a90 <__swc_fn_4fa09e82_000092_17e20532>:
  410a90:	push   rbx
  410a91:	push   rsi
  410a92:	sub    rsp,0x18
  410a96:	mov    rbx,rcx
  410a99:	mov    rcx,QWORD PTR [rip+0x162a0]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  410aa0:	test   rcx,rcx
  410aa3:	jne    410ab5 <__swc_fn_4fa09e82_000092_17e20532+0x25>
  410aa5:	call   40f060 <__swc_fn_4fa09e82_000166_e09accff>
  410aaa:	lea    rcx,[rax+0x1]
  410aae:	mov    QWORD PTR [rip+0x1628b],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  410ab5:	dec    rcx
  410ab8:	call   40b620 <__swc_fn_4fa09e82_000168_3130645d>
  410abd:	mov    rsi,rax
  410ac0:	mov    rax,QWORD PTR [rsi+0x8]
  410ac4:	test   rax,rax
  410ac7:	jne    410b17 <__swc_fn_4fa09e82_000092_17e20532+0x87>
  410ac9:	call   40dc90 <__swc_fn_4fa09e82_000091_e6773530>
  410ace:	test   al,al
  410ad0:	jne    410b17 <__swc_fn_4fa09e82_000092_17e20532+0x87>
  410ad2:	lea    rdx,[rip+0x13767]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  410ad9:	mov    rcx,rdx
  410adc:	call   407740 <__swc_fn_4fa09e82_000036_62160bb3>
  410ae1:	test   al,al
  410ae3:	jne    410af4 <__swc_fn_4fa09e82_000092_17e20532+0x64>
  410ae5:	mov    rcx,rdx
  410ae8:	call   40c580 <__swc_fn_4fa09e82_000034_c72914a2>
  410aed:	lea    rdx,[rip+0x1374c]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  410af4:	mov    QWORD PTR [rsp+0x8],rdx
  410af9:	lea    rax,[rip+0x2650]        # 413150 <__swc_rdata_base_4fa09e82+0x40>
  410b00:	mov    QWORD PTR [rsp+0x10],rax
  410b05:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  410b0b:	vmovups XMMWORD PTR [rsi],xmm0
  410b0f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  410b17:	vmovups xmm0,XMMWORD PTR [rsi]
  410b1b:	vmovups XMMWORD PTR [rbx],xmm0
  410b1f:	mov    rax,rbx
  410b22:	add    rsp,0x18
  410b26:	pop    rsi
  410b27:	pop    rbx
  410b28:	ret
  410b29:	add    BYTE PTR [rax],al
  410b2b:	add    BYTE PTR [rax],al
  410b2d:	add    BYTE PTR [rax],al
	...

0000000000410b30 <__swc_fn_4fa09e82_000095_a3245f7e>:
  410b30:	sub    rsp,0x8
  410b34:	call   40e200 <__swc_fn_4fa09e82_000118_76ff2f0a>
  410b39:	add    rsp,0x8
  410b3d:	ret
	...

0000000000410b40 <__swc_fn_4fa09e82_000098_d9d80f1a>:
  410b40:	push   rbx
  410b41:	push   rsi
  410b42:	sub    rsp,0x28
  410b46:	mov    rbx,rcx
  410b49:	xor    esi,esi
  410b4b:	jmp    410b60 <__swc_fn_4fa09e82_000098_d9d80f1a+0x20>
  410b4d:	nop    DWORD PTR [rax]
  410b50:	mov    QWORD PTR [rbx+0x28],rsi
  410b54:	mov    rsi,rbx
  410b57:	mov    rbx,rax
  410b5a:	nop    WORD PTR [rax+rax*1+0x0]
  410b60:	test   rbx,rbx
  410b63:	je     410bc3 <__swc_fn_4fa09e82_000098_d9d80f1a+0x83>
  410b65:	mov    rcx,rbx
  410b68:	mov    edx,0x1
  410b6d:	call   408200 <__swc_fn_4fa09e82_000078_5a70c27a>
  410b72:	cmp    rax,0x1
  410b76:	jne    410bc3 <__swc_fn_4fa09e82_000098_d9d80f1a+0x83>
  410b78:	mov    r10,QWORD PTR [rbx+0x18]
  410b7c:	mov    rcx,r10
  410b7f:	mov    edx,0x1
  410b84:	call   408200 <__swc_fn_4fa09e82_000078_5a70c27a>
  410b89:	cmp    rax,0x1
  410b8d:	jne    410b9c <__swc_fn_4fa09e82_000098_d9d80f1a+0x5c>
  410b8f:	mov    rcx,r10
  410b92:	call   40de30 <__swc_fn_4fa09e82_000097_8b4a07e9>
  410b97:	test   rax,rax
  410b9a:	jne    410b50 <__swc_fn_4fa09e82_000098_d9d80f1a+0x10>
  410b9c:	mov    rax,QWORD PTR [rbx+0x20]
  410ba0:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  410ba5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410bab:	lea    rcx,[rsp+0x8]
  410bb0:	mov    rdx,rbx
  410bb3:	mov    r8d,0x30
  410bb9:	mov    rbx,rax
  410bbc:	call   408960 <__swc_fn_4fa09e82_000096_f879630a>
  410bc1:	jmp    410b60 <__swc_fn_4fa09e82_000098_d9d80f1a+0x20>
  410bc3:	test   rsi,rsi
  410bc6:	jne    410bcf <__swc_fn_4fa09e82_000098_d9d80f1a+0x8f>
  410bc8:	add    rsp,0x28
  410bcc:	pop    rsi
  410bcd:	pop    rbx
  410bce:	ret
  410bcf:	mov    rax,rsi
  410bd2:	mov    rsi,QWORD PTR [rsi+0x28]
  410bd6:	mov    rbx,QWORD PTR [rax+0x20]
  410bda:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  410bdf:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  410be5:	lea    rcx,[rsp+0x18]
  410bea:	mov    rdx,rax
  410bed:	mov    r8d,0x30
  410bf3:	call   408960 <__swc_fn_4fa09e82_000096_f879630a>
  410bf8:	jmp    410b60 <__swc_fn_4fa09e82_000098_d9d80f1a+0x20>
  410bfd:	add    BYTE PTR [rax],al
	...

0000000000410c00 <__swc_fn_4fa09e82_000101_295ddd7c>:
  410c00:	push   rbx
  410c01:	push   rsi
  410c02:	push   rdi
  410c03:	push   r12
  410c05:	push   r13
  410c07:	sub    rsp,0x20
  410c0b:	mov    rbx,rcx
  410c0e:	lea    rsi,[rcx+0x6f8]
  410c15:	mov    edi,0x4
  410c1a:	mov    r12,rsi
  410c1d:	test   rdi,rdi
  410c20:	je     410c6a <__swc_fn_4fa09e82_000101_295ddd7c+0x6a>
  410c22:	cs nop WORD PTR [rax+rax*1+0x0]
  410c2c:	nop    DWORD PTR [rax+0x0]
  410c30:	mov    rcx,QWORD PTR [r12+0x10]
  410c35:	mov    QWORD PTR [r12+0x10],0x0
  410c3e:	vxorps xmm0,xmm0,xmm0
  410c42:	vmovups XMMWORD PTR [r12],xmm0
  410c48:	vmovups XMMWORD PTR [r12+0x28],xmm0
  410c4f:	mov    DWORD PTR [r12+0x20],0x0
  410c58:	call   4089b0 <__swc_fn_4fa09e82_000099_6e0faaee>
  410c5d:	add    r12,0x90
  410c64:	sub    rdi,0x1
  410c68:	jne    410c30 <__swc_fn_4fa09e82_000101_295ddd7c+0x30>
  410c6a:	mov    rax,QWORD PTR [rbx+0x938]
  410c71:	mov    rdi,rax
  410c74:	test   rdi,rdi
  410c77:	je     410cd1 <__swc_fn_4fa09e82_000101_295ddd7c+0xd1>
  410c79:	nop    DWORD PTR [rax+0x0]
  410c80:	mov    r12d,0x10
  410c86:	lea    r13,[rdi+0x18]
  410c8a:	test   r12,r12
  410c8d:	je     410cc6 <__swc_fn_4fa09e82_000101_295ddd7c+0xc6>
  410c8f:	nop
  410c90:	mov    rcx,QWORD PTR [r13+0x10]
  410c94:	mov    QWORD PTR [r13+0x10],0x0
  410c9c:	vxorps xmm0,xmm0,xmm0
  410ca0:	vmovups XMMWORD PTR [r13+0x0],xmm0
  410ca6:	vmovups XMMWORD PTR [r13+0x28],xmm0
  410cac:	mov    DWORD PTR [r13+0x20],0x0
  410cb4:	call   4089b0 <__swc_fn_4fa09e82_000099_6e0faaee>
  410cb9:	add    r13,0x90
  410cc0:	sub    r12,0x1
  410cc4:	jne    410c90 <__swc_fn_4fa09e82_000101_295ddd7c+0x90>
  410cc6:	mov    rax,QWORD PTR [rdi]
  410cc9:	mov    rdi,rax
  410ccc:	test   rax,rax
  410ccf:	jne    410c80 <__swc_fn_4fa09e82_000101_295ddd7c+0x80>
  410cd1:	vxorps xmm0,xmm0,xmm0
  410cd5:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  410cdd:	mov    DWORD PTR [rbx+0x9b0],0x0
  410ce7:	mov    DWORD PTR [rbx+0x9a8],0x0
  410cf1:	mov    edi,0x4
  410cf6:	mov    r12,rsi
  410cf9:	lea    rsi,[rsi+0x38]
  410cfd:	test   rdi,rdi
  410d00:	je     410d2c <__swc_fn_4fa09e82_000101_295ddd7c+0x12c>
  410d02:	cs nop WORD PTR [rax+rax*1+0x0]
  410d0c:	nop    DWORD PTR [rax+0x0]
  410d10:	mov    rcx,rsi
  410d13:	call   411bd0 <__swc_fn_4fa09e82_000158_5c8b11d8>
  410d18:	add    rsi,0x90
  410d1f:	add    r12,0x90
  410d26:	sub    rdi,0x1
  410d2a:	jne    410d10 <__swc_fn_4fa09e82_000101_295ddd7c+0x110>
  410d2c:	mov    rax,QWORD PTR [rbx+0x938]
  410d33:	mov    rdi,rax
  410d36:	mov    QWORD PTR [rbx+0x938],0x0
  410d41:	test   rdi,rdi
  410d44:	je     410db5 <__swc_fn_4fa09e82_000101_295ddd7c+0x1b5>
  410d4a:	nop    WORD PTR [rax+rax*1+0x0]
  410d50:	mov    esi,0x10
  410d55:	lea    r12,[rdi+0x18]
  410d59:	lea    r13,[rdi+0x50]
  410d5d:	test   rsi,rsi
  410d60:	je     410d8c <__swc_fn_4fa09e82_000101_295ddd7c+0x18c>
  410d62:	cs nop WORD PTR [rax+rax*1+0x0]
  410d6c:	nop    DWORD PTR [rax+0x0]
  410d70:	mov    rcx,r13
  410d73:	call   411bd0 <__swc_fn_4fa09e82_000158_5c8b11d8>
  410d78:	add    r13,0x90
  410d7f:	add    r12,0x90
  410d86:	sub    rsi,0x1
  410d8a:	jne    410d70 <__swc_fn_4fa09e82_000101_295ddd7c+0x170>
  410d8c:	mov    rax,QWORD PTR [rdi]
  410d8f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  410d94:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410d9a:	lea    rcx,[rsp+0x8]
  410d9f:	mov    rdx,rdi
  410da2:	mov    r8d,0x918
  410da8:	mov    rdi,rax
  410dab:	call   408960 <__swc_fn_4fa09e82_000096_f879630a>
  410db0:	test   rdi,rdi
  410db3:	jne    410d50 <__swc_fn_4fa09e82_000101_295ddd7c+0x150>
  410db5:	lea    rcx,[rbx+0x68]
  410db9:	call   411bd0 <__swc_fn_4fa09e82_000158_5c8b11d8>
  410dbe:	add    rsp,0x20
  410dc2:	pop    r13
  410dc4:	pop    r12
  410dc6:	pop    rdi
  410dc7:	pop    rsi
  410dc8:	pop    rbx
  410dc9:	ret
  410dca:	add    BYTE PTR [rax],al
  410dcc:	add    BYTE PTR [rax],al
	...

0000000000410dd0 <__swc_fn_4fa09e82_000104_baf871f8>:
  410dd0:	xor    eax,eax
  410dd2:	cs nop WORD PTR [rax+rax*1+0x0]
  410ddc:	nop    DWORD PTR [rax+0x0]
  410de0:	mov    r9,r8
  410de3:	sub    r9,rax
  410de6:	cmp    r9,0x40
  410dea:	jb     410e28 <__swc_fn_4fa09e82_000104_baf871f8+0x58>
  410dec:	lea    r9,[rcx+rax*1]
  410df0:	lea    r10,[rdx+rax*1]
  410df4:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  410dfa:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  410e00:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  410e06:	vmovups xmm3,XMMWORD PTR [r10]
  410e0b:	vmovups XMMWORD PTR [r9],xmm3
  410e10:	vmovups XMMWORD PTR [r9+0x10],xmm0
  410e16:	vmovups XMMWORD PTR [r9+0x20],xmm1
  410e1c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  410e22:	lea    rax,[rax+0x40]
  410e26:	jmp    410de0 <__swc_fn_4fa09e82_000104_baf871f8+0x10>
  410e28:	nop    DWORD PTR [rax+rax*1+0x0]
  410e30:	mov    r9,r8
  410e33:	sub    r9,rax
  410e36:	cmp    r9,0x10
  410e3a:	jb     410e54 <__swc_fn_4fa09e82_000104_baf871f8+0x84>
  410e3c:	lea    r9,[rdx+rax*1]
  410e40:	lea    r10,[rcx+rax*1]
  410e44:	vmovups xmm0,XMMWORD PTR [r9]
  410e49:	vmovups XMMWORD PTR [r10],xmm0
  410e4e:	lea    rax,[rax+0x10]
  410e52:	jmp    410e30 <__swc_fn_4fa09e82_000104_baf871f8+0x60>
  410e54:	cs nop WORD PTR [rax+rax*1+0x0]
  410e5e:	xchg   ax,ax
  410e60:	mov    r9,r8
  410e63:	sub    r9,rax
  410e66:	cmp    r9,0x8
  410e6a:	jb     410e7d <__swc_fn_4fa09e82_000104_baf871f8+0xad>
  410e6c:	lea    r9,[rcx+rax*1]
  410e70:	mov    r10,QWORD PTR [rdx+rax*1]
  410e74:	mov    QWORD PTR [r9],r10
  410e77:	lea    rax,[rax+0x8]
  410e7b:	jmp    410e60 <__swc_fn_4fa09e82_000104_baf871f8+0x90>
  410e7d:	cmp    rax,r8
  410e80:	jae    410ea0 <__swc_fn_4fa09e82_000104_baf871f8+0xd0>
  410e82:	cs nop WORD PTR [rax+rax*1+0x0]
  410e8c:	nop    DWORD PTR [rax+0x0]
  410e90:	mov    r9b,BYTE PTR [rdx+rax*1]
  410e94:	mov    BYTE PTR [rcx+rax*1],r9b
  410e98:	inc    rax
  410e9b:	cmp    rax,r8
  410e9e:	jb     410e90 <__swc_fn_4fa09e82_000104_baf871f8+0xc0>
  410ea0:	ret
	...

0000000000410eb0 <__swc_fn_4fa09e82_000107_77a5d54a>:
  410eb0:	test   r8,r8
  410eb3:	jne    410eb8 <__swc_fn_4fa09e82_000107_77a5d54a+0x8>
  410eb5:	xor    eax,eax
  410eb7:	ret
  410eb8:	xor    eax,eax
  410eba:	nop    WORD PTR [rax+rax*1+0x0]
  410ec0:	mov    r9,r8
  410ec3:	sub    r9,rax
  410ec6:	cmp    r9,0x10
  410eca:	jb     410f14 <__swc_fn_4fa09e82_000107_77a5d54a+0x64>
  410ecc:	lea    r9,[rcx+rax*1]
  410ed0:	lea    r10,[rdx+rax*1]
  410ed4:	vmovups xmm0,XMMWORD PTR [r10]
  410ed9:	vmovups xmm1,XMMWORD PTR [r9]
  410ede:	vpcmpeqb xmm0,xmm1,xmm0
  410ee2:	vpmovmskb r9d,xmm0
  410ee6:	cmp    r9d,0xffff
  410eed:	je     410f0e <__swc_fn_4fa09e82_000107_77a5d54a+0x5e>
  410eef:	not    r9d
  410ef2:	xor    r8d,r8d
  410ef5:	movzx  r9d,r9w
  410ef9:	tzcnt  r8d,r9d
  410efe:	add    rax,r8
  410f01:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410f05:	movzx  eax,BYTE PTR [rdx+rax*1]
  410f09:	sub    ecx,eax
  410f0b:	mov    eax,ecx
  410f0d:	ret
  410f0e:	lea    rax,[rax+0x10]
  410f12:	jmp    410ec0 <__swc_fn_4fa09e82_000107_77a5d54a+0x10>
  410f14:	cmp    r9,0x8
  410f18:	jb     410f8b <__swc_fn_4fa09e82_000107_77a5d54a+0xdb>
  410f1a:	lea    r9,[rcx+rax*1]
  410f1e:	lea    r10,[rdx+rax*1]
  410f22:	mov    r9,QWORD PTR [r9]
  410f25:	xor    r9,QWORD PTR [r10]
  410f28:	test   r9,r9
  410f2b:	je     410f49 <__swc_fn_4fa09e82_000107_77a5d54a+0x99>
  410f2d:	xor    r8d,r8d
  410f30:	tzcnt  r8,r9
  410f35:	shr    r8,0x3
  410f39:	add    rax,r8
  410f3c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410f40:	movzx  eax,BYTE PTR [rdx+rax*1]
  410f44:	sub    ecx,eax
  410f46:	mov    eax,ecx
  410f48:	ret
  410f49:	lea    rax,[rax+0x8]
  410f4d:	cmp    rax,r8
  410f50:	jne    410f55 <__swc_fn_4fa09e82_000107_77a5d54a+0xa5>
  410f52:	xor    eax,eax
  410f54:	ret
  410f55:	lea    rax,[r8-0x8]
  410f59:	lea    r8,[rcx+rax*1]
  410f5d:	lea    r9,[rdx+rax*1]
  410f61:	mov    r8,QWORD PTR [r8]
  410f64:	xor    r8,QWORD PTR [r9]
  410f67:	test   r8,r8
  410f6a:	je     410f88 <__swc_fn_4fa09e82_000107_77a5d54a+0xd8>
  410f6c:	xor    r9d,r9d
  410f6f:	tzcnt  r9,r8
  410f74:	shr    r9,0x3
  410f78:	add    rax,r9
  410f7b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410f7f:	movzx  eax,BYTE PTR [rdx+rax*1]
  410f83:	sub    ecx,eax
  410f85:	mov    eax,ecx
  410f87:	ret
  410f88:	xor    eax,eax
  410f8a:	ret
  410f8b:	cmp    r9,0x4
  410f8f:	jb     411002 <__swc_fn_4fa09e82_000107_77a5d54a+0x152>
  410f91:	lea    r9,[rcx+rax*1]
  410f95:	lea    r10,[rdx+rax*1]
  410f99:	mov    r9d,DWORD PTR [r9]
  410f9c:	xor    r9d,DWORD PTR [r10]
  410f9f:	test   r9d,r9d
  410fa2:	je     410fc0 <__swc_fn_4fa09e82_000107_77a5d54a+0x110>
  410fa4:	xor    r8d,r8d
  410fa7:	tzcnt  r8,r9
  410fac:	shr    r8,0x3
  410fb0:	add    rax,r8
  410fb3:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410fb7:	movzx  eax,BYTE PTR [rdx+rax*1]
  410fbb:	sub    ecx,eax
  410fbd:	mov    eax,ecx
  410fbf:	ret
  410fc0:	lea    rax,[rax+0x4]
  410fc4:	cmp    rax,r8
  410fc7:	jne    410fcc <__swc_fn_4fa09e82_000107_77a5d54a+0x11c>
  410fc9:	xor    eax,eax
  410fcb:	ret
  410fcc:	lea    rax,[r8-0x4]
  410fd0:	lea    r8,[rcx+rax*1]
  410fd4:	lea    r9,[rdx+rax*1]
  410fd8:	mov    r8d,DWORD PTR [r8]
  410fdb:	xor    r8d,DWORD PTR [r9]
  410fde:	test   r8d,r8d
  410fe1:	je     410fff <__swc_fn_4fa09e82_000107_77a5d54a+0x14f>
  410fe3:	xor    r9d,r9d
  410fe6:	tzcnt  r9,r8
  410feb:	shr    r9,0x3
  410fef:	add    rax,r9
  410ff2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410ff6:	movzx  eax,BYTE PTR [rdx+rax*1]
  410ffa:	sub    ecx,eax
  410ffc:	mov    eax,ecx
  410ffe:	ret
  410fff:	xor    eax,eax
  411001:	ret
  411002:	cmp    r9,0x2
  411006:	jb     411059 <__swc_fn_4fa09e82_000107_77a5d54a+0x1a9>
  411008:	lea    r9,[rcx+rax*1]
  41100c:	lea    r10,[rdx+rax*1]
  411010:	mov    r9w,WORD PTR [r9]
  411014:	xor    r9w,WORD PTR [r10]
  411018:	test   r9w,r9w
  41101c:	je     41103e <__swc_fn_4fa09e82_000107_77a5d54a+0x18e>
  41101e:	xor    r8d,r8d
  411021:	movzx  r9d,r9w
  411025:	tzcnt  r8,r9
  41102a:	shr    r8,0x3
  41102e:	add    rax,r8
  411031:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411035:	movzx  eax,BYTE PTR [rdx+rax*1]
  411039:	sub    ecx,eax
  41103b:	mov    eax,ecx
  41103d:	ret
  41103e:	lea    rax,[rax+0x2]
  411042:	cmp    rax,r8
  411045:	jne    41104a <__swc_fn_4fa09e82_000107_77a5d54a+0x19a>
  411047:	xor    eax,eax
  411049:	ret
  41104a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  411050:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  411056:	sub    eax,ecx
  411058:	ret
  411059:	test   r9,r9
  41105c:	je     41106b <__swc_fn_4fa09e82_000107_77a5d54a+0x1bb>
  41105e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411062:	movzx  eax,BYTE PTR [rdx+rax*1]
  411066:	sub    ecx,eax
  411068:	mov    eax,ecx
  41106a:	ret
  41106b:	xor    eax,eax
  41106d:	ret
	...

0000000000411070 <__swc_fn_4fa09e82_000110_aa570b2b>:
  411070:	push   r12
  411072:	push   r13
  411074:	push   r14
  411076:	push   rdi
  411077:	push   rsi
  411078:	push   r15
  41107a:	sub    rsp,0xd8
  411081:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  411087:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  41108d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  411093:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  411099:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  41109f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  4110a8:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  4110b1:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  4110ba:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  4110c3:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  4110cc:	mov    r12,rcx
  4110cf:	test   rcx,rcx
  4110d2:	je     4110ee <__swc_fn_4fa09e82_000110_aa570b2b+0x7e>
  4110d4:	mov    eax,r12d
  4110d7:	and    eax,0xfff
  4110dd:	setne  al
  4110e0:	cmp    r12,0xffffffffffffefff
  4110e7:	seta   cl
  4110ea:	or     al,cl
  4110ec:	je     4110f5 <__swc_fn_4fa09e82_000110_aa570b2b+0x85>
  4110ee:	xor    eax,eax
  4110f0:	jmp    41118b <__swc_fn_4fa09e82_000110_aa570b2b+0x11b>
  4110f5:	call   40dfc0 <__swc_fn_4fa09e82_000109_32416b9e>
  4110fa:	mov    r13,rax
  4110fd:	test   rax,rax
  411100:	jne    411109 <__swc_fn_4fa09e82_000110_aa570b2b+0x99>
  411102:	xor    eax,eax
  411104:	jmp    41118b <__swc_fn_4fa09e82_000110_aa570b2b+0x11b>
  411109:	lea    r14,[r12+0x1000]
  411111:	xor    edi,edi
  411113:	mov    rsi,r14
  411116:	xor    edx,edx
  411118:	mov    ecx,0x22
  41111d:	mov    eax,0xffffffff
  411122:	movsxd r8,eax
  411125:	xor    r9d,r9d
  411128:	xor    eax,eax
  41112a:	call   4070d0 <mmap@plt>
  41112f:	mov    r15,rax
  411132:	cmp    rax,0xffffffffffffffff
  411136:	jne    41113c <__swc_fn_4fa09e82_000110_aa570b2b+0xcc>
  411138:	xor    eax,eax
  41113a:	jmp    41118b <__swc_fn_4fa09e82_000110_aa570b2b+0x11b>
  41113c:	mov    rdi,r15
  41113f:	mov    esi,0x1000
  411144:	mov    edx,0x3
  411149:	xor    eax,eax
  41114b:	call   407170 <mprotect@plt>
  411150:	test   eax,eax
  411152:	je     411165 <__swc_fn_4fa09e82_000110_aa570b2b+0xf5>
  411154:	mov    rdi,r15
  411157:	mov    rsi,r14
  41115a:	xor    eax,eax
  41115c:	call   407160 <munmap@plt>
  411161:	xor    eax,eax
  411163:	jmp    41118b <__swc_fn_4fa09e82_000110_aa570b2b+0x11b>
  411165:	mov    QWORD PTR [r15+0x8],r12
  411169:	mov    rcx,r13
  41116c:	call   4117d0 <__swc_fn_4fa09e82_000134_c6de0049>
  411171:	mov    rax,QWORD PTR [r13+0x8]
  411175:	mov    QWORD PTR [r15],rax
  411178:	mov    QWORD PTR [r13+0x8],r15
  41117c:	mov    rcx,r13
  41117f:	call   409d20 <__swc_fn_4fa09e82_000135_5696c87e>
  411184:	lea    rax,[r15+0x1000]
  41118b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  411191:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  411197:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  41119d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4111a3:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4111a9:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  4111b2:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  4111bb:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  4111c4:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  4111cd:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  4111d6:	add    rsp,0xd8
  4111dd:	pop    r15
  4111df:	pop    rsi
  4111e0:	pop    rdi
  4111e1:	pop    r14
  4111e3:	pop    r13
  4111e5:	pop    r12
  4111e7:	ret
	...

00000000004111f0 <__swc_fn_4fa09e82_000113_cb2656be>:
  4111f0:	push   rbx
  4111f1:	push   r12
  4111f3:	push   rdi
  4111f4:	push   rsi
  4111f5:	sub    rsp,0xa8
  4111fc:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  411202:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411208:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41120e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411214:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  41121a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  411220:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411226:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  41122c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411235:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41123e:	mov    rbx,rdx
  411241:	mov    r12,rcx
  411244:	mov    rdi,rcx
  411247:	mov    rsi,rdx
  41124a:	xor    edx,edx
  41124c:	xor    eax,eax
  41124e:	call   407170 <mprotect@plt>
  411253:	test   eax,eax
  411255:	jne    411279 <__swc_fn_4fa09e82_000113_cb2656be+0x89>
  411257:	mov    rcx,r12
  41125a:	mov    rdx,rbx
  41125d:	xor    al,al
  41125f:	mov    r8,rax
  411262:	call   4097c0 <__swc_fn_4fa09e82_000111_e606239a>
  411267:	mov    rdi,r12
  41126a:	mov    rsi,rbx
  41126d:	mov    edx,0x4
  411272:	xor    eax,eax
  411274:	call   4071d0 <madvise@plt>
  411279:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41127f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411285:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41128b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411291:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411297:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  41129d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4112a3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4112a9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4112b2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4112bb:	add    rsp,0xa8
  4112c2:	pop    rsi
  4112c3:	pop    rdi
  4112c4:	pop    r12
  4112c6:	pop    rbx
  4112c7:	ret
	...

00000000004112d0 <__swc_fn_4fa09e82_000116_259b5d5a>:
  4112d0:	push   rsi
  4112d1:	push   rdi
  4112d2:	push   r12
  4112d4:	push   r13
  4112d6:	push   r14
  4112d8:	sub    rsp,0xe0
  4112df:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  4112e5:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  4112eb:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  4112f1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  4112f7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  4112fd:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  411306:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  41130f:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  411318:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  411321:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  41132a:	mov    rsi,rdx
  41132d:	mov    rdi,rcx
  411330:	call   40dfc0 <__swc_fn_4fa09e82_000109_32416b9e>
  411335:	mov    r12,rax
  411338:	test   rax,rax
  41133b:	jne    411342 <__swc_fn_4fa09e82_000116_259b5d5a+0x72>
  41133d:	jmp    4113b6 <__swc_fn_4fa09e82_000116_259b5d5a+0xe6>
  411342:	mov    rcx,r12
  411345:	call   4117d0 <__swc_fn_4fa09e82_000134_c6de0049>
  41134a:	lea    r13,[r12+0x8]
  41134f:	mov    rax,QWORD PTR [r13+0x0]
  411353:	test   rax,rax
  411356:	je     4113ae <__swc_fn_4fa09e82_000116_259b5d5a+0xde>
  411358:	nop    DWORD PTR [rax+rax*1+0x0]
  411360:	lea    rcx,[rax+0x1000]
  411367:	cmp    rcx,rdi
  41136a:	jne    4113a2 <__swc_fn_4fa09e82_000116_259b5d5a+0xd2>
  41136c:	cmp    QWORD PTR [rax+0x8],rsi
  411370:	je     41137c <__swc_fn_4fa09e82_000116_259b5d5a+0xac>
  411372:	mov    rcx,r12
  411375:	call   409d20 <__swc_fn_4fa09e82_000135_5696c87e>
  41137a:	jmp    4113b6 <__swc_fn_4fa09e82_000116_259b5d5a+0xe6>
  41137c:	mov    r14,QWORD PTR [rax]
  41137f:	mov    rdi,rax
  411382:	lea    rsi,[rsi+0x1000]
  411389:	xor    eax,eax
  41138b:	call   407160 <munmap@plt>
  411390:	test   eax,eax
  411392:	jne    411398 <__swc_fn_4fa09e82_000116_259b5d5a+0xc8>
  411394:	mov    QWORD PTR [r13+0x0],r14
  411398:	mov    rcx,r12
  41139b:	call   409d20 <__swc_fn_4fa09e82_000135_5696c87e>
  4113a0:	jmp    4113b6 <__swc_fn_4fa09e82_000116_259b5d5a+0xe6>
  4113a2:	mov    r13,rax
  4113a5:	mov    rax,QWORD PTR [r13+0x0]
  4113a9:	test   rax,rax
  4113ac:	jne    411360 <__swc_fn_4fa09e82_000116_259b5d5a+0x90>
  4113ae:	mov    rcx,r12
  4113b1:	call   409d20 <__swc_fn_4fa09e82_000135_5696c87e>
  4113b6:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4113bc:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4113c2:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4113c8:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4113ce:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4113d4:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  4113dd:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  4113e6:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  4113ef:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  4113f8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  411401:	add    rsp,0xe0
  411408:	pop    r14
  41140a:	pop    r13
  41140c:	pop    r12
  41140e:	pop    rdi
  41140f:	pop    rsi
  411410:	ret
	...

0000000000411420 <__swc_fn_4fa09e82_000119_2b35b5e0>:
  411420:	push   rdi
  411421:	push   rsi
  411422:	sub    rsp,0xa8
  411429:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41142f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411435:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41143b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411441:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411447:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41144d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411453:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411459:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411462:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41146b:	mov    rdi,0xfffffffffffffd66
  411472:	xor    eax,eax
  411474:	call   407180 <exit@plt>
  411479:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41147f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411485:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41148b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411491:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411497:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  41149d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4114a3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4114a9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4114b2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4114bb:	add    rsp,0xa8
  4114c2:	pop    rsi
  4114c3:	pop    rdi
  4114c4:	ret
	...

00000000004114e0 <__swc_fn_4fa09e82_000122_71a5b1cd>:
  4114e0:	push   rbx
  4114e1:	push   rsi
  4114e2:	push   rdi
  4114e3:	sub    rsp,0x30
  4114e7:	mov    rbx,rdx
  4114ea:	mov    esi,ecx
  4114ec:	test   ecx,ecx
  4114ee:	je     4115c3 <__swc_fn_4fa09e82_000122_71a5b1cd+0xe3>
  4114f4:	mov    rcx,rsi
  4114f7:	shl    rcx,0x4
  4114fb:	call   40dad0 <__swc_fn_4fa09e82_000079_29fad089>
  411500:	test   rax,rax
  411503:	je     4115b2 <__swc_fn_4fa09e82_000122_71a5b1cd+0xd2>
  411509:	mov    rcx,rsi
  41150c:	xor    edx,edx
  41150e:	test   rsi,rsi
  411511:	jbe    411592 <__swc_fn_4fa09e82_000122_71a5b1cd+0xb2>
  411517:	nop    WORD PTR [rax+rax*1+0x0]
  411520:	mov    r8d,edx
  411523:	mov    r9,QWORD PTR [rbx+r8*8]
  411527:	add    r8,r8
  41152a:	lea    r8,[rax+r8*8]
  41152e:	xor    r10d,r10d
  411531:	test   r9,r9
  411534:	je     411570 <__swc_fn_4fa09e82_000122_71a5b1cd+0x90>
  411536:	mov    r11,r9
  411539:	mov    dil,BYTE PTR [r11]
  41153c:	test   dil,dil
  41153f:	je     411570 <__swc_fn_4fa09e82_000122_71a5b1cd+0x90>
  411541:	cs nop WORD PTR [rax+rax*1+0x0]
  41154b:	cs nop WORD PTR [rax+rax*1+0x0]
  411555:	cs nop WORD PTR [rax+rax*1+0x0]
  41155f:	nop
  411560:	add    r11,0x1
  411564:	add    r10,0x1
  411568:	mov    dil,BYTE PTR [r11]
  41156b:	test   dil,dil
  41156e:	jne    411560 <__swc_fn_4fa09e82_000122_71a5b1cd+0x80>
  411570:	mov    QWORD PTR [rsp+0x18],r9
  411575:	mov    QWORD PTR [rsp+0x20],r10
  41157a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411580:	vmovups XMMWORD PTR [r8],xmm0
  411585:	add    rdx,0x1
  411589:	cmp    rdx,rcx
  41158c:	jb     411520 <__swc_fn_4fa09e82_000122_71a5b1cd+0x40>
  411592:	lea    rcx,[rip+0x157b7]        # 426d50 <__swc_bss_base_4fa09e82+0x2d10>
  411599:	mov    QWORD PTR [rsp+0x8],rax
  41159e:	mov    esi,esi
  4115a0:	mov    QWORD PTR [rsp+0x10],rsi
  4115a5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4115ab:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4115b0:	jmp    4115c3 <__swc_fn_4fa09e82_000122_71a5b1cd+0xe3>
  4115b2:	lea    rcx,[rip+0x1f67]        # 413520 <__swc_rdata_base_4fa09e82+0x410>
  4115b9:	call   409870 <__swc_fn_4fa09e82_000117_3499f7d6>
  4115be:	call   411420 <__swc_fn_4fa09e82_000119_2b35b5e0>
  4115c3:	add    rsp,0x30
  4115c7:	pop    rdi
  4115c8:	pop    rsi
  4115c9:	pop    rbx
  4115ca:	ret
  4115cb:	add    BYTE PTR [rax],al
  4115cd:	add    BYTE PTR [rax],al
	...

00000000004115d0 <__swc_fn_4fa09e82_000125_df97aa0a>:
  4115d0:	push   rdi
  4115d1:	push   rsi
  4115d2:	sub    rsp,0xa8
  4115d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4115df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4115e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4115eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4115f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4115f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4115fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411603:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411609:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411612:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41161b:	mov    edi,ecx
  41161d:	xor    eax,eax
  41161f:	call   4071e0 <pthread_key_delete@plt>
  411624:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41162a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411630:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411636:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41163c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411642:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411648:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41164e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411654:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41165d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411666:	add    rsp,0xa8
  41166d:	pop    rsi
  41166e:	pop    rdi
  41166f:	ret

0000000000411670 <__swc_fn_4fa09e82_000128_75f8ab5c>:
  411670:	push   rdi
  411671:	push   rsi
  411672:	sub    rsp,0xa8
  411679:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41167f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411685:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41168b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411691:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411697:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41169d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4116a3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4116a9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4116b2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4116bb:	test   rcx,rcx
  4116be:	je     4116cf <__swc_fn_4fa09e82_000128_75f8ab5c+0x5f>
  4116c0:	lea    rax,[rcx-0x1]
  4116c4:	mov    eax,eax
  4116c6:	mov    edi,eax
  4116c8:	xor    eax,eax
  4116ca:	call   4071e0 <pthread_key_delete@plt>
  4116cf:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4116d5:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4116db:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4116e1:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4116e7:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4116ed:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4116f3:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4116f9:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4116ff:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411708:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411711:	add    rsp,0xa8
  411718:	pop    rsi
  411719:	pop    rdi
  41171a:	ret
  41171b:	add    BYTE PTR [rax],al
  41171d:	add    BYTE PTR [rax],al
	...

0000000000411720 <__swc_fn_4fa09e82_000131_d2d78689>:
  411720:	push   rsi
  411721:	push   rdi
  411722:	sub    rsp,0xa8
  411729:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41172f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411735:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41173b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411741:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411747:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41174d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411753:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411759:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411762:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41176b:	xor    eax,eax
  41176d:	call   4071f0 <gettid@plt>
  411772:	movsxd rax,eax
  411775:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41177b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411781:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411787:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41178d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411793:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411799:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41179f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4117a5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4117ae:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4117b7:	add    rsp,0xa8
  4117be:	pop    rdi
  4117bf:	pop    rsi
  4117c0:	ret
	...

00000000004117d0 <__swc_fn_4fa09e82_000134_c6de0049>:
  4117d0:	push   rbx
  4117d1:	push   rdi
  4117d2:	push   rsi
  4117d3:	sub    rsp,0xc0
  4117da:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4117e0:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4117e6:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4117ec:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4117f2:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4117f8:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4117fe:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  411804:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41180d:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  411816:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41181f:	mov    rbx,rcx
  411822:	cs nop WORD PTR [rax+rax*1+0x0]
  41182c:	nop    DWORD PTR [rax+0x0]
  411830:	mov    edx,0x80000000
  411835:	xor    eax,eax
  411837:	lock cmpxchg DWORD PTR [rbx],edx
  41183b:	test   eax,eax
  41183d:	je     411874 <__swc_fn_4fa09e82_000134_c6de0049+0xa4>
  41183f:	mov    eax,DWORD PTR [rbx]
  411841:	lea    rcx,[rsp+0x14]
  411846:	mov    DWORD PTR [rsp+0x14],eax
  41184a:	test   eax,eax
  41184c:	je     411830 <__swc_fn_4fa09e82_000134_c6de0049+0x60>
  41184e:	mov    QWORD PTR [rsp],0x0
  411856:	mov    edi,0xca
  41185b:	mov    rsi,rbx
  41185e:	mov    edx,0x80
  411863:	mov    ecx,DWORD PTR [rcx]
  411865:	xor    r8d,r8d
  411868:	xor    r9d,r9d
  41186b:	xor    eax,eax
  41186d:	call   4071a0 <syscall@plt>
  411872:	jmp    411830 <__swc_fn_4fa09e82_000134_c6de0049+0x60>
  411874:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  41187a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411880:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411886:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41188c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411892:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411898:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41189e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4118a7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4118b0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4118b9:	add    rsp,0xc0
  4118c0:	pop    rsi
  4118c1:	pop    rdi
  4118c2:	pop    rbx
  4118c3:	ret
	...

00000000004118d0 <__swc_fn_4fa09e82_000137_5589b4a1>:
  4118d0:	sub    rsp,0x8
  4118d4:	call   409d20 <__swc_fn_4fa09e82_000135_5696c87e>
  4118d9:	add    rsp,0x8
  4118dd:	ret
	...

00000000004118e0 <__swc_fn_4fa09e82_000140_20e2e2c7>:
  4118e0:	push   rdi
  4118e1:	push   rsi
  4118e2:	sub    rsp,0xa8
  4118e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4118ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4118f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4118fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411901:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411907:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41190d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411913:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411919:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411922:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41192b:	mov    edi,0x28
  411930:	xor    eax,eax
  411932:	call   4071c0 <malloc@plt>
  411937:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41193d:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411943:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411949:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41194f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411955:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  41195b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411961:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411967:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411970:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411979:	add    rsp,0xa8
  411980:	pop    rsi
  411981:	pop    rdi
  411982:	ret
	...

0000000000411990 <__swc_fn_4fa09e82_000143_e0543f36>:
  411990:	mov    QWORD PTR [r8],0x0
  411997:	cmp    rdx,0x10
  41199b:	jae    4119a0 <__swc_fn_4fa09e82_000143_e0543f36+0x10>
  41199d:	xor    eax,eax
  41199f:	ret
  4119a0:	mov    eax,DWORD PTR [rcx]
  4119a2:	cmp    eax,0x42445753
  4119a8:	jne    4119b2 <__swc_fn_4fa09e82_000143_e0543f36+0x22>
  4119aa:	mov    eax,DWORD PTR [rcx+0x4]
  4119ad:	cmp    eax,0x1
  4119b0:	je     4119b5 <__swc_fn_4fa09e82_000143_e0543f36+0x25>
  4119b2:	xor    eax,eax
  4119b4:	ret
  4119b5:	mov    QWORD PTR [r8],rdx
  4119b8:	mov    rax,rcx
  4119bb:	ret
  4119bc:	add    BYTE PTR [rax],al
	...

00000000004119c0 <__swc_fn_4fa09e82_000146_071b4f4c>:
  4119c0:	push   rbx
  4119c1:	sub    rsp,0xe0
  4119c8:	lea    rbx,[rsp+0x8]
  4119cd:	vxorps xmm0,xmm0,xmm0
  4119d1:	vmovups YMMWORD PTR [rbx],ymm0
  4119d5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  4119da:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  4119df:	vzeroupper
  4119e2:	mov    DWORD PTR [rbx+0x60],0x0
  4119e9:	mov    r8,rbx
  4119ec:	mov    rdx,rcx
  4119ef:	nop
  4119f0:	mov    r9,rdx
  4119f3:	movabs rdx,0x6666666666666667
  4119fd:	mov    rax,r9
  411a00:	imul   rdx
  411a03:	sar    rdx,0x2
  411a07:	mov    r10,rdx
  411a0a:	shr    rdx,0x3f
  411a0e:	add    r10,rdx
  411a11:	mov    rdx,r10
  411a14:	imul   r11,r10,0xa
  411a18:	sub    r9,r11
  411a1b:	mov    r11,QWORD PTR [rip+0x1b1e]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  411a22:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  411a27:	mov    BYTE PTR [r8],r9b
  411a2a:	lea    r9,[r8+0x1]
  411a2e:	mov    r8,r9
  411a31:	test   r10,r10
  411a34:	jne    4119f0 <__swc_fn_4fa09e82_000146_071b4f4c+0x30>
  411a36:	test   rcx,rcx
  411a39:	jge    411a43 <__swc_fn_4fa09e82_000146_071b4f4c+0x83>
  411a3b:	mov    BYTE PTR [r9],0x2d
  411a3f:	add    r8,0x1
  411a43:	mov    BYTE PTR [r8],0x0
  411a47:	sub    r8,0x1
  411a4b:	mov    rax,rbx
  411a4e:	cmp    rax,r8
  411a51:	jae    411a76 <__swc_fn_4fa09e82_000146_071b4f4c+0xb6>
  411a53:	cs nop WORD PTR [rax+rax*1+0x0]
  411a5d:	nop    DWORD PTR [rax]
  411a60:	mov    cl,BYTE PTR [r8]
  411a63:	mov    dl,BYTE PTR [rax]
  411a65:	mov    BYTE PTR [r8],dl
  411a68:	sub    r8,0x1
  411a6c:	mov    BYTE PTR [rax],cl
  411a6e:	inc    rax
  411a71:	cmp    rax,r8
  411a74:	jb     411a60 <__swc_fn_4fa09e82_000146_071b4f4c+0xa0>
  411a76:	xor    eax,eax
  411a78:	test   rbx,rbx
  411a7b:	je     411a9e <__swc_fn_4fa09e82_000146_071b4f4c+0xde>
  411a7d:	mov    rcx,rbx
  411a80:	mov    dl,BYTE PTR [rcx]
  411a82:	test   dl,dl
  411a84:	je     411a9e <__swc_fn_4fa09e82_000146_071b4f4c+0xde>
  411a86:	cs nop WORD PTR [rax+rax*1+0x0]
  411a90:	add    rcx,0x1
  411a94:	add    rax,0x1
  411a98:	mov    dl,BYTE PTR [rcx]
  411a9a:	test   dl,dl
  411a9c:	jne    411a90 <__swc_fn_4fa09e82_000146_071b4f4c+0xd0>
  411a9e:	mov    QWORD PTR [rbx+0xa8],rbx
  411aa5:	mov    QWORD PTR [rbx+0xb0],rax
  411aac:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  411ab4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  411abc:	lea    rcx,[rbx+0xb8]
  411ac3:	call   409870 <__swc_fn_4fa09e82_000117_3499f7d6>
  411ac8:	add    rsp,0xe0
  411acf:	pop    rbx
  411ad0:	ret
	...

0000000000411ae0 <__swc_fn_4fa09e82_000149_33e5e24f>:
  411ae0:	vxorps xmm0,xmm0,xmm0
  411ae4:	vmovups XMMWORD PTR [rcx],xmm0
  411ae8:	mov    QWORD PTR [rcx+0x10],0x0
  411af0:	ret
	...

0000000000411b00 <__swc_fn_4fa09e82_000152_33e5e24f>:
  411b00:	vxorps xmm0,xmm0,xmm0
  411b04:	vmovups XMMWORD PTR [rcx],xmm0
  411b08:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411b0d:	vxorps xmm0,xmm0,xmm0
  411b11:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411b16:	vmovups xmm0,XMMWORD PTR [rip+0x1b1a]        # 413638 <__swc_rdata_base_4fa09e82+0x528>
  411b1e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411b23:	vxorps xmm0,xmm0,xmm0
  411b27:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411b2c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411b31:	mov    QWORD PTR [rcx+0x60],0x0
  411b39:	ret
  411b3a:	add    BYTE PTR [rax],al
  411b3c:	add    BYTE PTR [rax],al
	...

0000000000411b40 <__swc_fn_4fa09e82_000155_33e5e24f>:
  411b40:	vxorps xmm0,xmm0,xmm0
  411b44:	vmovups XMMWORD PTR [rcx],xmm0
  411b48:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411b4d:	vxorps xmm0,xmm0,xmm0
  411b51:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411b56:	vmovups xmm0,XMMWORD PTR [rip+0x1c02]        # 413760 <__swc_rdata_base_4fa09e82+0x650>
  411b5e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411b63:	vxorps xmm0,xmm0,xmm0
  411b67:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411b6c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411b71:	vxorps xmm0,xmm0,xmm0
  411b75:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411b7a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  411b7f:	vxorps xmm0,xmm0,xmm0
  411b83:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  411b8b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  411b93:	vxorps xmm0,xmm0,xmm0
  411b97:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  411b9f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  411ba7:	vxorps xmm0,xmm0,xmm0
  411bab:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  411bb3:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  411bbb:	mov    QWORD PTR [rcx+0xe0],0x0
  411bc6:	ret
	...

0000000000411bd0 <__swc_fn_4fa09e82_000158_5c8b11d8>:
  411bd0:	push   rbx
  411bd1:	mov    rbx,rcx
  411bd4:	call   40b2b0 <__swc_fn_4fa09e82_000159_6741c23b>
  411bd9:	mov    rax,QWORD PTR [rbx+0x10]
  411bdd:	test   rax,rax
  411be0:	je     411bf1 <__swc_fn_4fa09e82_000158_5c8b11d8+0x21>
  411be2:	mov    rcx,rbx
  411be5:	mov    rdx,rax
  411be8:	mov    r8,QWORD PTR [rbx+0x18]
  411bec:	call   40ed50 <__swc_fn_4fa09e82_000157_312df05a>
  411bf1:	vxorps xmm0,xmm0,xmm0
  411bf5:	vmovups XMMWORD PTR [rbx],xmm0
  411bf9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411bfe:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411c03:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  411c08:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  411c0d:	mov    QWORD PTR [rbx+0x50],0x0
  411c15:	pop    rbx
  411c16:	ret
	...

0000000000411c20 <__swc_fn_4fa09e82_000161_e25d06b9>:
  411c20:	sub    rsp,0x10
  411c24:	mov    eax,r8d
  411c27:	mov    r8d,r9d
  411c2a:	test   r9d,r9d
  411c2d:	jne    411c46 <__swc_fn_4fa09e82_000161_e25d06b9+0x26>
  411c2f:	vmovups xmm0,XMMWORD PTR [rip+0x1be1]        # 413818 <__swc_rdata_base_4fa09e82+0x708>
  411c37:	vmovups XMMWORD PTR [r10],xmm0
  411c3c:	mov    eax,0x1
  411c41:	add    rsp,0x10
  411c45:	ret
  411c46:	mov    r9,r8
  411c49:	cmp    r8,rax
  411c4c:	jb     411c53 <__swc_fn_4fa09e82_000161_e25d06b9+0x33>
  411c4e:	cmp    r9,rdx
  411c51:	jb     411c5a <__swc_fn_4fa09e82_000161_e25d06b9+0x3a>
  411c53:	xor    eax,eax
  411c55:	add    rsp,0x10
  411c59:	ret
  411c5a:	xor    eax,eax
  411c5c:	lea    r8,[r9+rax*1]
  411c60:	cmp    r8,rdx
  411c63:	jae    411c93 <__swc_fn_4fa09e82_000161_e25d06b9+0x73>
  411c65:	cs nop WORD PTR [rax+rax*1+0x0]
  411c6f:	cs nop WORD PTR [rax+rax*1+0x0]
  411c79:	nop    DWORD PTR [rax+0x0]
  411c80:	cmp    BYTE PTR [rcx+r8*1],0x0
  411c85:	je     411c93 <__swc_fn_4fa09e82_000161_e25d06b9+0x73>
  411c87:	inc    rax
  411c8a:	lea    r8,[r9+rax*1]
  411c8e:	cmp    r8,rdx
  411c91:	jb     411c80 <__swc_fn_4fa09e82_000161_e25d06b9+0x60>
  411c93:	cmp    r8,rdx
  411c96:	jne    411c9f <__swc_fn_4fa09e82_000161_e25d06b9+0x7f>
  411c98:	xor    eax,eax
  411c9a:	add    rsp,0x10
  411c9e:	ret
  411c9f:	add    rcx,r9
  411ca2:	mov    QWORD PTR [rsp],rcx
  411ca6:	mov    QWORD PTR [rsp+0x8],rax
  411cab:	vmovups xmm0,XMMWORD PTR [rsp]
  411cb0:	vmovups XMMWORD PTR [r10],xmm0
  411cb5:	mov    eax,0x1
  411cba:	add    rsp,0x10
  411cbe:	ret
	...

0000000000411cc0 <__swc_fn_4fa09e82_000164_5fbed98a>:
  411cc0:	push   rbp
  411cc1:	push   rbx
  411cc2:	push   rsi
  411cc3:	push   rdi
  411cc4:	push   r12
  411cc6:	push   r13
  411cc8:	push   r14
  411cca:	push   r15
  411ccc:	sub    rsp,0x10
  411cd0:	mov    rbp,rsp
  411cd3:	vmovups XMMWORD PTR [rsp],xmm6
  411cd8:	sub    rsp,0x50
  411cdc:	mov    rbx,rsp
  411cdf:	mov    rsi,r8
  411ce2:	mov    QWORD PTR [rsp+0x30],r8
  411ce7:	mov    rdi,rcx
  411cea:	mov    QWORD PTR [rsp+0x38],rcx
  411cef:	mov    r12,rdx
  411cf2:	xor    r13b,r13b
  411cf5:	mov    r14,QWORD PTR [rdi+0x8]
  411cf9:	mov    QWORD PTR [rsp+0x40],r14
  411cfe:	xor    r15d,r15d
  411d01:	test   r14,r14
  411d04:	jbe    411f5e <__swc_fn_4fa09e82_000164_5fbed98a+0x29e>
  411d0a:	mov    r14,QWORD PTR [rdi]
  411d0d:	mov    rax,QWORD PTR [rsp+0x40]
  411d12:	mov    QWORD PTR [rsp+0x48],r14
  411d17:	vmovups xmm6,XMMWORD PTR [rip+0x1719]        # 413438 <__swc_rdata_base_4fa09e82+0x328>
  411d1f:	nop
  411d20:	cmp    QWORD PTR [r14+r15*8],0x0
  411d25:	jne    411d2f <__swc_fn_4fa09e82_000164_5fbed98a+0x6f>
  411d27:	mov    r14,rax
  411d2a:	jmp    411f3e <__swc_fn_4fa09e82_000164_5fbed98a+0x27e>
  411d2f:	mov    rcx,QWORD PTR [rdi]
  411d32:	mov    rdx,QWORD PTR [rcx+r15*8]
  411d36:	mov    rdi,rbx
  411d39:	mov    rcx,rdi
  411d3c:	sub    rsp,0x8
  411d40:	mov    r14,rax
  411d43:	call   40edd0 <__swc_fn_4fa09e82_000163_edb9cf73>
  411d48:	add    rsp,0x8
  411d4c:	mov    al,BYTE PTR [rbx]
  411d4e:	test   al,al
  411d50:	je     411f3e <__swc_fn_4fa09e82_000164_5fbed98a+0x27e>
  411d56:	mov    al,BYTE PTR [rbx+0x1]
  411d59:	test   al,al
  411d5b:	jne    411d66 <__swc_fn_4fa09e82_000164_5fbed98a+0xa6>
  411d5d:	test   sil,sil
  411d60:	je     411f3e <__swc_fn_4fa09e82_000164_5fbed98a+0x27e>
  411d66:	test   r13b,r13b
  411d69:	jne    411e27 <__swc_fn_4fa09e82_000164_5fbed98a+0x167>
  411d6f:	test   r12,r12
  411d72:	je     411e27 <__swc_fn_4fa09e82_000164_5fbed98a+0x167>
  411d78:	mov    al,BYTE PTR [rbx+0x1]
  411d7b:	test   al,al
  411d7d:	je     411f3e <__swc_fn_4fa09e82_000164_5fbed98a+0x27e>
  411d83:	mov    eax,DWORD PTR [rbx+0x28]
  411d86:	cmp    DWORD PTR [r12+0x20],eax
  411d8b:	jne    411f3e <__swc_fn_4fa09e82_000164_5fbed98a+0x27e>
  411d91:	mov    rax,QWORD PTR [r12]
  411d95:	mov    rcx,QWORD PTR [r12+0x8]
  411d9a:	cmp    QWORD PTR [rbx+0x20],rcx
  411d9e:	jne    411f3e <__swc_fn_4fa09e82_000164_5fbed98a+0x27e>
  411da4:	mov    cl,0x1
  411da6:	test   rax,rax
  411da9:	je     411e12 <__swc_fn_4fa09e82_000164_5fbed98a+0x152>
  411daf:	mov    rdx,QWORD PTR [rbx+0x20]
  411db3:	xor    r8d,r8d
  411db6:	test   rdx,rdx
  411db9:	jbe    411e12 <__swc_fn_4fa09e82_000164_5fbed98a+0x152>
  411dbb:	mov    r9,QWORD PTR [rbx+0x18]
  411dbf:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  411dc4:	cs nop WORD PTR [rax+rax*1+0x0]
  411dce:	xchg   ax,ax
  411dd0:	mov    r10b,BYTE PTR [rax+r8*1]
  411dd4:	cmp    BYTE PTR [r9+r8*1],r10b
  411dd8:	je     411e09 <__swc_fn_4fa09e82_000164_5fbed98a+0x149>
  411dda:	vmovq  r10,xmm0
  411ddf:	cmp    BYTE PTR [r10+r8*1],0x5c
  411de4:	jne    411ded <__swc_fn_4fa09e82_000164_5fbed98a+0x12d>
  411de6:	cmp    BYTE PTR [rax+r8*1],0x2f
  411deb:	je     411e09 <__swc_fn_4fa09e82_000164_5fbed98a+0x149>
  411ded:	vmovq  r10,xmm0
  411df2:	cmp    BYTE PTR [r10+r8*1],0x2f
  411df7:	jne    411e00 <__swc_fn_4fa09e82_000164_5fbed98a+0x140>
  411df9:	cmp    BYTE PTR [rax+r8*1],0x5c
  411dfe:	je     411e09 <__swc_fn_4fa09e82_000164_5fbed98a+0x149>
  411e00:	xor    eax,eax
  411e02:	movzx  eax,al
  411e05:	mov    cl,al
  411e07:	jmp    411e12 <__swc_fn_4fa09e82_000164_5fbed98a+0x152>
  411e09:	add    r8,0x1
  411e0d:	cmp    r8,rdx
  411e10:	jb     411dd0 <__swc_fn_4fa09e82_000164_5fbed98a+0x110>
  411e12:	test   cl,cl
  411e14:	je     411f3e <__swc_fn_4fa09e82_000164_5fbed98a+0x27e>
  411e1a:	mov    eax,0x1
  411e1f:	mov    r13b,al
  411e22:	jmp    411f3e <__swc_fn_4fa09e82_000164_5fbed98a+0x27e>
  411e27:	mov    r13b,0x1
  411e2a:	sub    rsp,0x20
  411e2e:	mov    rax,rsp
  411e31:	lea    rcx,[rdi+0x8]
  411e35:	mov    QWORD PTR [rax],rcx
  411e38:	lea    rsi,[rip+0x14d1]        # 413310 <__swc_rdata_base_4fa09e82+0x200>
  411e3f:	mov    QWORD PTR [rax+0x8],rsi
  411e43:	mov    QWORD PTR [rax+0x10],rsp
  411e47:	mov    QWORD PTR [rax+0x18],0x1
  411e4f:	lea    rcx,[rsp+0x10]
  411e54:	sub    rsp,0x8
  411e58:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  411e5d:	add    rsp,0x8
  411e61:	add    rsp,0x20
  411e65:	mov    al,BYTE PTR [rbx+0x1]
  411e68:	test   al,al
  411e6a:	je     411f07 <__swc_fn_4fa09e82_000164_5fbed98a+0x247>
  411e70:	lea    rax,[rip+0x1a41]        # 4138b8 <__swc_rdata_base_4fa09e82+0x7a8>
  411e77:	sub    rsp,0x20
  411e7b:	mov    rcx,rsp
  411e7e:	mov    QWORD PTR [rcx],rax
  411e81:	mov    QWORD PTR [rcx+0x8],rsi
  411e85:	mov    QWORD PTR [rcx+0x10],rsp
  411e89:	mov    QWORD PTR [rcx+0x18],0x1
  411e91:	lea    rcx,[rsp+0x10]
  411e96:	sub    rsp,0x8
  411e9a:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  411e9f:	add    rsp,0x8
  411ea3:	add    rsp,0x20
  411ea7:	mov    eax,DWORD PTR [rbx+0x28]
  411eaa:	sub    rsp,0x60
  411eae:	mov    rcx,rsp
  411eb1:	lea    rdx,[rdi+0x18]
  411eb5:	mov    QWORD PTR [rcx+0x18],rdx
  411eb9:	mov    QWORD PTR [rcx+0x20],rsi
  411ebd:	vmovups XMMWORD PTR [rcx],xmm6
  411ec1:	mov    QWORD PTR [rcx+0x28],rsp
  411ec5:	mov    QWORD PTR [rcx+0x30],rsi
  411ec9:	mov    DWORD PTR [rcx+0x10],eax
  411ecc:	lea    rax,[rsp+0x10]
  411ed1:	mov    QWORD PTR [rcx+0x38],rax
  411ed5:	lea    rax,[rip+0x14f4]        # 4133d0 <__swc_rdata_base_4fa09e82+0x2c0>
  411edc:	mov    QWORD PTR [rcx+0x40],rax
  411ee0:	lea    rax,[rsp+0x18]
  411ee5:	mov    QWORD PTR [rcx+0x48],rax
  411ee9:	mov    QWORD PTR [rcx+0x50],0x3
  411ef1:	lea    rcx,[rsp+0x48]
  411ef6:	sub    rsp,0x8
  411efa:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  411eff:	add    rsp,0x8
  411f03:	add    rsp,0x60
  411f07:	lea    rax,[rip+0x145a]        # 413368 <__swc_rdata_base_4fa09e82+0x258>
  411f0e:	sub    rsp,0x20
  411f12:	mov    rcx,rsp
  411f15:	mov    QWORD PTR [rcx],rax
  411f18:	mov    QWORD PTR [rcx+0x8],rsi
  411f1c:	mov    QWORD PTR [rcx+0x10],rsp
  411f20:	mov    QWORD PTR [rcx+0x18],0x1
  411f28:	lea    rcx,[rsp+0x10]
  411f2d:	sub    rsp,0x8
  411f31:	call   40a0e0 <__swc_fn_4fa09e82_000147_e9d46966>
  411f36:	add    rsp,0x8
  411f3a:	add    rsp,0x20
  411f3e:	add    r15,0x1
  411f42:	cmp    r15,r14
  411f45:	jae    411f5e <__swc_fn_4fa09e82_000164_5fbed98a+0x29e>
  411f47:	mov    rsi,QWORD PTR [rsp+0x30]
  411f4c:	mov    rdi,QWORD PTR [rsp+0x38]
  411f51:	mov    rax,r14
  411f54:	mov    r14,QWORD PTR [rsp+0x48]
  411f59:	jmp    411d20 <__swc_fn_4fa09e82_000164_5fbed98a+0x60>
  411f5e:	add    rsp,0x50
  411f62:	vmovups xmm6,XMMWORD PTR [rsp]
  411f67:	add    rsp,0x10
  411f6b:	pop    r15
  411f6d:	pop    r14
  411f6f:	pop    r13
  411f71:	pop    r12
  411f73:	pop    rdi
  411f74:	pop    rsi
  411f75:	pop    rbx
  411f76:	pop    rbp
  411f77:	ret
	...

0000000000411f80 <__swc_fn_4fa09e82_000167_31ca4f53>:
  411f80:	sub    rsp,0x8
  411f84:	call   409af0 <__swc_fn_4fa09e82_000126_e19c72b3>
  411f89:	add    rsp,0x8
  411f8d:	ret
	...

0000000000411f90 <__swc_fn_4fa09e82_000170_aabbfb4c>:
  411f90:	push   rsi
  411f91:	sub    rsp,0x30
  411f95:	lea    rsi,[rip+0x14e04]        # 426da0 <__swc_bss_base_4fa09e82+0x2d60>
  411f9c:	mov    rax,QWORD PTR [rsi]
  411f9f:	test   rax,rax
  411fa2:	je     411faa <__swc_fn_4fa09e82_000170_aabbfb4c+0x1a>
  411fa4:	add    rsp,0x30
  411fa8:	pop    rsi
  411fa9:	ret
  411faa:	mov    ecx,0x2
  411faf:	mov    edx,0x8020
  411fb4:	call   409190 <__swc_fn_4fa09e82_000108_ff529476>
  411fb9:	test   rax,rax
  411fbc:	jne    411fcd <__swc_fn_4fa09e82_000170_aabbfb4c+0x3d>
  411fbe:	mov    QWORD PTR [rsp+0x18],rax
  411fc3:	call   411420 <__swc_fn_4fa09e82_000119_2b35b5e0>
  411fc8:	mov    rax,QWORD PTR [rsp+0x18]
  411fcd:	mov    rcx,rax
  411fd0:	xchg   QWORD PTR [rsi],rcx
  411fd3:	add    rsp,0x30
  411fd7:	pop    rsi
  411fd8:	ret
  411fd9:	add    BYTE PTR [rax],al
  411fdb:	add    BYTE PTR [rax],al
  411fdd:	add    BYTE PTR [rax],al
	...

0000000000411fe0 <__swc_fn_4fa09e82_000173_9a88b1d5>:
  411fe0:	push   rsi
  411fe1:	test   r8,r8
  411fe4:	jne    411fe8 <__swc_fn_4fa09e82_000173_9a88b1d5+0x8>
  411fe6:	pop    rsi
  411fe7:	ret
  411fe8:	lea    rax,[rcx+0x18]
  411fec:	mov    r10,QWORD PTR [rax]
  411fef:	lea    r11,[r10+0x1]
  411ff3:	mov    QWORD PTR [rax],r11
  411ff6:	mov    r11,rdx
  411ff9:	not    rdx
  411ffc:	lea    rsi,[r8-0x1]
  412000:	cmp    rsi,rdx
  412003:	ja     412023 <__swc_fn_4fa09e82_000173_9a88b1d5+0x43>
  412005:	lea    rdx,[r11+r8*1]
  412009:	dec    rdx
  41200c:	shr    rdx,0x6
  412010:	mov    r8,r11
  412013:	shr    r8,0x6
  412017:	mov    rsi,rdx
  41201a:	sub    rsi,r8
  41201d:	cmp    rsi,0x8
  412021:	jb     412039 <__swc_fn_4fa09e82_000173_9a88b1d5+0x59>
  412023:	lea    rcx,[rcx+0x10]
  412027:	mov    rdx,QWORD PTR [rcx]
  41202a:	add    rdx,r9
  41202d:	mov    QWORD PTR [rcx],rdx
  412030:	lea    rcx,[r10+0x2]
  412034:	mov    QWORD PTR [rax],rcx
  412037:	pop    rsi
  412038:	ret
  412039:	shr    r11,0x6
  41203d:	nop    DWORD PTR [rax]
  412040:	cmp    r11,rdx
  412043:	ja     412083 <__swc_fn_4fa09e82_000173_9a88b1d5+0xa3>
  412045:	jmp    412056 <__swc_fn_4fa09e82_000173_9a88b1d5+0x76>
  412047:	nop    WORD PTR [rax+rax*1+0x0]
  412050:	add    r11,0x1
  412054:	jmp    412040 <__swc_fn_4fa09e82_000173_9a88b1d5+0x60>
  412056:	mov    r8,r11
  412059:	shr    r8,0xc
  41205d:	mov    rsi,r11
  412060:	xor    rsi,r8
  412063:	mov    r8,r11
  412066:	shr    r8,0x18
  41206a:	xor    rsi,r8
  41206d:	and    esi,0xfff
  412073:	lea    r8,[rcx+rsi*8+0x20]
  412078:	mov    rsi,QWORD PTR [r8]
  41207b:	add    rsi,r9
  41207e:	mov    QWORD PTR [r8],rsi
  412081:	jmp    412050 <__swc_fn_4fa09e82_000173_9a88b1d5+0x70>
  412083:	lea    rcx,[r10+0x2]
  412087:	mov    QWORD PTR [rax],rcx
  41208a:	pop    rsi
  41208b:	ret
  41208c:	add    BYTE PTR [rax],al
	...

0000000000412090 <__swc_fn_4fa09e82_000176_e7f0b636>:
  412090:	push   rsi
  412091:	push   rdi
  412092:	push   r12
  412094:	mov    rsi,r8
  412097:	mov    rdi,rcx
  41209a:	mov    r12,rdx
  41209d:	lea    rcx,[rdx*8+0x0]
  4120a5:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  4120aa:	mov    QWORD PTR [rdi],rax
  4120ad:	lea    rcx,[r12*8+0x0]
  4120b5:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  4120ba:	mov    QWORD PTR [rdi+0x8],rax
  4120be:	lea    rcx,[r12*8+0x0]
  4120c6:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  4120cb:	mov    QWORD PTR [rdi+0x10],rax
  4120cf:	mov    rcx,r12
  4120d2:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  4120d7:	mov    QWORD PTR [rdi+0x18],rax
  4120db:	mov    rcx,rax
  4120de:	xor    al,al
  4120e0:	mov    rdx,rax
  4120e3:	mov    r8,r12
  4120e6:	call   4090e0 <__swc_fn_4fa09e82_000105_84094be1>
  4120eb:	mov    QWORD PTR [rdi+0x20],rsi
  4120ef:	lea    rax,[r12-0x1]
  4120f4:	mov    QWORD PTR [rdi+0x28],rax
  4120f8:	mov    QWORD PTR [rdi+0x30],0x0
  412100:	pop    r12
  412102:	pop    rdi
  412103:	pop    rsi
  412104:	ret
	...

0000000000412110 <__swc_fn_4fa09e82_000179_6937fe70>:
  412110:	push   rsi
  412111:	push   rdi
  412112:	push   r12
  412114:	push   r13
  412116:	push   r14
  412118:	push   r15
  41211a:	sub    rsp,0xd8
  412121:	mov    rsi,rdx
  412124:	mov    QWORD PTR [rsp+0x88],rdx
  41212c:	mov    rdi,rcx
  41212f:	cmp    rdi,rsi
  412132:	jge    412349 <__swc_fn_4fa09e82_000179_6937fe70+0x239>
  412138:	nop    DWORD PTR [rax+rax*1+0x0]
  412140:	lea    rax,[rdi+rsi*1]
  412144:	mov    rcx,rax
  412147:	shr    rax,0x3f
  41214b:	add    rcx,rax
  41214e:	sar    rcx,1
  412151:	mov    rax,QWORD PTR [rip+0x14c58]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  412158:	mov    r12,QWORD PTR [rax+rcx*8]
  41215c:	mov    r13,rdi
  41215f:	mov    QWORD PTR [rsp+0x90],rdi
  412167:	mov    r14,rsi
  41216a:	nop    WORD PTR [rax+rax*1+0x0]
  412170:	cmp    r13,r14
  412173:	jle    412180 <__swc_fn_4fa09e82_000179_6937fe70+0x70>
  412175:	mov    rax,r13
  412178:	mov    r13,r14
  41217b:	jmp    412325 <__swc_fn_4fa09e82_000179_6937fe70+0x215>
  412180:	mov    r15,QWORD PTR [rip+0x14c29]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  412187:	mov    rsi,QWORD PTR [rip+0x14c2a]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  41218e:	mov    QWORD PTR [rsp+0xa8],rsi
  412196:	mov    rdi,QWORD PTR [rsi+r12*8]
  41219a:	mov    QWORD PTR [rsp+0xa0],r14
  4121a2:	mov    r14,QWORD PTR [rip+0x14c17]        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  4121a9:	mov    rax,QWORD PTR [rip+0x14c18]        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  4121b0:	mov    QWORD PTR [rsp+0xb0],rax
  4121b8:	mov    r9,QWORD PTR [rip+0x14c11]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  4121bf:	mov    QWORD PTR [rsp+0xb8],r9
  4121c7:	nop    WORD PTR [rax+rax*1+0x0]
  4121d0:	mov    r10,QWORD PTR [r15+r13*8]
  4121d4:	cmp    QWORD PTR [rsi+r10*8],rdi
  4121d8:	je     4121de <__swc_fn_4fa09e82_000179_6937fe70+0xce>
  4121da:	ja     412215 <__swc_fn_4fa09e82_000179_6937fe70+0x105>
  4121dc:	jmp    412232 <__swc_fn_4fa09e82_000179_6937fe70+0x122>
  4121de:	mov    rcx,QWORD PTR [r14+r10*8]
  4121e2:	mov    r8,QWORD PTR [r14+r12*8]
  4121e6:	cmp    r8,rcx
  4121e9:	cmovae r8,rcx
  4121ed:	mov    rcx,QWORD PTR [rax+r10*8]
  4121f1:	add    rcx,r9
  4121f4:	mov    rdx,QWORD PTR [rax+r12*8]
  4121f8:	add    rdx,r9
  4121fb:	mov    rsi,r10
  4121fe:	call   410eb0 <__swc_fn_4fa09e82_000107_77a5d54a>
  412203:	test   eax,eax
  412205:	je     41220b <__swc_fn_4fa09e82_000179_6937fe70+0xfb>
  412207:	jl     412215 <__swc_fn_4fa09e82_000179_6937fe70+0x105>
  412209:	jmp    412232 <__swc_fn_4fa09e82_000179_6937fe70+0x122>
  41220b:	mov    rax,QWORD PTR [r14+r12*8]
  41220f:	cmp    QWORD PTR [r14+rsi*8],rax
  412213:	jae    412232 <__swc_fn_4fa09e82_000179_6937fe70+0x122>
  412215:	inc    r13
  412218:	mov    rsi,QWORD PTR [rsp+0xa8]
  412220:	mov    rax,QWORD PTR [rsp+0xb0]
  412228:	mov    r9,QWORD PTR [rsp+0xb8]
  412230:	jmp    4121d0 <__swc_fn_4fa09e82_000179_6937fe70+0xc0>
  412232:	mov    rsi,QWORD PTR [rip+0x14b77]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  412239:	mov    QWORD PTR [rsp+0xc0],rsi
  412241:	mov    rdi,QWORD PTR [rip+0x14b70]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  412248:	mov    r14,QWORD PTR [rip+0x14b71]        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  41224f:	mov    r15,QWORD PTR [rip+0x14b72]        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  412256:	mov    QWORD PTR [rsp+0x98],r13
  41225e:	mov    r13,QWORD PTR [rsp+0xa0]
  412266:	mov    rax,QWORD PTR [rip+0x14b63]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  41226d:	mov    QWORD PTR [rsp+0xc8],rax
  412275:	cs nop WORD PTR [rax+rax*1+0x0]
  41227f:	nop
  412280:	mov    r9,QWORD PTR [rsi+r13*8]
  412284:	mov    rcx,QWORD PTR [rdi+r9*8]
  412288:	cmp    QWORD PTR [rdi+r12*8],rcx
  41228c:	je     412292 <__swc_fn_4fa09e82_000179_6937fe70+0x182>
  41228e:	ja     4122c9 <__swc_fn_4fa09e82_000179_6937fe70+0x1b9>
  412290:	jmp    4122de <__swc_fn_4fa09e82_000179_6937fe70+0x1ce>
  412292:	mov    rcx,QWORD PTR [r14+r12*8]
  412296:	mov    r8,QWORD PTR [r14+r9*8]
  41229a:	cmp    r8,rcx
  41229d:	cmovae r8,rcx
  4122a1:	mov    rcx,QWORD PTR [r15+r12*8]
  4122a5:	add    rcx,rax
  4122a8:	mov    rdx,QWORD PTR [r15+r9*8]
  4122ac:	add    rdx,rax
  4122af:	mov    rsi,r9
  4122b2:	call   410eb0 <__swc_fn_4fa09e82_000107_77a5d54a>
  4122b7:	test   eax,eax
  4122b9:	je     4122bf <__swc_fn_4fa09e82_000179_6937fe70+0x1af>
  4122bb:	jl     4122c9 <__swc_fn_4fa09e82_000179_6937fe70+0x1b9>
  4122bd:	jmp    4122de <__swc_fn_4fa09e82_000179_6937fe70+0x1ce>
  4122bf:	mov    rax,QWORD PTR [r14+rsi*8]
  4122c3:	cmp    QWORD PTR [r14+r12*8],rax
  4122c7:	jae    4122de <__swc_fn_4fa09e82_000179_6937fe70+0x1ce>
  4122c9:	dec    r13
  4122cc:	mov    rsi,QWORD PTR [rsp+0xc0]
  4122d4:	mov    rax,QWORD PTR [rsp+0xc8]
  4122dc:	jmp    412280 <__swc_fn_4fa09e82_000179_6937fe70+0x170>
  4122de:	mov    rax,QWORD PTR [rsp+0x98]
  4122e6:	cmp    rax,r13
  4122e9:	jle    4122f6 <__swc_fn_4fa09e82_000179_6937fe70+0x1e6>
  4122eb:	mov    r14,r13
  4122ee:	mov    r13,rax
  4122f1:	jmp    412170 <__swc_fn_4fa09e82_000179_6937fe70+0x60>
  4122f6:	mov    rcx,QWORD PTR [rip+0x14ab3]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  4122fd:	mov    rdx,QWORD PTR [rcx+rax*8]
  412301:	mov    r8,QWORD PTR [rcx+r13*8]
  412305:	mov    QWORD PTR [rcx+rax*8],r8
  412309:	mov    rcx,QWORD PTR [rip+0x14aa0]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  412310:	mov    QWORD PTR [rcx+r13*8],rdx
  412314:	inc    rax
  412317:	dec    r13
  41231a:	mov    r14,r13
  41231d:	mov    r13,rax
  412320:	jmp    412170 <__swc_fn_4fa09e82_000179_6937fe70+0x60>
  412325:	mov    rcx,QWORD PTR [rsp+0x90]
  41232d:	mov    rdx,r13
  412330:	mov    rdi,rax
  412333:	call   412110 <__swc_fn_4fa09e82_000179_6937fe70>
  412338:	mov    rsi,QWORD PTR [rsp+0x88]
  412340:	cmp    rdi,rsi
  412343:	jl     412140 <__swc_fn_4fa09e82_000179_6937fe70+0x30>
  412349:	add    rsp,0xd8
  412350:	pop    r15
  412352:	pop    r14
  412354:	pop    r13
  412356:	pop    r12
  412358:	pop    rdi
  412359:	pop    rsi
  41235a:	ret
