
/workspace/prompt2-20261115/batch5-final-micro/base/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

000000000040ebf0 <__swc_fn_4fa09e82_000145_34d6a3dc>:
  40ebf0:	push   rbx
  40ebf1:	sub    rsp,0xe0
  40ebf8:	lea    rbx,[rsp+0x8]
  40ebfd:	vxorps xmm0,xmm0,xmm0
  40ec01:	vmovups XMMWORD PTR [rbx],xmm0
  40ec05:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ec0a:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ec0f:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40ec14:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40ec19:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  40ec1e:	mov    DWORD PTR [rbx+0x60],0x0
  40ec25:	mov    r8,rbx
  40ec28:	nop    DWORD PTR [rax+rax*1+0x0]
  40ec30:	mov    r9,rcx
  40ec33:	movabs rcx,0xcccccccccccccccd
  40ec3d:	mov    rax,r9
  40ec40:	mul    rcx
  40ec43:	mov    r10,rdx
  40ec46:	shr    r10,0x3
  40ec4a:	mov    rcx,r10
  40ec4d:	imul   rdx,r10,0xa
  40ec51:	sub    r9,rdx
  40ec54:	mov    rdx,QWORD PTR [rip+0x48e5]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40ec5b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  40ec60:	mov    BYTE PTR [r8],dl
  40ec63:	lea    rdx,[r8+0x1]
  40ec67:	mov    r8,rdx
  40ec6a:	test   r10,r10
  40ec6d:	jne    40ec30 <__swc_fn_4fa09e82_000145_34d6a3dc+0x40>
  40ec6f:	mov    BYTE PTR [rdx],0x0
  40ec72:	sub    r8,0x1
  40ec76:	mov    rax,rbx
  40ec79:	cmp    rax,r8
  40ec7c:	jae    40ec96 <__swc_fn_4fa09e82_000145_34d6a3dc+0xa6>
  40ec7e:	xchg   ax,ax
  40ec80:	mov    cl,BYTE PTR [r8]
  40ec83:	mov    dl,BYTE PTR [rax]
  40ec85:	mov    BYTE PTR [r8],dl
  40ec88:	sub    r8,0x1
  40ec8c:	mov    BYTE PTR [rax],cl
  40ec8e:	inc    rax
  40ec91:	cmp    rax,r8
  40ec94:	jb     40ec80 <__swc_fn_4fa09e82_000145_34d6a3dc+0x90>
  40ec96:	xor    eax,eax
  40ec98:	test   rbx,rbx
  40ec9b:	je     40ecbe <__swc_fn_4fa09e82_000145_34d6a3dc+0xce>
  40ec9d:	mov    rcx,rbx
  40eca0:	mov    dl,BYTE PTR [rcx]
  40eca2:	test   dl,dl
  40eca4:	je     40ecbe <__swc_fn_4fa09e82_000145_34d6a3dc+0xce>
  40eca6:	cs nop WORD PTR [rax+rax*1+0x0]
  40ecb0:	add    rcx,0x1
  40ecb4:	add    rax,0x1
  40ecb8:	mov    dl,BYTE PTR [rcx]
  40ecba:	test   dl,dl
  40ecbc:	jne    40ecb0 <__swc_fn_4fa09e82_000145_34d6a3dc+0xc0>
  40ecbe:	mov    QWORD PTR [rbx+0xa8],rbx
  40ecc5:	mov    QWORD PTR [rbx+0xb0],rax
  40eccc:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40ecd4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40ecdc:	lea    rcx,[rbx+0xb8]
  40ece3:	call   4098c0 <__swc_fn_4fa09e82_000117_18ca1307>
  40ece8:	add    rsp,0xe0
  40ecef:	pop    rbx
  40ecf0:	ret
