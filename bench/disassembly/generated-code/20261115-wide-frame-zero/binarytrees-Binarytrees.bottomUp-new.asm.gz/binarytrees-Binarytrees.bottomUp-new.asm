
/workspace/prompt2-20261115/batch5-final-micro/new/binarytrees/binarytrees:     file format elf64-x86-64


Disassembly of section .text:

0000000000407270 <__swc_fn_7dafa2b1_000000_82999b37>:
  407270:	push   rbx
  407271:	push   rsi
  407272:	sub    rsp,0x68
  407276:	mov    rbx,rcx
  407279:	vxorps xmm0,xmm0,xmm0
  40727d:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  407283:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  407289:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40728f:	vzeroupper
  407292:	mov    QWORD PTR [rsp+0x50],0x20
  40729b:	mov    DWORD PTR [rsp+0x60],0x10
  4072a3:	mov    rcx,QWORD PTR [rip+0x1bd96]        # 423040 <__swc_bss_base_7dafa2b1>
  4072aa:	test   rcx,rcx
  4072ad:	jne    4072bf <__swc_fn_7dafa2b1_000000_82999b37+0x4f>
  4072af:	call   4119a0 <__swc_fn_7dafa2b1_000170_994c8876>
  4072b4:	lea    rcx,[rax+0x1]
  4072b8:	mov    QWORD PTR [rip+0x1bd81],rcx        # 423040 <__swc_bss_base_7dafa2b1>
  4072bf:	dec    rcx
  4072c2:	call   40e840 <__swc_fn_7dafa2b1_000172_360af05d>
  4072c7:	mov    rcx,QWORD PTR [rax]
  4072ca:	lea    rdx,[rsp+0x8]
  4072cf:	mov    rsi,QWORD PTR [rax+0x8]
  4072d3:	mov    rsi,QWORD PTR [rsi+0x8]
  4072d7:	call   rsi
  4072d9:	mov    rax,QWORD PTR [rsp+0x48]
  4072de:	test   rax,rax
  4072e1:	jne    4072e7 <__swc_fn_7dafa2b1_000000_82999b37+0x77>
  4072e3:	xor    esi,esi
  4072e5:	jmp    4072fb <__swc_fn_7dafa2b1_000000_82999b37+0x8b>
  4072e7:	mov    rcx,QWORD PTR [rsp+0x50]
  4072ec:	mov    QWORD PTR [rax],rcx
  4072ef:	mov    QWORD PTR [rax+0x8],0x0
  4072f7:	lea    rsi,[rax+0x10]
  4072fb:	test   ebx,ebx
  4072fd:	jle    407318 <__swc_fn_7dafa2b1_000000_82999b37+0xa8>
  4072ff:	dec    ebx
  407301:	mov    ecx,ebx
  407303:	call   407270 <__swc_fn_7dafa2b1_000000_82999b37>
  407308:	mov    QWORD PTR [rsi],rax
  40730b:	mov    ecx,ebx
  40730d:	call   407270 <__swc_fn_7dafa2b1_000000_82999b37>
  407312:	mov    QWORD PTR [rsi+0x8],rax
  407316:	jmp    407320 <__swc_fn_7dafa2b1_000000_82999b37+0xb0>
  407318:	vxorps xmm0,xmm0,xmm0
  40731c:	vmovdqu XMMWORD PTR [rsi],xmm0
  407320:	mov    rax,rsi
  407323:	add    rsp,0x68
  407327:	pop    rsi
  407328:	pop    rbx
  407329:	ret
