
/workspace/prompt2-20261115/batch5-final-micro/base/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

000000000040ede0 <__swc_fn_4fa09e82_000157_65b5512b>:
  40ede0:	push   rbx
  40ede1:	sub    rsp,0x70
  40ede5:	mov    rax,QWORD PTR [rcx]
  40ede8:	mov    rbx,QWORD PTR [rcx+0x8]
  40edec:	vxorps xmm0,xmm0,xmm0
  40edf0:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40edf6:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40edfc:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ee02:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40ee08:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40ee0e:	mov    QWORD PTR [rsp+0x48],rdx
  40ee13:	mov    QWORD PTR [rsp+0x50],r8
  40ee18:	mov    rcx,rax
  40ee1b:	lea    rdx,[rsp+0x8]
  40ee20:	mov    rbx,QWORD PTR [rbx+0x18]
  40ee24:	call   rbx
  40ee26:	add    rsp,0x70
  40ee2a:	pop    rbx
  40ee2b:	ret
