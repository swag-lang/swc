
/workspace/prompt2-20261115/batch7-placement-micro/base/dijkstra/dijkstra:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <clock_gettime@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <clock_gettime@GLIBC_2.17>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <madvise@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf92]        # 413088 <madvise@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <pthread_key_delete@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf8a]        # 413090 <pthread_key_delete@GLIBC_2.34>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <gettid@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf82]        # 413098 <gettid@GLIBC_2.30>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <flock@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf7a]        # 4130a0 <flock@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <__errno_location@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf72]        # 4130a8 <__errno_location@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <opendir@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf6a]        # 4130b0 <opendir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <dirfd@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf62]        # 4130b8 <dirfd@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readdir@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <readdir@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <readlinkat@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <readlinkat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <openat@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <openat@GLIBC_2.4>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <closedir@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <closedir@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <memfd_create@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <memfd_create@GLIBC_2.27>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <ftruncate@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <ftruncate@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <write@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <write@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <backtrace@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <backtrace@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_7069e055_000176_5d3d19bd+0xf60>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40ca80 <__swc_fn_7069e055_000121_1c5e75b6>
  40724e:	xor    ecx,ecx
  407250:	call   40c1a0 <__swc_fn_7069e055_000094_383a814c>
  407255:	call   40d6e0 <__swc_fn_7069e055_000178_fa681d0f>
  40725a:	call   40f6f0 <__swc_fn_7069e055_000095_8cc4b392>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_7069e055_000000_0e26756e>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_7069e055_000003_81215399>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_7069e055_000003_81215399+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409240 <__swc_fn_7069e055_000111_f9e19033>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_7069e055_000003_81215399+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_7069e055+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_7069e055+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_7069e055_000003_81215399+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_7069e055_000003_81215399+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_7069e055+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_7069e055+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_7069e055_000003_81215399+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_7069e055_000003_81215399+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_7069e055_000006_7b253ae1>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40dfa0 <__swc_fn_7069e055_000011_71c91685>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_7069e055_000012_be38a1a2>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_7069e055_000006_7b253ae1+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_7069e055_000003_81215399>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_7069e055_000006_7b253ae1+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_7069e055_000009_4c3ebf16>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_7069e055_000009_4c3ebf16+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40a530 <__swc_fn_7069e055_000007_a7bfb091>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40df90 <__swc_fn_7069e055_000008_b2f73e0d>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_7069e055_000009_4c3ebf16+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_7069e055_000009_4c3ebf16+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_7069e055_000012_be38a1a2>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_7069e055_000015_96cb1311>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_7069e055_000015_96cb1311+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_7069e055_000015_96cb1311+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_7069e055_000015_96cb1311+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_7069e055_000015_96cb1311+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40e100 <__swc_fn_7069e055_000017_f003fc47>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_7069e055_000015_96cb1311+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_7069e055+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_7069e055+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_7069e055_000015_96cb1311+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_7069e055_000015_96cb1311+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40dfa0 <__swc_fn_7069e055_000011_71c91685>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_7069e055_000015_96cb1311+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40c7a0 <__swc_fn_7069e055_000112_2f7f9346>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_7069e055+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_7069e055+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_7069e055_000015_96cb1311+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_7069e055_000015_96cb1311+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_7069e055+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_7069e055+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_7069e055_000015_96cb1311+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_7069e055_000015_96cb1311+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_7069e055_000018_77ece227>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_7069e055_000015_96cb1311+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_7069e055_000018_77ece227>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_7069e055_000018_77ece227+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_7069e055_000018_77ece227+0x10>

0000000000407630 <__swc_fn_7069e055_000021_9cf87641>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_7069e055_000015_96cb1311>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_7069e055+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098a0 <__swc_fn_7069e055_000135_db32cc57>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_7069e055+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_7069e055+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_7069e055_000024_e876734d>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_7069e055_000027_e876734d>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_7069e055_000030_650caec0>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_7069e055_000030_650caec0+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_7069e055>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_7069e055_000030_650caec0+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_7069e055_000030_650caec0+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_7069e055_000030_650caec0+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40e2c0 <__swc_fn_7069e055_000032_f1940e30>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_7069e055_000030_650caec0+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_7069e055_000036_290a131c>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_7069e055_000030_650caec0+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_7069e055_000042_0573444d>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_7069e055_000033_d15eb4ea>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40a9e0 <__swc_fn_7069e055_000031_3c3e930e>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409720 <__swc_fn_7069e055_000129_bc477461>
  407734:	mov    rcx,rsi
  407737:	call   40e2c0 <__swc_fn_7069e055_000032_f1940e30>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_7069e055_000036_290a131c>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_7069e055_000039_9ae4348f>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_7069e055_000039_9ae4348f+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_7069e055_000039_9ae4348f+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_7069e055_000039_9ae4348f+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_7069e055_000039_9ae4348f+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_7069e055_000039_9ae4348f+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409320 <__swc_fn_7069e055_000114_cc486df9>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_7069e055+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_7069e055+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_7069e055_000039_9ae4348f+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_7069e055_000039_9ae4348f+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_7069e055+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_7069e055+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_7069e055_000039_9ae4348f+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_7069e055_000039_9ae4348f+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_7069e055_000042_0573444d>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_7069e055_000042_0573444d+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e890 <__swc_fn_7069e055_000059_ee6a254c>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098a0 <__swc_fn_7069e055_000135_db32cc57>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_7069e055_000042_0573444d+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_7069e055_000042_0573444d+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_7069e055_000009_4c3ebf16>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_7069e055_000042_0573444d+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40dfc0 <__swc_fn_7069e055_000014_be17798c>
  40791e:	jmp    407941 <__swc_fn_7069e055_000042_0573444d+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_7069e055_000042_0573444d+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_7069e055_000042_0573444d+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_7069e055_000042_0573444d+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40aba0 <__swc_fn_7069e055_000043_47ff6d9b>
  407997:	mov    rcx,rdi
  40799a:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_7069e055_000039_9ae4348f>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_7069e055_000045_bb688d37>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_7069e055_000045_bb688d37+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_7069e055_000045_bb688d37+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_7069e055_000045_bb688d37+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_7069e055_000045_bb688d37+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098a0 <__swc_fn_7069e055_000135_db32cc57>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_7069e055_000045_bb688d37+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_7069e055_000045_bb688d37+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_7069e055_000045_bb688d37+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_7069e055_000045_bb688d37+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_7069e055_000009_4c3ebf16>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_7069e055_000045_bb688d37+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_7069e055_000045_bb688d37+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_7069e055_000045_bb688d37+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_7069e055_000045_bb688d37+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_7069e055_000045_bb688d37+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40a5e0 <__swc_fn_7069e055_000013_7b85dbab>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_7069e055_000045_bb688d37+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_7069e055_000045_bb688d37+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_7069e055_000045_bb688d37+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_7069e055_000045_bb688d37+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40e140 <__swc_fn_7069e055_000020_4285d9c5>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_7069e055_000045_bb688d37+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40a5e0 <__swc_fn_7069e055_000013_7b85dbab>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_7069e055_000045_bb688d37+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_7069e055_000021_9cf87641>
  407c07:	mov    rcx,r14
  407c0a:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_7069e055_000045_bb688d37+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_7069e055_000045_bb688d37+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_7069e055_000045_bb688d37+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_7069e055_000048_8e68f77b>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_7069e055_000048_8e68f77b+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_7069e055_000048_8e68f77b+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_7069e055_000048_8e68f77b+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_7069e055_000048_8e68f77b+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40e4f0 <__swc_fn_7069e055_000047_e7fd8d42>
  407d14:	jmp    407ce0 <__swc_fn_7069e055_000048_8e68f77b+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_7069e055_000048_8e68f77b+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_7069e055_000048_8e68f77b+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_7069e055_000048_8e68f77b+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_7069e055_000048_8e68f77b+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_7069e055_000048_8e68f77b+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_7069e055_000048_8e68f77b+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_7069e055_000048_8e68f77b+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_7069e055_000051_27d2a35f>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_7069e055_000051_27d2a35f+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_7069e055_000051_27d2a35f+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_7069e055_000051_27d2a35f+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_7069e055_000051_27d2a35f+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40e450 <__swc_fn_7069e055_000044_fe6bbfdb>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40dfc0 <__swc_fn_7069e055_000014_be17798c>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_7069e055_000054_e8e85c01>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098a0 <__swc_fn_7069e055_000135_db32cc57>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_7069e055_000054_e8e85c01+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_7069e055_000054_e8e85c01+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_7069e055_000054_e8e85c01+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_7069e055_000057_01c75a1d>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_7069e055_000060_6818d0d1>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_7069e055_000060_6818d0d1+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_7069e055_000039_9ae4348f>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_7069e055_000060_6818d0d1+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_7069e055_000063_db6d2425>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40af20 <__swc_fn_7069e055_000052_92b016ae>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_7069e055_000054_e8e85c01>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_7069e055_000063_db6d2425+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_7069e055_000063_db6d2425+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40b040 <__swc_fn_7069e055_000058_01964a17>
  407f7f:	mov    rcx,rsi
  407f82:	call   40ac80 <__swc_fn_7069e055_000049_f6a485a2>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_7069e055_000066_918d3875>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_7069e055_000066_918d3875+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_7069e055+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_7069e055+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_7069e055_000066_918d3875+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_7069e055_000066_918d3875+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40a910 <__swc_fn_7069e055_000022_53fc00d2>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_7069e055_000066_918d3875+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_7069e055_000063_db6d2425>
  40808f:	jmp    408122 <__swc_fn_7069e055_000066_918d3875+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_7069e055>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_7069e055_000066_918d3875+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_7069e055_000066_918d3875+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_7069e055_000066_918d3875+0x135>
  4080b8:	call   40a9e0 <__swc_fn_7069e055_000031_3c3e930e>
  4080bd:	mov    rcx,rax
  4080c0:	call   410480 <__swc_fn_7069e055_000128_8d8a7dd2>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_7069e055_000066_918d3875+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_7069e055_000066_918d3875+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_7069e055_000066_918d3875+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40e4f0 <__swc_fn_7069e055_000047_e7fd8d42>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_7069e055_000066_918d3875+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_7069e055_000051_27d2a35f>
  408115:	jmp    408122 <__swc_fn_7069e055_000066_918d3875+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40a550 <__swc_fn_7069e055_000010_0569f799>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_7069e055_000069_34b04ef2>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_7069e055_000036_290a131c>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_7069e055_000069_34b04ef2+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_7069e055+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_7069e055_000069_34b04ef2+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098a0 <__swc_fn_7069e055_000135_db32cc57>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40ecc0 <__swc_fn_7069e055_000068_f501e74b>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_7069e055_000072_bf7b5562>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40ea10 <__swc_fn_7069e055_000065_0b20477c>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_7069e055_000075_41334281>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40ecc0 <__swc_fn_7069e055_000068_f501e74b>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_7069e055_000078_140918ec>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_7069e055_000078_140918ec+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_7069e055_000078_140918ec+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_7069e055_000081_f4f506c7>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_7069e055_000084_5ed30bd6>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_7069e055_000090_14cf59b2>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_7069e055_000084_5ed30bd6+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_7069e055_000084_5ed30bd6+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_7069e055_000084_5ed30bd6+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_7069e055_000084_5ed30bd6+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_7069e055_000090_14cf59b2>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_7069e055_000084_5ed30bd6+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_7069e055_000084_5ed30bd6+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_7069e055_000084_5ed30bd6+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_7069e055_000084_5ed30bd6+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_7069e055_000084_5ed30bd6+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_7069e055_000084_5ed30bd6+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_7069e055_000084_5ed30bd6+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_7069e055_000084_5ed30bd6+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_7069e055_000084_5ed30bd6+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_7069e055_000084_5ed30bd6+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40c020 <__swc_fn_7069e055_000082_ff7d1455>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_7069e055_000084_5ed30bd6+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_7069e055_000084_5ed30bd6+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_7069e055_000084_5ed30bd6+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40c020 <__swc_fn_7069e055_000082_ff7d1455>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_7069e055_000084_5ed30bd6+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_7069e055_000084_5ed30bd6>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_7069e055_000084_5ed30bd6+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_7069e055_000084_5ed30bd6+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_7069e055_000087_693f118e>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_7069e055_000090_14cf59b2>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_7069e055_000087_693f118e+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40f120 <__swc_fn_7069e055_000086_d9243de4>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_7069e055_000087_693f118e+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_7069e055_000087_693f118e+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_7069e055_000087_693f118e+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40c020 <__swc_fn_7069e055_000082_ff7d1455>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_7069e055_000087_693f118e+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_7069e055_000087_693f118e>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_7069e055_000087_693f118e+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_7069e055_000087_693f118e+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_7069e055_000090_14cf59b2>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_7069e055_000090_14cf59b2+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_7069e055_000090_14cf59b2+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_7069e055_000090_14cf59b2+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_7069e055_000090_14cf59b2+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40c020 <__swc_fn_7069e055_000082_ff7d1455>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40c020 <__swc_fn_7069e055_000082_ff7d1455>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_7069e055_000090_14cf59b2+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_7069e055_000090_14cf59b2+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_7069e055_000090_14cf59b2+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_7069e055_000090_14cf59b2+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_7069e055_000090_14cf59b2>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_7069e055_000090_14cf59b2+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_7069e055_000090_14cf59b2+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_7069e055_000090_14cf59b2+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_7069e055_000090_14cf59b2+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_7069e055_000090_14cf59b2+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_7069e055_000090_14cf59b2+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_7069e055_000090_14cf59b2+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_7069e055_000090_14cf59b2+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_7069e055_000090_14cf59b2+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_7069e055_000090_14cf59b2+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_7069e055_000090_14cf59b2+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_7069e055_000090_14cf59b2+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_7069e055_000090_14cf59b2+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_7069e055_000090_14cf59b2+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_7069e055_000090_14cf59b2+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_7069e055_000090_14cf59b2+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409db0 <__swc_fn_7069e055_000147_e7bfe29e>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_7069e055_000090_14cf59b2+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_7069e055_000090_14cf59b2>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_7069e055_000090_14cf59b2+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_7069e055_000090_14cf59b2+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_7069e055_000090_14cf59b2+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409db0 <__swc_fn_7069e055_000147_e7bfe29e>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409db0 <__swc_fn_7069e055_000147_e7bfe29e>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_7069e055_000093_0c97fc6c>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c150 <__swc_fn_7069e055_000091_f21926ed>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_7069e055_000093_0c97fc6c+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_7069e055_000093_0c97fc6c+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   410620 <__swc_fn_7069e055_000137_2d595cc7>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_7069e055_000093_0c97fc6c+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_7069e055+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   410150 <__swc_fn_7069e055_000116_3f5cfdef>
  408959:	call   40c9d0 <__swc_fn_7069e055_000118_591530fe>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_7069e055_000096_a4baaa40>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40896f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  408975:	vzeroupper
  408978:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40897e:	mov    QWORD PTR [rsp+0x48],rdx
  408983:	mov    rax,r8
  408986:	cmp    r8,0x1
  40898a:	mov    edx,0x1
  40898f:	cmovb  rax,rdx
  408993:	mov    QWORD PTR [rsp+0x50],rax
  408998:	mov    rbx,QWORD PTR [rcx+0x8]
  40899c:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a0:	mov    rcx,QWORD PTR [rcx]
  4089a3:	lea    rdx,[rsp+0x8]
  4089a8:	call   rbx
  4089aa:	add    rsp,0x70
  4089ae:	pop    rbx
  4089af:	ret

00000000004089b0 <__swc_fn_7069e055_000099_5232b57d>:
  4089b0:	push   rbx
  4089b1:	push   rsi
  4089b2:	push   rdi
  4089b3:	sub    rsp,0x30
  4089b7:	mov    rbx,rcx
  4089ba:	test   rcx,rcx
  4089bd:	je     4089d2 <__swc_fn_7069e055_000099_5232b57d+0x22>
  4089bf:	mov    rcx,rbx
  4089c2:	mov    edx,0x1
  4089c7:	call   408200 <__swc_fn_7069e055_000078_140918ec>
  4089cc:	cmp    rax,0x1
  4089d0:	je     4089da <__swc_fn_7069e055_000099_5232b57d+0x2a>
  4089d2:	add    rsp,0x30
  4089d6:	pop    rdi
  4089d7:	pop    rsi
  4089d8:	pop    rbx
  4089d9:	ret
  4089da:	lea    rsi,[rsp+0x8]
  4089df:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089e4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089ea:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  4089ef:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4089f5:	mov    rax,QWORD PTR [rsp+0x20]
  4089fa:	test   rax,rax
  4089fd:	je     408a13 <__swc_fn_7069e055_000099_5232b57d+0x63>
  4089ff:	test   DWORD PTR [rax+0x28],0x400000
  408a06:	je     408a13 <__swc_fn_7069e055_000099_5232b57d+0x63>
  408a08:	mov    rcx,QWORD PTR [rax+0x30]
  408a0c:	test   rcx,rcx
  408a0f:	cmovne rax,rcx
  408a13:	mov    edi,DWORD PTR [rax+0x20]
  408a16:	lea    rcx,[rsp+0x18]
  408a1b:	call   40c330 <__swc_fn_7069e055_000100_5714513e>
  408a20:	mov    rcx,rsi
  408a23:	mov    rdx,QWORD PTR [rsp+0x18]
  408a28:	mov    r8,rdi
  408a2b:	call   408960 <__swc_fn_7069e055_000096_a4baaa40>
  408a30:	mov    rcx,QWORD PTR [rbx+0x28]
  408a34:	call   40f700 <__swc_fn_7069e055_000098_f82a1ed3>
  408a39:	mov    rcx,rsi
  408a3c:	mov    rdx,rbx
  408a3f:	mov    r8d,0x30
  408a45:	call   408960 <__swc_fn_7069e055_000096_a4baaa40>
  408a4a:	add    rsp,0x30
  408a4e:	pop    rdi
  408a4f:	pop    rsi
  408a50:	pop    rbx
  408a51:	ret
	...

0000000000408a60 <__swc_fn_7069e055_000102_14986ec5>:
  408a60:	push   rbp
  408a61:	push   rbx
  408a62:	push   rsi
  408a63:	push   rdi
  408a64:	push   r12
  408a66:	push   r13
  408a68:	push   r14
  408a6a:	push   r15
  408a6c:	sub    rsp,0x500
  408a73:	mov    rbp,rsp
  408a76:	mov    rbx,rsp
  408a79:	mov    rsi,rdx
  408a7c:	mov    rdi,rcx
  408a7f:	mov    rcx,QWORD PTR [rip+0x1e2ba]        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  408a86:	test   rcx,rcx
  408a89:	jne    408aa3 <__swc_fn_7069e055_000102_14986ec5+0x43>
  408a8b:	sub    rsp,0x8
  408a8f:	call   40a1a0 <__swc_fn_7069e055_000165_56054fe7>
  408a94:	add    rsp,0x8
  408a98:	lea    rcx,[rax+0x1]
  408a9c:	mov    QWORD PTR [rip+0x1e29d],rcx        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  408aa3:	dec    rcx
  408aa6:	sub    rsp,0x8
  408aaa:	call   411f00 <__swc_fn_7069e055_000167_39c041ad>
  408aaf:	add    rsp,0x8
  408ab3:	mov    r12,rax
  408ab6:	mov    QWORD PTR [rsp+0x4f0],rax
  408abe:	lea    rax,[rip+0xa83b]        # 413300 <__swc_rdata_base_7069e055+0x1f0>
  408ac5:	sub    rsp,0x20
  408ac9:	mov    rcx,rsp
  408acc:	mov    QWORD PTR [rcx],rax
  408acf:	lea    r13,[rip+0xa83a]        # 413310 <__swc_rdata_base_7069e055+0x200>
  408ad6:	mov    QWORD PTR [rcx+0x8],r13
  408ada:	mov    QWORD PTR [rcx+0x10],rsp
  408ade:	mov    QWORD PTR [rcx+0x18],0x1
  408ae6:	lea    rcx,[rsp+0x10]
  408aeb:	sub    rsp,0x8
  408aef:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  408af4:	add    rsp,0x8
  408af8:	add    rsp,0x20
  408afc:	lea    rax,[rip+0xa855]        # 413358 <__swc_rdata_base_7069e055+0x248>
  408b03:	sub    rsp,0x20
  408b07:	mov    rcx,rsp
  408b0a:	mov    QWORD PTR [rcx],rax
  408b0d:	mov    QWORD PTR [rcx+0x8],r13
  408b11:	mov    QWORD PTR [rcx+0x10],rsp
  408b15:	mov    QWORD PTR [rcx+0x18],0x1
  408b1d:	lea    rcx,[rsp+0x10]
  408b22:	sub    rsp,0x8
  408b26:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  408b2b:	add    rsp,0x8
  408b2f:	add    rsp,0x20
  408b33:	lea    r14,[rip+0xa82e]        # 413368 <__swc_rdata_base_7069e055+0x258>
  408b3a:	sub    rsp,0x50
  408b3e:	mov    rax,rsp
  408b41:	vmovups xmm0,XMMWORD PTR [rip+0xa957]        # 4134a0 <__swc_rdata_base_7069e055+0x390>
  408b49:	vmovups XMMWORD PTR [rax],xmm0
  408b4d:	mov    QWORD PTR [rax+0x10],rsp
  408b51:	mov    QWORD PTR [rax+0x18],r13
  408b55:	mov    QWORD PTR [rax+0x20],rdi
  408b59:	lea    rdi,[rip+0xa818]        # 413378 <__swc_rdata_base_7069e055+0x268>
  408b60:	mov    QWORD PTR [rax+0x28],rdi
  408b64:	mov    QWORD PTR [rax+0x30],r14
  408b68:	mov    QWORD PTR [rax+0x38],r13
  408b6c:	lea    rcx,[rsp+0x10]
  408b71:	mov    QWORD PTR [rax+0x40],rcx
  408b75:	mov    QWORD PTR [rax+0x48],0x3
  408b7d:	lea    rcx,[rsp+0x40]
  408b82:	sub    rsp,0x8
  408b86:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  408b8b:	add    rsp,0x8
  408b8f:	add    rsp,0x50
  408b93:	lea    rax,[rip+0xa826]        # 4133c0 <__swc_rdata_base_7069e055+0x2b0>
  408b9a:	sub    rsp,0x20
  408b9e:	mov    rcx,rsp
  408ba1:	mov    QWORD PTR [rcx],rax
  408ba4:	mov    QWORD PTR [rcx+0x8],r13
  408ba8:	mov    QWORD PTR [rcx+0x10],rsp
  408bac:	mov    QWORD PTR [rcx+0x18],0x1
  408bb4:	lea    rcx,[rsp+0x10]
  408bb9:	sub    rsp,0x8
  408bbd:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  408bc2:	add    rsp,0x8
  408bc6:	add    rsp,0x20
  408bca:	mov    eax,DWORD PTR [rsi+0x20]
  408bcd:	mov    ecx,DWORD PTR [rsi+0x24]
  408bd0:	sub    rsp,0xa0
  408bd7:	mov    rdx,rsp
  408bda:	mov    QWORD PTR [rdx+0x30],rsi
  408bde:	mov    QWORD PTR [rdx+0x38],rdi
  408be2:	vmovups xmm0,XMMWORD PTR [rip+0xa84e]        # 413438 <__swc_rdata_base_7069e055+0x328>
  408bea:	vmovups XMMWORD PTR [rdx],xmm0
  408bee:	mov    QWORD PTR [rdx+0x40],rsp
  408bf2:	mov    QWORD PTR [rdx+0x48],r13
  408bf6:	mov    DWORD PTR [rdx+0x10],eax
  408bf9:	lea    rax,[rsp+0x10]
  408bfe:	mov    QWORD PTR [rdx+0x50],rax
  408c02:	lea    rax,[rip+0xa7c7]        # 4133d0 <__swc_rdata_base_7069e055+0x2c0>
  408c09:	mov    QWORD PTR [rdx+0x58],rax
  408c0d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c12:	lea    r8,[rsp+0x18]
  408c17:	mov    QWORD PTR [rdx+0x60],r8
  408c1b:	mov    QWORD PTR [rdx+0x68],r13
  408c1f:	mov    DWORD PTR [rdx+0x28],ecx
  408c22:	lea    rcx,[rdx+0x28]
  408c26:	mov    QWORD PTR [rdx+0x70],rcx
  408c2a:	mov    QWORD PTR [rdx+0x78],rax
  408c2e:	mov    QWORD PTR [rdx+0x80],r14
  408c35:	mov    QWORD PTR [rdx+0x88],r13
  408c3c:	lea    rax,[rdx+0x30]
  408c40:	mov    QWORD PTR [rdx+0x90],rax
  408c47:	mov    QWORD PTR [rdx+0x98],0x6
  408c52:	lea    rcx,[rdx+0x90]
  408c59:	sub    rsp,0x8
  408c5d:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  408c62:	add    rsp,0x8
  408c66:	add    rsp,0xa0
  408c6d:	sub    rsp,0x20
  408c71:	mov    rax,rsp
  408c74:	mov    QWORD PTR [rax],r14
  408c77:	mov    QWORD PTR [rax+0x8],r13
  408c7b:	mov    QWORD PTR [rax+0x10],rsp
  408c7f:	mov    QWORD PTR [rax+0x18],0x1
  408c87:	lea    rcx,[rsp+0x10]
  408c8c:	sub    rsp,0x8
  408c90:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  408c95:	add    rsp,0x8
  408c99:	add    rsp,0x20
  408c9d:	mov    eax,DWORD PTR [r12+0x9ac]
  408ca5:	test   eax,eax
  408ca7:	je     408ee0 <__swc_fn_7069e055_000102_14986ec5+0x480>
  408cad:	lea    rax,[rip+0xa764]        # 413418 <__swc_rdata_base_7069e055+0x308>
  408cb4:	sub    rsp,0x20
  408cb8:	mov    rcx,rsp
  408cbb:	mov    QWORD PTR [rcx],rax
  408cbe:	mov    QWORD PTR [rcx+0x8],r13
  408cc2:	mov    QWORD PTR [rcx+0x10],rsp
  408cc6:	mov    QWORD PTR [rcx+0x18],0x1
  408cce:	lea    rcx,[rsp+0x10]
  408cd3:	sub    rsp,0x8
  408cd7:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  408cdc:	add    rsp,0x8
  408ce0:	add    rsp,0x20
  408ce4:	mov    eax,DWORD PTR [r12+0x9ac]
  408cec:	dec    eax
  408cee:	mov    esi,eax
  408cf0:	test   esi,esi
  408cf2:	jl     408eb0 <__swc_fn_7069e055_000102_14986ec5+0x450>
  408cf8:	jmp    408d04 <__swc_fn_7069e055_000102_14986ec5+0x2a4>
  408cfa:	nop    WORD PTR [rax+rax*1+0x0]
  408d00:	dec    esi
  408d02:	jmp    408cf0 <__swc_fn_7069e055_000102_14986ec5+0x290>
  408d04:	lea    rax,[rip+0xa71d]        # 413428 <__swc_rdata_base_7069e055+0x318>
  408d0b:	sub    rsp,0x20
  408d0f:	mov    rcx,rsp
  408d12:	mov    QWORD PTR [rcx],rax
  408d15:	mov    QWORD PTR [rcx+0x8],r13
  408d19:	mov    QWORD PTR [rcx+0x10],rsp
  408d1d:	mov    QWORD PTR [rcx+0x18],0x1
  408d25:	lea    rcx,[rsp+0x10]
  408d2a:	sub    rsp,0x8
  408d2e:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  408d33:	add    rsp,0x8
  408d37:	add    rsp,0x20
  408d3b:	movsxd rax,esi
  408d3e:	imul   r15,rax,0x30
  408d42:	add    r15,r12
  408d45:	add    r15,0xf8
  408d4c:	sub    rsp,0x20
  408d50:	mov    rax,rsp
  408d53:	mov    QWORD PTR [rax],r15
  408d56:	mov    QWORD PTR [rax+0x8],rdi
  408d5a:	mov    QWORD PTR [rax+0x10],rsp
  408d5e:	mov    QWORD PTR [rax+0x18],0x1
  408d66:	lea    rcx,[rsp+0x10]
  408d6b:	sub    rsp,0x8
  408d6f:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  408d74:	add    rsp,0x8
  408d78:	add    rsp,0x20
  408d7c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408d84:	lea    rsi,[rip+0xa6ad]        # 413438 <__swc_rdata_base_7069e055+0x328>
  408d8b:	sub    rsp,0x20
  408d8f:	mov    rax,rsp
  408d92:	mov    QWORD PTR [rax],rsi
  408d95:	mov    QWORD PTR [rax+0x8],r13
  408d99:	mov    QWORD PTR [rax+0x10],rsp
  408d9d:	mov    QWORD PTR [rax+0x18],0x1
  408da5:	lea    rcx,[rsp+0x10]
  408daa:	sub    rsp,0x8
  408dae:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  408db3:	add    rsp,0x8
  408db7:	add    rsp,0x20
  408dbb:	sub    rsp,0x30
  408dbf:	mov    rax,rsp
  408dc2:	mov    ecx,DWORD PTR [r15+0x20]
  408dc6:	mov    QWORD PTR [rax],rcx
  408dc9:	mov    QWORD PTR [rax+0x8],rsp
  408dcd:	lea    rdi,[rip+0xa674]        # 413448 <__swc_rdata_base_7069e055+0x338>
  408dd4:	mov    QWORD PTR [rax+0x10],rdi
  408dd8:	lea    rcx,[rsp+0x8]
  408ddd:	mov    QWORD PTR [rax+0x18],rcx
  408de1:	mov    QWORD PTR [rax+0x20],0x1
  408de9:	lea    rcx,[rsp+0x18]
  408dee:	sub    rsp,0x8
  408df2:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  408df7:	add    rsp,0x8
  408dfb:	add    rsp,0x30
  408dff:	sub    rsp,0x20
  408e03:	mov    rax,rsp
  408e06:	mov    QWORD PTR [rax],rsi
  408e09:	mov    QWORD PTR [rax+0x8],r13
  408e0d:	mov    QWORD PTR [rax+0x10],rsp
  408e11:	mov    QWORD PTR [rax+0x18],0x1
  408e19:	lea    rcx,[rsp+0x10]
  408e1e:	sub    rsp,0x8
  408e22:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  408e27:	add    rsp,0x8
  408e2b:	add    rsp,0x20
  408e2f:	sub    rsp,0x30
  408e33:	mov    rax,rsp
  408e36:	mov    ecx,DWORD PTR [r15+0x24]
  408e3a:	mov    QWORD PTR [rax],rcx
  408e3d:	mov    QWORD PTR [rax+0x8],rsp
  408e41:	mov    QWORD PTR [rax+0x10],rdi
  408e45:	lea    rcx,[rsp+0x8]
  408e4a:	mov    QWORD PTR [rax+0x18],rcx
  408e4e:	mov    QWORD PTR [rax+0x20],0x1
  408e56:	lea    rcx,[rsp+0x18]
  408e5b:	sub    rsp,0x8
  408e5f:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  408e64:	add    rsp,0x8
  408e68:	add    rsp,0x30
  408e6c:	sub    rsp,0x20
  408e70:	mov    rax,rsp
  408e73:	mov    QWORD PTR [rax],r14
  408e76:	mov    QWORD PTR [rax+0x8],r13
  408e7a:	mov    QWORD PTR [rax+0x10],rsp
  408e7e:	mov    QWORD PTR [rax+0x18],0x1
  408e86:	lea    rcx,[rsp+0x10]
  408e8b:	sub    rsp,0x8
  408e8f:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  408e94:	add    rsp,0x8
  408e98:	add    rsp,0x20
  408e9c:	lea    rdi,[rip+0xa4d5]        # 413378 <__swc_rdata_base_7069e055+0x268>
  408ea3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408eab:	jmp    408d00 <__swc_fn_7069e055_000102_14986ec5+0x2a0>
  408eb0:	sub    rsp,0x20
  408eb4:	mov    rax,rsp
  408eb7:	mov    QWORD PTR [rax],r14
  408eba:	mov    QWORD PTR [rax+0x8],r13
  408ebe:	mov    QWORD PTR [rax+0x10],rsp
  408ec2:	mov    QWORD PTR [rax+0x18],0x1
  408eca:	lea    rcx,[rsp+0x10]
  408ecf:	sub    rsp,0x8
  408ed3:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  408ed8:	add    rsp,0x8
  408edc:	add    rsp,0x20
  408ee0:	lea    rax,[rbx+0x28]
  408ee4:	mov    rcx,rax
  408ee7:	mov    QWORD PTR [rbx+0x28],0x0
  408eef:	mov    QWORD PTR [rbx+0x30],0x0
  408ef7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408efc:	add    rcx,0x10
  408f00:	mov    edx,0x1f
  408f05:	cs nop WORD PTR [rax+rax*1+0x0]
  408f0f:	nop
  408f10:	vmovups XMMWORD PTR [rcx],xmm0
  408f14:	add    rcx,0x10
  408f18:	sub    rdx,0x1
  408f1c:	jne    408f10 <__swc_fn_7069e055_000102_14986ec5+0x4b0>
  408f1e:	lea    rsi,[rbx+0x228]
  408f25:	xor    ecx,ecx
  408f27:	cs nop WORD PTR [rax+rax*1+0x0]
  408f31:	cs nop WORD PTR [rax+rax*1+0x0]
  408f3b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f40:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f45:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f4a:	add    rcx,0x10
  408f4e:	cmp    rcx,0x200
  408f55:	jne    408f40 <__swc_fn_7069e055_000102_14986ec5+0x4e0>
  408f57:	mov    eax,DWORD PTR [r12+0xbc8]
  408f5f:	lea    rcx,[r12+0x9c8]
  408f67:	mov    QWORD PTR [rbx+0x428],rcx
  408f6e:	mov    QWORD PTR [rbx+0x430],rax
  408f75:	lea    rdi,[rbx+0x438]
  408f7c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408f84:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408f8c:	mov    eax,DWORD PTR [r12+0xbc8]
  408f94:	test   eax,eax
  408f96:	jne    408fe3 <__swc_fn_7069e055_000102_14986ec5+0x583>
  408f98:	lea    rax,[rbx+0x448]
  408f9f:	mov    QWORD PTR [rbx+0x448],rsi
  408fa6:	mov    QWORD PTR [rax+0x8],0x40
  408fae:	mov    ecx,0x1
  408fb3:	mov    rdx,rax
  408fb6:	sub    rsp,0x8
  408fba:	call   410260 <__swc_fn_7069e055_000119_2d9caf16>
  408fbf:	add    rsp,0x8
  408fc3:	mov    QWORD PTR [rbx+0x460],rsi
  408fca:	mov    ecx,eax
  408fcc:	mov    QWORD PTR [rbx+0x468],rcx
  408fd3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408fdb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fe3:	mov    rsi,QWORD PTR [rbx+0x438]
  408fea:	mov    rax,QWORD PTR [rbx+0x440]
  408ff1:	mov    r15,rax
  408ff4:	xor    r12d,r12d
  408ff7:	test   r15,r15
  408ffa:	je     4090b0 <__swc_fn_7069e055_000102_14986ec5+0x650>
  409000:	mov    rax,QWORD PTR [rsi+r12*8]
  409004:	test   rax,rax
  409007:	je     409026 <__swc_fn_7069e055_000102_14986ec5+0x5c6>
  409009:	lea    rcx,[rbx+0x4b8]
  409010:	mov    rdx,rax
  409013:	sub    rsp,0x8
  409017:	call   409f10 <__swc_fn_7069e055_000162_61e293bf>
  40901c:	add    rsp,0x8
  409020:	mov    al,BYTE PTR [rax]
  409022:	test   al,al
  409024:	jne    409032 <__swc_fn_7069e055_000102_14986ec5+0x5d2>
  409026:	add    r12,0x1
  40902a:	sub    r15,0x1
  40902e:	jne    409000 <__swc_fn_7069e055_000102_14986ec5+0x5a0>
  409030:	jmp    4090b0 <__swc_fn_7069e055_000102_14986ec5+0x650>
  409032:	lea    rax,[rip+0xa457]        # 413490 <__swc_rdata_base_7069e055+0x380>
  409039:	sub    rsp,0x20
  40903d:	mov    rcx,rsp
  409040:	mov    QWORD PTR [rcx],rax
  409043:	mov    QWORD PTR [rcx+0x8],r13
  409047:	mov    QWORD PTR [rcx+0x10],rsp
  40904b:	mov    QWORD PTR [rcx+0x18],0x1
  409053:	lea    rcx,[rsp+0x10]
  409058:	sub    rsp,0x8
  40905c:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  409061:	add    rsp,0x8
  409065:	add    rsp,0x20
  409069:	mov    rcx,rdi
  40906c:	xor    edx,edx
  40906e:	mov    al,0x1
  409070:	mov    r8,rax
  409073:	sub    rsp,0x8
  409077:	call   40d260 <__swc_fn_7069e055_000163_3a7aae74>
  40907c:	add    rsp,0x8
  409080:	sub    rsp,0x20
  409084:	mov    rax,rsp
  409087:	mov    QWORD PTR [rax],r14
  40908a:	mov    QWORD PTR [rax+0x8],r13
  40908e:	mov    QWORD PTR [rax+0x10],rsp
  409092:	mov    QWORD PTR [rax+0x18],0x1
  40909a:	lea    rcx,[rsp+0x10]
  40909f:	sub    rsp,0x8
  4090a3:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  4090a8:	add    rsp,0x8
  4090ac:	add    rsp,0x20
  4090b0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090b8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090c4:	add    rsp,0x500
  4090cb:	pop    r15
  4090cd:	pop    r14
  4090cf:	pop    r13
  4090d1:	pop    r12
  4090d3:	pop    rdi
  4090d4:	pop    rsi
  4090d5:	pop    rbx
  4090d6:	pop    rbp
  4090d7:	ret
	...

00000000004090e0 <__swc_fn_7069e055_000105_83487ba1>:
  4090e0:	sub    rsp,0x8
  4090e4:	test   r8,r8
  4090e7:	je     4090ee <__swc_fn_7069e055_000105_83487ba1+0xe>
  4090e9:	call   40f990 <__swc_fn_7069e055_000104_04d1a8be>
  4090ee:	add    rsp,0x8
  4090f2:	ret
	...

0000000000409100 <__swc_fn_7069e055_000108_b8f4bd15>:
  409100:	push   rsi
  409101:	push   rdi
  409102:	push   r12
  409104:	push   r13
  409106:	sub    rsp,0xd8
  40910d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409113:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409119:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40911f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409125:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40912b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409134:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40913d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409146:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40914f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409158:	xor    eax,eax
  40915a:	call   407010 <getpid@plt>
  40915f:	mov    rsi,rax
  409162:	lea    rdi,[rip+0x1dbdf]        # 426d48 <__swc_bss_base_7069e055+0x2d08>
  409169:	mov    r12,QWORD PTR [rdi]
  40916c:	test   r12,r12
  40916f:	je     40917d <__swc_fn_7069e055_000108_b8f4bd15+0x7d>
  409171:	cmp    DWORD PTR [r12+0x10],esi
  409176:	jne    40917d <__swc_fn_7069e055_000108_b8f4bd15+0x7d>
  409178:	mov    rax,r12
  40917b:	jmp    4091e0 <__swc_fn_7069e055_000108_b8f4bd15+0xe0>
  40917d:	mov    ecx,0x4
  409182:	mov    edx,0x18
  409187:	call   40fa70 <__swc_fn_7069e055_000107_c8d4a68e>
  40918c:	mov    rcx,rax
  40918f:	test   rax,rax
  409192:	jne    409198 <__swc_fn_7069e055_000108_b8f4bd15+0x98>
  409194:	xor    eax,eax
  409196:	jmp    4091e0 <__swc_fn_7069e055_000108_b8f4bd15+0xe0>
  409198:	mov    DWORD PTR [rcx+0x10],esi
  40919b:	mov    rax,r12
  40919e:	lock cmpxchg QWORD PTR [rdi],rcx
  4091a3:	mov    r13,rax
  4091a6:	cmp    rax,r12
  4091a9:	je     4091bf <__swc_fn_7069e055_000108_b8f4bd15+0xbf>
  4091ab:	mov    rdi,rcx
  4091ae:	mov    esi,0x18
  4091b3:	xor    eax,eax
  4091b5:	call   407020 <munmap@plt>
  4091ba:	mov    rax,r13
  4091bd:	jmp    4091e0 <__swc_fn_7069e055_000108_b8f4bd15+0xe0>
  4091bf:	test   r12,r12
  4091c2:	je     4091dd <__swc_fn_7069e055_000108_b8f4bd15+0xdd>
  4091c4:	mov    rdi,r12
  4091c7:	mov    esi,0x18
  4091cc:	xor    eax,eax
  4091ce:	mov    QWORD PTR [rsp+0x28],rcx
  4091d3:	call   407020 <munmap@plt>
  4091d8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091dd:	mov    rax,rcx
  4091e0:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4091e6:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4091ec:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4091f2:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4091f8:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4091fe:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409207:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409210:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409219:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409222:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40922b:	add    rsp,0xd8
  409232:	pop    r13
  409234:	pop    r12
  409236:	pop    rdi
  409237:	pop    rsi
  409238:	ret
  409239:	add    BYTE PTR [rax],al
  40923b:	add    BYTE PTR [rax],al
  40923d:	add    BYTE PTR [rax],al
	...

0000000000409240 <__swc_fn_7069e055_000111_f9e19033>:
  409240:	push   rbx
  409241:	push   r12
  409243:	push   rdi
  409244:	push   rsi
  409245:	sub    rsp,0xa8
  40924c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409252:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409258:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40925e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409264:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40926a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409270:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409276:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40927c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409285:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40928e:	mov    rbx,rdx
  409291:	mov    r12,rcx
  409294:	mov    rdi,rcx
  409297:	mov    rsi,rdx
  40929a:	mov    edx,0x3
  40929f:	xor    eax,eax
  4092a1:	call   407030 <mprotect@plt>
  4092a6:	test   eax,eax
  4092a8:	je     4092ae <__swc_fn_7069e055_000111_f9e19033+0x6e>
  4092aa:	xor    eax,eax
  4092ac:	jmp    4092c3 <__swc_fn_7069e055_000111_f9e19033+0x83>
  4092ae:	mov    rcx,r12
  4092b1:	mov    rdx,rbx
  4092b4:	mov    al,0x1
  4092b6:	mov    r8,rax
  4092b9:	call   4100a0 <__swc_fn_7069e055_000110_918d5a21>
  4092be:	mov    eax,0x1
  4092c3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092c9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092cf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092d5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092db:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4092e1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4092e7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4092ed:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4092f3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4092fc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409305:	add    rsp,0xa8
  40930c:	pop    rsi
  40930d:	pop    rdi
  40930e:	pop    r12
  409310:	pop    rbx
  409311:	ret
	...

0000000000409320 <__swc_fn_7069e055_000114_cc486df9>:
  409320:	sub    rsp,0x8
  409324:	test   rcx,rcx
  409327:	jne    40932e <__swc_fn_7069e055_000114_cc486df9+0xe>
  409329:	add    rsp,0x8
  40932d:	ret
  40932e:	call   40c880 <__swc_fn_7069e055_000115_3f6af4b1>
  409333:	add    rsp,0x8
  409337:	ret
	...

0000000000409340 <__swc_fn_7069e055_000117_5aba1420>:
  409340:	push   rdi
  409341:	push   rsi
  409342:	sub    rsp,0xa8
  409349:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40934f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409355:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40935b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409361:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409367:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40936d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409373:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409379:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409382:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40938b:	xor    edi,edi
  40938d:	xor    eax,eax
  40938f:	call   407040 <exit@plt>
  409394:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40939a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093a0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093a6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093ac:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093b2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093b8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093be:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093c4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093cd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093d6:	add    rsp,0xa8
  4093dd:	pop    rsi
  4093de:	pop    rdi
  4093df:	ret

00000000004093e0 <__swc_fn_7069e055_000120_1e032ef6>:
  4093e0:	push   rbx
  4093e1:	push   rsi
  4093e2:	push   rdi
  4093e3:	push   r12
  4093e5:	sub    rsp,0x18
  4093e9:	mov    rbx,r8
  4093ec:	mov    rsi,rcx
  4093ef:	mov    rdi,rdx
  4093f2:	mov    rcx,QWORD PTR [rip+0x1d947]        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  4093f9:	test   rcx,rcx
  4093fc:	jne    40940e <__swc_fn_7069e055_000120_1e032ef6+0x2e>
  4093fe:	call   40a1a0 <__swc_fn_7069e055_000165_56054fe7>
  409403:	lea    rcx,[rax+0x1]
  409407:	mov    QWORD PTR [rip+0x1d932],rcx        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40940e:	dec    rcx
  409411:	call   411f00 <__swc_fn_7069e055_000167_39c041ad>
  409416:	mov    r12,rax
  409419:	cmp    ebx,0x3
  40941c:	jne    40942f <__swc_fn_7069e055_000120_1e032ef6+0x4f>
  40941e:	mov    rax,QWORD PTR [r12+0xbd0]
  409426:	test   rax,rax
  409429:	jne    40956c <__swc_fn_7069e055_000120_1e032ef6+0x18c>
  40942f:	cmp    ebx,0x5
  409432:	jne    409456 <__swc_fn_7069e055_000120_1e032ef6+0x76>
  409434:	call   40c150 <__swc_fn_7069e055_000091_f21926ed>
  409439:	test   al,al
  40943b:	jne    409456 <__swc_fn_7069e055_000120_1e032ef6+0x76>
  40943d:	mov    rcx,rsi
  409440:	mov    rdx,rdi
  409443:	call   411eb0 <__swc_fn_7069e055_000164_d25850aa>
  409448:	test   al,al
  40944a:	je     409456 <__swc_fn_7069e055_000120_1e032ef6+0x76>
  40944c:	add    rsp,0x18
  409450:	pop    r12
  409452:	pop    rdi
  409453:	pop    rsi
  409454:	pop    rbx
  409455:	ret
  409456:	call   40c150 <__swc_fn_7069e055_000091_f21926ed>
  40945b:	test   al,al
  40945d:	jne    4094cf <__swc_fn_7069e055_000120_1e032ef6+0xef>
  40945f:	vmovups xmm0,XMMWORD PTR [rsi]
  409463:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409469:	mov    rax,QWORD PTR [rsp+0x8]
  40946e:	test   rax,rax
  409471:	jne    4094c2 <__swc_fn_7069e055_000120_1e032ef6+0xe2>
  409473:	cmp    ebx,0x3
  409476:	je     409484 <__swc_fn_7069e055_000120_1e032ef6+0xa4>
  409478:	cmp    ebx,0x4
  40947b:	je     409494 <__swc_fn_7069e055_000120_1e032ef6+0xb4>
  40947d:	cmp    ebx,0x5
  409480:	je     4094a4 <__swc_fn_7069e055_000120_1e032ef6+0xc4>
  409482:	jmp    4094b4 <__swc_fn_7069e055_000120_1e032ef6+0xd4>
  409484:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 4134e0 <__swc_rdata_base_7069e055+0x3d0>
  40948c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409492:	jmp    4094c2 <__swc_fn_7069e055_000120_1e032ef6+0xe2>
  409494:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 4134f0 <__swc_rdata_base_7069e055+0x3e0>
  40949c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094a2:	jmp    4094c2 <__swc_fn_7069e055_000120_1e032ef6+0xe2>
  4094a4:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 413500 <__swc_rdata_base_7069e055+0x3f0>
  4094ac:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b2:	jmp    4094c2 <__swc_fn_7069e055_000120_1e032ef6+0xe2>
  4094b4:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 413510 <__swc_rdata_base_7069e055+0x400>
  4094bc:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c2:	lea    rcx,[rsp+0x8]
  4094c7:	mov    rdx,rdi
  4094ca:	call   40c3a0 <__swc_fn_7069e055_000103_0d4cc079>
  4094cf:	vmovups xmm0,XMMWORD PTR [rdi]
  4094d3:	vmovups XMMWORD PTR [r12+0x940],xmm0
  4094dd:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  4094e2:	vmovups XMMWORD PTR [r12+0x950],xmm0
  4094ec:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  4094f1:	vmovups XMMWORD PTR [r12+0x960],xmm0
  4094fb:	lea    rax,[r12+0x940]
  409503:	mov    QWORD PTR [r12+0x970],rax
  40950b:	mov    rax,QWORD PTR [rsi]
  40950e:	mov    QWORD PTR [r12+0x978],rax
  409516:	mov    rax,QWORD PTR [rsi+0x8]
  40951a:	mov    QWORD PTR [r12+0x980],rax
  409522:	movsxd rax,ebx
  409525:	mov    QWORD PTR [r12+0x988],rax
  40952d:	cmp    ebx,0x5
  409530:	je     409539 <__swc_fn_7069e055_000120_1e032ef6+0x159>
  409532:	xor    ecx,ecx
  409534:	call   40a2d0 <__swc_fn_7069e055_000174_02e645b4>
  409539:	mov    rbx,QWORD PTR [r12+0xbe8]
  409541:	test   rbx,rbx
  409544:	je     409555 <__swc_fn_7069e055_000120_1e032ef6+0x175>
  409546:	mov    rcx,r12
  409549:	call   rbx
  40954b:	add    rsp,0x18
  40954f:	pop    r12
  409551:	pop    rdi
  409552:	pop    rsi
  409553:	pop    rbx
  409554:	ret
  409555:	mov    rcx,rsi
  409558:	call   410150 <__swc_fn_7069e055_000116_3f5cfdef>
  40955d:	call   40c9d0 <__swc_fn_7069e055_000118_591530fe>
  409562:	add    rsp,0x18
  409566:	pop    r12
  409568:	pop    rdi
  409569:	pop    rsi
  40956a:	pop    rbx
  40956b:	ret
  40956c:	mov    rcx,rsi
  40956f:	mov    rdx,rdi
  409572:	call   40c3a0 <__swc_fn_7069e055_000103_0d4cc079>
  409577:	jmp    40942f <__swc_fn_7069e055_000120_1e032ef6+0x4f>
  40957c:	add    BYTE PTR [rax],al
	...

0000000000409580 <__swc_fn_7069e055_000123_e4107ade>:
  409580:	push   rdi
  409581:	push   rsi
  409582:	sub    rsp,0xb8
  409589:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40958f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409595:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40959b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ce:	mov    DWORD PTR [rsp+0x8],0x0
  4095d6:	lea    rdi,[rsp+0x8]
  4095db:	xor    esi,esi
  4095dd:	xor    eax,eax
  4095df:	call   407050 <pthread_key_create@plt>
  4095e4:	test   eax,eax
  4095e6:	jne    4095ee <__swc_fn_7069e055_000123_e4107ade+0x6e>
  4095e8:	mov    eax,DWORD PTR [rsp+0x8]
  4095ec:	jmp    4095f5 <__swc_fn_7069e055_000123_e4107ade+0x75>
  4095ee:	mov    rax,0xffffffffffffffff
  4095f5:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4095fb:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409601:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409607:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40960d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409613:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409619:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40961f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409628:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409631:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40963a:	add    rsp,0xb8
  409641:	pop    rsi
  409642:	pop    rdi
  409643:	ret
	...

0000000000409650 <__swc_fn_7069e055_000126_9e9697c7>:
  409650:	push   rdi
  409651:	push   rsi
  409652:	sub    rsp,0xb8
  409659:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40965f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409665:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40966b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409671:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409677:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40967d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409683:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40968c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409695:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40969e:	mov    DWORD PTR [rsp+0x8],0x0
  4096a6:	lea    rdi,[rsp+0x8]
  4096ab:	mov    rsi,rcx
  4096ae:	xor    eax,eax
  4096b0:	call   407050 <pthread_key_create@plt>
  4096b5:	test   eax,eax
  4096b7:	jne    4096c2 <__swc_fn_7069e055_000126_9e9697c7+0x72>
  4096b9:	mov    eax,DWORD PTR [rsp+0x8]
  4096bd:	inc    rax
  4096c0:	jmp    4096c4 <__swc_fn_7069e055_000126_9e9697c7+0x74>
  4096c2:	xor    eax,eax
  4096c4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ca:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096d0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096d6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096dc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4096e2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4096e8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4096ee:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4096f7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409700:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409709:	add    rsp,0xb8
  409710:	pop    rsi
  409711:	pop    rdi
  409712:	ret
	...

0000000000409720 <__swc_fn_7069e055_000129_bc477461>:
  409720:	push   rdi
  409721:	push   rsi
  409722:	sub    rsp,0xa8
  409729:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40972f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409735:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40973b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409741:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409747:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40974d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409753:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409759:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409762:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40976b:	test   rcx,rcx
  40976e:	setne  al
  409771:	je     40978a <__swc_fn_7069e055_000129_bc477461+0x6a>
  409773:	lea    rax,[rcx-0x1]
  409777:	mov    eax,eax
  409779:	mov    edi,eax
  40977b:	mov    rsi,rdx
  40977e:	xor    eax,eax
  409780:	call   407060 <pthread_setspecific@plt>
  409785:	test   eax,eax
  409787:	sete   al
  40978a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409790:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409796:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40979c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097a2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097a8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ae:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097b4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097ba:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097c3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097cc:	add    rsp,0xa8
  4097d3:	pop    rsi
  4097d4:	pop    rdi
  4097d5:	ret
	...

00000000004097e0 <__swc_fn_7069e055_000132_51cc49e7>:
  4097e0:	push   rdi
  4097e1:	push   rsi
  4097e2:	sub    rsp,0xa8
  4097e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4097ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4097f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4097fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409801:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409807:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40980d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409813:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409819:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409822:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40982b:	mov    rax,rdx
  40982e:	mov    QWORD PTR [rsp],0x0
  409836:	mov    edi,0xca
  40983b:	mov    rsi,rcx
  40983e:	mov    edx,0x81
  409843:	mov    eax,eax
  409845:	mov    ecx,eax
  409847:	xor    r8d,r8d
  40984a:	xor    r9d,r9d
  40984d:	xor    eax,eax
  40984f:	call   407070 <syscall@plt>
  409854:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40985a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409860:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409866:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40986c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409872:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409878:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40987e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409884:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40988d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409896:	add    rsp,0xa8
  40989d:	pop    rsi
  40989e:	pop    rdi
  40989f:	ret

00000000004098a0 <__swc_fn_7069e055_000135_db32cc57>:
  4098a0:	sub    rsp,0x8
  4098a4:	call   40cd70 <__swc_fn_7069e055_000133_807fd51d>
  4098a9:	add    rsp,0x8
  4098ad:	ret
	...

00000000004098b0 <__swc_fn_7069e055_000138_22d6573c>:
  4098b0:	push   rdi
  4098b1:	push   rsi
  4098b2:	sub    rsp,0xc8
  4098b9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098bf:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098c5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098cb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098d1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098d7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098dd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  4098e6:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  4098ef:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  4098f8:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409901:	vxorps xmm0,xmm0,xmm0
  409905:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40990b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409911:	mov    rdi,rcx
  409914:	lea    rsi,[rsp+0x8]
  409919:	xor    eax,eax
  40991b:	call   407080 <dladdr@plt>
  409920:	xor    ecx,ecx
  409922:	test   eax,eax
  409924:	je     40992b <__swc_fn_7069e055_000138_22d6573c+0x7b>
  409926:	mov    rcx,QWORD PTR [rsp+0x10]
  40992b:	mov    rax,rcx
  40992e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409934:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40993a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409940:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409946:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40994c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409952:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40995b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409964:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40996d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409976:	add    rsp,0xc8
  40997d:	pop    rsi
  40997e:	pop    rdi
  40997f:	ret

0000000000409980 <__swc_fn_7069e055_000141_5e493395>:
  409980:	push   rbx
  409981:	push   r12
  409983:	push   r13
  409985:	push   rdi
  409986:	push   rsi
  409987:	push   r14
  409989:	push   r15
  40998b:	sub    rsp,0x150
  409992:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40999b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099a4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099ad:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099b6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099bf:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099c8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099d1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099da:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  4099e3:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  4099ec:	mov    rbx,rdx
  4099ef:	mov    QWORD PTR [rsp+0x98],rdx
  4099f7:	mov    r12,rcx
  4099fa:	mov    QWORD PTR [rsp+0xa0],rcx
  409a02:	mov    QWORD PTR [rbx],0x0
  409a09:	lea    r13,[rip+0x1d370]        # 426d80 <__swc_bss_base_7069e055+0x2d40>
  409a10:	mov    rcx,r13
  409a13:	call   4098a0 <__swc_fn_7069e055_000135_db32cc57>
  409a18:	mov    rax,QWORD PTR [rip+0x1d369]        # 426d88 <__swc_bss_base_7069e055+0x2d48>
  409a1f:	test   rax,rax
  409a22:	je     409a59 <__swc_fn_7069e055_000141_5e493395+0xd9>
  409a24:	cs nop WORD PTR [rax+rax*1+0x0]
  409a2e:	xchg   ax,ax
  409a30:	cmp    QWORD PTR [rax+0x8],r12
  409a34:	jne    409a51 <__swc_fn_7069e055_000141_5e493395+0xd1>
  409a36:	mov    rcx,QWORD PTR [rax+0x18]
  409a3a:	mov    QWORD PTR [rbx],rcx
  409a3d:	mov    rbx,QWORD PTR [rax+0x10]
  409a41:	mov    rcx,r13
  409a44:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  409a49:	mov    rax,rbx
  409a4c:	jmp    409c3b <__swc_fn_7069e055_000141_5e493395+0x2bb>
  409a51:	mov    rax,QWORD PTR [rax]
  409a54:	test   rax,rax
  409a57:	jne    409a30 <__swc_fn_7069e055_000141_5e493395+0xb0>
  409a59:	vxorps xmm0,xmm0,xmm0
  409a5d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a63:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a69:	mov    rdi,r12
  409a6c:	lea    rsi,[rsp+0x10]
  409a71:	xor    eax,eax
  409a73:	call   407080 <dladdr@plt>
  409a78:	test   eax,eax
  409a7a:	sete   al
  409a7d:	je     409a8a <__swc_fn_7069e055_000141_5e493395+0x10a>
  409a7f:	mov    rax,QWORD PTR [rsp+0x10]
  409a84:	test   rax,rax
  409a87:	sete   al
  409a8a:	test   al,al
  409a8c:	je     409a9d <__swc_fn_7069e055_000141_5e493395+0x11d>
  409a8e:	mov    rcx,r13
  409a91:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  409a96:	xor    eax,eax
  409a98:	jmp    409c3b <__swc_fn_7069e055_000141_5e493395+0x2bb>
  409a9d:	mov    rdi,QWORD PTR [rsp+0x10]
  409aa2:	mov    esi,0x80000
  409aa7:	xor    eax,eax
  409aa9:	call   407090 <open@plt>
  409aae:	lea    r14,[rsp+0x30]
  409ab3:	mov    DWORD PTR [rsp+0x30],eax
  409ab7:	cmp    DWORD PTR [r14],0x0
  409abb:	jge    409acc <__swc_fn_7069e055_000141_5e493395+0x14c>
  409abd:	mov    rcx,r13
  409ac0:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  409ac5:	xor    eax,eax
  409ac7:	jmp    409c3b <__swc_fn_7069e055_000141_5e493395+0x2bb>
  409acc:	mov    rax,r14
  409acf:	movsxd rdi,DWORD PTR [rax]
  409ad2:	xor    esi,esi
  409ad4:	mov    edx,0x2
  409ad9:	xor    eax,eax
  409adb:	call   4070a0 <lseek@plt>
  409ae0:	mov    r15,rax
  409ae3:	test   rax,rax
  409ae6:	jg     409b01 <__swc_fn_7069e055_000141_5e493395+0x181>
  409ae8:	movsxd rdi,DWORD PTR [r14]
  409aeb:	xor    eax,eax
  409aed:	call   4070b0 <close@plt>
  409af2:	mov    rcx,r13
  409af5:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  409afa:	xor    eax,eax
  409afc:	jmp    409c3b <__swc_fn_7069e055_000141_5e493395+0x2bb>
  409b01:	xor    edi,edi
  409b03:	mov    rsi,r15
  409b06:	mov    edx,0x1
  409b0b:	mov    ecx,0x2
  409b10:	mov    rax,r14
  409b13:	movsxd r8,DWORD PTR [rax]
  409b16:	xor    r9d,r9d
  409b19:	xor    eax,eax
  409b1b:	call   4070c0 <mmap@plt>
  409b20:	mov    rbx,rax
  409b23:	test   rax,rax
  409b26:	sete   al
  409b29:	cmp    rbx,0xffffffffffffffff
  409b2d:	sete   cl
  409b30:	or     al,cl
  409b32:	je     409b4d <__swc_fn_7069e055_000141_5e493395+0x1cd>
  409b34:	movsxd rdi,DWORD PTR [r14]
  409b37:	xor    eax,eax
  409b39:	call   4070b0 <close@plt>
  409b3e:	mov    rcx,r13
  409b41:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  409b46:	xor    eax,eax
  409b48:	jmp    409c3b <__swc_fn_7069e055_000141_5e493395+0x2bb>
  409b4d:	lea    rax,[rsp+0x50]
  409b52:	mov    QWORD PTR [rax],0x0
  409b59:	mov    rcx,rbx
  409b5c:	mov    rdx,r15
  409b5f:	mov    r8,rax
  409b62:	call   4106e0 <__swc_fn_7069e055_000140_55003b6d>
  409b67:	mov    r12,rax
  409b6a:	test   rax,rax
  409b6d:	jne    409b95 <__swc_fn_7069e055_000141_5e493395+0x215>
  409b6f:	mov    rdi,rbx
  409b72:	mov    rsi,r15
  409b75:	xor    eax,eax
  409b77:	call   407020 <munmap@plt>
  409b7c:	movsxd rdi,DWORD PTR [r14]
  409b7f:	xor    eax,eax
  409b81:	call   4070b0 <close@plt>
  409b86:	mov    rcx,r13
  409b89:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  409b8e:	xor    eax,eax
  409b90:	jmp    409c3b <__swc_fn_7069e055_000141_5e493395+0x2bb>
  409b95:	mov    edi,0x20
  409b9a:	xor    eax,eax
  409b9c:	call   4070d0 <malloc@plt>
  409ba1:	test   rax,rax
  409ba4:	jne    409bc9 <__swc_fn_7069e055_000141_5e493395+0x249>
  409ba6:	mov    rdi,rbx
  409ba9:	mov    rsi,r15
  409bac:	xor    eax,eax
  409bae:	call   407020 <munmap@plt>
  409bb3:	movsxd rdi,DWORD PTR [r14]
  409bb6:	xor    eax,eax
  409bb8:	call   4070b0 <close@plt>
  409bbd:	mov    rcx,r13
  409bc0:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  409bc5:	xor    eax,eax
  409bc7:	jmp    409c3b <__swc_fn_7069e055_000141_5e493395+0x2bb>
  409bc9:	mov    rcx,QWORD PTR [rip+0x1d1b8]        # 426d88 <__swc_bss_base_7069e055+0x2d48>
  409bd0:	mov    QWORD PTR [rsp+0x70],rcx
  409bd5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bdd:	mov    QWORD PTR [rsp+0x78],rcx
  409be2:	mov    QWORD PTR [rsp+0x80],r12
  409bea:	mov    rcx,QWORD PTR [rsp+0x50]
  409bef:	mov    QWORD PTR [rsp+0x88],rcx
  409bf7:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409bfd:	vmovups XMMWORD PTR [rax],xmm0
  409c01:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c0a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c0f:	mov    QWORD PTR [rip+0x1d172],rax        # 426d88 <__swc_bss_base_7069e055+0x2d48>
  409c16:	mov    rax,QWORD PTR [rsp+0x50]
  409c1b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c23:	mov    QWORD PTR [rbx],rax
  409c26:	movsxd rdi,DWORD PTR [r14]
  409c29:	xor    eax,eax
  409c2b:	call   4070b0 <close@plt>
  409c30:	mov    rcx,r13
  409c33:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  409c38:	mov    rax,r12
  409c3b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c44:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c4d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c56:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c5f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c68:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c71:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c7a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409c83:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409c8c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409c95:	add    rsp,0x150
  409c9c:	pop    r15
  409c9e:	pop    r14
  409ca0:	pop    rsi
  409ca1:	pop    rdi
  409ca2:	pop    r13
  409ca4:	pop    r12
  409ca6:	pop    rbx
  409ca7:	ret
	...

0000000000409cb0 <__swc_fn_7069e055_000144_c3e86ca0>:
  409cb0:	push   rbx
  409cb1:	sub    rsp,0xe0
  409cb8:	lea    rbx,[rsp+0x8]
  409cbd:	vxorps xmm0,xmm0,xmm0
  409cc1:	vmovups YMMWORD PTR [rbx],ymm0
  409cc5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  409cca:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  409ccf:	vzeroupper
  409cd2:	mov    DWORD PTR [rbx+0x60],0x0
  409cd9:	mov    r8,rbx
  409cdc:	nop    DWORD PTR [rax+0x0]
  409ce0:	mov    r9,rcx
  409ce3:	movabs rcx,0xcccccccccccccccd
  409ced:	mov    rax,r9
  409cf0:	mul    rcx
  409cf3:	mov    r10,rdx
  409cf6:	shr    r10,0x3
  409cfa:	mov    rcx,r10
  409cfd:	imul   rdx,r10,0xa
  409d01:	sub    r9,rdx
  409d04:	mov    rdx,QWORD PTR [rip+0x9835]        # 413540 <__swc_rdata_base_7069e055+0x430>
  409d0b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d10:	mov    BYTE PTR [r8],dl
  409d13:	lea    rdx,[r8+0x1]
  409d17:	mov    r8,rdx
  409d1a:	test   r10,r10
  409d1d:	jne    409ce0 <__swc_fn_7069e055_000144_c3e86ca0+0x30>
  409d1f:	mov    BYTE PTR [rdx],0x0
  409d22:	sub    r8,0x1
  409d26:	mov    rax,rbx
  409d29:	cmp    rax,r8
  409d2c:	jae    409d46 <__swc_fn_7069e055_000144_c3e86ca0+0x96>
  409d2e:	xchg   ax,ax
  409d30:	mov    cl,BYTE PTR [r8]
  409d33:	mov    dl,BYTE PTR [rax]
  409d35:	mov    BYTE PTR [r8],dl
  409d38:	sub    r8,0x1
  409d3c:	mov    BYTE PTR [rax],cl
  409d3e:	inc    rax
  409d41:	cmp    rax,r8
  409d44:	jb     409d30 <__swc_fn_7069e055_000144_c3e86ca0+0x80>
  409d46:	xor    eax,eax
  409d48:	test   rbx,rbx
  409d4b:	je     409d6e <__swc_fn_7069e055_000144_c3e86ca0+0xbe>
  409d4d:	mov    rcx,rbx
  409d50:	mov    dl,BYTE PTR [rcx]
  409d52:	test   dl,dl
  409d54:	je     409d6e <__swc_fn_7069e055_000144_c3e86ca0+0xbe>
  409d56:	cs nop WORD PTR [rax+rax*1+0x0]
  409d60:	add    rcx,0x1
  409d64:	add    rax,0x1
  409d68:	mov    dl,BYTE PTR [rcx]
  409d6a:	test   dl,dl
  409d6c:	jne    409d60 <__swc_fn_7069e055_000144_c3e86ca0+0xb0>
  409d6e:	mov    QWORD PTR [rbx+0xa8],rbx
  409d75:	mov    QWORD PTR [rbx+0xb0],rax
  409d7c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409d84:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409d8c:	lea    rcx,[rbx+0xb8]
  409d93:	call   410150 <__swc_fn_7069e055_000116_3f5cfdef>
  409d98:	add    rsp,0xe0
  409d9f:	pop    rbx
  409da0:	ret
	...

0000000000409db0 <__swc_fn_7069e055_000147_e7bfe29e>:
  409db0:	sub    rsp,0x8
  409db4:	mov    rax,QWORD PTR [rcx+0x8]
  409db8:	mov    r8,QWORD PTR [rdx+0x8]
  409dbc:	cmp    rax,r8
  409dbf:	je     409dc8 <__swc_fn_7069e055_000147_e7bfe29e+0x18>
  409dc1:	xor    eax,eax
  409dc3:	add    rsp,0x8
  409dc7:	ret
  409dc8:	test   rax,rax
  409dcb:	jne    409ddc <__swc_fn_7069e055_000147_e7bfe29e+0x2c>
  409dcd:	test   r8,r8
  409dd0:	jne    409ddc <__swc_fn_7069e055_000147_e7bfe29e+0x2c>
  409dd2:	mov    eax,0x1
  409dd7:	add    rsp,0x8
  409ddb:	ret
  409ddc:	mov    rcx,QWORD PTR [rcx]
  409ddf:	mov    rdx,QWORD PTR [rdx]
  409de2:	test   rcx,rcx
  409de5:	sete   r8b
  409de9:	test   rdx,rdx
  409dec:	sete   r9b
  409df0:	or     r8b,r9b
  409df3:	je     409e00 <__swc_fn_7069e055_000147_e7bfe29e+0x50>
  409df5:	cmp    rcx,rdx
  409df8:	sete   al
  409dfb:	add    rsp,0x8
  409dff:	ret
  409e00:	cmp    rcx,rdx
  409e03:	jne    409e0f <__swc_fn_7069e055_000147_e7bfe29e+0x5f>
  409e05:	mov    eax,0x1
  409e0a:	add    rsp,0x8
  409e0e:	ret
  409e0f:	mov    r8,rax
  409e12:	call   40c460 <__swc_fn_7069e055_000106_aba05410>
  409e17:	test   eax,eax
  409e19:	sete   al
  409e1c:	add    rsp,0x8
  409e20:	ret
	...

0000000000409e30 <__swc_fn_7069e055_000150_365b4daf>:
  409e30:	vxorps xmm0,xmm0,xmm0
  409e34:	vmovups XMMWORD PTR [rcx],xmm0
  409e38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e3d:	vxorps xmm0,xmm0,xmm0
  409e41:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e46:	vmovups xmm0,XMMWORD PTR [rip+0x97aa]        # 4135f8 <__swc_rdata_base_7069e055+0x4e8>
  409e4e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e53:	ret
	...

0000000000409e60 <__swc_fn_7069e055_000153_365b4daf>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x989a]        # 413718 <__swc_rdata_base_7069e055+0x608>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	mov    QWORD PTR [rcx+0x40],0x0
  409e8b:	ret
  409e8c:	add    BYTE PTR [rax],al
	...

0000000000409e90 <__swc_fn_7069e055_000156_9e2052d6>:
  409e90:	push   rbx
  409e91:	sub    rsp,0x70
  409e95:	mov    rax,QWORD PTR [rcx]
  409e98:	mov    rbx,QWORD PTR [rcx+0x8]
  409e9c:	vxorps xmm0,xmm0,xmm0
  409ea0:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  409ea6:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  409eac:	vzeroupper
  409eaf:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eb5:	mov    QWORD PTR [rsp+0x48],rdx
  409eba:	mov    QWORD PTR [rsp+0x50],r8
  409ebf:	mov    rcx,rax
  409ec2:	lea    rdx,[rsp+0x8]
  409ec7:	mov    rbx,QWORD PTR [rbx+0x18]
  409ecb:	call   rbx
  409ecd:	add    rsp,0x70
  409ed1:	pop    rbx
  409ed2:	ret
	...

0000000000409ee0 <__swc_fn_7069e055_000159_6861d596>:
  409ee0:	push   rbx
  409ee1:	push   rsi
  409ee2:	push   rdi
  409ee3:	mov    rbx,r8
  409ee6:	mov    rsi,rcx
  409ee9:	mov    rdi,rdx
  409eec:	call   40d170 <__swc_fn_7069e055_000157_3495a3ca>
  409ef1:	vmovups xmm0,XMMWORD PTR [rbx]
  409ef5:	vmovups XMMWORD PTR [rsi],xmm0
  409ef9:	mov    QWORD PTR [rsi+0x18],rdi
  409efd:	pop    rdi
  409efe:	pop    rsi
  409eff:	pop    rbx
  409f00:	ret
	...

0000000000409f10 <__swc_fn_7069e055_000162_61e293bf>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	push   r12
  409f15:	push   r13
  409f17:	sub    rsp,0x50
  409f1b:	mov    rbx,rcx
  409f1e:	mov    rsi,rdx
  409f21:	vmovups xmm0,XMMWORD PTR [rip+0x98ff]        # 413828 <__swc_rdata_base_7069e055+0x718>
  409f29:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f2f:	vmovups xmm0,XMMWORD PTR [rip+0x9901]        # 413838 <__swc_rdata_base_7069e055+0x728>
  409f37:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f3d:	vxorps xmm0,xmm0,xmm0
  409f41:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f47:	mov    rcx,rdx
  409f4a:	call   4098b0 <__swc_fn_7069e055_000138_22d6573c>
  409f4f:	mov    rdi,rax
  409f52:	test   rax,rax
  409f55:	jne    409f86 <__swc_fn_7069e055_000162_61e293bf+0x76>
  409f57:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f5d:	vmovups XMMWORD PTR [rbx],xmm0
  409f61:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f67:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f6c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409f72:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409f77:	mov    rax,rbx
  409f7a:	add    rsp,0x50
  409f7e:	pop    r13
  409f80:	pop    r12
  409f82:	pop    rdi
  409f83:	pop    rsi
  409f84:	pop    rbx
  409f85:	ret
  409f86:	mov    rcx,rdi
  409f89:	call   411c00 <__swc_fn_7069e055_000161_b553c03d>
  409f8e:	mov    r11,rax
  409f91:	test   rax,rax
  409f94:	je     409f9e <__swc_fn_7069e055_000162_61e293bf+0x8e>
  409f96:	mov    al,BYTE PTR [r11+0x24]
  409f9a:	test   al,al
  409f9c:	jne    409fcd <__swc_fn_7069e055_000162_61e293bf+0xbd>
  409f9e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fa4:	vmovups XMMWORD PTR [rbx],xmm0
  409fa8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fae:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fb3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fb9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fbe:	mov    rax,rbx
  409fc1:	add    rsp,0x50
  409fc5:	pop    r13
  409fc7:	pop    r12
  409fc9:	pop    rdi
  409fca:	pop    rsi
  409fcb:	pop    rbx
  409fcc:	ret
  409fcd:	sub    rsi,rdi
  409fd0:	mov    eax,0xffffffff
  409fd5:	cmp    rsi,rax
  409fd8:	jbe    40a009 <__swc_fn_7069e055_000162_61e293bf+0xf9>
  409fda:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fe0:	vmovups XMMWORD PTR [rbx],xmm0
  409fe4:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fea:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fef:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409ff5:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409ffa:	mov    rax,rbx
  409ffd:	add    rsp,0x50
  40a001:	pop    r13
  40a003:	pop    r12
  40a005:	pop    rdi
  40a006:	pop    rsi
  40a007:	pop    rbx
  40a008:	ret
  40a009:	mov    rdi,QWORD PTR [r11+0x10]
  40a00d:	mov    eax,DWORD PTR [r11+0x20]
  40a011:	xor    ecx,ecx
  40a013:	test   rax,rax
  40a016:	jbe    40a168 <__swc_fn_7069e055_000162_61e293bf+0x258>
  40a01c:	nop    DWORD PTR [rax+0x0]
  40a020:	mov    edx,ecx
  40a022:	imul   r12,rdx,0x14
  40a026:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a02b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a030:	mov    r9d,esi
  40a033:	cmp    r9,rdx
  40a036:	jb     40a15b <__swc_fn_7069e055_000162_61e293bf+0x24b>
  40a03c:	add    rdx,r8
  40a03f:	mov    r8d,esi
  40a042:	cmp    r8,rdx
  40a045:	jae    40a15b <__swc_fn_7069e055_000162_61e293bf+0x24b>
  40a04b:	lea    rsi,[rsp+0x38]
  40a050:	mov    eax,DWORD PTR [rdi+0xc]
  40a053:	mov    DWORD PTR [rsp+0x38],eax
  40a057:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a05c:	mov    rcx,rdi
  40a05f:	mov    rdx,QWORD PTR [r11+0x18]
  40a063:	mov    r8,rsi
  40a066:	mov    r8d,DWORD PTR [r8]
  40a069:	mov    r9,rax
  40a06c:	lea    r10,[rsp+0x10]
  40a071:	call   40d1c0 <__swc_fn_7069e055_000160_dfca9093>
  40a076:	test   al,al
  40a078:	jne    40a0ab <__swc_fn_7069e055_000162_61e293bf+0x19b>
  40a07a:	vmovups xmm0,XMMWORD PTR [rip+0x97d6]        # 413858 <__swc_rdata_base_7069e055+0x748>
  40a082:	vmovups XMMWORD PTR [rbx],xmm0
  40a086:	vmovups xmm0,XMMWORD PTR [rip+0x97da]        # 413868 <__swc_rdata_base_7069e055+0x758>
  40a08e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a093:	vxorps xmm0,xmm0,xmm0
  40a097:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a09c:	mov    rax,rbx
  40a09f:	add    rsp,0x50
  40a0a3:	pop    r13
  40a0a5:	pop    r12
  40a0a7:	pop    rdi
  40a0a8:	pop    rsi
  40a0a9:	pop    rbx
  40a0aa:	ret
  40a0ab:	lea    r13,[rsp+0x3c]
  40a0b0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0b5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0b9:	test   eax,eax
  40a0bb:	je     40a10c <__swc_fn_7069e055_000162_61e293bf+0x1fc>
  40a0bd:	mov    rcx,rdi
  40a0c0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0c4:	mov    r8d,DWORD PTR [rsi]
  40a0c7:	mov    rax,r13
  40a0ca:	mov    r9d,DWORD PTR [rax]
  40a0cd:	lea    r10,[rsp+0x20]
  40a0d2:	call   40d1c0 <__swc_fn_7069e055_000160_dfca9093>
  40a0d7:	test   al,al
  40a0d9:	jne    40a10c <__swc_fn_7069e055_000162_61e293bf+0x1fc>
  40a0db:	vmovups xmm0,XMMWORD PTR [rip+0x97a5]        # 413888 <__swc_rdata_base_7069e055+0x778>
  40a0e3:	vmovups XMMWORD PTR [rbx],xmm0
  40a0e7:	vmovups xmm0,XMMWORD PTR [rip+0x97a9]        # 413898 <__swc_rdata_base_7069e055+0x788>
  40a0ef:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0f4:	vxorps xmm0,xmm0,xmm0
  40a0f8:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0fd:	mov    rax,rbx
  40a100:	add    rsp,0x50
  40a104:	pop    r13
  40a106:	pop    r12
  40a108:	pop    rdi
  40a109:	pop    rsi
  40a10a:	pop    rbx
  40a10b:	ret
  40a10c:	mov    eax,0x1
  40a111:	rex mov BYTE PTR [rsp+0x8],al
  40a116:	cmp    DWORD PTR [r13+0x0],0x0
  40a11b:	je     40a12c <__swc_fn_7069e055_000162_61e293bf+0x21c>
  40a11d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a123:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a128:	mov    DWORD PTR [rsp+0x30],eax
  40a12c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a132:	vmovups XMMWORD PTR [rbx],xmm0
  40a136:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a13c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a141:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a147:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a14c:	mov    rax,rbx
  40a14f:	add    rsp,0x50
  40a153:	pop    r13
  40a155:	pop    r12
  40a157:	pop    rdi
  40a158:	pop    rsi
  40a159:	pop    rbx
  40a15a:	ret
  40a15b:	add    rcx,0x1
  40a15f:	cmp    rcx,rax
  40a162:	jb     40a020 <__swc_fn_7069e055_000162_61e293bf+0x110>
  40a168:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a16e:	vmovups XMMWORD PTR [rbx],xmm0
  40a172:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a178:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a17d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a183:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a188:	mov    rax,rbx
  40a18b:	add    rsp,0x50
  40a18f:	pop    r13
  40a191:	pop    r12
  40a193:	pop    rdi
  40a194:	pop    rsi
  40a195:	pop    rbx
  40a196:	ret
	...

000000000040a1a0 <__swc_fn_7069e055_000165_56054fe7>:
  40a1a0:	sub    rsp,0x48
  40a1a4:	call   409580 <__swc_fn_7069e055_000123_e4107ade>
  40a1a9:	cmp    rax,0xffffffffffffffff
  40a1ad:	je     40a1b4 <__swc_fn_7069e055_000165_56054fe7+0x14>
  40a1af:	add    rsp,0x48
  40a1b3:	ret
  40a1b4:	lea    rcx,[rip+0x970d]        # 4138c8 <__swc_rdata_base_7069e055+0x7b8>
  40a1bb:	vmovups xmm0,XMMWORD PTR [rip+0x9715]        # 4138d8 <__swc_rdata_base_7069e055+0x7c8>
  40a1c3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1c9:	vmovups xmm0,XMMWORD PTR [rip+0x9717]        # 4138e8 <__swc_rdata_base_7069e055+0x7d8>
  40a1d1:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a1d7:	vmovups xmm0,XMMWORD PTR [rip+0x9719]        # 4138f8 <__swc_rdata_base_7069e055+0x7e8>
  40a1df:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a1e5:	lea    rdx,[rsp+0x8]
  40a1ea:	mov    QWORD PTR [rsp+0x38],rax
  40a1ef:	call   40c3a0 <__swc_fn_7069e055_000103_0d4cc079>
  40a1f4:	mov    rax,QWORD PTR [rsp+0x38]
  40a1f9:	jmp    40a1af <__swc_fn_7069e055_000165_56054fe7+0xf>
  40a1fb:	add    BYTE PTR [rax],al
  40a1fd:	add    BYTE PTR [rax],al
	...

000000000040a200 <__swc_fn_7069e055_000168_0ad81c51>:
  40a200:	push   rbx
  40a201:	push   rsi
  40a202:	sub    rsp,0x28
  40a206:	mov    rbx,rcx
  40a209:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a211:	mov    ecx,0xbf0
  40a216:	call   40bf90 <__swc_fn_7069e055_000079_633af784>
  40a21b:	mov    rsi,rax
  40a21e:	test   rax,rax
  40a221:	jne    40a22c <__swc_fn_7069e055_000168_0ad81c51+0x2c>
  40a223:	xor    eax,eax
  40a225:	add    rsp,0x28
  40a229:	pop    rsi
  40a22a:	pop    rbx
  40a22b:	ret
  40a22c:	vxorps xmm0,xmm0,xmm0
  40a230:	xor    eax,eax
  40a232:	cs nop WORD PTR [rax+rax*1+0x0]
  40a23c:	nop    DWORD PTR [rax+0x0]
  40a240:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a245:	add    rax,0x10
  40a249:	cmp    rax,0xbf0
  40a250:	jne    40a240 <__swc_fn_7069e055_000168_0ad81c51+0x40>
  40a252:	lea    rax,[rbx+0x1]
  40a256:	mov    QWORD PTR [rsi+0x9c0],rax
  40a25d:	mov    rcx,rbx
  40a260:	mov    rdx,rsi
  40a263:	call   40d520 <__swc_fn_7069e055_000166_c370e18e>
  40a268:	test   al,al
  40a26a:	jne    40a27d <__swc_fn_7069e055_000168_0ad81c51+0x7d>
  40a26c:	mov    rcx,rsi
  40a26f:	call   40f0d0 <__swc_fn_7069e055_000080_207908fe>
  40a274:	xor    eax,eax
  40a276:	add    rsp,0x28
  40a27a:	pop    rsi
  40a27b:	pop    rbx
  40a27c:	ret
  40a27d:	lea    rcx,[rsp+0x18]
  40a282:	call   40f650 <__swc_fn_7069e055_000092_809deff5>
  40a287:	mov    rax,rsi
  40a28a:	add    rsp,0x28
  40a28e:	pop    rsi
  40a28f:	pop    rbx
  40a290:	ret
	...

000000000040a2a0 <__swc_fn_7069e055_000171_8c19aea5>:
  40a2a0:	xor    eax,eax
  40a2a2:	mov    edx,0x1
  40a2a7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2ac:	test   rax,rax
  40a2af:	jne    40a2b2 <__swc_fn_7069e055_000171_8c19aea5+0x12>
  40a2b1:	ret
  40a2b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2bc:	nop    DWORD PTR [rax+0x0]
  40a2c0:	mov    rax,QWORD PTR [rcx]
  40a2c3:	test   rax,rax
  40a2c6:	je     40a2a0 <__swc_fn_7069e055_000171_8c19aea5>
  40a2c8:	jmp    40a2c0 <__swc_fn_7069e055_000171_8c19aea5+0x20>
  40a2ca:	add    BYTE PTR [rax],al
  40a2cc:	add    BYTE PTR [rax],al
	...

000000000040a2d0 <__swc_fn_7069e055_000174_02e645b4>:
  40a2d0:	push   rsi
  40a2d1:	push   rdi
  40a2d2:	sub    rsp,0x38
  40a2d6:	mov    rsi,rcx
  40a2d9:	call   40d530 <__swc_fn_7069e055_000169_4694b8ad>
  40a2de:	mov    rdi,rax
  40a2e1:	call   40ccc0 <__swc_fn_7069e055_000130_375c7357>
  40a2e6:	mov    r8,rax
  40a2e9:	mov    rcx,rdi
  40a2ec:	call   40a2a0 <__swc_fn_7069e055_000171_8c19aea5>
  40a2f1:	mov    rax,QWORD PTR [rdi+0x8]
  40a2f5:	test   rax,rax
  40a2f8:	je     40a335 <__swc_fn_7069e055_000174_02e645b4+0x65>
  40a2fa:	nop    WORD PTR [rax+rax*1+0x0]
  40a300:	cmp    rax,rsi
  40a303:	je     40a335 <__swc_fn_7069e055_000174_02e645b4+0x65>
  40a305:	mov    r9,QWORD PTR [rax]
  40a308:	cmp    QWORD PTR [rax+0x20],r8
  40a30c:	jne    40a32d <__swc_fn_7069e055_000174_02e645b4+0x5d>
  40a30e:	mov    rcx,rdi
  40a311:	mov    rdx,rax
  40a314:	mov    QWORD PTR [rsp+0x28],r8
  40a319:	mov    QWORD PTR [rsp+0x30],r9
  40a31e:	call   412020 <__swc_fn_7069e055_000173_e17a224b>
  40a323:	mov    r8,QWORD PTR [rsp+0x28]
  40a328:	mov    r9,QWORD PTR [rsp+0x30]
  40a32d:	mov    rax,r9
  40a330:	test   r9,r9
  40a333:	jne    40a300 <__swc_fn_7069e055_000174_02e645b4+0x30>
  40a335:	xor    eax,eax
  40a337:	mov    QWORD PTR [rdi],rax
  40a33a:	add    rsp,0x38
  40a33e:	pop    rdi
  40a33f:	pop    rsi
  40a340:	ret
	...

000000000040a350 <__swc_fn_7069e055_000177_1ca87929>:
  40a350:	push   rdi
  40a351:	push   rsi
  40a352:	sub    rsp,0xb8
  40a359:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a35f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a365:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a36b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a371:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a377:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a37d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a383:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a38c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a395:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a39e:	vxorps xmm0,xmm0,xmm0
  40a3a2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a3a8:	mov    edi,0x1
  40a3ad:	lea    rsi,[rsp+0x8]
  40a3b2:	xor    eax,eax
  40a3b4:	call   4070e0 <clock_gettime@plt>
  40a3b9:	vxorpd xmm0,xmm0,xmm0
  40a3bd:	mov    rax,QWORD PTR [rsp+0x8]
  40a3c2:	vcvtsi2sd xmm0,xmm0,rax
  40a3c7:	vxorpd xmm1,xmm1,xmm1
  40a3cb:	mov    rax,QWORD PTR [rsp+0x10]
  40a3d0:	vcvtsi2sd xmm1,xmm1,rax
  40a3d5:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x952b]        # 413908 <__swc_rdata_base_7069e055+0x7f8>
  40a3dd:	vaddsd xmm0,xmm0,xmm1
  40a3e1:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a3e7:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a3ed:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a3f3:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a3f9:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a3ff:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a405:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a40b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a414:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a41d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a426:	add    rsp,0xb8
  40a42d:	pop    rsi
  40a42e:	pop    rdi
  40a42f:	ret
	...

000000000040a440 <__swc_fn_7069e055_000001_0e26756e>:
  40a440:	vxorps xmm0,xmm0,xmm0
  40a444:	xor    eax,eax
  40a446:	cs nop WORD PTR [rax+rax*1+0x0]
  40a450:	cs nop WORD PTR [rax+rax*1+0x0]
  40a45a:	nop    WORD PTR [rax+rax*1+0x0]
  40a460:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a465:	add    rax,0x10
  40a469:	cmp    rax,0x2080
  40a470:	jne    40a460 <__swc_fn_7069e055_000001_0e26756e+0x20>
  40a472:	ret
	...

000000000040a480 <__swc_fn_7069e055_000004_3deb8b54>:
  40a480:	push   rsi
  40a481:	push   rdi
  40a482:	push   r12
  40a484:	push   r13
  40a486:	push   r14
  40a488:	mov    rsi,rcx
  40a48b:	mov    edi,r10d
  40a48e:	mov    r12,rcx
  40a491:	mov    r13,r9
  40a494:	mov    ecx,DWORD PTR [rdx+0x28]
  40a497:	shlx   r14d,r8d,ecx
  40a49c:	mov    rcx,rdx
  40a49f:	mov    edx,r8d
  40a4a2:	call   40dfa0 <__swc_fn_7069e055_000011_71c91685>
  40a4a7:	mov    rcx,rax
  40a4aa:	mov    eax,DWORD PTR [r12+0x3c]
  40a4af:	xor    edx,edx
  40a4b1:	div    rdi
  40a4b4:	vxorps xmm0,xmm0,xmm0
  40a4b8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40a4bc:	mov    QWORD PTR [r12+0x60],0x0
  40a4c5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40a4ca:	mov    QWORD PTR [r12+0x10],rcx
  40a4cf:	imul   rax,rdi
  40a4d3:	lea    rdx,[rcx+rax*1]
  40a4d7:	mov    QWORD PTR [r12+0x18],rdx
  40a4dc:	mov    QWORD PTR [r12+0x20],rcx
  40a4e1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40a4e6:	mov    DWORD PTR [r12+0x28],0x0
  40a4ef:	mov    DWORD PTR [r12+0x68],0x0
  40a4f8:	mov    BYTE PTR [r12+0x39],r13b
  40a4fd:	mov    BYTE PTR [r12+0x3a],r14b
  40a502:	mov    BYTE PTR [r12+0x3b],0x1
  40a508:	mov    DWORD PTR [r12+0x6c],0x0
  40a511:	mov    rcx,r12
  40a514:	mov    edx,edi
  40a516:	call   40df00 <__swc_fn_7069e055_000005_6a556171>
  40a51b:	pop    r14
  40a51d:	pop    r13
  40a51f:	pop    r12
  40a521:	pop    rdi
  40a522:	pop    rsi
  40a523:	ret
	...

000000000040a530 <__swc_fn_7069e055_000007_a7bfb091>:
  40a530:	mov    r8d,0x1
  40a536:	xor    eax,eax
  40a538:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40a53e:	test   eax,eax
  40a540:	jne    40a530 <__swc_fn_7069e055_000007_a7bfb091>
  40a542:	ret
	...

000000000040a550 <__swc_fn_7069e055_000010_0569f799>:
  40a550:	lea    r8,[rcx+0x60]
  40a554:	mov    rax,QWORD PTR [r8]
  40a557:	mov    r9,rax
  40a55a:	nop    WORD PTR [rax+rax*1+0x0]
  40a560:	mov    QWORD PTR [rdx],r9
  40a563:	mov    rax,r9
  40a566:	lock cmpxchg QWORD PTR [r8],rdx
  40a56b:	cmp    rax,r9
  40a56e:	jne    40a5d7 <__swc_fn_7069e055_000010_0569f799+0x87>
  40a570:	mov    eax,DWORD PTR [rcx+0x6c]
  40a573:	test   eax,eax
  40a575:	je     40a5d6 <__swc_fn_7069e055_000010_0569f799+0x86>
  40a577:	lea    rdx,[rcx+0x70]
  40a57b:	mov    r9d,0x1
  40a581:	xor    eax,eax
  40a583:	lock cmpxchg DWORD PTR [rdx],r9d
  40a588:	test   eax,eax
  40a58a:	jne    40a5d6 <__swc_fn_7069e055_000010_0569f799+0x86>
  40a58c:	mov    rax,rcx
  40a58f:	and    rax,0xffffffffffc00000
  40a596:	mov    rax,QWORD PTR [rax+0x8]
  40a59a:	test   rax,rax
  40a59d:	jne    40a5a5 <__swc_fn_7069e055_000010_0569f799+0x55>
  40a59f:	xor    eax,eax
  40a5a1:	xchg   DWORD PTR [rdx],eax
  40a5a3:	jmp    40a5d6 <__swc_fn_7069e055_000010_0569f799+0x86>
  40a5a5:	lea    rdx,[rax+0x2a80]
  40a5ac:	mov    rax,QWORD PTR [rdx]
  40a5af:	mov    r8,rax
  40a5b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5bc:	nop    DWORD PTR [rax+0x0]
  40a5c0:	mov    QWORD PTR [rcx+0x78],r8
  40a5c4:	mov    rax,r8
  40a5c7:	lock cmpxchg QWORD PTR [rdx],rcx
  40a5cc:	cmp    rax,r8
  40a5cf:	je     40a5d6 <__swc_fn_7069e055_000010_0569f799+0x86>
  40a5d1:	mov    r8,rax
  40a5d4:	jmp    40a5c0 <__swc_fn_7069e055_000010_0569f799+0x70>
  40a5d6:	ret
  40a5d7:	mov    r9,rax
  40a5da:	jmp    40a560 <__swc_fn_7069e055_000010_0569f799+0x10>
	...

000000000040a5e0 <__swc_fn_7069e055_000013_7b85dbab>:
  40a5e0:	push   rsi
  40a5e1:	push   rdi
  40a5e2:	push   r12
  40a5e4:	push   r13
  40a5e6:	push   r14
  40a5e8:	push   r15
  40a5ea:	push   rbx
  40a5eb:	sub    rsp,0x30
  40a5ef:	mov    QWORD PTR [rsp+0x18],r8
  40a5f4:	mov    rsi,rcx
  40a5f7:	mov    rdi,rdx
  40a5fa:	mov    rdx,QWORD PTR [rsi+0x40]
  40a5fe:	xchg   ax,ax
  40a600:	mov    rax,rdx
  40a603:	not    rax
  40a606:	and    rax,QWORD PTR [rsi+0x20]
  40a60a:	test   rax,rax
  40a60d:	jne    40a621 <__swc_fn_7069e055_000013_7b85dbab+0x41>
  40a60f:	xor    eax,eax
  40a611:	add    rsp,0x30
  40a615:	pop    rbx
  40a616:	pop    r15
  40a618:	pop    r14
  40a61a:	pop    r13
  40a61c:	pop    r12
  40a61e:	pop    rdi
  40a61f:	pop    rsi
  40a620:	ret
  40a621:	xor    ecx,ecx
  40a623:	tzcnt  rcx,rax
  40a628:	lea    r12,[rsp+0x8]
  40a62d:	mov    DWORD PTR [rsp+0x8],ecx
  40a631:	mov    r13d,0x1
  40a637:	shl    r13,cl
  40a63a:	mov    rcx,rdx
  40a63d:	or     rcx,r13
  40a640:	mov    rax,rdx
  40a643:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40a649:	cmp    rax,rdx
  40a64c:	je     40a653 <__swc_fn_7069e055_000013_7b85dbab+0x73>
  40a64e:	mov    rdx,rax
  40a651:	jmp    40a600 <__swc_fn_7069e055_000013_7b85dbab+0x20>
  40a653:	mov    eax,DWORD PTR [r12]
  40a657:	shl    rax,0x4
  40a65b:	lea    r14,[rsi+rax*8+0x80]
  40a663:	mov    rcx,rsi
  40a666:	mov    rax,r12
  40a669:	mov    edx,DWORD PTR [rax]
  40a66b:	call   40dfa0 <__swc_fn_7069e055_000011_71c91685>
  40a670:	mov    r15,rax
  40a673:	mov    rcx,rsi
  40a676:	mov    rdx,r13
  40a679:	call   40e100 <__swc_fn_7069e055_000017_f003fc47>
  40a67e:	test   al,al
  40a680:	je     40a6b8 <__swc_fn_7069e055_000013_7b85dbab+0xd8>
  40a682:	mov    ecx,DWORD PTR [r14+0x3c]
  40a686:	lea    rdx,[rip+0x199cb]        # 424058 <__swc_bss_base_7069e055+0x18>
  40a68d:	mov    r8,QWORD PTR [rip+0x199c4]        # 424058 <__swc_bss_base_7069e055+0x18>
  40a694:	cs nop WORD PTR [rax+rax*1+0x0]
  40a69e:	xchg   ax,ax
  40a6a0:	mov    r9,r8
  40a6a3:	sub    r9,rcx
  40a6a6:	mov    rax,r8
  40a6a9:	lock cmpxchg QWORD PTR [rdx],r9
  40a6ae:	cmp    rax,r8
  40a6b1:	je     40a719 <__swc_fn_7069e055_000013_7b85dbab+0x139>
  40a6b3:	mov    r8,rax
  40a6b6:	jmp    40a6a0 <__swc_fn_7069e055_000013_7b85dbab+0xc0>
  40a6b8:	mov    rcx,rsi
  40a6bb:	mov    rax,r12
  40a6be:	mov    edx,DWORD PTR [rax]
  40a6c0:	call   407450 <__swc_fn_7069e055_000012_be38a1a2>
  40a6c5:	mov    rcx,r15
  40a6c8:	and    rcx,0xffffffffffff0000
  40a6cf:	lea    rcx,[rcx+0x10000]
  40a6d6:	mov    rbx,rax
  40a6d9:	cmp    rax,rcx
  40a6dc:	cmova  rbx,rcx
  40a6e0:	mov    rax,rbx
  40a6e3:	sub    rax,r15
  40a6e6:	mov    rcx,r15
  40a6e9:	mov    rdx,rax
  40a6ec:	call   4072a0 <__swc_fn_7069e055_000003_81215399>
  40a6f1:	test   al,al
  40a6f3:	jne    40a712 <__swc_fn_7069e055_000013_7b85dbab+0x132>
  40a6f5:	mov    rcx,rsi
  40a6f8:	mov    rdx,r13
  40a6fb:	call   407600 <__swc_fn_7069e055_000018_77ece227>
  40a700:	xor    eax,eax
  40a702:	add    rsp,0x30
  40a706:	pop    rbx
  40a707:	pop    r15
  40a709:	pop    r14
  40a70b:	pop    r13
  40a70d:	pop    r12
  40a70f:	pop    rdi
  40a710:	pop    rsi
  40a711:	ret
  40a712:	sub    rbx,r15
  40a715:	mov    DWORD PTR [r14+0x3c],ebx
  40a719:	mov    rcx,r14
  40a71c:	mov    rdx,rsi
  40a71f:	mov    r8d,DWORD PTR [r12]
  40a723:	mov    r9d,edi
  40a726:	mov    rbx,QWORD PTR [rsp+0x18]
  40a72b:	mov    r10d,ebx
  40a72e:	call   40a480 <__swc_fn_7069e055_000004_3deb8b54>
  40a733:	mov    rax,r14
  40a736:	add    rsp,0x30
  40a73a:	pop    rbx
  40a73b:	pop    r15
  40a73d:	pop    r14
  40a73f:	pop    r13
  40a741:	pop    r12
  40a743:	pop    rdi
  40a744:	pop    rsi
  40a745:	ret
	...

000000000040a750 <__swc_fn_7069e055_000016_a0b588d0>:
  40a750:	mov    r8,QWORD PTR [rcx+0x48]
  40a754:	cs nop WORD PTR [rax+rax*1+0x0]
  40a75e:	xchg   ax,ax
  40a760:	mov    r9,r8
  40a763:	or     r9,rdx
  40a766:	mov    rax,r8
  40a769:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40a76f:	cmp    rax,r8
  40a772:	jne    40a775 <__swc_fn_7069e055_000016_a0b588d0+0x25>
  40a774:	ret
  40a775:	mov    r8,rax
  40a778:	jmp    40a760 <__swc_fn_7069e055_000016_a0b588d0+0x10>
  40a77a:	add    BYTE PTR [rax],al
  40a77c:	add    BYTE PTR [rax],al
	...

000000000040a780 <__swc_fn_7069e055_000019_447bb610>:
  40a780:	push   rsi
  40a781:	push   rdi
  40a782:	push   r12
  40a784:	mov    rsi,rcx
  40a787:	xor    edi,edi
  40a789:	lea    r12,[rip+0x198d8]        # 424068 <__swc_bss_base_7069e055+0x28>
  40a790:	mov    eax,DWORD PTR [r12]
  40a794:	xor    ecx,ecx
  40a796:	test   rax,rax
  40a799:	jbe    40a7d4 <__swc_fn_7069e055_000019_447bb610+0x54>
  40a79b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a7a0:	lea    rdx,[rip+0x198c9]        # 424070 <__swc_bss_base_7069e055+0x30>
  40a7a7:	mov    r8d,ecx
  40a7aa:	lea    r8,[r8+r8*2]
  40a7ae:	lea    r8,[rdx+r8*8]
  40a7b2:	mov    rdx,QWORD PTR [r8+0x10]
  40a7b6:	add    rdx,0x400000
  40a7bd:	cmp    rdx,0x40000000
  40a7c4:	ja     40a7cb <__swc_fn_7069e055_000019_447bb610+0x4b>
  40a7c6:	mov    rdi,r8
  40a7c9:	jmp    40a7d4 <__swc_fn_7069e055_000019_447bb610+0x54>
  40a7cb:	add    rcx,0x1
  40a7cf:	cmp    rcx,rax
  40a7d2:	jb     40a7a0 <__swc_fn_7069e055_000019_447bb610+0x20>
  40a7d4:	test   rdi,rdi
  40a7d7:	jne    40a863 <__swc_fn_7069e055_000019_447bb610+0xe3>
  40a7dd:	cmp    DWORD PTR [r12],0x10
  40a7e2:	jae    40a84b <__swc_fn_7069e055_000019_447bb610+0xcb>
  40a7e4:	mov    ecx,0x40400000
  40a7e9:	call   40dec0 <__swc_fn_7069e055_000002_102336c4>
  40a7ee:	test   rax,rax
  40a7f1:	je     40a84b <__swc_fn_7069e055_000019_447bb610+0xcb>
  40a7f3:	lea    rcx,[rip+0x19876]        # 424070 <__swc_bss_base_7069e055+0x30>
  40a7fa:	mov    edx,DWORD PTR [r12]
  40a7fe:	lea    rdx,[rdx+rdx*2]
  40a802:	lea    rdx,[rcx+rdx*8]
  40a806:	mov    QWORD PTR [rdx],rax
  40a809:	lea    rax,[rax+0x3fffff]
  40a810:	and    rax,0xffffffffffc00000
  40a817:	mov    QWORD PTR [rdx+0x8],rax
  40a81b:	mov    QWORD PTR [rdx+0x10],0x0
  40a823:	mov    edx,DWORD PTR [rip+0x1983f]        # 424068 <__swc_bss_base_7069e055+0x28>
  40a829:	nop    DWORD PTR [rax+0x0]
  40a830:	lea    r9d,[rdx+0x1]
  40a834:	mov    rax,rdx
  40a837:	lock cmpxchg DWORD PTR [r12],r9d
  40a83d:	mov    r8d,eax
  40a840:	cmp    eax,edx
  40a842:	je     40a852 <__swc_fn_7069e055_000019_447bb610+0xd2>
  40a844:	mov    rdx,r8
  40a847:	jmp    40a830 <__swc_fn_7069e055_000019_447bb610+0xb0>
  40a849:	jmp    40a852 <__swc_fn_7069e055_000019_447bb610+0xd2>
  40a84b:	xor    eax,eax
  40a84d:	pop    r12
  40a84f:	pop    rdi
  40a850:	pop    rsi
  40a851:	ret
  40a852:	mov    eax,DWORD PTR [rip+0x19810]        # 424068 <__swc_bss_base_7069e055+0x28>
  40a858:	sub    eax,0x1
  40a85b:	lea    rdi,[rax+rax*2]
  40a85f:	lea    rdi,[rcx+rdi*8]
  40a863:	mov    r12,QWORD PTR [rdi+0x8]
  40a867:	add    r12,QWORD PTR [rdi+0x10]
  40a86b:	mov    rcx,r12
  40a86e:	mov    edx,0x3000
  40a873:	call   4072a0 <__swc_fn_7069e055_000003_81215399>
  40a878:	test   al,al
  40a87a:	jne    40a883 <__swc_fn_7069e055_000019_447bb610+0x103>
  40a87c:	xor    eax,eax
  40a87e:	pop    r12
  40a880:	pop    rdi
  40a881:	pop    rsi
  40a882:	ret
  40a883:	vxorps xmm0,xmm0,xmm0
  40a887:	xor    eax,eax
  40a889:	cs nop WORD PTR [rax+rax*1+0x0]
  40a893:	cs nop WORD PTR [rax+rax*1+0x0]
  40a89d:	nop    DWORD PTR [rax]
  40a8a0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40a8a6:	add    rax,0x10
  40a8aa:	cmp    rax,0x3000
  40a8b1:	jne    40a8a0 <__swc_fn_7069e055_000019_447bb610+0x120>
  40a8b3:	mov    DWORD PTR [r12+0x28],esi
  40a8b8:	mov    eax,0x40
  40a8bd:	mov    ecx,esi
  40a8bf:	shr    eax,cl
  40a8c1:	mov    DWORD PTR [r12+0x2c],eax
  40a8c6:	cmp    DWORD PTR [r12+0x2c],0x40
  40a8cc:	jb     40a8d7 <__swc_fn_7069e055_000019_447bb610+0x157>
  40a8ce:	mov    rax,0xffffffffffffffff
  40a8d5:	jmp    40a8e7 <__swc_fn_7069e055_000019_447bb610+0x167>
  40a8d7:	mov    eax,0x1
  40a8dc:	mov    ecx,DWORD PTR [r12+0x2c]
  40a8e1:	shl    rax,cl
  40a8e4:	dec    rax
  40a8e7:	mov    QWORD PTR [r12+0x20],rax
  40a8ec:	mov    DWORD PTR [r12],0x4e540001
  40a8f4:	mov    DWORD PTR [r12+0x4],0x53474d45
  40a8fd:	add    QWORD PTR [rdi+0x10],0x400000
  40a905:	mov    rax,r12
  40a908:	pop    r12
  40a90a:	pop    rdi
  40a90b:	pop    rsi
  40a90c:	ret
  40a90d:	add    BYTE PTR [rax],al
	...

000000000040a910 <__swc_fn_7069e055_000022_53fc00d2>:
  40a910:	mov    eax,0x1
  40a915:	mov    edx,DWORD PTR [rip+0x1974d]        # 424068 <__swc_bss_base_7069e055+0x28>
  40a91b:	cmp    eax,edx
  40a91d:	jae    40a96b <__swc_fn_7069e055_000022_53fc00d2+0x5b>
  40a91f:	nop
  40a920:	lea    r8,[rip+0x19749]        # 424070 <__swc_bss_base_7069e055+0x30>
  40a927:	lea    r9,[rax+rax*2]
  40a92b:	lea    r9,[r8+r9*8]
  40a92f:	mov    r8,rcx
  40a932:	sub    r8,QWORD PTR [r9+0x8]
  40a936:	mov    r9,QWORD PTR [r9+0x10]
  40a93a:	cmp    r8,r9
  40a93d:	jae    40a965 <__swc_fn_7069e055_000022_53fc00d2+0x55>
  40a93f:	mov    rax,rcx
  40a942:	and    rax,0xffffffffffc00000
  40a949:	shr    rcx,0x10
  40a94d:	and    ecx,0x3f
  40a950:	mov    edx,DWORD PTR [rax+0x28]
  40a953:	shrx   ecx,ecx,edx
  40a958:	shl    rcx,0x4
  40a95c:	lea    rax,[rax+rcx*8+0x80]
  40a964:	ret
  40a965:	inc    eax
  40a967:	cmp    eax,edx
  40a969:	jb     40a920 <__swc_fn_7069e055_000022_53fc00d2+0x10>
  40a96b:	xor    eax,eax
  40a96d:	ret
	...

000000000040a970 <__swc_fn_7069e055_000025_e876734d>:
  40a970:	vxorps xmm0,xmm0,xmm0
  40a974:	vmovups XMMWORD PTR [rcx],xmm0
  40a978:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a97d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a982:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a987:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a98c:	mov    QWORD PTR [rcx+0x50],0x0
  40a994:	ret
	...

000000000040a9a0 <__swc_fn_7069e055_000028_e876734d>:
  40a9a0:	vxorps xmm0,xmm0,xmm0
  40a9a4:	xor    eax,eax
  40a9a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9b0:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9ba:	nop    WORD PTR [rax+rax*1+0x0]
  40a9c0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a9c5:	add    rax,0x10
  40a9c9:	cmp    rax,0x9b0
  40a9d0:	jne    40a9c0 <__swc_fn_7069e055_000028_e876734d+0x20>
  40a9d2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40a9dd:	ret
	...

000000000040a9e0 <__swc_fn_7069e055_000031_3c3e930e>:
  40a9e0:	push   rsi
  40a9e1:	push   rdi
  40a9e2:	sub    rsp,0x8
  40a9e6:	lea    rsi,[rip+0x1761b]        # 422008 <__swc_data_base_7069e055+0x8>
  40a9ed:	mov    rax,QWORD PTR [rsi]
  40a9f0:	mov    ecx,0xffffffff
  40a9f5:	cmp    rax,rcx
  40a9f8:	je     40aa01 <__swc_fn_7069e055_000031_3c3e930e+0x21>
  40a9fa:	add    rsp,0x8
  40a9fe:	pop    rdi
  40a9ff:	pop    rsi
  40aa00:	ret
  40aa01:	mov    rcx,QWORD PTR [rip+0x8678]        # 413080 <__swc_fn_7069e055_000176_5d3d19bd+0xfe0>
  40aa08:	call   409650 <__swc_fn_7069e055_000126_9e9697c7>
  40aa0d:	mov    rcx,rax
  40aa10:	mov    eax,0xffffffff
  40aa15:	lock cmpxchg QWORD PTR [rsi],rcx
  40aa1a:	mov    rdi,rax
  40aa1d:	mov    eax,0xffffffff
  40aa22:	cmp    rdi,rax
  40aa25:	je     40aa36 <__swc_fn_7069e055_000031_3c3e930e+0x56>
  40aa27:	call   40cc10 <__swc_fn_7069e055_000127_f163135d>
  40aa2c:	mov    rax,rdi
  40aa2f:	add    rsp,0x8
  40aa33:	pop    rdi
  40aa34:	pop    rsi
  40aa35:	ret
  40aa36:	mov    rax,rcx
  40aa39:	add    rsp,0x8
  40aa3d:	pop    rdi
  40aa3e:	pop    rsi
  40aa3f:	ret

000000000040aa40 <__swc_fn_7069e055_000034_cf5ba7bd>:
  40aa40:	sub    rsp,0x8
  40aa44:	vxorps xmm0,xmm0,xmm0
  40aa48:	xor    eax,eax
  40aa4a:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa54:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa5e:	xchg   ax,ax
  40aa60:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40aa65:	add    rax,0x10
  40aa69:	cmp    rax,0x2b00
  40aa70:	jne    40aa60 <__swc_fn_7069e055_000034_cf5ba7bd+0x20>
  40aa72:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40aa7c:	xor    al,al
  40aa7e:	mov    rdx,rax
  40aa81:	xor    al,al
  40aa83:	mov    r8,rax
  40aa86:	xor    al,al
  40aa88:	mov    r9,rax
  40aa8b:	xor    al,al
  40aa8d:	mov    r10,rax
  40aa90:	xor    al,al
  40aa92:	mov    r11,rax
  40aa95:	call   40e330 <__swc_fn_7069e055_000035_ab2e8c35>
  40aa9a:	add    rsp,0x8
  40aa9e:	ret
	...

000000000040aaa0 <__swc_fn_7069e055_000037_1e381f55>:
  40aaa0:	push   rsi
  40aaa1:	push   rdi
  40aaa2:	push   r12
  40aaa4:	mov    rsi,r8
  40aaa7:	mov    rdi,rdx
  40aaaa:	mov    rcx,rdx
  40aaad:	call   40dec0 <__swc_fn_7069e055_000002_102336c4>
  40aab2:	mov    r12,rax
  40aab5:	test   rax,rax
  40aab8:	jne    40aac1 <__swc_fn_7069e055_000037_1e381f55+0x21>
  40aaba:	xor    eax,eax
  40aabc:	pop    r12
  40aabe:	pop    rdi
  40aabf:	pop    rsi
  40aac0:	ret
  40aac1:	mov    rcx,r12
  40aac4:	mov    rdx,rsi
  40aac7:	call   4072a0 <__swc_fn_7069e055_000003_81215399>
  40aacc:	test   al,al
  40aace:	jne    40aae2 <__swc_fn_7069e055_000037_1e381f55+0x42>
  40aad0:	mov    rcx,r12
  40aad3:	mov    rdx,rdi
  40aad6:	call   410130 <__swc_fn_7069e055_000113_4e83a03a>
  40aadb:	xor    eax,eax
  40aadd:	pop    r12
  40aadf:	pop    rdi
  40aae0:	pop    rsi
  40aae1:	ret
  40aae2:	mov    rax,r12
  40aae5:	pop    r12
  40aae7:	pop    rdi
  40aae8:	pop    rsi
  40aae9:	ret
	...

000000000040ab00 <__swc_fn_7069e055_000040_8029566e>:
  40ab00:	push   rsi
  40ab01:	push   rdi
  40ab02:	push   r12
  40ab04:	mov    rsi,rcx
  40ab07:	mov    edx,0x9b8
  40ab0c:	call   40e3a0 <__swc_fn_7069e055_000038_292d55e5>
  40ab11:	mov    rdi,rax
  40ab14:	test   rax,rax
  40ab17:	jne    40ab20 <__swc_fn_7069e055_000040_8029566e+0x20>
  40ab19:	xor    eax,eax
  40ab1b:	pop    r12
  40ab1d:	pop    rdi
  40ab1e:	pop    rsi
  40ab1f:	ret
  40ab20:	vxorps xmm0,xmm0,xmm0
  40ab24:	xor    eax,eax
  40ab26:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab30:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ab40:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40ab45:	add    rax,0x10
  40ab49:	cmp    rax,0x9b0
  40ab50:	jne    40ab40 <__swc_fn_7069e055_000040_8029566e+0x40>
  40ab52:	mov    QWORD PTR [rdi+0x9b0],0x0
  40ab5d:	mov    QWORD PTR [rdi],rsi
  40ab60:	call   40ccc0 <__swc_fn_7069e055_000130_375c7357>
  40ab65:	mov    QWORD PTR [rdi+0x18],rax
  40ab69:	lea    r12,[rsi+0x10]
  40ab6d:	mov    rcx,r12
  40ab70:	call   4098a0 <__swc_fn_7069e055_000135_db32cc57>
  40ab75:	mov    rax,QWORD PTR [rsi+0x20]
  40ab79:	mov    QWORD PTR [rdi+0x8],rax
  40ab7d:	mov    rax,QWORD PTR [rsi+0x20]
  40ab81:	test   rax,rax
  40ab84:	je     40ab8a <__swc_fn_7069e055_000040_8029566e+0x8a>
  40ab86:	mov    QWORD PTR [rax+0x10],rdi
  40ab8a:	mov    QWORD PTR [rsi+0x20],rdi
  40ab8e:	mov    rcx,r12
  40ab91:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  40ab96:	mov    rax,rdi
  40ab99:	pop    r12
  40ab9b:	pop    rdi
  40ab9c:	pop    rsi
  40ab9d:	ret
	...

000000000040aba0 <__swc_fn_7069e055_000043_47ff6d9b>:
  40aba0:	mov    rax,QWORD PTR [rdx+0x10]
  40aba4:	test   rax,rax
  40aba7:	je     40abb3 <__swc_fn_7069e055_000043_47ff6d9b+0x13>
  40aba9:	mov    rcx,QWORD PTR [rdx+0x8]
  40abad:	mov    QWORD PTR [rax+0x8],rcx
  40abb1:	jmp    40abbb <__swc_fn_7069e055_000043_47ff6d9b+0x1b>
  40abb3:	mov    rax,QWORD PTR [rdx+0x8]
  40abb7:	mov    QWORD PTR [rcx+0x20],rax
  40abbb:	mov    rax,QWORD PTR [rdx+0x8]
  40abbf:	test   rax,rax
  40abc2:	je     40abcc <__swc_fn_7069e055_000043_47ff6d9b+0x2c>
  40abc4:	mov    rcx,QWORD PTR [rdx+0x10]
  40abc8:	mov    QWORD PTR [rax+0x10],rcx
  40abcc:	vxorps xmm0,xmm0,xmm0
  40abd0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40abd5:	ret
	...

000000000040abe0 <__swc_fn_7069e055_000046_b28a6ee7>:
  40abe0:	sub    rsp,0x8
  40abe4:	mov    r9,r8
  40abe7:	mov    r10,rdx
  40abea:	call   40e450 <__swc_fn_7069e055_000044_fe6bbfdb>
  40abef:	mov    eax,0x1
  40abf4:	xchg   DWORD PTR [r9+0x6c],eax
  40abf8:	mov    rax,QWORD PTR [r9+0x60]
  40abfc:	test   rax,rax
  40abff:	je     40ac43 <__swc_fn_7069e055_000046_b28a6ee7+0x63>
  40ac01:	xor    eax,eax
  40ac03:	xchg   DWORD PTR [r9+0x6c],eax
  40ac07:	movzx  eax,BYTE PTR [r9+0x39]
  40ac0c:	lea    rax,[rax+rax*4]
  40ac10:	lea    rax,[r10+rax*8+0x28]
  40ac15:	mov    QWORD PTR [r9+0x50],0x0
  40ac1d:	mov    rcx,QWORD PTR [rax+0x8]
  40ac21:	mov    QWORD PTR [r9+0x48],rcx
  40ac25:	mov    rcx,QWORD PTR [rax+0x8]
  40ac29:	test   rcx,rcx
  40ac2c:	je     40ac34 <__swc_fn_7069e055_000046_b28a6ee7+0x54>
  40ac2e:	mov    QWORD PTR [rcx+0x50],r9
  40ac32:	jmp    40ac38 <__swc_fn_7069e055_000046_b28a6ee7+0x58>
  40ac34:	mov    QWORD PTR [rax+0x10],r9
  40ac38:	mov    QWORD PTR [rax+0x8],r9
  40ac3c:	xor    eax,eax
  40ac3e:	add    rsp,0x8
  40ac42:	ret
  40ac43:	movzx  eax,BYTE PTR [r9+0x39]
  40ac48:	lea    rax,[rax+rax*4]
  40ac4c:	lea    rax,[r10+rax*8+0x28]
  40ac51:	mov    QWORD PTR [r9+0x50],0x0
  40ac59:	mov    rcx,QWORD PTR [rax+0x18]
  40ac5d:	mov    QWORD PTR [r9+0x48],rcx
  40ac61:	mov    rcx,QWORD PTR [rax+0x18]
  40ac65:	test   rcx,rcx
  40ac68:	je     40ac6e <__swc_fn_7069e055_000046_b28a6ee7+0x8e>
  40ac6a:	mov    QWORD PTR [rcx+0x50],r9
  40ac6e:	mov    QWORD PTR [rax+0x18],r9
  40ac72:	mov    eax,0x1
  40ac77:	add    rsp,0x8
  40ac7b:	ret
  40ac7c:	add    BYTE PTR [rax],al
	...

000000000040ac80 <__swc_fn_7069e055_000049_f6a485a2>:
  40ac80:	push   r12
  40ac82:	push   r13
  40ac84:	push   rdi
  40ac85:	push   rsi
  40ac86:	push   r14
  40ac88:	push   r15
  40ac8a:	sub    rsp,0x178
  40ac91:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40ac9a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40aca3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40acac:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40acb5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40acbe:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40acc7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40acd0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40acd9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40ace2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40aceb:	mov    r12,rcx
  40acee:	lea    rax,[rip+0x1950b]        # 424200 <__swc_bss_base_7069e055+0x1c0>
  40acf5:	mov    rcx,QWORD PTR [rax]
  40acf8:	mov    r13,rcx
  40acfb:	test   rcx,rcx
  40acfe:	jne    40ad0e <__swc_fn_7069e055_000049_f6a485a2+0x8e>
  40ad00:	mov    r13d,0x1dcd6500
  40ad06:	mov    ecx,0x1dcd6500
  40ad0b:	xchg   QWORD PTR [rax],rcx
  40ad0e:	lea    rax,[rip+0x172eb]        # 422000 <__swc_data_base_7069e055>
  40ad15:	mov    rax,QWORD PTR [rax]
  40ad18:	cmp    rax,0xffffffffffffffff
  40ad1c:	je     40ad2b <__swc_fn_7069e055_000049_f6a485a2+0xab>
  40ad1e:	mov    eax,eax
  40ad20:	mov    edi,eax
  40ad22:	xor    eax,eax
  40ad24:	call   407000 <pthread_getspecific@plt>
  40ad29:	jmp    40ad2d <__swc_fn_7069e055_000049_f6a485a2+0xad>
  40ad2b:	xor    eax,eax
  40ad2d:	test   rax,rax
  40ad30:	jne    40ad3f <__swc_fn_7069e055_000049_f6a485a2+0xbf>
  40ad32:	call   40a9e0 <__swc_fn_7069e055_000031_3c3e930e>
  40ad37:	mov    rcx,rax
  40ad3a:	call   410480 <__swc_fn_7069e055_000128_8d8a7dd2>
  40ad3f:	test   rax,rax
  40ad42:	je     40ad54 <__swc_fn_7069e055_000049_f6a485a2+0xd4>
  40ad44:	cmp    QWORD PTR [rax],r12
  40ad47:	jne    40ad54 <__swc_fn_7069e055_000049_f6a485a2+0xd4>
  40ad49:	cmp    DWORD PTR [rax+0x20],0x0
  40ad4d:	jne    40ad54 <__swc_fn_7069e055_000049_f6a485a2+0xd4>
  40ad4f:	mov    rsi,rax
  40ad52:	jmp    40ad56 <__swc_fn_7069e055_000049_f6a485a2+0xd6>
  40ad54:	xor    esi,esi
  40ad56:	lea    rdi,[r12+0x2a88]
  40ad5e:	mov    r14,QWORD PTR [rdi]
  40ad61:	test   r14,r14
  40ad64:	jne    40adb3 <__swc_fn_7069e055_000049_f6a485a2+0x133>
  40ad66:	lea    rax,[rip+0x192eb]        # 424058 <__swc_bss_base_7069e055+0x18>
  40ad6d:	mov    rax,QWORD PTR [rax]
  40ad70:	test   rax,rax
  40ad73:	setne  al
  40ad76:	jne    40ad9a <__swc_fn_7069e055_000049_f6a485a2+0x11a>
  40ad78:	mov    rax,QWORD PTR [r12+0x2a70]
  40ad80:	test   rax,rax
  40ad83:	setne  al
  40ad86:	jne    40ad9a <__swc_fn_7069e055_000049_f6a485a2+0x11a>
  40ad88:	test   rsi,rsi
  40ad8b:	setne  al
  40ad8e:	je     40ad9a <__swc_fn_7069e055_000049_f6a485a2+0x11a>
  40ad90:	cmp    DWORD PTR [rsi+0x730],0x0
  40ad97:	setne  al
  40ad9a:	test   al,al
  40ad9c:	je     40adae <__swc_fn_7069e055_000049_f6a485a2+0x12e>
  40ad9e:	call   410530 <__swc_fn_7069e055_000131_91db8856>
  40ada3:	lea    rcx,[rax+r13*1]
  40ada7:	xor    eax,eax
  40ada9:	lock cmpxchg QWORD PTR [rdi],rcx
  40adae:	jmp    40aeb3 <__swc_fn_7069e055_000049_f6a485a2+0x233>
  40adb3:	call   410530 <__swc_fn_7069e055_000131_91db8856>
  40adb8:	mov    r15,rax
  40adbb:	cmp    rax,r14
  40adbe:	jb     40adcf <__swc_fn_7069e055_000049_f6a485a2+0x14f>
  40adc0:	xor    ecx,ecx
  40adc2:	mov    rax,r14
  40adc5:	lock cmpxchg QWORD PTR [rdi],rcx
  40adca:	cmp    rax,r14
  40adcd:	je     40add4 <__swc_fn_7069e055_000049_f6a485a2+0x154>
  40adcf:	jmp    40aeb3 <__swc_fn_7069e055_000049_f6a485a2+0x233>
  40add4:	test   rsi,rsi
  40add7:	je     40adf2 <__swc_fn_7069e055_000049_f6a485a2+0x172>
  40add9:	cmp    r15,r13
  40addc:	jb     40adf2 <__swc_fn_7069e055_000049_f6a485a2+0x172>
  40adde:	mov    rax,r15
  40ade1:	sub    rax,r13
  40ade4:	mov    rcx,r12
  40ade7:	mov    rdx,rsi
  40adea:	mov    r8,rax
  40aded:	call   40e890 <__swc_fn_7069e055_000059_ee6a254c>
  40adf2:	lea    rsi,[r12+0x10]
  40adf7:	mov    rcx,rsi
  40adfa:	call   4098a0 <__swc_fn_7069e055_000135_db32cc57>
  40adff:	mov    rax,QWORD PTR [r12+0x18]
  40ae04:	mov    rdi,rax
  40ae07:	test   rdi,rdi
  40ae0a:	je     40ae34 <__swc_fn_7069e055_000049_f6a485a2+0x1b4>
  40ae0c:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae16:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae20:	mov    rcx,rdi
  40ae23:	call   407470 <__swc_fn_7069e055_000015_96cb1311>
  40ae28:	mov    rax,QWORD PTR [rdi+0x10]
  40ae2c:	mov    rdi,rax
  40ae2f:	test   rax,rax
  40ae32:	jne    40ae20 <__swc_fn_7069e055_000049_f6a485a2+0x1a0>
  40ae34:	mov    rcx,rsi
  40ae37:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  40ae3c:	mov    rcx,r12
  40ae3f:	call   4098a0 <__swc_fn_7069e055_000135_db32cc57>
  40ae44:	xor    esi,esi
  40ae46:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae50:	mov    rax,QWORD PTR [r12+0x2a70]
  40ae58:	cmp    rsi,rax
  40ae5b:	jae    40aeab <__swc_fn_7069e055_000049_f6a485a2+0x22b>
  40ae5d:	lea    rax,[rsi+rsi*4]
  40ae61:	lea    rax,[r12+rax*8+0x268]
  40ae69:	mov    r8,QWORD PTR [rax]
  40ae6c:	mov    r9,QWORD PTR [rax+0x8]
  40ae70:	mov    r10,QWORD PTR [rax+0x10]
  40ae74:	mov    rax,QWORD PTR [rax+0x20]
  40ae78:	cmp    rax,r15
  40ae7b:	jae    40ae88 <__swc_fn_7069e055_000049_f6a485a2+0x208>
  40ae7d:	mov    rcx,r15
  40ae80:	sub    rcx,rax
  40ae83:	cmp    rcx,r13
  40ae86:	jae    40ae8d <__swc_fn_7069e055_000049_f6a485a2+0x20d>
  40ae88:	inc    rsi
  40ae8b:	jmp    40ae50 <__swc_fn_7069e055_000049_f6a485a2+0x1d0>
  40ae8d:	mov    rcx,r12
  40ae90:	mov    rdx,rsi
  40ae93:	call   40e840 <__swc_fn_7069e055_000056_87dc216f>
  40ae98:	mov    rcx,r12
  40ae9b:	mov    rdx,r8
  40ae9e:	mov    r8,r9
  40aea1:	mov    r9,r10
  40aea4:	call   407750 <__swc_fn_7069e055_000039_9ae4348f>
  40aea9:	jmp    40ae50 <__swc_fn_7069e055_000049_f6a485a2+0x1d0>
  40aeab:	mov    rcx,r12
  40aeae:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  40aeb3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40aebc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40aec5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40aece:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40aed7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40aee0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40aee9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40aef2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40aefb:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40af04:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40af0d:	add    rsp,0x178
  40af14:	pop    r15
  40af16:	pop    r14
  40af18:	pop    rsi
  40af19:	pop    rdi
  40af1a:	pop    r13
  40af1c:	pop    r12
  40af1e:	ret
	...

000000000040af20 <__swc_fn_7069e055_000052_92b016ae>:
  40af20:	lea    rax,[rdx-0x58]
  40af24:	ret
	...

000000000040af30 <__swc_fn_7069e055_000055_ddf32775>:
  40af30:	push   rsi
  40af31:	push   rdi
  40af32:	push   r12
  40af34:	push   r13
  40af36:	sub    rsp,0x68
  40af3a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40af40:	mov    rsi,r9
  40af43:	mov    rdi,rcx
  40af46:	mov    r12,rdx
  40af49:	mov    r13,r8
  40af4c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40af54:	jne    40af63 <__swc_fn_7069e055_000055_ddf32775+0x33>
  40af56:	xor    eax,eax
  40af58:	add    rsp,0x68
  40af5c:	pop    r13
  40af5e:	pop    r12
  40af60:	pop    rdi
  40af61:	pop    rsi
  40af62:	ret
  40af63:	mov    rcx,rdi
  40af66:	call   4098a0 <__swc_fn_7069e055_000135_db32cc57>
  40af6b:	movabs rax,0x7fffffffffffffff
  40af75:	cmp    r12,rax
  40af78:	mov    rax,0xffffffffffffffff
  40af7f:	lea    rcx,[r12+r12*1]
  40af83:	cmovbe rax,rcx
  40af87:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40af8e:	mov    rdx,rcx
  40af91:	sub    rax,r12
  40af94:	inc    rax
  40af97:	xor    r8d,r8d
  40af9a:	test   rcx,rcx
  40af9d:	jbe    40afc8 <__swc_fn_7069e055_000055_ddf32775+0x98>
  40af9f:	nop
  40afa0:	lea    r9,[r8+r8*4]
  40afa4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40afac:	sub    r9,r12
  40afaf:	cmp    r9,rax
  40afb2:	jae    40afbf <__swc_fn_7069e055_000055_ddf32775+0x8f>
  40afb4:	mov    rdx,r8
  40afb7:	mov    rax,r9
  40afba:	test   r9,r9
  40afbd:	je     40afc8 <__swc_fn_7069e055_000055_ddf32775+0x98>
  40afbf:	add    r8,0x1
  40afc3:	cmp    r8,rcx
  40afc6:	jb     40afa0 <__swc_fn_7069e055_000055_ddf32775+0x70>
  40afc8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40afcf:	cmp    rdx,rax
  40afd2:	jne    40afef <__swc_fn_7069e055_000055_ddf32775+0xbf>
  40afd4:	mov    rcx,rdi
  40afd7:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  40afdc:	xor    eax,eax
  40afde:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40afe4:	add    rsp,0x68
  40afe8:	pop    r13
  40afea:	pop    r12
  40afec:	pop    rdi
  40afed:	pop    rsi
  40afee:	ret
  40afef:	lea    rax,[rdx+rdx*4]
  40aff3:	lea    rax,[rdi+rax*8+0x268]
  40affb:	vmovups xmm6,XMMWORD PTR [rax]
  40afff:	mov    r8,QWORD PTR [rax+0x10]
  40b003:	mov    rcx,rdi
  40b006:	call   40e840 <__swc_fn_7069e055_000056_87dc216f>
  40b00b:	vpshufd xmm0,xmm6,0xee
  40b010:	vmovsd QWORD PTR [r13+0x0],xmm0
  40b016:	mov    QWORD PTR [rsi],r8
  40b019:	mov    rcx,rdi
  40b01c:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  40b021:	vmovq  rax,xmm6
  40b026:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b02c:	add    rsp,0x68
  40b030:	pop    r13
  40b032:	pop    r12
  40b034:	pop    rdi
  40b035:	pop    rsi
  40b036:	ret
	...

000000000040b040 <__swc_fn_7069e055_000058_01964a17>:
  40b040:	push   r12
  40b042:	push   r13
  40b044:	push   r14
  40b046:	push   r15
  40b048:	push   rdi
  40b049:	push   rsi
  40b04a:	sub    rsp,0x148
  40b051:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b05a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b063:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b06c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b075:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b07e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b087:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b090:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b099:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b0a2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b0ab:	mov    r12,r9
  40b0ae:	mov    r13,rcx
  40b0b1:	mov    r14,rdx
  40b0b4:	mov    r15,r8
  40b0b7:	test   rdx,rdx
  40b0ba:	jne    40b0ce <__swc_fn_7069e055_000058_01964a17+0x8e>
  40b0bc:	add    rsp,0x148
  40b0c3:	pop    rsi
  40b0c4:	pop    rdi
  40b0c5:	pop    r15
  40b0c7:	pop    r14
  40b0c9:	pop    r13
  40b0cb:	pop    r12
  40b0cd:	ret
  40b0ce:	cmp    r12,0x200000
  40b0d5:	ja     40b167 <__swc_fn_7069e055_000058_01964a17+0x127>
  40b0db:	lea    rax,[rip+0x16f1e]        # 422000 <__swc_data_base_7069e055>
  40b0e2:	mov    rax,QWORD PTR [rax]
  40b0e5:	cmp    rax,0xffffffffffffffff
  40b0e9:	je     40b0f8 <__swc_fn_7069e055_000058_01964a17+0xb8>
  40b0eb:	mov    eax,eax
  40b0ed:	mov    edi,eax
  40b0ef:	xor    eax,eax
  40b0f1:	call   407000 <pthread_getspecific@plt>
  40b0f6:	jmp    40b0fa <__swc_fn_7069e055_000058_01964a17+0xba>
  40b0f8:	xor    eax,eax
  40b0fa:	test   rax,rax
  40b0fd:	je     40b104 <__swc_fn_7069e055_000058_01964a17+0xc4>
  40b0ff:	mov    rsi,rax
  40b102:	jmp    40b114 <__swc_fn_7069e055_000058_01964a17+0xd4>
  40b104:	call   40a9e0 <__swc_fn_7069e055_000031_3c3e930e>
  40b109:	mov    rcx,rax
  40b10c:	call   410480 <__swc_fn_7069e055_000128_8d8a7dd2>
  40b111:	mov    rsi,rax
  40b114:	test   rsi,rsi
  40b117:	je     40b167 <__swc_fn_7069e055_000058_01964a17+0x127>
  40b119:	cmp    QWORD PTR [rsi],r13
  40b11c:	jne    40b167 <__swc_fn_7069e055_000058_01964a17+0x127>
  40b11e:	cmp    DWORD PTR [rsi+0x20],0x0
  40b122:	jne    40b167 <__swc_fn_7069e055_000058_01964a17+0x127>
  40b124:	cmp    DWORD PTR [rsi+0x730],0x10
  40b12b:	jae    40b167 <__swc_fn_7069e055_000058_01964a17+0x127>
  40b12d:	mov    eax,DWORD PTR [rsi+0x730]
  40b133:	lea    rdi,[rax+rax*4]
  40b137:	lea    rdi,[rsi+rdi*8+0x738]
  40b13f:	mov    QWORD PTR [rdi],r14
  40b142:	mov    QWORD PTR [rdi+0x8],r15
  40b146:	mov    QWORD PTR [rdi+0x10],r12
  40b14a:	mov    QWORD PTR [rdi+0x18],0x0
  40b152:	call   410530 <__swc_fn_7069e055_000131_91db8856>
  40b157:	mov    QWORD PTR [rdi+0x20],rax
  40b15b:	add    DWORD PTR [rsi+0x730],0x1
  40b162:	jmp    40b2c6 <__swc_fn_7069e055_000058_01964a17+0x286>
  40b167:	mov    rcx,r13
  40b16a:	call   407e90 <__swc_fn_7069e055_000057_01c75a1d>
  40b16f:	mov    rsi,rax
  40b172:	cmp    r12,rax
  40b175:	jbe    40b1aa <__swc_fn_7069e055_000058_01964a17+0x16a>
  40b177:	cmp    r12,0x10000000
  40b17e:	seta   al
  40b181:	ja     40b190 <__swc_fn_7069e055_000058_01964a17+0x150>
  40b183:	mov    rax,QWORD PTR [r13+0x2a70]
  40b18a:	test   rax,rax
  40b18d:	setne  al
  40b190:	test   al,al
  40b192:	je     40b1aa <__swc_fn_7069e055_000058_01964a17+0x16a>
  40b194:	mov    rcx,r13
  40b197:	mov    rdx,r14
  40b19a:	mov    r8,r15
  40b19d:	mov    r9,r12
  40b1a0:	call   407750 <__swc_fn_7069e055_000039_9ae4348f>
  40b1a5:	jmp    40b2c6 <__swc_fn_7069e055_000058_01964a17+0x286>
  40b1aa:	call   410530 <__swc_fn_7069e055_000131_91db8856>
  40b1af:	mov    rdi,rax
  40b1b2:	mov    rcx,r13
  40b1b5:	call   4098a0 <__swc_fn_7069e055_000135_db32cc57>
  40b1ba:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b1c2:	je     40b27a <__swc_fn_7069e055_000058_01964a17+0x23a>
  40b1c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b1d0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b1db:	jae    40b1f0 <__swc_fn_7069e055_000058_01964a17+0x1b0>
  40b1dd:	mov    rax,QWORD PTR [r13+0x2a68]
  40b1e4:	add    rax,r12
  40b1e7:	cmp    rax,rsi
  40b1ea:	jbe    40b27a <__swc_fn_7069e055_000058_01964a17+0x23a>
  40b1f0:	xor    eax,eax
  40b1f2:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b1f9:	mov    edx,0x1
  40b1fe:	cmp    rcx,0x1
  40b202:	jbe    40b239 <__swc_fn_7069e055_000058_01964a17+0x1f9>
  40b204:	cs nop WORD PTR [rax+rax*1+0x0]
  40b20e:	xchg   ax,ax
  40b210:	lea    r8,[rdx+rdx*4]
  40b214:	lea    r8,[r13+r8*8+0x268]
  40b21c:	lea    r9,[rax+rax*4]
  40b220:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b228:	cmp    QWORD PTR [r8+0x18],r9
  40b22c:	cmovb  rax,rdx
  40b230:	add    rdx,0x1
  40b234:	cmp    rdx,rcx
  40b237:	jb     40b210 <__swc_fn_7069e055_000058_01964a17+0x1d0>
  40b239:	lea    rcx,[rax+rax*4]
  40b23d:	lea    rcx,[r13+rcx*8+0x268]
  40b245:	mov    r8,QWORD PTR [rcx]
  40b248:	mov    r9,QWORD PTR [rcx+0x8]
  40b24c:	mov    r10,QWORD PTR [rcx+0x10]
  40b250:	mov    rcx,r13
  40b253:	mov    rdx,rax
  40b256:	call   40e840 <__swc_fn_7069e055_000056_87dc216f>
  40b25b:	mov    rcx,r13
  40b25e:	mov    rdx,r8
  40b261:	mov    r8,r9
  40b264:	mov    r9,r10
  40b267:	call   407750 <__swc_fn_7069e055_000039_9ae4348f>
  40b26c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b274:	jne    40b1d0 <__swc_fn_7069e055_000058_01964a17+0x190>
  40b27a:	add    QWORD PTR [r13+0x2a78],0x1
  40b282:	mov    rax,QWORD PTR [r13+0x2a70]
  40b289:	lea    rax,[rax+rax*4]
  40b28d:	lea    rax,[r13+rax*8+0x268]
  40b295:	mov    QWORD PTR [rax],r14
  40b298:	mov    QWORD PTR [rax+0x8],r15
  40b29c:	mov    QWORD PTR [rax+0x10],r12
  40b2a0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40b2a7:	mov    QWORD PTR [rax+0x18],rcx
  40b2ab:	mov    QWORD PTR [rax+0x20],rdi
  40b2af:	add    QWORD PTR [r13+0x2a68],r12
  40b2b6:	add    QWORD PTR [r13+0x2a70],0x1
  40b2be:	mov    rcx,r13
  40b2c1:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  40b2c6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40b2cf:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40b2d8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40b2e1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40b2ea:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40b2f3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40b2fc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40b305:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40b30e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40b317:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40b320:	add    rsp,0x148
  40b327:	pop    rsi
  40b328:	pop    rdi
  40b329:	pop    r15
  40b32b:	pop    r14
  40b32d:	pop    r13
  40b32f:	pop    r12
  40b331:	ret
	...

000000000040b340 <__swc_fn_7069e055_000061_73a9baa2>:
  40b340:	push   rbx
  40b341:	push   r12
  40b343:	push   r13
  40b345:	push   r14
  40b347:	push   r15
  40b349:	push   rdi
  40b34a:	push   rsi
  40b34b:	sub    rsp,0xf0
  40b352:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40b358:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40b35e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40b364:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40b36a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40b373:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40b37c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40b385:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40b38e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40b397:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40b3a0:	mov    eax,r8d
  40b3a3:	mov    rbx,rcx
  40b3a6:	mov    r12,rdx
  40b3a9:	mov    QWORD PTR [rsp+0x18],rdx
  40b3ae:	mov    ecx,DWORD PTR [r12+0x58]
  40b3b3:	mov    r13d,ecx
  40b3b6:	cmp    ecx,0x10
  40b3b9:	mov    ecx,0x10
  40b3be:	cmovb  r13d,ecx
  40b3c2:	test   r13d,r13d
  40b3c5:	mov    rcx,r13
  40b3c8:	mov    edx,0x8
  40b3cd:	cmove  ecx,edx
  40b3d0:	dec    rcx
  40b3d3:	mov    rdx,0xffffffffffffffff
  40b3da:	sub    rdx,rcx
  40b3dd:	xor    r14d,r14d
  40b3e0:	mov    r8,rcx
  40b3e3:	not    r8
  40b3e6:	lea    rcx,[rcx+0x58]
  40b3ea:	and    rcx,r8
  40b3ed:	cmp    rdx,0x58
  40b3f1:	cmovae r14,rcx
  40b3f5:	cmp    eax,0xffffffff
  40b3f8:	jne    40b401 <__swc_fn_7069e055_000061_73a9baa2+0xc1>
  40b3fa:	mov    r15,QWORD PTR [r12+0x48]
  40b3ff:	jmp    40b433 <__swc_fn_7069e055_000061_73a9baa2+0xf3>
  40b401:	test   eax,eax
  40b403:	jne    40b40c <__swc_fn_7069e055_000061_73a9baa2+0xcc>
  40b405:	mov    eax,0x8
  40b40a:	jmp    40b430 <__swc_fn_7069e055_000061_73a9baa2+0xf0>
  40b40c:	cmp    eax,0x8
  40b40f:	ja     40b417 <__swc_fn_7069e055_000061_73a9baa2+0xd7>
  40b411:	shl    rax,0x4
  40b415:	jmp    40b430 <__swc_fn_7069e055_000061_73a9baa2+0xf0>
  40b417:	lea    eax,[rax-0x9]
  40b41a:	mov    ecx,eax
  40b41c:	shr    ecx,0x2
  40b41f:	and    eax,0x3
  40b422:	lea    ecx,[rcx+0x7]
  40b425:	lea    ecx,[rcx-0x2]
  40b428:	lea    eax,[rax+0x5]
  40b42b:	shlx   rax,rax,rcx
  40b430:	mov    r15,rax
  40b433:	lea    rax,[r14+r13*1]
  40b437:	mov    rcx,0xffffffffffffffff
  40b43e:	sub    rcx,rax
  40b441:	cmp    r15,rcx
  40b444:	jbe    40b454 <__swc_fn_7069e055_000061_73a9baa2+0x114>
  40b446:	mov    QWORD PTR [r12+0x40],0x0
  40b44f:	jmp    40b826 <__swc_fn_7069e055_000061_73a9baa2+0x4e6>
  40b454:	mov    QWORD PTR [rsp+0x20],r13
  40b459:	lea    r13,[rsp+0x8]
  40b45e:	add    rax,r15
  40b461:	mov    ecx,0x1000
  40b466:	test   ecx,ecx
  40b468:	mov    edx,0x8
  40b46d:	cmove  ecx,edx
  40b470:	dec    rcx
  40b473:	mov    rdx,0xffffffffffffffff
  40b47a:	sub    rdx,rcx
  40b47d:	cmp    rax,rdx
  40b480:	jbe    40b48c <__swc_fn_7069e055_000061_73a9baa2+0x14c>
  40b482:	mov    QWORD PTR [r13+0x0],0x0
  40b48a:	jmp    40b499 <__swc_fn_7069e055_000061_73a9baa2+0x159>
  40b48c:	add    rax,rcx
  40b48f:	andn   rax,rcx,rax
  40b494:	mov    QWORD PTR [rsp+0x8],rax
  40b499:	cmp    QWORD PTR [r13+0x0],0x0
  40b49e:	jne    40b4ae <__swc_fn_7069e055_000061_73a9baa2+0x16e>
  40b4a0:	mov    QWORD PTR [r12+0x40],0x0
  40b4a9:	jmp    40b826 <__swc_fn_7069e055_000061_73a9baa2+0x4e6>
  40b4ae:	mov    QWORD PTR [rsp+0x30],r15
  40b4b3:	xor    r15d,r15d
  40b4b6:	mov    QWORD PTR [rsp+0x38],0x0
  40b4bf:	lea    r12,[rsp+0x10]
  40b4c4:	mov    QWORD PTR [rsp+0x28],r14
  40b4c9:	mov    r14,QWORD PTR [rsp+0x8]
  40b4ce:	mov    QWORD PTR [rsp+0x10],r14
  40b4d3:	cmp    r14,0x10000
  40b4da:	ja     40b4e1 <__swc_fn_7069e055_000061_73a9baa2+0x1a1>
  40b4dc:	mov    rax,r14
  40b4df:	jmp    40b532 <__swc_fn_7069e055_000061_73a9baa2+0x1f2>
  40b4e1:	xor    eax,eax
  40b4e3:	lea    rcx,[r14-0x1]
  40b4e7:	lzcnt  rax,rcx
  40b4ec:	mov    ecx,0x3f
  40b4f1:	sub    rcx,rax
  40b4f4:	mov    eax,0x1
  40b4f9:	lea    rcx,[rcx-0x3]
  40b4fd:	shl    rax,cl
  40b500:	mov    rcx,rax
  40b503:	cmp    rax,0x1000
  40b50a:	mov    eax,0x1000
  40b50f:	cmovb  rcx,rax
  40b513:	mov    rdx,0xffffffffffffffff
  40b51a:	sub    rdx,rcx
  40b51d:	mov    rax,r14
  40b520:	lea    r8,[r14+rcx*1-0x1]
  40b525:	neg    rcx
  40b528:	and    r8,rcx
  40b52b:	cmp    r14,rdx
  40b52e:	cmovbe rax,r8
  40b532:	mov    QWORD PTR [rsp+0x8],rax
  40b537:	lea    rax,[rip+0x16ac2]        # 422000 <__swc_data_base_7069e055>
  40b53e:	mov    rax,QWORD PTR [rax]
  40b541:	cmp    rax,0xffffffffffffffff
  40b545:	je     40b554 <__swc_fn_7069e055_000061_73a9baa2+0x214>
  40b547:	mov    eax,eax
  40b549:	mov    edi,eax
  40b54b:	xor    eax,eax
  40b54d:	call   407000 <pthread_getspecific@plt>
  40b552:	jmp    40b556 <__swc_fn_7069e055_000061_73a9baa2+0x216>
  40b554:	xor    eax,eax
  40b556:	test   rax,rax
  40b559:	jne    40b568 <__swc_fn_7069e055_000061_73a9baa2+0x228>
  40b55b:	call   40a9e0 <__swc_fn_7069e055_000031_3c3e930e>
  40b560:	mov    rcx,rax
  40b563:	call   410480 <__swc_fn_7069e055_000128_8d8a7dd2>
  40b568:	test   rax,rax
  40b56b:	je     40b65c <__swc_fn_7069e055_000061_73a9baa2+0x31c>
  40b571:	cmp    QWORD PTR [rax],rbx
  40b574:	jne    40b65c <__swc_fn_7069e055_000061_73a9baa2+0x31c>
  40b57a:	cmp    DWORD PTR [rax+0x20],0x0
  40b57e:	jne    40b65c <__swc_fn_7069e055_000061_73a9baa2+0x31c>
  40b584:	mov    rcx,QWORD PTR [rsp+0x8]
  40b589:	movabs rdx,0x7fffffffffffffff
  40b593:	cmp    rcx,rdx
  40b596:	mov    rdx,0xffffffffffffffff
  40b59d:	lea    r8,[rcx+rcx*1]
  40b5a1:	cmovbe rdx,r8
  40b5a5:	mov    r8d,DWORD PTR [rax+0x730]
  40b5ac:	mov    r9d,r8d
  40b5af:	sub    rdx,rcx
  40b5b2:	inc    rdx
  40b5b5:	xor    r10d,r10d
  40b5b8:	test   r8,r8
  40b5bb:	jbe    40b5eb <__swc_fn_7069e055_000061_73a9baa2+0x2ab>
  40b5bd:	nop    DWORD PTR [rax]
  40b5c0:	mov    r11d,r10d
  40b5c3:	lea    r11,[r11+r11*4]
  40b5c7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40b5cf:	sub    r11,rcx
  40b5d2:	cmp    r11,rdx
  40b5d5:	jae    40b5e2 <__swc_fn_7069e055_000061_73a9baa2+0x2a2>
  40b5d7:	mov    r9d,r10d
  40b5da:	mov    rdx,r11
  40b5dd:	test   r11,r11
  40b5e0:	je     40b5eb <__swc_fn_7069e055_000061_73a9baa2+0x2ab>
  40b5e2:	add    r10,0x1
  40b5e6:	cmp    r10,r8
  40b5e9:	jb     40b5c0 <__swc_fn_7069e055_000061_73a9baa2+0x280>
  40b5eb:	mov    ecx,DWORD PTR [rax+0x730]
  40b5f1:	cmp    r9d,ecx
  40b5f4:	jne    40b5fa <__swc_fn_7069e055_000061_73a9baa2+0x2ba>
  40b5f6:	xor    eax,eax
  40b5f8:	jmp    40b659 <__swc_fn_7069e055_000061_73a9baa2+0x319>
  40b5fa:	lea    rcx,[r9+r9*4]
  40b5fe:	lea    rcx,[rax+rcx*8+0x738]
  40b606:	vmovups xmm0,XMMWORD PTR [rcx]
  40b60a:	mov    rdx,QWORD PTR [rcx+0x10]
  40b60e:	sub    DWORD PTR [rax+0x730],0x1
  40b615:	mov    r8d,DWORD PTR [rax+0x730]
  40b61c:	lea    r8,[r8+r8*4]
  40b620:	lea    r8,[rax+r8*8+0x738]
  40b628:	vmovups xmm1,XMMWORD PTR [r8]
  40b62d:	vmovups XMMWORD PTR [rcx],xmm1
  40b631:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40b637:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40b63c:	mov    rax,QWORD PTR [r8+0x20]
  40b640:	mov    QWORD PTR [rcx+0x20],rax
  40b644:	vpshufd xmm1,xmm0,0xee
  40b649:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40b64f:	mov    QWORD PTR [rsp+0x10],rdx
  40b654:	vmovq  rax,xmm0
  40b659:	mov    r15,rax
  40b65c:	test   r15,r15
  40b65f:	jne    40b677 <__swc_fn_7069e055_000061_73a9baa2+0x337>
  40b661:	mov    rcx,rbx
  40b664:	mov    rdx,QWORD PTR [rsp+0x8]
  40b669:	mov    r8,r13
  40b66c:	mov    r9,r12
  40b66f:	call   40af30 <__swc_fn_7069e055_000055_ddf32775>
  40b674:	mov    r15,rax
  40b677:	test   r15,r15
  40b67a:	je     40b6bb <__swc_fn_7069e055_000061_73a9baa2+0x37b>
  40b67c:	cmp    QWORD PTR [r12],r14
  40b680:	jae    40b6bb <__swc_fn_7069e055_000061_73a9baa2+0x37b>
  40b682:	mov    rax,r15
  40b685:	add    rax,QWORD PTR [r12]
  40b689:	mov    rdx,r14
  40b68c:	sub    rdx,QWORD PTR [r12]
  40b690:	mov    rcx,rax
  40b693:	call   4072a0 <__swc_fn_7069e055_000003_81215399>
  40b698:	test   al,al
  40b69a:	je     40b6a3 <__swc_fn_7069e055_000061_73a9baa2+0x363>
  40b69c:	mov    QWORD PTR [rsp+0x10],r14
  40b6a1:	jmp    40b6bb <__swc_fn_7069e055_000061_73a9baa2+0x37b>
  40b6a3:	mov    rcx,rbx
  40b6a6:	mov    rdx,r15
  40b6a9:	mov    r8,QWORD PTR [rsp+0x8]
  40b6ae:	mov    r9,QWORD PTR [rsp+0x10]
  40b6b3:	call   40b040 <__swc_fn_7069e055_000058_01964a17>
  40b6b8:	xor    r15d,r15d
  40b6bb:	test   r15,r15
  40b6be:	jne    40b73a <__swc_fn_7069e055_000061_73a9baa2+0x3fa>
  40b6c0:	cmp    r14,0x10000
  40b6c7:	ja     40b6ce <__swc_fn_7069e055_000061_73a9baa2+0x38e>
  40b6c9:	mov    rax,r14
  40b6cc:	jmp    40b71f <__swc_fn_7069e055_000061_73a9baa2+0x3df>
  40b6ce:	xor    eax,eax
  40b6d0:	lea    rcx,[r14-0x1]
  40b6d4:	lzcnt  rax,rcx
  40b6d9:	mov    ecx,0x3f
  40b6de:	sub    rcx,rax
  40b6e1:	mov    eax,0x1
  40b6e6:	lea    rcx,[rcx-0x3]
  40b6ea:	shl    rax,cl
  40b6ed:	mov    rcx,rax
  40b6f0:	cmp    rax,0x1000
  40b6f7:	mov    eax,0x1000
  40b6fc:	cmovb  rcx,rax
  40b700:	mov    rdx,0xffffffffffffffff
  40b707:	sub    rdx,rcx
  40b70a:	mov    rax,r14
  40b70d:	lea    r8,[r14+rcx*1-0x1]
  40b712:	neg    rcx
  40b715:	and    r8,rcx
  40b718:	cmp    r14,rdx
  40b71b:	cmovbe rax,r8
  40b71f:	mov    QWORD PTR [rsp+0x8],rax
  40b724:	mov    QWORD PTR [rsp+0x10],r14
  40b729:	mov    rcx,rbx
  40b72c:	mov    rdx,rax
  40b72f:	mov    r8,r14
  40b732:	call   40aaa0 <__swc_fn_7069e055_000037_1e381f55>
  40b737:	mov    r15,rax
  40b73a:	test   r15,r15
  40b73d:	jne    40b74b <__swc_fn_7069e055_000061_73a9baa2+0x40b>
  40b73f:	mov    r13,QWORD PTR [rsp+0x20]
  40b744:	mov    rsi,QWORD PTR [rsp+0x38]
  40b749:	jmp    40b787 <__swc_fn_7069e055_000061_73a9baa2+0x447>
  40b74b:	mov    rax,r15
  40b74e:	add    rax,QWORD PTR [rsp+0x28]
  40b753:	mov    r13,QWORD PTR [rsp+0x20]
  40b758:	test   r13d,r13d
  40b75b:	mov    rcx,r13
  40b75e:	mov    edx,0x8
  40b763:	cmove  ecx,edx
  40b766:	dec    rcx
  40b769:	mov    rdx,0xffffffffffffffff
  40b770:	sub    rdx,rcx
  40b773:	cmp    rax,rdx
  40b776:	jbe    40b77c <__swc_fn_7069e055_000061_73a9baa2+0x43c>
  40b778:	xor    eax,eax
  40b77a:	jmp    40b784 <__swc_fn_7069e055_000061_73a9baa2+0x444>
  40b77c:	add    rax,rcx
  40b77f:	andn   rax,rcx,rax
  40b784:	mov    rsi,rax
  40b787:	mov    rax,QWORD PTR [rsp+0x8]
  40b78c:	test   r15,r15
  40b78f:	je     40b798 <__swc_fn_7069e055_000061_73a9baa2+0x458>
  40b791:	mov    rdi,QWORD PTR [rsp+0x18]
  40b796:	jmp    40b7aa <__swc_fn_7069e055_000061_73a9baa2+0x46a>
  40b798:	mov    rdi,QWORD PTR [rsp+0x18]
  40b79d:	mov    QWORD PTR [rdi+0x40],0x0
  40b7a5:	jmp    40b826 <__swc_fn_7069e055_000061_73a9baa2+0x4e6>
  40b7aa:	lea    rdx,[rsi-0x58]
  40b7ae:	mov    QWORD PTR [rsi-0x58],r15
  40b7b2:	mov    QWORD PTR [rsi-0x50],rax
  40b7b6:	mov    rax,QWORD PTR [rsp+0x10]
  40b7bb:	mov    QWORD PTR [rsi-0x48],rax
  40b7bf:	mov    QWORD PTR [rsi-0x40],rsi
  40b7c3:	mov    rax,QWORD PTR [rdi+0x48]
  40b7c7:	mov    QWORD PTR [rsi-0x38],rax
  40b7cb:	mov    rax,QWORD PTR [rsp+0x30]
  40b7d0:	mov    QWORD PTR [rsi-0x30],rax
  40b7d4:	mov    DWORD PTR [rsi-0x10],r13d
  40b7d8:	mov    QWORD PTR [rsi-0x28],0x0
  40b7e0:	mov    QWORD PTR [rsi-0x20],0x0
  40b7e8:	add    r15,QWORD PTR [r12]
  40b7ec:	sub    r15,rsi
  40b7ef:	mov    QWORD PTR [rsi-0x30],r15
  40b7f3:	mov    rcx,QWORD PTR [rbx+0x250]
  40b7fa:	nop    WORD PTR [rax+rax*1+0x0]
  40b800:	lea    r8,[rcx+r15*1]
  40b804:	mov    rax,rcx
  40b807:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40b810:	cmp    rax,rcx
  40b813:	je     40b81a <__swc_fn_7069e055_000061_73a9baa2+0x4da>
  40b815:	mov    rcx,rax
  40b818:	jmp    40b800 <__swc_fn_7069e055_000061_73a9baa2+0x4c0>
  40b81a:	mov    rcx,rbx
  40b81d:	call   40e7b0 <__swc_fn_7069e055_000053_9aa81fa7>
  40b822:	mov    QWORD PTR [rdi+0x40],rsi
  40b826:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40b82c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40b832:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40b838:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40b83e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40b847:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40b850:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40b859:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40b862:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40b86b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40b874:	add    rsp,0xf0
  40b87b:	pop    rsi
  40b87c:	pop    rdi
  40b87d:	pop    r15
  40b87f:	pop    r14
  40b881:	pop    r13
  40b883:	pop    r12
  40b885:	pop    rbx
  40b886:	ret
	...

000000000040b890 <__swc_fn_7069e055_000064_20100e91>:
  40b890:	push   rbx
  40b891:	push   r12
  40b893:	push   rdi
  40b894:	push   rsi
  40b895:	sub    rsp,0xb8
  40b89c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40b8a2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40b8a8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40b8ae:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40b8b4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40b8ba:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40b8c0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40b8c6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40b8cf:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40b8d8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40b8e1:	mov    rbx,rdx
  40b8e4:	mov    r12,rcx
  40b8e7:	cmp    DWORD PTR [rbx+0x58],0x0
  40b8eb:	je     40b905 <__swc_fn_7069e055_000064_20100e91+0x75>
  40b8ed:	mov    eax,DWORD PTR [rbx+0x58]
  40b8f0:	sub    eax,0x1
  40b8f3:	test   DWORD PTR [rbx+0x58],eax
  40b8f6:	je     40b905 <__swc_fn_7069e055_000064_20100e91+0x75>
  40b8f8:	mov    QWORD PTR [rbx+0x40],0x0
  40b900:	jmp    40bb17 <__swc_fn_7069e055_000064_20100e91+0x287>
  40b905:	cmp    QWORD PTR [rbx+0x48],0x0
  40b90a:	jne    40b919 <__swc_fn_7069e055_000064_20100e91+0x89>
  40b90c:	mov    QWORD PTR [rbx+0x40],0x0
  40b914:	jmp    40bb17 <__swc_fn_7069e055_000064_20100e91+0x287>
  40b919:	lea    rax,[rsp+0x8]
  40b91e:	mov    rcx,QWORD PTR [rbx+0x48]
  40b922:	cmp    rcx,0x8
  40b926:	ja     40b930 <__swc_fn_7069e055_000064_20100e91+0xa0>
  40b928:	mov    DWORD PTR [rax],0x0
  40b92e:	jmp    40b98b <__swc_fn_7069e055_000064_20100e91+0xfb>
  40b930:	cmp    rcx,0x80
  40b937:	ja     40b947 <__swc_fn_7069e055_000064_20100e91+0xb7>
  40b939:	lea    rcx,[rcx+0xf]
  40b93d:	shr    rcx,0x4
  40b941:	mov    DWORD PTR [rsp+0x8],ecx
  40b945:	jmp    40b98b <__swc_fn_7069e055_000064_20100e91+0xfb>
  40b947:	cmp    rcx,0x10000
  40b94e:	jbe    40b958 <__swc_fn_7069e055_000064_20100e91+0xc8>
  40b950:	mov    DWORD PTR [rax],0xffffffff
  40b956:	jmp    40b98b <__swc_fn_7069e055_000064_20100e91+0xfb>
  40b958:	dec    rcx
  40b95b:	xor    edx,edx
  40b95d:	lzcnt  rdx,rcx
  40b962:	mov    r8d,0x3f
  40b968:	sub    r8d,edx
  40b96b:	lea    edx,[r8-0x2]
  40b96f:	shrx   rcx,rcx,rdx
  40b974:	and    ecx,0x3
  40b977:	lea    edx,[r8-0x7]
  40b97b:	lea    edx,[rdx*4+0x0]
  40b982:	lea    edx,[rdx+0x9]
  40b985:	add    edx,ecx
  40b987:	mov    DWORD PTR [rsp+0x8],edx
  40b98b:	cmp    DWORD PTR [rax],0x0
  40b98e:	jne    40b99e <__swc_fn_7069e055_000064_20100e91+0x10e>
  40b990:	cmp    DWORD PTR [rbx+0x58],0x8
  40b994:	jbe    40b99e <__swc_fn_7069e055_000064_20100e91+0x10e>
  40b996:	mov    DWORD PTR [rsp+0x8],0x1
  40b99e:	cmp    DWORD PTR [rbx+0x58],0x10
  40b9a2:	jbe    40ba21 <__swc_fn_7069e055_000064_20100e91+0x191>
  40b9a8:	cmp    DWORD PTR [rbx+0x58],0x40
  40b9ac:	ja     40ba21 <__swc_fn_7069e055_000064_20100e91+0x191>
  40b9ae:	cmp    DWORD PTR [rax],0xffffffff
  40b9b1:	je     40ba21 <__swc_fn_7069e055_000064_20100e91+0x191>
  40b9b3:	mov    ecx,DWORD PTR [rsp+0x8]
  40b9b7:	mov    edx,DWORD PTR [rbx+0x58]
  40b9ba:	dec    rdx
  40b9bd:	cmp    ecx,0x2d
  40b9c0:	jae    40ba18 <__swc_fn_7069e055_000064_20100e91+0x188>
  40b9c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b9cc:	nop    DWORD PTR [rax+0x0]
  40b9d0:	mov    r8d,ecx
  40b9d3:	test   ecx,ecx
  40b9d5:	jne    40b9df <__swc_fn_7069e055_000064_20100e91+0x14f>
  40b9d7:	mov    r8d,0x8
  40b9dd:	jmp    40ba0b <__swc_fn_7069e055_000064_20100e91+0x17b>
  40b9df:	cmp    r8d,0x8
  40b9e3:	ja     40b9eb <__swc_fn_7069e055_000064_20100e91+0x15b>
  40b9e5:	shl    r8,0x4
  40b9e9:	jmp    40ba0b <__swc_fn_7069e055_000064_20100e91+0x17b>
  40b9eb:	lea    r8d,[r8-0x9]
  40b9ef:	mov    r9d,r8d
  40b9f2:	shr    r9d,0x2
  40b9f6:	and    r8d,0x3
  40b9fa:	lea    r9d,[r9+0x7]
  40b9fe:	lea    r9d,[r9-0x2]
  40ba02:	lea    r8d,[r8+0x5]
  40ba06:	shlx   r8,r8,r9
  40ba0b:	test   r8,rdx
  40ba0e:	je     40ba1d <__swc_fn_7069e055_000064_20100e91+0x18d>
  40ba10:	add    ecx,0x1
  40ba13:	cmp    ecx,0x2d
  40ba16:	jb     40b9d0 <__swc_fn_7069e055_000064_20100e91+0x140>
  40ba18:	mov    ecx,0xffffffff
  40ba1d:	mov    DWORD PTR [rsp+0x8],ecx
  40ba21:	mov    ecx,DWORD PTR [rsp+0x8]
  40ba25:	cmp    ecx,0xffffffff
  40ba28:	je     40ba30 <__swc_fn_7069e055_000064_20100e91+0x1a0>
  40ba2a:	cmp    DWORD PTR [rbx+0x58],0x40
  40ba2e:	jbe    40ba43 <__swc_fn_7069e055_000064_20100e91+0x1b3>
  40ba30:	mov    rcx,r12
  40ba33:	mov    rdx,rbx
  40ba36:	mov    r8d,DWORD PTR [rax]
  40ba39:	call   40b340 <__swc_fn_7069e055_000061_73a9baa2>
  40ba3e:	jmp    40bb17 <__swc_fn_7069e055_000064_20100e91+0x287>
  40ba43:	lea    rax,[rip+0x165b6]        # 422000 <__swc_data_base_7069e055>
  40ba4a:	mov    rax,QWORD PTR [rax]
  40ba4d:	cmp    rax,0xffffffffffffffff
  40ba51:	je     40ba60 <__swc_fn_7069e055_000064_20100e91+0x1d0>
  40ba53:	mov    eax,eax
  40ba55:	mov    edi,eax
  40ba57:	xor    eax,eax
  40ba59:	call   407000 <pthread_getspecific@plt>
  40ba5e:	jmp    40ba62 <__swc_fn_7069e055_000064_20100e91+0x1d2>
  40ba60:	xor    eax,eax
  40ba62:	test   rax,rax
  40ba65:	jne    40ba74 <__swc_fn_7069e055_000064_20100e91+0x1e4>
  40ba67:	call   40a9e0 <__swc_fn_7069e055_000031_3c3e930e>
  40ba6c:	mov    rcx,rax
  40ba6f:	call   410480 <__swc_fn_7069e055_000128_8d8a7dd2>
  40ba74:	test   rax,rax
  40ba77:	je     40ba84 <__swc_fn_7069e055_000064_20100e91+0x1f4>
  40ba79:	cmp    QWORD PTR [rax],r12
  40ba7c:	jne    40ba84 <__swc_fn_7069e055_000064_20100e91+0x1f4>
  40ba7e:	cmp    DWORD PTR [rax+0x20],0x0
  40ba82:	je     40ba8f <__swc_fn_7069e055_000064_20100e91+0x1ff>
  40ba84:	mov    rcx,r12
  40ba87:	mov    rdx,rax
  40ba8a:	call   40e3f0 <__swc_fn_7069e055_000041_41400651>
  40ba8f:	test   rax,rax
  40ba92:	jne    40ba9e <__swc_fn_7069e055_000064_20100e91+0x20e>
  40ba94:	mov    QWORD PTR [rbx+0x40],0x0
  40ba9c:	jmp    40bb17 <__swc_fn_7069e055_000064_20100e91+0x287>
  40ba9e:	lea    r8,[rsp+0xc]
  40baa3:	mov    ecx,DWORD PTR [rsp+0x8]
  40baa7:	mov    DWORD PTR [rsp+0xc],ecx
  40baab:	mov    ecx,DWORD PTR [r8]
  40baae:	lea    rcx,[rcx+rcx*4]
  40bab2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40bab7:	test   rcx,rcx
  40baba:	je     40baf3 <__swc_fn_7069e055_000064_20100e91+0x263>
  40babc:	mov    rdx,QWORD PTR [rcx]
  40babf:	test   rdx,rdx
  40bac2:	je     40bad0 <__swc_fn_7069e055_000064_20100e91+0x240>
  40bac4:	mov    r9,QWORD PTR [rdx]
  40bac7:	mov    QWORD PTR [rcx],r9
  40baca:	add    DWORD PTR [rcx+0x28],0x1
  40bace:	jmp    40baee <__swc_fn_7069e055_000064_20100e91+0x25e>
  40bad0:	mov    rdx,QWORD PTR [rcx+0x18]
  40bad4:	cmp    QWORD PTR [rcx+0x20],rdx
  40bad8:	jae    40baec <__swc_fn_7069e055_000064_20100e91+0x25c>
  40bada:	mov    rdx,QWORD PTR [rcx+0x20]
  40bade:	mov    r9d,DWORD PTR [rcx+0x2c]
  40bae2:	add    QWORD PTR [rcx+0x20],r9
  40bae6:	add    DWORD PTR [rcx+0x28],0x1
  40baea:	jmp    40baee <__swc_fn_7069e055_000064_20100e91+0x25e>
  40baec:	xor    edx,edx
  40baee:	test   rdx,rdx
  40baf1:	jne    40bb04 <__swc_fn_7069e055_000064_20100e91+0x274>
  40baf3:	mov    rcx,r12
  40baf6:	mov    rdx,rax
  40baf9:	mov    r8d,DWORD PTR [r8]
  40bafc:	call   40e560 <__swc_fn_7069e055_000050_5e919db9>
  40bb01:	mov    rdx,rax
  40bb04:	test   rdx,rdx
  40bb07:	jne    40bb13 <__swc_fn_7069e055_000064_20100e91+0x283>
  40bb09:	mov    QWORD PTR [rbx+0x40],0x0
  40bb11:	jmp    40bb17 <__swc_fn_7069e055_000064_20100e91+0x287>
  40bb13:	mov    QWORD PTR [rbx+0x40],rdx
  40bb17:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40bb1d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40bb23:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40bb29:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40bb2f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40bb35:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40bb3b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40bb41:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40bb4a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40bb53:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40bb5c:	add    rsp,0xb8
  40bb63:	pop    rsi
  40bb64:	pop    rdi
  40bb65:	pop    r12
  40bb67:	pop    rbx
  40bb68:	ret
  40bb69:	add    BYTE PTR [rax],al
  40bb6b:	add    BYTE PTR [rax],al
  40bb6d:	add    BYTE PTR [rax],al
	...

000000000040bb70 <__swc_fn_7069e055_000067_0145abfc>:
  40bb70:	ret
	...

000000000040bb80 <__swc_fn_7069e055_000070_357c932c>:
  40bb80:	push   r12
  40bb82:	push   r13
  40bb84:	push   r14
  40bb86:	push   rdi
  40bb87:	push   rsi
  40bb88:	sub    rsp,0x1a0
  40bb8f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40bb98:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40bba1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40bbaa:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40bbb3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40bbbc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40bbc5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40bbce:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40bbd7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40bbe0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40bbe9:	mov    r12,rdx
  40bbec:	mov    r13,rcx
  40bbef:	mov    rax,QWORD PTR [r12+0x48]
  40bbf4:	mov    ecx,DWORD PTR [r12+0x58]
  40bbf9:	lea    rdx,[rax-0x1]
  40bbfd:	cmp    rdx,0x10000
  40bc04:	jae    40bcfe <__swc_fn_7069e055_000070_357c932c+0x17e>
  40bc0a:	cmp    rax,0x8
  40bc0e:	ja     40bc15 <__swc_fn_7069e055_000070_357c932c+0x95>
  40bc10:	xor    r14d,r14d
  40bc13:	jmp    40bc67 <__swc_fn_7069e055_000070_357c932c+0xe7>
  40bc15:	cmp    rax,0x80
  40bc1c:	ja     40bc28 <__swc_fn_7069e055_000070_357c932c+0xa8>
  40bc1e:	lea    r14,[rax+0xf]
  40bc22:	shr    r14,0x4
  40bc26:	jmp    40bc67 <__swc_fn_7069e055_000070_357c932c+0xe7>
  40bc28:	cmp    rax,0x10000
  40bc2f:	jbe    40bc39 <__swc_fn_7069e055_000070_357c932c+0xb9>
  40bc31:	mov    r14d,0xffffffff
  40bc37:	jmp    40bc67 <__swc_fn_7069e055_000070_357c932c+0xe7>
  40bc39:	xor    eax,eax
  40bc3b:	lzcnt  rax,rdx
  40bc40:	mov    r8d,0x3f
  40bc46:	sub    r8d,eax
  40bc49:	lea    eax,[r8-0x2]
  40bc4d:	shrx   rax,rdx,rax
  40bc52:	and    eax,0x3
  40bc55:	lea    edx,[r8-0x7]
  40bc59:	lea    edx,[rdx*4+0x0]
  40bc60:	lea    edx,[rdx+0x9]
  40bc63:	lea    r14d,[rdx+rax*1]
  40bc67:	cmp    ecx,0x8
  40bc6a:	jbe    40bc83 <__swc_fn_7069e055_000070_357c932c+0x103>
  40bc6c:	cmp    ecx,0x10
  40bc6f:	jne    40bcfe <__swc_fn_7069e055_000070_357c932c+0x17e>
  40bc75:	test   r14d,r14d
  40bc78:	mov    eax,0x1
  40bc7d:	cmove  r14d,eax
  40bc81:	jmp    40bc8a <__swc_fn_7069e055_000070_357c932c+0x10a>
  40bc83:	lea    eax,[rcx-0x1]
  40bc86:	test   eax,ecx
  40bc88:	jne    40bcfe <__swc_fn_7069e055_000070_357c932c+0x17e>
  40bc8a:	lea    rax,[rip+0x1636f]        # 422000 <__swc_data_base_7069e055>
  40bc91:	mov    rax,QWORD PTR [rax]
  40bc94:	cmp    rax,0xffffffffffffffff
  40bc98:	je     40bca7 <__swc_fn_7069e055_000070_357c932c+0x127>
  40bc9a:	mov    eax,eax
  40bc9c:	mov    edi,eax
  40bc9e:	xor    eax,eax
  40bca0:	call   407000 <pthread_getspecific@plt>
  40bca5:	jmp    40bca9 <__swc_fn_7069e055_000070_357c932c+0x129>
  40bca7:	xor    eax,eax
  40bca9:	test   rax,rax
  40bcac:	je     40bcfe <__swc_fn_7069e055_000070_357c932c+0x17e>
  40bcae:	cmp    QWORD PTR [rax],r13
  40bcb1:	jne    40bcfe <__swc_fn_7069e055_000070_357c932c+0x17e>
  40bcb3:	lea    rcx,[r14+r14*4]
  40bcb7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40bcbc:	test   rax,rax
  40bcbf:	je     40bcfe <__swc_fn_7069e055_000070_357c932c+0x17e>
  40bcc1:	mov    rcx,QWORD PTR [rax]
  40bcc4:	test   rcx,rcx
  40bcc7:	je     40bcd5 <__swc_fn_7069e055_000070_357c932c+0x155>
  40bcc9:	mov    rdx,QWORD PTR [rcx]
  40bccc:	mov    QWORD PTR [rax],rdx
  40bccf:	add    DWORD PTR [rax+0x28],0x1
  40bcd3:	jmp    40bcf2 <__swc_fn_7069e055_000070_357c932c+0x172>
  40bcd5:	mov    rcx,QWORD PTR [rax+0x18]
  40bcd9:	cmp    QWORD PTR [rax+0x20],rcx
  40bcdd:	jae    40bcf0 <__swc_fn_7069e055_000070_357c932c+0x170>
  40bcdf:	mov    rcx,QWORD PTR [rax+0x20]
  40bce3:	mov    edx,DWORD PTR [rax+0x2c]
  40bce6:	add    QWORD PTR [rax+0x20],rdx
  40bcea:	add    DWORD PTR [rax+0x28],0x1
  40bcee:	jmp    40bcf2 <__swc_fn_7069e055_000070_357c932c+0x172>
  40bcf0:	xor    ecx,ecx
  40bcf2:	test   rcx,rcx
  40bcf5:	je     40bcfe <__swc_fn_7069e055_000070_357c932c+0x17e>
  40bcf7:	mov    QWORD PTR [r12+0x40],rcx
  40bcfc:	jmp    40bd09 <__swc_fn_7069e055_000070_357c932c+0x189>
  40bcfe:	mov    rcx,r13
  40bd01:	mov    rdx,r12
  40bd04:	call   40efe0 <__swc_fn_7069e055_000071_1e1e3bf8>
  40bd09:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40bd12:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40bd1b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40bd24:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40bd2d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40bd36:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40bd3f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40bd48:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40bd51:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40bd5a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40bd63:	add    rsp,0x1a0
  40bd6a:	pop    rsi
  40bd6b:	pop    rdi
  40bd6c:	pop    r14
  40bd6e:	pop    r13
  40bd70:	pop    r12
  40bd72:	ret
	...

000000000040bd80 <__swc_fn_7069e055_000073_cdd57f51>:
  40bd80:	push   r12
  40bd82:	push   r13
  40bd84:	push   r14
  40bd86:	push   r15
  40bd88:	push   rdi
  40bd89:	push   rsi
  40bd8a:	sub    rsp,0x188
  40bd91:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40bd9a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40bda3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40bdac:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40bdb5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40bdbe:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40bdc7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40bdd0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40bdd9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40bde2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40bdeb:	mov    r12,rdx
  40bdee:	mov    r13,rcx
  40bdf1:	mov    r14,QWORD PTR [r12+0x40]
  40bdf6:	lea    rax,[rip+0x18273]        # 424070 <__swc_bss_base_7069e055+0x30>
  40bdfd:	mov    rcx,r14
  40be00:	sub    rcx,QWORD PTR [rax+0x8]
  40be04:	mov    rax,QWORD PTR [rip+0x18275]        # 424080 <__swc_bss_base_7069e055+0x40>
  40be0b:	cmp    rcx,rax
  40be0e:	jae    40be3a <__swc_fn_7069e055_000073_cdd57f51+0xba>
  40be10:	mov    rax,r14
  40be13:	and    rax,0xffffffffffc00000
  40be1a:	mov    rcx,r14
  40be1d:	shr    rcx,0x10
  40be21:	and    ecx,0x3f
  40be24:	mov    edx,DWORD PTR [rax+0x28]
  40be27:	shrx   ecx,ecx,edx
  40be2c:	shl    rcx,0x4
  40be30:	lea    r15,[rax+rcx*8+0x80]
  40be38:	jmp    40be45 <__swc_fn_7069e055_000073_cdd57f51+0xc5>
  40be3a:	mov    rcx,r14
  40be3d:	call   40a910 <__swc_fn_7069e055_000022_53fc00d2>
  40be42:	mov    r15,rax
  40be45:	test   r15,r15
  40be48:	je     40beef <__swc_fn_7069e055_000073_cdd57f51+0x16f>
  40be4e:	lea    rax,[rip+0x161ab]        # 422000 <__swc_data_base_7069e055>
  40be55:	mov    rax,QWORD PTR [rax]
  40be58:	cmp    rax,0xffffffffffffffff
  40be5c:	je     40be6b <__swc_fn_7069e055_000073_cdd57f51+0xeb>
  40be5e:	mov    eax,eax
  40be60:	mov    edi,eax
  40be62:	xor    eax,eax
  40be64:	call   407000 <pthread_getspecific@plt>
  40be69:	jmp    40be6d <__swc_fn_7069e055_000073_cdd57f51+0xed>
  40be6b:	xor    eax,eax
  40be6d:	mov    rcx,QWORD PTR [r15+0x40]
  40be71:	cmp    rcx,rax
  40be74:	jne    40bed4 <__swc_fn_7069e055_000073_cdd57f51+0x154>
  40be76:	test   rax,rax
  40be79:	je     40beef <__swc_fn_7069e055_000073_cdd57f51+0x16f>
  40be7b:	mov    ecx,DWORD PTR [r15+0x6c]
  40be7f:	test   ecx,ecx
  40be81:	je     40bea1 <__swc_fn_7069e055_000073_cdd57f51+0x121>
  40be83:	mov    rcx,r13
  40be86:	mov    rdx,rax
  40be89:	mov    r8,r15
  40be8c:	mov    QWORD PTR [rsp+0xd8],rax
  40be94:	call   40e4f0 <__swc_fn_7069e055_000047_e7fd8d42>
  40be99:	mov    rax,QWORD PTR [rsp+0xd8]
  40bea1:	mov    rcx,QWORD PTR [r15]
  40bea4:	mov    QWORD PTR [r14],rcx
  40bea7:	mov    QWORD PTR [r15],r14
  40beaa:	sub    DWORD PTR [r15+0x28],0x1
  40beaf:	jne    40bee4 <__swc_fn_7069e055_000073_cdd57f51+0x164>
  40beb1:	movzx  ecx,BYTE PTR [r15+0x39]
  40beb6:	lea    rcx,[rcx+rcx*4]
  40beba:	lea    rcx,[rax+rcx*8+0x28]
  40bebf:	cmp    QWORD PTR [rcx],r15
  40bec2:	je     40bee4 <__swc_fn_7069e055_000073_cdd57f51+0x164>
  40bec4:	mov    rcx,r13
  40bec7:	mov    rdx,rax
  40beca:	mov    r8,r15
  40becd:	call   407d80 <__swc_fn_7069e055_000051_27d2a35f>
  40bed2:	jmp    40bee4 <__swc_fn_7069e055_000073_cdd57f51+0x164>
  40bed4:	test   rcx,rcx
  40bed7:	je     40beef <__swc_fn_7069e055_000073_cdd57f51+0x16f>
  40bed9:	mov    rcx,r15
  40bedc:	mov    rdx,r14
  40bedf:	call   40a550 <__swc_fn_7069e055_000010_0569f799>
  40bee4:	mov    QWORD PTR [r12+0x40],0x0
  40beed:	jmp    40befa <__swc_fn_7069e055_000073_cdd57f51+0x17a>
  40beef:	mov    rcx,r13
  40bef2:	mov    rdx,r12
  40bef5:	call   40f000 <__swc_fn_7069e055_000074_30b8696a>
  40befa:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40bf03:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40bf0c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40bf15:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40bf1e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40bf27:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40bf30:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40bf39:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40bf42:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40bf4b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40bf54:	add    rsp,0x188
  40bf5b:	pop    rsi
  40bf5c:	pop    rdi
  40bf5d:	pop    r15
  40bf5f:	pop    r14
  40bf61:	pop    r13
  40bf63:	pop    r12
  40bf65:	ret
	...

000000000040bf70 <__swc_fn_7069e055_000076_c3ad0fb4>:
  40bf70:	sub    rsp,0x8
  40bf74:	mov    rax,rdx
  40bf77:	mov    rdx,QWORD PTR [rax+0x40]
  40bf7b:	mov    r8,rax
  40bf7e:	call   40bb70 <__swc_fn_7069e055_000067_0145abfc>
  40bf83:	add    rsp,0x8
  40bf87:	ret
	...

000000000040bf90 <__swc_fn_7069e055_000079_633af784>:
  40bf90:	push   rsi
  40bf91:	push   rdi
  40bf92:	sub    rsp,0x8
  40bf96:	cmp    rcx,0xffffffffffffffef
  40bf9a:	ja     40bfc0 <__swc_fn_7069e055_000079_633af784+0x30>
  40bf9c:	xor    esi,esi
  40bf9e:	lea    rax,[rcx+0x100f]
  40bfa5:	and    rax,0xfffffffffffff000
  40bfac:	lea    rcx,[rcx+0x10]
  40bfb0:	cmp    rcx,0xfffffffffffff000
  40bfb7:	cmovbe rsi,rax
  40bfbb:	test   rsi,rsi
  40bfbe:	jne    40bfc9 <__swc_fn_7069e055_000079_633af784+0x39>
  40bfc0:	xor    eax,eax
  40bfc2:	add    rsp,0x8
  40bfc6:	pop    rdi
  40bfc7:	pop    rsi
  40bfc8:	ret
  40bfc9:	mov    rcx,rsi
  40bfcc:	call   40c620 <__swc_fn_7069e055_000109_9f5af8ae>
  40bfd1:	mov    rdi,rax
  40bfd4:	test   rax,rax
  40bfd7:	jne    40bfe2 <__swc_fn_7069e055_000079_633af784+0x52>
  40bfd9:	xor    eax,eax
  40bfdb:	add    rsp,0x8
  40bfdf:	pop    rdi
  40bfe0:	pop    rsi
  40bfe1:	ret
  40bfe2:	mov    rcx,rdi
  40bfe5:	mov    rdx,rsi
  40bfe8:	call   409240 <__swc_fn_7069e055_000111_f9e19033>
  40bfed:	test   al,al
  40bfef:	jne    40c005 <__swc_fn_7069e055_000079_633af784+0x75>
  40bff1:	mov    rcx,rdi
  40bff4:	mov    rdx,rsi
  40bff7:	call   410130 <__swc_fn_7069e055_000113_4e83a03a>
  40bffc:	xor    eax,eax
  40bffe:	add    rsp,0x8
  40c002:	pop    rdi
  40c003:	pop    rsi
  40c004:	ret
  40c005:	mov    QWORD PTR [rdi],rsi
  40c008:	mov    QWORD PTR [rdi+0x8],0x0
  40c010:	lea    rax,[rdi+0x10]
  40c014:	add    rsp,0x8
  40c018:	pop    rdi
  40c019:	pop    rsi
  40c01a:	ret
  40c01b:	add    BYTE PTR [rax],al
  40c01d:	add    BYTE PTR [rax],al
	...

000000000040c020 <__swc_fn_7069e055_000082_ff7d1455>:
  40c020:	sub    rsp,0x8
  40c024:	cmp    BYTE PTR [rcx+0x2c],0x10
  40c028:	jne    40c033 <__swc_fn_7069e055_000082_ff7d1455+0x13>
  40c02a:	test   DWORD PTR [rcx+0x28],0x80
  40c031:	je     40c03b <__swc_fn_7069e055_000082_ff7d1455+0x1b>
  40c033:	mov    rax,rcx
  40c036:	add    rsp,0x8
  40c03a:	ret
  40c03b:	mov    rcx,QWORD PTR [rcx+0x40]
  40c03f:	call   40c020 <__swc_fn_7069e055_000082_ff7d1455>
  40c044:	add    rsp,0x8
  40c048:	ret
	...

000000000040c060 <__swc_fn_7069e055_000085_e24ecd12>:
  40c060:	push   rsi
  40c061:	push   rdi
  40c062:	push   r12
  40c064:	push   r13
  40c066:	sub    rsp,0x8
  40c06a:	mov    rsi,rdx
  40c06d:	mov    rdi,rcx
  40c070:	xor    r8d,r8d
  40c073:	call   4085a0 <__swc_fn_7069e055_000090_14cf59b2>
  40c078:	test   al,al
  40c07a:	je     40c08c <__swc_fn_7069e055_000085_e24ecd12+0x2c>
  40c07c:	mov    eax,0x1
  40c081:	add    rsp,0x8
  40c085:	pop    r13
  40c087:	pop    r12
  40c089:	pop    rdi
  40c08a:	pop    rsi
  40c08b:	ret
  40c08c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c091:	je     40c0a0 <__swc_fn_7069e055_000085_e24ecd12+0x40>
  40c093:	xor    eax,eax
  40c095:	add    rsp,0x8
  40c099:	pop    r13
  40c09b:	pop    r12
  40c09d:	pop    rdi
  40c09e:	pop    rsi
  40c09f:	ret
  40c0a0:	mov    r12,QWORD PTR [rsi+0x98]
  40c0a7:	mov    rax,QWORD PTR [rsi+0xa0]
  40c0ae:	mov    rsi,rax
  40c0b1:	xor    r13d,r13d
  40c0b4:	test   rsi,rsi
  40c0b7:	je     40c114 <__swc_fn_7069e055_000085_e24ecd12+0xb4>
  40c0b9:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0c3:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0cd:	nop    DWORD PTR [rax]
  40c0d0:	lea    rax,[r13*8+0x0]
  40c0d8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c0dd:	mov    rcx,rax
  40c0e0:	call   40c020 <__swc_fn_7069e055_000082_ff7d1455>
  40c0e5:	cmp    BYTE PTR [rax+0x2c],0xe
  40c0e9:	jne    40c10a <__swc_fn_7069e055_000085_e24ecd12+0xaa>
  40c0eb:	mov    rcx,rdi
  40c0ee:	mov    rdx,rax
  40c0f1:	call   40c060 <__swc_fn_7069e055_000085_e24ecd12>
  40c0f6:	test   al,al
  40c0f8:	je     40c10a <__swc_fn_7069e055_000085_e24ecd12+0xaa>
  40c0fa:	mov    eax,0x1
  40c0ff:	add    rsp,0x8
  40c103:	pop    r13
  40c105:	pop    r12
  40c107:	pop    rdi
  40c108:	pop    rsi
  40c109:	ret
  40c10a:	add    r13,0x1
  40c10e:	sub    rsi,0x1
  40c112:	jne    40c0d0 <__swc_fn_7069e055_000085_e24ecd12+0x70>
  40c114:	xor    eax,eax
  40c116:	add    rsp,0x8
  40c11a:	pop    r13
  40c11c:	pop    r12
  40c11e:	pop    rdi
  40c11f:	pop    rsi
  40c120:	ret
	...

000000000040c130 <__swc_fn_7069e055_000088_ab2f35d8>:
  40c130:	sub    rsp,0x18
  40c134:	vxorps xmm0,xmm0,xmm0
  40c138:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c13d:	call   40f210 <__swc_fn_7069e055_000089_3c530920>
  40c142:	add    rsp,0x18
  40c146:	ret
	...

000000000040c150 <__swc_fn_7069e055_000091_f21926ed>:
  40c150:	sub    rsp,0x8
  40c154:	mov    rcx,QWORD PTR [rip+0x1abe5]        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40c15b:	test   rcx,rcx
  40c15e:	jne    40c170 <__swc_fn_7069e055_000091_f21926ed+0x20>
  40c160:	call   40a1a0 <__swc_fn_7069e055_000165_56054fe7>
  40c165:	lea    rcx,[rax+0x1]
  40c169:	mov    QWORD PTR [rip+0x1abd0],rcx        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40c170:	dec    rcx
  40c173:	call   411f00 <__swc_fn_7069e055_000167_39c041ad>
  40c178:	mov    rax,QWORD PTR [rax+0xc0]
  40c17f:	and    eax,0x1
  40c182:	setne  al
  40c185:	add    rsp,0x8
  40c189:	ret
	...

000000000040c1a0 <__swc_fn_7069e055_000094_383a814c>:
  40c1a0:	push   rbx
  40c1a1:	push   rsi
  40c1a2:	push   rdi
  40c1a3:	push   r12
  40c1a5:	sub    rsp,0x28
  40c1a9:	mov    rbx,rcx
  40c1ac:	call   408900 <__swc_fn_7069e055_000093_0c97fc6c>
  40c1b1:	mov    rcx,QWORD PTR [rip+0x1ab88]        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40c1b8:	test   rcx,rcx
  40c1bb:	jne    40c1cd <__swc_fn_7069e055_000094_383a814c+0x2d>
  40c1bd:	call   40a1a0 <__swc_fn_7069e055_000165_56054fe7>
  40c1c2:	lea    rcx,[rax+0x1]
  40c1c6:	mov    QWORD PTR [rip+0x1ab73],rcx        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40c1cd:	dec    rcx
  40c1d0:	call   411f00 <__swc_fn_7069e055_000167_39c041ad>
  40c1d5:	mov    rsi,rax
  40c1d8:	lea    rcx,[rsp+0x8]
  40c1dd:	call   40f650 <__swc_fn_7069e055_000092_809deff5>
  40c1e2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c1e9:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c1f0:	lea    rcx,[rsi+0x10]
  40c1f4:	call   40d170 <__swc_fn_7069e055_000157_3495a3ca>
  40c1f9:	mov    rcx,rsi
  40c1fc:	call   40f7c0 <__swc_fn_7069e055_000101_afcb7774>
  40c201:	vxorps xmm0,xmm0,xmm0
  40c205:	xor    eax,eax
  40c207:	cs nop WORD PTR [rax+rax*1+0x0]
  40c211:	cs nop WORD PTR [rax+rax*1+0x0]
  40c21b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c220:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c225:	add    rax,0x10
  40c229:	cmp    rax,0xbf0
  40c230:	jne    40c220 <__swc_fn_7069e055_000094_383a814c+0x80>
  40c232:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c238:	vmovups XMMWORD PTR [rsi],xmm0
  40c23c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c242:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c24a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c251:	mov    QWORD PTR [rsi+0xbe8],r12
  40c258:	mov    rcx,QWORD PTR [rip+0x1aae1]        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40c25f:	test   rcx,rcx
  40c262:	jne    40c274 <__swc_fn_7069e055_000094_383a814c+0xd4>
  40c264:	call   40a1a0 <__swc_fn_7069e055_000165_56054fe7>
  40c269:	lea    rcx,[rax+0x1]
  40c26d:	mov    QWORD PTR [rip+0x1aacc],rcx        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40c274:	dec    rcx
  40c277:	call   411f00 <__swc_fn_7069e055_000167_39c041ad>
  40c27c:	mov    rsi,rax
  40c27f:	mov    QWORD PTR [rsi+0xc0],rbx
  40c286:	and    ebx,0x1
  40c289:	jne    40c28d <__swc_fn_7069e055_000094_383a814c+0xed>
  40c28b:	xor    eax,eax
  40c28d:	test   rbx,rbx
  40c290:	sete   al
  40c293:	xor    cl,cl
  40c295:	xor    dl,dl
  40c297:	xor    r8b,r8b
  40c29a:	xor    r9b,r9b
  40c29d:	xor    r10b,r10b
  40c2a0:	mov    r11,rax
  40c2a3:	call   40f010 <__swc_fn_7069e055_000077_948ef603>
  40c2a8:	lea    rbx,[rsp+0x18]
  40c2ad:	mov    rcx,rbx
  40c2b0:	call   40f650 <__swc_fn_7069e055_000092_809deff5>
  40c2b5:	lea    rcx,[rsi+0x10]
  40c2b9:	mov    edx,0x400000
  40c2be:	mov    r8,rbx
  40c2c1:	call   409ee0 <__swc_fn_7069e055_000159_6861d596>
  40c2c6:	lea    rcx,[rsi+0x68]
  40c2ca:	mov    edx,0x4000
  40c2cf:	mov    r8,rbx
  40c2d2:	call   409ee0 <__swc_fn_7069e055_000159_6861d596>
  40c2d7:	add    rsp,0x28
  40c2db:	pop    r12
  40c2dd:	pop    rdi
  40c2de:	pop    rsi
  40c2df:	pop    rbx
  40c2e0:	ret
	...

000000000040c2f0 <__swc_fn_7069e055_000097_96d6739a>:
  40c2f0:	push   rbx
  40c2f1:	push   rsi
  40c2f2:	sub    rsp,0x18
  40c2f6:	mov    rbx,rcx
  40c2f9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c2fe:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c304:	mov    rsi,QWORD PTR [rbx+0x70]
  40c308:	lea    rcx,[rcx+0x18]
  40c30c:	call   40d170 <__swc_fn_7069e055_000157_3495a3ca>
  40c311:	lea    rcx,[rsp+0x8]
  40c316:	mov    rdx,rbx
  40c319:	mov    r8d,0x78
  40c31f:	call   408960 <__swc_fn_7069e055_000096_a4baaa40>
  40c324:	mov    rax,rsi
  40c327:	add    rsp,0x18
  40c32b:	pop    rsi
  40c32c:	pop    rbx
  40c32d:	ret
	...

000000000040c330 <__swc_fn_7069e055_000100_5714513e>:
  40c330:	push   rsi
  40c331:	push   rdi
  40c332:	sub    rsp,0x8
  40c336:	cmp    QWORD PTR [rcx],0x0
  40c33a:	jne    40c343 <__swc_fn_7069e055_000100_5714513e+0x13>
  40c33c:	add    rsp,0x8
  40c340:	pop    rdi
  40c341:	pop    rsi
  40c342:	ret
  40c343:	mov    rsi,QWORD PTR [rcx]
  40c346:	mov    rax,QWORD PTR [rcx+0x8]
  40c34a:	test   rax,rax
  40c34d:	je     40c363 <__swc_fn_7069e055_000100_5714513e+0x33>
  40c34f:	test   DWORD PTR [rax+0x28],0x400000
  40c356:	je     40c363 <__swc_fn_7069e055_000100_5714513e+0x33>
  40c358:	mov    rcx,QWORD PTR [rax+0x30]
  40c35c:	test   rcx,rcx
  40c35f:	cmovne rax,rcx
  40c363:	lea    rdx,[rip+0x6e66]        # 4131d0 <__swc_rdata_base_7069e055+0xc0>
  40c36a:	lea    rcx,[rip+0x6f47]        # 4132b8 <__swc_rdata_base_7069e055+0x1a8>
  40c371:	mov    r8,rax
  40c374:	xor    r9d,r9d
  40c377:	xor    al,al
  40c379:	mov    r10,rax
  40c37c:	xor    r11d,r11d
  40c37f:	call   40c130 <__swc_fn_7069e055_000088_ab2f35d8>
  40c384:	test   rax,rax
  40c387:	je     40c397 <__swc_fn_7069e055_000100_5714513e+0x67>
  40c389:	mov    rdi,QWORD PTR [rax+0x48]
  40c38d:	test   rdi,rdi
  40c390:	je     40c397 <__swc_fn_7069e055_000100_5714513e+0x67>
  40c392:	mov    rcx,rsi
  40c395:	call   rdi
  40c397:	add    rsp,0x8
  40c39b:	pop    rdi
  40c39c:	pop    rsi
  40c39d:	ret
	...

000000000040c3a0 <__swc_fn_7069e055_000103_0d4cc079>:
  40c3a0:	push   rbx
  40c3a1:	push   rsi
  40c3a2:	push   rdi
  40c3a3:	sub    rsp,0x20
  40c3a7:	mov    rbx,rdx
  40c3aa:	mov    rsi,rcx
  40c3ad:	mov    rcx,QWORD PTR [rip+0x1a98c]        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40c3b4:	test   rcx,rcx
  40c3b7:	jne    40c3c9 <__swc_fn_7069e055_000103_0d4cc079+0x29>
  40c3b9:	call   40a1a0 <__swc_fn_7069e055_000165_56054fe7>
  40c3be:	lea    rcx,[rax+0x1]
  40c3c2:	mov    QWORD PTR [rip+0x1a977],rcx        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40c3c9:	dec    rcx
  40c3cc:	call   411f00 <__swc_fn_7069e055_000167_39c041ad>
  40c3d1:	mov    rdi,rax
  40c3d4:	mov    rax,QWORD PTR [rdi+0xbd0]
  40c3db:	xor    ecx,ecx
  40c3dd:	test   rax,rax
  40c3e0:	je     40c3e5 <__swc_fn_7069e055_000103_0d4cc079+0x45>
  40c3e2:	mov    rcx,QWORD PTR [rax]
  40c3e5:	call   40a2d0 <__swc_fn_7069e055_000174_02e645b4>
  40c3ea:	lea    rax,[rsp+0x8]
  40c3ef:	lea    rcx,[rdi+0x9c8]
  40c3f6:	mov    QWORD PTR [rsp+0x8],rcx
  40c3fb:	mov    QWORD PTR [rax+0x8],0x40
  40c403:	xor    ecx,ecx
  40c405:	mov    rdx,rax
  40c408:	call   410260 <__swc_fn_7069e055_000119_2d9caf16>
  40c40d:	mov    DWORD PTR [rdi+0xbc8],eax
  40c413:	mov    rdi,QWORD PTR [rdi+0x990]
  40c41a:	test   rdi,rdi
  40c41d:	je     40c427 <__swc_fn_7069e055_000103_0d4cc079+0x87>
  40c41f:	mov    rcx,rsi
  40c422:	mov    rdx,rbx
  40c425:	call   rdi
  40c427:	call   40c150 <__swc_fn_7069e055_000091_f21926ed>
  40c42c:	test   al,al
  40c42e:	je     40c43e <__swc_fn_7069e055_000103_0d4cc079+0x9e>
  40c430:	mov    rcx,rsi
  40c433:	mov    rdx,rbx
  40c436:	xor    r8d,r8d
  40c439:	call   4093e0 <__swc_fn_7069e055_000120_1e032ef6>
  40c43e:	mov    rcx,rsi
  40c441:	mov    rdx,rbx
  40c444:	call   408a60 <__swc_fn_7069e055_000102_14986ec5>
  40c449:	call   40c9d0 <__swc_fn_7069e055_000118_591530fe>
  40c44e:	add    rsp,0x20
  40c452:	pop    rdi
  40c453:	pop    rsi
  40c454:	pop    rbx
  40c455:	ret
	...

000000000040c460 <__swc_fn_7069e055_000106_aba05410>:
  40c460:	test   r8,r8
  40c463:	jne    40c468 <__swc_fn_7069e055_000106_aba05410+0x8>
  40c465:	xor    eax,eax
  40c467:	ret
  40c468:	xor    eax,eax
  40c46a:	nop    WORD PTR [rax+rax*1+0x0]
  40c470:	mov    r9,r8
  40c473:	sub    r9,rax
  40c476:	cmp    r9,0x10
  40c47a:	jb     40c4c4 <__swc_fn_7069e055_000106_aba05410+0x64>
  40c47c:	lea    r9,[rcx+rax*1]
  40c480:	lea    r10,[rdx+rax*1]
  40c484:	vmovups xmm0,XMMWORD PTR [r10]
  40c489:	vmovups xmm1,XMMWORD PTR [r9]
  40c48e:	vpcmpeqb xmm0,xmm1,xmm0
  40c492:	vpmovmskb r9d,xmm0
  40c496:	cmp    r9d,0xffff
  40c49d:	je     40c4be <__swc_fn_7069e055_000106_aba05410+0x5e>
  40c49f:	not    r9d
  40c4a2:	xor    r8d,r8d
  40c4a5:	movzx  r9d,r9w
  40c4a9:	tzcnt  r8d,r9d
  40c4ae:	add    rax,r8
  40c4b1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4b5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4b9:	sub    ecx,eax
  40c4bb:	mov    eax,ecx
  40c4bd:	ret
  40c4be:	lea    rax,[rax+0x10]
  40c4c2:	jmp    40c470 <__swc_fn_7069e055_000106_aba05410+0x10>
  40c4c4:	cmp    r9,0x8
  40c4c8:	jb     40c53b <__swc_fn_7069e055_000106_aba05410+0xdb>
  40c4ca:	lea    r9,[rcx+rax*1]
  40c4ce:	lea    r10,[rdx+rax*1]
  40c4d2:	mov    r9,QWORD PTR [r9]
  40c4d5:	xor    r9,QWORD PTR [r10]
  40c4d8:	test   r9,r9
  40c4db:	je     40c4f9 <__swc_fn_7069e055_000106_aba05410+0x99>
  40c4dd:	xor    r8d,r8d
  40c4e0:	tzcnt  r8,r9
  40c4e5:	shr    r8,0x3
  40c4e9:	add    rax,r8
  40c4ec:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4f0:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4f4:	sub    ecx,eax
  40c4f6:	mov    eax,ecx
  40c4f8:	ret
  40c4f9:	lea    rax,[rax+0x8]
  40c4fd:	cmp    rax,r8
  40c500:	jne    40c505 <__swc_fn_7069e055_000106_aba05410+0xa5>
  40c502:	xor    eax,eax
  40c504:	ret
  40c505:	lea    rax,[r8-0x8]
  40c509:	lea    r8,[rcx+rax*1]
  40c50d:	lea    r9,[rdx+rax*1]
  40c511:	mov    r8,QWORD PTR [r8]
  40c514:	xor    r8,QWORD PTR [r9]
  40c517:	test   r8,r8
  40c51a:	je     40c538 <__swc_fn_7069e055_000106_aba05410+0xd8>
  40c51c:	xor    r9d,r9d
  40c51f:	tzcnt  r9,r8
  40c524:	shr    r9,0x3
  40c528:	add    rax,r9
  40c52b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c52f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c533:	sub    ecx,eax
  40c535:	mov    eax,ecx
  40c537:	ret
  40c538:	xor    eax,eax
  40c53a:	ret
  40c53b:	cmp    r9,0x4
  40c53f:	jb     40c5b2 <__swc_fn_7069e055_000106_aba05410+0x152>
  40c541:	lea    r9,[rcx+rax*1]
  40c545:	lea    r10,[rdx+rax*1]
  40c549:	mov    r9d,DWORD PTR [r9]
  40c54c:	xor    r9d,DWORD PTR [r10]
  40c54f:	test   r9d,r9d
  40c552:	je     40c570 <__swc_fn_7069e055_000106_aba05410+0x110>
  40c554:	xor    r8d,r8d
  40c557:	tzcnt  r8,r9
  40c55c:	shr    r8,0x3
  40c560:	add    rax,r8
  40c563:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c567:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c56b:	sub    ecx,eax
  40c56d:	mov    eax,ecx
  40c56f:	ret
  40c570:	lea    rax,[rax+0x4]
  40c574:	cmp    rax,r8
  40c577:	jne    40c57c <__swc_fn_7069e055_000106_aba05410+0x11c>
  40c579:	xor    eax,eax
  40c57b:	ret
  40c57c:	lea    rax,[r8-0x4]
  40c580:	lea    r8,[rcx+rax*1]
  40c584:	lea    r9,[rdx+rax*1]
  40c588:	mov    r8d,DWORD PTR [r8]
  40c58b:	xor    r8d,DWORD PTR [r9]
  40c58e:	test   r8d,r8d
  40c591:	je     40c5af <__swc_fn_7069e055_000106_aba05410+0x14f>
  40c593:	xor    r9d,r9d
  40c596:	tzcnt  r9,r8
  40c59b:	shr    r9,0x3
  40c59f:	add    rax,r9
  40c5a2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5a6:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5aa:	sub    ecx,eax
  40c5ac:	mov    eax,ecx
  40c5ae:	ret
  40c5af:	xor    eax,eax
  40c5b1:	ret
  40c5b2:	cmp    r9,0x2
  40c5b6:	jb     40c609 <__swc_fn_7069e055_000106_aba05410+0x1a9>
  40c5b8:	lea    r9,[rcx+rax*1]
  40c5bc:	lea    r10,[rdx+rax*1]
  40c5c0:	mov    r9w,WORD PTR [r9]
  40c5c4:	xor    r9w,WORD PTR [r10]
  40c5c8:	test   r9w,r9w
  40c5cc:	je     40c5ee <__swc_fn_7069e055_000106_aba05410+0x18e>
  40c5ce:	xor    r8d,r8d
  40c5d1:	movzx  r9d,r9w
  40c5d5:	tzcnt  r8,r9
  40c5da:	shr    r8,0x3
  40c5de:	add    rax,r8
  40c5e1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5e5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5e9:	sub    ecx,eax
  40c5eb:	mov    eax,ecx
  40c5ed:	ret
  40c5ee:	lea    rax,[rax+0x2]
  40c5f2:	cmp    rax,r8
  40c5f5:	jne    40c5fa <__swc_fn_7069e055_000106_aba05410+0x19a>
  40c5f7:	xor    eax,eax
  40c5f9:	ret
  40c5fa:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40c600:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40c606:	sub    eax,ecx
  40c608:	ret
  40c609:	test   r9,r9
  40c60c:	je     40c61b <__swc_fn_7069e055_000106_aba05410+0x1bb>
  40c60e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c612:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c616:	sub    ecx,eax
  40c618:	mov    eax,ecx
  40c61a:	ret
  40c61b:	xor    eax,eax
  40c61d:	ret
	...

000000000040c620 <__swc_fn_7069e055_000109_9f5af8ae>:
  40c620:	push   r12
  40c622:	push   r13
  40c624:	push   r14
  40c626:	push   rdi
  40c627:	push   rsi
  40c628:	push   r15
  40c62a:	sub    rsp,0xd8
  40c631:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c637:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c63d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c643:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c649:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c64f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c658:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c661:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c66a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c673:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c67c:	mov    r12,rcx
  40c67f:	test   rcx,rcx
  40c682:	je     40c69e <__swc_fn_7069e055_000109_9f5af8ae+0x7e>
  40c684:	mov    eax,r12d
  40c687:	and    eax,0xfff
  40c68d:	setne  al
  40c690:	cmp    r12,0xffffffffffffefff
  40c697:	seta   cl
  40c69a:	or     al,cl
  40c69c:	je     40c6a5 <__swc_fn_7069e055_000109_9f5af8ae+0x85>
  40c69e:	xor    eax,eax
  40c6a0:	jmp    40c73b <__swc_fn_7069e055_000109_9f5af8ae+0x11b>
  40c6a5:	call   409100 <__swc_fn_7069e055_000108_b8f4bd15>
  40c6aa:	mov    r13,rax
  40c6ad:	test   rax,rax
  40c6b0:	jne    40c6b9 <__swc_fn_7069e055_000109_9f5af8ae+0x99>
  40c6b2:	xor    eax,eax
  40c6b4:	jmp    40c73b <__swc_fn_7069e055_000109_9f5af8ae+0x11b>
  40c6b9:	lea    r14,[r12+0x1000]
  40c6c1:	xor    edi,edi
  40c6c3:	mov    rsi,r14
  40c6c6:	xor    edx,edx
  40c6c8:	mov    ecx,0x22
  40c6cd:	mov    eax,0xffffffff
  40c6d2:	movsxd r8,eax
  40c6d5:	xor    r9d,r9d
  40c6d8:	xor    eax,eax
  40c6da:	call   4070c0 <mmap@plt>
  40c6df:	mov    r15,rax
  40c6e2:	cmp    rax,0xffffffffffffffff
  40c6e6:	jne    40c6ec <__swc_fn_7069e055_000109_9f5af8ae+0xcc>
  40c6e8:	xor    eax,eax
  40c6ea:	jmp    40c73b <__swc_fn_7069e055_000109_9f5af8ae+0x11b>
  40c6ec:	mov    rdi,r15
  40c6ef:	mov    esi,0x1000
  40c6f4:	mov    edx,0x3
  40c6f9:	xor    eax,eax
  40c6fb:	call   407030 <mprotect@plt>
  40c700:	test   eax,eax
  40c702:	je     40c715 <__swc_fn_7069e055_000109_9f5af8ae+0xf5>
  40c704:	mov    rdi,r15
  40c707:	mov    rsi,r14
  40c70a:	xor    eax,eax
  40c70c:	call   407020 <munmap@plt>
  40c711:	xor    eax,eax
  40c713:	jmp    40c73b <__swc_fn_7069e055_000109_9f5af8ae+0x11b>
  40c715:	mov    QWORD PTR [r15+0x8],r12
  40c719:	mov    rcx,r13
  40c71c:	call   40cd70 <__swc_fn_7069e055_000133_807fd51d>
  40c721:	mov    rax,QWORD PTR [r13+0x8]
  40c725:	mov    QWORD PTR [r15],rax
  40c728:	mov    QWORD PTR [r13+0x8],r15
  40c72c:	mov    rcx,r13
  40c72f:	call   410600 <__swc_fn_7069e055_000134_10472836>
  40c734:	lea    rax,[r15+0x1000]
  40c73b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c741:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c747:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c74d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c753:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c759:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c762:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c76b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c774:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c77d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c786:	add    rsp,0xd8
  40c78d:	pop    r15
  40c78f:	pop    rsi
  40c790:	pop    rdi
  40c791:	pop    r14
  40c793:	pop    r13
  40c795:	pop    r12
  40c797:	ret
	...

000000000040c7a0 <__swc_fn_7069e055_000112_2f7f9346>:
  40c7a0:	push   rbx
  40c7a1:	push   r12
  40c7a3:	push   rdi
  40c7a4:	push   rsi
  40c7a5:	sub    rsp,0xa8
  40c7ac:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c7b2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c7b8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c7be:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c7c4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c7ca:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c7d0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c7d6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c7dc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c7e5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c7ee:	mov    rbx,rdx
  40c7f1:	mov    r12,rcx
  40c7f4:	mov    rdi,rcx
  40c7f7:	mov    rsi,rdx
  40c7fa:	xor    edx,edx
  40c7fc:	xor    eax,eax
  40c7fe:	call   407030 <mprotect@plt>
  40c803:	test   eax,eax
  40c805:	jne    40c829 <__swc_fn_7069e055_000112_2f7f9346+0x89>
  40c807:	mov    rcx,r12
  40c80a:	mov    rdx,rbx
  40c80d:	xor    al,al
  40c80f:	mov    r8,rax
  40c812:	call   4100a0 <__swc_fn_7069e055_000110_918d5a21>
  40c817:	mov    rdi,r12
  40c81a:	mov    rsi,rbx
  40c81d:	mov    edx,0x4
  40c822:	xor    eax,eax
  40c824:	call   4070f0 <madvise@plt>
  40c829:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c82f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c835:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c83b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40c841:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40c847:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40c84d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40c853:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40c859:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40c862:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40c86b:	add    rsp,0xa8
  40c872:	pop    rsi
  40c873:	pop    rdi
  40c874:	pop    r12
  40c876:	pop    rbx
  40c877:	ret
	...

000000000040c880 <__swc_fn_7069e055_000115_3f6af4b1>:
  40c880:	push   rsi
  40c881:	push   rdi
  40c882:	push   r12
  40c884:	push   r13
  40c886:	push   r14
  40c888:	sub    rsp,0xe0
  40c88f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c895:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c89b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c8a1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c8a7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c8ad:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c8b6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c8bf:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c8c8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c8d1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c8da:	mov    rsi,rdx
  40c8dd:	mov    rdi,rcx
  40c8e0:	call   409100 <__swc_fn_7069e055_000108_b8f4bd15>
  40c8e5:	mov    r12,rax
  40c8e8:	test   rax,rax
  40c8eb:	jne    40c8f2 <__swc_fn_7069e055_000115_3f6af4b1+0x72>
  40c8ed:	jmp    40c966 <__swc_fn_7069e055_000115_3f6af4b1+0xe6>
  40c8f2:	mov    rcx,r12
  40c8f5:	call   40cd70 <__swc_fn_7069e055_000133_807fd51d>
  40c8fa:	lea    r13,[r12+0x8]
  40c8ff:	mov    rax,QWORD PTR [r13+0x0]
  40c903:	test   rax,rax
  40c906:	je     40c95e <__swc_fn_7069e055_000115_3f6af4b1+0xde>
  40c908:	nop    DWORD PTR [rax+rax*1+0x0]
  40c910:	lea    rcx,[rax+0x1000]
  40c917:	cmp    rcx,rdi
  40c91a:	jne    40c952 <__swc_fn_7069e055_000115_3f6af4b1+0xd2>
  40c91c:	cmp    QWORD PTR [rax+0x8],rsi
  40c920:	je     40c92c <__swc_fn_7069e055_000115_3f6af4b1+0xac>
  40c922:	mov    rcx,r12
  40c925:	call   410600 <__swc_fn_7069e055_000134_10472836>
  40c92a:	jmp    40c966 <__swc_fn_7069e055_000115_3f6af4b1+0xe6>
  40c92c:	mov    r14,QWORD PTR [rax]
  40c92f:	mov    rdi,rax
  40c932:	lea    rsi,[rsi+0x1000]
  40c939:	xor    eax,eax
  40c93b:	call   407020 <munmap@plt>
  40c940:	test   eax,eax
  40c942:	jne    40c948 <__swc_fn_7069e055_000115_3f6af4b1+0xc8>
  40c944:	mov    QWORD PTR [r13+0x0],r14
  40c948:	mov    rcx,r12
  40c94b:	call   410600 <__swc_fn_7069e055_000134_10472836>
  40c950:	jmp    40c966 <__swc_fn_7069e055_000115_3f6af4b1+0xe6>
  40c952:	mov    r13,rax
  40c955:	mov    rax,QWORD PTR [r13+0x0]
  40c959:	test   rax,rax
  40c95c:	jne    40c910 <__swc_fn_7069e055_000115_3f6af4b1+0x90>
  40c95e:	mov    rcx,r12
  40c961:	call   410600 <__swc_fn_7069e055_000134_10472836>
  40c966:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c96c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c972:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c978:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c97e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c984:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c98d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c996:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c99f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c9a8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c9b1:	add    rsp,0xe0
  40c9b8:	pop    r14
  40c9ba:	pop    r13
  40c9bc:	pop    r12
  40c9be:	pop    rdi
  40c9bf:	pop    rsi
  40c9c0:	ret
	...

000000000040c9d0 <__swc_fn_7069e055_000118_591530fe>:
  40c9d0:	push   rdi
  40c9d1:	push   rsi
  40c9d2:	sub    rsp,0xa8
  40c9d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c9df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c9e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c9eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c9f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c9f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c9fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ca03:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ca09:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ca12:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ca1b:	mov    rdi,0xfffffffffffffd66
  40ca22:	xor    eax,eax
  40ca24:	call   407040 <exit@plt>
  40ca29:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ca2f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ca35:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ca3b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ca41:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ca47:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ca4d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ca53:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ca59:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ca62:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ca6b:	add    rsp,0xa8
  40ca72:	pop    rsi
  40ca73:	pop    rdi
  40ca74:	ret
	...

000000000040ca80 <__swc_fn_7069e055_000121_1c5e75b6>:
  40ca80:	push   rbx
  40ca81:	push   rsi
  40ca82:	push   rdi
  40ca83:	sub    rsp,0x30
  40ca87:	mov    rbx,rdx
  40ca8a:	mov    esi,ecx
  40ca8c:	test   ecx,ecx
  40ca8e:	je     40cb63 <__swc_fn_7069e055_000121_1c5e75b6+0xe3>
  40ca94:	mov    rcx,rsi
  40ca97:	shl    rcx,0x4
  40ca9b:	call   40bf90 <__swc_fn_7069e055_000079_633af784>
  40caa0:	test   rax,rax
  40caa3:	je     40cb52 <__swc_fn_7069e055_000121_1c5e75b6+0xd2>
  40caa9:	mov    rcx,rsi
  40caac:	xor    edx,edx
  40caae:	test   rsi,rsi
  40cab1:	jbe    40cb32 <__swc_fn_7069e055_000121_1c5e75b6+0xb2>
  40cab7:	nop    WORD PTR [rax+rax*1+0x0]
  40cac0:	mov    r8d,edx
  40cac3:	mov    r9,QWORD PTR [rbx+r8*8]
  40cac7:	add    r8,r8
  40caca:	lea    r8,[rax+r8*8]
  40cace:	xor    r10d,r10d
  40cad1:	test   r9,r9
  40cad4:	je     40cb10 <__swc_fn_7069e055_000121_1c5e75b6+0x90>
  40cad6:	mov    r11,r9
  40cad9:	mov    dil,BYTE PTR [r11]
  40cadc:	test   dil,dil
  40cadf:	je     40cb10 <__swc_fn_7069e055_000121_1c5e75b6+0x90>
  40cae1:	cs nop WORD PTR [rax+rax*1+0x0]
  40caeb:	cs nop WORD PTR [rax+rax*1+0x0]
  40caf5:	cs nop WORD PTR [rax+rax*1+0x0]
  40caff:	nop
  40cb00:	add    r11,0x1
  40cb04:	add    r10,0x1
  40cb08:	mov    dil,BYTE PTR [r11]
  40cb0b:	test   dil,dil
  40cb0e:	jne    40cb00 <__swc_fn_7069e055_000121_1c5e75b6+0x80>
  40cb10:	mov    QWORD PTR [rsp+0x18],r9
  40cb15:	mov    QWORD PTR [rsp+0x20],r10
  40cb1a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40cb20:	vmovups XMMWORD PTR [r8],xmm0
  40cb25:	add    rdx,0x1
  40cb29:	cmp    rdx,rcx
  40cb2c:	jb     40cac0 <__swc_fn_7069e055_000121_1c5e75b6+0x40>
  40cb32:	lea    rcx,[rip+0x1a217]        # 426d50 <__swc_bss_base_7069e055+0x2d10>
  40cb39:	mov    QWORD PTR [rsp+0x8],rax
  40cb3e:	mov    esi,esi
  40cb40:	mov    QWORD PTR [rsp+0x10],rsi
  40cb45:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40cb4b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cb50:	jmp    40cb63 <__swc_fn_7069e055_000121_1c5e75b6+0xe3>
  40cb52:	lea    rcx,[rip+0x69c7]        # 413520 <__swc_rdata_base_7069e055+0x410>
  40cb59:	call   410150 <__swc_fn_7069e055_000116_3f5cfdef>
  40cb5e:	call   40c9d0 <__swc_fn_7069e055_000118_591530fe>
  40cb63:	add    rsp,0x30
  40cb67:	pop    rdi
  40cb68:	pop    rsi
  40cb69:	pop    rbx
  40cb6a:	ret
  40cb6b:	add    BYTE PTR [rax],al
  40cb6d:	add    BYTE PTR [rax],al
	...

000000000040cb70 <__swc_fn_7069e055_000124_37eaf452>:
  40cb70:	push   rdi
  40cb71:	push   rsi
  40cb72:	sub    rsp,0xa8
  40cb79:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cb7f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cb85:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cb8b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cb91:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cb97:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cb9d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cba3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cba9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cbb2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cbbb:	mov    edi,ecx
  40cbbd:	xor    eax,eax
  40cbbf:	call   407100 <pthread_key_delete@plt>
  40cbc4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cbca:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cbd0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cbd6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cbdc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cbe2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cbe8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cbee:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cbf4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cbfd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cc06:	add    rsp,0xa8
  40cc0d:	pop    rsi
  40cc0e:	pop    rdi
  40cc0f:	ret

000000000040cc10 <__swc_fn_7069e055_000127_f163135d>:
  40cc10:	push   rdi
  40cc11:	push   rsi
  40cc12:	sub    rsp,0xa8
  40cc19:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cc1f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cc25:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cc2b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cc31:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cc37:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cc3d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cc43:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cc49:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cc52:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cc5b:	test   rcx,rcx
  40cc5e:	je     40cc6f <__swc_fn_7069e055_000127_f163135d+0x5f>
  40cc60:	lea    rax,[rcx-0x1]
  40cc64:	mov    eax,eax
  40cc66:	mov    edi,eax
  40cc68:	xor    eax,eax
  40cc6a:	call   407100 <pthread_key_delete@plt>
  40cc6f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cc75:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cc7b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cc81:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cc87:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cc8d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cc93:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cc99:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cc9f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cca8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ccb1:	add    rsp,0xa8
  40ccb8:	pop    rsi
  40ccb9:	pop    rdi
  40ccba:	ret
  40ccbb:	add    BYTE PTR [rax],al
  40ccbd:	add    BYTE PTR [rax],al
	...

000000000040ccc0 <__swc_fn_7069e055_000130_375c7357>:
  40ccc0:	push   rsi
  40ccc1:	push   rdi
  40ccc2:	sub    rsp,0xa8
  40ccc9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cccf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ccd5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ccdb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cce1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cce7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cced:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ccf3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ccf9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cd02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cd0b:	xor    eax,eax
  40cd0d:	call   407110 <gettid@plt>
  40cd12:	movsxd rax,eax
  40cd15:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cd1b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cd21:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cd27:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cd2d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cd33:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cd39:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cd3f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cd45:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cd4e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cd57:	add    rsp,0xa8
  40cd5e:	pop    rdi
  40cd5f:	pop    rsi
  40cd60:	ret
	...

000000000040cd70 <__swc_fn_7069e055_000133_807fd51d>:
  40cd70:	push   rbx
  40cd71:	push   rdi
  40cd72:	push   rsi
  40cd73:	sub    rsp,0xc0
  40cd7a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40cd80:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40cd86:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cd8c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40cd92:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40cd98:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cd9e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cda4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cdad:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40cdb6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cdbf:	mov    rbx,rcx
  40cdc2:	cs nop WORD PTR [rax+rax*1+0x0]
  40cdcc:	nop    DWORD PTR [rax+0x0]
  40cdd0:	mov    edx,0x80000000
  40cdd5:	xor    eax,eax
  40cdd7:	lock cmpxchg DWORD PTR [rbx],edx
  40cddb:	test   eax,eax
  40cddd:	je     40ce14 <__swc_fn_7069e055_000133_807fd51d+0xa4>
  40cddf:	mov    eax,DWORD PTR [rbx]
  40cde1:	lea    rcx,[rsp+0x14]
  40cde6:	mov    DWORD PTR [rsp+0x14],eax
  40cdea:	test   eax,eax
  40cdec:	je     40cdd0 <__swc_fn_7069e055_000133_807fd51d+0x60>
  40cdee:	mov    QWORD PTR [rsp],0x0
  40cdf6:	mov    edi,0xca
  40cdfb:	mov    rsi,rbx
  40cdfe:	mov    edx,0x80
  40ce03:	mov    ecx,DWORD PTR [rcx]
  40ce05:	xor    r8d,r8d
  40ce08:	xor    r9d,r9d
  40ce0b:	xor    eax,eax
  40ce0d:	call   407070 <syscall@plt>
  40ce12:	jmp    40cdd0 <__swc_fn_7069e055_000133_807fd51d+0x60>
  40ce14:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ce1a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ce20:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ce26:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ce2c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ce32:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ce38:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ce3e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ce47:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ce50:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ce59:	add    rsp,0xc0
  40ce60:	pop    rsi
  40ce61:	pop    rdi
  40ce62:	pop    rbx
  40ce63:	ret
	...

000000000040ce70 <__swc_fn_7069e055_000136_d579ef75>:
  40ce70:	sub    rsp,0x8
  40ce74:	call   410600 <__swc_fn_7069e055_000134_10472836>
  40ce79:	add    rsp,0x8
  40ce7d:	ret
	...

000000000040ce80 <__swc_fn_7069e055_000139_e4a7a8b1>:
  40ce80:	push   rdi
  40ce81:	push   rsi
  40ce82:	sub    rsp,0xa8
  40ce89:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ce8f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ce95:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ce9b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cea1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cea7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cead:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ceb3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ceb9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cec2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cecb:	mov    edi,0x28
  40ced0:	xor    eax,eax
  40ced2:	call   4070d0 <malloc@plt>
  40ced7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cedd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cee3:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cee9:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ceef:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cef5:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cefb:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cf01:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cf07:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cf10:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cf19:	add    rsp,0xa8
  40cf20:	pop    rsi
  40cf21:	pop    rdi
  40cf22:	ret
	...

000000000040cf30 <__swc_fn_7069e055_000142_89a6ef72>:
  40cf30:	mov    QWORD PTR [r8],0x0
  40cf37:	cmp    rdx,0x10
  40cf3b:	jae    40cf40 <__swc_fn_7069e055_000142_89a6ef72+0x10>
  40cf3d:	xor    eax,eax
  40cf3f:	ret
  40cf40:	mov    eax,DWORD PTR [rcx]
  40cf42:	cmp    eax,0x42445753
  40cf48:	jne    40cf52 <__swc_fn_7069e055_000142_89a6ef72+0x22>
  40cf4a:	mov    eax,DWORD PTR [rcx+0x4]
  40cf4d:	cmp    eax,0x1
  40cf50:	je     40cf55 <__swc_fn_7069e055_000142_89a6ef72+0x25>
  40cf52:	xor    eax,eax
  40cf54:	ret
  40cf55:	mov    QWORD PTR [r8],rdx
  40cf58:	mov    rax,rcx
  40cf5b:	ret
  40cf5c:	add    BYTE PTR [rax],al
	...

000000000040cf60 <__swc_fn_7069e055_000145_32a1d6a2>:
  40cf60:	push   rbx
  40cf61:	sub    rsp,0xe0
  40cf68:	lea    rbx,[rsp+0x8]
  40cf6d:	vxorps xmm0,xmm0,xmm0
  40cf71:	vmovups YMMWORD PTR [rbx],ymm0
  40cf75:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40cf7a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40cf7f:	vzeroupper
  40cf82:	mov    DWORD PTR [rbx+0x60],0x0
  40cf89:	mov    r8,rbx
  40cf8c:	mov    rdx,rcx
  40cf8f:	nop
  40cf90:	mov    r9,rdx
  40cf93:	movabs rdx,0x6666666666666667
  40cf9d:	mov    rax,r9
  40cfa0:	imul   rdx
  40cfa3:	sar    rdx,0x2
  40cfa7:	mov    r10,rdx
  40cfaa:	shr    rdx,0x3f
  40cfae:	add    r10,rdx
  40cfb1:	mov    rdx,r10
  40cfb4:	imul   r11,r10,0xa
  40cfb8:	sub    r9,r11
  40cfbb:	mov    r11,QWORD PTR [rip+0x657e]        # 413540 <__swc_rdata_base_7069e055+0x430>
  40cfc2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40cfc7:	mov    BYTE PTR [r8],r9b
  40cfca:	lea    r9,[r8+0x1]
  40cfce:	mov    r8,r9
  40cfd1:	test   r10,r10
  40cfd4:	jne    40cf90 <__swc_fn_7069e055_000145_32a1d6a2+0x30>
  40cfd6:	test   rcx,rcx
  40cfd9:	jge    40cfe3 <__swc_fn_7069e055_000145_32a1d6a2+0x83>
  40cfdb:	mov    BYTE PTR [r9],0x2d
  40cfdf:	add    r8,0x1
  40cfe3:	mov    BYTE PTR [r8],0x0
  40cfe7:	sub    r8,0x1
  40cfeb:	mov    rax,rbx
  40cfee:	cmp    rax,r8
  40cff1:	jae    40d016 <__swc_fn_7069e055_000145_32a1d6a2+0xb6>
  40cff3:	cs nop WORD PTR [rax+rax*1+0x0]
  40cffd:	nop    DWORD PTR [rax]
  40d000:	mov    cl,BYTE PTR [r8]
  40d003:	mov    dl,BYTE PTR [rax]
  40d005:	mov    BYTE PTR [r8],dl
  40d008:	sub    r8,0x1
  40d00c:	mov    BYTE PTR [rax],cl
  40d00e:	inc    rax
  40d011:	cmp    rax,r8
  40d014:	jb     40d000 <__swc_fn_7069e055_000145_32a1d6a2+0xa0>
  40d016:	xor    eax,eax
  40d018:	test   rbx,rbx
  40d01b:	je     40d03e <__swc_fn_7069e055_000145_32a1d6a2+0xde>
  40d01d:	mov    rcx,rbx
  40d020:	mov    dl,BYTE PTR [rcx]
  40d022:	test   dl,dl
  40d024:	je     40d03e <__swc_fn_7069e055_000145_32a1d6a2+0xde>
  40d026:	cs nop WORD PTR [rax+rax*1+0x0]
  40d030:	add    rcx,0x1
  40d034:	add    rax,0x1
  40d038:	mov    dl,BYTE PTR [rcx]
  40d03a:	test   dl,dl
  40d03c:	jne    40d030 <__swc_fn_7069e055_000145_32a1d6a2+0xd0>
  40d03e:	mov    QWORD PTR [rbx+0xa8],rbx
  40d045:	mov    QWORD PTR [rbx+0xb0],rax
  40d04c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d054:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d05c:	lea    rcx,[rbx+0xb8]
  40d063:	call   410150 <__swc_fn_7069e055_000116_3f5cfdef>
  40d068:	add    rsp,0xe0
  40d06f:	pop    rbx
  40d070:	ret
	...

000000000040d080 <__swc_fn_7069e055_000148_365b4daf>:
  40d080:	vxorps xmm0,xmm0,xmm0
  40d084:	vmovups XMMWORD PTR [rcx],xmm0
  40d088:	mov    QWORD PTR [rcx+0x10],0x0
  40d090:	ret
	...

000000000040d0a0 <__swc_fn_7069e055_000151_365b4daf>:
  40d0a0:	vxorps xmm0,xmm0,xmm0
  40d0a4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0ad:	vxorps xmm0,xmm0,xmm0
  40d0b1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0b6:	vmovups xmm0,XMMWORD PTR [rip+0x657a]        # 413638 <__swc_rdata_base_7069e055+0x528>
  40d0be:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d0c3:	vxorps xmm0,xmm0,xmm0
  40d0c7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d0cc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d0d1:	mov    QWORD PTR [rcx+0x60],0x0
  40d0d9:	ret
  40d0da:	add    BYTE PTR [rax],al
  40d0dc:	add    BYTE PTR [rax],al
	...

000000000040d0e0 <__swc_fn_7069e055_000154_365b4daf>:
  40d0e0:	vxorps xmm0,xmm0,xmm0
  40d0e4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0ed:	vxorps xmm0,xmm0,xmm0
  40d0f1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0f6:	vmovups xmm0,XMMWORD PTR [rip+0x6662]        # 413760 <__swc_rdata_base_7069e055+0x650>
  40d0fe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d103:	vxorps xmm0,xmm0,xmm0
  40d107:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d10c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d111:	vxorps xmm0,xmm0,xmm0
  40d115:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d11a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d11f:	vxorps xmm0,xmm0,xmm0
  40d123:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d12b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d133:	vxorps xmm0,xmm0,xmm0
  40d137:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d13f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d147:	vxorps xmm0,xmm0,xmm0
  40d14b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d153:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d15b:	mov    QWORD PTR [rcx+0xe0],0x0
  40d166:	ret
	...

000000000040d170 <__swc_fn_7069e055_000157_3495a3ca>:
  40d170:	push   rbx
  40d171:	mov    rbx,rcx
  40d174:	call   411b90 <__swc_fn_7069e055_000158_31e09513>
  40d179:	mov    rax,QWORD PTR [rbx+0x10]
  40d17d:	test   rax,rax
  40d180:	je     40d191 <__swc_fn_7069e055_000157_3495a3ca+0x21>
  40d182:	mov    rcx,rbx
  40d185:	mov    rdx,rax
  40d188:	mov    r8,QWORD PTR [rbx+0x18]
  40d18c:	call   409e90 <__swc_fn_7069e055_000156_9e2052d6>
  40d191:	vxorps xmm0,xmm0,xmm0
  40d195:	vmovups XMMWORD PTR [rbx],xmm0
  40d199:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d19e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d1a3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d1a8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d1ad:	mov    QWORD PTR [rbx+0x50],0x0
  40d1b5:	pop    rbx
  40d1b6:	ret
	...

000000000040d1c0 <__swc_fn_7069e055_000160_dfca9093>:
  40d1c0:	sub    rsp,0x10
  40d1c4:	mov    eax,r8d
  40d1c7:	mov    r8d,r9d
  40d1ca:	test   r9d,r9d
  40d1cd:	jne    40d1e6 <__swc_fn_7069e055_000160_dfca9093+0x26>
  40d1cf:	vmovups xmm0,XMMWORD PTR [rip+0x6641]        # 413818 <__swc_rdata_base_7069e055+0x708>
  40d1d7:	vmovups XMMWORD PTR [r10],xmm0
  40d1dc:	mov    eax,0x1
  40d1e1:	add    rsp,0x10
  40d1e5:	ret
  40d1e6:	mov    r9,r8
  40d1e9:	cmp    r8,rax
  40d1ec:	jb     40d1f3 <__swc_fn_7069e055_000160_dfca9093+0x33>
  40d1ee:	cmp    r9,rdx
  40d1f1:	jb     40d1fa <__swc_fn_7069e055_000160_dfca9093+0x3a>
  40d1f3:	xor    eax,eax
  40d1f5:	add    rsp,0x10
  40d1f9:	ret
  40d1fa:	xor    eax,eax
  40d1fc:	lea    r8,[r9+rax*1]
  40d200:	cmp    r8,rdx
  40d203:	jae    40d233 <__swc_fn_7069e055_000160_dfca9093+0x73>
  40d205:	cs nop WORD PTR [rax+rax*1+0x0]
  40d20f:	cs nop WORD PTR [rax+rax*1+0x0]
  40d219:	nop    DWORD PTR [rax+0x0]
  40d220:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d225:	je     40d233 <__swc_fn_7069e055_000160_dfca9093+0x73>
  40d227:	inc    rax
  40d22a:	lea    r8,[r9+rax*1]
  40d22e:	cmp    r8,rdx
  40d231:	jb     40d220 <__swc_fn_7069e055_000160_dfca9093+0x60>
  40d233:	cmp    r8,rdx
  40d236:	jne    40d23f <__swc_fn_7069e055_000160_dfca9093+0x7f>
  40d238:	xor    eax,eax
  40d23a:	add    rsp,0x10
  40d23e:	ret
  40d23f:	add    rcx,r9
  40d242:	mov    QWORD PTR [rsp],rcx
  40d246:	mov    QWORD PTR [rsp+0x8],rax
  40d24b:	vmovups xmm0,XMMWORD PTR [rsp]
  40d250:	vmovups XMMWORD PTR [r10],xmm0
  40d255:	mov    eax,0x1
  40d25a:	add    rsp,0x10
  40d25e:	ret
	...

000000000040d260 <__swc_fn_7069e055_000163_3a7aae74>:
  40d260:	push   rbp
  40d261:	push   rbx
  40d262:	push   rsi
  40d263:	push   rdi
  40d264:	push   r12
  40d266:	push   r13
  40d268:	push   r14
  40d26a:	push   r15
  40d26c:	sub    rsp,0x10
  40d270:	mov    rbp,rsp
  40d273:	vmovups XMMWORD PTR [rsp],xmm6
  40d278:	sub    rsp,0x50
  40d27c:	mov    rbx,rsp
  40d27f:	mov    rsi,r8
  40d282:	mov    QWORD PTR [rsp+0x30],r8
  40d287:	mov    rdi,rcx
  40d28a:	mov    QWORD PTR [rsp+0x38],rcx
  40d28f:	mov    r12,rdx
  40d292:	xor    r13b,r13b
  40d295:	mov    r14,QWORD PTR [rdi+0x8]
  40d299:	mov    QWORD PTR [rsp+0x40],r14
  40d29e:	xor    r15d,r15d
  40d2a1:	test   r14,r14
  40d2a4:	jbe    40d4fe <__swc_fn_7069e055_000163_3a7aae74+0x29e>
  40d2aa:	mov    r14,QWORD PTR [rdi]
  40d2ad:	mov    rax,QWORD PTR [rsp+0x40]
  40d2b2:	mov    QWORD PTR [rsp+0x48],r14
  40d2b7:	vmovups xmm6,XMMWORD PTR [rip+0x6179]        # 413438 <__swc_rdata_base_7069e055+0x328>
  40d2bf:	nop
  40d2c0:	cmp    QWORD PTR [r14+r15*8],0x0
  40d2c5:	jne    40d2cf <__swc_fn_7069e055_000163_3a7aae74+0x6f>
  40d2c7:	mov    r14,rax
  40d2ca:	jmp    40d4de <__swc_fn_7069e055_000163_3a7aae74+0x27e>
  40d2cf:	mov    rcx,QWORD PTR [rdi]
  40d2d2:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d2d6:	mov    rdi,rbx
  40d2d9:	mov    rcx,rdi
  40d2dc:	sub    rsp,0x8
  40d2e0:	mov    r14,rax
  40d2e3:	call   409f10 <__swc_fn_7069e055_000162_61e293bf>
  40d2e8:	add    rsp,0x8
  40d2ec:	mov    al,BYTE PTR [rbx]
  40d2ee:	test   al,al
  40d2f0:	je     40d4de <__swc_fn_7069e055_000163_3a7aae74+0x27e>
  40d2f6:	mov    al,BYTE PTR [rbx+0x1]
  40d2f9:	test   al,al
  40d2fb:	jne    40d306 <__swc_fn_7069e055_000163_3a7aae74+0xa6>
  40d2fd:	test   sil,sil
  40d300:	je     40d4de <__swc_fn_7069e055_000163_3a7aae74+0x27e>
  40d306:	test   r13b,r13b
  40d309:	jne    40d3c7 <__swc_fn_7069e055_000163_3a7aae74+0x167>
  40d30f:	test   r12,r12
  40d312:	je     40d3c7 <__swc_fn_7069e055_000163_3a7aae74+0x167>
  40d318:	mov    al,BYTE PTR [rbx+0x1]
  40d31b:	test   al,al
  40d31d:	je     40d4de <__swc_fn_7069e055_000163_3a7aae74+0x27e>
  40d323:	mov    eax,DWORD PTR [rbx+0x28]
  40d326:	cmp    DWORD PTR [r12+0x20],eax
  40d32b:	jne    40d4de <__swc_fn_7069e055_000163_3a7aae74+0x27e>
  40d331:	mov    rax,QWORD PTR [r12]
  40d335:	mov    rcx,QWORD PTR [r12+0x8]
  40d33a:	cmp    QWORD PTR [rbx+0x20],rcx
  40d33e:	jne    40d4de <__swc_fn_7069e055_000163_3a7aae74+0x27e>
  40d344:	mov    cl,0x1
  40d346:	test   rax,rax
  40d349:	je     40d3b2 <__swc_fn_7069e055_000163_3a7aae74+0x152>
  40d34f:	mov    rdx,QWORD PTR [rbx+0x20]
  40d353:	xor    r8d,r8d
  40d356:	test   rdx,rdx
  40d359:	jbe    40d3b2 <__swc_fn_7069e055_000163_3a7aae74+0x152>
  40d35b:	mov    r9,QWORD PTR [rbx+0x18]
  40d35f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40d364:	cs nop WORD PTR [rax+rax*1+0x0]
  40d36e:	xchg   ax,ax
  40d370:	mov    r10b,BYTE PTR [rax+r8*1]
  40d374:	cmp    BYTE PTR [r9+r8*1],r10b
  40d378:	je     40d3a9 <__swc_fn_7069e055_000163_3a7aae74+0x149>
  40d37a:	vmovq  r10,xmm0
  40d37f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40d384:	jne    40d38d <__swc_fn_7069e055_000163_3a7aae74+0x12d>
  40d386:	cmp    BYTE PTR [rax+r8*1],0x2f
  40d38b:	je     40d3a9 <__swc_fn_7069e055_000163_3a7aae74+0x149>
  40d38d:	vmovq  r10,xmm0
  40d392:	cmp    BYTE PTR [r10+r8*1],0x2f
  40d397:	jne    40d3a0 <__swc_fn_7069e055_000163_3a7aae74+0x140>
  40d399:	cmp    BYTE PTR [rax+r8*1],0x5c
  40d39e:	je     40d3a9 <__swc_fn_7069e055_000163_3a7aae74+0x149>
  40d3a0:	xor    eax,eax
  40d3a2:	movzx  eax,al
  40d3a5:	mov    cl,al
  40d3a7:	jmp    40d3b2 <__swc_fn_7069e055_000163_3a7aae74+0x152>
  40d3a9:	add    r8,0x1
  40d3ad:	cmp    r8,rdx
  40d3b0:	jb     40d370 <__swc_fn_7069e055_000163_3a7aae74+0x110>
  40d3b2:	test   cl,cl
  40d3b4:	je     40d4de <__swc_fn_7069e055_000163_3a7aae74+0x27e>
  40d3ba:	mov    eax,0x1
  40d3bf:	mov    r13b,al
  40d3c2:	jmp    40d4de <__swc_fn_7069e055_000163_3a7aae74+0x27e>
  40d3c7:	mov    r13b,0x1
  40d3ca:	sub    rsp,0x20
  40d3ce:	mov    rax,rsp
  40d3d1:	lea    rcx,[rdi+0x8]
  40d3d5:	mov    QWORD PTR [rax],rcx
  40d3d8:	lea    rsi,[rip+0x5f31]        # 413310 <__swc_rdata_base_7069e055+0x200>
  40d3df:	mov    QWORD PTR [rax+0x8],rsi
  40d3e3:	mov    QWORD PTR [rax+0x10],rsp
  40d3e7:	mov    QWORD PTR [rax+0x18],0x1
  40d3ef:	lea    rcx,[rsp+0x10]
  40d3f4:	sub    rsp,0x8
  40d3f8:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  40d3fd:	add    rsp,0x8
  40d401:	add    rsp,0x20
  40d405:	mov    al,BYTE PTR [rbx+0x1]
  40d408:	test   al,al
  40d40a:	je     40d4a7 <__swc_fn_7069e055_000163_3a7aae74+0x247>
  40d410:	lea    rax,[rip+0x64a1]        # 4138b8 <__swc_rdata_base_7069e055+0x7a8>
  40d417:	sub    rsp,0x20
  40d41b:	mov    rcx,rsp
  40d41e:	mov    QWORD PTR [rcx],rax
  40d421:	mov    QWORD PTR [rcx+0x8],rsi
  40d425:	mov    QWORD PTR [rcx+0x10],rsp
  40d429:	mov    QWORD PTR [rcx+0x18],0x1
  40d431:	lea    rcx,[rsp+0x10]
  40d436:	sub    rsp,0x8
  40d43a:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  40d43f:	add    rsp,0x8
  40d443:	add    rsp,0x20
  40d447:	mov    eax,DWORD PTR [rbx+0x28]
  40d44a:	sub    rsp,0x60
  40d44e:	mov    rcx,rsp
  40d451:	lea    rdx,[rdi+0x18]
  40d455:	mov    QWORD PTR [rcx+0x18],rdx
  40d459:	mov    QWORD PTR [rcx+0x20],rsi
  40d45d:	vmovups XMMWORD PTR [rcx],xmm6
  40d461:	mov    QWORD PTR [rcx+0x28],rsp
  40d465:	mov    QWORD PTR [rcx+0x30],rsi
  40d469:	mov    DWORD PTR [rcx+0x10],eax
  40d46c:	lea    rax,[rsp+0x10]
  40d471:	mov    QWORD PTR [rcx+0x38],rax
  40d475:	lea    rax,[rip+0x5f54]        # 4133d0 <__swc_rdata_base_7069e055+0x2c0>
  40d47c:	mov    QWORD PTR [rcx+0x40],rax
  40d480:	lea    rax,[rsp+0x18]
  40d485:	mov    QWORD PTR [rcx+0x48],rax
  40d489:	mov    QWORD PTR [rcx+0x50],0x3
  40d491:	lea    rcx,[rsp+0x48]
  40d496:	sub    rsp,0x8
  40d49a:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  40d49f:	add    rsp,0x8
  40d4a3:	add    rsp,0x60
  40d4a7:	lea    rax,[rip+0x5eba]        # 413368 <__swc_rdata_base_7069e055+0x258>
  40d4ae:	sub    rsp,0x20
  40d4b2:	mov    rcx,rsp
  40d4b5:	mov    QWORD PTR [rcx],rax
  40d4b8:	mov    QWORD PTR [rcx+0x8],rsi
  40d4bc:	mov    QWORD PTR [rcx+0x10],rsp
  40d4c0:	mov    QWORD PTR [rcx+0x18],0x1
  40d4c8:	lea    rcx,[rsp+0x10]
  40d4cd:	sub    rsp,0x8
  40d4d1:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  40d4d6:	add    rsp,0x8
  40d4da:	add    rsp,0x20
  40d4de:	add    r15,0x1
  40d4e2:	cmp    r15,r14
  40d4e5:	jae    40d4fe <__swc_fn_7069e055_000163_3a7aae74+0x29e>
  40d4e7:	mov    rsi,QWORD PTR [rsp+0x30]
  40d4ec:	mov    rdi,QWORD PTR [rsp+0x38]
  40d4f1:	mov    rax,r14
  40d4f4:	mov    r14,QWORD PTR [rsp+0x48]
  40d4f9:	jmp    40d2c0 <__swc_fn_7069e055_000163_3a7aae74+0x60>
  40d4fe:	add    rsp,0x50
  40d502:	vmovups xmm6,XMMWORD PTR [rsp]
  40d507:	add    rsp,0x10
  40d50b:	pop    r15
  40d50d:	pop    r14
  40d50f:	pop    r13
  40d511:	pop    r12
  40d513:	pop    rdi
  40d514:	pop    rsi
  40d515:	pop    rbx
  40d516:	pop    rbp
  40d517:	ret
	...

000000000040d520 <__swc_fn_7069e055_000166_c370e18e>:
  40d520:	sub    rsp,0x8
  40d524:	call   4103d0 <__swc_fn_7069e055_000125_7a81492f>
  40d529:	add    rsp,0x8
  40d52d:	ret
	...

000000000040d530 <__swc_fn_7069e055_000169_4694b8ad>:
  40d530:	push   rsi
  40d531:	sub    rsp,0x30
  40d535:	lea    rsi,[rip+0x19864]        # 426da0 <__swc_bss_base_7069e055+0x2d60>
  40d53c:	mov    rax,QWORD PTR [rsi]
  40d53f:	test   rax,rax
  40d542:	je     40d54a <__swc_fn_7069e055_000169_4694b8ad+0x1a>
  40d544:	add    rsp,0x30
  40d548:	pop    rsi
  40d549:	ret
  40d54a:	mov    ecx,0x2
  40d54f:	mov    edx,0x8020
  40d554:	call   40fa70 <__swc_fn_7069e055_000107_c8d4a68e>
  40d559:	test   rax,rax
  40d55c:	jne    40d56d <__swc_fn_7069e055_000169_4694b8ad+0x3d>
  40d55e:	mov    QWORD PTR [rsp+0x18],rax
  40d563:	call   40c9d0 <__swc_fn_7069e055_000118_591530fe>
  40d568:	mov    rax,QWORD PTR [rsp+0x18]
  40d56d:	mov    rcx,rax
  40d570:	xchg   QWORD PTR [rsi],rcx
  40d573:	add    rsp,0x30
  40d577:	pop    rsi
  40d578:	ret
  40d579:	add    BYTE PTR [rax],al
  40d57b:	add    BYTE PTR [rax],al
  40d57d:	add    BYTE PTR [rax],al
	...

000000000040d580 <__swc_fn_7069e055_000172_1751ecdd>:
  40d580:	push   rsi
  40d581:	test   r8,r8
  40d584:	jne    40d588 <__swc_fn_7069e055_000172_1751ecdd+0x8>
  40d586:	pop    rsi
  40d587:	ret
  40d588:	lea    rax,[rcx+0x18]
  40d58c:	mov    r10,QWORD PTR [rax]
  40d58f:	lea    r11,[r10+0x1]
  40d593:	mov    QWORD PTR [rax],r11
  40d596:	mov    r11,rdx
  40d599:	not    rdx
  40d59c:	lea    rsi,[r8-0x1]
  40d5a0:	cmp    rsi,rdx
  40d5a3:	ja     40d5c3 <__swc_fn_7069e055_000172_1751ecdd+0x43>
  40d5a5:	lea    rdx,[r11+r8*1]
  40d5a9:	dec    rdx
  40d5ac:	shr    rdx,0x6
  40d5b0:	mov    r8,r11
  40d5b3:	shr    r8,0x6
  40d5b7:	mov    rsi,rdx
  40d5ba:	sub    rsi,r8
  40d5bd:	cmp    rsi,0x8
  40d5c1:	jb     40d5d9 <__swc_fn_7069e055_000172_1751ecdd+0x59>
  40d5c3:	lea    rcx,[rcx+0x10]
  40d5c7:	mov    rdx,QWORD PTR [rcx]
  40d5ca:	add    rdx,r9
  40d5cd:	mov    QWORD PTR [rcx],rdx
  40d5d0:	lea    rcx,[r10+0x2]
  40d5d4:	mov    QWORD PTR [rax],rcx
  40d5d7:	pop    rsi
  40d5d8:	ret
  40d5d9:	shr    r11,0x6
  40d5dd:	nop    DWORD PTR [rax]
  40d5e0:	cmp    r11,rdx
  40d5e3:	ja     40d623 <__swc_fn_7069e055_000172_1751ecdd+0xa3>
  40d5e5:	jmp    40d5f6 <__swc_fn_7069e055_000172_1751ecdd+0x76>
  40d5e7:	nop    WORD PTR [rax+rax*1+0x0]
  40d5f0:	add    r11,0x1
  40d5f4:	jmp    40d5e0 <__swc_fn_7069e055_000172_1751ecdd+0x60>
  40d5f6:	mov    r8,r11
  40d5f9:	shr    r8,0xc
  40d5fd:	mov    rsi,r11
  40d600:	xor    rsi,r8
  40d603:	mov    r8,r11
  40d606:	shr    r8,0x18
  40d60a:	xor    rsi,r8
  40d60d:	and    esi,0xfff
  40d613:	lea    r8,[rcx+rsi*8+0x20]
  40d618:	mov    rsi,QWORD PTR [r8]
  40d61b:	add    rsi,r9
  40d61e:	mov    QWORD PTR [r8],rsi
  40d621:	jmp    40d5f0 <__swc_fn_7069e055_000172_1751ecdd+0x70>
  40d623:	lea    rcx,[r10+0x2]
  40d627:	mov    QWORD PTR [rax],rcx
  40d62a:	pop    rsi
  40d62b:	ret
  40d62c:	add    BYTE PTR [rax],al
	...

000000000040d630 <__swc_fn_7069e055_000175_2744b483>:
  40d630:	push   rbx
  40d631:	sub    rsp,0x70
  40d635:	cmp    rcx,0xffffffffffffffef
  40d639:	jbe    40d643 <__swc_fn_7069e055_000175_2744b483+0x13>
  40d63b:	xor    eax,eax
  40d63d:	add    rsp,0x70
  40d641:	pop    rbx
  40d642:	ret
  40d643:	vxorps xmm0,xmm0,xmm0
  40d647:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40d64d:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40d653:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40d659:	vzeroupper
  40d65c:	lea    rax,[rcx+0x10]
  40d660:	mov    QWORD PTR [rsp+0x50],rax
  40d665:	mov    DWORD PTR [rsp+0x60],0x10
  40d66d:	mov    rcx,QWORD PTR [rip+0x196cc]        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40d674:	test   rcx,rcx
  40d677:	jne    40d689 <__swc_fn_7069e055_000175_2744b483+0x59>
  40d679:	call   40a1a0 <__swc_fn_7069e055_000165_56054fe7>
  40d67e:	lea    rcx,[rax+0x1]
  40d682:	mov    QWORD PTR [rip+0x196b7],rcx        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40d689:	dec    rcx
  40d68c:	call   411f00 <__swc_fn_7069e055_000167_39c041ad>
  40d691:	mov    rcx,QWORD PTR [rax]
  40d694:	lea    rdx,[rsp+0x8]
  40d699:	mov    rbx,QWORD PTR [rax+0x8]
  40d69d:	mov    rbx,QWORD PTR [rbx+0x8]
  40d6a1:	call   rbx
  40d6a3:	mov    rax,QWORD PTR [rsp+0x48]
  40d6a8:	test   rax,rax
  40d6ab:	jne    40d6b5 <__swc_fn_7069e055_000175_2744b483+0x85>
  40d6ad:	xor    eax,eax
  40d6af:	add    rsp,0x70
  40d6b3:	pop    rbx
  40d6b4:	ret
  40d6b5:	mov    rcx,QWORD PTR [rsp+0x50]
  40d6ba:	mov    QWORD PTR [rax],rcx
  40d6bd:	mov    QWORD PTR [rax+0x8],0x0
  40d6c5:	lea    rax,[rax+0x10]
  40d6c9:	add    rsp,0x70
  40d6cd:	pop    rbx
  40d6ce:	ret
	...

000000000040d6e0 <__swc_fn_7069e055_000178_fa681d0f>:
  40d6e0:	push   rbp
  40d6e1:	push   rsi
  40d6e2:	push   r15
  40d6e4:	push   r14
  40d6e6:	push   r13
  40d6e8:	push   rdi
  40d6e9:	push   r12
  40d6eb:	sub    rsp,0x18
  40d6ef:	mov    rbp,rsp
  40d6f2:	vmovups XMMWORD PTR [rsp],xmm6
  40d6f7:	sub    rsp,0x1b0
  40d6fe:	mov    ecx,0x4e2000
  40d703:	sub    rsp,0x8
  40d707:	call   40d630 <__swc_fn_7069e055_000175_2744b483>
  40d70c:	add    rsp,0x8
  40d710:	mov    rsi,rax
  40d713:	xor    ecx,ecx
  40d715:	cs nop WORD PTR [rax+rax*1+0x0]
  40d71f:	nop
  40d720:	lea    r8,[rsi+rcx*8]
  40d724:	mov    r9,QWORD PTR [rip+0x148e5]        # 422010 <__swc_data_base_7069e055+0x10>
  40d72b:	imul   r9,r9,0x41a7
  40d732:	movabs rdx,0x200000005
  40d73c:	mov    r11,rax
  40d73f:	mov    rax,r9
  40d742:	mul    rdx
  40d745:	mov    r10,rdx
  40d748:	mov    rdx,r9
  40d74b:	sub    rdx,r10
  40d74e:	shr    rdx,1
  40d751:	add    rdx,r10
  40d754:	shr    rdx,0x1e
  40d758:	imul   r10,rdx,0x7fffffff
  40d75f:	sub    r9,r10
  40d762:	mov    QWORD PTR [rip+0x148a7],r9        # 422010 <__swc_data_base_7069e055+0x10>
  40d769:	movabs rdx,0xe38e38e38e38e38f
  40d773:	mov    rax,r9
  40d776:	mul    rdx
  40d779:	shr    rdx,0x3
  40d77d:	lea    rdx,[rdx+rdx*8]
  40d781:	sub    r9,rdx
  40d784:	lea    rdx,[r9+0x1]
  40d788:	mov    QWORD PTR [r8],rdx
  40d78b:	add    rcx,0x1
  40d78f:	lea    r8,[rsi+rcx*8]
  40d793:	mov    r9,QWORD PTR [rip+0x14876]        # 422010 <__swc_data_base_7069e055+0x10>
  40d79a:	imul   r9,r9,0x41a7
  40d7a1:	movabs rdx,0x200000005
  40d7ab:	mov    rax,r9
  40d7ae:	mul    rdx
  40d7b1:	mov    r10,rdx
  40d7b4:	mov    rdx,r9
  40d7b7:	sub    rdx,r10
  40d7ba:	shr    rdx,1
  40d7bd:	add    rdx,r10
  40d7c0:	shr    rdx,0x1e
  40d7c4:	imul   rdx,rdx,0x7fffffff
  40d7cb:	sub    r9,rdx
  40d7ce:	mov    QWORD PTR [rip+0x1483b],r9        # 422010 <__swc_data_base_7069e055+0x10>
  40d7d5:	movabs rdx,0xe38e38e38e38e38f
  40d7df:	mov    rax,r9
  40d7e2:	mul    rdx
  40d7e5:	mov    r10,rdx
  40d7e8:	mov    rax,r11
  40d7eb:	shr    r10,0x3
  40d7ef:	lea    rdx,[r10+r10*8]
  40d7f3:	sub    r9,rdx
  40d7f6:	lea    rdx,[r9+0x1]
  40d7fa:	mov    QWORD PTR [r8],rdx
  40d7fd:	add    rcx,0x1
  40d801:	cmp    rcx,0x9c400
  40d808:	jb     40d720 <__swc_fn_7069e055_000178_fa681d0f+0x40>
  40d80e:	sub    rsp,0x8
  40d812:	call   40a350 <__swc_fn_7069e055_000177_1ca87929>
  40d817:	add    rsp,0x8
  40d81b:	vmovups xmm6,xmm0
  40d81f:	mov    ecx,0x4e2000
  40d824:	sub    rsp,0x8
  40d828:	call   40d630 <__swc_fn_7069e055_000175_2744b483>
  40d82d:	add    rsp,0x8
  40d831:	mov    rdi,rax
  40d834:	xor    eax,eax
  40d836:	cs nop WORD PTR [rax+rax*1+0x0]
  40d840:	mov    DWORD PTR [rdi+rax*8],0xffffffff
  40d847:	mov    DWORD PTR [rdi+rax*8+0x4],0xfffffff
  40d84f:	add    rax,0x1
  40d853:	cmp    rax,0x9c400
  40d85a:	jb     40d840 <__swc_fn_7069e055_000178_fa681d0f+0x160>
  40d85c:	mov    ecx,0x1388000
  40d861:	sub    rsp,0x8
  40d865:	call   40d630 <__swc_fn_7069e055_000175_2744b483>
  40d86a:	add    rsp,0x8
  40d86e:	mov    QWORD PTR [rip+0x19543],rax        # 426db8 <__swc_bss_base_7069e055+0x2d78>
  40d875:	mov    ecx,0x1388000
  40d87a:	sub    rsp,0x8
  40d87e:	call   40d630 <__swc_fn_7069e055_000175_2744b483>
  40d883:	add    rsp,0x8
  40d887:	mov    QWORD PTR [rip+0x19532],rax        # 426dc0 <__swc_bss_base_7069e055+0x2d80>
  40d88e:	lea    rcx,[rip+0x1951b]        # 426db0 <__swc_bss_base_7069e055+0x2d70>
  40d895:	mov    QWORD PTR [rcx],0x0
  40d89c:	mov    QWORD PTR [rdi],0x0
  40d8a3:	mov    rdx,QWORD PTR [rip+0x19506]        # 426db0 <__swc_bss_base_7069e055+0x2d70>
  40d8aa:	mov    r8,rdx
  40d8ad:	add    QWORD PTR [rcx],0x1
  40d8b1:	mov    r9,QWORD PTR [rip+0x19500]        # 426db8 <__swc_bss_base_7069e055+0x2d78>
  40d8b8:	mov    QWORD PTR [r9+rdx*8],0x0
  40d8c0:	mov    r9,QWORD PTR [rip+0x194f9]        # 426dc0 <__swc_bss_base_7069e055+0x2d80>
  40d8c7:	mov    QWORD PTR [r9+rdx*8],0x0
  40d8cf:	mov    rdx,QWORD PTR [rip+0x194e2]        # 426db8 <__swc_bss_base_7069e055+0x2d78>
  40d8d6:	mov    r9,QWORD PTR [rip+0x194e3]        # 426dc0 <__swc_bss_base_7069e055+0x2d80>
  40d8dd:	test   r8,r8
  40d8e0:	jbe    40d934 <__swc_fn_7069e055_000178_fa681d0f+0x254>
  40d8e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40d8ec:	cs nop WORD PTR [rax+rax*1+0x0]
  40d8f6:	cs nop WORD PTR [rax+rax*1+0x0]
  40d900:	lea    r10,[r8-0x1]
  40d904:	shr    r10,1
  40d907:	mov    r11,QWORD PTR [rdx+r8*8]
  40d90b:	mov    r12,QWORD PTR [rdx+r10*8]
  40d90f:	cmp    r12,r11
  40d912:	jbe    40d934 <__swc_fn_7069e055_000178_fa681d0f+0x254>
  40d914:	mov    QWORD PTR [rdx+r10*8],r11
  40d918:	mov    QWORD PTR [rdx+r8*8],r12
  40d91c:	mov    r11,QWORD PTR [r9+r10*8]
  40d920:	mov    r12,QWORD PTR [r9+r8*8]
  40d924:	mov    QWORD PTR [r9+r10*8],r12
  40d928:	mov    QWORD PTR [r9+r8*8],r11
  40d92c:	mov    r8,r10
  40d92f:	test   r10,r10
  40d932:	ja     40d900 <__swc_fn_7069e055_000178_fa681d0f+0x220>
  40d934:	xor    r8d,r8d
  40d937:	vmovq  xmm0,r8
  40d93c:	jmp    40d950 <__swc_fn_7069e055_000178_fa681d0f+0x270>
  40d93e:	xchg   ax,ax
  40d940:	vmovq  r8,xmm0
  40d945:	cs nop WORD PTR [rax+rax*1+0x0]
  40d94f:	nop
  40d950:	mov    rdx,QWORD PTR [rip+0x19459]        # 426db0 <__swc_bss_base_7069e055+0x2d70>
  40d957:	test   rdx,rdx
  40d95a:	jbe    40dd54 <__swc_fn_7069e055_000178_fa681d0f+0x674>
  40d960:	mov    rdx,QWORD PTR [rip+0x19451]        # 426db8 <__swc_bss_base_7069e055+0x2d78>
  40d967:	mov    rdx,QWORD PTR [rdx]
  40d96a:	mov    QWORD PTR [rip+0x19457],rdx        # 426dc8 <__swc_bss_base_7069e055+0x2d88>
  40d971:	mov    rdx,QWORD PTR [rip+0x19448]        # 426dc0 <__swc_bss_base_7069e055+0x2d80>
  40d978:	mov    rdx,QWORD PTR [rdx]
  40d97b:	mov    QWORD PTR [rip+0x1944e],rdx        # 426dd0 <__swc_bss_base_7069e055+0x2d90>
  40d982:	sub    QWORD PTR [rcx],0x1
  40d986:	mov    rdx,QWORD PTR [rip+0x1942b]        # 426db8 <__swc_bss_base_7069e055+0x2d78>
  40d98d:	mov    r9,QWORD PTR [rip+0x1941c]        # 426db0 <__swc_bss_base_7069e055+0x2d70>
  40d994:	mov    r9,QWORD PTR [rdx+r9*8]
  40d998:	mov    QWORD PTR [rdx],r9
  40d99b:	mov    rdx,QWORD PTR [rip+0x1941e]        # 426dc0 <__swc_bss_base_7069e055+0x2d80>
  40d9a2:	mov    r9,QWORD PTR [rip+0x19407]        # 426db0 <__swc_bss_base_7069e055+0x2d70>
  40d9a9:	mov    r9,QWORD PTR [rdx+r9*8]
  40d9ad:	mov    QWORD PTR [rdx],r9
  40d9b0:	xor    edx,edx
  40d9b2:	mov    r9,QWORD PTR [rip+0x193f7]        # 426db0 <__swc_bss_base_7069e055+0x2d70>
  40d9b9:	mov    r10,QWORD PTR [rip+0x193f8]        # 426db8 <__swc_bss_base_7069e055+0x2d78>
  40d9c0:	mov    r11,QWORD PTR [rip+0x193f9]        # 426dc0 <__swc_bss_base_7069e055+0x2d80>
  40d9c7:	lea    r12,[rdx+rdx*1+0x1]
  40d9cc:	cmp    r12,r9
  40d9cf:	jae    40da2c <__swc_fn_7069e055_000178_fa681d0f+0x34c>
  40d9d1:	cs nop WORD PTR [rax+rax*1+0x0]
  40d9db:	nop    DWORD PTR [rax+rax*1+0x0]
  40d9e0:	lea    r13,[r12+0x1]
  40d9e5:	cmp    r13,r9
  40d9e8:	mov    r13,QWORD PTR [r10+r12*8]
  40d9ec:	jae    40d9fe <__swc_fn_7069e055_000178_fa681d0f+0x31e>
  40d9ee:	mov    r14,QWORD PTR [r10+r12*8+0x8]
  40d9f3:	cmp    r14,r13
  40d9f6:	cmovb  r13,r14
  40d9fa:	adc    r12,0x0
  40d9fe:	mov    r14,QWORD PTR [r10+rdx*8]
  40da02:	cmp    r14,r13
  40da05:	jbe    40da2c <__swc_fn_7069e055_000178_fa681d0f+0x34c>
  40da07:	mov    QWORD PTR [r10+r12*8],r14
  40da0b:	mov    QWORD PTR [r10+rdx*8],r13
  40da0f:	mov    r13,QWORD PTR [r11+r12*8]
  40da13:	mov    r14,QWORD PTR [r11+rdx*8]
  40da17:	mov    QWORD PTR [r11+r12*8],r14
  40da1b:	mov    QWORD PTR [r11+rdx*8],r13
  40da1f:	mov    rdx,r12
  40da22:	lea    r12,[r12+r12*1+0x1]
  40da27:	cmp    r12,r9
  40da2a:	jb     40d9e0 <__swc_fn_7069e055_000178_fa681d0f+0x300>
  40da2c:	mov    r9,QWORD PTR [rip+0x19395]        # 426dc8 <__swc_bss_base_7069e055+0x2d88>
  40da33:	mov    r10,QWORD PTR [rip+0x19396]        # 426dd0 <__swc_bss_base_7069e055+0x2d90>
  40da3a:	inc    r8
  40da3d:	vmovq  xmm0,r8
  40da42:	mov    rdx,QWORD PTR [rdi+r10*8]
  40da46:	cmp    r9,rdx
  40da49:	ja     40d950 <__swc_fn_7069e055_000178_fa681d0f+0x270>
  40da4f:	cmp    r10,0x9c3ff
  40da56:	je     40dd54 <__swc_fn_7069e055_000178_fa681d0f+0x674>
  40da5c:	mov    r11,r10
  40da5f:	shr    r11,0x5
  40da63:	movabs rdx,0xa3d70a3d70a3d71
  40da6d:	mov    r8,rax
  40da70:	mov    rax,r11
  40da73:	mul    rdx
  40da76:	mov    rax,r8
  40da79:	imul   r11,rdx,0x320
  40da80:	mov    r12,r10
  40da83:	sub    r12,r11
  40da86:	vmovq  xmm1,rdx
  40da8b:	test   r12,r12
  40da8e:	jbe    40db34 <__swc_fn_7069e055_000178_fa681d0f+0x454>
  40da94:	lea    r11,[r10-0x1]
  40da98:	mov    r13,r9
  40da9b:	add    r13,QWORD PTR [rsi+r10*8-0x8]
  40daa0:	mov    r14,QWORD PTR [rdi+r10*8-0x8]
  40daa5:	cmp    r13,r14
  40daa8:	jae    40db34 <__swc_fn_7069e055_000178_fa681d0f+0x454>
  40daae:	mov    QWORD PTR [rdi+r10*8-0x8],r13
  40dab3:	mov    r14,QWORD PTR [rip+0x192f6]        # 426db0 <__swc_bss_base_7069e055+0x2d70>
  40daba:	mov    r15,r14
  40dabd:	add    QWORD PTR [rcx],0x1
  40dac1:	mov    r8,QWORD PTR [rip+0x192f0]        # 426db8 <__swc_bss_base_7069e055+0x2d78>
  40dac8:	mov    QWORD PTR [r8+r14*8],r13
  40dacc:	mov    r8,QWORD PTR [rip+0x192ed]        # 426dc0 <__swc_bss_base_7069e055+0x2d80>
  40dad3:	mov    QWORD PTR [r8+r14*8],r11
  40dad7:	mov    r8,QWORD PTR [rip+0x192da]        # 426db8 <__swc_bss_base_7069e055+0x2d78>
  40dade:	mov    r11,QWORD PTR [rip+0x192db]        # 426dc0 <__swc_bss_base_7069e055+0x2d80>
  40dae5:	test   r15,r15
  40dae8:	jbe    40db34 <__swc_fn_7069e055_000178_fa681d0f+0x454>
  40daea:	cs nop WORD PTR [rax+rax*1+0x0]
  40daf4:	cs nop WORD PTR [rax+rax*1+0x0]
  40dafe:	xchg   ax,ax
  40db00:	lea    r13,[r15-0x1]
  40db04:	shr    r13,1
  40db07:	mov    r14,QWORD PTR [r8+r15*8]
  40db0b:	mov    rdx,QWORD PTR [r8+r13*8]
  40db0f:	cmp    rdx,r14
  40db12:	jbe    40db34 <__swc_fn_7069e055_000178_fa681d0f+0x454>
  40db14:	mov    QWORD PTR [r8+r13*8],r14
  40db18:	mov    QWORD PTR [r8+r15*8],rdx
  40db1c:	mov    rdx,QWORD PTR [r11+r13*8]
  40db20:	mov    r14,QWORD PTR [r11+r15*8]
  40db24:	mov    QWORD PTR [r11+r13*8],r14
  40db28:	mov    QWORD PTR [r11+r15*8],rdx
  40db2c:	mov    r15,r13
  40db2f:	test   r13,r13
  40db32:	ja     40db00 <__swc_fn_7069e055_000178_fa681d0f+0x420>
  40db34:	cmp    r12,0x31f
  40db3b:	jae    40dbd5 <__swc_fn_7069e055_000178_fa681d0f+0x4f5>
  40db41:	lea    rdx,[r10+0x1]
  40db45:	mov    r8,r9
  40db48:	add    r8,QWORD PTR [rsi+r10*8+0x8]
  40db4d:	mov    r11,QWORD PTR [rdi+r10*8+0x8]
  40db52:	cmp    r8,r11
  40db55:	jae    40dbd5 <__swc_fn_7069e055_000178_fa681d0f+0x4f5>
  40db5b:	mov    QWORD PTR [rdi+r10*8+0x8],r8
  40db60:	mov    r11,QWORD PTR [rip+0x19249]        # 426db0 <__swc_bss_base_7069e055+0x2d70>
  40db67:	mov    r12,r11
  40db6a:	add    QWORD PTR [rcx],0x1
  40db6e:	mov    r13,QWORD PTR [rip+0x19243]        # 426db8 <__swc_bss_base_7069e055+0x2d78>
  40db75:	mov    QWORD PTR [r13+r11*8+0x0],r8
  40db7a:	mov    r8,QWORD PTR [rip+0x1923f]        # 426dc0 <__swc_bss_base_7069e055+0x2d80>
  40db81:	mov    QWORD PTR [r8+r11*8],rdx
  40db85:	mov    rdx,QWORD PTR [rip+0x1922c]        # 426db8 <__swc_bss_base_7069e055+0x2d78>
  40db8c:	mov    r8,QWORD PTR [rip+0x1922d]        # 426dc0 <__swc_bss_base_7069e055+0x2d80>
  40db93:	test   r12,r12
  40db96:	jbe    40dbd5 <__swc_fn_7069e055_000178_fa681d0f+0x4f5>
  40db98:	nop    DWORD PTR [rax+rax*1+0x0]
  40dba0:	lea    r11,[r12-0x1]
  40dba5:	shr    r11,1
  40dba8:	mov    r13,QWORD PTR [rdx+r12*8]
  40dbac:	mov    r14,QWORD PTR [rdx+r11*8]
  40dbb0:	cmp    r14,r13
  40dbb3:	jbe    40dbd5 <__swc_fn_7069e055_000178_fa681d0f+0x4f5>
  40dbb5:	mov    QWORD PTR [rdx+r11*8],r13
  40dbb9:	mov    QWORD PTR [rdx+r12*8],r14
  40dbbd:	mov    r13,QWORD PTR [r8+r11*8]
  40dbc1:	mov    r14,QWORD PTR [r8+r12*8]
  40dbc5:	mov    QWORD PTR [r8+r11*8],r14
  40dbc9:	mov    QWORD PTR [r8+r12*8],r13
  40dbcd:	mov    r12,r11
  40dbd0:	test   r11,r11
  40dbd3:	ja     40dba0 <__swc_fn_7069e055_000178_fa681d0f+0x4c0>
  40dbd5:	vmovq  rdx,xmm1
  40dbda:	test   rdx,rdx
  40dbdd:	jbe    40dc94 <__swc_fn_7069e055_000178_fa681d0f+0x5b4>
  40dbe3:	lea    r8,[r10-0x320]
  40dbea:	mov    r11,r9
  40dbed:	add    r11,QWORD PTR [rsi+r10*8-0x1900]
  40dbf5:	mov    r12,QWORD PTR [rdi+r10*8-0x1900]
  40dbfd:	cmp    r11,r12
  40dc00:	jae    40dc94 <__swc_fn_7069e055_000178_fa681d0f+0x5b4>
  40dc06:	mov    QWORD PTR [rdi+r10*8-0x1900],r11
  40dc0e:	mov    r12,QWORD PTR [rip+0x1919b]        # 426db0 <__swc_bss_base_7069e055+0x2d70>
  40dc15:	mov    r13,r12
  40dc18:	add    QWORD PTR [rcx],0x1
  40dc1c:	mov    r14,QWORD PTR [rip+0x19195]        # 426db8 <__swc_bss_base_7069e055+0x2d78>
  40dc23:	mov    QWORD PTR [r14+r12*8],r11
  40dc27:	mov    r11,QWORD PTR [rip+0x19192]        # 426dc0 <__swc_bss_base_7069e055+0x2d80>
  40dc2e:	mov    QWORD PTR [r11+r12*8],r8
  40dc32:	mov    r8,QWORD PTR [rip+0x1917f]        # 426db8 <__swc_bss_base_7069e055+0x2d78>
  40dc39:	mov    r11,QWORD PTR [rip+0x19180]        # 426dc0 <__swc_bss_base_7069e055+0x2d80>
  40dc40:	test   r13,r13
  40dc43:	jbe    40dc94 <__swc_fn_7069e055_000178_fa681d0f+0x5b4>
  40dc45:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc4f:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc59:	nop    DWORD PTR [rax+0x0]
  40dc60:	lea    r12,[r13-0x1]
  40dc64:	shr    r12,1
  40dc67:	mov    r14,QWORD PTR [r8+r13*8]
  40dc6b:	mov    r15,QWORD PTR [r8+r12*8]
  40dc6f:	cmp    r15,r14
  40dc72:	jbe    40dc94 <__swc_fn_7069e055_000178_fa681d0f+0x5b4>
  40dc74:	mov    QWORD PTR [r8+r12*8],r14
  40dc78:	mov    QWORD PTR [r8+r13*8],r15
  40dc7c:	mov    r14,QWORD PTR [r11+r12*8]
  40dc80:	mov    r15,QWORD PTR [r11+r13*8]
  40dc84:	mov    QWORD PTR [r11+r12*8],r15
  40dc88:	mov    QWORD PTR [r11+r13*8],r14
  40dc8c:	mov    r13,r12
  40dc8f:	test   r12,r12
  40dc92:	ja     40dc60 <__swc_fn_7069e055_000178_fa681d0f+0x580>
  40dc94:	cmp    rdx,0x31f
  40dc9b:	vmovq  r8,xmm0
  40dca0:	jae    40d950 <__swc_fn_7069e055_000178_fa681d0f+0x270>
  40dca6:	lea    rdx,[r10+0x320]
  40dcad:	add    r9,QWORD PTR [rsi+r10*8+0x1900]
  40dcb5:	mov    r8,QWORD PTR [rdi+r10*8+0x1900]
  40dcbd:	cmp    r9,r8
  40dcc0:	vmovq  r8,xmm0
  40dcc5:	jae    40d950 <__swc_fn_7069e055_000178_fa681d0f+0x270>
  40dccb:	mov    QWORD PTR [rdi+r10*8+0x1900],r9
  40dcd3:	mov    r8,QWORD PTR [rip+0x190d6]        # 426db0 <__swc_bss_base_7069e055+0x2d70>
  40dcda:	mov    r10,r8
  40dcdd:	add    QWORD PTR [rcx],0x1
  40dce1:	mov    r11,QWORD PTR [rip+0x190d0]        # 426db8 <__swc_bss_base_7069e055+0x2d78>
  40dce8:	mov    QWORD PTR [r11+r8*8],r9
  40dcec:	mov    r9,QWORD PTR [rip+0x190cd]        # 426dc0 <__swc_bss_base_7069e055+0x2d80>
  40dcf3:	mov    QWORD PTR [r9+r8*8],rdx
  40dcf7:	mov    rdx,QWORD PTR [rip+0x190ba]        # 426db8 <__swc_bss_base_7069e055+0x2d78>
  40dcfe:	mov    r8,QWORD PTR [rip+0x190bb]        # 426dc0 <__swc_bss_base_7069e055+0x2d80>
  40dd05:	cs nop WORD PTR [rax+rax*1+0x0]
  40dd0f:	nop
  40dd10:	test   r10,r10
  40dd13:	jbe    40d940 <__swc_fn_7069e055_000178_fa681d0f+0x260>
  40dd19:	lea    r9,[r10-0x1]
  40dd1d:	shr    r9,1
  40dd20:	mov    r11,QWORD PTR [rdx+r10*8]
  40dd24:	mov    r12,QWORD PTR [rdx+r9*8]
  40dd28:	cmp    r12,r11
  40dd2b:	ja     40dd37 <__swc_fn_7069e055_000178_fa681d0f+0x657>
  40dd2d:	vmovq  r8,xmm0
  40dd32:	jmp    40d950 <__swc_fn_7069e055_000178_fa681d0f+0x270>
  40dd37:	mov    QWORD PTR [rdx+r9*8],r11
  40dd3b:	mov    QWORD PTR [rdx+r10*8],r12
  40dd3f:	mov    r11,QWORD PTR [r8+r9*8]
  40dd43:	mov    r12,QWORD PTR [r8+r10*8]
  40dd47:	mov    QWORD PTR [r8+r9*8],r12
  40dd4b:	mov    QWORD PTR [r8+r10*8],r11
  40dd4f:	mov    r10,r9
  40dd52:	jmp    40dd10 <__swc_fn_7069e055_000178_fa681d0f+0x630>
  40dd54:	mov    rcx,QWORD PTR [rdi+0x4e1ff8]
  40dd5b:	imul   rcx,rcx,0x3e8
  40dd62:	vmovq  r8,xmm0
  40dd67:	mov    r9,r8
  40dd6a:	shr    r9,0x3
  40dd6e:	movabs rdx,0x20c49ba5e353f7cf
  40dd78:	mov    rax,r9
  40dd7b:	mul    rdx
  40dd7e:	shr    rdx,0x4
  40dd82:	imul   rdx,rdx,0x3e8
  40dd89:	sub    r8,rdx
  40dd8c:	lea    r12,[rcx+r8*1]
  40dd90:	sub    rsp,0x8
  40dd94:	call   40a350 <__swc_fn_7069e055_000177_1ca87929>
  40dd99:	add    rsp,0x8
  40dd9d:	vsubsd xmm0,xmm0,xmm6
  40dda1:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x5c1f]        # 4139c8 <__swc_rdata_base_7069e055+0x8b8>
  40dda9:	lea    rax,[rip+0x55b8]        # 413368 <__swc_rdata_base_7069e055+0x258>
  40ddb0:	sub    rsp,0x90
  40ddb7:	mov    rcx,rsp
  40ddba:	vmovups xmm1,XMMWORD PTR [rip+0x5be6]        # 4139a8 <__swc_rdata_base_7069e055+0x898>
  40ddc2:	vmovups XMMWORD PTR [rcx],xmm1
  40ddc6:	mov    QWORD PTR [rcx+0x30],rsp
  40ddca:	lea    rdx,[rip+0x553f]        # 413310 <__swc_rdata_base_7069e055+0x200>
  40ddd1:	mov    QWORD PTR [rcx+0x38],rdx
  40ddd5:	mov    QWORD PTR [rcx+0x10],r12
  40ddd9:	lea    r8,[rsp+0x10]
  40ddde:	mov    QWORD PTR [rcx+0x40],r8
  40dde2:	lea    r8,[rip+0x5b2f]        # 413918 <__swc_rdata_base_7069e055+0x808>
  40dde9:	mov    QWORD PTR [rcx+0x48],r8
  40dded:	vmovups xmm1,XMMWORD PTR [rip+0x5bc3]        # 4139b8 <__swc_rdata_base_7069e055+0x8a8>
  40ddf5:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40ddfa:	lea    r8,[rsp+0x18]
  40ddff:	mov    QWORD PTR [rcx+0x50],r8
  40de03:	mov    QWORD PTR [rcx+0x58],rdx
  40de07:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40de0c:	lea    r8,[rcx+0x28]
  40de10:	mov    QWORD PTR [rcx+0x60],r8
  40de14:	lea    r8,[rip+0x5b45]        # 413960 <__swc_rdata_base_7069e055+0x850>
  40de1b:	mov    QWORD PTR [rcx+0x68],r8
  40de1f:	mov    QWORD PTR [rcx+0x70],rax
  40de23:	mov    QWORD PTR [rcx+0x78],rdx
  40de27:	lea    rax,[rcx+0x30]
  40de2b:	mov    QWORD PTR [rcx+0x80],rax
  40de32:	mov    QWORD PTR [rcx+0x88],0x5
  40de3d:	lea    rcx,[rcx+0x80]
  40de44:	sub    rsp,0x8
  40de48:	call   4109c0 <__swc_fn_7069e055_000146_d2097256>
  40de4d:	add    rsp,0x8
  40de51:	add    rsp,0x90
  40de58:	mov    rcx,QWORD PTR [rip+0x18f61]        # 426dc0 <__swc_bss_base_7069e055+0x2d80>
  40de5f:	sub    rsp,0x8
  40de63:	call   4120a0 <__swc_fn_7069e055_000176_5d3d19bd>
  40de68:	add    rsp,0x8
  40de6c:	mov    rcx,QWORD PTR [rip+0x18f45]        # 426db8 <__swc_bss_base_7069e055+0x2d78>
  40de73:	sub    rsp,0x8
  40de77:	call   4120a0 <__swc_fn_7069e055_000176_5d3d19bd>
  40de7c:	add    rsp,0x8
  40de80:	mov    rcx,rdi
  40de83:	sub    rsp,0x8
  40de87:	call   4120a0 <__swc_fn_7069e055_000176_5d3d19bd>
  40de8c:	add    rsp,0x8
  40de90:	mov    rcx,rsi
  40de93:	sub    rsp,0x8
  40de97:	call   4120a0 <__swc_fn_7069e055_000176_5d3d19bd>
  40de9c:	add    rsp,0x1b8
  40dea3:	vmovups xmm6,XMMWORD PTR [rsp]
  40dea8:	add    rsp,0x18
  40deac:	pop    r12
  40deae:	pop    rdi
  40deaf:	pop    r13
  40deb1:	pop    r14
  40deb3:	pop    r15
  40deb5:	pop    rsi
  40deb6:	pop    rbp
  40deb7:	ret
	...

000000000040dec0 <__swc_fn_7069e055_000002_102336c4>:
  40dec0:	sub    rsp,0x8
  40dec4:	call   40c620 <__swc_fn_7069e055_000109_9f5af8ae>
  40dec9:	mov    rcx,rax
  40decc:	test   rax,rax
  40decf:	je     40def6 <__swc_fn_7069e055_000002_102336c4+0x36>
  40ded1:	lea    rdx,[rip+0x16168]        # 424040 <__swc_bss_base_7069e055>
  40ded8:	mov    r8,QWORD PTR [rip+0x16161]        # 424040 <__swc_bss_base_7069e055>
  40dedf:	nop
  40dee0:	lea    r9,[r8+0x1]
  40dee4:	mov    rax,r8
  40dee7:	lock cmpxchg QWORD PTR [rdx],r9
  40deec:	cmp    rax,r8
  40deef:	je     40def6 <__swc_fn_7069e055_000002_102336c4+0x36>
  40def1:	mov    r8,rax
  40def4:	jmp    40dee0 <__swc_fn_7069e055_000002_102336c4+0x20>
  40def6:	mov    rax,rcx
  40def9:	add    rsp,0x8
  40defd:	ret
	...

000000000040df00 <__swc_fn_7069e055_000005_6a556171>:
  40df00:	mov    r8d,edx
  40df03:	xor    eax,eax
  40df05:	tzcnt  eax,edx
  40df09:	shrx   r9d,edx,eax
  40df0e:	mov    DWORD PTR [rcx+0x2c],edx
  40df11:	xor    eax,eax
  40df13:	tzcnt  eax,edx
  40df17:	mov    BYTE PTR [rcx+0x38],al
  40df1a:	mov    eax,0xffffffff
  40df1f:	xor    edx,edx
  40df21:	div    r8d
  40df24:	mov    DWORD PTR [rcx+0x34],eax
  40df27:	mov    eax,r9d
  40df2a:	mov    edx,r9d
  40df2d:	imul   edx,r9d
  40df31:	mov    r8d,0x2
  40df37:	sub    r8d,edx
  40df3a:	imul   eax,r8d
  40df3e:	mov    edx,r9d
  40df41:	imul   edx,eax
  40df44:	mov    r8d,0x2
  40df4a:	sub    r8d,edx
  40df4d:	imul   eax,r8d
  40df51:	mov    edx,r9d
  40df54:	imul   edx,eax
  40df57:	mov    r8d,0x2
  40df5d:	sub    r8d,edx
  40df60:	imul   eax,r8d
  40df64:	mov    edx,r9d
  40df67:	imul   edx,eax
  40df6a:	mov    r8d,0x2
  40df70:	sub    r8d,edx
  40df73:	imul   eax,r8d
  40df77:	imul   r9d,eax
  40df7b:	mov    edx,0x2
  40df80:	sub    edx,r9d
  40df83:	imul   eax,edx
  40df86:	mov    DWORD PTR [rcx+0x30],eax
  40df89:	ret
  40df8a:	add    BYTE PTR [rax],al
  40df8c:	add    BYTE PTR [rax],al
	...

000000000040df90 <__swc_fn_7069e055_000008_b2f73e0d>:
  40df90:	xor    eax,eax
  40df92:	mov    DWORD PTR [rcx+0x68],eax
  40df95:	ret
	...

000000000040dfa0 <__swc_fn_7069e055_000011_71c91685>:
  40dfa0:	mov    eax,DWORD PTR [rcx+0x28]
  40dfa3:	shlx   eax,edx,eax
  40dfa8:	shl    rax,0x10
  40dfac:	lea    rdx,[rcx+rax*1]
  40dfb0:	lea    rax,[rcx+0x3000]
  40dfb7:	cmp    rdx,rax
  40dfba:	cmovae rax,rdx
  40dfbe:	ret
	...

000000000040dfc0 <__swc_fn_7069e055_000014_be17798c>:
  40dfc0:	push   rsi
  40dfc1:	push   rdi
  40dfc2:	push   r12
  40dfc4:	push   r13
  40dfc6:	push   r14
  40dfc8:	mov    rsi,rdx
  40dfcb:	mov    rdi,rcx
  40dfce:	rex mov dl,BYTE PTR [rsi+0x3a]
  40dfd2:	mov    ecx,DWORD PTR [rdi+0x28]
  40dfd5:	shr    dl,cl
  40dfd7:	mov    r12d,0x1
  40dfdd:	mov    ecx,edx
  40dfdf:	shl    r12,cl
  40dfe2:	mov    r13d,DWORD PTR [rsi+0x3c]
  40dfe6:	rex mov BYTE PTR [rsi+0x3b],0x0
  40dfeb:	mov    QWORD PTR [rsi+0x40],0x0
  40dff3:	mov    QWORD PTR [rsi],0x0
  40dffa:	mov    rax,QWORD PTR [rsi+0x10]
  40dffe:	mov    QWORD PTR [rsi+0x20],rax
  40e002:	lea    r14,[rip+0x1603f]        # 424048 <__swc_bss_base_7069e055+0x8>
  40e009:	mov    rax,QWORD PTR [r14]
  40e00c:	shr    rax,0x2
  40e010:	mov    rcx,rax
  40e013:	cmp    rax,0x800000
  40e01a:	mov    eax,0x800000
  40e01f:	cmovb  rcx,rax
  40e023:	lea    r8,[rip+0x1602e]        # 424058 <__swc_bss_base_7069e055+0x18>
  40e02a:	mov    rax,QWORD PTR [r8]
  40e02d:	mov    r9,rax
  40e030:	lea    r10,[r9+r13*1]
  40e034:	cmp    r10,rcx
  40e037:	ja     40e05b <__swc_fn_7069e055_000014_be17798c+0x9b>
  40e039:	mov    rax,r9
  40e03c:	lock cmpxchg QWORD PTR [r8],r10
  40e041:	cmp    rax,r9
  40e044:	je     40e04b <__swc_fn_7069e055_000014_be17798c+0x8b>
  40e046:	mov    r9,rax
  40e049:	jmp    40e030 <__swc_fn_7069e055_000014_be17798c+0x70>
  40e04b:	mov    rcx,rdi
  40e04e:	mov    rdx,r12
  40e051:	call   40a750 <__swc_fn_7069e055_000016_a0b588d0>
  40e056:	jmp    40e0dd <__swc_fn_7069e055_000014_be17798c+0x11d>
  40e05b:	mov    rcx,rdi
  40e05e:	movzx  edx,dl
  40e061:	call   40dfa0 <__swc_fn_7069e055_000011_71c91685>
  40e066:	test   r13,r13
  40e069:	je     40e0d6 <__swc_fn_7069e055_000014_be17798c+0x116>
  40e06f:	mov    rcx,rax
  40e072:	mov    rdx,r13
  40e075:	call   40c7a0 <__swc_fn_7069e055_000112_2f7f9346>
  40e07a:	mov    rcx,QWORD PTR [rip+0x15fc7]        # 424048 <__swc_bss_base_7069e055+0x8>
  40e081:	cs nop WORD PTR [rax+rax*1+0x0]
  40e08b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e090:	mov    rdx,rcx
  40e093:	sub    rdx,r13
  40e096:	mov    rax,rcx
  40e099:	lock cmpxchg QWORD PTR [r14],rdx
  40e09e:	cmp    rax,rcx
  40e0a1:	je     40e0a8 <__swc_fn_7069e055_000014_be17798c+0xe8>
  40e0a3:	mov    rcx,rax
  40e0a6:	jmp    40e090 <__swc_fn_7069e055_000014_be17798c+0xd0>
  40e0a8:	lea    rcx,[rip+0x15fb1]        # 424060 <__swc_bss_base_7069e055+0x20>
  40e0af:	mov    rdx,QWORD PTR [rip+0x15faa]        # 424060 <__swc_bss_base_7069e055+0x20>
  40e0b6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e0c0:	lea    r8,[rdx+0x1]
  40e0c4:	mov    rax,rdx
  40e0c7:	lock cmpxchg QWORD PTR [rcx],r8
  40e0cc:	cmp    rax,rdx
  40e0cf:	je     40e0d6 <__swc_fn_7069e055_000014_be17798c+0x116>
  40e0d1:	mov    rdx,rax
  40e0d4:	jmp    40e0c0 <__swc_fn_7069e055_000014_be17798c+0x100>
  40e0d6:	mov    DWORD PTR [rsi+0x3c],0x0
  40e0dd:	mov    rcx,rdi
  40e0e0:	mov    rdx,r12
  40e0e3:	call   407600 <__swc_fn_7069e055_000018_77ece227>
  40e0e8:	pop    r14
  40e0ea:	pop    r13
  40e0ec:	pop    r12
  40e0ee:	pop    rdi
  40e0ef:	pop    rsi
  40e0f0:	ret
	...

000000000040e100 <__swc_fn_7069e055_000017_f003fc47>:
  40e100:	mov    r8,QWORD PTR [rcx+0x48]
  40e104:	test   r8,rdx
  40e107:	je     40e138 <__swc_fn_7069e055_000017_f003fc47+0x38>
  40e109:	nop    DWORD PTR [rax+0x0]
  40e110:	mov    rax,rdx
  40e113:	not    rax
  40e116:	mov    r9,r8
  40e119:	and    r9,rax
  40e11c:	mov    rax,r8
  40e11f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40e125:	cmp    rax,r8
  40e128:	jne    40e130 <__swc_fn_7069e055_000017_f003fc47+0x30>
  40e12a:	mov    eax,0x1
  40e12f:	ret
  40e130:	mov    r8,rax
  40e133:	test   rax,rdx
  40e136:	jne    40e110 <__swc_fn_7069e055_000017_f003fc47+0x10>
  40e138:	xor    eax,eax
  40e13a:	ret
  40e13b:	add    BYTE PTR [rax],al
  40e13d:	add    BYTE PTR [rax],al
	...

000000000040e140 <__swc_fn_7069e055_000020_4285d9c5>:
  40e140:	push   rsi
  40e141:	push   rdi
  40e142:	push   r12
  40e144:	push   r13
  40e146:	sub    rsp,0x8
  40e14a:	mov    rsi,rdx
  40e14d:	mov    rdi,rcx
  40e150:	lea    r12,[rip+0x16099]        # 4241f0 <__swc_bss_base_7069e055+0x1b0>
  40e157:	mov    rcx,r12
  40e15a:	call   4098a0 <__swc_fn_7069e055_000135_db32cc57>
  40e15f:	xor    eax,eax
  40e161:	mov    rcx,QWORD PTR [rip+0x16090]        # 4241f8 <__swc_bss_base_7069e055+0x1b8>
  40e168:	mov    r13,rcx
  40e16b:	test   r13,r13
  40e16e:	je     40e1bb <__swc_fn_7069e055_000020_4285d9c5+0x7b>
  40e170:	mov    rcx,QWORD PTR [r13+0x10]
  40e174:	cmp    DWORD PTR [r13+0x28],esi
  40e178:	jne    40e1b0 <__swc_fn_7069e055_000020_4285d9c5+0x70>
  40e17a:	test   rax,rax
  40e17d:	jne    40e188 <__swc_fn_7069e055_000020_4285d9c5+0x48>
  40e17f:	mov    QWORD PTR [rip+0x16072],rcx        # 4241f8 <__swc_bss_base_7069e055+0x1b8>
  40e186:	jmp    40e18c <__swc_fn_7069e055_000020_4285d9c5+0x4c>
  40e188:	mov    QWORD PTR [rax+0x10],rcx
  40e18c:	vxorps xmm0,xmm0,xmm0
  40e190:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40e196:	mov    QWORD PTR [r13+0x8],rdi
  40e19a:	mov    rcx,r12
  40e19d:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  40e1a2:	mov    rax,r13
  40e1a5:	add    rsp,0x8
  40e1a9:	pop    r13
  40e1ab:	pop    r12
  40e1ad:	pop    rdi
  40e1ae:	pop    rsi
  40e1af:	ret
  40e1b0:	mov    rax,r13
  40e1b3:	mov    r13,rcx
  40e1b6:	test   rcx,rcx
  40e1b9:	jne    40e170 <__swc_fn_7069e055_000020_4285d9c5+0x30>
  40e1bb:	mov    ecx,esi
  40e1bd:	call   40a780 <__swc_fn_7069e055_000019_447bb610>
  40e1c2:	mov    rsi,rax
  40e1c5:	test   rax,rax
  40e1c8:	jne    40e1df <__swc_fn_7069e055_000020_4285d9c5+0x9f>
  40e1ca:	mov    rcx,r12
  40e1cd:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  40e1d2:	xor    eax,eax
  40e1d4:	add    rsp,0x8
  40e1d8:	pop    r13
  40e1da:	pop    r12
  40e1dc:	pop    rdi
  40e1dd:	pop    rsi
  40e1de:	ret
  40e1df:	mov    QWORD PTR [rsi+0x8],rdi
  40e1e3:	mov    rcx,r12
  40e1e6:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  40e1eb:	mov    rax,rsi
  40e1ee:	add    rsp,0x8
  40e1f2:	pop    r13
  40e1f4:	pop    r12
  40e1f6:	pop    rdi
  40e1f7:	pop    rsi
  40e1f8:	ret
  40e1f9:	add    BYTE PTR [rax],al
  40e1fb:	add    BYTE PTR [rax],al
  40e1fd:	add    BYTE PTR [rax],al
	...

000000000040e200 <__swc_fn_7069e055_000023_e876734d>:
  40e200:	vxorps xmm0,xmm0,xmm0
  40e204:	xor    eax,eax
  40e206:	cs nop WORD PTR [rax+rax*1+0x0]
  40e210:	cs nop WORD PTR [rax+rax*1+0x0]
  40e21a:	nop    WORD PTR [rax+rax*1+0x0]
  40e220:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40e225:	add    rax,0x10
  40e229:	cmp    rax,0x2b00
  40e230:	jne    40e220 <__swc_fn_7069e055_000023_e876734d+0x20>
  40e232:	ret
	...

000000000040e240 <__swc_fn_7069e055_000026_e876734d>:
  40e240:	vxorps xmm0,xmm0,xmm0
  40e244:	vmovups XMMWORD PTR [rcx],xmm0
  40e248:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e24d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e252:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e257:	ret
	...

000000000040e260 <__swc_fn_7069e055_000029_e876734d>:
  40e260:	vxorps xmm0,xmm0,xmm0
  40e264:	vmovups XMMWORD PTR [rcx],xmm0
  40e268:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e26d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e272:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e277:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40e27c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40e281:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40e286:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40e28b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40e293:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40e29b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40e2a3:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40e2ab:	mov    QWORD PTR [rcx+0xc0],0x0
  40e2b6:	ret
	...

000000000040e2c0 <__swc_fn_7069e055_000032_f1940e30>:
  40e2c0:	push   rsi
  40e2c1:	push   rdi
  40e2c2:	sub    rsp,0x8
  40e2c6:	mov    rsi,rcx
  40e2c9:	lea    rdi,[rip+0x13d30]        # 422000 <__swc_data_base_7069e055>
  40e2d0:	mov    rax,QWORD PTR [rdi]
  40e2d3:	cmp    rax,0xffffffffffffffff
  40e2d7:	je     40e2de <__swc_fn_7069e055_000032_f1940e30+0x1e>
  40e2d9:	mov    rdi,rax
  40e2dc:	jmp    40e30b <__swc_fn_7069e055_000032_f1940e30+0x4b>
  40e2de:	call   409580 <__swc_fn_7069e055_000123_e4107ade>
  40e2e3:	mov    rcx,rax
  40e2e6:	cmp    rax,0xffffffffffffffff
  40e2ea:	je     40e31c <__swc_fn_7069e055_000032_f1940e30+0x5c>
  40e2ec:	mov    rax,0xffffffffffffffff
  40e2f3:	lock cmpxchg QWORD PTR [rdi],rcx
  40e2f8:	cmp    rax,0xffffffffffffffff
  40e2fc:	je     40e308 <__swc_fn_7069e055_000032_f1940e30+0x48>
  40e2fe:	mov    rdi,rax
  40e301:	call   40cb70 <__swc_fn_7069e055_000124_37eaf452>
  40e306:	jmp    40e30b <__swc_fn_7069e055_000032_f1940e30+0x4b>
  40e308:	mov    rdi,rcx
  40e30b:	cmp    rdi,0xffffffffffffffff
  40e30f:	je     40e31c <__swc_fn_7069e055_000032_f1940e30+0x5c>
  40e311:	mov    rcx,rdi
  40e314:	mov    rdx,rsi
  40e317:	call   4103d0 <__swc_fn_7069e055_000125_7a81492f>
  40e31c:	add    rsp,0x8
  40e320:	pop    rdi
  40e321:	pop    rsi
  40e322:	ret
	...

000000000040e330 <__swc_fn_7069e055_000035_ab2e8c35>:
  40e330:	sub    rsp,0x38
  40e334:	mov    rax,rdx
  40e337:	test   dl,dl
  40e339:	jne    40e351 <__swc_fn_7069e055_000035_ab2e8c35+0x21>
  40e33b:	mov    rax,r8
  40e33e:	test   r8b,r8b
  40e341:	cmove  eax,r9d
  40e345:	test   al,al
  40e347:	cmove  eax,r10d
  40e34b:	test   al,al
  40e34d:	cmove  eax,r11d
  40e351:	test   al,al
  40e353:	jne    40e35a <__swc_fn_7069e055_000035_ab2e8c35+0x2a>
  40e355:	add    rsp,0x38
  40e359:	ret
  40e35a:	lea    rcx,[rip+0x4daf]        # 413110 <__swc_rdata_base_7069e055>
  40e361:	vmovups xmm0,XMMWORD PTR [rip+0x4db7]        # 413120 <__swc_rdata_base_7069e055+0x10>
  40e369:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e36f:	vmovups xmm0,XMMWORD PTR [rip+0x4db9]        # 413130 <__swc_rdata_base_7069e055+0x20>
  40e377:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e37d:	vmovups xmm0,XMMWORD PTR [rip+0x4dbb]        # 413140 <__swc_rdata_base_7069e055+0x30>
  40e385:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e38b:	lea    rdx,[rsp+0x8]
  40e390:	call   40c3a0 <__swc_fn_7069e055_000103_0d4cc079>
  40e395:	jmp    40e355 <__swc_fn_7069e055_000035_ab2e8c35+0x25>
	...

000000000040e3a0 <__swc_fn_7069e055_000038_292d55e5>:
  40e3a0:	sub    rsp,0x8
  40e3a4:	mov    eax,0x1000
  40e3a9:	test   eax,eax
  40e3ab:	mov    r8d,0x8
  40e3b1:	cmove  eax,r8d
  40e3b5:	dec    rax
  40e3b8:	mov    r8,0xffffffffffffffff
  40e3bf:	sub    r8,rax
  40e3c2:	cmp    rdx,r8
  40e3c5:	ja     40e3d5 <__swc_fn_7069e055_000038_292d55e5+0x35>
  40e3c7:	add    rdx,rax
  40e3ca:	not    rax
  40e3cd:	mov    r8,rdx
  40e3d0:	and    r8,rax
  40e3d3:	jne    40e3dc <__swc_fn_7069e055_000038_292d55e5+0x3c>
  40e3d5:	xor    eax,eax
  40e3d7:	add    rsp,0x8
  40e3db:	ret
  40e3dc:	mov    rdx,r8
  40e3df:	call   40aaa0 <__swc_fn_7069e055_000037_1e381f55>
  40e3e4:	add    rsp,0x8
  40e3e8:	ret
  40e3e9:	add    BYTE PTR [rax],al
  40e3eb:	add    BYTE PTR [rax],al
  40e3ed:	add    BYTE PTR [rax],al
	...

000000000040e3f0 <__swc_fn_7069e055_000041_41400651>:
  40e3f0:	push   rsi
  40e3f1:	push   rdi
  40e3f2:	sub    rsp,0x8
  40e3f6:	mov    rsi,rdx
  40e3f9:	mov    rdi,rcx
  40e3fc:	test   rdx,rdx
  40e3ff:	je     40e41b <__swc_fn_7069e055_000041_41400651+0x2b>
  40e401:	xor    ecx,ecx
  40e403:	call   407720 <__swc_fn_7069e055_000033_d15eb4ea>
  40e408:	mov    rax,QWORD PTR [rsi]
  40e40b:	test   rax,rax
  40e40e:	je     40e41b <__swc_fn_7069e055_000041_41400651+0x2b>
  40e410:	mov    rcx,rax
  40e413:	mov    rdx,rsi
  40e416:	call   407840 <__swc_fn_7069e055_000042_0573444d>
  40e41b:	mov    rcx,rdi
  40e41e:	call   40ab00 <__swc_fn_7069e055_000040_8029566e>
  40e423:	mov    rsi,rax
  40e426:	test   rax,rax
  40e429:	jne    40e434 <__swc_fn_7069e055_000041_41400651+0x44>
  40e42b:	xor    eax,eax
  40e42d:	add    rsp,0x8
  40e431:	pop    rdi
  40e432:	pop    rsi
  40e433:	ret
  40e434:	mov    rcx,rsi
  40e437:	call   407720 <__swc_fn_7069e055_000033_d15eb4ea>
  40e43c:	mov    rax,rsi
  40e43f:	add    rsp,0x8
  40e443:	pop    rdi
  40e444:	pop    rsi
  40e445:	ret
	...

000000000040e450 <__swc_fn_7069e055_000044_fe6bbfdb>:
  40e450:	movzx  eax,BYTE PTR [r8+0x39]
  40e455:	lea    rax,[rax+rax*4]
  40e459:	lea    rax,[rdx+rax*8+0x28]
  40e45e:	mov    ecx,DWORD PTR [r8+0x6c]
  40e462:	test   ecx,ecx
  40e464:	je     40e49d <__swc_fn_7069e055_000044_fe6bbfdb+0x4d>
  40e466:	mov    rcx,QWORD PTR [r8+0x50]
  40e46a:	test   rcx,rcx
  40e46d:	je     40e479 <__swc_fn_7069e055_000044_fe6bbfdb+0x29>
  40e46f:	mov    rax,QWORD PTR [r8+0x48]
  40e473:	mov    QWORD PTR [rcx+0x48],rax
  40e477:	jmp    40e481 <__swc_fn_7069e055_000044_fe6bbfdb+0x31>
  40e479:	mov    rcx,QWORD PTR [r8+0x48]
  40e47d:	mov    QWORD PTR [rax+0x18],rcx
  40e481:	mov    rax,QWORD PTR [r8+0x48]
  40e485:	test   rax,rax
  40e488:	je     40e492 <__swc_fn_7069e055_000044_fe6bbfdb+0x42>
  40e48a:	mov    rcx,QWORD PTR [r8+0x50]
  40e48e:	mov    QWORD PTR [rax+0x50],rcx
  40e492:	vxorps xmm0,xmm0,xmm0
  40e496:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e49c:	ret
  40e49d:	mov    rcx,QWORD PTR [r8+0x50]
  40e4a1:	test   rcx,rcx
  40e4a4:	je     40e4b0 <__swc_fn_7069e055_000044_fe6bbfdb+0x60>
  40e4a6:	mov    rdx,QWORD PTR [r8+0x48]
  40e4aa:	mov    QWORD PTR [rcx+0x48],rdx
  40e4ae:	jmp    40e4b8 <__swc_fn_7069e055_000044_fe6bbfdb+0x68>
  40e4b0:	mov    rcx,QWORD PTR [r8+0x48]
  40e4b4:	mov    QWORD PTR [rax+0x8],rcx
  40e4b8:	mov    rcx,QWORD PTR [r8+0x48]
  40e4bc:	test   rcx,rcx
  40e4bf:	je     40e4cb <__swc_fn_7069e055_000044_fe6bbfdb+0x7b>
  40e4c1:	mov    rdx,QWORD PTR [r8+0x50]
  40e4c5:	mov    QWORD PTR [rcx+0x50],rdx
  40e4c9:	jmp    40e4d3 <__swc_fn_7069e055_000044_fe6bbfdb+0x83>
  40e4cb:	mov    rcx,QWORD PTR [r8+0x50]
  40e4cf:	mov    QWORD PTR [rax+0x10],rcx
  40e4d3:	cmp    QWORD PTR [rax],r8
  40e4d6:	jne    40e4df <__swc_fn_7069e055_000044_fe6bbfdb+0x8f>
  40e4d8:	mov    QWORD PTR [rax],0x0
  40e4df:	vxorps xmm0,xmm0,xmm0
  40e4e3:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e4e9:	ret
  40e4ea:	add    BYTE PTR [rax],al
  40e4ec:	add    BYTE PTR [rax],al
	...

000000000040e4f0 <__swc_fn_7069e055_000047_e7fd8d42>:
  40e4f0:	sub    rsp,0x8
  40e4f4:	mov    r9,r8
  40e4f7:	mov    r10,rdx
  40e4fa:	call   40e450 <__swc_fn_7069e055_000044_fe6bbfdb>
  40e4ff:	mov    DWORD PTR [r9+0x6c],0x0
  40e507:	movzx  eax,BYTE PTR [r9+0x39]
  40e50c:	lea    rax,[rax+rax*4]
  40e510:	lea    rax,[r10+rax*8+0x28]
  40e515:	mov    rcx,QWORD PTR [rax+0x10]
  40e519:	mov    QWORD PTR [r9+0x50],rcx
  40e51d:	mov    QWORD PTR [r9+0x48],0x0
  40e525:	mov    rcx,QWORD PTR [rax+0x10]
  40e529:	test   rcx,rcx
  40e52c:	je     40e534 <__swc_fn_7069e055_000047_e7fd8d42+0x44>
  40e52e:	mov    QWORD PTR [rcx+0x48],r9
  40e532:	jmp    40e538 <__swc_fn_7069e055_000047_e7fd8d42+0x48>
  40e534:	mov    QWORD PTR [rax+0x8],r9
  40e538:	mov    QWORD PTR [rax+0x10],r9
  40e53c:	add    rsp,0x8
  40e540:	ret
	...

000000000040e560 <__swc_fn_7069e055_000050_5e919db9>:
  40e560:	push   rsi
  40e561:	push   rdi
  40e562:	push   r12
  40e564:	push   r13
  40e566:	push   r14
  40e568:	push   r15
  40e56a:	sub    rsp,0x1f8
  40e571:	mov    esi,r8d
  40e574:	mov    QWORD PTR [rsp+0x1e8],rsi
  40e57c:	mov    rdi,rcx
  40e57f:	mov    r12,rdx
  40e582:	lea    r13,[rsi+rsi*4]
  40e586:	lea    r13,[rdx+r13*8+0x28]
  40e58b:	call   407ca0 <__swc_fn_7069e055_000048_8e68f77b>
  40e590:	add    DWORD PTR [r12+0x24],0x1
  40e596:	test   BYTE PTR [r12+0x24],0x3f
  40e59c:	jne    40e5a6 <__swc_fn_7069e055_000050_5e919db9+0x46>
  40e59e:	mov    rcx,rdi
  40e5a1:	call   40ac80 <__swc_fn_7069e055_000049_f6a485a2>
  40e5a6:	mov    rax,QWORD PTR [r13+0x8]
  40e5aa:	mov    r14,rax
  40e5ad:	nop    DWORD PTR [rax]
  40e5b0:	test   r14,r14
  40e5b3:	jne    40e5c2 <__swc_fn_7069e055_000050_5e919db9+0x62>
  40e5b5:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40e5bd:	jmp    40e6c9 <__swc_fn_7069e055_000050_5e919db9+0x169>
  40e5c2:	mov    r15,QWORD PTR [r14+0x48]
  40e5c6:	mov    rcx,r14
  40e5c9:	call   4073f0 <__swc_fn_7069e055_000009_4c3ebf16>
  40e5ce:	mov    rax,QWORD PTR [r14]
  40e5d1:	test   rax,rax
  40e5d4:	je     40e5e6 <__swc_fn_7069e055_000050_5e919db9+0x86>
  40e5d6:	mov    rcx,QWORD PTR [rax]
  40e5d9:	mov    QWORD PTR [r14],rcx
  40e5dc:	add    DWORD PTR [r14+0x28],0x1
  40e5e1:	mov    rsi,rax
  40e5e4:	jmp    40e605 <__swc_fn_7069e055_000050_5e919db9+0xa5>
  40e5e6:	mov    rax,QWORD PTR [r14+0x18]
  40e5ea:	cmp    QWORD PTR [r14+0x20],rax
  40e5ee:	jae    40e603 <__swc_fn_7069e055_000050_5e919db9+0xa3>
  40e5f0:	mov    rsi,QWORD PTR [r14+0x20]
  40e5f4:	mov    eax,DWORD PTR [r14+0x2c]
  40e5f8:	add    QWORD PTR [r14+0x20],rax
  40e5fc:	add    DWORD PTR [r14+0x28],0x1
  40e601:	jmp    40e605 <__swc_fn_7069e055_000050_5e919db9+0xa5>
  40e603:	xor    esi,esi
  40e605:	test   rsi,rsi
  40e608:	jne    40e64d <__swc_fn_7069e055_000050_5e919db9+0xed>
  40e60a:	mov    rcx,r14
  40e60d:	call   407320 <__swc_fn_7069e055_000006_7b253ae1>
  40e612:	test   al,al
  40e614:	je     40e64d <__swc_fn_7069e055_000050_5e919db9+0xed>
  40e616:	mov    rax,QWORD PTR [r14]
  40e619:	test   rax,rax
  40e61c:	je     40e62b <__swc_fn_7069e055_000050_5e919db9+0xcb>
  40e61e:	mov    rcx,QWORD PTR [rax]
  40e621:	mov    QWORD PTR [r14],rcx
  40e624:	add    DWORD PTR [r14+0x28],0x1
  40e629:	jmp    40e64a <__swc_fn_7069e055_000050_5e919db9+0xea>
  40e62b:	mov    rax,QWORD PTR [r14+0x18]
  40e62f:	cmp    QWORD PTR [r14+0x20],rax
  40e633:	jae    40e648 <__swc_fn_7069e055_000050_5e919db9+0xe8>
  40e635:	mov    rax,QWORD PTR [r14+0x20]
  40e639:	mov    ecx,DWORD PTR [r14+0x2c]
  40e63d:	add    QWORD PTR [r14+0x20],rcx
  40e641:	add    DWORD PTR [r14+0x28],0x1
  40e646:	jmp    40e64a <__swc_fn_7069e055_000050_5e919db9+0xea>
  40e648:	xor    eax,eax
  40e64a:	mov    rsi,rax
  40e64d:	test   rsi,rsi
  40e650:	jne    40e6a3 <__swc_fn_7069e055_000050_5e919db9+0x143>
  40e652:	mov    rcx,rdi
  40e655:	mov    rdx,r12
  40e658:	mov    r8,r14
  40e65b:	call   40abe0 <__swc_fn_7069e055_000046_b28a6ee7>
  40e660:	test   al,al
  40e662:	jne    40e6a3 <__swc_fn_7069e055_000050_5e919db9+0x143>
  40e664:	mov    rcx,r14
  40e667:	call   4073f0 <__swc_fn_7069e055_000009_4c3ebf16>
  40e66c:	mov    rax,QWORD PTR [r14]
  40e66f:	test   rax,rax
  40e672:	je     40e681 <__swc_fn_7069e055_000050_5e919db9+0x121>
  40e674:	mov    rcx,QWORD PTR [rax]
  40e677:	mov    QWORD PTR [r14],rcx
  40e67a:	add    DWORD PTR [r14+0x28],0x1
  40e67f:	jmp    40e6a0 <__swc_fn_7069e055_000050_5e919db9+0x140>
  40e681:	mov    rax,QWORD PTR [r14+0x18]
  40e685:	cmp    QWORD PTR [r14+0x20],rax
  40e689:	jae    40e69e <__swc_fn_7069e055_000050_5e919db9+0x13e>
  40e68b:	mov    rax,QWORD PTR [r14+0x20]
  40e68f:	mov    ecx,DWORD PTR [r14+0x2c]
  40e693:	add    QWORD PTR [r14+0x20],rcx
  40e697:	add    DWORD PTR [r14+0x28],0x1
  40e69c:	jmp    40e6a0 <__swc_fn_7069e055_000050_5e919db9+0x140>
  40e69e:	xor    eax,eax
  40e6a0:	mov    rsi,rax
  40e6a3:	test   rsi,rsi
  40e6a6:	je     40e6c1 <__swc_fn_7069e055_000050_5e919db9+0x161>
  40e6a8:	mov    QWORD PTR [r13+0x0],r14
  40e6ac:	mov    rax,rsi
  40e6af:	add    rsp,0x1f8
  40e6b6:	pop    r15
  40e6b8:	pop    r14
  40e6ba:	pop    r13
  40e6bc:	pop    r12
  40e6be:	pop    rdi
  40e6bf:	pop    rsi
  40e6c0:	ret
  40e6c1:	mov    r14,r15
  40e6c4:	jmp    40e5b0 <__swc_fn_7069e055_000050_5e919db9+0x50>
  40e6c9:	cs nop WORD PTR [rax+rax*1+0x0]
  40e6d3:	cs nop WORD PTR [rax+rax*1+0x0]
  40e6dd:	nop    DWORD PTR [rax]
  40e6e0:	mov    rcx,rdi
  40e6e3:	mov    rdx,r12
  40e6e6:	mov    r8d,esi
  40e6e9:	call   4079e0 <__swc_fn_7069e055_000045_bb688d37>
  40e6ee:	mov    r14,rax
  40e6f1:	test   rax,rax
  40e6f4:	jne    40e70a <__swc_fn_7069e055_000050_5e919db9+0x1aa>
  40e6f6:	xor    eax,eax
  40e6f8:	add    rsp,0x1f8
  40e6ff:	pop    r15
  40e701:	pop    r14
  40e703:	pop    r13
  40e705:	pop    r12
  40e707:	pop    rdi
  40e708:	pop    rsi
  40e709:	ret
  40e70a:	mov    QWORD PTR [r13+0x0],r14
  40e70e:	mov    rax,QWORD PTR [r14]
  40e711:	test   rax,rax
  40e714:	je     40e726 <__swc_fn_7069e055_000050_5e919db9+0x1c6>
  40e716:	mov    rcx,QWORD PTR [rax]
  40e719:	mov    QWORD PTR [r14],rcx
  40e71c:	add    DWORD PTR [r14+0x28],0x1
  40e721:	mov    r15,rax
  40e724:	jmp    40e746 <__swc_fn_7069e055_000050_5e919db9+0x1e6>
  40e726:	mov    rax,QWORD PTR [r14+0x18]
  40e72a:	cmp    QWORD PTR [r14+0x20],rax
  40e72e:	jae    40e743 <__swc_fn_7069e055_000050_5e919db9+0x1e3>
  40e730:	mov    r15,QWORD PTR [r14+0x20]
  40e734:	mov    eax,DWORD PTR [r14+0x2c]
  40e738:	add    QWORD PTR [r14+0x20],rax
  40e73c:	add    DWORD PTR [r14+0x28],0x1
  40e741:	jmp    40e746 <__swc_fn_7069e055_000050_5e919db9+0x1e6>
  40e743:	xor    r15d,r15d
  40e746:	test   r15,r15
  40e749:	jne    40e78e <__swc_fn_7069e055_000050_5e919db9+0x22e>
  40e74b:	mov    rcx,r14
  40e74e:	call   407320 <__swc_fn_7069e055_000006_7b253ae1>
  40e753:	test   al,al
  40e755:	je     40e78e <__swc_fn_7069e055_000050_5e919db9+0x22e>
  40e757:	mov    rax,QWORD PTR [r14]
  40e75a:	test   rax,rax
  40e75d:	je     40e76c <__swc_fn_7069e055_000050_5e919db9+0x20c>
  40e75f:	mov    rcx,QWORD PTR [rax]
  40e762:	mov    QWORD PTR [r14],rcx
  40e765:	add    DWORD PTR [r14+0x28],0x1
  40e76a:	jmp    40e78b <__swc_fn_7069e055_000050_5e919db9+0x22b>
  40e76c:	mov    rax,QWORD PTR [r14+0x18]
  40e770:	cmp    QWORD PTR [r14+0x20],rax
  40e774:	jae    40e789 <__swc_fn_7069e055_000050_5e919db9+0x229>
  40e776:	mov    rax,QWORD PTR [r14+0x20]
  40e77a:	mov    ecx,DWORD PTR [r14+0x2c]
  40e77e:	add    QWORD PTR [r14+0x20],rcx
  40e782:	add    DWORD PTR [r14+0x28],0x1
  40e787:	jmp    40e78b <__swc_fn_7069e055_000050_5e919db9+0x22b>
  40e789:	xor    eax,eax
  40e78b:	mov    r15,rax
  40e78e:	test   r15,r15
  40e791:	je     40e6e0 <__swc_fn_7069e055_000050_5e919db9+0x180>
  40e797:	mov    rax,r15
  40e79a:	add    rsp,0x1f8
  40e7a1:	pop    r15
  40e7a3:	pop    r14
  40e7a5:	pop    r13
  40e7a7:	pop    r12
  40e7a9:	pop    rdi
  40e7aa:	pop    rsi
  40e7ab:	ret
  40e7ac:	add    BYTE PTR [rax],al
	...

000000000040e7b0 <__swc_fn_7069e055_000053_9aa81fa7>:
  40e7b0:	push   rsi
  40e7b1:	push   rdi
  40e7b2:	push   r12
  40e7b4:	mov    rsi,rdx
  40e7b7:	mov    rax,rdx
  40e7ba:	shr    rax,0xc
  40e7be:	movabs rdx,0x9e3779b97f4a7c15
  40e7c8:	imul   rax,rdx
  40e7cc:	shr    rax,0x20
  40e7d0:	lea    rax,[rax*8+0x0]
  40e7d8:	shr    rax,0x20
  40e7dc:	lea    rax,[rax*8+0x0]
  40e7e4:	lea    rax,[rcx+rax*8+0x40]
  40e7e9:	xor    edx,edx
  40e7eb:	test   dl,dl
  40e7ed:	lea    rdi,[rcx+0x8]
  40e7f1:	cmove  rdi,rax
  40e7f5:	xor    edx,edx
  40e7f7:	test   dl,dl
  40e7f9:	lea    r12,[rcx+0x30]
  40e7fd:	lea    rax,[rax+0x8]
  40e801:	cmove  r12,rax
  40e805:	mov    rcx,rdi
  40e808:	call   4098a0 <__swc_fn_7069e055_000135_db32cc57>
  40e80d:	mov    QWORD PTR [rsi+0x30],0x0
  40e815:	mov    rax,QWORD PTR [r12]
  40e819:	mov    QWORD PTR [rsi+0x38],rax
  40e81d:	test   rax,rax
  40e820:	je     40e82a <__swc_fn_7069e055_000053_9aa81fa7+0x7a>
  40e822:	mov    rax,QWORD PTR [rsi+0x38]
  40e826:	mov    QWORD PTR [rax+0x30],rsi
  40e82a:	mov    QWORD PTR [r12],rsi
  40e82e:	mov    rcx,rdi
  40e831:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  40e836:	pop    r12
  40e838:	pop    rdi
  40e839:	pop    rsi
  40e83a:	ret
  40e83b:	add    BYTE PTR [rax],al
  40e83d:	add    BYTE PTR [rax],al
	...

000000000040e840 <__swc_fn_7069e055_000056_87dc216f>:
  40e840:	lea    rax,[rdx+rdx*4]
  40e844:	lea    rax,[rcx+rax*8+0x268]
  40e84c:	mov    rdx,QWORD PTR [rax+0x10]
  40e850:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e857:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e85f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e866:	lea    rdx,[rdx+rdx*4]
  40e86a:	lea    rdx,[rcx+rdx*8+0x268]
  40e872:	vmovups xmm0,XMMWORD PTR [rdx]
  40e876:	vmovups XMMWORD PTR [rax],xmm0
  40e87a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e87f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e884:	mov    rcx,QWORD PTR [rdx+0x20]
  40e888:	mov    QWORD PTR [rax+0x20],rcx
  40e88c:	ret
  40e88d:	add    BYTE PTR [rax],al
	...

000000000040e890 <__swc_fn_7069e055_000059_ee6a254c>:
  40e890:	push   rsi
  40e891:	push   rdi
  40e892:	push   r12
  40e894:	push   r13
  40e896:	sub    rsp,0x8
  40e89a:	mov    rsi,r8
  40e89d:	mov    rdi,rcx
  40e8a0:	mov    r12,rdx
  40e8a3:	xor    r13d,r13d
  40e8a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e8b0:	mov    eax,DWORD PTR [r12+0x730]
  40e8b8:	cmp    r13d,eax
  40e8bb:	jae    40e921 <__swc_fn_7069e055_000059_ee6a254c+0x91>
  40e8bd:	lea    rax,[r13+r13*4+0x0]
  40e8c2:	lea    rax,[r12+rax*8+0x738]
  40e8ca:	mov    rdx,QWORD PTR [rax]
  40e8cd:	mov    r8,QWORD PTR [rax+0x8]
  40e8d1:	mov    r9,QWORD PTR [rax+0x10]
  40e8d5:	cmp    QWORD PTR [rax+0x20],rsi
  40e8d9:	jb     40e8e0 <__swc_fn_7069e055_000059_ee6a254c+0x50>
  40e8db:	inc    r13d
  40e8de:	jmp    40e8b0 <__swc_fn_7069e055_000059_ee6a254c+0x20>
  40e8e0:	sub    DWORD PTR [r12+0x730],0x1
  40e8e9:	mov    ecx,DWORD PTR [r12+0x730]
  40e8f1:	lea    rcx,[rcx+rcx*4]
  40e8f5:	lea    rcx,[r12+rcx*8+0x738]
  40e8fd:	vmovups xmm0,XMMWORD PTR [rcx]
  40e901:	vmovups XMMWORD PTR [rax],xmm0
  40e905:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e90a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e90f:	mov    rcx,QWORD PTR [rcx+0x20]
  40e913:	mov    QWORD PTR [rax+0x20],rcx
  40e917:	mov    rcx,rdi
  40e91a:	call   407750 <__swc_fn_7069e055_000039_9ae4348f>
  40e91f:	jmp    40e8b0 <__swc_fn_7069e055_000059_ee6a254c+0x20>
  40e921:	add    rsp,0x8
  40e925:	pop    r13
  40e927:	pop    r12
  40e929:	pop    rdi
  40e92a:	pop    rsi
  40e92b:	ret
  40e92c:	add    BYTE PTR [rax],al
	...

000000000040e930 <__swc_fn_7069e055_000062_0a65f1d5>:
  40e930:	push   rsi
  40e931:	push   rdi
  40e932:	push   r12
  40e934:	push   r13
  40e936:	push   r14
  40e938:	mov    rsi,rcx
  40e93b:	mov    rdi,rdx
  40e93e:	mov    r12,QWORD PTR [rdi]
  40e941:	mov    r13,QWORD PTR [rdi+0x18]
  40e945:	mov    rax,r12
  40e948:	add    rax,QWORD PTR [rdi+0x8]
  40e94c:	sub    rax,r13
  40e94f:	cmp    r8,rax
  40e952:	jbe    40e95d <__swc_fn_7069e055_000062_0a65f1d5+0x2d>
  40e954:	pop    r14
  40e956:	pop    r13
  40e958:	pop    r12
  40e95a:	pop    rdi
  40e95b:	pop    rsi
  40e95c:	ret
  40e95d:	lea    rax,[r13+r8*1+0x0]
  40e962:	sub    rax,r12
  40e965:	mov    ecx,0x1000
  40e96a:	test   ecx,ecx
  40e96c:	mov    edx,0x8
  40e971:	cmove  ecx,edx
  40e974:	dec    rcx
  40e977:	mov    rdx,0xffffffffffffffff
  40e97e:	sub    rdx,rcx
  40e981:	cmp    rax,rdx
  40e984:	jbe    40e98b <__swc_fn_7069e055_000062_0a65f1d5+0x5b>
  40e986:	xor    r14d,r14d
  40e989:	jmp    40e996 <__swc_fn_7069e055_000062_0a65f1d5+0x66>
  40e98b:	add    rax,rcx
  40e98e:	andn   rax,rcx,rax
  40e993:	mov    r14,rax
  40e996:	mov    rax,QWORD PTR [rdi+0x10]
  40e99a:	cmp    r14,rax
  40e99d:	ja     40e9a8 <__swc_fn_7069e055_000062_0a65f1d5+0x78>
  40e99f:	pop    r14
  40e9a1:	pop    r13
  40e9a3:	pop    r12
  40e9a5:	pop    rdi
  40e9a6:	pop    rsi
  40e9a7:	ret
  40e9a8:	mov    rax,r12
  40e9ab:	add    rax,QWORD PTR [rdi+0x10]
  40e9af:	mov    rdx,r14
  40e9b2:	sub    rdx,QWORD PTR [rdi+0x10]
  40e9b6:	mov    rcx,rax
  40e9b9:	call   4072a0 <__swc_fn_7069e055_000003_81215399>
  40e9be:	test   al,al
  40e9c0:	jne    40e9cb <__swc_fn_7069e055_000062_0a65f1d5+0x9b>
  40e9c2:	pop    r14
  40e9c4:	pop    r13
  40e9c6:	pop    r12
  40e9c8:	pop    rdi
  40e9c9:	pop    rsi
  40e9ca:	ret
  40e9cb:	add    r12,r14
  40e9ce:	sub    r12,r13
  40e9d1:	mov    rcx,r12
  40e9d4:	sub    rcx,QWORD PTR [rdi+0x28]
  40e9d8:	mov    rdx,QWORD PTR [rsi+0x250]
  40e9df:	nop
  40e9e0:	lea    r8,[rdx+rcx*1]
  40e9e4:	mov    rax,rdx
  40e9e7:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40e9f0:	cmp    rax,rdx
  40e9f3:	je     40e9fa <__swc_fn_7069e055_000062_0a65f1d5+0xca>
  40e9f5:	mov    rdx,rax
  40e9f8:	jmp    40e9e0 <__swc_fn_7069e055_000062_0a65f1d5+0xb0>
  40e9fa:	mov    QWORD PTR [rdi+0x10],r14
  40e9fe:	mov    QWORD PTR [rdi+0x28],r12
  40ea02:	pop    r14
  40ea04:	pop    r13
  40ea06:	pop    r12
  40ea08:	pop    rdi
  40ea09:	pop    rsi
  40ea0a:	ret
  40ea0b:	add    BYTE PTR [rax],al
  40ea0d:	add    BYTE PTR [rax],al
	...

000000000040ea10 <__swc_fn_7069e055_000065_0b20477c>:
  40ea10:	push   rbx
  40ea11:	push   rsi
  40ea12:	push   rdi
  40ea13:	push   r12
  40ea15:	push   r13
  40ea17:	sub    rsp,0xe0
  40ea1e:	mov    rbx,rdx
  40ea21:	mov    rsi,rcx
  40ea24:	cmp    DWORD PTR [rbx+0x58],0x0
  40ea28:	je     40ea4c <__swc_fn_7069e055_000065_0b20477c+0x3c>
  40ea2a:	mov    eax,DWORD PTR [rbx+0x58]
  40ea2d:	sub    eax,0x1
  40ea30:	test   DWORD PTR [rbx+0x58],eax
  40ea33:	je     40ea4c <__swc_fn_7069e055_000065_0b20477c+0x3c>
  40ea35:	mov    QWORD PTR [rbx+0x40],0x0
  40ea3d:	add    rsp,0xe0
  40ea44:	pop    r13
  40ea46:	pop    r12
  40ea48:	pop    rdi
  40ea49:	pop    rsi
  40ea4a:	pop    rbx
  40ea4b:	ret
  40ea4c:	mov    rax,QWORD PTR [rbx+0x40]
  40ea50:	test   rax,rax
  40ea53:	jne    40ea6f <__swc_fn_7069e055_000065_0b20477c+0x5f>
  40ea55:	mov    rcx,rsi
  40ea58:	mov    rdx,rbx
  40ea5b:	call   40b890 <__swc_fn_7069e055_000064_20100e91>
  40ea60:	add    rsp,0xe0
  40ea67:	pop    r13
  40ea69:	pop    r12
  40ea6b:	pop    rdi
  40ea6c:	pop    rsi
  40ea6d:	pop    rbx
  40ea6e:	ret
  40ea6f:	cmp    QWORD PTR [rbx+0x48],0x0
  40ea74:	jne    40ea90 <__swc_fn_7069e055_000065_0b20477c+0x80>
  40ea76:	mov    rcx,rsi
  40ea79:	mov    rdx,rbx
  40ea7c:	call   407f90 <__swc_fn_7069e055_000066_918d3875>
  40ea81:	add    rsp,0xe0
  40ea88:	pop    r13
  40ea8a:	pop    r12
  40ea8c:	pop    rdi
  40ea8d:	pop    rsi
  40ea8e:	pop    rbx
  40ea8f:	ret
  40ea90:	mov    rdi,QWORD PTR [rbx+0x40]
  40ea94:	lea    rax,[rip+0x155d5]        # 424070 <__swc_bss_base_7069e055+0x30>
  40ea9b:	mov    rcx,rdi
  40ea9e:	sub    rcx,QWORD PTR [rax+0x8]
  40eaa2:	mov    rax,QWORD PTR [rip+0x155d7]        # 424080 <__swc_bss_base_7069e055+0x40>
  40eaa9:	cmp    rcx,rax
  40eaac:	jae    40ead8 <__swc_fn_7069e055_000065_0b20477c+0xc8>
  40eaae:	mov    rax,rdi
  40eab1:	and    rax,0xffffffffffc00000
  40eab8:	mov    rcx,rdi
  40eabb:	shr    rcx,0x10
  40eabf:	and    ecx,0x3f
  40eac2:	mov    edx,DWORD PTR [rax+0x28]
  40eac5:	shrx   ecx,ecx,edx
  40eaca:	shl    rcx,0x4
  40eace:	lea    r12,[rax+rcx*8+0x80]
  40ead6:	jmp    40eae3 <__swc_fn_7069e055_000065_0b20477c+0xd3>
  40ead8:	mov    rcx,rdi
  40eadb:	call   40a910 <__swc_fn_7069e055_000022_53fc00d2>
  40eae0:	mov    r12,rax
  40eae3:	test   r12,r12
  40eae6:	je     40eaf5 <__swc_fn_7069e055_000065_0b20477c+0xe5>
  40eae8:	mov    eax,DWORD PTR [r12+0x2c]
  40eaed:	mov    r9d,eax
  40eaf0:	mov    r13,rax
  40eaf3:	jmp    40eb74 <__swc_fn_7069e055_000065_0b20477c+0x164>
  40eaf5:	mov    rcx,rsi
  40eaf8:	mov    rdx,rdi
  40eafb:	call   40af20 <__swc_fn_7069e055_000052_92b016ae>
  40eb00:	mov    rcx,QWORD PTR [rax+0x28]
  40eb04:	mov    r9,rcx
  40eb07:	mov    rdx,QWORD PTR [rax+0x20]
  40eb0b:	mov    r13,rdx
  40eb0e:	cmp    QWORD PTR [rbx+0x48],rcx
  40eb12:	jbe    40eb4b <__swc_fn_7069e055_000065_0b20477c+0x13b>
  40eb14:	mov    ecx,DWORD PTR [rax+0x48]
  40eb17:	cmp    DWORD PTR [rbx+0x58],ecx
  40eb1a:	ja     40eb4b <__swc_fn_7069e055_000065_0b20477c+0x13b>
  40eb1c:	mov    rcx,rsi
  40eb1f:	mov    rdx,rax
  40eb22:	mov    r8,QWORD PTR [rbx+0x48]
  40eb26:	mov    QWORD PTR [rsp+0xc8],r9
  40eb2e:	mov    QWORD PTR [rsp+0xd0],rax
  40eb36:	call   40e930 <__swc_fn_7069e055_000062_0a65f1d5>
  40eb3b:	mov    r9,QWORD PTR [rsp+0xc8]
  40eb43:	mov    rax,QWORD PTR [rsp+0xd0]
  40eb4b:	mov    rcx,QWORD PTR [rax+0x28]
  40eb4f:	cmp    QWORD PTR [rbx+0x48],rcx
  40eb53:	ja     40eb74 <__swc_fn_7069e055_000065_0b20477c+0x164>
  40eb55:	mov    ecx,DWORD PTR [rax+0x48]
  40eb58:	cmp    DWORD PTR [rbx+0x58],ecx
  40eb5b:	ja     40eb74 <__swc_fn_7069e055_000065_0b20477c+0x164>
  40eb5d:	mov    rcx,QWORD PTR [rbx+0x48]
  40eb61:	mov    QWORD PTR [rax+0x20],rcx
  40eb65:	add    rsp,0xe0
  40eb6c:	pop    r13
  40eb6e:	pop    r12
  40eb70:	pop    rdi
  40eb71:	pop    rsi
  40eb72:	pop    rbx
  40eb73:	ret
  40eb74:	test   r12,r12
  40eb77:	je     40eba9 <__swc_fn_7069e055_000065_0b20477c+0x199>
  40eb79:	cmp    QWORD PTR [rbx+0x48],r9
  40eb7d:	ja     40eba9 <__swc_fn_7069e055_000065_0b20477c+0x199>
  40eb7f:	cmp    DWORD PTR [rbx+0x58],0x40
  40eb83:	ja     40eba9 <__swc_fn_7069e055_000065_0b20477c+0x199>
  40eb85:	cmp    DWORD PTR [rbx+0x58],0x0
  40eb89:	je     40eb96 <__swc_fn_7069e055_000065_0b20477c+0x186>
  40eb8b:	mov    ecx,DWORD PTR [rbx+0x58]
  40eb8e:	dec    rcx
  40eb91:	test   rdi,rcx
  40eb94:	jne    40eba9 <__swc_fn_7069e055_000065_0b20477c+0x199>
  40eb96:	mov    QWORD PTR [rbx+0x40],rdi
  40eb9a:	add    rsp,0xe0
  40eba1:	pop    r13
  40eba3:	pop    r12
  40eba5:	pop    rdi
  40eba6:	pop    rsi
  40eba7:	pop    rbx
  40eba8:	ret
  40eba9:	vmovups xmm0,XMMWORD PTR [rbx]
  40ebad:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ebb3:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40ebb8:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ebbe:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40ebc3:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ebc9:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40ebce:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40ebd4:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40ebd9:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40ebdf:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40ebe4:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40ebea:	mov    QWORD PTR [rsp+0x48],0x0
  40ebf3:	mov    rcx,rsi
  40ebf6:	lea    rdx,[rsp+0x8]
  40ebfb:	call   40b890 <__swc_fn_7069e055_000064_20100e91>
  40ec00:	mov    rax,QWORD PTR [rsp+0x48]
  40ec05:	test   rax,rax
  40ec08:	jne    40ec21 <__swc_fn_7069e055_000065_0b20477c+0x211>
  40ec0a:	mov    QWORD PTR [rbx+0x40],0x0
  40ec12:	add    rsp,0xe0
  40ec19:	pop    r13
  40ec1b:	pop    r12
  40ec1d:	pop    rdi
  40ec1e:	pop    rsi
  40ec1f:	pop    rbx
  40ec20:	ret
  40ec21:	mov    rax,QWORD PTR [rbx+0x48]
  40ec25:	cmp    r13,rax
  40ec28:	cmovbe rax,r13
  40ec2c:	mov    rcx,QWORD PTR [rsp+0x48]
  40ec31:	mov    rdx,rdi
  40ec34:	mov    r8,rax
  40ec37:	call   4090e0 <__swc_fn_7069e055_000105_83487ba1>
  40ec3c:	vmovups xmm0,XMMWORD PTR [rbx]
  40ec40:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40ec46:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40ec4b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40ec51:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40ec56:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40ec5f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40ec64:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40ec6d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40ec72:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40ec7b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40ec80:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40ec89:	mov    QWORD PTR [rsp+0xa8],rdi
  40ec91:	mov    rcx,rsi
  40ec94:	lea    rdx,[rsp+0x68]
  40ec99:	call   407f90 <__swc_fn_7069e055_000066_918d3875>
  40ec9e:	mov    rax,QWORD PTR [rsp+0x48]
  40eca3:	mov    QWORD PTR [rbx+0x40],rax
  40eca7:	add    rsp,0xe0
  40ecae:	pop    r13
  40ecb0:	pop    r12
  40ecb2:	pop    rdi
  40ecb3:	pop    rsi
  40ecb4:	pop    rbx
  40ecb5:	ret
	...

000000000040ecc0 <__swc_fn_7069e055_000068_f501e74b>:
  40ecc0:	push   r12
  40ecc2:	push   rdi
  40ecc3:	push   rsi
  40ecc4:	push   r13
  40ecc6:	push   r14
  40ecc8:	sub    rsp,0x190
  40eccf:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40ecd8:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40ece1:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40ecea:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40ecf3:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40ecfc:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40ed05:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40ed0e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40ed17:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40ed20:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40ed29:	mov    r12,rcx
  40ed2c:	lea    rax,[rip+0x132cd]        # 422000 <__swc_data_base_7069e055>
  40ed33:	mov    rax,QWORD PTR [rax]
  40ed36:	cmp    rax,0xffffffffffffffff
  40ed3a:	je     40ed49 <__swc_fn_7069e055_000068_f501e74b+0x89>
  40ed3c:	mov    eax,eax
  40ed3e:	mov    edi,eax
  40ed40:	xor    eax,eax
  40ed42:	call   407000 <pthread_getspecific@plt>
  40ed47:	jmp    40ed4b <__swc_fn_7069e055_000068_f501e74b+0x8b>
  40ed49:	xor    eax,eax
  40ed4b:	test   rax,rax
  40ed4e:	jne    40ed5d <__swc_fn_7069e055_000068_f501e74b+0x9d>
  40ed50:	call   40a9e0 <__swc_fn_7069e055_000031_3c3e930e>
  40ed55:	mov    rcx,rax
  40ed58:	call   410480 <__swc_fn_7069e055_000128_8d8a7dd2>
  40ed5d:	test   rax,rax
  40ed60:	je     40ed86 <__swc_fn_7069e055_000068_f501e74b+0xc6>
  40ed62:	cmp    QWORD PTR [rax],r12
  40ed65:	jne    40ed86 <__swc_fn_7069e055_000068_f501e74b+0xc6>
  40ed67:	xor    ecx,ecx
  40ed69:	mov    QWORD PTR [rsp+0xc8],rax
  40ed71:	call   407720 <__swc_fn_7069e055_000033_d15eb4ea>
  40ed76:	mov    rdx,QWORD PTR [rsp+0xc8]
  40ed7e:	mov    rcx,r12
  40ed81:	call   407840 <__swc_fn_7069e055_000042_0573444d>
  40ed86:	lea    rsi,[r12+0x10]
  40ed8b:	mov    rcx,rsi
  40ed8e:	call   4098a0 <__swc_fn_7069e055_000135_db32cc57>
  40ed93:	mov    rdi,QWORD PTR [r12+0x20]
  40ed98:	test   rdi,rdi
  40ed9b:	je     40edde <__swc_fn_7069e055_000068_f501e74b+0x11e>
  40ed9d:	nop    DWORD PTR [rax]
  40eda0:	mov    rcx,r12
  40eda3:	mov    rdx,rdi
  40eda6:	call   40aba0 <__swc_fn_7069e055_000043_47ff6d9b>
  40edab:	mov    rcx,r12
  40edae:	mov    rdx,rdi
  40edb1:	mov    r8,0xffffffffffffffff
  40edb8:	call   40e890 <__swc_fn_7069e055_000059_ee6a254c>
  40edbd:	mov    rcx,r12
  40edc0:	mov    rdx,rdi
  40edc3:	mov    r8d,0x9b8
  40edc9:	mov    r9d,0x9b8
  40edcf:	call   407750 <__swc_fn_7069e055_000039_9ae4348f>
  40edd4:	mov    rdi,QWORD PTR [r12+0x20]
  40edd9:	test   rdi,rdi
  40eddc:	jne    40eda0 <__swc_fn_7069e055_000068_f501e74b+0xe0>
  40edde:	xor    eax,eax
  40ede0:	xchg   QWORD PTR [r12+0x2a80],rax
  40ede8:	test   rax,rax
  40edeb:	je     40ee11 <__swc_fn_7069e055_000068_f501e74b+0x151>
  40eded:	cs nop WORD PTR [rax+rax*1+0x0]
  40edf7:	nop    WORD PTR [rax+rax*1+0x0]
  40ee00:	mov    rcx,rax
  40ee03:	mov    rax,QWORD PTR [rax+0x78]
  40ee07:	xor    edx,edx
  40ee09:	xchg   DWORD PTR [rcx+0x70],edx
  40ee0c:	test   rax,rax
  40ee0f:	jne    40ee00 <__swc_fn_7069e055_000068_f501e74b+0x140>
  40ee11:	mov    rax,QWORD PTR [r12+0x18]
  40ee16:	mov    rdi,rax
  40ee19:	test   rdi,rdi
  40ee1c:	je     40eeb1 <__swc_fn_7069e055_000068_f501e74b+0x1f1>
  40ee22:	cs nop WORD PTR [rax+rax*1+0x0]
  40ee2c:	nop    DWORD PTR [rax+0x0]
  40ee30:	mov    rax,QWORD PTR [rdi+0x10]
  40ee34:	mov    r8d,DWORD PTR [rdi+0x2c]
  40ee38:	xor    r9d,r9d
  40ee3b:	test   r8,r8
  40ee3e:	jbe    40ee9d <__swc_fn_7069e055_000068_f501e74b+0x1dd>
  40ee40:	mov    ecx,r9d
  40ee43:	shl    rcx,0x4
  40ee47:	lea    rdx,[rdi+rcx*8+0x80]
  40ee4f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40ee53:	je     40ee94 <__swc_fn_7069e055_000068_f501e74b+0x1d4>
  40ee55:	mov    DWORD PTR [rdx+0x28],0x0
  40ee5c:	mov    rcx,rdi
  40ee5f:	mov    QWORD PTR [rsp+0xd0],rax
  40ee67:	mov    QWORD PTR [rsp+0xd8],r8
  40ee6f:	mov    QWORD PTR [rsp+0xe0],r9
  40ee77:	call   40dfc0 <__swc_fn_7069e055_000014_be17798c>
  40ee7c:	mov    rax,QWORD PTR [rsp+0xd0]
  40ee84:	mov    r8,QWORD PTR [rsp+0xd8]
  40ee8c:	mov    r9,QWORD PTR [rsp+0xe0]
  40ee94:	add    r9,0x1
  40ee98:	cmp    r9,r8
  40ee9b:	jb     40ee40 <__swc_fn_7069e055_000068_f501e74b+0x180>
  40ee9d:	mov    rcx,rdi
  40eea0:	mov    rdi,rax
  40eea3:	call   407630 <__swc_fn_7069e055_000021_9cf87641>
  40eea8:	test   rdi,rdi
  40eeab:	jne    40ee30 <__swc_fn_7069e055_000068_f501e74b+0x170>
  40eeb1:	mov    QWORD PTR [r12+0x18],0x0
  40eeba:	mov    QWORD PTR [r12+0x28],0x0
  40eec3:	mov    rcx,rsi
  40eec6:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  40eecb:	mov    esi,0x8
  40eed0:	xor    edi,edi
  40eed2:	test   rsi,rsi
  40eed5:	je     40ef32 <__swc_fn_7069e055_000068_f501e74b+0x272>
  40eedb:	nop    DWORD PTR [rax+rax*1+0x0]
  40eee0:	lea    r13,[rdi*8+0x0]
  40eee8:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40eeed:	test   r14,r14
  40eef0:	je     40ef28 <__swc_fn_7069e055_000068_f501e74b+0x268>
  40eef2:	cs nop WORD PTR [rax+rax*1+0x0]
  40eefc:	nop    DWORD PTR [rax+0x0]
  40ef00:	mov    rcx,r12
  40ef03:	mov    rdx,r14
  40ef06:	call   407df0 <__swc_fn_7069e055_000054_e8e85c01>
  40ef0b:	mov    rcx,r12
  40ef0e:	mov    rdx,QWORD PTR [r14]
  40ef11:	mov    r8,QWORD PTR [r14+0x8]
  40ef15:	mov    r9,QWORD PTR [r14+0x10]
  40ef19:	call   407750 <__swc_fn_7069e055_000039_9ae4348f>
  40ef1e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ef23:	test   r14,r14
  40ef26:	jne    40ef00 <__swc_fn_7069e055_000068_f501e74b+0x240>
  40ef28:	add    rdi,0x1
  40ef2c:	sub    rsi,0x1
  40ef30:	jne    40eee0 <__swc_fn_7069e055_000068_f501e74b+0x220>
  40ef32:	mov    rcx,r12
  40ef35:	call   407ec0 <__swc_fn_7069e055_000060_6818d0d1>
  40ef3a:	lea    rcx,[r12+0x250]
  40ef42:	mov    rdx,QWORD PTR [rcx]
  40ef45:	mov    r8,QWORD PTR [r12+0x250]
  40ef4d:	nop    DWORD PTR [rax]
  40ef50:	mov    r9,r8
  40ef53:	sub    r9,rdx
  40ef56:	mov    rax,r8
  40ef59:	lock cmpxchg QWORD PTR [rcx],r9
  40ef5e:	cmp    rax,r8
  40ef61:	je     40ef68 <__swc_fn_7069e055_000068_f501e74b+0x2a8>
  40ef63:	mov    r8,rax
  40ef66:	jmp    40ef50 <__swc_fn_7069e055_000068_f501e74b+0x290>
  40ef68:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40ef71:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40ef7a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40ef83:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40ef8c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40ef95:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40ef9e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40efa7:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40efb0:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40efb9:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40efc2:	add    rsp,0x190
  40efc9:	pop    r14
  40efcb:	pop    r13
  40efcd:	pop    rsi
  40efce:	pop    rdi
  40efcf:	pop    r12
  40efd1:	ret
	...

000000000040efe0 <__swc_fn_7069e055_000071_1e1e3bf8>:
  40efe0:	sub    rsp,0x8
  40efe4:	mov    QWORD PTR [rdx+0x40],0x0
  40efec:	call   40b890 <__swc_fn_7069e055_000064_20100e91>
  40eff1:	add    rsp,0x8
  40eff5:	ret
	...

000000000040f000 <__swc_fn_7069e055_000074_30b8696a>:
  40f000:	sub    rsp,0x8
  40f004:	call   407f90 <__swc_fn_7069e055_000066_918d3875>
  40f009:	add    rsp,0x8
  40f00d:	ret
	...

000000000040f010 <__swc_fn_7069e055_000077_948ef603>:
  40f010:	push   rbx
  40f011:	push   rsi
  40f012:	push   rdi
  40f013:	push   r12
  40f015:	push   r13
  40f017:	push   r14
  40f019:	push   r15
  40f01b:	sub    rsp,0x20
  40f01f:	mov    rbx,r11
  40f022:	mov    rsi,rcx
  40f025:	mov    rdi,rdx
  40f028:	mov    r12,r8
  40f02b:	mov    r13,r9
  40f02e:	mov    r14,r10
  40f031:	mov    rcx,QWORD PTR [rip+0x17d08]        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40f038:	test   rcx,rcx
  40f03b:	jne    40f04d <__swc_fn_7069e055_000077_948ef603+0x3d>
  40f03d:	call   40a1a0 <__swc_fn_7069e055_000165_56054fe7>
  40f042:	lea    rcx,[rax+0x1]
  40f046:	mov    QWORD PTR [rip+0x17cf3],rcx        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40f04d:	dec    rcx
  40f050:	call   411f00 <__swc_fn_7069e055_000167_39c041ad>
  40f055:	mov    r15,rax
  40f058:	lea    r11,[rip+0x151e1]        # 424240 <__swc_bss_base_7069e055+0x200>
  40f05f:	mov    rcx,r11
  40f062:	call   407740 <__swc_fn_7069e055_000036_290a131c>
  40f067:	test   al,al
  40f069:	jne    40f07a <__swc_fn_7069e055_000077_948ef603+0x6a>
  40f06b:	mov    rcx,r11
  40f06e:	call   40aa40 <__swc_fn_7069e055_000034_cf5ba7bd>
  40f073:	lea    r11,[rip+0x151c6]        # 424240 <__swc_bss_base_7069e055+0x200>
  40f07a:	mov    rcx,r11
  40f07d:	mov    rdx,rsi
  40f080:	mov    r8,rdi
  40f083:	mov    r9,r12
  40f086:	mov    r10,r13
  40f089:	mov    rsi,r11
  40f08c:	mov    r11,r14
  40f08f:	call   40e330 <__swc_fn_7069e055_000035_ab2e8c35>
  40f094:	test   bl,bl
  40f096:	je     40f0bd <__swc_fn_7069e055_000077_948ef603+0xad>
  40f098:	mov    QWORD PTR [rsp+0x8],rsi
  40f09d:	lea    rax,[rip+0x40ac]        # 413150 <__swc_rdata_base_7069e055+0x40>
  40f0a4:	mov    QWORD PTR [rsp+0x10],rax
  40f0a9:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f0af:	vmovups XMMWORD PTR [r15],xmm0
  40f0b4:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40f0bd:	mov    rax,rsi
  40f0c0:	add    rsp,0x20
  40f0c4:	pop    r15
  40f0c6:	pop    r14
  40f0c8:	pop    r13
  40f0ca:	pop    r12
  40f0cc:	pop    rdi
  40f0cd:	pop    rsi
  40f0ce:	pop    rbx
  40f0cf:	ret

000000000040f0d0 <__swc_fn_7069e055_000080_207908fe>:
  40f0d0:	sub    rsp,0x8
  40f0d4:	mov    rax,rcx
  40f0d7:	test   rcx,rcx
  40f0da:	jne    40f0e1 <__swc_fn_7069e055_000080_207908fe+0x11>
  40f0dc:	add    rsp,0x8
  40f0e0:	ret
  40f0e1:	lea    rcx,[rax-0x10]
  40f0e5:	mov    rax,QWORD PTR [rax-0x10]
  40f0e9:	mov    rdx,rax
  40f0ec:	call   410130 <__swc_fn_7069e055_000113_4e83a03a>
  40f0f1:	add    rsp,0x8
  40f0f5:	ret
	...

000000000040f100 <__swc_fn_7069e055_000083_f2d93dad>:
  40f100:	sub    rsp,0x8
  40f104:	xor    r11d,r11d
  40f107:	call   408250 <__swc_fn_7069e055_000084_5ed30bd6>
  40f10c:	add    rsp,0x8
  40f110:	ret
	...

000000000040f120 <__swc_fn_7069e055_000086_d9243de4>:
  40f120:	push   rsi
  40f121:	push   rdi
  40f122:	push   r12
  40f124:	push   r13
  40f126:	push   r14
  40f128:	push   r15
  40f12a:	sub    rsp,0x68
  40f12e:	mov    rsi,r9
  40f131:	mov    rdi,rcx
  40f134:	mov    r12,rdx
  40f137:	mov    r13,r8
  40f13a:	cmp    r8,r9
  40f13d:	jne    40f165 <__swc_fn_7069e055_000086_d9243de4+0x45>
  40f13f:	mov    rcx,rdi
  40f142:	mov    rdx,r12
  40f145:	xor    r8d,r8d
  40f148:	call   4085a0 <__swc_fn_7069e055_000090_14cf59b2>
  40f14d:	test   al,al
  40f14f:	je     40f165 <__swc_fn_7069e055_000086_d9243de4+0x45>
  40f151:	mov    eax,0x1
  40f156:	add    rsp,0x68
  40f15a:	pop    r15
  40f15c:	pop    r14
  40f15e:	pop    r13
  40f160:	pop    r12
  40f162:	pop    rdi
  40f163:	pop    rsi
  40f164:	ret
  40f165:	cmp    BYTE PTR [r12+0x2c],0xe
  40f16b:	je     40f17e <__swc_fn_7069e055_000086_d9243de4+0x5e>
  40f16d:	xor    eax,eax
  40f16f:	add    rsp,0x68
  40f173:	pop    r15
  40f175:	pop    r14
  40f177:	pop    r13
  40f179:	pop    r12
  40f17b:	pop    rdi
  40f17c:	pop    rsi
  40f17d:	ret
  40f17e:	mov    r14,QWORD PTR [r12+0x98]
  40f186:	mov    rax,QWORD PTR [r12+0xa0]
  40f18e:	mov    r12,rax
  40f191:	xor    r15d,r15d
  40f194:	test   r12,r12
  40f197:	je     40f1ff <__swc_fn_7069e055_000086_d9243de4+0xdf>
  40f199:	nop    DWORD PTR [rax+0x0]
  40f1a0:	mov    QWORD PTR [rsp+0x58],r12
  40f1a5:	lea    r12,[r15*8+0x0]
  40f1ad:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40f1b2:	mov    rcx,rax
  40f1b5:	call   40c020 <__swc_fn_7069e055_000082_ff7d1455>
  40f1ba:	cmp    BYTE PTR [rax+0x2c],0xe
  40f1be:	jne    40f1f0 <__swc_fn_7069e055_000086_d9243de4+0xd0>
  40f1c0:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40f1c5:	lea    r8,[r13+rcx*1+0x0]
  40f1ca:	mov    rcx,rdi
  40f1cd:	mov    rdx,rax
  40f1d0:	mov    r9,rsi
  40f1d3:	call   40f120 <__swc_fn_7069e055_000086_d9243de4>
  40f1d8:	test   al,al
  40f1da:	je     40f1f0 <__swc_fn_7069e055_000086_d9243de4+0xd0>
  40f1dc:	mov    eax,0x1
  40f1e1:	add    rsp,0x68
  40f1e5:	pop    r15
  40f1e7:	pop    r14
  40f1e9:	pop    r13
  40f1eb:	pop    r12
  40f1ed:	pop    rdi
  40f1ee:	pop    rsi
  40f1ef:	ret
  40f1f0:	add    r15,0x1
  40f1f4:	mov    r12,QWORD PTR [rsp+0x58]
  40f1f9:	sub    r12,0x1
  40f1fd:	jne    40f1a0 <__swc_fn_7069e055_000086_d9243de4+0x80>
  40f1ff:	xor    eax,eax
  40f201:	add    rsp,0x68
  40f205:	pop    r15
  40f207:	pop    r14
  40f209:	pop    r13
  40f20b:	pop    r12
  40f20d:	pop    rdi
  40f20e:	pop    rsi
  40f20f:	ret

000000000040f210 <__swc_fn_7069e055_000089_3c530920>:
  40f210:	push   rbp
  40f211:	push   rbx
  40f212:	push   rsi
  40f213:	push   rdi
  40f214:	push   r12
  40f216:	push   r13
  40f218:	push   r14
  40f21a:	push   r15
  40f21c:	sub    rsp,0x38
  40f220:	mov    rbp,rsp
  40f223:	mov    rbx,r11
  40f226:	mov    rsi,rdx
  40f229:	mov    rdi,r8
  40f22c:	mov    r12,r9
  40f22f:	mov    QWORD PTR [rsp+0x18],r9
  40f234:	mov    r13,r10
  40f237:	movzx  r14d,BYTE PTR [rbp+0x80]
  40f23f:	movzx  r15d,BYTE PTR [rbp+0x88]
  40f247:	test   r11,r11
  40f24a:	je     40f250 <__swc_fn_7069e055_000089_3c530920+0x40>
  40f24c:	xor    eax,eax
  40f24e:	mov    BYTE PTR [rbx],al
  40f250:	test   r12,r12
  40f253:	je     40f25e <__swc_fn_7069e055_000089_3c530920+0x4e>
  40f255:	mov    QWORD PTR [r12+0x8],0x0
  40f25e:	test   rcx,rcx
  40f261:	je     40f268 <__swc_fn_7069e055_000089_3c530920+0x58>
  40f263:	test   rsi,rsi
  40f266:	jne    40f27b <__swc_fn_7069e055_000089_3c530920+0x6b>
  40f268:	xor    eax,eax
  40f26a:	add    rsp,0x38
  40f26e:	pop    r15
  40f270:	pop    r14
  40f272:	pop    r13
  40f274:	pop    r12
  40f276:	pop    rdi
  40f277:	pop    rsi
  40f278:	pop    rbx
  40f279:	pop    rbp
  40f27a:	ret
  40f27b:	call   40c020 <__swc_fn_7069e055_000082_ff7d1455>
  40f280:	mov    r12,rax
  40f283:	mov    al,r15b
  40f286:	test   r15b,r15b
  40f289:	jne    40f299 <__swc_fn_7069e055_000089_3c530920+0x89>
  40f28b:	mov    eax,DWORD PTR [r12+0x28]
  40f290:	and    eax,0x10000
  40f296:	setne  al
  40f299:	lea    r15,[rsp+0x8]
  40f29e:	mov    QWORD PTR [rsp+0x20],r15
  40f2a3:	rex mov BYTE PTR [rsp+0x8],al
  40f2a8:	test   DWORD PTR [rsi+0x28],0x400000
  40f2af:	je     40f2e7 <__swc_fn_7069e055_000089_3c530920+0xd7>
  40f2b1:	test   rsi,rsi
  40f2b4:	je     40f2d4 <__swc_fn_7069e055_000089_3c530920+0xc4>
  40f2b6:	mov    rax,QWORD PTR [rsi+0x38]
  40f2ba:	cmp    QWORD PTR [rax+0x10],rsi
  40f2be:	jne    40f2d4 <__swc_fn_7069e055_000089_3c530920+0xc4>
  40f2c0:	rex mov al,BYTE PTR [rsp+0x8]
  40f2c5:	test   al,al
  40f2c7:	sete   al
  40f2ca:	test   r14b,r14b
  40f2cd:	sete   cl
  40f2d0:	test   al,cl
  40f2d2:	je     40f2e7 <__swc_fn_7069e055_000089_3c530920+0xd7>
  40f2d4:	xor    eax,eax
  40f2d6:	add    rsp,0x38
  40f2da:	pop    r15
  40f2dc:	pop    r14
  40f2de:	pop    r13
  40f2e0:	pop    r12
  40f2e2:	pop    rdi
  40f2e3:	pop    rsi
  40f2e4:	pop    rbx
  40f2e5:	pop    rbp
  40f2e6:	ret
  40f2e7:	mov    r15,r12
  40f2ea:	test   r14b,r14b
  40f2ed:	jne    40f304 <__swc_fn_7069e055_000089_3c530920+0xf4>
  40f2ef:	cmp    BYTE PTR [r12+0x2c],0x6
  40f2f5:	jne    40f304 <__swc_fn_7069e055_000089_3c530920+0xf4>
  40f2f7:	mov    rcx,QWORD PTR [r12+0x40]
  40f2fc:	call   40c020 <__swc_fn_7069e055_000082_ff7d1455>
  40f301:	mov    r15,rax
  40f304:	test   r14b,r14b
  40f307:	je     40f30d <__swc_fn_7069e055_000089_3c530920+0xfd>
  40f309:	mov    r15,QWORD PTR [r15+0x30]
  40f30d:	mov    rcx,rsi
  40f310:	call   40c020 <__swc_fn_7069e055_000082_ff7d1455>
  40f315:	mov    rsi,rax
  40f318:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f31d:	je     40f354 <__swc_fn_7069e055_000089_3c530920+0x144>
  40f31f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f324:	je     40f354 <__swc_fn_7069e055_000089_3c530920+0x144>
  40f326:	mov    eax,DWORD PTR [rsi+0x28]
  40f329:	and    eax,0x10000
  40f32f:	je     40f354 <__swc_fn_7069e055_000089_3c530920+0x144>
  40f331:	rex mov al,BYTE PTR [rsp+0x8]
  40f336:	test   al,al
  40f338:	jne    40f34d <__swc_fn_7069e055_000089_3c530920+0x13d>
  40f33a:	xor    eax,eax
  40f33c:	add    rsp,0x38
  40f340:	pop    r15
  40f342:	pop    r14
  40f344:	pop    r13
  40f346:	pop    r12
  40f348:	pop    rdi
  40f349:	pop    rsi
  40f34a:	pop    rbx
  40f34b:	pop    rbp
  40f34c:	ret
  40f34d:	mov    rax,QWORD PTR [rsi+0x30]
  40f351:	mov    rsi,rax
  40f354:	mov    r14b,r13b
  40f357:	test   rbx,rbx
  40f35a:	je     40f390 <__swc_fn_7069e055_000089_3c530920+0x180>
  40f35c:	cmp    BYTE PTR [r12+0x2c],0x6
  40f362:	jne    40f390 <__swc_fn_7069e055_000089_3c530920+0x180>
  40f364:	lea    rdx,[rip+0x3e15]        # 413180 <__swc_rdata_base_7069e055+0x70>
  40f36b:	mov    rcx,rsi
  40f36e:	xor    r8d,r8d
  40f371:	call   4085a0 <__swc_fn_7069e055_000090_14cf59b2>
  40f376:	test   al,al
  40f378:	je     40f390 <__swc_fn_7069e055_000089_3c530920+0x180>
  40f37a:	mov    BYTE PTR [rbx],0x1
  40f37d:	xor    eax,eax
  40f37f:	add    rsp,0x38
  40f383:	pop    r15
  40f385:	pop    r14
  40f387:	pop    r13
  40f389:	pop    r12
  40f38b:	pop    rdi
  40f38c:	pop    rsi
  40f38d:	pop    rbx
  40f38e:	pop    rbp
  40f38f:	ret
  40f390:	test   rdi,rdi
  40f393:	jne    40f3ad <__swc_fn_7069e055_000089_3c530920+0x19d>
  40f395:	test   r13b,r13b
  40f398:	jne    40f3ad <__swc_fn_7069e055_000089_3c530920+0x19d>
  40f39a:	xor    eax,eax
  40f39c:	add    rsp,0x38
  40f3a0:	pop    r15
  40f3a2:	pop    r14
  40f3a4:	pop    r13
  40f3a6:	pop    r12
  40f3a8:	pop    rdi
  40f3a9:	pop    rsi
  40f3aa:	pop    rbx
  40f3ab:	pop    rbp
  40f3ac:	ret
  40f3ad:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f3b2:	jne    40f468 <__swc_fn_7069e055_000089_3c530920+0x258>
  40f3b8:	mov    rcx,r15
  40f3bb:	mov    rdx,rsi
  40f3be:	xor    r8d,r8d
  40f3c1:	call   4085a0 <__swc_fn_7069e055_000090_14cf59b2>
  40f3c6:	test   al,al
  40f3c8:	jne    40f468 <__swc_fn_7069e055_000089_3c530920+0x258>
  40f3ce:	test   DWORD PTR [rsi+0x28],0x10000
  40f3d5:	je     40f3f3 <__swc_fn_7069e055_000089_3c530920+0x1e3>
  40f3d7:	rex mov al,BYTE PTR [rsp+0x8]
  40f3dc:	test   al,al
  40f3de:	jne    40f3f3 <__swc_fn_7069e055_000089_3c530920+0x1e3>
  40f3e0:	xor    eax,eax
  40f3e2:	add    rsp,0x38
  40f3e6:	pop    r15
  40f3e8:	pop    r14
  40f3ea:	pop    r13
  40f3ec:	pop    r12
  40f3ee:	pop    rdi
  40f3ef:	pop    rsi
  40f3f0:	pop    rbx
  40f3f1:	pop    rbp
  40f3f2:	ret
  40f3f3:	test   rdi,rdi
  40f3f6:	jne    40f40b <__swc_fn_7069e055_000089_3c530920+0x1fb>
  40f3f8:	xor    eax,eax
  40f3fa:	add    rsp,0x38
  40f3fe:	pop    r15
  40f400:	pop    r14
  40f402:	pop    r13
  40f404:	pop    r12
  40f406:	pop    rdi
  40f407:	pop    rsi
  40f408:	pop    rbx
  40f409:	pop    rbp
  40f40a:	ret
  40f40b:	mov    rcx,QWORD PTR [rsi+0x40]
  40f40f:	call   40c020 <__swc_fn_7069e055_000082_ff7d1455>
  40f414:	mov    rsi,rax
  40f417:	mov    rax,QWORD PTR [rdi]
  40f41a:	mov    rdi,rax
  40f41d:	test   rax,rax
  40f420:	jne    40f463 <__swc_fn_7069e055_000089_3c530920+0x253>
  40f422:	test   rbx,rbx
  40f425:	je     40f463 <__swc_fn_7069e055_000089_3c530920+0x253>
  40f427:	mov    rcx,r15
  40f42a:	mov    rdx,rsi
  40f42d:	xor    r8d,r8d
  40f430:	call   4085a0 <__swc_fn_7069e055_000090_14cf59b2>
  40f435:	mov    rcx,rax
  40f438:	test   al,al
  40f43a:	jne    40f45c <__swc_fn_7069e055_000089_3c530920+0x24c>
  40f43c:	mov    rcx,r15
  40f43f:	mov    rdx,rsi
  40f442:	call   40c060 <__swc_fn_7069e055_000085_e24ecd12>
  40f447:	mov    rcx,rax
  40f44a:	test   al,al
  40f44c:	jne    40f45c <__swc_fn_7069e055_000089_3c530920+0x24c>
  40f44e:	mov    rcx,rsi
  40f451:	mov    rdx,r15
  40f454:	call   40c060 <__swc_fn_7069e055_000085_e24ecd12>
  40f459:	mov    rcx,rax
  40f45c:	test   cl,cl
  40f45e:	setne  al
  40f461:	mov    BYTE PTR [rbx],al
  40f463:	xor    eax,eax
  40f465:	mov    r14b,al
  40f468:	test   rdi,rdi
  40f46b:	jne    40f485 <__swc_fn_7069e055_000089_3c530920+0x275>
  40f46d:	test   r14b,r14b
  40f470:	jne    40f485 <__swc_fn_7069e055_000089_3c530920+0x275>
  40f472:	xor    eax,eax
  40f474:	add    rsp,0x38
  40f478:	pop    r15
  40f47a:	pop    r14
  40f47c:	pop    r13
  40f47e:	pop    r12
  40f480:	pop    rdi
  40f481:	pop    rsi
  40f482:	pop    rbx
  40f483:	pop    rbp
  40f484:	ret
  40f485:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f48a:	je     40f496 <__swc_fn_7069e055_000089_3c530920+0x286>
  40f48c:	mov    r12,QWORD PTR [rsp+0x18]
  40f491:	jmp    40f51e <__swc_fn_7069e055_000089_3c530920+0x30e>
  40f496:	mov    r12,QWORD PTR [rsp+0x18]
  40f49b:	test   r12,r12
  40f49e:	jne    40f4b2 <__swc_fn_7069e055_000089_3c530920+0x2a2>
  40f4a0:	mov    rcx,r15
  40f4a3:	mov    rdx,rsi
  40f4a6:	xor    r8d,r8d
  40f4a9:	call   4085a0 <__swc_fn_7069e055_000090_14cf59b2>
  40f4ae:	test   al,al
  40f4b0:	jne    40f51e <__swc_fn_7069e055_000089_3c530920+0x30e>
  40f4b2:	test   DWORD PTR [rsi+0x28],0x10000
  40f4b9:	je     40f4d7 <__swc_fn_7069e055_000089_3c530920+0x2c7>
  40f4bb:	rex mov al,BYTE PTR [rsp+0x8]
  40f4c0:	test   al,al
  40f4c2:	jne    40f4d7 <__swc_fn_7069e055_000089_3c530920+0x2c7>
  40f4c4:	xor    eax,eax
  40f4c6:	add    rsp,0x38
  40f4ca:	pop    r15
  40f4cc:	pop    r14
  40f4ce:	pop    r13
  40f4d0:	pop    r12
  40f4d2:	pop    rdi
  40f4d3:	pop    rsi
  40f4d4:	pop    rbx
  40f4d5:	pop    rbp
  40f4d6:	ret
  40f4d7:	test   rdi,rdi
  40f4da:	jne    40f4ef <__swc_fn_7069e055_000089_3c530920+0x2df>
  40f4dc:	xor    eax,eax
  40f4de:	add    rsp,0x38
  40f4e2:	pop    r15
  40f4e4:	pop    r14
  40f4e6:	pop    r13
  40f4e8:	pop    r12
  40f4ea:	pop    rdi
  40f4eb:	pop    rsi
  40f4ec:	pop    rbx
  40f4ed:	pop    rbp
  40f4ee:	ret
  40f4ef:	cmp    QWORD PTR [rdi+0x8],0x0
  40f4f4:	jne    40f509 <__swc_fn_7069e055_000089_3c530920+0x2f9>
  40f4f6:	xor    eax,eax
  40f4f8:	add    rsp,0x38
  40f4fc:	pop    r15
  40f4fe:	pop    r14
  40f500:	pop    r13
  40f502:	pop    r12
  40f504:	pop    rdi
  40f505:	pop    rsi
  40f506:	pop    rbx
  40f507:	pop    rbp
  40f508:	ret
  40f509:	mov    rax,QWORD PTR [rdi+0x8]
  40f50d:	mov    rax,QWORD PTR [rax]
  40f510:	mov    rsi,rax
  40f513:	mov    rdi,QWORD PTR [rdi]
  40f516:	mov    eax,0x1
  40f51b:	mov    r14b,al
  40f51e:	test   rdi,rdi
  40f521:	mov    rbx,QWORD PTR [rsp+0x20]
  40f526:	jne    40f570 <__swc_fn_7069e055_000089_3c530920+0x360>
  40f528:	test   r14b,r14b
  40f52b:	je     40f55d <__swc_fn_7069e055_000089_3c530920+0x34d>
  40f52d:	test   r12,r12
  40f530:	je     40f55d <__swc_fn_7069e055_000089_3c530920+0x34d>
  40f532:	mov    rcx,r15
  40f535:	mov    rdx,rsi
  40f538:	xor    r8d,r8d
  40f53b:	mov    r9,r12
  40f53e:	mov    rbx,QWORD PTR [rsp+0x20]
  40f543:	movzx  r10d,BYTE PTR [rbx]
  40f547:	call   40f100 <__swc_fn_7069e055_000083_f2d93dad>
  40f54c:	add    rsp,0x38
  40f550:	pop    r15
  40f552:	pop    r14
  40f554:	pop    r13
  40f556:	pop    r12
  40f558:	pop    rdi
  40f559:	pop    rsi
  40f55a:	pop    rbx
  40f55b:	pop    rbp
  40f55c:	ret
  40f55d:	xor    eax,eax
  40f55f:	add    rsp,0x38
  40f563:	pop    r15
  40f565:	pop    r14
  40f567:	pop    r13
  40f569:	pop    r12
  40f56b:	pop    rdi
  40f56c:	pop    rsi
  40f56d:	pop    rbx
  40f56e:	pop    rbp
  40f56f:	ret
  40f570:	mov    r13,rsi
  40f573:	mov    QWORD PTR [rsp+0x28],rdi
  40f578:	cmp    BYTE PTR [r15+0x2c],0xe
  40f57d:	sete   al
  40f580:	mov    r14b,al
  40f583:	jne    40f597 <__swc_fn_7069e055_000089_3c530920+0x387>
  40f585:	mov    rcx,rsi
  40f588:	mov    rdx,r15
  40f58b:	call   40c060 <__swc_fn_7069e055_000085_e24ecd12>
  40f590:	mov    r14b,al
  40f593:	test   al,al
  40f595:	jne    40f5cc <__swc_fn_7069e055_000089_3c530920+0x3bc>
  40f597:	cmp    BYTE PTR [r15+0x2c],0x12
  40f59c:	je     40f5cc <__swc_fn_7069e055_000089_3c530920+0x3bc>
  40f59e:	mov    rcx,r15
  40f5a1:	mov    rdx,rsi
  40f5a4:	mov    r8,rdi
  40f5a7:	mov    r9,r12
  40f5aa:	mov    rax,rbx
  40f5ad:	movzx  r10d,BYTE PTR [rax]
  40f5b1:	call   40f100 <__swc_fn_7069e055_000083_f2d93dad>
  40f5b6:	test   rax,rax
  40f5b9:	je     40f5cc <__swc_fn_7069e055_000089_3c530920+0x3bc>
  40f5bb:	add    rsp,0x38
  40f5bf:	pop    r15
  40f5c1:	pop    r14
  40f5c3:	pop    r13
  40f5c5:	pop    r12
  40f5c7:	pop    rdi
  40f5c8:	pop    rsi
  40f5c9:	pop    rbx
  40f5ca:	pop    rbp
  40f5cb:	ret
  40f5cc:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40f5d1:	jne    40f5f0 <__swc_fn_7069e055_000089_3c530920+0x3e0>
  40f5d3:	mov    rax,QWORD PTR [rsi+0xd8]
  40f5da:	test   rax,rax
  40f5dd:	je     40f5f0 <__swc_fn_7069e055_000089_3c530920+0x3e0>
  40f5df:	add    rdi,QWORD PTR [rax+0x8]
  40f5e3:	mov    rax,QWORD PTR [rdi]
  40f5e6:	sub    rdi,QWORD PTR [rax+0x8]
  40f5ea:	mov    rax,QWORD PTR [rax]
  40f5ed:	mov    rsi,rax
  40f5f0:	test   r14b,r14b
  40f5f3:	je     40f61f <__swc_fn_7069e055_000089_3c530920+0x40f>
  40f5f5:	mov    rcx,r15
  40f5f8:	mov    rdx,rsi
  40f5fb:	mov    r8,rdi
  40f5fe:	mov    r9,r13
  40f601:	mov    r14,QWORD PTR [rsp+0x28]
  40f606:	mov    r10,r14
  40f609:	call   408480 <__swc_fn_7069e055_000087_693f118e>
  40f60e:	add    rsp,0x38
  40f612:	pop    r15
  40f614:	pop    r14
  40f616:	pop    r13
  40f618:	pop    r12
  40f61a:	pop    rdi
  40f61b:	pop    rsi
  40f61c:	pop    rbx
  40f61d:	pop    rbp
  40f61e:	ret
  40f61f:	mov    rcx,r15
  40f622:	mov    rdx,rsi
  40f625:	mov    r8,rdi
  40f628:	mov    r9,r12
  40f62b:	movzx  r10d,BYTE PTR [rbx]
  40f62f:	call   40f100 <__swc_fn_7069e055_000083_f2d93dad>
  40f634:	add    rsp,0x38
  40f638:	pop    r15
  40f63a:	pop    r14
  40f63c:	pop    r13
  40f63e:	pop    r12
  40f640:	pop    rdi
  40f641:	pop    rsi
  40f642:	pop    rbx
  40f643:	pop    rbp
  40f644:	ret
	...

000000000040f650 <__swc_fn_7069e055_000092_809deff5>:
  40f650:	push   rbx
  40f651:	push   rsi
  40f652:	sub    rsp,0x18
  40f656:	mov    rbx,rcx
  40f659:	mov    rcx,QWORD PTR [rip+0x176e0]        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40f660:	test   rcx,rcx
  40f663:	jne    40f675 <__swc_fn_7069e055_000092_809deff5+0x25>
  40f665:	call   40a1a0 <__swc_fn_7069e055_000165_56054fe7>
  40f66a:	lea    rcx,[rax+0x1]
  40f66e:	mov    QWORD PTR [rip+0x176cb],rcx        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40f675:	dec    rcx
  40f678:	call   411f00 <__swc_fn_7069e055_000167_39c041ad>
  40f67d:	mov    rsi,rax
  40f680:	mov    rax,QWORD PTR [rsi+0x8]
  40f684:	test   rax,rax
  40f687:	jne    40f6d7 <__swc_fn_7069e055_000092_809deff5+0x87>
  40f689:	call   40c150 <__swc_fn_7069e055_000091_f21926ed>
  40f68e:	test   al,al
  40f690:	jne    40f6d7 <__swc_fn_7069e055_000092_809deff5+0x87>
  40f692:	lea    rdx,[rip+0x14ba7]        # 424240 <__swc_bss_base_7069e055+0x200>
  40f699:	mov    rcx,rdx
  40f69c:	call   407740 <__swc_fn_7069e055_000036_290a131c>
  40f6a1:	test   al,al
  40f6a3:	jne    40f6b4 <__swc_fn_7069e055_000092_809deff5+0x64>
  40f6a5:	mov    rcx,rdx
  40f6a8:	call   40aa40 <__swc_fn_7069e055_000034_cf5ba7bd>
  40f6ad:	lea    rdx,[rip+0x14b8c]        # 424240 <__swc_bss_base_7069e055+0x200>
  40f6b4:	mov    QWORD PTR [rsp+0x8],rdx
  40f6b9:	lea    rax,[rip+0x3a90]        # 413150 <__swc_rdata_base_7069e055+0x40>
  40f6c0:	mov    QWORD PTR [rsp+0x10],rax
  40f6c5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f6cb:	vmovups XMMWORD PTR [rsi],xmm0
  40f6cf:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f6d7:	vmovups xmm0,XMMWORD PTR [rsi]
  40f6db:	vmovups XMMWORD PTR [rbx],xmm0
  40f6df:	mov    rax,rbx
  40f6e2:	add    rsp,0x18
  40f6e6:	pop    rsi
  40f6e7:	pop    rbx
  40f6e8:	ret
  40f6e9:	add    BYTE PTR [rax],al
  40f6eb:	add    BYTE PTR [rax],al
  40f6ed:	add    BYTE PTR [rax],al
	...

000000000040f6f0 <__swc_fn_7069e055_000095_8cc4b392>:
  40f6f0:	sub    rsp,0x8
  40f6f4:	call   409340 <__swc_fn_7069e055_000117_5aba1420>
  40f6f9:	add    rsp,0x8
  40f6fd:	ret
	...

000000000040f700 <__swc_fn_7069e055_000098_f82a1ed3>:
  40f700:	push   rbx
  40f701:	push   rsi
  40f702:	sub    rsp,0x28
  40f706:	mov    rbx,rcx
  40f709:	xor    esi,esi
  40f70b:	jmp    40f720 <__swc_fn_7069e055_000098_f82a1ed3+0x20>
  40f70d:	nop    DWORD PTR [rax]
  40f710:	mov    QWORD PTR [rbx+0x28],rsi
  40f714:	mov    rsi,rbx
  40f717:	mov    rbx,rax
  40f71a:	nop    WORD PTR [rax+rax*1+0x0]
  40f720:	test   rbx,rbx
  40f723:	je     40f783 <__swc_fn_7069e055_000098_f82a1ed3+0x83>
  40f725:	mov    rcx,rbx
  40f728:	mov    edx,0x1
  40f72d:	call   408200 <__swc_fn_7069e055_000078_140918ec>
  40f732:	cmp    rax,0x1
  40f736:	jne    40f783 <__swc_fn_7069e055_000098_f82a1ed3+0x83>
  40f738:	mov    r10,QWORD PTR [rbx+0x18]
  40f73c:	mov    rcx,r10
  40f73f:	mov    edx,0x1
  40f744:	call   408200 <__swc_fn_7069e055_000078_140918ec>
  40f749:	cmp    rax,0x1
  40f74d:	jne    40f75c <__swc_fn_7069e055_000098_f82a1ed3+0x5c>
  40f74f:	mov    rcx,r10
  40f752:	call   40c2f0 <__swc_fn_7069e055_000097_96d6739a>
  40f757:	test   rax,rax
  40f75a:	jne    40f710 <__swc_fn_7069e055_000098_f82a1ed3+0x10>
  40f75c:	mov    rax,QWORD PTR [rbx+0x20]
  40f760:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f765:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f76b:	lea    rcx,[rsp+0x8]
  40f770:	mov    rdx,rbx
  40f773:	mov    r8d,0x30
  40f779:	mov    rbx,rax
  40f77c:	call   408960 <__swc_fn_7069e055_000096_a4baaa40>
  40f781:	jmp    40f720 <__swc_fn_7069e055_000098_f82a1ed3+0x20>
  40f783:	test   rsi,rsi
  40f786:	jne    40f78f <__swc_fn_7069e055_000098_f82a1ed3+0x8f>
  40f788:	add    rsp,0x28
  40f78c:	pop    rsi
  40f78d:	pop    rbx
  40f78e:	ret
  40f78f:	mov    rax,rsi
  40f792:	mov    rsi,QWORD PTR [rsi+0x28]
  40f796:	mov    rbx,QWORD PTR [rax+0x20]
  40f79a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f79f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f7a5:	lea    rcx,[rsp+0x18]
  40f7aa:	mov    rdx,rax
  40f7ad:	mov    r8d,0x30
  40f7b3:	call   408960 <__swc_fn_7069e055_000096_a4baaa40>
  40f7b8:	jmp    40f720 <__swc_fn_7069e055_000098_f82a1ed3+0x20>
  40f7bd:	add    BYTE PTR [rax],al
	...

000000000040f7c0 <__swc_fn_7069e055_000101_afcb7774>:
  40f7c0:	push   rbx
  40f7c1:	push   rsi
  40f7c2:	push   rdi
  40f7c3:	push   r12
  40f7c5:	push   r13
  40f7c7:	sub    rsp,0x20
  40f7cb:	mov    rbx,rcx
  40f7ce:	lea    rsi,[rcx+0x6f8]
  40f7d5:	mov    edi,0x4
  40f7da:	mov    r12,rsi
  40f7dd:	test   rdi,rdi
  40f7e0:	je     40f82a <__swc_fn_7069e055_000101_afcb7774+0x6a>
  40f7e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f7ec:	nop    DWORD PTR [rax+0x0]
  40f7f0:	mov    rcx,QWORD PTR [r12+0x10]
  40f7f5:	mov    QWORD PTR [r12+0x10],0x0
  40f7fe:	vxorps xmm0,xmm0,xmm0
  40f802:	vmovups XMMWORD PTR [r12],xmm0
  40f808:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f80f:	mov    DWORD PTR [r12+0x20],0x0
  40f818:	call   4089b0 <__swc_fn_7069e055_000099_5232b57d>
  40f81d:	add    r12,0x90
  40f824:	sub    rdi,0x1
  40f828:	jne    40f7f0 <__swc_fn_7069e055_000101_afcb7774+0x30>
  40f82a:	mov    rax,QWORD PTR [rbx+0x938]
  40f831:	mov    rdi,rax
  40f834:	test   rdi,rdi
  40f837:	je     40f891 <__swc_fn_7069e055_000101_afcb7774+0xd1>
  40f839:	nop    DWORD PTR [rax+0x0]
  40f840:	mov    r12d,0x10
  40f846:	lea    r13,[rdi+0x18]
  40f84a:	test   r12,r12
  40f84d:	je     40f886 <__swc_fn_7069e055_000101_afcb7774+0xc6>
  40f84f:	nop
  40f850:	mov    rcx,QWORD PTR [r13+0x10]
  40f854:	mov    QWORD PTR [r13+0x10],0x0
  40f85c:	vxorps xmm0,xmm0,xmm0
  40f860:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f866:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f86c:	mov    DWORD PTR [r13+0x20],0x0
  40f874:	call   4089b0 <__swc_fn_7069e055_000099_5232b57d>
  40f879:	add    r13,0x90
  40f880:	sub    r12,0x1
  40f884:	jne    40f850 <__swc_fn_7069e055_000101_afcb7774+0x90>
  40f886:	mov    rax,QWORD PTR [rdi]
  40f889:	mov    rdi,rax
  40f88c:	test   rax,rax
  40f88f:	jne    40f840 <__swc_fn_7069e055_000101_afcb7774+0x80>
  40f891:	vxorps xmm0,xmm0,xmm0
  40f895:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f89d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f8a7:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f8b1:	mov    edi,0x4
  40f8b6:	mov    r12,rsi
  40f8b9:	lea    rsi,[rsi+0x38]
  40f8bd:	test   rdi,rdi
  40f8c0:	je     40f8ec <__swc_fn_7069e055_000101_afcb7774+0x12c>
  40f8c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f8cc:	nop    DWORD PTR [rax+0x0]
  40f8d0:	mov    rcx,rsi
  40f8d3:	call   40d170 <__swc_fn_7069e055_000157_3495a3ca>
  40f8d8:	add    rsi,0x90
  40f8df:	add    r12,0x90
  40f8e6:	sub    rdi,0x1
  40f8ea:	jne    40f8d0 <__swc_fn_7069e055_000101_afcb7774+0x110>
  40f8ec:	mov    rax,QWORD PTR [rbx+0x938]
  40f8f3:	mov    rdi,rax
  40f8f6:	mov    QWORD PTR [rbx+0x938],0x0
  40f901:	test   rdi,rdi
  40f904:	je     40f975 <__swc_fn_7069e055_000101_afcb7774+0x1b5>
  40f90a:	nop    WORD PTR [rax+rax*1+0x0]
  40f910:	mov    esi,0x10
  40f915:	lea    r12,[rdi+0x18]
  40f919:	lea    r13,[rdi+0x50]
  40f91d:	test   rsi,rsi
  40f920:	je     40f94c <__swc_fn_7069e055_000101_afcb7774+0x18c>
  40f922:	cs nop WORD PTR [rax+rax*1+0x0]
  40f92c:	nop    DWORD PTR [rax+0x0]
  40f930:	mov    rcx,r13
  40f933:	call   40d170 <__swc_fn_7069e055_000157_3495a3ca>
  40f938:	add    r13,0x90
  40f93f:	add    r12,0x90
  40f946:	sub    rsi,0x1
  40f94a:	jne    40f930 <__swc_fn_7069e055_000101_afcb7774+0x170>
  40f94c:	mov    rax,QWORD PTR [rdi]
  40f94f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f954:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f95a:	lea    rcx,[rsp+0x8]
  40f95f:	mov    rdx,rdi
  40f962:	mov    r8d,0x918
  40f968:	mov    rdi,rax
  40f96b:	call   408960 <__swc_fn_7069e055_000096_a4baaa40>
  40f970:	test   rdi,rdi
  40f973:	jne    40f910 <__swc_fn_7069e055_000101_afcb7774+0x150>
  40f975:	lea    rcx,[rbx+0x68]
  40f979:	call   40d170 <__swc_fn_7069e055_000157_3495a3ca>
  40f97e:	add    rsp,0x20
  40f982:	pop    r13
  40f984:	pop    r12
  40f986:	pop    rdi
  40f987:	pop    rsi
  40f988:	pop    rbx
  40f989:	ret
  40f98a:	add    BYTE PTR [rax],al
  40f98c:	add    BYTE PTR [rax],al
	...

000000000040f990 <__swc_fn_7069e055_000104_04d1a8be>:
  40f990:	xor    eax,eax
  40f992:	cs nop WORD PTR [rax+rax*1+0x0]
  40f99c:	nop    DWORD PTR [rax+0x0]
  40f9a0:	mov    r9,r8
  40f9a3:	sub    r9,rax
  40f9a6:	cmp    r9,0x40
  40f9aa:	jb     40f9e8 <__swc_fn_7069e055_000104_04d1a8be+0x58>
  40f9ac:	lea    r9,[rcx+rax*1]
  40f9b0:	lea    r10,[rdx+rax*1]
  40f9b4:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f9ba:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40f9c0:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40f9c6:	vmovups xmm3,XMMWORD PTR [r10]
  40f9cb:	vmovups XMMWORD PTR [r9],xmm3
  40f9d0:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40f9d6:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40f9dc:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40f9e2:	lea    rax,[rax+0x40]
  40f9e6:	jmp    40f9a0 <__swc_fn_7069e055_000104_04d1a8be+0x10>
  40f9e8:	nop    DWORD PTR [rax+rax*1+0x0]
  40f9f0:	mov    r9,r8
  40f9f3:	sub    r9,rax
  40f9f6:	cmp    r9,0x10
  40f9fa:	jb     40fa14 <__swc_fn_7069e055_000104_04d1a8be+0x84>
  40f9fc:	lea    r9,[rdx+rax*1]
  40fa00:	lea    r10,[rcx+rax*1]
  40fa04:	vmovups xmm0,XMMWORD PTR [r9]
  40fa09:	vmovups XMMWORD PTR [r10],xmm0
  40fa0e:	lea    rax,[rax+0x10]
  40fa12:	jmp    40f9f0 <__swc_fn_7069e055_000104_04d1a8be+0x60>
  40fa14:	cs nop WORD PTR [rax+rax*1+0x0]
  40fa1e:	xchg   ax,ax
  40fa20:	mov    r9,r8
  40fa23:	sub    r9,rax
  40fa26:	cmp    r9,0x8
  40fa2a:	jb     40fa3d <__swc_fn_7069e055_000104_04d1a8be+0xad>
  40fa2c:	lea    r9,[rcx+rax*1]
  40fa30:	mov    r10,QWORD PTR [rdx+rax*1]
  40fa34:	mov    QWORD PTR [r9],r10
  40fa37:	lea    rax,[rax+0x8]
  40fa3b:	jmp    40fa20 <__swc_fn_7069e055_000104_04d1a8be+0x90>
  40fa3d:	cmp    rax,r8
  40fa40:	jae    40fa60 <__swc_fn_7069e055_000104_04d1a8be+0xd0>
  40fa42:	cs nop WORD PTR [rax+rax*1+0x0]
  40fa4c:	nop    DWORD PTR [rax+0x0]
  40fa50:	mov    r9b,BYTE PTR [rdx+rax*1]
  40fa54:	mov    BYTE PTR [rcx+rax*1],r9b
  40fa58:	inc    rax
  40fa5b:	cmp    rax,r8
  40fa5e:	jb     40fa50 <__swc_fn_7069e055_000104_04d1a8be+0xc0>
  40fa60:	ret
	...

000000000040fa70 <__swc_fn_7069e055_000107_c8d4a68e>:
  40fa70:	push   rbx
  40fa71:	push   r12
  40fa73:	push   rdi
  40fa74:	push   rsi
  40fa75:	push   r13
  40fa77:	push   r14
  40fa79:	push   r15
  40fa7b:	sub    rsp,0x170
  40fa82:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40fa8b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40fa94:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40fa9d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40faa6:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40faaf:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40fab8:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40fac1:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40faca:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40fad3:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40fadc:	mov    ebx,edx
  40fade:	mov    QWORD PTR [rsp+0xa8],rbx
  40fae6:	mov    r12d,ecx
  40fae9:	test   edx,edx
  40faeb:	jne    40fb02 <__swc_fn_7069e055_000107_c8d4a68e+0x92>
  40faed:	xor    eax,eax
  40faef:	add    rsp,0x170
  40faf6:	pop    r15
  40faf8:	pop    r14
  40fafa:	pop    r13
  40fafc:	pop    rsi
  40fafd:	pop    rdi
  40fafe:	pop    r12
  40fb00:	pop    rbx
  40fb01:	ret
  40fb02:	lea    rdi,[rip+0x39a7]        # 4134b0 <__swc_rdata_base_7069e055+0x3a0>
  40fb09:	mov    esi,0x90000
  40fb0e:	xor    eax,eax
  40fb10:	call   407090 <open@plt>
  40fb15:	mov    r13,rax
  40fb18:	mov    QWORD PTR [rsp+0xb0],rax
  40fb20:	test   eax,eax
  40fb22:	jge    40fb2b <__swc_fn_7069e055_000107_c8d4a68e+0xbb>
  40fb24:	xor    eax,eax
  40fb26:	jmp    410026 <__swc_fn_7069e055_000107_c8d4a68e+0x5b6>
  40fb2b:	nop    DWORD PTR [rax+rax*1+0x0]
  40fb30:	movsxd rdi,r13d
  40fb33:	mov    esi,0x2
  40fb38:	xor    eax,eax
  40fb3a:	call   407120 <flock@plt>
  40fb3f:	test   eax,eax
  40fb41:	je     40fb60 <__swc_fn_7069e055_000107_c8d4a68e+0xf0>
  40fb43:	xor    eax,eax
  40fb45:	call   407130 <__errno_location@plt>
  40fb4a:	cmp    DWORD PTR [rax],0x4
  40fb4d:	je     40fb30 <__swc_fn_7069e055_000107_c8d4a68e+0xc0>
  40fb4f:	movsxd rdi,r13d
  40fb52:	xor    eax,eax
  40fb54:	call   4070b0 <close@plt>
  40fb59:	xor    eax,eax
  40fb5b:	jmp    410026 <__swc_fn_7069e055_000107_c8d4a68e+0x5b6>
  40fb60:	lea    r14,[rsp+0x8]
  40fb65:	mov    QWORD PTR [rsp+0xb8],r14
  40fb6d:	vxorps xmm0,xmm0,xmm0
  40fb71:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fb77:	mov    QWORD PTR [rsp+0x18],0x0
  40fb80:	mov    WORD PTR [rsp+0x20],0x0
  40fb87:	mov    DWORD PTR [r14],0x67617753
  40fb8e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40fb96:	xor    eax,eax
  40fb98:	call   407010 <getpid@plt>
  40fb9d:	mov    ecx,eax
  40fb9f:	mov    eax,0x1c
  40fba4:	shrx   eax,ecx,eax
  40fba9:	and    eax,0xf
  40fbac:	mov    rdx,QWORD PTR [rip+0x391d]        # 4134d0 <__swc_rdata_base_7069e055+0x3c0>
  40fbb3:	mov    al,BYTE PTR [rdx+rax*1]
  40fbb6:	rex mov BYTE PTR [rsp+0x10],al
  40fbbb:	mov    eax,0x1c
  40fbc0:	shrx   eax,r12d,eax
  40fbc5:	and    eax,0xf
  40fbc8:	mov    al,BYTE PTR [rdx+rax*1]
  40fbcb:	rex mov BYTE PTR [rsp+0x19],al
  40fbd0:	mov    eax,0x18
  40fbd5:	shrx   eax,ecx,eax
  40fbda:	and    eax,0xf
  40fbdd:	mov    al,BYTE PTR [rdx+rax*1]
  40fbe0:	rex mov BYTE PTR [rsp+0x11],al
  40fbe5:	mov    eax,0x18
  40fbea:	shrx   eax,r12d,eax
  40fbef:	and    eax,0xf
  40fbf2:	mov    al,BYTE PTR [rdx+rax*1]
  40fbf5:	rex mov BYTE PTR [rsp+0x1a],al
  40fbfa:	mov    eax,0x14
  40fbff:	shrx   eax,ecx,eax
  40fc04:	and    eax,0xf
  40fc07:	mov    al,BYTE PTR [rdx+rax*1]
  40fc0a:	rex mov BYTE PTR [rsp+0x12],al
  40fc0f:	mov    eax,0x14
  40fc14:	shrx   eax,r12d,eax
  40fc19:	and    eax,0xf
  40fc1c:	mov    al,BYTE PTR [rdx+rax*1]
  40fc1f:	rex mov BYTE PTR [rsp+0x1b],al
  40fc24:	mov    eax,0x10
  40fc29:	shrx   eax,ecx,eax
  40fc2e:	and    eax,0xf
  40fc31:	mov    al,BYTE PTR [rdx+rax*1]
  40fc34:	rex mov BYTE PTR [rsp+0x13],al
  40fc39:	mov    eax,0x10
  40fc3e:	shrx   eax,r12d,eax
  40fc43:	and    eax,0xf
  40fc46:	mov    al,BYTE PTR [rdx+rax*1]
  40fc49:	rex mov BYTE PTR [rsp+0x1c],al
  40fc4e:	mov    eax,0xc
  40fc53:	shrx   eax,ecx,eax
  40fc58:	and    eax,0xf
  40fc5b:	mov    al,BYTE PTR [rdx+rax*1]
  40fc5e:	rex mov BYTE PTR [rsp+0x14],al
  40fc63:	mov    eax,0xc
  40fc68:	shrx   eax,r12d,eax
  40fc6d:	and    eax,0xf
  40fc70:	mov    al,BYTE PTR [rdx+rax*1]
  40fc73:	rex mov BYTE PTR [rsp+0x1d],al
  40fc78:	mov    eax,0x8
  40fc7d:	shrx   eax,ecx,eax
  40fc82:	and    eax,0xf
  40fc85:	mov    al,BYTE PTR [rdx+rax*1]
  40fc88:	rex mov BYTE PTR [rsp+0x15],al
  40fc8d:	mov    eax,0x8
  40fc92:	shrx   eax,r12d,eax
  40fc97:	and    eax,0xf
  40fc9a:	mov    al,BYTE PTR [rdx+rax*1]
  40fc9d:	rex mov BYTE PTR [rsp+0x1e],al
  40fca2:	mov    eax,0x4
  40fca7:	shrx   eax,ecx,eax
  40fcac:	and    eax,0xf
  40fcaf:	mov    al,BYTE PTR [rdx+rax*1]
  40fcb2:	rex mov BYTE PTR [rsp+0x16],al
  40fcb7:	mov    eax,0x4
  40fcbc:	shrx   eax,r12d,eax
  40fcc1:	and    eax,0xf
  40fcc4:	mov    al,BYTE PTR [rdx+rax*1]
  40fcc7:	rex mov BYTE PTR [rsp+0x1f],al
  40fccc:	xor    eax,eax
  40fcce:	shrx   eax,ecx,eax
  40fcd3:	and    eax,0xf
  40fcd6:	mov    al,BYTE PTR [rdx+rax*1]
  40fcd9:	rex mov BYTE PTR [rsp+0x17],al
  40fcde:	xor    eax,eax
  40fce0:	shrx   eax,r12d,eax
  40fce5:	and    eax,0xf
  40fce8:	mov    al,BYTE PTR [rdx+rax*1]
  40fceb:	rex mov BYTE PTR [rsp+0x20],al
  40fcf0:	mov    BYTE PTR [r14+0x10],0x2e
  40fcf5:	lea    r12,[rsp+0x22]
  40fcfa:	vxorps xmm0,xmm0,xmm0
  40fcfe:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40fd04:	mov    DWORD PTR [r12],0x6d656d2f
  40fd0c:	mov    WORD PTR [r12+0x4],0x6466
  40fd14:	mov    BYTE PTR [r12+0x6],0x3a
  40fd1a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40fd20:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40fd26:	mov    rax,QWORD PTR [rsp+0x18]
  40fd2b:	mov    QWORD PTR [rsp+0x39],rax
  40fd30:	rex mov al,BYTE PTR [rsp+0x20]
  40fd35:	rex mov BYTE PTR [rsp+0x41],al
  40fd3a:	mov    DWORD PTR [r12+0x20],0x65642820
  40fd43:	mov    DWORD PTR [r12+0x24],0x6574656c
  40fd4c:	mov    WORD PTR [r12+0x28],0x2964
  40fd54:	lea    rdi,[rip+0x3760]        # 4134bb <__swc_rdata_base_7069e055+0x3ab>
  40fd5b:	xor    eax,eax
  40fd5d:	call   407140 <opendir@plt>
  40fd62:	mov    r15,rax
  40fd65:	test   rax,rax
  40fd68:	jne    40fd7b <__swc_fn_7069e055_000107_c8d4a68e+0x30b>
  40fd6a:	movsxd rdi,r13d
  40fd6d:	xor    eax,eax
  40fd6f:	call   4070b0 <close@plt>
  40fd74:	xor    eax,eax
  40fd76:	jmp    410026 <__swc_fn_7069e055_000107_c8d4a68e+0x5b6>
  40fd7b:	mov    rdi,r15
  40fd7e:	xor    eax,eax
  40fd80:	call   407150 <dirfd@plt>
  40fd85:	lea    r14,[rsp+0x54]
  40fd8a:	mov    DWORD PTR [rsp+0x54],eax
  40fd8e:	lea    rbx,[rsp+0x58]
  40fd93:	cs nop WORD PTR [rax+rax*1+0x0]
  40fd9d:	nop    DWORD PTR [rax]
  40fda0:	mov    rdi,r15
  40fda3:	xor    eax,eax
  40fda5:	call   407160 <readdir@plt>
  40fdaa:	test   rax,rax
  40fdad:	jne    40fdc4 <__swc_fn_7069e055_000107_c8d4a68e+0x354>
  40fdaf:	mov    r12,QWORD PTR [rsp+0xa8]
  40fdb7:	mov    r13,QWORD PTR [rsp+0xb0]
  40fdbf:	jmp    40ff4a <__swc_fn_7069e055_000107_c8d4a68e+0x4da>
  40fdc4:	vxorps xmm0,xmm0,xmm0
  40fdc8:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40fdce:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40fdd4:	vzeroupper
  40fdd7:	lea    r13,[rax+0x13]
  40fddb:	mov    rax,r14
  40fdde:	movsxd rdi,DWORD PTR [rax]
  40fde1:	mov    rsi,r13
  40fde4:	mov    rdx,rbx
  40fde7:	mov    ecx,0x40
  40fdec:	xor    eax,eax
  40fdee:	call   407170 <readlinkat@plt>
  40fdf3:	cmp    rax,0x2a
  40fdf7:	jne    40fda0 <__swc_fn_7069e055_000107_c8d4a68e+0x330>
  40fdf9:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40fdff:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40fe05:	vptest xmm0,xmm0
  40fe0a:	jne    40fe3a <__swc_fn_7069e055_000107_c8d4a68e+0x3ca>
  40fe0c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40fe12:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40fe18:	vptest xmm0,xmm0
  40fe1d:	jne    40fe3a <__swc_fn_7069e055_000107_c8d4a68e+0x3ca>
  40fe1f:	mov    rcx,QWORD PTR [rsp+0x42]
  40fe24:	cmp    QWORD PTR [rsp+0x78],rcx
  40fe29:	jne    40fe3a <__swc_fn_7069e055_000107_c8d4a68e+0x3ca>
  40fe2b:	mov    cx,WORD PTR [rsp+0x4a]
  40fe30:	cmp    WORD PTR [rsp+0x80],cx
  40fe38:	je     40fe64 <__swc_fn_7069e055_000107_c8d4a68e+0x3f4>
  40fe3a:	mov    rax,rbx
  40fe3d:	mov    rcx,r12
  40fe40:	movzx  edx,BYTE PTR [rax]
  40fe43:	movzx  r8d,BYTE PTR [rcx]
  40fe47:	cmp    rdx,r8
  40fe4a:	jne    40fe56 <__swc_fn_7069e055_000107_c8d4a68e+0x3e6>
  40fe4c:	add    rax,0x1
  40fe50:	add    rcx,0x1
  40fe54:	jmp    40fe40 <__swc_fn_7069e055_000107_c8d4a68e+0x3d0>
  40fe56:	mov    rax,rdx
  40fe59:	sub    rax,r8
  40fe5c:	test   eax,eax
  40fe5e:	jne    40fda0 <__swc_fn_7069e055_000107_c8d4a68e+0x330>
  40fe64:	movsxd rdi,DWORD PTR [r14]
  40fe67:	mov    rsi,r13
  40fe6a:	mov    edx,0x80002
  40fe6f:	xor    eax,eax
  40fe71:	call   407180 <openat@plt>
  40fe76:	lea    rbx,[rsp+0x98]
  40fe7e:	mov    DWORD PTR [rsp+0x98],eax
  40fe85:	test   eax,eax
  40fe87:	mov    r13,QWORD PTR [rsp+0xb0]
  40fe8f:	jge    40feb4 <__swc_fn_7069e055_000107_c8d4a68e+0x444>
  40fe91:	mov    rdi,r15
  40fe94:	xor    eax,eax
  40fe96:	call   407190 <closedir@plt>
  40fe9b:	mov    r13,QWORD PTR [rsp+0xb0]
  40fea3:	movsxd rdi,r13d
  40fea6:	xor    eax,eax
  40fea8:	call   4070b0 <close@plt>
  40fead:	xor    eax,eax
  40feaf:	jmp    410026 <__swc_fn_7069e055_000107_c8d4a68e+0x5b6>
  40feb4:	mov    rax,rbx
  40feb7:	movsxd rdi,DWORD PTR [rax]
  40feba:	xor    esi,esi
  40febc:	mov    edx,0x2
  40fec1:	xor    eax,eax
  40fec3:	call   4070a0 <lseek@plt>
  40fec8:	mov    r12,QWORD PTR [rsp+0xa8]
  40fed0:	cmp    rax,r12
  40fed3:	je     40fefa <__swc_fn_7069e055_000107_c8d4a68e+0x48a>
  40fed5:	movsxd rdi,DWORD PTR [rbx]
  40fed8:	xor    eax,eax
  40feda:	call   4070b0 <close@plt>
  40fedf:	mov    rdi,r15
  40fee2:	xor    eax,eax
  40fee4:	call   407190 <closedir@plt>
  40fee9:	movsxd rdi,r13d
  40feec:	xor    eax,eax
  40feee:	call   4070b0 <close@plt>
  40fef3:	xor    eax,eax
  40fef5:	jmp    410026 <__swc_fn_7069e055_000107_c8d4a68e+0x5b6>
  40fefa:	xor    edi,edi
  40fefc:	mov    rsi,r12
  40feff:	mov    edx,0x3
  40ff04:	mov    ecx,0x1
  40ff09:	mov    rax,rbx
  40ff0c:	movsxd r8,DWORD PTR [rax]
  40ff0f:	xor    r9d,r9d
  40ff12:	xor    eax,eax
  40ff14:	call   4070c0 <mmap@plt>
  40ff19:	xor    r12d,r12d
  40ff1c:	cmp    rax,0xffffffffffffffff
  40ff20:	cmovne r12,rax
  40ff24:	movsxd rdi,DWORD PTR [rbx]
  40ff27:	xor    eax,eax
  40ff29:	call   4070b0 <close@plt>
  40ff2e:	mov    rdi,r15
  40ff31:	xor    eax,eax
  40ff33:	call   407190 <closedir@plt>
  40ff38:	movsxd rdi,r13d
  40ff3b:	xor    eax,eax
  40ff3d:	call   4070b0 <close@plt>
  40ff42:	mov    rax,r12
  40ff45:	jmp    410026 <__swc_fn_7069e055_000107_c8d4a68e+0x5b6>
  40ff4a:	mov    r14,QWORD PTR [rsp+0xb8]
  40ff52:	mov    rdi,r14
  40ff55:	mov    esi,0x1
  40ff5a:	xor    eax,eax
  40ff5c:	call   4071a0 <memfd_create@plt>
  40ff61:	lea    rbx,[rsp+0x9c]
  40ff69:	mov    DWORD PTR [rsp+0x9c],eax
  40ff70:	test   eax,eax
  40ff72:	jge    40ff8f <__swc_fn_7069e055_000107_c8d4a68e+0x51f>
  40ff74:	mov    rdi,r15
  40ff77:	xor    eax,eax
  40ff79:	call   407190 <closedir@plt>
  40ff7e:	movsxd rdi,r13d
  40ff81:	xor    eax,eax
  40ff83:	call   4070b0 <close@plt>
  40ff88:	xor    eax,eax
  40ff8a:	jmp    410026 <__swc_fn_7069e055_000107_c8d4a68e+0x5b6>
  40ff8f:	mov    rax,rbx
  40ff92:	movsxd rdi,DWORD PTR [rax]
  40ff95:	mov    rsi,r12
  40ff98:	xor    eax,eax
  40ff9a:	call   4071b0 <ftruncate@plt>
  40ff9f:	test   eax,eax
  40ffa1:	je     40ffc5 <__swc_fn_7069e055_000107_c8d4a68e+0x555>
  40ffa3:	movsxd rdi,DWORD PTR [rbx]
  40ffa6:	xor    eax,eax
  40ffa8:	call   4070b0 <close@plt>
  40ffad:	mov    rdi,r15
  40ffb0:	xor    eax,eax
  40ffb2:	call   407190 <closedir@plt>
  40ffb7:	movsxd rdi,r13d
  40ffba:	xor    eax,eax
  40ffbc:	call   4070b0 <close@plt>
  40ffc1:	xor    eax,eax
  40ffc3:	jmp    410026 <__swc_fn_7069e055_000107_c8d4a68e+0x5b6>
  40ffc5:	xor    edi,edi
  40ffc7:	mov    rsi,r12
  40ffca:	mov    edx,0x3
  40ffcf:	mov    ecx,0x1
  40ffd4:	mov    rax,rbx
  40ffd7:	movsxd r8,DWORD PTR [rax]
  40ffda:	xor    r9d,r9d
  40ffdd:	xor    eax,eax
  40ffdf:	call   4070c0 <mmap@plt>
  40ffe4:	mov    r12,rax
  40ffe7:	cmp    rax,0xffffffffffffffff
  40ffeb:	jne    41000f <__swc_fn_7069e055_000107_c8d4a68e+0x59f>
  40ffed:	movsxd rdi,DWORD PTR [rbx]
  40fff0:	xor    eax,eax
  40fff2:	call   4070b0 <close@plt>
  40fff7:	mov    rdi,r15
  40fffa:	xor    eax,eax
  40fffc:	call   407190 <closedir@plt>
  410001:	movsxd rdi,r13d
  410004:	xor    eax,eax
  410006:	call   4070b0 <close@plt>
  41000b:	xor    eax,eax
  41000d:	jmp    410026 <__swc_fn_7069e055_000107_c8d4a68e+0x5b6>
  41000f:	mov    rdi,r15
  410012:	xor    eax,eax
  410014:	call   407190 <closedir@plt>
  410019:	movsxd rdi,r13d
  41001c:	xor    eax,eax
  41001e:	call   4070b0 <close@plt>
  410023:	mov    rax,r12
  410026:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  41002f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  410038:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  410041:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  41004a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  410053:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  41005c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  410065:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  41006e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  410077:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  410080:	add    rsp,0x170
  410087:	pop    r15
  410089:	pop    r14
  41008b:	pop    r13
  41008d:	pop    rsi
  41008e:	pop    rdi
  41008f:	pop    r12
  410091:	pop    rbx
  410092:	ret
	...

00000000004100a0 <__swc_fn_7069e055_000110_918d5a21>:
  4100a0:	push   rsi
  4100a1:	push   rdi
  4100a2:	push   r12
  4100a4:	push   r13
  4100a6:	sub    rsp,0x8
  4100aa:	mov    rsi,r8
  4100ad:	mov    rdi,rcx
  4100b0:	mov    r12,rdx
  4100b3:	call   409100 <__swc_fn_7069e055_000108_b8f4bd15>
  4100b8:	mov    r13,rax
  4100bb:	test   rax,rax
  4100be:	jne    4100cb <__swc_fn_7069e055_000110_918d5a21+0x2b>
  4100c0:	add    rsp,0x8
  4100c4:	pop    r13
  4100c6:	pop    r12
  4100c8:	pop    rdi
  4100c9:	pop    rsi
  4100ca:	ret
  4100cb:	mov    rcx,r13
  4100ce:	call   40cd70 <__swc_fn_7069e055_000133_807fd51d>
  4100d3:	mov    rax,QWORD PTR [r13+0x8]
  4100d7:	test   rax,rax
  4100da:	je     410119 <__swc_fn_7069e055_000110_918d5a21+0x79>
  4100dc:	nop    DWORD PTR [rax+0x0]
  4100e0:	lea    rcx,[rax+0x1000]
  4100e7:	cmp    rdi,rcx
  4100ea:	jne    410111 <__swc_fn_7069e055_000110_918d5a21+0x71>
  4100ec:	cmp    r12,0x1000
  4100f3:	jb     410111 <__swc_fn_7069e055_000110_918d5a21+0x71>
  4100f5:	test   sil,sil
  4100f8:	setne  cl
  4100fb:	mov    BYTE PTR [rax+0x10],cl
  4100fe:	mov    rcx,r13
  410101:	call   410600 <__swc_fn_7069e055_000134_10472836>
  410106:	add    rsp,0x8
  41010a:	pop    r13
  41010c:	pop    r12
  41010e:	pop    rdi
  41010f:	pop    rsi
  410110:	ret
  410111:	mov    rax,QWORD PTR [rax]
  410114:	test   rax,rax
  410117:	jne    4100e0 <__swc_fn_7069e055_000110_918d5a21+0x40>
  410119:	mov    rcx,r13
  41011c:	call   410600 <__swc_fn_7069e055_000134_10472836>
  410121:	add    rsp,0x8
  410125:	pop    r13
  410127:	pop    r12
  410129:	pop    rdi
  41012a:	pop    rsi
  41012b:	ret
  41012c:	add    BYTE PTR [rax],al
	...

0000000000410130 <__swc_fn_7069e055_000113_4e83a03a>:
  410130:	sub    rsp,0x8
  410134:	test   rcx,rcx
  410137:	jne    41013e <__swc_fn_7069e055_000113_4e83a03a+0xe>
  410139:	add    rsp,0x8
  41013d:	ret
  41013e:	call   40c880 <__swc_fn_7069e055_000115_3f6af4b1>
  410143:	add    rsp,0x8
  410147:	ret
	...

0000000000410150 <__swc_fn_7069e055_000116_3f5cfdef>:
  410150:	push   r12
  410152:	push   r13
  410154:	push   r14
  410156:	push   rdi
  410157:	push   rsi
  410158:	sub    rsp,0xc0
  41015f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410165:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  41016b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  410171:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410177:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  41017d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  410183:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410189:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  410192:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  41019b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4101a4:	mov    r12,QWORD PTR [rcx]
  4101a7:	test   r12,r12
  4101aa:	jne    4101bc <__swc_fn_7069e055_000116_3f5cfdef+0x6c>
  4101ac:	add    rsp,0xc0
  4101b3:	pop    rsi
  4101b4:	pop    rdi
  4101b5:	pop    r14
  4101b7:	pop    r13
  4101b9:	pop    r12
  4101bb:	ret
  4101bc:	xor    r13d,r13d
  4101bf:	mov    r14,QWORD PTR [rcx+0x8]
  4101c3:	cs nop WORD PTR [rax+rax*1+0x0]
  4101cd:	nop    DWORD PTR [rax]
  4101d0:	cmp    r13,r14
  4101d3:	jae    41020b <__swc_fn_7069e055_000116_3f5cfdef+0xbb>
  4101d5:	lea    rax,[r12+r13*1]
  4101d9:	mov    rcx,r14
  4101dc:	sub    rcx,r13
  4101df:	mov    edi,0x1
  4101e4:	mov    rsi,rax
  4101e7:	mov    rdx,rcx
  4101ea:	xor    eax,eax
  4101ec:	call   4071c0 <write@plt>
  4101f1:	test   rax,rax
  4101f4:	jle    4101fb <__swc_fn_7069e055_000116_3f5cfdef+0xab>
  4101f6:	add    r13,rax
  4101f9:	jmp    4101d0 <__swc_fn_7069e055_000116_3f5cfdef+0x80>
  4101fb:	je     410209 <__swc_fn_7069e055_000116_3f5cfdef+0xb9>
  4101fd:	xor    eax,eax
  4101ff:	call   407130 <__errno_location@plt>
  410204:	cmp    DWORD PTR [rax],0x4
  410207:	je     4101d0 <__swc_fn_7069e055_000116_3f5cfdef+0x80>
  410209:	jmp    41020b <__swc_fn_7069e055_000116_3f5cfdef+0xbb>
  41020b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410211:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410217:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  41021d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410223:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410229:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41022f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410235:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41023e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410247:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410250:	add    rsp,0xc0
  410257:	pop    rsi
  410258:	pop    rdi
  410259:	pop    r14
  41025b:	pop    r13
  41025d:	pop    r12
  41025f:	ret

0000000000410260 <__swc_fn_7069e055_000119_2d9caf16>:
  410260:	push   rbx
  410261:	push   r12
  410263:	push   rdi
  410264:	push   rsi
  410265:	sub    rsp,0x4a8
  41026c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  410275:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  41027e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  410287:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  410290:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  410299:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  4102a2:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  4102ab:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  4102b4:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  4102bd:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  4102c6:	mov    rbx,rdx
  4102c9:	mov    r12d,ecx
  4102cc:	vxorps xmm0,xmm0,xmm0
  4102d0:	xor    eax,eax
  4102d2:	cs nop WORD PTR [rax+rax*1+0x0]
  4102dc:	nop    DWORD PTR [rax+0x0]
  4102e0:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  4102e6:	add    rax,0x10
  4102ea:	cmp    rax,0x400
  4102f1:	jne    4102e0 <__swc_fn_7069e055_000119_2d9caf16+0x80>
  4102f3:	lea    rdi,[rsp+0x8]
  4102f8:	mov    esi,0x80
  4102fd:	xor    eax,eax
  4102ff:	call   4071d0 <backtrace@plt>
  410304:	test   eax,eax
  410306:	jle    410315 <__swc_fn_7069e055_000119_2d9caf16+0xb5>
  410308:	movsxd rax,eax
  41030b:	lea    rcx,[r12+0x1]
  410310:	cmp    rcx,rax
  410313:	jb     410319 <__swc_fn_7069e055_000119_2d9caf16+0xb9>
  410315:	xor    eax,eax
  410317:	jmp    41034a <__swc_fn_7069e055_000119_2d9caf16+0xea>
  410319:	mov    rcx,QWORD PTR [rbx+0x8]
  41031d:	sub    rax,r12
  410320:	lea    rsi,[rax-0x1]
  410324:	cmp    rcx,rsi
  410327:	cmovbe rsi,rcx
  41032b:	lea    eax,[r12+0x1]
  410330:	lea    rax,[rsp+rax*8+0x8]
  410335:	mov    rcx,QWORD PTR [rbx]
  410338:	mov    rdx,rax
  41033b:	lea    r8,[rsi*8+0x0]
  410343:	call   4090e0 <__swc_fn_7069e055_000105_83487ba1>
  410348:	mov    eax,esi
  41034a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  410353:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  41035c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  410365:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  41036e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  410377:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  410380:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  410389:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  410392:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  41039b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  4103a4:	add    rsp,0x4a8
  4103ab:	pop    rsi
  4103ac:	pop    rdi
  4103ad:	pop    r12
  4103af:	pop    rbx
  4103b0:	ret
	...

00000000004103c0 <__swc_fn_7069e055_000122_66e5d2a9>:
  4103c0:	mov    QWORD PTR [rcx],0x0
  4103c7:	ret
	...

00000000004103d0 <__swc_fn_7069e055_000125_7a81492f>:
  4103d0:	push   rdi
  4103d1:	push   rsi
  4103d2:	sub    rsp,0xa8
  4103d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4103df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4103e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4103eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4103f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4103f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4103fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410403:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410409:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410412:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41041b:	mov    edi,ecx
  41041d:	mov    rsi,rdx
  410420:	xor    eax,eax
  410422:	call   407060 <pthread_setspecific@plt>
  410427:	test   eax,eax
  410429:	sete   al
  41042c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410432:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410438:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41043e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410444:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41044a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410450:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410456:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41045c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410465:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41046e:	add    rsp,0xa8
  410475:	pop    rsi
  410476:	pop    rdi
  410477:	ret
	...

0000000000410480 <__swc_fn_7069e055_000128_8d8a7dd2>:
  410480:	push   rdi
  410481:	push   rsi
  410482:	sub    rsp,0xa8
  410489:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41048f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410495:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41049b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4104a1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4104a7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4104ad:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4104b3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4104b9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4104c2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4104cb:	test   rcx,rcx
  4104ce:	je     4104e1 <__swc_fn_7069e055_000128_8d8a7dd2+0x61>
  4104d0:	lea    rax,[rcx-0x1]
  4104d4:	mov    eax,eax
  4104d6:	mov    edi,eax
  4104d8:	xor    eax,eax
  4104da:	call   407000 <pthread_getspecific@plt>
  4104df:	jmp    4104e3 <__swc_fn_7069e055_000128_8d8a7dd2+0x63>
  4104e1:	xor    eax,eax
  4104e3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4104e9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4104ef:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4104f5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4104fb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410501:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410507:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41050d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410513:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41051c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410525:	add    rsp,0xa8
  41052c:	pop    rsi
  41052d:	pop    rdi
  41052e:	ret
	...

0000000000410530 <__swc_fn_7069e055_000131_91db8856>:
  410530:	push   rdi
  410531:	push   rsi
  410532:	sub    rsp,0xb8
  410539:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41053f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410545:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41054b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410551:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410557:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41055d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410563:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41056c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410575:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41057e:	vxorps xmm0,xmm0,xmm0
  410582:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410588:	mov    edi,0x1
  41058d:	lea    rsi,[rsp+0x8]
  410592:	xor    eax,eax
  410594:	call   4070e0 <clock_gettime@plt>
  410599:	mov    rax,QWORD PTR [rsp+0x8]
  41059e:	imul   rax,rax,0x3b9aca00
  4105a5:	add    rax,QWORD PTR [rsp+0x10]
  4105aa:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4105b0:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4105b6:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4105bc:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4105c2:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4105c8:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4105ce:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4105d4:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4105dd:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4105e6:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4105ef:	add    rsp,0xb8
  4105f6:	pop    rsi
  4105f7:	pop    rdi
  4105f8:	ret
  4105f9:	add    BYTE PTR [rax],al
  4105fb:	add    BYTE PTR [rax],al
  4105fd:	add    BYTE PTR [rax],al
	...

0000000000410600 <__swc_fn_7069e055_000134_10472836>:
  410600:	sub    rsp,0x8
  410604:	xor    eax,eax
  410606:	mov    DWORD PTR [rcx],eax
  410608:	mov    edx,0x7fffffff
  41060d:	call   4097e0 <__swc_fn_7069e055_000132_51cc49e7>
  410612:	add    rsp,0x8
  410616:	ret
	...

0000000000410620 <__swc_fn_7069e055_000137_2d595cc7>:
  410620:	push   rdi
  410621:	push   rsi
  410622:	sub    rsp,0xb8
  410629:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41062f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410635:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41063b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410641:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410647:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41064d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410653:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41065c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410665:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41066e:	mov    edi,0x1
  410673:	xor    eax,eax
  410675:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  41067a:	mov    eax,DWORD PTR [rax+0x14]
  41067d:	and    eax,0x20
  410680:	setne  al
  410683:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410689:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41068f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410695:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41069b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4106a1:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4106a7:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4106ad:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4106b6:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4106bf:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4106c8:	add    rsp,0xb8
  4106cf:	pop    rsi
  4106d0:	pop    rdi
  4106d1:	ret
	...

00000000004106e0 <__swc_fn_7069e055_000140_55003b6d>:
  4106e0:	push   rsi
  4106e1:	push   rdi
  4106e2:	push   r12
  4106e4:	push   r13
  4106e6:	push   r14
  4106e8:	push   r15
  4106ea:	cmp    rdx,0x40
  4106ee:	jae    4106fd <__swc_fn_7069e055_000140_55003b6d+0x1d>
  4106f0:	xor    eax,eax
  4106f2:	pop    r15
  4106f4:	pop    r14
  4106f6:	pop    r13
  4106f8:	pop    r12
  4106fa:	pop    rdi
  4106fb:	pop    rsi
  4106fc:	ret
  4106fd:	cmp    BYTE PTR [rcx],0x7f
  410700:	jne    410744 <__swc_fn_7069e055_000140_55003b6d+0x64>
  410702:	movzx  eax,BYTE PTR [rcx+0x1]
  410706:	cmp    eax,0x45
  410709:	setne  al
  41070c:	jne    410740 <__swc_fn_7069e055_000140_55003b6d+0x60>
  41070e:	movzx  eax,BYTE PTR [rcx+0x2]
  410712:	cmp    eax,0x4c
  410715:	setne  al
  410718:	jne    410740 <__swc_fn_7069e055_000140_55003b6d+0x60>
  41071a:	movzx  eax,BYTE PTR [rcx+0x3]
  41071e:	cmp    eax,0x46
  410721:	setne  al
  410724:	jne    410740 <__swc_fn_7069e055_000140_55003b6d+0x60>
  410726:	cmp    BYTE PTR [rcx+0x4],0x2
  41072a:	setne  al
  41072d:	jne    410740 <__swc_fn_7069e055_000140_55003b6d+0x60>
  41072f:	cmp    BYTE PTR [rcx+0x5],0x1
  410733:	setne  al
  410736:	jne    410740 <__swc_fn_7069e055_000140_55003b6d+0x60>
  410738:	cmp    WORD PTR [rcx+0x12],0x3e
  41073d:	setne  al
  410740:	test   al,al
  410742:	je     410751 <__swc_fn_7069e055_000140_55003b6d+0x71>
  410744:	xor    eax,eax
  410746:	pop    r15
  410748:	pop    r14
  41074a:	pop    r13
  41074c:	pop    r12
  41074e:	pop    rdi
  41074f:	pop    rsi
  410750:	ret
  410751:	cmp    WORD PTR [rcx+0x3a],0x40
  410756:	jne    410771 <__swc_fn_7069e055_000140_55003b6d+0x91>
  410758:	cmp    WORD PTR [rcx+0x3c],0x0
  41075d:	sete   al
  410760:	je     41076d <__swc_fn_7069e055_000140_55003b6d+0x8d>
  410762:	mov    ax,WORD PTR [rcx+0x3c]
  410766:	cmp    WORD PTR [rcx+0x3e],ax
  41076a:	setae  al
  41076d:	test   al,al
  41076f:	je     41077e <__swc_fn_7069e055_000140_55003b6d+0x9e>
  410771:	xor    eax,eax
  410773:	pop    r15
  410775:	pop    r14
  410777:	pop    r13
  410779:	pop    r12
  41077b:	pop    rdi
  41077c:	pop    rsi
  41077d:	ret
  41077e:	movzx  eax,WORD PTR [rcx+0x3c]
  410782:	shl    rax,0x6
  410786:	cmp    rax,rdx
  410789:	ja     410797 <__swc_fn_7069e055_000140_55003b6d+0xb7>
  41078b:	mov    r9,rdx
  41078e:	sub    r9,rax
  410791:	cmp    QWORD PTR [rcx+0x28],r9
  410795:	jbe    4107a4 <__swc_fn_7069e055_000140_55003b6d+0xc4>
  410797:	xor    eax,eax
  410799:	pop    r15
  41079b:	pop    r14
  41079d:	pop    r13
  41079f:	pop    r12
  4107a1:	pop    rdi
  4107a2:	pop    rsi
  4107a3:	ret
  4107a4:	mov    rax,QWORD PTR [rcx+0x28]
  4107a8:	add    rax,rcx
  4107ab:	movzx  r9d,WORD PTR [rcx+0x3e]
  4107b0:	lea    r9,[r9*8+0x0]
  4107b8:	lea    r10,[rax+r9*8]
  4107bc:	cmp    QWORD PTR [r10+0x20],rdx
  4107c0:	ja     4107e2 <__swc_fn_7069e055_000140_55003b6d+0x102>
  4107c2:	mov    r11,rdx
  4107c5:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  4107ca:	cmp    QWORD PTR [r10+0x18],r11
  4107ce:	seta   r9b
  4107d2:	ja     4107dd <__swc_fn_7069e055_000140_55003b6d+0xfd>
  4107d4:	cmp    QWORD PTR [r10+0x20],0x9
  4107d9:	setb   r9b
  4107dd:	test   r9b,r9b
  4107e0:	je     4107ef <__swc_fn_7069e055_000140_55003b6d+0x10f>
  4107e2:	xor    eax,eax
  4107e4:	pop    r15
  4107e6:	pop    r14
  4107e8:	pop    r13
  4107ea:	pop    r12
  4107ec:	pop    rdi
  4107ed:	pop    rsi
  4107ee:	ret
  4107ef:	movzx  r9d,WORD PTR [rcx+0x3c]
  4107f4:	xor    r11d,r11d
  4107f7:	test   r9,r9
  4107fa:	jbe    4108f5 <__swc_fn_7069e055_000140_55003b6d+0x215>
  410800:	mov    rsi,QWORD PTR [r10+0x20]
  410804:	sub    rsi,0x9
  410808:	cs nop WORD PTR [rax+rax*1+0x0]
  410812:	cs nop WORD PTR [rax+rax*1+0x0]
  41081c:	nop    DWORD PTR [rax+0x0]
  410820:	movzx  edi,r11w
  410824:	lea    rdi,[rdi*8+0x0]
  41082c:	lea    r12,[rax+rdi*8]
  410830:	rex mov edi,DWORD PTR [rax+rdi*8]
  410834:	cmp    rdi,rsi
  410837:	ja     4108e8 <__swc_fn_7069e055_000140_55003b6d+0x208>
  41083d:	mov    r13,QWORD PTR [r10+0x18]
  410841:	add    r13,rdi
  410844:	lea    rdi,[rcx+r13*1]
  410848:	lea    r13,[rip+0x2ce1]        # 413530 <__swc_rdata_base_7069e055+0x420>
  41084f:	movabs r14,0x676264676177732e
  410859:	cmp    QWORD PTR [rdi],r14
  41085c:	jne    410865 <__swc_fn_7069e055_000140_55003b6d+0x185>
  41085e:	rex cmp BYTE PTR [rdi+0x8],0x0
  410863:	je     410892 <__swc_fn_7069e055_000140_55003b6d+0x1b2>
  410865:	cs nop WORD PTR [rax+rax*1+0x0]
  41086f:	nop
  410870:	movzx  r14d,BYTE PTR [rdi]
  410874:	movzx  r15d,BYTE PTR [r13+0x0]
  410879:	cmp    r14,r15
  41087c:	jne    410888 <__swc_fn_7069e055_000140_55003b6d+0x1a8>
  41087e:	add    rdi,0x1
  410882:	add    r13,0x1
  410886:	jmp    410870 <__swc_fn_7069e055_000140_55003b6d+0x190>
  410888:	mov    rdi,r14
  41088b:	sub    rdi,r15
  41088e:	test   edi,edi
  410890:	jne    4108e8 <__swc_fn_7069e055_000140_55003b6d+0x208>
  410892:	cmp    DWORD PTR [r12+0x4],0x1
  410898:	jne    4108c0 <__swc_fn_7069e055_000140_55003b6d+0x1e0>
  41089a:	cmp    QWORD PTR [r12+0x20],0x10
  4108a0:	setb   al
  4108a3:	jb     4108bc <__swc_fn_7069e055_000140_55003b6d+0x1dc>
  4108a5:	cmp    QWORD PTR [r12+0x20],rdx
  4108aa:	seta   al
  4108ad:	ja     4108bc <__swc_fn_7069e055_000140_55003b6d+0x1dc>
  4108af:	sub    rdx,QWORD PTR [r12+0x20]
  4108b4:	cmp    QWORD PTR [r12+0x18],rdx
  4108b9:	seta   al
  4108bc:	test   al,al
  4108be:	je     4108cd <__swc_fn_7069e055_000140_55003b6d+0x1ed>
  4108c0:	xor    eax,eax
  4108c2:	pop    r15
  4108c4:	pop    r14
  4108c6:	pop    r13
  4108c8:	pop    r12
  4108ca:	pop    rdi
  4108cb:	pop    rsi
  4108cc:	ret
  4108cd:	mov    rax,QWORD PTR [r12+0x20]
  4108d2:	mov    QWORD PTR [r8],rax
  4108d5:	mov    rax,QWORD PTR [r12+0x18]
  4108da:	add    rax,rcx
  4108dd:	pop    r15
  4108df:	pop    r14
  4108e1:	pop    r13
  4108e3:	pop    r12
  4108e5:	pop    rdi
  4108e6:	pop    rsi
  4108e7:	ret
  4108e8:	add    r11,0x1
  4108ec:	cmp    r11,r9
  4108ef:	jb     410820 <__swc_fn_7069e055_000140_55003b6d+0x140>
  4108f5:	xor    eax,eax
  4108f7:	pop    r15
  4108f9:	pop    r14
  4108fb:	pop    r13
  4108fd:	pop    r12
  4108ff:	pop    rdi
  410900:	pop    rsi
  410901:	ret
	...

0000000000410910 <__swc_fn_7069e055_000143_b7ad855f>:
  410910:	push   rdi
  410911:	push   rsi
  410912:	sub    rsp,0xa8
  410919:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41091f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410925:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41092b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410931:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410937:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41093d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410943:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410949:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410952:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41095b:	mov    rdi,rcx
  41095e:	xor    eax,eax
  410960:	call   4071f0 <free@plt>
  410965:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41096b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410971:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410977:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41097d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410983:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410989:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41098f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410995:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41099e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4109a7:	add    rsp,0xa8
  4109ae:	pop    rsi
  4109af:	pop    rdi
  4109b0:	ret
	...

00000000004109c0 <__swc_fn_7069e055_000146_d2097256>:
  4109c0:	push   rbx
  4109c1:	push   rsi
  4109c2:	push   rdi
  4109c3:	push   r12
  4109c5:	push   r13
  4109c7:	push   r15
  4109c9:	sub    rsp,0x4e8
  4109d0:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  4109d9:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  4109e2:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  4109eb:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  4109f4:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  4109fd:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  410a06:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  410a0f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  410a18:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  410a21:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  410a2a:	mov    rbx,QWORD PTR [rcx]
  410a2d:	mov    rcx,QWORD PTR [rcx+0x8]
  410a31:	mov    rsi,rcx
  410a34:	xor    edi,edi
  410a36:	vmovsd xmm6,QWORD PTR [rip+0x2b52]        # 413590 <__swc_rdata_base_7069e055+0x480>
  410a3e:	vmovsd xmm7,QWORD PTR [rip+0x2b53]        # 413599 <__swc_rdata_base_7069e055+0x489>
  410a46:	vmovsd xmm8,QWORD PTR [rip+0x2b54]        # 4135a2 <__swc_rdata_base_7069e055+0x492>
  410a4e:	vmovsd xmm9,QWORD PTR [rip+0x2b55]        # 4135ab <__swc_rdata_base_7069e055+0x49b>
  410a56:	vmovsd xmm10,QWORD PTR [rip+0x2b56]        # 4135b4 <__swc_rdata_base_7069e055+0x4a4>
  410a5e:	vmovups xmm11,xmm6
  410a62:	vmovsd QWORD PTR [rsp+0x418],xmm7
  410a6b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410a74:	vmovsd QWORD PTR [rsp+0x428],xmm9
  410a7d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410a86:	vmovsd xmm15,QWORD PTR [rip+0x2b2f]        # 4135bd <__swc_rdata_base_7069e055+0x4ad>
  410a8e:	vmovups xmm14,xmm15
  410a93:	vmovups xmm0,xmm9
  410a98:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410aa1:	vmovups xmm13,xmm8
  410aa6:	vmovsd QWORD PTR [rsp+0x440],xmm15
  410aaf:	test   rsi,rsi
  410ab2:	je     411aa3 <__swc_fn_7069e055_000146_d2097256+0x10e3>
  410ab8:	cs nop WORD PTR [rax+rax*1+0x0]
  410ac2:	cs nop WORD PTR [rax+rax*1+0x0]
  410acc:	nop    DWORD PTR [rax+0x0]
  410ad0:	lea    rcx,[rdi+rdi*1]
  410ad4:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410ad9:	vpshufd xmm3,xmm2,0xee
  410ade:	vmovq  rcx,xmm3
  410ae3:	test   rcx,rcx
  410ae6:	je     410afc <__swc_fn_7069e055_000146_d2097256+0x13c>
  410ae8:	test   DWORD PTR [rcx+0x28],0x400000
  410aef:	je     410afc <__swc_fn_7069e055_000146_d2097256+0x13c>
  410af1:	mov    rdx,QWORD PTR [rcx+0x30]
  410af5:	test   rdx,rdx
  410af8:	cmovne rcx,rdx
  410afc:	test   DWORD PTR [rcx+0x28],0x1000
  410b03:	je     410b24 <__swc_fn_7069e055_000146_d2097256+0x164>
  410b05:	mov    rdx,QWORD PTR [rcx+0x40]
  410b09:	mov    rcx,rdx
  410b0c:	vmovq  r8,xmm2
  410b11:	mov    r8,QWORD PTR [r8]
  410b14:	mov    QWORD PTR [rsp+0x60],r8
  410b19:	mov    QWORD PTR [rsp+0x68],rdx
  410b1e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410b24:	test   BYTE PTR [rcx+0x28],0x1
  410b28:	jne    410b30 <__swc_fn_7069e055_000146_d2097256+0x170>
  410b2a:	vmovups xmm12,xmm0
  410b2e:	jmp    410b4a <__swc_fn_7069e055_000146_d2097256+0x18a>
  410b30:	vmovq  rax,xmm2
  410b35:	mov    rax,QWORD PTR [rax]
  410b38:	lea    rcx,[rax+0x10]
  410b3c:	vmovups xmm12,xmm0
  410b40:	call   410150 <__swc_fn_7069e055_000116_3f5cfdef>
  410b45:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  410b4a:	test   DWORD PTR [rcx+0x28],0x400
  410b51:	je     410bb2 <__swc_fn_7069e055_000146_d2097256+0x1f2>
  410b53:	vmovq  rax,xmm2
  410b58:	mov    rax,QWORD PTR [rax]
  410b5b:	xor    ecx,ecx
  410b5d:	test   rax,rax
  410b60:	je     410b90 <__swc_fn_7069e055_000146_d2097256+0x1d0>
  410b62:	mov    rdx,rax
  410b65:	mov    r8b,BYTE PTR [rdx]
  410b68:	test   r8b,r8b
  410b6b:	je     410b90 <__swc_fn_7069e055_000146_d2097256+0x1d0>
  410b6d:	cs nop WORD PTR [rax+rax*1+0x0]
  410b77:	nop    WORD PTR [rax+rax*1+0x0]
  410b80:	add    rdx,0x1
  410b84:	add    rcx,0x1
  410b88:	mov    r8b,BYTE PTR [rdx]
  410b8b:	test   r8b,r8b
  410b8e:	jne    410b80 <__swc_fn_7069e055_000146_d2097256+0x1c0>
  410b90:	mov    QWORD PTR [rsp+0x88],rax
  410b98:	mov    QWORD PTR [rsp+0x90],rcx
  410ba0:	lea    rcx,[rsp+0x88]
  410ba8:	call   410150 <__swc_fn_7069e055_000116_3f5cfdef>
  410bad:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  410bb2:	cmp    BYTE PTR [rcx+0x2c],0x6
  410bb6:	jne    410bcd <__swc_fn_7069e055_000146_d2097256+0x20d>
  410bb8:	vmovq  rax,xmm2
  410bbd:	mov    rax,QWORD PTR [rax]
  410bc0:	mov    rcx,rax
  410bc3:	call   409cb0 <__swc_fn_7069e055_000144_c3e86ca0>
  410bc8:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  410bcd:	cmp    BYTE PTR [rcx+0x2c],0x1
  410bd1:	jne    411a79 <__swc_fn_7069e055_000146_d2097256+0x10b9>
  410bd7:	vmovq  rdx,xmm2
  410bdc:	mov    cl,BYTE PTR [rcx+0x40]
  410bdf:	cmp    cl,0x7
  410be2:	jb     410c25 <__swc_fn_7069e055_000146_d2097256+0x265>
  410be4:	je     410c98 <__swc_fn_7069e055_000146_d2097256+0x2d8>
  410bea:	cmp    cl,0x8
  410bed:	je     410ca4 <__swc_fn_7069e055_000146_d2097256+0x2e4>
  410bf3:	cmp    cl,0x9
  410bf6:	je     410cbd <__swc_fn_7069e055_000146_d2097256+0x2fd>
  410bfc:	cmp    cl,0xa
  410bff:	je     411384 <__swc_fn_7069e055_000146_d2097256+0x9c4>
  410c05:	cmp    cl,0xb
  410c08:	je     411a4b <__swc_fn_7069e055_000146_d2097256+0x108b>
  410c0e:	cmp    cl,0xc
  410c11:	je     410cb1 <__swc_fn_7069e055_000146_d2097256+0x2f1>
  410c17:	cmp    cl,0xd
  410c1a:	je     411a41 <__swc_fn_7069e055_000146_d2097256+0x1081>
  410c20:	jmp    411a6b <__swc_fn_7069e055_000146_d2097256+0x10ab>
  410c25:	cmp    cl,0x1
  410c28:	je     410c48 <__swc_fn_7069e055_000146_d2097256+0x288>
  410c2a:	cmp    cl,0x2
  410c2d:	je     410c56 <__swc_fn_7069e055_000146_d2097256+0x296>
  410c2f:	cmp    cl,0x3
  410c32:	je     410c64 <__swc_fn_7069e055_000146_d2097256+0x2a4>
  410c34:	cmp    cl,0x4
  410c37:	je     410c71 <__swc_fn_7069e055_000146_d2097256+0x2b1>
  410c39:	cmp    cl,0x5
  410c3c:	je     410c7e <__swc_fn_7069e055_000146_d2097256+0x2be>
  410c3e:	cmp    cl,0x6
  410c41:	je     410c8b <__swc_fn_7069e055_000146_d2097256+0x2cb>
  410c43:	jmp    411a6b <__swc_fn_7069e055_000146_d2097256+0x10ab>
  410c48:	movsx  rcx,BYTE PTR [rdx]
  410c4c:	call   40cf60 <__swc_fn_7069e055_000145_32a1d6a2>
  410c51:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  410c56:	movsx  rcx,WORD PTR [rdx]
  410c5a:	call   40cf60 <__swc_fn_7069e055_000145_32a1d6a2>
  410c5f:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  410c64:	movsxd rcx,DWORD PTR [rdx]
  410c67:	call   40cf60 <__swc_fn_7069e055_000145_32a1d6a2>
  410c6c:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  410c71:	mov    rcx,QWORD PTR [rdx]
  410c74:	call   40cf60 <__swc_fn_7069e055_000145_32a1d6a2>
  410c79:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  410c7e:	movzx  ecx,BYTE PTR [rdx]
  410c81:	call   409cb0 <__swc_fn_7069e055_000144_c3e86ca0>
  410c86:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  410c8b:	movzx  ecx,WORD PTR [rdx]
  410c8e:	call   409cb0 <__swc_fn_7069e055_000144_c3e86ca0>
  410c93:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  410c98:	mov    ecx,DWORD PTR [rdx]
  410c9a:	call   409cb0 <__swc_fn_7069e055_000144_c3e86ca0>
  410c9f:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  410ca4:	mov    rcx,QWORD PTR [rdx]
  410ca7:	call   409cb0 <__swc_fn_7069e055_000144_c3e86ca0>
  410cac:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  410cb1:	mov    ecx,DWORD PTR [rdx]
  410cb3:	call   409cb0 <__swc_fn_7069e055_000144_c3e86ca0>
  410cb8:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  410cbd:	lea    rcx,[rsp+0xa8]
  410cc5:	vxorps xmm0,xmm0,xmm0
  410cc9:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  410cd2:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  410cdb:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  410ce4:	vzeroupper
  410ce7:	mov    DWORD PTR [rsp+0x108],0x0
  410cf2:	vxorpd xmm0,xmm0,xmm0
  410cf6:	vmovss xmm1,DWORD PTR [rdx]
  410cfa:	vcvtss2sd xmm0,xmm0,xmm1
  410cfe:	vmovsd xmm1,xmm1,xmm0
  410d02:	vcomisd xmm0,xmm0
  410d06:	setne  dl
  410d09:	movzx  edx,dl
  410d0c:	setp   r8b
  410d10:	movzx  r8d,r8b
  410d14:	or     edx,r8d
  410d17:	test   dl,dl
  410d19:	je     410d26 <__swc_fn_7069e055_000146_d2097256+0x366>
  410d1b:	mov    DWORD PTR [rcx],0x6e616e
  410d21:	jmp    411318 <__swc_fn_7069e055_000146_d2097256+0x958>
  410d26:	vcomisd xmm1,xmm6
  410d2a:	ja     410d32 <__swc_fn_7069e055_000146_d2097256+0x372>
  410d2c:	vcomisd xmm7,xmm1
  410d30:	jbe    410d56 <__swc_fn_7069e055_000146_d2097256+0x396>
  410d32:	vxorpd xmm0,xmm0,xmm0
  410d36:	vcomisd xmm0,xmm1
  410d3a:	jbe    410d4b <__swc_fn_7069e055_000146_d2097256+0x38b>
  410d3c:	mov    DWORD PTR [rcx],0x666e692d
  410d42:	mov    BYTE PTR [rcx+0x4],0x0
  410d46:	jmp    411318 <__swc_fn_7069e055_000146_d2097256+0x958>
  410d4b:	mov    DWORD PTR [rcx],0x666e69
  410d51:	jmp    411318 <__swc_fn_7069e055_000146_d2097256+0x958>
  410d56:	vcomisd xmm1,xmm8
  410d5b:	jae    410d67 <__swc_fn_7069e055_000146_d2097256+0x3a7>
  410d5d:	vcomisd xmm9,xmm1
  410d61:	jbe    4110de <__swc_fn_7069e055_000146_d2097256+0x71e>
  410d67:	vmovups xmm0,xmm1
  410d6b:	vxorpd xmm2,xmm2,xmm2
  410d6f:	vcomisd xmm2,xmm1
  410d73:	jbe    410d83 <__swc_fn_7069e055_000146_d2097256+0x3c3>
  410d75:	vmovsd xmm1,xmm1,xmm0
  410d79:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x27cf]        # 413550 <__swc_rdata_base_7069e055+0x440>
  410d81:	jmp    410d87 <__swc_fn_7069e055_000146_d2097256+0x3c7>
  410d83:	vmovsd xmm1,xmm1,xmm0
  410d87:	xor    r8d,r8d
  410d8a:	vcomisd xmm1,xmm15
  410d8f:	jb     410db0 <__swc_fn_7069e055_000146_d2097256+0x3f0>
  410d91:	cs nop WORD PTR [rax+rax*1+0x0]
  410d9b:	nop    DWORD PTR [rax+rax*1+0x0]
  410da0:	vdivsd xmm1,xmm1,xmm15
  410da5:	add    r8,0x1
  410da9:	vcomisd xmm1,xmm15
  410dae:	jae    410da0 <__swc_fn_7069e055_000146_d2097256+0x3e0>
  410db0:	mov    r9,rcx
  410db3:	vxorpd xmm2,xmm2,xmm2
  410db7:	vcomisd xmm2,xmm0
  410dbb:	jbe    410dc4 <__swc_fn_7069e055_000146_d2097256+0x404>
  410dbd:	mov    BYTE PTR [rcx],0x2d
  410dc0:	lea    r9,[rcx+0x1]
  410dc4:	vcvttsd2si rdx,xmm1
  410dc9:	mov    r10b,dl
  410dcc:	add    r10b,0x30
  410dd0:	mov    BYTE PTR [r9],r10b
  410dd3:	vxorpd xmm0,xmm0,xmm0
  410dd7:	movzx  edx,dl
  410dda:	vcvtsi2sd xmm0,xmm0,rdx
  410ddf:	vsubsd xmm0,xmm1,xmm0
  410de3:	vmulsd xmm1,xmm0,xmm15
  410de8:	mov    BYTE PTR [r9+0x1],0x2e
  410ded:	vcvttsd2si rdx,xmm1
  410df2:	mov    r10b,dl
  410df5:	add    r10b,0x30
  410df9:	mov    BYTE PTR [r9+0x2],r10b
  410dfd:	vxorpd xmm0,xmm0,xmm0
  410e01:	movzx  edx,dl
  410e04:	vcvtsi2sd xmm0,xmm0,rdx
  410e09:	vsubsd xmm0,xmm1,xmm0
  410e0d:	vmulsd xmm1,xmm0,xmm15
  410e12:	vcvttsd2si rdx,xmm1
  410e17:	mov    r10b,dl
  410e1a:	add    r10b,0x30
  410e1e:	mov    BYTE PTR [r9+0x3],r10b
  410e22:	vxorpd xmm0,xmm0,xmm0
  410e26:	movzx  edx,dl
  410e29:	vcvtsi2sd xmm0,xmm0,rdx
  410e2e:	vsubsd xmm0,xmm1,xmm0
  410e32:	vmulsd xmm1,xmm0,xmm15
  410e37:	vcvttsd2si rdx,xmm1
  410e3c:	mov    r10b,dl
  410e3f:	add    r10b,0x30
  410e43:	mov    BYTE PTR [r9+0x4],r10b
  410e47:	vxorpd xmm0,xmm0,xmm0
  410e4b:	movzx  edx,dl
  410e4e:	vcvtsi2sd xmm0,xmm0,rdx
  410e53:	vsubsd xmm0,xmm1,xmm0
  410e57:	vmulsd xmm1,xmm0,xmm15
  410e5c:	vcvttsd2si rdx,xmm1
  410e61:	mov    r10b,dl
  410e64:	add    r10b,0x30
  410e68:	mov    BYTE PTR [r9+0x5],r10b
  410e6c:	vxorpd xmm0,xmm0,xmm0
  410e70:	movzx  edx,dl
  410e73:	vcvtsi2sd xmm0,xmm0,rdx
  410e78:	vsubsd xmm0,xmm1,xmm0
  410e7c:	vmulsd xmm1,xmm0,xmm15
  410e81:	vcvttsd2si rdx,xmm1
  410e86:	mov    r10b,dl
  410e89:	add    r10b,0x30
  410e8d:	mov    BYTE PTR [r9+0x6],r10b
  410e91:	vxorpd xmm0,xmm0,xmm0
  410e95:	movzx  edx,dl
  410e98:	vcvtsi2sd xmm0,xmm0,rdx
  410e9d:	vsubsd xmm0,xmm1,xmm0
  410ea1:	vmulsd xmm1,xmm0,xmm15
  410ea6:	vcvttsd2si rdx,xmm1
  410eab:	mov    r10b,dl
  410eae:	add    r10b,0x30
  410eb2:	mov    BYTE PTR [r9+0x7],r10b
  410eb6:	vxorpd xmm0,xmm0,xmm0
  410eba:	movzx  edx,dl
  410ebd:	vcvtsi2sd xmm0,xmm0,rdx
  410ec2:	vsubsd xmm0,xmm1,xmm0
  410ec6:	vmulsd xmm1,xmm0,xmm15
  410ecb:	vcvttsd2si rdx,xmm1
  410ed0:	mov    r10b,dl
  410ed3:	add    r10b,0x30
  410ed7:	mov    BYTE PTR [r9+0x8],r10b
  410edb:	vxorpd xmm0,xmm0,xmm0
  410edf:	movzx  edx,dl
  410ee2:	vcvtsi2sd xmm0,xmm0,rdx
  410ee7:	vsubsd xmm0,xmm1,xmm0
  410eeb:	vmulsd xmm1,xmm0,xmm15
  410ef0:	vcvttsd2si rdx,xmm1
  410ef5:	mov    r10b,dl
  410ef8:	add    r10b,0x30
  410efc:	mov    BYTE PTR [r9+0x9],r10b
  410f00:	vxorpd xmm0,xmm0,xmm0
  410f04:	movzx  edx,dl
  410f07:	vcvtsi2sd xmm0,xmm0,rdx
  410f0c:	vsubsd xmm0,xmm1,xmm0
  410f10:	vmulsd xmm1,xmm0,xmm15
  410f15:	vcvttsd2si rdx,xmm1
  410f1a:	mov    r10b,dl
  410f1d:	add    r10b,0x30
  410f21:	mov    BYTE PTR [r9+0xa],r10b
  410f25:	vxorpd xmm0,xmm0,xmm0
  410f29:	movzx  edx,dl
  410f2c:	vcvtsi2sd xmm0,xmm0,rdx
  410f31:	vsubsd xmm0,xmm1,xmm0
  410f35:	vmulsd xmm1,xmm0,xmm15
  410f3a:	vcvttsd2si rdx,xmm1
  410f3f:	mov    r10b,dl
  410f42:	add    r10b,0x30
  410f46:	mov    BYTE PTR [r9+0xb],r10b
  410f4a:	lea    r10,[r9+0x4]
  410f4e:	vxorpd xmm0,xmm0,xmm0
  410f52:	movzx  edx,dl
  410f55:	vcvtsi2sd xmm0,xmm0,rdx
  410f5a:	vsubsd xmm0,xmm1,xmm0
  410f5e:	vmulsd xmm1,xmm0,xmm15
  410f63:	vcvttsd2si rdx,xmm1
  410f68:	mov    r11b,dl
  410f6b:	add    r11b,0x30
  410f6f:	mov    BYTE PTR [r9+0xc],r11b
  410f73:	vxorpd xmm0,xmm0,xmm0
  410f77:	movzx  edx,dl
  410f7a:	vcvtsi2sd xmm0,xmm0,rdx
  410f7f:	vsubsd xmm0,xmm1,xmm0
  410f83:	vmulsd xmm1,xmm0,xmm15
  410f88:	vcvttsd2si rdx,xmm1
  410f8d:	mov    r11b,dl
  410f90:	add    r11b,0x30
  410f94:	mov    BYTE PTR [r9+0xd],r11b
  410f98:	lea    r10,[r10+0x2]
  410f9c:	vxorpd xmm0,xmm0,xmm0
  410fa0:	movzx  edx,dl
  410fa3:	vcvtsi2sd xmm0,xmm0,rdx
  410fa8:	vsubsd xmm0,xmm1,xmm0
  410fac:	vmulsd xmm1,xmm0,xmm15
  410fb1:	vcvttsd2si rdx,xmm1
  410fb6:	mov    r11b,dl
  410fb9:	add    r11b,0x30
  410fbd:	mov    BYTE PTR [r9+0xe],r11b
  410fc1:	vxorpd xmm0,xmm0,xmm0
  410fc5:	movzx  edx,dl
  410fc8:	vcvtsi2sd xmm0,xmm0,rdx
  410fcd:	vsubsd xmm0,xmm1,xmm0
  410fd1:	vmulsd xmm1,xmm0,xmm15
  410fd6:	vcvttsd2si rdx,xmm1
  410fdb:	mov    r11b,dl
  410fde:	add    r11b,0x30
  410fe2:	mov    BYTE PTR [r9+0xf],r11b
  410fe6:	lea    r10,[r10+0x2]
  410fea:	lea    r10,[r10+0x2]
  410fee:	lea    r10,[r10+0x2]
  410ff2:	lea    r10,[r10+0x2]
  410ff6:	lea    r10,[r10+0x2]
  410ffa:	vxorpd xmm0,xmm0,xmm0
  410ffe:	movzx  edx,dl
  411001:	vcvtsi2sd xmm0,xmm0,rdx
  411006:	vsubsd xmm0,xmm1,xmm0
  41100a:	vmulsd xmm1,xmm0,xmm15
  41100f:	vcvttsd2si rdx,xmm1
  411014:	mov    r11b,dl
  411017:	add    r11b,0x30
  41101b:	mov    BYTE PTR [r9+0x10],r11b
  41101f:	vxorpd xmm0,xmm0,xmm0
  411023:	movzx  edx,dl
  411026:	vcvtsi2sd xmm0,xmm0,rdx
  41102b:	vsubsd xmm0,xmm1,xmm0
  41102f:	vmulsd xmm1,xmm0,xmm15
  411034:	vcvttsd2si rdx,xmm1
  411039:	add    dl,0x30
  41103c:	mov    BYTE PTR [r9+0x11],dl
  411040:	mov    BYTE PTR [r10+0x2],0x65
  411045:	lea    r9,[r10+0x3]
  411049:	test   r8,r8
  41104c:	jl     411055 <__swc_fn_7069e055_000146_d2097256+0x695>
  41104e:	mov    BYTE PTR [r9],0x2b
  411052:	inc    r9
  411055:	mov    r10,r9
  411058:	mov    rdx,r8
  41105b:	nop    DWORD PTR [rax+rax*1+0x0]
  411060:	mov    r11,rdx
  411063:	movabs rdx,0x6666666666666667
  41106d:	mov    rax,r11
  411070:	imul   rdx
  411073:	sar    rdx,0x2
  411077:	mov    r12,rdx
  41107a:	shr    rdx,0x3f
  41107e:	add    r12,rdx
  411081:	mov    rdx,r12
  411084:	imul   r13,r12,0xa
  411088:	sub    r11,r13
  41108b:	mov    r13,QWORD PTR [rip+0x24ae]        # 413540 <__swc_rdata_base_7069e055+0x430>
  411092:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411097:	mov    BYTE PTR [r10],r11b
  41109a:	lea    r11,[r10+0x1]
  41109e:	mov    r10,r11
  4110a1:	test   r12,r12
  4110a4:	jne    411060 <__swc_fn_7069e055_000146_d2097256+0x6a0>
  4110a6:	test   r8,r8
  4110a9:	jge    4110b3 <__swc_fn_7069e055_000146_d2097256+0x6f3>
  4110ab:	mov    BYTE PTR [r11],0x2d
  4110af:	lea    r10,[r11+0x1]
  4110b3:	mov    BYTE PTR [r10],0x0
  4110b7:	sub    r10,0x1
  4110bb:	nop    DWORD PTR [rax+rax*1+0x0]
  4110c0:	cmp    r9,r10
  4110c3:	jae    411318 <__swc_fn_7069e055_000146_d2097256+0x958>
  4110c9:	mov    al,BYTE PTR [r10]
  4110cc:	mov    dl,BYTE PTR [r9]
  4110cf:	mov    BYTE PTR [r10],dl
  4110d2:	sub    r10,0x1
  4110d6:	mov    BYTE PTR [r9],al
  4110d9:	inc    r9
  4110dc:	jmp    4110c0 <__swc_fn_7069e055_000146_d2097256+0x700>
  4110de:	vcvttsd2si rdx,xmm1
  4110e3:	mov    r8,rdx
  4110e6:	vxorpd xmm0,xmm0,xmm0
  4110ea:	vcvtsi2sd xmm0,xmm0,rdx
  4110ef:	vsubsd xmm0,xmm1,xmm0
  4110f3:	mov    r9d,0x8
  4110f9:	vxorpd xmm2,xmm2,xmm2
  4110fd:	vcomisd xmm2,xmm0
  411101:	jbe    41110b <__swc_fn_7069e055_000146_d2097256+0x74b>
  411103:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2445]        # 413550 <__swc_rdata_base_7069e055+0x440>
  41110b:	test   r9d,r9d
  41110e:	je     41111a <__swc_fn_7069e055_000146_d2097256+0x75a>
  411110:	vmulsd xmm0,xmm0,xmm14
  411115:	dec    r9d
  411118:	jne    411110 <__swc_fn_7069e055_000146_d2097256+0x750>
  41111a:	vcvttsd2si r9,xmm0
  41111f:	mov    r10,r9
  411122:	vxorpd xmm2,xmm2,xmm2
  411126:	vcvtsi2sd xmm2,xmm2,r9
  41112b:	vsubsd xmm0,xmm0,xmm2
  41112f:	vcomisd xmm0,xmm10
  411134:	lea    r9,[r9+0x1]
  411138:	cmova  r10,r9
  41113c:	cmp    r10,0x5f5e100
  411143:	jne    41115c <__swc_fn_7069e055_000146_d2097256+0x79c>
  411145:	lea    r8,[rdx-0x1]
  411149:	vxorpd xmm0,xmm0,xmm0
  41114d:	vcomisd xmm0,xmm1
  411151:	lea    rdx,[rdx+0x1]
  411155:	cmovbe r8,rdx
  411159:	xor    r10d,r10d
  41115c:	mov    r9,rcx
  41115f:	test   r8,r8
  411162:	jne    411182 <__swc_fn_7069e055_000146_d2097256+0x7c2>
  411164:	vxorpd xmm0,xmm0,xmm0
  411168:	vcomisd xmm0,xmm1
  41116c:	jbe    411175 <__swc_fn_7069e055_000146_d2097256+0x7b5>
  41116e:	mov    BYTE PTR [rcx],0x2d
  411171:	lea    r9,[rcx+0x1]
  411175:	mov    BYTE PTR [r9],0x30
  411179:	add    r9,0x1
  41117d:	jmp    41121b <__swc_fn_7069e055_000146_d2097256+0x85b>
  411182:	mov    r9,rcx
  411185:	mov    rdx,r8
  411188:	nop    DWORD PTR [rax+rax*1+0x0]
  411190:	mov    r11,rdx
  411193:	movabs rdx,0x6666666666666667
  41119d:	mov    r15,rax
  4111a0:	mov    rax,r11
  4111a3:	imul   rdx
  4111a6:	mov    r12,rdx
  4111a9:	mov    rax,r15
  4111ac:	sar    r12,0x2
  4111b0:	mov    rdx,r12
  4111b3:	shr    rdx,0x3f
  4111b7:	add    r12,rdx
  4111ba:	mov    rdx,r12
  4111bd:	imul   r13,r12,0xa
  4111c1:	sub    r11,r13
  4111c4:	mov    r13,QWORD PTR [rip+0x2375]        # 413540 <__swc_rdata_base_7069e055+0x430>
  4111cb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4111d0:	mov    BYTE PTR [r9],r11b
  4111d3:	lea    r11,[r9+0x1]
  4111d7:	mov    r9,r11
  4111da:	test   r12,r12
  4111dd:	jne    411190 <__swc_fn_7069e055_000146_d2097256+0x7d0>
  4111df:	test   r8,r8
  4111e2:	jge    4111ec <__swc_fn_7069e055_000146_d2097256+0x82c>
  4111e4:	mov    BYTE PTR [r11],0x2d
  4111e8:	lea    r9,[r11+0x1]
  4111ec:	mov    rdx,r9
  4111ef:	mov    BYTE PTR [r9],0x0
  4111f3:	sub    r9,0x1
  4111f7:	mov    r8,rcx
  4111fa:	cmp    r8,r9
  4111fd:	jae    411218 <__swc_fn_7069e055_000146_d2097256+0x858>
  4111ff:	nop
  411200:	mov    r11b,BYTE PTR [r9]
  411203:	mov    r12b,BYTE PTR [r8]
  411206:	mov    BYTE PTR [r9],r12b
  411209:	sub    r9,0x1
  41120d:	mov    BYTE PTR [r8],r11b
  411210:	inc    r8
  411213:	cmp    r8,r9
  411216:	jb     411200 <__swc_fn_7069e055_000146_d2097256+0x840>
  411218:	mov    r9,rdx
  41121b:	mov    BYTE PTR [r9],0x2e
  41121f:	add    r9,0x1
  411223:	xor    r8d,r8d
  411226:	test   r10,r10
  411229:	je     41126f <__swc_fn_7069e055_000146_d2097256+0x8af>
  41122b:	mov    r11d,0x989680
  411231:	cmp    r10,r11
  411234:	jge    41126f <__swc_fn_7069e055_000146_d2097256+0x8af>
  411236:	cs nop WORD PTR [rax+rax*1+0x0]
  411240:	inc    r8d
  411243:	movabs rdx,0x6666666666666667
  41124d:	mov    r15,rax
  411250:	mov    rax,r11
  411253:	imul   rdx
  411256:	mov    r11,rdx
  411259:	mov    rax,r15
  41125c:	sar    r11,0x2
  411260:	mov    rdx,r11
  411263:	shr    rdx,0x3f
  411267:	add    r11,rdx
  41126a:	cmp    r10,r11
  41126d:	jl     411240 <__swc_fn_7069e055_000146_d2097256+0x880>
  41126f:	test   r8d,r8d
  411272:	je     41128d <__swc_fn_7069e055_000146_d2097256+0x8cd>
  411274:	cs nop WORD PTR [rax+rax*1+0x0]
  41127e:	xchg   ax,ax
  411280:	mov    BYTE PTR [r9],0x30
  411284:	add    r9,0x1
  411288:	dec    r8d
  41128b:	jne    411280 <__swc_fn_7069e055_000146_d2097256+0x8c0>
  41128d:	mov    r8,r9
  411290:	mov    rdx,r10
  411293:	cs nop WORD PTR [rax+rax*1+0x0]
  41129d:	nop    DWORD PTR [rax]
  4112a0:	mov    r11,rdx
  4112a3:	movabs rdx,0x6666666666666667
  4112ad:	mov    rax,r11
  4112b0:	imul   rdx
  4112b3:	sar    rdx,0x2
  4112b7:	mov    r12,rdx
  4112ba:	shr    rdx,0x3f
  4112be:	add    r12,rdx
  4112c1:	mov    rdx,r12
  4112c4:	imul   r13,r12,0xa
  4112c8:	sub    r11,r13
  4112cb:	mov    r13,QWORD PTR [rip+0x226e]        # 413540 <__swc_rdata_base_7069e055+0x430>
  4112d2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4112d7:	mov    BYTE PTR [r8],r11b
  4112da:	lea    r11,[r8+0x1]
  4112de:	mov    r8,r11
  4112e1:	test   r12,r12
  4112e4:	jne    4112a0 <__swc_fn_7069e055_000146_d2097256+0x8e0>
  4112e6:	test   r10,r10
  4112e9:	jge    4112f3 <__swc_fn_7069e055_000146_d2097256+0x933>
  4112eb:	mov    BYTE PTR [r11],0x2d
  4112ef:	lea    r8,[r11+0x1]
  4112f3:	mov    BYTE PTR [r8],0x0
  4112f7:	sub    r8,0x1
  4112fb:	cmp    r9,r8
  4112fe:	jae    411318 <__swc_fn_7069e055_000146_d2097256+0x958>
  411300:	mov    al,BYTE PTR [r8]
  411303:	mov    dl,BYTE PTR [r9]
  411306:	mov    BYTE PTR [r8],dl
  411309:	sub    r8,0x1
  41130d:	mov    BYTE PTR [r9],al
  411310:	inc    r9
  411313:	cmp    r9,r8
  411316:	jb     411300 <__swc_fn_7069e055_000146_d2097256+0x940>
  411318:	xor    eax,eax
  41131a:	test   rcx,rcx
  41131d:	je     411350 <__swc_fn_7069e055_000146_d2097256+0x990>
  41131f:	mov    rdx,rcx
  411322:	mov    r8b,BYTE PTR [rdx]
  411325:	test   r8b,r8b
  411328:	je     411350 <__swc_fn_7069e055_000146_d2097256+0x990>
  41132a:	cs nop WORD PTR [rax+rax*1+0x0]
  411334:	cs nop WORD PTR [rax+rax*1+0x0]
  41133e:	xchg   ax,ax
  411340:	add    rdx,0x1
  411344:	add    rax,0x1
  411348:	mov    r8b,BYTE PTR [rdx]
  41134b:	test   r8b,r8b
  41134e:	jne    411340 <__swc_fn_7069e055_000146_d2097256+0x980>
  411350:	mov    QWORD PTR [rsp+0x240],rcx
  411358:	mov    QWORD PTR [rsp+0x248],rax
  411360:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  411369:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  411372:	lea    rcx,[rsp+0x250]
  41137a:	call   410150 <__swc_fn_7069e055_000116_3f5cfdef>
  41137f:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  411384:	lea    rcx,[rsp+0x260]
  41138c:	vxorps xmm0,xmm0,xmm0
  411390:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  411399:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  4113a2:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  4113ab:	vzeroupper
  4113ae:	mov    DWORD PTR [rsp+0x2c0],0x0
  4113b9:	vmovsd xmm0,QWORD PTR [rdx]
  4113bd:	vcomisd xmm0,xmm0
  4113c1:	setne  dl
  4113c4:	movzx  edx,dl
  4113c7:	setp   r8b
  4113cb:	movzx  r8d,r8b
  4113cf:	or     edx,r8d
  4113d2:	test   dl,dl
  4113d4:	je     4113e1 <__swc_fn_7069e055_000146_d2097256+0xa21>
  4113d6:	mov    DWORD PTR [rcx],0x6e616e
  4113dc:	jmp    4119e8 <__swc_fn_7069e055_000146_d2097256+0x1028>
  4113e1:	vcomisd xmm0,xmm11
  4113e6:	ja     4113f7 <__swc_fn_7069e055_000146_d2097256+0xa37>
  4113e8:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  4113f1:	vcomisd xmm6,xmm0
  4113f5:	jbe    41141b <__swc_fn_7069e055_000146_d2097256+0xa5b>
  4113f7:	vxorpd xmm1,xmm1,xmm1
  4113fb:	vcomisd xmm1,xmm0
  4113ff:	jbe    411410 <__swc_fn_7069e055_000146_d2097256+0xa50>
  411401:	mov    DWORD PTR [rcx],0x666e692d
  411407:	mov    BYTE PTR [rcx+0x4],0x0
  41140b:	jmp    4119e8 <__swc_fn_7069e055_000146_d2097256+0x1028>
  411410:	mov    DWORD PTR [rcx],0x666e69
  411416:	jmp    4119e8 <__swc_fn_7069e055_000146_d2097256+0x1028>
  41141b:	vcomisd xmm0,xmm13
  411420:	jae    41142c <__swc_fn_7069e055_000146_d2097256+0xa6c>
  411422:	vcomisd xmm12,xmm0
  411426:	jbe    41178e <__swc_fn_7069e055_000146_d2097256+0xdce>
  41142c:	vmovups xmm1,xmm0
  411430:	vxorpd xmm2,xmm2,xmm2
  411434:	vcomisd xmm2,xmm0
  411438:	jbe    411448 <__swc_fn_7069e055_000146_d2097256+0xa88>
  41143a:	vmovsd xmm0,xmm0,xmm1
  41143e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x210a]        # 413550 <__swc_rdata_base_7069e055+0x440>
  411446:	jmp    41144c <__swc_fn_7069e055_000146_d2097256+0xa8c>
  411448:	vmovsd xmm0,xmm0,xmm1
  41144c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  411455:	xor    r8d,r8d
  411458:	vcomisd xmm0,xmm6
  41145c:	jb     41146e <__swc_fn_7069e055_000146_d2097256+0xaae>
  41145e:	xchg   ax,ax
  411460:	vdivsd xmm0,xmm0,xmm6
  411464:	add    r8,0x1
  411468:	vcomisd xmm0,xmm6
  41146c:	jae    411460 <__swc_fn_7069e055_000146_d2097256+0xaa0>
  41146e:	mov    r9,rcx
  411471:	vxorpd xmm2,xmm2,xmm2
  411475:	vcomisd xmm2,xmm1
  411479:	jbe    411482 <__swc_fn_7069e055_000146_d2097256+0xac2>
  41147b:	mov    BYTE PTR [rcx],0x2d
  41147e:	lea    r9,[rcx+0x1]
  411482:	vcvttsd2si rdx,xmm0
  411487:	mov    r10b,dl
  41148a:	add    r10b,0x30
  41148e:	mov    BYTE PTR [r9],r10b
  411491:	vxorpd xmm1,xmm1,xmm1
  411495:	movzx  edx,dl
  411498:	vcvtsi2sd xmm1,xmm1,rdx
  41149d:	vsubsd xmm0,xmm0,xmm1
  4114a1:	vmulsd xmm0,xmm0,xmm6
  4114a5:	mov    BYTE PTR [r9+0x1],0x2e
  4114aa:	vcvttsd2si rdx,xmm0
  4114af:	mov    r10b,dl
  4114b2:	add    r10b,0x30
  4114b6:	mov    BYTE PTR [r9+0x2],r10b
  4114ba:	vxorpd xmm1,xmm1,xmm1
  4114be:	movzx  edx,dl
  4114c1:	vcvtsi2sd xmm1,xmm1,rdx
  4114c6:	vsubsd xmm0,xmm0,xmm1
  4114ca:	vmulsd xmm0,xmm0,xmm6
  4114ce:	vcvttsd2si rdx,xmm0
  4114d3:	mov    r10b,dl
  4114d6:	add    r10b,0x30
  4114da:	mov    BYTE PTR [r9+0x3],r10b
  4114de:	vxorpd xmm1,xmm1,xmm1
  4114e2:	movzx  edx,dl
  4114e5:	vcvtsi2sd xmm1,xmm1,rdx
  4114ea:	vsubsd xmm0,xmm0,xmm1
  4114ee:	vmulsd xmm0,xmm0,xmm6
  4114f2:	vcvttsd2si rdx,xmm0
  4114f7:	mov    r10b,dl
  4114fa:	add    r10b,0x30
  4114fe:	mov    BYTE PTR [r9+0x4],r10b
  411502:	vxorpd xmm1,xmm1,xmm1
  411506:	movzx  edx,dl
  411509:	vcvtsi2sd xmm1,xmm1,rdx
  41150e:	vsubsd xmm0,xmm0,xmm1
  411512:	vmulsd xmm0,xmm0,xmm6
  411516:	vcvttsd2si rdx,xmm0
  41151b:	mov    r10b,dl
  41151e:	add    r10b,0x30
  411522:	mov    BYTE PTR [r9+0x5],r10b
  411526:	vxorpd xmm1,xmm1,xmm1
  41152a:	movzx  edx,dl
  41152d:	vcvtsi2sd xmm1,xmm1,rdx
  411532:	vsubsd xmm0,xmm0,xmm1
  411536:	vmulsd xmm0,xmm0,xmm6
  41153a:	vcvttsd2si rdx,xmm0
  41153f:	mov    r10b,dl
  411542:	add    r10b,0x30
  411546:	mov    BYTE PTR [r9+0x6],r10b
  41154a:	vxorpd xmm1,xmm1,xmm1
  41154e:	movzx  edx,dl
  411551:	vcvtsi2sd xmm1,xmm1,rdx
  411556:	vsubsd xmm0,xmm0,xmm1
  41155a:	vmulsd xmm0,xmm0,xmm6
  41155e:	vcvttsd2si rdx,xmm0
  411563:	mov    r10b,dl
  411566:	add    r10b,0x30
  41156a:	mov    BYTE PTR [r9+0x7],r10b
  41156e:	vxorpd xmm1,xmm1,xmm1
  411572:	movzx  edx,dl
  411575:	vcvtsi2sd xmm1,xmm1,rdx
  41157a:	vsubsd xmm0,xmm0,xmm1
  41157e:	vmulsd xmm0,xmm0,xmm6
  411582:	vcvttsd2si rdx,xmm0
  411587:	mov    r10b,dl
  41158a:	add    r10b,0x30
  41158e:	mov    BYTE PTR [r9+0x8],r10b
  411592:	vxorpd xmm1,xmm1,xmm1
  411596:	movzx  edx,dl
  411599:	vcvtsi2sd xmm1,xmm1,rdx
  41159e:	vsubsd xmm0,xmm0,xmm1
  4115a2:	vmulsd xmm0,xmm0,xmm6
  4115a6:	vcvttsd2si rdx,xmm0
  4115ab:	mov    r10b,dl
  4115ae:	add    r10b,0x30
  4115b2:	mov    BYTE PTR [r9+0x9],r10b
  4115b6:	vxorpd xmm1,xmm1,xmm1
  4115ba:	movzx  edx,dl
  4115bd:	vcvtsi2sd xmm1,xmm1,rdx
  4115c2:	vsubsd xmm0,xmm0,xmm1
  4115c6:	vmulsd xmm0,xmm0,xmm6
  4115ca:	vcvttsd2si rdx,xmm0
  4115cf:	mov    r10b,dl
  4115d2:	add    r10b,0x30
  4115d6:	mov    BYTE PTR [r9+0xa],r10b
  4115da:	vxorpd xmm1,xmm1,xmm1
  4115de:	movzx  edx,dl
  4115e1:	vcvtsi2sd xmm1,xmm1,rdx
  4115e6:	vsubsd xmm0,xmm0,xmm1
  4115ea:	vmulsd xmm0,xmm0,xmm6
  4115ee:	vcvttsd2si rdx,xmm0
  4115f3:	mov    r10b,dl
  4115f6:	add    r10b,0x30
  4115fa:	mov    BYTE PTR [r9+0xb],r10b
  4115fe:	lea    r10,[r9+0x4]
  411602:	vxorpd xmm1,xmm1,xmm1
  411606:	movzx  edx,dl
  411609:	vcvtsi2sd xmm1,xmm1,rdx
  41160e:	vsubsd xmm0,xmm0,xmm1
  411612:	vmulsd xmm0,xmm0,xmm6
  411616:	vcvttsd2si rdx,xmm0
  41161b:	mov    r11b,dl
  41161e:	add    r11b,0x30
  411622:	mov    BYTE PTR [r9+0xc],r11b
  411626:	vxorpd xmm1,xmm1,xmm1
  41162a:	movzx  edx,dl
  41162d:	vcvtsi2sd xmm1,xmm1,rdx
  411632:	vsubsd xmm0,xmm0,xmm1
  411636:	vmulsd xmm0,xmm0,xmm6
  41163a:	vcvttsd2si rdx,xmm0
  41163f:	mov    r11b,dl
  411642:	add    r11b,0x30
  411646:	mov    BYTE PTR [r9+0xd],r11b
  41164a:	lea    r10,[r10+0x2]
  41164e:	vxorpd xmm1,xmm1,xmm1
  411652:	movzx  edx,dl
  411655:	vcvtsi2sd xmm1,xmm1,rdx
  41165a:	vsubsd xmm0,xmm0,xmm1
  41165e:	vmulsd xmm0,xmm0,xmm6
  411662:	vcvttsd2si rdx,xmm0
  411667:	mov    r11b,dl
  41166a:	add    r11b,0x30
  41166e:	mov    BYTE PTR [r9+0xe],r11b
  411672:	vxorpd xmm1,xmm1,xmm1
  411676:	movzx  edx,dl
  411679:	vcvtsi2sd xmm1,xmm1,rdx
  41167e:	vsubsd xmm0,xmm0,xmm1
  411682:	vmulsd xmm0,xmm0,xmm6
  411686:	vcvttsd2si rdx,xmm0
  41168b:	mov    r11b,dl
  41168e:	add    r11b,0x30
  411692:	mov    BYTE PTR [r9+0xf],r11b
  411696:	lea    r10,[r10+0x2]
  41169a:	lea    r10,[r10+0x2]
  41169e:	lea    r10,[r10+0x2]
  4116a2:	lea    r10,[r10+0x2]
  4116a6:	lea    r10,[r10+0x2]
  4116aa:	vxorpd xmm1,xmm1,xmm1
  4116ae:	movzx  edx,dl
  4116b1:	vcvtsi2sd xmm1,xmm1,rdx
  4116b6:	vsubsd xmm0,xmm0,xmm1
  4116ba:	vmulsd xmm0,xmm0,xmm6
  4116be:	vcvttsd2si rdx,xmm0
  4116c3:	mov    r11b,dl
  4116c6:	add    r11b,0x30
  4116ca:	mov    BYTE PTR [r9+0x10],r11b
  4116ce:	vxorpd xmm1,xmm1,xmm1
  4116d2:	movzx  edx,dl
  4116d5:	vcvtsi2sd xmm1,xmm1,rdx
  4116da:	vsubsd xmm0,xmm0,xmm1
  4116de:	vmulsd xmm0,xmm0,xmm6
  4116e2:	vcvttsd2si rdx,xmm0
  4116e7:	add    dl,0x30
  4116ea:	mov    BYTE PTR [r9+0x11],dl
  4116ee:	mov    BYTE PTR [r10+0x2],0x65
  4116f3:	lea    r9,[r10+0x3]
  4116f7:	test   r8,r8
  4116fa:	jl     411703 <__swc_fn_7069e055_000146_d2097256+0xd43>
  4116fc:	mov    BYTE PTR [r9],0x2b
  411700:	inc    r9
  411703:	mov    r10,r9
  411706:	mov    rdx,r8
  411709:	nop    DWORD PTR [rax+0x0]
  411710:	mov    r11,rdx
  411713:	movabs rdx,0x6666666666666667
  41171d:	mov    rax,r11
  411720:	imul   rdx
  411723:	sar    rdx,0x2
  411727:	mov    r12,rdx
  41172a:	shr    rdx,0x3f
  41172e:	add    r12,rdx
  411731:	mov    rdx,r12
  411734:	imul   r13,r12,0xa
  411738:	sub    r11,r13
  41173b:	mov    r13,QWORD PTR [rip+0x1dfe]        # 413540 <__swc_rdata_base_7069e055+0x430>
  411742:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411747:	mov    BYTE PTR [r10],r11b
  41174a:	lea    r11,[r10+0x1]
  41174e:	mov    r10,r11
  411751:	test   r12,r12
  411754:	jne    411710 <__swc_fn_7069e055_000146_d2097256+0xd50>
  411756:	test   r8,r8
  411759:	jge    411763 <__swc_fn_7069e055_000146_d2097256+0xda3>
  41175b:	mov    BYTE PTR [r11],0x2d
  41175f:	lea    r10,[r11+0x1]
  411763:	mov    BYTE PTR [r10],0x0
  411767:	sub    r10,0x1
  41176b:	nop    DWORD PTR [rax+rax*1+0x0]
  411770:	cmp    r9,r10
  411773:	jae    4119e8 <__swc_fn_7069e055_000146_d2097256+0x1028>
  411779:	mov    al,BYTE PTR [r10]
  41177c:	mov    dl,BYTE PTR [r9]
  41177f:	mov    BYTE PTR [r10],dl
  411782:	sub    r10,0x1
  411786:	mov    BYTE PTR [r9],al
  411789:	inc    r9
  41178c:	jmp    411770 <__swc_fn_7069e055_000146_d2097256+0xdb0>
  41178e:	vcvttsd2si rdx,xmm0
  411793:	mov    r8,rdx
  411796:	vxorpd xmm1,xmm1,xmm1
  41179a:	vcvtsi2sd xmm1,xmm1,rdx
  41179f:	vsubsd xmm1,xmm0,xmm1
  4117a3:	mov    r9d,0x8
  4117a9:	vxorpd xmm2,xmm2,xmm2
  4117ad:	vcomisd xmm2,xmm1
  4117b1:	ja     4117be <__swc_fn_7069e055_000146_d2097256+0xdfe>
  4117b3:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  4117bc:	jmp    4117cf <__swc_fn_7069e055_000146_d2097256+0xe0f>
  4117be:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1d8a]        # 413550 <__swc_rdata_base_7069e055+0x440>
  4117c6:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  4117cf:	test   r9d,r9d
  4117d2:	je     4117e9 <__swc_fn_7069e055_000146_d2097256+0xe29>
  4117d4:	cs nop WORD PTR [rax+rax*1+0x0]
  4117de:	xchg   ax,ax
  4117e0:	vmulsd xmm1,xmm1,xmm6
  4117e4:	dec    r9d
  4117e7:	jne    4117e0 <__swc_fn_7069e055_000146_d2097256+0xe20>
  4117e9:	vcvttsd2si r9,xmm1
  4117ee:	mov    r10,r9
  4117f1:	vxorpd xmm2,xmm2,xmm2
  4117f5:	vcvtsi2sd xmm2,xmm2,r9
  4117fa:	vsubsd xmm1,xmm1,xmm2
  4117fe:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  411807:	vcomisd xmm1,xmm6
  41180b:	lea    r9,[r9+0x1]
  41180f:	cmova  r10,r9
  411813:	cmp    r10,0x5f5e100
  41181a:	jne    411833 <__swc_fn_7069e055_000146_d2097256+0xe73>
  41181c:	lea    r8,[rdx-0x1]
  411820:	vxorpd xmm1,xmm1,xmm1
  411824:	vcomisd xmm1,xmm0
  411828:	lea    rdx,[rdx+0x1]
  41182c:	cmovbe r8,rdx
  411830:	xor    r10d,r10d
  411833:	mov    r9,rcx
  411836:	test   r8,r8
  411839:	jne    411859 <__swc_fn_7069e055_000146_d2097256+0xe99>
  41183b:	vxorpd xmm1,xmm1,xmm1
  41183f:	vcomisd xmm1,xmm0
  411843:	jbe    41184c <__swc_fn_7069e055_000146_d2097256+0xe8c>
  411845:	mov    BYTE PTR [rcx],0x2d
  411848:	lea    r9,[rcx+0x1]
  41184c:	mov    BYTE PTR [r9],0x30
  411850:	add    r9,0x1
  411854:	jmp    4118eb <__swc_fn_7069e055_000146_d2097256+0xf2b>
  411859:	mov    r9,rcx
  41185c:	mov    rdx,r8
  41185f:	nop
  411860:	mov    r11,rdx
  411863:	movabs rdx,0x6666666666666667
  41186d:	mov    r15,rax
  411870:	mov    rax,r11
  411873:	imul   rdx
  411876:	mov    r12,rdx
  411879:	mov    rax,r15
  41187c:	sar    r12,0x2
  411880:	mov    rdx,r12
  411883:	shr    rdx,0x3f
  411887:	add    r12,rdx
  41188a:	mov    rdx,r12
  41188d:	imul   r13,r12,0xa
  411891:	sub    r11,r13
  411894:	mov    r13,QWORD PTR [rip+0x1ca5]        # 413540 <__swc_rdata_base_7069e055+0x430>
  41189b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4118a0:	mov    BYTE PTR [r9],r11b
  4118a3:	lea    r11,[r9+0x1]
  4118a7:	mov    r9,r11
  4118aa:	test   r12,r12
  4118ad:	jne    411860 <__swc_fn_7069e055_000146_d2097256+0xea0>
  4118af:	test   r8,r8
  4118b2:	jge    4118bc <__swc_fn_7069e055_000146_d2097256+0xefc>
  4118b4:	mov    BYTE PTR [r11],0x2d
  4118b8:	lea    r9,[r11+0x1]
  4118bc:	mov    rdx,r9
  4118bf:	mov    BYTE PTR [r9],0x0
  4118c3:	sub    r9,0x1
  4118c7:	mov    r8,rcx
  4118ca:	cmp    r8,r9
  4118cd:	jae    4118e8 <__swc_fn_7069e055_000146_d2097256+0xf28>
  4118cf:	nop
  4118d0:	mov    r11b,BYTE PTR [r9]
  4118d3:	mov    r12b,BYTE PTR [r8]
  4118d6:	mov    BYTE PTR [r9],r12b
  4118d9:	sub    r9,0x1
  4118dd:	mov    BYTE PTR [r8],r11b
  4118e0:	inc    r8
  4118e3:	cmp    r8,r9
  4118e6:	jb     4118d0 <__swc_fn_7069e055_000146_d2097256+0xf10>
  4118e8:	mov    r9,rdx
  4118eb:	mov    BYTE PTR [r9],0x2e
  4118ef:	add    r9,0x1
  4118f3:	xor    r8d,r8d
  4118f6:	test   r10,r10
  4118f9:	je     41193f <__swc_fn_7069e055_000146_d2097256+0xf7f>
  4118fb:	mov    r11d,0x989680
  411901:	cmp    r10,r11
  411904:	jge    41193f <__swc_fn_7069e055_000146_d2097256+0xf7f>
  411906:	cs nop WORD PTR [rax+rax*1+0x0]
  411910:	inc    r8d
  411913:	movabs rdx,0x6666666666666667
  41191d:	mov    r15,rax
  411920:	mov    rax,r11
  411923:	imul   rdx
  411926:	mov    r11,rdx
  411929:	mov    rax,r15
  41192c:	sar    r11,0x2
  411930:	mov    rdx,r11
  411933:	shr    rdx,0x3f
  411937:	add    r11,rdx
  41193a:	cmp    r10,r11
  41193d:	jl     411910 <__swc_fn_7069e055_000146_d2097256+0xf50>
  41193f:	test   r8d,r8d
  411942:	je     41195d <__swc_fn_7069e055_000146_d2097256+0xf9d>
  411944:	cs nop WORD PTR [rax+rax*1+0x0]
  41194e:	xchg   ax,ax
  411950:	mov    BYTE PTR [r9],0x30
  411954:	add    r9,0x1
  411958:	dec    r8d
  41195b:	jne    411950 <__swc_fn_7069e055_000146_d2097256+0xf90>
  41195d:	mov    r8,r9
  411960:	mov    rdx,r10
  411963:	cs nop WORD PTR [rax+rax*1+0x0]
  41196d:	nop    DWORD PTR [rax]
  411970:	mov    r11,rdx
  411973:	movabs rdx,0x6666666666666667
  41197d:	mov    rax,r11
  411980:	imul   rdx
  411983:	sar    rdx,0x2
  411987:	mov    r12,rdx
  41198a:	shr    rdx,0x3f
  41198e:	add    r12,rdx
  411991:	mov    rdx,r12
  411994:	imul   r13,r12,0xa
  411998:	sub    r11,r13
  41199b:	mov    r13,QWORD PTR [rip+0x1b9e]        # 413540 <__swc_rdata_base_7069e055+0x430>
  4119a2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4119a7:	mov    BYTE PTR [r8],r11b
  4119aa:	lea    r11,[r8+0x1]
  4119ae:	mov    r8,r11
  4119b1:	test   r12,r12
  4119b4:	jne    411970 <__swc_fn_7069e055_000146_d2097256+0xfb0>
  4119b6:	test   r10,r10
  4119b9:	jge    4119c3 <__swc_fn_7069e055_000146_d2097256+0x1003>
  4119bb:	mov    BYTE PTR [r11],0x2d
  4119bf:	lea    r8,[r11+0x1]
  4119c3:	mov    BYTE PTR [r8],0x0
  4119c7:	sub    r8,0x1
  4119cb:	cmp    r9,r8
  4119ce:	jae    4119e8 <__swc_fn_7069e055_000146_d2097256+0x1028>
  4119d0:	mov    al,BYTE PTR [r8]
  4119d3:	mov    dl,BYTE PTR [r9]
  4119d6:	mov    BYTE PTR [r8],dl
  4119d9:	sub    r8,0x1
  4119dd:	mov    BYTE PTR [r9],al
  4119e0:	inc    r9
  4119e3:	cmp    r9,r8
  4119e6:	jb     4119d0 <__swc_fn_7069e055_000146_d2097256+0x1010>
  4119e8:	xor    eax,eax
  4119ea:	test   rcx,rcx
  4119ed:	je     411a10 <__swc_fn_7069e055_000146_d2097256+0x1050>
  4119ef:	mov    rdx,rcx
  4119f2:	mov    r8b,BYTE PTR [rdx]
  4119f5:	test   r8b,r8b
  4119f8:	je     411a10 <__swc_fn_7069e055_000146_d2097256+0x1050>
  4119fa:	nop    WORD PTR [rax+rax*1+0x0]
  411a00:	add    rdx,0x1
  411a04:	add    rax,0x1
  411a08:	mov    r8b,BYTE PTR [rdx]
  411a0b:	test   r8b,r8b
  411a0e:	jne    411a00 <__swc_fn_7069e055_000146_d2097256+0x1040>
  411a10:	mov    QWORD PTR [rsp+0x3f8],rcx
  411a18:	mov    QWORD PTR [rsp+0x400],rax
  411a20:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  411a29:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  411a32:	lea    rcx,[rsp+0x408]
  411a3a:	call   410150 <__swc_fn_7069e055_000116_3f5cfdef>
  411a3f:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  411a41:	mov    rcx,rdx
  411a44:	call   410150 <__swc_fn_7069e055_000116_3f5cfdef>
  411a49:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  411a4b:	mov    al,BYTE PTR [rdx]
  411a4d:	test   al,al
  411a4f:	je     411a5a <__swc_fn_7069e055_000146_d2097256+0x109a>
  411a51:	lea    rax,[rip+0x1b08]        # 413560 <__swc_rdata_base_7069e055+0x450>
  411a58:	jmp    411a61 <__swc_fn_7069e055_000146_d2097256+0x10a1>
  411a5a:	lea    rax,[rip+0x1b0f]        # 413570 <__swc_rdata_base_7069e055+0x460>
  411a61:	mov    rcx,rax
  411a64:	call   410150 <__swc_fn_7069e055_000116_3f5cfdef>
  411a69:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  411a6b:	lea    rcx,[rip+0x1b0e]        # 413580 <__swc_rdata_base_7069e055+0x470>
  411a72:	call   410150 <__swc_fn_7069e055_000116_3f5cfdef>
  411a77:	jmp    411a85 <__swc_fn_7069e055_000146_d2097256+0x10c5>
  411a79:	lea    rcx,[rip+0x1b00]        # 413580 <__swc_rdata_base_7069e055+0x470>
  411a80:	call   410150 <__swc_fn_7069e055_000116_3f5cfdef>
  411a85:	add    rdi,0x1
  411a89:	sub    rsi,0x1
  411a8d:	vmovups xmm0,xmm12
  411a92:	vmovsd xmm6,QWORD PTR [rip+0x1af6]        # 413590 <__swc_rdata_base_7069e055+0x480>
  411a9a:	test   rsi,rsi
  411a9d:	jne    410ad0 <__swc_fn_7069e055_000146_d2097256+0x110>
  411aa3:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  411aac:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411ab5:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  411abe:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411ac7:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411ad0:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411ad9:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411ae2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  411aeb:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411af4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  411afd:	add    rsp,0x4e8
  411b04:	pop    r15
  411b06:	pop    r13
  411b08:	pop    r12
  411b0a:	pop    rdi
  411b0b:	pop    rsi
  411b0c:	pop    rbx
  411b0d:	ret
	...

0000000000411b10 <__swc_fn_7069e055_000149_365b4daf>:
  411b10:	vxorps xmm0,xmm0,xmm0
  411b14:	vmovups XMMWORD PTR [rcx],xmm0
  411b18:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411b1d:	ret
	...

0000000000411b20 <__swc_fn_7069e055_000152_365b4daf>:
  411b20:	vxorps xmm0,xmm0,xmm0
  411b24:	vmovups XMMWORD PTR [rcx],xmm0
  411b28:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411b2d:	vxorps xmm0,xmm0,xmm0
  411b31:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411b36:	vmovups xmm0,XMMWORD PTR [rip+0x1b62]        # 4136a0 <__swc_rdata_base_7069e055+0x590>
  411b3e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411b43:	vxorps xmm0,xmm0,xmm0
  411b47:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411b4c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411b51:	vxorps xmm0,xmm0,xmm0
  411b55:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411b5a:	mov    QWORD PTR [rcx+0x70],0x0
  411b62:	ret
	...

0000000000411b70 <__swc_fn_7069e055_000155_365b4daf>:
  411b70:	vxorps xmm0,xmm0,xmm0
  411b74:	vmovups XMMWORD PTR [rcx],xmm0
  411b78:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411b7d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411b82:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411b87:	ret
	...

0000000000411b90 <__swc_fn_7069e055_000158_31e09513>:
  411b90:	push   rsi
  411b91:	push   rdi
  411b92:	sub    rsp,0x8
  411b96:	mov    rsi,rcx
  411b99:	mov    rdi,QWORD PTR [rsi+0x50]
  411b9d:	test   rdi,rdi
  411ba0:	je     411ba7 <__swc_fn_7069e055_000158_31e09513+0x17>
  411ba2:	mov    rcx,rsi
  411ba5:	call   rdi
  411ba7:	mov    QWORD PTR [rsi+0x20],0x0
  411baf:	mov    rax,QWORD PTR [rsi+0x30]
  411bb3:	test   rax,rax
  411bb6:	je     411be4 <__swc_fn_7069e055_000158_31e09513+0x54>
  411bb8:	nop    DWORD PTR [rax+rax*1+0x0]
  411bc0:	mov    rdi,QWORD PTR [rax+0x8]
  411bc4:	mov    rcx,rsi
  411bc7:	mov    rdx,QWORD PTR [rax+0x10]
  411bcb:	mov    rax,QWORD PTR [rax+0x18]
  411bcf:	mov    r8,rax
  411bd2:	call   409e90 <__swc_fn_7069e055_000156_9e2052d6>
  411bd7:	mov    QWORD PTR [rsi+0x30],rdi
  411bdb:	mov    rax,QWORD PTR [rsi+0x30]
  411bdf:	test   rax,rax
  411be2:	jne    411bc0 <__swc_fn_7069e055_000158_31e09513+0x30>
  411be4:	mov    QWORD PTR [rsi+0x38],0x0
  411bec:	add    rsp,0x8
  411bf0:	pop    rdi
  411bf1:	pop    rsi
  411bf2:	ret
	...

0000000000411c00 <__swc_fn_7069e055_000161_b553c03d>:
  411c00:	push   rbx
  411c01:	push   rsi
  411c02:	push   rdi
  411c03:	push   r12
  411c05:	sub    rsp,0x188
  411c0c:	mov    rbx,rcx
  411c0f:	lea    rsi,[rip+0x1517a]        # 426d90 <__swc_bss_base_7069e055+0x2d50>
  411c16:	mov    rcx,rsi
  411c19:	call   4098a0 <__swc_fn_7069e055_000135_db32cc57>
  411c1e:	mov    rax,QWORD PTR [rip+0x15173]        # 426d98 <__swc_bss_base_7069e055+0x2d58>
  411c25:	mov    rdi,rax
  411c28:	test   rdi,rdi
  411c2b:	je     411c59 <__swc_fn_7069e055_000161_b553c03d+0x59>
  411c2d:	nop    DWORD PTR [rax]
  411c30:	cmp    QWORD PTR [rdi+0x8],rbx
  411c34:	jne    411c4e <__swc_fn_7069e055_000161_b553c03d+0x4e>
  411c36:	mov    rcx,rsi
  411c39:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  411c3e:	mov    rax,rdi
  411c41:	add    rsp,0x188
  411c48:	pop    r12
  411c4a:	pop    rdi
  411c4b:	pop    rsi
  411c4c:	pop    rbx
  411c4d:	ret
  411c4e:	mov    rax,QWORD PTR [rdi]
  411c51:	mov    rdi,rax
  411c54:	test   rax,rax
  411c57:	jne    411c30 <__swc_fn_7069e055_000161_b553c03d+0x30>
  411c59:	call   40ce80 <__swc_fn_7069e055_000139_e4a7a8b1>
  411c5e:	mov    rdi,rax
  411c61:	test   rax,rax
  411c64:	jne    411c7d <__swc_fn_7069e055_000161_b553c03d+0x7d>
  411c66:	mov    rcx,rsi
  411c69:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  411c6e:	xor    eax,eax
  411c70:	add    rsp,0x188
  411c77:	pop    r12
  411c79:	pop    rdi
  411c7a:	pop    rsi
  411c7b:	pop    rbx
  411c7c:	ret
  411c7d:	lea    rax,[rsp+0x18]
  411c82:	mov    QWORD PTR [rax+0x10],0x0
  411c8a:	mov    QWORD PTR [rax+0x18],0x0
  411c92:	mov    DWORD PTR [rax+0x20],0x0
  411c99:	mov    BYTE PTR [rax+0x24],0x0
  411c9d:	mov    rax,QWORD PTR [rip+0x150f4]        # 426d98 <__swc_bss_base_7069e055+0x2d58>
  411ca4:	mov    QWORD PTR [rsp+0x18],rax
  411ca9:	mov    QWORD PTR [rsp+0x20],rbx
  411cae:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411cb4:	vmovups XMMWORD PTR [rdi],xmm0
  411cb8:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411cbe:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411cc3:	mov    rax,QWORD PTR [rsp+0x38]
  411cc8:	mov    QWORD PTR [rdi+0x20],rax
  411ccc:	mov    QWORD PTR [rip+0x150c5],rdi        # 426d98 <__swc_bss_base_7069e055+0x2d58>
  411cd3:	lea    rax,[rsp+0x40]
  411cd8:	mov    QWORD PTR [rax],0x0
  411cdf:	mov    rcx,rbx
  411ce2:	mov    rdx,rax
  411ce5:	call   409980 <__swc_fn_7069e055_000141_5e493395>
  411cea:	mov    rbx,rax
  411ced:	test   rax,rax
  411cf0:	jne    411d0a <__swc_fn_7069e055_000161_b553c03d+0x10a>
  411cf2:	mov    rcx,rsi
  411cf5:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  411cfa:	mov    rax,rdi
  411cfd:	add    rsp,0x188
  411d04:	pop    r12
  411d06:	pop    rdi
  411d07:	pop    rsi
  411d08:	pop    rbx
  411d09:	ret
  411d0a:	lea    r12,[rsp+0x50]
  411d0f:	mov    QWORD PTR [r12],0x0
  411d17:	mov    rcx,rbx
  411d1a:	mov    rdx,QWORD PTR [rsp+0x40]
  411d1f:	mov    r8,r12
  411d22:	call   40cf30 <__swc_fn_7069e055_000142_89a6ef72>
  411d27:	test   rax,rax
  411d2a:	jne    411d44 <__swc_fn_7069e055_000161_b553c03d+0x144>
  411d2c:	mov    rcx,rsi
  411d2f:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  411d34:	mov    rax,rdi
  411d37:	add    rsp,0x188
  411d3e:	pop    r12
  411d40:	pop    rdi
  411d41:	pop    rsi
  411d42:	pop    rbx
  411d43:	ret
  411d44:	cmp    QWORD PTR [r12],0x10
  411d49:	jb     411e4c <__swc_fn_7069e055_000161_b553c03d+0x24c>
  411d4f:	mov    ecx,DWORD PTR [rax]
  411d51:	cmp    ecx,0x42445753
  411d57:	jne    411e4c <__swc_fn_7069e055_000161_b553c03d+0x24c>
  411d5d:	mov    ecx,DWORD PTR [rax+0x4]
  411d60:	cmp    ecx,0x1
  411d63:	jne    411e4c <__swc_fn_7069e055_000161_b553c03d+0x24c>
  411d69:	mov    ecx,DWORD PTR [rax+0x8]
  411d6c:	mov    edx,DWORD PTR [rax+0xc]
  411d6f:	imul   r8,rcx,0x14
  411d73:	mov    r9,QWORD PTR [rsp+0x50]
  411d78:	sub    r9,0x10
  411d7c:	cmp    r8,r9
  411d7f:	ja     411e4c <__swc_fn_7069e055_000161_b553c03d+0x24c>
  411d85:	lea    r8,[r8+0x10]
  411d89:	cmp    rdx,r8
  411d8c:	jb     411e4c <__swc_fn_7069e055_000161_b553c03d+0x24c>
  411d92:	mov    r8,QWORD PTR [rsp+0x50]
  411d97:	cmp    rdx,r8
  411d9a:	ja     411e4c <__swc_fn_7069e055_000161_b553c03d+0x24c>
  411da0:	xor    r8d,r8d
  411da3:	test   rcx,rcx
  411da6:	jbe    411e72 <__swc_fn_7069e055_000161_b553c03d+0x272>
  411dac:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411db2:	cs nop WORD PTR [rax+rax*1+0x0]
  411dbc:	nop    DWORD PTR [rax+0x0]
  411dc0:	imul   r9,r8,0x14
  411dc4:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411dc9:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  411dce:	add    r10,r11
  411dd1:	movabs r11,0x100000000
  411ddb:	cmp    r10,r11
  411dde:	ja     411e4c <__swc_fn_7069e055_000161_b553c03d+0x24c>
  411de0:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411de5:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  411dea:	test   r10d,r10d
  411ded:	setne  r11b
  411df1:	je     411e0b <__swc_fn_7069e055_000161_b553c03d+0x20b>
  411df3:	cmp    r10d,edx
  411df6:	setb   r11b
  411dfa:	jb     411e0b <__swc_fn_7069e055_000161_b553c03d+0x20b>
  411dfc:	vmovq  r11,xmm1
  411e01:	cmp    r10,r11
  411e04:	setae  r10b
  411e08:	mov    r11b,r10b
  411e0b:	mov    r10,r11
  411e0e:	test   r11b,r11b
  411e11:	jne    411e38 <__swc_fn_7069e055_000161_b553c03d+0x238>
  411e13:	test   r9d,r9d
  411e16:	setne  r10b
  411e1a:	je     411e38 <__swc_fn_7069e055_000161_b553c03d+0x238>
  411e1c:	cmp    r9d,edx
  411e1f:	setb   r10b
  411e23:	jb     411e38 <__swc_fn_7069e055_000161_b553c03d+0x238>
  411e25:	vmovq  r10,xmm1
  411e2a:	cmp    r9,r10
  411e2d:	setae  r9b
  411e31:	movzx  r9d,r9b
  411e35:	mov    r10b,r9b
  411e38:	test   r10b,r10b
  411e3b:	jne    411e4c <__swc_fn_7069e055_000161_b553c03d+0x24c>
  411e3d:	add    r8,0x1
  411e41:	cmp    r8,rcx
  411e44:	jb     411dc0 <__swc_fn_7069e055_000161_b553c03d+0x1c0>
  411e4a:	jmp    411e72 <__swc_fn_7069e055_000161_b553c03d+0x272>
  411e4c:	xor    ecx,ecx
  411e4e:	cmp    rax,rbx
  411e51:	cmovne rcx,rax
  411e55:	call   410910 <__swc_fn_7069e055_000143_b7ad855f>
  411e5a:	mov    rcx,rsi
  411e5d:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  411e62:	mov    rax,rdi
  411e65:	add    rsp,0x188
  411e6c:	pop    r12
  411e6e:	pop    rdi
  411e6f:	pop    rsi
  411e70:	pop    rbx
  411e71:	ret
  411e72:	mov    QWORD PTR [rdi+0x10],rax
  411e76:	mov    rcx,QWORD PTR [rsp+0x50]
  411e7b:	mov    QWORD PTR [rdi+0x18],rcx
  411e7f:	mov    eax,DWORD PTR [rax+0x8]
  411e82:	mov    DWORD PTR [rdi+0x20],eax
  411e85:	rex mov BYTE PTR [rdi+0x24],0x1
  411e8a:	mov    rcx,rsi
  411e8d:	call   40ce70 <__swc_fn_7069e055_000136_d579ef75>
  411e92:	mov    rax,rdi
  411e95:	add    rsp,0x188
  411e9c:	pop    r12
  411e9e:	pop    rdi
  411e9f:	pop    rsi
  411ea0:	pop    rbx
  411ea1:	ret
	...

0000000000411eb0 <__swc_fn_7069e055_000164_d25850aa>:
  411eb0:	push   rsi
  411eb1:	push   rdi
  411eb2:	push   r12
  411eb4:	mov    rsi,rdx
  411eb7:	mov    rdi,rcx
  411eba:	mov    rcx,QWORD PTR [rip+0x14e7f]        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  411ec1:	test   rcx,rcx
  411ec4:	jne    411ed6 <__swc_fn_7069e055_000164_d25850aa+0x26>
  411ec6:	call   40a1a0 <__swc_fn_7069e055_000165_56054fe7>
  411ecb:	lea    rcx,[rax+0x1]
  411ecf:	mov    QWORD PTR [rip+0x14e6a],rcx        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  411ed6:	dec    rcx
  411ed9:	call   411f00 <__swc_fn_7069e055_000167_39c041ad>
  411ede:	mov    r12,QWORD PTR [rax+0xbe0]
  411ee5:	test   r12,r12
  411ee8:	setne  al
  411eeb:	je     411ef6 <__swc_fn_7069e055_000164_d25850aa+0x46>
  411eed:	mov    rcx,rdi
  411ef0:	mov    rdx,rsi
  411ef3:	call   r12
  411ef6:	pop    r12
  411ef8:	pop    rdi
  411ef9:	pop    rsi
  411efa:	ret
  411efb:	add    BYTE PTR [rax],al
  411efd:	add    BYTE PTR [rax],al
	...

0000000000411f00 <__swc_fn_7069e055_000167_39c041ad>:
  411f00:	push   r12
  411f02:	push   rdi
  411f03:	push   rsi
  411f04:	sub    rsp,0xd0
  411f0b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411f11:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411f17:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  411f1d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  411f23:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  411f29:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  411f2f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411f38:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  411f41:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  411f4a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  411f53:	mov    r12,rcx
  411f56:	mov    edi,ecx
  411f58:	xor    eax,eax
  411f5a:	call   407000 <pthread_getspecific@plt>
  411f5f:	test   rax,rax
  411f62:	je     411f66 <__swc_fn_7069e055_000167_39c041ad+0x66>
  411f64:	jmp    411f6e <__swc_fn_7069e055_000167_39c041ad+0x6e>
  411f66:	mov    rcx,r12
  411f69:	call   40a200 <__swc_fn_7069e055_000168_0ad81c51>
  411f6e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  411f74:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  411f7a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411f80:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411f86:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  411f8c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411f92:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  411f9b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411fa4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  411fad:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411fb6:	add    rsp,0xd0
  411fbd:	pop    rsi
  411fbe:	pop    rdi
  411fbf:	pop    r12
  411fc1:	ret
	...

0000000000411fd0 <__swc_fn_7069e055_000170_4dbacba0>:
  411fd0:	push   rsi
  411fd1:	sub    rsp,0x30
  411fd5:	lea    rsi,[rip+0x14dcc]        # 426da8 <__swc_bss_base_7069e055+0x2d68>
  411fdc:	mov    rax,QWORD PTR [rsi]
  411fdf:	test   rax,rax
  411fe2:	je     411fea <__swc_fn_7069e055_000170_4dbacba0+0x1a>
  411fe4:	add    rsp,0x30
  411fe8:	pop    rsi
  411fe9:	ret
  411fea:	mov    ecx,0x3
  411fef:	mov    edx,0x10
  411ff4:	call   40fa70 <__swc_fn_7069e055_000107_c8d4a68e>
  411ff9:	test   rax,rax
  411ffc:	jne    41200d <__swc_fn_7069e055_000170_4dbacba0+0x3d>
  411ffe:	mov    QWORD PTR [rsp+0x18],rax
  412003:	call   40c9d0 <__swc_fn_7069e055_000118_591530fe>
  412008:	mov    rax,QWORD PTR [rsp+0x18]
  41200d:	mov    rcx,rax
  412010:	xchg   QWORD PTR [rsi],rcx
  412013:	add    rsp,0x30
  412017:	pop    rsi
  412018:	ret
  412019:	add    BYTE PTR [rax],al
  41201b:	add    BYTE PTR [rax],al
  41201d:	add    BYTE PTR [rax],al
	...

0000000000412020 <__swc_fn_7069e055_000173_e17a224b>:
  412020:	push   rsi
  412021:	push   rdi
  412022:	sub    rsp,0x8
  412026:	mov    rsi,rdx
  412029:	mov    rdi,rcx
  41202c:	mov    rax,QWORD PTR [rsi+0x8]
  412030:	test   rax,rax
  412033:	je     41203d <__swc_fn_7069e055_000173_e17a224b+0x1d>
  412035:	mov    rcx,QWORD PTR [rsi]
  412038:	mov    QWORD PTR [rax],rcx
  41203b:	jmp    412044 <__swc_fn_7069e055_000173_e17a224b+0x24>
  41203d:	mov    rax,QWORD PTR [rsi]
  412040:	mov    QWORD PTR [rdi+0x8],rax
  412044:	mov    rax,QWORD PTR [rsi]
  412047:	test   rax,rax
  41204a:	je     412054 <__swc_fn_7069e055_000173_e17a224b+0x34>
  41204c:	mov    rcx,QWORD PTR [rsi+0x8]
  412050:	mov    QWORD PTR [rax+0x8],rcx
  412054:	mov    rcx,rdi
  412057:	mov    rdx,QWORD PTR [rsi+0x10]
  41205b:	mov    r8,QWORD PTR [rsi+0x18]
  41205f:	mov    r9,0xffffffffffffffff
  412066:	call   40d580 <__swc_fn_7069e055_000172_1751ecdd>
  41206b:	mov    QWORD PTR [rsi+0x18],0x0
  412073:	mov    rax,QWORD PTR [rdi+0x8]
  412077:	test   rax,rax
  41207a:	jne    41208c <__swc_fn_7069e055_000173_e17a224b+0x6c>
  41207c:	call   411fd0 <__swc_fn_7069e055_000170_4dbacba0>
  412081:	xor    ecx,ecx
  412083:	mov    QWORD PTR [rax+0x8],rcx
  412087:	xor    ecx,ecx
  412089:	mov    QWORD PTR [rax],rcx
  41208c:	add    rsp,0x8
  412090:	pop    rdi
  412091:	pop    rsi
  412092:	ret
	...

00000000004120a0 <__swc_fn_7069e055_000176_5d3d19bd>:
  4120a0:	push   rbx
  4120a1:	sub    rsp,0x70
  4120a5:	test   rcx,rcx
  4120a8:	jne    4120b0 <__swc_fn_7069e055_000176_5d3d19bd+0x10>
  4120aa:	add    rsp,0x70
  4120ae:	pop    rbx
  4120af:	ret
  4120b0:	vxorps xmm0,xmm0,xmm0
  4120b4:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  4120ba:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  4120c0:	vzeroupper
  4120c3:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  4120c9:	lea    rax,[rcx-0x10]
  4120cd:	mov    QWORD PTR [rsp+0x48],rax
  4120d2:	mov    rax,QWORD PTR [rcx-0x10]
  4120d6:	mov    QWORD PTR [rsp+0x50],rax
  4120db:	mov    rcx,QWORD PTR [rip+0x14c5e]        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  4120e2:	test   rcx,rcx
  4120e5:	jne    4120f7 <__swc_fn_7069e055_000176_5d3d19bd+0x57>
  4120e7:	call   40a1a0 <__swc_fn_7069e055_000165_56054fe7>
  4120ec:	lea    rcx,[rax+0x1]
  4120f0:	mov    QWORD PTR [rip+0x14c49],rcx        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  4120f7:	dec    rcx
  4120fa:	call   411f00 <__swc_fn_7069e055_000167_39c041ad>
  4120ff:	mov    rcx,QWORD PTR [rax]
  412102:	lea    rdx,[rsp+0x8]
  412107:	mov    rbx,QWORD PTR [rax+0x8]
  41210b:	mov    rbx,QWORD PTR [rbx+0x18]
  41210f:	call   rbx
  412111:	add    rsp,0x70
  412115:	pop    rbx
  412116:	ret
