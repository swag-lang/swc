
/workspace/prompt2-20261115/batch9-audited-micro/new/binarytrees/binarytrees:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xb00a]        # 412010 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <mmap@plt>:
  407010:	jmp    QWORD PTR [rip+0xb002]        # 412018 <mmap@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <mprotect@plt>:
  407020:	jmp    QWORD PTR [rip+0xaffa]        # 412020 <mprotect@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <munmap@plt>:
  407030:	jmp    QWORD PTR [rip+0xaff2]        # 412028 <munmap@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <madvise@plt>:
  407040:	jmp    QWORD PTR [rip+0xafea]        # 412030 <madvise@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <exit@plt>:
  407050:	jmp    QWORD PTR [rip+0xafe2]        # 412038 <exit@GLIBC_2.2.5>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_key_delete@plt>:
  407060:	jmp    QWORD PTR [rip+0xafda]        # 412040 <pthread_key_delete@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <gettid@plt>:
  407070:	jmp    QWORD PTR [rip+0xafd2]        # 412048 <gettid@GLIBC_2.30>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <syscall@plt>:
  407080:	jmp    QWORD PTR [rip+0xafca]        # 412050 <syscall@GLIBC_2.2.5>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <malloc@plt>:
  407090:	jmp    QWORD PTR [rip+0xafc2]        # 412058 <malloc@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <clock_gettime@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xafba]        # 412060 <clock_gettime@GLIBC_2.17>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <open@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xafb2]        # 412068 <open@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <flock@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xafaa]        # 412070 <flock@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <__errno_location@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xafa2]        # 412078 <__errno_location@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <close@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xaf9a]        # 412080 <close@GLIBC_2.2.5>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <getpid@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xaf92]        # 412088 <getpid@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <opendir@plt>:
  407100:	jmp    QWORD PTR [rip+0xaf8a]        # 412090 <opendir@GLIBC_2.2.5>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <dirfd@plt>:
  407110:	jmp    QWORD PTR [rip+0xaf82]        # 412098 <dirfd@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <readdir@plt>:
  407120:	jmp    QWORD PTR [rip+0xaf7a]        # 4120a0 <readdir@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <readlinkat@plt>:
  407130:	jmp    QWORD PTR [rip+0xaf72]        # 4120a8 <readlinkat@GLIBC_2.4>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <openat@plt>:
  407140:	jmp    QWORD PTR [rip+0xaf6a]        # 4120b0 <openat@GLIBC_2.4>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <closedir@plt>:
  407150:	jmp    QWORD PTR [rip+0xaf62]        # 4120b8 <closedir@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <lseek@plt>:
  407160:	jmp    QWORD PTR [rip+0xaf5a]        # 4120c0 <lseek@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <memfd_create@plt>:
  407170:	jmp    QWORD PTR [rip+0xaf52]        # 4120c8 <memfd_create@GLIBC_2.27>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <ftruncate@plt>:
  407180:	jmp    QWORD PTR [rip+0xaf4a]        # 4120d0 <ftruncate@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <write@plt>:
  407190:	jmp    QWORD PTR [rip+0xaf42]        # 4120d8 <write@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <backtrace@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xaf3a]        # 4120e0 <backtrace@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <pthread_setspecific@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xaf32]        # 4120e8 <pthread_setspecific@GLIBC_2.34>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <__x86_get_cpuid_feature_leaf@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xaf2a]        # 4120f0 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <free@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xaf22]        # 4120f8 <free@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <pthread_key_create@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xaf1a]        # 412100 <pthread_key_create@GLIBC_2.34>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <dladdr@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xaf12]        # 412108 <dladdr@GLIBC_2.34>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xaddf]        # 412000 <__swc_fn_7dafa2b1_000179_718d7b54+0x530>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   409b20 <__swc_fn_7dafa2b1_000126_540bf7e8>
  40724e:	xor    ecx,ecx
  407250:	call   409240 <__swc_fn_7dafa2b1_000099_4f209617>
  407255:	call   407330 <__swc_fn_7dafa2b1_000003_a6773dec>
  40725a:	call   40c030 <__swc_fn_7dafa2b1_000100_65137b72>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_7dafa2b1_000000_82999b37>:
  407270:	push   rbx
  407271:	push   rsi
  407272:	sub    rsp,0x68
  407276:	mov    rbx,rcx
  407279:	vxorps xmm0,xmm0,xmm0
  40727d:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  407283:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  407289:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40728f:	vzeroupper
  407292:	mov    QWORD PTR [rsp+0x50],0x20
  40729b:	mov    DWORD PTR [rsp+0x60],0x10
  4072a3:	mov    rcx,QWORD PTR [rip+0x1bd96]        # 423040 <__swc_bss_base_7dafa2b1>
  4072aa:	test   rcx,rcx
  4072ad:	jne    4072bf <__swc_fn_7dafa2b1_000000_82999b37+0x4f>
  4072af:	call   4119a0 <__swc_fn_7dafa2b1_000170_994c8876>
  4072b4:	lea    rcx,[rax+0x1]
  4072b8:	mov    QWORD PTR [rip+0x1bd81],rcx        # 423040 <__swc_bss_base_7dafa2b1>
  4072bf:	dec    rcx
  4072c2:	call   40e840 <__swc_fn_7dafa2b1_000172_360af05d>
  4072c7:	mov    rcx,QWORD PTR [rax]
  4072ca:	lea    rdx,[rsp+0x8]
  4072cf:	mov    rsi,QWORD PTR [rax+0x8]
  4072d3:	mov    rsi,QWORD PTR [rsi+0x8]
  4072d7:	call   rsi
  4072d9:	mov    rax,QWORD PTR [rsp+0x48]
  4072de:	test   rax,rax
  4072e1:	jne    4072e7 <__swc_fn_7dafa2b1_000000_82999b37+0x77>
  4072e3:	xor    esi,esi
  4072e5:	jmp    4072fb <__swc_fn_7dafa2b1_000000_82999b37+0x8b>
  4072e7:	mov    rcx,QWORD PTR [rsp+0x50]
  4072ec:	mov    QWORD PTR [rax],rcx
  4072ef:	mov    QWORD PTR [rax+0x8],0x0
  4072f7:	lea    rsi,[rax+0x10]
  4072fb:	test   ebx,ebx
  4072fd:	jle    407318 <__swc_fn_7dafa2b1_000000_82999b37+0xa8>
  4072ff:	dec    ebx
  407301:	mov    ecx,ebx
  407303:	call   407270 <__swc_fn_7dafa2b1_000000_82999b37>
  407308:	mov    QWORD PTR [rsi],rax
  40730b:	mov    ecx,ebx
  40730d:	call   407270 <__swc_fn_7dafa2b1_000000_82999b37>
  407312:	mov    QWORD PTR [rsi+0x8],rax
  407316:	jmp    407320 <__swc_fn_7dafa2b1_000000_82999b37+0xb0>
  407318:	vxorps xmm0,xmm0,xmm0
  40731c:	vmovdqu XMMWORD PTR [rsi],xmm0
  407320:	mov    rax,rsi
  407323:	add    rsp,0x68
  407327:	pop    rsi
  407328:	pop    rbx
  407329:	ret
  40732a:	add    BYTE PTR [rax],al
  40732c:	add    BYTE PTR [rax],al
	...

0000000000407330 <__swc_fn_7dafa2b1_000003_a6773dec>:
  407330:	push   rbp
  407331:	push   rbx
  407332:	push   rsi
  407333:	push   rdi
  407334:	push   r12
  407336:	push   r13
  407338:	push   r14
  40733a:	push   r15
  40733c:	sub    rsp,0x10
  407340:	mov    rbp,rsp
  407343:	vmovups XMMWORD PTR [rsp],xmm6
  407348:	sub    rsp,0x10
  40734c:	mov    rbx,rsp
  40734f:	sub    rsp,0x8
  407353:	call   40a720 <__swc_fn_7dafa2b1_000004_1ca87929>
  407358:	vmovups xmm6,xmm0
  40735c:	mov    ecx,0xd
  407361:	call   407270 <__swc_fn_7dafa2b1_000000_82999b37>
  407366:	mov    rsi,rax
  407369:	mov    rcx,rax
  40736c:	call   40a6e0 <__swc_fn_7dafa2b1_000001_cb8588f1>
  407371:	mov    rdi,rax
  407374:	mov    rcx,rsi
  407377:	call   40e9e0 <__swc_fn_7dafa2b1_000002_6e6aee58>
  40737c:	mov    ecx,0xc
  407381:	call   407270 <__swc_fn_7dafa2b1_000000_82999b37>
  407386:	mov    rsi,rax
  407389:	mov    r12,rbx
  40738c:	mov    DWORD PTR [rbx],0x4
  407392:	mov    eax,DWORD PTR [rbx]
  407394:	cmp    eax,0xc
  407397:	jg     4073f6 <__swc_fn_7dafa2b1_000003_a6773dec+0xc6>
  407399:	nop    DWORD PTR [rax+0x0]
  4073a0:	mov    eax,0xc
  4073a5:	sub    eax,DWORD PTR [rbx]
  4073a7:	mov    r13d,0x1
  4073ad:	lea    ecx,[rax+0x4]
  4073b0:	shl    r13,cl
  4073b3:	xor    r14d,r14d
  4073b6:	test   r13,r13
  4073b9:	jbe    4073ea <__swc_fn_7dafa2b1_000003_a6773dec+0xba>
  4073bb:	nop    DWORD PTR [rax+rax*1+0x0]
  4073c0:	mov    rax,r12
  4073c3:	movsxd rcx,DWORD PTR [rax]
  4073c6:	call   407270 <__swc_fn_7dafa2b1_000000_82999b37>
  4073cb:	mov    r15,rax
  4073ce:	mov    rcx,rax
  4073d1:	call   40a6e0 <__swc_fn_7dafa2b1_000001_cb8588f1>
  4073d6:	add    rdi,rax
  4073d9:	mov    rcx,r15
  4073dc:	call   40e9e0 <__swc_fn_7dafa2b1_000002_6e6aee58>
  4073e1:	add    r14,0x1
  4073e5:	cmp    r14,r13
  4073e8:	jb     4073c0 <__swc_fn_7dafa2b1_000003_a6773dec+0x90>
  4073ea:	mov    eax,DWORD PTR [rbx]
  4073ec:	add    eax,0x2
  4073ef:	mov    DWORD PTR [rbx],eax
  4073f1:	cmp    eax,0xc
  4073f4:	jle    4073a0 <__swc_fn_7dafa2b1_000003_a6773dec+0x70>
  4073f6:	mov    rcx,rsi
  4073f9:	call   40a6e0 <__swc_fn_7dafa2b1_000001_cb8588f1>
  4073fe:	add    rdi,rax
  407401:	mov    rcx,rsi
  407404:	call   40e9e0 <__swc_fn_7dafa2b1_000002_6e6aee58>
  407409:	call   40a720 <__swc_fn_7dafa2b1_000004_1ca87929>
  40740e:	vsubsd xmm0,xmm0,xmm6
  407412:	vmulsd xmm0,xmm0,QWORD PTR [rip+0xadfe]        # 412218 <__swc_rdata_base_7dafa2b1+0x108>
  40741a:	lea    rax,[rip+0xacef]        # 412110 <__swc_rdata_base_7dafa2b1>
  407421:	sub    rsp,0x88
  407428:	mov    rcx,rsp
  40742b:	vmovups xmm1,XMMWORD PTR [rip+0xadc5]        # 4121f8 <__swc_rdata_base_7dafa2b1+0xe8>
  407433:	vmovups XMMWORD PTR [rcx],xmm1
  407437:	mov    QWORD PTR [rcx+0x30],rsp
  40743b:	lea    rdx,[rip+0xacde]        # 412120 <__swc_rdata_base_7dafa2b1+0x10>
  407442:	mov    QWORD PTR [rcx+0x38],rdx
  407446:	mov    QWORD PTR [rcx+0x10],rdi
  40744a:	lea    r8,[rsp+0x10]
  40744f:	mov    QWORD PTR [rcx+0x40],r8
  407453:	lea    r8,[rip+0xad0e]        # 412168 <__swc_rdata_base_7dafa2b1+0x58>
  40745a:	mov    QWORD PTR [rcx+0x48],r8
  40745e:	vmovups xmm1,XMMWORD PTR [rip+0xada2]        # 412208 <__swc_rdata_base_7dafa2b1+0xf8>
  407466:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40746b:	lea    r8,[rsp+0x18]
  407470:	mov    QWORD PTR [rcx+0x50],r8
  407474:	mov    QWORD PTR [rcx+0x58],rdx
  407478:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40747d:	lea    r8,[rcx+0x28]
  407481:	mov    QWORD PTR [rcx+0x60],r8
  407485:	lea    r8,[rip+0xad24]        # 4121b0 <__swc_rdata_base_7dafa2b1+0xa0>
  40748c:	mov    QWORD PTR [rcx+0x68],r8
  407490:	mov    QWORD PTR [rcx+0x70],rax
  407494:	mov    QWORD PTR [rcx+0x78],rdx
  407498:	lea    rax,[rcx+0x30]
  40749c:	mov    QWORD PTR [rcx+0x80],rax
  4074a3:	mov    QWORD PTR [rcx+0x88],0x5
  4074ae:	lea    rcx,[rcx+0x80]
  4074b5:	sub    rsp,0x8
  4074b9:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  4074be:	add    rsp,0xa8
  4074c5:	vmovups xmm6,XMMWORD PTR [rsp]
  4074ca:	add    rsp,0x10
  4074ce:	pop    r15
  4074d0:	pop    r14
  4074d2:	pop    r13
  4074d4:	pop    r12
  4074d6:	pop    rdi
  4074d7:	pop    rsi
  4074d8:	pop    rbx
  4074d9:	pop    rbp
  4074da:	ret
  4074db:	add    BYTE PTR [rax],al
  4074dd:	add    BYTE PTR [rax],al
	...

00000000004074e0 <__swc_fn_7dafa2b1_000006_9ee35b18>:
  4074e0:	vxorps xmm0,xmm0,xmm0
  4074e4:	xor    eax,eax
  4074e6:	cs nop WORD PTR [rax+rax*1+0x0]
  4074f0:	cs nop WORD PTR [rax+rax*1+0x0]
  4074fa:	nop    WORD PTR [rax+rax*1+0x0]
  407500:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  407505:	add    rax,0x10
  407509:	cmp    rax,0x2080
  407510:	jne    407500 <__swc_fn_7dafa2b1_000006_9ee35b18+0x20>
  407512:	ret
	...

0000000000407520 <__swc_fn_7dafa2b1_000009_d64b2baa>:
  407520:	push   rsi
  407521:	push   rdi
  407522:	push   r12
  407524:	push   r13
  407526:	push   r14
  407528:	mov    rsi,rcx
  40752b:	mov    edi,r10d
  40752e:	mov    r12,rcx
  407531:	mov    r13,r9
  407534:	mov    ecx,DWORD PTR [rdx+0x28]
  407537:	shlx   r14d,r8d,ecx
  40753c:	mov    rcx,rdx
  40753f:	mov    edx,r8d
  407542:	call   40a8e0 <__swc_fn_7dafa2b1_000016_9dea5065>
  407547:	mov    rcx,rax
  40754a:	mov    eax,DWORD PTR [r12+0x3c]
  40754f:	xor    edx,edx
  407551:	div    rdi
  407554:	vxorps xmm0,xmm0,xmm0
  407558:	vmovdqu XMMWORD PTR [rsi],xmm0
  40755c:	mov    QWORD PTR [r12+0x60],0x0
  407565:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40756a:	mov    QWORD PTR [r12+0x10],rcx
  40756f:	imul   rax,rdi
  407573:	lea    rdx,[rcx+rax*1]
  407577:	mov    QWORD PTR [r12+0x18],rdx
  40757c:	mov    QWORD PTR [r12+0x20],rcx
  407581:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  407586:	mov    DWORD PTR [r12+0x28],0x0
  40758f:	mov    DWORD PTR [r12+0x68],0x0
  407598:	mov    BYTE PTR [r12+0x39],r13b
  40759d:	mov    BYTE PTR [r12+0x3a],r14b
  4075a2:	mov    BYTE PTR [r12+0x3b],0x1
  4075a8:	mov    DWORD PTR [r12+0x6c],0x0
  4075b1:	mov    rcx,r12
  4075b4:	mov    edx,edi
  4075b6:	call   40a840 <__swc_fn_7dafa2b1_000010_065ed5b1>
  4075bb:	pop    r14
  4075bd:	pop    r13
  4075bf:	pop    r12
  4075c1:	pop    rdi
  4075c2:	pop    rsi
  4075c3:	ret
	...

00000000004075d0 <__swc_fn_7dafa2b1_000012_c3647f66>:
  4075d0:	mov    r8d,0x1
  4075d6:	xor    eax,eax
  4075d8:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  4075de:	test   eax,eax
  4075e0:	jne    4075d0 <__swc_fn_7dafa2b1_000012_c3647f66>
  4075e2:	ret
	...

00000000004075f0 <__swc_fn_7dafa2b1_000015_524c1f23>:
  4075f0:	lea    r8,[rcx+0x60]
  4075f4:	mov    rax,QWORD PTR [r8]
  4075f7:	mov    r9,rax
  4075fa:	nop    WORD PTR [rax+rax*1+0x0]
  407600:	mov    QWORD PTR [rdx],r9
  407603:	mov    rax,r9
  407606:	lock cmpxchg QWORD PTR [r8],rdx
  40760b:	cmp    rax,r9
  40760e:	jne    407677 <__swc_fn_7dafa2b1_000015_524c1f23+0x87>
  407610:	mov    eax,DWORD PTR [rcx+0x6c]
  407613:	test   eax,eax
  407615:	je     407676 <__swc_fn_7dafa2b1_000015_524c1f23+0x86>
  407617:	lea    rdx,[rcx+0x70]
  40761b:	mov    r9d,0x1
  407621:	xor    eax,eax
  407623:	lock cmpxchg DWORD PTR [rdx],r9d
  407628:	test   eax,eax
  40762a:	jne    407676 <__swc_fn_7dafa2b1_000015_524c1f23+0x86>
  40762c:	mov    rax,rcx
  40762f:	and    rax,0xffffffffffc00000
  407636:	mov    rax,QWORD PTR [rax+0x8]
  40763a:	test   rax,rax
  40763d:	jne    407645 <__swc_fn_7dafa2b1_000015_524c1f23+0x55>
  40763f:	xor    eax,eax
  407641:	xchg   DWORD PTR [rdx],eax
  407643:	jmp    407676 <__swc_fn_7dafa2b1_000015_524c1f23+0x86>
  407645:	lea    rdx,[rax+0x2a80]
  40764c:	mov    rax,QWORD PTR [rdx]
  40764f:	mov    r8,rax
  407652:	cs nop WORD PTR [rax+rax*1+0x0]
  40765c:	nop    DWORD PTR [rax+0x0]
  407660:	mov    QWORD PTR [rcx+0x78],r8
  407664:	mov    rax,r8
  407667:	lock cmpxchg QWORD PTR [rdx],rcx
  40766c:	cmp    rax,r8
  40766f:	je     407676 <__swc_fn_7dafa2b1_000015_524c1f23+0x86>
  407671:	mov    r8,rax
  407674:	jmp    407660 <__swc_fn_7dafa2b1_000015_524c1f23+0x70>
  407676:	ret
  407677:	mov    r9,rax
  40767a:	jmp    407600 <__swc_fn_7dafa2b1_000015_524c1f23+0x10>
	...

0000000000407680 <__swc_fn_7dafa2b1_000018_efc44797>:
  407680:	push   rsi
  407681:	push   rdi
  407682:	push   r12
  407684:	push   r13
  407686:	push   r14
  407688:	push   r15
  40768a:	push   rbx
  40768b:	sub    rsp,0x30
  40768f:	mov    QWORD PTR [rsp+0x18],r8
  407694:	mov    rsi,rcx
  407697:	mov    rdi,rdx
  40769a:	mov    rdx,QWORD PTR [rsi+0x40]
  40769e:	xchg   ax,ax
  4076a0:	mov    rax,rdx
  4076a3:	not    rax
  4076a6:	and    rax,QWORD PTR [rsi+0x20]
  4076aa:	test   rax,rax
  4076ad:	jne    4076c1 <__swc_fn_7dafa2b1_000018_efc44797+0x41>
  4076af:	xor    eax,eax
  4076b1:	add    rsp,0x30
  4076b5:	pop    rbx
  4076b6:	pop    r15
  4076b8:	pop    r14
  4076ba:	pop    r13
  4076bc:	pop    r12
  4076be:	pop    rdi
  4076bf:	pop    rsi
  4076c0:	ret
  4076c1:	xor    ecx,ecx
  4076c3:	tzcnt  rcx,rax
  4076c8:	lea    r12,[rsp+0x8]
  4076cd:	mov    DWORD PTR [rsp+0x8],ecx
  4076d1:	mov    r13d,0x1
  4076d7:	shl    r13,cl
  4076da:	mov    rcx,rdx
  4076dd:	or     rcx,r13
  4076e0:	mov    rax,rdx
  4076e3:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  4076e9:	cmp    rax,rdx
  4076ec:	je     4076f3 <__swc_fn_7dafa2b1_000018_efc44797+0x73>
  4076ee:	mov    rdx,rax
  4076f1:	jmp    4076a0 <__swc_fn_7dafa2b1_000018_efc44797+0x20>
  4076f3:	mov    eax,DWORD PTR [r12]
  4076f7:	shl    rax,0x4
  4076fb:	lea    r14,[rsi+rax*8+0x80]
  407703:	mov    rcx,rsi
  407706:	mov    rax,r12
  407709:	mov    edx,DWORD PTR [rax]
  40770b:	call   40a8e0 <__swc_fn_7dafa2b1_000016_9dea5065>
  407710:	mov    r15,rax
  407713:	mov    rcx,rsi
  407716:	mov    rdx,r13
  407719:	call   40aa40 <__swc_fn_7dafa2b1_000022_fd2b165c>
  40771e:	test   al,al
  407720:	je     407758 <__swc_fn_7dafa2b1_000018_efc44797+0xd8>
  407722:	mov    ecx,DWORD PTR [r14+0x3c]
  407726:	lea    rdx,[rip+0x1b933]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  40772d:	mov    r8,QWORD PTR [rip+0x1b92c]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  407734:	cs nop WORD PTR [rax+rax*1+0x0]
  40773e:	xchg   ax,ax
  407740:	mov    r9,r8
  407743:	sub    r9,rcx
  407746:	mov    rax,r8
  407749:	lock cmpxchg QWORD PTR [rdx],r9
  40774e:	cmp    rax,r8
  407751:	je     4077b9 <__swc_fn_7dafa2b1_000018_efc44797+0x139>
  407753:	mov    r8,rax
  407756:	jmp    407740 <__swc_fn_7dafa2b1_000018_efc44797+0xc0>
  407758:	mov    rcx,rsi
  40775b:	mov    rax,r12
  40775e:	mov    edx,DWORD PTR [rax]
  407760:	call   40ec60 <__swc_fn_7dafa2b1_000017_9afb7cfb>
  407765:	mov    rcx,r15
  407768:	and    rcx,0xffffffffffff0000
  40776f:	lea    rcx,[rcx+0x10000]
  407776:	mov    rbx,rax
  407779:	cmp    rax,rcx
  40777c:	cmova  rbx,rcx
  407780:	mov    rax,rbx
  407783:	sub    rax,r15
  407786:	mov    rcx,r15
  407789:	mov    rdx,rax
  40778c:	call   40eab0 <__swc_fn_7dafa2b1_000008_f7acedb0>
  407791:	test   al,al
  407793:	jne    4077b2 <__swc_fn_7dafa2b1_000018_efc44797+0x132>
  407795:	mov    rcx,rsi
  407798:	mov    rdx,r13
  40779b:	call   40ee10 <__swc_fn_7dafa2b1_000023_c8f5f27c>
  4077a0:	xor    eax,eax
  4077a2:	add    rsp,0x30
  4077a6:	pop    rbx
  4077a7:	pop    r15
  4077a9:	pop    r14
  4077ab:	pop    r13
  4077ad:	pop    r12
  4077af:	pop    rdi
  4077b0:	pop    rsi
  4077b1:	ret
  4077b2:	sub    rbx,r15
  4077b5:	mov    DWORD PTR [r14+0x3c],ebx
  4077b9:	mov    rcx,r14
  4077bc:	mov    rdx,rsi
  4077bf:	mov    r8d,DWORD PTR [r12]
  4077c3:	mov    r9d,edi
  4077c6:	mov    rbx,QWORD PTR [rsp+0x18]
  4077cb:	mov    r10d,ebx
  4077ce:	call   407520 <__swc_fn_7dafa2b1_000009_d64b2baa>
  4077d3:	mov    rax,r14
  4077d6:	add    rsp,0x30
  4077da:	pop    rbx
  4077db:	pop    r15
  4077dd:	pop    r14
  4077df:	pop    r13
  4077e1:	pop    r12
  4077e3:	pop    rdi
  4077e4:	pop    rsi
  4077e5:	ret
	...

00000000004077f0 <__swc_fn_7dafa2b1_000021_de02dbdf>:
  4077f0:	mov    r8,QWORD PTR [rcx+0x48]
  4077f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4077fe:	xchg   ax,ax
  407800:	mov    r9,r8
  407803:	or     r9,rdx
  407806:	mov    rax,r8
  407809:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40780f:	cmp    rax,r8
  407812:	jne    407815 <__swc_fn_7dafa2b1_000021_de02dbdf+0x25>
  407814:	ret
  407815:	mov    r8,rax
  407818:	jmp    407800 <__swc_fn_7dafa2b1_000021_de02dbdf+0x10>
  40781a:	add    BYTE PTR [rax],al
  40781c:	add    BYTE PTR [rax],al
	...

0000000000407820 <__swc_fn_7dafa2b1_000024_2d0fcd2c>:
  407820:	push   rsi
  407821:	push   rdi
  407822:	push   r12
  407824:	mov    rsi,rcx
  407827:	xor    edi,edi
  407829:	lea    r12,[rip+0x1b840]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  407830:	mov    eax,DWORD PTR [r12]
  407834:	xor    ecx,ecx
  407836:	test   rax,rax
  407839:	jbe    407874 <__swc_fn_7dafa2b1_000024_2d0fcd2c+0x54>
  40783b:	nop    DWORD PTR [rax+rax*1+0x0]
  407840:	lea    rdx,[rip+0x1b831]        # 423078 <__swc_bss_base_7dafa2b1+0x38>
  407847:	mov    r8d,ecx
  40784a:	lea    r8,[r8+r8*2]
  40784e:	lea    r8,[rdx+r8*8]
  407852:	mov    rdx,QWORD PTR [r8+0x10]
  407856:	add    rdx,0x400000
  40785d:	cmp    rdx,0x40000000
  407864:	ja     40786b <__swc_fn_7dafa2b1_000024_2d0fcd2c+0x4b>
  407866:	mov    rdi,r8
  407869:	jmp    407874 <__swc_fn_7dafa2b1_000024_2d0fcd2c+0x54>
  40786b:	add    rcx,0x1
  40786f:	cmp    rcx,rax
  407872:	jb     407840 <__swc_fn_7dafa2b1_000024_2d0fcd2c+0x20>
  407874:	test   rdi,rdi
  407877:	jne    407903 <__swc_fn_7dafa2b1_000024_2d0fcd2c+0xe3>
  40787d:	cmp    DWORD PTR [r12],0x10
  407882:	jae    4078eb <__swc_fn_7dafa2b1_000024_2d0fcd2c+0xcb>
  407884:	mov    ecx,0x40400000
  407889:	call   40a800 <__swc_fn_7dafa2b1_000007_81d2e1e9>
  40788e:	test   rax,rax
  407891:	je     4078eb <__swc_fn_7dafa2b1_000024_2d0fcd2c+0xcb>
  407893:	lea    rcx,[rip+0x1b7de]        # 423078 <__swc_bss_base_7dafa2b1+0x38>
  40789a:	mov    edx,DWORD PTR [r12]
  40789e:	lea    rdx,[rdx+rdx*2]
  4078a2:	lea    rdx,[rcx+rdx*8]
  4078a6:	mov    QWORD PTR [rdx],rax
  4078a9:	lea    rax,[rax+0x3fffff]
  4078b0:	and    rax,0xffffffffffc00000
  4078b7:	mov    QWORD PTR [rdx+0x8],rax
  4078bb:	mov    QWORD PTR [rdx+0x10],0x0
  4078c3:	mov    edx,DWORD PTR [rip+0x1b7a7]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  4078c9:	nop    DWORD PTR [rax+0x0]
  4078d0:	lea    r9d,[rdx+0x1]
  4078d4:	mov    rax,rdx
  4078d7:	lock cmpxchg DWORD PTR [r12],r9d
  4078dd:	mov    r8d,eax
  4078e0:	cmp    eax,edx
  4078e2:	je     4078f2 <__swc_fn_7dafa2b1_000024_2d0fcd2c+0xd2>
  4078e4:	mov    rdx,r8
  4078e7:	jmp    4078d0 <__swc_fn_7dafa2b1_000024_2d0fcd2c+0xb0>
  4078e9:	jmp    4078f2 <__swc_fn_7dafa2b1_000024_2d0fcd2c+0xd2>
  4078eb:	xor    eax,eax
  4078ed:	pop    r12
  4078ef:	pop    rdi
  4078f0:	pop    rsi
  4078f1:	ret
  4078f2:	mov    eax,DWORD PTR [rip+0x1b778]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  4078f8:	sub    eax,0x1
  4078fb:	lea    rdi,[rax+rax*2]
  4078ff:	lea    rdi,[rcx+rdi*8]
  407903:	mov    r12,QWORD PTR [rdi+0x8]
  407907:	add    r12,QWORD PTR [rdi+0x10]
  40790b:	mov    rcx,r12
  40790e:	mov    edx,0x3000
  407913:	call   40eab0 <__swc_fn_7dafa2b1_000008_f7acedb0>
  407918:	test   al,al
  40791a:	jne    407923 <__swc_fn_7dafa2b1_000024_2d0fcd2c+0x103>
  40791c:	xor    eax,eax
  40791e:	pop    r12
  407920:	pop    rdi
  407921:	pop    rsi
  407922:	ret
  407923:	vxorps xmm0,xmm0,xmm0
  407927:	xor    eax,eax
  407929:	cs nop WORD PTR [rax+rax*1+0x0]
  407933:	cs nop WORD PTR [rax+rax*1+0x0]
  40793d:	nop    DWORD PTR [rax]
  407940:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  407946:	add    rax,0x10
  40794a:	cmp    rax,0x3000
  407951:	jne    407940 <__swc_fn_7dafa2b1_000024_2d0fcd2c+0x120>
  407953:	mov    DWORD PTR [r12+0x28],esi
  407958:	mov    eax,0x40
  40795d:	mov    ecx,esi
  40795f:	shr    eax,cl
  407961:	mov    DWORD PTR [r12+0x2c],eax
  407966:	cmp    DWORD PTR [r12+0x2c],0x40
  40796c:	jb     407977 <__swc_fn_7dafa2b1_000024_2d0fcd2c+0x157>
  40796e:	mov    rax,0xffffffffffffffff
  407975:	jmp    407987 <__swc_fn_7dafa2b1_000024_2d0fcd2c+0x167>
  407977:	mov    eax,0x1
  40797c:	mov    ecx,DWORD PTR [r12+0x2c]
  407981:	shl    rax,cl
  407984:	dec    rax
  407987:	mov    QWORD PTR [r12+0x20],rax
  40798c:	mov    DWORD PTR [r12],0x4e540001
  407994:	mov    DWORD PTR [r12+0x4],0x53474d45
  40799d:	add    QWORD PTR [rdi+0x10],0x400000
  4079a5:	mov    rax,r12
  4079a8:	pop    r12
  4079aa:	pop    rdi
  4079ab:	pop    rsi
  4079ac:	ret
  4079ad:	add    BYTE PTR [rax],al
	...

00000000004079b0 <__swc_fn_7dafa2b1_000027_bcdc5519>:
  4079b0:	mov    eax,0x1
  4079b5:	mov    edx,DWORD PTR [rip+0x1b6b5]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  4079bb:	cmp    eax,edx
  4079bd:	jae    407a0b <__swc_fn_7dafa2b1_000027_bcdc5519+0x5b>
  4079bf:	nop
  4079c0:	lea    r8,[rip+0x1b6b1]        # 423078 <__swc_bss_base_7dafa2b1+0x38>
  4079c7:	lea    r9,[rax+rax*2]
  4079cb:	lea    r9,[r8+r9*8]
  4079cf:	mov    r8,rcx
  4079d2:	sub    r8,QWORD PTR [r9+0x8]
  4079d6:	mov    r9,QWORD PTR [r9+0x10]
  4079da:	cmp    r8,r9
  4079dd:	jae    407a05 <__swc_fn_7dafa2b1_000027_bcdc5519+0x55>
  4079df:	mov    rax,rcx
  4079e2:	and    rax,0xffffffffffc00000
  4079e9:	shr    rcx,0x10
  4079ed:	and    ecx,0x3f
  4079f0:	mov    edx,DWORD PTR [rax+0x28]
  4079f3:	shrx   ecx,ecx,edx
  4079f8:	shl    rcx,0x4
  4079fc:	lea    rax,[rax+rcx*8+0x80]
  407a04:	ret
  407a05:	inc    eax
  407a07:	cmp    eax,edx
  407a09:	jb     4079c0 <__swc_fn_7dafa2b1_000027_bcdc5519+0x10>
  407a0b:	xor    eax,eax
  407a0d:	ret
	...

0000000000407a10 <__swc_fn_7dafa2b1_000030_9798fb47>:
  407a10:	vxorps xmm0,xmm0,xmm0
  407a14:	vmovups XMMWORD PTR [rcx],xmm0
  407a18:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  407a1d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407a22:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407a27:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  407a2c:	mov    QWORD PTR [rcx+0x50],0x0
  407a34:	ret
	...

0000000000407a40 <__swc_fn_7dafa2b1_000033_9798fb47>:
  407a40:	vxorps xmm0,xmm0,xmm0
  407a44:	xor    eax,eax
  407a46:	cs nop WORD PTR [rax+rax*1+0x0]
  407a50:	cs nop WORD PTR [rax+rax*1+0x0]
  407a5a:	nop    WORD PTR [rax+rax*1+0x0]
  407a60:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  407a65:	add    rax,0x10
  407a69:	cmp    rax,0x9b0
  407a70:	jne    407a60 <__swc_fn_7dafa2b1_000033_9798fb47+0x20>
  407a72:	mov    QWORD PTR [rcx+0x9b0],0x0
  407a7d:	ret
	...

0000000000407a80 <__swc_fn_7dafa2b1_000036_cd1a4e8c>:
  407a80:	push   rsi
  407a81:	push   rdi
  407a82:	sub    rsp,0x8
  407a86:	lea    rsi,[rip+0x1957b]        # 421008 <__swc_data_base_7dafa2b1+0x8>
  407a8d:	mov    rax,QWORD PTR [rsi]
  407a90:	mov    ecx,0xffffffff
  407a95:	cmp    rax,rcx
  407a98:	je     407aa1 <__swc_fn_7dafa2b1_000036_cd1a4e8c+0x21>
  407a9a:	add    rsp,0x8
  407a9e:	pop    rdi
  407a9f:	pop    rsi
  407aa0:	ret
  407aa1:	mov    rcx,QWORD PTR [rip+0xa560]        # 412008 <__swc_fn_7dafa2b1_000179_718d7b54+0x538>
  407aa8:	call   410e50 <__swc_fn_7dafa2b1_000131_4a82cdf6>
  407aad:	mov    rcx,rax
  407ab0:	mov    eax,0xffffffff
  407ab5:	lock cmpxchg QWORD PTR [rsi],rcx
  407aba:	mov    rdi,rax
  407abd:	mov    eax,0xffffffff
  407ac2:	cmp    rdi,rax
  407ac5:	je     407ad6 <__swc_fn_7dafa2b1_000036_cd1a4e8c+0x56>
  407ac7:	call   409cb0 <__swc_fn_7dafa2b1_000132_a611b8c4>
  407acc:	mov    rax,rdi
  407acf:	add    rsp,0x8
  407ad3:	pop    rdi
  407ad4:	pop    rsi
  407ad5:	ret
  407ad6:	mov    rax,rcx
  407ad9:	add    rsp,0x8
  407add:	pop    rdi
  407ade:	pop    rsi
  407adf:	ret

0000000000407ae0 <__swc_fn_7dafa2b1_000039_14f56618>:
  407ae0:	sub    rsp,0x8
  407ae4:	vxorps xmm0,xmm0,xmm0
  407ae8:	xor    eax,eax
  407aea:	cs nop WORD PTR [rax+rax*1+0x0]
  407af4:	cs nop WORD PTR [rax+rax*1+0x0]
  407afe:	xchg   ax,ax
  407b00:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  407b05:	add    rax,0x10
  407b09:	cmp    rax,0x2b00
  407b10:	jne    407b00 <__swc_fn_7dafa2b1_000039_14f56618+0x20>
  407b12:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  407b1c:	xor    al,al
  407b1e:	mov    rdx,rax
  407b21:	xor    al,al
  407b23:	mov    r8,rax
  407b26:	xor    al,al
  407b28:	mov    r9,rax
  407b2b:	xor    al,al
  407b2d:	mov    r10,rax
  407b30:	xor    al,al
  407b32:	mov    r11,rax
  407b35:	call   40ac70 <__swc_fn_7dafa2b1_000040_03f1bf9a>
  407b3a:	add    rsp,0x8
  407b3e:	ret
	...

0000000000407b40 <__swc_fn_7dafa2b1_000042_c90d80c1>:
  407b40:	push   rsi
  407b41:	push   rdi
  407b42:	push   r12
  407b44:	mov    rsi,r8
  407b47:	mov    rdi,rdx
  407b4a:	mov    rcx,rdx
  407b4d:	call   40a800 <__swc_fn_7dafa2b1_000007_81d2e1e9>
  407b52:	mov    r12,rax
  407b55:	test   rax,rax
  407b58:	jne    407b61 <__swc_fn_7dafa2b1_000042_c90d80c1+0x21>
  407b5a:	xor    eax,eax
  407b5c:	pop    r12
  407b5e:	pop    rdi
  407b5f:	pop    rsi
  407b60:	ret
  407b61:	mov    rcx,r12
  407b64:	mov    rdx,rsi
  407b67:	call   40eab0 <__swc_fn_7dafa2b1_000008_f7acedb0>
  407b6c:	test   al,al
  407b6e:	jne    407b82 <__swc_fn_7dafa2b1_000042_c90d80c1+0x42>
  407b70:	mov    rcx,r12
  407b73:	mov    rdx,rdi
  407b76:	call   40ca70 <__swc_fn_7dafa2b1_000118_ed2d8fed>
  407b7b:	xor    eax,eax
  407b7d:	pop    r12
  407b7f:	pop    rdi
  407b80:	pop    rsi
  407b81:	ret
  407b82:	mov    rax,r12
  407b85:	pop    r12
  407b87:	pop    rdi
  407b88:	pop    rsi
  407b89:	ret
	...

0000000000407ba0 <__swc_fn_7dafa2b1_000045_a78ae66b>:
  407ba0:	push   rsi
  407ba1:	push   rdi
  407ba2:	push   r12
  407ba4:	mov    rsi,rcx
  407ba7:	mov    edx,0x9b8
  407bac:	call   40ace0 <__swc_fn_7dafa2b1_000043_facd3e17>
  407bb1:	mov    rdi,rax
  407bb4:	test   rax,rax
  407bb7:	jne    407bc0 <__swc_fn_7dafa2b1_000045_a78ae66b+0x20>
  407bb9:	xor    eax,eax
  407bbb:	pop    r12
  407bbd:	pop    rdi
  407bbe:	pop    rsi
  407bbf:	ret
  407bc0:	vxorps xmm0,xmm0,xmm0
  407bc4:	xor    eax,eax
  407bc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407bd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407bda:	nop    WORD PTR [rax+rax*1+0x0]
  407be0:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  407be5:	add    rax,0x10
  407be9:	cmp    rax,0x9b0
  407bf0:	jne    407be0 <__swc_fn_7dafa2b1_000045_a78ae66b+0x40>
  407bf2:	mov    QWORD PTR [rdi+0x9b0],0x0
  407bfd:	mov    QWORD PTR [rdi],rsi
  407c00:	call   409d60 <__swc_fn_7dafa2b1_000135_a9c1c700>
  407c05:	mov    QWORD PTR [rdi+0x18],rax
  407c09:	lea    r12,[rsi+0x10]
  407c0d:	mov    rcx,r12
  407c10:	call   4110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>
  407c15:	mov    rax,QWORD PTR [rsi+0x20]
  407c19:	mov    QWORD PTR [rdi+0x8],rax
  407c1d:	mov    rax,QWORD PTR [rsi+0x20]
  407c21:	test   rax,rax
  407c24:	je     407c2a <__swc_fn_7dafa2b1_000045_a78ae66b+0x8a>
  407c26:	mov    QWORD PTR [rax+0x10],rdi
  407c2a:	mov    QWORD PTR [rsi+0x20],rdi
  407c2e:	mov    rcx,r12
  407c31:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  407c36:	mov    rax,rdi
  407c39:	pop    r12
  407c3b:	pop    rdi
  407c3c:	pop    rsi
  407c3d:	ret
	...

0000000000407c40 <__swc_fn_7dafa2b1_000048_6e7a8d58>:
  407c40:	mov    rax,QWORD PTR [rdx+0x10]
  407c44:	test   rax,rax
  407c47:	je     407c53 <__swc_fn_7dafa2b1_000048_6e7a8d58+0x13>
  407c49:	mov    rcx,QWORD PTR [rdx+0x8]
  407c4d:	mov    QWORD PTR [rax+0x8],rcx
  407c51:	jmp    407c5b <__swc_fn_7dafa2b1_000048_6e7a8d58+0x1b>
  407c53:	mov    rax,QWORD PTR [rdx+0x8]
  407c57:	mov    QWORD PTR [rcx+0x20],rax
  407c5b:	mov    rax,QWORD PTR [rdx+0x8]
  407c5f:	test   rax,rax
  407c62:	je     407c6c <__swc_fn_7dafa2b1_000048_6e7a8d58+0x2c>
  407c64:	mov    rcx,QWORD PTR [rdx+0x10]
  407c68:	mov    QWORD PTR [rax+0x10],rcx
  407c6c:	vxorps xmm0,xmm0,xmm0
  407c70:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  407c75:	ret
	...

0000000000407c80 <__swc_fn_7dafa2b1_000051_129b9bf4>:
  407c80:	sub    rsp,0x8
  407c84:	mov    r9,r8
  407c87:	mov    r10,rdx
  407c8a:	call   40ad90 <__swc_fn_7dafa2b1_000049_137687bb>
  407c8f:	mov    eax,0x1
  407c94:	xchg   DWORD PTR [r9+0x6c],eax
  407c98:	mov    rax,QWORD PTR [r9+0x60]
  407c9c:	test   rax,rax
  407c9f:	je     407ce3 <__swc_fn_7dafa2b1_000051_129b9bf4+0x63>
  407ca1:	xor    eax,eax
  407ca3:	xchg   DWORD PTR [r9+0x6c],eax
  407ca7:	movzx  eax,BYTE PTR [r9+0x39]
  407cac:	lea    rax,[rax+rax*4]
  407cb0:	lea    rax,[r10+rax*8+0x28]
  407cb5:	mov    QWORD PTR [r9+0x50],0x0
  407cbd:	mov    rcx,QWORD PTR [rax+0x8]
  407cc1:	mov    QWORD PTR [r9+0x48],rcx
  407cc5:	mov    rcx,QWORD PTR [rax+0x8]
  407cc9:	test   rcx,rcx
  407ccc:	je     407cd4 <__swc_fn_7dafa2b1_000051_129b9bf4+0x54>
  407cce:	mov    QWORD PTR [rcx+0x50],r9
  407cd2:	jmp    407cd8 <__swc_fn_7dafa2b1_000051_129b9bf4+0x58>
  407cd4:	mov    QWORD PTR [rax+0x10],r9
  407cd8:	mov    QWORD PTR [rax+0x8],r9
  407cdc:	xor    eax,eax
  407cde:	add    rsp,0x8
  407ce2:	ret
  407ce3:	movzx  eax,BYTE PTR [r9+0x39]
  407ce8:	lea    rax,[rax+rax*4]
  407cec:	lea    rax,[r10+rax*8+0x28]
  407cf1:	mov    QWORD PTR [r9+0x50],0x0
  407cf9:	mov    rcx,QWORD PTR [rax+0x18]
  407cfd:	mov    QWORD PTR [r9+0x48],rcx
  407d01:	mov    rcx,QWORD PTR [rax+0x18]
  407d05:	test   rcx,rcx
  407d08:	je     407d0e <__swc_fn_7dafa2b1_000051_129b9bf4+0x8e>
  407d0a:	mov    QWORD PTR [rcx+0x50],r9
  407d0e:	mov    QWORD PTR [rax+0x18],r9
  407d12:	mov    eax,0x1
  407d17:	add    rsp,0x8
  407d1b:	ret
  407d1c:	add    BYTE PTR [rax],al
	...

0000000000407d20 <__swc_fn_7dafa2b1_000054_3af34d7f>:
  407d20:	push   r12
  407d22:	push   r13
  407d24:	push   rdi
  407d25:	push   rsi
  407d26:	push   r14
  407d28:	push   r15
  407d2a:	sub    rsp,0x178
  407d31:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  407d3a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  407d43:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  407d4c:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  407d55:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  407d5e:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  407d67:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  407d70:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  407d79:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  407d82:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  407d8b:	mov    r12,rcx
  407d8e:	lea    rax,[rip+0x1b473]        # 423208 <__swc_bss_base_7dafa2b1+0x1c8>
  407d95:	mov    rcx,QWORD PTR [rax]
  407d98:	mov    r13,rcx
  407d9b:	test   rcx,rcx
  407d9e:	jne    407dae <__swc_fn_7dafa2b1_000054_3af34d7f+0x8e>
  407da0:	mov    r13d,0x1dcd6500
  407da6:	mov    ecx,0x1dcd6500
  407dab:	xchg   QWORD PTR [rax],rcx
  407dae:	lea    rax,[rip+0x1924b]        # 421000 <__swc_data_base_7dafa2b1>
  407db5:	mov    rax,QWORD PTR [rax]
  407db8:	cmp    rax,0xffffffffffffffff
  407dbc:	je     407dcb <__swc_fn_7dafa2b1_000054_3af34d7f+0xab>
  407dbe:	mov    eax,eax
  407dc0:	mov    edi,eax
  407dc2:	xor    eax,eax
  407dc4:	call   407000 <pthread_getspecific@plt>
  407dc9:	jmp    407dcd <__swc_fn_7dafa2b1_000054_3af34d7f+0xad>
  407dcb:	xor    eax,eax
  407dcd:	test   rax,rax
  407dd0:	jne    407ddf <__swc_fn_7dafa2b1_000054_3af34d7f+0xbf>
  407dd2:	call   407a80 <__swc_fn_7dafa2b1_000036_cd1a4e8c>
  407dd7:	mov    rcx,rax
  407dda:	call   40cdc0 <__swc_fn_7dafa2b1_000133_5f757033>
  407ddf:	test   rax,rax
  407de2:	je     407df4 <__swc_fn_7dafa2b1_000054_3af34d7f+0xd4>
  407de4:	cmp    QWORD PTR [rax],r12
  407de7:	jne    407df4 <__swc_fn_7dafa2b1_000054_3af34d7f+0xd4>
  407de9:	cmp    DWORD PTR [rax+0x20],0x0
  407ded:	jne    407df4 <__swc_fn_7dafa2b1_000054_3af34d7f+0xd4>
  407def:	mov    rsi,rax
  407df2:	jmp    407df6 <__swc_fn_7dafa2b1_000054_3af34d7f+0xd6>
  407df4:	xor    esi,esi
  407df6:	lea    rdi,[r12+0x2a88]
  407dfe:	mov    r14,QWORD PTR [rdi]
  407e01:	test   r14,r14
  407e04:	jne    407e53 <__swc_fn_7dafa2b1_000054_3af34d7f+0x133>
  407e06:	lea    rax,[rip+0x1b253]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  407e0d:	mov    rax,QWORD PTR [rax]
  407e10:	test   rax,rax
  407e13:	setne  al
  407e16:	jne    407e3a <__swc_fn_7dafa2b1_000054_3af34d7f+0x11a>
  407e18:	mov    rax,QWORD PTR [r12+0x2a70]
  407e20:	test   rax,rax
  407e23:	setne  al
  407e26:	jne    407e3a <__swc_fn_7dafa2b1_000054_3af34d7f+0x11a>
  407e28:	test   rsi,rsi
  407e2b:	setne  al
  407e2e:	je     407e3a <__swc_fn_7dafa2b1_000054_3af34d7f+0x11a>
  407e30:	cmp    DWORD PTR [rsi+0x730],0x0
  407e37:	setne  al
  407e3a:	test   al,al
  407e3c:	je     407e4e <__swc_fn_7dafa2b1_000054_3af34d7f+0x12e>
  407e3e:	call   40ce70 <__swc_fn_7dafa2b1_000136_07d76562>
  407e43:	lea    rcx,[rax+r13*1]
  407e47:	xor    eax,eax
  407e49:	lock cmpxchg QWORD PTR [rdi],rcx
  407e4e:	jmp    407f53 <__swc_fn_7dafa2b1_000054_3af34d7f+0x233>
  407e53:	call   40ce70 <__swc_fn_7dafa2b1_000136_07d76562>
  407e58:	mov    r15,rax
  407e5b:	cmp    rax,r14
  407e5e:	jb     407e6f <__swc_fn_7dafa2b1_000054_3af34d7f+0x14f>
  407e60:	xor    ecx,ecx
  407e62:	mov    rax,r14
  407e65:	lock cmpxchg QWORD PTR [rdi],rcx
  407e6a:	cmp    rax,r14
  407e6d:	je     407e74 <__swc_fn_7dafa2b1_000054_3af34d7f+0x154>
  407e6f:	jmp    407f53 <__swc_fn_7dafa2b1_000054_3af34d7f+0x233>
  407e74:	test   rsi,rsi
  407e77:	je     407e92 <__swc_fn_7dafa2b1_000054_3af34d7f+0x172>
  407e79:	cmp    r15,r13
  407e7c:	jb     407e92 <__swc_fn_7dafa2b1_000054_3af34d7f+0x172>
  407e7e:	mov    rax,r15
  407e81:	sub    rax,r13
  407e84:	mov    rcx,r12
  407e87:	mov    rdx,rsi
  407e8a:	mov    r8,rax
  407e8d:	call   40b1d0 <__swc_fn_7dafa2b1_000064_dea90857>
  407e92:	lea    rsi,[r12+0x10]
  407e97:	mov    rcx,rsi
  407e9a:	call   4110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>
  407e9f:	mov    rax,QWORD PTR [r12+0x18]
  407ea4:	mov    rdi,rax
  407ea7:	test   rdi,rdi
  407eaa:	je     407ed4 <__swc_fn_7dafa2b1_000054_3af34d7f+0x1b4>
  407eac:	cs nop WORD PTR [rax+rax*1+0x0]
  407eb6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ec0:	mov    rcx,rdi
  407ec3:	call   40ec80 <__swc_fn_7dafa2b1_000020_adca76cf>
  407ec8:	mov    rax,QWORD PTR [rdi+0x10]
  407ecc:	mov    rdi,rax
  407ecf:	test   rax,rax
  407ed2:	jne    407ec0 <__swc_fn_7dafa2b1_000054_3af34d7f+0x1a0>
  407ed4:	mov    rcx,rsi
  407ed7:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  407edc:	mov    rcx,r12
  407edf:	call   4110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>
  407ee4:	xor    esi,esi
  407ee6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ef0:	mov    rax,QWORD PTR [r12+0x2a70]
  407ef8:	cmp    rsi,rax
  407efb:	jae    407f4b <__swc_fn_7dafa2b1_000054_3af34d7f+0x22b>
  407efd:	lea    rax,[rsi+rsi*4]
  407f01:	lea    rax,[r12+rax*8+0x268]
  407f09:	mov    r8,QWORD PTR [rax]
  407f0c:	mov    r9,QWORD PTR [rax+0x8]
  407f10:	mov    r10,QWORD PTR [rax+0x10]
  407f14:	mov    rax,QWORD PTR [rax+0x20]
  407f18:	cmp    rax,r15
  407f1b:	jae    407f28 <__swc_fn_7dafa2b1_000054_3af34d7f+0x208>
  407f1d:	mov    rcx,r15
  407f20:	sub    rcx,rax
  407f23:	cmp    rcx,r13
  407f26:	jae    407f2d <__swc_fn_7dafa2b1_000054_3af34d7f+0x20d>
  407f28:	inc    rsi
  407f2b:	jmp    407ef0 <__swc_fn_7dafa2b1_000054_3af34d7f+0x1d0>
  407f2d:	mov    rcx,r12
  407f30:	mov    rdx,rsi
  407f33:	call   40b180 <__swc_fn_7dafa2b1_000061_15c28ca7>
  407f38:	mov    rcx,r12
  407f3b:	mov    rdx,r8
  407f3e:	mov    r8,r9
  407f41:	mov    r9,r10
  407f44:	call   40ef60 <__swc_fn_7dafa2b1_000044_d3c2ab54>
  407f49:	jmp    407ef0 <__swc_fn_7dafa2b1_000054_3af34d7f+0x1d0>
  407f4b:	mov    rcx,r12
  407f4e:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  407f53:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  407f5c:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  407f65:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  407f6e:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  407f77:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  407f80:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  407f89:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  407f92:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  407f9b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  407fa4:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  407fad:	add    rsp,0x178
  407fb4:	pop    r15
  407fb6:	pop    r14
  407fb8:	pop    rsi
  407fb9:	pop    rdi
  407fba:	pop    r13
  407fbc:	pop    r12
  407fbe:	ret
	...

0000000000407fc0 <__swc_fn_7dafa2b1_000057_df0696cd>:
  407fc0:	lea    rax,[rdx-0x58]
  407fc4:	ret
	...

0000000000407fd0 <__swc_fn_7dafa2b1_000060_2ca0cb05>:
  407fd0:	push   rsi
  407fd1:	push   rdi
  407fd2:	push   r12
  407fd4:	push   r13
  407fd6:	sub    rsp,0x68
  407fda:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  407fe0:	mov    rsi,r9
  407fe3:	mov    rdi,rcx
  407fe6:	mov    r12,rdx
  407fe9:	mov    r13,r8
  407fec:	cmp    QWORD PTR [rdi+0x2a70],0x0
  407ff4:	jne    408003 <__swc_fn_7dafa2b1_000060_2ca0cb05+0x33>
  407ff6:	xor    eax,eax
  407ff8:	add    rsp,0x68
  407ffc:	pop    r13
  407ffe:	pop    r12
  408000:	pop    rdi
  408001:	pop    rsi
  408002:	ret
  408003:	mov    rcx,rdi
  408006:	call   4110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>
  40800b:	movabs rax,0x7fffffffffffffff
  408015:	cmp    r12,rax
  408018:	mov    rax,0xffffffffffffffff
  40801f:	lea    rcx,[r12+r12*1]
  408023:	cmovbe rax,rcx
  408027:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40802e:	mov    rdx,rcx
  408031:	sub    rax,r12
  408034:	inc    rax
  408037:	xor    r8d,r8d
  40803a:	test   rcx,rcx
  40803d:	jbe    408068 <__swc_fn_7dafa2b1_000060_2ca0cb05+0x98>
  40803f:	nop
  408040:	lea    r9,[r8+r8*4]
  408044:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40804c:	sub    r9,r12
  40804f:	cmp    r9,rax
  408052:	jae    40805f <__swc_fn_7dafa2b1_000060_2ca0cb05+0x8f>
  408054:	mov    rdx,r8
  408057:	mov    rax,r9
  40805a:	test   r9,r9
  40805d:	je     408068 <__swc_fn_7dafa2b1_000060_2ca0cb05+0x98>
  40805f:	add    r8,0x1
  408063:	cmp    r8,rcx
  408066:	jb     408040 <__swc_fn_7dafa2b1_000060_2ca0cb05+0x70>
  408068:	mov    rax,QWORD PTR [rdi+0x2a70]
  40806f:	cmp    rdx,rax
  408072:	jne    40808f <__swc_fn_7dafa2b1_000060_2ca0cb05+0xbf>
  408074:	mov    rcx,rdi
  408077:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40807c:	xor    eax,eax
  40807e:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  408084:	add    rsp,0x68
  408088:	pop    r13
  40808a:	pop    r12
  40808c:	pop    rdi
  40808d:	pop    rsi
  40808e:	ret
  40808f:	lea    rax,[rdx+rdx*4]
  408093:	lea    rax,[rdi+rax*8+0x268]
  40809b:	vmovups xmm6,XMMWORD PTR [rax]
  40809f:	mov    r8,QWORD PTR [rax+0x10]
  4080a3:	mov    rcx,rdi
  4080a6:	call   40b180 <__swc_fn_7dafa2b1_000061_15c28ca7>
  4080ab:	vpshufd xmm0,xmm6,0xee
  4080b0:	vmovsd QWORD PTR [r13+0x0],xmm0
  4080b6:	mov    QWORD PTR [rsi],r8
  4080b9:	mov    rcx,rdi
  4080bc:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  4080c1:	vmovq  rax,xmm6
  4080c6:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  4080cc:	add    rsp,0x68
  4080d0:	pop    r13
  4080d2:	pop    r12
  4080d4:	pop    rdi
  4080d5:	pop    rsi
  4080d6:	ret
	...

00000000004080e0 <__swc_fn_7dafa2b1_000063_b304235a>:
  4080e0:	push   r12
  4080e2:	push   r13
  4080e4:	push   r14
  4080e6:	push   r15
  4080e8:	push   rdi
  4080e9:	push   rsi
  4080ea:	sub    rsp,0x148
  4080f1:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  4080fa:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  408103:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40810c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  408115:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40811e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  408127:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  408130:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  408139:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  408142:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40814b:	mov    r12,r9
  40814e:	mov    r13,rcx
  408151:	mov    r14,rdx
  408154:	mov    r15,r8
  408157:	test   rdx,rdx
  40815a:	jne    40816e <__swc_fn_7dafa2b1_000063_b304235a+0x8e>
  40815c:	add    rsp,0x148
  408163:	pop    rsi
  408164:	pop    rdi
  408165:	pop    r15
  408167:	pop    r14
  408169:	pop    r13
  40816b:	pop    r12
  40816d:	ret
  40816e:	cmp    r12,0x200000
  408175:	ja     408207 <__swc_fn_7dafa2b1_000063_b304235a+0x127>
  40817b:	lea    rax,[rip+0x18e7e]        # 421000 <__swc_data_base_7dafa2b1>
  408182:	mov    rax,QWORD PTR [rax]
  408185:	cmp    rax,0xffffffffffffffff
  408189:	je     408198 <__swc_fn_7dafa2b1_000063_b304235a+0xb8>
  40818b:	mov    eax,eax
  40818d:	mov    edi,eax
  40818f:	xor    eax,eax
  408191:	call   407000 <pthread_getspecific@plt>
  408196:	jmp    40819a <__swc_fn_7dafa2b1_000063_b304235a+0xba>
  408198:	xor    eax,eax
  40819a:	test   rax,rax
  40819d:	je     4081a4 <__swc_fn_7dafa2b1_000063_b304235a+0xc4>
  40819f:	mov    rsi,rax
  4081a2:	jmp    4081b4 <__swc_fn_7dafa2b1_000063_b304235a+0xd4>
  4081a4:	call   407a80 <__swc_fn_7dafa2b1_000036_cd1a4e8c>
  4081a9:	mov    rcx,rax
  4081ac:	call   40cdc0 <__swc_fn_7dafa2b1_000133_5f757033>
  4081b1:	mov    rsi,rax
  4081b4:	test   rsi,rsi
  4081b7:	je     408207 <__swc_fn_7dafa2b1_000063_b304235a+0x127>
  4081b9:	cmp    QWORD PTR [rsi],r13
  4081bc:	jne    408207 <__swc_fn_7dafa2b1_000063_b304235a+0x127>
  4081be:	cmp    DWORD PTR [rsi+0x20],0x0
  4081c2:	jne    408207 <__swc_fn_7dafa2b1_000063_b304235a+0x127>
  4081c4:	cmp    DWORD PTR [rsi+0x730],0x10
  4081cb:	jae    408207 <__swc_fn_7dafa2b1_000063_b304235a+0x127>
  4081cd:	mov    eax,DWORD PTR [rsi+0x730]
  4081d3:	lea    rdi,[rax+rax*4]
  4081d7:	lea    rdi,[rsi+rdi*8+0x738]
  4081df:	mov    QWORD PTR [rdi],r14
  4081e2:	mov    QWORD PTR [rdi+0x8],r15
  4081e6:	mov    QWORD PTR [rdi+0x10],r12
  4081ea:	mov    QWORD PTR [rdi+0x18],0x0
  4081f2:	call   40ce70 <__swc_fn_7dafa2b1_000136_07d76562>
  4081f7:	mov    QWORD PTR [rdi+0x20],rax
  4081fb:	add    DWORD PTR [rsi+0x730],0x1
  408202:	jmp    408366 <__swc_fn_7dafa2b1_000063_b304235a+0x286>
  408207:	mov    rcx,r13
  40820a:	call   40f690 <__swc_fn_7dafa2b1_000062_ad030a10>
  40820f:	mov    rsi,rax
  408212:	cmp    r12,rax
  408215:	jbe    40824a <__swc_fn_7dafa2b1_000063_b304235a+0x16a>
  408217:	cmp    r12,0x10000000
  40821e:	seta   al
  408221:	ja     408230 <__swc_fn_7dafa2b1_000063_b304235a+0x150>
  408223:	mov    rax,QWORD PTR [r13+0x2a70]
  40822a:	test   rax,rax
  40822d:	setne  al
  408230:	test   al,al
  408232:	je     40824a <__swc_fn_7dafa2b1_000063_b304235a+0x16a>
  408234:	mov    rcx,r13
  408237:	mov    rdx,r14
  40823a:	mov    r8,r15
  40823d:	mov    r9,r12
  408240:	call   40ef60 <__swc_fn_7dafa2b1_000044_d3c2ab54>
  408245:	jmp    408366 <__swc_fn_7dafa2b1_000063_b304235a+0x286>
  40824a:	call   40ce70 <__swc_fn_7dafa2b1_000136_07d76562>
  40824f:	mov    rdi,rax
  408252:	mov    rcx,r13
  408255:	call   4110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>
  40825a:	cmp    QWORD PTR [r13+0x2a70],0x0
  408262:	je     40831a <__swc_fn_7dafa2b1_000063_b304235a+0x23a>
  408268:	nop    DWORD PTR [rax+rax*1+0x0]
  408270:	cmp    QWORD PTR [r13+0x2a70],0x100
  40827b:	jae    408290 <__swc_fn_7dafa2b1_000063_b304235a+0x1b0>
  40827d:	mov    rax,QWORD PTR [r13+0x2a68]
  408284:	add    rax,r12
  408287:	cmp    rax,rsi
  40828a:	jbe    40831a <__swc_fn_7dafa2b1_000063_b304235a+0x23a>
  408290:	xor    eax,eax
  408292:	mov    rcx,QWORD PTR [r13+0x2a70]
  408299:	mov    edx,0x1
  40829e:	cmp    rcx,0x1
  4082a2:	jbe    4082d9 <__swc_fn_7dafa2b1_000063_b304235a+0x1f9>
  4082a4:	cs nop WORD PTR [rax+rax*1+0x0]
  4082ae:	xchg   ax,ax
  4082b0:	lea    r8,[rdx+rdx*4]
  4082b4:	lea    r8,[r13+r8*8+0x268]
  4082bc:	lea    r9,[rax+rax*4]
  4082c0:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  4082c8:	cmp    QWORD PTR [r8+0x18],r9
  4082cc:	cmovb  rax,rdx
  4082d0:	add    rdx,0x1
  4082d4:	cmp    rdx,rcx
  4082d7:	jb     4082b0 <__swc_fn_7dafa2b1_000063_b304235a+0x1d0>
  4082d9:	lea    rcx,[rax+rax*4]
  4082dd:	lea    rcx,[r13+rcx*8+0x268]
  4082e5:	mov    r8,QWORD PTR [rcx]
  4082e8:	mov    r9,QWORD PTR [rcx+0x8]
  4082ec:	mov    r10,QWORD PTR [rcx+0x10]
  4082f0:	mov    rcx,r13
  4082f3:	mov    rdx,rax
  4082f6:	call   40b180 <__swc_fn_7dafa2b1_000061_15c28ca7>
  4082fb:	mov    rcx,r13
  4082fe:	mov    rdx,r8
  408301:	mov    r8,r9
  408304:	mov    r9,r10
  408307:	call   40ef60 <__swc_fn_7dafa2b1_000044_d3c2ab54>
  40830c:	cmp    QWORD PTR [r13+0x2a70],0x0
  408314:	jne    408270 <__swc_fn_7dafa2b1_000063_b304235a+0x190>
  40831a:	add    QWORD PTR [r13+0x2a78],0x1
  408322:	mov    rax,QWORD PTR [r13+0x2a70]
  408329:	lea    rax,[rax+rax*4]
  40832d:	lea    rax,[r13+rax*8+0x268]
  408335:	mov    QWORD PTR [rax],r14
  408338:	mov    QWORD PTR [rax+0x8],r15
  40833c:	mov    QWORD PTR [rax+0x10],r12
  408340:	mov    rcx,QWORD PTR [r13+0x2a78]
  408347:	mov    QWORD PTR [rax+0x18],rcx
  40834b:	mov    QWORD PTR [rax+0x20],rdi
  40834f:	add    QWORD PTR [r13+0x2a68],r12
  408356:	add    QWORD PTR [r13+0x2a70],0x1
  40835e:	mov    rcx,r13
  408361:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  408366:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40836f:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  408378:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  408381:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40838a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  408393:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40839c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  4083a5:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  4083ae:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  4083b7:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  4083c0:	add    rsp,0x148
  4083c7:	pop    rsi
  4083c8:	pop    rdi
  4083c9:	pop    r15
  4083cb:	pop    r14
  4083cd:	pop    r13
  4083cf:	pop    r12
  4083d1:	ret
	...

00000000004083e0 <__swc_fn_7dafa2b1_000066_d9ee99ea>:
  4083e0:	push   rbx
  4083e1:	push   r12
  4083e3:	push   r13
  4083e5:	push   r14
  4083e7:	push   r15
  4083e9:	push   rdi
  4083ea:	push   rsi
  4083eb:	sub    rsp,0xf0
  4083f2:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  4083f8:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  4083fe:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  408404:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40840a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  408413:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40841c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  408425:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40842e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  408437:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  408440:	mov    eax,r8d
  408443:	mov    rbx,rcx
  408446:	mov    r12,rdx
  408449:	mov    QWORD PTR [rsp+0x18],rdx
  40844e:	mov    ecx,DWORD PTR [r12+0x58]
  408453:	mov    r13d,ecx
  408456:	cmp    ecx,0x10
  408459:	mov    ecx,0x10
  40845e:	cmovb  r13d,ecx
  408462:	test   r13d,r13d
  408465:	mov    rcx,r13
  408468:	mov    edx,0x8
  40846d:	cmove  ecx,edx
  408470:	dec    rcx
  408473:	mov    rdx,0xffffffffffffffff
  40847a:	sub    rdx,rcx
  40847d:	xor    r14d,r14d
  408480:	mov    r8,rcx
  408483:	not    r8
  408486:	lea    rcx,[rcx+0x58]
  40848a:	and    rcx,r8
  40848d:	cmp    rdx,0x58
  408491:	cmovae r14,rcx
  408495:	cmp    eax,0xffffffff
  408498:	jne    4084a1 <__swc_fn_7dafa2b1_000066_d9ee99ea+0xc1>
  40849a:	mov    r15,QWORD PTR [r12+0x48]
  40849f:	jmp    4084d3 <__swc_fn_7dafa2b1_000066_d9ee99ea+0xf3>
  4084a1:	test   eax,eax
  4084a3:	jne    4084ac <__swc_fn_7dafa2b1_000066_d9ee99ea+0xcc>
  4084a5:	mov    eax,0x8
  4084aa:	jmp    4084d0 <__swc_fn_7dafa2b1_000066_d9ee99ea+0xf0>
  4084ac:	cmp    eax,0x8
  4084af:	ja     4084b7 <__swc_fn_7dafa2b1_000066_d9ee99ea+0xd7>
  4084b1:	shl    rax,0x4
  4084b5:	jmp    4084d0 <__swc_fn_7dafa2b1_000066_d9ee99ea+0xf0>
  4084b7:	lea    eax,[rax-0x9]
  4084ba:	mov    ecx,eax
  4084bc:	shr    ecx,0x2
  4084bf:	and    eax,0x3
  4084c2:	lea    ecx,[rcx+0x7]
  4084c5:	lea    ecx,[rcx-0x2]
  4084c8:	lea    eax,[rax+0x5]
  4084cb:	shlx   rax,rax,rcx
  4084d0:	mov    r15,rax
  4084d3:	lea    rax,[r14+r13*1]
  4084d7:	mov    rcx,0xffffffffffffffff
  4084de:	sub    rcx,rax
  4084e1:	cmp    r15,rcx
  4084e4:	jbe    4084f4 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x114>
  4084e6:	mov    QWORD PTR [r12+0x40],0x0
  4084ef:	jmp    4088c6 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x4e6>
  4084f4:	mov    QWORD PTR [rsp+0x20],r13
  4084f9:	lea    r13,[rsp+0x8]
  4084fe:	add    rax,r15
  408501:	mov    ecx,0x1000
  408506:	test   ecx,ecx
  408508:	mov    edx,0x8
  40850d:	cmove  ecx,edx
  408510:	dec    rcx
  408513:	mov    rdx,0xffffffffffffffff
  40851a:	sub    rdx,rcx
  40851d:	cmp    rax,rdx
  408520:	jbe    40852c <__swc_fn_7dafa2b1_000066_d9ee99ea+0x14c>
  408522:	mov    QWORD PTR [r13+0x0],0x0
  40852a:	jmp    408539 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x159>
  40852c:	add    rax,rcx
  40852f:	andn   rax,rcx,rax
  408534:	mov    QWORD PTR [rsp+0x8],rax
  408539:	cmp    QWORD PTR [r13+0x0],0x0
  40853e:	jne    40854e <__swc_fn_7dafa2b1_000066_d9ee99ea+0x16e>
  408540:	mov    QWORD PTR [r12+0x40],0x0
  408549:	jmp    4088c6 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x4e6>
  40854e:	mov    QWORD PTR [rsp+0x30],r15
  408553:	xor    r15d,r15d
  408556:	mov    QWORD PTR [rsp+0x38],0x0
  40855f:	lea    r12,[rsp+0x10]
  408564:	mov    QWORD PTR [rsp+0x28],r14
  408569:	mov    r14,QWORD PTR [rsp+0x8]
  40856e:	mov    QWORD PTR [rsp+0x10],r14
  408573:	cmp    r14,0x10000
  40857a:	ja     408581 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x1a1>
  40857c:	mov    rax,r14
  40857f:	jmp    4085d2 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x1f2>
  408581:	xor    eax,eax
  408583:	lea    rcx,[r14-0x1]
  408587:	lzcnt  rax,rcx
  40858c:	mov    ecx,0x3f
  408591:	sub    rcx,rax
  408594:	mov    eax,0x1
  408599:	lea    rcx,[rcx-0x3]
  40859d:	shl    rax,cl
  4085a0:	mov    rcx,rax
  4085a3:	cmp    rax,0x1000
  4085aa:	mov    eax,0x1000
  4085af:	cmovb  rcx,rax
  4085b3:	mov    rdx,0xffffffffffffffff
  4085ba:	sub    rdx,rcx
  4085bd:	mov    rax,r14
  4085c0:	lea    r8,[r14+rcx*1-0x1]
  4085c5:	neg    rcx
  4085c8:	and    r8,rcx
  4085cb:	cmp    r14,rdx
  4085ce:	cmovbe rax,r8
  4085d2:	mov    QWORD PTR [rsp+0x8],rax
  4085d7:	lea    rax,[rip+0x18a22]        # 421000 <__swc_data_base_7dafa2b1>
  4085de:	mov    rax,QWORD PTR [rax]
  4085e1:	cmp    rax,0xffffffffffffffff
  4085e5:	je     4085f4 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x214>
  4085e7:	mov    eax,eax
  4085e9:	mov    edi,eax
  4085eb:	xor    eax,eax
  4085ed:	call   407000 <pthread_getspecific@plt>
  4085f2:	jmp    4085f6 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x216>
  4085f4:	xor    eax,eax
  4085f6:	test   rax,rax
  4085f9:	jne    408608 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x228>
  4085fb:	call   407a80 <__swc_fn_7dafa2b1_000036_cd1a4e8c>
  408600:	mov    rcx,rax
  408603:	call   40cdc0 <__swc_fn_7dafa2b1_000133_5f757033>
  408608:	test   rax,rax
  40860b:	je     4086fc <__swc_fn_7dafa2b1_000066_d9ee99ea+0x31c>
  408611:	cmp    QWORD PTR [rax],rbx
  408614:	jne    4086fc <__swc_fn_7dafa2b1_000066_d9ee99ea+0x31c>
  40861a:	cmp    DWORD PTR [rax+0x20],0x0
  40861e:	jne    4086fc <__swc_fn_7dafa2b1_000066_d9ee99ea+0x31c>
  408624:	mov    rcx,QWORD PTR [rsp+0x8]
  408629:	movabs rdx,0x7fffffffffffffff
  408633:	cmp    rcx,rdx
  408636:	mov    rdx,0xffffffffffffffff
  40863d:	lea    r8,[rcx+rcx*1]
  408641:	cmovbe rdx,r8
  408645:	mov    r8d,DWORD PTR [rax+0x730]
  40864c:	mov    r9d,r8d
  40864f:	sub    rdx,rcx
  408652:	inc    rdx
  408655:	xor    r10d,r10d
  408658:	test   r8,r8
  40865b:	jbe    40868b <__swc_fn_7dafa2b1_000066_d9ee99ea+0x2ab>
  40865d:	nop    DWORD PTR [rax]
  408660:	mov    r11d,r10d
  408663:	lea    r11,[r11+r11*4]
  408667:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40866f:	sub    r11,rcx
  408672:	cmp    r11,rdx
  408675:	jae    408682 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x2a2>
  408677:	mov    r9d,r10d
  40867a:	mov    rdx,r11
  40867d:	test   r11,r11
  408680:	je     40868b <__swc_fn_7dafa2b1_000066_d9ee99ea+0x2ab>
  408682:	add    r10,0x1
  408686:	cmp    r10,r8
  408689:	jb     408660 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x280>
  40868b:	mov    ecx,DWORD PTR [rax+0x730]
  408691:	cmp    r9d,ecx
  408694:	jne    40869a <__swc_fn_7dafa2b1_000066_d9ee99ea+0x2ba>
  408696:	xor    eax,eax
  408698:	jmp    4086f9 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x319>
  40869a:	lea    rcx,[r9+r9*4]
  40869e:	lea    rcx,[rax+rcx*8+0x738]
  4086a6:	vmovups xmm0,XMMWORD PTR [rcx]
  4086aa:	mov    rdx,QWORD PTR [rcx+0x10]
  4086ae:	sub    DWORD PTR [rax+0x730],0x1
  4086b5:	mov    r8d,DWORD PTR [rax+0x730]
  4086bc:	lea    r8,[r8+r8*4]
  4086c0:	lea    r8,[rax+r8*8+0x738]
  4086c8:	vmovups xmm1,XMMWORD PTR [r8]
  4086cd:	vmovups XMMWORD PTR [rcx],xmm1
  4086d1:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  4086d7:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  4086dc:	mov    rax,QWORD PTR [r8+0x20]
  4086e0:	mov    QWORD PTR [rcx+0x20],rax
  4086e4:	vpshufd xmm1,xmm0,0xee
  4086e9:	vmovsd QWORD PTR [rsp+0x8],xmm1
  4086ef:	mov    QWORD PTR [rsp+0x10],rdx
  4086f4:	vmovq  rax,xmm0
  4086f9:	mov    r15,rax
  4086fc:	test   r15,r15
  4086ff:	jne    408717 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x337>
  408701:	mov    rcx,rbx
  408704:	mov    rdx,QWORD PTR [rsp+0x8]
  408709:	mov    r8,r13
  40870c:	mov    r9,r12
  40870f:	call   407fd0 <__swc_fn_7dafa2b1_000060_2ca0cb05>
  408714:	mov    r15,rax
  408717:	test   r15,r15
  40871a:	je     40875b <__swc_fn_7dafa2b1_000066_d9ee99ea+0x37b>
  40871c:	cmp    QWORD PTR [r12],r14
  408720:	jae    40875b <__swc_fn_7dafa2b1_000066_d9ee99ea+0x37b>
  408722:	mov    rax,r15
  408725:	add    rax,QWORD PTR [r12]
  408729:	mov    rdx,r14
  40872c:	sub    rdx,QWORD PTR [r12]
  408730:	mov    rcx,rax
  408733:	call   40eab0 <__swc_fn_7dafa2b1_000008_f7acedb0>
  408738:	test   al,al
  40873a:	je     408743 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x363>
  40873c:	mov    QWORD PTR [rsp+0x10],r14
  408741:	jmp    40875b <__swc_fn_7dafa2b1_000066_d9ee99ea+0x37b>
  408743:	mov    rcx,rbx
  408746:	mov    rdx,r15
  408749:	mov    r8,QWORD PTR [rsp+0x8]
  40874e:	mov    r9,QWORD PTR [rsp+0x10]
  408753:	call   4080e0 <__swc_fn_7dafa2b1_000063_b304235a>
  408758:	xor    r15d,r15d
  40875b:	test   r15,r15
  40875e:	jne    4087da <__swc_fn_7dafa2b1_000066_d9ee99ea+0x3fa>
  408760:	cmp    r14,0x10000
  408767:	ja     40876e <__swc_fn_7dafa2b1_000066_d9ee99ea+0x38e>
  408769:	mov    rax,r14
  40876c:	jmp    4087bf <__swc_fn_7dafa2b1_000066_d9ee99ea+0x3df>
  40876e:	xor    eax,eax
  408770:	lea    rcx,[r14-0x1]
  408774:	lzcnt  rax,rcx
  408779:	mov    ecx,0x3f
  40877e:	sub    rcx,rax
  408781:	mov    eax,0x1
  408786:	lea    rcx,[rcx-0x3]
  40878a:	shl    rax,cl
  40878d:	mov    rcx,rax
  408790:	cmp    rax,0x1000
  408797:	mov    eax,0x1000
  40879c:	cmovb  rcx,rax
  4087a0:	mov    rdx,0xffffffffffffffff
  4087a7:	sub    rdx,rcx
  4087aa:	mov    rax,r14
  4087ad:	lea    r8,[r14+rcx*1-0x1]
  4087b2:	neg    rcx
  4087b5:	and    r8,rcx
  4087b8:	cmp    r14,rdx
  4087bb:	cmovbe rax,r8
  4087bf:	mov    QWORD PTR [rsp+0x8],rax
  4087c4:	mov    QWORD PTR [rsp+0x10],r14
  4087c9:	mov    rcx,rbx
  4087cc:	mov    rdx,rax
  4087cf:	mov    r8,r14
  4087d2:	call   407b40 <__swc_fn_7dafa2b1_000042_c90d80c1>
  4087d7:	mov    r15,rax
  4087da:	test   r15,r15
  4087dd:	jne    4087eb <__swc_fn_7dafa2b1_000066_d9ee99ea+0x40b>
  4087df:	mov    r13,QWORD PTR [rsp+0x20]
  4087e4:	mov    rsi,QWORD PTR [rsp+0x38]
  4087e9:	jmp    408827 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x447>
  4087eb:	mov    rax,r15
  4087ee:	add    rax,QWORD PTR [rsp+0x28]
  4087f3:	mov    r13,QWORD PTR [rsp+0x20]
  4087f8:	test   r13d,r13d
  4087fb:	mov    rcx,r13
  4087fe:	mov    edx,0x8
  408803:	cmove  ecx,edx
  408806:	dec    rcx
  408809:	mov    rdx,0xffffffffffffffff
  408810:	sub    rdx,rcx
  408813:	cmp    rax,rdx
  408816:	jbe    40881c <__swc_fn_7dafa2b1_000066_d9ee99ea+0x43c>
  408818:	xor    eax,eax
  40881a:	jmp    408824 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x444>
  40881c:	add    rax,rcx
  40881f:	andn   rax,rcx,rax
  408824:	mov    rsi,rax
  408827:	mov    rax,QWORD PTR [rsp+0x8]
  40882c:	test   r15,r15
  40882f:	je     408838 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x458>
  408831:	mov    rdi,QWORD PTR [rsp+0x18]
  408836:	jmp    40884a <__swc_fn_7dafa2b1_000066_d9ee99ea+0x46a>
  408838:	mov    rdi,QWORD PTR [rsp+0x18]
  40883d:	mov    QWORD PTR [rdi+0x40],0x0
  408845:	jmp    4088c6 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x4e6>
  40884a:	lea    rdx,[rsi-0x58]
  40884e:	mov    QWORD PTR [rsi-0x58],r15
  408852:	mov    QWORD PTR [rsi-0x50],rax
  408856:	mov    rax,QWORD PTR [rsp+0x10]
  40885b:	mov    QWORD PTR [rsi-0x48],rax
  40885f:	mov    QWORD PTR [rsi-0x40],rsi
  408863:	mov    rax,QWORD PTR [rdi+0x48]
  408867:	mov    QWORD PTR [rsi-0x38],rax
  40886b:	mov    rax,QWORD PTR [rsp+0x30]
  408870:	mov    QWORD PTR [rsi-0x30],rax
  408874:	mov    DWORD PTR [rsi-0x10],r13d
  408878:	mov    QWORD PTR [rsi-0x28],0x0
  408880:	mov    QWORD PTR [rsi-0x20],0x0
  408888:	add    r15,QWORD PTR [r12]
  40888c:	sub    r15,rsi
  40888f:	mov    QWORD PTR [rsi-0x30],r15
  408893:	mov    rcx,QWORD PTR [rbx+0x250]
  40889a:	nop    WORD PTR [rax+rax*1+0x0]
  4088a0:	lea    r8,[rcx+r15*1]
  4088a4:	mov    rax,rcx
  4088a7:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  4088b0:	cmp    rax,rcx
  4088b3:	je     4088ba <__swc_fn_7dafa2b1_000066_d9ee99ea+0x4da>
  4088b5:	mov    rcx,rax
  4088b8:	jmp    4088a0 <__swc_fn_7dafa2b1_000066_d9ee99ea+0x4c0>
  4088ba:	mov    rcx,rbx
  4088bd:	call   40b0f0 <__swc_fn_7dafa2b1_000058_7e1dbcb0>
  4088c2:	mov    QWORD PTR [rdi+0x40],rsi
  4088c6:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  4088cc:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  4088d2:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  4088d8:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  4088de:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  4088e7:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  4088f0:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  4088f9:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  408902:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40890b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  408914:	add    rsp,0xf0
  40891b:	pop    rsi
  40891c:	pop    rdi
  40891d:	pop    r15
  40891f:	pop    r14
  408921:	pop    r13
  408923:	pop    r12
  408925:	pop    rbx
  408926:	ret
	...

0000000000408930 <__swc_fn_7dafa2b1_000069_f3aa21af>:
  408930:	push   rbx
  408931:	push   r12
  408933:	push   rdi
  408934:	push   rsi
  408935:	sub    rsp,0xb8
  40893c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  408942:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  408948:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40894e:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  408954:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40895a:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  408960:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  408966:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40896f:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  408978:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  408981:	mov    rbx,rdx
  408984:	mov    r12,rcx
  408987:	cmp    DWORD PTR [rbx+0x58],0x0
  40898b:	je     4089a5 <__swc_fn_7dafa2b1_000069_f3aa21af+0x75>
  40898d:	mov    eax,DWORD PTR [rbx+0x58]
  408990:	sub    eax,0x1
  408993:	test   DWORD PTR [rbx+0x58],eax
  408996:	je     4089a5 <__swc_fn_7dafa2b1_000069_f3aa21af+0x75>
  408998:	mov    QWORD PTR [rbx+0x40],0x0
  4089a0:	jmp    408bb7 <__swc_fn_7dafa2b1_000069_f3aa21af+0x287>
  4089a5:	cmp    QWORD PTR [rbx+0x48],0x0
  4089aa:	jne    4089b9 <__swc_fn_7dafa2b1_000069_f3aa21af+0x89>
  4089ac:	mov    QWORD PTR [rbx+0x40],0x0
  4089b4:	jmp    408bb7 <__swc_fn_7dafa2b1_000069_f3aa21af+0x287>
  4089b9:	lea    rax,[rsp+0x8]
  4089be:	mov    rcx,QWORD PTR [rbx+0x48]
  4089c2:	cmp    rcx,0x8
  4089c6:	ja     4089d0 <__swc_fn_7dafa2b1_000069_f3aa21af+0xa0>
  4089c8:	mov    DWORD PTR [rax],0x0
  4089ce:	jmp    408a2b <__swc_fn_7dafa2b1_000069_f3aa21af+0xfb>
  4089d0:	cmp    rcx,0x80
  4089d7:	ja     4089e7 <__swc_fn_7dafa2b1_000069_f3aa21af+0xb7>
  4089d9:	lea    rcx,[rcx+0xf]
  4089dd:	shr    rcx,0x4
  4089e1:	mov    DWORD PTR [rsp+0x8],ecx
  4089e5:	jmp    408a2b <__swc_fn_7dafa2b1_000069_f3aa21af+0xfb>
  4089e7:	cmp    rcx,0x10000
  4089ee:	jbe    4089f8 <__swc_fn_7dafa2b1_000069_f3aa21af+0xc8>
  4089f0:	mov    DWORD PTR [rax],0xffffffff
  4089f6:	jmp    408a2b <__swc_fn_7dafa2b1_000069_f3aa21af+0xfb>
  4089f8:	dec    rcx
  4089fb:	xor    edx,edx
  4089fd:	lzcnt  rdx,rcx
  408a02:	mov    r8d,0x3f
  408a08:	sub    r8d,edx
  408a0b:	lea    edx,[r8-0x2]
  408a0f:	shrx   rcx,rcx,rdx
  408a14:	and    ecx,0x3
  408a17:	lea    edx,[r8-0x7]
  408a1b:	lea    edx,[rdx*4+0x0]
  408a22:	lea    edx,[rdx+0x9]
  408a25:	add    edx,ecx
  408a27:	mov    DWORD PTR [rsp+0x8],edx
  408a2b:	cmp    DWORD PTR [rax],0x0
  408a2e:	jne    408a3e <__swc_fn_7dafa2b1_000069_f3aa21af+0x10e>
  408a30:	cmp    DWORD PTR [rbx+0x58],0x8
  408a34:	jbe    408a3e <__swc_fn_7dafa2b1_000069_f3aa21af+0x10e>
  408a36:	mov    DWORD PTR [rsp+0x8],0x1
  408a3e:	cmp    DWORD PTR [rbx+0x58],0x10
  408a42:	jbe    408ac1 <__swc_fn_7dafa2b1_000069_f3aa21af+0x191>
  408a48:	cmp    DWORD PTR [rbx+0x58],0x40
  408a4c:	ja     408ac1 <__swc_fn_7dafa2b1_000069_f3aa21af+0x191>
  408a4e:	cmp    DWORD PTR [rax],0xffffffff
  408a51:	je     408ac1 <__swc_fn_7dafa2b1_000069_f3aa21af+0x191>
  408a53:	mov    ecx,DWORD PTR [rsp+0x8]
  408a57:	mov    edx,DWORD PTR [rbx+0x58]
  408a5a:	dec    rdx
  408a5d:	cmp    ecx,0x2d
  408a60:	jae    408ab8 <__swc_fn_7dafa2b1_000069_f3aa21af+0x188>
  408a62:	cs nop WORD PTR [rax+rax*1+0x0]
  408a6c:	nop    DWORD PTR [rax+0x0]
  408a70:	mov    r8d,ecx
  408a73:	test   ecx,ecx
  408a75:	jne    408a7f <__swc_fn_7dafa2b1_000069_f3aa21af+0x14f>
  408a77:	mov    r8d,0x8
  408a7d:	jmp    408aab <__swc_fn_7dafa2b1_000069_f3aa21af+0x17b>
  408a7f:	cmp    r8d,0x8
  408a83:	ja     408a8b <__swc_fn_7dafa2b1_000069_f3aa21af+0x15b>
  408a85:	shl    r8,0x4
  408a89:	jmp    408aab <__swc_fn_7dafa2b1_000069_f3aa21af+0x17b>
  408a8b:	lea    r8d,[r8-0x9]
  408a8f:	mov    r9d,r8d
  408a92:	shr    r9d,0x2
  408a96:	and    r8d,0x3
  408a9a:	lea    r9d,[r9+0x7]
  408a9e:	lea    r9d,[r9-0x2]
  408aa2:	lea    r8d,[r8+0x5]
  408aa6:	shlx   r8,r8,r9
  408aab:	test   r8,rdx
  408aae:	je     408abd <__swc_fn_7dafa2b1_000069_f3aa21af+0x18d>
  408ab0:	add    ecx,0x1
  408ab3:	cmp    ecx,0x2d
  408ab6:	jb     408a70 <__swc_fn_7dafa2b1_000069_f3aa21af+0x140>
  408ab8:	mov    ecx,0xffffffff
  408abd:	mov    DWORD PTR [rsp+0x8],ecx
  408ac1:	mov    ecx,DWORD PTR [rsp+0x8]
  408ac5:	cmp    ecx,0xffffffff
  408ac8:	je     408ad0 <__swc_fn_7dafa2b1_000069_f3aa21af+0x1a0>
  408aca:	cmp    DWORD PTR [rbx+0x58],0x40
  408ace:	jbe    408ae3 <__swc_fn_7dafa2b1_000069_f3aa21af+0x1b3>
  408ad0:	mov    rcx,r12
  408ad3:	mov    rdx,rbx
  408ad6:	mov    r8d,DWORD PTR [rax]
  408ad9:	call   4083e0 <__swc_fn_7dafa2b1_000066_d9ee99ea>
  408ade:	jmp    408bb7 <__swc_fn_7dafa2b1_000069_f3aa21af+0x287>
  408ae3:	lea    rax,[rip+0x18516]        # 421000 <__swc_data_base_7dafa2b1>
  408aea:	mov    rax,QWORD PTR [rax]
  408aed:	cmp    rax,0xffffffffffffffff
  408af1:	je     408b00 <__swc_fn_7dafa2b1_000069_f3aa21af+0x1d0>
  408af3:	mov    eax,eax
  408af5:	mov    edi,eax
  408af7:	xor    eax,eax
  408af9:	call   407000 <pthread_getspecific@plt>
  408afe:	jmp    408b02 <__swc_fn_7dafa2b1_000069_f3aa21af+0x1d2>
  408b00:	xor    eax,eax
  408b02:	test   rax,rax
  408b05:	jne    408b14 <__swc_fn_7dafa2b1_000069_f3aa21af+0x1e4>
  408b07:	call   407a80 <__swc_fn_7dafa2b1_000036_cd1a4e8c>
  408b0c:	mov    rcx,rax
  408b0f:	call   40cdc0 <__swc_fn_7dafa2b1_000133_5f757033>
  408b14:	test   rax,rax
  408b17:	je     408b24 <__swc_fn_7dafa2b1_000069_f3aa21af+0x1f4>
  408b19:	cmp    QWORD PTR [rax],r12
  408b1c:	jne    408b24 <__swc_fn_7dafa2b1_000069_f3aa21af+0x1f4>
  408b1e:	cmp    DWORD PTR [rax+0x20],0x0
  408b22:	je     408b2f <__swc_fn_7dafa2b1_000069_f3aa21af+0x1ff>
  408b24:	mov    rcx,r12
  408b27:	mov    rdx,rax
  408b2a:	call   40ad30 <__swc_fn_7dafa2b1_000046_d8bd27c3>
  408b2f:	test   rax,rax
  408b32:	jne    408b3e <__swc_fn_7dafa2b1_000069_f3aa21af+0x20e>
  408b34:	mov    QWORD PTR [rbx+0x40],0x0
  408b3c:	jmp    408bb7 <__swc_fn_7dafa2b1_000069_f3aa21af+0x287>
  408b3e:	lea    r8,[rsp+0xc]
  408b43:	mov    ecx,DWORD PTR [rsp+0x8]
  408b47:	mov    DWORD PTR [rsp+0xc],ecx
  408b4b:	mov    ecx,DWORD PTR [r8]
  408b4e:	lea    rcx,[rcx+rcx*4]
  408b52:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  408b57:	test   rcx,rcx
  408b5a:	je     408b93 <__swc_fn_7dafa2b1_000069_f3aa21af+0x263>
  408b5c:	mov    rdx,QWORD PTR [rcx]
  408b5f:	test   rdx,rdx
  408b62:	je     408b70 <__swc_fn_7dafa2b1_000069_f3aa21af+0x240>
  408b64:	mov    r9,QWORD PTR [rdx]
  408b67:	mov    QWORD PTR [rcx],r9
  408b6a:	add    DWORD PTR [rcx+0x28],0x1
  408b6e:	jmp    408b8e <__swc_fn_7dafa2b1_000069_f3aa21af+0x25e>
  408b70:	mov    rdx,QWORD PTR [rcx+0x18]
  408b74:	cmp    QWORD PTR [rcx+0x20],rdx
  408b78:	jae    408b8c <__swc_fn_7dafa2b1_000069_f3aa21af+0x25c>
  408b7a:	mov    rdx,QWORD PTR [rcx+0x20]
  408b7e:	mov    r9d,DWORD PTR [rcx+0x2c]
  408b82:	add    QWORD PTR [rcx+0x20],r9
  408b86:	add    DWORD PTR [rcx+0x28],0x1
  408b8a:	jmp    408b8e <__swc_fn_7dafa2b1_000069_f3aa21af+0x25e>
  408b8c:	xor    edx,edx
  408b8e:	test   rdx,rdx
  408b91:	jne    408ba4 <__swc_fn_7dafa2b1_000069_f3aa21af+0x274>
  408b93:	mov    rcx,r12
  408b96:	mov    rdx,rax
  408b99:	mov    r8d,DWORD PTR [r8]
  408b9c:	call   40aea0 <__swc_fn_7dafa2b1_000055_faa92dcc>
  408ba1:	mov    rdx,rax
  408ba4:	test   rdx,rdx
  408ba7:	jne    408bb3 <__swc_fn_7dafa2b1_000069_f3aa21af+0x283>
  408ba9:	mov    QWORD PTR [rbx+0x40],0x0
  408bb1:	jmp    408bb7 <__swc_fn_7dafa2b1_000069_f3aa21af+0x287>
  408bb3:	mov    QWORD PTR [rbx+0x40],rdx
  408bb7:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  408bbd:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  408bc3:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  408bc9:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  408bcf:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  408bd5:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  408bdb:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  408be1:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  408bea:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  408bf3:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  408bfc:	add    rsp,0xb8
  408c03:	pop    rsi
  408c04:	pop    rdi
  408c05:	pop    r12
  408c07:	pop    rbx
  408c08:	ret
  408c09:	add    BYTE PTR [rax],al
  408c0b:	add    BYTE PTR [rax],al
  408c0d:	add    BYTE PTR [rax],al
	...

0000000000408c10 <__swc_fn_7dafa2b1_000072_b3d7b28e>:
  408c10:	ret
	...

0000000000408c20 <__swc_fn_7dafa2b1_000075_042643a3>:
  408c20:	push   r12
  408c22:	push   r13
  408c24:	push   r14
  408c26:	push   rdi
  408c27:	push   rsi
  408c28:	sub    rsp,0x1a0
  408c2f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  408c38:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  408c41:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  408c4a:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  408c53:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  408c5c:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  408c65:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  408c6e:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  408c77:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  408c80:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  408c89:	mov    r12,rdx
  408c8c:	mov    r13,rcx
  408c8f:	mov    rax,QWORD PTR [r12+0x48]
  408c94:	mov    ecx,DWORD PTR [r12+0x58]
  408c99:	lea    rdx,[rax-0x1]
  408c9d:	cmp    rdx,0x10000
  408ca4:	jae    408d9e <__swc_fn_7dafa2b1_000075_042643a3+0x17e>
  408caa:	cmp    rax,0x8
  408cae:	ja     408cb5 <__swc_fn_7dafa2b1_000075_042643a3+0x95>
  408cb0:	xor    r14d,r14d
  408cb3:	jmp    408d07 <__swc_fn_7dafa2b1_000075_042643a3+0xe7>
  408cb5:	cmp    rax,0x80
  408cbc:	ja     408cc8 <__swc_fn_7dafa2b1_000075_042643a3+0xa8>
  408cbe:	lea    r14,[rax+0xf]
  408cc2:	shr    r14,0x4
  408cc6:	jmp    408d07 <__swc_fn_7dafa2b1_000075_042643a3+0xe7>
  408cc8:	cmp    rax,0x10000
  408ccf:	jbe    408cd9 <__swc_fn_7dafa2b1_000075_042643a3+0xb9>
  408cd1:	mov    r14d,0xffffffff
  408cd7:	jmp    408d07 <__swc_fn_7dafa2b1_000075_042643a3+0xe7>
  408cd9:	xor    eax,eax
  408cdb:	lzcnt  rax,rdx
  408ce0:	mov    r8d,0x3f
  408ce6:	sub    r8d,eax
  408ce9:	lea    eax,[r8-0x2]
  408ced:	shrx   rax,rdx,rax
  408cf2:	and    eax,0x3
  408cf5:	lea    edx,[r8-0x7]
  408cf9:	lea    edx,[rdx*4+0x0]
  408d00:	lea    edx,[rdx+0x9]
  408d03:	lea    r14d,[rdx+rax*1]
  408d07:	cmp    ecx,0x8
  408d0a:	jbe    408d23 <__swc_fn_7dafa2b1_000075_042643a3+0x103>
  408d0c:	cmp    ecx,0x10
  408d0f:	jne    408d9e <__swc_fn_7dafa2b1_000075_042643a3+0x17e>
  408d15:	test   r14d,r14d
  408d18:	mov    eax,0x1
  408d1d:	cmove  r14d,eax
  408d21:	jmp    408d2a <__swc_fn_7dafa2b1_000075_042643a3+0x10a>
  408d23:	lea    eax,[rcx-0x1]
  408d26:	test   eax,ecx
  408d28:	jne    408d9e <__swc_fn_7dafa2b1_000075_042643a3+0x17e>
  408d2a:	lea    rax,[rip+0x182cf]        # 421000 <__swc_data_base_7dafa2b1>
  408d31:	mov    rax,QWORD PTR [rax]
  408d34:	cmp    rax,0xffffffffffffffff
  408d38:	je     408d47 <__swc_fn_7dafa2b1_000075_042643a3+0x127>
  408d3a:	mov    eax,eax
  408d3c:	mov    edi,eax
  408d3e:	xor    eax,eax
  408d40:	call   407000 <pthread_getspecific@plt>
  408d45:	jmp    408d49 <__swc_fn_7dafa2b1_000075_042643a3+0x129>
  408d47:	xor    eax,eax
  408d49:	test   rax,rax
  408d4c:	je     408d9e <__swc_fn_7dafa2b1_000075_042643a3+0x17e>
  408d4e:	cmp    QWORD PTR [rax],r13
  408d51:	jne    408d9e <__swc_fn_7dafa2b1_000075_042643a3+0x17e>
  408d53:	lea    rcx,[r14+r14*4]
  408d57:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  408d5c:	test   rax,rax
  408d5f:	je     408d9e <__swc_fn_7dafa2b1_000075_042643a3+0x17e>
  408d61:	mov    rcx,QWORD PTR [rax]
  408d64:	test   rcx,rcx
  408d67:	je     408d75 <__swc_fn_7dafa2b1_000075_042643a3+0x155>
  408d69:	mov    rdx,QWORD PTR [rcx]
  408d6c:	mov    QWORD PTR [rax],rdx
  408d6f:	add    DWORD PTR [rax+0x28],0x1
  408d73:	jmp    408d92 <__swc_fn_7dafa2b1_000075_042643a3+0x172>
  408d75:	mov    rcx,QWORD PTR [rax+0x18]
  408d79:	cmp    QWORD PTR [rax+0x20],rcx
  408d7d:	jae    408d90 <__swc_fn_7dafa2b1_000075_042643a3+0x170>
  408d7f:	mov    rcx,QWORD PTR [rax+0x20]
  408d83:	mov    edx,DWORD PTR [rax+0x2c]
  408d86:	add    QWORD PTR [rax+0x20],rdx
  408d8a:	add    DWORD PTR [rax+0x28],0x1
  408d8e:	jmp    408d92 <__swc_fn_7dafa2b1_000075_042643a3+0x172>
  408d90:	xor    ecx,ecx
  408d92:	test   rcx,rcx
  408d95:	je     408d9e <__swc_fn_7dafa2b1_000075_042643a3+0x17e>
  408d97:	mov    QWORD PTR [r12+0x40],rcx
  408d9c:	jmp    408da9 <__swc_fn_7dafa2b1_000075_042643a3+0x189>
  408d9e:	mov    rcx,r13
  408da1:	mov    rdx,r12
  408da4:	call   40b920 <__swc_fn_7dafa2b1_000076_64d36d78>
  408da9:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  408db2:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  408dbb:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  408dc4:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  408dcd:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  408dd6:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  408ddf:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  408de8:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  408df1:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  408dfa:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  408e03:	add    rsp,0x1a0
  408e0a:	pop    rsi
  408e0b:	pop    rdi
  408e0c:	pop    r14
  408e0e:	pop    r13
  408e10:	pop    r12
  408e12:	ret
	...

0000000000408e20 <__swc_fn_7dafa2b1_000078_7b195156>:
  408e20:	push   r12
  408e22:	push   r13
  408e24:	push   r14
  408e26:	push   r15
  408e28:	push   rdi
  408e29:	push   rsi
  408e2a:	sub    rsp,0x188
  408e31:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  408e3a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  408e43:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  408e4c:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  408e55:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  408e5e:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  408e67:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  408e70:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  408e79:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  408e82:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  408e8b:	mov    r12,rdx
  408e8e:	mov    r13,rcx
  408e91:	mov    r14,QWORD PTR [r12+0x40]
  408e96:	lea    rax,[rip+0x1a1db]        # 423078 <__swc_bss_base_7dafa2b1+0x38>
  408e9d:	mov    rcx,r14
  408ea0:	sub    rcx,QWORD PTR [rax+0x8]
  408ea4:	mov    rax,QWORD PTR [rip+0x1a1dd]        # 423088 <__swc_bss_base_7dafa2b1+0x48>
  408eab:	cmp    rcx,rax
  408eae:	jae    408eda <__swc_fn_7dafa2b1_000078_7b195156+0xba>
  408eb0:	mov    rax,r14
  408eb3:	and    rax,0xffffffffffc00000
  408eba:	mov    rcx,r14
  408ebd:	shr    rcx,0x10
  408ec1:	and    ecx,0x3f
  408ec4:	mov    edx,DWORD PTR [rax+0x28]
  408ec7:	shrx   ecx,ecx,edx
  408ecc:	shl    rcx,0x4
  408ed0:	lea    r15,[rax+rcx*8+0x80]
  408ed8:	jmp    408ee5 <__swc_fn_7dafa2b1_000078_7b195156+0xc5>
  408eda:	mov    rcx,r14
  408edd:	call   4079b0 <__swc_fn_7dafa2b1_000027_bcdc5519>
  408ee2:	mov    r15,rax
  408ee5:	test   r15,r15
  408ee8:	je     408f8f <__swc_fn_7dafa2b1_000078_7b195156+0x16f>
  408eee:	lea    rax,[rip+0x1810b]        # 421000 <__swc_data_base_7dafa2b1>
  408ef5:	mov    rax,QWORD PTR [rax]
  408ef8:	cmp    rax,0xffffffffffffffff
  408efc:	je     408f0b <__swc_fn_7dafa2b1_000078_7b195156+0xeb>
  408efe:	mov    eax,eax
  408f00:	mov    edi,eax
  408f02:	xor    eax,eax
  408f04:	call   407000 <pthread_getspecific@plt>
  408f09:	jmp    408f0d <__swc_fn_7dafa2b1_000078_7b195156+0xed>
  408f0b:	xor    eax,eax
  408f0d:	mov    rcx,QWORD PTR [r15+0x40]
  408f11:	cmp    rcx,rax
  408f14:	jne    408f74 <__swc_fn_7dafa2b1_000078_7b195156+0x154>
  408f16:	test   rax,rax
  408f19:	je     408f8f <__swc_fn_7dafa2b1_000078_7b195156+0x16f>
  408f1b:	mov    ecx,DWORD PTR [r15+0x6c]
  408f1f:	test   ecx,ecx
  408f21:	je     408f41 <__swc_fn_7dafa2b1_000078_7b195156+0x121>
  408f23:	mov    rcx,r13
  408f26:	mov    rdx,rax
  408f29:	mov    r8,r15
  408f2c:	mov    QWORD PTR [rsp+0xd8],rax
  408f34:	call   40ae30 <__swc_fn_7dafa2b1_000052_e072b516>
  408f39:	mov    rax,QWORD PTR [rsp+0xd8]
  408f41:	mov    rcx,QWORD PTR [r15]
  408f44:	mov    QWORD PTR [r14],rcx
  408f47:	mov    QWORD PTR [r15],r14
  408f4a:	sub    DWORD PTR [r15+0x28],0x1
  408f4f:	jne    408f84 <__swc_fn_7dafa2b1_000078_7b195156+0x164>
  408f51:	movzx  ecx,BYTE PTR [r15+0x39]
  408f56:	lea    rcx,[rcx+rcx*4]
  408f5a:	lea    rcx,[rax+rcx*8+0x28]
  408f5f:	cmp    QWORD PTR [rcx],r15
  408f62:	je     408f84 <__swc_fn_7dafa2b1_000078_7b195156+0x164>
  408f64:	mov    rcx,r13
  408f67:	mov    rdx,rax
  408f6a:	mov    r8,r15
  408f6d:	call   40f580 <__swc_fn_7dafa2b1_000056_2e3450f7>
  408f72:	jmp    408f84 <__swc_fn_7dafa2b1_000078_7b195156+0x164>
  408f74:	test   rcx,rcx
  408f77:	je     408f8f <__swc_fn_7dafa2b1_000078_7b195156+0x16f>
  408f79:	mov    rcx,r15
  408f7c:	mov    rdx,r14
  408f7f:	call   4075f0 <__swc_fn_7dafa2b1_000015_524c1f23>
  408f84:	mov    QWORD PTR [r12+0x40],0x0
  408f8d:	jmp    408f9a <__swc_fn_7dafa2b1_000078_7b195156+0x17a>
  408f8f:	mov    rcx,r13
  408f92:	mov    rdx,r12
  408f95:	call   40b940 <__swc_fn_7dafa2b1_000079_1966ae2e>
  408f9a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  408fa3:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  408fac:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  408fb5:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  408fbe:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  408fc7:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  408fd0:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  408fd9:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  408fe2:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  408feb:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  408ff4:	add    rsp,0x188
  408ffb:	pop    rsi
  408ffc:	pop    rdi
  408ffd:	pop    r15
  408fff:	pop    r14
  409001:	pop    r13
  409003:	pop    r12
  409005:	ret
	...

0000000000409010 <__swc_fn_7dafa2b1_000081_d2cd17e2>:
  409010:	sub    rsp,0x8
  409014:	mov    rax,rdx
  409017:	mov    rdx,QWORD PTR [rax+0x40]
  40901b:	mov    r8,rax
  40901e:	call   408c10 <__swc_fn_7dafa2b1_000072_b3d7b28e>
  409023:	add    rsp,0x8
  409027:	ret
	...

0000000000409030 <__swc_fn_7dafa2b1_000084_4a10c7e7>:
  409030:	push   rsi
  409031:	push   rdi
  409032:	sub    rsp,0x8
  409036:	cmp    rcx,0xffffffffffffffef
  40903a:	ja     409060 <__swc_fn_7dafa2b1_000084_4a10c7e7+0x30>
  40903c:	xor    esi,esi
  40903e:	lea    rax,[rcx+0x100f]
  409045:	and    rax,0xfffffffffffff000
  40904c:	lea    rcx,[rcx+0x10]
  409050:	cmp    rcx,0xfffffffffffff000
  409057:	cmovbe rsi,rax
  40905b:	test   rsi,rsi
  40905e:	jne    409069 <__swc_fn_7dafa2b1_000084_4a10c7e7+0x39>
  409060:	xor    eax,eax
  409062:	add    rsp,0x8
  409066:	pop    rdi
  409067:	pop    rsi
  409068:	ret
  409069:	mov    rcx,rsi
  40906c:	call   4096c0 <__swc_fn_7dafa2b1_000114_6b799b8d>
  409071:	mov    rdi,rax
  409074:	test   rax,rax
  409077:	jne    409082 <__swc_fn_7dafa2b1_000084_4a10c7e7+0x52>
  409079:	xor    eax,eax
  40907b:	add    rsp,0x8
  40907f:	pop    rdi
  409080:	pop    rsi
  409081:	ret
  409082:	mov    rcx,rdi
  409085:	mov    rdx,rsi
  409088:	call   410a40 <__swc_fn_7dafa2b1_000116_36905703>
  40908d:	test   al,al
  40908f:	jne    4090a5 <__swc_fn_7dafa2b1_000084_4a10c7e7+0x75>
  409091:	mov    rcx,rdi
  409094:	mov    rdx,rsi
  409097:	call   40ca70 <__swc_fn_7dafa2b1_000118_ed2d8fed>
  40909c:	xor    eax,eax
  40909e:	add    rsp,0x8
  4090a2:	pop    rdi
  4090a3:	pop    rsi
  4090a4:	ret
  4090a5:	mov    QWORD PTR [rdi],rsi
  4090a8:	mov    QWORD PTR [rdi+0x8],0x0
  4090b0:	lea    rax,[rdi+0x10]
  4090b4:	add    rsp,0x8
  4090b8:	pop    rdi
  4090b9:	pop    rsi
  4090ba:	ret
  4090bb:	add    BYTE PTR [rax],al
  4090bd:	add    BYTE PTR [rax],al
	...

00000000004090c0 <__swc_fn_7dafa2b1_000087_3953ef98>:
  4090c0:	sub    rsp,0x8
  4090c4:	cmp    BYTE PTR [rcx+0x2c],0x10
  4090c8:	jne    4090d3 <__swc_fn_7dafa2b1_000087_3953ef98+0x13>
  4090ca:	test   DWORD PTR [rcx+0x28],0x80
  4090d1:	je     4090db <__swc_fn_7dafa2b1_000087_3953ef98+0x1b>
  4090d3:	mov    rax,rcx
  4090d6:	add    rsp,0x8
  4090da:	ret
  4090db:	mov    rcx,QWORD PTR [rcx+0x40]
  4090df:	call   4090c0 <__swc_fn_7dafa2b1_000087_3953ef98>
  4090e4:	add    rsp,0x8
  4090e8:	ret
	...

0000000000409100 <__swc_fn_7dafa2b1_000090_d182c4dc>:
  409100:	push   rsi
  409101:	push   rdi
  409102:	push   r12
  409104:	push   r13
  409106:	sub    rsp,0x8
  40910a:	mov    rsi,rdx
  40910d:	mov    rdi,rcx
  409110:	xor    r8d,r8d
  409113:	call   40fda0 <__swc_fn_7dafa2b1_000095_63c1827b>
  409118:	test   al,al
  40911a:	je     40912c <__swc_fn_7dafa2b1_000090_d182c4dc+0x2c>
  40911c:	mov    eax,0x1
  409121:	add    rsp,0x8
  409125:	pop    r13
  409127:	pop    r12
  409129:	pop    rdi
  40912a:	pop    rsi
  40912b:	ret
  40912c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  409131:	je     409140 <__swc_fn_7dafa2b1_000090_d182c4dc+0x40>
  409133:	xor    eax,eax
  409135:	add    rsp,0x8
  409139:	pop    r13
  40913b:	pop    r12
  40913d:	pop    rdi
  40913e:	pop    rsi
  40913f:	ret
  409140:	mov    r12,QWORD PTR [rsi+0x98]
  409147:	mov    rax,QWORD PTR [rsi+0xa0]
  40914e:	mov    rsi,rax
  409151:	xor    r13d,r13d
  409154:	test   rsi,rsi
  409157:	je     4091b4 <__swc_fn_7dafa2b1_000090_d182c4dc+0xb4>
  409159:	cs nop WORD PTR [rax+rax*1+0x0]
  409163:	cs nop WORD PTR [rax+rax*1+0x0]
  40916d:	nop    DWORD PTR [rax]
  409170:	lea    rax,[r13*8+0x0]
  409178:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40917d:	mov    rcx,rax
  409180:	call   4090c0 <__swc_fn_7dafa2b1_000087_3953ef98>
  409185:	cmp    BYTE PTR [rax+0x2c],0xe
  409189:	jne    4091aa <__swc_fn_7dafa2b1_000090_d182c4dc+0xaa>
  40918b:	mov    rcx,rdi
  40918e:	mov    rdx,rax
  409191:	call   409100 <__swc_fn_7dafa2b1_000090_d182c4dc>
  409196:	test   al,al
  409198:	je     4091aa <__swc_fn_7dafa2b1_000090_d182c4dc+0xaa>
  40919a:	mov    eax,0x1
  40919f:	add    rsp,0x8
  4091a3:	pop    r13
  4091a5:	pop    r12
  4091a7:	pop    rdi
  4091a8:	pop    rsi
  4091a9:	ret
  4091aa:	add    r13,0x1
  4091ae:	sub    rsi,0x1
  4091b2:	jne    409170 <__swc_fn_7dafa2b1_000090_d182c4dc+0x70>
  4091b4:	xor    eax,eax
  4091b6:	add    rsp,0x8
  4091ba:	pop    r13
  4091bc:	pop    r12
  4091be:	pop    rdi
  4091bf:	pop    rsi
  4091c0:	ret
	...

00000000004091d0 <__swc_fn_7dafa2b1_000093_14c65203>:
  4091d0:	sub    rsp,0x18
  4091d4:	vxorps xmm0,xmm0,xmm0
  4091d8:	vmovdqu XMMWORD PTR [rsp],xmm0
  4091dd:	call   40bb50 <__swc_fn_7dafa2b1_000094_c2567a3b>
  4091e2:	add    rsp,0x18
  4091e6:	ret
	...

00000000004091f0 <__swc_fn_7dafa2b1_000096_ad13d15c>:
  4091f0:	sub    rsp,0x8
  4091f4:	mov    rcx,QWORD PTR [rip+0x19e45]        # 423040 <__swc_bss_base_7dafa2b1>
  4091fb:	test   rcx,rcx
  4091fe:	jne    409210 <__swc_fn_7dafa2b1_000096_ad13d15c+0x20>
  409200:	call   4119a0 <__swc_fn_7dafa2b1_000170_994c8876>
  409205:	lea    rcx,[rax+0x1]
  409209:	mov    QWORD PTR [rip+0x19e30],rcx        # 423040 <__swc_bss_base_7dafa2b1>
  409210:	dec    rcx
  409213:	call   40e840 <__swc_fn_7dafa2b1_000172_360af05d>
  409218:	mov    rax,QWORD PTR [rax+0xc0]
  40921f:	and    eax,0x1
  409222:	setne  al
  409225:	add    rsp,0x8
  409229:	ret
	...

0000000000409240 <__swc_fn_7dafa2b1_000099_4f209617>:
  409240:	push   rbx
  409241:	push   rsi
  409242:	push   rdi
  409243:	push   r12
  409245:	sub    rsp,0x28
  409249:	mov    rbx,rcx
  40924c:	call   410100 <__swc_fn_7dafa2b1_000098_4185993f>
  409251:	mov    rcx,QWORD PTR [rip+0x19de8]        # 423040 <__swc_bss_base_7dafa2b1>
  409258:	test   rcx,rcx
  40925b:	jne    40926d <__swc_fn_7dafa2b1_000099_4f209617+0x2d>
  40925d:	call   4119a0 <__swc_fn_7dafa2b1_000170_994c8876>
  409262:	lea    rcx,[rax+0x1]
  409266:	mov    QWORD PTR [rip+0x19dd3],rcx        # 423040 <__swc_bss_base_7dafa2b1>
  40926d:	dec    rcx
  409270:	call   40e840 <__swc_fn_7dafa2b1_000172_360af05d>
  409275:	mov    rsi,rax
  409278:	lea    rcx,[rsp+0x8]
  40927d:	call   40bf90 <__swc_fn_7dafa2b1_000097_93bfe675>
  409282:	mov    rdi,QWORD PTR [rsi+0x9c0]
  409289:	mov    r12,QWORD PTR [rsi+0xbe8]
  409290:	lea    rcx,[rsi+0x10]
  409294:	call   40a210 <__swc_fn_7dafa2b1_000162_13ead2ff>
  409299:	mov    rcx,rsi
  40929c:	call   40c100 <__swc_fn_7dafa2b1_000106_5a85fcf5>
  4092a1:	vxorps xmm0,xmm0,xmm0
  4092a5:	xor    eax,eax
  4092a7:	cs nop WORD PTR [rax+rax*1+0x0]
  4092b1:	cs nop WORD PTR [rax+rax*1+0x0]
  4092bb:	nop    DWORD PTR [rax+rax*1+0x0]
  4092c0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  4092c5:	add    rax,0x10
  4092c9:	cmp    rax,0xbf0
  4092d0:	jne    4092c0 <__swc_fn_7dafa2b1_000099_4f209617+0x80>
  4092d2:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4092d8:	vmovups XMMWORD PTR [rsi],xmm0
  4092dc:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4092e2:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  4092ea:	mov    QWORD PTR [rsi+0x9c0],rdi
  4092f1:	mov    QWORD PTR [rsi+0xbe8],r12
  4092f8:	mov    rcx,QWORD PTR [rip+0x19d41]        # 423040 <__swc_bss_base_7dafa2b1>
  4092ff:	test   rcx,rcx
  409302:	jne    409314 <__swc_fn_7dafa2b1_000099_4f209617+0xd4>
  409304:	call   4119a0 <__swc_fn_7dafa2b1_000170_994c8876>
  409309:	lea    rcx,[rax+0x1]
  40930d:	mov    QWORD PTR [rip+0x19d2c],rcx        # 423040 <__swc_bss_base_7dafa2b1>
  409314:	dec    rcx
  409317:	call   40e840 <__swc_fn_7dafa2b1_000172_360af05d>
  40931c:	mov    rsi,rax
  40931f:	mov    QWORD PTR [rsi+0xc0],rbx
  409326:	and    ebx,0x1
  409329:	jne    40932d <__swc_fn_7dafa2b1_000099_4f209617+0xed>
  40932b:	xor    eax,eax
  40932d:	test   rbx,rbx
  409330:	sete   al
  409333:	xor    cl,cl
  409335:	xor    dl,dl
  409337:	xor    r8b,r8b
  40933a:	xor    r9b,r9b
  40933d:	xor    r10b,r10b
  409340:	mov    r11,rax
  409343:	call   40b950 <__swc_fn_7dafa2b1_000082_5cc7acfc>
  409348:	lea    rbx,[rsp+0x18]
  40934d:	mov    rcx,rbx
  409350:	call   40bf90 <__swc_fn_7dafa2b1_000097_93bfe675>
  409355:	lea    rcx,[rsi+0x10]
  409359:	mov    edx,0x400000
  40935e:	mov    r8,rbx
  409361:	call   4116e0 <__swc_fn_7dafa2b1_000164_8a3d304f>
  409366:	lea    rcx,[rsi+0x68]
  40936a:	mov    edx,0x4000
  40936f:	mov    r8,rbx
  409372:	call   4116e0 <__swc_fn_7dafa2b1_000164_8a3d304f>
  409377:	add    rsp,0x28
  40937b:	pop    r12
  40937d:	pop    rdi
  40937e:	pop    rsi
  40937f:	pop    rbx
  409380:	ret
	...

0000000000409390 <__swc_fn_7dafa2b1_000102_d0b19c14>:
  409390:	push   rbx
  409391:	push   rsi
  409392:	sub    rsp,0x18
  409396:	mov    rbx,rcx
  409399:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40939e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4093a4:	mov    rsi,QWORD PTR [rbx+0x70]
  4093a8:	lea    rcx,[rcx+0x18]
  4093ac:	call   40a210 <__swc_fn_7dafa2b1_000162_13ead2ff>
  4093b1:	lea    rcx,[rsp+0x8]
  4093b6:	mov    rdx,rbx
  4093b9:	mov    r8d,0x78
  4093bf:	call   410160 <__swc_fn_7dafa2b1_000101_d4bdcaa4>
  4093c4:	mov    rax,rsi
  4093c7:	add    rsp,0x18
  4093cb:	pop    rsi
  4093cc:	pop    rbx
  4093cd:	ret
	...

00000000004093d0 <__swc_fn_7dafa2b1_000105_3c3b96fb>:
  4093d0:	push   rsi
  4093d1:	push   rdi
  4093d2:	sub    rsp,0x8
  4093d6:	cmp    QWORD PTR [rcx],0x0
  4093da:	jne    4093e3 <__swc_fn_7dafa2b1_000105_3c3b96fb+0x13>
  4093dc:	add    rsp,0x8
  4093e0:	pop    rdi
  4093e1:	pop    rsi
  4093e2:	ret
  4093e3:	mov    rsi,QWORD PTR [rcx]
  4093e6:	mov    rax,QWORD PTR [rcx+0x8]
  4093ea:	test   rax,rax
  4093ed:	je     409403 <__swc_fn_7dafa2b1_000105_3c3b96fb+0x33>
  4093ef:	test   DWORD PTR [rax+0x28],0x400000
  4093f6:	je     409403 <__swc_fn_7dafa2b1_000105_3c3b96fb+0x33>
  4093f8:	mov    rcx,QWORD PTR [rax+0x30]
  4093fc:	test   rcx,rcx
  4093ff:	cmovne rax,rcx
  409403:	lea    rdx,[rip+0x8ee6]        # 4122f0 <__swc_rdata_base_7dafa2b1+0x1e0>
  40940a:	lea    rcx,[rip+0x8fc7]        # 4123d8 <__swc_rdata_base_7dafa2b1+0x2c8>
  409411:	mov    r8,rax
  409414:	xor    r9d,r9d
  409417:	xor    al,al
  409419:	mov    r10,rax
  40941c:	xor    r11d,r11d
  40941f:	call   4091d0 <__swc_fn_7dafa2b1_000093_14c65203>
  409424:	test   rax,rax
  409427:	je     409437 <__swc_fn_7dafa2b1_000105_3c3b96fb+0x67>
  409429:	mov    rdi,QWORD PTR [rax+0x48]
  40942d:	test   rdi,rdi
  409430:	je     409437 <__swc_fn_7dafa2b1_000105_3c3b96fb+0x67>
  409432:	mov    rcx,rsi
  409435:	call   rdi
  409437:	add    rsp,0x8
  40943b:	pop    rdi
  40943c:	pop    rsi
  40943d:	ret
	...

0000000000409440 <__swc_fn_7dafa2b1_000108_90faaa26>:
  409440:	push   rbx
  409441:	push   rsi
  409442:	push   rdi
  409443:	sub    rsp,0x20
  409447:	mov    rbx,rdx
  40944a:	mov    rsi,rcx
  40944d:	mov    rcx,QWORD PTR [rip+0x19bec]        # 423040 <__swc_bss_base_7dafa2b1>
  409454:	test   rcx,rcx
  409457:	jne    409469 <__swc_fn_7dafa2b1_000108_90faaa26+0x29>
  409459:	call   4119a0 <__swc_fn_7dafa2b1_000170_994c8876>
  40945e:	lea    rcx,[rax+0x1]
  409462:	mov    QWORD PTR [rip+0x19bd7],rcx        # 423040 <__swc_bss_base_7dafa2b1>
  409469:	dec    rcx
  40946c:	call   40e840 <__swc_fn_7dafa2b1_000172_360af05d>
  409471:	mov    rdi,rax
  409474:	mov    rax,QWORD PTR [rdi+0xbd0]
  40947b:	xor    ecx,ecx
  40947d:	test   rax,rax
  409480:	je     409485 <__swc_fn_7dafa2b1_000108_90faaa26+0x45>
  409482:	mov    rcx,QWORD PTR [rax]
  409485:	call   411ad0 <__swc_fn_7dafa2b1_000179_718d7b54>
  40948a:	lea    rax,[rsp+0x8]
  40948f:	lea    rcx,[rdi+0x9c8]
  409496:	mov    QWORD PTR [rsp+0x8],rcx
  40949b:	mov    QWORD PTR [rax+0x8],0x40
  4094a3:	xor    ecx,ecx
  4094a5:	mov    rdx,rax
  4094a8:	call   40cba0 <__swc_fn_7dafa2b1_000124_4f256d58>
  4094ad:	mov    DWORD PTR [rdi+0xbc8],eax
  4094b3:	mov    rdi,QWORD PTR [rdi+0x990]
  4094ba:	test   rdi,rdi
  4094bd:	je     4094c7 <__swc_fn_7dafa2b1_000108_90faaa26+0x87>
  4094bf:	mov    rcx,rsi
  4094c2:	mov    rdx,rbx
  4094c5:	call   rdi
  4094c7:	call   4091f0 <__swc_fn_7dafa2b1_000096_ad13d15c>
  4094cc:	test   al,al
  4094ce:	je     4094de <__swc_fn_7dafa2b1_000108_90faaa26+0x9e>
  4094d0:	mov    rcx,rsi
  4094d3:	mov    rdx,rbx
  4094d6:	xor    r8d,r8d
  4094d9:	call   410be0 <__swc_fn_7dafa2b1_000125_83db7238>
  4094de:	mov    rcx,rsi
  4094e1:	mov    rdx,rbx
  4094e4:	call   410260 <__swc_fn_7dafa2b1_000107_ffe51047>
  4094e9:	call   409a70 <__swc_fn_7dafa2b1_000123_be2e2f68>
  4094ee:	add    rsp,0x20
  4094f2:	pop    rdi
  4094f3:	pop    rsi
  4094f4:	pop    rbx
  4094f5:	ret
	...

0000000000409500 <__swc_fn_7dafa2b1_000111_3dc01326>:
  409500:	test   r8,r8
  409503:	jne    409508 <__swc_fn_7dafa2b1_000111_3dc01326+0x8>
  409505:	xor    eax,eax
  409507:	ret
  409508:	xor    eax,eax
  40950a:	nop    WORD PTR [rax+rax*1+0x0]
  409510:	mov    r9,r8
  409513:	sub    r9,rax
  409516:	cmp    r9,0x10
  40951a:	jb     409564 <__swc_fn_7dafa2b1_000111_3dc01326+0x64>
  40951c:	lea    r9,[rcx+rax*1]
  409520:	lea    r10,[rdx+rax*1]
  409524:	vmovups xmm0,XMMWORD PTR [r10]
  409529:	vmovups xmm1,XMMWORD PTR [r9]
  40952e:	vpcmpeqb xmm0,xmm1,xmm0
  409532:	vpmovmskb r9d,xmm0
  409536:	cmp    r9d,0xffff
  40953d:	je     40955e <__swc_fn_7dafa2b1_000111_3dc01326+0x5e>
  40953f:	not    r9d
  409542:	xor    r8d,r8d
  409545:	movzx  r9d,r9w
  409549:	tzcnt  r8d,r9d
  40954e:	add    rax,r8
  409551:	movzx  ecx,BYTE PTR [rcx+rax*1]
  409555:	movzx  eax,BYTE PTR [rdx+rax*1]
  409559:	sub    ecx,eax
  40955b:	mov    eax,ecx
  40955d:	ret
  40955e:	lea    rax,[rax+0x10]
  409562:	jmp    409510 <__swc_fn_7dafa2b1_000111_3dc01326+0x10>
  409564:	cmp    r9,0x8
  409568:	jb     4095db <__swc_fn_7dafa2b1_000111_3dc01326+0xdb>
  40956a:	lea    r9,[rcx+rax*1]
  40956e:	lea    r10,[rdx+rax*1]
  409572:	mov    r9,QWORD PTR [r9]
  409575:	xor    r9,QWORD PTR [r10]
  409578:	test   r9,r9
  40957b:	je     409599 <__swc_fn_7dafa2b1_000111_3dc01326+0x99>
  40957d:	xor    r8d,r8d
  409580:	tzcnt  r8,r9
  409585:	shr    r8,0x3
  409589:	add    rax,r8
  40958c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  409590:	movzx  eax,BYTE PTR [rdx+rax*1]
  409594:	sub    ecx,eax
  409596:	mov    eax,ecx
  409598:	ret
  409599:	lea    rax,[rax+0x8]
  40959d:	cmp    rax,r8
  4095a0:	jne    4095a5 <__swc_fn_7dafa2b1_000111_3dc01326+0xa5>
  4095a2:	xor    eax,eax
  4095a4:	ret
  4095a5:	lea    rax,[r8-0x8]
  4095a9:	lea    r8,[rcx+rax*1]
  4095ad:	lea    r9,[rdx+rax*1]
  4095b1:	mov    r8,QWORD PTR [r8]
  4095b4:	xor    r8,QWORD PTR [r9]
  4095b7:	test   r8,r8
  4095ba:	je     4095d8 <__swc_fn_7dafa2b1_000111_3dc01326+0xd8>
  4095bc:	xor    r9d,r9d
  4095bf:	tzcnt  r9,r8
  4095c4:	shr    r9,0x3
  4095c8:	add    rax,r9
  4095cb:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4095cf:	movzx  eax,BYTE PTR [rdx+rax*1]
  4095d3:	sub    ecx,eax
  4095d5:	mov    eax,ecx
  4095d7:	ret
  4095d8:	xor    eax,eax
  4095da:	ret
  4095db:	cmp    r9,0x4
  4095df:	jb     409652 <__swc_fn_7dafa2b1_000111_3dc01326+0x152>
  4095e1:	lea    r9,[rcx+rax*1]
  4095e5:	lea    r10,[rdx+rax*1]
  4095e9:	mov    r9d,DWORD PTR [r9]
  4095ec:	xor    r9d,DWORD PTR [r10]
  4095ef:	test   r9d,r9d
  4095f2:	je     409610 <__swc_fn_7dafa2b1_000111_3dc01326+0x110>
  4095f4:	xor    r8d,r8d
  4095f7:	tzcnt  r8,r9
  4095fc:	shr    r8,0x3
  409600:	add    rax,r8
  409603:	movzx  ecx,BYTE PTR [rcx+rax*1]
  409607:	movzx  eax,BYTE PTR [rdx+rax*1]
  40960b:	sub    ecx,eax
  40960d:	mov    eax,ecx
  40960f:	ret
  409610:	lea    rax,[rax+0x4]
  409614:	cmp    rax,r8
  409617:	jne    40961c <__swc_fn_7dafa2b1_000111_3dc01326+0x11c>
  409619:	xor    eax,eax
  40961b:	ret
  40961c:	lea    rax,[r8-0x4]
  409620:	lea    r8,[rcx+rax*1]
  409624:	lea    r9,[rdx+rax*1]
  409628:	mov    r8d,DWORD PTR [r8]
  40962b:	xor    r8d,DWORD PTR [r9]
  40962e:	test   r8d,r8d
  409631:	je     40964f <__swc_fn_7dafa2b1_000111_3dc01326+0x14f>
  409633:	xor    r9d,r9d
  409636:	tzcnt  r9,r8
  40963b:	shr    r9,0x3
  40963f:	add    rax,r9
  409642:	movzx  ecx,BYTE PTR [rcx+rax*1]
  409646:	movzx  eax,BYTE PTR [rdx+rax*1]
  40964a:	sub    ecx,eax
  40964c:	mov    eax,ecx
  40964e:	ret
  40964f:	xor    eax,eax
  409651:	ret
  409652:	cmp    r9,0x2
  409656:	jb     4096a9 <__swc_fn_7dafa2b1_000111_3dc01326+0x1a9>
  409658:	lea    r9,[rcx+rax*1]
  40965c:	lea    r10,[rdx+rax*1]
  409660:	mov    r9w,WORD PTR [r9]
  409664:	xor    r9w,WORD PTR [r10]
  409668:	test   r9w,r9w
  40966c:	je     40968e <__swc_fn_7dafa2b1_000111_3dc01326+0x18e>
  40966e:	xor    r8d,r8d
  409671:	movzx  r9d,r9w
  409675:	tzcnt  r8,r9
  40967a:	shr    r8,0x3
  40967e:	add    rax,r8
  409681:	movzx  ecx,BYTE PTR [rcx+rax*1]
  409685:	movzx  eax,BYTE PTR [rdx+rax*1]
  409689:	sub    ecx,eax
  40968b:	mov    eax,ecx
  40968d:	ret
  40968e:	lea    rax,[rax+0x2]
  409692:	cmp    rax,r8
  409695:	jne    40969a <__swc_fn_7dafa2b1_000111_3dc01326+0x19a>
  409697:	xor    eax,eax
  409699:	ret
  40969a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  4096a0:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  4096a6:	sub    eax,ecx
  4096a8:	ret
  4096a9:	test   r9,r9
  4096ac:	je     4096bb <__swc_fn_7dafa2b1_000111_3dc01326+0x1bb>
  4096ae:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4096b2:	movzx  eax,BYTE PTR [rdx+rax*1]
  4096b6:	sub    ecx,eax
  4096b8:	mov    eax,ecx
  4096ba:	ret
  4096bb:	xor    eax,eax
  4096bd:	ret
	...

00000000004096c0 <__swc_fn_7dafa2b1_000114_6b799b8d>:
  4096c0:	push   r12
  4096c2:	push   r13
  4096c4:	push   r14
  4096c6:	push   rdi
  4096c7:	push   rsi
  4096c8:	push   r15
  4096ca:	sub    rsp,0xd8
  4096d1:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  4096d7:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  4096dd:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  4096e3:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  4096e9:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  4096ef:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  4096f8:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  409701:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40970a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  409713:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40971c:	mov    r12,rcx
  40971f:	test   rcx,rcx
  409722:	je     40973e <__swc_fn_7dafa2b1_000114_6b799b8d+0x7e>
  409724:	mov    eax,r12d
  409727:	and    eax,0xfff
  40972d:	setne  al
  409730:	cmp    r12,0xffffffffffffefff
  409737:	seta   cl
  40973a:	or     al,cl
  40973c:	je     409745 <__swc_fn_7dafa2b1_000114_6b799b8d+0x85>
  40973e:	xor    eax,eax
  409740:	jmp    4097db <__swc_fn_7dafa2b1_000114_6b799b8d+0x11b>
  409745:	call   410900 <__swc_fn_7dafa2b1_000113_126150d1>
  40974a:	mov    r13,rax
  40974d:	test   rax,rax
  409750:	jne    409759 <__swc_fn_7dafa2b1_000114_6b799b8d+0x99>
  409752:	xor    eax,eax
  409754:	jmp    4097db <__swc_fn_7dafa2b1_000114_6b799b8d+0x11b>
  409759:	lea    r14,[r12+0x1000]
  409761:	xor    edi,edi
  409763:	mov    rsi,r14
  409766:	xor    edx,edx
  409768:	mov    ecx,0x22
  40976d:	mov    eax,0xffffffff
  409772:	movsxd r8,eax
  409775:	xor    r9d,r9d
  409778:	xor    eax,eax
  40977a:	call   407010 <mmap@plt>
  40977f:	mov    r15,rax
  409782:	cmp    rax,0xffffffffffffffff
  409786:	jne    40978c <__swc_fn_7dafa2b1_000114_6b799b8d+0xcc>
  409788:	xor    eax,eax
  40978a:	jmp    4097db <__swc_fn_7dafa2b1_000114_6b799b8d+0x11b>
  40978c:	mov    rdi,r15
  40978f:	mov    esi,0x1000
  409794:	mov    edx,0x3
  409799:	xor    eax,eax
  40979b:	call   407020 <mprotect@plt>
  4097a0:	test   eax,eax
  4097a2:	je     4097b5 <__swc_fn_7dafa2b1_000114_6b799b8d+0xf5>
  4097a4:	mov    rdi,r15
  4097a7:	mov    rsi,r14
  4097aa:	xor    eax,eax
  4097ac:	call   407030 <munmap@plt>
  4097b1:	xor    eax,eax
  4097b3:	jmp    4097db <__swc_fn_7dafa2b1_000114_6b799b8d+0x11b>
  4097b5:	mov    QWORD PTR [r15+0x8],r12
  4097b9:	mov    rcx,r13
  4097bc:	call   409e10 <__swc_fn_7dafa2b1_000138_8c07c14b>
  4097c1:	mov    rax,QWORD PTR [r13+0x8]
  4097c5:	mov    QWORD PTR [r15],rax
  4097c8:	mov    QWORD PTR [r13+0x8],r15
  4097cc:	mov    rcx,r13
  4097cf:	call   40cf40 <__swc_fn_7dafa2b1_000139_715e84ff>
  4097d4:	lea    rax,[r15+0x1000]
  4097db:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4097e1:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4097e7:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4097ed:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4097f3:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4097f9:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409802:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40980b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409814:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40981d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  409826:	add    rsp,0xd8
  40982d:	pop    r15
  40982f:	pop    rsi
  409830:	pop    rdi
  409831:	pop    r14
  409833:	pop    r13
  409835:	pop    r12
  409837:	ret
	...

0000000000409840 <__swc_fn_7dafa2b1_000117_e9fc0224>:
  409840:	push   rbx
  409841:	push   r12
  409843:	push   rdi
  409844:	push   rsi
  409845:	sub    rsp,0xa8
  40984c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409852:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409858:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40985e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409864:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40986a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409870:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409876:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40987c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409885:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40988e:	mov    rbx,rdx
  409891:	mov    r12,rcx
  409894:	mov    rdi,rcx
  409897:	mov    rsi,rdx
  40989a:	xor    edx,edx
  40989c:	xor    eax,eax
  40989e:	call   407020 <mprotect@plt>
  4098a3:	test   eax,eax
  4098a5:	jne    4098c9 <__swc_fn_7dafa2b1_000117_e9fc0224+0x89>
  4098a7:	mov    rcx,r12
  4098aa:	mov    rdx,rbx
  4098ad:	xor    al,al
  4098af:	mov    r8,rax
  4098b2:	call   40c9e0 <__swc_fn_7dafa2b1_000115_5f48311c>
  4098b7:	mov    rdi,r12
  4098ba:	mov    rsi,rbx
  4098bd:	mov    edx,0x4
  4098c2:	xor    eax,eax
  4098c4:	call   407040 <madvise@plt>
  4098c9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4098cf:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4098d5:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4098db:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4098e1:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4098e7:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4098ed:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4098f3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4098f9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409902:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40990b:	add    rsp,0xa8
  409912:	pop    rsi
  409913:	pop    rdi
  409914:	pop    r12
  409916:	pop    rbx
  409917:	ret
	...

0000000000409920 <__swc_fn_7dafa2b1_000120_d3318640>:
  409920:	push   rsi
  409921:	push   rdi
  409922:	push   r12
  409924:	push   r13
  409926:	push   r14
  409928:	sub    rsp,0xe0
  40992f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409935:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40993b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  409941:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409947:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40994d:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409956:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40995f:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409968:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  409971:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40997a:	mov    rsi,rdx
  40997d:	mov    rdi,rcx
  409980:	call   410900 <__swc_fn_7dafa2b1_000113_126150d1>
  409985:	mov    r12,rax
  409988:	test   rax,rax
  40998b:	jne    409992 <__swc_fn_7dafa2b1_000120_d3318640+0x72>
  40998d:	jmp    409a06 <__swc_fn_7dafa2b1_000120_d3318640+0xe6>
  409992:	mov    rcx,r12
  409995:	call   409e10 <__swc_fn_7dafa2b1_000138_8c07c14b>
  40999a:	lea    r13,[r12+0x8]
  40999f:	mov    rax,QWORD PTR [r13+0x0]
  4099a3:	test   rax,rax
  4099a6:	je     4099fe <__swc_fn_7dafa2b1_000120_d3318640+0xde>
  4099a8:	nop    DWORD PTR [rax+rax*1+0x0]
  4099b0:	lea    rcx,[rax+0x1000]
  4099b7:	cmp    rcx,rdi
  4099ba:	jne    4099f2 <__swc_fn_7dafa2b1_000120_d3318640+0xd2>
  4099bc:	cmp    QWORD PTR [rax+0x8],rsi
  4099c0:	je     4099cc <__swc_fn_7dafa2b1_000120_d3318640+0xac>
  4099c2:	mov    rcx,r12
  4099c5:	call   40cf40 <__swc_fn_7dafa2b1_000139_715e84ff>
  4099ca:	jmp    409a06 <__swc_fn_7dafa2b1_000120_d3318640+0xe6>
  4099cc:	mov    r14,QWORD PTR [rax]
  4099cf:	mov    rdi,rax
  4099d2:	lea    rsi,[rsi+0x1000]
  4099d9:	xor    eax,eax
  4099db:	call   407030 <munmap@plt>
  4099e0:	test   eax,eax
  4099e2:	jne    4099e8 <__swc_fn_7dafa2b1_000120_d3318640+0xc8>
  4099e4:	mov    QWORD PTR [r13+0x0],r14
  4099e8:	mov    rcx,r12
  4099eb:	call   40cf40 <__swc_fn_7dafa2b1_000139_715e84ff>
  4099f0:	jmp    409a06 <__swc_fn_7dafa2b1_000120_d3318640+0xe6>
  4099f2:	mov    r13,rax
  4099f5:	mov    rax,QWORD PTR [r13+0x0]
  4099f9:	test   rax,rax
  4099fc:	jne    4099b0 <__swc_fn_7dafa2b1_000120_d3318640+0x90>
  4099fe:	mov    rcx,r12
  409a01:	call   40cf40 <__swc_fn_7dafa2b1_000139_715e84ff>
  409a06:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  409a0c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  409a12:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  409a18:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  409a1e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  409a24:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409a2d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409a36:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409a3f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409a48:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  409a51:	add    rsp,0xe0
  409a58:	pop    r14
  409a5a:	pop    r13
  409a5c:	pop    r12
  409a5e:	pop    rdi
  409a5f:	pop    rsi
  409a60:	ret
	...

0000000000409a70 <__swc_fn_7dafa2b1_000123_be2e2f68>:
  409a70:	push   rdi
  409a71:	push   rsi
  409a72:	sub    rsp,0xa8
  409a79:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409a7f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409a85:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409a8b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409a91:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409a97:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409a9d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409aa3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409aa9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409ab2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409abb:	mov    rdi,0xfffffffffffffd66
  409ac2:	xor    eax,eax
  409ac4:	call   407050 <exit@plt>
  409ac9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409acf:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409ad5:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409adb:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409ae1:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409ae7:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409aed:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409af3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409af9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409b02:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409b0b:	add    rsp,0xa8
  409b12:	pop    rsi
  409b13:	pop    rdi
  409b14:	ret
	...

0000000000409b20 <__swc_fn_7dafa2b1_000126_540bf7e8>:
  409b20:	push   rbx
  409b21:	push   rsi
  409b22:	push   rdi
  409b23:	sub    rsp,0x30
  409b27:	mov    rbx,rdx
  409b2a:	mov    esi,ecx
  409b2c:	test   ecx,ecx
  409b2e:	je     409c03 <__swc_fn_7dafa2b1_000126_540bf7e8+0xe3>
  409b34:	mov    rcx,rsi
  409b37:	shl    rcx,0x4
  409b3b:	call   409030 <__swc_fn_7dafa2b1_000084_4a10c7e7>
  409b40:	test   rax,rax
  409b43:	je     409bf2 <__swc_fn_7dafa2b1_000126_540bf7e8+0xd2>
  409b49:	mov    rcx,rsi
  409b4c:	xor    edx,edx
  409b4e:	test   rsi,rsi
  409b51:	jbe    409bd2 <__swc_fn_7dafa2b1_000126_540bf7e8+0xb2>
  409b57:	nop    WORD PTR [rax+rax*1+0x0]
  409b60:	mov    r8d,edx
  409b63:	mov    r9,QWORD PTR [rbx+r8*8]
  409b67:	add    r8,r8
  409b6a:	lea    r8,[rax+r8*8]
  409b6e:	xor    r10d,r10d
  409b71:	test   r9,r9
  409b74:	je     409bb0 <__swc_fn_7dafa2b1_000126_540bf7e8+0x90>
  409b76:	mov    r11,r9
  409b79:	mov    dil,BYTE PTR [r11]
  409b7c:	test   dil,dil
  409b7f:	je     409bb0 <__swc_fn_7dafa2b1_000126_540bf7e8+0x90>
  409b81:	cs nop WORD PTR [rax+rax*1+0x0]
  409b8b:	cs nop WORD PTR [rax+rax*1+0x0]
  409b95:	cs nop WORD PTR [rax+rax*1+0x0]
  409b9f:	nop
  409ba0:	add    r11,0x1
  409ba4:	add    r10,0x1
  409ba8:	mov    dil,BYTE PTR [r11]
  409bab:	test   dil,dil
  409bae:	jne    409ba0 <__swc_fn_7dafa2b1_000126_540bf7e8+0x80>
  409bb0:	mov    QWORD PTR [rsp+0x18],r9
  409bb5:	mov    QWORD PTR [rsp+0x20],r10
  409bba:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409bc0:	vmovups XMMWORD PTR [r8],xmm0
  409bc5:	add    rdx,0x1
  409bc9:	cmp    rdx,rcx
  409bcc:	jb     409b60 <__swc_fn_7dafa2b1_000126_540bf7e8+0x40>
  409bd2:	lea    rcx,[rip+0x1c16f]        # 425d48 <__swc_bss_base_7dafa2b1+0x2d08>
  409bd9:	mov    QWORD PTR [rsp+0x8],rax
  409bde:	mov    esi,esi
  409be0:	mov    QWORD PTR [rsp+0x10],rsi
  409be5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409beb:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409bf0:	jmp    409c03 <__swc_fn_7dafa2b1_000126_540bf7e8+0xe3>
  409bf2:	lea    rcx,[rip+0x89ef]        # 4125e8 <__swc_rdata_base_7dafa2b1+0x4d8>
  409bf9:	call   40ca90 <__swc_fn_7dafa2b1_000121_2648f149>
  409bfe:	call   409a70 <__swc_fn_7dafa2b1_000123_be2e2f68>
  409c03:	add    rsp,0x30
  409c07:	pop    rdi
  409c08:	pop    rsi
  409c09:	pop    rbx
  409c0a:	ret
  409c0b:	add    BYTE PTR [rax],al
  409c0d:	add    BYTE PTR [rax],al
	...

0000000000409c10 <__swc_fn_7dafa2b1_000129_a481cb88>:
  409c10:	push   rdi
  409c11:	push   rsi
  409c12:	sub    rsp,0xa8
  409c19:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409c1f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409c25:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409c2b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409c31:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409c37:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409c3d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409c43:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409c49:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409c52:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409c5b:	mov    edi,ecx
  409c5d:	xor    eax,eax
  409c5f:	call   407060 <pthread_key_delete@plt>
  409c64:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409c6a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409c70:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409c76:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409c7c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409c82:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409c88:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409c8e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409c94:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409c9d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409ca6:	add    rsp,0xa8
  409cad:	pop    rsi
  409cae:	pop    rdi
  409caf:	ret

0000000000409cb0 <__swc_fn_7dafa2b1_000132_a611b8c4>:
  409cb0:	push   rdi
  409cb1:	push   rsi
  409cb2:	sub    rsp,0xa8
  409cb9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409cbf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409cc5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409ccb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409cd1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409cd7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409cdd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409ce3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409ce9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409cf2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409cfb:	test   rcx,rcx
  409cfe:	je     409d0f <__swc_fn_7dafa2b1_000132_a611b8c4+0x5f>
  409d00:	lea    rax,[rcx-0x1]
  409d04:	mov    eax,eax
  409d06:	mov    edi,eax
  409d08:	xor    eax,eax
  409d0a:	call   407060 <pthread_key_delete@plt>
  409d0f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409d15:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409d1b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409d21:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409d27:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409d2d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409d33:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409d39:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409d3f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409d48:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409d51:	add    rsp,0xa8
  409d58:	pop    rsi
  409d59:	pop    rdi
  409d5a:	ret
  409d5b:	add    BYTE PTR [rax],al
  409d5d:	add    BYTE PTR [rax],al
	...

0000000000409d60 <__swc_fn_7dafa2b1_000135_a9c1c700>:
  409d60:	push   rsi
  409d61:	push   rdi
  409d62:	sub    rsp,0xa8
  409d69:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409d6f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409d75:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409d7b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409d81:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409d87:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409d8d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409d93:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409d99:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409da2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409dab:	xor    eax,eax
  409dad:	call   407070 <gettid@plt>
  409db2:	movsxd rax,eax
  409db5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409dbb:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409dc1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409dc7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409dcd:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409dd3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409dd9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409ddf:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409de5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409dee:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409df7:	add    rsp,0xa8
  409dfe:	pop    rdi
  409dff:	pop    rsi
  409e00:	ret
	...

0000000000409e10 <__swc_fn_7dafa2b1_000138_8c07c14b>:
  409e10:	push   rbx
  409e11:	push   rdi
  409e12:	push   rsi
  409e13:	sub    rsp,0xc0
  409e1a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409e20:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409e26:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409e2c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409e32:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409e38:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409e3e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409e44:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409e4d:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409e56:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409e5f:	mov    rbx,rcx
  409e62:	cs nop WORD PTR [rax+rax*1+0x0]
  409e6c:	nop    DWORD PTR [rax+0x0]
  409e70:	mov    edx,0x80000000
  409e75:	xor    eax,eax
  409e77:	lock cmpxchg DWORD PTR [rbx],edx
  409e7b:	test   eax,eax
  409e7d:	je     409eb4 <__swc_fn_7dafa2b1_000138_8c07c14b+0xa4>
  409e7f:	mov    eax,DWORD PTR [rbx]
  409e81:	lea    rcx,[rsp+0x14]
  409e86:	mov    DWORD PTR [rsp+0x14],eax
  409e8a:	test   eax,eax
  409e8c:	je     409e70 <__swc_fn_7dafa2b1_000138_8c07c14b+0x60>
  409e8e:	mov    QWORD PTR [rsp],0x0
  409e96:	mov    edi,0xca
  409e9b:	mov    rsi,rbx
  409e9e:	mov    edx,0x80
  409ea3:	mov    ecx,DWORD PTR [rcx]
  409ea5:	xor    r8d,r8d
  409ea8:	xor    r9d,r9d
  409eab:	xor    eax,eax
  409ead:	call   407080 <syscall@plt>
  409eb2:	jmp    409e70 <__swc_fn_7dafa2b1_000138_8c07c14b+0x60>
  409eb4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409eba:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409ec0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409ec6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409ecc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409ed2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409ed8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409ede:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409ee7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409ef0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409ef9:	add    rsp,0xc0
  409f00:	pop    rsi
  409f01:	pop    rdi
  409f02:	pop    rbx
  409f03:	ret
	...

0000000000409f10 <__swc_fn_7dafa2b1_000141_055b38a4>:
  409f10:	sub    rsp,0x8
  409f14:	call   40cf40 <__swc_fn_7dafa2b1_000139_715e84ff>
  409f19:	add    rsp,0x8
  409f1d:	ret
	...

0000000000409f20 <__swc_fn_7dafa2b1_000144_d299b428>:
  409f20:	push   rdi
  409f21:	push   rsi
  409f22:	sub    rsp,0xa8
  409f29:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409f2f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409f35:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409f3b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409f41:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409f47:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409f4d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409f53:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409f59:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409f62:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409f6b:	mov    edi,0x28
  409f70:	xor    eax,eax
  409f72:	call   407090 <malloc@plt>
  409f77:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409f7d:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409f83:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409f89:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409f8f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409f95:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409f9b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409fa1:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409fa7:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409fb0:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409fb9:	add    rsp,0xa8
  409fc0:	pop    rsi
  409fc1:	pop    rdi
  409fc2:	ret
	...

0000000000409fd0 <__swc_fn_7dafa2b1_000147_162f363d>:
  409fd0:	mov    QWORD PTR [r8],0x0
  409fd7:	cmp    rdx,0x10
  409fdb:	jae    409fe0 <__swc_fn_7dafa2b1_000147_162f363d+0x10>
  409fdd:	xor    eax,eax
  409fdf:	ret
  409fe0:	mov    eax,DWORD PTR [rcx]
  409fe2:	cmp    eax,0x42445753
  409fe8:	jne    409ff2 <__swc_fn_7dafa2b1_000147_162f363d+0x22>
  409fea:	mov    eax,DWORD PTR [rcx+0x4]
  409fed:	cmp    eax,0x1
  409ff0:	je     409ff5 <__swc_fn_7dafa2b1_000147_162f363d+0x25>
  409ff2:	xor    eax,eax
  409ff4:	ret
  409ff5:	mov    QWORD PTR [r8],rdx
  409ff8:	mov    rax,rcx
  409ffb:	ret
  409ffc:	add    BYTE PTR [rax],al
	...

000000000040a000 <__swc_fn_7dafa2b1_000150_2eb804cc>:
  40a000:	push   rbx
  40a001:	sub    rsp,0xe0
  40a008:	lea    rbx,[rsp+0x8]
  40a00d:	vxorps xmm0,xmm0,xmm0
  40a011:	vmovups YMMWORD PTR [rbx],ymm0
  40a015:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40a01a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40a01f:	vzeroupper
  40a022:	mov    DWORD PTR [rbx+0x60],0x0
  40a029:	mov    r8,rbx
  40a02c:	mov    rdx,rcx
  40a02f:	nop
  40a030:	mov    r9,rdx
  40a033:	movabs rdx,0x6666666666666667
  40a03d:	mov    rax,r9
  40a040:	imul   rdx
  40a043:	sar    rdx,0x2
  40a047:	mov    r10,rdx
  40a04a:	shr    rdx,0x3f
  40a04e:	add    r10,rdx
  40a051:	mov    rdx,r10
  40a054:	imul   r11,r10,0xa
  40a058:	sub    r9,r11
  40a05b:	mov    r11,QWORD PTR [rip+0x85a6]        # 412608 <__swc_rdata_base_7dafa2b1+0x4f8>
  40a062:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40a067:	mov    BYTE PTR [r8],r9b
  40a06a:	lea    r9,[r8+0x1]
  40a06e:	mov    r8,r9
  40a071:	test   r10,r10
  40a074:	jne    40a030 <__swc_fn_7dafa2b1_000150_2eb804cc+0x30>
  40a076:	test   rcx,rcx
  40a079:	jge    40a083 <__swc_fn_7dafa2b1_000150_2eb804cc+0x83>
  40a07b:	mov    BYTE PTR [r9],0x2d
  40a07f:	add    r8,0x1
  40a083:	mov    BYTE PTR [r8],0x0
  40a087:	sub    r8,0x1
  40a08b:	mov    rax,rbx
  40a08e:	cmp    rax,r8
  40a091:	jae    40a0b6 <__swc_fn_7dafa2b1_000150_2eb804cc+0xb6>
  40a093:	cs nop WORD PTR [rax+rax*1+0x0]
  40a09d:	nop    DWORD PTR [rax]
  40a0a0:	mov    cl,BYTE PTR [r8]
  40a0a3:	mov    dl,BYTE PTR [rax]
  40a0a5:	mov    BYTE PTR [r8],dl
  40a0a8:	sub    r8,0x1
  40a0ac:	mov    BYTE PTR [rax],cl
  40a0ae:	inc    rax
  40a0b1:	cmp    rax,r8
  40a0b4:	jb     40a0a0 <__swc_fn_7dafa2b1_000150_2eb804cc+0xa0>
  40a0b6:	xor    eax,eax
  40a0b8:	test   rbx,rbx
  40a0bb:	je     40a0de <__swc_fn_7dafa2b1_000150_2eb804cc+0xde>
  40a0bd:	mov    rcx,rbx
  40a0c0:	mov    dl,BYTE PTR [rcx]
  40a0c2:	test   dl,dl
  40a0c4:	je     40a0de <__swc_fn_7dafa2b1_000150_2eb804cc+0xde>
  40a0c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a0d0:	add    rcx,0x1
  40a0d4:	add    rax,0x1
  40a0d8:	mov    dl,BYTE PTR [rcx]
  40a0da:	test   dl,dl
  40a0dc:	jne    40a0d0 <__swc_fn_7dafa2b1_000150_2eb804cc+0xd0>
  40a0de:	mov    QWORD PTR [rbx+0xa8],rbx
  40a0e5:	mov    QWORD PTR [rbx+0xb0],rax
  40a0ec:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40a0f4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40a0fc:	lea    rcx,[rbx+0xb8]
  40a103:	call   40ca90 <__swc_fn_7dafa2b1_000121_2648f149>
  40a108:	add    rsp,0xe0
  40a10f:	pop    rbx
  40a110:	ret
	...

000000000040a120 <__swc_fn_7dafa2b1_000153_86f1d437>:
  40a120:	vxorps xmm0,xmm0,xmm0
  40a124:	vmovups XMMWORD PTR [rcx],xmm0
  40a128:	mov    QWORD PTR [rcx+0x10],0x0
  40a130:	ret
	...

000000000040a140 <__swc_fn_7dafa2b1_000156_86f1d437>:
  40a140:	vxorps xmm0,xmm0,xmm0
  40a144:	vmovups XMMWORD PTR [rcx],xmm0
  40a148:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a14d:	vxorps xmm0,xmm0,xmm0
  40a151:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a156:	vmovups xmm0,XMMWORD PTR [rip+0x85aa]        # 412708 <__swc_rdata_base_7dafa2b1+0x5f8>
  40a15e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a163:	vxorps xmm0,xmm0,xmm0
  40a167:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a16c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40a171:	mov    QWORD PTR [rcx+0x60],0x0
  40a179:	ret
  40a17a:	add    BYTE PTR [rax],al
  40a17c:	add    BYTE PTR [rax],al
	...

000000000040a180 <__swc_fn_7dafa2b1_000159_86f1d437>:
  40a180:	vxorps xmm0,xmm0,xmm0
  40a184:	vmovups XMMWORD PTR [rcx],xmm0
  40a188:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a18d:	vxorps xmm0,xmm0,xmm0
  40a191:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a196:	vmovups xmm0,XMMWORD PTR [rip+0x8692]        # 412830 <__swc_rdata_base_7dafa2b1+0x720>
  40a19e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a1a3:	vxorps xmm0,xmm0,xmm0
  40a1a7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a1ac:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40a1b1:	vxorps xmm0,xmm0,xmm0
  40a1b5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40a1ba:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40a1bf:	vxorps xmm0,xmm0,xmm0
  40a1c3:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40a1cb:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40a1d3:	vxorps xmm0,xmm0,xmm0
  40a1d7:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40a1df:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40a1e7:	vxorps xmm0,xmm0,xmm0
  40a1eb:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40a1f3:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40a1fb:	mov    QWORD PTR [rcx+0xe0],0x0
  40a206:	ret
	...

000000000040a210 <__swc_fn_7dafa2b1_000162_13ead2ff>:
  40a210:	push   rbx
  40a211:	mov    rbx,rcx
  40a214:	call   40e4d0 <__swc_fn_7dafa2b1_000163_e36363a8>
  40a219:	mov    rax,QWORD PTR [rbx+0x10]
  40a21d:	test   rax,rax
  40a220:	je     40a231 <__swc_fn_7dafa2b1_000162_13ead2ff+0x21>
  40a222:	mov    rcx,rbx
  40a225:	mov    rdx,rax
  40a228:	mov    r8,QWORD PTR [rbx+0x18]
  40a22c:	call   411690 <__swc_fn_7dafa2b1_000161_47b270e1>
  40a231:	vxorps xmm0,xmm0,xmm0
  40a235:	vmovups XMMWORD PTR [rbx],xmm0
  40a239:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a23e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a243:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40a248:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40a24d:	mov    QWORD PTR [rbx+0x50],0x0
  40a255:	pop    rbx
  40a256:	ret
	...

000000000040a260 <__swc_fn_7dafa2b1_000165_72795826>:
  40a260:	sub    rsp,0x10
  40a264:	mov    eax,r8d
  40a267:	mov    r8d,r9d
  40a26a:	test   r9d,r9d
  40a26d:	jne    40a286 <__swc_fn_7dafa2b1_000165_72795826+0x26>
  40a26f:	vmovups xmm0,XMMWORD PTR [rip+0x8671]        # 4128e8 <__swc_rdata_base_7dafa2b1+0x7d8>
  40a277:	vmovups XMMWORD PTR [r10],xmm0
  40a27c:	mov    eax,0x1
  40a281:	add    rsp,0x10
  40a285:	ret
  40a286:	mov    r9,r8
  40a289:	cmp    r8,rax
  40a28c:	jb     40a293 <__swc_fn_7dafa2b1_000165_72795826+0x33>
  40a28e:	cmp    r9,rdx
  40a291:	jb     40a29a <__swc_fn_7dafa2b1_000165_72795826+0x3a>
  40a293:	xor    eax,eax
  40a295:	add    rsp,0x10
  40a299:	ret
  40a29a:	xor    eax,eax
  40a29c:	lea    r8,[r9+rax*1]
  40a2a0:	cmp    r8,rdx
  40a2a3:	jae    40a2d3 <__swc_fn_7dafa2b1_000165_72795826+0x73>
  40a2a5:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2af:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2b9:	nop    DWORD PTR [rax+0x0]
  40a2c0:	cmp    BYTE PTR [rcx+r8*1],0x0
  40a2c5:	je     40a2d3 <__swc_fn_7dafa2b1_000165_72795826+0x73>
  40a2c7:	inc    rax
  40a2ca:	lea    r8,[r9+rax*1]
  40a2ce:	cmp    r8,rdx
  40a2d1:	jb     40a2c0 <__swc_fn_7dafa2b1_000165_72795826+0x60>
  40a2d3:	cmp    r8,rdx
  40a2d6:	jne    40a2df <__swc_fn_7dafa2b1_000165_72795826+0x7f>
  40a2d8:	xor    eax,eax
  40a2da:	add    rsp,0x10
  40a2de:	ret
  40a2df:	add    rcx,r9
  40a2e2:	mov    QWORD PTR [rsp],rcx
  40a2e6:	mov    QWORD PTR [rsp+0x8],rax
  40a2eb:	vmovups xmm0,XMMWORD PTR [rsp]
  40a2f0:	vmovups XMMWORD PTR [r10],xmm0
  40a2f5:	mov    eax,0x1
  40a2fa:	add    rsp,0x10
  40a2fe:	ret
	...

000000000040a300 <__swc_fn_7dafa2b1_000168_bcc835b8>:
  40a300:	push   rbp
  40a301:	push   rbx
  40a302:	push   rsi
  40a303:	push   rdi
  40a304:	push   r12
  40a306:	push   r13
  40a308:	push   r14
  40a30a:	push   r15
  40a30c:	sub    rsp,0x10
  40a310:	mov    rbp,rsp
  40a313:	vmovups XMMWORD PTR [rsp],xmm6
  40a318:	sub    rsp,0x50
  40a31c:	mov    rbx,rsp
  40a31f:	mov    rsi,r8
  40a322:	mov    QWORD PTR [rsp+0x30],r8
  40a327:	mov    rdi,rcx
  40a32a:	mov    QWORD PTR [rsp+0x38],rcx
  40a32f:	mov    r12,rdx
  40a332:	xor    r13b,r13b
  40a335:	mov    r14,QWORD PTR [rdi+0x8]
  40a339:	mov    QWORD PTR [rsp+0x40],r14
  40a33e:	xor    r15d,r15d
  40a341:	test   r14,r14
  40a344:	jbe    40a59e <__swc_fn_7dafa2b1_000168_bcc835b8+0x29e>
  40a34a:	mov    r14,QWORD PTR [rdi]
  40a34d:	mov    rax,QWORD PTR [rsp+0x40]
  40a352:	mov    QWORD PTR [rsp+0x48],r14
  40a357:	vmovups xmm6,XMMWORD PTR [rip+0x81a1]        # 412500 <__swc_rdata_base_7dafa2b1+0x3f0>
  40a35f:	nop
  40a360:	cmp    QWORD PTR [r14+r15*8],0x0
  40a365:	jne    40a36f <__swc_fn_7dafa2b1_000168_bcc835b8+0x6f>
  40a367:	mov    r14,rax
  40a36a:	jmp    40a57e <__swc_fn_7dafa2b1_000168_bcc835b8+0x27e>
  40a36f:	mov    rcx,QWORD PTR [rdi]
  40a372:	mov    rdx,QWORD PTR [rcx+r15*8]
  40a376:	mov    rdi,rbx
  40a379:	mov    rcx,rdi
  40a37c:	sub    rsp,0x8
  40a380:	mov    r14,rax
  40a383:	call   411710 <__swc_fn_7dafa2b1_000167_cc119975>
  40a388:	add    rsp,0x8
  40a38c:	mov    al,BYTE PTR [rbx]
  40a38e:	test   al,al
  40a390:	je     40a57e <__swc_fn_7dafa2b1_000168_bcc835b8+0x27e>
  40a396:	mov    al,BYTE PTR [rbx+0x1]
  40a399:	test   al,al
  40a39b:	jne    40a3a6 <__swc_fn_7dafa2b1_000168_bcc835b8+0xa6>
  40a39d:	test   sil,sil
  40a3a0:	je     40a57e <__swc_fn_7dafa2b1_000168_bcc835b8+0x27e>
  40a3a6:	test   r13b,r13b
  40a3a9:	jne    40a467 <__swc_fn_7dafa2b1_000168_bcc835b8+0x167>
  40a3af:	test   r12,r12
  40a3b2:	je     40a467 <__swc_fn_7dafa2b1_000168_bcc835b8+0x167>
  40a3b8:	mov    al,BYTE PTR [rbx+0x1]
  40a3bb:	test   al,al
  40a3bd:	je     40a57e <__swc_fn_7dafa2b1_000168_bcc835b8+0x27e>
  40a3c3:	mov    eax,DWORD PTR [rbx+0x28]
  40a3c6:	cmp    DWORD PTR [r12+0x20],eax
  40a3cb:	jne    40a57e <__swc_fn_7dafa2b1_000168_bcc835b8+0x27e>
  40a3d1:	mov    rax,QWORD PTR [r12]
  40a3d5:	mov    rcx,QWORD PTR [r12+0x8]
  40a3da:	cmp    QWORD PTR [rbx+0x20],rcx
  40a3de:	jne    40a57e <__swc_fn_7dafa2b1_000168_bcc835b8+0x27e>
  40a3e4:	mov    cl,0x1
  40a3e6:	test   rax,rax
  40a3e9:	je     40a452 <__swc_fn_7dafa2b1_000168_bcc835b8+0x152>
  40a3ef:	mov    rdx,QWORD PTR [rbx+0x20]
  40a3f3:	xor    r8d,r8d
  40a3f6:	test   rdx,rdx
  40a3f9:	jbe    40a452 <__swc_fn_7dafa2b1_000168_bcc835b8+0x152>
  40a3fb:	mov    r9,QWORD PTR [rbx+0x18]
  40a3ff:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40a404:	cs nop WORD PTR [rax+rax*1+0x0]
  40a40e:	xchg   ax,ax
  40a410:	mov    r10b,BYTE PTR [rax+r8*1]
  40a414:	cmp    BYTE PTR [r9+r8*1],r10b
  40a418:	je     40a449 <__swc_fn_7dafa2b1_000168_bcc835b8+0x149>
  40a41a:	vmovq  r10,xmm0
  40a41f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40a424:	jne    40a42d <__swc_fn_7dafa2b1_000168_bcc835b8+0x12d>
  40a426:	cmp    BYTE PTR [rax+r8*1],0x2f
  40a42b:	je     40a449 <__swc_fn_7dafa2b1_000168_bcc835b8+0x149>
  40a42d:	vmovq  r10,xmm0
  40a432:	cmp    BYTE PTR [r10+r8*1],0x2f
  40a437:	jne    40a440 <__swc_fn_7dafa2b1_000168_bcc835b8+0x140>
  40a439:	cmp    BYTE PTR [rax+r8*1],0x5c
  40a43e:	je     40a449 <__swc_fn_7dafa2b1_000168_bcc835b8+0x149>
  40a440:	xor    eax,eax
  40a442:	movzx  eax,al
  40a445:	mov    cl,al
  40a447:	jmp    40a452 <__swc_fn_7dafa2b1_000168_bcc835b8+0x152>
  40a449:	add    r8,0x1
  40a44d:	cmp    r8,rdx
  40a450:	jb     40a410 <__swc_fn_7dafa2b1_000168_bcc835b8+0x110>
  40a452:	test   cl,cl
  40a454:	je     40a57e <__swc_fn_7dafa2b1_000168_bcc835b8+0x27e>
  40a45a:	mov    eax,0x1
  40a45f:	mov    r13b,al
  40a462:	jmp    40a57e <__swc_fn_7dafa2b1_000168_bcc835b8+0x27e>
  40a467:	mov    r13b,0x1
  40a46a:	sub    rsp,0x20
  40a46e:	mov    rax,rsp
  40a471:	lea    rcx,[rdi+0x8]
  40a475:	mov    QWORD PTR [rax],rcx
  40a478:	lea    rsi,[rip+0x7ca1]        # 412120 <__swc_rdata_base_7dafa2b1+0x10>
  40a47f:	mov    QWORD PTR [rax+0x8],rsi
  40a483:	mov    QWORD PTR [rax+0x10],rsp
  40a487:	mov    QWORD PTR [rax+0x18],0x1
  40a48f:	lea    rcx,[rsp+0x10]
  40a494:	sub    rsp,0x8
  40a498:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  40a49d:	add    rsp,0x8
  40a4a1:	add    rsp,0x20
  40a4a5:	mov    al,BYTE PTR [rbx+0x1]
  40a4a8:	test   al,al
  40a4aa:	je     40a547 <__swc_fn_7dafa2b1_000168_bcc835b8+0x247>
  40a4b0:	lea    rax,[rip+0x84d1]        # 412988 <__swc_rdata_base_7dafa2b1+0x878>
  40a4b7:	sub    rsp,0x20
  40a4bb:	mov    rcx,rsp
  40a4be:	mov    QWORD PTR [rcx],rax
  40a4c1:	mov    QWORD PTR [rcx+0x8],rsi
  40a4c5:	mov    QWORD PTR [rcx+0x10],rsp
  40a4c9:	mov    QWORD PTR [rcx+0x18],0x1
  40a4d1:	lea    rcx,[rsp+0x10]
  40a4d6:	sub    rsp,0x8
  40a4da:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  40a4df:	add    rsp,0x8
  40a4e3:	add    rsp,0x20
  40a4e7:	mov    eax,DWORD PTR [rbx+0x28]
  40a4ea:	sub    rsp,0x60
  40a4ee:	mov    rcx,rsp
  40a4f1:	lea    rdx,[rdi+0x18]
  40a4f5:	mov    QWORD PTR [rcx+0x18],rdx
  40a4f9:	mov    QWORD PTR [rcx+0x20],rsi
  40a4fd:	vmovups XMMWORD PTR [rcx],xmm6
  40a501:	mov    QWORD PTR [rcx+0x28],rsp
  40a505:	mov    QWORD PTR [rcx+0x30],rsi
  40a509:	mov    DWORD PTR [rcx+0x10],eax
  40a50c:	lea    rax,[rsp+0x10]
  40a511:	mov    QWORD PTR [rcx+0x38],rax
  40a515:	lea    rax,[rip+0x7f7c]        # 412498 <__swc_rdata_base_7dafa2b1+0x388>
  40a51c:	mov    QWORD PTR [rcx+0x40],rax
  40a520:	lea    rax,[rsp+0x18]
  40a525:	mov    QWORD PTR [rcx+0x48],rax
  40a529:	mov    QWORD PTR [rcx+0x50],0x3
  40a531:	lea    rcx,[rsp+0x48]
  40a536:	sub    rsp,0x8
  40a53a:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  40a53f:	add    rsp,0x8
  40a543:	add    rsp,0x60
  40a547:	lea    rax,[rip+0x7bc2]        # 412110 <__swc_rdata_base_7dafa2b1>
  40a54e:	sub    rsp,0x20
  40a552:	mov    rcx,rsp
  40a555:	mov    QWORD PTR [rcx],rax
  40a558:	mov    QWORD PTR [rcx+0x8],rsi
  40a55c:	mov    QWORD PTR [rcx+0x10],rsp
  40a560:	mov    QWORD PTR [rcx+0x18],0x1
  40a568:	lea    rcx,[rsp+0x10]
  40a56d:	sub    rsp,0x8
  40a571:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  40a576:	add    rsp,0x8
  40a57a:	add    rsp,0x20
  40a57e:	add    r15,0x1
  40a582:	cmp    r15,r14
  40a585:	jae    40a59e <__swc_fn_7dafa2b1_000168_bcc835b8+0x29e>
  40a587:	mov    rsi,QWORD PTR [rsp+0x30]
  40a58c:	mov    rdi,QWORD PTR [rsp+0x38]
  40a591:	mov    rax,r14
  40a594:	mov    r14,QWORD PTR [rsp+0x48]
  40a599:	jmp    40a360 <__swc_fn_7dafa2b1_000168_bcc835b8+0x60>
  40a59e:	add    rsp,0x50
  40a5a2:	vmovups xmm6,XMMWORD PTR [rsp]
  40a5a7:	add    rsp,0x10
  40a5ab:	pop    r15
  40a5ad:	pop    r14
  40a5af:	pop    r13
  40a5b1:	pop    r12
  40a5b3:	pop    rdi
  40a5b4:	pop    rsi
  40a5b5:	pop    rbx
  40a5b6:	pop    rbp
  40a5b7:	ret
	...

000000000040a5c0 <__swc_fn_7dafa2b1_000171_646fdf20>:
  40a5c0:	sub    rsp,0x8
  40a5c4:	call   40cd10 <__swc_fn_7dafa2b1_000130_4bbe3f14>
  40a5c9:	add    rsp,0x8
  40a5cd:	ret
	...

000000000040a5d0 <__swc_fn_7dafa2b1_000174_1e0ea8cf>:
  40a5d0:	push   rsi
  40a5d1:	sub    rsp,0x30
  40a5d5:	lea    rsi,[rip+0x1b7bc]        # 425d98 <__swc_bss_base_7dafa2b1+0x2d58>
  40a5dc:	mov    rax,QWORD PTR [rsi]
  40a5df:	test   rax,rax
  40a5e2:	je     40a5ea <__swc_fn_7dafa2b1_000174_1e0ea8cf+0x1a>
  40a5e4:	add    rsp,0x30
  40a5e8:	pop    rsi
  40a5e9:	ret
  40a5ea:	mov    ecx,0x2
  40a5ef:	mov    edx,0x8020
  40a5f4:	call   40c3b0 <__swc_fn_7dafa2b1_000112_6814119b>
  40a5f9:	test   rax,rax
  40a5fc:	jne    40a60d <__swc_fn_7dafa2b1_000174_1e0ea8cf+0x3d>
  40a5fe:	mov    QWORD PTR [rsp+0x18],rax
  40a603:	call   409a70 <__swc_fn_7dafa2b1_000123_be2e2f68>
  40a608:	mov    rax,QWORD PTR [rsp+0x18]
  40a60d:	mov    rcx,rax
  40a610:	xchg   QWORD PTR [rsi],rcx
  40a613:	add    rsp,0x30
  40a617:	pop    rsi
  40a618:	ret
  40a619:	add    BYTE PTR [rax],al
  40a61b:	add    BYTE PTR [rax],al
  40a61d:	add    BYTE PTR [rax],al
	...

000000000040a620 <__swc_fn_7dafa2b1_000177_4de704de>:
  40a620:	push   rsi
  40a621:	test   r8,r8
  40a624:	jne    40a628 <__swc_fn_7dafa2b1_000177_4de704de+0x8>
  40a626:	pop    rsi
  40a627:	ret
  40a628:	lea    rax,[rcx+0x18]
  40a62c:	mov    r10,QWORD PTR [rax]
  40a62f:	lea    r11,[r10+0x1]
  40a633:	mov    QWORD PTR [rax],r11
  40a636:	mov    r11,rdx
  40a639:	not    rdx
  40a63c:	lea    rsi,[r8-0x1]
  40a640:	cmp    rsi,rdx
  40a643:	ja     40a663 <__swc_fn_7dafa2b1_000177_4de704de+0x43>
  40a645:	lea    rdx,[r11+r8*1]
  40a649:	dec    rdx
  40a64c:	shr    rdx,0x6
  40a650:	mov    r8,r11
  40a653:	shr    r8,0x6
  40a657:	mov    rsi,rdx
  40a65a:	sub    rsi,r8
  40a65d:	cmp    rsi,0x8
  40a661:	jb     40a679 <__swc_fn_7dafa2b1_000177_4de704de+0x59>
  40a663:	lea    rcx,[rcx+0x10]
  40a667:	mov    rdx,QWORD PTR [rcx]
  40a66a:	add    rdx,r9
  40a66d:	mov    QWORD PTR [rcx],rdx
  40a670:	lea    rcx,[r10+0x2]
  40a674:	mov    QWORD PTR [rax],rcx
  40a677:	pop    rsi
  40a678:	ret
  40a679:	shr    r11,0x6
  40a67d:	nop    DWORD PTR [rax]
  40a680:	cmp    r11,rdx
  40a683:	ja     40a6c3 <__swc_fn_7dafa2b1_000177_4de704de+0xa3>
  40a685:	jmp    40a696 <__swc_fn_7dafa2b1_000177_4de704de+0x76>
  40a687:	nop    WORD PTR [rax+rax*1+0x0]
  40a690:	add    r11,0x1
  40a694:	jmp    40a680 <__swc_fn_7dafa2b1_000177_4de704de+0x60>
  40a696:	mov    r8,r11
  40a699:	shr    r8,0xc
  40a69d:	mov    rsi,r11
  40a6a0:	xor    rsi,r8
  40a6a3:	mov    r8,r11
  40a6a6:	shr    r8,0x18
  40a6aa:	xor    rsi,r8
  40a6ad:	and    esi,0xfff
  40a6b3:	lea    r8,[rcx+rsi*8+0x20]
  40a6b8:	mov    rsi,QWORD PTR [r8]
  40a6bb:	add    rsi,r9
  40a6be:	mov    QWORD PTR [r8],rsi
  40a6c1:	jmp    40a690 <__swc_fn_7dafa2b1_000177_4de704de+0x70>
  40a6c3:	lea    rcx,[r10+0x2]
  40a6c7:	mov    QWORD PTR [rax],rcx
  40a6ca:	pop    rsi
  40a6cb:	ret
	...

000000000040a6e0 <__swc_fn_7dafa2b1_000001_cb8588f1>:
  40a6e0:	push   rsi
  40a6e1:	push   rdi
  40a6e2:	sub    rsp,0x8
  40a6e6:	mov    rax,QWORD PTR [rcx]
  40a6e9:	test   rax,rax
  40a6ec:	jne    40a6fa <__swc_fn_7dafa2b1_000001_cb8588f1+0x1a>
  40a6ee:	mov    eax,0x1
  40a6f3:	add    rsp,0x8
  40a6f7:	pop    rdi
  40a6f8:	pop    rsi
  40a6f9:	ret
  40a6fa:	mov    rsi,QWORD PTR [rcx+0x8]
  40a6fe:	mov    rcx,rax
  40a701:	call   40a6e0 <__swc_fn_7dafa2b1_000001_cb8588f1>
  40a706:	mov    rdi,rax
  40a709:	mov    rcx,rsi
  40a70c:	call   40a6e0 <__swc_fn_7dafa2b1_000001_cb8588f1>
  40a711:	lea    rax,[rdi+rax*1+0x1]
  40a716:	add    rsp,0x8
  40a71a:	pop    rdi
  40a71b:	pop    rsi
  40a71c:	ret
  40a71d:	add    BYTE PTR [rax],al
	...

000000000040a720 <__swc_fn_7dafa2b1_000004_1ca87929>:
  40a720:	push   rdi
  40a721:	push   rsi
  40a722:	sub    rsp,0xb8
  40a729:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a72f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a735:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a73b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a741:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a747:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a74d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a753:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a75c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a765:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a76e:	vxorps xmm0,xmm0,xmm0
  40a772:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a778:	mov    edi,0x1
  40a77d:	lea    rsi,[rsp+0x8]
  40a782:	xor    eax,eax
  40a784:	call   4070a0 <clock_gettime@plt>
  40a789:	vxorpd xmm0,xmm0,xmm0
  40a78d:	mov    rax,QWORD PTR [rsp+0x8]
  40a792:	vcvtsi2sd xmm0,xmm0,rax
  40a797:	vxorpd xmm1,xmm1,xmm1
  40a79b:	mov    rax,QWORD PTR [rsp+0x10]
  40a7a0:	vcvtsi2sd xmm1,xmm1,rax
  40a7a5:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x7a74]        # 412221 <__swc_rdata_base_7dafa2b1+0x111>
  40a7ad:	vaddsd xmm0,xmm0,xmm1
  40a7b1:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a7b7:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a7bd:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a7c3:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a7c9:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a7cf:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a7d5:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a7db:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a7e4:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a7ed:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a7f6:	add    rsp,0xb8
  40a7fd:	pop    rsi
  40a7fe:	pop    rdi
  40a7ff:	ret

000000000040a800 <__swc_fn_7dafa2b1_000007_81d2e1e9>:
  40a800:	sub    rsp,0x8
  40a804:	call   4096c0 <__swc_fn_7dafa2b1_000114_6b799b8d>
  40a809:	mov    rcx,rax
  40a80c:	test   rax,rax
  40a80f:	je     40a836 <__swc_fn_7dafa2b1_000007_81d2e1e9+0x36>
  40a811:	lea    rdx,[rip+0x18830]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  40a818:	mov    r8,QWORD PTR [rip+0x18829]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  40a81f:	nop
  40a820:	lea    r9,[r8+0x1]
  40a824:	mov    rax,r8
  40a827:	lock cmpxchg QWORD PTR [rdx],r9
  40a82c:	cmp    rax,r8
  40a82f:	je     40a836 <__swc_fn_7dafa2b1_000007_81d2e1e9+0x36>
  40a831:	mov    r8,rax
  40a834:	jmp    40a820 <__swc_fn_7dafa2b1_000007_81d2e1e9+0x20>
  40a836:	mov    rax,rcx
  40a839:	add    rsp,0x8
  40a83d:	ret
	...

000000000040a840 <__swc_fn_7dafa2b1_000010_065ed5b1>:
  40a840:	mov    r8d,edx
  40a843:	xor    eax,eax
  40a845:	tzcnt  eax,edx
  40a849:	shrx   r9d,edx,eax
  40a84e:	mov    DWORD PTR [rcx+0x2c],edx
  40a851:	xor    eax,eax
  40a853:	tzcnt  eax,edx
  40a857:	mov    BYTE PTR [rcx+0x38],al
  40a85a:	mov    eax,0xffffffff
  40a85f:	xor    edx,edx
  40a861:	div    r8d
  40a864:	mov    DWORD PTR [rcx+0x34],eax
  40a867:	mov    eax,r9d
  40a86a:	mov    edx,r9d
  40a86d:	imul   edx,r9d
  40a871:	mov    r8d,0x2
  40a877:	sub    r8d,edx
  40a87a:	imul   eax,r8d
  40a87e:	mov    edx,r9d
  40a881:	imul   edx,eax
  40a884:	mov    r8d,0x2
  40a88a:	sub    r8d,edx
  40a88d:	imul   eax,r8d
  40a891:	mov    edx,r9d
  40a894:	imul   edx,eax
  40a897:	mov    r8d,0x2
  40a89d:	sub    r8d,edx
  40a8a0:	imul   eax,r8d
  40a8a4:	mov    edx,r9d
  40a8a7:	imul   edx,eax
  40a8aa:	mov    r8d,0x2
  40a8b0:	sub    r8d,edx
  40a8b3:	imul   eax,r8d
  40a8b7:	imul   r9d,eax
  40a8bb:	mov    edx,0x2
  40a8c0:	sub    edx,r9d
  40a8c3:	imul   eax,edx
  40a8c6:	mov    DWORD PTR [rcx+0x30],eax
  40a8c9:	ret
  40a8ca:	add    BYTE PTR [rax],al
  40a8cc:	add    BYTE PTR [rax],al
	...

000000000040a8d0 <__swc_fn_7dafa2b1_000013_861b8b62>:
  40a8d0:	xor    eax,eax
  40a8d2:	mov    DWORD PTR [rcx+0x68],eax
  40a8d5:	ret
	...

000000000040a8e0 <__swc_fn_7dafa2b1_000016_9dea5065>:
  40a8e0:	mov    eax,DWORD PTR [rcx+0x28]
  40a8e3:	shlx   eax,edx,eax
  40a8e8:	shl    rax,0x10
  40a8ec:	lea    rdx,[rcx+rax*1]
  40a8f0:	lea    rax,[rcx+0x3000]
  40a8f7:	cmp    rdx,rax
  40a8fa:	cmovae rax,rdx
  40a8fe:	ret
	...

000000000040a900 <__swc_fn_7dafa2b1_000019_283e2b5e>:
  40a900:	push   rsi
  40a901:	push   rdi
  40a902:	push   r12
  40a904:	push   r13
  40a906:	push   r14
  40a908:	mov    rsi,rdx
  40a90b:	mov    rdi,rcx
  40a90e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40a912:	mov    ecx,DWORD PTR [rdi+0x28]
  40a915:	shr    dl,cl
  40a917:	mov    r12d,0x1
  40a91d:	mov    ecx,edx
  40a91f:	shl    r12,cl
  40a922:	mov    r13d,DWORD PTR [rsi+0x3c]
  40a926:	rex mov BYTE PTR [rsi+0x3b],0x0
  40a92b:	mov    QWORD PTR [rsi+0x40],0x0
  40a933:	mov    QWORD PTR [rsi],0x0
  40a93a:	mov    rax,QWORD PTR [rsi+0x10]
  40a93e:	mov    QWORD PTR [rsi+0x20],rax
  40a942:	lea    r14,[rip+0x18707]        # 423050 <__swc_bss_base_7dafa2b1+0x10>
  40a949:	mov    rax,QWORD PTR [r14]
  40a94c:	shr    rax,0x2
  40a950:	mov    rcx,rax
  40a953:	cmp    rax,0x800000
  40a95a:	mov    eax,0x800000
  40a95f:	cmovb  rcx,rax
  40a963:	lea    r8,[rip+0x186f6]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  40a96a:	mov    rax,QWORD PTR [r8]
  40a96d:	mov    r9,rax
  40a970:	lea    r10,[r9+r13*1]
  40a974:	cmp    r10,rcx
  40a977:	ja     40a99b <__swc_fn_7dafa2b1_000019_283e2b5e+0x9b>
  40a979:	mov    rax,r9
  40a97c:	lock cmpxchg QWORD PTR [r8],r10
  40a981:	cmp    rax,r9
  40a984:	je     40a98b <__swc_fn_7dafa2b1_000019_283e2b5e+0x8b>
  40a986:	mov    r9,rax
  40a989:	jmp    40a970 <__swc_fn_7dafa2b1_000019_283e2b5e+0x70>
  40a98b:	mov    rcx,rdi
  40a98e:	mov    rdx,r12
  40a991:	call   4077f0 <__swc_fn_7dafa2b1_000021_de02dbdf>
  40a996:	jmp    40aa1d <__swc_fn_7dafa2b1_000019_283e2b5e+0x11d>
  40a99b:	mov    rcx,rdi
  40a99e:	movzx  edx,dl
  40a9a1:	call   40a8e0 <__swc_fn_7dafa2b1_000016_9dea5065>
  40a9a6:	test   r13,r13
  40a9a9:	je     40aa16 <__swc_fn_7dafa2b1_000019_283e2b5e+0x116>
  40a9af:	mov    rcx,rax
  40a9b2:	mov    rdx,r13
  40a9b5:	call   409840 <__swc_fn_7dafa2b1_000117_e9fc0224>
  40a9ba:	mov    rcx,QWORD PTR [rip+0x1868f]        # 423050 <__swc_bss_base_7dafa2b1+0x10>
  40a9c1:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9cb:	nop    DWORD PTR [rax+rax*1+0x0]
  40a9d0:	mov    rdx,rcx
  40a9d3:	sub    rdx,r13
  40a9d6:	mov    rax,rcx
  40a9d9:	lock cmpxchg QWORD PTR [r14],rdx
  40a9de:	cmp    rax,rcx
  40a9e1:	je     40a9e8 <__swc_fn_7dafa2b1_000019_283e2b5e+0xe8>
  40a9e3:	mov    rcx,rax
  40a9e6:	jmp    40a9d0 <__swc_fn_7dafa2b1_000019_283e2b5e+0xd0>
  40a9e8:	lea    rcx,[rip+0x18679]        # 423068 <__swc_bss_base_7dafa2b1+0x28>
  40a9ef:	mov    rdx,QWORD PTR [rip+0x18672]        # 423068 <__swc_bss_base_7dafa2b1+0x28>
  40a9f6:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa00:	lea    r8,[rdx+0x1]
  40aa04:	mov    rax,rdx
  40aa07:	lock cmpxchg QWORD PTR [rcx],r8
  40aa0c:	cmp    rax,rdx
  40aa0f:	je     40aa16 <__swc_fn_7dafa2b1_000019_283e2b5e+0x116>
  40aa11:	mov    rdx,rax
  40aa14:	jmp    40aa00 <__swc_fn_7dafa2b1_000019_283e2b5e+0x100>
  40aa16:	mov    DWORD PTR [rsi+0x3c],0x0
  40aa1d:	mov    rcx,rdi
  40aa20:	mov    rdx,r12
  40aa23:	call   40ee10 <__swc_fn_7dafa2b1_000023_c8f5f27c>
  40aa28:	pop    r14
  40aa2a:	pop    r13
  40aa2c:	pop    r12
  40aa2e:	pop    rdi
  40aa2f:	pop    rsi
  40aa30:	ret
	...

000000000040aa40 <__swc_fn_7dafa2b1_000022_fd2b165c>:
  40aa40:	mov    r8,QWORD PTR [rcx+0x48]
  40aa44:	test   r8,rdx
  40aa47:	je     40aa78 <__swc_fn_7dafa2b1_000022_fd2b165c+0x38>
  40aa49:	nop    DWORD PTR [rax+0x0]
  40aa50:	mov    rax,rdx
  40aa53:	not    rax
  40aa56:	mov    r9,r8
  40aa59:	and    r9,rax
  40aa5c:	mov    rax,r8
  40aa5f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40aa65:	cmp    rax,r8
  40aa68:	jne    40aa70 <__swc_fn_7dafa2b1_000022_fd2b165c+0x30>
  40aa6a:	mov    eax,0x1
  40aa6f:	ret
  40aa70:	mov    r8,rax
  40aa73:	test   rax,rdx
  40aa76:	jne    40aa50 <__swc_fn_7dafa2b1_000022_fd2b165c+0x10>
  40aa78:	xor    eax,eax
  40aa7a:	ret
  40aa7b:	add    BYTE PTR [rax],al
  40aa7d:	add    BYTE PTR [rax],al
	...

000000000040aa80 <__swc_fn_7dafa2b1_000025_2685aade>:
  40aa80:	push   rsi
  40aa81:	push   rdi
  40aa82:	push   r12
  40aa84:	push   r13
  40aa86:	sub    rsp,0x8
  40aa8a:	mov    rsi,rdx
  40aa8d:	mov    rdi,rcx
  40aa90:	lea    r12,[rip+0x18761]        # 4231f8 <__swc_bss_base_7dafa2b1+0x1b8>
  40aa97:	mov    rcx,r12
  40aa9a:	call   4110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>
  40aa9f:	xor    eax,eax
  40aaa1:	mov    rcx,QWORD PTR [rip+0x18758]        # 423200 <__swc_bss_base_7dafa2b1+0x1c0>
  40aaa8:	mov    r13,rcx
  40aaab:	test   r13,r13
  40aaae:	je     40aafb <__swc_fn_7dafa2b1_000025_2685aade+0x7b>
  40aab0:	mov    rcx,QWORD PTR [r13+0x10]
  40aab4:	cmp    DWORD PTR [r13+0x28],esi
  40aab8:	jne    40aaf0 <__swc_fn_7dafa2b1_000025_2685aade+0x70>
  40aaba:	test   rax,rax
  40aabd:	jne    40aac8 <__swc_fn_7dafa2b1_000025_2685aade+0x48>
  40aabf:	mov    QWORD PTR [rip+0x1873a],rcx        # 423200 <__swc_bss_base_7dafa2b1+0x1c0>
  40aac6:	jmp    40aacc <__swc_fn_7dafa2b1_000025_2685aade+0x4c>
  40aac8:	mov    QWORD PTR [rax+0x10],rcx
  40aacc:	vxorps xmm0,xmm0,xmm0
  40aad0:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40aad6:	mov    QWORD PTR [r13+0x8],rdi
  40aada:	mov    rcx,r12
  40aadd:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40aae2:	mov    rax,r13
  40aae5:	add    rsp,0x8
  40aae9:	pop    r13
  40aaeb:	pop    r12
  40aaed:	pop    rdi
  40aaee:	pop    rsi
  40aaef:	ret
  40aaf0:	mov    rax,r13
  40aaf3:	mov    r13,rcx
  40aaf6:	test   rcx,rcx
  40aaf9:	jne    40aab0 <__swc_fn_7dafa2b1_000025_2685aade+0x30>
  40aafb:	mov    ecx,esi
  40aafd:	call   407820 <__swc_fn_7dafa2b1_000024_2d0fcd2c>
  40ab02:	mov    rsi,rax
  40ab05:	test   rax,rax
  40ab08:	jne    40ab1f <__swc_fn_7dafa2b1_000025_2685aade+0x9f>
  40ab0a:	mov    rcx,r12
  40ab0d:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40ab12:	xor    eax,eax
  40ab14:	add    rsp,0x8
  40ab18:	pop    r13
  40ab1a:	pop    r12
  40ab1c:	pop    rdi
  40ab1d:	pop    rsi
  40ab1e:	ret
  40ab1f:	mov    QWORD PTR [rsi+0x8],rdi
  40ab23:	mov    rcx,r12
  40ab26:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40ab2b:	mov    rax,rsi
  40ab2e:	add    rsp,0x8
  40ab32:	pop    r13
  40ab34:	pop    r12
  40ab36:	pop    rdi
  40ab37:	pop    rsi
  40ab38:	ret
  40ab39:	add    BYTE PTR [rax],al
  40ab3b:	add    BYTE PTR [rax],al
  40ab3d:	add    BYTE PTR [rax],al
	...

000000000040ab40 <__swc_fn_7dafa2b1_000028_9798fb47>:
  40ab40:	vxorps xmm0,xmm0,xmm0
  40ab44:	xor    eax,eax
  40ab46:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab50:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab5a:	nop    WORD PTR [rax+rax*1+0x0]
  40ab60:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40ab65:	add    rax,0x10
  40ab69:	cmp    rax,0x2b00
  40ab70:	jne    40ab60 <__swc_fn_7dafa2b1_000028_9798fb47+0x20>
  40ab72:	ret
	...

000000000040ab80 <__swc_fn_7dafa2b1_000031_9798fb47>:
  40ab80:	vxorps xmm0,xmm0,xmm0
  40ab84:	vmovups XMMWORD PTR [rcx],xmm0
  40ab88:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40ab8d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ab92:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ab97:	ret
	...

000000000040aba0 <__swc_fn_7dafa2b1_000034_9798fb47>:
  40aba0:	vxorps xmm0,xmm0,xmm0
  40aba4:	vmovups XMMWORD PTR [rcx],xmm0
  40aba8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40abad:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40abb2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40abb7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40abbc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40abc1:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40abc6:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40abcb:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40abd3:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40abdb:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40abe3:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40abeb:	mov    QWORD PTR [rcx+0xc0],0x0
  40abf6:	ret
	...

000000000040ac00 <__swc_fn_7dafa2b1_000037_92d9bbff>:
  40ac00:	push   rsi
  40ac01:	push   rdi
  40ac02:	sub    rsp,0x8
  40ac06:	mov    rsi,rcx
  40ac09:	lea    rdi,[rip+0x163f0]        # 421000 <__swc_data_base_7dafa2b1>
  40ac10:	mov    rax,QWORD PTR [rdi]
  40ac13:	cmp    rax,0xffffffffffffffff
  40ac17:	je     40ac1e <__swc_fn_7dafa2b1_000037_92d9bbff+0x1e>
  40ac19:	mov    rdi,rax
  40ac1c:	jmp    40ac4b <__swc_fn_7dafa2b1_000037_92d9bbff+0x4b>
  40ac1e:	call   410d80 <__swc_fn_7dafa2b1_000128_58f0f391>
  40ac23:	mov    rcx,rax
  40ac26:	cmp    rax,0xffffffffffffffff
  40ac2a:	je     40ac5c <__swc_fn_7dafa2b1_000037_92d9bbff+0x5c>
  40ac2c:	mov    rax,0xffffffffffffffff
  40ac33:	lock cmpxchg QWORD PTR [rdi],rcx
  40ac38:	cmp    rax,0xffffffffffffffff
  40ac3c:	je     40ac48 <__swc_fn_7dafa2b1_000037_92d9bbff+0x48>
  40ac3e:	mov    rdi,rax
  40ac41:	call   409c10 <__swc_fn_7dafa2b1_000129_a481cb88>
  40ac46:	jmp    40ac4b <__swc_fn_7dafa2b1_000037_92d9bbff+0x4b>
  40ac48:	mov    rdi,rcx
  40ac4b:	cmp    rdi,0xffffffffffffffff
  40ac4f:	je     40ac5c <__swc_fn_7dafa2b1_000037_92d9bbff+0x5c>
  40ac51:	mov    rcx,rdi
  40ac54:	mov    rdx,rsi
  40ac57:	call   40cd10 <__swc_fn_7dafa2b1_000130_4bbe3f14>
  40ac5c:	add    rsp,0x8
  40ac60:	pop    rdi
  40ac61:	pop    rsi
  40ac62:	ret
	...

000000000040ac70 <__swc_fn_7dafa2b1_000040_03f1bf9a>:
  40ac70:	sub    rsp,0x38
  40ac74:	mov    rax,rdx
  40ac77:	test   dl,dl
  40ac79:	jne    40ac91 <__swc_fn_7dafa2b1_000040_03f1bf9a+0x21>
  40ac7b:	mov    rax,r8
  40ac7e:	test   r8b,r8b
  40ac81:	cmove  eax,r9d
  40ac85:	test   al,al
  40ac87:	cmove  eax,r10d
  40ac8b:	test   al,al
  40ac8d:	cmove  eax,r11d
  40ac91:	test   al,al
  40ac93:	jne    40ac9a <__swc_fn_7dafa2b1_000040_03f1bf9a+0x2a>
  40ac95:	add    rsp,0x38
  40ac99:	ret
  40ac9a:	lea    rcx,[rip+0x758f]        # 412230 <__swc_rdata_base_7dafa2b1+0x120>
  40aca1:	vmovups xmm0,XMMWORD PTR [rip+0x7597]        # 412240 <__swc_rdata_base_7dafa2b1+0x130>
  40aca9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40acaf:	vmovups xmm0,XMMWORD PTR [rip+0x7599]        # 412250 <__swc_rdata_base_7dafa2b1+0x140>
  40acb7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40acbd:	vmovups xmm0,XMMWORD PTR [rip+0x759b]        # 412260 <__swc_rdata_base_7dafa2b1+0x150>
  40acc5:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40accb:	lea    rdx,[rsp+0x8]
  40acd0:	call   409440 <__swc_fn_7dafa2b1_000108_90faaa26>
  40acd5:	jmp    40ac95 <__swc_fn_7dafa2b1_000040_03f1bf9a+0x25>
	...

000000000040ace0 <__swc_fn_7dafa2b1_000043_facd3e17>:
  40ace0:	sub    rsp,0x8
  40ace4:	mov    eax,0x1000
  40ace9:	test   eax,eax
  40aceb:	mov    r8d,0x8
  40acf1:	cmove  eax,r8d
  40acf5:	dec    rax
  40acf8:	mov    r8,0xffffffffffffffff
  40acff:	sub    r8,rax
  40ad02:	cmp    rdx,r8
  40ad05:	ja     40ad15 <__swc_fn_7dafa2b1_000043_facd3e17+0x35>
  40ad07:	add    rdx,rax
  40ad0a:	not    rax
  40ad0d:	mov    r8,rdx
  40ad10:	and    r8,rax
  40ad13:	jne    40ad1c <__swc_fn_7dafa2b1_000043_facd3e17+0x3c>
  40ad15:	xor    eax,eax
  40ad17:	add    rsp,0x8
  40ad1b:	ret
  40ad1c:	mov    rdx,r8
  40ad1f:	call   407b40 <__swc_fn_7dafa2b1_000042_c90d80c1>
  40ad24:	add    rsp,0x8
  40ad28:	ret
  40ad29:	add    BYTE PTR [rax],al
  40ad2b:	add    BYTE PTR [rax],al
  40ad2d:	add    BYTE PTR [rax],al
	...

000000000040ad30 <__swc_fn_7dafa2b1_000046_d8bd27c3>:
  40ad30:	push   rsi
  40ad31:	push   rdi
  40ad32:	sub    rsp,0x8
  40ad36:	mov    rsi,rdx
  40ad39:	mov    rdi,rcx
  40ad3c:	test   rdx,rdx
  40ad3f:	je     40ad5b <__swc_fn_7dafa2b1_000046_d8bd27c3+0x2b>
  40ad41:	xor    ecx,ecx
  40ad43:	call   40ef30 <__swc_fn_7dafa2b1_000038_28d0e998>
  40ad48:	mov    rax,QWORD PTR [rsi]
  40ad4b:	test   rax,rax
  40ad4e:	je     40ad5b <__swc_fn_7dafa2b1_000046_d8bd27c3+0x2b>
  40ad50:	mov    rcx,rax
  40ad53:	mov    rdx,rsi
  40ad56:	call   40f040 <__swc_fn_7dafa2b1_000047_b30433d0>
  40ad5b:	mov    rcx,rdi
  40ad5e:	call   407ba0 <__swc_fn_7dafa2b1_000045_a78ae66b>
  40ad63:	mov    rsi,rax
  40ad66:	test   rax,rax
  40ad69:	jne    40ad74 <__swc_fn_7dafa2b1_000046_d8bd27c3+0x44>
  40ad6b:	xor    eax,eax
  40ad6d:	add    rsp,0x8
  40ad71:	pop    rdi
  40ad72:	pop    rsi
  40ad73:	ret
  40ad74:	mov    rcx,rsi
  40ad77:	call   40ef30 <__swc_fn_7dafa2b1_000038_28d0e998>
  40ad7c:	mov    rax,rsi
  40ad7f:	add    rsp,0x8
  40ad83:	pop    rdi
  40ad84:	pop    rsi
  40ad85:	ret
	...

000000000040ad90 <__swc_fn_7dafa2b1_000049_137687bb>:
  40ad90:	movzx  eax,BYTE PTR [r8+0x39]
  40ad95:	lea    rax,[rax+rax*4]
  40ad99:	lea    rax,[rdx+rax*8+0x28]
  40ad9e:	mov    ecx,DWORD PTR [r8+0x6c]
  40ada2:	test   ecx,ecx
  40ada4:	je     40addd <__swc_fn_7dafa2b1_000049_137687bb+0x4d>
  40ada6:	mov    rcx,QWORD PTR [r8+0x50]
  40adaa:	test   rcx,rcx
  40adad:	je     40adb9 <__swc_fn_7dafa2b1_000049_137687bb+0x29>
  40adaf:	mov    rax,QWORD PTR [r8+0x48]
  40adb3:	mov    QWORD PTR [rcx+0x48],rax
  40adb7:	jmp    40adc1 <__swc_fn_7dafa2b1_000049_137687bb+0x31>
  40adb9:	mov    rcx,QWORD PTR [r8+0x48]
  40adbd:	mov    QWORD PTR [rax+0x18],rcx
  40adc1:	mov    rax,QWORD PTR [r8+0x48]
  40adc5:	test   rax,rax
  40adc8:	je     40add2 <__swc_fn_7dafa2b1_000049_137687bb+0x42>
  40adca:	mov    rcx,QWORD PTR [r8+0x50]
  40adce:	mov    QWORD PTR [rax+0x50],rcx
  40add2:	vxorps xmm0,xmm0,xmm0
  40add6:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40addc:	ret
  40addd:	mov    rcx,QWORD PTR [r8+0x50]
  40ade1:	test   rcx,rcx
  40ade4:	je     40adf0 <__swc_fn_7dafa2b1_000049_137687bb+0x60>
  40ade6:	mov    rdx,QWORD PTR [r8+0x48]
  40adea:	mov    QWORD PTR [rcx+0x48],rdx
  40adee:	jmp    40adf8 <__swc_fn_7dafa2b1_000049_137687bb+0x68>
  40adf0:	mov    rcx,QWORD PTR [r8+0x48]
  40adf4:	mov    QWORD PTR [rax+0x8],rcx
  40adf8:	mov    rcx,QWORD PTR [r8+0x48]
  40adfc:	test   rcx,rcx
  40adff:	je     40ae0b <__swc_fn_7dafa2b1_000049_137687bb+0x7b>
  40ae01:	mov    rdx,QWORD PTR [r8+0x50]
  40ae05:	mov    QWORD PTR [rcx+0x50],rdx
  40ae09:	jmp    40ae13 <__swc_fn_7dafa2b1_000049_137687bb+0x83>
  40ae0b:	mov    rcx,QWORD PTR [r8+0x50]
  40ae0f:	mov    QWORD PTR [rax+0x10],rcx
  40ae13:	cmp    QWORD PTR [rax],r8
  40ae16:	jne    40ae1f <__swc_fn_7dafa2b1_000049_137687bb+0x8f>
  40ae18:	mov    QWORD PTR [rax],0x0
  40ae1f:	vxorps xmm0,xmm0,xmm0
  40ae23:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40ae29:	ret
  40ae2a:	add    BYTE PTR [rax],al
  40ae2c:	add    BYTE PTR [rax],al
	...

000000000040ae30 <__swc_fn_7dafa2b1_000052_e072b516>:
  40ae30:	sub    rsp,0x8
  40ae34:	mov    r9,r8
  40ae37:	mov    r10,rdx
  40ae3a:	call   40ad90 <__swc_fn_7dafa2b1_000049_137687bb>
  40ae3f:	mov    DWORD PTR [r9+0x6c],0x0
  40ae47:	movzx  eax,BYTE PTR [r9+0x39]
  40ae4c:	lea    rax,[rax+rax*4]
  40ae50:	lea    rax,[r10+rax*8+0x28]
  40ae55:	mov    rcx,QWORD PTR [rax+0x10]
  40ae59:	mov    QWORD PTR [r9+0x50],rcx
  40ae5d:	mov    QWORD PTR [r9+0x48],0x0
  40ae65:	mov    rcx,QWORD PTR [rax+0x10]
  40ae69:	test   rcx,rcx
  40ae6c:	je     40ae74 <__swc_fn_7dafa2b1_000052_e072b516+0x44>
  40ae6e:	mov    QWORD PTR [rcx+0x48],r9
  40ae72:	jmp    40ae78 <__swc_fn_7dafa2b1_000052_e072b516+0x48>
  40ae74:	mov    QWORD PTR [rax+0x8],r9
  40ae78:	mov    QWORD PTR [rax+0x10],r9
  40ae7c:	add    rsp,0x8
  40ae80:	ret
	...

000000000040aea0 <__swc_fn_7dafa2b1_000055_faa92dcc>:
  40aea0:	push   rsi
  40aea1:	push   rdi
  40aea2:	push   r12
  40aea4:	push   r13
  40aea6:	push   r14
  40aea8:	push   r15
  40aeaa:	sub    rsp,0x1f8
  40aeb1:	mov    esi,r8d
  40aeb4:	mov    QWORD PTR [rsp+0x1e8],rsi
  40aebc:	mov    rdi,rcx
  40aebf:	mov    r12,rdx
  40aec2:	lea    r13,[rsi+rsi*4]
  40aec6:	lea    r13,[rdx+r13*8+0x28]
  40aecb:	call   40f4a0 <__swc_fn_7dafa2b1_000053_d846b172>
  40aed0:	add    DWORD PTR [r12+0x24],0x1
  40aed6:	test   BYTE PTR [r12+0x24],0x3f
  40aedc:	jne    40aee6 <__swc_fn_7dafa2b1_000055_faa92dcc+0x46>
  40aede:	mov    rcx,rdi
  40aee1:	call   407d20 <__swc_fn_7dafa2b1_000054_3af34d7f>
  40aee6:	mov    rax,QWORD PTR [r13+0x8]
  40aeea:	mov    r14,rax
  40aeed:	nop    DWORD PTR [rax]
  40aef0:	test   r14,r14
  40aef3:	jne    40af02 <__swc_fn_7dafa2b1_000055_faa92dcc+0x62>
  40aef5:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40aefd:	jmp    40b009 <__swc_fn_7dafa2b1_000055_faa92dcc+0x169>
  40af02:	mov    r15,QWORD PTR [r14+0x48]
  40af06:	mov    rcx,r14
  40af09:	call   40ec00 <__swc_fn_7dafa2b1_000014_e4b0ddfc>
  40af0e:	mov    rax,QWORD PTR [r14]
  40af11:	test   rax,rax
  40af14:	je     40af26 <__swc_fn_7dafa2b1_000055_faa92dcc+0x86>
  40af16:	mov    rcx,QWORD PTR [rax]
  40af19:	mov    QWORD PTR [r14],rcx
  40af1c:	add    DWORD PTR [r14+0x28],0x1
  40af21:	mov    rsi,rax
  40af24:	jmp    40af45 <__swc_fn_7dafa2b1_000055_faa92dcc+0xa5>
  40af26:	mov    rax,QWORD PTR [r14+0x18]
  40af2a:	cmp    QWORD PTR [r14+0x20],rax
  40af2e:	jae    40af43 <__swc_fn_7dafa2b1_000055_faa92dcc+0xa3>
  40af30:	mov    rsi,QWORD PTR [r14+0x20]
  40af34:	mov    eax,DWORD PTR [r14+0x2c]
  40af38:	add    QWORD PTR [r14+0x20],rax
  40af3c:	add    DWORD PTR [r14+0x28],0x1
  40af41:	jmp    40af45 <__swc_fn_7dafa2b1_000055_faa92dcc+0xa5>
  40af43:	xor    esi,esi
  40af45:	test   rsi,rsi
  40af48:	jne    40af8d <__swc_fn_7dafa2b1_000055_faa92dcc+0xed>
  40af4a:	mov    rcx,r14
  40af4d:	call   40eb30 <__swc_fn_7dafa2b1_000011_24a20786>
  40af52:	test   al,al
  40af54:	je     40af8d <__swc_fn_7dafa2b1_000055_faa92dcc+0xed>
  40af56:	mov    rax,QWORD PTR [r14]
  40af59:	test   rax,rax
  40af5c:	je     40af6b <__swc_fn_7dafa2b1_000055_faa92dcc+0xcb>
  40af5e:	mov    rcx,QWORD PTR [rax]
  40af61:	mov    QWORD PTR [r14],rcx
  40af64:	add    DWORD PTR [r14+0x28],0x1
  40af69:	jmp    40af8a <__swc_fn_7dafa2b1_000055_faa92dcc+0xea>
  40af6b:	mov    rax,QWORD PTR [r14+0x18]
  40af6f:	cmp    QWORD PTR [r14+0x20],rax
  40af73:	jae    40af88 <__swc_fn_7dafa2b1_000055_faa92dcc+0xe8>
  40af75:	mov    rax,QWORD PTR [r14+0x20]
  40af79:	mov    ecx,DWORD PTR [r14+0x2c]
  40af7d:	add    QWORD PTR [r14+0x20],rcx
  40af81:	add    DWORD PTR [r14+0x28],0x1
  40af86:	jmp    40af8a <__swc_fn_7dafa2b1_000055_faa92dcc+0xea>
  40af88:	xor    eax,eax
  40af8a:	mov    rsi,rax
  40af8d:	test   rsi,rsi
  40af90:	jne    40afe3 <__swc_fn_7dafa2b1_000055_faa92dcc+0x143>
  40af92:	mov    rcx,rdi
  40af95:	mov    rdx,r12
  40af98:	mov    r8,r14
  40af9b:	call   407c80 <__swc_fn_7dafa2b1_000051_129b9bf4>
  40afa0:	test   al,al
  40afa2:	jne    40afe3 <__swc_fn_7dafa2b1_000055_faa92dcc+0x143>
  40afa4:	mov    rcx,r14
  40afa7:	call   40ec00 <__swc_fn_7dafa2b1_000014_e4b0ddfc>
  40afac:	mov    rax,QWORD PTR [r14]
  40afaf:	test   rax,rax
  40afb2:	je     40afc1 <__swc_fn_7dafa2b1_000055_faa92dcc+0x121>
  40afb4:	mov    rcx,QWORD PTR [rax]
  40afb7:	mov    QWORD PTR [r14],rcx
  40afba:	add    DWORD PTR [r14+0x28],0x1
  40afbf:	jmp    40afe0 <__swc_fn_7dafa2b1_000055_faa92dcc+0x140>
  40afc1:	mov    rax,QWORD PTR [r14+0x18]
  40afc5:	cmp    QWORD PTR [r14+0x20],rax
  40afc9:	jae    40afde <__swc_fn_7dafa2b1_000055_faa92dcc+0x13e>
  40afcb:	mov    rax,QWORD PTR [r14+0x20]
  40afcf:	mov    ecx,DWORD PTR [r14+0x2c]
  40afd3:	add    QWORD PTR [r14+0x20],rcx
  40afd7:	add    DWORD PTR [r14+0x28],0x1
  40afdc:	jmp    40afe0 <__swc_fn_7dafa2b1_000055_faa92dcc+0x140>
  40afde:	xor    eax,eax
  40afe0:	mov    rsi,rax
  40afe3:	test   rsi,rsi
  40afe6:	je     40b001 <__swc_fn_7dafa2b1_000055_faa92dcc+0x161>
  40afe8:	mov    QWORD PTR [r13+0x0],r14
  40afec:	mov    rax,rsi
  40afef:	add    rsp,0x1f8
  40aff6:	pop    r15
  40aff8:	pop    r14
  40affa:	pop    r13
  40affc:	pop    r12
  40affe:	pop    rdi
  40afff:	pop    rsi
  40b000:	ret
  40b001:	mov    r14,r15
  40b004:	jmp    40aef0 <__swc_fn_7dafa2b1_000055_faa92dcc+0x50>
  40b009:	cs nop WORD PTR [rax+rax*1+0x0]
  40b013:	cs nop WORD PTR [rax+rax*1+0x0]
  40b01d:	nop    DWORD PTR [rax]
  40b020:	mov    rcx,rdi
  40b023:	mov    rdx,r12
  40b026:	mov    r8d,esi
  40b029:	call   40f1e0 <__swc_fn_7dafa2b1_000050_ad48ec88>
  40b02e:	mov    r14,rax
  40b031:	test   rax,rax
  40b034:	jne    40b04a <__swc_fn_7dafa2b1_000055_faa92dcc+0x1aa>
  40b036:	xor    eax,eax
  40b038:	add    rsp,0x1f8
  40b03f:	pop    r15
  40b041:	pop    r14
  40b043:	pop    r13
  40b045:	pop    r12
  40b047:	pop    rdi
  40b048:	pop    rsi
  40b049:	ret
  40b04a:	mov    QWORD PTR [r13+0x0],r14
  40b04e:	mov    rax,QWORD PTR [r14]
  40b051:	test   rax,rax
  40b054:	je     40b066 <__swc_fn_7dafa2b1_000055_faa92dcc+0x1c6>
  40b056:	mov    rcx,QWORD PTR [rax]
  40b059:	mov    QWORD PTR [r14],rcx
  40b05c:	add    DWORD PTR [r14+0x28],0x1
  40b061:	mov    r15,rax
  40b064:	jmp    40b086 <__swc_fn_7dafa2b1_000055_faa92dcc+0x1e6>
  40b066:	mov    rax,QWORD PTR [r14+0x18]
  40b06a:	cmp    QWORD PTR [r14+0x20],rax
  40b06e:	jae    40b083 <__swc_fn_7dafa2b1_000055_faa92dcc+0x1e3>
  40b070:	mov    r15,QWORD PTR [r14+0x20]
  40b074:	mov    eax,DWORD PTR [r14+0x2c]
  40b078:	add    QWORD PTR [r14+0x20],rax
  40b07c:	add    DWORD PTR [r14+0x28],0x1
  40b081:	jmp    40b086 <__swc_fn_7dafa2b1_000055_faa92dcc+0x1e6>
  40b083:	xor    r15d,r15d
  40b086:	test   r15,r15
  40b089:	jne    40b0ce <__swc_fn_7dafa2b1_000055_faa92dcc+0x22e>
  40b08b:	mov    rcx,r14
  40b08e:	call   40eb30 <__swc_fn_7dafa2b1_000011_24a20786>
  40b093:	test   al,al
  40b095:	je     40b0ce <__swc_fn_7dafa2b1_000055_faa92dcc+0x22e>
  40b097:	mov    rax,QWORD PTR [r14]
  40b09a:	test   rax,rax
  40b09d:	je     40b0ac <__swc_fn_7dafa2b1_000055_faa92dcc+0x20c>
  40b09f:	mov    rcx,QWORD PTR [rax]
  40b0a2:	mov    QWORD PTR [r14],rcx
  40b0a5:	add    DWORD PTR [r14+0x28],0x1
  40b0aa:	jmp    40b0cb <__swc_fn_7dafa2b1_000055_faa92dcc+0x22b>
  40b0ac:	mov    rax,QWORD PTR [r14+0x18]
  40b0b0:	cmp    QWORD PTR [r14+0x20],rax
  40b0b4:	jae    40b0c9 <__swc_fn_7dafa2b1_000055_faa92dcc+0x229>
  40b0b6:	mov    rax,QWORD PTR [r14+0x20]
  40b0ba:	mov    ecx,DWORD PTR [r14+0x2c]
  40b0be:	add    QWORD PTR [r14+0x20],rcx
  40b0c2:	add    DWORD PTR [r14+0x28],0x1
  40b0c7:	jmp    40b0cb <__swc_fn_7dafa2b1_000055_faa92dcc+0x22b>
  40b0c9:	xor    eax,eax
  40b0cb:	mov    r15,rax
  40b0ce:	test   r15,r15
  40b0d1:	je     40b020 <__swc_fn_7dafa2b1_000055_faa92dcc+0x180>
  40b0d7:	mov    rax,r15
  40b0da:	add    rsp,0x1f8
  40b0e1:	pop    r15
  40b0e3:	pop    r14
  40b0e5:	pop    r13
  40b0e7:	pop    r12
  40b0e9:	pop    rdi
  40b0ea:	pop    rsi
  40b0eb:	ret
  40b0ec:	add    BYTE PTR [rax],al
	...

000000000040b0f0 <__swc_fn_7dafa2b1_000058_7e1dbcb0>:
  40b0f0:	push   rsi
  40b0f1:	push   rdi
  40b0f2:	push   r12
  40b0f4:	mov    rsi,rdx
  40b0f7:	mov    rax,rdx
  40b0fa:	shr    rax,0xc
  40b0fe:	movabs rdx,0x9e3779b97f4a7c15
  40b108:	imul   rax,rdx
  40b10c:	shr    rax,0x20
  40b110:	lea    rax,[rax*8+0x0]
  40b118:	shr    rax,0x20
  40b11c:	lea    rax,[rax*8+0x0]
  40b124:	lea    rax,[rcx+rax*8+0x40]
  40b129:	xor    edx,edx
  40b12b:	test   dl,dl
  40b12d:	lea    rdi,[rcx+0x8]
  40b131:	cmove  rdi,rax
  40b135:	xor    edx,edx
  40b137:	test   dl,dl
  40b139:	lea    r12,[rcx+0x30]
  40b13d:	lea    rax,[rax+0x8]
  40b141:	cmove  r12,rax
  40b145:	mov    rcx,rdi
  40b148:	call   4110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>
  40b14d:	mov    QWORD PTR [rsi+0x30],0x0
  40b155:	mov    rax,QWORD PTR [r12]
  40b159:	mov    QWORD PTR [rsi+0x38],rax
  40b15d:	test   rax,rax
  40b160:	je     40b16a <__swc_fn_7dafa2b1_000058_7e1dbcb0+0x7a>
  40b162:	mov    rax,QWORD PTR [rsi+0x38]
  40b166:	mov    QWORD PTR [rax+0x30],rsi
  40b16a:	mov    QWORD PTR [r12],rsi
  40b16e:	mov    rcx,rdi
  40b171:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40b176:	pop    r12
  40b178:	pop    rdi
  40b179:	pop    rsi
  40b17a:	ret
  40b17b:	add    BYTE PTR [rax],al
  40b17d:	add    BYTE PTR [rax],al
	...

000000000040b180 <__swc_fn_7dafa2b1_000061_15c28ca7>:
  40b180:	lea    rax,[rdx+rdx*4]
  40b184:	lea    rax,[rcx+rax*8+0x268]
  40b18c:	mov    rdx,QWORD PTR [rax+0x10]
  40b190:	sub    QWORD PTR [rcx+0x2a68],rdx
  40b197:	sub    QWORD PTR [rcx+0x2a70],0x1
  40b19f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40b1a6:	lea    rdx,[rdx+rdx*4]
  40b1aa:	lea    rdx,[rcx+rdx*8+0x268]
  40b1b2:	vmovups xmm0,XMMWORD PTR [rdx]
  40b1b6:	vmovups XMMWORD PTR [rax],xmm0
  40b1ba:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40b1bf:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40b1c4:	mov    rcx,QWORD PTR [rdx+0x20]
  40b1c8:	mov    QWORD PTR [rax+0x20],rcx
  40b1cc:	ret
  40b1cd:	add    BYTE PTR [rax],al
	...

000000000040b1d0 <__swc_fn_7dafa2b1_000064_dea90857>:
  40b1d0:	push   rsi
  40b1d1:	push   rdi
  40b1d2:	push   r12
  40b1d4:	push   r13
  40b1d6:	sub    rsp,0x8
  40b1da:	mov    rsi,r8
  40b1dd:	mov    rdi,rcx
  40b1e0:	mov    r12,rdx
  40b1e3:	xor    r13d,r13d
  40b1e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40b1f0:	mov    eax,DWORD PTR [r12+0x730]
  40b1f8:	cmp    r13d,eax
  40b1fb:	jae    40b261 <__swc_fn_7dafa2b1_000064_dea90857+0x91>
  40b1fd:	lea    rax,[r13+r13*4+0x0]
  40b202:	lea    rax,[r12+rax*8+0x738]
  40b20a:	mov    rdx,QWORD PTR [rax]
  40b20d:	mov    r8,QWORD PTR [rax+0x8]
  40b211:	mov    r9,QWORD PTR [rax+0x10]
  40b215:	cmp    QWORD PTR [rax+0x20],rsi
  40b219:	jb     40b220 <__swc_fn_7dafa2b1_000064_dea90857+0x50>
  40b21b:	inc    r13d
  40b21e:	jmp    40b1f0 <__swc_fn_7dafa2b1_000064_dea90857+0x20>
  40b220:	sub    DWORD PTR [r12+0x730],0x1
  40b229:	mov    ecx,DWORD PTR [r12+0x730]
  40b231:	lea    rcx,[rcx+rcx*4]
  40b235:	lea    rcx,[r12+rcx*8+0x738]
  40b23d:	vmovups xmm0,XMMWORD PTR [rcx]
  40b241:	vmovups XMMWORD PTR [rax],xmm0
  40b245:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40b24a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40b24f:	mov    rcx,QWORD PTR [rcx+0x20]
  40b253:	mov    QWORD PTR [rax+0x20],rcx
  40b257:	mov    rcx,rdi
  40b25a:	call   40ef60 <__swc_fn_7dafa2b1_000044_d3c2ab54>
  40b25f:	jmp    40b1f0 <__swc_fn_7dafa2b1_000064_dea90857+0x20>
  40b261:	add    rsp,0x8
  40b265:	pop    r13
  40b267:	pop    r12
  40b269:	pop    rdi
  40b26a:	pop    rsi
  40b26b:	ret
  40b26c:	add    BYTE PTR [rax],al
	...

000000000040b270 <__swc_fn_7dafa2b1_000067_de167e8d>:
  40b270:	push   rsi
  40b271:	push   rdi
  40b272:	push   r12
  40b274:	push   r13
  40b276:	push   r14
  40b278:	mov    rsi,rcx
  40b27b:	mov    rdi,rdx
  40b27e:	mov    r12,QWORD PTR [rdi]
  40b281:	mov    r13,QWORD PTR [rdi+0x18]
  40b285:	mov    rax,r12
  40b288:	add    rax,QWORD PTR [rdi+0x8]
  40b28c:	sub    rax,r13
  40b28f:	cmp    r8,rax
  40b292:	jbe    40b29d <__swc_fn_7dafa2b1_000067_de167e8d+0x2d>
  40b294:	pop    r14
  40b296:	pop    r13
  40b298:	pop    r12
  40b29a:	pop    rdi
  40b29b:	pop    rsi
  40b29c:	ret
  40b29d:	lea    rax,[r13+r8*1+0x0]
  40b2a2:	sub    rax,r12
  40b2a5:	mov    ecx,0x1000
  40b2aa:	test   ecx,ecx
  40b2ac:	mov    edx,0x8
  40b2b1:	cmove  ecx,edx
  40b2b4:	dec    rcx
  40b2b7:	mov    rdx,0xffffffffffffffff
  40b2be:	sub    rdx,rcx
  40b2c1:	cmp    rax,rdx
  40b2c4:	jbe    40b2cb <__swc_fn_7dafa2b1_000067_de167e8d+0x5b>
  40b2c6:	xor    r14d,r14d
  40b2c9:	jmp    40b2d6 <__swc_fn_7dafa2b1_000067_de167e8d+0x66>
  40b2cb:	add    rax,rcx
  40b2ce:	andn   rax,rcx,rax
  40b2d3:	mov    r14,rax
  40b2d6:	mov    rax,QWORD PTR [rdi+0x10]
  40b2da:	cmp    r14,rax
  40b2dd:	ja     40b2e8 <__swc_fn_7dafa2b1_000067_de167e8d+0x78>
  40b2df:	pop    r14
  40b2e1:	pop    r13
  40b2e3:	pop    r12
  40b2e5:	pop    rdi
  40b2e6:	pop    rsi
  40b2e7:	ret
  40b2e8:	mov    rax,r12
  40b2eb:	add    rax,QWORD PTR [rdi+0x10]
  40b2ef:	mov    rdx,r14
  40b2f2:	sub    rdx,QWORD PTR [rdi+0x10]
  40b2f6:	mov    rcx,rax
  40b2f9:	call   40eab0 <__swc_fn_7dafa2b1_000008_f7acedb0>
  40b2fe:	test   al,al
  40b300:	jne    40b30b <__swc_fn_7dafa2b1_000067_de167e8d+0x9b>
  40b302:	pop    r14
  40b304:	pop    r13
  40b306:	pop    r12
  40b308:	pop    rdi
  40b309:	pop    rsi
  40b30a:	ret
  40b30b:	add    r12,r14
  40b30e:	sub    r12,r13
  40b311:	mov    rcx,r12
  40b314:	sub    rcx,QWORD PTR [rdi+0x28]
  40b318:	mov    rdx,QWORD PTR [rsi+0x250]
  40b31f:	nop
  40b320:	lea    r8,[rdx+rcx*1]
  40b324:	mov    rax,rdx
  40b327:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40b330:	cmp    rax,rdx
  40b333:	je     40b33a <__swc_fn_7dafa2b1_000067_de167e8d+0xca>
  40b335:	mov    rdx,rax
  40b338:	jmp    40b320 <__swc_fn_7dafa2b1_000067_de167e8d+0xb0>
  40b33a:	mov    QWORD PTR [rdi+0x10],r14
  40b33e:	mov    QWORD PTR [rdi+0x28],r12
  40b342:	pop    r14
  40b344:	pop    r13
  40b346:	pop    r12
  40b348:	pop    rdi
  40b349:	pop    rsi
  40b34a:	ret
  40b34b:	add    BYTE PTR [rax],al
  40b34d:	add    BYTE PTR [rax],al
	...

000000000040b350 <__swc_fn_7dafa2b1_000070_7130736e>:
  40b350:	push   rbx
  40b351:	push   rsi
  40b352:	push   rdi
  40b353:	push   r12
  40b355:	push   r13
  40b357:	sub    rsp,0xe0
  40b35e:	mov    rbx,rdx
  40b361:	mov    rsi,rcx
  40b364:	cmp    DWORD PTR [rbx+0x58],0x0
  40b368:	je     40b38c <__swc_fn_7dafa2b1_000070_7130736e+0x3c>
  40b36a:	mov    eax,DWORD PTR [rbx+0x58]
  40b36d:	sub    eax,0x1
  40b370:	test   DWORD PTR [rbx+0x58],eax
  40b373:	je     40b38c <__swc_fn_7dafa2b1_000070_7130736e+0x3c>
  40b375:	mov    QWORD PTR [rbx+0x40],0x0
  40b37d:	add    rsp,0xe0
  40b384:	pop    r13
  40b386:	pop    r12
  40b388:	pop    rdi
  40b389:	pop    rsi
  40b38a:	pop    rbx
  40b38b:	ret
  40b38c:	mov    rax,QWORD PTR [rbx+0x40]
  40b390:	test   rax,rax
  40b393:	jne    40b3af <__swc_fn_7dafa2b1_000070_7130736e+0x5f>
  40b395:	mov    rcx,rsi
  40b398:	mov    rdx,rbx
  40b39b:	call   408930 <__swc_fn_7dafa2b1_000069_f3aa21af>
  40b3a0:	add    rsp,0xe0
  40b3a7:	pop    r13
  40b3a9:	pop    r12
  40b3ab:	pop    rdi
  40b3ac:	pop    rsi
  40b3ad:	pop    rbx
  40b3ae:	ret
  40b3af:	cmp    QWORD PTR [rbx+0x48],0x0
  40b3b4:	jne    40b3d0 <__swc_fn_7dafa2b1_000070_7130736e+0x80>
  40b3b6:	mov    rcx,rsi
  40b3b9:	mov    rdx,rbx
  40b3bc:	call   40f790 <__swc_fn_7dafa2b1_000071_97813b89>
  40b3c1:	add    rsp,0xe0
  40b3c8:	pop    r13
  40b3ca:	pop    r12
  40b3cc:	pop    rdi
  40b3cd:	pop    rsi
  40b3ce:	pop    rbx
  40b3cf:	ret
  40b3d0:	mov    rdi,QWORD PTR [rbx+0x40]
  40b3d4:	lea    rax,[rip+0x17c9d]        # 423078 <__swc_bss_base_7dafa2b1+0x38>
  40b3db:	mov    rcx,rdi
  40b3de:	sub    rcx,QWORD PTR [rax+0x8]
  40b3e2:	mov    rax,QWORD PTR [rip+0x17c9f]        # 423088 <__swc_bss_base_7dafa2b1+0x48>
  40b3e9:	cmp    rcx,rax
  40b3ec:	jae    40b418 <__swc_fn_7dafa2b1_000070_7130736e+0xc8>
  40b3ee:	mov    rax,rdi
  40b3f1:	and    rax,0xffffffffffc00000
  40b3f8:	mov    rcx,rdi
  40b3fb:	shr    rcx,0x10
  40b3ff:	and    ecx,0x3f
  40b402:	mov    edx,DWORD PTR [rax+0x28]
  40b405:	shrx   ecx,ecx,edx
  40b40a:	shl    rcx,0x4
  40b40e:	lea    r12,[rax+rcx*8+0x80]
  40b416:	jmp    40b423 <__swc_fn_7dafa2b1_000070_7130736e+0xd3>
  40b418:	mov    rcx,rdi
  40b41b:	call   4079b0 <__swc_fn_7dafa2b1_000027_bcdc5519>
  40b420:	mov    r12,rax
  40b423:	test   r12,r12
  40b426:	je     40b435 <__swc_fn_7dafa2b1_000070_7130736e+0xe5>
  40b428:	mov    eax,DWORD PTR [r12+0x2c]
  40b42d:	mov    r9d,eax
  40b430:	mov    r13,rax
  40b433:	jmp    40b4b4 <__swc_fn_7dafa2b1_000070_7130736e+0x164>
  40b435:	mov    rcx,rsi
  40b438:	mov    rdx,rdi
  40b43b:	call   407fc0 <__swc_fn_7dafa2b1_000057_df0696cd>
  40b440:	mov    rcx,QWORD PTR [rax+0x28]
  40b444:	mov    r9,rcx
  40b447:	mov    rdx,QWORD PTR [rax+0x20]
  40b44b:	mov    r13,rdx
  40b44e:	cmp    QWORD PTR [rbx+0x48],rcx
  40b452:	jbe    40b48b <__swc_fn_7dafa2b1_000070_7130736e+0x13b>
  40b454:	mov    ecx,DWORD PTR [rax+0x48]
  40b457:	cmp    DWORD PTR [rbx+0x58],ecx
  40b45a:	ja     40b48b <__swc_fn_7dafa2b1_000070_7130736e+0x13b>
  40b45c:	mov    rcx,rsi
  40b45f:	mov    rdx,rax
  40b462:	mov    r8,QWORD PTR [rbx+0x48]
  40b466:	mov    QWORD PTR [rsp+0xc8],r9
  40b46e:	mov    QWORD PTR [rsp+0xd0],rax
  40b476:	call   40b270 <__swc_fn_7dafa2b1_000067_de167e8d>
  40b47b:	mov    r9,QWORD PTR [rsp+0xc8]
  40b483:	mov    rax,QWORD PTR [rsp+0xd0]
  40b48b:	mov    rcx,QWORD PTR [rax+0x28]
  40b48f:	cmp    QWORD PTR [rbx+0x48],rcx
  40b493:	ja     40b4b4 <__swc_fn_7dafa2b1_000070_7130736e+0x164>
  40b495:	mov    ecx,DWORD PTR [rax+0x48]
  40b498:	cmp    DWORD PTR [rbx+0x58],ecx
  40b49b:	ja     40b4b4 <__swc_fn_7dafa2b1_000070_7130736e+0x164>
  40b49d:	mov    rcx,QWORD PTR [rbx+0x48]
  40b4a1:	mov    QWORD PTR [rax+0x20],rcx
  40b4a5:	add    rsp,0xe0
  40b4ac:	pop    r13
  40b4ae:	pop    r12
  40b4b0:	pop    rdi
  40b4b1:	pop    rsi
  40b4b2:	pop    rbx
  40b4b3:	ret
  40b4b4:	test   r12,r12
  40b4b7:	je     40b4e9 <__swc_fn_7dafa2b1_000070_7130736e+0x199>
  40b4b9:	cmp    QWORD PTR [rbx+0x48],r9
  40b4bd:	ja     40b4e9 <__swc_fn_7dafa2b1_000070_7130736e+0x199>
  40b4bf:	cmp    DWORD PTR [rbx+0x58],0x40
  40b4c3:	ja     40b4e9 <__swc_fn_7dafa2b1_000070_7130736e+0x199>
  40b4c5:	cmp    DWORD PTR [rbx+0x58],0x0
  40b4c9:	je     40b4d6 <__swc_fn_7dafa2b1_000070_7130736e+0x186>
  40b4cb:	mov    ecx,DWORD PTR [rbx+0x58]
  40b4ce:	dec    rcx
  40b4d1:	test   rdi,rcx
  40b4d4:	jne    40b4e9 <__swc_fn_7dafa2b1_000070_7130736e+0x199>
  40b4d6:	mov    QWORD PTR [rbx+0x40],rdi
  40b4da:	add    rsp,0xe0
  40b4e1:	pop    r13
  40b4e3:	pop    r12
  40b4e5:	pop    rdi
  40b4e6:	pop    rsi
  40b4e7:	pop    rbx
  40b4e8:	ret
  40b4e9:	vmovups xmm0,XMMWORD PTR [rbx]
  40b4ed:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40b4f3:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40b4f8:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40b4fe:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40b503:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40b509:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40b50e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40b514:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40b519:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40b51f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40b524:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40b52a:	mov    QWORD PTR [rsp+0x48],0x0
  40b533:	mov    rcx,rsi
  40b536:	lea    rdx,[rsp+0x8]
  40b53b:	call   408930 <__swc_fn_7dafa2b1_000069_f3aa21af>
  40b540:	mov    rax,QWORD PTR [rsp+0x48]
  40b545:	test   rax,rax
  40b548:	jne    40b561 <__swc_fn_7dafa2b1_000070_7130736e+0x211>
  40b54a:	mov    QWORD PTR [rbx+0x40],0x0
  40b552:	add    rsp,0xe0
  40b559:	pop    r13
  40b55b:	pop    r12
  40b55d:	pop    rdi
  40b55e:	pop    rsi
  40b55f:	pop    rbx
  40b560:	ret
  40b561:	mov    rax,QWORD PTR [rbx+0x48]
  40b565:	cmp    r13,rax
  40b568:	cmovbe rax,r13
  40b56c:	mov    rcx,QWORD PTR [rsp+0x48]
  40b571:	mov    rdx,rdi
  40b574:	mov    r8,rax
  40b577:	call   4108e0 <__swc_fn_7dafa2b1_000110_7c204aac>
  40b57c:	vmovups xmm0,XMMWORD PTR [rbx]
  40b580:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40b586:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40b58b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40b591:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40b596:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40b59f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40b5a4:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40b5ad:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40b5b2:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40b5bb:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40b5c0:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40b5c9:	mov    QWORD PTR [rsp+0xa8],rdi
  40b5d1:	mov    rcx,rsi
  40b5d4:	lea    rdx,[rsp+0x68]
  40b5d9:	call   40f790 <__swc_fn_7dafa2b1_000071_97813b89>
  40b5de:	mov    rax,QWORD PTR [rsp+0x48]
  40b5e3:	mov    QWORD PTR [rbx+0x40],rax
  40b5e7:	add    rsp,0xe0
  40b5ee:	pop    r13
  40b5f0:	pop    r12
  40b5f2:	pop    rdi
  40b5f3:	pop    rsi
  40b5f4:	pop    rbx
  40b5f5:	ret
	...

000000000040b600 <__swc_fn_7dafa2b1_000073_61e60aab>:
  40b600:	push   r12
  40b602:	push   rdi
  40b603:	push   rsi
  40b604:	push   r13
  40b606:	push   r14
  40b608:	sub    rsp,0x190
  40b60f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40b618:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40b621:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40b62a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40b633:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40b63c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40b645:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40b64e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40b657:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40b660:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40b669:	mov    r12,rcx
  40b66c:	lea    rax,[rip+0x1598d]        # 421000 <__swc_data_base_7dafa2b1>
  40b673:	mov    rax,QWORD PTR [rax]
  40b676:	cmp    rax,0xffffffffffffffff
  40b67a:	je     40b689 <__swc_fn_7dafa2b1_000073_61e60aab+0x89>
  40b67c:	mov    eax,eax
  40b67e:	mov    edi,eax
  40b680:	xor    eax,eax
  40b682:	call   407000 <pthread_getspecific@plt>
  40b687:	jmp    40b68b <__swc_fn_7dafa2b1_000073_61e60aab+0x8b>
  40b689:	xor    eax,eax
  40b68b:	test   rax,rax
  40b68e:	jne    40b69d <__swc_fn_7dafa2b1_000073_61e60aab+0x9d>
  40b690:	call   407a80 <__swc_fn_7dafa2b1_000036_cd1a4e8c>
  40b695:	mov    rcx,rax
  40b698:	call   40cdc0 <__swc_fn_7dafa2b1_000133_5f757033>
  40b69d:	test   rax,rax
  40b6a0:	je     40b6c6 <__swc_fn_7dafa2b1_000073_61e60aab+0xc6>
  40b6a2:	cmp    QWORD PTR [rax],r12
  40b6a5:	jne    40b6c6 <__swc_fn_7dafa2b1_000073_61e60aab+0xc6>
  40b6a7:	xor    ecx,ecx
  40b6a9:	mov    QWORD PTR [rsp+0xc8],rax
  40b6b1:	call   40ef30 <__swc_fn_7dafa2b1_000038_28d0e998>
  40b6b6:	mov    rdx,QWORD PTR [rsp+0xc8]
  40b6be:	mov    rcx,r12
  40b6c1:	call   40f040 <__swc_fn_7dafa2b1_000047_b30433d0>
  40b6c6:	lea    rsi,[r12+0x10]
  40b6cb:	mov    rcx,rsi
  40b6ce:	call   4110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>
  40b6d3:	mov    rdi,QWORD PTR [r12+0x20]
  40b6d8:	test   rdi,rdi
  40b6db:	je     40b71e <__swc_fn_7dafa2b1_000073_61e60aab+0x11e>
  40b6dd:	nop    DWORD PTR [rax]
  40b6e0:	mov    rcx,r12
  40b6e3:	mov    rdx,rdi
  40b6e6:	call   407c40 <__swc_fn_7dafa2b1_000048_6e7a8d58>
  40b6eb:	mov    rcx,r12
  40b6ee:	mov    rdx,rdi
  40b6f1:	mov    r8,0xffffffffffffffff
  40b6f8:	call   40b1d0 <__swc_fn_7dafa2b1_000064_dea90857>
  40b6fd:	mov    rcx,r12
  40b700:	mov    rdx,rdi
  40b703:	mov    r8d,0x9b8
  40b709:	mov    r9d,0x9b8
  40b70f:	call   40ef60 <__swc_fn_7dafa2b1_000044_d3c2ab54>
  40b714:	mov    rdi,QWORD PTR [r12+0x20]
  40b719:	test   rdi,rdi
  40b71c:	jne    40b6e0 <__swc_fn_7dafa2b1_000073_61e60aab+0xe0>
  40b71e:	xor    eax,eax
  40b720:	xchg   QWORD PTR [r12+0x2a80],rax
  40b728:	test   rax,rax
  40b72b:	je     40b751 <__swc_fn_7dafa2b1_000073_61e60aab+0x151>
  40b72d:	cs nop WORD PTR [rax+rax*1+0x0]
  40b737:	nop    WORD PTR [rax+rax*1+0x0]
  40b740:	mov    rcx,rax
  40b743:	mov    rax,QWORD PTR [rax+0x78]
  40b747:	xor    edx,edx
  40b749:	xchg   DWORD PTR [rcx+0x70],edx
  40b74c:	test   rax,rax
  40b74f:	jne    40b740 <__swc_fn_7dafa2b1_000073_61e60aab+0x140>
  40b751:	mov    rax,QWORD PTR [r12+0x18]
  40b756:	mov    rdi,rax
  40b759:	test   rdi,rdi
  40b75c:	je     40b7f1 <__swc_fn_7dafa2b1_000073_61e60aab+0x1f1>
  40b762:	cs nop WORD PTR [rax+rax*1+0x0]
  40b76c:	nop    DWORD PTR [rax+0x0]
  40b770:	mov    rax,QWORD PTR [rdi+0x10]
  40b774:	mov    r8d,DWORD PTR [rdi+0x2c]
  40b778:	xor    r9d,r9d
  40b77b:	test   r8,r8
  40b77e:	jbe    40b7dd <__swc_fn_7dafa2b1_000073_61e60aab+0x1dd>
  40b780:	mov    ecx,r9d
  40b783:	shl    rcx,0x4
  40b787:	lea    rdx,[rdi+rcx*8+0x80]
  40b78f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40b793:	je     40b7d4 <__swc_fn_7dafa2b1_000073_61e60aab+0x1d4>
  40b795:	mov    DWORD PTR [rdx+0x28],0x0
  40b79c:	mov    rcx,rdi
  40b79f:	mov    QWORD PTR [rsp+0xd0],rax
  40b7a7:	mov    QWORD PTR [rsp+0xd8],r8
  40b7af:	mov    QWORD PTR [rsp+0xe0],r9
  40b7b7:	call   40a900 <__swc_fn_7dafa2b1_000019_283e2b5e>
  40b7bc:	mov    rax,QWORD PTR [rsp+0xd0]
  40b7c4:	mov    r8,QWORD PTR [rsp+0xd8]
  40b7cc:	mov    r9,QWORD PTR [rsp+0xe0]
  40b7d4:	add    r9,0x1
  40b7d8:	cmp    r9,r8
  40b7db:	jb     40b780 <__swc_fn_7dafa2b1_000073_61e60aab+0x180>
  40b7dd:	mov    rcx,rdi
  40b7e0:	mov    rdi,rax
  40b7e3:	call   40ee40 <__swc_fn_7dafa2b1_000026_aa910677>
  40b7e8:	test   rdi,rdi
  40b7eb:	jne    40b770 <__swc_fn_7dafa2b1_000073_61e60aab+0x170>
  40b7f1:	mov    QWORD PTR [r12+0x18],0x0
  40b7fa:	mov    QWORD PTR [r12+0x28],0x0
  40b803:	mov    rcx,rsi
  40b806:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40b80b:	mov    esi,0x8
  40b810:	xor    edi,edi
  40b812:	test   rsi,rsi
  40b815:	je     40b872 <__swc_fn_7dafa2b1_000073_61e60aab+0x272>
  40b81b:	nop    DWORD PTR [rax+rax*1+0x0]
  40b820:	lea    r13,[rdi*8+0x0]
  40b828:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40b82d:	test   r14,r14
  40b830:	je     40b868 <__swc_fn_7dafa2b1_000073_61e60aab+0x268>
  40b832:	cs nop WORD PTR [rax+rax*1+0x0]
  40b83c:	nop    DWORD PTR [rax+0x0]
  40b840:	mov    rcx,r12
  40b843:	mov    rdx,r14
  40b846:	call   40f5f0 <__swc_fn_7dafa2b1_000059_1bb23e77>
  40b84b:	mov    rcx,r12
  40b84e:	mov    rdx,QWORD PTR [r14]
  40b851:	mov    r8,QWORD PTR [r14+0x8]
  40b855:	mov    r9,QWORD PTR [r14+0x10]
  40b859:	call   40ef60 <__swc_fn_7dafa2b1_000044_d3c2ab54>
  40b85e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40b863:	test   r14,r14
  40b866:	jne    40b840 <__swc_fn_7dafa2b1_000073_61e60aab+0x240>
  40b868:	add    rdi,0x1
  40b86c:	sub    rsi,0x1
  40b870:	jne    40b820 <__swc_fn_7dafa2b1_000073_61e60aab+0x220>
  40b872:	mov    rcx,r12
  40b875:	call   40f6c0 <__swc_fn_7dafa2b1_000065_ffcd96eb>
  40b87a:	lea    rcx,[r12+0x250]
  40b882:	mov    rdx,QWORD PTR [rcx]
  40b885:	mov    r8,QWORD PTR [r12+0x250]
  40b88d:	nop    DWORD PTR [rax]
  40b890:	mov    r9,r8
  40b893:	sub    r9,rdx
  40b896:	mov    rax,r8
  40b899:	lock cmpxchg QWORD PTR [rcx],r9
  40b89e:	cmp    rax,r8
  40b8a1:	je     40b8a8 <__swc_fn_7dafa2b1_000073_61e60aab+0x2a8>
  40b8a3:	mov    r8,rax
  40b8a6:	jmp    40b890 <__swc_fn_7dafa2b1_000073_61e60aab+0x290>
  40b8a8:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40b8b1:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40b8ba:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40b8c3:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40b8cc:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40b8d5:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40b8de:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40b8e7:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40b8f0:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40b8f9:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40b902:	add    rsp,0x190
  40b909:	pop    r14
  40b90b:	pop    r13
  40b90d:	pop    rsi
  40b90e:	pop    rdi
  40b90f:	pop    r12
  40b911:	ret
	...

000000000040b920 <__swc_fn_7dafa2b1_000076_64d36d78>:
  40b920:	sub    rsp,0x8
  40b924:	mov    QWORD PTR [rdx+0x40],0x0
  40b92c:	call   408930 <__swc_fn_7dafa2b1_000069_f3aa21af>
  40b931:	add    rsp,0x8
  40b935:	ret
	...

000000000040b940 <__swc_fn_7dafa2b1_000079_1966ae2e>:
  40b940:	sub    rsp,0x8
  40b944:	call   40f790 <__swc_fn_7dafa2b1_000071_97813b89>
  40b949:	add    rsp,0x8
  40b94d:	ret
	...

000000000040b950 <__swc_fn_7dafa2b1_000082_5cc7acfc>:
  40b950:	push   rbx
  40b951:	push   rsi
  40b952:	push   rdi
  40b953:	push   r12
  40b955:	push   r13
  40b957:	push   r14
  40b959:	push   r15
  40b95b:	sub    rsp,0x20
  40b95f:	mov    rbx,r11
  40b962:	mov    rsi,rcx
  40b965:	mov    rdi,rdx
  40b968:	mov    r12,r8
  40b96b:	mov    r13,r9
  40b96e:	mov    r14,r10
  40b971:	mov    rcx,QWORD PTR [rip+0x176c8]        # 423040 <__swc_bss_base_7dafa2b1>
  40b978:	test   rcx,rcx
  40b97b:	jne    40b98d <__swc_fn_7dafa2b1_000082_5cc7acfc+0x3d>
  40b97d:	call   4119a0 <__swc_fn_7dafa2b1_000170_994c8876>
  40b982:	lea    rcx,[rax+0x1]
  40b986:	mov    QWORD PTR [rip+0x176b3],rcx        # 423040 <__swc_bss_base_7dafa2b1>
  40b98d:	dec    rcx
  40b990:	call   40e840 <__swc_fn_7dafa2b1_000172_360af05d>
  40b995:	mov    r15,rax
  40b998:	lea    r11,[rip+0x178a1]        # 423240 <__swc_bss_base_7dafa2b1+0x200>
  40b99f:	mov    rcx,r11
  40b9a2:	call   40ef50 <__swc_fn_7dafa2b1_000041_eb6108f2>
  40b9a7:	test   al,al
  40b9a9:	jne    40b9ba <__swc_fn_7dafa2b1_000082_5cc7acfc+0x6a>
  40b9ab:	mov    rcx,r11
  40b9ae:	call   407ae0 <__swc_fn_7dafa2b1_000039_14f56618>
  40b9b3:	lea    r11,[rip+0x17886]        # 423240 <__swc_bss_base_7dafa2b1+0x200>
  40b9ba:	mov    rcx,r11
  40b9bd:	mov    rdx,rsi
  40b9c0:	mov    r8,rdi
  40b9c3:	mov    r9,r12
  40b9c6:	mov    r10,r13
  40b9c9:	mov    rsi,r11
  40b9cc:	mov    r11,r14
  40b9cf:	call   40ac70 <__swc_fn_7dafa2b1_000040_03f1bf9a>
  40b9d4:	test   bl,bl
  40b9d6:	je     40b9fd <__swc_fn_7dafa2b1_000082_5cc7acfc+0xad>
  40b9d8:	mov    QWORD PTR [rsp+0x8],rsi
  40b9dd:	lea    rax,[rip+0x688c]        # 412270 <__swc_rdata_base_7dafa2b1+0x160>
  40b9e4:	mov    QWORD PTR [rsp+0x10],rax
  40b9e9:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40b9ef:	vmovups XMMWORD PTR [r15],xmm0
  40b9f4:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40b9fd:	mov    rax,rsi
  40ba00:	add    rsp,0x20
  40ba04:	pop    r15
  40ba06:	pop    r14
  40ba08:	pop    r13
  40ba0a:	pop    r12
  40ba0c:	pop    rdi
  40ba0d:	pop    rsi
  40ba0e:	pop    rbx
  40ba0f:	ret

000000000040ba10 <__swc_fn_7dafa2b1_000085_cf82995a>:
  40ba10:	sub    rsp,0x8
  40ba14:	mov    rax,rcx
  40ba17:	test   rcx,rcx
  40ba1a:	jne    40ba21 <__swc_fn_7dafa2b1_000085_cf82995a+0x11>
  40ba1c:	add    rsp,0x8
  40ba20:	ret
  40ba21:	lea    rcx,[rax-0x10]
  40ba25:	mov    rax,QWORD PTR [rax-0x10]
  40ba29:	mov    rdx,rax
  40ba2c:	call   40ca70 <__swc_fn_7dafa2b1_000118_ed2d8fed>
  40ba31:	add    rsp,0x8
  40ba35:	ret
	...

000000000040ba40 <__swc_fn_7dafa2b1_000088_ef55f6e4>:
  40ba40:	sub    rsp,0x8
  40ba44:	xor    r11d,r11d
  40ba47:	call   40fa50 <__swc_fn_7dafa2b1_000089_0d280354>
  40ba4c:	add    rsp,0x8
  40ba50:	ret
	...

000000000040ba60 <__swc_fn_7dafa2b1_000091_23214800>:
  40ba60:	push   rsi
  40ba61:	push   rdi
  40ba62:	push   r12
  40ba64:	push   r13
  40ba66:	push   r14
  40ba68:	push   r15
  40ba6a:	sub    rsp,0x68
  40ba6e:	mov    rsi,r9
  40ba71:	mov    rdi,rcx
  40ba74:	mov    r12,rdx
  40ba77:	mov    r13,r8
  40ba7a:	cmp    r8,r9
  40ba7d:	jne    40baa5 <__swc_fn_7dafa2b1_000091_23214800+0x45>
  40ba7f:	mov    rcx,rdi
  40ba82:	mov    rdx,r12
  40ba85:	xor    r8d,r8d
  40ba88:	call   40fda0 <__swc_fn_7dafa2b1_000095_63c1827b>
  40ba8d:	test   al,al
  40ba8f:	je     40baa5 <__swc_fn_7dafa2b1_000091_23214800+0x45>
  40ba91:	mov    eax,0x1
  40ba96:	add    rsp,0x68
  40ba9a:	pop    r15
  40ba9c:	pop    r14
  40ba9e:	pop    r13
  40baa0:	pop    r12
  40baa2:	pop    rdi
  40baa3:	pop    rsi
  40baa4:	ret
  40baa5:	cmp    BYTE PTR [r12+0x2c],0xe
  40baab:	je     40babe <__swc_fn_7dafa2b1_000091_23214800+0x5e>
  40baad:	xor    eax,eax
  40baaf:	add    rsp,0x68
  40bab3:	pop    r15
  40bab5:	pop    r14
  40bab7:	pop    r13
  40bab9:	pop    r12
  40babb:	pop    rdi
  40babc:	pop    rsi
  40babd:	ret
  40babe:	mov    r14,QWORD PTR [r12+0x98]
  40bac6:	mov    rax,QWORD PTR [r12+0xa0]
  40bace:	mov    r12,rax
  40bad1:	xor    r15d,r15d
  40bad4:	test   r12,r12
  40bad7:	je     40bb3f <__swc_fn_7dafa2b1_000091_23214800+0xdf>
  40bad9:	nop    DWORD PTR [rax+0x0]
  40bae0:	mov    QWORD PTR [rsp+0x58],r12
  40bae5:	lea    r12,[r15*8+0x0]
  40baed:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40baf2:	mov    rcx,rax
  40baf5:	call   4090c0 <__swc_fn_7dafa2b1_000087_3953ef98>
  40bafa:	cmp    BYTE PTR [rax+0x2c],0xe
  40bafe:	jne    40bb30 <__swc_fn_7dafa2b1_000091_23214800+0xd0>
  40bb00:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40bb05:	lea    r8,[r13+rcx*1+0x0]
  40bb0a:	mov    rcx,rdi
  40bb0d:	mov    rdx,rax
  40bb10:	mov    r9,rsi
  40bb13:	call   40ba60 <__swc_fn_7dafa2b1_000091_23214800>
  40bb18:	test   al,al
  40bb1a:	je     40bb30 <__swc_fn_7dafa2b1_000091_23214800+0xd0>
  40bb1c:	mov    eax,0x1
  40bb21:	add    rsp,0x68
  40bb25:	pop    r15
  40bb27:	pop    r14
  40bb29:	pop    r13
  40bb2b:	pop    r12
  40bb2d:	pop    rdi
  40bb2e:	pop    rsi
  40bb2f:	ret
  40bb30:	add    r15,0x1
  40bb34:	mov    r12,QWORD PTR [rsp+0x58]
  40bb39:	sub    r12,0x1
  40bb3d:	jne    40bae0 <__swc_fn_7dafa2b1_000091_23214800+0x80>
  40bb3f:	xor    eax,eax
  40bb41:	add    rsp,0x68
  40bb45:	pop    r15
  40bb47:	pop    r14
  40bb49:	pop    r13
  40bb4b:	pop    r12
  40bb4d:	pop    rdi
  40bb4e:	pop    rsi
  40bb4f:	ret

000000000040bb50 <__swc_fn_7dafa2b1_000094_c2567a3b>:
  40bb50:	push   rbp
  40bb51:	push   rbx
  40bb52:	push   rsi
  40bb53:	push   rdi
  40bb54:	push   r12
  40bb56:	push   r13
  40bb58:	push   r14
  40bb5a:	push   r15
  40bb5c:	sub    rsp,0x38
  40bb60:	mov    rbp,rsp
  40bb63:	mov    rbx,r11
  40bb66:	mov    rsi,rdx
  40bb69:	mov    rdi,r8
  40bb6c:	mov    r12,r9
  40bb6f:	mov    QWORD PTR [rsp+0x18],r9
  40bb74:	mov    r13,r10
  40bb77:	movzx  r14d,BYTE PTR [rbp+0x80]
  40bb7f:	movzx  r15d,BYTE PTR [rbp+0x88]
  40bb87:	test   r11,r11
  40bb8a:	je     40bb90 <__swc_fn_7dafa2b1_000094_c2567a3b+0x40>
  40bb8c:	xor    eax,eax
  40bb8e:	mov    BYTE PTR [rbx],al
  40bb90:	test   r12,r12
  40bb93:	je     40bb9e <__swc_fn_7dafa2b1_000094_c2567a3b+0x4e>
  40bb95:	mov    QWORD PTR [r12+0x8],0x0
  40bb9e:	test   rcx,rcx
  40bba1:	je     40bba8 <__swc_fn_7dafa2b1_000094_c2567a3b+0x58>
  40bba3:	test   rsi,rsi
  40bba6:	jne    40bbbb <__swc_fn_7dafa2b1_000094_c2567a3b+0x6b>
  40bba8:	xor    eax,eax
  40bbaa:	add    rsp,0x38
  40bbae:	pop    r15
  40bbb0:	pop    r14
  40bbb2:	pop    r13
  40bbb4:	pop    r12
  40bbb6:	pop    rdi
  40bbb7:	pop    rsi
  40bbb8:	pop    rbx
  40bbb9:	pop    rbp
  40bbba:	ret
  40bbbb:	call   4090c0 <__swc_fn_7dafa2b1_000087_3953ef98>
  40bbc0:	mov    r12,rax
  40bbc3:	mov    al,r15b
  40bbc6:	test   r15b,r15b
  40bbc9:	jne    40bbd9 <__swc_fn_7dafa2b1_000094_c2567a3b+0x89>
  40bbcb:	mov    eax,DWORD PTR [r12+0x28]
  40bbd0:	and    eax,0x10000
  40bbd6:	setne  al
  40bbd9:	lea    r15,[rsp+0x8]
  40bbde:	mov    QWORD PTR [rsp+0x20],r15
  40bbe3:	rex mov BYTE PTR [rsp+0x8],al
  40bbe8:	test   DWORD PTR [rsi+0x28],0x400000
  40bbef:	je     40bc27 <__swc_fn_7dafa2b1_000094_c2567a3b+0xd7>
  40bbf1:	test   rsi,rsi
  40bbf4:	je     40bc14 <__swc_fn_7dafa2b1_000094_c2567a3b+0xc4>
  40bbf6:	mov    rax,QWORD PTR [rsi+0x38]
  40bbfa:	cmp    QWORD PTR [rax+0x10],rsi
  40bbfe:	jne    40bc14 <__swc_fn_7dafa2b1_000094_c2567a3b+0xc4>
  40bc00:	rex mov al,BYTE PTR [rsp+0x8]
  40bc05:	test   al,al
  40bc07:	sete   al
  40bc0a:	test   r14b,r14b
  40bc0d:	sete   cl
  40bc10:	test   al,cl
  40bc12:	je     40bc27 <__swc_fn_7dafa2b1_000094_c2567a3b+0xd7>
  40bc14:	xor    eax,eax
  40bc16:	add    rsp,0x38
  40bc1a:	pop    r15
  40bc1c:	pop    r14
  40bc1e:	pop    r13
  40bc20:	pop    r12
  40bc22:	pop    rdi
  40bc23:	pop    rsi
  40bc24:	pop    rbx
  40bc25:	pop    rbp
  40bc26:	ret
  40bc27:	mov    r15,r12
  40bc2a:	test   r14b,r14b
  40bc2d:	jne    40bc44 <__swc_fn_7dafa2b1_000094_c2567a3b+0xf4>
  40bc2f:	cmp    BYTE PTR [r12+0x2c],0x6
  40bc35:	jne    40bc44 <__swc_fn_7dafa2b1_000094_c2567a3b+0xf4>
  40bc37:	mov    rcx,QWORD PTR [r12+0x40]
  40bc3c:	call   4090c0 <__swc_fn_7dafa2b1_000087_3953ef98>
  40bc41:	mov    r15,rax
  40bc44:	test   r14b,r14b
  40bc47:	je     40bc4d <__swc_fn_7dafa2b1_000094_c2567a3b+0xfd>
  40bc49:	mov    r15,QWORD PTR [r15+0x30]
  40bc4d:	mov    rcx,rsi
  40bc50:	call   4090c0 <__swc_fn_7dafa2b1_000087_3953ef98>
  40bc55:	mov    rsi,rax
  40bc58:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40bc5d:	je     40bc94 <__swc_fn_7dafa2b1_000094_c2567a3b+0x144>
  40bc5f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40bc64:	je     40bc94 <__swc_fn_7dafa2b1_000094_c2567a3b+0x144>
  40bc66:	mov    eax,DWORD PTR [rsi+0x28]
  40bc69:	and    eax,0x10000
  40bc6f:	je     40bc94 <__swc_fn_7dafa2b1_000094_c2567a3b+0x144>
  40bc71:	rex mov al,BYTE PTR [rsp+0x8]
  40bc76:	test   al,al
  40bc78:	jne    40bc8d <__swc_fn_7dafa2b1_000094_c2567a3b+0x13d>
  40bc7a:	xor    eax,eax
  40bc7c:	add    rsp,0x38
  40bc80:	pop    r15
  40bc82:	pop    r14
  40bc84:	pop    r13
  40bc86:	pop    r12
  40bc88:	pop    rdi
  40bc89:	pop    rsi
  40bc8a:	pop    rbx
  40bc8b:	pop    rbp
  40bc8c:	ret
  40bc8d:	mov    rax,QWORD PTR [rsi+0x30]
  40bc91:	mov    rsi,rax
  40bc94:	mov    r14b,r13b
  40bc97:	test   rbx,rbx
  40bc9a:	je     40bcd0 <__swc_fn_7dafa2b1_000094_c2567a3b+0x180>
  40bc9c:	cmp    BYTE PTR [r12+0x2c],0x6
  40bca2:	jne    40bcd0 <__swc_fn_7dafa2b1_000094_c2567a3b+0x180>
  40bca4:	lea    rdx,[rip+0x65f5]        # 4122a0 <__swc_rdata_base_7dafa2b1+0x190>
  40bcab:	mov    rcx,rsi
  40bcae:	xor    r8d,r8d
  40bcb1:	call   40fda0 <__swc_fn_7dafa2b1_000095_63c1827b>
  40bcb6:	test   al,al
  40bcb8:	je     40bcd0 <__swc_fn_7dafa2b1_000094_c2567a3b+0x180>
  40bcba:	mov    BYTE PTR [rbx],0x1
  40bcbd:	xor    eax,eax
  40bcbf:	add    rsp,0x38
  40bcc3:	pop    r15
  40bcc5:	pop    r14
  40bcc7:	pop    r13
  40bcc9:	pop    r12
  40bccb:	pop    rdi
  40bccc:	pop    rsi
  40bccd:	pop    rbx
  40bcce:	pop    rbp
  40bccf:	ret
  40bcd0:	test   rdi,rdi
  40bcd3:	jne    40bced <__swc_fn_7dafa2b1_000094_c2567a3b+0x19d>
  40bcd5:	test   r13b,r13b
  40bcd8:	jne    40bced <__swc_fn_7dafa2b1_000094_c2567a3b+0x19d>
  40bcda:	xor    eax,eax
  40bcdc:	add    rsp,0x38
  40bce0:	pop    r15
  40bce2:	pop    r14
  40bce4:	pop    r13
  40bce6:	pop    r12
  40bce8:	pop    rdi
  40bce9:	pop    rsi
  40bcea:	pop    rbx
  40bceb:	pop    rbp
  40bcec:	ret
  40bced:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40bcf2:	jne    40bda8 <__swc_fn_7dafa2b1_000094_c2567a3b+0x258>
  40bcf8:	mov    rcx,r15
  40bcfb:	mov    rdx,rsi
  40bcfe:	xor    r8d,r8d
  40bd01:	call   40fda0 <__swc_fn_7dafa2b1_000095_63c1827b>
  40bd06:	test   al,al
  40bd08:	jne    40bda8 <__swc_fn_7dafa2b1_000094_c2567a3b+0x258>
  40bd0e:	test   DWORD PTR [rsi+0x28],0x10000
  40bd15:	je     40bd33 <__swc_fn_7dafa2b1_000094_c2567a3b+0x1e3>
  40bd17:	rex mov al,BYTE PTR [rsp+0x8]
  40bd1c:	test   al,al
  40bd1e:	jne    40bd33 <__swc_fn_7dafa2b1_000094_c2567a3b+0x1e3>
  40bd20:	xor    eax,eax
  40bd22:	add    rsp,0x38
  40bd26:	pop    r15
  40bd28:	pop    r14
  40bd2a:	pop    r13
  40bd2c:	pop    r12
  40bd2e:	pop    rdi
  40bd2f:	pop    rsi
  40bd30:	pop    rbx
  40bd31:	pop    rbp
  40bd32:	ret
  40bd33:	test   rdi,rdi
  40bd36:	jne    40bd4b <__swc_fn_7dafa2b1_000094_c2567a3b+0x1fb>
  40bd38:	xor    eax,eax
  40bd3a:	add    rsp,0x38
  40bd3e:	pop    r15
  40bd40:	pop    r14
  40bd42:	pop    r13
  40bd44:	pop    r12
  40bd46:	pop    rdi
  40bd47:	pop    rsi
  40bd48:	pop    rbx
  40bd49:	pop    rbp
  40bd4a:	ret
  40bd4b:	mov    rcx,QWORD PTR [rsi+0x40]
  40bd4f:	call   4090c0 <__swc_fn_7dafa2b1_000087_3953ef98>
  40bd54:	mov    rsi,rax
  40bd57:	mov    rax,QWORD PTR [rdi]
  40bd5a:	mov    rdi,rax
  40bd5d:	test   rax,rax
  40bd60:	jne    40bda3 <__swc_fn_7dafa2b1_000094_c2567a3b+0x253>
  40bd62:	test   rbx,rbx
  40bd65:	je     40bda3 <__swc_fn_7dafa2b1_000094_c2567a3b+0x253>
  40bd67:	mov    rcx,r15
  40bd6a:	mov    rdx,rsi
  40bd6d:	xor    r8d,r8d
  40bd70:	call   40fda0 <__swc_fn_7dafa2b1_000095_63c1827b>
  40bd75:	mov    rcx,rax
  40bd78:	test   al,al
  40bd7a:	jne    40bd9c <__swc_fn_7dafa2b1_000094_c2567a3b+0x24c>
  40bd7c:	mov    rcx,r15
  40bd7f:	mov    rdx,rsi
  40bd82:	call   409100 <__swc_fn_7dafa2b1_000090_d182c4dc>
  40bd87:	mov    rcx,rax
  40bd8a:	test   al,al
  40bd8c:	jne    40bd9c <__swc_fn_7dafa2b1_000094_c2567a3b+0x24c>
  40bd8e:	mov    rcx,rsi
  40bd91:	mov    rdx,r15
  40bd94:	call   409100 <__swc_fn_7dafa2b1_000090_d182c4dc>
  40bd99:	mov    rcx,rax
  40bd9c:	test   cl,cl
  40bd9e:	setne  al
  40bda1:	mov    BYTE PTR [rbx],al
  40bda3:	xor    eax,eax
  40bda5:	mov    r14b,al
  40bda8:	test   rdi,rdi
  40bdab:	jne    40bdc5 <__swc_fn_7dafa2b1_000094_c2567a3b+0x275>
  40bdad:	test   r14b,r14b
  40bdb0:	jne    40bdc5 <__swc_fn_7dafa2b1_000094_c2567a3b+0x275>
  40bdb2:	xor    eax,eax
  40bdb4:	add    rsp,0x38
  40bdb8:	pop    r15
  40bdba:	pop    r14
  40bdbc:	pop    r13
  40bdbe:	pop    r12
  40bdc0:	pop    rdi
  40bdc1:	pop    rsi
  40bdc2:	pop    rbx
  40bdc3:	pop    rbp
  40bdc4:	ret
  40bdc5:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40bdca:	je     40bdd6 <__swc_fn_7dafa2b1_000094_c2567a3b+0x286>
  40bdcc:	mov    r12,QWORD PTR [rsp+0x18]
  40bdd1:	jmp    40be5e <__swc_fn_7dafa2b1_000094_c2567a3b+0x30e>
  40bdd6:	mov    r12,QWORD PTR [rsp+0x18]
  40bddb:	test   r12,r12
  40bdde:	jne    40bdf2 <__swc_fn_7dafa2b1_000094_c2567a3b+0x2a2>
  40bde0:	mov    rcx,r15
  40bde3:	mov    rdx,rsi
  40bde6:	xor    r8d,r8d
  40bde9:	call   40fda0 <__swc_fn_7dafa2b1_000095_63c1827b>
  40bdee:	test   al,al
  40bdf0:	jne    40be5e <__swc_fn_7dafa2b1_000094_c2567a3b+0x30e>
  40bdf2:	test   DWORD PTR [rsi+0x28],0x10000
  40bdf9:	je     40be17 <__swc_fn_7dafa2b1_000094_c2567a3b+0x2c7>
  40bdfb:	rex mov al,BYTE PTR [rsp+0x8]
  40be00:	test   al,al
  40be02:	jne    40be17 <__swc_fn_7dafa2b1_000094_c2567a3b+0x2c7>
  40be04:	xor    eax,eax
  40be06:	add    rsp,0x38
  40be0a:	pop    r15
  40be0c:	pop    r14
  40be0e:	pop    r13
  40be10:	pop    r12
  40be12:	pop    rdi
  40be13:	pop    rsi
  40be14:	pop    rbx
  40be15:	pop    rbp
  40be16:	ret
  40be17:	test   rdi,rdi
  40be1a:	jne    40be2f <__swc_fn_7dafa2b1_000094_c2567a3b+0x2df>
  40be1c:	xor    eax,eax
  40be1e:	add    rsp,0x38
  40be22:	pop    r15
  40be24:	pop    r14
  40be26:	pop    r13
  40be28:	pop    r12
  40be2a:	pop    rdi
  40be2b:	pop    rsi
  40be2c:	pop    rbx
  40be2d:	pop    rbp
  40be2e:	ret
  40be2f:	cmp    QWORD PTR [rdi+0x8],0x0
  40be34:	jne    40be49 <__swc_fn_7dafa2b1_000094_c2567a3b+0x2f9>
  40be36:	xor    eax,eax
  40be38:	add    rsp,0x38
  40be3c:	pop    r15
  40be3e:	pop    r14
  40be40:	pop    r13
  40be42:	pop    r12
  40be44:	pop    rdi
  40be45:	pop    rsi
  40be46:	pop    rbx
  40be47:	pop    rbp
  40be48:	ret
  40be49:	mov    rax,QWORD PTR [rdi+0x8]
  40be4d:	mov    rax,QWORD PTR [rax]
  40be50:	mov    rsi,rax
  40be53:	mov    rdi,QWORD PTR [rdi]
  40be56:	mov    eax,0x1
  40be5b:	mov    r14b,al
  40be5e:	test   rdi,rdi
  40be61:	mov    rbx,QWORD PTR [rsp+0x20]
  40be66:	jne    40beb0 <__swc_fn_7dafa2b1_000094_c2567a3b+0x360>
  40be68:	test   r14b,r14b
  40be6b:	je     40be9d <__swc_fn_7dafa2b1_000094_c2567a3b+0x34d>
  40be6d:	test   r12,r12
  40be70:	je     40be9d <__swc_fn_7dafa2b1_000094_c2567a3b+0x34d>
  40be72:	mov    rcx,r15
  40be75:	mov    rdx,rsi
  40be78:	xor    r8d,r8d
  40be7b:	mov    r9,r12
  40be7e:	mov    rbx,QWORD PTR [rsp+0x20]
  40be83:	movzx  r10d,BYTE PTR [rbx]
  40be87:	call   40ba40 <__swc_fn_7dafa2b1_000088_ef55f6e4>
  40be8c:	add    rsp,0x38
  40be90:	pop    r15
  40be92:	pop    r14
  40be94:	pop    r13
  40be96:	pop    r12
  40be98:	pop    rdi
  40be99:	pop    rsi
  40be9a:	pop    rbx
  40be9b:	pop    rbp
  40be9c:	ret
  40be9d:	xor    eax,eax
  40be9f:	add    rsp,0x38
  40bea3:	pop    r15
  40bea5:	pop    r14
  40bea7:	pop    r13
  40bea9:	pop    r12
  40beab:	pop    rdi
  40beac:	pop    rsi
  40bead:	pop    rbx
  40beae:	pop    rbp
  40beaf:	ret
  40beb0:	mov    r13,rsi
  40beb3:	mov    QWORD PTR [rsp+0x28],rdi
  40beb8:	cmp    BYTE PTR [r15+0x2c],0xe
  40bebd:	sete   al
  40bec0:	mov    r14b,al
  40bec3:	jne    40bed7 <__swc_fn_7dafa2b1_000094_c2567a3b+0x387>
  40bec5:	mov    rcx,rsi
  40bec8:	mov    rdx,r15
  40becb:	call   409100 <__swc_fn_7dafa2b1_000090_d182c4dc>
  40bed0:	mov    r14b,al
  40bed3:	test   al,al
  40bed5:	jne    40bf0c <__swc_fn_7dafa2b1_000094_c2567a3b+0x3bc>
  40bed7:	cmp    BYTE PTR [r15+0x2c],0x12
  40bedc:	je     40bf0c <__swc_fn_7dafa2b1_000094_c2567a3b+0x3bc>
  40bede:	mov    rcx,r15
  40bee1:	mov    rdx,rsi
  40bee4:	mov    r8,rdi
  40bee7:	mov    r9,r12
  40beea:	mov    rax,rbx
  40beed:	movzx  r10d,BYTE PTR [rax]
  40bef1:	call   40ba40 <__swc_fn_7dafa2b1_000088_ef55f6e4>
  40bef6:	test   rax,rax
  40bef9:	je     40bf0c <__swc_fn_7dafa2b1_000094_c2567a3b+0x3bc>
  40befb:	add    rsp,0x38
  40beff:	pop    r15
  40bf01:	pop    r14
  40bf03:	pop    r13
  40bf05:	pop    r12
  40bf07:	pop    rdi
  40bf08:	pop    rsi
  40bf09:	pop    rbx
  40bf0a:	pop    rbp
  40bf0b:	ret
  40bf0c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40bf11:	jne    40bf30 <__swc_fn_7dafa2b1_000094_c2567a3b+0x3e0>
  40bf13:	mov    rax,QWORD PTR [rsi+0xd8]
  40bf1a:	test   rax,rax
  40bf1d:	je     40bf30 <__swc_fn_7dafa2b1_000094_c2567a3b+0x3e0>
  40bf1f:	add    rdi,QWORD PTR [rax+0x8]
  40bf23:	mov    rax,QWORD PTR [rdi]
  40bf26:	sub    rdi,QWORD PTR [rax+0x8]
  40bf2a:	mov    rax,QWORD PTR [rax]
  40bf2d:	mov    rsi,rax
  40bf30:	test   r14b,r14b
  40bf33:	je     40bf5f <__swc_fn_7dafa2b1_000094_c2567a3b+0x40f>
  40bf35:	mov    rcx,r15
  40bf38:	mov    rdx,rsi
  40bf3b:	mov    r8,rdi
  40bf3e:	mov    r9,r13
  40bf41:	mov    r14,QWORD PTR [rsp+0x28]
  40bf46:	mov    r10,r14
  40bf49:	call   40fc80 <__swc_fn_7dafa2b1_000092_c1c9085b>
  40bf4e:	add    rsp,0x38
  40bf52:	pop    r15
  40bf54:	pop    r14
  40bf56:	pop    r13
  40bf58:	pop    r12
  40bf5a:	pop    rdi
  40bf5b:	pop    rsi
  40bf5c:	pop    rbx
  40bf5d:	pop    rbp
  40bf5e:	ret
  40bf5f:	mov    rcx,r15
  40bf62:	mov    rdx,rsi
  40bf65:	mov    r8,rdi
  40bf68:	mov    r9,r12
  40bf6b:	movzx  r10d,BYTE PTR [rbx]
  40bf6f:	call   40ba40 <__swc_fn_7dafa2b1_000088_ef55f6e4>
  40bf74:	add    rsp,0x38
  40bf78:	pop    r15
  40bf7a:	pop    r14
  40bf7c:	pop    r13
  40bf7e:	pop    r12
  40bf80:	pop    rdi
  40bf81:	pop    rsi
  40bf82:	pop    rbx
  40bf83:	pop    rbp
  40bf84:	ret
	...

000000000040bf90 <__swc_fn_7dafa2b1_000097_93bfe675>:
  40bf90:	push   rbx
  40bf91:	push   rsi
  40bf92:	sub    rsp,0x18
  40bf96:	mov    rbx,rcx
  40bf99:	mov    rcx,QWORD PTR [rip+0x170a0]        # 423040 <__swc_bss_base_7dafa2b1>
  40bfa0:	test   rcx,rcx
  40bfa3:	jne    40bfb5 <__swc_fn_7dafa2b1_000097_93bfe675+0x25>
  40bfa5:	call   4119a0 <__swc_fn_7dafa2b1_000170_994c8876>
  40bfaa:	lea    rcx,[rax+0x1]
  40bfae:	mov    QWORD PTR [rip+0x1708b],rcx        # 423040 <__swc_bss_base_7dafa2b1>
  40bfb5:	dec    rcx
  40bfb8:	call   40e840 <__swc_fn_7dafa2b1_000172_360af05d>
  40bfbd:	mov    rsi,rax
  40bfc0:	mov    rax,QWORD PTR [rsi+0x8]
  40bfc4:	test   rax,rax
  40bfc7:	jne    40c017 <__swc_fn_7dafa2b1_000097_93bfe675+0x87>
  40bfc9:	call   4091f0 <__swc_fn_7dafa2b1_000096_ad13d15c>
  40bfce:	test   al,al
  40bfd0:	jne    40c017 <__swc_fn_7dafa2b1_000097_93bfe675+0x87>
  40bfd2:	lea    rdx,[rip+0x17267]        # 423240 <__swc_bss_base_7dafa2b1+0x200>
  40bfd9:	mov    rcx,rdx
  40bfdc:	call   40ef50 <__swc_fn_7dafa2b1_000041_eb6108f2>
  40bfe1:	test   al,al
  40bfe3:	jne    40bff4 <__swc_fn_7dafa2b1_000097_93bfe675+0x64>
  40bfe5:	mov    rcx,rdx
  40bfe8:	call   407ae0 <__swc_fn_7dafa2b1_000039_14f56618>
  40bfed:	lea    rdx,[rip+0x1724c]        # 423240 <__swc_bss_base_7dafa2b1+0x200>
  40bff4:	mov    QWORD PTR [rsp+0x8],rdx
  40bff9:	lea    rax,[rip+0x6270]        # 412270 <__swc_rdata_base_7dafa2b1+0x160>
  40c000:	mov    QWORD PTR [rsp+0x10],rax
  40c005:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c00b:	vmovups XMMWORD PTR [rsi],xmm0
  40c00f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c017:	vmovups xmm0,XMMWORD PTR [rsi]
  40c01b:	vmovups XMMWORD PTR [rbx],xmm0
  40c01f:	mov    rax,rbx
  40c022:	add    rsp,0x18
  40c026:	pop    rsi
  40c027:	pop    rbx
  40c028:	ret
  40c029:	add    BYTE PTR [rax],al
  40c02b:	add    BYTE PTR [rax],al
  40c02d:	add    BYTE PTR [rax],al
	...

000000000040c030 <__swc_fn_7dafa2b1_000100_65137b72>:
  40c030:	sub    rsp,0x8
  40c034:	call   410b40 <__swc_fn_7dafa2b1_000122_0a5fa85a>
  40c039:	add    rsp,0x8
  40c03d:	ret
	...

000000000040c040 <__swc_fn_7dafa2b1_000103_e34f54dc>:
  40c040:	push   rbx
  40c041:	push   rsi
  40c042:	sub    rsp,0x28
  40c046:	mov    rbx,rcx
  40c049:	xor    esi,esi
  40c04b:	jmp    40c060 <__swc_fn_7dafa2b1_000103_e34f54dc+0x20>
  40c04d:	nop    DWORD PTR [rax]
  40c050:	mov    QWORD PTR [rbx+0x28],rsi
  40c054:	mov    rsi,rbx
  40c057:	mov    rbx,rax
  40c05a:	nop    WORD PTR [rax+rax*1+0x0]
  40c060:	test   rbx,rbx
  40c063:	je     40c0c3 <__swc_fn_7dafa2b1_000103_e34f54dc+0x83>
  40c065:	mov    rcx,rbx
  40c068:	mov    edx,0x1
  40c06d:	call   40fa00 <__swc_fn_7dafa2b1_000083_63a67586>
  40c072:	cmp    rax,0x1
  40c076:	jne    40c0c3 <__swc_fn_7dafa2b1_000103_e34f54dc+0x83>
  40c078:	mov    r10,QWORD PTR [rbx+0x18]
  40c07c:	mov    rcx,r10
  40c07f:	mov    edx,0x1
  40c084:	call   40fa00 <__swc_fn_7dafa2b1_000083_63a67586>
  40c089:	cmp    rax,0x1
  40c08d:	jne    40c09c <__swc_fn_7dafa2b1_000103_e34f54dc+0x5c>
  40c08f:	mov    rcx,r10
  40c092:	call   409390 <__swc_fn_7dafa2b1_000102_d0b19c14>
  40c097:	test   rax,rax
  40c09a:	jne    40c050 <__swc_fn_7dafa2b1_000103_e34f54dc+0x10>
  40c09c:	mov    rax,QWORD PTR [rbx+0x20]
  40c0a0:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c0a5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c0ab:	lea    rcx,[rsp+0x8]
  40c0b0:	mov    rdx,rbx
  40c0b3:	mov    r8d,0x30
  40c0b9:	mov    rbx,rax
  40c0bc:	call   410160 <__swc_fn_7dafa2b1_000101_d4bdcaa4>
  40c0c1:	jmp    40c060 <__swc_fn_7dafa2b1_000103_e34f54dc+0x20>
  40c0c3:	test   rsi,rsi
  40c0c6:	jne    40c0cf <__swc_fn_7dafa2b1_000103_e34f54dc+0x8f>
  40c0c8:	add    rsp,0x28
  40c0cc:	pop    rsi
  40c0cd:	pop    rbx
  40c0ce:	ret
  40c0cf:	mov    rax,rsi
  40c0d2:	mov    rsi,QWORD PTR [rsi+0x28]
  40c0d6:	mov    rbx,QWORD PTR [rax+0x20]
  40c0da:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40c0df:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40c0e5:	lea    rcx,[rsp+0x18]
  40c0ea:	mov    rdx,rax
  40c0ed:	mov    r8d,0x30
  40c0f3:	call   410160 <__swc_fn_7dafa2b1_000101_d4bdcaa4>
  40c0f8:	jmp    40c060 <__swc_fn_7dafa2b1_000103_e34f54dc+0x20>
  40c0fd:	add    BYTE PTR [rax],al
	...

000000000040c100 <__swc_fn_7dafa2b1_000106_5a85fcf5>:
  40c100:	push   rbx
  40c101:	push   rsi
  40c102:	push   rdi
  40c103:	push   r12
  40c105:	push   r13
  40c107:	sub    rsp,0x20
  40c10b:	mov    rbx,rcx
  40c10e:	lea    rsi,[rcx+0x6f8]
  40c115:	mov    edi,0x4
  40c11a:	mov    r12,rsi
  40c11d:	test   rdi,rdi
  40c120:	je     40c16a <__swc_fn_7dafa2b1_000106_5a85fcf5+0x6a>
  40c122:	cs nop WORD PTR [rax+rax*1+0x0]
  40c12c:	nop    DWORD PTR [rax+0x0]
  40c130:	mov    rcx,QWORD PTR [r12+0x10]
  40c135:	mov    QWORD PTR [r12+0x10],0x0
  40c13e:	vxorps xmm0,xmm0,xmm0
  40c142:	vmovups XMMWORD PTR [r12],xmm0
  40c148:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40c14f:	mov    DWORD PTR [r12+0x20],0x0
  40c158:	call   4101b0 <__swc_fn_7dafa2b1_000104_2fdd2c61>
  40c15d:	add    r12,0x90
  40c164:	sub    rdi,0x1
  40c168:	jne    40c130 <__swc_fn_7dafa2b1_000106_5a85fcf5+0x30>
  40c16a:	mov    rax,QWORD PTR [rbx+0x938]
  40c171:	mov    rdi,rax
  40c174:	test   rdi,rdi
  40c177:	je     40c1d1 <__swc_fn_7dafa2b1_000106_5a85fcf5+0xd1>
  40c179:	nop    DWORD PTR [rax+0x0]
  40c180:	mov    r12d,0x10
  40c186:	lea    r13,[rdi+0x18]
  40c18a:	test   r12,r12
  40c18d:	je     40c1c6 <__swc_fn_7dafa2b1_000106_5a85fcf5+0xc6>
  40c18f:	nop
  40c190:	mov    rcx,QWORD PTR [r13+0x10]
  40c194:	mov    QWORD PTR [r13+0x10],0x0
  40c19c:	vxorps xmm0,xmm0,xmm0
  40c1a0:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40c1a6:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40c1ac:	mov    DWORD PTR [r13+0x20],0x0
  40c1b4:	call   4101b0 <__swc_fn_7dafa2b1_000104_2fdd2c61>
  40c1b9:	add    r13,0x90
  40c1c0:	sub    r12,0x1
  40c1c4:	jne    40c190 <__swc_fn_7dafa2b1_000106_5a85fcf5+0x90>
  40c1c6:	mov    rax,QWORD PTR [rdi]
  40c1c9:	mov    rdi,rax
  40c1cc:	test   rax,rax
  40c1cf:	jne    40c180 <__swc_fn_7dafa2b1_000106_5a85fcf5+0x80>
  40c1d1:	vxorps xmm0,xmm0,xmm0
  40c1d5:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40c1dd:	mov    DWORD PTR [rbx+0x9b0],0x0
  40c1e7:	mov    DWORD PTR [rbx+0x9a8],0x0
  40c1f1:	mov    edi,0x4
  40c1f6:	mov    r12,rsi
  40c1f9:	lea    rsi,[rsi+0x38]
  40c1fd:	test   rdi,rdi
  40c200:	je     40c22c <__swc_fn_7dafa2b1_000106_5a85fcf5+0x12c>
  40c202:	cs nop WORD PTR [rax+rax*1+0x0]
  40c20c:	nop    DWORD PTR [rax+0x0]
  40c210:	mov    rcx,rsi
  40c213:	call   40a210 <__swc_fn_7dafa2b1_000162_13ead2ff>
  40c218:	add    rsi,0x90
  40c21f:	add    r12,0x90
  40c226:	sub    rdi,0x1
  40c22a:	jne    40c210 <__swc_fn_7dafa2b1_000106_5a85fcf5+0x110>
  40c22c:	mov    rax,QWORD PTR [rbx+0x938]
  40c233:	mov    rdi,rax
  40c236:	mov    QWORD PTR [rbx+0x938],0x0
  40c241:	test   rdi,rdi
  40c244:	je     40c2b5 <__swc_fn_7dafa2b1_000106_5a85fcf5+0x1b5>
  40c24a:	nop    WORD PTR [rax+rax*1+0x0]
  40c250:	mov    esi,0x10
  40c255:	lea    r12,[rdi+0x18]
  40c259:	lea    r13,[rdi+0x50]
  40c25d:	test   rsi,rsi
  40c260:	je     40c28c <__swc_fn_7dafa2b1_000106_5a85fcf5+0x18c>
  40c262:	cs nop WORD PTR [rax+rax*1+0x0]
  40c26c:	nop    DWORD PTR [rax+0x0]
  40c270:	mov    rcx,r13
  40c273:	call   40a210 <__swc_fn_7dafa2b1_000162_13ead2ff>
  40c278:	add    r13,0x90
  40c27f:	add    r12,0x90
  40c286:	sub    rsi,0x1
  40c28a:	jne    40c270 <__swc_fn_7dafa2b1_000106_5a85fcf5+0x170>
  40c28c:	mov    rax,QWORD PTR [rdi]
  40c28f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40c294:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c29a:	lea    rcx,[rsp+0x8]
  40c29f:	mov    rdx,rdi
  40c2a2:	mov    r8d,0x918
  40c2a8:	mov    rdi,rax
  40c2ab:	call   410160 <__swc_fn_7dafa2b1_000101_d4bdcaa4>
  40c2b0:	test   rdi,rdi
  40c2b3:	jne    40c250 <__swc_fn_7dafa2b1_000106_5a85fcf5+0x150>
  40c2b5:	lea    rcx,[rbx+0x68]
  40c2b9:	call   40a210 <__swc_fn_7dafa2b1_000162_13ead2ff>
  40c2be:	add    rsp,0x20
  40c2c2:	pop    r13
  40c2c4:	pop    r12
  40c2c6:	pop    rdi
  40c2c7:	pop    rsi
  40c2c8:	pop    rbx
  40c2c9:	ret
  40c2ca:	add    BYTE PTR [rax],al
  40c2cc:	add    BYTE PTR [rax],al
	...

000000000040c2d0 <__swc_fn_7dafa2b1_000109_c51c3158>:
  40c2d0:	xor    eax,eax
  40c2d2:	cs nop WORD PTR [rax+rax*1+0x0]
  40c2dc:	nop    DWORD PTR [rax+0x0]
  40c2e0:	mov    r9,r8
  40c2e3:	sub    r9,rax
  40c2e6:	cmp    r9,0x40
  40c2ea:	jb     40c328 <__swc_fn_7dafa2b1_000109_c51c3158+0x58>
  40c2ec:	lea    r9,[rcx+rax*1]
  40c2f0:	lea    r10,[rdx+rax*1]
  40c2f4:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40c2fa:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40c300:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40c306:	vmovups xmm3,XMMWORD PTR [r10]
  40c30b:	vmovups XMMWORD PTR [r9],xmm3
  40c310:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40c316:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40c31c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40c322:	lea    rax,[rax+0x40]
  40c326:	jmp    40c2e0 <__swc_fn_7dafa2b1_000109_c51c3158+0x10>
  40c328:	nop    DWORD PTR [rax+rax*1+0x0]
  40c330:	mov    r9,r8
  40c333:	sub    r9,rax
  40c336:	cmp    r9,0x10
  40c33a:	jb     40c354 <__swc_fn_7dafa2b1_000109_c51c3158+0x84>
  40c33c:	lea    r9,[rdx+rax*1]
  40c340:	lea    r10,[rcx+rax*1]
  40c344:	vmovups xmm0,XMMWORD PTR [r9]
  40c349:	vmovups XMMWORD PTR [r10],xmm0
  40c34e:	lea    rax,[rax+0x10]
  40c352:	jmp    40c330 <__swc_fn_7dafa2b1_000109_c51c3158+0x60>
  40c354:	cs nop WORD PTR [rax+rax*1+0x0]
  40c35e:	xchg   ax,ax
  40c360:	mov    r9,r8
  40c363:	sub    r9,rax
  40c366:	cmp    r9,0x8
  40c36a:	jb     40c37d <__swc_fn_7dafa2b1_000109_c51c3158+0xad>
  40c36c:	lea    r9,[rcx+rax*1]
  40c370:	mov    r10,QWORD PTR [rdx+rax*1]
  40c374:	mov    QWORD PTR [r9],r10
  40c377:	lea    rax,[rax+0x8]
  40c37b:	jmp    40c360 <__swc_fn_7dafa2b1_000109_c51c3158+0x90>
  40c37d:	cmp    rax,r8
  40c380:	jae    40c3a0 <__swc_fn_7dafa2b1_000109_c51c3158+0xd0>
  40c382:	cs nop WORD PTR [rax+rax*1+0x0]
  40c38c:	nop    DWORD PTR [rax+0x0]
  40c390:	mov    r9b,BYTE PTR [rdx+rax*1]
  40c394:	mov    BYTE PTR [rcx+rax*1],r9b
  40c398:	inc    rax
  40c39b:	cmp    rax,r8
  40c39e:	jb     40c390 <__swc_fn_7dafa2b1_000109_c51c3158+0xc0>
  40c3a0:	ret
	...

000000000040c3b0 <__swc_fn_7dafa2b1_000112_6814119b>:
  40c3b0:	push   rbx
  40c3b1:	push   r12
  40c3b3:	push   rdi
  40c3b4:	push   rsi
  40c3b5:	push   r13
  40c3b7:	push   r14
  40c3b9:	push   r15
  40c3bb:	sub    rsp,0x170
  40c3c2:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40c3cb:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40c3d4:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40c3dd:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40c3e6:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40c3ef:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40c3f8:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40c401:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40c40a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40c413:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40c41c:	mov    ebx,edx
  40c41e:	mov    QWORD PTR [rsp+0xa8],rbx
  40c426:	mov    r12d,ecx
  40c429:	test   edx,edx
  40c42b:	jne    40c442 <__swc_fn_7dafa2b1_000112_6814119b+0x92>
  40c42d:	xor    eax,eax
  40c42f:	add    rsp,0x170
  40c436:	pop    r15
  40c438:	pop    r14
  40c43a:	pop    r13
  40c43c:	pop    rsi
  40c43d:	pop    rdi
  40c43e:	pop    r12
  40c440:	pop    rbx
  40c441:	ret
  40c442:	lea    rdi,[rip+0x612f]        # 412578 <__swc_rdata_base_7dafa2b1+0x468>
  40c449:	mov    esi,0x90000
  40c44e:	xor    eax,eax
  40c450:	call   4070b0 <open@plt>
  40c455:	mov    r13,rax
  40c458:	mov    QWORD PTR [rsp+0xb0],rax
  40c460:	test   eax,eax
  40c462:	jge    40c46b <__swc_fn_7dafa2b1_000112_6814119b+0xbb>
  40c464:	xor    eax,eax
  40c466:	jmp    40c966 <__swc_fn_7dafa2b1_000112_6814119b+0x5b6>
  40c46b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c470:	movsxd rdi,r13d
  40c473:	mov    esi,0x2
  40c478:	xor    eax,eax
  40c47a:	call   4070c0 <flock@plt>
  40c47f:	test   eax,eax
  40c481:	je     40c4a0 <__swc_fn_7dafa2b1_000112_6814119b+0xf0>
  40c483:	xor    eax,eax
  40c485:	call   4070d0 <__errno_location@plt>
  40c48a:	cmp    DWORD PTR [rax],0x4
  40c48d:	je     40c470 <__swc_fn_7dafa2b1_000112_6814119b+0xc0>
  40c48f:	movsxd rdi,r13d
  40c492:	xor    eax,eax
  40c494:	call   4070e0 <close@plt>
  40c499:	xor    eax,eax
  40c49b:	jmp    40c966 <__swc_fn_7dafa2b1_000112_6814119b+0x5b6>
  40c4a0:	lea    r14,[rsp+0x8]
  40c4a5:	mov    QWORD PTR [rsp+0xb8],r14
  40c4ad:	vxorps xmm0,xmm0,xmm0
  40c4b1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c4b7:	mov    QWORD PTR [rsp+0x18],0x0
  40c4c0:	mov    WORD PTR [rsp+0x20],0x0
  40c4c7:	mov    DWORD PTR [r14],0x67617753
  40c4ce:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40c4d6:	xor    eax,eax
  40c4d8:	call   4070f0 <getpid@plt>
  40c4dd:	mov    ecx,eax
  40c4df:	mov    eax,0x1c
  40c4e4:	shrx   eax,ecx,eax
  40c4e9:	and    eax,0xf
  40c4ec:	mov    rdx,QWORD PTR [rip+0x60a5]        # 412598 <__swc_rdata_base_7dafa2b1+0x488>
  40c4f3:	mov    al,BYTE PTR [rdx+rax*1]
  40c4f6:	rex mov BYTE PTR [rsp+0x10],al
  40c4fb:	mov    eax,0x1c
  40c500:	shrx   eax,r12d,eax
  40c505:	and    eax,0xf
  40c508:	mov    al,BYTE PTR [rdx+rax*1]
  40c50b:	rex mov BYTE PTR [rsp+0x19],al
  40c510:	mov    eax,0x18
  40c515:	shrx   eax,ecx,eax
  40c51a:	and    eax,0xf
  40c51d:	mov    al,BYTE PTR [rdx+rax*1]
  40c520:	rex mov BYTE PTR [rsp+0x11],al
  40c525:	mov    eax,0x18
  40c52a:	shrx   eax,r12d,eax
  40c52f:	and    eax,0xf
  40c532:	mov    al,BYTE PTR [rdx+rax*1]
  40c535:	rex mov BYTE PTR [rsp+0x1a],al
  40c53a:	mov    eax,0x14
  40c53f:	shrx   eax,ecx,eax
  40c544:	and    eax,0xf
  40c547:	mov    al,BYTE PTR [rdx+rax*1]
  40c54a:	rex mov BYTE PTR [rsp+0x12],al
  40c54f:	mov    eax,0x14
  40c554:	shrx   eax,r12d,eax
  40c559:	and    eax,0xf
  40c55c:	mov    al,BYTE PTR [rdx+rax*1]
  40c55f:	rex mov BYTE PTR [rsp+0x1b],al
  40c564:	mov    eax,0x10
  40c569:	shrx   eax,ecx,eax
  40c56e:	and    eax,0xf
  40c571:	mov    al,BYTE PTR [rdx+rax*1]
  40c574:	rex mov BYTE PTR [rsp+0x13],al
  40c579:	mov    eax,0x10
  40c57e:	shrx   eax,r12d,eax
  40c583:	and    eax,0xf
  40c586:	mov    al,BYTE PTR [rdx+rax*1]
  40c589:	rex mov BYTE PTR [rsp+0x1c],al
  40c58e:	mov    eax,0xc
  40c593:	shrx   eax,ecx,eax
  40c598:	and    eax,0xf
  40c59b:	mov    al,BYTE PTR [rdx+rax*1]
  40c59e:	rex mov BYTE PTR [rsp+0x14],al
  40c5a3:	mov    eax,0xc
  40c5a8:	shrx   eax,r12d,eax
  40c5ad:	and    eax,0xf
  40c5b0:	mov    al,BYTE PTR [rdx+rax*1]
  40c5b3:	rex mov BYTE PTR [rsp+0x1d],al
  40c5b8:	mov    eax,0x8
  40c5bd:	shrx   eax,ecx,eax
  40c5c2:	and    eax,0xf
  40c5c5:	mov    al,BYTE PTR [rdx+rax*1]
  40c5c8:	rex mov BYTE PTR [rsp+0x15],al
  40c5cd:	mov    eax,0x8
  40c5d2:	shrx   eax,r12d,eax
  40c5d7:	and    eax,0xf
  40c5da:	mov    al,BYTE PTR [rdx+rax*1]
  40c5dd:	rex mov BYTE PTR [rsp+0x1e],al
  40c5e2:	mov    eax,0x4
  40c5e7:	shrx   eax,ecx,eax
  40c5ec:	and    eax,0xf
  40c5ef:	mov    al,BYTE PTR [rdx+rax*1]
  40c5f2:	rex mov BYTE PTR [rsp+0x16],al
  40c5f7:	mov    eax,0x4
  40c5fc:	shrx   eax,r12d,eax
  40c601:	and    eax,0xf
  40c604:	mov    al,BYTE PTR [rdx+rax*1]
  40c607:	rex mov BYTE PTR [rsp+0x1f],al
  40c60c:	xor    eax,eax
  40c60e:	shrx   eax,ecx,eax
  40c613:	and    eax,0xf
  40c616:	mov    al,BYTE PTR [rdx+rax*1]
  40c619:	rex mov BYTE PTR [rsp+0x17],al
  40c61e:	xor    eax,eax
  40c620:	shrx   eax,r12d,eax
  40c625:	and    eax,0xf
  40c628:	mov    al,BYTE PTR [rdx+rax*1]
  40c62b:	rex mov BYTE PTR [rsp+0x20],al
  40c630:	mov    BYTE PTR [r14+0x10],0x2e
  40c635:	lea    r12,[rsp+0x22]
  40c63a:	vxorps xmm0,xmm0,xmm0
  40c63e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40c644:	mov    DWORD PTR [r12],0x6d656d2f
  40c64c:	mov    WORD PTR [r12+0x4],0x6466
  40c654:	mov    BYTE PTR [r12+0x6],0x3a
  40c65a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c660:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40c666:	mov    rax,QWORD PTR [rsp+0x18]
  40c66b:	mov    QWORD PTR [rsp+0x39],rax
  40c670:	rex mov al,BYTE PTR [rsp+0x20]
  40c675:	rex mov BYTE PTR [rsp+0x41],al
  40c67a:	mov    DWORD PTR [r12+0x20],0x65642820
  40c683:	mov    DWORD PTR [r12+0x24],0x6574656c
  40c68c:	mov    WORD PTR [r12+0x28],0x2964
  40c694:	lea    rdi,[rip+0x5ee8]        # 412583 <__swc_rdata_base_7dafa2b1+0x473>
  40c69b:	xor    eax,eax
  40c69d:	call   407100 <opendir@plt>
  40c6a2:	mov    r15,rax
  40c6a5:	test   rax,rax
  40c6a8:	jne    40c6bb <__swc_fn_7dafa2b1_000112_6814119b+0x30b>
  40c6aa:	movsxd rdi,r13d
  40c6ad:	xor    eax,eax
  40c6af:	call   4070e0 <close@plt>
  40c6b4:	xor    eax,eax
  40c6b6:	jmp    40c966 <__swc_fn_7dafa2b1_000112_6814119b+0x5b6>
  40c6bb:	mov    rdi,r15
  40c6be:	xor    eax,eax
  40c6c0:	call   407110 <dirfd@plt>
  40c6c5:	lea    r14,[rsp+0x54]
  40c6ca:	mov    DWORD PTR [rsp+0x54],eax
  40c6ce:	lea    rbx,[rsp+0x58]
  40c6d3:	cs nop WORD PTR [rax+rax*1+0x0]
  40c6dd:	nop    DWORD PTR [rax]
  40c6e0:	mov    rdi,r15
  40c6e3:	xor    eax,eax
  40c6e5:	call   407120 <readdir@plt>
  40c6ea:	test   rax,rax
  40c6ed:	jne    40c704 <__swc_fn_7dafa2b1_000112_6814119b+0x354>
  40c6ef:	mov    r12,QWORD PTR [rsp+0xa8]
  40c6f7:	mov    r13,QWORD PTR [rsp+0xb0]
  40c6ff:	jmp    40c88a <__swc_fn_7dafa2b1_000112_6814119b+0x4da>
  40c704:	vxorps xmm0,xmm0,xmm0
  40c708:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40c70e:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40c714:	vzeroupper
  40c717:	lea    r13,[rax+0x13]
  40c71b:	mov    rax,r14
  40c71e:	movsxd rdi,DWORD PTR [rax]
  40c721:	mov    rsi,r13
  40c724:	mov    rdx,rbx
  40c727:	mov    ecx,0x40
  40c72c:	xor    eax,eax
  40c72e:	call   407130 <readlinkat@plt>
  40c733:	cmp    rax,0x2a
  40c737:	jne    40c6e0 <__swc_fn_7dafa2b1_000112_6814119b+0x330>
  40c739:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40c73f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40c745:	vptest xmm0,xmm0
  40c74a:	jne    40c77a <__swc_fn_7dafa2b1_000112_6814119b+0x3ca>
  40c74c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40c752:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40c758:	vptest xmm0,xmm0
  40c75d:	jne    40c77a <__swc_fn_7dafa2b1_000112_6814119b+0x3ca>
  40c75f:	mov    rcx,QWORD PTR [rsp+0x42]
  40c764:	cmp    QWORD PTR [rsp+0x78],rcx
  40c769:	jne    40c77a <__swc_fn_7dafa2b1_000112_6814119b+0x3ca>
  40c76b:	mov    cx,WORD PTR [rsp+0x4a]
  40c770:	cmp    WORD PTR [rsp+0x80],cx
  40c778:	je     40c7a4 <__swc_fn_7dafa2b1_000112_6814119b+0x3f4>
  40c77a:	mov    rax,rbx
  40c77d:	mov    rcx,r12
  40c780:	movzx  edx,BYTE PTR [rax]
  40c783:	movzx  r8d,BYTE PTR [rcx]
  40c787:	cmp    rdx,r8
  40c78a:	jne    40c796 <__swc_fn_7dafa2b1_000112_6814119b+0x3e6>
  40c78c:	add    rax,0x1
  40c790:	add    rcx,0x1
  40c794:	jmp    40c780 <__swc_fn_7dafa2b1_000112_6814119b+0x3d0>
  40c796:	mov    rax,rdx
  40c799:	sub    rax,r8
  40c79c:	test   eax,eax
  40c79e:	jne    40c6e0 <__swc_fn_7dafa2b1_000112_6814119b+0x330>
  40c7a4:	movsxd rdi,DWORD PTR [r14]
  40c7a7:	mov    rsi,r13
  40c7aa:	mov    edx,0x80002
  40c7af:	xor    eax,eax
  40c7b1:	call   407140 <openat@plt>
  40c7b6:	lea    rbx,[rsp+0x98]
  40c7be:	mov    DWORD PTR [rsp+0x98],eax
  40c7c5:	test   eax,eax
  40c7c7:	mov    r13,QWORD PTR [rsp+0xb0]
  40c7cf:	jge    40c7f4 <__swc_fn_7dafa2b1_000112_6814119b+0x444>
  40c7d1:	mov    rdi,r15
  40c7d4:	xor    eax,eax
  40c7d6:	call   407150 <closedir@plt>
  40c7db:	mov    r13,QWORD PTR [rsp+0xb0]
  40c7e3:	movsxd rdi,r13d
  40c7e6:	xor    eax,eax
  40c7e8:	call   4070e0 <close@plt>
  40c7ed:	xor    eax,eax
  40c7ef:	jmp    40c966 <__swc_fn_7dafa2b1_000112_6814119b+0x5b6>
  40c7f4:	mov    rax,rbx
  40c7f7:	movsxd rdi,DWORD PTR [rax]
  40c7fa:	xor    esi,esi
  40c7fc:	mov    edx,0x2
  40c801:	xor    eax,eax
  40c803:	call   407160 <lseek@plt>
  40c808:	mov    r12,QWORD PTR [rsp+0xa8]
  40c810:	cmp    rax,r12
  40c813:	je     40c83a <__swc_fn_7dafa2b1_000112_6814119b+0x48a>
  40c815:	movsxd rdi,DWORD PTR [rbx]
  40c818:	xor    eax,eax
  40c81a:	call   4070e0 <close@plt>
  40c81f:	mov    rdi,r15
  40c822:	xor    eax,eax
  40c824:	call   407150 <closedir@plt>
  40c829:	movsxd rdi,r13d
  40c82c:	xor    eax,eax
  40c82e:	call   4070e0 <close@plt>
  40c833:	xor    eax,eax
  40c835:	jmp    40c966 <__swc_fn_7dafa2b1_000112_6814119b+0x5b6>
  40c83a:	xor    edi,edi
  40c83c:	mov    rsi,r12
  40c83f:	mov    edx,0x3
  40c844:	mov    ecx,0x1
  40c849:	mov    rax,rbx
  40c84c:	movsxd r8,DWORD PTR [rax]
  40c84f:	xor    r9d,r9d
  40c852:	xor    eax,eax
  40c854:	call   407010 <mmap@plt>
  40c859:	xor    r12d,r12d
  40c85c:	cmp    rax,0xffffffffffffffff
  40c860:	cmovne r12,rax
  40c864:	movsxd rdi,DWORD PTR [rbx]
  40c867:	xor    eax,eax
  40c869:	call   4070e0 <close@plt>
  40c86e:	mov    rdi,r15
  40c871:	xor    eax,eax
  40c873:	call   407150 <closedir@plt>
  40c878:	movsxd rdi,r13d
  40c87b:	xor    eax,eax
  40c87d:	call   4070e0 <close@plt>
  40c882:	mov    rax,r12
  40c885:	jmp    40c966 <__swc_fn_7dafa2b1_000112_6814119b+0x5b6>
  40c88a:	mov    r14,QWORD PTR [rsp+0xb8]
  40c892:	mov    rdi,r14
  40c895:	mov    esi,0x1
  40c89a:	xor    eax,eax
  40c89c:	call   407170 <memfd_create@plt>
  40c8a1:	lea    rbx,[rsp+0x9c]
  40c8a9:	mov    DWORD PTR [rsp+0x9c],eax
  40c8b0:	test   eax,eax
  40c8b2:	jge    40c8cf <__swc_fn_7dafa2b1_000112_6814119b+0x51f>
  40c8b4:	mov    rdi,r15
  40c8b7:	xor    eax,eax
  40c8b9:	call   407150 <closedir@plt>
  40c8be:	movsxd rdi,r13d
  40c8c1:	xor    eax,eax
  40c8c3:	call   4070e0 <close@plt>
  40c8c8:	xor    eax,eax
  40c8ca:	jmp    40c966 <__swc_fn_7dafa2b1_000112_6814119b+0x5b6>
  40c8cf:	mov    rax,rbx
  40c8d2:	movsxd rdi,DWORD PTR [rax]
  40c8d5:	mov    rsi,r12
  40c8d8:	xor    eax,eax
  40c8da:	call   407180 <ftruncate@plt>
  40c8df:	test   eax,eax
  40c8e1:	je     40c905 <__swc_fn_7dafa2b1_000112_6814119b+0x555>
  40c8e3:	movsxd rdi,DWORD PTR [rbx]
  40c8e6:	xor    eax,eax
  40c8e8:	call   4070e0 <close@plt>
  40c8ed:	mov    rdi,r15
  40c8f0:	xor    eax,eax
  40c8f2:	call   407150 <closedir@plt>
  40c8f7:	movsxd rdi,r13d
  40c8fa:	xor    eax,eax
  40c8fc:	call   4070e0 <close@plt>
  40c901:	xor    eax,eax
  40c903:	jmp    40c966 <__swc_fn_7dafa2b1_000112_6814119b+0x5b6>
  40c905:	xor    edi,edi
  40c907:	mov    rsi,r12
  40c90a:	mov    edx,0x3
  40c90f:	mov    ecx,0x1
  40c914:	mov    rax,rbx
  40c917:	movsxd r8,DWORD PTR [rax]
  40c91a:	xor    r9d,r9d
  40c91d:	xor    eax,eax
  40c91f:	call   407010 <mmap@plt>
  40c924:	mov    r12,rax
  40c927:	cmp    rax,0xffffffffffffffff
  40c92b:	jne    40c94f <__swc_fn_7dafa2b1_000112_6814119b+0x59f>
  40c92d:	movsxd rdi,DWORD PTR [rbx]
  40c930:	xor    eax,eax
  40c932:	call   4070e0 <close@plt>
  40c937:	mov    rdi,r15
  40c93a:	xor    eax,eax
  40c93c:	call   407150 <closedir@plt>
  40c941:	movsxd rdi,r13d
  40c944:	xor    eax,eax
  40c946:	call   4070e0 <close@plt>
  40c94b:	xor    eax,eax
  40c94d:	jmp    40c966 <__swc_fn_7dafa2b1_000112_6814119b+0x5b6>
  40c94f:	mov    rdi,r15
  40c952:	xor    eax,eax
  40c954:	call   407150 <closedir@plt>
  40c959:	movsxd rdi,r13d
  40c95c:	xor    eax,eax
  40c95e:	call   4070e0 <close@plt>
  40c963:	mov    rax,r12
  40c966:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40c96f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40c978:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40c981:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40c98a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40c993:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40c99c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40c9a5:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40c9ae:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40c9b7:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40c9c0:	add    rsp,0x170
  40c9c7:	pop    r15
  40c9c9:	pop    r14
  40c9cb:	pop    r13
  40c9cd:	pop    rsi
  40c9ce:	pop    rdi
  40c9cf:	pop    r12
  40c9d1:	pop    rbx
  40c9d2:	ret
	...

000000000040c9e0 <__swc_fn_7dafa2b1_000115_5f48311c>:
  40c9e0:	push   rsi
  40c9e1:	push   rdi
  40c9e2:	push   r12
  40c9e4:	push   r13
  40c9e6:	sub    rsp,0x8
  40c9ea:	mov    rsi,r8
  40c9ed:	mov    rdi,rcx
  40c9f0:	mov    r12,rdx
  40c9f3:	call   410900 <__swc_fn_7dafa2b1_000113_126150d1>
  40c9f8:	mov    r13,rax
  40c9fb:	test   rax,rax
  40c9fe:	jne    40ca0b <__swc_fn_7dafa2b1_000115_5f48311c+0x2b>
  40ca00:	add    rsp,0x8
  40ca04:	pop    r13
  40ca06:	pop    r12
  40ca08:	pop    rdi
  40ca09:	pop    rsi
  40ca0a:	ret
  40ca0b:	mov    rcx,r13
  40ca0e:	call   409e10 <__swc_fn_7dafa2b1_000138_8c07c14b>
  40ca13:	mov    rax,QWORD PTR [r13+0x8]
  40ca17:	test   rax,rax
  40ca1a:	je     40ca59 <__swc_fn_7dafa2b1_000115_5f48311c+0x79>
  40ca1c:	nop    DWORD PTR [rax+0x0]
  40ca20:	lea    rcx,[rax+0x1000]
  40ca27:	cmp    rdi,rcx
  40ca2a:	jne    40ca51 <__swc_fn_7dafa2b1_000115_5f48311c+0x71>
  40ca2c:	cmp    r12,0x1000
  40ca33:	jb     40ca51 <__swc_fn_7dafa2b1_000115_5f48311c+0x71>
  40ca35:	test   sil,sil
  40ca38:	setne  cl
  40ca3b:	mov    BYTE PTR [rax+0x10],cl
  40ca3e:	mov    rcx,r13
  40ca41:	call   40cf40 <__swc_fn_7dafa2b1_000139_715e84ff>
  40ca46:	add    rsp,0x8
  40ca4a:	pop    r13
  40ca4c:	pop    r12
  40ca4e:	pop    rdi
  40ca4f:	pop    rsi
  40ca50:	ret
  40ca51:	mov    rax,QWORD PTR [rax]
  40ca54:	test   rax,rax
  40ca57:	jne    40ca20 <__swc_fn_7dafa2b1_000115_5f48311c+0x40>
  40ca59:	mov    rcx,r13
  40ca5c:	call   40cf40 <__swc_fn_7dafa2b1_000139_715e84ff>
  40ca61:	add    rsp,0x8
  40ca65:	pop    r13
  40ca67:	pop    r12
  40ca69:	pop    rdi
  40ca6a:	pop    rsi
  40ca6b:	ret
  40ca6c:	add    BYTE PTR [rax],al
	...

000000000040ca70 <__swc_fn_7dafa2b1_000118_ed2d8fed>:
  40ca70:	sub    rsp,0x8
  40ca74:	test   rcx,rcx
  40ca77:	jne    40ca7e <__swc_fn_7dafa2b1_000118_ed2d8fed+0xe>
  40ca79:	add    rsp,0x8
  40ca7d:	ret
  40ca7e:	call   409920 <__swc_fn_7dafa2b1_000120_d3318640>
  40ca83:	add    rsp,0x8
  40ca87:	ret
	...

000000000040ca90 <__swc_fn_7dafa2b1_000121_2648f149>:
  40ca90:	push   r12
  40ca92:	push   r13
  40ca94:	push   r14
  40ca96:	push   rdi
  40ca97:	push   rsi
  40ca98:	sub    rsp,0xc0
  40ca9f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40caa5:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40caab:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cab1:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40cab7:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40cabd:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cac3:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cac9:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cad2:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40cadb:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cae4:	mov    r12,QWORD PTR [rcx]
  40cae7:	test   r12,r12
  40caea:	jne    40cafc <__swc_fn_7dafa2b1_000121_2648f149+0x6c>
  40caec:	add    rsp,0xc0
  40caf3:	pop    rsi
  40caf4:	pop    rdi
  40caf5:	pop    r14
  40caf7:	pop    r13
  40caf9:	pop    r12
  40cafb:	ret
  40cafc:	xor    r13d,r13d
  40caff:	mov    r14,QWORD PTR [rcx+0x8]
  40cb03:	cs nop WORD PTR [rax+rax*1+0x0]
  40cb0d:	nop    DWORD PTR [rax]
  40cb10:	cmp    r13,r14
  40cb13:	jae    40cb4b <__swc_fn_7dafa2b1_000121_2648f149+0xbb>
  40cb15:	lea    rax,[r12+r13*1]
  40cb19:	mov    rcx,r14
  40cb1c:	sub    rcx,r13
  40cb1f:	mov    edi,0x1
  40cb24:	mov    rsi,rax
  40cb27:	mov    rdx,rcx
  40cb2a:	xor    eax,eax
  40cb2c:	call   407190 <write@plt>
  40cb31:	test   rax,rax
  40cb34:	jle    40cb3b <__swc_fn_7dafa2b1_000121_2648f149+0xab>
  40cb36:	add    r13,rax
  40cb39:	jmp    40cb10 <__swc_fn_7dafa2b1_000121_2648f149+0x80>
  40cb3b:	je     40cb49 <__swc_fn_7dafa2b1_000121_2648f149+0xb9>
  40cb3d:	xor    eax,eax
  40cb3f:	call   4070d0 <__errno_location@plt>
  40cb44:	cmp    DWORD PTR [rax],0x4
  40cb47:	je     40cb10 <__swc_fn_7dafa2b1_000121_2648f149+0x80>
  40cb49:	jmp    40cb4b <__swc_fn_7dafa2b1_000121_2648f149+0xbb>
  40cb4b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40cb51:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40cb57:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40cb5d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40cb63:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40cb69:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40cb6f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40cb75:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40cb7e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40cb87:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40cb90:	add    rsp,0xc0
  40cb97:	pop    rsi
  40cb98:	pop    rdi
  40cb99:	pop    r14
  40cb9b:	pop    r13
  40cb9d:	pop    r12
  40cb9f:	ret

000000000040cba0 <__swc_fn_7dafa2b1_000124_4f256d58>:
  40cba0:	push   rbx
  40cba1:	push   r12
  40cba3:	push   rdi
  40cba4:	push   rsi
  40cba5:	sub    rsp,0x4a8
  40cbac:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  40cbb5:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  40cbbe:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  40cbc7:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  40cbd0:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  40cbd9:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  40cbe2:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  40cbeb:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  40cbf4:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  40cbfd:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  40cc06:	mov    rbx,rdx
  40cc09:	mov    r12d,ecx
  40cc0c:	vxorps xmm0,xmm0,xmm0
  40cc10:	xor    eax,eax
  40cc12:	cs nop WORD PTR [rax+rax*1+0x0]
  40cc1c:	nop    DWORD PTR [rax+0x0]
  40cc20:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  40cc26:	add    rax,0x10
  40cc2a:	cmp    rax,0x400
  40cc31:	jne    40cc20 <__swc_fn_7dafa2b1_000124_4f256d58+0x80>
  40cc33:	lea    rdi,[rsp+0x8]
  40cc38:	mov    esi,0x80
  40cc3d:	xor    eax,eax
  40cc3f:	call   4071a0 <backtrace@plt>
  40cc44:	test   eax,eax
  40cc46:	jle    40cc55 <__swc_fn_7dafa2b1_000124_4f256d58+0xb5>
  40cc48:	movsxd rax,eax
  40cc4b:	lea    rcx,[r12+0x1]
  40cc50:	cmp    rcx,rax
  40cc53:	jb     40cc59 <__swc_fn_7dafa2b1_000124_4f256d58+0xb9>
  40cc55:	xor    eax,eax
  40cc57:	jmp    40cc8a <__swc_fn_7dafa2b1_000124_4f256d58+0xea>
  40cc59:	mov    rcx,QWORD PTR [rbx+0x8]
  40cc5d:	sub    rax,r12
  40cc60:	lea    rsi,[rax-0x1]
  40cc64:	cmp    rcx,rsi
  40cc67:	cmovbe rsi,rcx
  40cc6b:	lea    eax,[r12+0x1]
  40cc70:	lea    rax,[rsp+rax*8+0x8]
  40cc75:	mov    rcx,QWORD PTR [rbx]
  40cc78:	mov    rdx,rax
  40cc7b:	lea    r8,[rsi*8+0x0]
  40cc83:	call   4108e0 <__swc_fn_7dafa2b1_000110_7c204aac>
  40cc88:	mov    eax,esi
  40cc8a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  40cc93:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  40cc9c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  40cca5:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  40ccae:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  40ccb7:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  40ccc0:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  40ccc9:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  40ccd2:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  40ccdb:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  40cce4:	add    rsp,0x4a8
  40cceb:	pop    rsi
  40ccec:	pop    rdi
  40cced:	pop    r12
  40ccef:	pop    rbx
  40ccf0:	ret
	...

000000000040cd00 <__swc_fn_7dafa2b1_000127_fcd5a289>:
  40cd00:	mov    QWORD PTR [rcx],0x0
  40cd07:	ret
	...

000000000040cd10 <__swc_fn_7dafa2b1_000130_4bbe3f14>:
  40cd10:	push   rdi
  40cd11:	push   rsi
  40cd12:	sub    rsp,0xa8
  40cd19:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cd1f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cd25:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cd2b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cd31:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cd37:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cd3d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cd43:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cd49:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cd52:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cd5b:	mov    edi,ecx
  40cd5d:	mov    rsi,rdx
  40cd60:	xor    eax,eax
  40cd62:	call   4071b0 <pthread_setspecific@plt>
  40cd67:	test   eax,eax
  40cd69:	sete   al
  40cd6c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cd72:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cd78:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cd7e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cd84:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cd8a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cd90:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cd96:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cd9c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cda5:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cdae:	add    rsp,0xa8
  40cdb5:	pop    rsi
  40cdb6:	pop    rdi
  40cdb7:	ret
	...

000000000040cdc0 <__swc_fn_7dafa2b1_000133_5f757033>:
  40cdc0:	push   rdi
  40cdc1:	push   rsi
  40cdc2:	sub    rsp,0xa8
  40cdc9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cdcf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cdd5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cddb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cde1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cde7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cded:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cdf3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cdf9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ce02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ce0b:	test   rcx,rcx
  40ce0e:	je     40ce21 <__swc_fn_7dafa2b1_000133_5f757033+0x61>
  40ce10:	lea    rax,[rcx-0x1]
  40ce14:	mov    eax,eax
  40ce16:	mov    edi,eax
  40ce18:	xor    eax,eax
  40ce1a:	call   407000 <pthread_getspecific@plt>
  40ce1f:	jmp    40ce23 <__swc_fn_7dafa2b1_000133_5f757033+0x63>
  40ce21:	xor    eax,eax
  40ce23:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ce29:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ce2f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ce35:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ce3b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ce41:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ce47:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ce4d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ce53:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ce5c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ce65:	add    rsp,0xa8
  40ce6c:	pop    rsi
  40ce6d:	pop    rdi
  40ce6e:	ret
	...

000000000040ce70 <__swc_fn_7dafa2b1_000136_07d76562>:
  40ce70:	push   rdi
  40ce71:	push   rsi
  40ce72:	sub    rsp,0xb8
  40ce79:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ce7f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40ce85:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40ce8b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ce91:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ce97:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ce9d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cea3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40ceac:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ceb5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cebe:	vxorps xmm0,xmm0,xmm0
  40cec2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40cec8:	mov    edi,0x1
  40cecd:	lea    rsi,[rsp+0x8]
  40ced2:	xor    eax,eax
  40ced4:	call   4070a0 <clock_gettime@plt>
  40ced9:	mov    rax,QWORD PTR [rsp+0x8]
  40cede:	imul   rax,rax,0x3b9aca00
  40cee5:	add    rax,QWORD PTR [rsp+0x10]
  40ceea:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40cef0:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40cef6:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40cefc:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40cf02:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40cf08:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40cf0e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40cf14:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40cf1d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40cf26:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40cf2f:	add    rsp,0xb8
  40cf36:	pop    rsi
  40cf37:	pop    rdi
  40cf38:	ret
  40cf39:	add    BYTE PTR [rax],al
  40cf3b:	add    BYTE PTR [rax],al
  40cf3d:	add    BYTE PTR [rax],al
	...

000000000040cf40 <__swc_fn_7dafa2b1_000139_715e84ff>:
  40cf40:	sub    rsp,0x8
  40cf44:	xor    eax,eax
  40cf46:	mov    DWORD PTR [rcx],eax
  40cf48:	mov    edx,0x7fffffff
  40cf4d:	call   410fe0 <__swc_fn_7dafa2b1_000137_865f5106>
  40cf52:	add    rsp,0x8
  40cf56:	ret
	...

000000000040cf60 <__swc_fn_7dafa2b1_000142_519fdf94>:
  40cf60:	push   rdi
  40cf61:	push   rsi
  40cf62:	sub    rsp,0xb8
  40cf69:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40cf6f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40cf75:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cf7b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40cf81:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40cf87:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cf8d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cf93:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cf9c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40cfa5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cfae:	mov    edi,0x1
  40cfb3:	xor    eax,eax
  40cfb5:	call   4071c0 <__x86_get_cpuid_feature_leaf@plt>
  40cfba:	mov    eax,DWORD PTR [rax+0x14]
  40cfbd:	and    eax,0x20
  40cfc0:	setne  al
  40cfc3:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40cfc9:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40cfcf:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40cfd5:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40cfdb:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40cfe1:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40cfe7:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40cfed:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40cff6:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40cfff:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d008:	add    rsp,0xb8
  40d00f:	pop    rsi
  40d010:	pop    rdi
  40d011:	ret
	...

000000000040d020 <__swc_fn_7dafa2b1_000145_d5d4d43f>:
  40d020:	push   rsi
  40d021:	push   rdi
  40d022:	push   r12
  40d024:	push   r13
  40d026:	push   r14
  40d028:	push   r15
  40d02a:	cmp    rdx,0x40
  40d02e:	jae    40d03d <__swc_fn_7dafa2b1_000145_d5d4d43f+0x1d>
  40d030:	xor    eax,eax
  40d032:	pop    r15
  40d034:	pop    r14
  40d036:	pop    r13
  40d038:	pop    r12
  40d03a:	pop    rdi
  40d03b:	pop    rsi
  40d03c:	ret
  40d03d:	cmp    BYTE PTR [rcx],0x7f
  40d040:	jne    40d084 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x64>
  40d042:	movzx  eax,BYTE PTR [rcx+0x1]
  40d046:	cmp    eax,0x45
  40d049:	setne  al
  40d04c:	jne    40d080 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x60>
  40d04e:	movzx  eax,BYTE PTR [rcx+0x2]
  40d052:	cmp    eax,0x4c
  40d055:	setne  al
  40d058:	jne    40d080 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x60>
  40d05a:	movzx  eax,BYTE PTR [rcx+0x3]
  40d05e:	cmp    eax,0x46
  40d061:	setne  al
  40d064:	jne    40d080 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x60>
  40d066:	cmp    BYTE PTR [rcx+0x4],0x2
  40d06a:	setne  al
  40d06d:	jne    40d080 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x60>
  40d06f:	cmp    BYTE PTR [rcx+0x5],0x1
  40d073:	setne  al
  40d076:	jne    40d080 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x60>
  40d078:	cmp    WORD PTR [rcx+0x12],0x3e
  40d07d:	setne  al
  40d080:	test   al,al
  40d082:	je     40d091 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x71>
  40d084:	xor    eax,eax
  40d086:	pop    r15
  40d088:	pop    r14
  40d08a:	pop    r13
  40d08c:	pop    r12
  40d08e:	pop    rdi
  40d08f:	pop    rsi
  40d090:	ret
  40d091:	cmp    WORD PTR [rcx+0x3a],0x40
  40d096:	jne    40d0b1 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x91>
  40d098:	cmp    WORD PTR [rcx+0x3c],0x0
  40d09d:	sete   al
  40d0a0:	je     40d0ad <__swc_fn_7dafa2b1_000145_d5d4d43f+0x8d>
  40d0a2:	mov    ax,WORD PTR [rcx+0x3c]
  40d0a6:	cmp    WORD PTR [rcx+0x3e],ax
  40d0aa:	setae  al
  40d0ad:	test   al,al
  40d0af:	je     40d0be <__swc_fn_7dafa2b1_000145_d5d4d43f+0x9e>
  40d0b1:	xor    eax,eax
  40d0b3:	pop    r15
  40d0b5:	pop    r14
  40d0b7:	pop    r13
  40d0b9:	pop    r12
  40d0bb:	pop    rdi
  40d0bc:	pop    rsi
  40d0bd:	ret
  40d0be:	movzx  eax,WORD PTR [rcx+0x3c]
  40d0c2:	shl    rax,0x6
  40d0c6:	cmp    rax,rdx
  40d0c9:	ja     40d0d7 <__swc_fn_7dafa2b1_000145_d5d4d43f+0xb7>
  40d0cb:	mov    r9,rdx
  40d0ce:	sub    r9,rax
  40d0d1:	cmp    QWORD PTR [rcx+0x28],r9
  40d0d5:	jbe    40d0e4 <__swc_fn_7dafa2b1_000145_d5d4d43f+0xc4>
  40d0d7:	xor    eax,eax
  40d0d9:	pop    r15
  40d0db:	pop    r14
  40d0dd:	pop    r13
  40d0df:	pop    r12
  40d0e1:	pop    rdi
  40d0e2:	pop    rsi
  40d0e3:	ret
  40d0e4:	mov    rax,QWORD PTR [rcx+0x28]
  40d0e8:	add    rax,rcx
  40d0eb:	movzx  r9d,WORD PTR [rcx+0x3e]
  40d0f0:	lea    r9,[r9*8+0x0]
  40d0f8:	lea    r10,[rax+r9*8]
  40d0fc:	cmp    QWORD PTR [r10+0x20],rdx
  40d100:	ja     40d122 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x102>
  40d102:	mov    r11,rdx
  40d105:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  40d10a:	cmp    QWORD PTR [r10+0x18],r11
  40d10e:	seta   r9b
  40d112:	ja     40d11d <__swc_fn_7dafa2b1_000145_d5d4d43f+0xfd>
  40d114:	cmp    QWORD PTR [r10+0x20],0x9
  40d119:	setb   r9b
  40d11d:	test   r9b,r9b
  40d120:	je     40d12f <__swc_fn_7dafa2b1_000145_d5d4d43f+0x10f>
  40d122:	xor    eax,eax
  40d124:	pop    r15
  40d126:	pop    r14
  40d128:	pop    r13
  40d12a:	pop    r12
  40d12c:	pop    rdi
  40d12d:	pop    rsi
  40d12e:	ret
  40d12f:	movzx  r9d,WORD PTR [rcx+0x3c]
  40d134:	xor    r11d,r11d
  40d137:	test   r9,r9
  40d13a:	jbe    40d235 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x215>
  40d140:	mov    rsi,QWORD PTR [r10+0x20]
  40d144:	sub    rsi,0x9
  40d148:	cs nop WORD PTR [rax+rax*1+0x0]
  40d152:	cs nop WORD PTR [rax+rax*1+0x0]
  40d15c:	nop    DWORD PTR [rax+0x0]
  40d160:	movzx  edi,r11w
  40d164:	lea    rdi,[rdi*8+0x0]
  40d16c:	lea    r12,[rax+rdi*8]
  40d170:	rex mov edi,DWORD PTR [rax+rdi*8]
  40d174:	cmp    rdi,rsi
  40d177:	ja     40d228 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x208>
  40d17d:	mov    r13,QWORD PTR [r10+0x18]
  40d181:	add    r13,rdi
  40d184:	lea    rdi,[rcx+r13*1]
  40d188:	lea    r13,[rip+0x5469]        # 4125f8 <__swc_rdata_base_7dafa2b1+0x4e8>
  40d18f:	movabs r14,0x676264676177732e
  40d199:	cmp    QWORD PTR [rdi],r14
  40d19c:	jne    40d1a5 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x185>
  40d19e:	rex cmp BYTE PTR [rdi+0x8],0x0
  40d1a3:	je     40d1d2 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x1b2>
  40d1a5:	cs nop WORD PTR [rax+rax*1+0x0]
  40d1af:	nop
  40d1b0:	movzx  r14d,BYTE PTR [rdi]
  40d1b4:	movzx  r15d,BYTE PTR [r13+0x0]
  40d1b9:	cmp    r14,r15
  40d1bc:	jne    40d1c8 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x1a8>
  40d1be:	add    rdi,0x1
  40d1c2:	add    r13,0x1
  40d1c6:	jmp    40d1b0 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x190>
  40d1c8:	mov    rdi,r14
  40d1cb:	sub    rdi,r15
  40d1ce:	test   edi,edi
  40d1d0:	jne    40d228 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x208>
  40d1d2:	cmp    DWORD PTR [r12+0x4],0x1
  40d1d8:	jne    40d200 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x1e0>
  40d1da:	cmp    QWORD PTR [r12+0x20],0x10
  40d1e0:	setb   al
  40d1e3:	jb     40d1fc <__swc_fn_7dafa2b1_000145_d5d4d43f+0x1dc>
  40d1e5:	cmp    QWORD PTR [r12+0x20],rdx
  40d1ea:	seta   al
  40d1ed:	ja     40d1fc <__swc_fn_7dafa2b1_000145_d5d4d43f+0x1dc>
  40d1ef:	sub    rdx,QWORD PTR [r12+0x20]
  40d1f4:	cmp    QWORD PTR [r12+0x18],rdx
  40d1f9:	seta   al
  40d1fc:	test   al,al
  40d1fe:	je     40d20d <__swc_fn_7dafa2b1_000145_d5d4d43f+0x1ed>
  40d200:	xor    eax,eax
  40d202:	pop    r15
  40d204:	pop    r14
  40d206:	pop    r13
  40d208:	pop    r12
  40d20a:	pop    rdi
  40d20b:	pop    rsi
  40d20c:	ret
  40d20d:	mov    rax,QWORD PTR [r12+0x20]
  40d212:	mov    QWORD PTR [r8],rax
  40d215:	mov    rax,QWORD PTR [r12+0x18]
  40d21a:	add    rax,rcx
  40d21d:	pop    r15
  40d21f:	pop    r14
  40d221:	pop    r13
  40d223:	pop    r12
  40d225:	pop    rdi
  40d226:	pop    rsi
  40d227:	ret
  40d228:	add    r11,0x1
  40d22c:	cmp    r11,r9
  40d22f:	jb     40d160 <__swc_fn_7dafa2b1_000145_d5d4d43f+0x140>
  40d235:	xor    eax,eax
  40d237:	pop    r15
  40d239:	pop    r14
  40d23b:	pop    r13
  40d23d:	pop    r12
  40d23f:	pop    rdi
  40d240:	pop    rsi
  40d241:	ret
	...

000000000040d250 <__swc_fn_7dafa2b1_000148_d7edc04f>:
  40d250:	push   rdi
  40d251:	push   rsi
  40d252:	sub    rsp,0xa8
  40d259:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d25f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d265:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d26b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d271:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d277:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d27d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d283:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d289:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d292:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d29b:	mov    rdi,rcx
  40d29e:	xor    eax,eax
  40d2a0:	call   4071d0 <free@plt>
  40d2a5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d2ab:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d2b1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d2b7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d2bd:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d2c3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d2c9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d2cf:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d2d5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d2de:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d2e7:	add    rsp,0xa8
  40d2ee:	pop    rsi
  40d2ef:	pop    rdi
  40d2f0:	ret
	...

000000000040d300 <__swc_fn_7dafa2b1_000151_6203dca2>:
  40d300:	push   rbx
  40d301:	push   rsi
  40d302:	push   rdi
  40d303:	push   r12
  40d305:	push   r13
  40d307:	push   r15
  40d309:	sub    rsp,0x4e8
  40d310:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  40d319:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  40d322:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  40d32b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  40d334:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  40d33d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  40d346:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  40d34f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  40d358:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  40d361:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  40d36a:	mov    rbx,QWORD PTR [rcx]
  40d36d:	mov    rcx,QWORD PTR [rcx+0x8]
  40d371:	mov    rsi,rcx
  40d374:	xor    edi,edi
  40d376:	vmovsd xmm6,QWORD PTR [rip+0x52e2]        # 412660 <__swc_rdata_base_7dafa2b1+0x550>
  40d37e:	vmovsd xmm7,QWORD PTR [rip+0x52e3]        # 412669 <__swc_rdata_base_7dafa2b1+0x559>
  40d386:	vmovsd xmm8,QWORD PTR [rip+0x52e4]        # 412672 <__swc_rdata_base_7dafa2b1+0x562>
  40d38e:	vmovsd xmm9,QWORD PTR [rip+0x52e5]        # 41267b <__swc_rdata_base_7dafa2b1+0x56b>
  40d396:	vmovsd xmm10,QWORD PTR [rip+0x52e6]        # 412684 <__swc_rdata_base_7dafa2b1+0x574>
  40d39e:	vmovups xmm11,xmm6
  40d3a2:	vmovsd QWORD PTR [rsp+0x418],xmm7
  40d3ab:	vmovsd QWORD PTR [rsp+0x420],xmm8
  40d3b4:	vmovsd QWORD PTR [rsp+0x428],xmm9
  40d3bd:	vmovsd QWORD PTR [rsp+0x430],xmm10
  40d3c6:	vmovsd xmm15,QWORD PTR [rip+0x52bf]        # 41268d <__swc_rdata_base_7dafa2b1+0x57d>
  40d3ce:	vmovups xmm14,xmm15
  40d3d3:	vmovups xmm0,xmm9
  40d3d8:	vmovsd QWORD PTR [rsp+0x438],xmm15
  40d3e1:	vmovups xmm13,xmm8
  40d3e6:	vmovsd QWORD PTR [rsp+0x440],xmm15
  40d3ef:	test   rsi,rsi
  40d3f2:	je     40e3e3 <__swc_fn_7dafa2b1_000151_6203dca2+0x10e3>
  40d3f8:	cs nop WORD PTR [rax+rax*1+0x0]
  40d402:	cs nop WORD PTR [rax+rax*1+0x0]
  40d40c:	nop    DWORD PTR [rax+0x0]
  40d410:	lea    rcx,[rdi+rdi*1]
  40d414:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  40d419:	vpshufd xmm3,xmm2,0xee
  40d41e:	vmovq  rcx,xmm3
  40d423:	test   rcx,rcx
  40d426:	je     40d43c <__swc_fn_7dafa2b1_000151_6203dca2+0x13c>
  40d428:	test   DWORD PTR [rcx+0x28],0x400000
  40d42f:	je     40d43c <__swc_fn_7dafa2b1_000151_6203dca2+0x13c>
  40d431:	mov    rdx,QWORD PTR [rcx+0x30]
  40d435:	test   rdx,rdx
  40d438:	cmovne rcx,rdx
  40d43c:	test   DWORD PTR [rcx+0x28],0x1000
  40d443:	je     40d464 <__swc_fn_7dafa2b1_000151_6203dca2+0x164>
  40d445:	mov    rdx,QWORD PTR [rcx+0x40]
  40d449:	mov    rcx,rdx
  40d44c:	vmovq  r8,xmm2
  40d451:	mov    r8,QWORD PTR [r8]
  40d454:	mov    QWORD PTR [rsp+0x60],r8
  40d459:	mov    QWORD PTR [rsp+0x68],rdx
  40d45e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  40d464:	test   BYTE PTR [rcx+0x28],0x1
  40d468:	jne    40d470 <__swc_fn_7dafa2b1_000151_6203dca2+0x170>
  40d46a:	vmovups xmm12,xmm0
  40d46e:	jmp    40d48a <__swc_fn_7dafa2b1_000151_6203dca2+0x18a>
  40d470:	vmovq  rax,xmm2
  40d475:	mov    rax,QWORD PTR [rax]
  40d478:	lea    rcx,[rax+0x10]
  40d47c:	vmovups xmm12,xmm0
  40d480:	call   40ca90 <__swc_fn_7dafa2b1_000121_2648f149>
  40d485:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40d48a:	test   DWORD PTR [rcx+0x28],0x400
  40d491:	je     40d4f2 <__swc_fn_7dafa2b1_000151_6203dca2+0x1f2>
  40d493:	vmovq  rax,xmm2
  40d498:	mov    rax,QWORD PTR [rax]
  40d49b:	xor    ecx,ecx
  40d49d:	test   rax,rax
  40d4a0:	je     40d4d0 <__swc_fn_7dafa2b1_000151_6203dca2+0x1d0>
  40d4a2:	mov    rdx,rax
  40d4a5:	mov    r8b,BYTE PTR [rdx]
  40d4a8:	test   r8b,r8b
  40d4ab:	je     40d4d0 <__swc_fn_7dafa2b1_000151_6203dca2+0x1d0>
  40d4ad:	cs nop WORD PTR [rax+rax*1+0x0]
  40d4b7:	nop    WORD PTR [rax+rax*1+0x0]
  40d4c0:	add    rdx,0x1
  40d4c4:	add    rcx,0x1
  40d4c8:	mov    r8b,BYTE PTR [rdx]
  40d4cb:	test   r8b,r8b
  40d4ce:	jne    40d4c0 <__swc_fn_7dafa2b1_000151_6203dca2+0x1c0>
  40d4d0:	mov    QWORD PTR [rsp+0x88],rax
  40d4d8:	mov    QWORD PTR [rsp+0x90],rcx
  40d4e0:	lea    rcx,[rsp+0x88]
  40d4e8:	call   40ca90 <__swc_fn_7dafa2b1_000121_2648f149>
  40d4ed:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40d4f2:	cmp    BYTE PTR [rcx+0x2c],0x6
  40d4f6:	jne    40d50d <__swc_fn_7dafa2b1_000151_6203dca2+0x20d>
  40d4f8:	vmovq  rax,xmm2
  40d4fd:	mov    rax,QWORD PTR [rax]
  40d500:	mov    rcx,rax
  40d503:	call   4114b0 <__swc_fn_7dafa2b1_000149_43c96957>
  40d508:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40d50d:	cmp    BYTE PTR [rcx+0x2c],0x1
  40d511:	jne    40e3b9 <__swc_fn_7dafa2b1_000151_6203dca2+0x10b9>
  40d517:	vmovq  rdx,xmm2
  40d51c:	mov    cl,BYTE PTR [rcx+0x40]
  40d51f:	cmp    cl,0x7
  40d522:	jb     40d565 <__swc_fn_7dafa2b1_000151_6203dca2+0x265>
  40d524:	je     40d5d8 <__swc_fn_7dafa2b1_000151_6203dca2+0x2d8>
  40d52a:	cmp    cl,0x8
  40d52d:	je     40d5e4 <__swc_fn_7dafa2b1_000151_6203dca2+0x2e4>
  40d533:	cmp    cl,0x9
  40d536:	je     40d5fd <__swc_fn_7dafa2b1_000151_6203dca2+0x2fd>
  40d53c:	cmp    cl,0xa
  40d53f:	je     40dcc4 <__swc_fn_7dafa2b1_000151_6203dca2+0x9c4>
  40d545:	cmp    cl,0xb
  40d548:	je     40e38b <__swc_fn_7dafa2b1_000151_6203dca2+0x108b>
  40d54e:	cmp    cl,0xc
  40d551:	je     40d5f1 <__swc_fn_7dafa2b1_000151_6203dca2+0x2f1>
  40d557:	cmp    cl,0xd
  40d55a:	je     40e381 <__swc_fn_7dafa2b1_000151_6203dca2+0x1081>
  40d560:	jmp    40e3ab <__swc_fn_7dafa2b1_000151_6203dca2+0x10ab>
  40d565:	cmp    cl,0x1
  40d568:	je     40d588 <__swc_fn_7dafa2b1_000151_6203dca2+0x288>
  40d56a:	cmp    cl,0x2
  40d56d:	je     40d596 <__swc_fn_7dafa2b1_000151_6203dca2+0x296>
  40d56f:	cmp    cl,0x3
  40d572:	je     40d5a4 <__swc_fn_7dafa2b1_000151_6203dca2+0x2a4>
  40d574:	cmp    cl,0x4
  40d577:	je     40d5b1 <__swc_fn_7dafa2b1_000151_6203dca2+0x2b1>
  40d579:	cmp    cl,0x5
  40d57c:	je     40d5be <__swc_fn_7dafa2b1_000151_6203dca2+0x2be>
  40d57e:	cmp    cl,0x6
  40d581:	je     40d5cb <__swc_fn_7dafa2b1_000151_6203dca2+0x2cb>
  40d583:	jmp    40e3ab <__swc_fn_7dafa2b1_000151_6203dca2+0x10ab>
  40d588:	movsx  rcx,BYTE PTR [rdx]
  40d58c:	call   40a000 <__swc_fn_7dafa2b1_000150_2eb804cc>
  40d591:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40d596:	movsx  rcx,WORD PTR [rdx]
  40d59a:	call   40a000 <__swc_fn_7dafa2b1_000150_2eb804cc>
  40d59f:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40d5a4:	movsxd rcx,DWORD PTR [rdx]
  40d5a7:	call   40a000 <__swc_fn_7dafa2b1_000150_2eb804cc>
  40d5ac:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40d5b1:	mov    rcx,QWORD PTR [rdx]
  40d5b4:	call   40a000 <__swc_fn_7dafa2b1_000150_2eb804cc>
  40d5b9:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40d5be:	movzx  ecx,BYTE PTR [rdx]
  40d5c1:	call   4114b0 <__swc_fn_7dafa2b1_000149_43c96957>
  40d5c6:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40d5cb:	movzx  ecx,WORD PTR [rdx]
  40d5ce:	call   4114b0 <__swc_fn_7dafa2b1_000149_43c96957>
  40d5d3:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40d5d8:	mov    ecx,DWORD PTR [rdx]
  40d5da:	call   4114b0 <__swc_fn_7dafa2b1_000149_43c96957>
  40d5df:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40d5e4:	mov    rcx,QWORD PTR [rdx]
  40d5e7:	call   4114b0 <__swc_fn_7dafa2b1_000149_43c96957>
  40d5ec:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40d5f1:	mov    ecx,DWORD PTR [rdx]
  40d5f3:	call   4114b0 <__swc_fn_7dafa2b1_000149_43c96957>
  40d5f8:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40d5fd:	lea    rcx,[rsp+0xa8]
  40d605:	vxorps xmm0,xmm0,xmm0
  40d609:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  40d612:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  40d61b:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  40d624:	vzeroupper
  40d627:	mov    DWORD PTR [rsp+0x108],0x0
  40d632:	vxorpd xmm0,xmm0,xmm0
  40d636:	vmovss xmm1,DWORD PTR [rdx]
  40d63a:	vcvtss2sd xmm0,xmm0,xmm1
  40d63e:	vmovsd xmm1,xmm1,xmm0
  40d642:	vcomisd xmm0,xmm0
  40d646:	setne  dl
  40d649:	movzx  edx,dl
  40d64c:	setp   r8b
  40d650:	movzx  r8d,r8b
  40d654:	or     edx,r8d
  40d657:	test   dl,dl
  40d659:	je     40d666 <__swc_fn_7dafa2b1_000151_6203dca2+0x366>
  40d65b:	mov    DWORD PTR [rcx],0x6e616e
  40d661:	jmp    40dc58 <__swc_fn_7dafa2b1_000151_6203dca2+0x958>
  40d666:	vcomisd xmm1,xmm6
  40d66a:	ja     40d672 <__swc_fn_7dafa2b1_000151_6203dca2+0x372>
  40d66c:	vcomisd xmm7,xmm1
  40d670:	jbe    40d696 <__swc_fn_7dafa2b1_000151_6203dca2+0x396>
  40d672:	vxorpd xmm0,xmm0,xmm0
  40d676:	vcomisd xmm0,xmm1
  40d67a:	jbe    40d68b <__swc_fn_7dafa2b1_000151_6203dca2+0x38b>
  40d67c:	mov    DWORD PTR [rcx],0x666e692d
  40d682:	mov    BYTE PTR [rcx+0x4],0x0
  40d686:	jmp    40dc58 <__swc_fn_7dafa2b1_000151_6203dca2+0x958>
  40d68b:	mov    DWORD PTR [rcx],0x666e69
  40d691:	jmp    40dc58 <__swc_fn_7dafa2b1_000151_6203dca2+0x958>
  40d696:	vcomisd xmm1,xmm8
  40d69b:	jae    40d6a7 <__swc_fn_7dafa2b1_000151_6203dca2+0x3a7>
  40d69d:	vcomisd xmm9,xmm1
  40d6a1:	jbe    40da1e <__swc_fn_7dafa2b1_000151_6203dca2+0x71e>
  40d6a7:	vmovups xmm0,xmm1
  40d6ab:	vxorpd xmm2,xmm2,xmm2
  40d6af:	vcomisd xmm2,xmm1
  40d6b3:	jbe    40d6c3 <__swc_fn_7dafa2b1_000151_6203dca2+0x3c3>
  40d6b5:	vmovsd xmm1,xmm1,xmm0
  40d6b9:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x4f5f]        # 412620 <__swc_rdata_base_7dafa2b1+0x510>
  40d6c1:	jmp    40d6c7 <__swc_fn_7dafa2b1_000151_6203dca2+0x3c7>
  40d6c3:	vmovsd xmm1,xmm1,xmm0
  40d6c7:	xor    r8d,r8d
  40d6ca:	vcomisd xmm1,xmm15
  40d6cf:	jb     40d6f0 <__swc_fn_7dafa2b1_000151_6203dca2+0x3f0>
  40d6d1:	cs nop WORD PTR [rax+rax*1+0x0]
  40d6db:	nop    DWORD PTR [rax+rax*1+0x0]
  40d6e0:	vdivsd xmm1,xmm1,xmm15
  40d6e5:	add    r8,0x1
  40d6e9:	vcomisd xmm1,xmm15
  40d6ee:	jae    40d6e0 <__swc_fn_7dafa2b1_000151_6203dca2+0x3e0>
  40d6f0:	mov    r9,rcx
  40d6f3:	vxorpd xmm2,xmm2,xmm2
  40d6f7:	vcomisd xmm2,xmm0
  40d6fb:	jbe    40d704 <__swc_fn_7dafa2b1_000151_6203dca2+0x404>
  40d6fd:	mov    BYTE PTR [rcx],0x2d
  40d700:	lea    r9,[rcx+0x1]
  40d704:	vcvttsd2si rdx,xmm1
  40d709:	mov    r10b,dl
  40d70c:	add    r10b,0x30
  40d710:	mov    BYTE PTR [r9],r10b
  40d713:	vxorpd xmm0,xmm0,xmm0
  40d717:	movzx  edx,dl
  40d71a:	vcvtsi2sd xmm0,xmm0,rdx
  40d71f:	vsubsd xmm0,xmm1,xmm0
  40d723:	vmulsd xmm1,xmm0,xmm15
  40d728:	mov    BYTE PTR [r9+0x1],0x2e
  40d72d:	vcvttsd2si rdx,xmm1
  40d732:	mov    r10b,dl
  40d735:	add    r10b,0x30
  40d739:	mov    BYTE PTR [r9+0x2],r10b
  40d73d:	vxorpd xmm0,xmm0,xmm0
  40d741:	movzx  edx,dl
  40d744:	vcvtsi2sd xmm0,xmm0,rdx
  40d749:	vsubsd xmm0,xmm1,xmm0
  40d74d:	vmulsd xmm1,xmm0,xmm15
  40d752:	vcvttsd2si rdx,xmm1
  40d757:	mov    r10b,dl
  40d75a:	add    r10b,0x30
  40d75e:	mov    BYTE PTR [r9+0x3],r10b
  40d762:	vxorpd xmm0,xmm0,xmm0
  40d766:	movzx  edx,dl
  40d769:	vcvtsi2sd xmm0,xmm0,rdx
  40d76e:	vsubsd xmm0,xmm1,xmm0
  40d772:	vmulsd xmm1,xmm0,xmm15
  40d777:	vcvttsd2si rdx,xmm1
  40d77c:	mov    r10b,dl
  40d77f:	add    r10b,0x30
  40d783:	mov    BYTE PTR [r9+0x4],r10b
  40d787:	vxorpd xmm0,xmm0,xmm0
  40d78b:	movzx  edx,dl
  40d78e:	vcvtsi2sd xmm0,xmm0,rdx
  40d793:	vsubsd xmm0,xmm1,xmm0
  40d797:	vmulsd xmm1,xmm0,xmm15
  40d79c:	vcvttsd2si rdx,xmm1
  40d7a1:	mov    r10b,dl
  40d7a4:	add    r10b,0x30
  40d7a8:	mov    BYTE PTR [r9+0x5],r10b
  40d7ac:	vxorpd xmm0,xmm0,xmm0
  40d7b0:	movzx  edx,dl
  40d7b3:	vcvtsi2sd xmm0,xmm0,rdx
  40d7b8:	vsubsd xmm0,xmm1,xmm0
  40d7bc:	vmulsd xmm1,xmm0,xmm15
  40d7c1:	vcvttsd2si rdx,xmm1
  40d7c6:	mov    r10b,dl
  40d7c9:	add    r10b,0x30
  40d7cd:	mov    BYTE PTR [r9+0x6],r10b
  40d7d1:	vxorpd xmm0,xmm0,xmm0
  40d7d5:	movzx  edx,dl
  40d7d8:	vcvtsi2sd xmm0,xmm0,rdx
  40d7dd:	vsubsd xmm0,xmm1,xmm0
  40d7e1:	vmulsd xmm1,xmm0,xmm15
  40d7e6:	vcvttsd2si rdx,xmm1
  40d7eb:	mov    r10b,dl
  40d7ee:	add    r10b,0x30
  40d7f2:	mov    BYTE PTR [r9+0x7],r10b
  40d7f6:	vxorpd xmm0,xmm0,xmm0
  40d7fa:	movzx  edx,dl
  40d7fd:	vcvtsi2sd xmm0,xmm0,rdx
  40d802:	vsubsd xmm0,xmm1,xmm0
  40d806:	vmulsd xmm1,xmm0,xmm15
  40d80b:	vcvttsd2si rdx,xmm1
  40d810:	mov    r10b,dl
  40d813:	add    r10b,0x30
  40d817:	mov    BYTE PTR [r9+0x8],r10b
  40d81b:	vxorpd xmm0,xmm0,xmm0
  40d81f:	movzx  edx,dl
  40d822:	vcvtsi2sd xmm0,xmm0,rdx
  40d827:	vsubsd xmm0,xmm1,xmm0
  40d82b:	vmulsd xmm1,xmm0,xmm15
  40d830:	vcvttsd2si rdx,xmm1
  40d835:	mov    r10b,dl
  40d838:	add    r10b,0x30
  40d83c:	mov    BYTE PTR [r9+0x9],r10b
  40d840:	vxorpd xmm0,xmm0,xmm0
  40d844:	movzx  edx,dl
  40d847:	vcvtsi2sd xmm0,xmm0,rdx
  40d84c:	vsubsd xmm0,xmm1,xmm0
  40d850:	vmulsd xmm1,xmm0,xmm15
  40d855:	vcvttsd2si rdx,xmm1
  40d85a:	mov    r10b,dl
  40d85d:	add    r10b,0x30
  40d861:	mov    BYTE PTR [r9+0xa],r10b
  40d865:	vxorpd xmm0,xmm0,xmm0
  40d869:	movzx  edx,dl
  40d86c:	vcvtsi2sd xmm0,xmm0,rdx
  40d871:	vsubsd xmm0,xmm1,xmm0
  40d875:	vmulsd xmm1,xmm0,xmm15
  40d87a:	vcvttsd2si rdx,xmm1
  40d87f:	mov    r10b,dl
  40d882:	add    r10b,0x30
  40d886:	mov    BYTE PTR [r9+0xb],r10b
  40d88a:	lea    r10,[r9+0x4]
  40d88e:	vxorpd xmm0,xmm0,xmm0
  40d892:	movzx  edx,dl
  40d895:	vcvtsi2sd xmm0,xmm0,rdx
  40d89a:	vsubsd xmm0,xmm1,xmm0
  40d89e:	vmulsd xmm1,xmm0,xmm15
  40d8a3:	vcvttsd2si rdx,xmm1
  40d8a8:	mov    r11b,dl
  40d8ab:	add    r11b,0x30
  40d8af:	mov    BYTE PTR [r9+0xc],r11b
  40d8b3:	vxorpd xmm0,xmm0,xmm0
  40d8b7:	movzx  edx,dl
  40d8ba:	vcvtsi2sd xmm0,xmm0,rdx
  40d8bf:	vsubsd xmm0,xmm1,xmm0
  40d8c3:	vmulsd xmm1,xmm0,xmm15
  40d8c8:	vcvttsd2si rdx,xmm1
  40d8cd:	mov    r11b,dl
  40d8d0:	add    r11b,0x30
  40d8d4:	mov    BYTE PTR [r9+0xd],r11b
  40d8d8:	lea    r10,[r10+0x2]
  40d8dc:	vxorpd xmm0,xmm0,xmm0
  40d8e0:	movzx  edx,dl
  40d8e3:	vcvtsi2sd xmm0,xmm0,rdx
  40d8e8:	vsubsd xmm0,xmm1,xmm0
  40d8ec:	vmulsd xmm1,xmm0,xmm15
  40d8f1:	vcvttsd2si rdx,xmm1
  40d8f6:	mov    r11b,dl
  40d8f9:	add    r11b,0x30
  40d8fd:	mov    BYTE PTR [r9+0xe],r11b
  40d901:	vxorpd xmm0,xmm0,xmm0
  40d905:	movzx  edx,dl
  40d908:	vcvtsi2sd xmm0,xmm0,rdx
  40d90d:	vsubsd xmm0,xmm1,xmm0
  40d911:	vmulsd xmm1,xmm0,xmm15
  40d916:	vcvttsd2si rdx,xmm1
  40d91b:	mov    r11b,dl
  40d91e:	add    r11b,0x30
  40d922:	mov    BYTE PTR [r9+0xf],r11b
  40d926:	lea    r10,[r10+0x2]
  40d92a:	lea    r10,[r10+0x2]
  40d92e:	lea    r10,[r10+0x2]
  40d932:	lea    r10,[r10+0x2]
  40d936:	lea    r10,[r10+0x2]
  40d93a:	vxorpd xmm0,xmm0,xmm0
  40d93e:	movzx  edx,dl
  40d941:	vcvtsi2sd xmm0,xmm0,rdx
  40d946:	vsubsd xmm0,xmm1,xmm0
  40d94a:	vmulsd xmm1,xmm0,xmm15
  40d94f:	vcvttsd2si rdx,xmm1
  40d954:	mov    r11b,dl
  40d957:	add    r11b,0x30
  40d95b:	mov    BYTE PTR [r9+0x10],r11b
  40d95f:	vxorpd xmm0,xmm0,xmm0
  40d963:	movzx  edx,dl
  40d966:	vcvtsi2sd xmm0,xmm0,rdx
  40d96b:	vsubsd xmm0,xmm1,xmm0
  40d96f:	vmulsd xmm1,xmm0,xmm15
  40d974:	vcvttsd2si rdx,xmm1
  40d979:	add    dl,0x30
  40d97c:	mov    BYTE PTR [r9+0x11],dl
  40d980:	mov    BYTE PTR [r10+0x2],0x65
  40d985:	lea    r9,[r10+0x3]
  40d989:	test   r8,r8
  40d98c:	jl     40d995 <__swc_fn_7dafa2b1_000151_6203dca2+0x695>
  40d98e:	mov    BYTE PTR [r9],0x2b
  40d992:	inc    r9
  40d995:	mov    r10,r9
  40d998:	mov    rdx,r8
  40d99b:	nop    DWORD PTR [rax+rax*1+0x0]
  40d9a0:	mov    r11,rdx
  40d9a3:	movabs rdx,0x6666666666666667
  40d9ad:	mov    rax,r11
  40d9b0:	imul   rdx
  40d9b3:	sar    rdx,0x2
  40d9b7:	mov    r12,rdx
  40d9ba:	shr    rdx,0x3f
  40d9be:	add    r12,rdx
  40d9c1:	mov    rdx,r12
  40d9c4:	imul   r13,r12,0xa
  40d9c8:	sub    r11,r13
  40d9cb:	mov    r13,QWORD PTR [rip+0x4c36]        # 412608 <__swc_rdata_base_7dafa2b1+0x4f8>
  40d9d2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40d9d7:	mov    BYTE PTR [r10],r11b
  40d9da:	lea    r11,[r10+0x1]
  40d9de:	mov    r10,r11
  40d9e1:	test   r12,r12
  40d9e4:	jne    40d9a0 <__swc_fn_7dafa2b1_000151_6203dca2+0x6a0>
  40d9e6:	test   r8,r8
  40d9e9:	jge    40d9f3 <__swc_fn_7dafa2b1_000151_6203dca2+0x6f3>
  40d9eb:	mov    BYTE PTR [r11],0x2d
  40d9ef:	lea    r10,[r11+0x1]
  40d9f3:	mov    BYTE PTR [r10],0x0
  40d9f7:	sub    r10,0x1
  40d9fb:	nop    DWORD PTR [rax+rax*1+0x0]
  40da00:	cmp    r9,r10
  40da03:	jae    40dc58 <__swc_fn_7dafa2b1_000151_6203dca2+0x958>
  40da09:	mov    al,BYTE PTR [r10]
  40da0c:	mov    dl,BYTE PTR [r9]
  40da0f:	mov    BYTE PTR [r10],dl
  40da12:	sub    r10,0x1
  40da16:	mov    BYTE PTR [r9],al
  40da19:	inc    r9
  40da1c:	jmp    40da00 <__swc_fn_7dafa2b1_000151_6203dca2+0x700>
  40da1e:	vcvttsd2si rdx,xmm1
  40da23:	mov    r8,rdx
  40da26:	vxorpd xmm0,xmm0,xmm0
  40da2a:	vcvtsi2sd xmm0,xmm0,rdx
  40da2f:	vsubsd xmm0,xmm1,xmm0
  40da33:	mov    r9d,0x8
  40da39:	vxorpd xmm2,xmm2,xmm2
  40da3d:	vcomisd xmm2,xmm0
  40da41:	jbe    40da4b <__swc_fn_7dafa2b1_000151_6203dca2+0x74b>
  40da43:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x4bd5]        # 412620 <__swc_rdata_base_7dafa2b1+0x510>
  40da4b:	test   r9d,r9d
  40da4e:	je     40da5a <__swc_fn_7dafa2b1_000151_6203dca2+0x75a>
  40da50:	vmulsd xmm0,xmm0,xmm14
  40da55:	dec    r9d
  40da58:	jne    40da50 <__swc_fn_7dafa2b1_000151_6203dca2+0x750>
  40da5a:	vcvttsd2si r9,xmm0
  40da5f:	mov    r10,r9
  40da62:	vxorpd xmm2,xmm2,xmm2
  40da66:	vcvtsi2sd xmm2,xmm2,r9
  40da6b:	vsubsd xmm0,xmm0,xmm2
  40da6f:	vcomisd xmm0,xmm10
  40da74:	lea    r9,[r9+0x1]
  40da78:	cmova  r10,r9
  40da7c:	cmp    r10,0x5f5e100
  40da83:	jne    40da9c <__swc_fn_7dafa2b1_000151_6203dca2+0x79c>
  40da85:	lea    r8,[rdx-0x1]
  40da89:	vxorpd xmm0,xmm0,xmm0
  40da8d:	vcomisd xmm0,xmm1
  40da91:	lea    rdx,[rdx+0x1]
  40da95:	cmovbe r8,rdx
  40da99:	xor    r10d,r10d
  40da9c:	mov    r9,rcx
  40da9f:	test   r8,r8
  40daa2:	jne    40dac2 <__swc_fn_7dafa2b1_000151_6203dca2+0x7c2>
  40daa4:	vxorpd xmm0,xmm0,xmm0
  40daa8:	vcomisd xmm0,xmm1
  40daac:	jbe    40dab5 <__swc_fn_7dafa2b1_000151_6203dca2+0x7b5>
  40daae:	mov    BYTE PTR [rcx],0x2d
  40dab1:	lea    r9,[rcx+0x1]
  40dab5:	mov    BYTE PTR [r9],0x30
  40dab9:	add    r9,0x1
  40dabd:	jmp    40db5b <__swc_fn_7dafa2b1_000151_6203dca2+0x85b>
  40dac2:	mov    r9,rcx
  40dac5:	mov    rdx,r8
  40dac8:	nop    DWORD PTR [rax+rax*1+0x0]
  40dad0:	mov    r11,rdx
  40dad3:	movabs rdx,0x6666666666666667
  40dadd:	mov    r15,rax
  40dae0:	mov    rax,r11
  40dae3:	imul   rdx
  40dae6:	mov    r12,rdx
  40dae9:	mov    rax,r15
  40daec:	sar    r12,0x2
  40daf0:	mov    rdx,r12
  40daf3:	shr    rdx,0x3f
  40daf7:	add    r12,rdx
  40dafa:	mov    rdx,r12
  40dafd:	imul   r13,r12,0xa
  40db01:	sub    r11,r13
  40db04:	mov    r13,QWORD PTR [rip+0x4afd]        # 412608 <__swc_rdata_base_7dafa2b1+0x4f8>
  40db0b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40db10:	mov    BYTE PTR [r9],r11b
  40db13:	lea    r11,[r9+0x1]
  40db17:	mov    r9,r11
  40db1a:	test   r12,r12
  40db1d:	jne    40dad0 <__swc_fn_7dafa2b1_000151_6203dca2+0x7d0>
  40db1f:	test   r8,r8
  40db22:	jge    40db2c <__swc_fn_7dafa2b1_000151_6203dca2+0x82c>
  40db24:	mov    BYTE PTR [r11],0x2d
  40db28:	lea    r9,[r11+0x1]
  40db2c:	mov    rdx,r9
  40db2f:	mov    BYTE PTR [r9],0x0
  40db33:	sub    r9,0x1
  40db37:	mov    r8,rcx
  40db3a:	cmp    r8,r9
  40db3d:	jae    40db58 <__swc_fn_7dafa2b1_000151_6203dca2+0x858>
  40db3f:	nop
  40db40:	mov    r11b,BYTE PTR [r9]
  40db43:	mov    r12b,BYTE PTR [r8]
  40db46:	mov    BYTE PTR [r9],r12b
  40db49:	sub    r9,0x1
  40db4d:	mov    BYTE PTR [r8],r11b
  40db50:	inc    r8
  40db53:	cmp    r8,r9
  40db56:	jb     40db40 <__swc_fn_7dafa2b1_000151_6203dca2+0x840>
  40db58:	mov    r9,rdx
  40db5b:	mov    BYTE PTR [r9],0x2e
  40db5f:	add    r9,0x1
  40db63:	xor    r8d,r8d
  40db66:	test   r10,r10
  40db69:	je     40dbaf <__swc_fn_7dafa2b1_000151_6203dca2+0x8af>
  40db6b:	mov    r11d,0x989680
  40db71:	cmp    r10,r11
  40db74:	jge    40dbaf <__swc_fn_7dafa2b1_000151_6203dca2+0x8af>
  40db76:	cs nop WORD PTR [rax+rax*1+0x0]
  40db80:	inc    r8d
  40db83:	movabs rdx,0x6666666666666667
  40db8d:	mov    r15,rax
  40db90:	mov    rax,r11
  40db93:	imul   rdx
  40db96:	mov    r11,rdx
  40db99:	mov    rax,r15
  40db9c:	sar    r11,0x2
  40dba0:	mov    rdx,r11
  40dba3:	shr    rdx,0x3f
  40dba7:	add    r11,rdx
  40dbaa:	cmp    r10,r11
  40dbad:	jl     40db80 <__swc_fn_7dafa2b1_000151_6203dca2+0x880>
  40dbaf:	test   r8d,r8d
  40dbb2:	je     40dbcd <__swc_fn_7dafa2b1_000151_6203dca2+0x8cd>
  40dbb4:	cs nop WORD PTR [rax+rax*1+0x0]
  40dbbe:	xchg   ax,ax
  40dbc0:	mov    BYTE PTR [r9],0x30
  40dbc4:	add    r9,0x1
  40dbc8:	dec    r8d
  40dbcb:	jne    40dbc0 <__swc_fn_7dafa2b1_000151_6203dca2+0x8c0>
  40dbcd:	mov    r8,r9
  40dbd0:	mov    rdx,r10
  40dbd3:	cs nop WORD PTR [rax+rax*1+0x0]
  40dbdd:	nop    DWORD PTR [rax]
  40dbe0:	mov    r11,rdx
  40dbe3:	movabs rdx,0x6666666666666667
  40dbed:	mov    rax,r11
  40dbf0:	imul   rdx
  40dbf3:	sar    rdx,0x2
  40dbf7:	mov    r12,rdx
  40dbfa:	shr    rdx,0x3f
  40dbfe:	add    r12,rdx
  40dc01:	mov    rdx,r12
  40dc04:	imul   r13,r12,0xa
  40dc08:	sub    r11,r13
  40dc0b:	mov    r13,QWORD PTR [rip+0x49f6]        # 412608 <__swc_rdata_base_7dafa2b1+0x4f8>
  40dc12:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40dc17:	mov    BYTE PTR [r8],r11b
  40dc1a:	lea    r11,[r8+0x1]
  40dc1e:	mov    r8,r11
  40dc21:	test   r12,r12
  40dc24:	jne    40dbe0 <__swc_fn_7dafa2b1_000151_6203dca2+0x8e0>
  40dc26:	test   r10,r10
  40dc29:	jge    40dc33 <__swc_fn_7dafa2b1_000151_6203dca2+0x933>
  40dc2b:	mov    BYTE PTR [r11],0x2d
  40dc2f:	lea    r8,[r11+0x1]
  40dc33:	mov    BYTE PTR [r8],0x0
  40dc37:	sub    r8,0x1
  40dc3b:	cmp    r9,r8
  40dc3e:	jae    40dc58 <__swc_fn_7dafa2b1_000151_6203dca2+0x958>
  40dc40:	mov    al,BYTE PTR [r8]
  40dc43:	mov    dl,BYTE PTR [r9]
  40dc46:	mov    BYTE PTR [r8],dl
  40dc49:	sub    r8,0x1
  40dc4d:	mov    BYTE PTR [r9],al
  40dc50:	inc    r9
  40dc53:	cmp    r9,r8
  40dc56:	jb     40dc40 <__swc_fn_7dafa2b1_000151_6203dca2+0x940>
  40dc58:	xor    eax,eax
  40dc5a:	test   rcx,rcx
  40dc5d:	je     40dc90 <__swc_fn_7dafa2b1_000151_6203dca2+0x990>
  40dc5f:	mov    rdx,rcx
  40dc62:	mov    r8b,BYTE PTR [rdx]
  40dc65:	test   r8b,r8b
  40dc68:	je     40dc90 <__swc_fn_7dafa2b1_000151_6203dca2+0x990>
  40dc6a:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc74:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc7e:	xchg   ax,ax
  40dc80:	add    rdx,0x1
  40dc84:	add    rax,0x1
  40dc88:	mov    r8b,BYTE PTR [rdx]
  40dc8b:	test   r8b,r8b
  40dc8e:	jne    40dc80 <__swc_fn_7dafa2b1_000151_6203dca2+0x980>
  40dc90:	mov    QWORD PTR [rsp+0x240],rcx
  40dc98:	mov    QWORD PTR [rsp+0x248],rax
  40dca0:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  40dca9:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  40dcb2:	lea    rcx,[rsp+0x250]
  40dcba:	call   40ca90 <__swc_fn_7dafa2b1_000121_2648f149>
  40dcbf:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40dcc4:	lea    rcx,[rsp+0x260]
  40dccc:	vxorps xmm0,xmm0,xmm0
  40dcd0:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  40dcd9:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  40dce2:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  40dceb:	vzeroupper
  40dcee:	mov    DWORD PTR [rsp+0x2c0],0x0
  40dcf9:	vmovsd xmm0,QWORD PTR [rdx]
  40dcfd:	vcomisd xmm0,xmm0
  40dd01:	setne  dl
  40dd04:	movzx  edx,dl
  40dd07:	setp   r8b
  40dd0b:	movzx  r8d,r8b
  40dd0f:	or     edx,r8d
  40dd12:	test   dl,dl
  40dd14:	je     40dd21 <__swc_fn_7dafa2b1_000151_6203dca2+0xa21>
  40dd16:	mov    DWORD PTR [rcx],0x6e616e
  40dd1c:	jmp    40e328 <__swc_fn_7dafa2b1_000151_6203dca2+0x1028>
  40dd21:	vcomisd xmm0,xmm11
  40dd26:	ja     40dd37 <__swc_fn_7dafa2b1_000151_6203dca2+0xa37>
  40dd28:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  40dd31:	vcomisd xmm6,xmm0
  40dd35:	jbe    40dd5b <__swc_fn_7dafa2b1_000151_6203dca2+0xa5b>
  40dd37:	vxorpd xmm1,xmm1,xmm1
  40dd3b:	vcomisd xmm1,xmm0
  40dd3f:	jbe    40dd50 <__swc_fn_7dafa2b1_000151_6203dca2+0xa50>
  40dd41:	mov    DWORD PTR [rcx],0x666e692d
  40dd47:	mov    BYTE PTR [rcx+0x4],0x0
  40dd4b:	jmp    40e328 <__swc_fn_7dafa2b1_000151_6203dca2+0x1028>
  40dd50:	mov    DWORD PTR [rcx],0x666e69
  40dd56:	jmp    40e328 <__swc_fn_7dafa2b1_000151_6203dca2+0x1028>
  40dd5b:	vcomisd xmm0,xmm13
  40dd60:	jae    40dd6c <__swc_fn_7dafa2b1_000151_6203dca2+0xa6c>
  40dd62:	vcomisd xmm12,xmm0
  40dd66:	jbe    40e0ce <__swc_fn_7dafa2b1_000151_6203dca2+0xdce>
  40dd6c:	vmovups xmm1,xmm0
  40dd70:	vxorpd xmm2,xmm2,xmm2
  40dd74:	vcomisd xmm2,xmm0
  40dd78:	jbe    40dd88 <__swc_fn_7dafa2b1_000151_6203dca2+0xa88>
  40dd7a:	vmovsd xmm0,xmm0,xmm1
  40dd7e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x489a]        # 412620 <__swc_rdata_base_7dafa2b1+0x510>
  40dd86:	jmp    40dd8c <__swc_fn_7dafa2b1_000151_6203dca2+0xa8c>
  40dd88:	vmovsd xmm0,xmm0,xmm1
  40dd8c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  40dd95:	xor    r8d,r8d
  40dd98:	vcomisd xmm0,xmm6
  40dd9c:	jb     40ddae <__swc_fn_7dafa2b1_000151_6203dca2+0xaae>
  40dd9e:	xchg   ax,ax
  40dda0:	vdivsd xmm0,xmm0,xmm6
  40dda4:	add    r8,0x1
  40dda8:	vcomisd xmm0,xmm6
  40ddac:	jae    40dda0 <__swc_fn_7dafa2b1_000151_6203dca2+0xaa0>
  40ddae:	mov    r9,rcx
  40ddb1:	vxorpd xmm2,xmm2,xmm2
  40ddb5:	vcomisd xmm2,xmm1
  40ddb9:	jbe    40ddc2 <__swc_fn_7dafa2b1_000151_6203dca2+0xac2>
  40ddbb:	mov    BYTE PTR [rcx],0x2d
  40ddbe:	lea    r9,[rcx+0x1]
  40ddc2:	vcvttsd2si rdx,xmm0
  40ddc7:	mov    r10b,dl
  40ddca:	add    r10b,0x30
  40ddce:	mov    BYTE PTR [r9],r10b
  40ddd1:	vxorpd xmm1,xmm1,xmm1
  40ddd5:	movzx  edx,dl
  40ddd8:	vcvtsi2sd xmm1,xmm1,rdx
  40dddd:	vsubsd xmm0,xmm0,xmm1
  40dde1:	vmulsd xmm0,xmm0,xmm6
  40dde5:	mov    BYTE PTR [r9+0x1],0x2e
  40ddea:	vcvttsd2si rdx,xmm0
  40ddef:	mov    r10b,dl
  40ddf2:	add    r10b,0x30
  40ddf6:	mov    BYTE PTR [r9+0x2],r10b
  40ddfa:	vxorpd xmm1,xmm1,xmm1
  40ddfe:	movzx  edx,dl
  40de01:	vcvtsi2sd xmm1,xmm1,rdx
  40de06:	vsubsd xmm0,xmm0,xmm1
  40de0a:	vmulsd xmm0,xmm0,xmm6
  40de0e:	vcvttsd2si rdx,xmm0
  40de13:	mov    r10b,dl
  40de16:	add    r10b,0x30
  40de1a:	mov    BYTE PTR [r9+0x3],r10b
  40de1e:	vxorpd xmm1,xmm1,xmm1
  40de22:	movzx  edx,dl
  40de25:	vcvtsi2sd xmm1,xmm1,rdx
  40de2a:	vsubsd xmm0,xmm0,xmm1
  40de2e:	vmulsd xmm0,xmm0,xmm6
  40de32:	vcvttsd2si rdx,xmm0
  40de37:	mov    r10b,dl
  40de3a:	add    r10b,0x30
  40de3e:	mov    BYTE PTR [r9+0x4],r10b
  40de42:	vxorpd xmm1,xmm1,xmm1
  40de46:	movzx  edx,dl
  40de49:	vcvtsi2sd xmm1,xmm1,rdx
  40de4e:	vsubsd xmm0,xmm0,xmm1
  40de52:	vmulsd xmm0,xmm0,xmm6
  40de56:	vcvttsd2si rdx,xmm0
  40de5b:	mov    r10b,dl
  40de5e:	add    r10b,0x30
  40de62:	mov    BYTE PTR [r9+0x5],r10b
  40de66:	vxorpd xmm1,xmm1,xmm1
  40de6a:	movzx  edx,dl
  40de6d:	vcvtsi2sd xmm1,xmm1,rdx
  40de72:	vsubsd xmm0,xmm0,xmm1
  40de76:	vmulsd xmm0,xmm0,xmm6
  40de7a:	vcvttsd2si rdx,xmm0
  40de7f:	mov    r10b,dl
  40de82:	add    r10b,0x30
  40de86:	mov    BYTE PTR [r9+0x6],r10b
  40de8a:	vxorpd xmm1,xmm1,xmm1
  40de8e:	movzx  edx,dl
  40de91:	vcvtsi2sd xmm1,xmm1,rdx
  40de96:	vsubsd xmm0,xmm0,xmm1
  40de9a:	vmulsd xmm0,xmm0,xmm6
  40de9e:	vcvttsd2si rdx,xmm0
  40dea3:	mov    r10b,dl
  40dea6:	add    r10b,0x30
  40deaa:	mov    BYTE PTR [r9+0x7],r10b
  40deae:	vxorpd xmm1,xmm1,xmm1
  40deb2:	movzx  edx,dl
  40deb5:	vcvtsi2sd xmm1,xmm1,rdx
  40deba:	vsubsd xmm0,xmm0,xmm1
  40debe:	vmulsd xmm0,xmm0,xmm6
  40dec2:	vcvttsd2si rdx,xmm0
  40dec7:	mov    r10b,dl
  40deca:	add    r10b,0x30
  40dece:	mov    BYTE PTR [r9+0x8],r10b
  40ded2:	vxorpd xmm1,xmm1,xmm1
  40ded6:	movzx  edx,dl
  40ded9:	vcvtsi2sd xmm1,xmm1,rdx
  40dede:	vsubsd xmm0,xmm0,xmm1
  40dee2:	vmulsd xmm0,xmm0,xmm6
  40dee6:	vcvttsd2si rdx,xmm0
  40deeb:	mov    r10b,dl
  40deee:	add    r10b,0x30
  40def2:	mov    BYTE PTR [r9+0x9],r10b
  40def6:	vxorpd xmm1,xmm1,xmm1
  40defa:	movzx  edx,dl
  40defd:	vcvtsi2sd xmm1,xmm1,rdx
  40df02:	vsubsd xmm0,xmm0,xmm1
  40df06:	vmulsd xmm0,xmm0,xmm6
  40df0a:	vcvttsd2si rdx,xmm0
  40df0f:	mov    r10b,dl
  40df12:	add    r10b,0x30
  40df16:	mov    BYTE PTR [r9+0xa],r10b
  40df1a:	vxorpd xmm1,xmm1,xmm1
  40df1e:	movzx  edx,dl
  40df21:	vcvtsi2sd xmm1,xmm1,rdx
  40df26:	vsubsd xmm0,xmm0,xmm1
  40df2a:	vmulsd xmm0,xmm0,xmm6
  40df2e:	vcvttsd2si rdx,xmm0
  40df33:	mov    r10b,dl
  40df36:	add    r10b,0x30
  40df3a:	mov    BYTE PTR [r9+0xb],r10b
  40df3e:	lea    r10,[r9+0x4]
  40df42:	vxorpd xmm1,xmm1,xmm1
  40df46:	movzx  edx,dl
  40df49:	vcvtsi2sd xmm1,xmm1,rdx
  40df4e:	vsubsd xmm0,xmm0,xmm1
  40df52:	vmulsd xmm0,xmm0,xmm6
  40df56:	vcvttsd2si rdx,xmm0
  40df5b:	mov    r11b,dl
  40df5e:	add    r11b,0x30
  40df62:	mov    BYTE PTR [r9+0xc],r11b
  40df66:	vxorpd xmm1,xmm1,xmm1
  40df6a:	movzx  edx,dl
  40df6d:	vcvtsi2sd xmm1,xmm1,rdx
  40df72:	vsubsd xmm0,xmm0,xmm1
  40df76:	vmulsd xmm0,xmm0,xmm6
  40df7a:	vcvttsd2si rdx,xmm0
  40df7f:	mov    r11b,dl
  40df82:	add    r11b,0x30
  40df86:	mov    BYTE PTR [r9+0xd],r11b
  40df8a:	lea    r10,[r10+0x2]
  40df8e:	vxorpd xmm1,xmm1,xmm1
  40df92:	movzx  edx,dl
  40df95:	vcvtsi2sd xmm1,xmm1,rdx
  40df9a:	vsubsd xmm0,xmm0,xmm1
  40df9e:	vmulsd xmm0,xmm0,xmm6
  40dfa2:	vcvttsd2si rdx,xmm0
  40dfa7:	mov    r11b,dl
  40dfaa:	add    r11b,0x30
  40dfae:	mov    BYTE PTR [r9+0xe],r11b
  40dfb2:	vxorpd xmm1,xmm1,xmm1
  40dfb6:	movzx  edx,dl
  40dfb9:	vcvtsi2sd xmm1,xmm1,rdx
  40dfbe:	vsubsd xmm0,xmm0,xmm1
  40dfc2:	vmulsd xmm0,xmm0,xmm6
  40dfc6:	vcvttsd2si rdx,xmm0
  40dfcb:	mov    r11b,dl
  40dfce:	add    r11b,0x30
  40dfd2:	mov    BYTE PTR [r9+0xf],r11b
  40dfd6:	lea    r10,[r10+0x2]
  40dfda:	lea    r10,[r10+0x2]
  40dfde:	lea    r10,[r10+0x2]
  40dfe2:	lea    r10,[r10+0x2]
  40dfe6:	lea    r10,[r10+0x2]
  40dfea:	vxorpd xmm1,xmm1,xmm1
  40dfee:	movzx  edx,dl
  40dff1:	vcvtsi2sd xmm1,xmm1,rdx
  40dff6:	vsubsd xmm0,xmm0,xmm1
  40dffa:	vmulsd xmm0,xmm0,xmm6
  40dffe:	vcvttsd2si rdx,xmm0
  40e003:	mov    r11b,dl
  40e006:	add    r11b,0x30
  40e00a:	mov    BYTE PTR [r9+0x10],r11b
  40e00e:	vxorpd xmm1,xmm1,xmm1
  40e012:	movzx  edx,dl
  40e015:	vcvtsi2sd xmm1,xmm1,rdx
  40e01a:	vsubsd xmm0,xmm0,xmm1
  40e01e:	vmulsd xmm0,xmm0,xmm6
  40e022:	vcvttsd2si rdx,xmm0
  40e027:	add    dl,0x30
  40e02a:	mov    BYTE PTR [r9+0x11],dl
  40e02e:	mov    BYTE PTR [r10+0x2],0x65
  40e033:	lea    r9,[r10+0x3]
  40e037:	test   r8,r8
  40e03a:	jl     40e043 <__swc_fn_7dafa2b1_000151_6203dca2+0xd43>
  40e03c:	mov    BYTE PTR [r9],0x2b
  40e040:	inc    r9
  40e043:	mov    r10,r9
  40e046:	mov    rdx,r8
  40e049:	nop    DWORD PTR [rax+0x0]
  40e050:	mov    r11,rdx
  40e053:	movabs rdx,0x6666666666666667
  40e05d:	mov    rax,r11
  40e060:	imul   rdx
  40e063:	sar    rdx,0x2
  40e067:	mov    r12,rdx
  40e06a:	shr    rdx,0x3f
  40e06e:	add    r12,rdx
  40e071:	mov    rdx,r12
  40e074:	imul   r13,r12,0xa
  40e078:	sub    r11,r13
  40e07b:	mov    r13,QWORD PTR [rip+0x4586]        # 412608 <__swc_rdata_base_7dafa2b1+0x4f8>
  40e082:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40e087:	mov    BYTE PTR [r10],r11b
  40e08a:	lea    r11,[r10+0x1]
  40e08e:	mov    r10,r11
  40e091:	test   r12,r12
  40e094:	jne    40e050 <__swc_fn_7dafa2b1_000151_6203dca2+0xd50>
  40e096:	test   r8,r8
  40e099:	jge    40e0a3 <__swc_fn_7dafa2b1_000151_6203dca2+0xda3>
  40e09b:	mov    BYTE PTR [r11],0x2d
  40e09f:	lea    r10,[r11+0x1]
  40e0a3:	mov    BYTE PTR [r10],0x0
  40e0a7:	sub    r10,0x1
  40e0ab:	nop    DWORD PTR [rax+rax*1+0x0]
  40e0b0:	cmp    r9,r10
  40e0b3:	jae    40e328 <__swc_fn_7dafa2b1_000151_6203dca2+0x1028>
  40e0b9:	mov    al,BYTE PTR [r10]
  40e0bc:	mov    dl,BYTE PTR [r9]
  40e0bf:	mov    BYTE PTR [r10],dl
  40e0c2:	sub    r10,0x1
  40e0c6:	mov    BYTE PTR [r9],al
  40e0c9:	inc    r9
  40e0cc:	jmp    40e0b0 <__swc_fn_7dafa2b1_000151_6203dca2+0xdb0>
  40e0ce:	vcvttsd2si rdx,xmm0
  40e0d3:	mov    r8,rdx
  40e0d6:	vxorpd xmm1,xmm1,xmm1
  40e0da:	vcvtsi2sd xmm1,xmm1,rdx
  40e0df:	vsubsd xmm1,xmm0,xmm1
  40e0e3:	mov    r9d,0x8
  40e0e9:	vxorpd xmm2,xmm2,xmm2
  40e0ed:	vcomisd xmm2,xmm1
  40e0f1:	ja     40e0fe <__swc_fn_7dafa2b1_000151_6203dca2+0xdfe>
  40e0f3:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40e0fc:	jmp    40e10f <__swc_fn_7dafa2b1_000151_6203dca2+0xe0f>
  40e0fe:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x451a]        # 412620 <__swc_rdata_base_7dafa2b1+0x510>
  40e106:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40e10f:	test   r9d,r9d
  40e112:	je     40e129 <__swc_fn_7dafa2b1_000151_6203dca2+0xe29>
  40e114:	cs nop WORD PTR [rax+rax*1+0x0]
  40e11e:	xchg   ax,ax
  40e120:	vmulsd xmm1,xmm1,xmm6
  40e124:	dec    r9d
  40e127:	jne    40e120 <__swc_fn_7dafa2b1_000151_6203dca2+0xe20>
  40e129:	vcvttsd2si r9,xmm1
  40e12e:	mov    r10,r9
  40e131:	vxorpd xmm2,xmm2,xmm2
  40e135:	vcvtsi2sd xmm2,xmm2,r9
  40e13a:	vsubsd xmm1,xmm1,xmm2
  40e13e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  40e147:	vcomisd xmm1,xmm6
  40e14b:	lea    r9,[r9+0x1]
  40e14f:	cmova  r10,r9
  40e153:	cmp    r10,0x5f5e100
  40e15a:	jne    40e173 <__swc_fn_7dafa2b1_000151_6203dca2+0xe73>
  40e15c:	lea    r8,[rdx-0x1]
  40e160:	vxorpd xmm1,xmm1,xmm1
  40e164:	vcomisd xmm1,xmm0
  40e168:	lea    rdx,[rdx+0x1]
  40e16c:	cmovbe r8,rdx
  40e170:	xor    r10d,r10d
  40e173:	mov    r9,rcx
  40e176:	test   r8,r8
  40e179:	jne    40e199 <__swc_fn_7dafa2b1_000151_6203dca2+0xe99>
  40e17b:	vxorpd xmm1,xmm1,xmm1
  40e17f:	vcomisd xmm1,xmm0
  40e183:	jbe    40e18c <__swc_fn_7dafa2b1_000151_6203dca2+0xe8c>
  40e185:	mov    BYTE PTR [rcx],0x2d
  40e188:	lea    r9,[rcx+0x1]
  40e18c:	mov    BYTE PTR [r9],0x30
  40e190:	add    r9,0x1
  40e194:	jmp    40e22b <__swc_fn_7dafa2b1_000151_6203dca2+0xf2b>
  40e199:	mov    r9,rcx
  40e19c:	mov    rdx,r8
  40e19f:	nop
  40e1a0:	mov    r11,rdx
  40e1a3:	movabs rdx,0x6666666666666667
  40e1ad:	mov    r15,rax
  40e1b0:	mov    rax,r11
  40e1b3:	imul   rdx
  40e1b6:	mov    r12,rdx
  40e1b9:	mov    rax,r15
  40e1bc:	sar    r12,0x2
  40e1c0:	mov    rdx,r12
  40e1c3:	shr    rdx,0x3f
  40e1c7:	add    r12,rdx
  40e1ca:	mov    rdx,r12
  40e1cd:	imul   r13,r12,0xa
  40e1d1:	sub    r11,r13
  40e1d4:	mov    r13,QWORD PTR [rip+0x442d]        # 412608 <__swc_rdata_base_7dafa2b1+0x4f8>
  40e1db:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40e1e0:	mov    BYTE PTR [r9],r11b
  40e1e3:	lea    r11,[r9+0x1]
  40e1e7:	mov    r9,r11
  40e1ea:	test   r12,r12
  40e1ed:	jne    40e1a0 <__swc_fn_7dafa2b1_000151_6203dca2+0xea0>
  40e1ef:	test   r8,r8
  40e1f2:	jge    40e1fc <__swc_fn_7dafa2b1_000151_6203dca2+0xefc>
  40e1f4:	mov    BYTE PTR [r11],0x2d
  40e1f8:	lea    r9,[r11+0x1]
  40e1fc:	mov    rdx,r9
  40e1ff:	mov    BYTE PTR [r9],0x0
  40e203:	sub    r9,0x1
  40e207:	mov    r8,rcx
  40e20a:	cmp    r8,r9
  40e20d:	jae    40e228 <__swc_fn_7dafa2b1_000151_6203dca2+0xf28>
  40e20f:	nop
  40e210:	mov    r11b,BYTE PTR [r9]
  40e213:	mov    r12b,BYTE PTR [r8]
  40e216:	mov    BYTE PTR [r9],r12b
  40e219:	sub    r9,0x1
  40e21d:	mov    BYTE PTR [r8],r11b
  40e220:	inc    r8
  40e223:	cmp    r8,r9
  40e226:	jb     40e210 <__swc_fn_7dafa2b1_000151_6203dca2+0xf10>
  40e228:	mov    r9,rdx
  40e22b:	mov    BYTE PTR [r9],0x2e
  40e22f:	add    r9,0x1
  40e233:	xor    r8d,r8d
  40e236:	test   r10,r10
  40e239:	je     40e27f <__swc_fn_7dafa2b1_000151_6203dca2+0xf7f>
  40e23b:	mov    r11d,0x989680
  40e241:	cmp    r10,r11
  40e244:	jge    40e27f <__swc_fn_7dafa2b1_000151_6203dca2+0xf7f>
  40e246:	cs nop WORD PTR [rax+rax*1+0x0]
  40e250:	inc    r8d
  40e253:	movabs rdx,0x6666666666666667
  40e25d:	mov    r15,rax
  40e260:	mov    rax,r11
  40e263:	imul   rdx
  40e266:	mov    r11,rdx
  40e269:	mov    rax,r15
  40e26c:	sar    r11,0x2
  40e270:	mov    rdx,r11
  40e273:	shr    rdx,0x3f
  40e277:	add    r11,rdx
  40e27a:	cmp    r10,r11
  40e27d:	jl     40e250 <__swc_fn_7dafa2b1_000151_6203dca2+0xf50>
  40e27f:	test   r8d,r8d
  40e282:	je     40e29d <__swc_fn_7dafa2b1_000151_6203dca2+0xf9d>
  40e284:	cs nop WORD PTR [rax+rax*1+0x0]
  40e28e:	xchg   ax,ax
  40e290:	mov    BYTE PTR [r9],0x30
  40e294:	add    r9,0x1
  40e298:	dec    r8d
  40e29b:	jne    40e290 <__swc_fn_7dafa2b1_000151_6203dca2+0xf90>
  40e29d:	mov    r8,r9
  40e2a0:	mov    rdx,r10
  40e2a3:	cs nop WORD PTR [rax+rax*1+0x0]
  40e2ad:	nop    DWORD PTR [rax]
  40e2b0:	mov    r11,rdx
  40e2b3:	movabs rdx,0x6666666666666667
  40e2bd:	mov    rax,r11
  40e2c0:	imul   rdx
  40e2c3:	sar    rdx,0x2
  40e2c7:	mov    r12,rdx
  40e2ca:	shr    rdx,0x3f
  40e2ce:	add    r12,rdx
  40e2d1:	mov    rdx,r12
  40e2d4:	imul   r13,r12,0xa
  40e2d8:	sub    r11,r13
  40e2db:	mov    r13,QWORD PTR [rip+0x4326]        # 412608 <__swc_rdata_base_7dafa2b1+0x4f8>
  40e2e2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40e2e7:	mov    BYTE PTR [r8],r11b
  40e2ea:	lea    r11,[r8+0x1]
  40e2ee:	mov    r8,r11
  40e2f1:	test   r12,r12
  40e2f4:	jne    40e2b0 <__swc_fn_7dafa2b1_000151_6203dca2+0xfb0>
  40e2f6:	test   r10,r10
  40e2f9:	jge    40e303 <__swc_fn_7dafa2b1_000151_6203dca2+0x1003>
  40e2fb:	mov    BYTE PTR [r11],0x2d
  40e2ff:	lea    r8,[r11+0x1]
  40e303:	mov    BYTE PTR [r8],0x0
  40e307:	sub    r8,0x1
  40e30b:	cmp    r9,r8
  40e30e:	jae    40e328 <__swc_fn_7dafa2b1_000151_6203dca2+0x1028>
  40e310:	mov    al,BYTE PTR [r8]
  40e313:	mov    dl,BYTE PTR [r9]
  40e316:	mov    BYTE PTR [r8],dl
  40e319:	sub    r8,0x1
  40e31d:	mov    BYTE PTR [r9],al
  40e320:	inc    r9
  40e323:	cmp    r9,r8
  40e326:	jb     40e310 <__swc_fn_7dafa2b1_000151_6203dca2+0x1010>
  40e328:	xor    eax,eax
  40e32a:	test   rcx,rcx
  40e32d:	je     40e350 <__swc_fn_7dafa2b1_000151_6203dca2+0x1050>
  40e32f:	mov    rdx,rcx
  40e332:	mov    r8b,BYTE PTR [rdx]
  40e335:	test   r8b,r8b
  40e338:	je     40e350 <__swc_fn_7dafa2b1_000151_6203dca2+0x1050>
  40e33a:	nop    WORD PTR [rax+rax*1+0x0]
  40e340:	add    rdx,0x1
  40e344:	add    rax,0x1
  40e348:	mov    r8b,BYTE PTR [rdx]
  40e34b:	test   r8b,r8b
  40e34e:	jne    40e340 <__swc_fn_7dafa2b1_000151_6203dca2+0x1040>
  40e350:	mov    QWORD PTR [rsp+0x3f8],rcx
  40e358:	mov    QWORD PTR [rsp+0x400],rax
  40e360:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  40e369:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  40e372:	lea    rcx,[rsp+0x408]
  40e37a:	call   40ca90 <__swc_fn_7dafa2b1_000121_2648f149>
  40e37f:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40e381:	mov    rcx,rdx
  40e384:	call   40ca90 <__swc_fn_7dafa2b1_000121_2648f149>
  40e389:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40e38b:	mov    al,BYTE PTR [rdx]
  40e38d:	test   al,al
  40e38f:	je     40e39a <__swc_fn_7dafa2b1_000151_6203dca2+0x109a>
  40e391:	lea    rax,[rip+0x4298]        # 412630 <__swc_rdata_base_7dafa2b1+0x520>
  40e398:	jmp    40e3a1 <__swc_fn_7dafa2b1_000151_6203dca2+0x10a1>
  40e39a:	lea    rax,[rip+0x429f]        # 412640 <__swc_rdata_base_7dafa2b1+0x530>
  40e3a1:	mov    rcx,rax
  40e3a4:	call   40ca90 <__swc_fn_7dafa2b1_000121_2648f149>
  40e3a9:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40e3ab:	lea    rcx,[rip+0x429e]        # 412650 <__swc_rdata_base_7dafa2b1+0x540>
  40e3b2:	call   40ca90 <__swc_fn_7dafa2b1_000121_2648f149>
  40e3b7:	jmp    40e3c5 <__swc_fn_7dafa2b1_000151_6203dca2+0x10c5>
  40e3b9:	lea    rcx,[rip+0x4290]        # 412650 <__swc_rdata_base_7dafa2b1+0x540>
  40e3c0:	call   40ca90 <__swc_fn_7dafa2b1_000121_2648f149>
  40e3c5:	add    rdi,0x1
  40e3c9:	sub    rsi,0x1
  40e3cd:	vmovups xmm0,xmm12
  40e3d2:	vmovsd xmm6,QWORD PTR [rip+0x4286]        # 412660 <__swc_rdata_base_7dafa2b1+0x550>
  40e3da:	test   rsi,rsi
  40e3dd:	jne    40d410 <__swc_fn_7dafa2b1_000151_6203dca2+0x110>
  40e3e3:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  40e3ec:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  40e3f5:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  40e3fe:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  40e407:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  40e410:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  40e419:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  40e422:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  40e42b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  40e434:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  40e43d:	add    rsp,0x4e8
  40e444:	pop    r15
  40e446:	pop    r13
  40e448:	pop    r12
  40e44a:	pop    rdi
  40e44b:	pop    rsi
  40e44c:	pop    rbx
  40e44d:	ret
	...

000000000040e450 <__swc_fn_7dafa2b1_000154_86f1d437>:
  40e450:	vxorps xmm0,xmm0,xmm0
  40e454:	vmovups XMMWORD PTR [rcx],xmm0
  40e458:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e45d:	ret
	...

000000000040e460 <__swc_fn_7dafa2b1_000157_86f1d437>:
  40e460:	vxorps xmm0,xmm0,xmm0
  40e464:	vmovups XMMWORD PTR [rcx],xmm0
  40e468:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e46d:	vxorps xmm0,xmm0,xmm0
  40e471:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e476:	vmovups xmm0,XMMWORD PTR [rip+0x42f2]        # 412770 <__swc_rdata_base_7dafa2b1+0x660>
  40e47e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e483:	vxorps xmm0,xmm0,xmm0
  40e487:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40e48c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40e491:	vxorps xmm0,xmm0,xmm0
  40e495:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40e49a:	mov    QWORD PTR [rcx+0x70],0x0
  40e4a2:	ret
	...

000000000040e4b0 <__swc_fn_7dafa2b1_000160_86f1d437>:
  40e4b0:	vxorps xmm0,xmm0,xmm0
  40e4b4:	vmovups XMMWORD PTR [rcx],xmm0
  40e4b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e4bd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e4c2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e4c7:	ret
	...

000000000040e4d0 <__swc_fn_7dafa2b1_000163_e36363a8>:
  40e4d0:	push   rsi
  40e4d1:	push   rdi
  40e4d2:	sub    rsp,0x8
  40e4d6:	mov    rsi,rcx
  40e4d9:	mov    rdi,QWORD PTR [rsi+0x50]
  40e4dd:	test   rdi,rdi
  40e4e0:	je     40e4e7 <__swc_fn_7dafa2b1_000163_e36363a8+0x17>
  40e4e2:	mov    rcx,rsi
  40e4e5:	call   rdi
  40e4e7:	mov    QWORD PTR [rsi+0x20],0x0
  40e4ef:	mov    rax,QWORD PTR [rsi+0x30]
  40e4f3:	test   rax,rax
  40e4f6:	je     40e524 <__swc_fn_7dafa2b1_000163_e36363a8+0x54>
  40e4f8:	nop    DWORD PTR [rax+rax*1+0x0]
  40e500:	mov    rdi,QWORD PTR [rax+0x8]
  40e504:	mov    rcx,rsi
  40e507:	mov    rdx,QWORD PTR [rax+0x10]
  40e50b:	mov    rax,QWORD PTR [rax+0x18]
  40e50f:	mov    r8,rax
  40e512:	call   411690 <__swc_fn_7dafa2b1_000161_47b270e1>
  40e517:	mov    QWORD PTR [rsi+0x30],rdi
  40e51b:	mov    rax,QWORD PTR [rsi+0x30]
  40e51f:	test   rax,rax
  40e522:	jne    40e500 <__swc_fn_7dafa2b1_000163_e36363a8+0x30>
  40e524:	mov    QWORD PTR [rsi+0x38],0x0
  40e52c:	add    rsp,0x8
  40e530:	pop    rdi
  40e531:	pop    rsi
  40e532:	ret
	...

000000000040e540 <__swc_fn_7dafa2b1_000166_016ee66a>:
  40e540:	push   rbx
  40e541:	push   rsi
  40e542:	push   rdi
  40e543:	push   r12
  40e545:	sub    rsp,0x188
  40e54c:	mov    rbx,rcx
  40e54f:	lea    rsi,[rip+0x17832]        # 425d88 <__swc_bss_base_7dafa2b1+0x2d48>
  40e556:	mov    rcx,rsi
  40e559:	call   4110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>
  40e55e:	mov    rax,QWORD PTR [rip+0x1782b]        # 425d90 <__swc_bss_base_7dafa2b1+0x2d50>
  40e565:	mov    rdi,rax
  40e568:	test   rdi,rdi
  40e56b:	je     40e599 <__swc_fn_7dafa2b1_000166_016ee66a+0x59>
  40e56d:	nop    DWORD PTR [rax]
  40e570:	cmp    QWORD PTR [rdi+0x8],rbx
  40e574:	jne    40e58e <__swc_fn_7dafa2b1_000166_016ee66a+0x4e>
  40e576:	mov    rcx,rsi
  40e579:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40e57e:	mov    rax,rdi
  40e581:	add    rsp,0x188
  40e588:	pop    r12
  40e58a:	pop    rdi
  40e58b:	pop    rsi
  40e58c:	pop    rbx
  40e58d:	ret
  40e58e:	mov    rax,QWORD PTR [rdi]
  40e591:	mov    rdi,rax
  40e594:	test   rax,rax
  40e597:	jne    40e570 <__swc_fn_7dafa2b1_000166_016ee66a+0x30>
  40e599:	call   409f20 <__swc_fn_7dafa2b1_000144_d299b428>
  40e59e:	mov    rdi,rax
  40e5a1:	test   rax,rax
  40e5a4:	jne    40e5bd <__swc_fn_7dafa2b1_000166_016ee66a+0x7d>
  40e5a6:	mov    rcx,rsi
  40e5a9:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40e5ae:	xor    eax,eax
  40e5b0:	add    rsp,0x188
  40e5b7:	pop    r12
  40e5b9:	pop    rdi
  40e5ba:	pop    rsi
  40e5bb:	pop    rbx
  40e5bc:	ret
  40e5bd:	lea    rax,[rsp+0x18]
  40e5c2:	mov    QWORD PTR [rax+0x10],0x0
  40e5ca:	mov    QWORD PTR [rax+0x18],0x0
  40e5d2:	mov    DWORD PTR [rax+0x20],0x0
  40e5d9:	mov    BYTE PTR [rax+0x24],0x0
  40e5dd:	mov    rax,QWORD PTR [rip+0x177ac]        # 425d90 <__swc_bss_base_7dafa2b1+0x2d50>
  40e5e4:	mov    QWORD PTR [rsp+0x18],rax
  40e5e9:	mov    QWORD PTR [rsp+0x20],rbx
  40e5ee:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e5f4:	vmovups XMMWORD PTR [rdi],xmm0
  40e5f8:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e5fe:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  40e603:	mov    rax,QWORD PTR [rsp+0x38]
  40e608:	mov    QWORD PTR [rdi+0x20],rax
  40e60c:	mov    QWORD PTR [rip+0x1777d],rdi        # 425d90 <__swc_bss_base_7dafa2b1+0x2d50>
  40e613:	lea    rax,[rsp+0x40]
  40e618:	mov    QWORD PTR [rax],0x0
  40e61f:	mov    rcx,rbx
  40e622:	mov    rdx,rax
  40e625:	call   411180 <__swc_fn_7dafa2b1_000146_1534de9a>
  40e62a:	mov    rbx,rax
  40e62d:	test   rax,rax
  40e630:	jne    40e64a <__swc_fn_7dafa2b1_000166_016ee66a+0x10a>
  40e632:	mov    rcx,rsi
  40e635:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40e63a:	mov    rax,rdi
  40e63d:	add    rsp,0x188
  40e644:	pop    r12
  40e646:	pop    rdi
  40e647:	pop    rsi
  40e648:	pop    rbx
  40e649:	ret
  40e64a:	lea    r12,[rsp+0x50]
  40e64f:	mov    QWORD PTR [r12],0x0
  40e657:	mov    rcx,rbx
  40e65a:	mov    rdx,QWORD PTR [rsp+0x40]
  40e65f:	mov    r8,r12
  40e662:	call   409fd0 <__swc_fn_7dafa2b1_000147_162f363d>
  40e667:	test   rax,rax
  40e66a:	jne    40e684 <__swc_fn_7dafa2b1_000166_016ee66a+0x144>
  40e66c:	mov    rcx,rsi
  40e66f:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40e674:	mov    rax,rdi
  40e677:	add    rsp,0x188
  40e67e:	pop    r12
  40e680:	pop    rdi
  40e681:	pop    rsi
  40e682:	pop    rbx
  40e683:	ret
  40e684:	cmp    QWORD PTR [r12],0x10
  40e689:	jb     40e78c <__swc_fn_7dafa2b1_000166_016ee66a+0x24c>
  40e68f:	mov    ecx,DWORD PTR [rax]
  40e691:	cmp    ecx,0x42445753
  40e697:	jne    40e78c <__swc_fn_7dafa2b1_000166_016ee66a+0x24c>
  40e69d:	mov    ecx,DWORD PTR [rax+0x4]
  40e6a0:	cmp    ecx,0x1
  40e6a3:	jne    40e78c <__swc_fn_7dafa2b1_000166_016ee66a+0x24c>
  40e6a9:	mov    ecx,DWORD PTR [rax+0x8]
  40e6ac:	mov    edx,DWORD PTR [rax+0xc]
  40e6af:	imul   r8,rcx,0x14
  40e6b3:	mov    r9,QWORD PTR [rsp+0x50]
  40e6b8:	sub    r9,0x10
  40e6bc:	cmp    r8,r9
  40e6bf:	ja     40e78c <__swc_fn_7dafa2b1_000166_016ee66a+0x24c>
  40e6c5:	lea    r8,[r8+0x10]
  40e6c9:	cmp    rdx,r8
  40e6cc:	jb     40e78c <__swc_fn_7dafa2b1_000166_016ee66a+0x24c>
  40e6d2:	mov    r8,QWORD PTR [rsp+0x50]
  40e6d7:	cmp    rdx,r8
  40e6da:	ja     40e78c <__swc_fn_7dafa2b1_000166_016ee66a+0x24c>
  40e6e0:	xor    r8d,r8d
  40e6e3:	test   rcx,rcx
  40e6e6:	jbe    40e7b2 <__swc_fn_7dafa2b1_000166_016ee66a+0x272>
  40e6ec:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  40e6f2:	cs nop WORD PTR [rax+rax*1+0x0]
  40e6fc:	nop    DWORD PTR [rax+0x0]
  40e700:	imul   r9,r8,0x14
  40e704:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  40e709:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  40e70e:	add    r10,r11
  40e711:	movabs r11,0x100000000
  40e71b:	cmp    r10,r11
  40e71e:	ja     40e78c <__swc_fn_7dafa2b1_000166_016ee66a+0x24c>
  40e720:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  40e725:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  40e72a:	test   r10d,r10d
  40e72d:	setne  r11b
  40e731:	je     40e74b <__swc_fn_7dafa2b1_000166_016ee66a+0x20b>
  40e733:	cmp    r10d,edx
  40e736:	setb   r11b
  40e73a:	jb     40e74b <__swc_fn_7dafa2b1_000166_016ee66a+0x20b>
  40e73c:	vmovq  r11,xmm1
  40e741:	cmp    r10,r11
  40e744:	setae  r10b
  40e748:	mov    r11b,r10b
  40e74b:	mov    r10,r11
  40e74e:	test   r11b,r11b
  40e751:	jne    40e778 <__swc_fn_7dafa2b1_000166_016ee66a+0x238>
  40e753:	test   r9d,r9d
  40e756:	setne  r10b
  40e75a:	je     40e778 <__swc_fn_7dafa2b1_000166_016ee66a+0x238>
  40e75c:	cmp    r9d,edx
  40e75f:	setb   r10b
  40e763:	jb     40e778 <__swc_fn_7dafa2b1_000166_016ee66a+0x238>
  40e765:	vmovq  r10,xmm1
  40e76a:	cmp    r9,r10
  40e76d:	setae  r9b
  40e771:	movzx  r9d,r9b
  40e775:	mov    r10b,r9b
  40e778:	test   r10b,r10b
  40e77b:	jne    40e78c <__swc_fn_7dafa2b1_000166_016ee66a+0x24c>
  40e77d:	add    r8,0x1
  40e781:	cmp    r8,rcx
  40e784:	jb     40e700 <__swc_fn_7dafa2b1_000166_016ee66a+0x1c0>
  40e78a:	jmp    40e7b2 <__swc_fn_7dafa2b1_000166_016ee66a+0x272>
  40e78c:	xor    ecx,ecx
  40e78e:	cmp    rax,rbx
  40e791:	cmovne rcx,rax
  40e795:	call   40d250 <__swc_fn_7dafa2b1_000148_d7edc04f>
  40e79a:	mov    rcx,rsi
  40e79d:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40e7a2:	mov    rax,rdi
  40e7a5:	add    rsp,0x188
  40e7ac:	pop    r12
  40e7ae:	pop    rdi
  40e7af:	pop    rsi
  40e7b0:	pop    rbx
  40e7b1:	ret
  40e7b2:	mov    QWORD PTR [rdi+0x10],rax
  40e7b6:	mov    rcx,QWORD PTR [rsp+0x50]
  40e7bb:	mov    QWORD PTR [rdi+0x18],rcx
  40e7bf:	mov    eax,DWORD PTR [rax+0x8]
  40e7c2:	mov    DWORD PTR [rdi+0x20],eax
  40e7c5:	rex mov BYTE PTR [rdi+0x24],0x1
  40e7ca:	mov    rcx,rsi
  40e7cd:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40e7d2:	mov    rax,rdi
  40e7d5:	add    rsp,0x188
  40e7dc:	pop    r12
  40e7de:	pop    rdi
  40e7df:	pop    rsi
  40e7e0:	pop    rbx
  40e7e1:	ret
	...

000000000040e7f0 <__swc_fn_7dafa2b1_000169_3459066f>:
  40e7f0:	push   rsi
  40e7f1:	push   rdi
  40e7f2:	push   r12
  40e7f4:	mov    rsi,rdx
  40e7f7:	mov    rdi,rcx
  40e7fa:	mov    rcx,QWORD PTR [rip+0x1483f]        # 423040 <__swc_bss_base_7dafa2b1>
  40e801:	test   rcx,rcx
  40e804:	jne    40e816 <__swc_fn_7dafa2b1_000169_3459066f+0x26>
  40e806:	call   4119a0 <__swc_fn_7dafa2b1_000170_994c8876>
  40e80b:	lea    rcx,[rax+0x1]
  40e80f:	mov    QWORD PTR [rip+0x1482a],rcx        # 423040 <__swc_bss_base_7dafa2b1>
  40e816:	dec    rcx
  40e819:	call   40e840 <__swc_fn_7dafa2b1_000172_360af05d>
  40e81e:	mov    r12,QWORD PTR [rax+0xbe0]
  40e825:	test   r12,r12
  40e828:	setne  al
  40e82b:	je     40e836 <__swc_fn_7dafa2b1_000169_3459066f+0x46>
  40e82d:	mov    rcx,rdi
  40e830:	mov    rdx,rsi
  40e833:	call   r12
  40e836:	pop    r12
  40e838:	pop    rdi
  40e839:	pop    rsi
  40e83a:	ret
  40e83b:	add    BYTE PTR [rax],al
  40e83d:	add    BYTE PTR [rax],al
	...

000000000040e840 <__swc_fn_7dafa2b1_000172_360af05d>:
  40e840:	push   r12
  40e842:	push   rdi
  40e843:	push   rsi
  40e844:	sub    rsp,0xd0
  40e84b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40e851:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40e857:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40e85d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40e863:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40e869:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40e86f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40e878:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40e881:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40e88a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40e893:	mov    r12,rcx
  40e896:	mov    edi,ecx
  40e898:	xor    eax,eax
  40e89a:	call   407000 <pthread_getspecific@plt>
  40e89f:	test   rax,rax
  40e8a2:	je     40e8a6 <__swc_fn_7dafa2b1_000172_360af05d+0x66>
  40e8a4:	jmp    40e8ae <__swc_fn_7dafa2b1_000172_360af05d+0x6e>
  40e8a6:	mov    rcx,r12
  40e8a9:	call   411a00 <__swc_fn_7dafa2b1_000173_cbeff767>
  40e8ae:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40e8b4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40e8ba:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40e8c0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40e8c6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40e8cc:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40e8d2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40e8db:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40e8e4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40e8ed:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40e8f6:	add    rsp,0xd0
  40e8fd:	pop    rsi
  40e8fe:	pop    rdi
  40e8ff:	pop    r12
  40e901:	ret
	...

000000000040e910 <__swc_fn_7dafa2b1_000175_5eac0ab4>:
  40e910:	push   rsi
  40e911:	sub    rsp,0x30
  40e915:	lea    rsi,[rip+0x17484]        # 425da0 <__swc_bss_base_7dafa2b1+0x2d60>
  40e91c:	mov    rax,QWORD PTR [rsi]
  40e91f:	test   rax,rax
  40e922:	je     40e92a <__swc_fn_7dafa2b1_000175_5eac0ab4+0x1a>
  40e924:	add    rsp,0x30
  40e928:	pop    rsi
  40e929:	ret
  40e92a:	mov    ecx,0x3
  40e92f:	mov    edx,0x10
  40e934:	call   40c3b0 <__swc_fn_7dafa2b1_000112_6814119b>
  40e939:	test   rax,rax
  40e93c:	jne    40e94d <__swc_fn_7dafa2b1_000175_5eac0ab4+0x3d>
  40e93e:	mov    QWORD PTR [rsp+0x18],rax
  40e943:	call   409a70 <__swc_fn_7dafa2b1_000123_be2e2f68>
  40e948:	mov    rax,QWORD PTR [rsp+0x18]
  40e94d:	mov    rcx,rax
  40e950:	xchg   QWORD PTR [rsi],rcx
  40e953:	add    rsp,0x30
  40e957:	pop    rsi
  40e958:	ret
  40e959:	add    BYTE PTR [rax],al
  40e95b:	add    BYTE PTR [rax],al
  40e95d:	add    BYTE PTR [rax],al
	...

000000000040e960 <__swc_fn_7dafa2b1_000178_cf4ffedd>:
  40e960:	push   rsi
  40e961:	push   rdi
  40e962:	sub    rsp,0x8
  40e966:	mov    rsi,rdx
  40e969:	mov    rdi,rcx
  40e96c:	mov    rax,QWORD PTR [rsi+0x8]
  40e970:	test   rax,rax
  40e973:	je     40e97d <__swc_fn_7dafa2b1_000178_cf4ffedd+0x1d>
  40e975:	mov    rcx,QWORD PTR [rsi]
  40e978:	mov    QWORD PTR [rax],rcx
  40e97b:	jmp    40e984 <__swc_fn_7dafa2b1_000178_cf4ffedd+0x24>
  40e97d:	mov    rax,QWORD PTR [rsi]
  40e980:	mov    QWORD PTR [rdi+0x8],rax
  40e984:	mov    rax,QWORD PTR [rsi]
  40e987:	test   rax,rax
  40e98a:	je     40e994 <__swc_fn_7dafa2b1_000178_cf4ffedd+0x34>
  40e98c:	mov    rcx,QWORD PTR [rsi+0x8]
  40e990:	mov    QWORD PTR [rax+0x8],rcx
  40e994:	mov    rcx,rdi
  40e997:	mov    rdx,QWORD PTR [rsi+0x10]
  40e99b:	mov    r8,QWORD PTR [rsi+0x18]
  40e99f:	mov    r9,0xffffffffffffffff
  40e9a6:	call   40a620 <__swc_fn_7dafa2b1_000177_4de704de>
  40e9ab:	mov    QWORD PTR [rsi+0x18],0x0
  40e9b3:	mov    rax,QWORD PTR [rdi+0x8]
  40e9b7:	test   rax,rax
  40e9ba:	jne    40e9cc <__swc_fn_7dafa2b1_000178_cf4ffedd+0x6c>
  40e9bc:	call   40e910 <__swc_fn_7dafa2b1_000175_5eac0ab4>
  40e9c1:	xor    ecx,ecx
  40e9c3:	mov    QWORD PTR [rax+0x8],rcx
  40e9c7:	xor    ecx,ecx
  40e9c9:	mov    QWORD PTR [rax],rcx
  40e9cc:	add    rsp,0x8
  40e9d0:	pop    rdi
  40e9d1:	pop    rsi
  40e9d2:	ret
	...

000000000040e9e0 <__swc_fn_7dafa2b1_000002_6e6aee58>:
  40e9e0:	push   rbx
  40e9e1:	sub    rsp,0x80
  40e9e8:	mov    rax,rcx
  40e9eb:	mov    rcx,QWORD PTR [rax]
  40e9ee:	test   rcx,rcx
  40e9f1:	je     40ea10 <__swc_fn_7dafa2b1_000002_6e6aee58+0x30>
  40e9f3:	mov    QWORD PTR [rsp+0x68],rax
  40e9f8:	call   40e9e0 <__swc_fn_7dafa2b1_000002_6e6aee58>
  40e9fd:	mov    rax,QWORD PTR [rsp+0x68]
  40ea02:	mov    rcx,QWORD PTR [rax+0x8]
  40ea06:	call   40e9e0 <__swc_fn_7dafa2b1_000002_6e6aee58>
  40ea0b:	mov    rax,QWORD PTR [rsp+0x68]
  40ea10:	test   rax,rax
  40ea13:	je     40ea76 <__swc_fn_7dafa2b1_000002_6e6aee58+0x96>
  40ea15:	vxorps xmm0,xmm0,xmm0
  40ea19:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40ea1f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40ea25:	vzeroupper
  40ea28:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40ea2e:	lea    rcx,[rax-0x10]
  40ea32:	mov    QWORD PTR [rsp+0x48],rcx
  40ea37:	mov    rax,QWORD PTR [rax-0x10]
  40ea3b:	mov    QWORD PTR [rsp+0x50],rax
  40ea40:	mov    rcx,QWORD PTR [rip+0x145f9]        # 423040 <__swc_bss_base_7dafa2b1>
  40ea47:	test   rcx,rcx
  40ea4a:	jne    40ea5c <__swc_fn_7dafa2b1_000002_6e6aee58+0x7c>
  40ea4c:	call   4119a0 <__swc_fn_7dafa2b1_000170_994c8876>
  40ea51:	lea    rcx,[rax+0x1]
  40ea55:	mov    QWORD PTR [rip+0x145e4],rcx        # 423040 <__swc_bss_base_7dafa2b1>
  40ea5c:	dec    rcx
  40ea5f:	call   40e840 <__swc_fn_7dafa2b1_000172_360af05d>
  40ea64:	mov    rcx,QWORD PTR [rax]
  40ea67:	lea    rdx,[rsp+0x8]
  40ea6c:	mov    rbx,QWORD PTR [rax+0x8]
  40ea70:	mov    rbx,QWORD PTR [rbx+0x18]
  40ea74:	call   rbx
  40ea76:	add    rsp,0x80
  40ea7d:	pop    rbx
  40ea7e:	ret
	...

000000000040ea80 <__swc_fn_7dafa2b1_000005_9ee35b18>:
  40ea80:	vxorps xmm0,xmm0,xmm0
  40ea84:	vmovups XMMWORD PTR [rcx],xmm0
  40ea88:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40ea8d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ea92:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ea97:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40ea9c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40eaa1:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40eaa6:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40eaab:	ret
  40eaac:	add    BYTE PTR [rax],al
	...

000000000040eab0 <__swc_fn_7dafa2b1_000008_f7acedb0>:
  40eab0:	push   rsi
  40eab1:	mov    rsi,rdx
  40eab4:	test   rdx,rdx
  40eab7:	jne    40eac0 <__swc_fn_7dafa2b1_000008_f7acedb0+0x10>
  40eab9:	mov    eax,0x1
  40eabe:	pop    rsi
  40eabf:	ret
  40eac0:	mov    rdx,rsi
  40eac3:	call   410a40 <__swc_fn_7dafa2b1_000116_36905703>
  40eac8:	test   al,al
  40eaca:	jne    40ead0 <__swc_fn_7dafa2b1_000008_f7acedb0+0x20>
  40eacc:	xor    eax,eax
  40eace:	pop    rsi
  40eacf:	ret
  40ead0:	lea    rcx,[rip+0x14579]        # 423050 <__swc_bss_base_7dafa2b1+0x10>
  40ead7:	mov    rdx,QWORD PTR [rip+0x14572]        # 423050 <__swc_bss_base_7dafa2b1+0x10>
  40eade:	xchg   ax,ax
  40eae0:	lea    r8,[rdx+rsi*1]
  40eae4:	mov    rax,rdx
  40eae7:	lock cmpxchg QWORD PTR [rcx],r8
  40eaec:	cmp    rax,rdx
  40eaef:	je     40eaf6 <__swc_fn_7dafa2b1_000008_f7acedb0+0x46>
  40eaf1:	mov    rdx,rax
  40eaf4:	jmp    40eae0 <__swc_fn_7dafa2b1_000008_f7acedb0+0x30>
  40eaf6:	lea    rcx,[rip+0x1455b]        # 423058 <__swc_bss_base_7dafa2b1+0x18>
  40eafd:	mov    rdx,QWORD PTR [rip+0x14554]        # 423058 <__swc_bss_base_7dafa2b1+0x18>
  40eb04:	cs nop WORD PTR [rax+rax*1+0x0]
  40eb0e:	xchg   ax,ax
  40eb10:	lea    r8,[rdx+0x1]
  40eb14:	mov    rax,rdx
  40eb17:	lock cmpxchg QWORD PTR [rcx],r8
  40eb1c:	cmp    rax,rdx
  40eb1f:	je     40eb26 <__swc_fn_7dafa2b1_000008_f7acedb0+0x76>
  40eb21:	mov    rdx,rax
  40eb24:	jmp    40eb10 <__swc_fn_7dafa2b1_000008_f7acedb0+0x60>
  40eb26:	mov    eax,0x1
  40eb2b:	pop    rsi
  40eb2c:	ret
  40eb2d:	add    BYTE PTR [rax],al
	...

000000000040eb30 <__swc_fn_7dafa2b1_000011_24a20786>:
  40eb30:	push   rbx
  40eb31:	push   rsi
  40eb32:	push   rdi
  40eb33:	push   r12
  40eb35:	sub    rsp,0x18
  40eb39:	mov    rbx,rcx
  40eb3c:	mov    rsi,rcx
  40eb3f:	and    rsi,0xffffffffffc00000
  40eb46:	movzx  eax,BYTE PTR [rbx+0x3a]
  40eb4a:	mov    ecx,DWORD PTR [rsi+0x28]
  40eb4d:	shrx   eax,eax,ecx
  40eb52:	lea    rdi,[rsp+0x8]
  40eb57:	mov    DWORD PTR [rsp+0x8],eax
  40eb5b:	mov    rcx,rsi
  40eb5e:	mov    rax,rdi
  40eb61:	mov    edx,DWORD PTR [rax]
  40eb63:	call   40a8e0 <__swc_fn_7dafa2b1_000016_9dea5065>
  40eb68:	mov    r12,rax
  40eb6b:	mov    rcx,rsi
  40eb6e:	mov    edx,DWORD PTR [rdi]
  40eb70:	call   40ec60 <__swc_fn_7dafa2b1_000017_9afb7cfb>
  40eb75:	mov    rcx,r12
  40eb78:	mov    edx,DWORD PTR [rbx+0x3c]
  40eb7b:	add    rcx,rdx
  40eb7e:	cmp    rcx,rax
  40eb81:	jb     40eb8f <__swc_fn_7dafa2b1_000011_24a20786+0x5f>
  40eb83:	xor    eax,eax
  40eb85:	add    rsp,0x18
  40eb89:	pop    r12
  40eb8b:	pop    rdi
  40eb8c:	pop    rsi
  40eb8d:	pop    rbx
  40eb8e:	ret
  40eb8f:	mov    rdx,QWORD PTR [rbx+0x20]
  40eb93:	mov    r8d,DWORD PTR [rbx+0x2c]
  40eb97:	add    rdx,r8
  40eb9a:	lea    rsi,[rdx+0xffff]
  40eba1:	and    rsi,0xffffffffffff0000
  40eba8:	cmp    rax,rsi
  40ebab:	cmovbe rsi,rax
  40ebaf:	mov    rax,rsi
  40ebb2:	sub    rax,rcx
  40ebb5:	mov    rdx,rax
  40ebb8:	call   40eab0 <__swc_fn_7dafa2b1_000008_f7acedb0>
  40ebbd:	test   al,al
  40ebbf:	jne    40ebcd <__swc_fn_7dafa2b1_000011_24a20786+0x9d>
  40ebc1:	xor    eax,eax
  40ebc3:	add    rsp,0x18
  40ebc7:	pop    r12
  40ebc9:	pop    rdi
  40ebca:	pop    rsi
  40ebcb:	pop    rbx
  40ebcc:	ret
  40ebcd:	sub    rsi,r12
  40ebd0:	mov    DWORD PTR [rbx+0x3c],esi
  40ebd3:	mov    ecx,DWORD PTR [rbx+0x2c]
  40ebd6:	mov    rax,rsi
  40ebd9:	xor    edx,edx
  40ebdb:	div    rcx
  40ebde:	imul   rax,rcx
  40ebe2:	add    r12,rax
  40ebe5:	mov    QWORD PTR [rbx+0x18],r12
  40ebe9:	mov    eax,0x1
  40ebee:	add    rsp,0x18
  40ebf2:	pop    r12
  40ebf4:	pop    rdi
  40ebf5:	pop    rsi
  40ebf6:	pop    rbx
  40ebf7:	ret
	...

000000000040ec00 <__swc_fn_7dafa2b1_000014_e4b0ddfc>:
  40ec00:	sub    rsp,0x8
  40ec04:	mov    rdx,rcx
  40ec07:	lea    r9,[rcx+0x60]
  40ec0b:	mov    rax,QWORD PTR [r9]
  40ec0e:	test   rax,rax
  40ec11:	jne    40ec18 <__swc_fn_7dafa2b1_000014_e4b0ddfc+0x18>
  40ec13:	add    rsp,0x8
  40ec17:	ret
  40ec18:	mov    rcx,rdx
  40ec1b:	call   4075d0 <__swc_fn_7dafa2b1_000012_c3647f66>
  40ec20:	xor    eax,eax
  40ec22:	xchg   QWORD PTR [r9],rax
  40ec25:	mov    r8,rax
  40ec28:	mov    rcx,rdx
  40ec2b:	call   40a8d0 <__swc_fn_7dafa2b1_000013_861b8b62>
  40ec30:	xor    eax,eax
  40ec32:	test   r8,r8
  40ec35:	je     40ec56 <__swc_fn_7dafa2b1_000014_e4b0ddfc+0x56>
  40ec37:	nop    WORD PTR [rax+rax*1+0x0]
  40ec40:	mov    rcx,QWORD PTR [r8]
  40ec43:	mov    r9,QWORD PTR [rdx]
  40ec46:	mov    QWORD PTR [r8],r9
  40ec49:	mov    QWORD PTR [rdx],r8
  40ec4c:	mov    r8,rcx
  40ec4f:	inc    eax
  40ec51:	test   rcx,rcx
  40ec54:	jne    40ec40 <__swc_fn_7dafa2b1_000014_e4b0ddfc+0x40>
  40ec56:	sub    DWORD PTR [rdx+0x28],eax
  40ec59:	add    rsp,0x8
  40ec5d:	ret
	...

000000000040ec60 <__swc_fn_7dafa2b1_000017_9afb7cfb>:
  40ec60:	lea    eax,[rdx+0x1]
  40ec63:	mov    edx,DWORD PTR [rcx+0x28]
  40ec66:	shlx   eax,eax,edx
  40ec6b:	shl    rax,0x10
  40ec6f:	add    rax,rcx
  40ec72:	ret
	...

000000000040ec80 <__swc_fn_7dafa2b1_000020_adca76cf>:
  40ec80:	push   rbx
  40ec81:	push   rsi
  40ec82:	push   rdi
  40ec83:	push   r12
  40ec85:	push   r13
  40ec87:	push   r14
  40ec89:	push   r15
  40ec8b:	sub    rsp,0x30
  40ec8f:	mov    rbx,rcx
  40ec92:	lea    rsi,[rcx+0x48]
  40ec96:	mov    QWORD PTR [rsp+0x18],rsi
  40ec9b:	mov    rax,QWORD PTR [rsi]
  40ec9e:	mov    rdi,rax
  40eca1:	lea    r12,[rsp+0x8]
  40eca6:	lea    r13,[rcx+0x40]
  40ecaa:	nop    WORD PTR [rax+rax*1+0x0]
  40ecb0:	test   rdi,rdi
  40ecb3:	je     40edf3 <__swc_fn_7dafa2b1_000020_adca76cf+0x173>
  40ecb9:	xor    eax,eax
  40ecbb:	tzcnt  rax,rdi
  40ecc0:	mov    DWORD PTR [rsp+0x8],eax
  40ecc4:	mov    r14d,0x1
  40ecca:	mov    ecx,eax
  40eccc:	shl    r14,cl
  40eccf:	andn   rdi,r14,rdi
  40ecd4:	mov    rcx,QWORD PTR [r13+0x0]
  40ecd8:	test   rcx,r14
  40ecdb:	jne    40ecb0 <__swc_fn_7dafa2b1_000020_adca76cf+0x30>
  40ecdd:	mov    rdx,rcx
  40ece0:	or     rdx,r14
  40ece3:	mov    rax,rcx
  40ece6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  40ecec:	cmp    rax,rcx
  40ecef:	je     40ecf9 <__swc_fn_7dafa2b1_000020_adca76cf+0x79>
  40ecf1:	mov    rax,QWORD PTR [rsi]
  40ecf4:	mov    rdi,rax
  40ecf7:	jmp    40ecb0 <__swc_fn_7dafa2b1_000020_adca76cf+0x30>
  40ecf9:	mov    rcx,rbx
  40ecfc:	mov    rdx,r14
  40ecff:	call   40aa40 <__swc_fn_7dafa2b1_000022_fd2b165c>
  40ed04:	test   al,al
  40ed06:	je     40edde <__swc_fn_7dafa2b1_000020_adca76cf+0x15e>
  40ed0c:	mov    eax,DWORD PTR [r12]
  40ed10:	shl    rax,0x4
  40ed14:	lea    r15,[rbx+rax*8+0x80]
  40ed1c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  40ed24:	lea    rcx,[rip+0x14335]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  40ed2b:	mov    rdx,QWORD PTR [rip+0x1432e]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  40ed32:	cs nop WORD PTR [rax+rax*1+0x0]
  40ed3c:	nop    DWORD PTR [rax+0x0]
  40ed40:	mov    r8,rdx
  40ed43:	sub    r8,rsi
  40ed46:	mov    rax,rdx
  40ed49:	lock cmpxchg QWORD PTR [rcx],r8
  40ed4e:	cmp    rax,rdx
  40ed51:	je     40ed58 <__swc_fn_7dafa2b1_000020_adca76cf+0xd8>
  40ed53:	mov    rdx,rax
  40ed56:	jmp    40ed40 <__swc_fn_7dafa2b1_000020_adca76cf+0xc0>
  40ed58:	mov    rcx,rbx
  40ed5b:	mov    rax,r12
  40ed5e:	mov    edx,DWORD PTR [rax]
  40ed60:	call   40a8e0 <__swc_fn_7dafa2b1_000016_9dea5065>
  40ed65:	test   rsi,rsi
  40ed68:	je     40edd6 <__swc_fn_7dafa2b1_000020_adca76cf+0x156>
  40ed6e:	mov    rcx,rax
  40ed71:	mov    rdx,rsi
  40ed74:	call   409840 <__swc_fn_7dafa2b1_000117_e9fc0224>
  40ed79:	lea    rcx,[rip+0x142d0]        # 423050 <__swc_bss_base_7dafa2b1+0x10>
  40ed80:	mov    rdx,QWORD PTR [rip+0x142c9]        # 423050 <__swc_bss_base_7dafa2b1+0x10>
  40ed87:	nop    WORD PTR [rax+rax*1+0x0]
  40ed90:	mov    r8,rdx
  40ed93:	sub    r8,rsi
  40ed96:	mov    rax,rdx
  40ed99:	lock cmpxchg QWORD PTR [rcx],r8
  40ed9e:	cmp    rax,rdx
  40eda1:	je     40eda8 <__swc_fn_7dafa2b1_000020_adca76cf+0x128>
  40eda3:	mov    rdx,rax
  40eda6:	jmp    40ed90 <__swc_fn_7dafa2b1_000020_adca76cf+0x110>
  40eda8:	lea    rcx,[rip+0x142b9]        # 423068 <__swc_bss_base_7dafa2b1+0x28>
  40edaf:	mov    rdx,QWORD PTR [rip+0x142b2]        # 423068 <__swc_bss_base_7dafa2b1+0x28>
  40edb6:	cs nop WORD PTR [rax+rax*1+0x0]
  40edc0:	lea    r8,[rdx+0x1]
  40edc4:	mov    rax,rdx
  40edc7:	lock cmpxchg QWORD PTR [rcx],r8
  40edcc:	cmp    rax,rdx
  40edcf:	je     40edd6 <__swc_fn_7dafa2b1_000020_adca76cf+0x156>
  40edd1:	mov    rdx,rax
  40edd4:	jmp    40edc0 <__swc_fn_7dafa2b1_000020_adca76cf+0x140>
  40edd6:	mov    DWORD PTR [r15+0x3c],0x0
  40edde:	mov    rcx,rbx
  40ede1:	mov    rdx,r14
  40ede4:	call   40ee10 <__swc_fn_7dafa2b1_000023_c8f5f27c>
  40ede9:	mov    rsi,QWORD PTR [rsp+0x18]
  40edee:	jmp    40ecb0 <__swc_fn_7dafa2b1_000020_adca76cf+0x30>
  40edf3:	add    rsp,0x30
  40edf7:	pop    r15
  40edf9:	pop    r14
  40edfb:	pop    r13
  40edfd:	pop    r12
  40edff:	pop    rdi
  40ee00:	pop    rsi
  40ee01:	pop    rbx
  40ee02:	ret
	...

000000000040ee10 <__swc_fn_7dafa2b1_000023_c8f5f27c>:
  40ee10:	mov    r8,QWORD PTR [rcx+0x40]
  40ee14:	cs nop WORD PTR [rax+rax*1+0x0]
  40ee1e:	xchg   ax,ax
  40ee20:	mov    rax,rdx
  40ee23:	not    rax
  40ee26:	mov    r9,r8
  40ee29:	and    r9,rax
  40ee2c:	mov    rax,r8
  40ee2f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  40ee35:	cmp    rax,r8
  40ee38:	jne    40ee3b <__swc_fn_7dafa2b1_000023_c8f5f27c+0x2b>
  40ee3a:	ret
  40ee3b:	mov    r8,rax
  40ee3e:	jmp    40ee20 <__swc_fn_7dafa2b1_000023_c8f5f27c+0x10>

000000000040ee40 <__swc_fn_7dafa2b1_000026_aa910677>:
  40ee40:	push   rsi
  40ee41:	push   rdi
  40ee42:	sub    rsp,0x8
  40ee46:	mov    rsi,rcx
  40ee49:	call   40ec80 <__swc_fn_7dafa2b1_000020_adca76cf>
  40ee4e:	lea    rdi,[rip+0x143a3]        # 4231f8 <__swc_bss_base_7dafa2b1+0x1b8>
  40ee55:	mov    rcx,rdi
  40ee58:	call   4110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>
  40ee5d:	mov    QWORD PTR [rsi+0x8],0x0
  40ee65:	mov    QWORD PTR [rsi+0x18],0x0
  40ee6d:	mov    rax,QWORD PTR [rip+0x1438c]        # 423200 <__swc_bss_base_7dafa2b1+0x1c0>
  40ee74:	mov    QWORD PTR [rsi+0x10],rax
  40ee78:	mov    QWORD PTR [rip+0x14381],rsi        # 423200 <__swc_bss_base_7dafa2b1+0x1c0>
  40ee7f:	mov    rcx,rdi
  40ee82:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40ee87:	add    rsp,0x8
  40ee8b:	pop    rdi
  40ee8c:	pop    rsi
  40ee8d:	ret
	...

000000000040ee90 <__swc_fn_7dafa2b1_000029_9798fb47>:
  40ee90:	vxorps xmm0,xmm0,xmm0
  40ee94:	vmovups XMMWORD PTR [rcx],xmm0
  40ee98:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40ee9d:	mov    QWORD PTR [rcx+0x20],0x0
  40eea5:	ret
	...

000000000040eeb0 <__swc_fn_7dafa2b1_000032_9798fb47>:
  40eeb0:	vxorps xmm0,xmm0,xmm0
  40eeb4:	vmovups XMMWORD PTR [rcx],xmm0
  40eeb8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40eebd:	mov    QWORD PTR [rcx+0x20],0x0
  40eec5:	ret
	...

000000000040eed0 <__swc_fn_7dafa2b1_000035_9128bcf9>:
  40eed0:	push   r12
  40eed2:	mov    r12,rdi
  40eed5:	test   rdi,rdi
  40eed8:	jne    40eedd <__swc_fn_7dafa2b1_000035_9128bcf9+0xd>
  40eeda:	pop    r12
  40eedc:	ret
  40eedd:	lea    rax,[rip+0x1211c]        # 421000 <__swc_data_base_7dafa2b1>
  40eee4:	mov    rax,QWORD PTR [rax]
  40eee7:	cmp    rax,0xffffffffffffffff
  40eeeb:	je     40eefa <__swc_fn_7dafa2b1_000035_9128bcf9+0x2a>
  40eeed:	mov    eax,eax
  40eeef:	mov    edi,eax
  40eef1:	xor    eax,eax
  40eef3:	call   407000 <pthread_getspecific@plt>
  40eef8:	jmp    40eefc <__swc_fn_7dafa2b1_000035_9128bcf9+0x2c>
  40eefa:	xor    eax,eax
  40eefc:	cmp    rax,r12
  40eeff:	jne    40ef08 <__swc_fn_7dafa2b1_000035_9128bcf9+0x38>
  40ef01:	xor    ecx,ecx
  40ef03:	call   40ac00 <__swc_fn_7dafa2b1_000037_92d9bbff>
  40ef08:	mov    rdx,QWORD PTR [r12]
  40ef0c:	test   rdx,rdx
  40ef0f:	je     40ef28 <__swc_fn_7dafa2b1_000035_9128bcf9+0x58>
  40ef11:	mov    rcx,rdx
  40ef14:	call   40ef50 <__swc_fn_7dafa2b1_000041_eb6108f2>
  40ef19:	test   al,al
  40ef1b:	je     40ef28 <__swc_fn_7dafa2b1_000035_9128bcf9+0x58>
  40ef1d:	mov    rcx,rdx
  40ef20:	mov    rdx,r12
  40ef23:	call   40f040 <__swc_fn_7dafa2b1_000047_b30433d0>
  40ef28:	pop    r12
  40ef2a:	ret
  40ef2b:	add    BYTE PTR [rax],al
  40ef2d:	add    BYTE PTR [rax],al
	...

000000000040ef30 <__swc_fn_7dafa2b1_000038_28d0e998>:
  40ef30:	push   rsi
  40ef31:	mov    rsi,rcx
  40ef34:	call   407a80 <__swc_fn_7dafa2b1_000036_cd1a4e8c>
  40ef39:	mov    rcx,rax
  40ef3c:	mov    rdx,rsi
  40ef3f:	call   410f20 <__swc_fn_7dafa2b1_000134_ae5891af>
  40ef44:	mov    rcx,rsi
  40ef47:	call   40ac00 <__swc_fn_7dafa2b1_000037_92d9bbff>
  40ef4c:	pop    rsi
  40ef4d:	ret
	...

000000000040ef50 <__swc_fn_7dafa2b1_000041_eb6108f2>:
  40ef50:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40ef5a:	sete   al
  40ef5d:	ret
	...

000000000040ef60 <__swc_fn_7dafa2b1_000044_d3c2ab54>:
  40ef60:	push   rsi
  40ef61:	test   rdx,rdx
  40ef64:	jne    40ef68 <__swc_fn_7dafa2b1_000044_d3c2ab54+0x8>
  40ef66:	pop    rsi
  40ef67:	ret
  40ef68:	mov    rax,r8
  40ef6b:	mov    ecx,0x1000
  40ef70:	test   ecx,ecx
  40ef72:	mov    r10d,0x8
  40ef78:	cmove  ecx,r10d
  40ef7c:	dec    rcx
  40ef7f:	mov    r10,0xffffffffffffffff
  40ef86:	sub    r10,rcx
  40ef89:	cmp    r8,r10
  40ef8c:	jbe    40ef92 <__swc_fn_7dafa2b1_000044_d3c2ab54+0x32>
  40ef8e:	xor    eax,eax
  40ef90:	jmp    40ef9a <__swc_fn_7dafa2b1_000044_d3c2ab54+0x3a>
  40ef92:	add    rax,rcx
  40ef95:	andn   rax,rcx,rax
  40ef9a:	mov    ecx,0x1000
  40ef9f:	test   ecx,ecx
  40efa1:	mov    r8d,0x8
  40efa7:	cmove  ecx,r8d
  40efab:	dec    rcx
  40efae:	mov    r8,0xffffffffffffffff
  40efb5:	sub    r8,rcx
  40efb8:	cmp    r9,r8
  40efbb:	jbe    40efc1 <__swc_fn_7dafa2b1_000044_d3c2ab54+0x61>
  40efbd:	xor    esi,esi
  40efbf:	jmp    40efcc <__swc_fn_7dafa2b1_000044_d3c2ab54+0x6c>
  40efc1:	add    r9,rcx
  40efc4:	andn   r9,rcx,r9
  40efc9:	mov    rsi,r9
  40efcc:	mov    rcx,rdx
  40efcf:	mov    rdx,rax
  40efd2:	mov    r8,rsi
  40efd5:	call   410b20 <__swc_fn_7dafa2b1_000119_5208f471>
  40efda:	lea    rcx,[rip+0x1406f]        # 423050 <__swc_bss_base_7dafa2b1+0x10>
  40efe1:	mov    rdx,QWORD PTR [rip+0x14068]        # 423050 <__swc_bss_base_7dafa2b1+0x10>
  40efe8:	nop    DWORD PTR [rax+rax*1+0x0]
  40eff0:	mov    r8,rdx
  40eff3:	sub    r8,rsi
  40eff6:	mov    rax,rdx
  40eff9:	lock cmpxchg QWORD PTR [rcx],r8
  40effe:	cmp    rax,rdx
  40f001:	je     40f008 <__swc_fn_7dafa2b1_000044_d3c2ab54+0xa8>
  40f003:	mov    rdx,rax
  40f006:	jmp    40eff0 <__swc_fn_7dafa2b1_000044_d3c2ab54+0x90>
  40f008:	lea    rcx,[rip+0x14059]        # 423068 <__swc_bss_base_7dafa2b1+0x28>
  40f00f:	mov    rdx,QWORD PTR [rip+0x14052]        # 423068 <__swc_bss_base_7dafa2b1+0x28>
  40f016:	cs nop WORD PTR [rax+rax*1+0x0]
  40f020:	lea    r8,[rdx+0x1]
  40f024:	mov    rax,rdx
  40f027:	lock cmpxchg QWORD PTR [rcx],r8
  40f02c:	cmp    rax,rdx
  40f02f:	je     40f036 <__swc_fn_7dafa2b1_000044_d3c2ab54+0xd6>
  40f031:	mov    rdx,rax
  40f034:	jmp    40f020 <__swc_fn_7dafa2b1_000044_d3c2ab54+0xc0>
  40f036:	pop    rsi
  40f037:	ret
	...

000000000040f040 <__swc_fn_7dafa2b1_000047_b30433d0>:
  40f040:	push   rbx
  40f041:	push   rsi
  40f042:	push   rdi
  40f043:	push   r12
  40f045:	push   r13
  40f047:	push   r14
  40f049:	push   r15
  40f04b:	sub    rsp,0x30
  40f04f:	mov    rbx,rdx
  40f052:	mov    QWORD PTR [rsp+0x18],rdx
  40f057:	mov    rsi,rcx
  40f05a:	mov    eax,0x1
  40f05f:	xchg   DWORD PTR [rbx+0x20],eax
  40f062:	test   eax,eax
  40f064:	je     40f076 <__swc_fn_7dafa2b1_000047_b30433d0+0x36>
  40f066:	add    rsp,0x30
  40f06a:	pop    r15
  40f06c:	pop    r14
  40f06e:	pop    r13
  40f070:	pop    r12
  40f072:	pop    rdi
  40f073:	pop    rsi
  40f074:	pop    rbx
  40f075:	ret
  40f076:	mov    rcx,rsi
  40f079:	mov    rdx,rbx
  40f07c:	mov    r8,0xffffffffffffffff
  40f083:	call   40b1d0 <__swc_fn_7dafa2b1_000064_dea90857>
  40f088:	lea    rdi,[rsi+0x10]
  40f08c:	mov    QWORD PTR [rsp+0x20],rdi
  40f091:	mov    rcx,rdi
  40f094:	call   4110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>
  40f099:	xor    r12d,r12d
  40f09c:	cs nop WORD PTR [rax+rax*1+0x0]
  40f0a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f0b0:	mov    eax,r12d
  40f0b3:	lea    r13,[rax+rax*4]
  40f0b7:	lea    r13,[rbx+r13*8+0x28]
  40f0bc:	mov    rax,QWORD PTR [r13+0x8]
  40f0c0:	mov    QWORD PTR [rsp+0x8],rax
  40f0c5:	mov    rax,QWORD PTR [r13+0x18]
  40f0c9:	mov    QWORD PTR [rsp+0x10],rax
  40f0ce:	mov    r14d,0x2
  40f0d4:	xor    r15d,r15d
  40f0d7:	test   r14,r14
  40f0da:	je     40f157 <__swc_fn_7dafa2b1_000047_b30433d0+0x117>
  40f0e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  40f0e5:	mov    rdi,rax
  40f0e8:	test   rdi,rdi
  40f0eb:	je     40f149 <__swc_fn_7dafa2b1_000047_b30433d0+0x109>
  40f0ed:	nop    DWORD PTR [rax]
  40f0f0:	mov    rbx,QWORD PTR [rdi+0x48]
  40f0f4:	mov    DWORD PTR [rdi+0x6c],0x0
  40f0fb:	mov    rcx,rdi
  40f0fe:	call   40ec00 <__swc_fn_7dafa2b1_000014_e4b0ddfc>
  40f103:	cmp    DWORD PTR [rdi+0x28],0x0
  40f107:	jne    40f120 <__swc_fn_7dafa2b1_000047_b30433d0+0xe0>
  40f109:	mov    rax,rdi
  40f10c:	and    rax,0xffffffffffc00000
  40f113:	mov    rcx,rax
  40f116:	mov    rdx,rdi
  40f119:	call   40a900 <__swc_fn_7dafa2b1_000019_283e2b5e>
  40f11e:	jmp    40f141 <__swc_fn_7dafa2b1_000047_b30433d0+0x101>
  40f120:	mov    QWORD PTR [rdi+0x40],0x0
  40f128:	rex mov BYTE PTR [rdi+0x3b],0x2
  40f12d:	mov    QWORD PTR [rdi+0x50],0x0
  40f135:	mov    rax,QWORD PTR [rsi+0x28]
  40f139:	mov    QWORD PTR [rdi+0x48],rax
  40f13d:	mov    QWORD PTR [rsi+0x28],rdi
  40f141:	mov    rdi,rbx
  40f144:	test   rbx,rbx
  40f147:	jne    40f0f0 <__swc_fn_7dafa2b1_000047_b30433d0+0xb0>
  40f149:	add    r15,0x1
  40f14d:	sub    r14,0x1
  40f151:	jne    40f0e0 <__swc_fn_7dafa2b1_000047_b30433d0+0xa0>
  40f157:	vxorps xmm0,xmm0,xmm0
  40f15b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  40f161:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40f167:	mov    QWORD PTR [r13+0x20],0x0
  40f16f:	add    r12,0x1
  40f173:	cmp    r12,0x2d
  40f177:	mov    rbx,QWORD PTR [rsp+0x18]
  40f17c:	jb     40f0b0 <__swc_fn_7dafa2b1_000047_b30433d0+0x70>
  40f182:	mov    rcx,rsi
  40f185:	mov    rbx,QWORD PTR [rsp+0x18]
  40f18a:	mov    rdx,rbx
  40f18d:	mov    rdi,QWORD PTR [rsp+0x20]
  40f192:	call   407c40 <__swc_fn_7dafa2b1_000048_6e7a8d58>
  40f197:	mov    rcx,rdi
  40f19a:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40f19f:	mov    rcx,rsi
  40f1a2:	mov    rdx,rbx
  40f1a5:	mov    r8d,0x9b8
  40f1ab:	mov    r9d,0x9b8
  40f1b1:	call   40ef60 <__swc_fn_7dafa2b1_000044_d3c2ab54>
  40f1b6:	add    rsp,0x30
  40f1ba:	pop    r15
  40f1bc:	pop    r14
  40f1be:	pop    r13
  40f1c0:	pop    r12
  40f1c2:	pop    rdi
  40f1c3:	pop    rsi
  40f1c4:	pop    rbx
  40f1c5:	ret
	...

000000000040f1e0 <__swc_fn_7dafa2b1_000050_ad48ec88>:
  40f1e0:	push   rbx
  40f1e1:	push   rsi
  40f1e2:	push   rdi
  40f1e3:	push   r12
  40f1e5:	push   r13
  40f1e7:	push   r14
  40f1e9:	push   r15
  40f1eb:	sub    rsp,0x30
  40f1ef:	mov    ebx,r8d
  40f1f2:	mov    rsi,rcx
  40f1f5:	mov    rdi,rdx
  40f1f8:	test   r8d,r8d
  40f1fb:	jne    40f204 <__swc_fn_7dafa2b1_000050_ad48ec88+0x24>
  40f1fd:	mov    eax,0x8
  40f202:	jmp    40f22b <__swc_fn_7dafa2b1_000050_ad48ec88+0x4b>
  40f204:	cmp    ebx,0x8
  40f207:	ja     40f212 <__swc_fn_7dafa2b1_000050_ad48ec88+0x32>
  40f209:	mov    rax,rbx
  40f20c:	shl    rax,0x4
  40f210:	jmp    40f22b <__swc_fn_7dafa2b1_000050_ad48ec88+0x4b>
  40f212:	lea    eax,[rbx-0x9]
  40f215:	mov    ecx,eax
  40f217:	shr    ecx,0x2
  40f21a:	and    eax,0x3
  40f21d:	lea    ecx,[rcx+0x7]
  40f220:	lea    ecx,[rcx-0x2]
  40f223:	lea    eax,[rax+0x5]
  40f226:	shlx   rax,rax,rcx
  40f22b:	lea    r12,[rsp+0x8]
  40f230:	mov    DWORD PTR [rsp+0x8],eax
  40f234:	lea    r13,[rsp+0xc]
  40f239:	mov    QWORD PTR [rsp+0x18],r13
  40f23e:	xor    eax,eax
  40f240:	cmp    ebx,0x21
  40f243:	setae  al
  40f246:	lea    eax,[rax+rax*2]
  40f249:	mov    DWORD PTR [rsp+0xc],eax
  40f24d:	lea    r14,[rsi+0x10]
  40f251:	mov    rcx,r14
  40f254:	call   4110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>
  40f259:	xor    eax,eax
  40f25b:	mov    rcx,QWORD PTR [rsi+0x28]
  40f25f:	mov    r15,rcx
  40f262:	test   r15,r15
  40f265:	je     40f316 <__swc_fn_7dafa2b1_000050_ad48ec88+0x136>
  40f26b:	cs nop WORD PTR [rax+rax*1+0x0]
  40f275:	cs nop WORD PTR [rax+rax*1+0x0]
  40f27f:	nop
  40f280:	mov    rcx,QWORD PTR [r15+0x48]
  40f284:	movzx  edx,BYTE PTR [r15+0x39]
  40f289:	cmp    edx,ebx
  40f28b:	jne    40f307 <__swc_fn_7dafa2b1_000050_ad48ec88+0x127>
  40f28d:	test   rax,rax
  40f290:	jne    40f298 <__swc_fn_7dafa2b1_000050_ad48ec88+0xb8>
  40f292:	mov    QWORD PTR [rsi+0x28],rcx
  40f296:	jmp    40f29c <__swc_fn_7dafa2b1_000050_ad48ec88+0xbc>
  40f298:	mov    QWORD PTR [rax+0x48],rcx
  40f29c:	vxorps xmm0,xmm0,xmm0
  40f2a0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  40f2a6:	mov    BYTE PTR [r15+0x3b],0x1
  40f2ab:	mov    QWORD PTR [r15+0x40],rdi
  40f2af:	mov    rcx,r15
  40f2b2:	call   40ec00 <__swc_fn_7dafa2b1_000014_e4b0ddfc>
  40f2b7:	movzx  eax,BYTE PTR [r15+0x39]
  40f2bc:	lea    rax,[rax+rax*4]
  40f2c0:	lea    rax,[rdi+rax*8+0x28]
  40f2c5:	mov    rcx,QWORD PTR [rax+0x10]
  40f2c9:	mov    QWORD PTR [r15+0x50],rcx
  40f2cd:	mov    QWORD PTR [r15+0x48],0x0
  40f2d5:	mov    rcx,QWORD PTR [rax+0x10]
  40f2d9:	test   rcx,rcx
  40f2dc:	je     40f2e4 <__swc_fn_7dafa2b1_000050_ad48ec88+0x104>
  40f2de:	mov    QWORD PTR [rcx+0x48],r15
  40f2e2:	jmp    40f2e8 <__swc_fn_7dafa2b1_000050_ad48ec88+0x108>
  40f2e4:	mov    QWORD PTR [rax+0x8],r15
  40f2e8:	mov    QWORD PTR [rax+0x10],r15
  40f2ec:	mov    rcx,r14
  40f2ef:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40f2f4:	mov    rax,r15
  40f2f7:	add    rsp,0x30
  40f2fb:	pop    r15
  40f2fd:	pop    r14
  40f2ff:	pop    r13
  40f301:	pop    r12
  40f303:	pop    rdi
  40f304:	pop    rsi
  40f305:	pop    rbx
  40f306:	ret
  40f307:	mov    rax,r15
  40f30a:	mov    r15,rcx
  40f30d:	test   rcx,rcx
  40f310:	jne    40f280 <__swc_fn_7dafa2b1_000050_ad48ec88+0xa0>
  40f316:	mov    rax,QWORD PTR [rsi+0x18]
  40f31a:	mov    r15,rax
  40f31d:	test   r15,r15
  40f320:	je     40f3b6 <__swc_fn_7dafa2b1_000050_ad48ec88+0x1d6>
  40f326:	cs nop WORD PTR [rax+rax*1+0x0]
  40f330:	mov    eax,DWORD PTR [rsp+0xc]
  40f334:	cmp    DWORD PTR [r15+0x28],eax
  40f338:	jne    40f3a6 <__swc_fn_7dafa2b1_000050_ad48ec88+0x1c6>
  40f33a:	mov    rcx,r15
  40f33d:	mov    edx,ebx
  40f33f:	mov    rax,r12
  40f342:	mov    r8d,DWORD PTR [rax]
  40f345:	call   407680 <__swc_fn_7dafa2b1_000018_efc44797>
  40f34a:	mov    r13,rax
  40f34d:	test   rax,rax
  40f350:	je     40f3a6 <__swc_fn_7dafa2b1_000050_ad48ec88+0x1c6>
  40f352:	mov    QWORD PTR [r13+0x40],rdi
  40f356:	movzx  eax,BYTE PTR [r13+0x39]
  40f35b:	lea    rax,[rax+rax*4]
  40f35f:	lea    rax,[rdi+rax*8+0x28]
  40f364:	mov    rcx,QWORD PTR [rax+0x10]
  40f368:	mov    QWORD PTR [r13+0x50],rcx
  40f36c:	mov    QWORD PTR [r13+0x48],0x0
  40f374:	mov    rcx,QWORD PTR [rax+0x10]
  40f378:	test   rcx,rcx
  40f37b:	je     40f383 <__swc_fn_7dafa2b1_000050_ad48ec88+0x1a3>
  40f37d:	mov    QWORD PTR [rcx+0x48],r13
  40f381:	jmp    40f387 <__swc_fn_7dafa2b1_000050_ad48ec88+0x1a7>
  40f383:	mov    QWORD PTR [rax+0x8],r13
  40f387:	mov    QWORD PTR [rax+0x10],r13
  40f38b:	mov    rcx,r14
  40f38e:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40f393:	mov    rax,r13
  40f396:	add    rsp,0x30
  40f39a:	pop    r15
  40f39c:	pop    r14
  40f39e:	pop    r13
  40f3a0:	pop    r12
  40f3a2:	pop    rdi
  40f3a3:	pop    rsi
  40f3a4:	pop    rbx
  40f3a5:	ret
  40f3a6:	mov    rax,QWORD PTR [r15+0x10]
  40f3aa:	mov    r15,rax
  40f3ad:	test   rax,rax
  40f3b0:	jne    40f330 <__swc_fn_7dafa2b1_000050_ad48ec88+0x150>
  40f3b6:	mov    rcx,rsi
  40f3b9:	mov    r13,QWORD PTR [rsp+0x18]
  40f3be:	mov    edx,DWORD PTR [r13+0x0]
  40f3c2:	call   40aa80 <__swc_fn_7dafa2b1_000025_2685aade>
  40f3c7:	mov    r13,rax
  40f3ca:	test   rax,rax
  40f3cd:	jne    40f3e9 <__swc_fn_7dafa2b1_000050_ad48ec88+0x209>
  40f3cf:	mov    rcx,r14
  40f3d2:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40f3d7:	xor    eax,eax
  40f3d9:	add    rsp,0x30
  40f3dd:	pop    r15
  40f3df:	pop    r14
  40f3e1:	pop    r13
  40f3e3:	pop    r12
  40f3e5:	pop    rdi
  40f3e6:	pop    rsi
  40f3e7:	pop    rbx
  40f3e8:	ret
  40f3e9:	mov    rcx,r13
  40f3ec:	mov    edx,ebx
  40f3ee:	mov    r8d,DWORD PTR [r12]
  40f3f2:	call   407680 <__swc_fn_7dafa2b1_000018_efc44797>
  40f3f7:	mov    rbx,rax
  40f3fa:	test   rax,rax
  40f3fd:	jne    40f421 <__swc_fn_7dafa2b1_000050_ad48ec88+0x241>
  40f3ff:	mov    rcx,r13
  40f402:	call   40ee40 <__swc_fn_7dafa2b1_000026_aa910677>
  40f407:	mov    rcx,r14
  40f40a:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40f40f:	xor    eax,eax
  40f411:	add    rsp,0x30
  40f415:	pop    r15
  40f417:	pop    r14
  40f419:	pop    r13
  40f41b:	pop    r12
  40f41d:	pop    rdi
  40f41e:	pop    rsi
  40f41f:	pop    rbx
  40f420:	ret
  40f421:	mov    rax,QWORD PTR [rsi+0x18]
  40f425:	mov    QWORD PTR [r13+0x10],rax
  40f429:	mov    rax,QWORD PTR [rsi+0x18]
  40f42d:	test   rax,rax
  40f430:	je     40f436 <__swc_fn_7dafa2b1_000050_ad48ec88+0x256>
  40f432:	mov    QWORD PTR [rax+0x18],r13
  40f436:	mov    QWORD PTR [rsi+0x18],r13
  40f43a:	mov    QWORD PTR [rbx+0x40],rdi
  40f43e:	movzx  eax,BYTE PTR [rbx+0x39]
  40f442:	lea    rax,[rax+rax*4]
  40f446:	lea    rax,[rdi+rax*8+0x28]
  40f44b:	mov    rcx,QWORD PTR [rax+0x10]
  40f44f:	mov    QWORD PTR [rbx+0x50],rcx
  40f453:	mov    QWORD PTR [rbx+0x48],0x0
  40f45b:	mov    rcx,QWORD PTR [rax+0x10]
  40f45f:	test   rcx,rcx
  40f462:	je     40f46a <__swc_fn_7dafa2b1_000050_ad48ec88+0x28a>
  40f464:	mov    QWORD PTR [rcx+0x48],rbx
  40f468:	jmp    40f46e <__swc_fn_7dafa2b1_000050_ad48ec88+0x28e>
  40f46a:	mov    QWORD PTR [rax+0x8],rbx
  40f46e:	mov    QWORD PTR [rax+0x10],rbx
  40f472:	mov    rcx,r14
  40f475:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40f47a:	mov    rax,rbx
  40f47d:	add    rsp,0x30
  40f481:	pop    r15
  40f483:	pop    r14
  40f485:	pop    r13
  40f487:	pop    r12
  40f489:	pop    rdi
  40f48a:	pop    rsi
  40f48b:	pop    rbx
  40f48c:	ret
	...

000000000040f4a0 <__swc_fn_7dafa2b1_000053_d846b172>:
  40f4a0:	push   rsi
  40f4a1:	push   rdi
  40f4a2:	push   r12
  40f4a4:	mov    rsi,rdx
  40f4a7:	mov    rdi,rcx
  40f4aa:	lea    rax,[rcx+0x2a80]
  40f4b1:	mov    rcx,QWORD PTR [rax]
  40f4b4:	test   rcx,rcx
  40f4b7:	jne    40f4be <__swc_fn_7dafa2b1_000053_d846b172+0x1e>
  40f4b9:	pop    r12
  40f4bb:	pop    rdi
  40f4bc:	pop    rsi
  40f4bd:	ret
  40f4be:	xor    ecx,ecx
  40f4c0:	xchg   QWORD PTR [rax],rcx
  40f4c3:	mov    r12,rcx
  40f4c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f4d0:	cs nop WORD PTR [rax+rax*1+0x0]
  40f4da:	nop    WORD PTR [rax+rax*1+0x0]
  40f4e0:	test   r12,r12
  40f4e3:	je     40f57a <__swc_fn_7dafa2b1_000053_d846b172+0xda>
  40f4e9:	mov    r8,r12
  40f4ec:	mov    r12,QWORD PTR [r12+0x78]
  40f4f1:	lea    rcx,[r8+0x70]
  40f4f5:	xor    eax,eax
  40f4f7:	xchg   DWORD PTR [r8+0x70],eax
  40f4fb:	cmp    QWORD PTR [r8+0x40],rsi
  40f4ff:	jne    40f516 <__swc_fn_7dafa2b1_000053_d846b172+0x76>
  40f501:	mov    eax,DWORD PTR [r8+0x6c]
  40f505:	test   eax,eax
  40f507:	je     40f4e0 <__swc_fn_7dafa2b1_000053_d846b172+0x40>
  40f509:	mov    rcx,rdi
  40f50c:	mov    rdx,rsi
  40f50f:	call   40ae30 <__swc_fn_7dafa2b1_000052_e072b516>
  40f514:	jmp    40f4e0 <__swc_fn_7dafa2b1_000053_d846b172+0x40>
  40f516:	mov    rax,QWORD PTR [r8+0x40]
  40f51a:	test   rax,rax
  40f51d:	je     40f4e0 <__swc_fn_7dafa2b1_000053_d846b172+0x40>
  40f51f:	mov    eax,DWORD PTR [r8+0x6c]
  40f523:	test   eax,eax
  40f525:	je     40f4e0 <__swc_fn_7dafa2b1_000053_d846b172+0x40>
  40f527:	mov    r9d,0x1
  40f52d:	xor    eax,eax
  40f52f:	lock cmpxchg DWORD PTR [rcx],r9d
  40f534:	test   eax,eax
  40f536:	jne    40f4e0 <__swc_fn_7dafa2b1_000053_d846b172+0x40>
  40f538:	mov    rax,r8
  40f53b:	and    rax,0xffffffffffc00000
  40f542:	mov    rax,QWORD PTR [rax+0x8]
  40f546:	test   rax,rax
  40f549:	jne    40f551 <__swc_fn_7dafa2b1_000053_d846b172+0xb1>
  40f54b:	xor    eax,eax
  40f54d:	xchg   DWORD PTR [rcx],eax
  40f54f:	jmp    40f4e0 <__swc_fn_7dafa2b1_000053_d846b172+0x40>
  40f551:	lea    rcx,[rax+0x2a80]
  40f558:	mov    rax,QWORD PTR [rcx]
  40f55b:	mov    rdx,rax
  40f55e:	xchg   ax,ax
  40f560:	mov    QWORD PTR [r8+0x78],rdx
  40f564:	mov    rax,rdx
  40f567:	lock cmpxchg QWORD PTR [rcx],r8
  40f56c:	cmp    rax,rdx
  40f56f:	je     40f4e0 <__swc_fn_7dafa2b1_000053_d846b172+0x40>
  40f575:	mov    rdx,rax
  40f578:	jmp    40f560 <__swc_fn_7dafa2b1_000053_d846b172+0xc0>
  40f57a:	pop    r12
  40f57c:	pop    rdi
  40f57d:	pop    rsi
  40f57e:	ret
	...

000000000040f580 <__swc_fn_7dafa2b1_000056_2e3450f7>:
  40f580:	sub    rsp,0x8
  40f584:	mov    r9,r8
  40f587:	movzx  eax,BYTE PTR [r9+0x39]
  40f58c:	lea    rax,[rax+rax*4]
  40f590:	lea    rax,[rdx+rax*8+0x28]
  40f595:	cmp    QWORD PTR [rax],r9
  40f598:	je     40f5a0 <__swc_fn_7dafa2b1_000056_2e3450f7+0x20>
  40f59a:	cmp    QWORD PTR [rax+0x20],r9
  40f59e:	jne    40f5a5 <__swc_fn_7dafa2b1_000056_2e3450f7+0x25>
  40f5a0:	add    rsp,0x8
  40f5a4:	ret
  40f5a5:	cmp    QWORD PTR [rax+0x20],0x0
  40f5aa:	je     40f5b7 <__swc_fn_7dafa2b1_000056_2e3450f7+0x37>
  40f5ac:	mov    r8,QWORD PTR [rax+0x20]
  40f5b0:	cmp    DWORD PTR [r8+0x28],0x0
  40f5b5:	je     40f5c0 <__swc_fn_7dafa2b1_000056_2e3450f7+0x40>
  40f5b7:	mov    QWORD PTR [rax+0x20],r9
  40f5bb:	add    rsp,0x8
  40f5bf:	ret
  40f5c0:	mov    r8,r9
  40f5c3:	call   40ad90 <__swc_fn_7dafa2b1_000049_137687bb>
  40f5c8:	mov    rax,r9
  40f5cb:	and    rax,0xffffffffffc00000
  40f5d2:	mov    rcx,rax
  40f5d5:	mov    rdx,r9
  40f5d8:	call   40a900 <__swc_fn_7dafa2b1_000019_283e2b5e>
  40f5dd:	add    rsp,0x8
  40f5e1:	ret
	...

000000000040f5f0 <__swc_fn_7dafa2b1_000059_1bb23e77>:
  40f5f0:	push   rsi
  40f5f1:	push   rdi
  40f5f2:	push   r12
  40f5f4:	mov    rsi,rdx
  40f5f7:	mov    rax,rdx
  40f5fa:	shr    rax,0xc
  40f5fe:	movabs rdx,0x9e3779b97f4a7c15
  40f608:	imul   rax,rdx
  40f60c:	shr    rax,0x20
  40f610:	lea    rax,[rax*8+0x0]
  40f618:	shr    rax,0x20
  40f61c:	lea    rax,[rax*8+0x0]
  40f624:	lea    rax,[rcx+rax*8+0x40]
  40f629:	xor    edx,edx
  40f62b:	test   dl,dl
  40f62d:	lea    rdi,[rcx+0x8]
  40f631:	cmove  rdi,rax
  40f635:	xor    edx,edx
  40f637:	test   dl,dl
  40f639:	lea    r12,[rcx+0x30]
  40f63d:	lea    rax,[rax+0x8]
  40f641:	cmove  r12,rax
  40f645:	mov    rcx,rdi
  40f648:	call   4110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>
  40f64d:	mov    rax,QWORD PTR [rsi+0x30]
  40f651:	test   rax,rax
  40f654:	jne    40f660 <__swc_fn_7dafa2b1_000059_1bb23e77+0x70>
  40f656:	mov    rax,QWORD PTR [rsi+0x38]
  40f65a:	mov    QWORD PTR [r12],rax
  40f65e:	jmp    40f668 <__swc_fn_7dafa2b1_000059_1bb23e77+0x78>
  40f660:	mov    rcx,QWORD PTR [rsi+0x38]
  40f664:	mov    QWORD PTR [rax+0x38],rcx
  40f668:	mov    rax,QWORD PTR [rsi+0x38]
  40f66c:	test   rax,rax
  40f66f:	je     40f679 <__swc_fn_7dafa2b1_000059_1bb23e77+0x89>
  40f671:	mov    rcx,QWORD PTR [rsi+0x30]
  40f675:	mov    QWORD PTR [rax+0x30],rcx
  40f679:	vxorps xmm0,xmm0,xmm0
  40f67d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  40f682:	mov    rcx,rdi
  40f685:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40f68a:	pop    r12
  40f68c:	pop    rdi
  40f68d:	pop    rsi
  40f68e:	ret
	...

000000000040f690 <__swc_fn_7dafa2b1_000062_ad030a10>:
  40f690:	mov    rax,QWORD PTR [rcx+0x250]
  40f697:	mov    rcx,rax
  40f69a:	cmp    rax,0x1000000
  40f6a1:	mov    eax,0x1000000
  40f6a6:	cmovb  rcx,rax
  40f6aa:	mov    rax,rcx
  40f6ad:	cmp    rcx,0x10000000
  40f6b4:	mov    ecx,0x10000000
  40f6b9:	cmova  rax,rcx
  40f6bd:	ret
	...

000000000040f6c0 <__swc_fn_7dafa2b1_000065_ffcd96eb>:
  40f6c0:	push   rsi
  40f6c1:	push   rdi
  40f6c2:	push   r12
  40f6c4:	mov    rsi,rcx
  40f6c7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  40f6ce:	xor    r12d,r12d
  40f6d1:	test   rdi,rdi
  40f6d4:	jbe    40f70b <__swc_fn_7dafa2b1_000065_ffcd96eb+0x4b>
  40f6d6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f6e0:	lea    rax,[r12+r12*4]
  40f6e4:	lea    rax,[rsi+rax*8+0x268]
  40f6ec:	mov    rcx,rsi
  40f6ef:	mov    rdx,QWORD PTR [rax]
  40f6f2:	mov    r8,QWORD PTR [rax+0x8]
  40f6f6:	mov    rax,QWORD PTR [rax+0x10]
  40f6fa:	mov    r9,rax
  40f6fd:	call   40ef60 <__swc_fn_7dafa2b1_000044_d3c2ab54>
  40f702:	add    r12,0x1
  40f706:	cmp    r12,rdi
  40f709:	jb     40f6e0 <__swc_fn_7dafa2b1_000065_ffcd96eb+0x20>
  40f70b:	vxorps xmm0,xmm0,xmm0
  40f70f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  40f717:	pop    r12
  40f719:	pop    rdi
  40f71a:	pop    rsi
  40f71b:	ret
  40f71c:	add    BYTE PTR [rax],al
	...

000000000040f720 <__swc_fn_7dafa2b1_000068_8c7d044b>:
  40f720:	push   rsi
  40f721:	push   rdi
  40f722:	sub    rsp,0x8
  40f726:	mov    rsi,rcx
  40f729:	call   407fc0 <__swc_fn_7dafa2b1_000057_df0696cd>
  40f72e:	mov    rdi,rax
  40f731:	mov    rcx,rsi
  40f734:	mov    rdx,rax
  40f737:	call   40f5f0 <__swc_fn_7dafa2b1_000059_1bb23e77>
  40f73c:	mov    rcx,QWORD PTR [rdi+0x28]
  40f740:	mov    rdx,QWORD PTR [rsi+0x250]
  40f747:	nop    WORD PTR [rax+rax*1+0x0]
  40f750:	mov    r8,rdx
  40f753:	sub    r8,rcx
  40f756:	mov    rax,rdx
  40f759:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40f762:	cmp    rax,rdx
  40f765:	je     40f76c <__swc_fn_7dafa2b1_000068_8c7d044b+0x4c>
  40f767:	mov    rdx,rax
  40f76a:	jmp    40f750 <__swc_fn_7dafa2b1_000068_8c7d044b+0x30>
  40f76c:	mov    rcx,rsi
  40f76f:	mov    rdx,QWORD PTR [rdi]
  40f772:	mov    r8,QWORD PTR [rdi+0x8]
  40f776:	mov    r9,QWORD PTR [rdi+0x10]
  40f77a:	call   4080e0 <__swc_fn_7dafa2b1_000063_b304235a>
  40f77f:	mov    rcx,rsi
  40f782:	call   407d20 <__swc_fn_7dafa2b1_000054_3af34d7f>
  40f787:	add    rsp,0x8
  40f78b:	pop    rdi
  40f78c:	pop    rsi
  40f78d:	ret
	...

000000000040f790 <__swc_fn_7dafa2b1_000071_97813b89>:
  40f790:	push   r12
  40f792:	push   r13
  40f794:	push   r14
  40f796:	push   rdi
  40f797:	push   rsi
  40f798:	sub    rsp,0x1b0
  40f79f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  40f7a8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  40f7b1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  40f7ba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  40f7c3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  40f7cc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  40f7d5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  40f7de:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  40f7e7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  40f7f0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  40f7f9:	mov    r8,rdx
  40f7fc:	mov    r12,rcx
  40f7ff:	mov    r13,QWORD PTR [r8+0x40]
  40f803:	test   r13,r13
  40f806:	jne    40f818 <__swc_fn_7dafa2b1_000071_97813b89+0x88>
  40f808:	add    rsp,0x1b0
  40f80f:	pop    rsi
  40f810:	pop    rdi
  40f811:	pop    r14
  40f813:	pop    r13
  40f815:	pop    r12
  40f817:	ret
  40f818:	mov    QWORD PTR [r8+0x40],0x0
  40f820:	lea    rax,[rip+0x13851]        # 423078 <__swc_bss_base_7dafa2b1+0x38>
  40f827:	mov    rcx,r13
  40f82a:	sub    rcx,QWORD PTR [rax+0x8]
  40f82e:	mov    rax,QWORD PTR [rip+0x13853]        # 423088 <__swc_bss_base_7dafa2b1+0x48>
  40f835:	cmp    rcx,rax
  40f838:	jae    40f864 <__swc_fn_7dafa2b1_000071_97813b89+0xd4>
  40f83a:	mov    rax,r13
  40f83d:	and    rax,0xffffffffffc00000
  40f844:	mov    rcx,r13
  40f847:	shr    rcx,0x10
  40f84b:	and    ecx,0x3f
  40f84e:	mov    edx,DWORD PTR [rax+0x28]
  40f851:	shrx   ecx,ecx,edx
  40f856:	shl    rcx,0x4
  40f85a:	lea    r14,[rax+rcx*8+0x80]
  40f862:	jmp    40f87f <__swc_fn_7dafa2b1_000071_97813b89+0xef>
  40f864:	mov    rcx,r13
  40f867:	mov    QWORD PTR [rsp+0xf8],r8
  40f86f:	call   4079b0 <__swc_fn_7dafa2b1_000027_bcdc5519>
  40f874:	mov    r8,QWORD PTR [rsp+0xf8]
  40f87c:	mov    r14,rax
  40f87f:	test   r14,r14
  40f882:	jne    40f894 <__swc_fn_7dafa2b1_000071_97813b89+0x104>
  40f884:	mov    rcx,r12
  40f887:	mov    rdx,r13
  40f88a:	call   40f720 <__swc_fn_7dafa2b1_000068_8c7d044b>
  40f88f:	jmp    40f922 <__swc_fn_7dafa2b1_000071_97813b89+0x192>
  40f894:	lea    rax,[rip+0x11765]        # 421000 <__swc_data_base_7dafa2b1>
  40f89b:	mov    rax,QWORD PTR [rax]
  40f89e:	cmp    rax,0xffffffffffffffff
  40f8a2:	je     40f8b1 <__swc_fn_7dafa2b1_000071_97813b89+0x121>
  40f8a4:	mov    eax,eax
  40f8a6:	mov    edi,eax
  40f8a8:	xor    eax,eax
  40f8aa:	call   407000 <pthread_getspecific@plt>
  40f8af:	jmp    40f8b3 <__swc_fn_7dafa2b1_000071_97813b89+0x123>
  40f8b1:	xor    eax,eax
  40f8b3:	test   rax,rax
  40f8b6:	jne    40f8c5 <__swc_fn_7dafa2b1_000071_97813b89+0x135>
  40f8b8:	call   407a80 <__swc_fn_7dafa2b1_000036_cd1a4e8c>
  40f8bd:	mov    rcx,rax
  40f8c0:	call   40cdc0 <__swc_fn_7dafa2b1_000133_5f757033>
  40f8c5:	test   rax,rax
  40f8c8:	je     40f917 <__swc_fn_7dafa2b1_000071_97813b89+0x187>
  40f8ca:	cmp    QWORD PTR [r14+0x40],rax
  40f8ce:	jne    40f917 <__swc_fn_7dafa2b1_000071_97813b89+0x187>
  40f8d0:	mov    ecx,DWORD PTR [r14+0x6c]
  40f8d4:	test   ecx,ecx
  40f8d6:	je     40f8f6 <__swc_fn_7dafa2b1_000071_97813b89+0x166>
  40f8d8:	mov    rcx,r12
  40f8db:	mov    rdx,rax
  40f8de:	mov    r8,r14
  40f8e1:	mov    QWORD PTR [rsp+0x100],rax
  40f8e9:	call   40ae30 <__swc_fn_7dafa2b1_000052_e072b516>
  40f8ee:	mov    rax,QWORD PTR [rsp+0x100]
  40f8f6:	mov    rcx,QWORD PTR [r14]
  40f8f9:	mov    QWORD PTR [r13+0x0],rcx
  40f8fd:	mov    QWORD PTR [r14],r13
  40f900:	sub    DWORD PTR [r14+0x28],0x1
  40f905:	jne    40f922 <__swc_fn_7dafa2b1_000071_97813b89+0x192>
  40f907:	mov    rcx,r12
  40f90a:	mov    rdx,rax
  40f90d:	mov    r8,r14
  40f910:	call   40f580 <__swc_fn_7dafa2b1_000056_2e3450f7>
  40f915:	jmp    40f922 <__swc_fn_7dafa2b1_000071_97813b89+0x192>
  40f917:	mov    rcx,r14
  40f91a:	mov    rdx,r13
  40f91d:	call   4075f0 <__swc_fn_7dafa2b1_000015_524c1f23>
  40f922:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40f92b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  40f934:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40f93d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  40f946:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40f94f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  40f958:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  40f961:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40f96a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  40f973:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40f97c:	add    rsp,0x1b0
  40f983:	pop    rsi
  40f984:	pop    rdi
  40f985:	pop    r14
  40f987:	pop    r13
  40f989:	pop    r12
  40f98b:	ret
  40f98c:	add    BYTE PTR [rax],al
	...

000000000040f990 <__swc_fn_7dafa2b1_000074_9c99bf04>:
  40f990:	push   rsi
  40f991:	mov    rsi,rcx
  40f994:	call   40ef50 <__swc_fn_7dafa2b1_000041_eb6108f2>
  40f999:	test   al,al
  40f99b:	jne    40f99f <__swc_fn_7dafa2b1_000074_9c99bf04+0xf>
  40f99d:	pop    rsi
  40f99e:	ret
  40f99f:	lea    rax,[rip+0x1389a]        # 423240 <__swc_bss_base_7dafa2b1+0x200>
  40f9a6:	cmp    rsi,rax
  40f9a9:	jne    40f9ad <__swc_fn_7dafa2b1_000074_9c99bf04+0x1d>
  40f9ab:	pop    rsi
  40f9ac:	ret
  40f9ad:	mov    rcx,rsi
  40f9b0:	call   4110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>
  40f9b5:	mov    rcx,rsi
  40f9b8:	call   40b600 <__swc_fn_7dafa2b1_000073_61e60aab>
  40f9bd:	mov    rcx,rsi
  40f9c0:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  40f9c5:	pop    rsi
  40f9c6:	ret
	...

000000000040f9d0 <__swc_fn_7dafa2b1_000077_15bd096c>:
  40f9d0:	sub    rsp,0x8
  40f9d4:	call   40b350 <__swc_fn_7dafa2b1_000070_7130736e>
  40f9d9:	add    rsp,0x8
  40f9dd:	ret
	...

000000000040f9e0 <__swc_fn_7dafa2b1_000080_a5fd3362>:
  40f9e0:	push   rsi
  40f9e1:	mov    rsi,rdx
  40f9e4:	call   40b600 <__swc_fn_7dafa2b1_000073_61e60aab>
  40f9e9:	mov    QWORD PTR [rsi+0x40],0x0
  40f9f1:	pop    rsi
  40f9f2:	ret
	...

000000000040fa00 <__swc_fn_7dafa2b1_000083_63a67586>:
  40fa00:	mov    r8,rcx
  40fa03:	mov    rcx,QWORD PTR [rcx]
  40fa06:	cs nop WORD PTR [rax+rax*1+0x0]
  40fa10:	mov    r9,rcx
  40fa13:	sub    r9,rdx
  40fa16:	mov    rax,rcx
  40fa19:	lock cmpxchg QWORD PTR [r8],r9
  40fa1e:	cmp    rax,rcx
  40fa21:	je     40fa28 <__swc_fn_7dafa2b1_000083_63a67586+0x28>
  40fa23:	mov    rcx,rax
  40fa26:	jmp    40fa10 <__swc_fn_7dafa2b1_000083_63a67586+0x10>
  40fa28:	mov    rax,rcx
  40fa2b:	ret
  40fa2c:	add    BYTE PTR [rax],al
	...

000000000040fa30 <__swc_fn_7dafa2b1_000086_c618ff58>:
  40fa30:	vxorps xmm0,xmm0,xmm0
  40fa34:	vmovups XMMWORD PTR [rcx],xmm0
  40fa38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40fa3d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40fa42:	ret
	...

000000000040fa50 <__swc_fn_7dafa2b1_000089_0d280354>:
  40fa50:	push   rsi
  40fa51:	push   rdi
  40fa52:	push   r12
  40fa54:	push   r13
  40fa56:	push   r15
  40fa58:	push   r14
  40fa5a:	push   rbx
  40fa5b:	sub    rsp,0x60
  40fa5f:	mov    QWORD PTR [rsp+0x28],r11
  40fa64:	mov    rsi,rcx
  40fa67:	mov    rdi,rdx
  40fa6a:	mov    QWORD PTR [rsp+0x30],rdx
  40fa6f:	mov    r12,r8
  40fa72:	mov    r13,r9
  40fa75:	mov    QWORD PTR [rsp+0x38],r10
  40fa7a:	xor    r8d,r8d
  40fa7d:	call   40fda0 <__swc_fn_7dafa2b1_000095_63c1827b>
  40fa82:	test   al,al
  40fa84:	je     40fa99 <__swc_fn_7dafa2b1_000089_0d280354+0x49>
  40fa86:	mov    rax,r12
  40fa89:	add    rsp,0x60
  40fa8d:	pop    rbx
  40fa8e:	pop    r14
  40fa90:	pop    r15
  40fa92:	pop    r13
  40fa94:	pop    r12
  40fa96:	pop    rdi
  40fa97:	pop    rsi
  40fa98:	ret
  40fa99:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40fa9e:	je     40fab2 <__swc_fn_7dafa2b1_000089_0d280354+0x62>
  40faa0:	xor    eax,eax
  40faa2:	add    rsp,0x60
  40faa6:	pop    rbx
  40faa7:	pop    r14
  40faa9:	pop    r15
  40faab:	pop    r13
  40faad:	pop    r12
  40faaf:	pop    rdi
  40fab0:	pop    rsi
  40fab1:	ret
  40fab2:	mov    r15,rdi
  40fab5:	mov    QWORD PTR [rsp+0x40],rdi
  40faba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40fabf:	jne    40fb2f <__swc_fn_7dafa2b1_000089_0d280354+0xdf>
  40fac1:	mov    r14,QWORD PTR [r15+0xb8]
  40fac8:	mov    rax,QWORD PTR [r15+0xc0]
  40facf:	mov    r15,rax
  40fad2:	xor    edi,edi
  40fad4:	test   r15,r15
  40fad7:	je     40fb2f <__swc_fn_7dafa2b1_000089_0d280354+0xdf>
  40fad9:	nop    DWORD PTR [rax+0x0]
  40fae0:	lea    rbx,[rdi*8+0x0]
  40fae8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  40faed:	mov    rcx,rax
  40faf0:	mov    rdx,rsi
  40faf3:	xor    r8d,r8d
  40faf6:	call   40fda0 <__swc_fn_7dafa2b1_000095_63c1827b>
  40fafb:	test   al,al
  40fafd:	je     40fb25 <__swc_fn_7dafa2b1_000089_0d280354+0xd5>
  40faff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  40fb04:	test   rax,rax
  40fb07:	je     40fb25 <__swc_fn_7dafa2b1_000089_0d280354+0xd5>
  40fb09:	test   r13,r13
  40fb0c:	je     40fb12 <__swc_fn_7dafa2b1_000089_0d280354+0xc2>
  40fb0e:	mov    QWORD PTR [r13+0x8],rax
  40fb12:	mov    rax,r12
  40fb15:	add    rsp,0x60
  40fb19:	pop    rbx
  40fb1a:	pop    r14
  40fb1c:	pop    r15
  40fb1e:	pop    r13
  40fb20:	pop    r12
  40fb22:	pop    rdi
  40fb23:	pop    rsi
  40fb24:	ret
  40fb25:	add    rdi,0x1
  40fb29:	sub    r15,0x1
  40fb2d:	jne    40fae0 <__swc_fn_7dafa2b1_000089_0d280354+0x90>
  40fb2f:	test   r12,r12
  40fb32:	jne    40fb46 <__swc_fn_7dafa2b1_000089_0d280354+0xf6>
  40fb34:	xor    eax,eax
  40fb36:	add    rsp,0x60
  40fb3a:	pop    rbx
  40fb3b:	pop    r14
  40fb3d:	pop    r15
  40fb3f:	pop    r13
  40fb41:	pop    r12
  40fb43:	pop    rdi
  40fb44:	pop    rsi
  40fb45:	ret
  40fb46:	mov    rbx,QWORD PTR [rsp+0x28]
  40fb4b:	mov    rdi,QWORD PTR [rsp+0x30]
  40fb50:	mov    rax,rbx
  40fb53:	test   rax,rax
  40fb56:	je     40fb86 <__swc_fn_7dafa2b1_000089_0d280354+0x136>
  40fb58:	nop    DWORD PTR [rax+rax*1+0x0]
  40fb60:	cmp    QWORD PTR [rax+0x8],r12
  40fb64:	jne    40fb7d <__swc_fn_7dafa2b1_000089_0d280354+0x12d>
  40fb66:	cmp    QWORD PTR [rax],rdi
  40fb69:	jne    40fb7d <__swc_fn_7dafa2b1_000089_0d280354+0x12d>
  40fb6b:	xor    eax,eax
  40fb6d:	add    rsp,0x60
  40fb71:	pop    rbx
  40fb72:	pop    r14
  40fb74:	pop    r15
  40fb76:	pop    r13
  40fb78:	pop    r12
  40fb7a:	pop    rdi
  40fb7b:	pop    rsi
  40fb7c:	ret
  40fb7d:	mov    rax,QWORD PTR [rax+0x10]
  40fb81:	test   rax,rax
  40fb84:	jne    40fb60 <__swc_fn_7dafa2b1_000089_0d280354+0x110>
  40fb86:	lea    r14,[rsp+0x8]
  40fb8b:	mov    QWORD PTR [rsp+0x48],r14
  40fb90:	mov    QWORD PTR [rsp+0x8],rdi
  40fb95:	mov    QWORD PTR [rsp+0x10],r12
  40fb9a:	mov    QWORD PTR [rsp+0x18],rbx
  40fb9f:	mov    r15,QWORD PTR [rsp+0x40]
  40fba4:	mov    rbx,QWORD PTR [r15+0x98]
  40fbab:	mov    rax,QWORD PTR [r15+0xa0]
  40fbb2:	mov    rdi,rax
  40fbb5:	mov    r15,QWORD PTR [rsp+0x38]
  40fbba:	xor    r14d,r14d
  40fbbd:	test   rdi,rdi
  40fbc0:	je     40fc6a <__swc_fn_7dafa2b1_000089_0d280354+0x21a>
  40fbc6:	cs nop WORD PTR [rax+rax*1+0x0]
  40fbd0:	mov    QWORD PTR [rsp+0x50],rdi
  40fbd5:	lea    rdi,[r14*8+0x0]
  40fbdd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  40fbe2:	mov    rcx,rax
  40fbe5:	call   4090c0 <__swc_fn_7dafa2b1_000087_3953ef98>
  40fbea:	test   DWORD PTR [rax+0x28],0x10000
  40fbf1:	je     40fbf8 <__swc_fn_7dafa2b1_000089_0d280354+0x1a8>
  40fbf3:	test   r15b,r15b
  40fbf6:	je     40fc51 <__swc_fn_7dafa2b1_000089_0d280354+0x201>
  40fbf8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  40fbfc:	lea    rdi,[r12+rcx*1]
  40fc00:	cmp    BYTE PTR [rax+0x2c],0x6
  40fc04:	jne    40fc18 <__swc_fn_7dafa2b1_000089_0d280354+0x1c8>
  40fc06:	mov    rax,QWORD PTR [rax+0x40]
  40fc0a:	mov    rcx,rax
  40fc0d:	call   4090c0 <__swc_fn_7dafa2b1_000087_3953ef98>
  40fc12:	mov    rcx,QWORD PTR [rdi]
  40fc15:	mov    rdi,rcx
  40fc18:	test   rdi,rdi
  40fc1b:	je     40fc51 <__swc_fn_7dafa2b1_000089_0d280354+0x201>
  40fc1d:	mov    rcx,rsi
  40fc20:	mov    rdx,rax
  40fc23:	mov    r8,rdi
  40fc26:	mov    r9,r13
  40fc29:	mov    al,r15b
  40fc2c:	mov    r10,rax
  40fc2f:	mov    rdi,QWORD PTR [rsp+0x48]
  40fc34:	mov    r11,rdi
  40fc37:	call   40fa50 <__swc_fn_7dafa2b1_000089_0d280354>
  40fc3c:	test   rax,rax
  40fc3f:	je     40fc51 <__swc_fn_7dafa2b1_000089_0d280354+0x201>
  40fc41:	add    rsp,0x60
  40fc45:	pop    rbx
  40fc46:	pop    r14
  40fc48:	pop    r15
  40fc4a:	pop    r13
  40fc4c:	pop    r12
  40fc4e:	pop    rdi
  40fc4f:	pop    rsi
  40fc50:	ret
  40fc51:	add    r14,0x1
  40fc55:	mov    rax,QWORD PTR [rsp+0x50]
  40fc5a:	sub    rax,0x1
  40fc5e:	mov    rdi,rax
  40fc61:	test   rax,rax
  40fc64:	jne    40fbd0 <__swc_fn_7dafa2b1_000089_0d280354+0x180>
  40fc6a:	xor    eax,eax
  40fc6c:	add    rsp,0x60
  40fc70:	pop    rbx
  40fc71:	pop    r14
  40fc73:	pop    r15
  40fc75:	pop    r13
  40fc77:	pop    r12
  40fc79:	pop    rdi
  40fc7a:	pop    rsi
  40fc7b:	ret
  40fc7c:	add    BYTE PTR [rax],al
	...

000000000040fc80 <__swc_fn_7dafa2b1_000092_c1c9085b>:
  40fc80:	push   rsi
  40fc81:	push   rdi
  40fc82:	push   r12
  40fc84:	push   r13
  40fc86:	push   r14
  40fc88:	push   r15
  40fc8a:	sub    rsp,0x78
  40fc8e:	mov    rsi,r10
  40fc91:	mov    QWORD PTR [rsp+0x68],r10
  40fc96:	mov    rdi,rcx
  40fc99:	mov    r12,rdx
  40fc9c:	mov    r13,r8
  40fc9f:	mov    r14,r9
  40fca2:	xor    r8d,r8d
  40fca5:	call   40fda0 <__swc_fn_7dafa2b1_000095_63c1827b>
  40fcaa:	test   al,al
  40fcac:	je     40fcd5 <__swc_fn_7dafa2b1_000092_c1c9085b+0x55>
  40fcae:	mov    rcx,r14
  40fcb1:	mov    rdx,r12
  40fcb4:	mov    r8,r13
  40fcb7:	mov    r9,rsi
  40fcba:	call   40ba60 <__swc_fn_7dafa2b1_000091_23214800>
  40fcbf:	test   al,al
  40fcc1:	je     40fcd5 <__swc_fn_7dafa2b1_000092_c1c9085b+0x55>
  40fcc3:	mov    rax,r13
  40fcc6:	add    rsp,0x78
  40fcca:	pop    r15
  40fccc:	pop    r14
  40fcce:	pop    r13
  40fcd0:	pop    r12
  40fcd2:	pop    rdi
  40fcd3:	pop    rsi
  40fcd4:	ret
  40fcd5:	cmp    BYTE PTR [r12+0x2c],0xe
  40fcdb:	je     40fcee <__swc_fn_7dafa2b1_000092_c1c9085b+0x6e>
  40fcdd:	xor    eax,eax
  40fcdf:	add    rsp,0x78
  40fce3:	pop    r15
  40fce5:	pop    r14
  40fce7:	pop    r13
  40fce9:	pop    r12
  40fceb:	pop    rdi
  40fcec:	pop    rsi
  40fced:	ret
  40fcee:	mov    r15,QWORD PTR [r12+0x98]
  40fcf6:	mov    rax,QWORD PTR [r12+0xa0]
  40fcfe:	mov    r12,rax
  40fd01:	xor    esi,esi
  40fd03:	test   r12,r12
  40fd06:	je     40fd79 <__swc_fn_7dafa2b1_000092_c1c9085b+0xf9>
  40fd08:	nop    DWORD PTR [rax+rax*1+0x0]
  40fd10:	mov    QWORD PTR [rsp+0x70],r12
  40fd15:	lea    r12,[rsi*8+0x0]
  40fd1d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  40fd22:	mov    rcx,rax
  40fd25:	call   4090c0 <__swc_fn_7dafa2b1_000087_3953ef98>
  40fd2a:	cmp    BYTE PTR [rax+0x2c],0xe
  40fd2e:	jne    40fd64 <__swc_fn_7dafa2b1_000092_c1c9085b+0xe4>
  40fd30:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  40fd35:	lea    r8,[r13+rcx*1+0x0]
  40fd3a:	mov    rcx,rdi
  40fd3d:	mov    rdx,rax
  40fd40:	mov    r9,r14
  40fd43:	mov    r12,QWORD PTR [rsp+0x68]
  40fd48:	mov    r10,r12
  40fd4b:	call   40fc80 <__swc_fn_7dafa2b1_000092_c1c9085b>
  40fd50:	test   rax,rax
  40fd53:	je     40fd64 <__swc_fn_7dafa2b1_000092_c1c9085b+0xe4>
  40fd55:	add    rsp,0x78
  40fd59:	pop    r15
  40fd5b:	pop    r14
  40fd5d:	pop    r13
  40fd5f:	pop    r12
  40fd61:	pop    rdi
  40fd62:	pop    rsi
  40fd63:	ret
  40fd64:	add    rsi,0x1
  40fd68:	mov    rax,QWORD PTR [rsp+0x70]
  40fd6d:	sub    rax,0x1
  40fd71:	mov    r12,rax
  40fd74:	test   rax,rax
  40fd77:	jne    40fd10 <__swc_fn_7dafa2b1_000092_c1c9085b+0x90>
  40fd79:	xor    eax,eax
  40fd7b:	add    rsp,0x78
  40fd7f:	pop    r15
  40fd81:	pop    r14
  40fd83:	pop    r13
  40fd85:	pop    r12
  40fd87:	pop    rdi
  40fd88:	pop    rsi
  40fd89:	ret
	...

000000000040fda0 <__swc_fn_7dafa2b1_000095_63c1827b>:
  40fda0:	push   rbx
  40fda1:	push   rsi
  40fda2:	push   rdi
  40fda3:	push   r12
  40fda5:	push   r13
  40fda7:	push   r14
  40fda9:	push   r15
  40fdab:	sub    rsp,0x120
  40fdb2:	mov    rbx,r8
  40fdb5:	mov    rsi,rdx
  40fdb8:	test   rcx,rcx
  40fdbb:	jne    40fdda <__swc_fn_7dafa2b1_000095_63c1827b+0x3a>
  40fdbd:	test   rsi,rsi
  40fdc0:	jne    40fdda <__swc_fn_7dafa2b1_000095_63c1827b+0x3a>
  40fdc2:	mov    eax,0x1
  40fdc7:	add    rsp,0x120
  40fdce:	pop    r15
  40fdd0:	pop    r14
  40fdd2:	pop    r13
  40fdd4:	pop    r12
  40fdd6:	pop    rdi
  40fdd7:	pop    rsi
  40fdd8:	pop    rbx
  40fdd9:	ret
  40fdda:	test   rcx,rcx
  40fddd:	je     40fde4 <__swc_fn_7dafa2b1_000095_63c1827b+0x44>
  40fddf:	test   rsi,rsi
  40fde2:	jne    40fdf9 <__swc_fn_7dafa2b1_000095_63c1827b+0x59>
  40fde4:	xor    eax,eax
  40fde6:	add    rsp,0x120
  40fded:	pop    r15
  40fdef:	pop    r14
  40fdf1:	pop    r13
  40fdf3:	pop    r12
  40fdf5:	pop    rdi
  40fdf6:	pop    rsi
  40fdf7:	pop    rbx
  40fdf8:	ret
  40fdf9:	call   4090c0 <__swc_fn_7dafa2b1_000087_3953ef98>
  40fdfe:	mov    rdi,rax
  40fe01:	mov    rcx,rsi
  40fe04:	call   4090c0 <__swc_fn_7dafa2b1_000087_3953ef98>
  40fe09:	test   bl,0x1
  40fe0c:	je     40fe4a <__swc_fn_7dafa2b1_000095_63c1827b+0xaa>
  40fe0e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  40fe13:	jne    40fe4a <__swc_fn_7dafa2b1_000095_63c1827b+0xaa>
  40fe15:	mov    ecx,DWORD PTR [rdi+0x28]
  40fe18:	test   ecx,0x1000
  40fe1e:	je     40fe4a <__swc_fn_7dafa2b1_000095_63c1827b+0xaa>
  40fe20:	test   ecx,0x10000
  40fe26:	je     40fe4a <__swc_fn_7dafa2b1_000095_63c1827b+0xaa>
  40fe28:	mov    rcx,QWORD PTR [rdi+0x40]
  40fe2c:	mov    rdx,rax
  40fe2f:	mov    r8d,ebx
  40fe32:	call   40fda0 <__swc_fn_7dafa2b1_000095_63c1827b>
  40fe37:	add    rsp,0x120
  40fe3e:	pop    r15
  40fe40:	pop    r14
  40fe42:	pop    r13
  40fe44:	pop    r12
  40fe46:	pop    rdi
  40fe47:	pop    rsi
  40fe48:	pop    rbx
  40fe49:	ret
  40fe4a:	mov    cl,BYTE PTR [rax+0x2c]
  40fe4d:	rex cmp BYTE PTR [rdi+0x2c],cl
  40fe51:	jne    40fe5b <__swc_fn_7dafa2b1_000095_63c1827b+0xbb>
  40fe53:	mov    ecx,DWORD PTR [rax+0x20]
  40fe56:	cmp    DWORD PTR [rdi+0x20],ecx
  40fe59:	je     40fe70 <__swc_fn_7dafa2b1_000095_63c1827b+0xd0>
  40fe5b:	xor    eax,eax
  40fe5d:	add    rsp,0x120
  40fe64:	pop    r15
  40fe66:	pop    r14
  40fe68:	pop    r13
  40fe6a:	pop    r12
  40fe6c:	pop    rdi
  40fe6d:	pop    rsi
  40fe6e:	pop    rbx
  40fe6f:	ret
  40fe70:	mov    ecx,DWORD PTR [rdi+0x28]
  40fe73:	and    ecx,0xffb5ffff
  40fe79:	mov    edx,DWORD PTR [rax+0x28]
  40fe7c:	and    edx,0xffb5ffff
  40fe82:	cmp    ecx,edx
  40fe84:	je     40fe9b <__swc_fn_7dafa2b1_000095_63c1827b+0xfb>
  40fe86:	xor    eax,eax
  40fe88:	add    rsp,0x120
  40fe8f:	pop    r15
  40fe91:	pop    r14
  40fe93:	pop    r13
  40fe95:	pop    r12
  40fe97:	pop    rdi
  40fe98:	pop    rsi
  40fe99:	pop    rbx
  40fe9a:	ret
  40fe9b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  40fea0:	jne    40fef5 <__swc_fn_7dafa2b1_000095_63c1827b+0x155>
  40fea2:	mov    cl,BYTE PTR [rax+0x40]
  40fea5:	rex cmp BYTE PTR [rdi+0x40],cl
  40fea9:	je     40fec0 <__swc_fn_7dafa2b1_000095_63c1827b+0x120>
  40feab:	xor    eax,eax
  40fead:	add    rsp,0x120
  40feb4:	pop    r15
  40feb6:	pop    r14
  40feb8:	pop    r13
  40feba:	pop    r12
  40febc:	pop    rdi
  40febd:	pop    rsi
  40febe:	pop    rbx
  40febf:	ret
  40fec0:	rex cmp BYTE PTR [rdi+0x40],0xd
  40fec5:	je     40fedd <__swc_fn_7dafa2b1_000095_63c1827b+0x13d>
  40fec7:	rex cmp BYTE PTR [rdi+0x40],0xf
  40fecc:	sete   cl
  40fecf:	je     40fed9 <__swc_fn_7dafa2b1_000095_63c1827b+0x139>
  40fed1:	rex cmp BYTE PTR [rdi+0x40],0xe
  40fed6:	sete   cl
  40fed9:	test   cl,cl
  40fedb:	je     40fef5 <__swc_fn_7dafa2b1_000095_63c1827b+0x155>
  40fedd:	mov    eax,0x1
  40fee2:	add    rsp,0x120
  40fee9:	pop    r15
  40feeb:	pop    r14
  40feed:	pop    r13
  40feef:	pop    r12
  40fef1:	pop    rdi
  40fef2:	pop    rsi
  40fef3:	pop    rbx
  40fef4:	ret
  40fef5:	test   DWORD PTR [rdi+0x28],0x200200
  40fefc:	je     4100af <__swc_fn_7dafa2b1_000095_63c1827b+0x30f>
  40ff02:	mov    rsi,QWORD PTR [rdi+0x88]
  40ff09:	mov    rdi,QWORD PTR [rdi+0x90]
  40ff10:	mov    r12,QWORD PTR [rax+0x88]
  40ff17:	mov    rax,QWORD PTR [rax+0x90]
  40ff1e:	cmp    rdi,rax
  40ff21:	je     40ff38 <__swc_fn_7dafa2b1_000095_63c1827b+0x198>
  40ff23:	xor    eax,eax
  40ff25:	add    rsp,0x120
  40ff2c:	pop    r15
  40ff2e:	pop    r14
  40ff30:	pop    r13
  40ff32:	pop    r12
  40ff34:	pop    rdi
  40ff35:	pop    rsi
  40ff36:	pop    rbx
  40ff37:	ret
  40ff38:	test   rsi,rsi
  40ff3b:	je     40ff42 <__swc_fn_7dafa2b1_000095_63c1827b+0x1a2>
  40ff3d:	test   r12,r12
  40ff40:	jne    40ff5a <__swc_fn_7dafa2b1_000095_63c1827b+0x1ba>
  40ff42:	mov    eax,0x1
  40ff47:	add    rsp,0x120
  40ff4e:	pop    r15
  40ff50:	pop    r14
  40ff52:	pop    r13
  40ff54:	pop    r12
  40ff56:	pop    rdi
  40ff57:	pop    rsi
  40ff58:	pop    rbx
  40ff59:	ret
  40ff5a:	xor    r13d,r13d
  40ff5d:	test   rdi,rdi
  40ff60:	jbe    410097 <__swc_fn_7dafa2b1_000095_63c1827b+0x2f7>
  40ff66:	lea    r14,[rsp+0x78]
  40ff6b:	lea    r15,[rsp+0xb8]
  40ff73:	cs nop WORD PTR [rax+rax*1+0x0]
  40ff7d:	cs nop WORD PTR [rax+rax*1+0x0]
  40ff87:	nop    WORD PTR [rax+rax*1+0x0]
  40ff90:	lea    rax,[r13*8+0x0]
  40ff98:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40ff9d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40ffa3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  40ffa9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40ffb2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  40ffb8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40ffc1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  40ffc7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40ffd0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  40ffd6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40ffdf:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  40ffe6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  40ffef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  40fff6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  40ffff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  410006:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  41000f:	xor    al,al
  410011:	rex test BYTE PTR [rsp+0xb0],0x1
  41001a:	je     410021 <__swc_fn_7dafa2b1_000095_63c1827b+0x281>
  41001c:	mov    eax,0x1
  410021:	rex test BYTE PTR [rsp+0xf0],0x1
  41002a:	je     410031 <__swc_fn_7dafa2b1_000095_63c1827b+0x291>
  41002c:	mov    eax,0x1
  410031:	test   al,al
  410033:	jne    410059 <__swc_fn_7dafa2b1_000095_63c1827b+0x2b9>
  410035:	mov    rcx,r14
  410038:	mov    rdx,r15
  41003b:	call   4115b0 <__swc_fn_7dafa2b1_000152_6fb05988>
  410040:	test   al,al
  410042:	jne    410059 <__swc_fn_7dafa2b1_000095_63c1827b+0x2b9>
  410044:	xor    eax,eax
  410046:	add    rsp,0x120
  41004d:	pop    r15
  41004f:	pop    r14
  410051:	pop    r13
  410053:	pop    r12
  410055:	pop    rdi
  410056:	pop    rsi
  410057:	pop    rbx
  410058:	ret
  410059:	mov    rcx,QWORD PTR [rsp+0x88]
  410061:	mov    rdx,QWORD PTR [rsp+0xc8]
  410069:	mov    r8d,ebx
  41006c:	call   40fda0 <__swc_fn_7dafa2b1_000095_63c1827b>
  410071:	test   al,al
  410073:	jne    41008a <__swc_fn_7dafa2b1_000095_63c1827b+0x2ea>
  410075:	xor    eax,eax
  410077:	add    rsp,0x120
  41007e:	pop    r15
  410080:	pop    r14
  410082:	pop    r13
  410084:	pop    r12
  410086:	pop    rdi
  410087:	pop    rsi
  410088:	pop    rbx
  410089:	ret
  41008a:	add    r13,0x1
  41008e:	cmp    r13,rdi
  410091:	jb     40ff90 <__swc_fn_7dafa2b1_000095_63c1827b+0x1f0>
  410097:	mov    eax,0x1
  41009c:	add    rsp,0x120
  4100a3:	pop    r15
  4100a5:	pop    r14
  4100a7:	pop    r13
  4100a9:	pop    r12
  4100ab:	pop    rdi
  4100ac:	pop    rsi
  4100ad:	pop    rbx
  4100ae:	ret
  4100af:	test   bl,0x2
  4100b2:	je     4100d4 <__swc_fn_7dafa2b1_000095_63c1827b+0x334>
  4100b4:	lea    rcx,[rdi+0x10]
  4100b8:	lea    rdx,[rax+0x10]
  4100bc:	call   4115b0 <__swc_fn_7dafa2b1_000152_6fb05988>
  4100c1:	add    rsp,0x120
  4100c8:	pop    r15
  4100ca:	pop    r14
  4100cc:	pop    r13
  4100ce:	pop    r12
  4100d0:	pop    rdi
  4100d1:	pop    rsi
  4100d2:	pop    rbx
  4100d3:	ret
  4100d4:	mov    rcx,rdi
  4100d7:	mov    rdx,rax
  4100da:	call   4115b0 <__swc_fn_7dafa2b1_000152_6fb05988>
  4100df:	add    rsp,0x120
  4100e6:	pop    r15
  4100e8:	pop    r14
  4100ea:	pop    r13
  4100ec:	pop    r12
  4100ee:	pop    rdi
  4100ef:	pop    rsi
  4100f0:	pop    rbx
  4100f1:	ret
	...

0000000000410100 <__swc_fn_7dafa2b1_000098_4185993f>:
  410100:	push   rbx
  410101:	mov    rbx,rcx
  410104:	call   4091f0 <__swc_fn_7dafa2b1_000096_ad13d15c>
  410109:	movzx  r11d,al
  41010d:	mov    r8b,r11b
  410110:	test   r8b,r8b
  410113:	jne    41012d <__swc_fn_7dafa2b1_000098_4185993f+0x2d>
  410115:	mov    r11d,0x1
  41011b:	mov    r10,rbx
  41011e:	mov    r9,r11
  410121:	and    r10,r11
  410124:	test   r10,r10
  410127:	setne  dl
  41012a:	mov    r8b,dl
  41012d:	mov    r10b,r8b
  410130:	test   r10b,r10b
  410133:	je     410137 <__swc_fn_7dafa2b1_000098_4185993f+0x37>
  410135:	pop    rbx
  410136:	ret
  410137:	call   40cf60 <__swc_fn_7dafa2b1_000142_519fdf94>
  41013c:	movzx  r10d,al
  410140:	test   r10b,r10b
  410143:	je     410147 <__swc_fn_7dafa2b1_000098_4185993f+0x47>
  410145:	pop    rbx
  410146:	ret
  410147:	lea    r10,[rip+0x2192]        # 4122e0 <__swc_rdata_base_7dafa2b1+0x1d0>
  41014e:	mov    rax,r10
  410151:	mov    rcx,rax
  410154:	call   40ca90 <__swc_fn_7dafa2b1_000121_2648f149>
  410159:	call   409a70 <__swc_fn_7dafa2b1_000123_be2e2f68>
  41015e:	pop    rbx
  41015f:	ret

0000000000410160 <__swc_fn_7dafa2b1_000101_d4bdcaa4>:
  410160:	push   rbx
  410161:	sub    rsp,0x70
  410165:	vxorps xmm0,xmm0,xmm0
  410169:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  41016f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  410175:	vzeroupper
  410178:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  41017e:	mov    QWORD PTR [rsp+0x48],rdx
  410183:	mov    rax,r8
  410186:	cmp    r8,0x1
  41018a:	mov    edx,0x1
  41018f:	cmovb  rax,rdx
  410193:	mov    QWORD PTR [rsp+0x50],rax
  410198:	mov    rbx,QWORD PTR [rcx+0x8]
  41019c:	mov    rbx,QWORD PTR [rbx+0x18]
  4101a0:	mov    rcx,QWORD PTR [rcx]
  4101a3:	lea    rdx,[rsp+0x8]
  4101a8:	call   rbx
  4101aa:	add    rsp,0x70
  4101ae:	pop    rbx
  4101af:	ret

00000000004101b0 <__swc_fn_7dafa2b1_000104_2fdd2c61>:
  4101b0:	push   rbx
  4101b1:	push   rsi
  4101b2:	push   rdi
  4101b3:	sub    rsp,0x30
  4101b7:	mov    rbx,rcx
  4101ba:	test   rcx,rcx
  4101bd:	je     4101d2 <__swc_fn_7dafa2b1_000104_2fdd2c61+0x22>
  4101bf:	mov    rcx,rbx
  4101c2:	mov    edx,0x1
  4101c7:	call   40fa00 <__swc_fn_7dafa2b1_000083_63a67586>
  4101cc:	cmp    rax,0x1
  4101d0:	je     4101da <__swc_fn_7dafa2b1_000104_2fdd2c61+0x2a>
  4101d2:	add    rsp,0x30
  4101d6:	pop    rdi
  4101d7:	pop    rsi
  4101d8:	pop    rbx
  4101d9:	ret
  4101da:	lea    rsi,[rsp+0x8]
  4101df:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4101e4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4101ea:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  4101ef:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4101f5:	mov    rax,QWORD PTR [rsp+0x20]
  4101fa:	test   rax,rax
  4101fd:	je     410213 <__swc_fn_7dafa2b1_000104_2fdd2c61+0x63>
  4101ff:	test   DWORD PTR [rax+0x28],0x400000
  410206:	je     410213 <__swc_fn_7dafa2b1_000104_2fdd2c61+0x63>
  410208:	mov    rcx,QWORD PTR [rax+0x30]
  41020c:	test   rcx,rcx
  41020f:	cmovne rax,rcx
  410213:	mov    edi,DWORD PTR [rax+0x20]
  410216:	lea    rcx,[rsp+0x18]
  41021b:	call   4093d0 <__swc_fn_7dafa2b1_000105_3c3b96fb>
  410220:	mov    rcx,rsi
  410223:	mov    rdx,QWORD PTR [rsp+0x18]
  410228:	mov    r8,rdi
  41022b:	call   410160 <__swc_fn_7dafa2b1_000101_d4bdcaa4>
  410230:	mov    rcx,QWORD PTR [rbx+0x28]
  410234:	call   40c040 <__swc_fn_7dafa2b1_000103_e34f54dc>
  410239:	mov    rcx,rsi
  41023c:	mov    rdx,rbx
  41023f:	mov    r8d,0x30
  410245:	call   410160 <__swc_fn_7dafa2b1_000101_d4bdcaa4>
  41024a:	add    rsp,0x30
  41024e:	pop    rdi
  41024f:	pop    rsi
  410250:	pop    rbx
  410251:	ret
	...

0000000000410260 <__swc_fn_7dafa2b1_000107_ffe51047>:
  410260:	push   rbp
  410261:	push   rbx
  410262:	push   rsi
  410263:	push   rdi
  410264:	push   r12
  410266:	push   r13
  410268:	push   r14
  41026a:	push   r15
  41026c:	sub    rsp,0x500
  410273:	mov    rbp,rsp
  410276:	mov    rbx,rsp
  410279:	mov    rsi,rdx
  41027c:	mov    rdi,rcx
  41027f:	mov    rcx,QWORD PTR [rip+0x12dba]        # 423040 <__swc_bss_base_7dafa2b1>
  410286:	test   rcx,rcx
  410289:	jne    4102a3 <__swc_fn_7dafa2b1_000107_ffe51047+0x43>
  41028b:	sub    rsp,0x8
  41028f:	call   4119a0 <__swc_fn_7dafa2b1_000170_994c8876>
  410294:	add    rsp,0x8
  410298:	lea    rcx,[rax+0x1]
  41029c:	mov    QWORD PTR [rip+0x12d9d],rcx        # 423040 <__swc_bss_base_7dafa2b1>
  4102a3:	dec    rcx
  4102a6:	sub    rsp,0x8
  4102aa:	call   40e840 <__swc_fn_7dafa2b1_000172_360af05d>
  4102af:	add    rsp,0x8
  4102b3:	mov    r12,rax
  4102b6:	mov    QWORD PTR [rsp+0x4f0],rax
  4102be:	lea    rax,[rip+0x215b]        # 412420 <__swc_rdata_base_7dafa2b1+0x310>
  4102c5:	sub    rsp,0x20
  4102c9:	mov    rcx,rsp
  4102cc:	mov    QWORD PTR [rcx],rax
  4102cf:	lea    r13,[rip+0x1e4a]        # 412120 <__swc_rdata_base_7dafa2b1+0x10>
  4102d6:	mov    QWORD PTR [rcx+0x8],r13
  4102da:	mov    QWORD PTR [rcx+0x10],rsp
  4102de:	mov    QWORD PTR [rcx+0x18],0x1
  4102e6:	lea    rcx,[rsp+0x10]
  4102eb:	sub    rsp,0x8
  4102ef:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  4102f4:	add    rsp,0x8
  4102f8:	add    rsp,0x20
  4102fc:	lea    rax,[rip+0x212d]        # 412430 <__swc_rdata_base_7dafa2b1+0x320>
  410303:	sub    rsp,0x20
  410307:	mov    rcx,rsp
  41030a:	mov    QWORD PTR [rcx],rax
  41030d:	mov    QWORD PTR [rcx+0x8],r13
  410311:	mov    QWORD PTR [rcx+0x10],rsp
  410315:	mov    QWORD PTR [rcx+0x18],0x1
  41031d:	lea    rcx,[rsp+0x10]
  410322:	sub    rsp,0x8
  410326:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  41032b:	add    rsp,0x8
  41032f:	add    rsp,0x20
  410333:	lea    r14,[rip+0x1dd6]        # 412110 <__swc_rdata_base_7dafa2b1>
  41033a:	sub    rsp,0x50
  41033e:	mov    rax,rsp
  410341:	vmovups xmm0,XMMWORD PTR [rip+0x221f]        # 412568 <__swc_rdata_base_7dafa2b1+0x458>
  410349:	vmovups XMMWORD PTR [rax],xmm0
  41034d:	mov    QWORD PTR [rax+0x10],rsp
  410351:	mov    QWORD PTR [rax+0x18],r13
  410355:	mov    QWORD PTR [rax+0x20],rdi
  410359:	lea    rdi,[rip+0x20e0]        # 412440 <__swc_rdata_base_7dafa2b1+0x330>
  410360:	mov    QWORD PTR [rax+0x28],rdi
  410364:	mov    QWORD PTR [rax+0x30],r14
  410368:	mov    QWORD PTR [rax+0x38],r13
  41036c:	lea    rcx,[rsp+0x10]
  410371:	mov    QWORD PTR [rax+0x40],rcx
  410375:	mov    QWORD PTR [rax+0x48],0x3
  41037d:	lea    rcx,[rsp+0x40]
  410382:	sub    rsp,0x8
  410386:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  41038b:	add    rsp,0x8
  41038f:	add    rsp,0x50
  410393:	lea    rax,[rip+0x20ee]        # 412488 <__swc_rdata_base_7dafa2b1+0x378>
  41039a:	sub    rsp,0x20
  41039e:	mov    rcx,rsp
  4103a1:	mov    QWORD PTR [rcx],rax
  4103a4:	mov    QWORD PTR [rcx+0x8],r13
  4103a8:	mov    QWORD PTR [rcx+0x10],rsp
  4103ac:	mov    QWORD PTR [rcx+0x18],0x1
  4103b4:	lea    rcx,[rsp+0x10]
  4103b9:	sub    rsp,0x8
  4103bd:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  4103c2:	add    rsp,0x8
  4103c6:	add    rsp,0x20
  4103ca:	mov    eax,DWORD PTR [rsi+0x20]
  4103cd:	mov    ecx,DWORD PTR [rsi+0x24]
  4103d0:	sub    rsp,0xa0
  4103d7:	mov    rdx,rsp
  4103da:	mov    QWORD PTR [rdx+0x30],rsi
  4103de:	mov    QWORD PTR [rdx+0x38],rdi
  4103e2:	vmovups xmm0,XMMWORD PTR [rip+0x2116]        # 412500 <__swc_rdata_base_7dafa2b1+0x3f0>
  4103ea:	vmovups XMMWORD PTR [rdx],xmm0
  4103ee:	mov    QWORD PTR [rdx+0x40],rsp
  4103f2:	mov    QWORD PTR [rdx+0x48],r13
  4103f6:	mov    DWORD PTR [rdx+0x10],eax
  4103f9:	lea    rax,[rsp+0x10]
  4103fe:	mov    QWORD PTR [rdx+0x50],rax
  410402:	lea    rax,[rip+0x208f]        # 412498 <__swc_rdata_base_7dafa2b1+0x388>
  410409:	mov    QWORD PTR [rdx+0x58],rax
  41040d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  410412:	lea    r8,[rsp+0x18]
  410417:	mov    QWORD PTR [rdx+0x60],r8
  41041b:	mov    QWORD PTR [rdx+0x68],r13
  41041f:	mov    DWORD PTR [rdx+0x28],ecx
  410422:	lea    rcx,[rdx+0x28]
  410426:	mov    QWORD PTR [rdx+0x70],rcx
  41042a:	mov    QWORD PTR [rdx+0x78],rax
  41042e:	mov    QWORD PTR [rdx+0x80],r14
  410435:	mov    QWORD PTR [rdx+0x88],r13
  41043c:	lea    rax,[rdx+0x30]
  410440:	mov    QWORD PTR [rdx+0x90],rax
  410447:	mov    QWORD PTR [rdx+0x98],0x6
  410452:	lea    rcx,[rdx+0x90]
  410459:	sub    rsp,0x8
  41045d:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  410462:	add    rsp,0x8
  410466:	add    rsp,0xa0
  41046d:	sub    rsp,0x20
  410471:	mov    rax,rsp
  410474:	mov    QWORD PTR [rax],r14
  410477:	mov    QWORD PTR [rax+0x8],r13
  41047b:	mov    QWORD PTR [rax+0x10],rsp
  41047f:	mov    QWORD PTR [rax+0x18],0x1
  410487:	lea    rcx,[rsp+0x10]
  41048c:	sub    rsp,0x8
  410490:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  410495:	add    rsp,0x8
  410499:	add    rsp,0x20
  41049d:	mov    eax,DWORD PTR [r12+0x9ac]
  4104a5:	test   eax,eax
  4104a7:	je     4106e0 <__swc_fn_7dafa2b1_000107_ffe51047+0x480>
  4104ad:	lea    rax,[rip+0x202c]        # 4124e0 <__swc_rdata_base_7dafa2b1+0x3d0>
  4104b4:	sub    rsp,0x20
  4104b8:	mov    rcx,rsp
  4104bb:	mov    QWORD PTR [rcx],rax
  4104be:	mov    QWORD PTR [rcx+0x8],r13
  4104c2:	mov    QWORD PTR [rcx+0x10],rsp
  4104c6:	mov    QWORD PTR [rcx+0x18],0x1
  4104ce:	lea    rcx,[rsp+0x10]
  4104d3:	sub    rsp,0x8
  4104d7:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  4104dc:	add    rsp,0x8
  4104e0:	add    rsp,0x20
  4104e4:	mov    eax,DWORD PTR [r12+0x9ac]
  4104ec:	dec    eax
  4104ee:	mov    esi,eax
  4104f0:	test   esi,esi
  4104f2:	jl     4106b0 <__swc_fn_7dafa2b1_000107_ffe51047+0x450>
  4104f8:	jmp    410504 <__swc_fn_7dafa2b1_000107_ffe51047+0x2a4>
  4104fa:	nop    WORD PTR [rax+rax*1+0x0]
  410500:	dec    esi
  410502:	jmp    4104f0 <__swc_fn_7dafa2b1_000107_ffe51047+0x290>
  410504:	lea    rax,[rip+0x1fe5]        # 4124f0 <__swc_rdata_base_7dafa2b1+0x3e0>
  41050b:	sub    rsp,0x20
  41050f:	mov    rcx,rsp
  410512:	mov    QWORD PTR [rcx],rax
  410515:	mov    QWORD PTR [rcx+0x8],r13
  410519:	mov    QWORD PTR [rcx+0x10],rsp
  41051d:	mov    QWORD PTR [rcx+0x18],0x1
  410525:	lea    rcx,[rsp+0x10]
  41052a:	sub    rsp,0x8
  41052e:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  410533:	add    rsp,0x8
  410537:	add    rsp,0x20
  41053b:	movsxd rax,esi
  41053e:	imul   r15,rax,0x30
  410542:	add    r15,r12
  410545:	add    r15,0xf8
  41054c:	sub    rsp,0x20
  410550:	mov    rax,rsp
  410553:	mov    QWORD PTR [rax],r15
  410556:	mov    QWORD PTR [rax+0x8],rdi
  41055a:	mov    QWORD PTR [rax+0x10],rsp
  41055e:	mov    QWORD PTR [rax+0x18],0x1
  410566:	lea    rcx,[rsp+0x10]
  41056b:	sub    rsp,0x8
  41056f:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  410574:	add    rsp,0x8
  410578:	add    rsp,0x20
  41057c:	mov    QWORD PTR [rsp+0x4f8],rsi
  410584:	lea    rsi,[rip+0x1f75]        # 412500 <__swc_rdata_base_7dafa2b1+0x3f0>
  41058b:	sub    rsp,0x20
  41058f:	mov    rax,rsp
  410592:	mov    QWORD PTR [rax],rsi
  410595:	mov    QWORD PTR [rax+0x8],r13
  410599:	mov    QWORD PTR [rax+0x10],rsp
  41059d:	mov    QWORD PTR [rax+0x18],0x1
  4105a5:	lea    rcx,[rsp+0x10]
  4105aa:	sub    rsp,0x8
  4105ae:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  4105b3:	add    rsp,0x8
  4105b7:	add    rsp,0x20
  4105bb:	sub    rsp,0x30
  4105bf:	mov    rax,rsp
  4105c2:	mov    ecx,DWORD PTR [r15+0x20]
  4105c6:	mov    QWORD PTR [rax],rcx
  4105c9:	mov    QWORD PTR [rax+0x8],rsp
  4105cd:	lea    rdi,[rip+0x1f3c]        # 412510 <__swc_rdata_base_7dafa2b1+0x400>
  4105d4:	mov    QWORD PTR [rax+0x10],rdi
  4105d8:	lea    rcx,[rsp+0x8]
  4105dd:	mov    QWORD PTR [rax+0x18],rcx
  4105e1:	mov    QWORD PTR [rax+0x20],0x1
  4105e9:	lea    rcx,[rsp+0x18]
  4105ee:	sub    rsp,0x8
  4105f2:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  4105f7:	add    rsp,0x8
  4105fb:	add    rsp,0x30
  4105ff:	sub    rsp,0x20
  410603:	mov    rax,rsp
  410606:	mov    QWORD PTR [rax],rsi
  410609:	mov    QWORD PTR [rax+0x8],r13
  41060d:	mov    QWORD PTR [rax+0x10],rsp
  410611:	mov    QWORD PTR [rax+0x18],0x1
  410619:	lea    rcx,[rsp+0x10]
  41061e:	sub    rsp,0x8
  410622:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  410627:	add    rsp,0x8
  41062b:	add    rsp,0x20
  41062f:	sub    rsp,0x30
  410633:	mov    rax,rsp
  410636:	mov    ecx,DWORD PTR [r15+0x24]
  41063a:	mov    QWORD PTR [rax],rcx
  41063d:	mov    QWORD PTR [rax+0x8],rsp
  410641:	mov    QWORD PTR [rax+0x10],rdi
  410645:	lea    rcx,[rsp+0x8]
  41064a:	mov    QWORD PTR [rax+0x18],rcx
  41064e:	mov    QWORD PTR [rax+0x20],0x1
  410656:	lea    rcx,[rsp+0x18]
  41065b:	sub    rsp,0x8
  41065f:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  410664:	add    rsp,0x8
  410668:	add    rsp,0x30
  41066c:	sub    rsp,0x20
  410670:	mov    rax,rsp
  410673:	mov    QWORD PTR [rax],r14
  410676:	mov    QWORD PTR [rax+0x8],r13
  41067a:	mov    QWORD PTR [rax+0x10],rsp
  41067e:	mov    QWORD PTR [rax+0x18],0x1
  410686:	lea    rcx,[rsp+0x10]
  41068b:	sub    rsp,0x8
  41068f:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  410694:	add    rsp,0x8
  410698:	add    rsp,0x20
  41069c:	lea    rdi,[rip+0x1d9d]        # 412440 <__swc_rdata_base_7dafa2b1+0x330>
  4106a3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  4106ab:	jmp    410500 <__swc_fn_7dafa2b1_000107_ffe51047+0x2a0>
  4106b0:	sub    rsp,0x20
  4106b4:	mov    rax,rsp
  4106b7:	mov    QWORD PTR [rax],r14
  4106ba:	mov    QWORD PTR [rax+0x8],r13
  4106be:	mov    QWORD PTR [rax+0x10],rsp
  4106c2:	mov    QWORD PTR [rax+0x18],0x1
  4106ca:	lea    rcx,[rsp+0x10]
  4106cf:	sub    rsp,0x8
  4106d3:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  4106d8:	add    rsp,0x8
  4106dc:	add    rsp,0x20
  4106e0:	lea    rax,[rbx+0x28]
  4106e4:	mov    rcx,rax
  4106e7:	mov    QWORD PTR [rbx+0x28],0x0
  4106ef:	mov    QWORD PTR [rbx+0x30],0x0
  4106f7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  4106fc:	add    rcx,0x10
  410700:	mov    edx,0x1f
  410705:	cs nop WORD PTR [rax+rax*1+0x0]
  41070f:	nop
  410710:	vmovups XMMWORD PTR [rcx],xmm0
  410714:	add    rcx,0x10
  410718:	sub    rdx,0x1
  41071c:	jne    410710 <__swc_fn_7dafa2b1_000107_ffe51047+0x4b0>
  41071e:	lea    rsi,[rbx+0x228]
  410725:	xor    ecx,ecx
  410727:	cs nop WORD PTR [rax+rax*1+0x0]
  410731:	cs nop WORD PTR [rax+rax*1+0x0]
  41073b:	nop    DWORD PTR [rax+rax*1+0x0]
  410740:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  410745:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  41074a:	add    rcx,0x10
  41074e:	cmp    rcx,0x200
  410755:	jne    410740 <__swc_fn_7dafa2b1_000107_ffe51047+0x4e0>
  410757:	mov    eax,DWORD PTR [r12+0xbc8]
  41075f:	lea    rcx,[r12+0x9c8]
  410767:	mov    QWORD PTR [rbx+0x428],rcx
  41076e:	mov    QWORD PTR [rbx+0x430],rax
  410775:	lea    rdi,[rbx+0x438]
  41077c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  410784:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  41078c:	mov    eax,DWORD PTR [r12+0xbc8]
  410794:	test   eax,eax
  410796:	jne    4107e3 <__swc_fn_7dafa2b1_000107_ffe51047+0x583>
  410798:	lea    rax,[rbx+0x448]
  41079f:	mov    QWORD PTR [rbx+0x448],rsi
  4107a6:	mov    QWORD PTR [rax+0x8],0x40
  4107ae:	mov    ecx,0x1
  4107b3:	mov    rdx,rax
  4107b6:	sub    rsp,0x8
  4107ba:	call   40cba0 <__swc_fn_7dafa2b1_000124_4f256d58>
  4107bf:	add    rsp,0x8
  4107c3:	mov    QWORD PTR [rbx+0x460],rsi
  4107ca:	mov    ecx,eax
  4107cc:	mov    QWORD PTR [rbx+0x468],rcx
  4107d3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  4107db:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  4107e3:	mov    rsi,QWORD PTR [rbx+0x438]
  4107ea:	mov    rax,QWORD PTR [rbx+0x440]
  4107f1:	mov    r15,rax
  4107f4:	xor    r12d,r12d
  4107f7:	test   r15,r15
  4107fa:	je     4108b0 <__swc_fn_7dafa2b1_000107_ffe51047+0x650>
  410800:	mov    rax,QWORD PTR [rsi+r12*8]
  410804:	test   rax,rax
  410807:	je     410826 <__swc_fn_7dafa2b1_000107_ffe51047+0x5c6>
  410809:	lea    rcx,[rbx+0x4b8]
  410810:	mov    rdx,rax
  410813:	sub    rsp,0x8
  410817:	call   411710 <__swc_fn_7dafa2b1_000167_cc119975>
  41081c:	add    rsp,0x8
  410820:	mov    al,BYTE PTR [rax]
  410822:	test   al,al
  410824:	jne    410832 <__swc_fn_7dafa2b1_000107_ffe51047+0x5d2>
  410826:	add    r12,0x1
  41082a:	sub    r15,0x1
  41082e:	jne    410800 <__swc_fn_7dafa2b1_000107_ffe51047+0x5a0>
  410830:	jmp    4108b0 <__swc_fn_7dafa2b1_000107_ffe51047+0x650>
  410832:	lea    rax,[rip+0x1d1f]        # 412558 <__swc_rdata_base_7dafa2b1+0x448>
  410839:	sub    rsp,0x20
  41083d:	mov    rcx,rsp
  410840:	mov    QWORD PTR [rcx],rax
  410843:	mov    QWORD PTR [rcx+0x8],r13
  410847:	mov    QWORD PTR [rcx+0x10],rsp
  41084b:	mov    QWORD PTR [rcx+0x18],0x1
  410853:	lea    rcx,[rsp+0x10]
  410858:	sub    rsp,0x8
  41085c:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  410861:	add    rsp,0x8
  410865:	add    rsp,0x20
  410869:	mov    rcx,rdi
  41086c:	xor    edx,edx
  41086e:	mov    al,0x1
  410870:	mov    r8,rax
  410873:	sub    rsp,0x8
  410877:	call   40a300 <__swc_fn_7dafa2b1_000168_bcc835b8>
  41087c:	add    rsp,0x8
  410880:	sub    rsp,0x20
  410884:	mov    rax,rsp
  410887:	mov    QWORD PTR [rax],r14
  41088a:	mov    QWORD PTR [rax+0x8],r13
  41088e:	mov    QWORD PTR [rax+0x10],rsp
  410892:	mov    QWORD PTR [rax+0x18],0x1
  41089a:	lea    rcx,[rsp+0x10]
  41089f:	sub    rsp,0x8
  4108a3:	call   40d300 <__swc_fn_7dafa2b1_000151_6203dca2>
  4108a8:	add    rsp,0x8
  4108ac:	add    rsp,0x20
  4108b0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4108b8:	mov    DWORD PTR [r12+0xbc8],0x0
  4108c4:	add    rsp,0x500
  4108cb:	pop    r15
  4108cd:	pop    r14
  4108cf:	pop    r13
  4108d1:	pop    r12
  4108d3:	pop    rdi
  4108d4:	pop    rsi
  4108d5:	pop    rbx
  4108d6:	pop    rbp
  4108d7:	ret
	...

00000000004108e0 <__swc_fn_7dafa2b1_000110_7c204aac>:
  4108e0:	sub    rsp,0x8
  4108e4:	test   r8,r8
  4108e7:	je     4108ee <__swc_fn_7dafa2b1_000110_7c204aac+0xe>
  4108e9:	call   40c2d0 <__swc_fn_7dafa2b1_000109_c51c3158>
  4108ee:	add    rsp,0x8
  4108f2:	ret
	...

0000000000410900 <__swc_fn_7dafa2b1_000113_126150d1>:
  410900:	push   rsi
  410901:	push   rdi
  410902:	push   r12
  410904:	push   r13
  410906:	sub    rsp,0xd8
  41090d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  410913:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  410919:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  41091f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  410925:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  41092b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  410934:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  41093d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  410946:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  41094f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  410958:	xor    eax,eax
  41095a:	call   4070f0 <getpid@plt>
  41095f:	mov    rsi,rax
  410962:	lea    rdi,[rip+0x153d7]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  410969:	mov    r12,QWORD PTR [rdi]
  41096c:	test   r12,r12
  41096f:	je     41097d <__swc_fn_7dafa2b1_000113_126150d1+0x7d>
  410971:	cmp    DWORD PTR [r12+0x10],esi
  410976:	jne    41097d <__swc_fn_7dafa2b1_000113_126150d1+0x7d>
  410978:	mov    rax,r12
  41097b:	jmp    4109e0 <__swc_fn_7dafa2b1_000113_126150d1+0xe0>
  41097d:	mov    ecx,0x4
  410982:	mov    edx,0x18
  410987:	call   40c3b0 <__swc_fn_7dafa2b1_000112_6814119b>
  41098c:	mov    rcx,rax
  41098f:	test   rax,rax
  410992:	jne    410998 <__swc_fn_7dafa2b1_000113_126150d1+0x98>
  410994:	xor    eax,eax
  410996:	jmp    4109e0 <__swc_fn_7dafa2b1_000113_126150d1+0xe0>
  410998:	mov    DWORD PTR [rcx+0x10],esi
  41099b:	mov    rax,r12
  41099e:	lock cmpxchg QWORD PTR [rdi],rcx
  4109a3:	mov    r13,rax
  4109a6:	cmp    rax,r12
  4109a9:	je     4109bf <__swc_fn_7dafa2b1_000113_126150d1+0xbf>
  4109ab:	mov    rdi,rcx
  4109ae:	mov    esi,0x18
  4109b3:	xor    eax,eax
  4109b5:	call   407030 <munmap@plt>
  4109ba:	mov    rax,r13
  4109bd:	jmp    4109e0 <__swc_fn_7dafa2b1_000113_126150d1+0xe0>
  4109bf:	test   r12,r12
  4109c2:	je     4109dd <__swc_fn_7dafa2b1_000113_126150d1+0xdd>
  4109c4:	mov    rdi,r12
  4109c7:	mov    esi,0x18
  4109cc:	xor    eax,eax
  4109ce:	mov    QWORD PTR [rsp+0x28],rcx
  4109d3:	call   407030 <munmap@plt>
  4109d8:	mov    rcx,QWORD PTR [rsp+0x28]
  4109dd:	mov    rax,rcx
  4109e0:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4109e6:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4109ec:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4109f2:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4109f8:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4109fe:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  410a07:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  410a10:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  410a19:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  410a22:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  410a2b:	add    rsp,0xd8
  410a32:	pop    r13
  410a34:	pop    r12
  410a36:	pop    rdi
  410a37:	pop    rsi
  410a38:	ret
  410a39:	add    BYTE PTR [rax],al
  410a3b:	add    BYTE PTR [rax],al
  410a3d:	add    BYTE PTR [rax],al
	...

0000000000410a40 <__swc_fn_7dafa2b1_000116_36905703>:
  410a40:	push   rbx
  410a41:	push   r12
  410a43:	push   rdi
  410a44:	push   rsi
  410a45:	sub    rsp,0xa8
  410a4c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  410a52:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410a58:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  410a5e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410a64:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410a6a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  410a70:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410a76:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410a7c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410a85:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  410a8e:	mov    rbx,rdx
  410a91:	mov    r12,rcx
  410a94:	mov    rdi,rcx
  410a97:	mov    rsi,rdx
  410a9a:	mov    edx,0x3
  410a9f:	xor    eax,eax
  410aa1:	call   407020 <mprotect@plt>
  410aa6:	test   eax,eax
  410aa8:	je     410aae <__swc_fn_7dafa2b1_000116_36905703+0x6e>
  410aaa:	xor    eax,eax
  410aac:	jmp    410ac3 <__swc_fn_7dafa2b1_000116_36905703+0x83>
  410aae:	mov    rcx,r12
  410ab1:	mov    rdx,rbx
  410ab4:	mov    al,0x1
  410ab6:	mov    r8,rax
  410ab9:	call   40c9e0 <__swc_fn_7dafa2b1_000115_5f48311c>
  410abe:	mov    eax,0x1
  410ac3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410ac9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410acf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410ad5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410adb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410ae1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410ae7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410aed:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410af3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410afc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410b05:	add    rsp,0xa8
  410b0c:	pop    rsi
  410b0d:	pop    rdi
  410b0e:	pop    r12
  410b10:	pop    rbx
  410b11:	ret
	...

0000000000410b20 <__swc_fn_7dafa2b1_000119_5208f471>:
  410b20:	sub    rsp,0x8
  410b24:	test   rcx,rcx
  410b27:	jne    410b2e <__swc_fn_7dafa2b1_000119_5208f471+0xe>
  410b29:	add    rsp,0x8
  410b2d:	ret
  410b2e:	call   409920 <__swc_fn_7dafa2b1_000120_d3318640>
  410b33:	add    rsp,0x8
  410b37:	ret
	...

0000000000410b40 <__swc_fn_7dafa2b1_000122_0a5fa85a>:
  410b40:	push   rdi
  410b41:	push   rsi
  410b42:	sub    rsp,0xa8
  410b49:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  410b4f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410b55:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  410b5b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410b61:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410b67:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  410b6d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410b73:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410b79:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410b82:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  410b8b:	xor    edi,edi
  410b8d:	xor    eax,eax
  410b8f:	call   407050 <exit@plt>
  410b94:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410b9a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410ba0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410ba6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410bac:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410bb2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410bb8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410bbe:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410bc4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410bcd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410bd6:	add    rsp,0xa8
  410bdd:	pop    rsi
  410bde:	pop    rdi
  410bdf:	ret

0000000000410be0 <__swc_fn_7dafa2b1_000125_83db7238>:
  410be0:	push   rbx
  410be1:	push   rsi
  410be2:	push   rdi
  410be3:	push   r12
  410be5:	sub    rsp,0x18
  410be9:	mov    rbx,r8
  410bec:	mov    rsi,rcx
  410bef:	mov    rdi,rdx
  410bf2:	mov    rcx,QWORD PTR [rip+0x12447]        # 423040 <__swc_bss_base_7dafa2b1>
  410bf9:	test   rcx,rcx
  410bfc:	jne    410c0e <__swc_fn_7dafa2b1_000125_83db7238+0x2e>
  410bfe:	call   4119a0 <__swc_fn_7dafa2b1_000170_994c8876>
  410c03:	lea    rcx,[rax+0x1]
  410c07:	mov    QWORD PTR [rip+0x12432],rcx        # 423040 <__swc_bss_base_7dafa2b1>
  410c0e:	dec    rcx
  410c11:	call   40e840 <__swc_fn_7dafa2b1_000172_360af05d>
  410c16:	mov    r12,rax
  410c19:	cmp    ebx,0x3
  410c1c:	jne    410c2f <__swc_fn_7dafa2b1_000125_83db7238+0x4f>
  410c1e:	mov    rax,QWORD PTR [r12+0xbd0]
  410c26:	test   rax,rax
  410c29:	jne    410d6c <__swc_fn_7dafa2b1_000125_83db7238+0x18c>
  410c2f:	cmp    ebx,0x5
  410c32:	jne    410c56 <__swc_fn_7dafa2b1_000125_83db7238+0x76>
  410c34:	call   4091f0 <__swc_fn_7dafa2b1_000096_ad13d15c>
  410c39:	test   al,al
  410c3b:	jne    410c56 <__swc_fn_7dafa2b1_000125_83db7238+0x76>
  410c3d:	mov    rcx,rsi
  410c40:	mov    rdx,rdi
  410c43:	call   40e7f0 <__swc_fn_7dafa2b1_000169_3459066f>
  410c48:	test   al,al
  410c4a:	je     410c56 <__swc_fn_7dafa2b1_000125_83db7238+0x76>
  410c4c:	add    rsp,0x18
  410c50:	pop    r12
  410c52:	pop    rdi
  410c53:	pop    rsi
  410c54:	pop    rbx
  410c55:	ret
  410c56:	call   4091f0 <__swc_fn_7dafa2b1_000096_ad13d15c>
  410c5b:	test   al,al
  410c5d:	jne    410ccf <__swc_fn_7dafa2b1_000125_83db7238+0xef>
  410c5f:	vmovups xmm0,XMMWORD PTR [rsi]
  410c63:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410c69:	mov    rax,QWORD PTR [rsp+0x8]
  410c6e:	test   rax,rax
  410c71:	jne    410cc2 <__swc_fn_7dafa2b1_000125_83db7238+0xe2>
  410c73:	cmp    ebx,0x3
  410c76:	je     410c84 <__swc_fn_7dafa2b1_000125_83db7238+0xa4>
  410c78:	cmp    ebx,0x4
  410c7b:	je     410c94 <__swc_fn_7dafa2b1_000125_83db7238+0xb4>
  410c7d:	cmp    ebx,0x5
  410c80:	je     410ca4 <__swc_fn_7dafa2b1_000125_83db7238+0xc4>
  410c82:	jmp    410cb4 <__swc_fn_7dafa2b1_000125_83db7238+0xd4>
  410c84:	vmovups xmm0,XMMWORD PTR [rip+0x191c]        # 4125a8 <__swc_rdata_base_7dafa2b1+0x498>
  410c8c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410c92:	jmp    410cc2 <__swc_fn_7dafa2b1_000125_83db7238+0xe2>
  410c94:	vmovups xmm0,XMMWORD PTR [rip+0x191c]        # 4125b8 <__swc_rdata_base_7dafa2b1+0x4a8>
  410c9c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410ca2:	jmp    410cc2 <__swc_fn_7dafa2b1_000125_83db7238+0xe2>
  410ca4:	vmovups xmm0,XMMWORD PTR [rip+0x191c]        # 4125c8 <__swc_rdata_base_7dafa2b1+0x4b8>
  410cac:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410cb2:	jmp    410cc2 <__swc_fn_7dafa2b1_000125_83db7238+0xe2>
  410cb4:	vmovups xmm0,XMMWORD PTR [rip+0x191c]        # 4125d8 <__swc_rdata_base_7dafa2b1+0x4c8>
  410cbc:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410cc2:	lea    rcx,[rsp+0x8]
  410cc7:	mov    rdx,rdi
  410cca:	call   409440 <__swc_fn_7dafa2b1_000108_90faaa26>
  410ccf:	vmovups xmm0,XMMWORD PTR [rdi]
  410cd3:	vmovups XMMWORD PTR [r12+0x940],xmm0
  410cdd:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  410ce2:	vmovups XMMWORD PTR [r12+0x950],xmm0
  410cec:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  410cf1:	vmovups XMMWORD PTR [r12+0x960],xmm0
  410cfb:	lea    rax,[r12+0x940]
  410d03:	mov    QWORD PTR [r12+0x970],rax
  410d0b:	mov    rax,QWORD PTR [rsi]
  410d0e:	mov    QWORD PTR [r12+0x978],rax
  410d16:	mov    rax,QWORD PTR [rsi+0x8]
  410d1a:	mov    QWORD PTR [r12+0x980],rax
  410d22:	movsxd rax,ebx
  410d25:	mov    QWORD PTR [r12+0x988],rax
  410d2d:	cmp    ebx,0x5
  410d30:	je     410d39 <__swc_fn_7dafa2b1_000125_83db7238+0x159>
  410d32:	xor    ecx,ecx
  410d34:	call   411ad0 <__swc_fn_7dafa2b1_000179_718d7b54>
  410d39:	mov    rbx,QWORD PTR [r12+0xbe8]
  410d41:	test   rbx,rbx
  410d44:	je     410d55 <__swc_fn_7dafa2b1_000125_83db7238+0x175>
  410d46:	mov    rcx,r12
  410d49:	call   rbx
  410d4b:	add    rsp,0x18
  410d4f:	pop    r12
  410d51:	pop    rdi
  410d52:	pop    rsi
  410d53:	pop    rbx
  410d54:	ret
  410d55:	mov    rcx,rsi
  410d58:	call   40ca90 <__swc_fn_7dafa2b1_000121_2648f149>
  410d5d:	call   409a70 <__swc_fn_7dafa2b1_000123_be2e2f68>
  410d62:	add    rsp,0x18
  410d66:	pop    r12
  410d68:	pop    rdi
  410d69:	pop    rsi
  410d6a:	pop    rbx
  410d6b:	ret
  410d6c:	mov    rcx,rsi
  410d6f:	mov    rdx,rdi
  410d72:	call   409440 <__swc_fn_7dafa2b1_000108_90faaa26>
  410d77:	jmp    410c2f <__swc_fn_7dafa2b1_000125_83db7238+0x4f>
  410d7c:	add    BYTE PTR [rax],al
	...

0000000000410d80 <__swc_fn_7dafa2b1_000128_58f0f391>:
  410d80:	push   rdi
  410d81:	push   rsi
  410d82:	sub    rsp,0xb8
  410d89:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410d8f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410d95:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  410d9b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410da1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410da7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  410dad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410db3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  410dbc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410dc5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  410dce:	mov    DWORD PTR [rsp+0x8],0x0
  410dd6:	lea    rdi,[rsp+0x8]
  410ddb:	xor    esi,esi
  410ddd:	xor    eax,eax
  410ddf:	call   4071e0 <pthread_key_create@plt>
  410de4:	test   eax,eax
  410de6:	jne    410dee <__swc_fn_7dafa2b1_000128_58f0f391+0x6e>
  410de8:	mov    eax,DWORD PTR [rsp+0x8]
  410dec:	jmp    410df5 <__swc_fn_7dafa2b1_000128_58f0f391+0x75>
  410dee:	mov    rax,0xffffffffffffffff
  410df5:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410dfb:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410e01:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410e07:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410e0d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410e13:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  410e19:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410e1f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  410e28:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410e31:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410e3a:	add    rsp,0xb8
  410e41:	pop    rsi
  410e42:	pop    rdi
  410e43:	ret
	...

0000000000410e50 <__swc_fn_7dafa2b1_000131_4a82cdf6>:
  410e50:	push   rdi
  410e51:	push   rsi
  410e52:	sub    rsp,0xb8
  410e59:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410e5f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410e65:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  410e6b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410e71:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410e77:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  410e7d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410e83:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  410e8c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410e95:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  410e9e:	mov    DWORD PTR [rsp+0x8],0x0
  410ea6:	lea    rdi,[rsp+0x8]
  410eab:	mov    rsi,rcx
  410eae:	xor    eax,eax
  410eb0:	call   4071e0 <pthread_key_create@plt>
  410eb5:	test   eax,eax
  410eb7:	jne    410ec2 <__swc_fn_7dafa2b1_000131_4a82cdf6+0x72>
  410eb9:	mov    eax,DWORD PTR [rsp+0x8]
  410ebd:	inc    rax
  410ec0:	jmp    410ec4 <__swc_fn_7dafa2b1_000131_4a82cdf6+0x74>
  410ec2:	xor    eax,eax
  410ec4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410eca:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410ed0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410ed6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410edc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410ee2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  410ee8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410eee:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  410ef7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410f00:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410f09:	add    rsp,0xb8
  410f10:	pop    rsi
  410f11:	pop    rdi
  410f12:	ret
	...

0000000000410f20 <__swc_fn_7dafa2b1_000134_ae5891af>:
  410f20:	push   rdi
  410f21:	push   rsi
  410f22:	sub    rsp,0xa8
  410f29:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  410f2f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410f35:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  410f3b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410f41:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410f47:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  410f4d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410f53:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410f59:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410f62:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  410f6b:	test   rcx,rcx
  410f6e:	setne  al
  410f71:	je     410f8a <__swc_fn_7dafa2b1_000134_ae5891af+0x6a>
  410f73:	lea    rax,[rcx-0x1]
  410f77:	mov    eax,eax
  410f79:	mov    edi,eax
  410f7b:	mov    rsi,rdx
  410f7e:	xor    eax,eax
  410f80:	call   4071b0 <pthread_setspecific@plt>
  410f85:	test   eax,eax
  410f87:	sete   al
  410f8a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410f90:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410f96:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410f9c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410fa2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410fa8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410fae:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410fb4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410fba:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410fc3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410fcc:	add    rsp,0xa8
  410fd3:	pop    rsi
  410fd4:	pop    rdi
  410fd5:	ret
	...

0000000000410fe0 <__swc_fn_7dafa2b1_000137_865f5106>:
  410fe0:	push   rdi
  410fe1:	push   rsi
  410fe2:	sub    rsp,0xa8
  410fe9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  410fef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410ff5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  410ffb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411001:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411007:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41100d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411013:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411019:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411022:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41102b:	mov    rax,rdx
  41102e:	mov    QWORD PTR [rsp],0x0
  411036:	mov    edi,0xca
  41103b:	mov    rsi,rcx
  41103e:	mov    edx,0x81
  411043:	mov    eax,eax
  411045:	mov    ecx,eax
  411047:	xor    r8d,r8d
  41104a:	xor    r9d,r9d
  41104d:	xor    eax,eax
  41104f:	call   407080 <syscall@plt>
  411054:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41105a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411060:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411066:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41106c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411072:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411078:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41107e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411084:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41108d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411096:	add    rsp,0xa8
  41109d:	pop    rsi
  41109e:	pop    rdi
  41109f:	ret

00000000004110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>:
  4110a0:	sub    rsp,0x8
  4110a4:	call   409e10 <__swc_fn_7dafa2b1_000138_8c07c14b>
  4110a9:	add    rsp,0x8
  4110ad:	ret
	...

00000000004110b0 <__swc_fn_7dafa2b1_000143_be4c2719>:
  4110b0:	push   rdi
  4110b1:	push   rsi
  4110b2:	sub    rsp,0xc8
  4110b9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4110bf:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4110c5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4110cb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4110d1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4110d7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4110dd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  4110e6:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  4110ef:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  4110f8:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  411101:	vxorps xmm0,xmm0,xmm0
  411105:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  41110b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  411111:	mov    rdi,rcx
  411114:	lea    rsi,[rsp+0x8]
  411119:	xor    eax,eax
  41111b:	call   4071f0 <dladdr@plt>
  411120:	xor    ecx,ecx
  411122:	test   eax,eax
  411124:	je     41112b <__swc_fn_7dafa2b1_000143_be4c2719+0x7b>
  411126:	mov    rcx,QWORD PTR [rsp+0x10]
  41112b:	mov    rax,rcx
  41112e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  411134:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  41113a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411140:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411146:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  41114c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411152:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  41115b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411164:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  41116d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411176:	add    rsp,0xc8
  41117d:	pop    rsi
  41117e:	pop    rdi
  41117f:	ret

0000000000411180 <__swc_fn_7dafa2b1_000146_1534de9a>:
  411180:	push   rbx
  411181:	push   r12
  411183:	push   r13
  411185:	push   rdi
  411186:	push   rsi
  411187:	push   r14
  411189:	push   r15
  41118b:	sub    rsp,0x150
  411192:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  41119b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4111a4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4111ad:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4111b6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4111bf:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4111c8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4111d1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4111da:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  4111e3:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  4111ec:	mov    rbx,rdx
  4111ef:	mov    QWORD PTR [rsp+0x98],rdx
  4111f7:	mov    r12,rcx
  4111fa:	mov    QWORD PTR [rsp+0xa0],rcx
  411202:	mov    QWORD PTR [rbx],0x0
  411209:	lea    r13,[rip+0x14b68]        # 425d78 <__swc_bss_base_7dafa2b1+0x2d38>
  411210:	mov    rcx,r13
  411213:	call   4110a0 <__swc_fn_7dafa2b1_000140_86bb0f90>
  411218:	mov    rax,QWORD PTR [rip+0x14b61]        # 425d80 <__swc_bss_base_7dafa2b1+0x2d40>
  41121f:	test   rax,rax
  411222:	je     411259 <__swc_fn_7dafa2b1_000146_1534de9a+0xd9>
  411224:	cs nop WORD PTR [rax+rax*1+0x0]
  41122e:	xchg   ax,ax
  411230:	cmp    QWORD PTR [rax+0x8],r12
  411234:	jne    411251 <__swc_fn_7dafa2b1_000146_1534de9a+0xd1>
  411236:	mov    rcx,QWORD PTR [rax+0x18]
  41123a:	mov    QWORD PTR [rbx],rcx
  41123d:	mov    rbx,QWORD PTR [rax+0x10]
  411241:	mov    rcx,r13
  411244:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  411249:	mov    rax,rbx
  41124c:	jmp    41143b <__swc_fn_7dafa2b1_000146_1534de9a+0x2bb>
  411251:	mov    rax,QWORD PTR [rax]
  411254:	test   rax,rax
  411257:	jne    411230 <__swc_fn_7dafa2b1_000146_1534de9a+0xb0>
  411259:	vxorps xmm0,xmm0,xmm0
  41125d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  411263:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  411269:	mov    rdi,r12
  41126c:	lea    rsi,[rsp+0x10]
  411271:	xor    eax,eax
  411273:	call   4071f0 <dladdr@plt>
  411278:	test   eax,eax
  41127a:	sete   al
  41127d:	je     41128a <__swc_fn_7dafa2b1_000146_1534de9a+0x10a>
  41127f:	mov    rax,QWORD PTR [rsp+0x10]
  411284:	test   rax,rax
  411287:	sete   al
  41128a:	test   al,al
  41128c:	je     41129d <__swc_fn_7dafa2b1_000146_1534de9a+0x11d>
  41128e:	mov    rcx,r13
  411291:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  411296:	xor    eax,eax
  411298:	jmp    41143b <__swc_fn_7dafa2b1_000146_1534de9a+0x2bb>
  41129d:	mov    rdi,QWORD PTR [rsp+0x10]
  4112a2:	mov    esi,0x80000
  4112a7:	xor    eax,eax
  4112a9:	call   4070b0 <open@plt>
  4112ae:	lea    r14,[rsp+0x30]
  4112b3:	mov    DWORD PTR [rsp+0x30],eax
  4112b7:	cmp    DWORD PTR [r14],0x0
  4112bb:	jge    4112cc <__swc_fn_7dafa2b1_000146_1534de9a+0x14c>
  4112bd:	mov    rcx,r13
  4112c0:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  4112c5:	xor    eax,eax
  4112c7:	jmp    41143b <__swc_fn_7dafa2b1_000146_1534de9a+0x2bb>
  4112cc:	mov    rax,r14
  4112cf:	movsxd rdi,DWORD PTR [rax]
  4112d2:	xor    esi,esi
  4112d4:	mov    edx,0x2
  4112d9:	xor    eax,eax
  4112db:	call   407160 <lseek@plt>
  4112e0:	mov    r15,rax
  4112e3:	test   rax,rax
  4112e6:	jg     411301 <__swc_fn_7dafa2b1_000146_1534de9a+0x181>
  4112e8:	movsxd rdi,DWORD PTR [r14]
  4112eb:	xor    eax,eax
  4112ed:	call   4070e0 <close@plt>
  4112f2:	mov    rcx,r13
  4112f5:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  4112fa:	xor    eax,eax
  4112fc:	jmp    41143b <__swc_fn_7dafa2b1_000146_1534de9a+0x2bb>
  411301:	xor    edi,edi
  411303:	mov    rsi,r15
  411306:	mov    edx,0x1
  41130b:	mov    ecx,0x2
  411310:	mov    rax,r14
  411313:	movsxd r8,DWORD PTR [rax]
  411316:	xor    r9d,r9d
  411319:	xor    eax,eax
  41131b:	call   407010 <mmap@plt>
  411320:	mov    rbx,rax
  411323:	test   rax,rax
  411326:	sete   al
  411329:	cmp    rbx,0xffffffffffffffff
  41132d:	sete   cl
  411330:	or     al,cl
  411332:	je     41134d <__swc_fn_7dafa2b1_000146_1534de9a+0x1cd>
  411334:	movsxd rdi,DWORD PTR [r14]
  411337:	xor    eax,eax
  411339:	call   4070e0 <close@plt>
  41133e:	mov    rcx,r13
  411341:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  411346:	xor    eax,eax
  411348:	jmp    41143b <__swc_fn_7dafa2b1_000146_1534de9a+0x2bb>
  41134d:	lea    rax,[rsp+0x50]
  411352:	mov    QWORD PTR [rax],0x0
  411359:	mov    rcx,rbx
  41135c:	mov    rdx,r15
  41135f:	mov    r8,rax
  411362:	call   40d020 <__swc_fn_7dafa2b1_000145_d5d4d43f>
  411367:	mov    r12,rax
  41136a:	test   rax,rax
  41136d:	jne    411395 <__swc_fn_7dafa2b1_000146_1534de9a+0x215>
  41136f:	mov    rdi,rbx
  411372:	mov    rsi,r15
  411375:	xor    eax,eax
  411377:	call   407030 <munmap@plt>
  41137c:	movsxd rdi,DWORD PTR [r14]
  41137f:	xor    eax,eax
  411381:	call   4070e0 <close@plt>
  411386:	mov    rcx,r13
  411389:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  41138e:	xor    eax,eax
  411390:	jmp    41143b <__swc_fn_7dafa2b1_000146_1534de9a+0x2bb>
  411395:	mov    edi,0x20
  41139a:	xor    eax,eax
  41139c:	call   407090 <malloc@plt>
  4113a1:	test   rax,rax
  4113a4:	jne    4113c9 <__swc_fn_7dafa2b1_000146_1534de9a+0x249>
  4113a6:	mov    rdi,rbx
  4113a9:	mov    rsi,r15
  4113ac:	xor    eax,eax
  4113ae:	call   407030 <munmap@plt>
  4113b3:	movsxd rdi,DWORD PTR [r14]
  4113b6:	xor    eax,eax
  4113b8:	call   4070e0 <close@plt>
  4113bd:	mov    rcx,r13
  4113c0:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  4113c5:	xor    eax,eax
  4113c7:	jmp    41143b <__swc_fn_7dafa2b1_000146_1534de9a+0x2bb>
  4113c9:	mov    rcx,QWORD PTR [rip+0x149b0]        # 425d80 <__swc_bss_base_7dafa2b1+0x2d40>
  4113d0:	mov    QWORD PTR [rsp+0x70],rcx
  4113d5:	mov    rcx,QWORD PTR [rsp+0xa0]
  4113dd:	mov    QWORD PTR [rsp+0x78],rcx
  4113e2:	mov    QWORD PTR [rsp+0x80],r12
  4113ea:	mov    rcx,QWORD PTR [rsp+0x50]
  4113ef:	mov    QWORD PTR [rsp+0x88],rcx
  4113f7:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  4113fd:	vmovups XMMWORD PTR [rax],xmm0
  411401:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  41140a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  41140f:	mov    QWORD PTR [rip+0x1496a],rax        # 425d80 <__swc_bss_base_7dafa2b1+0x2d40>
  411416:	mov    rax,QWORD PTR [rsp+0x50]
  41141b:	mov    rbx,QWORD PTR [rsp+0x98]
  411423:	mov    QWORD PTR [rbx],rax
  411426:	movsxd rdi,DWORD PTR [r14]
  411429:	xor    eax,eax
  41142b:	call   4070e0 <close@plt>
  411430:	mov    rcx,r13
  411433:	call   409f10 <__swc_fn_7dafa2b1_000141_055b38a4>
  411438:	mov    rax,r12
  41143b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  411444:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  41144d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  411456:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  41145f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  411468:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  411471:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  41147a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  411483:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  41148c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  411495:	add    rsp,0x150
  41149c:	pop    r15
  41149e:	pop    r14
  4114a0:	pop    rsi
  4114a1:	pop    rdi
  4114a2:	pop    r13
  4114a4:	pop    r12
  4114a6:	pop    rbx
  4114a7:	ret
	...

00000000004114b0 <__swc_fn_7dafa2b1_000149_43c96957>:
  4114b0:	push   rbx
  4114b1:	sub    rsp,0xe0
  4114b8:	lea    rbx,[rsp+0x8]
  4114bd:	vxorps xmm0,xmm0,xmm0
  4114c1:	vmovups YMMWORD PTR [rbx],ymm0
  4114c5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  4114ca:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  4114cf:	vzeroupper
  4114d2:	mov    DWORD PTR [rbx+0x60],0x0
  4114d9:	mov    r8,rbx
  4114dc:	nop    DWORD PTR [rax+0x0]
  4114e0:	mov    r9,rcx
  4114e3:	movabs rcx,0xcccccccccccccccd
  4114ed:	mov    rax,r9
  4114f0:	mul    rcx
  4114f3:	mov    r10,rdx
  4114f6:	shr    r10,0x3
  4114fa:	mov    rcx,r10
  4114fd:	imul   rdx,r10,0xa
  411501:	sub    r9,rdx
  411504:	mov    rdx,QWORD PTR [rip+0x10fd]        # 412608 <__swc_rdata_base_7dafa2b1+0x4f8>
  41150b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  411510:	mov    BYTE PTR [r8],dl
  411513:	lea    rdx,[r8+0x1]
  411517:	mov    r8,rdx
  41151a:	test   r10,r10
  41151d:	jne    4114e0 <__swc_fn_7dafa2b1_000149_43c96957+0x30>
  41151f:	mov    BYTE PTR [rdx],0x0
  411522:	sub    r8,0x1
  411526:	mov    rax,rbx
  411529:	cmp    rax,r8
  41152c:	jae    411546 <__swc_fn_7dafa2b1_000149_43c96957+0x96>
  41152e:	xchg   ax,ax
  411530:	mov    cl,BYTE PTR [r8]
  411533:	mov    dl,BYTE PTR [rax]
  411535:	mov    BYTE PTR [r8],dl
  411538:	sub    r8,0x1
  41153c:	mov    BYTE PTR [rax],cl
  41153e:	inc    rax
  411541:	cmp    rax,r8
  411544:	jb     411530 <__swc_fn_7dafa2b1_000149_43c96957+0x80>
  411546:	xor    eax,eax
  411548:	test   rbx,rbx
  41154b:	je     41156e <__swc_fn_7dafa2b1_000149_43c96957+0xbe>
  41154d:	mov    rcx,rbx
  411550:	mov    dl,BYTE PTR [rcx]
  411552:	test   dl,dl
  411554:	je     41156e <__swc_fn_7dafa2b1_000149_43c96957+0xbe>
  411556:	cs nop WORD PTR [rax+rax*1+0x0]
  411560:	add    rcx,0x1
  411564:	add    rax,0x1
  411568:	mov    dl,BYTE PTR [rcx]
  41156a:	test   dl,dl
  41156c:	jne    411560 <__swc_fn_7dafa2b1_000149_43c96957+0xb0>
  41156e:	mov    QWORD PTR [rbx+0xa8],rbx
  411575:	mov    QWORD PTR [rbx+0xb0],rax
  41157c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  411584:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  41158c:	lea    rcx,[rbx+0xb8]
  411593:	call   40ca90 <__swc_fn_7dafa2b1_000121_2648f149>
  411598:	add    rsp,0xe0
  41159f:	pop    rbx
  4115a0:	ret
	...

00000000004115b0 <__swc_fn_7dafa2b1_000152_6fb05988>:
  4115b0:	sub    rsp,0x8
  4115b4:	mov    rax,QWORD PTR [rcx+0x8]
  4115b8:	mov    r8,QWORD PTR [rdx+0x8]
  4115bc:	cmp    rax,r8
  4115bf:	je     4115c8 <__swc_fn_7dafa2b1_000152_6fb05988+0x18>
  4115c1:	xor    eax,eax
  4115c3:	add    rsp,0x8
  4115c7:	ret
  4115c8:	test   rax,rax
  4115cb:	jne    4115dc <__swc_fn_7dafa2b1_000152_6fb05988+0x2c>
  4115cd:	test   r8,r8
  4115d0:	jne    4115dc <__swc_fn_7dafa2b1_000152_6fb05988+0x2c>
  4115d2:	mov    eax,0x1
  4115d7:	add    rsp,0x8
  4115db:	ret
  4115dc:	mov    rcx,QWORD PTR [rcx]
  4115df:	mov    rdx,QWORD PTR [rdx]
  4115e2:	test   rcx,rcx
  4115e5:	sete   r8b
  4115e9:	test   rdx,rdx
  4115ec:	sete   r9b
  4115f0:	or     r8b,r9b
  4115f3:	je     411600 <__swc_fn_7dafa2b1_000152_6fb05988+0x50>
  4115f5:	cmp    rcx,rdx
  4115f8:	sete   al
  4115fb:	add    rsp,0x8
  4115ff:	ret
  411600:	cmp    rcx,rdx
  411603:	jne    41160f <__swc_fn_7dafa2b1_000152_6fb05988+0x5f>
  411605:	mov    eax,0x1
  41160a:	add    rsp,0x8
  41160e:	ret
  41160f:	mov    r8,rax
  411612:	call   409500 <__swc_fn_7dafa2b1_000111_3dc01326>
  411617:	test   eax,eax
  411619:	sete   al
  41161c:	add    rsp,0x8
  411620:	ret
	...

0000000000411630 <__swc_fn_7dafa2b1_000155_86f1d437>:
  411630:	vxorps xmm0,xmm0,xmm0
  411634:	vmovups XMMWORD PTR [rcx],xmm0
  411638:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41163d:	vxorps xmm0,xmm0,xmm0
  411641:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411646:	vmovups xmm0,XMMWORD PTR [rip+0x107a]        # 4126c8 <__swc_rdata_base_7dafa2b1+0x5b8>
  41164e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411653:	ret
	...

0000000000411660 <__swc_fn_7dafa2b1_000158_86f1d437>:
  411660:	vxorps xmm0,xmm0,xmm0
  411664:	vmovups XMMWORD PTR [rcx],xmm0
  411668:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41166d:	vxorps xmm0,xmm0,xmm0
  411671:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411676:	vmovups xmm0,XMMWORD PTR [rip+0x116a]        # 4127e8 <__swc_rdata_base_7dafa2b1+0x6d8>
  41167e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411683:	mov    QWORD PTR [rcx+0x40],0x0
  41168b:	ret
  41168c:	add    BYTE PTR [rax],al
	...

0000000000411690 <__swc_fn_7dafa2b1_000161_47b270e1>:
  411690:	push   rbx
  411691:	sub    rsp,0x70
  411695:	mov    rax,QWORD PTR [rcx]
  411698:	mov    rbx,QWORD PTR [rcx+0x8]
  41169c:	vxorps xmm0,xmm0,xmm0
  4116a0:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  4116a6:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  4116ac:	vzeroupper
  4116af:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  4116b5:	mov    QWORD PTR [rsp+0x48],rdx
  4116ba:	mov    QWORD PTR [rsp+0x50],r8
  4116bf:	mov    rcx,rax
  4116c2:	lea    rdx,[rsp+0x8]
  4116c7:	mov    rbx,QWORD PTR [rbx+0x18]
  4116cb:	call   rbx
  4116cd:	add    rsp,0x70
  4116d1:	pop    rbx
  4116d2:	ret
	...

00000000004116e0 <__swc_fn_7dafa2b1_000164_8a3d304f>:
  4116e0:	push   rbx
  4116e1:	push   rsi
  4116e2:	push   rdi
  4116e3:	mov    rbx,r8
  4116e6:	mov    rsi,rcx
  4116e9:	mov    rdi,rdx
  4116ec:	call   40a210 <__swc_fn_7dafa2b1_000162_13ead2ff>
  4116f1:	vmovups xmm0,XMMWORD PTR [rbx]
  4116f5:	vmovups XMMWORD PTR [rsi],xmm0
  4116f9:	mov    QWORD PTR [rsi+0x18],rdi
  4116fd:	pop    rdi
  4116fe:	pop    rsi
  4116ff:	pop    rbx
  411700:	ret
	...

0000000000411710 <__swc_fn_7dafa2b1_000167_cc119975>:
  411710:	push   rbx
  411711:	push   rsi
  411712:	push   rdi
  411713:	push   r12
  411715:	push   r13
  411717:	sub    rsp,0x50
  41171b:	mov    rbx,rcx
  41171e:	mov    rsi,rdx
  411721:	vmovups xmm0,XMMWORD PTR [rip+0x11cf]        # 4128f8 <__swc_rdata_base_7dafa2b1+0x7e8>
  411729:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  41172f:	vmovups xmm0,XMMWORD PTR [rip+0x11d1]        # 412908 <__swc_rdata_base_7dafa2b1+0x7f8>
  411737:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  41173d:	vxorps xmm0,xmm0,xmm0
  411741:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  411747:	mov    rcx,rdx
  41174a:	call   4110b0 <__swc_fn_7dafa2b1_000143_be4c2719>
  41174f:	mov    rdi,rax
  411752:	test   rax,rax
  411755:	jne    411786 <__swc_fn_7dafa2b1_000167_cc119975+0x76>
  411757:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  41175d:	vmovups XMMWORD PTR [rbx],xmm0
  411761:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411767:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  41176c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411772:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411777:	mov    rax,rbx
  41177a:	add    rsp,0x50
  41177e:	pop    r13
  411780:	pop    r12
  411782:	pop    rdi
  411783:	pop    rsi
  411784:	pop    rbx
  411785:	ret
  411786:	mov    rcx,rdi
  411789:	call   40e540 <__swc_fn_7dafa2b1_000166_016ee66a>
  41178e:	mov    r11,rax
  411791:	test   rax,rax
  411794:	je     41179e <__swc_fn_7dafa2b1_000167_cc119975+0x8e>
  411796:	mov    al,BYTE PTR [r11+0x24]
  41179a:	test   al,al
  41179c:	jne    4117cd <__swc_fn_7dafa2b1_000167_cc119975+0xbd>
  41179e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4117a4:	vmovups XMMWORD PTR [rbx],xmm0
  4117a8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  4117ae:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  4117b3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  4117b9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  4117be:	mov    rax,rbx
  4117c1:	add    rsp,0x50
  4117c5:	pop    r13
  4117c7:	pop    r12
  4117c9:	pop    rdi
  4117ca:	pop    rsi
  4117cb:	pop    rbx
  4117cc:	ret
  4117cd:	sub    rsi,rdi
  4117d0:	mov    eax,0xffffffff
  4117d5:	cmp    rsi,rax
  4117d8:	jbe    411809 <__swc_fn_7dafa2b1_000167_cc119975+0xf9>
  4117da:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4117e0:	vmovups XMMWORD PTR [rbx],xmm0
  4117e4:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  4117ea:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  4117ef:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  4117f5:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  4117fa:	mov    rax,rbx
  4117fd:	add    rsp,0x50
  411801:	pop    r13
  411803:	pop    r12
  411805:	pop    rdi
  411806:	pop    rsi
  411807:	pop    rbx
  411808:	ret
  411809:	mov    rdi,QWORD PTR [r11+0x10]
  41180d:	mov    eax,DWORD PTR [r11+0x20]
  411811:	xor    ecx,ecx
  411813:	test   rax,rax
  411816:	jbe    411968 <__swc_fn_7dafa2b1_000167_cc119975+0x258>
  41181c:	nop    DWORD PTR [rax+0x0]
  411820:	mov    edx,ecx
  411822:	imul   r12,rdx,0x14
  411826:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  41182b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  411830:	mov    r9d,esi
  411833:	cmp    r9,rdx
  411836:	jb     41195b <__swc_fn_7dafa2b1_000167_cc119975+0x24b>
  41183c:	add    rdx,r8
  41183f:	mov    r8d,esi
  411842:	cmp    r8,rdx
  411845:	jae    41195b <__swc_fn_7dafa2b1_000167_cc119975+0x24b>
  41184b:	lea    rsi,[rsp+0x38]
  411850:	mov    eax,DWORD PTR [rdi+0xc]
  411853:	mov    DWORD PTR [rsp+0x38],eax
  411857:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  41185c:	mov    rcx,rdi
  41185f:	mov    rdx,QWORD PTR [r11+0x18]
  411863:	mov    r8,rsi
  411866:	mov    r8d,DWORD PTR [r8]
  411869:	mov    r9,rax
  41186c:	lea    r10,[rsp+0x10]
  411871:	call   40a260 <__swc_fn_7dafa2b1_000165_72795826>
  411876:	test   al,al
  411878:	jne    4118ab <__swc_fn_7dafa2b1_000167_cc119975+0x19b>
  41187a:	vmovups xmm0,XMMWORD PTR [rip+0x10a6]        # 412928 <__swc_rdata_base_7dafa2b1+0x818>
  411882:	vmovups XMMWORD PTR [rbx],xmm0
  411886:	vmovups xmm0,XMMWORD PTR [rip+0x10aa]        # 412938 <__swc_rdata_base_7dafa2b1+0x828>
  41188e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411893:	vxorps xmm0,xmm0,xmm0
  411897:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  41189c:	mov    rax,rbx
  41189f:	add    rsp,0x50
  4118a3:	pop    r13
  4118a5:	pop    r12
  4118a7:	pop    rdi
  4118a8:	pop    rsi
  4118a9:	pop    rbx
  4118aa:	ret
  4118ab:	lea    r13,[rsp+0x3c]
  4118b0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  4118b5:	mov    DWORD PTR [rsp+0x3c],eax
  4118b9:	test   eax,eax
  4118bb:	je     41190c <__swc_fn_7dafa2b1_000167_cc119975+0x1fc>
  4118bd:	mov    rcx,rdi
  4118c0:	mov    rdx,QWORD PTR [r11+0x18]
  4118c4:	mov    r8d,DWORD PTR [rsi]
  4118c7:	mov    rax,r13
  4118ca:	mov    r9d,DWORD PTR [rax]
  4118cd:	lea    r10,[rsp+0x20]
  4118d2:	call   40a260 <__swc_fn_7dafa2b1_000165_72795826>
  4118d7:	test   al,al
  4118d9:	jne    41190c <__swc_fn_7dafa2b1_000167_cc119975+0x1fc>
  4118db:	vmovups xmm0,XMMWORD PTR [rip+0x1075]        # 412958 <__swc_rdata_base_7dafa2b1+0x848>
  4118e3:	vmovups XMMWORD PTR [rbx],xmm0
  4118e7:	vmovups xmm0,XMMWORD PTR [rip+0x1079]        # 412968 <__swc_rdata_base_7dafa2b1+0x858>
  4118ef:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  4118f4:	vxorps xmm0,xmm0,xmm0
  4118f8:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  4118fd:	mov    rax,rbx
  411900:	add    rsp,0x50
  411904:	pop    r13
  411906:	pop    r12
  411908:	pop    rdi
  411909:	pop    rsi
  41190a:	pop    rbx
  41190b:	ret
  41190c:	mov    eax,0x1
  411911:	rex mov BYTE PTR [rsp+0x8],al
  411916:	cmp    DWORD PTR [r13+0x0],0x0
  41191b:	je     41192c <__swc_fn_7dafa2b1_000167_cc119975+0x21c>
  41191d:	rex mov BYTE PTR [rsp+0x9],0x1
  411923:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  411928:	mov    DWORD PTR [rsp+0x30],eax
  41192c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  411932:	vmovups XMMWORD PTR [rbx],xmm0
  411936:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  41193c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411941:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411947:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  41194c:	mov    rax,rbx
  41194f:	add    rsp,0x50
  411953:	pop    r13
  411955:	pop    r12
  411957:	pop    rdi
  411958:	pop    rsi
  411959:	pop    rbx
  41195a:	ret
  41195b:	add    rcx,0x1
  41195f:	cmp    rcx,rax
  411962:	jb     411820 <__swc_fn_7dafa2b1_000167_cc119975+0x110>
  411968:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  41196e:	vmovups XMMWORD PTR [rbx],xmm0
  411972:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411978:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  41197d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411983:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411988:	mov    rax,rbx
  41198b:	add    rsp,0x50
  41198f:	pop    r13
  411991:	pop    r12
  411993:	pop    rdi
  411994:	pop    rsi
  411995:	pop    rbx
  411996:	ret
	...

00000000004119a0 <__swc_fn_7dafa2b1_000170_994c8876>:
  4119a0:	sub    rsp,0x48
  4119a4:	call   410d80 <__swc_fn_7dafa2b1_000128_58f0f391>
  4119a9:	cmp    rax,0xffffffffffffffff
  4119ad:	je     4119b4 <__swc_fn_7dafa2b1_000170_994c8876+0x14>
  4119af:	add    rsp,0x48
  4119b3:	ret
  4119b4:	lea    rcx,[rip+0xfdd]        # 412998 <__swc_rdata_base_7dafa2b1+0x888>
  4119bb:	vmovups xmm0,XMMWORD PTR [rip+0xfe5]        # 4129a8 <__swc_rdata_base_7dafa2b1+0x898>
  4119c3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4119c9:	vmovups xmm0,XMMWORD PTR [rip+0xfe7]        # 4129b8 <__swc_rdata_base_7dafa2b1+0x8a8>
  4119d1:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4119d7:	vmovups xmm0,XMMWORD PTR [rip+0xfe9]        # 4129c8 <__swc_rdata_base_7dafa2b1+0x8b8>
  4119df:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  4119e5:	lea    rdx,[rsp+0x8]
  4119ea:	mov    QWORD PTR [rsp+0x38],rax
  4119ef:	call   409440 <__swc_fn_7dafa2b1_000108_90faaa26>
  4119f4:	mov    rax,QWORD PTR [rsp+0x38]
  4119f9:	jmp    4119af <__swc_fn_7dafa2b1_000170_994c8876+0xf>
  4119fb:	add    BYTE PTR [rax],al
  4119fd:	add    BYTE PTR [rax],al
	...

0000000000411a00 <__swc_fn_7dafa2b1_000173_cbeff767>:
  411a00:	push   rbx
  411a01:	push   rsi
  411a02:	sub    rsp,0x28
  411a06:	mov    rbx,rcx
  411a09:	mov    DWORD PTR [rsp+0x8],0xbf0
  411a11:	mov    ecx,0xbf0
  411a16:	call   409030 <__swc_fn_7dafa2b1_000084_4a10c7e7>
  411a1b:	mov    rsi,rax
  411a1e:	test   rax,rax
  411a21:	jne    411a2c <__swc_fn_7dafa2b1_000173_cbeff767+0x2c>
  411a23:	xor    eax,eax
  411a25:	add    rsp,0x28
  411a29:	pop    rsi
  411a2a:	pop    rbx
  411a2b:	ret
  411a2c:	vxorps xmm0,xmm0,xmm0
  411a30:	xor    eax,eax
  411a32:	cs nop WORD PTR [rax+rax*1+0x0]
  411a3c:	nop    DWORD PTR [rax+0x0]
  411a40:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  411a45:	add    rax,0x10
  411a49:	cmp    rax,0xbf0
  411a50:	jne    411a40 <__swc_fn_7dafa2b1_000173_cbeff767+0x40>
  411a52:	lea    rax,[rbx+0x1]
  411a56:	mov    QWORD PTR [rsi+0x9c0],rax
  411a5d:	mov    rcx,rbx
  411a60:	mov    rdx,rsi
  411a63:	call   40a5c0 <__swc_fn_7dafa2b1_000171_646fdf20>
  411a68:	test   al,al
  411a6a:	jne    411a7d <__swc_fn_7dafa2b1_000173_cbeff767+0x7d>
  411a6c:	mov    rcx,rsi
  411a6f:	call   40ba10 <__swc_fn_7dafa2b1_000085_cf82995a>
  411a74:	xor    eax,eax
  411a76:	add    rsp,0x28
  411a7a:	pop    rsi
  411a7b:	pop    rbx
  411a7c:	ret
  411a7d:	lea    rcx,[rsp+0x18]
  411a82:	call   40bf90 <__swc_fn_7dafa2b1_000097_93bfe675>
  411a87:	mov    rax,rsi
  411a8a:	add    rsp,0x28
  411a8e:	pop    rsi
  411a8f:	pop    rbx
  411a90:	ret
	...

0000000000411aa0 <__swc_fn_7dafa2b1_000176_e09f8b62>:
  411aa0:	xor    eax,eax
  411aa2:	mov    edx,0x1
  411aa7:	lock cmpxchg QWORD PTR [rcx],rdx
  411aac:	test   rax,rax
  411aaf:	jne    411ab2 <__swc_fn_7dafa2b1_000176_e09f8b62+0x12>
  411ab1:	ret
  411ab2:	cs nop WORD PTR [rax+rax*1+0x0]
  411abc:	nop    DWORD PTR [rax+0x0]
  411ac0:	mov    rax,QWORD PTR [rcx]
  411ac3:	test   rax,rax
  411ac6:	je     411aa0 <__swc_fn_7dafa2b1_000176_e09f8b62>
  411ac8:	jmp    411ac0 <__swc_fn_7dafa2b1_000176_e09f8b62+0x20>
  411aca:	add    BYTE PTR [rax],al
  411acc:	add    BYTE PTR [rax],al
	...

0000000000411ad0 <__swc_fn_7dafa2b1_000179_718d7b54>:
  411ad0:	push   rsi
  411ad1:	push   rdi
  411ad2:	sub    rsp,0x38
  411ad6:	mov    rsi,rcx
  411ad9:	call   40a5d0 <__swc_fn_7dafa2b1_000174_1e0ea8cf>
  411ade:	mov    rdi,rax
  411ae1:	call   409d60 <__swc_fn_7dafa2b1_000135_a9c1c700>
  411ae6:	mov    r8,rax
  411ae9:	mov    rcx,rdi
  411aec:	call   411aa0 <__swc_fn_7dafa2b1_000176_e09f8b62>
  411af1:	mov    rax,QWORD PTR [rdi+0x8]
  411af5:	test   rax,rax
  411af8:	je     411b35 <__swc_fn_7dafa2b1_000179_718d7b54+0x65>
  411afa:	nop    WORD PTR [rax+rax*1+0x0]
  411b00:	cmp    rax,rsi
  411b03:	je     411b35 <__swc_fn_7dafa2b1_000179_718d7b54+0x65>
  411b05:	mov    r9,QWORD PTR [rax]
  411b08:	cmp    QWORD PTR [rax+0x20],r8
  411b0c:	jne    411b2d <__swc_fn_7dafa2b1_000179_718d7b54+0x5d>
  411b0e:	mov    rcx,rdi
  411b11:	mov    rdx,rax
  411b14:	mov    QWORD PTR [rsp+0x28],r8
  411b19:	mov    QWORD PTR [rsp+0x30],r9
  411b1e:	call   40e960 <__swc_fn_7dafa2b1_000178_cf4ffedd>
  411b23:	mov    r8,QWORD PTR [rsp+0x28]
  411b28:	mov    r9,QWORD PTR [rsp+0x30]
  411b2d:	mov    rax,r9
  411b30:	test   r9,r9
  411b33:	jne    411b00 <__swc_fn_7dafa2b1_000179_718d7b54+0x30>
  411b35:	xor    eax,eax
  411b37:	mov    QWORD PTR [rdi],rax
  411b3a:	add    rsp,0x38
  411b3e:	pop    rdi
  411b3f:	pop    rsi
  411b40:	ret
