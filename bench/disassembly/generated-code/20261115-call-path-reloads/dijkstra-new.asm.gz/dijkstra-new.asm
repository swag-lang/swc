
/workspace/prompt2-20261115/batch9-audited-micro/new/dijkstra/dijkstra:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <open@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <open@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <flock@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <flock@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <__errno_location@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <__errno_location@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <close@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <close@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <getpid@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <getpid@GLIBC_2.2.5>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <opendir@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <opendir@GLIBC_2.2.5>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <dirfd@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <dirfd@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <readdir@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <readdir@GLIBC_2.2.5>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <readlinkat@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <readlinkat@GLIBC_2.4>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <openat@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <openat@GLIBC_2.4>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <closedir@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <closedir@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <lseek@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <lseek@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <mmap@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <mmap@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <memfd_create@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <memfd_create@GLIBC_2.27>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <ftruncate@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf8a]        # 413080 <ftruncate@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <write@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf82]        # 413088 <write@GLIBC_2.2.5>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <backtrace@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf7a]        # 413090 <backtrace@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <pthread_setspecific@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf72]        # 413098 <pthread_setspecific@GLIBC_2.34>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <clock_gettime@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf6a]        # 4130a0 <clock_gettime@GLIBC_2.17>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <__x86_get_cpuid_feature_leaf@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf62]        # 4130a8 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <free@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf5a]        # 4130b0 <free@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <munmap@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf52]        # 4130b8 <munmap@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <mprotect@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf4a]        # 4130c0 <mprotect@GLIBC_2.2.5>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <exit@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf42]        # 4130c8 <exit@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <pthread_key_create@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf3a]        # 4130d0 <pthread_key_create@GLIBC_2.34>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <syscall@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf32]        # 4130d8 <syscall@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <dladdr@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130e0 <dladdr@GLIBC_2.34>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <malloc@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf22]        # 4130e8 <malloc@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <madvise@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <madvise@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <pthread_key_delete@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <pthread_key_delete@GLIBC_2.34>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <gettid@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <gettid@GLIBC_2.30>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_7069e055_000176_4de704de+0xfa0>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   411560 <__swc_fn_7069e055_000125_540bf7e8>
  40724e:	xor    ecx,ecx
  407250:	call   410c80 <__swc_fn_7069e055_000098_4f209617>
  407255:	call   407320 <__swc_fn_7069e055_000003_fa681d0f>
  40725a:	call   409330 <__swc_fn_7069e055_000099_65137b72>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_7069e055_000000_2744b483>:
  407270:	push   rbx
  407271:	sub    rsp,0x70
  407275:	cmp    rcx,0xffffffffffffffef
  407279:	jbe    407283 <__swc_fn_7069e055_000000_2744b483+0x13>
  40727b:	xor    eax,eax
  40727d:	add    rsp,0x70
  407281:	pop    rbx
  407282:	ret
  407283:	vxorps xmm0,xmm0,xmm0
  407287:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40728d:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  407293:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  407299:	vzeroupper
  40729c:	lea    rax,[rcx+0x10]
  4072a0:	mov    QWORD PTR [rsp+0x50],rax
  4072a5:	mov    DWORD PTR [rsp+0x60],0x10
  4072ad:	mov    rcx,QWORD PTR [rip+0x1cd8c]        # 424040 <__swc_bss_base_7069e055>
  4072b4:	test   rcx,rcx
  4072b7:	jne    4072c9 <__swc_fn_7069e055_000000_2744b483+0x59>
  4072b9:	call   40ec80 <__swc_fn_7069e055_000169_994c8876>
  4072be:	lea    rcx,[rax+0x1]
  4072c2:	mov    QWORD PTR [rip+0x1cd77],rcx        # 424040 <__swc_bss_base_7069e055>
  4072c9:	dec    rcx
  4072cc:	call   40bb40 <__swc_fn_7069e055_000171_360af05d>
  4072d1:	mov    rcx,QWORD PTR [rax]
  4072d4:	lea    rdx,[rsp+0x8]
  4072d9:	mov    rbx,QWORD PTR [rax+0x8]
  4072dd:	mov    rbx,QWORD PTR [rbx+0x8]
  4072e1:	call   rbx
  4072e3:	mov    rax,QWORD PTR [rsp+0x48]
  4072e8:	test   rax,rax
  4072eb:	jne    4072f5 <__swc_fn_7069e055_000000_2744b483+0x85>
  4072ed:	xor    eax,eax
  4072ef:	add    rsp,0x70
  4072f3:	pop    rbx
  4072f4:	ret
  4072f5:	mov    rcx,QWORD PTR [rsp+0x50]
  4072fa:	mov    QWORD PTR [rax],rcx
  4072fd:	mov    QWORD PTR [rax+0x8],0x0
  407305:	lea    rax,[rax+0x10]
  407309:	add    rsp,0x70
  40730d:	pop    rbx
  40730e:	ret
	...

0000000000407320 <__swc_fn_7069e055_000003_fa681d0f>:
  407320:	push   rbp
  407321:	push   rsi
  407322:	push   r15
  407324:	push   r14
  407326:	push   r13
  407328:	push   rdi
  407329:	push   r12
  40732b:	sub    rsp,0x18
  40732f:	mov    rbp,rsp
  407332:	vmovups XMMWORD PTR [rsp],xmm6
  407337:	sub    rsp,0x1b0
  40733e:	mov    ecx,0x4e2000
  407343:	sub    rsp,0x8
  407347:	call   407270 <__swc_fn_7069e055_000000_2744b483>
  40734c:	add    rsp,0x8
  407350:	mov    rsi,rax
  407353:	xor    ecx,ecx
  407355:	cs nop WORD PTR [rax+rax*1+0x0]
  40735f:	nop
  407360:	lea    r8,[rsi+rcx*8]
  407364:	mov    r9,QWORD PTR [rip+0x1ac95]        # 422000 <__swc_data_base_7069e055>
  40736b:	imul   r9,r9,0x41a7
  407372:	movabs rdx,0x200000005
  40737c:	mov    r11,rax
  40737f:	mov    rax,r9
  407382:	mul    rdx
  407385:	mov    r10,rdx
  407388:	mov    rdx,r9
  40738b:	sub    rdx,r10
  40738e:	shr    rdx,1
  407391:	add    rdx,r10
  407394:	shr    rdx,0x1e
  407398:	imul   r10,rdx,0x7fffffff
  40739f:	sub    r9,r10
  4073a2:	mov    QWORD PTR [rip+0x1ac57],r9        # 422000 <__swc_data_base_7069e055>
  4073a9:	movabs rdx,0xe38e38e38e38e38f
  4073b3:	mov    rax,r9
  4073b6:	mul    rdx
  4073b9:	shr    rdx,0x3
  4073bd:	lea    rdx,[rdx+rdx*8]
  4073c1:	sub    r9,rdx
  4073c4:	lea    rdx,[r9+0x1]
  4073c8:	mov    QWORD PTR [r8],rdx
  4073cb:	add    rcx,0x1
  4073cf:	lea    r8,[rsi+rcx*8]
  4073d3:	mov    r9,QWORD PTR [rip+0x1ac26]        # 422000 <__swc_data_base_7069e055>
  4073da:	imul   r9,r9,0x41a7
  4073e1:	movabs rdx,0x200000005
  4073eb:	mov    rax,r9
  4073ee:	mul    rdx
  4073f1:	mov    r10,rdx
  4073f4:	mov    rdx,r9
  4073f7:	sub    rdx,r10
  4073fa:	shr    rdx,1
  4073fd:	add    rdx,r10
  407400:	shr    rdx,0x1e
  407404:	imul   rdx,rdx,0x7fffffff
  40740b:	sub    r9,rdx
  40740e:	mov    QWORD PTR [rip+0x1abeb],r9        # 422000 <__swc_data_base_7069e055>
  407415:	movabs rdx,0xe38e38e38e38e38f
  40741f:	mov    rax,r9
  407422:	mul    rdx
  407425:	mov    r10,rdx
  407428:	mov    rax,r11
  40742b:	shr    r10,0x3
  40742f:	lea    rdx,[r10+r10*8]
  407433:	sub    r9,rdx
  407436:	lea    rdx,[r9+0x1]
  40743a:	mov    QWORD PTR [r8],rdx
  40743d:	add    rcx,0x1
  407441:	cmp    rcx,0x9c400
  407448:	jb     407360 <__swc_fn_7069e055_000003_fa681d0f+0x40>
  40744e:	sub    rsp,0x8
  407452:	call   40ee40 <__swc_fn_7069e055_000002_1ca87929>
  407457:	add    rsp,0x8
  40745b:	vmovups xmm6,xmm0
  40745f:	mov    ecx,0x4e2000
  407464:	sub    rsp,0x8
  407468:	call   407270 <__swc_fn_7069e055_000000_2744b483>
  40746d:	add    rsp,0x8
  407471:	mov    rdi,rax
  407474:	xor    eax,eax
  407476:	cs nop WORD PTR [rax+rax*1+0x0]
  407480:	mov    DWORD PTR [rdi+rax*8],0xffffffff
  407487:	mov    DWORD PTR [rdi+rax*8+0x4],0xfffffff
  40748f:	add    rax,0x1
  407493:	cmp    rax,0x9c400
  40749a:	jb     407480 <__swc_fn_7069e055_000003_fa681d0f+0x160>
  40749c:	mov    ecx,0x1388000
  4074a1:	sub    rsp,0x8
  4074a5:	call   407270 <__swc_fn_7069e055_000000_2744b483>
  4074aa:	add    rsp,0x8
  4074ae:	mov    QWORD PTR [rip+0x1cb9b],rax        # 424050 <__swc_bss_base_7069e055+0x10>
  4074b5:	mov    ecx,0x1388000
  4074ba:	sub    rsp,0x8
  4074be:	call   407270 <__swc_fn_7069e055_000000_2744b483>
  4074c3:	add    rsp,0x8
  4074c7:	mov    QWORD PTR [rip+0x1cb8a],rax        # 424058 <__swc_bss_base_7069e055+0x18>
  4074ce:	lea    rcx,[rip+0x1cb73]        # 424048 <__swc_bss_base_7069e055+0x8>
  4074d5:	mov    QWORD PTR [rcx],0x0
  4074dc:	mov    QWORD PTR [rdi],0x0
  4074e3:	mov    rdx,QWORD PTR [rip+0x1cb5e]        # 424048 <__swc_bss_base_7069e055+0x8>
  4074ea:	mov    r8,rdx
  4074ed:	add    QWORD PTR [rcx],0x1
  4074f1:	mov    r9,QWORD PTR [rip+0x1cb58]        # 424050 <__swc_bss_base_7069e055+0x10>
  4074f8:	mov    QWORD PTR [r9+rdx*8],0x0
  407500:	mov    r9,QWORD PTR [rip+0x1cb51]        # 424058 <__swc_bss_base_7069e055+0x18>
  407507:	mov    QWORD PTR [r9+rdx*8],0x0
  40750f:	mov    rdx,QWORD PTR [rip+0x1cb3a]        # 424050 <__swc_bss_base_7069e055+0x10>
  407516:	mov    r9,QWORD PTR [rip+0x1cb3b]        # 424058 <__swc_bss_base_7069e055+0x18>
  40751d:	test   r8,r8
  407520:	jbe    407574 <__swc_fn_7069e055_000003_fa681d0f+0x254>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	cs nop WORD PTR [rax+rax*1+0x0]
  407536:	cs nop WORD PTR [rax+rax*1+0x0]
  407540:	lea    r10,[r8-0x1]
  407544:	shr    r10,1
  407547:	mov    r11,QWORD PTR [rdx+r8*8]
  40754b:	mov    r12,QWORD PTR [rdx+r10*8]
  40754f:	cmp    r12,r11
  407552:	jbe    407574 <__swc_fn_7069e055_000003_fa681d0f+0x254>
  407554:	mov    QWORD PTR [rdx+r10*8],r11
  407558:	mov    QWORD PTR [rdx+r8*8],r12
  40755c:	mov    r11,QWORD PTR [r9+r10*8]
  407560:	mov    r12,QWORD PTR [r9+r8*8]
  407564:	mov    QWORD PTR [r9+r10*8],r12
  407568:	mov    QWORD PTR [r9+r8*8],r11
  40756c:	mov    r8,r10
  40756f:	test   r10,r10
  407572:	ja     407540 <__swc_fn_7069e055_000003_fa681d0f+0x220>
  407574:	xor    r8d,r8d
  407577:	vmovq  xmm0,r8
  40757c:	jmp    407590 <__swc_fn_7069e055_000003_fa681d0f+0x270>
  40757e:	xchg   ax,ax
  407580:	vmovq  r8,xmm0
  407585:	cs nop WORD PTR [rax+rax*1+0x0]
  40758f:	nop
  407590:	mov    rdx,QWORD PTR [rip+0x1cab1]        # 424048 <__swc_bss_base_7069e055+0x8>
  407597:	test   rdx,rdx
  40759a:	jbe    407994 <__swc_fn_7069e055_000003_fa681d0f+0x674>
  4075a0:	mov    rdx,QWORD PTR [rip+0x1caa9]        # 424050 <__swc_bss_base_7069e055+0x10>
  4075a7:	mov    rdx,QWORD PTR [rdx]
  4075aa:	mov    QWORD PTR [rip+0x1caaf],rdx        # 424060 <__swc_bss_base_7069e055+0x20>
  4075b1:	mov    rdx,QWORD PTR [rip+0x1caa0]        # 424058 <__swc_bss_base_7069e055+0x18>
  4075b8:	mov    rdx,QWORD PTR [rdx]
  4075bb:	mov    QWORD PTR [rip+0x1caa6],rdx        # 424068 <__swc_bss_base_7069e055+0x28>
  4075c2:	sub    QWORD PTR [rcx],0x1
  4075c6:	mov    rdx,QWORD PTR [rip+0x1ca83]        # 424050 <__swc_bss_base_7069e055+0x10>
  4075cd:	mov    r9,QWORD PTR [rip+0x1ca74]        # 424048 <__swc_bss_base_7069e055+0x8>
  4075d4:	mov    r9,QWORD PTR [rdx+r9*8]
  4075d8:	mov    QWORD PTR [rdx],r9
  4075db:	mov    rdx,QWORD PTR [rip+0x1ca76]        # 424058 <__swc_bss_base_7069e055+0x18>
  4075e2:	mov    r9,QWORD PTR [rip+0x1ca5f]        # 424048 <__swc_bss_base_7069e055+0x8>
  4075e9:	mov    r9,QWORD PTR [rdx+r9*8]
  4075ed:	mov    QWORD PTR [rdx],r9
  4075f0:	xor    edx,edx
  4075f2:	mov    r9,QWORD PTR [rip+0x1ca4f]        # 424048 <__swc_bss_base_7069e055+0x8>
  4075f9:	mov    r10,QWORD PTR [rip+0x1ca50]        # 424050 <__swc_bss_base_7069e055+0x10>
  407600:	mov    r11,QWORD PTR [rip+0x1ca51]        # 424058 <__swc_bss_base_7069e055+0x18>
  407607:	lea    r12,[rdx+rdx*1+0x1]
  40760c:	cmp    r12,r9
  40760f:	jae    40766c <__swc_fn_7069e055_000003_fa681d0f+0x34c>
  407611:	cs nop WORD PTR [rax+rax*1+0x0]
  40761b:	nop    DWORD PTR [rax+rax*1+0x0]
  407620:	lea    r13,[r12+0x1]
  407625:	cmp    r13,r9
  407628:	mov    r13,QWORD PTR [r10+r12*8]
  40762c:	jae    40763e <__swc_fn_7069e055_000003_fa681d0f+0x31e>
  40762e:	mov    r14,QWORD PTR [r10+r12*8+0x8]
  407633:	cmp    r14,r13
  407636:	cmovb  r13,r14
  40763a:	adc    r12,0x0
  40763e:	mov    r14,QWORD PTR [r10+rdx*8]
  407642:	cmp    r14,r13
  407645:	jbe    40766c <__swc_fn_7069e055_000003_fa681d0f+0x34c>
  407647:	mov    QWORD PTR [r10+r12*8],r14
  40764b:	mov    QWORD PTR [r10+rdx*8],r13
  40764f:	mov    r13,QWORD PTR [r11+r12*8]
  407653:	mov    r14,QWORD PTR [r11+rdx*8]
  407657:	mov    QWORD PTR [r11+r12*8],r14
  40765b:	mov    QWORD PTR [r11+rdx*8],r13
  40765f:	mov    rdx,r12
  407662:	lea    r12,[r12+r12*1+0x1]
  407667:	cmp    r12,r9
  40766a:	jb     407620 <__swc_fn_7069e055_000003_fa681d0f+0x300>
  40766c:	mov    r9,QWORD PTR [rip+0x1c9ed]        # 424060 <__swc_bss_base_7069e055+0x20>
  407673:	mov    r10,QWORD PTR [rip+0x1c9ee]        # 424068 <__swc_bss_base_7069e055+0x28>
  40767a:	inc    r8
  40767d:	vmovq  xmm0,r8
  407682:	mov    rdx,QWORD PTR [rdi+r10*8]
  407686:	cmp    r9,rdx
  407689:	ja     407590 <__swc_fn_7069e055_000003_fa681d0f+0x270>
  40768f:	cmp    r10,0x9c3ff
  407696:	je     407994 <__swc_fn_7069e055_000003_fa681d0f+0x674>
  40769c:	mov    r11,r10
  40769f:	shr    r11,0x5
  4076a3:	movabs rdx,0xa3d70a3d70a3d71
  4076ad:	mov    r8,rax
  4076b0:	mov    rax,r11
  4076b3:	mul    rdx
  4076b6:	mov    rax,r8
  4076b9:	imul   r11,rdx,0x320
  4076c0:	mov    r12,r10
  4076c3:	sub    r12,r11
  4076c6:	vmovq  xmm1,rdx
  4076cb:	test   r12,r12
  4076ce:	jbe    407774 <__swc_fn_7069e055_000003_fa681d0f+0x454>
  4076d4:	lea    r11,[r10-0x1]
  4076d8:	mov    r13,r9
  4076db:	add    r13,QWORD PTR [rsi+r10*8-0x8]
  4076e0:	mov    r14,QWORD PTR [rdi+r10*8-0x8]
  4076e5:	cmp    r13,r14
  4076e8:	jae    407774 <__swc_fn_7069e055_000003_fa681d0f+0x454>
  4076ee:	mov    QWORD PTR [rdi+r10*8-0x8],r13
  4076f3:	mov    r14,QWORD PTR [rip+0x1c94e]        # 424048 <__swc_bss_base_7069e055+0x8>
  4076fa:	mov    r15,r14
  4076fd:	add    QWORD PTR [rcx],0x1
  407701:	mov    r8,QWORD PTR [rip+0x1c948]        # 424050 <__swc_bss_base_7069e055+0x10>
  407708:	mov    QWORD PTR [r8+r14*8],r13
  40770c:	mov    r8,QWORD PTR [rip+0x1c945]        # 424058 <__swc_bss_base_7069e055+0x18>
  407713:	mov    QWORD PTR [r8+r14*8],r11
  407717:	mov    r8,QWORD PTR [rip+0x1c932]        # 424050 <__swc_bss_base_7069e055+0x10>
  40771e:	mov    r11,QWORD PTR [rip+0x1c933]        # 424058 <__swc_bss_base_7069e055+0x18>
  407725:	test   r15,r15
  407728:	jbe    407774 <__swc_fn_7069e055_000003_fa681d0f+0x454>
  40772a:	cs nop WORD PTR [rax+rax*1+0x0]
  407734:	cs nop WORD PTR [rax+rax*1+0x0]
  40773e:	xchg   ax,ax
  407740:	lea    r13,[r15-0x1]
  407744:	shr    r13,1
  407747:	mov    r14,QWORD PTR [r8+r15*8]
  40774b:	mov    rdx,QWORD PTR [r8+r13*8]
  40774f:	cmp    rdx,r14
  407752:	jbe    407774 <__swc_fn_7069e055_000003_fa681d0f+0x454>
  407754:	mov    QWORD PTR [r8+r13*8],r14
  407758:	mov    QWORD PTR [r8+r15*8],rdx
  40775c:	mov    rdx,QWORD PTR [r11+r13*8]
  407760:	mov    r14,QWORD PTR [r11+r15*8]
  407764:	mov    QWORD PTR [r11+r13*8],r14
  407768:	mov    QWORD PTR [r11+r15*8],rdx
  40776c:	mov    r15,r13
  40776f:	test   r13,r13
  407772:	ja     407740 <__swc_fn_7069e055_000003_fa681d0f+0x420>
  407774:	cmp    r12,0x31f
  40777b:	jae    407815 <__swc_fn_7069e055_000003_fa681d0f+0x4f5>
  407781:	lea    rdx,[r10+0x1]
  407785:	mov    r8,r9
  407788:	add    r8,QWORD PTR [rsi+r10*8+0x8]
  40778d:	mov    r11,QWORD PTR [rdi+r10*8+0x8]
  407792:	cmp    r8,r11
  407795:	jae    407815 <__swc_fn_7069e055_000003_fa681d0f+0x4f5>
  40779b:	mov    QWORD PTR [rdi+r10*8+0x8],r8
  4077a0:	mov    r11,QWORD PTR [rip+0x1c8a1]        # 424048 <__swc_bss_base_7069e055+0x8>
  4077a7:	mov    r12,r11
  4077aa:	add    QWORD PTR [rcx],0x1
  4077ae:	mov    r13,QWORD PTR [rip+0x1c89b]        # 424050 <__swc_bss_base_7069e055+0x10>
  4077b5:	mov    QWORD PTR [r13+r11*8+0x0],r8
  4077ba:	mov    r8,QWORD PTR [rip+0x1c897]        # 424058 <__swc_bss_base_7069e055+0x18>
  4077c1:	mov    QWORD PTR [r8+r11*8],rdx
  4077c5:	mov    rdx,QWORD PTR [rip+0x1c884]        # 424050 <__swc_bss_base_7069e055+0x10>
  4077cc:	mov    r8,QWORD PTR [rip+0x1c885]        # 424058 <__swc_bss_base_7069e055+0x18>
  4077d3:	test   r12,r12
  4077d6:	jbe    407815 <__swc_fn_7069e055_000003_fa681d0f+0x4f5>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	lea    r11,[r12-0x1]
  4077e5:	shr    r11,1
  4077e8:	mov    r13,QWORD PTR [rdx+r12*8]
  4077ec:	mov    r14,QWORD PTR [rdx+r11*8]
  4077f0:	cmp    r14,r13
  4077f3:	jbe    407815 <__swc_fn_7069e055_000003_fa681d0f+0x4f5>
  4077f5:	mov    QWORD PTR [rdx+r11*8],r13
  4077f9:	mov    QWORD PTR [rdx+r12*8],r14
  4077fd:	mov    r13,QWORD PTR [r8+r11*8]
  407801:	mov    r14,QWORD PTR [r8+r12*8]
  407805:	mov    QWORD PTR [r8+r11*8],r14
  407809:	mov    QWORD PTR [r8+r12*8],r13
  40780d:	mov    r12,r11
  407810:	test   r11,r11
  407813:	ja     4077e0 <__swc_fn_7069e055_000003_fa681d0f+0x4c0>
  407815:	vmovq  rdx,xmm1
  40781a:	test   rdx,rdx
  40781d:	jbe    4078d4 <__swc_fn_7069e055_000003_fa681d0f+0x5b4>
  407823:	lea    r8,[r10-0x320]
  40782a:	mov    r11,r9
  40782d:	add    r11,QWORD PTR [rsi+r10*8-0x1900]
  407835:	mov    r12,QWORD PTR [rdi+r10*8-0x1900]
  40783d:	cmp    r11,r12
  407840:	jae    4078d4 <__swc_fn_7069e055_000003_fa681d0f+0x5b4>
  407846:	mov    QWORD PTR [rdi+r10*8-0x1900],r11
  40784e:	mov    r12,QWORD PTR [rip+0x1c7f3]        # 424048 <__swc_bss_base_7069e055+0x8>
  407855:	mov    r13,r12
  407858:	add    QWORD PTR [rcx],0x1
  40785c:	mov    r14,QWORD PTR [rip+0x1c7ed]        # 424050 <__swc_bss_base_7069e055+0x10>
  407863:	mov    QWORD PTR [r14+r12*8],r11
  407867:	mov    r11,QWORD PTR [rip+0x1c7ea]        # 424058 <__swc_bss_base_7069e055+0x18>
  40786e:	mov    QWORD PTR [r11+r12*8],r8
  407872:	mov    r8,QWORD PTR [rip+0x1c7d7]        # 424050 <__swc_bss_base_7069e055+0x10>
  407879:	mov    r11,QWORD PTR [rip+0x1c7d8]        # 424058 <__swc_bss_base_7069e055+0x18>
  407880:	test   r13,r13
  407883:	jbe    4078d4 <__swc_fn_7069e055_000003_fa681d0f+0x5b4>
  407885:	cs nop WORD PTR [rax+rax*1+0x0]
  40788f:	cs nop WORD PTR [rax+rax*1+0x0]
  407899:	nop    DWORD PTR [rax+0x0]
  4078a0:	lea    r12,[r13-0x1]
  4078a4:	shr    r12,1
  4078a7:	mov    r14,QWORD PTR [r8+r13*8]
  4078ab:	mov    r15,QWORD PTR [r8+r12*8]
  4078af:	cmp    r15,r14
  4078b2:	jbe    4078d4 <__swc_fn_7069e055_000003_fa681d0f+0x5b4>
  4078b4:	mov    QWORD PTR [r8+r12*8],r14
  4078b8:	mov    QWORD PTR [r8+r13*8],r15
  4078bc:	mov    r14,QWORD PTR [r11+r12*8]
  4078c0:	mov    r15,QWORD PTR [r11+r13*8]
  4078c4:	mov    QWORD PTR [r11+r12*8],r15
  4078c8:	mov    QWORD PTR [r11+r13*8],r14
  4078cc:	mov    r13,r12
  4078cf:	test   r12,r12
  4078d2:	ja     4078a0 <__swc_fn_7069e055_000003_fa681d0f+0x580>
  4078d4:	cmp    rdx,0x31f
  4078db:	vmovq  r8,xmm0
  4078e0:	jae    407590 <__swc_fn_7069e055_000003_fa681d0f+0x270>
  4078e6:	lea    rdx,[r10+0x320]
  4078ed:	add    r9,QWORD PTR [rsi+r10*8+0x1900]
  4078f5:	mov    r8,QWORD PTR [rdi+r10*8+0x1900]
  4078fd:	cmp    r9,r8
  407900:	vmovq  r8,xmm0
  407905:	jae    407590 <__swc_fn_7069e055_000003_fa681d0f+0x270>
  40790b:	mov    QWORD PTR [rdi+r10*8+0x1900],r9
  407913:	mov    r8,QWORD PTR [rip+0x1c72e]        # 424048 <__swc_bss_base_7069e055+0x8>
  40791a:	mov    r10,r8
  40791d:	add    QWORD PTR [rcx],0x1
  407921:	mov    r11,QWORD PTR [rip+0x1c728]        # 424050 <__swc_bss_base_7069e055+0x10>
  407928:	mov    QWORD PTR [r11+r8*8],r9
  40792c:	mov    r9,QWORD PTR [rip+0x1c725]        # 424058 <__swc_bss_base_7069e055+0x18>
  407933:	mov    QWORD PTR [r9+r8*8],rdx
  407937:	mov    rdx,QWORD PTR [rip+0x1c712]        # 424050 <__swc_bss_base_7069e055+0x10>
  40793e:	mov    r8,QWORD PTR [rip+0x1c713]        # 424058 <__swc_bss_base_7069e055+0x18>
  407945:	cs nop WORD PTR [rax+rax*1+0x0]
  40794f:	nop
  407950:	test   r10,r10
  407953:	jbe    407580 <__swc_fn_7069e055_000003_fa681d0f+0x260>
  407959:	lea    r9,[r10-0x1]
  40795d:	shr    r9,1
  407960:	mov    r11,QWORD PTR [rdx+r10*8]
  407964:	mov    r12,QWORD PTR [rdx+r9*8]
  407968:	cmp    r12,r11
  40796b:	ja     407977 <__swc_fn_7069e055_000003_fa681d0f+0x657>
  40796d:	vmovq  r8,xmm0
  407972:	jmp    407590 <__swc_fn_7069e055_000003_fa681d0f+0x270>
  407977:	mov    QWORD PTR [rdx+r9*8],r11
  40797b:	mov    QWORD PTR [rdx+r10*8],r12
  40797f:	mov    r11,QWORD PTR [r8+r9*8]
  407983:	mov    r12,QWORD PTR [r8+r10*8]
  407987:	mov    QWORD PTR [r8+r9*8],r12
  40798b:	mov    QWORD PTR [r8+r10*8],r11
  40798f:	mov    r10,r9
  407992:	jmp    407950 <__swc_fn_7069e055_000003_fa681d0f+0x630>
  407994:	mov    rcx,QWORD PTR [rdi+0x4e1ff8]
  40799b:	imul   rcx,rcx,0x3e8
  4079a2:	vmovq  r8,xmm0
  4079a7:	mov    r9,r8
  4079aa:	shr    r9,0x3
  4079ae:	movabs rdx,0x20c49ba5e353f7cf
  4079b8:	mov    rax,r9
  4079bb:	mul    rdx
  4079be:	shr    rdx,0x4
  4079c2:	imul   rdx,rdx,0x3e8
  4079c9:	sub    r8,rdx
  4079cc:	lea    r12,[rcx+r8*1]
  4079d0:	sub    rsp,0x8
  4079d4:	call   40ee40 <__swc_fn_7069e055_000002_1ca87929>
  4079d9:	add    rsp,0x8
  4079dd:	vsubsd xmm0,xmm0,xmm6
  4079e1:	vmulsd xmm0,xmm0,QWORD PTR [rip+0xb83f]        # 413228 <__swc_rdata_base_7069e055+0x118>
  4079e9:	lea    rax,[rip+0xb730]        # 413120 <__swc_rdata_base_7069e055+0x10>
  4079f0:	sub    rsp,0x90
  4079f7:	mov    rcx,rsp
  4079fa:	vmovups xmm1,XMMWORD PTR [rip+0xb806]        # 413208 <__swc_rdata_base_7069e055+0xf8>
  407a02:	vmovups XMMWORD PTR [rcx],xmm1
  407a06:	mov    QWORD PTR [rcx+0x30],rsp
  407a0a:	lea    rdx,[rip+0xb71f]        # 413130 <__swc_rdata_base_7069e055+0x20>
  407a11:	mov    QWORD PTR [rcx+0x38],rdx
  407a15:	mov    QWORD PTR [rcx+0x10],r12
  407a19:	lea    r8,[rsp+0x10]
  407a1e:	mov    QWORD PTR [rcx+0x40],r8
  407a22:	lea    r8,[rip+0xb74f]        # 413178 <__swc_rdata_base_7069e055+0x68>
  407a29:	mov    QWORD PTR [rcx+0x48],r8
  407a2d:	vmovups xmm1,XMMWORD PTR [rip+0xb7e3]        # 413218 <__swc_rdata_base_7069e055+0x108>
  407a35:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  407a3a:	lea    r8,[rsp+0x18]
  407a3f:	mov    QWORD PTR [rcx+0x50],r8
  407a43:	mov    QWORD PTR [rcx+0x58],rdx
  407a47:	vmovsd QWORD PTR [rcx+0x28],xmm0
  407a4c:	lea    r8,[rcx+0x28]
  407a50:	mov    QWORD PTR [rcx+0x60],r8
  407a54:	lea    r8,[rip+0xb765]        # 4131c0 <__swc_rdata_base_7069e055+0xb0>
  407a5b:	mov    QWORD PTR [rcx+0x68],r8
  407a5f:	mov    QWORD PTR [rcx+0x70],rax
  407a63:	mov    QWORD PTR [rcx+0x78],rdx
  407a67:	lea    rax,[rcx+0x30]
  407a6b:	mov    QWORD PTR [rcx+0x80],rax
  407a72:	mov    QWORD PTR [rcx+0x88],0x5
  407a7d:	lea    rcx,[rcx+0x80]
  407a84:	sub    rsp,0x8
  407a88:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  407a8d:	add    rsp,0x8
  407a91:	add    rsp,0x90
  407a98:	mov    rcx,QWORD PTR [rip+0x1c5b9]        # 424058 <__swc_bss_base_7069e055+0x18>
  407a9f:	sub    rsp,0x8
  407aa3:	call   40bce0 <__swc_fn_7069e055_000001_5d3d19bd>
  407aa8:	add    rsp,0x8
  407aac:	mov    rcx,QWORD PTR [rip+0x1c59d]        # 424050 <__swc_bss_base_7069e055+0x10>
  407ab3:	sub    rsp,0x8
  407ab7:	call   40bce0 <__swc_fn_7069e055_000001_5d3d19bd>
  407abc:	add    rsp,0x8
  407ac0:	mov    rcx,rdi
  407ac3:	sub    rsp,0x8
  407ac7:	call   40bce0 <__swc_fn_7069e055_000001_5d3d19bd>
  407acc:	add    rsp,0x8
  407ad0:	mov    rcx,rsi
  407ad3:	sub    rsp,0x8
  407ad7:	call   40bce0 <__swc_fn_7069e055_000001_5d3d19bd>
  407adc:	add    rsp,0x1b8
  407ae3:	vmovups xmm6,XMMWORD PTR [rsp]
  407ae8:	add    rsp,0x18
  407aec:	pop    r12
  407aee:	pop    rdi
  407aef:	pop    r13
  407af1:	pop    r14
  407af3:	pop    r15
  407af5:	pop    rsi
  407af6:	pop    rbp
  407af7:	ret
	...

0000000000407b00 <__swc_fn_7069e055_000006_81d2e1e9>:
  407b00:	sub    rsp,0x8
  407b04:	call   411100 <__swc_fn_7069e055_000113_6b799b8d>
  407b09:	mov    rcx,rax
  407b0c:	test   rax,rax
  407b0f:	je     407b36 <__swc_fn_7069e055_000006_81d2e1e9+0x36>
  407b11:	lea    rdx,[rip+0x1c558]        # 424070 <__swc_bss_base_7069e055+0x30>
  407b18:	mov    r8,QWORD PTR [rip+0x1c551]        # 424070 <__swc_bss_base_7069e055+0x30>
  407b1f:	nop
  407b20:	lea    r9,[r8+0x1]
  407b24:	mov    rax,r8
  407b27:	lock cmpxchg QWORD PTR [rdx],r9
  407b2c:	cmp    rax,r8
  407b2f:	je     407b36 <__swc_fn_7069e055_000006_81d2e1e9+0x36>
  407b31:	mov    r8,rax
  407b34:	jmp    407b20 <__swc_fn_7069e055_000006_81d2e1e9+0x20>
  407b36:	mov    rax,rcx
  407b39:	add    rsp,0x8
  407b3d:	ret
	...

0000000000407b40 <__swc_fn_7069e055_000009_065ed5b1>:
  407b40:	mov    r8d,edx
  407b43:	xor    eax,eax
  407b45:	tzcnt  eax,edx
  407b49:	shrx   r9d,edx,eax
  407b4e:	mov    DWORD PTR [rcx+0x2c],edx
  407b51:	xor    eax,eax
  407b53:	tzcnt  eax,edx
  407b57:	mov    BYTE PTR [rcx+0x38],al
  407b5a:	mov    eax,0xffffffff
  407b5f:	xor    edx,edx
  407b61:	div    r8d
  407b64:	mov    DWORD PTR [rcx+0x34],eax
  407b67:	mov    eax,r9d
  407b6a:	mov    edx,r9d
  407b6d:	imul   edx,r9d
  407b71:	mov    r8d,0x2
  407b77:	sub    r8d,edx
  407b7a:	imul   eax,r8d
  407b7e:	mov    edx,r9d
  407b81:	imul   edx,eax
  407b84:	mov    r8d,0x2
  407b8a:	sub    r8d,edx
  407b8d:	imul   eax,r8d
  407b91:	mov    edx,r9d
  407b94:	imul   edx,eax
  407b97:	mov    r8d,0x2
  407b9d:	sub    r8d,edx
  407ba0:	imul   eax,r8d
  407ba4:	mov    edx,r9d
  407ba7:	imul   edx,eax
  407baa:	mov    r8d,0x2
  407bb0:	sub    r8d,edx
  407bb3:	imul   eax,r8d
  407bb7:	imul   r9d,eax
  407bbb:	mov    edx,0x2
  407bc0:	sub    edx,r9d
  407bc3:	imul   eax,edx
  407bc6:	mov    DWORD PTR [rcx+0x30],eax
  407bc9:	ret
  407bca:	add    BYTE PTR [rax],al
  407bcc:	add    BYTE PTR [rax],al
	...

0000000000407bd0 <__swc_fn_7069e055_000012_861b8b62>:
  407bd0:	xor    eax,eax
  407bd2:	mov    DWORD PTR [rcx+0x68],eax
  407bd5:	ret
	...

0000000000407be0 <__swc_fn_7069e055_000015_9dea5065>:
  407be0:	mov    eax,DWORD PTR [rcx+0x28]
  407be3:	shlx   eax,edx,eax
  407be8:	shl    rax,0x10
  407bec:	lea    rdx,[rcx+rax*1]
  407bf0:	lea    rax,[rcx+0x3000]
  407bf7:	cmp    rdx,rax
  407bfa:	cmovae rax,rdx
  407bfe:	ret
	...

0000000000407c00 <__swc_fn_7069e055_000018_283e2b5e>:
  407c00:	push   rsi
  407c01:	push   rdi
  407c02:	push   r12
  407c04:	push   r13
  407c06:	push   r14
  407c08:	mov    rsi,rdx
  407c0b:	mov    rdi,rcx
  407c0e:	rex mov dl,BYTE PTR [rsi+0x3a]
  407c12:	mov    ecx,DWORD PTR [rdi+0x28]
  407c15:	shr    dl,cl
  407c17:	mov    r12d,0x1
  407c1d:	mov    ecx,edx
  407c1f:	shl    r12,cl
  407c22:	mov    r13d,DWORD PTR [rsi+0x3c]
  407c26:	rex mov BYTE PTR [rsi+0x3b],0x0
  407c2b:	mov    QWORD PTR [rsi+0x40],0x0
  407c33:	mov    QWORD PTR [rsi],0x0
  407c3a:	mov    rax,QWORD PTR [rsi+0x10]
  407c3e:	mov    QWORD PTR [rsi+0x20],rax
  407c42:	lea    r14,[rip+0x1c42f]        # 424078 <__swc_bss_base_7069e055+0x38>
  407c49:	mov    rax,QWORD PTR [r14]
  407c4c:	shr    rax,0x2
  407c50:	mov    rcx,rax
  407c53:	cmp    rax,0x800000
  407c5a:	mov    eax,0x800000
  407c5f:	cmovb  rcx,rax
  407c63:	lea    r8,[rip+0x1c41e]        # 424088 <__swc_bss_base_7069e055+0x48>
  407c6a:	mov    rax,QWORD PTR [r8]
  407c6d:	mov    r9,rax
  407c70:	lea    r10,[r9+r13*1]
  407c74:	cmp    r10,rcx
  407c77:	ja     407c9b <__swc_fn_7069e055_000018_283e2b5e+0x9b>
  407c79:	mov    rax,r9
  407c7c:	lock cmpxchg QWORD PTR [r8],r10
  407c81:	cmp    rax,r9
  407c84:	je     407c8b <__swc_fn_7069e055_000018_283e2b5e+0x8b>
  407c86:	mov    r9,rax
  407c89:	jmp    407c70 <__swc_fn_7069e055_000018_283e2b5e+0x70>
  407c8b:	mov    rcx,rdi
  407c8e:	mov    rdx,r12
  407c91:	call   40f230 <__swc_fn_7069e055_000020_de02dbdf>
  407c96:	jmp    407d1d <__swc_fn_7069e055_000018_283e2b5e+0x11d>
  407c9b:	mov    rcx,rdi
  407c9e:	movzx  edx,dl
  407ca1:	call   407be0 <__swc_fn_7069e055_000015_9dea5065>
  407ca6:	test   r13,r13
  407ca9:	je     407d16 <__swc_fn_7069e055_000018_283e2b5e+0x116>
  407caf:	mov    rcx,rax
  407cb2:	mov    rdx,r13
  407cb5:	call   411280 <__swc_fn_7069e055_000116_e9fc0224>
  407cba:	mov    rcx,QWORD PTR [rip+0x1c3b7]        # 424078 <__swc_bss_base_7069e055+0x38>
  407cc1:	cs nop WORD PTR [rax+rax*1+0x0]
  407ccb:	nop    DWORD PTR [rax+rax*1+0x0]
  407cd0:	mov    rdx,rcx
  407cd3:	sub    rdx,r13
  407cd6:	mov    rax,rcx
  407cd9:	lock cmpxchg QWORD PTR [r14],rdx
  407cde:	cmp    rax,rcx
  407ce1:	je     407ce8 <__swc_fn_7069e055_000018_283e2b5e+0xe8>
  407ce3:	mov    rcx,rax
  407ce6:	jmp    407cd0 <__swc_fn_7069e055_000018_283e2b5e+0xd0>
  407ce8:	lea    rcx,[rip+0x1c3a1]        # 424090 <__swc_bss_base_7069e055+0x50>
  407cef:	mov    rdx,QWORD PTR [rip+0x1c39a]        # 424090 <__swc_bss_base_7069e055+0x50>
  407cf6:	cs nop WORD PTR [rax+rax*1+0x0]
  407d00:	lea    r8,[rdx+0x1]
  407d04:	mov    rax,rdx
  407d07:	lock cmpxchg QWORD PTR [rcx],r8
  407d0c:	cmp    rax,rdx
  407d0f:	je     407d16 <__swc_fn_7069e055_000018_283e2b5e+0x116>
  407d11:	mov    rdx,rax
  407d14:	jmp    407d00 <__swc_fn_7069e055_000018_283e2b5e+0x100>
  407d16:	mov    DWORD PTR [rsi+0x3c],0x0
  407d1d:	mov    rcx,rdi
  407d20:	mov    rdx,r12
  407d23:	call   40c0f0 <__swc_fn_7069e055_000022_c8f5f27c>
  407d28:	pop    r14
  407d2a:	pop    r13
  407d2c:	pop    r12
  407d2e:	pop    rdi
  407d2f:	pop    rsi
  407d30:	ret
	...

0000000000407d40 <__swc_fn_7069e055_000021_fd2b165c>:
  407d40:	mov    r8,QWORD PTR [rcx+0x48]
  407d44:	test   r8,rdx
  407d47:	je     407d78 <__swc_fn_7069e055_000021_fd2b165c+0x38>
  407d49:	nop    DWORD PTR [rax+0x0]
  407d50:	mov    rax,rdx
  407d53:	not    rax
  407d56:	mov    r9,r8
  407d59:	and    r9,rax
  407d5c:	mov    rax,r8
  407d5f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  407d65:	cmp    rax,r8
  407d68:	jne    407d70 <__swc_fn_7069e055_000021_fd2b165c+0x30>
  407d6a:	mov    eax,0x1
  407d6f:	ret
  407d70:	mov    r8,rax
  407d73:	test   rax,rdx
  407d76:	jne    407d50 <__swc_fn_7069e055_000021_fd2b165c+0x10>
  407d78:	xor    eax,eax
  407d7a:	ret
  407d7b:	add    BYTE PTR [rax],al
  407d7d:	add    BYTE PTR [rax],al
	...

0000000000407d80 <__swc_fn_7069e055_000024_2685aade>:
  407d80:	push   rsi
  407d81:	push   rdi
  407d82:	push   r12
  407d84:	push   r13
  407d86:	sub    rsp,0x8
  407d8a:	mov    rsi,rdx
  407d8d:	mov    rdi,rcx
  407d90:	lea    r12,[rip+0x1c489]        # 424220 <__swc_bss_base_7069e055+0x1e0>
  407d97:	mov    rcx,r12
  407d9a:	call   40e380 <__swc_fn_7069e055_000139_86bb0f90>
  407d9f:	xor    eax,eax
  407da1:	mov    rcx,QWORD PTR [rip+0x1c480]        # 424228 <__swc_bss_base_7069e055+0x1e8>
  407da8:	mov    r13,rcx
  407dab:	test   r13,r13
  407dae:	je     407dfb <__swc_fn_7069e055_000024_2685aade+0x7b>
  407db0:	mov    rcx,QWORD PTR [r13+0x10]
  407db4:	cmp    DWORD PTR [r13+0x28],esi
  407db8:	jne    407df0 <__swc_fn_7069e055_000024_2685aade+0x70>
  407dba:	test   rax,rax
  407dbd:	jne    407dc8 <__swc_fn_7069e055_000024_2685aade+0x48>
  407dbf:	mov    QWORD PTR [rip+0x1c462],rcx        # 424228 <__swc_bss_base_7069e055+0x1e8>
  407dc6:	jmp    407dcc <__swc_fn_7069e055_000024_2685aade+0x4c>
  407dc8:	mov    QWORD PTR [rax+0x10],rcx
  407dcc:	vxorps xmm0,xmm0,xmm0
  407dd0:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407dd6:	mov    QWORD PTR [r13+0x8],rdi
  407dda:	mov    rcx,r12
  407ddd:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  407de2:	mov    rax,r13
  407de5:	add    rsp,0x8
  407de9:	pop    r13
  407deb:	pop    r12
  407ded:	pop    rdi
  407dee:	pop    rsi
  407def:	ret
  407df0:	mov    rax,r13
  407df3:	mov    r13,rcx
  407df6:	test   rcx,rcx
  407df9:	jne    407db0 <__swc_fn_7069e055_000024_2685aade+0x30>
  407dfb:	mov    ecx,esi
  407dfd:	call   40f260 <__swc_fn_7069e055_000023_2d0fcd2c>
  407e02:	mov    rsi,rax
  407e05:	test   rax,rax
  407e08:	jne    407e1f <__swc_fn_7069e055_000024_2685aade+0x9f>
  407e0a:	mov    rcx,r12
  407e0d:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  407e12:	xor    eax,eax
  407e14:	add    rsp,0x8
  407e18:	pop    r13
  407e1a:	pop    r12
  407e1c:	pop    rdi
  407e1d:	pop    rsi
  407e1e:	ret
  407e1f:	mov    QWORD PTR [rsi+0x8],rdi
  407e23:	mov    rcx,r12
  407e26:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  407e2b:	mov    rax,rsi
  407e2e:	add    rsp,0x8
  407e32:	pop    r13
  407e34:	pop    r12
  407e36:	pop    rdi
  407e37:	pop    rsi
  407e38:	ret
  407e39:	add    BYTE PTR [rax],al
  407e3b:	add    BYTE PTR [rax],al
  407e3d:	add    BYTE PTR [rax],al
	...

0000000000407e40 <__swc_fn_7069e055_000027_9798fb47>:
  407e40:	vxorps xmm0,xmm0,xmm0
  407e44:	xor    eax,eax
  407e46:	cs nop WORD PTR [rax+rax*1+0x0]
  407e50:	cs nop WORD PTR [rax+rax*1+0x0]
  407e5a:	nop    WORD PTR [rax+rax*1+0x0]
  407e60:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  407e65:	add    rax,0x10
  407e69:	cmp    rax,0x2b00
  407e70:	jne    407e60 <__swc_fn_7069e055_000027_9798fb47+0x20>
  407e72:	ret
	...

0000000000407e80 <__swc_fn_7069e055_000030_9798fb47>:
  407e80:	vxorps xmm0,xmm0,xmm0
  407e84:	vmovups XMMWORD PTR [rcx],xmm0
  407e88:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  407e8d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407e92:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407e97:	ret
	...

0000000000407ea0 <__swc_fn_7069e055_000033_9798fb47>:
  407ea0:	vxorps xmm0,xmm0,xmm0
  407ea4:	vmovups XMMWORD PTR [rcx],xmm0
  407ea8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  407ead:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407eb2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407eb7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  407ebc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407ec1:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407ec6:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  407ecb:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  407ed3:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  407edb:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  407ee3:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  407eeb:	mov    QWORD PTR [rcx+0xc0],0x0
  407ef6:	ret
	...

0000000000407f00 <__swc_fn_7069e055_000036_92d9bbff>:
  407f00:	push   rsi
  407f01:	push   rdi
  407f02:	sub    rsp,0x8
  407f06:	mov    rsi,rcx
  407f09:	lea    rdi,[rip+0x1a0f8]        # 422008 <__swc_data_base_7069e055+0x8>
  407f10:	mov    rax,QWORD PTR [rdi]
  407f13:	cmp    rax,0xffffffffffffffff
  407f17:	je     407f1e <__swc_fn_7069e055_000036_92d9bbff+0x1e>
  407f19:	mov    rdi,rax
  407f1c:	jmp    407f4b <__swc_fn_7069e055_000036_92d9bbff+0x4b>
  407f1e:	call   40e060 <__swc_fn_7069e055_000127_58f0f391>
  407f23:	mov    rcx,rax
  407f26:	cmp    rax,0xffffffffffffffff
  407f2a:	je     407f5c <__swc_fn_7069e055_000036_92d9bbff+0x5c>
  407f2c:	mov    rax,0xffffffffffffffff
  407f33:	lock cmpxchg QWORD PTR [rdi],rcx
  407f38:	cmp    rax,0xffffffffffffffff
  407f3c:	je     407f48 <__swc_fn_7069e055_000036_92d9bbff+0x48>
  407f3e:	mov    rdi,rax
  407f41:	call   411650 <__swc_fn_7069e055_000128_a481cb88>
  407f46:	jmp    407f4b <__swc_fn_7069e055_000036_92d9bbff+0x4b>
  407f48:	mov    rdi,rcx
  407f4b:	cmp    rdi,0xffffffffffffffff
  407f4f:	je     407f5c <__swc_fn_7069e055_000036_92d9bbff+0x5c>
  407f51:	mov    rcx,rdi
  407f54:	mov    rdx,rsi
  407f57:	call   40a010 <__swc_fn_7069e055_000129_4bbe3f14>
  407f5c:	add    rsp,0x8
  407f60:	pop    rdi
  407f61:	pop    rsi
  407f62:	ret
	...

0000000000407f70 <__swc_fn_7069e055_000039_03f1bf9a>:
  407f70:	sub    rsp,0x38
  407f74:	mov    rax,rdx
  407f77:	test   dl,dl
  407f79:	jne    407f91 <__swc_fn_7069e055_000039_03f1bf9a+0x21>
  407f7b:	mov    rax,r8
  407f7e:	test   r8b,r8b
  407f81:	cmove  eax,r9d
  407f85:	test   al,al
  407f87:	cmove  eax,r10d
  407f8b:	test   al,al
  407f8d:	cmove  eax,r11d
  407f91:	test   al,al
  407f93:	jne    407f9a <__swc_fn_7069e055_000039_03f1bf9a+0x2a>
  407f95:	add    rsp,0x38
  407f99:	ret
  407f9a:	lea    rcx,[rip+0xb297]        # 413238 <__swc_rdata_base_7069e055+0x128>
  407fa1:	vmovups xmm0,XMMWORD PTR [rip+0xb29f]        # 413248 <__swc_rdata_base_7069e055+0x138>
  407fa9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  407faf:	vmovups xmm0,XMMWORD PTR [rip+0xb2a1]        # 413258 <__swc_rdata_base_7069e055+0x148>
  407fb7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  407fbd:	vmovups xmm0,XMMWORD PTR [rip+0xb2a3]        # 413268 <__swc_rdata_base_7069e055+0x158>
  407fc5:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  407fcb:	lea    rdx,[rsp+0x8]
  407fd0:	call   410e80 <__swc_fn_7069e055_000107_90faaa26>
  407fd5:	jmp    407f95 <__swc_fn_7069e055_000039_03f1bf9a+0x25>
	...

0000000000407fe0 <__swc_fn_7069e055_000042_facd3e17>:
  407fe0:	sub    rsp,0x8
  407fe4:	mov    eax,0x1000
  407fe9:	test   eax,eax
  407feb:	mov    r8d,0x8
  407ff1:	cmove  eax,r8d
  407ff5:	dec    rax
  407ff8:	mov    r8,0xffffffffffffffff
  407fff:	sub    r8,rax
  408002:	cmp    rdx,r8
  408005:	ja     408015 <__swc_fn_7069e055_000042_facd3e17+0x35>
  408007:	add    rdx,rax
  40800a:	not    rax
  40800d:	mov    r8,rdx
  408010:	and    r8,rax
  408013:	jne    40801c <__swc_fn_7069e055_000042_facd3e17+0x3c>
  408015:	xor    eax,eax
  408017:	add    rsp,0x8
  40801b:	ret
  40801c:	mov    rdx,r8
  40801f:	call   40f580 <__swc_fn_7069e055_000041_c90d80c1>
  408024:	add    rsp,0x8
  408028:	ret
  408029:	add    BYTE PTR [rax],al
  40802b:	add    BYTE PTR [rax],al
  40802d:	add    BYTE PTR [rax],al
	...

0000000000408030 <__swc_fn_7069e055_000045_d8bd27c3>:
  408030:	push   rsi
  408031:	push   rdi
  408032:	sub    rsp,0x8
  408036:	mov    rsi,rdx
  408039:	mov    rdi,rcx
  40803c:	test   rdx,rdx
  40803f:	je     40805b <__swc_fn_7069e055_000045_d8bd27c3+0x2b>
  408041:	xor    ecx,ecx
  408043:	call   40c210 <__swc_fn_7069e055_000037_28d0e998>
  408048:	mov    rax,QWORD PTR [rsi]
  40804b:	test   rax,rax
  40804e:	je     40805b <__swc_fn_7069e055_000045_d8bd27c3+0x2b>
  408050:	mov    rcx,rax
  408053:	mov    rdx,rsi
  408056:	call   40c320 <__swc_fn_7069e055_000046_b30433d0>
  40805b:	mov    rcx,rdi
  40805e:	call   40f5e0 <__swc_fn_7069e055_000044_a78ae66b>
  408063:	mov    rsi,rax
  408066:	test   rax,rax
  408069:	jne    408074 <__swc_fn_7069e055_000045_d8bd27c3+0x44>
  40806b:	xor    eax,eax
  40806d:	add    rsp,0x8
  408071:	pop    rdi
  408072:	pop    rsi
  408073:	ret
  408074:	mov    rcx,rsi
  408077:	call   40c210 <__swc_fn_7069e055_000037_28d0e998>
  40807c:	mov    rax,rsi
  40807f:	add    rsp,0x8
  408083:	pop    rdi
  408084:	pop    rsi
  408085:	ret
	...

0000000000408090 <__swc_fn_7069e055_000048_137687bb>:
  408090:	movzx  eax,BYTE PTR [r8+0x39]
  408095:	lea    rax,[rax+rax*4]
  408099:	lea    rax,[rdx+rax*8+0x28]
  40809e:	mov    ecx,DWORD PTR [r8+0x6c]
  4080a2:	test   ecx,ecx
  4080a4:	je     4080dd <__swc_fn_7069e055_000048_137687bb+0x4d>
  4080a6:	mov    rcx,QWORD PTR [r8+0x50]
  4080aa:	test   rcx,rcx
  4080ad:	je     4080b9 <__swc_fn_7069e055_000048_137687bb+0x29>
  4080af:	mov    rax,QWORD PTR [r8+0x48]
  4080b3:	mov    QWORD PTR [rcx+0x48],rax
  4080b7:	jmp    4080c1 <__swc_fn_7069e055_000048_137687bb+0x31>
  4080b9:	mov    rcx,QWORD PTR [r8+0x48]
  4080bd:	mov    QWORD PTR [rax+0x18],rcx
  4080c1:	mov    rax,QWORD PTR [r8+0x48]
  4080c5:	test   rax,rax
  4080c8:	je     4080d2 <__swc_fn_7069e055_000048_137687bb+0x42>
  4080ca:	mov    rcx,QWORD PTR [r8+0x50]
  4080ce:	mov    QWORD PTR [rax+0x50],rcx
  4080d2:	vxorps xmm0,xmm0,xmm0
  4080d6:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  4080dc:	ret
  4080dd:	mov    rcx,QWORD PTR [r8+0x50]
  4080e1:	test   rcx,rcx
  4080e4:	je     4080f0 <__swc_fn_7069e055_000048_137687bb+0x60>
  4080e6:	mov    rdx,QWORD PTR [r8+0x48]
  4080ea:	mov    QWORD PTR [rcx+0x48],rdx
  4080ee:	jmp    4080f8 <__swc_fn_7069e055_000048_137687bb+0x68>
  4080f0:	mov    rcx,QWORD PTR [r8+0x48]
  4080f4:	mov    QWORD PTR [rax+0x8],rcx
  4080f8:	mov    rcx,QWORD PTR [r8+0x48]
  4080fc:	test   rcx,rcx
  4080ff:	je     40810b <__swc_fn_7069e055_000048_137687bb+0x7b>
  408101:	mov    rdx,QWORD PTR [r8+0x50]
  408105:	mov    QWORD PTR [rcx+0x50],rdx
  408109:	jmp    408113 <__swc_fn_7069e055_000048_137687bb+0x83>
  40810b:	mov    rcx,QWORD PTR [r8+0x50]
  40810f:	mov    QWORD PTR [rax+0x10],rcx
  408113:	cmp    QWORD PTR [rax],r8
  408116:	jne    40811f <__swc_fn_7069e055_000048_137687bb+0x8f>
  408118:	mov    QWORD PTR [rax],0x0
  40811f:	vxorps xmm0,xmm0,xmm0
  408123:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  408129:	ret
  40812a:	add    BYTE PTR [rax],al
  40812c:	add    BYTE PTR [rax],al
	...

0000000000408130 <__swc_fn_7069e055_000051_e072b516>:
  408130:	sub    rsp,0x8
  408134:	mov    r9,r8
  408137:	mov    r10,rdx
  40813a:	call   408090 <__swc_fn_7069e055_000048_137687bb>
  40813f:	mov    DWORD PTR [r9+0x6c],0x0
  408147:	movzx  eax,BYTE PTR [r9+0x39]
  40814c:	lea    rax,[rax+rax*4]
  408150:	lea    rax,[r10+rax*8+0x28]
  408155:	mov    rcx,QWORD PTR [rax+0x10]
  408159:	mov    QWORD PTR [r9+0x50],rcx
  40815d:	mov    QWORD PTR [r9+0x48],0x0
  408165:	mov    rcx,QWORD PTR [rax+0x10]
  408169:	test   rcx,rcx
  40816c:	je     408174 <__swc_fn_7069e055_000051_e072b516+0x44>
  40816e:	mov    QWORD PTR [rcx+0x48],r9
  408172:	jmp    408178 <__swc_fn_7069e055_000051_e072b516+0x48>
  408174:	mov    QWORD PTR [rax+0x8],r9
  408178:	mov    QWORD PTR [rax+0x10],r9
  40817c:	add    rsp,0x8
  408180:	ret
	...

00000000004081a0 <__swc_fn_7069e055_000054_faa92dcc>:
  4081a0:	push   rsi
  4081a1:	push   rdi
  4081a2:	push   r12
  4081a4:	push   r13
  4081a6:	push   r14
  4081a8:	push   r15
  4081aa:	sub    rsp,0x1f8
  4081b1:	mov    esi,r8d
  4081b4:	mov    QWORD PTR [rsp+0x1e8],rsi
  4081bc:	mov    rdi,rcx
  4081bf:	mov    r12,rdx
  4081c2:	lea    r13,[rsi+rsi*4]
  4081c6:	lea    r13,[rdx+r13*8+0x28]
  4081cb:	call   40c780 <__swc_fn_7069e055_000052_d846b172>
  4081d0:	add    DWORD PTR [r12+0x24],0x1
  4081d6:	test   BYTE PTR [r12+0x24],0x3f
  4081dc:	jne    4081e6 <__swc_fn_7069e055_000054_faa92dcc+0x46>
  4081de:	mov    rcx,rdi
  4081e1:	call   40f760 <__swc_fn_7069e055_000053_3af34d7f>
  4081e6:	mov    rax,QWORD PTR [r13+0x8]
  4081ea:	mov    r14,rax
  4081ed:	nop    DWORD PTR [rax]
  4081f0:	test   r14,r14
  4081f3:	jne    408202 <__swc_fn_7069e055_000054_faa92dcc+0x62>
  4081f5:	mov    rsi,QWORD PTR [rsp+0x1e8]
  4081fd:	jmp    408309 <__swc_fn_7069e055_000054_faa92dcc+0x169>
  408202:	mov    r15,QWORD PTR [r14+0x48]
  408206:	mov    rcx,r14
  408209:	call   40bee0 <__swc_fn_7069e055_000013_e4b0ddfc>
  40820e:	mov    rax,QWORD PTR [r14]
  408211:	test   rax,rax
  408214:	je     408226 <__swc_fn_7069e055_000054_faa92dcc+0x86>
  408216:	mov    rcx,QWORD PTR [rax]
  408219:	mov    QWORD PTR [r14],rcx
  40821c:	add    DWORD PTR [r14+0x28],0x1
  408221:	mov    rsi,rax
  408224:	jmp    408245 <__swc_fn_7069e055_000054_faa92dcc+0xa5>
  408226:	mov    rax,QWORD PTR [r14+0x18]
  40822a:	cmp    QWORD PTR [r14+0x20],rax
  40822e:	jae    408243 <__swc_fn_7069e055_000054_faa92dcc+0xa3>
  408230:	mov    rsi,QWORD PTR [r14+0x20]
  408234:	mov    eax,DWORD PTR [r14+0x2c]
  408238:	add    QWORD PTR [r14+0x20],rax
  40823c:	add    DWORD PTR [r14+0x28],0x1
  408241:	jmp    408245 <__swc_fn_7069e055_000054_faa92dcc+0xa5>
  408243:	xor    esi,esi
  408245:	test   rsi,rsi
  408248:	jne    40828d <__swc_fn_7069e055_000054_faa92dcc+0xed>
  40824a:	mov    rcx,r14
  40824d:	call   40be10 <__swc_fn_7069e055_000010_24a20786>
  408252:	test   al,al
  408254:	je     40828d <__swc_fn_7069e055_000054_faa92dcc+0xed>
  408256:	mov    rax,QWORD PTR [r14]
  408259:	test   rax,rax
  40825c:	je     40826b <__swc_fn_7069e055_000054_faa92dcc+0xcb>
  40825e:	mov    rcx,QWORD PTR [rax]
  408261:	mov    QWORD PTR [r14],rcx
  408264:	add    DWORD PTR [r14+0x28],0x1
  408269:	jmp    40828a <__swc_fn_7069e055_000054_faa92dcc+0xea>
  40826b:	mov    rax,QWORD PTR [r14+0x18]
  40826f:	cmp    QWORD PTR [r14+0x20],rax
  408273:	jae    408288 <__swc_fn_7069e055_000054_faa92dcc+0xe8>
  408275:	mov    rax,QWORD PTR [r14+0x20]
  408279:	mov    ecx,DWORD PTR [r14+0x2c]
  40827d:	add    QWORD PTR [r14+0x20],rcx
  408281:	add    DWORD PTR [r14+0x28],0x1
  408286:	jmp    40828a <__swc_fn_7069e055_000054_faa92dcc+0xea>
  408288:	xor    eax,eax
  40828a:	mov    rsi,rax
  40828d:	test   rsi,rsi
  408290:	jne    4082e3 <__swc_fn_7069e055_000054_faa92dcc+0x143>
  408292:	mov    rcx,rdi
  408295:	mov    rdx,r12
  408298:	mov    r8,r14
  40829b:	call   40f6c0 <__swc_fn_7069e055_000050_129b9bf4>
  4082a0:	test   al,al
  4082a2:	jne    4082e3 <__swc_fn_7069e055_000054_faa92dcc+0x143>
  4082a4:	mov    rcx,r14
  4082a7:	call   40bee0 <__swc_fn_7069e055_000013_e4b0ddfc>
  4082ac:	mov    rax,QWORD PTR [r14]
  4082af:	test   rax,rax
  4082b2:	je     4082c1 <__swc_fn_7069e055_000054_faa92dcc+0x121>
  4082b4:	mov    rcx,QWORD PTR [rax]
  4082b7:	mov    QWORD PTR [r14],rcx
  4082ba:	add    DWORD PTR [r14+0x28],0x1
  4082bf:	jmp    4082e0 <__swc_fn_7069e055_000054_faa92dcc+0x140>
  4082c1:	mov    rax,QWORD PTR [r14+0x18]
  4082c5:	cmp    QWORD PTR [r14+0x20],rax
  4082c9:	jae    4082de <__swc_fn_7069e055_000054_faa92dcc+0x13e>
  4082cb:	mov    rax,QWORD PTR [r14+0x20]
  4082cf:	mov    ecx,DWORD PTR [r14+0x2c]
  4082d3:	add    QWORD PTR [r14+0x20],rcx
  4082d7:	add    DWORD PTR [r14+0x28],0x1
  4082dc:	jmp    4082e0 <__swc_fn_7069e055_000054_faa92dcc+0x140>
  4082de:	xor    eax,eax
  4082e0:	mov    rsi,rax
  4082e3:	test   rsi,rsi
  4082e6:	je     408301 <__swc_fn_7069e055_000054_faa92dcc+0x161>
  4082e8:	mov    QWORD PTR [r13+0x0],r14
  4082ec:	mov    rax,rsi
  4082ef:	add    rsp,0x1f8
  4082f6:	pop    r15
  4082f8:	pop    r14
  4082fa:	pop    r13
  4082fc:	pop    r12
  4082fe:	pop    rdi
  4082ff:	pop    rsi
  408300:	ret
  408301:	mov    r14,r15
  408304:	jmp    4081f0 <__swc_fn_7069e055_000054_faa92dcc+0x50>
  408309:	cs nop WORD PTR [rax+rax*1+0x0]
  408313:	cs nop WORD PTR [rax+rax*1+0x0]
  40831d:	nop    DWORD PTR [rax]
  408320:	mov    rcx,rdi
  408323:	mov    rdx,r12
  408326:	mov    r8d,esi
  408329:	call   40c4c0 <__swc_fn_7069e055_000049_ad48ec88>
  40832e:	mov    r14,rax
  408331:	test   rax,rax
  408334:	jne    40834a <__swc_fn_7069e055_000054_faa92dcc+0x1aa>
  408336:	xor    eax,eax
  408338:	add    rsp,0x1f8
  40833f:	pop    r15
  408341:	pop    r14
  408343:	pop    r13
  408345:	pop    r12
  408347:	pop    rdi
  408348:	pop    rsi
  408349:	ret
  40834a:	mov    QWORD PTR [r13+0x0],r14
  40834e:	mov    rax,QWORD PTR [r14]
  408351:	test   rax,rax
  408354:	je     408366 <__swc_fn_7069e055_000054_faa92dcc+0x1c6>
  408356:	mov    rcx,QWORD PTR [rax]
  408359:	mov    QWORD PTR [r14],rcx
  40835c:	add    DWORD PTR [r14+0x28],0x1
  408361:	mov    r15,rax
  408364:	jmp    408386 <__swc_fn_7069e055_000054_faa92dcc+0x1e6>
  408366:	mov    rax,QWORD PTR [r14+0x18]
  40836a:	cmp    QWORD PTR [r14+0x20],rax
  40836e:	jae    408383 <__swc_fn_7069e055_000054_faa92dcc+0x1e3>
  408370:	mov    r15,QWORD PTR [r14+0x20]
  408374:	mov    eax,DWORD PTR [r14+0x2c]
  408378:	add    QWORD PTR [r14+0x20],rax
  40837c:	add    DWORD PTR [r14+0x28],0x1
  408381:	jmp    408386 <__swc_fn_7069e055_000054_faa92dcc+0x1e6>
  408383:	xor    r15d,r15d
  408386:	test   r15,r15
  408389:	jne    4083ce <__swc_fn_7069e055_000054_faa92dcc+0x22e>
  40838b:	mov    rcx,r14
  40838e:	call   40be10 <__swc_fn_7069e055_000010_24a20786>
  408393:	test   al,al
  408395:	je     4083ce <__swc_fn_7069e055_000054_faa92dcc+0x22e>
  408397:	mov    rax,QWORD PTR [r14]
  40839a:	test   rax,rax
  40839d:	je     4083ac <__swc_fn_7069e055_000054_faa92dcc+0x20c>
  40839f:	mov    rcx,QWORD PTR [rax]
  4083a2:	mov    QWORD PTR [r14],rcx
  4083a5:	add    DWORD PTR [r14+0x28],0x1
  4083aa:	jmp    4083cb <__swc_fn_7069e055_000054_faa92dcc+0x22b>
  4083ac:	mov    rax,QWORD PTR [r14+0x18]
  4083b0:	cmp    QWORD PTR [r14+0x20],rax
  4083b4:	jae    4083c9 <__swc_fn_7069e055_000054_faa92dcc+0x229>
  4083b6:	mov    rax,QWORD PTR [r14+0x20]
  4083ba:	mov    ecx,DWORD PTR [r14+0x2c]
  4083be:	add    QWORD PTR [r14+0x20],rcx
  4083c2:	add    DWORD PTR [r14+0x28],0x1
  4083c7:	jmp    4083cb <__swc_fn_7069e055_000054_faa92dcc+0x22b>
  4083c9:	xor    eax,eax
  4083cb:	mov    r15,rax
  4083ce:	test   r15,r15
  4083d1:	je     408320 <__swc_fn_7069e055_000054_faa92dcc+0x180>
  4083d7:	mov    rax,r15
  4083da:	add    rsp,0x1f8
  4083e1:	pop    r15
  4083e3:	pop    r14
  4083e5:	pop    r13
  4083e7:	pop    r12
  4083e9:	pop    rdi
  4083ea:	pop    rsi
  4083eb:	ret
  4083ec:	add    BYTE PTR [rax],al
	...

00000000004083f0 <__swc_fn_7069e055_000057_7e1dbcb0>:
  4083f0:	push   rsi
  4083f1:	push   rdi
  4083f2:	push   r12
  4083f4:	mov    rsi,rdx
  4083f7:	mov    rax,rdx
  4083fa:	shr    rax,0xc
  4083fe:	movabs rdx,0x9e3779b97f4a7c15
  408408:	imul   rax,rdx
  40840c:	shr    rax,0x20
  408410:	lea    rax,[rax*8+0x0]
  408418:	shr    rax,0x20
  40841c:	lea    rax,[rax*8+0x0]
  408424:	lea    rax,[rcx+rax*8+0x40]
  408429:	xor    edx,edx
  40842b:	test   dl,dl
  40842d:	lea    rdi,[rcx+0x8]
  408431:	cmove  rdi,rax
  408435:	xor    edx,edx
  408437:	test   dl,dl
  408439:	lea    r12,[rcx+0x30]
  40843d:	lea    rax,[rax+0x8]
  408441:	cmove  r12,rax
  408445:	mov    rcx,rdi
  408448:	call   40e380 <__swc_fn_7069e055_000139_86bb0f90>
  40844d:	mov    QWORD PTR [rsi+0x30],0x0
  408455:	mov    rax,QWORD PTR [r12]
  408459:	mov    QWORD PTR [rsi+0x38],rax
  40845d:	test   rax,rax
  408460:	je     40846a <__swc_fn_7069e055_000057_7e1dbcb0+0x7a>
  408462:	mov    rax,QWORD PTR [rsi+0x38]
  408466:	mov    QWORD PTR [rax+0x30],rsi
  40846a:	mov    QWORD PTR [r12],rsi
  40846e:	mov    rcx,rdi
  408471:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  408476:	pop    r12
  408478:	pop    rdi
  408479:	pop    rsi
  40847a:	ret
  40847b:	add    BYTE PTR [rax],al
  40847d:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_7069e055_000060_15c28ca7>:
  408480:	lea    rax,[rdx+rdx*4]
  408484:	lea    rax,[rcx+rax*8+0x268]
  40848c:	mov    rdx,QWORD PTR [rax+0x10]
  408490:	sub    QWORD PTR [rcx+0x2a68],rdx
  408497:	sub    QWORD PTR [rcx+0x2a70],0x1
  40849f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  4084a6:	lea    rdx,[rdx+rdx*4]
  4084aa:	lea    rdx,[rcx+rdx*8+0x268]
  4084b2:	vmovups xmm0,XMMWORD PTR [rdx]
  4084b6:	vmovups XMMWORD PTR [rax],xmm0
  4084ba:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  4084bf:	vmovups XMMWORD PTR [rax+0x10],xmm0
  4084c4:	mov    rcx,QWORD PTR [rdx+0x20]
  4084c8:	mov    QWORD PTR [rax+0x20],rcx
  4084cc:	ret
  4084cd:	add    BYTE PTR [rax],al
	...

00000000004084d0 <__swc_fn_7069e055_000063_dea90857>:
  4084d0:	push   rsi
  4084d1:	push   rdi
  4084d2:	push   r12
  4084d4:	push   r13
  4084d6:	sub    rsp,0x8
  4084da:	mov    rsi,r8
  4084dd:	mov    rdi,rcx
  4084e0:	mov    r12,rdx
  4084e3:	xor    r13d,r13d
  4084e6:	cs nop WORD PTR [rax+rax*1+0x0]
  4084f0:	mov    eax,DWORD PTR [r12+0x730]
  4084f8:	cmp    r13d,eax
  4084fb:	jae    408561 <__swc_fn_7069e055_000063_dea90857+0x91>
  4084fd:	lea    rax,[r13+r13*4+0x0]
  408502:	lea    rax,[r12+rax*8+0x738]
  40850a:	mov    rdx,QWORD PTR [rax]
  40850d:	mov    r8,QWORD PTR [rax+0x8]
  408511:	mov    r9,QWORD PTR [rax+0x10]
  408515:	cmp    QWORD PTR [rax+0x20],rsi
  408519:	jb     408520 <__swc_fn_7069e055_000063_dea90857+0x50>
  40851b:	inc    r13d
  40851e:	jmp    4084f0 <__swc_fn_7069e055_000063_dea90857+0x20>
  408520:	sub    DWORD PTR [r12+0x730],0x1
  408529:	mov    ecx,DWORD PTR [r12+0x730]
  408531:	lea    rcx,[rcx+rcx*4]
  408535:	lea    rcx,[r12+rcx*8+0x738]
  40853d:	vmovups xmm0,XMMWORD PTR [rcx]
  408541:	vmovups XMMWORD PTR [rax],xmm0
  408545:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40854a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40854f:	mov    rcx,QWORD PTR [rcx+0x20]
  408553:	mov    QWORD PTR [rax+0x20],rcx
  408557:	mov    rcx,rdi
  40855a:	call   40c240 <__swc_fn_7069e055_000043_d3c2ab54>
  40855f:	jmp    4084f0 <__swc_fn_7069e055_000063_dea90857+0x20>
  408561:	add    rsp,0x8
  408565:	pop    r13
  408567:	pop    r12
  408569:	pop    rdi
  40856a:	pop    rsi
  40856b:	ret
  40856c:	add    BYTE PTR [rax],al
	...

0000000000408570 <__swc_fn_7069e055_000066_de167e8d>:
  408570:	push   rsi
  408571:	push   rdi
  408572:	push   r12
  408574:	push   r13
  408576:	push   r14
  408578:	mov    rsi,rcx
  40857b:	mov    rdi,rdx
  40857e:	mov    r12,QWORD PTR [rdi]
  408581:	mov    r13,QWORD PTR [rdi+0x18]
  408585:	mov    rax,r12
  408588:	add    rax,QWORD PTR [rdi+0x8]
  40858c:	sub    rax,r13
  40858f:	cmp    r8,rax
  408592:	jbe    40859d <__swc_fn_7069e055_000066_de167e8d+0x2d>
  408594:	pop    r14
  408596:	pop    r13
  408598:	pop    r12
  40859a:	pop    rdi
  40859b:	pop    rsi
  40859c:	ret
  40859d:	lea    rax,[r13+r8*1+0x0]
  4085a2:	sub    rax,r12
  4085a5:	mov    ecx,0x1000
  4085aa:	test   ecx,ecx
  4085ac:	mov    edx,0x8
  4085b1:	cmove  ecx,edx
  4085b4:	dec    rcx
  4085b7:	mov    rdx,0xffffffffffffffff
  4085be:	sub    rdx,rcx
  4085c1:	cmp    rax,rdx
  4085c4:	jbe    4085cb <__swc_fn_7069e055_000066_de167e8d+0x5b>
  4085c6:	xor    r14d,r14d
  4085c9:	jmp    4085d6 <__swc_fn_7069e055_000066_de167e8d+0x66>
  4085cb:	add    rax,rcx
  4085ce:	andn   rax,rcx,rax
  4085d3:	mov    r14,rax
  4085d6:	mov    rax,QWORD PTR [rdi+0x10]
  4085da:	cmp    r14,rax
  4085dd:	ja     4085e8 <__swc_fn_7069e055_000066_de167e8d+0x78>
  4085df:	pop    r14
  4085e1:	pop    r13
  4085e3:	pop    r12
  4085e5:	pop    rdi
  4085e6:	pop    rsi
  4085e7:	ret
  4085e8:	mov    rax,r12
  4085eb:	add    rax,QWORD PTR [rdi+0x10]
  4085ef:	mov    rdx,r14
  4085f2:	sub    rdx,QWORD PTR [rdi+0x10]
  4085f6:	mov    rcx,rax
  4085f9:	call   40bd90 <__swc_fn_7069e055_000007_f7acedb0>
  4085fe:	test   al,al
  408600:	jne    40860b <__swc_fn_7069e055_000066_de167e8d+0x9b>
  408602:	pop    r14
  408604:	pop    r13
  408606:	pop    r12
  408608:	pop    rdi
  408609:	pop    rsi
  40860a:	ret
  40860b:	add    r12,r14
  40860e:	sub    r12,r13
  408611:	mov    rcx,r12
  408614:	sub    rcx,QWORD PTR [rdi+0x28]
  408618:	mov    rdx,QWORD PTR [rsi+0x250]
  40861f:	nop
  408620:	lea    r8,[rdx+rcx*1]
  408624:	mov    rax,rdx
  408627:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  408630:	cmp    rax,rdx
  408633:	je     40863a <__swc_fn_7069e055_000066_de167e8d+0xca>
  408635:	mov    rdx,rax
  408638:	jmp    408620 <__swc_fn_7069e055_000066_de167e8d+0xb0>
  40863a:	mov    QWORD PTR [rdi+0x10],r14
  40863e:	mov    QWORD PTR [rdi+0x28],r12
  408642:	pop    r14
  408644:	pop    r13
  408646:	pop    r12
  408648:	pop    rdi
  408649:	pop    rsi
  40864a:	ret
  40864b:	add    BYTE PTR [rax],al
  40864d:	add    BYTE PTR [rax],al
	...

0000000000408650 <__swc_fn_7069e055_000069_7130736e>:
  408650:	push   rbx
  408651:	push   rsi
  408652:	push   rdi
  408653:	push   r12
  408655:	push   r13
  408657:	sub    rsp,0xe0
  40865e:	mov    rbx,rdx
  408661:	mov    rsi,rcx
  408664:	cmp    DWORD PTR [rbx+0x58],0x0
  408668:	je     40868c <__swc_fn_7069e055_000069_7130736e+0x3c>
  40866a:	mov    eax,DWORD PTR [rbx+0x58]
  40866d:	sub    eax,0x1
  408670:	test   DWORD PTR [rbx+0x58],eax
  408673:	je     40868c <__swc_fn_7069e055_000069_7130736e+0x3c>
  408675:	mov    QWORD PTR [rbx+0x40],0x0
  40867d:	add    rsp,0xe0
  408684:	pop    r13
  408686:	pop    r12
  408688:	pop    rdi
  408689:	pop    rsi
  40868a:	pop    rbx
  40868b:	ret
  40868c:	mov    rax,QWORD PTR [rbx+0x40]
  408690:	test   rax,rax
  408693:	jne    4086af <__swc_fn_7069e055_000069_7130736e+0x5f>
  408695:	mov    rcx,rsi
  408698:	mov    rdx,rbx
  40869b:	call   410370 <__swc_fn_7069e055_000068_f3aa21af>
  4086a0:	add    rsp,0xe0
  4086a7:	pop    r13
  4086a9:	pop    r12
  4086ab:	pop    rdi
  4086ac:	pop    rsi
  4086ad:	pop    rbx
  4086ae:	ret
  4086af:	cmp    QWORD PTR [rbx+0x48],0x0
  4086b4:	jne    4086d0 <__swc_fn_7069e055_000069_7130736e+0x80>
  4086b6:	mov    rcx,rsi
  4086b9:	mov    rdx,rbx
  4086bc:	call   40ca70 <__swc_fn_7069e055_000070_97813b89>
  4086c1:	add    rsp,0xe0
  4086c8:	pop    r13
  4086ca:	pop    r12
  4086cc:	pop    rdi
  4086cd:	pop    rsi
  4086ce:	pop    rbx
  4086cf:	ret
  4086d0:	mov    rdi,QWORD PTR [rbx+0x40]
  4086d4:	lea    rax,[rip+0x1b9c5]        # 4240a0 <__swc_bss_base_7069e055+0x60>
  4086db:	mov    rcx,rdi
  4086de:	sub    rcx,QWORD PTR [rax+0x8]
  4086e2:	mov    rax,QWORD PTR [rip+0x1b9c7]        # 4240b0 <__swc_bss_base_7069e055+0x70>
  4086e9:	cmp    rcx,rax
  4086ec:	jae    408718 <__swc_fn_7069e055_000069_7130736e+0xc8>
  4086ee:	mov    rax,rdi
  4086f1:	and    rax,0xffffffffffc00000
  4086f8:	mov    rcx,rdi
  4086fb:	shr    rcx,0x10
  4086ff:	and    ecx,0x3f
  408702:	mov    edx,DWORD PTR [rax+0x28]
  408705:	shrx   ecx,ecx,edx
  40870a:	shl    rcx,0x4
  40870e:	lea    r12,[rax+rcx*8+0x80]
  408716:	jmp    408723 <__swc_fn_7069e055_000069_7130736e+0xd3>
  408718:	mov    rcx,rdi
  40871b:	call   40f3f0 <__swc_fn_7069e055_000026_bcdc5519>
  408720:	mov    r12,rax
  408723:	test   r12,r12
  408726:	je     408735 <__swc_fn_7069e055_000069_7130736e+0xe5>
  408728:	mov    eax,DWORD PTR [r12+0x2c]
  40872d:	mov    r9d,eax
  408730:	mov    r13,rax
  408733:	jmp    4087b4 <__swc_fn_7069e055_000069_7130736e+0x164>
  408735:	mov    rcx,rsi
  408738:	mov    rdx,rdi
  40873b:	call   40fa00 <__swc_fn_7069e055_000056_df0696cd>
  408740:	mov    rcx,QWORD PTR [rax+0x28]
  408744:	mov    r9,rcx
  408747:	mov    rdx,QWORD PTR [rax+0x20]
  40874b:	mov    r13,rdx
  40874e:	cmp    QWORD PTR [rbx+0x48],rcx
  408752:	jbe    40878b <__swc_fn_7069e055_000069_7130736e+0x13b>
  408754:	mov    ecx,DWORD PTR [rax+0x48]
  408757:	cmp    DWORD PTR [rbx+0x58],ecx
  40875a:	ja     40878b <__swc_fn_7069e055_000069_7130736e+0x13b>
  40875c:	mov    rcx,rsi
  40875f:	mov    rdx,rax
  408762:	mov    r8,QWORD PTR [rbx+0x48]
  408766:	mov    QWORD PTR [rsp+0xc8],r9
  40876e:	mov    QWORD PTR [rsp+0xd0],rax
  408776:	call   408570 <__swc_fn_7069e055_000066_de167e8d>
  40877b:	mov    r9,QWORD PTR [rsp+0xc8]
  408783:	mov    rax,QWORD PTR [rsp+0xd0]
  40878b:	mov    rcx,QWORD PTR [rax+0x28]
  40878f:	cmp    QWORD PTR [rbx+0x48],rcx
  408793:	ja     4087b4 <__swc_fn_7069e055_000069_7130736e+0x164>
  408795:	mov    ecx,DWORD PTR [rax+0x48]
  408798:	cmp    DWORD PTR [rbx+0x58],ecx
  40879b:	ja     4087b4 <__swc_fn_7069e055_000069_7130736e+0x164>
  40879d:	mov    rcx,QWORD PTR [rbx+0x48]
  4087a1:	mov    QWORD PTR [rax+0x20],rcx
  4087a5:	add    rsp,0xe0
  4087ac:	pop    r13
  4087ae:	pop    r12
  4087b0:	pop    rdi
  4087b1:	pop    rsi
  4087b2:	pop    rbx
  4087b3:	ret
  4087b4:	test   r12,r12
  4087b7:	je     4087e9 <__swc_fn_7069e055_000069_7130736e+0x199>
  4087b9:	cmp    QWORD PTR [rbx+0x48],r9
  4087bd:	ja     4087e9 <__swc_fn_7069e055_000069_7130736e+0x199>
  4087bf:	cmp    DWORD PTR [rbx+0x58],0x40
  4087c3:	ja     4087e9 <__swc_fn_7069e055_000069_7130736e+0x199>
  4087c5:	cmp    DWORD PTR [rbx+0x58],0x0
  4087c9:	je     4087d6 <__swc_fn_7069e055_000069_7130736e+0x186>
  4087cb:	mov    ecx,DWORD PTR [rbx+0x58]
  4087ce:	dec    rcx
  4087d1:	test   rdi,rcx
  4087d4:	jne    4087e9 <__swc_fn_7069e055_000069_7130736e+0x199>
  4087d6:	mov    QWORD PTR [rbx+0x40],rdi
  4087da:	add    rsp,0xe0
  4087e1:	pop    r13
  4087e3:	pop    r12
  4087e5:	pop    rdi
  4087e6:	pop    rsi
  4087e7:	pop    rbx
  4087e8:	ret
  4087e9:	vmovups xmm0,XMMWORD PTR [rbx]
  4087ed:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4087f3:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  4087f8:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4087fe:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  408803:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  408809:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40880e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  408814:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  408819:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40881f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  408824:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40882a:	mov    QWORD PTR [rsp+0x48],0x0
  408833:	mov    rcx,rsi
  408836:	lea    rdx,[rsp+0x8]
  40883b:	call   410370 <__swc_fn_7069e055_000068_f3aa21af>
  408840:	mov    rax,QWORD PTR [rsp+0x48]
  408845:	test   rax,rax
  408848:	jne    408861 <__swc_fn_7069e055_000069_7130736e+0x211>
  40884a:	mov    QWORD PTR [rbx+0x40],0x0
  408852:	add    rsp,0xe0
  408859:	pop    r13
  40885b:	pop    r12
  40885d:	pop    rdi
  40885e:	pop    rsi
  40885f:	pop    rbx
  408860:	ret
  408861:	mov    rax,QWORD PTR [rbx+0x48]
  408865:	cmp    r13,rax
  408868:	cmovbe rax,r13
  40886c:	mov    rcx,QWORD PTR [rsp+0x48]
  408871:	mov    rdx,rdi
  408874:	mov    r8,rax
  408877:	call   40dbc0 <__swc_fn_7069e055_000109_7c204aac>
  40887c:	vmovups xmm0,XMMWORD PTR [rbx]
  408880:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  408886:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40888b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  408891:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  408896:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40889f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  4088a4:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4088ad:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  4088b2:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4088bb:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  4088c0:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4088c9:	mov    QWORD PTR [rsp+0xa8],rdi
  4088d1:	mov    rcx,rsi
  4088d4:	lea    rdx,[rsp+0x68]
  4088d9:	call   40ca70 <__swc_fn_7069e055_000070_97813b89>
  4088de:	mov    rax,QWORD PTR [rsp+0x48]
  4088e3:	mov    QWORD PTR [rbx+0x40],rax
  4088e7:	add    rsp,0xe0
  4088ee:	pop    r13
  4088f0:	pop    r12
  4088f2:	pop    rdi
  4088f3:	pop    rsi
  4088f4:	pop    rbx
  4088f5:	ret
	...

0000000000408900 <__swc_fn_7069e055_000072_61e60aab>:
  408900:	push   r12
  408902:	push   rdi
  408903:	push   rsi
  408904:	push   r13
  408906:	push   r14
  408908:	sub    rsp,0x190
  40890f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  408918:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  408921:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40892a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  408933:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40893c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  408945:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40894e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  408957:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  408960:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  408969:	mov    r12,rcx
  40896c:	lea    rax,[rip+0x19695]        # 422008 <__swc_data_base_7069e055+0x8>
  408973:	mov    rax,QWORD PTR [rax]
  408976:	cmp    rax,0xffffffffffffffff
  40897a:	je     408989 <__swc_fn_7069e055_000072_61e60aab+0x89>
  40897c:	mov    eax,eax
  40897e:	mov    edi,eax
  408980:	xor    eax,eax
  408982:	call   407000 <pthread_getspecific@plt>
  408987:	jmp    40898b <__swc_fn_7069e055_000072_61e60aab+0x8b>
  408989:	xor    eax,eax
  40898b:	test   rax,rax
  40898e:	jne    40899d <__swc_fn_7069e055_000072_61e60aab+0x9d>
  408990:	call   40f4c0 <__swc_fn_7069e055_000035_cd1a4e8c>
  408995:	mov    rcx,rax
  408998:	call   40a0c0 <__swc_fn_7069e055_000132_5f757033>
  40899d:	test   rax,rax
  4089a0:	je     4089c6 <__swc_fn_7069e055_000072_61e60aab+0xc6>
  4089a2:	cmp    QWORD PTR [rax],r12
  4089a5:	jne    4089c6 <__swc_fn_7069e055_000072_61e60aab+0xc6>
  4089a7:	xor    ecx,ecx
  4089a9:	mov    QWORD PTR [rsp+0xc8],rax
  4089b1:	call   40c210 <__swc_fn_7069e055_000037_28d0e998>
  4089b6:	mov    rdx,QWORD PTR [rsp+0xc8]
  4089be:	mov    rcx,r12
  4089c1:	call   40c320 <__swc_fn_7069e055_000046_b30433d0>
  4089c6:	lea    rsi,[r12+0x10]
  4089cb:	mov    rcx,rsi
  4089ce:	call   40e380 <__swc_fn_7069e055_000139_86bb0f90>
  4089d3:	mov    rdi,QWORD PTR [r12+0x20]
  4089d8:	test   rdi,rdi
  4089db:	je     408a1e <__swc_fn_7069e055_000072_61e60aab+0x11e>
  4089dd:	nop    DWORD PTR [rax]
  4089e0:	mov    rcx,r12
  4089e3:	mov    rdx,rdi
  4089e6:	call   40f680 <__swc_fn_7069e055_000047_6e7a8d58>
  4089eb:	mov    rcx,r12
  4089ee:	mov    rdx,rdi
  4089f1:	mov    r8,0xffffffffffffffff
  4089f8:	call   4084d0 <__swc_fn_7069e055_000063_dea90857>
  4089fd:	mov    rcx,r12
  408a00:	mov    rdx,rdi
  408a03:	mov    r8d,0x9b8
  408a09:	mov    r9d,0x9b8
  408a0f:	call   40c240 <__swc_fn_7069e055_000043_d3c2ab54>
  408a14:	mov    rdi,QWORD PTR [r12+0x20]
  408a19:	test   rdi,rdi
  408a1c:	jne    4089e0 <__swc_fn_7069e055_000072_61e60aab+0xe0>
  408a1e:	xor    eax,eax
  408a20:	xchg   QWORD PTR [r12+0x2a80],rax
  408a28:	test   rax,rax
  408a2b:	je     408a51 <__swc_fn_7069e055_000072_61e60aab+0x151>
  408a2d:	cs nop WORD PTR [rax+rax*1+0x0]
  408a37:	nop    WORD PTR [rax+rax*1+0x0]
  408a40:	mov    rcx,rax
  408a43:	mov    rax,QWORD PTR [rax+0x78]
  408a47:	xor    edx,edx
  408a49:	xchg   DWORD PTR [rcx+0x70],edx
  408a4c:	test   rax,rax
  408a4f:	jne    408a40 <__swc_fn_7069e055_000072_61e60aab+0x140>
  408a51:	mov    rax,QWORD PTR [r12+0x18]
  408a56:	mov    rdi,rax
  408a59:	test   rdi,rdi
  408a5c:	je     408af1 <__swc_fn_7069e055_000072_61e60aab+0x1f1>
  408a62:	cs nop WORD PTR [rax+rax*1+0x0]
  408a6c:	nop    DWORD PTR [rax+0x0]
  408a70:	mov    rax,QWORD PTR [rdi+0x10]
  408a74:	mov    r8d,DWORD PTR [rdi+0x2c]
  408a78:	xor    r9d,r9d
  408a7b:	test   r8,r8
  408a7e:	jbe    408add <__swc_fn_7069e055_000072_61e60aab+0x1dd>
  408a80:	mov    ecx,r9d
  408a83:	shl    rcx,0x4
  408a87:	lea    rdx,[rdi+rcx*8+0x80]
  408a8f:	cmp    BYTE PTR [rdx+0x3b],0x0
  408a93:	je     408ad4 <__swc_fn_7069e055_000072_61e60aab+0x1d4>
  408a95:	mov    DWORD PTR [rdx+0x28],0x0
  408a9c:	mov    rcx,rdi
  408a9f:	mov    QWORD PTR [rsp+0xd0],rax
  408aa7:	mov    QWORD PTR [rsp+0xd8],r8
  408aaf:	mov    QWORD PTR [rsp+0xe0],r9
  408ab7:	call   407c00 <__swc_fn_7069e055_000018_283e2b5e>
  408abc:	mov    rax,QWORD PTR [rsp+0xd0]
  408ac4:	mov    r8,QWORD PTR [rsp+0xd8]
  408acc:	mov    r9,QWORD PTR [rsp+0xe0]
  408ad4:	add    r9,0x1
  408ad8:	cmp    r9,r8
  408adb:	jb     408a80 <__swc_fn_7069e055_000072_61e60aab+0x180>
  408add:	mov    rcx,rdi
  408ae0:	mov    rdi,rax
  408ae3:	call   40c120 <__swc_fn_7069e055_000025_aa910677>
  408ae8:	test   rdi,rdi
  408aeb:	jne    408a70 <__swc_fn_7069e055_000072_61e60aab+0x170>
  408af1:	mov    QWORD PTR [r12+0x18],0x0
  408afa:	mov    QWORD PTR [r12+0x28],0x0
  408b03:	mov    rcx,rsi
  408b06:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  408b0b:	mov    esi,0x8
  408b10:	xor    edi,edi
  408b12:	test   rsi,rsi
  408b15:	je     408b72 <__swc_fn_7069e055_000072_61e60aab+0x272>
  408b1b:	nop    DWORD PTR [rax+rax*1+0x0]
  408b20:	lea    r13,[rdi*8+0x0]
  408b28:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  408b2d:	test   r14,r14
  408b30:	je     408b68 <__swc_fn_7069e055_000072_61e60aab+0x268>
  408b32:	cs nop WORD PTR [rax+rax*1+0x0]
  408b3c:	nop    DWORD PTR [rax+0x0]
  408b40:	mov    rcx,r12
  408b43:	mov    rdx,r14
  408b46:	call   40c8d0 <__swc_fn_7069e055_000058_1bb23e77>
  408b4b:	mov    rcx,r12
  408b4e:	mov    rdx,QWORD PTR [r14]
  408b51:	mov    r8,QWORD PTR [r14+0x8]
  408b55:	mov    r9,QWORD PTR [r14+0x10]
  408b59:	call   40c240 <__swc_fn_7069e055_000043_d3c2ab54>
  408b5e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  408b63:	test   r14,r14
  408b66:	jne    408b40 <__swc_fn_7069e055_000072_61e60aab+0x240>
  408b68:	add    rdi,0x1
  408b6c:	sub    rsi,0x1
  408b70:	jne    408b20 <__swc_fn_7069e055_000072_61e60aab+0x220>
  408b72:	mov    rcx,r12
  408b75:	call   40c9a0 <__swc_fn_7069e055_000064_ffcd96eb>
  408b7a:	lea    rcx,[r12+0x250]
  408b82:	mov    rdx,QWORD PTR [rcx]
  408b85:	mov    r8,QWORD PTR [r12+0x250]
  408b8d:	nop    DWORD PTR [rax]
  408b90:	mov    r9,r8
  408b93:	sub    r9,rdx
  408b96:	mov    rax,r8
  408b99:	lock cmpxchg QWORD PTR [rcx],r9
  408b9e:	cmp    rax,r8
  408ba1:	je     408ba8 <__swc_fn_7069e055_000072_61e60aab+0x2a8>
  408ba3:	mov    r8,rax
  408ba6:	jmp    408b90 <__swc_fn_7069e055_000072_61e60aab+0x290>
  408ba8:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  408bb1:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  408bba:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  408bc3:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  408bcc:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  408bd5:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  408bde:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  408be7:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  408bf0:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  408bf9:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  408c02:	add    rsp,0x190
  408c09:	pop    r14
  408c0b:	pop    r13
  408c0d:	pop    rsi
  408c0e:	pop    rdi
  408c0f:	pop    r12
  408c11:	ret
	...

0000000000408c20 <__swc_fn_7069e055_000075_64d36d78>:
  408c20:	sub    rsp,0x8
  408c24:	mov    QWORD PTR [rdx+0x40],0x0
  408c2c:	call   410370 <__swc_fn_7069e055_000068_f3aa21af>
  408c31:	add    rsp,0x8
  408c35:	ret
	...

0000000000408c40 <__swc_fn_7069e055_000078_1966ae2e>:
  408c40:	sub    rsp,0x8
  408c44:	call   40ca70 <__swc_fn_7069e055_000070_97813b89>
  408c49:	add    rsp,0x8
  408c4d:	ret
	...

0000000000408c50 <__swc_fn_7069e055_000081_5cc7acfc>:
  408c50:	push   rbx
  408c51:	push   rsi
  408c52:	push   rdi
  408c53:	push   r12
  408c55:	push   r13
  408c57:	push   r14
  408c59:	push   r15
  408c5b:	sub    rsp,0x20
  408c5f:	mov    rbx,r11
  408c62:	mov    rsi,rcx
  408c65:	mov    rdi,rdx
  408c68:	mov    r12,r8
  408c6b:	mov    r13,r9
  408c6e:	mov    r14,r10
  408c71:	mov    rcx,QWORD PTR [rip+0x1b3c8]        # 424040 <__swc_bss_base_7069e055>
  408c78:	test   rcx,rcx
  408c7b:	jne    408c8d <__swc_fn_7069e055_000081_5cc7acfc+0x3d>
  408c7d:	call   40ec80 <__swc_fn_7069e055_000169_994c8876>
  408c82:	lea    rcx,[rax+0x1]
  408c86:	mov    QWORD PTR [rip+0x1b3b3],rcx        # 424040 <__swc_bss_base_7069e055>
  408c8d:	dec    rcx
  408c90:	call   40bb40 <__swc_fn_7069e055_000171_360af05d>
  408c95:	mov    r15,rax
  408c98:	lea    r11,[rip+0x1b5a1]        # 424240 <__swc_bss_base_7069e055+0x200>
  408c9f:	mov    rcx,r11
  408ca2:	call   40c230 <__swc_fn_7069e055_000040_eb6108f2>
  408ca7:	test   al,al
  408ca9:	jne    408cba <__swc_fn_7069e055_000081_5cc7acfc+0x6a>
  408cab:	mov    rcx,r11
  408cae:	call   40f520 <__swc_fn_7069e055_000038_14f56618>
  408cb3:	lea    r11,[rip+0x1b586]        # 424240 <__swc_bss_base_7069e055+0x200>
  408cba:	mov    rcx,r11
  408cbd:	mov    rdx,rsi
  408cc0:	mov    r8,rdi
  408cc3:	mov    r9,r12
  408cc6:	mov    r10,r13
  408cc9:	mov    rsi,r11
  408ccc:	mov    r11,r14
  408ccf:	call   407f70 <__swc_fn_7069e055_000039_03f1bf9a>
  408cd4:	test   bl,bl
  408cd6:	je     408cfd <__swc_fn_7069e055_000081_5cc7acfc+0xad>
  408cd8:	mov    QWORD PTR [rsp+0x8],rsi
  408cdd:	lea    rax,[rip+0xa594]        # 413278 <__swc_rdata_base_7069e055+0x168>
  408ce4:	mov    QWORD PTR [rsp+0x10],rax
  408ce9:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  408cef:	vmovups XMMWORD PTR [r15],xmm0
  408cf4:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  408cfd:	mov    rax,rsi
  408d00:	add    rsp,0x20
  408d04:	pop    r15
  408d06:	pop    r14
  408d08:	pop    r13
  408d0a:	pop    r12
  408d0c:	pop    rdi
  408d0d:	pop    rsi
  408d0e:	pop    rbx
  408d0f:	ret

0000000000408d10 <__swc_fn_7069e055_000084_cf82995a>:
  408d10:	sub    rsp,0x8
  408d14:	mov    rax,rcx
  408d17:	test   rcx,rcx
  408d1a:	jne    408d21 <__swc_fn_7069e055_000084_cf82995a+0x11>
  408d1c:	add    rsp,0x8
  408d20:	ret
  408d21:	lea    rcx,[rax-0x10]
  408d25:	mov    rax,QWORD PTR [rax-0x10]
  408d29:	mov    rdx,rax
  408d2c:	call   409d70 <__swc_fn_7069e055_000117_ed2d8fed>
  408d31:	add    rsp,0x8
  408d35:	ret
	...

0000000000408d40 <__swc_fn_7069e055_000087_ef55f6e4>:
  408d40:	sub    rsp,0x8
  408d44:	xor    r11d,r11d
  408d47:	call   40cd30 <__swc_fn_7069e055_000088_0d280354>
  408d4c:	add    rsp,0x8
  408d50:	ret
	...

0000000000408d60 <__swc_fn_7069e055_000090_23214800>:
  408d60:	push   rsi
  408d61:	push   rdi
  408d62:	push   r12
  408d64:	push   r13
  408d66:	push   r14
  408d68:	push   r15
  408d6a:	sub    rsp,0x68
  408d6e:	mov    rsi,r9
  408d71:	mov    rdi,rcx
  408d74:	mov    r12,rdx
  408d77:	mov    r13,r8
  408d7a:	cmp    r8,r9
  408d7d:	jne    408da5 <__swc_fn_7069e055_000090_23214800+0x45>
  408d7f:	mov    rcx,rdi
  408d82:	mov    rdx,r12
  408d85:	xor    r8d,r8d
  408d88:	call   40d080 <__swc_fn_7069e055_000094_63c1827b>
  408d8d:	test   al,al
  408d8f:	je     408da5 <__swc_fn_7069e055_000090_23214800+0x45>
  408d91:	mov    eax,0x1
  408d96:	add    rsp,0x68
  408d9a:	pop    r15
  408d9c:	pop    r14
  408d9e:	pop    r13
  408da0:	pop    r12
  408da2:	pop    rdi
  408da3:	pop    rsi
  408da4:	ret
  408da5:	cmp    BYTE PTR [r12+0x2c],0xe
  408dab:	je     408dbe <__swc_fn_7069e055_000090_23214800+0x5e>
  408dad:	xor    eax,eax
  408daf:	add    rsp,0x68
  408db3:	pop    r15
  408db5:	pop    r14
  408db7:	pop    r13
  408db9:	pop    r12
  408dbb:	pop    rdi
  408dbc:	pop    rsi
  408dbd:	ret
  408dbe:	mov    r14,QWORD PTR [r12+0x98]
  408dc6:	mov    rax,QWORD PTR [r12+0xa0]
  408dce:	mov    r12,rax
  408dd1:	xor    r15d,r15d
  408dd4:	test   r12,r12
  408dd7:	je     408e3f <__swc_fn_7069e055_000090_23214800+0xdf>
  408dd9:	nop    DWORD PTR [rax+0x0]
  408de0:	mov    QWORD PTR [rsp+0x58],r12
  408de5:	lea    r12,[r15*8+0x0]
  408ded:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  408df2:	mov    rcx,rax
  408df5:	call   410b00 <__swc_fn_7069e055_000086_3953ef98>
  408dfa:	cmp    BYTE PTR [rax+0x2c],0xe
  408dfe:	jne    408e30 <__swc_fn_7069e055_000090_23214800+0xd0>
  408e00:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  408e05:	lea    r8,[r13+rcx*1+0x0]
  408e0a:	mov    rcx,rdi
  408e0d:	mov    rdx,rax
  408e10:	mov    r9,rsi
  408e13:	call   408d60 <__swc_fn_7069e055_000090_23214800>
  408e18:	test   al,al
  408e1a:	je     408e30 <__swc_fn_7069e055_000090_23214800+0xd0>
  408e1c:	mov    eax,0x1
  408e21:	add    rsp,0x68
  408e25:	pop    r15
  408e27:	pop    r14
  408e29:	pop    r13
  408e2b:	pop    r12
  408e2d:	pop    rdi
  408e2e:	pop    rsi
  408e2f:	ret
  408e30:	add    r15,0x1
  408e34:	mov    r12,QWORD PTR [rsp+0x58]
  408e39:	sub    r12,0x1
  408e3d:	jne    408de0 <__swc_fn_7069e055_000090_23214800+0x80>
  408e3f:	xor    eax,eax
  408e41:	add    rsp,0x68
  408e45:	pop    r15
  408e47:	pop    r14
  408e49:	pop    r13
  408e4b:	pop    r12
  408e4d:	pop    rdi
  408e4e:	pop    rsi
  408e4f:	ret

0000000000408e50 <__swc_fn_7069e055_000093_c2567a3b>:
  408e50:	push   rbp
  408e51:	push   rbx
  408e52:	push   rsi
  408e53:	push   rdi
  408e54:	push   r12
  408e56:	push   r13
  408e58:	push   r14
  408e5a:	push   r15
  408e5c:	sub    rsp,0x38
  408e60:	mov    rbp,rsp
  408e63:	mov    rbx,r11
  408e66:	mov    rsi,rdx
  408e69:	mov    rdi,r8
  408e6c:	mov    r12,r9
  408e6f:	mov    QWORD PTR [rsp+0x18],r9
  408e74:	mov    r13,r10
  408e77:	movzx  r14d,BYTE PTR [rbp+0x80]
  408e7f:	movzx  r15d,BYTE PTR [rbp+0x88]
  408e87:	test   r11,r11
  408e8a:	je     408e90 <__swc_fn_7069e055_000093_c2567a3b+0x40>
  408e8c:	xor    eax,eax
  408e8e:	mov    BYTE PTR [rbx],al
  408e90:	test   r12,r12
  408e93:	je     408e9e <__swc_fn_7069e055_000093_c2567a3b+0x4e>
  408e95:	mov    QWORD PTR [r12+0x8],0x0
  408e9e:	test   rcx,rcx
  408ea1:	je     408ea8 <__swc_fn_7069e055_000093_c2567a3b+0x58>
  408ea3:	test   rsi,rsi
  408ea6:	jne    408ebb <__swc_fn_7069e055_000093_c2567a3b+0x6b>
  408ea8:	xor    eax,eax
  408eaa:	add    rsp,0x38
  408eae:	pop    r15
  408eb0:	pop    r14
  408eb2:	pop    r13
  408eb4:	pop    r12
  408eb6:	pop    rdi
  408eb7:	pop    rsi
  408eb8:	pop    rbx
  408eb9:	pop    rbp
  408eba:	ret
  408ebb:	call   410b00 <__swc_fn_7069e055_000086_3953ef98>
  408ec0:	mov    r12,rax
  408ec3:	mov    al,r15b
  408ec6:	test   r15b,r15b
  408ec9:	jne    408ed9 <__swc_fn_7069e055_000093_c2567a3b+0x89>
  408ecb:	mov    eax,DWORD PTR [r12+0x28]
  408ed0:	and    eax,0x10000
  408ed6:	setne  al
  408ed9:	lea    r15,[rsp+0x8]
  408ede:	mov    QWORD PTR [rsp+0x20],r15
  408ee3:	rex mov BYTE PTR [rsp+0x8],al
  408ee8:	test   DWORD PTR [rsi+0x28],0x400000
  408eef:	je     408f27 <__swc_fn_7069e055_000093_c2567a3b+0xd7>
  408ef1:	test   rsi,rsi
  408ef4:	je     408f14 <__swc_fn_7069e055_000093_c2567a3b+0xc4>
  408ef6:	mov    rax,QWORD PTR [rsi+0x38]
  408efa:	cmp    QWORD PTR [rax+0x10],rsi
  408efe:	jne    408f14 <__swc_fn_7069e055_000093_c2567a3b+0xc4>
  408f00:	rex mov al,BYTE PTR [rsp+0x8]
  408f05:	test   al,al
  408f07:	sete   al
  408f0a:	test   r14b,r14b
  408f0d:	sete   cl
  408f10:	test   al,cl
  408f12:	je     408f27 <__swc_fn_7069e055_000093_c2567a3b+0xd7>
  408f14:	xor    eax,eax
  408f16:	add    rsp,0x38
  408f1a:	pop    r15
  408f1c:	pop    r14
  408f1e:	pop    r13
  408f20:	pop    r12
  408f22:	pop    rdi
  408f23:	pop    rsi
  408f24:	pop    rbx
  408f25:	pop    rbp
  408f26:	ret
  408f27:	mov    r15,r12
  408f2a:	test   r14b,r14b
  408f2d:	jne    408f44 <__swc_fn_7069e055_000093_c2567a3b+0xf4>
  408f2f:	cmp    BYTE PTR [r12+0x2c],0x6
  408f35:	jne    408f44 <__swc_fn_7069e055_000093_c2567a3b+0xf4>
  408f37:	mov    rcx,QWORD PTR [r12+0x40]
  408f3c:	call   410b00 <__swc_fn_7069e055_000086_3953ef98>
  408f41:	mov    r15,rax
  408f44:	test   r14b,r14b
  408f47:	je     408f4d <__swc_fn_7069e055_000093_c2567a3b+0xfd>
  408f49:	mov    r15,QWORD PTR [r15+0x30]
  408f4d:	mov    rcx,rsi
  408f50:	call   410b00 <__swc_fn_7069e055_000086_3953ef98>
  408f55:	mov    rsi,rax
  408f58:	rex cmp BYTE PTR [rsi+0x2c],0x6
  408f5d:	je     408f94 <__swc_fn_7069e055_000093_c2567a3b+0x144>
  408f5f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  408f64:	je     408f94 <__swc_fn_7069e055_000093_c2567a3b+0x144>
  408f66:	mov    eax,DWORD PTR [rsi+0x28]
  408f69:	and    eax,0x10000
  408f6f:	je     408f94 <__swc_fn_7069e055_000093_c2567a3b+0x144>
  408f71:	rex mov al,BYTE PTR [rsp+0x8]
  408f76:	test   al,al
  408f78:	jne    408f8d <__swc_fn_7069e055_000093_c2567a3b+0x13d>
  408f7a:	xor    eax,eax
  408f7c:	add    rsp,0x38
  408f80:	pop    r15
  408f82:	pop    r14
  408f84:	pop    r13
  408f86:	pop    r12
  408f88:	pop    rdi
  408f89:	pop    rsi
  408f8a:	pop    rbx
  408f8b:	pop    rbp
  408f8c:	ret
  408f8d:	mov    rax,QWORD PTR [rsi+0x30]
  408f91:	mov    rsi,rax
  408f94:	mov    r14b,r13b
  408f97:	test   rbx,rbx
  408f9a:	je     408fd0 <__swc_fn_7069e055_000093_c2567a3b+0x180>
  408f9c:	cmp    BYTE PTR [r12+0x2c],0x6
  408fa2:	jne    408fd0 <__swc_fn_7069e055_000093_c2567a3b+0x180>
  408fa4:	lea    rdx,[rip+0xa2fd]        # 4132a8 <__swc_rdata_base_7069e055+0x198>
  408fab:	mov    rcx,rsi
  408fae:	xor    r8d,r8d
  408fb1:	call   40d080 <__swc_fn_7069e055_000094_63c1827b>
  408fb6:	test   al,al
  408fb8:	je     408fd0 <__swc_fn_7069e055_000093_c2567a3b+0x180>
  408fba:	mov    BYTE PTR [rbx],0x1
  408fbd:	xor    eax,eax
  408fbf:	add    rsp,0x38
  408fc3:	pop    r15
  408fc5:	pop    r14
  408fc7:	pop    r13
  408fc9:	pop    r12
  408fcb:	pop    rdi
  408fcc:	pop    rsi
  408fcd:	pop    rbx
  408fce:	pop    rbp
  408fcf:	ret
  408fd0:	test   rdi,rdi
  408fd3:	jne    408fed <__swc_fn_7069e055_000093_c2567a3b+0x19d>
  408fd5:	test   r13b,r13b
  408fd8:	jne    408fed <__swc_fn_7069e055_000093_c2567a3b+0x19d>
  408fda:	xor    eax,eax
  408fdc:	add    rsp,0x38
  408fe0:	pop    r15
  408fe2:	pop    r14
  408fe4:	pop    r13
  408fe6:	pop    r12
  408fe8:	pop    rdi
  408fe9:	pop    rsi
  408fea:	pop    rbx
  408feb:	pop    rbp
  408fec:	ret
  408fed:	rex cmp BYTE PTR [rsi+0x2c],0x6
  408ff2:	jne    4090a8 <__swc_fn_7069e055_000093_c2567a3b+0x258>
  408ff8:	mov    rcx,r15
  408ffb:	mov    rdx,rsi
  408ffe:	xor    r8d,r8d
  409001:	call   40d080 <__swc_fn_7069e055_000094_63c1827b>
  409006:	test   al,al
  409008:	jne    4090a8 <__swc_fn_7069e055_000093_c2567a3b+0x258>
  40900e:	test   DWORD PTR [rsi+0x28],0x10000
  409015:	je     409033 <__swc_fn_7069e055_000093_c2567a3b+0x1e3>
  409017:	rex mov al,BYTE PTR [rsp+0x8]
  40901c:	test   al,al
  40901e:	jne    409033 <__swc_fn_7069e055_000093_c2567a3b+0x1e3>
  409020:	xor    eax,eax
  409022:	add    rsp,0x38
  409026:	pop    r15
  409028:	pop    r14
  40902a:	pop    r13
  40902c:	pop    r12
  40902e:	pop    rdi
  40902f:	pop    rsi
  409030:	pop    rbx
  409031:	pop    rbp
  409032:	ret
  409033:	test   rdi,rdi
  409036:	jne    40904b <__swc_fn_7069e055_000093_c2567a3b+0x1fb>
  409038:	xor    eax,eax
  40903a:	add    rsp,0x38
  40903e:	pop    r15
  409040:	pop    r14
  409042:	pop    r13
  409044:	pop    r12
  409046:	pop    rdi
  409047:	pop    rsi
  409048:	pop    rbx
  409049:	pop    rbp
  40904a:	ret
  40904b:	mov    rcx,QWORD PTR [rsi+0x40]
  40904f:	call   410b00 <__swc_fn_7069e055_000086_3953ef98>
  409054:	mov    rsi,rax
  409057:	mov    rax,QWORD PTR [rdi]
  40905a:	mov    rdi,rax
  40905d:	test   rax,rax
  409060:	jne    4090a3 <__swc_fn_7069e055_000093_c2567a3b+0x253>
  409062:	test   rbx,rbx
  409065:	je     4090a3 <__swc_fn_7069e055_000093_c2567a3b+0x253>
  409067:	mov    rcx,r15
  40906a:	mov    rdx,rsi
  40906d:	xor    r8d,r8d
  409070:	call   40d080 <__swc_fn_7069e055_000094_63c1827b>
  409075:	mov    rcx,rax
  409078:	test   al,al
  40907a:	jne    40909c <__swc_fn_7069e055_000093_c2567a3b+0x24c>
  40907c:	mov    rcx,r15
  40907f:	mov    rdx,rsi
  409082:	call   410b40 <__swc_fn_7069e055_000089_d182c4dc>
  409087:	mov    rcx,rax
  40908a:	test   al,al
  40908c:	jne    40909c <__swc_fn_7069e055_000093_c2567a3b+0x24c>
  40908e:	mov    rcx,rsi
  409091:	mov    rdx,r15
  409094:	call   410b40 <__swc_fn_7069e055_000089_d182c4dc>
  409099:	mov    rcx,rax
  40909c:	test   cl,cl
  40909e:	setne  al
  4090a1:	mov    BYTE PTR [rbx],al
  4090a3:	xor    eax,eax
  4090a5:	mov    r14b,al
  4090a8:	test   rdi,rdi
  4090ab:	jne    4090c5 <__swc_fn_7069e055_000093_c2567a3b+0x275>
  4090ad:	test   r14b,r14b
  4090b0:	jne    4090c5 <__swc_fn_7069e055_000093_c2567a3b+0x275>
  4090b2:	xor    eax,eax
  4090b4:	add    rsp,0x38
  4090b8:	pop    r15
  4090ba:	pop    r14
  4090bc:	pop    r13
  4090be:	pop    r12
  4090c0:	pop    rdi
  4090c1:	pop    rsi
  4090c2:	pop    rbx
  4090c3:	pop    rbp
  4090c4:	ret
  4090c5:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4090ca:	je     4090d6 <__swc_fn_7069e055_000093_c2567a3b+0x286>
  4090cc:	mov    r12,QWORD PTR [rsp+0x18]
  4090d1:	jmp    40915e <__swc_fn_7069e055_000093_c2567a3b+0x30e>
  4090d6:	mov    r12,QWORD PTR [rsp+0x18]
  4090db:	test   r12,r12
  4090de:	jne    4090f2 <__swc_fn_7069e055_000093_c2567a3b+0x2a2>
  4090e0:	mov    rcx,r15
  4090e3:	mov    rdx,rsi
  4090e6:	xor    r8d,r8d
  4090e9:	call   40d080 <__swc_fn_7069e055_000094_63c1827b>
  4090ee:	test   al,al
  4090f0:	jne    40915e <__swc_fn_7069e055_000093_c2567a3b+0x30e>
  4090f2:	test   DWORD PTR [rsi+0x28],0x10000
  4090f9:	je     409117 <__swc_fn_7069e055_000093_c2567a3b+0x2c7>
  4090fb:	rex mov al,BYTE PTR [rsp+0x8]
  409100:	test   al,al
  409102:	jne    409117 <__swc_fn_7069e055_000093_c2567a3b+0x2c7>
  409104:	xor    eax,eax
  409106:	add    rsp,0x38
  40910a:	pop    r15
  40910c:	pop    r14
  40910e:	pop    r13
  409110:	pop    r12
  409112:	pop    rdi
  409113:	pop    rsi
  409114:	pop    rbx
  409115:	pop    rbp
  409116:	ret
  409117:	test   rdi,rdi
  40911a:	jne    40912f <__swc_fn_7069e055_000093_c2567a3b+0x2df>
  40911c:	xor    eax,eax
  40911e:	add    rsp,0x38
  409122:	pop    r15
  409124:	pop    r14
  409126:	pop    r13
  409128:	pop    r12
  40912a:	pop    rdi
  40912b:	pop    rsi
  40912c:	pop    rbx
  40912d:	pop    rbp
  40912e:	ret
  40912f:	cmp    QWORD PTR [rdi+0x8],0x0
  409134:	jne    409149 <__swc_fn_7069e055_000093_c2567a3b+0x2f9>
  409136:	xor    eax,eax
  409138:	add    rsp,0x38
  40913c:	pop    r15
  40913e:	pop    r14
  409140:	pop    r13
  409142:	pop    r12
  409144:	pop    rdi
  409145:	pop    rsi
  409146:	pop    rbx
  409147:	pop    rbp
  409148:	ret
  409149:	mov    rax,QWORD PTR [rdi+0x8]
  40914d:	mov    rax,QWORD PTR [rax]
  409150:	mov    rsi,rax
  409153:	mov    rdi,QWORD PTR [rdi]
  409156:	mov    eax,0x1
  40915b:	mov    r14b,al
  40915e:	test   rdi,rdi
  409161:	mov    rbx,QWORD PTR [rsp+0x20]
  409166:	jne    4091b0 <__swc_fn_7069e055_000093_c2567a3b+0x360>
  409168:	test   r14b,r14b
  40916b:	je     40919d <__swc_fn_7069e055_000093_c2567a3b+0x34d>
  40916d:	test   r12,r12
  409170:	je     40919d <__swc_fn_7069e055_000093_c2567a3b+0x34d>
  409172:	mov    rcx,r15
  409175:	mov    rdx,rsi
  409178:	xor    r8d,r8d
  40917b:	mov    r9,r12
  40917e:	mov    rbx,QWORD PTR [rsp+0x20]
  409183:	movzx  r10d,BYTE PTR [rbx]
  409187:	call   408d40 <__swc_fn_7069e055_000087_ef55f6e4>
  40918c:	add    rsp,0x38
  409190:	pop    r15
  409192:	pop    r14
  409194:	pop    r13
  409196:	pop    r12
  409198:	pop    rdi
  409199:	pop    rsi
  40919a:	pop    rbx
  40919b:	pop    rbp
  40919c:	ret
  40919d:	xor    eax,eax
  40919f:	add    rsp,0x38
  4091a3:	pop    r15
  4091a5:	pop    r14
  4091a7:	pop    r13
  4091a9:	pop    r12
  4091ab:	pop    rdi
  4091ac:	pop    rsi
  4091ad:	pop    rbx
  4091ae:	pop    rbp
  4091af:	ret
  4091b0:	mov    r13,rsi
  4091b3:	mov    QWORD PTR [rsp+0x28],rdi
  4091b8:	cmp    BYTE PTR [r15+0x2c],0xe
  4091bd:	sete   al
  4091c0:	mov    r14b,al
  4091c3:	jne    4091d7 <__swc_fn_7069e055_000093_c2567a3b+0x387>
  4091c5:	mov    rcx,rsi
  4091c8:	mov    rdx,r15
  4091cb:	call   410b40 <__swc_fn_7069e055_000089_d182c4dc>
  4091d0:	mov    r14b,al
  4091d3:	test   al,al
  4091d5:	jne    40920c <__swc_fn_7069e055_000093_c2567a3b+0x3bc>
  4091d7:	cmp    BYTE PTR [r15+0x2c],0x12
  4091dc:	je     40920c <__swc_fn_7069e055_000093_c2567a3b+0x3bc>
  4091de:	mov    rcx,r15
  4091e1:	mov    rdx,rsi
  4091e4:	mov    r8,rdi
  4091e7:	mov    r9,r12
  4091ea:	mov    rax,rbx
  4091ed:	movzx  r10d,BYTE PTR [rax]
  4091f1:	call   408d40 <__swc_fn_7069e055_000087_ef55f6e4>
  4091f6:	test   rax,rax
  4091f9:	je     40920c <__swc_fn_7069e055_000093_c2567a3b+0x3bc>
  4091fb:	add    rsp,0x38
  4091ff:	pop    r15
  409201:	pop    r14
  409203:	pop    r13
  409205:	pop    r12
  409207:	pop    rdi
  409208:	pop    rsi
  409209:	pop    rbx
  40920a:	pop    rbp
  40920b:	ret
  40920c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  409211:	jne    409230 <__swc_fn_7069e055_000093_c2567a3b+0x3e0>
  409213:	mov    rax,QWORD PTR [rsi+0xd8]
  40921a:	test   rax,rax
  40921d:	je     409230 <__swc_fn_7069e055_000093_c2567a3b+0x3e0>
  40921f:	add    rdi,QWORD PTR [rax+0x8]
  409223:	mov    rax,QWORD PTR [rdi]
  409226:	sub    rdi,QWORD PTR [rax+0x8]
  40922a:	mov    rax,QWORD PTR [rax]
  40922d:	mov    rsi,rax
  409230:	test   r14b,r14b
  409233:	je     40925f <__swc_fn_7069e055_000093_c2567a3b+0x40f>
  409235:	mov    rcx,r15
  409238:	mov    rdx,rsi
  40923b:	mov    r8,rdi
  40923e:	mov    r9,r13
  409241:	mov    r14,QWORD PTR [rsp+0x28]
  409246:	mov    r10,r14
  409249:	call   40cf60 <__swc_fn_7069e055_000091_c1c9085b>
  40924e:	add    rsp,0x38
  409252:	pop    r15
  409254:	pop    r14
  409256:	pop    r13
  409258:	pop    r12
  40925a:	pop    rdi
  40925b:	pop    rsi
  40925c:	pop    rbx
  40925d:	pop    rbp
  40925e:	ret
  40925f:	mov    rcx,r15
  409262:	mov    rdx,rsi
  409265:	mov    r8,rdi
  409268:	mov    r9,r12
  40926b:	movzx  r10d,BYTE PTR [rbx]
  40926f:	call   408d40 <__swc_fn_7069e055_000087_ef55f6e4>
  409274:	add    rsp,0x38
  409278:	pop    r15
  40927a:	pop    r14
  40927c:	pop    r13
  40927e:	pop    r12
  409280:	pop    rdi
  409281:	pop    rsi
  409282:	pop    rbx
  409283:	pop    rbp
  409284:	ret
	...

0000000000409290 <__swc_fn_7069e055_000096_93bfe675>:
  409290:	push   rbx
  409291:	push   rsi
  409292:	sub    rsp,0x18
  409296:	mov    rbx,rcx
  409299:	mov    rcx,QWORD PTR [rip+0x1ada0]        # 424040 <__swc_bss_base_7069e055>
  4092a0:	test   rcx,rcx
  4092a3:	jne    4092b5 <__swc_fn_7069e055_000096_93bfe675+0x25>
  4092a5:	call   40ec80 <__swc_fn_7069e055_000169_994c8876>
  4092aa:	lea    rcx,[rax+0x1]
  4092ae:	mov    QWORD PTR [rip+0x1ad8b],rcx        # 424040 <__swc_bss_base_7069e055>
  4092b5:	dec    rcx
  4092b8:	call   40bb40 <__swc_fn_7069e055_000171_360af05d>
  4092bd:	mov    rsi,rax
  4092c0:	mov    rax,QWORD PTR [rsi+0x8]
  4092c4:	test   rax,rax
  4092c7:	jne    409317 <__swc_fn_7069e055_000096_93bfe675+0x87>
  4092c9:	call   410c30 <__swc_fn_7069e055_000095_ad13d15c>
  4092ce:	test   al,al
  4092d0:	jne    409317 <__swc_fn_7069e055_000096_93bfe675+0x87>
  4092d2:	lea    rdx,[rip+0x1af67]        # 424240 <__swc_bss_base_7069e055+0x200>
  4092d9:	mov    rcx,rdx
  4092dc:	call   40c230 <__swc_fn_7069e055_000040_eb6108f2>
  4092e1:	test   al,al
  4092e3:	jne    4092f4 <__swc_fn_7069e055_000096_93bfe675+0x64>
  4092e5:	mov    rcx,rdx
  4092e8:	call   40f520 <__swc_fn_7069e055_000038_14f56618>
  4092ed:	lea    rdx,[rip+0x1af4c]        # 424240 <__swc_bss_base_7069e055+0x200>
  4092f4:	mov    QWORD PTR [rsp+0x8],rdx
  4092f9:	lea    rax,[rip+0x9f78]        # 413278 <__swc_rdata_base_7069e055+0x168>
  409300:	mov    QWORD PTR [rsp+0x10],rax
  409305:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40930b:	vmovups XMMWORD PTR [rsi],xmm0
  40930f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  409317:	vmovups xmm0,XMMWORD PTR [rsi]
  40931b:	vmovups XMMWORD PTR [rbx],xmm0
  40931f:	mov    rax,rbx
  409322:	add    rsp,0x18
  409326:	pop    rsi
  409327:	pop    rbx
  409328:	ret
  409329:	add    BYTE PTR [rax],al
  40932b:	add    BYTE PTR [rax],al
  40932d:	add    BYTE PTR [rax],al
	...

0000000000409330 <__swc_fn_7069e055_000099_65137b72>:
  409330:	sub    rsp,0x8
  409334:	call   40de20 <__swc_fn_7069e055_000121_0a5fa85a>
  409339:	add    rsp,0x8
  40933d:	ret
	...

0000000000409340 <__swc_fn_7069e055_000102_e34f54dc>:
  409340:	push   rbx
  409341:	push   rsi
  409342:	sub    rsp,0x28
  409346:	mov    rbx,rcx
  409349:	xor    esi,esi
  40934b:	jmp    409360 <__swc_fn_7069e055_000102_e34f54dc+0x20>
  40934d:	nop    DWORD PTR [rax]
  409350:	mov    QWORD PTR [rbx+0x28],rsi
  409354:	mov    rsi,rbx
  409357:	mov    rbx,rax
  40935a:	nop    WORD PTR [rax+rax*1+0x0]
  409360:	test   rbx,rbx
  409363:	je     4093c3 <__swc_fn_7069e055_000102_e34f54dc+0x83>
  409365:	mov    rcx,rbx
  409368:	mov    edx,0x1
  40936d:	call   40cce0 <__swc_fn_7069e055_000082_63a67586>
  409372:	cmp    rax,0x1
  409376:	jne    4093c3 <__swc_fn_7069e055_000102_e34f54dc+0x83>
  409378:	mov    r10,QWORD PTR [rbx+0x18]
  40937c:	mov    rcx,r10
  40937f:	mov    edx,0x1
  409384:	call   40cce0 <__swc_fn_7069e055_000082_63a67586>
  409389:	cmp    rax,0x1
  40938d:	jne    40939c <__swc_fn_7069e055_000102_e34f54dc+0x5c>
  40938f:	mov    rcx,r10
  409392:	call   410dd0 <__swc_fn_7069e055_000101_d0b19c14>
  409397:	test   rax,rax
  40939a:	jne    409350 <__swc_fn_7069e055_000102_e34f54dc+0x10>
  40939c:	mov    rax,QWORD PTR [rbx+0x20]
  4093a0:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4093a5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4093ab:	lea    rcx,[rsp+0x8]
  4093b0:	mov    rdx,rbx
  4093b3:	mov    r8d,0x30
  4093b9:	mov    rbx,rax
  4093bc:	call   40d440 <__swc_fn_7069e055_000100_d4bdcaa4>
  4093c1:	jmp    409360 <__swc_fn_7069e055_000102_e34f54dc+0x20>
  4093c3:	test   rsi,rsi
  4093c6:	jne    4093cf <__swc_fn_7069e055_000102_e34f54dc+0x8f>
  4093c8:	add    rsp,0x28
  4093cc:	pop    rsi
  4093cd:	pop    rbx
  4093ce:	ret
  4093cf:	mov    rax,rsi
  4093d2:	mov    rsi,QWORD PTR [rsi+0x28]
  4093d6:	mov    rbx,QWORD PTR [rax+0x20]
  4093da:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  4093df:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4093e5:	lea    rcx,[rsp+0x18]
  4093ea:	mov    rdx,rax
  4093ed:	mov    r8d,0x30
  4093f3:	call   40d440 <__swc_fn_7069e055_000100_d4bdcaa4>
  4093f8:	jmp    409360 <__swc_fn_7069e055_000102_e34f54dc+0x20>
  4093fd:	add    BYTE PTR [rax],al
	...

0000000000409400 <__swc_fn_7069e055_000105_5a85fcf5>:
  409400:	push   rbx
  409401:	push   rsi
  409402:	push   rdi
  409403:	push   r12
  409405:	push   r13
  409407:	sub    rsp,0x20
  40940b:	mov    rbx,rcx
  40940e:	lea    rsi,[rcx+0x6f8]
  409415:	mov    edi,0x4
  40941a:	mov    r12,rsi
  40941d:	test   rdi,rdi
  409420:	je     40946a <__swc_fn_7069e055_000105_5a85fcf5+0x6a>
  409422:	cs nop WORD PTR [rax+rax*1+0x0]
  40942c:	nop    DWORD PTR [rax+0x0]
  409430:	mov    rcx,QWORD PTR [r12+0x10]
  409435:	mov    QWORD PTR [r12+0x10],0x0
  40943e:	vxorps xmm0,xmm0,xmm0
  409442:	vmovups XMMWORD PTR [r12],xmm0
  409448:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40944f:	mov    DWORD PTR [r12+0x20],0x0
  409458:	call   40d490 <__swc_fn_7069e055_000103_2fdd2c61>
  40945d:	add    r12,0x90
  409464:	sub    rdi,0x1
  409468:	jne    409430 <__swc_fn_7069e055_000105_5a85fcf5+0x30>
  40946a:	mov    rax,QWORD PTR [rbx+0x938]
  409471:	mov    rdi,rax
  409474:	test   rdi,rdi
  409477:	je     4094d1 <__swc_fn_7069e055_000105_5a85fcf5+0xd1>
  409479:	nop    DWORD PTR [rax+0x0]
  409480:	mov    r12d,0x10
  409486:	lea    r13,[rdi+0x18]
  40948a:	test   r12,r12
  40948d:	je     4094c6 <__swc_fn_7069e055_000105_5a85fcf5+0xc6>
  40948f:	nop
  409490:	mov    rcx,QWORD PTR [r13+0x10]
  409494:	mov    QWORD PTR [r13+0x10],0x0
  40949c:	vxorps xmm0,xmm0,xmm0
  4094a0:	vmovups XMMWORD PTR [r13+0x0],xmm0
  4094a6:	vmovups XMMWORD PTR [r13+0x28],xmm0
  4094ac:	mov    DWORD PTR [r13+0x20],0x0
  4094b4:	call   40d490 <__swc_fn_7069e055_000103_2fdd2c61>
  4094b9:	add    r13,0x90
  4094c0:	sub    r12,0x1
  4094c4:	jne    409490 <__swc_fn_7069e055_000105_5a85fcf5+0x90>
  4094c6:	mov    rax,QWORD PTR [rdi]
  4094c9:	mov    rdi,rax
  4094cc:	test   rax,rax
  4094cf:	jne    409480 <__swc_fn_7069e055_000105_5a85fcf5+0x80>
  4094d1:	vxorps xmm0,xmm0,xmm0
  4094d5:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  4094dd:	mov    DWORD PTR [rbx+0x9b0],0x0
  4094e7:	mov    DWORD PTR [rbx+0x9a8],0x0
  4094f1:	mov    edi,0x4
  4094f6:	mov    r12,rsi
  4094f9:	lea    rsi,[rsi+0x38]
  4094fd:	test   rdi,rdi
  409500:	je     40952c <__swc_fn_7069e055_000105_5a85fcf5+0x12c>
  409502:	cs nop WORD PTR [rax+rax*1+0x0]
  40950c:	nop    DWORD PTR [rax+0x0]
  409510:	mov    rcx,rsi
  409513:	call   411c50 <__swc_fn_7069e055_000161_13ead2ff>
  409518:	add    rsi,0x90
  40951f:	add    r12,0x90
  409526:	sub    rdi,0x1
  40952a:	jne    409510 <__swc_fn_7069e055_000105_5a85fcf5+0x110>
  40952c:	mov    rax,QWORD PTR [rbx+0x938]
  409533:	mov    rdi,rax
  409536:	mov    QWORD PTR [rbx+0x938],0x0
  409541:	test   rdi,rdi
  409544:	je     4095b5 <__swc_fn_7069e055_000105_5a85fcf5+0x1b5>
  40954a:	nop    WORD PTR [rax+rax*1+0x0]
  409550:	mov    esi,0x10
  409555:	lea    r12,[rdi+0x18]
  409559:	lea    r13,[rdi+0x50]
  40955d:	test   rsi,rsi
  409560:	je     40958c <__swc_fn_7069e055_000105_5a85fcf5+0x18c>
  409562:	cs nop WORD PTR [rax+rax*1+0x0]
  40956c:	nop    DWORD PTR [rax+0x0]
  409570:	mov    rcx,r13
  409573:	call   411c50 <__swc_fn_7069e055_000161_13ead2ff>
  409578:	add    r13,0x90
  40957f:	add    r12,0x90
  409586:	sub    rsi,0x1
  40958a:	jne    409570 <__swc_fn_7069e055_000105_5a85fcf5+0x170>
  40958c:	mov    rax,QWORD PTR [rdi]
  40958f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  409594:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40959a:	lea    rcx,[rsp+0x8]
  40959f:	mov    rdx,rdi
  4095a2:	mov    r8d,0x918
  4095a8:	mov    rdi,rax
  4095ab:	call   40d440 <__swc_fn_7069e055_000100_d4bdcaa4>
  4095b0:	test   rdi,rdi
  4095b3:	jne    409550 <__swc_fn_7069e055_000105_5a85fcf5+0x150>
  4095b5:	lea    rcx,[rbx+0x68]
  4095b9:	call   411c50 <__swc_fn_7069e055_000161_13ead2ff>
  4095be:	add    rsp,0x20
  4095c2:	pop    r13
  4095c4:	pop    r12
  4095c6:	pop    rdi
  4095c7:	pop    rsi
  4095c8:	pop    rbx
  4095c9:	ret
  4095ca:	add    BYTE PTR [rax],al
  4095cc:	add    BYTE PTR [rax],al
	...

00000000004095d0 <__swc_fn_7069e055_000108_c51c3158>:
  4095d0:	xor    eax,eax
  4095d2:	cs nop WORD PTR [rax+rax*1+0x0]
  4095dc:	nop    DWORD PTR [rax+0x0]
  4095e0:	mov    r9,r8
  4095e3:	sub    r9,rax
  4095e6:	cmp    r9,0x40
  4095ea:	jb     409628 <__swc_fn_7069e055_000108_c51c3158+0x58>
  4095ec:	lea    r9,[rcx+rax*1]
  4095f0:	lea    r10,[rdx+rax*1]
  4095f4:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  4095fa:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  409600:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  409606:	vmovups xmm3,XMMWORD PTR [r10]
  40960b:	vmovups XMMWORD PTR [r9],xmm3
  409610:	vmovups XMMWORD PTR [r9+0x10],xmm0
  409616:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40961c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  409622:	lea    rax,[rax+0x40]
  409626:	jmp    4095e0 <__swc_fn_7069e055_000108_c51c3158+0x10>
  409628:	nop    DWORD PTR [rax+rax*1+0x0]
  409630:	mov    r9,r8
  409633:	sub    r9,rax
  409636:	cmp    r9,0x10
  40963a:	jb     409654 <__swc_fn_7069e055_000108_c51c3158+0x84>
  40963c:	lea    r9,[rdx+rax*1]
  409640:	lea    r10,[rcx+rax*1]
  409644:	vmovups xmm0,XMMWORD PTR [r9]
  409649:	vmovups XMMWORD PTR [r10],xmm0
  40964e:	lea    rax,[rax+0x10]
  409652:	jmp    409630 <__swc_fn_7069e055_000108_c51c3158+0x60>
  409654:	cs nop WORD PTR [rax+rax*1+0x0]
  40965e:	xchg   ax,ax
  409660:	mov    r9,r8
  409663:	sub    r9,rax
  409666:	cmp    r9,0x8
  40966a:	jb     40967d <__swc_fn_7069e055_000108_c51c3158+0xad>
  40966c:	lea    r9,[rcx+rax*1]
  409670:	mov    r10,QWORD PTR [rdx+rax*1]
  409674:	mov    QWORD PTR [r9],r10
  409677:	lea    rax,[rax+0x8]
  40967b:	jmp    409660 <__swc_fn_7069e055_000108_c51c3158+0x90>
  40967d:	cmp    rax,r8
  409680:	jae    4096a0 <__swc_fn_7069e055_000108_c51c3158+0xd0>
  409682:	cs nop WORD PTR [rax+rax*1+0x0]
  40968c:	nop    DWORD PTR [rax+0x0]
  409690:	mov    r9b,BYTE PTR [rdx+rax*1]
  409694:	mov    BYTE PTR [rcx+rax*1],r9b
  409698:	inc    rax
  40969b:	cmp    rax,r8
  40969e:	jb     409690 <__swc_fn_7069e055_000108_c51c3158+0xc0>
  4096a0:	ret
	...

00000000004096b0 <__swc_fn_7069e055_000111_6814119b>:
  4096b0:	push   rbx
  4096b1:	push   r12
  4096b3:	push   rdi
  4096b4:	push   rsi
  4096b5:	push   r13
  4096b7:	push   r14
  4096b9:	push   r15
  4096bb:	sub    rsp,0x170
  4096c2:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  4096cb:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  4096d4:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  4096dd:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  4096e6:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  4096ef:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  4096f8:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  409701:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40970a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  409713:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40971c:	mov    ebx,edx
  40971e:	mov    QWORD PTR [rsp+0xa8],rbx
  409726:	mov    r12d,ecx
  409729:	test   edx,edx
  40972b:	jne    409742 <__swc_fn_7069e055_000111_6814119b+0x92>
  40972d:	xor    eax,eax
  40972f:	add    rsp,0x170
  409736:	pop    r15
  409738:	pop    r14
  40973a:	pop    r13
  40973c:	pop    rsi
  40973d:	pop    rdi
  40973e:	pop    r12
  409740:	pop    rbx
  409741:	ret
  409742:	lea    rdi,[rip+0x9e37]        # 413580 <__swc_rdata_base_7069e055+0x470>
  409749:	mov    esi,0x90000
  40974e:	xor    eax,eax
  409750:	call   407010 <open@plt>
  409755:	mov    r13,rax
  409758:	mov    QWORD PTR [rsp+0xb0],rax
  409760:	test   eax,eax
  409762:	jge    40976b <__swc_fn_7069e055_000111_6814119b+0xbb>
  409764:	xor    eax,eax
  409766:	jmp    409c66 <__swc_fn_7069e055_000111_6814119b+0x5b6>
  40976b:	nop    DWORD PTR [rax+rax*1+0x0]
  409770:	movsxd rdi,r13d
  409773:	mov    esi,0x2
  409778:	xor    eax,eax
  40977a:	call   407020 <flock@plt>
  40977f:	test   eax,eax
  409781:	je     4097a0 <__swc_fn_7069e055_000111_6814119b+0xf0>
  409783:	xor    eax,eax
  409785:	call   407030 <__errno_location@plt>
  40978a:	cmp    DWORD PTR [rax],0x4
  40978d:	je     409770 <__swc_fn_7069e055_000111_6814119b+0xc0>
  40978f:	movsxd rdi,r13d
  409792:	xor    eax,eax
  409794:	call   407040 <close@plt>
  409799:	xor    eax,eax
  40979b:	jmp    409c66 <__swc_fn_7069e055_000111_6814119b+0x5b6>
  4097a0:	lea    r14,[rsp+0x8]
  4097a5:	mov    QWORD PTR [rsp+0xb8],r14
  4097ad:	vxorps xmm0,xmm0,xmm0
  4097b1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4097b7:	mov    QWORD PTR [rsp+0x18],0x0
  4097c0:	mov    WORD PTR [rsp+0x20],0x0
  4097c7:	mov    DWORD PTR [r14],0x67617753
  4097ce:	mov    DWORD PTR [r14+0x4],0x2e74522e
  4097d6:	xor    eax,eax
  4097d8:	call   407050 <getpid@plt>
  4097dd:	mov    ecx,eax
  4097df:	mov    eax,0x1c
  4097e4:	shrx   eax,ecx,eax
  4097e9:	and    eax,0xf
  4097ec:	mov    rdx,QWORD PTR [rip+0x9dad]        # 4135a0 <__swc_rdata_base_7069e055+0x490>
  4097f3:	mov    al,BYTE PTR [rdx+rax*1]
  4097f6:	rex mov BYTE PTR [rsp+0x10],al
  4097fb:	mov    eax,0x1c
  409800:	shrx   eax,r12d,eax
  409805:	and    eax,0xf
  409808:	mov    al,BYTE PTR [rdx+rax*1]
  40980b:	rex mov BYTE PTR [rsp+0x19],al
  409810:	mov    eax,0x18
  409815:	shrx   eax,ecx,eax
  40981a:	and    eax,0xf
  40981d:	mov    al,BYTE PTR [rdx+rax*1]
  409820:	rex mov BYTE PTR [rsp+0x11],al
  409825:	mov    eax,0x18
  40982a:	shrx   eax,r12d,eax
  40982f:	and    eax,0xf
  409832:	mov    al,BYTE PTR [rdx+rax*1]
  409835:	rex mov BYTE PTR [rsp+0x1a],al
  40983a:	mov    eax,0x14
  40983f:	shrx   eax,ecx,eax
  409844:	and    eax,0xf
  409847:	mov    al,BYTE PTR [rdx+rax*1]
  40984a:	rex mov BYTE PTR [rsp+0x12],al
  40984f:	mov    eax,0x14
  409854:	shrx   eax,r12d,eax
  409859:	and    eax,0xf
  40985c:	mov    al,BYTE PTR [rdx+rax*1]
  40985f:	rex mov BYTE PTR [rsp+0x1b],al
  409864:	mov    eax,0x10
  409869:	shrx   eax,ecx,eax
  40986e:	and    eax,0xf
  409871:	mov    al,BYTE PTR [rdx+rax*1]
  409874:	rex mov BYTE PTR [rsp+0x13],al
  409879:	mov    eax,0x10
  40987e:	shrx   eax,r12d,eax
  409883:	and    eax,0xf
  409886:	mov    al,BYTE PTR [rdx+rax*1]
  409889:	rex mov BYTE PTR [rsp+0x1c],al
  40988e:	mov    eax,0xc
  409893:	shrx   eax,ecx,eax
  409898:	and    eax,0xf
  40989b:	mov    al,BYTE PTR [rdx+rax*1]
  40989e:	rex mov BYTE PTR [rsp+0x14],al
  4098a3:	mov    eax,0xc
  4098a8:	shrx   eax,r12d,eax
  4098ad:	and    eax,0xf
  4098b0:	mov    al,BYTE PTR [rdx+rax*1]
  4098b3:	rex mov BYTE PTR [rsp+0x1d],al
  4098b8:	mov    eax,0x8
  4098bd:	shrx   eax,ecx,eax
  4098c2:	and    eax,0xf
  4098c5:	mov    al,BYTE PTR [rdx+rax*1]
  4098c8:	rex mov BYTE PTR [rsp+0x15],al
  4098cd:	mov    eax,0x8
  4098d2:	shrx   eax,r12d,eax
  4098d7:	and    eax,0xf
  4098da:	mov    al,BYTE PTR [rdx+rax*1]
  4098dd:	rex mov BYTE PTR [rsp+0x1e],al
  4098e2:	mov    eax,0x4
  4098e7:	shrx   eax,ecx,eax
  4098ec:	and    eax,0xf
  4098ef:	mov    al,BYTE PTR [rdx+rax*1]
  4098f2:	rex mov BYTE PTR [rsp+0x16],al
  4098f7:	mov    eax,0x4
  4098fc:	shrx   eax,r12d,eax
  409901:	and    eax,0xf
  409904:	mov    al,BYTE PTR [rdx+rax*1]
  409907:	rex mov BYTE PTR [rsp+0x1f],al
  40990c:	xor    eax,eax
  40990e:	shrx   eax,ecx,eax
  409913:	and    eax,0xf
  409916:	mov    al,BYTE PTR [rdx+rax*1]
  409919:	rex mov BYTE PTR [rsp+0x17],al
  40991e:	xor    eax,eax
  409920:	shrx   eax,r12d,eax
  409925:	and    eax,0xf
  409928:	mov    al,BYTE PTR [rdx+rax*1]
  40992b:	rex mov BYTE PTR [rsp+0x20],al
  409930:	mov    BYTE PTR [r14+0x10],0x2e
  409935:	lea    r12,[rsp+0x22]
  40993a:	vxorps xmm0,xmm0,xmm0
  40993e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  409944:	mov    DWORD PTR [r12],0x6d656d2f
  40994c:	mov    WORD PTR [r12+0x4],0x6466
  409954:	mov    BYTE PTR [r12+0x6],0x3a
  40995a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409960:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  409966:	mov    rax,QWORD PTR [rsp+0x18]
  40996b:	mov    QWORD PTR [rsp+0x39],rax
  409970:	rex mov al,BYTE PTR [rsp+0x20]
  409975:	rex mov BYTE PTR [rsp+0x41],al
  40997a:	mov    DWORD PTR [r12+0x20],0x65642820
  409983:	mov    DWORD PTR [r12+0x24],0x6574656c
  40998c:	mov    WORD PTR [r12+0x28],0x2964
  409994:	lea    rdi,[rip+0x9bf0]        # 41358b <__swc_rdata_base_7069e055+0x47b>
  40999b:	xor    eax,eax
  40999d:	call   407060 <opendir@plt>
  4099a2:	mov    r15,rax
  4099a5:	test   rax,rax
  4099a8:	jne    4099bb <__swc_fn_7069e055_000111_6814119b+0x30b>
  4099aa:	movsxd rdi,r13d
  4099ad:	xor    eax,eax
  4099af:	call   407040 <close@plt>
  4099b4:	xor    eax,eax
  4099b6:	jmp    409c66 <__swc_fn_7069e055_000111_6814119b+0x5b6>
  4099bb:	mov    rdi,r15
  4099be:	xor    eax,eax
  4099c0:	call   407070 <dirfd@plt>
  4099c5:	lea    r14,[rsp+0x54]
  4099ca:	mov    DWORD PTR [rsp+0x54],eax
  4099ce:	lea    rbx,[rsp+0x58]
  4099d3:	cs nop WORD PTR [rax+rax*1+0x0]
  4099dd:	nop    DWORD PTR [rax]
  4099e0:	mov    rdi,r15
  4099e3:	xor    eax,eax
  4099e5:	call   407080 <readdir@plt>
  4099ea:	test   rax,rax
  4099ed:	jne    409a04 <__swc_fn_7069e055_000111_6814119b+0x354>
  4099ef:	mov    r12,QWORD PTR [rsp+0xa8]
  4099f7:	mov    r13,QWORD PTR [rsp+0xb0]
  4099ff:	jmp    409b8a <__swc_fn_7069e055_000111_6814119b+0x4da>
  409a04:	vxorps xmm0,xmm0,xmm0
  409a08:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  409a0e:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  409a14:	vzeroupper
  409a17:	lea    r13,[rax+0x13]
  409a1b:	mov    rax,r14
  409a1e:	movsxd rdi,DWORD PTR [rax]
  409a21:	mov    rsi,r13
  409a24:	mov    rdx,rbx
  409a27:	mov    ecx,0x40
  409a2c:	xor    eax,eax
  409a2e:	call   407090 <readlinkat@plt>
  409a33:	cmp    rax,0x2a
  409a37:	jne    4099e0 <__swc_fn_7069e055_000111_6814119b+0x330>
  409a39:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  409a3f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  409a45:	vptest xmm0,xmm0
  409a4a:	jne    409a7a <__swc_fn_7069e055_000111_6814119b+0x3ca>
  409a4c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  409a52:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  409a58:	vptest xmm0,xmm0
  409a5d:	jne    409a7a <__swc_fn_7069e055_000111_6814119b+0x3ca>
  409a5f:	mov    rcx,QWORD PTR [rsp+0x42]
  409a64:	cmp    QWORD PTR [rsp+0x78],rcx
  409a69:	jne    409a7a <__swc_fn_7069e055_000111_6814119b+0x3ca>
  409a6b:	mov    cx,WORD PTR [rsp+0x4a]
  409a70:	cmp    WORD PTR [rsp+0x80],cx
  409a78:	je     409aa4 <__swc_fn_7069e055_000111_6814119b+0x3f4>
  409a7a:	mov    rax,rbx
  409a7d:	mov    rcx,r12
  409a80:	movzx  edx,BYTE PTR [rax]
  409a83:	movzx  r8d,BYTE PTR [rcx]
  409a87:	cmp    rdx,r8
  409a8a:	jne    409a96 <__swc_fn_7069e055_000111_6814119b+0x3e6>
  409a8c:	add    rax,0x1
  409a90:	add    rcx,0x1
  409a94:	jmp    409a80 <__swc_fn_7069e055_000111_6814119b+0x3d0>
  409a96:	mov    rax,rdx
  409a99:	sub    rax,r8
  409a9c:	test   eax,eax
  409a9e:	jne    4099e0 <__swc_fn_7069e055_000111_6814119b+0x330>
  409aa4:	movsxd rdi,DWORD PTR [r14]
  409aa7:	mov    rsi,r13
  409aaa:	mov    edx,0x80002
  409aaf:	xor    eax,eax
  409ab1:	call   4070a0 <openat@plt>
  409ab6:	lea    rbx,[rsp+0x98]
  409abe:	mov    DWORD PTR [rsp+0x98],eax
  409ac5:	test   eax,eax
  409ac7:	mov    r13,QWORD PTR [rsp+0xb0]
  409acf:	jge    409af4 <__swc_fn_7069e055_000111_6814119b+0x444>
  409ad1:	mov    rdi,r15
  409ad4:	xor    eax,eax
  409ad6:	call   4070b0 <closedir@plt>
  409adb:	mov    r13,QWORD PTR [rsp+0xb0]
  409ae3:	movsxd rdi,r13d
  409ae6:	xor    eax,eax
  409ae8:	call   407040 <close@plt>
  409aed:	xor    eax,eax
  409aef:	jmp    409c66 <__swc_fn_7069e055_000111_6814119b+0x5b6>
  409af4:	mov    rax,rbx
  409af7:	movsxd rdi,DWORD PTR [rax]
  409afa:	xor    esi,esi
  409afc:	mov    edx,0x2
  409b01:	xor    eax,eax
  409b03:	call   4070c0 <lseek@plt>
  409b08:	mov    r12,QWORD PTR [rsp+0xa8]
  409b10:	cmp    rax,r12
  409b13:	je     409b3a <__swc_fn_7069e055_000111_6814119b+0x48a>
  409b15:	movsxd rdi,DWORD PTR [rbx]
  409b18:	xor    eax,eax
  409b1a:	call   407040 <close@plt>
  409b1f:	mov    rdi,r15
  409b22:	xor    eax,eax
  409b24:	call   4070b0 <closedir@plt>
  409b29:	movsxd rdi,r13d
  409b2c:	xor    eax,eax
  409b2e:	call   407040 <close@plt>
  409b33:	xor    eax,eax
  409b35:	jmp    409c66 <__swc_fn_7069e055_000111_6814119b+0x5b6>
  409b3a:	xor    edi,edi
  409b3c:	mov    rsi,r12
  409b3f:	mov    edx,0x3
  409b44:	mov    ecx,0x1
  409b49:	mov    rax,rbx
  409b4c:	movsxd r8,DWORD PTR [rax]
  409b4f:	xor    r9d,r9d
  409b52:	xor    eax,eax
  409b54:	call   4070d0 <mmap@plt>
  409b59:	xor    r12d,r12d
  409b5c:	cmp    rax,0xffffffffffffffff
  409b60:	cmovne r12,rax
  409b64:	movsxd rdi,DWORD PTR [rbx]
  409b67:	xor    eax,eax
  409b69:	call   407040 <close@plt>
  409b6e:	mov    rdi,r15
  409b71:	xor    eax,eax
  409b73:	call   4070b0 <closedir@plt>
  409b78:	movsxd rdi,r13d
  409b7b:	xor    eax,eax
  409b7d:	call   407040 <close@plt>
  409b82:	mov    rax,r12
  409b85:	jmp    409c66 <__swc_fn_7069e055_000111_6814119b+0x5b6>
  409b8a:	mov    r14,QWORD PTR [rsp+0xb8]
  409b92:	mov    rdi,r14
  409b95:	mov    esi,0x1
  409b9a:	xor    eax,eax
  409b9c:	call   4070e0 <memfd_create@plt>
  409ba1:	lea    rbx,[rsp+0x9c]
  409ba9:	mov    DWORD PTR [rsp+0x9c],eax
  409bb0:	test   eax,eax
  409bb2:	jge    409bcf <__swc_fn_7069e055_000111_6814119b+0x51f>
  409bb4:	mov    rdi,r15
  409bb7:	xor    eax,eax
  409bb9:	call   4070b0 <closedir@plt>
  409bbe:	movsxd rdi,r13d
  409bc1:	xor    eax,eax
  409bc3:	call   407040 <close@plt>
  409bc8:	xor    eax,eax
  409bca:	jmp    409c66 <__swc_fn_7069e055_000111_6814119b+0x5b6>
  409bcf:	mov    rax,rbx
  409bd2:	movsxd rdi,DWORD PTR [rax]
  409bd5:	mov    rsi,r12
  409bd8:	xor    eax,eax
  409bda:	call   4070f0 <ftruncate@plt>
  409bdf:	test   eax,eax
  409be1:	je     409c05 <__swc_fn_7069e055_000111_6814119b+0x555>
  409be3:	movsxd rdi,DWORD PTR [rbx]
  409be6:	xor    eax,eax
  409be8:	call   407040 <close@plt>
  409bed:	mov    rdi,r15
  409bf0:	xor    eax,eax
  409bf2:	call   4070b0 <closedir@plt>
  409bf7:	movsxd rdi,r13d
  409bfa:	xor    eax,eax
  409bfc:	call   407040 <close@plt>
  409c01:	xor    eax,eax
  409c03:	jmp    409c66 <__swc_fn_7069e055_000111_6814119b+0x5b6>
  409c05:	xor    edi,edi
  409c07:	mov    rsi,r12
  409c0a:	mov    edx,0x3
  409c0f:	mov    ecx,0x1
  409c14:	mov    rax,rbx
  409c17:	movsxd r8,DWORD PTR [rax]
  409c1a:	xor    r9d,r9d
  409c1d:	xor    eax,eax
  409c1f:	call   4070d0 <mmap@plt>
  409c24:	mov    r12,rax
  409c27:	cmp    rax,0xffffffffffffffff
  409c2b:	jne    409c4f <__swc_fn_7069e055_000111_6814119b+0x59f>
  409c2d:	movsxd rdi,DWORD PTR [rbx]
  409c30:	xor    eax,eax
  409c32:	call   407040 <close@plt>
  409c37:	mov    rdi,r15
  409c3a:	xor    eax,eax
  409c3c:	call   4070b0 <closedir@plt>
  409c41:	movsxd rdi,r13d
  409c44:	xor    eax,eax
  409c46:	call   407040 <close@plt>
  409c4b:	xor    eax,eax
  409c4d:	jmp    409c66 <__swc_fn_7069e055_000111_6814119b+0x5b6>
  409c4f:	mov    rdi,r15
  409c52:	xor    eax,eax
  409c54:	call   4070b0 <closedir@plt>
  409c59:	movsxd rdi,r13d
  409c5c:	xor    eax,eax
  409c5e:	call   407040 <close@plt>
  409c63:	mov    rax,r12
  409c66:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  409c6f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  409c78:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  409c81:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  409c8a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  409c93:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  409c9c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  409ca5:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  409cae:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  409cb7:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  409cc0:	add    rsp,0x170
  409cc7:	pop    r15
  409cc9:	pop    r14
  409ccb:	pop    r13
  409ccd:	pop    rsi
  409cce:	pop    rdi
  409ccf:	pop    r12
  409cd1:	pop    rbx
  409cd2:	ret
	...

0000000000409ce0 <__swc_fn_7069e055_000114_5f48311c>:
  409ce0:	push   rsi
  409ce1:	push   rdi
  409ce2:	push   r12
  409ce4:	push   r13
  409ce6:	sub    rsp,0x8
  409cea:	mov    rsi,r8
  409ced:	mov    rdi,rcx
  409cf0:	mov    r12,rdx
  409cf3:	call   40dbe0 <__swc_fn_7069e055_000112_126150d1>
  409cf8:	mov    r13,rax
  409cfb:	test   rax,rax
  409cfe:	jne    409d0b <__swc_fn_7069e055_000114_5f48311c+0x2b>
  409d00:	add    rsp,0x8
  409d04:	pop    r13
  409d06:	pop    r12
  409d08:	pop    rdi
  409d09:	pop    rsi
  409d0a:	ret
  409d0b:	mov    rcx,r13
  409d0e:	call   411850 <__swc_fn_7069e055_000137_8c07c14b>
  409d13:	mov    rax,QWORD PTR [r13+0x8]
  409d17:	test   rax,rax
  409d1a:	je     409d59 <__swc_fn_7069e055_000114_5f48311c+0x79>
  409d1c:	nop    DWORD PTR [rax+0x0]
  409d20:	lea    rcx,[rax+0x1000]
  409d27:	cmp    rdi,rcx
  409d2a:	jne    409d51 <__swc_fn_7069e055_000114_5f48311c+0x71>
  409d2c:	cmp    r12,0x1000
  409d33:	jb     409d51 <__swc_fn_7069e055_000114_5f48311c+0x71>
  409d35:	test   sil,sil
  409d38:	setne  cl
  409d3b:	mov    BYTE PTR [rax+0x10],cl
  409d3e:	mov    rcx,r13
  409d41:	call   40a240 <__swc_fn_7069e055_000138_715e84ff>
  409d46:	add    rsp,0x8
  409d4a:	pop    r13
  409d4c:	pop    r12
  409d4e:	pop    rdi
  409d4f:	pop    rsi
  409d50:	ret
  409d51:	mov    rax,QWORD PTR [rax]
  409d54:	test   rax,rax
  409d57:	jne    409d20 <__swc_fn_7069e055_000114_5f48311c+0x40>
  409d59:	mov    rcx,r13
  409d5c:	call   40a240 <__swc_fn_7069e055_000138_715e84ff>
  409d61:	add    rsp,0x8
  409d65:	pop    r13
  409d67:	pop    r12
  409d69:	pop    rdi
  409d6a:	pop    rsi
  409d6b:	ret
  409d6c:	add    BYTE PTR [rax],al
	...

0000000000409d70 <__swc_fn_7069e055_000117_ed2d8fed>:
  409d70:	sub    rsp,0x8
  409d74:	test   rcx,rcx
  409d77:	jne    409d7e <__swc_fn_7069e055_000117_ed2d8fed+0xe>
  409d79:	add    rsp,0x8
  409d7d:	ret
  409d7e:	call   411360 <__swc_fn_7069e055_000119_d3318640>
  409d83:	add    rsp,0x8
  409d87:	ret
	...

0000000000409d90 <__swc_fn_7069e055_000120_2648f149>:
  409d90:	push   r12
  409d92:	push   r13
  409d94:	push   r14
  409d96:	push   rdi
  409d97:	push   rsi
  409d98:	sub    rsp,0xc0
  409d9f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409da5:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409dab:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409db1:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409db7:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409dbd:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409dc3:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409dc9:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409dd2:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409ddb:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409de4:	mov    r12,QWORD PTR [rcx]
  409de7:	test   r12,r12
  409dea:	jne    409dfc <__swc_fn_7069e055_000120_2648f149+0x6c>
  409dec:	add    rsp,0xc0
  409df3:	pop    rsi
  409df4:	pop    rdi
  409df5:	pop    r14
  409df7:	pop    r13
  409df9:	pop    r12
  409dfb:	ret
  409dfc:	xor    r13d,r13d
  409dff:	mov    r14,QWORD PTR [rcx+0x8]
  409e03:	cs nop WORD PTR [rax+rax*1+0x0]
  409e0d:	nop    DWORD PTR [rax]
  409e10:	cmp    r13,r14
  409e13:	jae    409e4b <__swc_fn_7069e055_000120_2648f149+0xbb>
  409e15:	lea    rax,[r12+r13*1]
  409e19:	mov    rcx,r14
  409e1c:	sub    rcx,r13
  409e1f:	mov    edi,0x1
  409e24:	mov    rsi,rax
  409e27:	mov    rdx,rcx
  409e2a:	xor    eax,eax
  409e2c:	call   407100 <write@plt>
  409e31:	test   rax,rax
  409e34:	jle    409e3b <__swc_fn_7069e055_000120_2648f149+0xab>
  409e36:	add    r13,rax
  409e39:	jmp    409e10 <__swc_fn_7069e055_000120_2648f149+0x80>
  409e3b:	je     409e49 <__swc_fn_7069e055_000120_2648f149+0xb9>
  409e3d:	xor    eax,eax
  409e3f:	call   407030 <__errno_location@plt>
  409e44:	cmp    DWORD PTR [rax],0x4
  409e47:	je     409e10 <__swc_fn_7069e055_000120_2648f149+0x80>
  409e49:	jmp    409e4b <__swc_fn_7069e055_000120_2648f149+0xbb>
  409e4b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409e51:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409e57:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409e5d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409e63:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409e69:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409e6f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409e75:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409e7e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409e87:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409e90:	add    rsp,0xc0
  409e97:	pop    rsi
  409e98:	pop    rdi
  409e99:	pop    r14
  409e9b:	pop    r13
  409e9d:	pop    r12
  409e9f:	ret

0000000000409ea0 <__swc_fn_7069e055_000123_4f256d58>:
  409ea0:	push   rbx
  409ea1:	push   r12
  409ea3:	push   rdi
  409ea4:	push   rsi
  409ea5:	sub    rsp,0x4a8
  409eac:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  409eb5:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  409ebe:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  409ec7:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  409ed0:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  409ed9:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  409ee2:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  409eeb:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  409ef4:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  409efd:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  409f06:	mov    rbx,rdx
  409f09:	mov    r12d,ecx
  409f0c:	vxorps xmm0,xmm0,xmm0
  409f10:	xor    eax,eax
  409f12:	cs nop WORD PTR [rax+rax*1+0x0]
  409f1c:	nop    DWORD PTR [rax+0x0]
  409f20:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  409f26:	add    rax,0x10
  409f2a:	cmp    rax,0x400
  409f31:	jne    409f20 <__swc_fn_7069e055_000123_4f256d58+0x80>
  409f33:	lea    rdi,[rsp+0x8]
  409f38:	mov    esi,0x80
  409f3d:	xor    eax,eax
  409f3f:	call   407110 <backtrace@plt>
  409f44:	test   eax,eax
  409f46:	jle    409f55 <__swc_fn_7069e055_000123_4f256d58+0xb5>
  409f48:	movsxd rax,eax
  409f4b:	lea    rcx,[r12+0x1]
  409f50:	cmp    rcx,rax
  409f53:	jb     409f59 <__swc_fn_7069e055_000123_4f256d58+0xb9>
  409f55:	xor    eax,eax
  409f57:	jmp    409f8a <__swc_fn_7069e055_000123_4f256d58+0xea>
  409f59:	mov    rcx,QWORD PTR [rbx+0x8]
  409f5d:	sub    rax,r12
  409f60:	lea    rsi,[rax-0x1]
  409f64:	cmp    rcx,rsi
  409f67:	cmovbe rsi,rcx
  409f6b:	lea    eax,[r12+0x1]
  409f70:	lea    rax,[rsp+rax*8+0x8]
  409f75:	mov    rcx,QWORD PTR [rbx]
  409f78:	mov    rdx,rax
  409f7b:	lea    r8,[rsi*8+0x0]
  409f83:	call   40dbc0 <__swc_fn_7069e055_000109_7c204aac>
  409f88:	mov    eax,esi
  409f8a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  409f93:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  409f9c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  409fa5:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  409fae:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  409fb7:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  409fc0:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  409fc9:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  409fd2:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  409fdb:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  409fe4:	add    rsp,0x4a8
  409feb:	pop    rsi
  409fec:	pop    rdi
  409fed:	pop    r12
  409fef:	pop    rbx
  409ff0:	ret
	...

000000000040a000 <__swc_fn_7069e055_000126_fcd5a289>:
  40a000:	mov    QWORD PTR [rcx],0x0
  40a007:	ret
	...

000000000040a010 <__swc_fn_7069e055_000129_4bbe3f14>:
  40a010:	push   rdi
  40a011:	push   rsi
  40a012:	sub    rsp,0xa8
  40a019:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a01f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a025:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a02b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a031:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a037:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a03d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a043:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a049:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a052:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a05b:	mov    edi,ecx
  40a05d:	mov    rsi,rdx
  40a060:	xor    eax,eax
  40a062:	call   407120 <pthread_setspecific@plt>
  40a067:	test   eax,eax
  40a069:	sete   al
  40a06c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a072:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a078:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a07e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a084:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a08a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a090:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a096:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a09c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a0a5:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a0ae:	add    rsp,0xa8
  40a0b5:	pop    rsi
  40a0b6:	pop    rdi
  40a0b7:	ret
	...

000000000040a0c0 <__swc_fn_7069e055_000132_5f757033>:
  40a0c0:	push   rdi
  40a0c1:	push   rsi
  40a0c2:	sub    rsp,0xa8
  40a0c9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a0cf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a0d5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a0db:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a0e1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a0e7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a0ed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a0f3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a0f9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a102:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a10b:	test   rcx,rcx
  40a10e:	je     40a121 <__swc_fn_7069e055_000132_5f757033+0x61>
  40a110:	lea    rax,[rcx-0x1]
  40a114:	mov    eax,eax
  40a116:	mov    edi,eax
  40a118:	xor    eax,eax
  40a11a:	call   407000 <pthread_getspecific@plt>
  40a11f:	jmp    40a123 <__swc_fn_7069e055_000132_5f757033+0x63>
  40a121:	xor    eax,eax
  40a123:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a129:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a12f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a135:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a13b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a141:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a147:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a14d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a153:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a15c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a165:	add    rsp,0xa8
  40a16c:	pop    rsi
  40a16d:	pop    rdi
  40a16e:	ret
	...

000000000040a170 <__swc_fn_7069e055_000135_07d76562>:
  40a170:	push   rdi
  40a171:	push   rsi
  40a172:	sub    rsp,0xb8
  40a179:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a17f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a185:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a18b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a191:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a197:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a19d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a1a3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a1ac:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a1b5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a1be:	vxorps xmm0,xmm0,xmm0
  40a1c2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1c8:	mov    edi,0x1
  40a1cd:	lea    rsi,[rsp+0x8]
  40a1d2:	xor    eax,eax
  40a1d4:	call   407130 <clock_gettime@plt>
  40a1d9:	mov    rax,QWORD PTR [rsp+0x8]
  40a1de:	imul   rax,rax,0x3b9aca00
  40a1e5:	add    rax,QWORD PTR [rsp+0x10]
  40a1ea:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a1f0:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a1f6:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a1fc:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a202:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a208:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a20e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a214:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a21d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a226:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a22f:	add    rsp,0xb8
  40a236:	pop    rsi
  40a237:	pop    rdi
  40a238:	ret
  40a239:	add    BYTE PTR [rax],al
  40a23b:	add    BYTE PTR [rax],al
  40a23d:	add    BYTE PTR [rax],al
	...

000000000040a240 <__swc_fn_7069e055_000138_715e84ff>:
  40a240:	sub    rsp,0x8
  40a244:	xor    eax,eax
  40a246:	mov    DWORD PTR [rcx],eax
  40a248:	mov    edx,0x7fffffff
  40a24d:	call   40e2c0 <__swc_fn_7069e055_000136_865f5106>
  40a252:	add    rsp,0x8
  40a256:	ret
	...

000000000040a260 <__swc_fn_7069e055_000141_519fdf94>:
  40a260:	push   rdi
  40a261:	push   rsi
  40a262:	sub    rsp,0xb8
  40a269:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a26f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a275:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a27b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a281:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a287:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a28d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a293:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a29c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a2a5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a2ae:	mov    edi,0x1
  40a2b3:	xor    eax,eax
  40a2b5:	call   407140 <__x86_get_cpuid_feature_leaf@plt>
  40a2ba:	mov    eax,DWORD PTR [rax+0x14]
  40a2bd:	and    eax,0x20
  40a2c0:	setne  al
  40a2c3:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a2c9:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a2cf:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a2d5:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a2db:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a2e1:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a2e7:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a2ed:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a2f6:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a2ff:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a308:	add    rsp,0xb8
  40a30f:	pop    rsi
  40a310:	pop    rdi
  40a311:	ret
	...

000000000040a320 <__swc_fn_7069e055_000144_d5d4d43f>:
  40a320:	push   rsi
  40a321:	push   rdi
  40a322:	push   r12
  40a324:	push   r13
  40a326:	push   r14
  40a328:	push   r15
  40a32a:	cmp    rdx,0x40
  40a32e:	jae    40a33d <__swc_fn_7069e055_000144_d5d4d43f+0x1d>
  40a330:	xor    eax,eax
  40a332:	pop    r15
  40a334:	pop    r14
  40a336:	pop    r13
  40a338:	pop    r12
  40a33a:	pop    rdi
  40a33b:	pop    rsi
  40a33c:	ret
  40a33d:	cmp    BYTE PTR [rcx],0x7f
  40a340:	jne    40a384 <__swc_fn_7069e055_000144_d5d4d43f+0x64>
  40a342:	movzx  eax,BYTE PTR [rcx+0x1]
  40a346:	cmp    eax,0x45
  40a349:	setne  al
  40a34c:	jne    40a380 <__swc_fn_7069e055_000144_d5d4d43f+0x60>
  40a34e:	movzx  eax,BYTE PTR [rcx+0x2]
  40a352:	cmp    eax,0x4c
  40a355:	setne  al
  40a358:	jne    40a380 <__swc_fn_7069e055_000144_d5d4d43f+0x60>
  40a35a:	movzx  eax,BYTE PTR [rcx+0x3]
  40a35e:	cmp    eax,0x46
  40a361:	setne  al
  40a364:	jne    40a380 <__swc_fn_7069e055_000144_d5d4d43f+0x60>
  40a366:	cmp    BYTE PTR [rcx+0x4],0x2
  40a36a:	setne  al
  40a36d:	jne    40a380 <__swc_fn_7069e055_000144_d5d4d43f+0x60>
  40a36f:	cmp    BYTE PTR [rcx+0x5],0x1
  40a373:	setne  al
  40a376:	jne    40a380 <__swc_fn_7069e055_000144_d5d4d43f+0x60>
  40a378:	cmp    WORD PTR [rcx+0x12],0x3e
  40a37d:	setne  al
  40a380:	test   al,al
  40a382:	je     40a391 <__swc_fn_7069e055_000144_d5d4d43f+0x71>
  40a384:	xor    eax,eax
  40a386:	pop    r15
  40a388:	pop    r14
  40a38a:	pop    r13
  40a38c:	pop    r12
  40a38e:	pop    rdi
  40a38f:	pop    rsi
  40a390:	ret
  40a391:	cmp    WORD PTR [rcx+0x3a],0x40
  40a396:	jne    40a3b1 <__swc_fn_7069e055_000144_d5d4d43f+0x91>
  40a398:	cmp    WORD PTR [rcx+0x3c],0x0
  40a39d:	sete   al
  40a3a0:	je     40a3ad <__swc_fn_7069e055_000144_d5d4d43f+0x8d>
  40a3a2:	mov    ax,WORD PTR [rcx+0x3c]
  40a3a6:	cmp    WORD PTR [rcx+0x3e],ax
  40a3aa:	setae  al
  40a3ad:	test   al,al
  40a3af:	je     40a3be <__swc_fn_7069e055_000144_d5d4d43f+0x9e>
  40a3b1:	xor    eax,eax
  40a3b3:	pop    r15
  40a3b5:	pop    r14
  40a3b7:	pop    r13
  40a3b9:	pop    r12
  40a3bb:	pop    rdi
  40a3bc:	pop    rsi
  40a3bd:	ret
  40a3be:	movzx  eax,WORD PTR [rcx+0x3c]
  40a3c2:	shl    rax,0x6
  40a3c6:	cmp    rax,rdx
  40a3c9:	ja     40a3d7 <__swc_fn_7069e055_000144_d5d4d43f+0xb7>
  40a3cb:	mov    r9,rdx
  40a3ce:	sub    r9,rax
  40a3d1:	cmp    QWORD PTR [rcx+0x28],r9
  40a3d5:	jbe    40a3e4 <__swc_fn_7069e055_000144_d5d4d43f+0xc4>
  40a3d7:	xor    eax,eax
  40a3d9:	pop    r15
  40a3db:	pop    r14
  40a3dd:	pop    r13
  40a3df:	pop    r12
  40a3e1:	pop    rdi
  40a3e2:	pop    rsi
  40a3e3:	ret
  40a3e4:	mov    rax,QWORD PTR [rcx+0x28]
  40a3e8:	add    rax,rcx
  40a3eb:	movzx  r9d,WORD PTR [rcx+0x3e]
  40a3f0:	lea    r9,[r9*8+0x0]
  40a3f8:	lea    r10,[rax+r9*8]
  40a3fc:	cmp    QWORD PTR [r10+0x20],rdx
  40a400:	ja     40a422 <__swc_fn_7069e055_000144_d5d4d43f+0x102>
  40a402:	mov    r11,rdx
  40a405:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  40a40a:	cmp    QWORD PTR [r10+0x18],r11
  40a40e:	seta   r9b
  40a412:	ja     40a41d <__swc_fn_7069e055_000144_d5d4d43f+0xfd>
  40a414:	cmp    QWORD PTR [r10+0x20],0x9
  40a419:	setb   r9b
  40a41d:	test   r9b,r9b
  40a420:	je     40a42f <__swc_fn_7069e055_000144_d5d4d43f+0x10f>
  40a422:	xor    eax,eax
  40a424:	pop    r15
  40a426:	pop    r14
  40a428:	pop    r13
  40a42a:	pop    r12
  40a42c:	pop    rdi
  40a42d:	pop    rsi
  40a42e:	ret
  40a42f:	movzx  r9d,WORD PTR [rcx+0x3c]
  40a434:	xor    r11d,r11d
  40a437:	test   r9,r9
  40a43a:	jbe    40a535 <__swc_fn_7069e055_000144_d5d4d43f+0x215>
  40a440:	mov    rsi,QWORD PTR [r10+0x20]
  40a444:	sub    rsi,0x9
  40a448:	cs nop WORD PTR [rax+rax*1+0x0]
  40a452:	cs nop WORD PTR [rax+rax*1+0x0]
  40a45c:	nop    DWORD PTR [rax+0x0]
  40a460:	movzx  edi,r11w
  40a464:	lea    rdi,[rdi*8+0x0]
  40a46c:	lea    r12,[rax+rdi*8]
  40a470:	rex mov edi,DWORD PTR [rax+rdi*8]
  40a474:	cmp    rdi,rsi
  40a477:	ja     40a528 <__swc_fn_7069e055_000144_d5d4d43f+0x208>
  40a47d:	mov    r13,QWORD PTR [r10+0x18]
  40a481:	add    r13,rdi
  40a484:	lea    rdi,[rcx+r13*1]
  40a488:	lea    r13,[rip+0x9171]        # 413600 <__swc_rdata_base_7069e055+0x4f0>
  40a48f:	movabs r14,0x676264676177732e
  40a499:	cmp    QWORD PTR [rdi],r14
  40a49c:	jne    40a4a5 <__swc_fn_7069e055_000144_d5d4d43f+0x185>
  40a49e:	rex cmp BYTE PTR [rdi+0x8],0x0
  40a4a3:	je     40a4d2 <__swc_fn_7069e055_000144_d5d4d43f+0x1b2>
  40a4a5:	cs nop WORD PTR [rax+rax*1+0x0]
  40a4af:	nop
  40a4b0:	movzx  r14d,BYTE PTR [rdi]
  40a4b4:	movzx  r15d,BYTE PTR [r13+0x0]
  40a4b9:	cmp    r14,r15
  40a4bc:	jne    40a4c8 <__swc_fn_7069e055_000144_d5d4d43f+0x1a8>
  40a4be:	add    rdi,0x1
  40a4c2:	add    r13,0x1
  40a4c6:	jmp    40a4b0 <__swc_fn_7069e055_000144_d5d4d43f+0x190>
  40a4c8:	mov    rdi,r14
  40a4cb:	sub    rdi,r15
  40a4ce:	test   edi,edi
  40a4d0:	jne    40a528 <__swc_fn_7069e055_000144_d5d4d43f+0x208>
  40a4d2:	cmp    DWORD PTR [r12+0x4],0x1
  40a4d8:	jne    40a500 <__swc_fn_7069e055_000144_d5d4d43f+0x1e0>
  40a4da:	cmp    QWORD PTR [r12+0x20],0x10
  40a4e0:	setb   al
  40a4e3:	jb     40a4fc <__swc_fn_7069e055_000144_d5d4d43f+0x1dc>
  40a4e5:	cmp    QWORD PTR [r12+0x20],rdx
  40a4ea:	seta   al
  40a4ed:	ja     40a4fc <__swc_fn_7069e055_000144_d5d4d43f+0x1dc>
  40a4ef:	sub    rdx,QWORD PTR [r12+0x20]
  40a4f4:	cmp    QWORD PTR [r12+0x18],rdx
  40a4f9:	seta   al
  40a4fc:	test   al,al
  40a4fe:	je     40a50d <__swc_fn_7069e055_000144_d5d4d43f+0x1ed>
  40a500:	xor    eax,eax
  40a502:	pop    r15
  40a504:	pop    r14
  40a506:	pop    r13
  40a508:	pop    r12
  40a50a:	pop    rdi
  40a50b:	pop    rsi
  40a50c:	ret
  40a50d:	mov    rax,QWORD PTR [r12+0x20]
  40a512:	mov    QWORD PTR [r8],rax
  40a515:	mov    rax,QWORD PTR [r12+0x18]
  40a51a:	add    rax,rcx
  40a51d:	pop    r15
  40a51f:	pop    r14
  40a521:	pop    r13
  40a523:	pop    r12
  40a525:	pop    rdi
  40a526:	pop    rsi
  40a527:	ret
  40a528:	add    r11,0x1
  40a52c:	cmp    r11,r9
  40a52f:	jb     40a460 <__swc_fn_7069e055_000144_d5d4d43f+0x140>
  40a535:	xor    eax,eax
  40a537:	pop    r15
  40a539:	pop    r14
  40a53b:	pop    r13
  40a53d:	pop    r12
  40a53f:	pop    rdi
  40a540:	pop    rsi
  40a541:	ret
	...

000000000040a550 <__swc_fn_7069e055_000147_d7edc04f>:
  40a550:	push   rdi
  40a551:	push   rsi
  40a552:	sub    rsp,0xa8
  40a559:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a55f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a565:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a56b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a571:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a577:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a57d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a583:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a589:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a592:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a59b:	mov    rdi,rcx
  40a59e:	xor    eax,eax
  40a5a0:	call   407150 <free@plt>
  40a5a5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a5ab:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a5b1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a5b7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a5bd:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a5c3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a5c9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a5cf:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a5d5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a5de:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a5e7:	add    rsp,0xa8
  40a5ee:	pop    rsi
  40a5ef:	pop    rdi
  40a5f0:	ret
	...

000000000040a600 <__swc_fn_7069e055_000150_6203dca2>:
  40a600:	push   rbx
  40a601:	push   rsi
  40a602:	push   rdi
  40a603:	push   r12
  40a605:	push   r13
  40a607:	push   r15
  40a609:	sub    rsp,0x4e8
  40a610:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  40a619:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  40a622:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  40a62b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  40a634:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  40a63d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  40a646:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  40a64f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  40a658:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  40a661:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  40a66a:	mov    rbx,QWORD PTR [rcx]
  40a66d:	mov    rcx,QWORD PTR [rcx+0x8]
  40a671:	mov    rsi,rcx
  40a674:	xor    edi,edi
  40a676:	vmovsd xmm6,QWORD PTR [rip+0x8fe2]        # 413660 <__swc_rdata_base_7069e055+0x550>
  40a67e:	vmovsd xmm7,QWORD PTR [rip+0x8fe3]        # 413669 <__swc_rdata_base_7069e055+0x559>
  40a686:	vmovsd xmm8,QWORD PTR [rip+0x8fe4]        # 413672 <__swc_rdata_base_7069e055+0x562>
  40a68e:	vmovsd xmm9,QWORD PTR [rip+0x8fe5]        # 41367b <__swc_rdata_base_7069e055+0x56b>
  40a696:	vmovsd xmm10,QWORD PTR [rip+0x8fe6]        # 413684 <__swc_rdata_base_7069e055+0x574>
  40a69e:	vmovups xmm11,xmm6
  40a6a2:	vmovsd QWORD PTR [rsp+0x418],xmm7
  40a6ab:	vmovsd QWORD PTR [rsp+0x420],xmm8
  40a6b4:	vmovsd QWORD PTR [rsp+0x428],xmm9
  40a6bd:	vmovsd QWORD PTR [rsp+0x430],xmm10
  40a6c6:	vmovsd xmm15,QWORD PTR [rip+0x8fbf]        # 41368d <__swc_rdata_base_7069e055+0x57d>
  40a6ce:	vmovups xmm14,xmm15
  40a6d3:	vmovups xmm0,xmm9
  40a6d8:	vmovsd QWORD PTR [rsp+0x438],xmm15
  40a6e1:	vmovups xmm13,xmm8
  40a6e6:	vmovsd QWORD PTR [rsp+0x440],xmm15
  40a6ef:	test   rsi,rsi
  40a6f2:	je     40b6e3 <__swc_fn_7069e055_000150_6203dca2+0x10e3>
  40a6f8:	cs nop WORD PTR [rax+rax*1+0x0]
  40a702:	cs nop WORD PTR [rax+rax*1+0x0]
  40a70c:	nop    DWORD PTR [rax+0x0]
  40a710:	lea    rcx,[rdi+rdi*1]
  40a714:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  40a719:	vpshufd xmm3,xmm2,0xee
  40a71e:	vmovq  rcx,xmm3
  40a723:	test   rcx,rcx
  40a726:	je     40a73c <__swc_fn_7069e055_000150_6203dca2+0x13c>
  40a728:	test   DWORD PTR [rcx+0x28],0x400000
  40a72f:	je     40a73c <__swc_fn_7069e055_000150_6203dca2+0x13c>
  40a731:	mov    rdx,QWORD PTR [rcx+0x30]
  40a735:	test   rdx,rdx
  40a738:	cmovne rcx,rdx
  40a73c:	test   DWORD PTR [rcx+0x28],0x1000
  40a743:	je     40a764 <__swc_fn_7069e055_000150_6203dca2+0x164>
  40a745:	mov    rdx,QWORD PTR [rcx+0x40]
  40a749:	mov    rcx,rdx
  40a74c:	vmovq  r8,xmm2
  40a751:	mov    r8,QWORD PTR [r8]
  40a754:	mov    QWORD PTR [rsp+0x60],r8
  40a759:	mov    QWORD PTR [rsp+0x68],rdx
  40a75e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  40a764:	test   BYTE PTR [rcx+0x28],0x1
  40a768:	jne    40a770 <__swc_fn_7069e055_000150_6203dca2+0x170>
  40a76a:	vmovups xmm12,xmm0
  40a76e:	jmp    40a78a <__swc_fn_7069e055_000150_6203dca2+0x18a>
  40a770:	vmovq  rax,xmm2
  40a775:	mov    rax,QWORD PTR [rax]
  40a778:	lea    rcx,[rax+0x10]
  40a77c:	vmovups xmm12,xmm0
  40a780:	call   409d90 <__swc_fn_7069e055_000120_2648f149>
  40a785:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40a78a:	test   DWORD PTR [rcx+0x28],0x400
  40a791:	je     40a7f2 <__swc_fn_7069e055_000150_6203dca2+0x1f2>
  40a793:	vmovq  rax,xmm2
  40a798:	mov    rax,QWORD PTR [rax]
  40a79b:	xor    ecx,ecx
  40a79d:	test   rax,rax
  40a7a0:	je     40a7d0 <__swc_fn_7069e055_000150_6203dca2+0x1d0>
  40a7a2:	mov    rdx,rax
  40a7a5:	mov    r8b,BYTE PTR [rdx]
  40a7a8:	test   r8b,r8b
  40a7ab:	je     40a7d0 <__swc_fn_7069e055_000150_6203dca2+0x1d0>
  40a7ad:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7b7:	nop    WORD PTR [rax+rax*1+0x0]
  40a7c0:	add    rdx,0x1
  40a7c4:	add    rcx,0x1
  40a7c8:	mov    r8b,BYTE PTR [rdx]
  40a7cb:	test   r8b,r8b
  40a7ce:	jne    40a7c0 <__swc_fn_7069e055_000150_6203dca2+0x1c0>
  40a7d0:	mov    QWORD PTR [rsp+0x88],rax
  40a7d8:	mov    QWORD PTR [rsp+0x90],rcx
  40a7e0:	lea    rcx,[rsp+0x88]
  40a7e8:	call   409d90 <__swc_fn_7069e055_000120_2648f149>
  40a7ed:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40a7f2:	cmp    BYTE PTR [rcx+0x2c],0x6
  40a7f6:	jne    40a80d <__swc_fn_7069e055_000150_6203dca2+0x20d>
  40a7f8:	vmovq  rax,xmm2
  40a7fd:	mov    rax,QWORD PTR [rax]
  40a800:	mov    rcx,rax
  40a803:	call   40e790 <__swc_fn_7069e055_000148_43c96957>
  40a808:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40a80d:	cmp    BYTE PTR [rcx+0x2c],0x1
  40a811:	jne    40b6b9 <__swc_fn_7069e055_000150_6203dca2+0x10b9>
  40a817:	vmovq  rdx,xmm2
  40a81c:	mov    cl,BYTE PTR [rcx+0x40]
  40a81f:	cmp    cl,0x7
  40a822:	jb     40a865 <__swc_fn_7069e055_000150_6203dca2+0x265>
  40a824:	je     40a8d8 <__swc_fn_7069e055_000150_6203dca2+0x2d8>
  40a82a:	cmp    cl,0x8
  40a82d:	je     40a8e4 <__swc_fn_7069e055_000150_6203dca2+0x2e4>
  40a833:	cmp    cl,0x9
  40a836:	je     40a8fd <__swc_fn_7069e055_000150_6203dca2+0x2fd>
  40a83c:	cmp    cl,0xa
  40a83f:	je     40afc4 <__swc_fn_7069e055_000150_6203dca2+0x9c4>
  40a845:	cmp    cl,0xb
  40a848:	je     40b68b <__swc_fn_7069e055_000150_6203dca2+0x108b>
  40a84e:	cmp    cl,0xc
  40a851:	je     40a8f1 <__swc_fn_7069e055_000150_6203dca2+0x2f1>
  40a857:	cmp    cl,0xd
  40a85a:	je     40b681 <__swc_fn_7069e055_000150_6203dca2+0x1081>
  40a860:	jmp    40b6ab <__swc_fn_7069e055_000150_6203dca2+0x10ab>
  40a865:	cmp    cl,0x1
  40a868:	je     40a888 <__swc_fn_7069e055_000150_6203dca2+0x288>
  40a86a:	cmp    cl,0x2
  40a86d:	je     40a896 <__swc_fn_7069e055_000150_6203dca2+0x296>
  40a86f:	cmp    cl,0x3
  40a872:	je     40a8a4 <__swc_fn_7069e055_000150_6203dca2+0x2a4>
  40a874:	cmp    cl,0x4
  40a877:	je     40a8b1 <__swc_fn_7069e055_000150_6203dca2+0x2b1>
  40a879:	cmp    cl,0x5
  40a87c:	je     40a8be <__swc_fn_7069e055_000150_6203dca2+0x2be>
  40a87e:	cmp    cl,0x6
  40a881:	je     40a8cb <__swc_fn_7069e055_000150_6203dca2+0x2cb>
  40a883:	jmp    40b6ab <__swc_fn_7069e055_000150_6203dca2+0x10ab>
  40a888:	movsx  rcx,BYTE PTR [rdx]
  40a88c:	call   411a40 <__swc_fn_7069e055_000149_2eb804cc>
  40a891:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40a896:	movsx  rcx,WORD PTR [rdx]
  40a89a:	call   411a40 <__swc_fn_7069e055_000149_2eb804cc>
  40a89f:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40a8a4:	movsxd rcx,DWORD PTR [rdx]
  40a8a7:	call   411a40 <__swc_fn_7069e055_000149_2eb804cc>
  40a8ac:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40a8b1:	mov    rcx,QWORD PTR [rdx]
  40a8b4:	call   411a40 <__swc_fn_7069e055_000149_2eb804cc>
  40a8b9:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40a8be:	movzx  ecx,BYTE PTR [rdx]
  40a8c1:	call   40e790 <__swc_fn_7069e055_000148_43c96957>
  40a8c6:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40a8cb:	movzx  ecx,WORD PTR [rdx]
  40a8ce:	call   40e790 <__swc_fn_7069e055_000148_43c96957>
  40a8d3:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40a8d8:	mov    ecx,DWORD PTR [rdx]
  40a8da:	call   40e790 <__swc_fn_7069e055_000148_43c96957>
  40a8df:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40a8e4:	mov    rcx,QWORD PTR [rdx]
  40a8e7:	call   40e790 <__swc_fn_7069e055_000148_43c96957>
  40a8ec:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40a8f1:	mov    ecx,DWORD PTR [rdx]
  40a8f3:	call   40e790 <__swc_fn_7069e055_000148_43c96957>
  40a8f8:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40a8fd:	lea    rcx,[rsp+0xa8]
  40a905:	vxorps xmm0,xmm0,xmm0
  40a909:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  40a912:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  40a91b:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  40a924:	vzeroupper
  40a927:	mov    DWORD PTR [rsp+0x108],0x0
  40a932:	vxorpd xmm0,xmm0,xmm0
  40a936:	vmovss xmm1,DWORD PTR [rdx]
  40a93a:	vcvtss2sd xmm0,xmm0,xmm1
  40a93e:	vmovsd xmm1,xmm1,xmm0
  40a942:	vcomisd xmm0,xmm0
  40a946:	setne  dl
  40a949:	movzx  edx,dl
  40a94c:	setp   r8b
  40a950:	movzx  r8d,r8b
  40a954:	or     edx,r8d
  40a957:	test   dl,dl
  40a959:	je     40a966 <__swc_fn_7069e055_000150_6203dca2+0x366>
  40a95b:	mov    DWORD PTR [rcx],0x6e616e
  40a961:	jmp    40af58 <__swc_fn_7069e055_000150_6203dca2+0x958>
  40a966:	vcomisd xmm1,xmm6
  40a96a:	ja     40a972 <__swc_fn_7069e055_000150_6203dca2+0x372>
  40a96c:	vcomisd xmm7,xmm1
  40a970:	jbe    40a996 <__swc_fn_7069e055_000150_6203dca2+0x396>
  40a972:	vxorpd xmm0,xmm0,xmm0
  40a976:	vcomisd xmm0,xmm1
  40a97a:	jbe    40a98b <__swc_fn_7069e055_000150_6203dca2+0x38b>
  40a97c:	mov    DWORD PTR [rcx],0x666e692d
  40a982:	mov    BYTE PTR [rcx+0x4],0x0
  40a986:	jmp    40af58 <__swc_fn_7069e055_000150_6203dca2+0x958>
  40a98b:	mov    DWORD PTR [rcx],0x666e69
  40a991:	jmp    40af58 <__swc_fn_7069e055_000150_6203dca2+0x958>
  40a996:	vcomisd xmm1,xmm8
  40a99b:	jae    40a9a7 <__swc_fn_7069e055_000150_6203dca2+0x3a7>
  40a99d:	vcomisd xmm9,xmm1
  40a9a1:	jbe    40ad1e <__swc_fn_7069e055_000150_6203dca2+0x71e>
  40a9a7:	vmovups xmm0,xmm1
  40a9ab:	vxorpd xmm2,xmm2,xmm2
  40a9af:	vcomisd xmm2,xmm1
  40a9b3:	jbe    40a9c3 <__swc_fn_7069e055_000150_6203dca2+0x3c3>
  40a9b5:	vmovsd xmm1,xmm1,xmm0
  40a9b9:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x8c5f]        # 413620 <__swc_rdata_base_7069e055+0x510>
  40a9c1:	jmp    40a9c7 <__swc_fn_7069e055_000150_6203dca2+0x3c7>
  40a9c3:	vmovsd xmm1,xmm1,xmm0
  40a9c7:	xor    r8d,r8d
  40a9ca:	vcomisd xmm1,xmm15
  40a9cf:	jb     40a9f0 <__swc_fn_7069e055_000150_6203dca2+0x3f0>
  40a9d1:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9db:	nop    DWORD PTR [rax+rax*1+0x0]
  40a9e0:	vdivsd xmm1,xmm1,xmm15
  40a9e5:	add    r8,0x1
  40a9e9:	vcomisd xmm1,xmm15
  40a9ee:	jae    40a9e0 <__swc_fn_7069e055_000150_6203dca2+0x3e0>
  40a9f0:	mov    r9,rcx
  40a9f3:	vxorpd xmm2,xmm2,xmm2
  40a9f7:	vcomisd xmm2,xmm0
  40a9fb:	jbe    40aa04 <__swc_fn_7069e055_000150_6203dca2+0x404>
  40a9fd:	mov    BYTE PTR [rcx],0x2d
  40aa00:	lea    r9,[rcx+0x1]
  40aa04:	vcvttsd2si rdx,xmm1
  40aa09:	mov    r10b,dl
  40aa0c:	add    r10b,0x30
  40aa10:	mov    BYTE PTR [r9],r10b
  40aa13:	vxorpd xmm0,xmm0,xmm0
  40aa17:	movzx  edx,dl
  40aa1a:	vcvtsi2sd xmm0,xmm0,rdx
  40aa1f:	vsubsd xmm0,xmm1,xmm0
  40aa23:	vmulsd xmm1,xmm0,xmm15
  40aa28:	mov    BYTE PTR [r9+0x1],0x2e
  40aa2d:	vcvttsd2si rdx,xmm1
  40aa32:	mov    r10b,dl
  40aa35:	add    r10b,0x30
  40aa39:	mov    BYTE PTR [r9+0x2],r10b
  40aa3d:	vxorpd xmm0,xmm0,xmm0
  40aa41:	movzx  edx,dl
  40aa44:	vcvtsi2sd xmm0,xmm0,rdx
  40aa49:	vsubsd xmm0,xmm1,xmm0
  40aa4d:	vmulsd xmm1,xmm0,xmm15
  40aa52:	vcvttsd2si rdx,xmm1
  40aa57:	mov    r10b,dl
  40aa5a:	add    r10b,0x30
  40aa5e:	mov    BYTE PTR [r9+0x3],r10b
  40aa62:	vxorpd xmm0,xmm0,xmm0
  40aa66:	movzx  edx,dl
  40aa69:	vcvtsi2sd xmm0,xmm0,rdx
  40aa6e:	vsubsd xmm0,xmm1,xmm0
  40aa72:	vmulsd xmm1,xmm0,xmm15
  40aa77:	vcvttsd2si rdx,xmm1
  40aa7c:	mov    r10b,dl
  40aa7f:	add    r10b,0x30
  40aa83:	mov    BYTE PTR [r9+0x4],r10b
  40aa87:	vxorpd xmm0,xmm0,xmm0
  40aa8b:	movzx  edx,dl
  40aa8e:	vcvtsi2sd xmm0,xmm0,rdx
  40aa93:	vsubsd xmm0,xmm1,xmm0
  40aa97:	vmulsd xmm1,xmm0,xmm15
  40aa9c:	vcvttsd2si rdx,xmm1
  40aaa1:	mov    r10b,dl
  40aaa4:	add    r10b,0x30
  40aaa8:	mov    BYTE PTR [r9+0x5],r10b
  40aaac:	vxorpd xmm0,xmm0,xmm0
  40aab0:	movzx  edx,dl
  40aab3:	vcvtsi2sd xmm0,xmm0,rdx
  40aab8:	vsubsd xmm0,xmm1,xmm0
  40aabc:	vmulsd xmm1,xmm0,xmm15
  40aac1:	vcvttsd2si rdx,xmm1
  40aac6:	mov    r10b,dl
  40aac9:	add    r10b,0x30
  40aacd:	mov    BYTE PTR [r9+0x6],r10b
  40aad1:	vxorpd xmm0,xmm0,xmm0
  40aad5:	movzx  edx,dl
  40aad8:	vcvtsi2sd xmm0,xmm0,rdx
  40aadd:	vsubsd xmm0,xmm1,xmm0
  40aae1:	vmulsd xmm1,xmm0,xmm15
  40aae6:	vcvttsd2si rdx,xmm1
  40aaeb:	mov    r10b,dl
  40aaee:	add    r10b,0x30
  40aaf2:	mov    BYTE PTR [r9+0x7],r10b
  40aaf6:	vxorpd xmm0,xmm0,xmm0
  40aafa:	movzx  edx,dl
  40aafd:	vcvtsi2sd xmm0,xmm0,rdx
  40ab02:	vsubsd xmm0,xmm1,xmm0
  40ab06:	vmulsd xmm1,xmm0,xmm15
  40ab0b:	vcvttsd2si rdx,xmm1
  40ab10:	mov    r10b,dl
  40ab13:	add    r10b,0x30
  40ab17:	mov    BYTE PTR [r9+0x8],r10b
  40ab1b:	vxorpd xmm0,xmm0,xmm0
  40ab1f:	movzx  edx,dl
  40ab22:	vcvtsi2sd xmm0,xmm0,rdx
  40ab27:	vsubsd xmm0,xmm1,xmm0
  40ab2b:	vmulsd xmm1,xmm0,xmm15
  40ab30:	vcvttsd2si rdx,xmm1
  40ab35:	mov    r10b,dl
  40ab38:	add    r10b,0x30
  40ab3c:	mov    BYTE PTR [r9+0x9],r10b
  40ab40:	vxorpd xmm0,xmm0,xmm0
  40ab44:	movzx  edx,dl
  40ab47:	vcvtsi2sd xmm0,xmm0,rdx
  40ab4c:	vsubsd xmm0,xmm1,xmm0
  40ab50:	vmulsd xmm1,xmm0,xmm15
  40ab55:	vcvttsd2si rdx,xmm1
  40ab5a:	mov    r10b,dl
  40ab5d:	add    r10b,0x30
  40ab61:	mov    BYTE PTR [r9+0xa],r10b
  40ab65:	vxorpd xmm0,xmm0,xmm0
  40ab69:	movzx  edx,dl
  40ab6c:	vcvtsi2sd xmm0,xmm0,rdx
  40ab71:	vsubsd xmm0,xmm1,xmm0
  40ab75:	vmulsd xmm1,xmm0,xmm15
  40ab7a:	vcvttsd2si rdx,xmm1
  40ab7f:	mov    r10b,dl
  40ab82:	add    r10b,0x30
  40ab86:	mov    BYTE PTR [r9+0xb],r10b
  40ab8a:	lea    r10,[r9+0x4]
  40ab8e:	vxorpd xmm0,xmm0,xmm0
  40ab92:	movzx  edx,dl
  40ab95:	vcvtsi2sd xmm0,xmm0,rdx
  40ab9a:	vsubsd xmm0,xmm1,xmm0
  40ab9e:	vmulsd xmm1,xmm0,xmm15
  40aba3:	vcvttsd2si rdx,xmm1
  40aba8:	mov    r11b,dl
  40abab:	add    r11b,0x30
  40abaf:	mov    BYTE PTR [r9+0xc],r11b
  40abb3:	vxorpd xmm0,xmm0,xmm0
  40abb7:	movzx  edx,dl
  40abba:	vcvtsi2sd xmm0,xmm0,rdx
  40abbf:	vsubsd xmm0,xmm1,xmm0
  40abc3:	vmulsd xmm1,xmm0,xmm15
  40abc8:	vcvttsd2si rdx,xmm1
  40abcd:	mov    r11b,dl
  40abd0:	add    r11b,0x30
  40abd4:	mov    BYTE PTR [r9+0xd],r11b
  40abd8:	lea    r10,[r10+0x2]
  40abdc:	vxorpd xmm0,xmm0,xmm0
  40abe0:	movzx  edx,dl
  40abe3:	vcvtsi2sd xmm0,xmm0,rdx
  40abe8:	vsubsd xmm0,xmm1,xmm0
  40abec:	vmulsd xmm1,xmm0,xmm15
  40abf1:	vcvttsd2si rdx,xmm1
  40abf6:	mov    r11b,dl
  40abf9:	add    r11b,0x30
  40abfd:	mov    BYTE PTR [r9+0xe],r11b
  40ac01:	vxorpd xmm0,xmm0,xmm0
  40ac05:	movzx  edx,dl
  40ac08:	vcvtsi2sd xmm0,xmm0,rdx
  40ac0d:	vsubsd xmm0,xmm1,xmm0
  40ac11:	vmulsd xmm1,xmm0,xmm15
  40ac16:	vcvttsd2si rdx,xmm1
  40ac1b:	mov    r11b,dl
  40ac1e:	add    r11b,0x30
  40ac22:	mov    BYTE PTR [r9+0xf],r11b
  40ac26:	lea    r10,[r10+0x2]
  40ac2a:	lea    r10,[r10+0x2]
  40ac2e:	lea    r10,[r10+0x2]
  40ac32:	lea    r10,[r10+0x2]
  40ac36:	lea    r10,[r10+0x2]
  40ac3a:	vxorpd xmm0,xmm0,xmm0
  40ac3e:	movzx  edx,dl
  40ac41:	vcvtsi2sd xmm0,xmm0,rdx
  40ac46:	vsubsd xmm0,xmm1,xmm0
  40ac4a:	vmulsd xmm1,xmm0,xmm15
  40ac4f:	vcvttsd2si rdx,xmm1
  40ac54:	mov    r11b,dl
  40ac57:	add    r11b,0x30
  40ac5b:	mov    BYTE PTR [r9+0x10],r11b
  40ac5f:	vxorpd xmm0,xmm0,xmm0
  40ac63:	movzx  edx,dl
  40ac66:	vcvtsi2sd xmm0,xmm0,rdx
  40ac6b:	vsubsd xmm0,xmm1,xmm0
  40ac6f:	vmulsd xmm1,xmm0,xmm15
  40ac74:	vcvttsd2si rdx,xmm1
  40ac79:	add    dl,0x30
  40ac7c:	mov    BYTE PTR [r9+0x11],dl
  40ac80:	mov    BYTE PTR [r10+0x2],0x65
  40ac85:	lea    r9,[r10+0x3]
  40ac89:	test   r8,r8
  40ac8c:	jl     40ac95 <__swc_fn_7069e055_000150_6203dca2+0x695>
  40ac8e:	mov    BYTE PTR [r9],0x2b
  40ac92:	inc    r9
  40ac95:	mov    r10,r9
  40ac98:	mov    rdx,r8
  40ac9b:	nop    DWORD PTR [rax+rax*1+0x0]
  40aca0:	mov    r11,rdx
  40aca3:	movabs rdx,0x6666666666666667
  40acad:	mov    rax,r11
  40acb0:	imul   rdx
  40acb3:	sar    rdx,0x2
  40acb7:	mov    r12,rdx
  40acba:	shr    rdx,0x3f
  40acbe:	add    r12,rdx
  40acc1:	mov    rdx,r12
  40acc4:	imul   r13,r12,0xa
  40acc8:	sub    r11,r13
  40accb:	mov    r13,QWORD PTR [rip+0x893e]        # 413610 <__swc_rdata_base_7069e055+0x500>
  40acd2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40acd7:	mov    BYTE PTR [r10],r11b
  40acda:	lea    r11,[r10+0x1]
  40acde:	mov    r10,r11
  40ace1:	test   r12,r12
  40ace4:	jne    40aca0 <__swc_fn_7069e055_000150_6203dca2+0x6a0>
  40ace6:	test   r8,r8
  40ace9:	jge    40acf3 <__swc_fn_7069e055_000150_6203dca2+0x6f3>
  40aceb:	mov    BYTE PTR [r11],0x2d
  40acef:	lea    r10,[r11+0x1]
  40acf3:	mov    BYTE PTR [r10],0x0
  40acf7:	sub    r10,0x1
  40acfb:	nop    DWORD PTR [rax+rax*1+0x0]
  40ad00:	cmp    r9,r10
  40ad03:	jae    40af58 <__swc_fn_7069e055_000150_6203dca2+0x958>
  40ad09:	mov    al,BYTE PTR [r10]
  40ad0c:	mov    dl,BYTE PTR [r9]
  40ad0f:	mov    BYTE PTR [r10],dl
  40ad12:	sub    r10,0x1
  40ad16:	mov    BYTE PTR [r9],al
  40ad19:	inc    r9
  40ad1c:	jmp    40ad00 <__swc_fn_7069e055_000150_6203dca2+0x700>
  40ad1e:	vcvttsd2si rdx,xmm1
  40ad23:	mov    r8,rdx
  40ad26:	vxorpd xmm0,xmm0,xmm0
  40ad2a:	vcvtsi2sd xmm0,xmm0,rdx
  40ad2f:	vsubsd xmm0,xmm1,xmm0
  40ad33:	mov    r9d,0x8
  40ad39:	vxorpd xmm2,xmm2,xmm2
  40ad3d:	vcomisd xmm2,xmm0
  40ad41:	jbe    40ad4b <__swc_fn_7069e055_000150_6203dca2+0x74b>
  40ad43:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x88d5]        # 413620 <__swc_rdata_base_7069e055+0x510>
  40ad4b:	test   r9d,r9d
  40ad4e:	je     40ad5a <__swc_fn_7069e055_000150_6203dca2+0x75a>
  40ad50:	vmulsd xmm0,xmm0,xmm14
  40ad55:	dec    r9d
  40ad58:	jne    40ad50 <__swc_fn_7069e055_000150_6203dca2+0x750>
  40ad5a:	vcvttsd2si r9,xmm0
  40ad5f:	mov    r10,r9
  40ad62:	vxorpd xmm2,xmm2,xmm2
  40ad66:	vcvtsi2sd xmm2,xmm2,r9
  40ad6b:	vsubsd xmm0,xmm0,xmm2
  40ad6f:	vcomisd xmm0,xmm10
  40ad74:	lea    r9,[r9+0x1]
  40ad78:	cmova  r10,r9
  40ad7c:	cmp    r10,0x5f5e100
  40ad83:	jne    40ad9c <__swc_fn_7069e055_000150_6203dca2+0x79c>
  40ad85:	lea    r8,[rdx-0x1]
  40ad89:	vxorpd xmm0,xmm0,xmm0
  40ad8d:	vcomisd xmm0,xmm1
  40ad91:	lea    rdx,[rdx+0x1]
  40ad95:	cmovbe r8,rdx
  40ad99:	xor    r10d,r10d
  40ad9c:	mov    r9,rcx
  40ad9f:	test   r8,r8
  40ada2:	jne    40adc2 <__swc_fn_7069e055_000150_6203dca2+0x7c2>
  40ada4:	vxorpd xmm0,xmm0,xmm0
  40ada8:	vcomisd xmm0,xmm1
  40adac:	jbe    40adb5 <__swc_fn_7069e055_000150_6203dca2+0x7b5>
  40adae:	mov    BYTE PTR [rcx],0x2d
  40adb1:	lea    r9,[rcx+0x1]
  40adb5:	mov    BYTE PTR [r9],0x30
  40adb9:	add    r9,0x1
  40adbd:	jmp    40ae5b <__swc_fn_7069e055_000150_6203dca2+0x85b>
  40adc2:	mov    r9,rcx
  40adc5:	mov    rdx,r8
  40adc8:	nop    DWORD PTR [rax+rax*1+0x0]
  40add0:	mov    r11,rdx
  40add3:	movabs rdx,0x6666666666666667
  40addd:	mov    r15,rax
  40ade0:	mov    rax,r11
  40ade3:	imul   rdx
  40ade6:	mov    r12,rdx
  40ade9:	mov    rax,r15
  40adec:	sar    r12,0x2
  40adf0:	mov    rdx,r12
  40adf3:	shr    rdx,0x3f
  40adf7:	add    r12,rdx
  40adfa:	mov    rdx,r12
  40adfd:	imul   r13,r12,0xa
  40ae01:	sub    r11,r13
  40ae04:	mov    r13,QWORD PTR [rip+0x8805]        # 413610 <__swc_rdata_base_7069e055+0x500>
  40ae0b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40ae10:	mov    BYTE PTR [r9],r11b
  40ae13:	lea    r11,[r9+0x1]
  40ae17:	mov    r9,r11
  40ae1a:	test   r12,r12
  40ae1d:	jne    40add0 <__swc_fn_7069e055_000150_6203dca2+0x7d0>
  40ae1f:	test   r8,r8
  40ae22:	jge    40ae2c <__swc_fn_7069e055_000150_6203dca2+0x82c>
  40ae24:	mov    BYTE PTR [r11],0x2d
  40ae28:	lea    r9,[r11+0x1]
  40ae2c:	mov    rdx,r9
  40ae2f:	mov    BYTE PTR [r9],0x0
  40ae33:	sub    r9,0x1
  40ae37:	mov    r8,rcx
  40ae3a:	cmp    r8,r9
  40ae3d:	jae    40ae58 <__swc_fn_7069e055_000150_6203dca2+0x858>
  40ae3f:	nop
  40ae40:	mov    r11b,BYTE PTR [r9]
  40ae43:	mov    r12b,BYTE PTR [r8]
  40ae46:	mov    BYTE PTR [r9],r12b
  40ae49:	sub    r9,0x1
  40ae4d:	mov    BYTE PTR [r8],r11b
  40ae50:	inc    r8
  40ae53:	cmp    r8,r9
  40ae56:	jb     40ae40 <__swc_fn_7069e055_000150_6203dca2+0x840>
  40ae58:	mov    r9,rdx
  40ae5b:	mov    BYTE PTR [r9],0x2e
  40ae5f:	add    r9,0x1
  40ae63:	xor    r8d,r8d
  40ae66:	test   r10,r10
  40ae69:	je     40aeaf <__swc_fn_7069e055_000150_6203dca2+0x8af>
  40ae6b:	mov    r11d,0x989680
  40ae71:	cmp    r10,r11
  40ae74:	jge    40aeaf <__swc_fn_7069e055_000150_6203dca2+0x8af>
  40ae76:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae80:	inc    r8d
  40ae83:	movabs rdx,0x6666666666666667
  40ae8d:	mov    r15,rax
  40ae90:	mov    rax,r11
  40ae93:	imul   rdx
  40ae96:	mov    r11,rdx
  40ae99:	mov    rax,r15
  40ae9c:	sar    r11,0x2
  40aea0:	mov    rdx,r11
  40aea3:	shr    rdx,0x3f
  40aea7:	add    r11,rdx
  40aeaa:	cmp    r10,r11
  40aead:	jl     40ae80 <__swc_fn_7069e055_000150_6203dca2+0x880>
  40aeaf:	test   r8d,r8d
  40aeb2:	je     40aecd <__swc_fn_7069e055_000150_6203dca2+0x8cd>
  40aeb4:	cs nop WORD PTR [rax+rax*1+0x0]
  40aebe:	xchg   ax,ax
  40aec0:	mov    BYTE PTR [r9],0x30
  40aec4:	add    r9,0x1
  40aec8:	dec    r8d
  40aecb:	jne    40aec0 <__swc_fn_7069e055_000150_6203dca2+0x8c0>
  40aecd:	mov    r8,r9
  40aed0:	mov    rdx,r10
  40aed3:	cs nop WORD PTR [rax+rax*1+0x0]
  40aedd:	nop    DWORD PTR [rax]
  40aee0:	mov    r11,rdx
  40aee3:	movabs rdx,0x6666666666666667
  40aeed:	mov    rax,r11
  40aef0:	imul   rdx
  40aef3:	sar    rdx,0x2
  40aef7:	mov    r12,rdx
  40aefa:	shr    rdx,0x3f
  40aefe:	add    r12,rdx
  40af01:	mov    rdx,r12
  40af04:	imul   r13,r12,0xa
  40af08:	sub    r11,r13
  40af0b:	mov    r13,QWORD PTR [rip+0x86fe]        # 413610 <__swc_rdata_base_7069e055+0x500>
  40af12:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40af17:	mov    BYTE PTR [r8],r11b
  40af1a:	lea    r11,[r8+0x1]
  40af1e:	mov    r8,r11
  40af21:	test   r12,r12
  40af24:	jne    40aee0 <__swc_fn_7069e055_000150_6203dca2+0x8e0>
  40af26:	test   r10,r10
  40af29:	jge    40af33 <__swc_fn_7069e055_000150_6203dca2+0x933>
  40af2b:	mov    BYTE PTR [r11],0x2d
  40af2f:	lea    r8,[r11+0x1]
  40af33:	mov    BYTE PTR [r8],0x0
  40af37:	sub    r8,0x1
  40af3b:	cmp    r9,r8
  40af3e:	jae    40af58 <__swc_fn_7069e055_000150_6203dca2+0x958>
  40af40:	mov    al,BYTE PTR [r8]
  40af43:	mov    dl,BYTE PTR [r9]
  40af46:	mov    BYTE PTR [r8],dl
  40af49:	sub    r8,0x1
  40af4d:	mov    BYTE PTR [r9],al
  40af50:	inc    r9
  40af53:	cmp    r9,r8
  40af56:	jb     40af40 <__swc_fn_7069e055_000150_6203dca2+0x940>
  40af58:	xor    eax,eax
  40af5a:	test   rcx,rcx
  40af5d:	je     40af90 <__swc_fn_7069e055_000150_6203dca2+0x990>
  40af5f:	mov    rdx,rcx
  40af62:	mov    r8b,BYTE PTR [rdx]
  40af65:	test   r8b,r8b
  40af68:	je     40af90 <__swc_fn_7069e055_000150_6203dca2+0x990>
  40af6a:	cs nop WORD PTR [rax+rax*1+0x0]
  40af74:	cs nop WORD PTR [rax+rax*1+0x0]
  40af7e:	xchg   ax,ax
  40af80:	add    rdx,0x1
  40af84:	add    rax,0x1
  40af88:	mov    r8b,BYTE PTR [rdx]
  40af8b:	test   r8b,r8b
  40af8e:	jne    40af80 <__swc_fn_7069e055_000150_6203dca2+0x980>
  40af90:	mov    QWORD PTR [rsp+0x240],rcx
  40af98:	mov    QWORD PTR [rsp+0x248],rax
  40afa0:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  40afa9:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  40afb2:	lea    rcx,[rsp+0x250]
  40afba:	call   409d90 <__swc_fn_7069e055_000120_2648f149>
  40afbf:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40afc4:	lea    rcx,[rsp+0x260]
  40afcc:	vxorps xmm0,xmm0,xmm0
  40afd0:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  40afd9:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  40afe2:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  40afeb:	vzeroupper
  40afee:	mov    DWORD PTR [rsp+0x2c0],0x0
  40aff9:	vmovsd xmm0,QWORD PTR [rdx]
  40affd:	vcomisd xmm0,xmm0
  40b001:	setne  dl
  40b004:	movzx  edx,dl
  40b007:	setp   r8b
  40b00b:	movzx  r8d,r8b
  40b00f:	or     edx,r8d
  40b012:	test   dl,dl
  40b014:	je     40b021 <__swc_fn_7069e055_000150_6203dca2+0xa21>
  40b016:	mov    DWORD PTR [rcx],0x6e616e
  40b01c:	jmp    40b628 <__swc_fn_7069e055_000150_6203dca2+0x1028>
  40b021:	vcomisd xmm0,xmm11
  40b026:	ja     40b037 <__swc_fn_7069e055_000150_6203dca2+0xa37>
  40b028:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  40b031:	vcomisd xmm6,xmm0
  40b035:	jbe    40b05b <__swc_fn_7069e055_000150_6203dca2+0xa5b>
  40b037:	vxorpd xmm1,xmm1,xmm1
  40b03b:	vcomisd xmm1,xmm0
  40b03f:	jbe    40b050 <__swc_fn_7069e055_000150_6203dca2+0xa50>
  40b041:	mov    DWORD PTR [rcx],0x666e692d
  40b047:	mov    BYTE PTR [rcx+0x4],0x0
  40b04b:	jmp    40b628 <__swc_fn_7069e055_000150_6203dca2+0x1028>
  40b050:	mov    DWORD PTR [rcx],0x666e69
  40b056:	jmp    40b628 <__swc_fn_7069e055_000150_6203dca2+0x1028>
  40b05b:	vcomisd xmm0,xmm13
  40b060:	jae    40b06c <__swc_fn_7069e055_000150_6203dca2+0xa6c>
  40b062:	vcomisd xmm12,xmm0
  40b066:	jbe    40b3ce <__swc_fn_7069e055_000150_6203dca2+0xdce>
  40b06c:	vmovups xmm1,xmm0
  40b070:	vxorpd xmm2,xmm2,xmm2
  40b074:	vcomisd xmm2,xmm0
  40b078:	jbe    40b088 <__swc_fn_7069e055_000150_6203dca2+0xa88>
  40b07a:	vmovsd xmm0,xmm0,xmm1
  40b07e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x859a]        # 413620 <__swc_rdata_base_7069e055+0x510>
  40b086:	jmp    40b08c <__swc_fn_7069e055_000150_6203dca2+0xa8c>
  40b088:	vmovsd xmm0,xmm0,xmm1
  40b08c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  40b095:	xor    r8d,r8d
  40b098:	vcomisd xmm0,xmm6
  40b09c:	jb     40b0ae <__swc_fn_7069e055_000150_6203dca2+0xaae>
  40b09e:	xchg   ax,ax
  40b0a0:	vdivsd xmm0,xmm0,xmm6
  40b0a4:	add    r8,0x1
  40b0a8:	vcomisd xmm0,xmm6
  40b0ac:	jae    40b0a0 <__swc_fn_7069e055_000150_6203dca2+0xaa0>
  40b0ae:	mov    r9,rcx
  40b0b1:	vxorpd xmm2,xmm2,xmm2
  40b0b5:	vcomisd xmm2,xmm1
  40b0b9:	jbe    40b0c2 <__swc_fn_7069e055_000150_6203dca2+0xac2>
  40b0bb:	mov    BYTE PTR [rcx],0x2d
  40b0be:	lea    r9,[rcx+0x1]
  40b0c2:	vcvttsd2si rdx,xmm0
  40b0c7:	mov    r10b,dl
  40b0ca:	add    r10b,0x30
  40b0ce:	mov    BYTE PTR [r9],r10b
  40b0d1:	vxorpd xmm1,xmm1,xmm1
  40b0d5:	movzx  edx,dl
  40b0d8:	vcvtsi2sd xmm1,xmm1,rdx
  40b0dd:	vsubsd xmm0,xmm0,xmm1
  40b0e1:	vmulsd xmm0,xmm0,xmm6
  40b0e5:	mov    BYTE PTR [r9+0x1],0x2e
  40b0ea:	vcvttsd2si rdx,xmm0
  40b0ef:	mov    r10b,dl
  40b0f2:	add    r10b,0x30
  40b0f6:	mov    BYTE PTR [r9+0x2],r10b
  40b0fa:	vxorpd xmm1,xmm1,xmm1
  40b0fe:	movzx  edx,dl
  40b101:	vcvtsi2sd xmm1,xmm1,rdx
  40b106:	vsubsd xmm0,xmm0,xmm1
  40b10a:	vmulsd xmm0,xmm0,xmm6
  40b10e:	vcvttsd2si rdx,xmm0
  40b113:	mov    r10b,dl
  40b116:	add    r10b,0x30
  40b11a:	mov    BYTE PTR [r9+0x3],r10b
  40b11e:	vxorpd xmm1,xmm1,xmm1
  40b122:	movzx  edx,dl
  40b125:	vcvtsi2sd xmm1,xmm1,rdx
  40b12a:	vsubsd xmm0,xmm0,xmm1
  40b12e:	vmulsd xmm0,xmm0,xmm6
  40b132:	vcvttsd2si rdx,xmm0
  40b137:	mov    r10b,dl
  40b13a:	add    r10b,0x30
  40b13e:	mov    BYTE PTR [r9+0x4],r10b
  40b142:	vxorpd xmm1,xmm1,xmm1
  40b146:	movzx  edx,dl
  40b149:	vcvtsi2sd xmm1,xmm1,rdx
  40b14e:	vsubsd xmm0,xmm0,xmm1
  40b152:	vmulsd xmm0,xmm0,xmm6
  40b156:	vcvttsd2si rdx,xmm0
  40b15b:	mov    r10b,dl
  40b15e:	add    r10b,0x30
  40b162:	mov    BYTE PTR [r9+0x5],r10b
  40b166:	vxorpd xmm1,xmm1,xmm1
  40b16a:	movzx  edx,dl
  40b16d:	vcvtsi2sd xmm1,xmm1,rdx
  40b172:	vsubsd xmm0,xmm0,xmm1
  40b176:	vmulsd xmm0,xmm0,xmm6
  40b17a:	vcvttsd2si rdx,xmm0
  40b17f:	mov    r10b,dl
  40b182:	add    r10b,0x30
  40b186:	mov    BYTE PTR [r9+0x6],r10b
  40b18a:	vxorpd xmm1,xmm1,xmm1
  40b18e:	movzx  edx,dl
  40b191:	vcvtsi2sd xmm1,xmm1,rdx
  40b196:	vsubsd xmm0,xmm0,xmm1
  40b19a:	vmulsd xmm0,xmm0,xmm6
  40b19e:	vcvttsd2si rdx,xmm0
  40b1a3:	mov    r10b,dl
  40b1a6:	add    r10b,0x30
  40b1aa:	mov    BYTE PTR [r9+0x7],r10b
  40b1ae:	vxorpd xmm1,xmm1,xmm1
  40b1b2:	movzx  edx,dl
  40b1b5:	vcvtsi2sd xmm1,xmm1,rdx
  40b1ba:	vsubsd xmm0,xmm0,xmm1
  40b1be:	vmulsd xmm0,xmm0,xmm6
  40b1c2:	vcvttsd2si rdx,xmm0
  40b1c7:	mov    r10b,dl
  40b1ca:	add    r10b,0x30
  40b1ce:	mov    BYTE PTR [r9+0x8],r10b
  40b1d2:	vxorpd xmm1,xmm1,xmm1
  40b1d6:	movzx  edx,dl
  40b1d9:	vcvtsi2sd xmm1,xmm1,rdx
  40b1de:	vsubsd xmm0,xmm0,xmm1
  40b1e2:	vmulsd xmm0,xmm0,xmm6
  40b1e6:	vcvttsd2si rdx,xmm0
  40b1eb:	mov    r10b,dl
  40b1ee:	add    r10b,0x30
  40b1f2:	mov    BYTE PTR [r9+0x9],r10b
  40b1f6:	vxorpd xmm1,xmm1,xmm1
  40b1fa:	movzx  edx,dl
  40b1fd:	vcvtsi2sd xmm1,xmm1,rdx
  40b202:	vsubsd xmm0,xmm0,xmm1
  40b206:	vmulsd xmm0,xmm0,xmm6
  40b20a:	vcvttsd2si rdx,xmm0
  40b20f:	mov    r10b,dl
  40b212:	add    r10b,0x30
  40b216:	mov    BYTE PTR [r9+0xa],r10b
  40b21a:	vxorpd xmm1,xmm1,xmm1
  40b21e:	movzx  edx,dl
  40b221:	vcvtsi2sd xmm1,xmm1,rdx
  40b226:	vsubsd xmm0,xmm0,xmm1
  40b22a:	vmulsd xmm0,xmm0,xmm6
  40b22e:	vcvttsd2si rdx,xmm0
  40b233:	mov    r10b,dl
  40b236:	add    r10b,0x30
  40b23a:	mov    BYTE PTR [r9+0xb],r10b
  40b23e:	lea    r10,[r9+0x4]
  40b242:	vxorpd xmm1,xmm1,xmm1
  40b246:	movzx  edx,dl
  40b249:	vcvtsi2sd xmm1,xmm1,rdx
  40b24e:	vsubsd xmm0,xmm0,xmm1
  40b252:	vmulsd xmm0,xmm0,xmm6
  40b256:	vcvttsd2si rdx,xmm0
  40b25b:	mov    r11b,dl
  40b25e:	add    r11b,0x30
  40b262:	mov    BYTE PTR [r9+0xc],r11b
  40b266:	vxorpd xmm1,xmm1,xmm1
  40b26a:	movzx  edx,dl
  40b26d:	vcvtsi2sd xmm1,xmm1,rdx
  40b272:	vsubsd xmm0,xmm0,xmm1
  40b276:	vmulsd xmm0,xmm0,xmm6
  40b27a:	vcvttsd2si rdx,xmm0
  40b27f:	mov    r11b,dl
  40b282:	add    r11b,0x30
  40b286:	mov    BYTE PTR [r9+0xd],r11b
  40b28a:	lea    r10,[r10+0x2]
  40b28e:	vxorpd xmm1,xmm1,xmm1
  40b292:	movzx  edx,dl
  40b295:	vcvtsi2sd xmm1,xmm1,rdx
  40b29a:	vsubsd xmm0,xmm0,xmm1
  40b29e:	vmulsd xmm0,xmm0,xmm6
  40b2a2:	vcvttsd2si rdx,xmm0
  40b2a7:	mov    r11b,dl
  40b2aa:	add    r11b,0x30
  40b2ae:	mov    BYTE PTR [r9+0xe],r11b
  40b2b2:	vxorpd xmm1,xmm1,xmm1
  40b2b6:	movzx  edx,dl
  40b2b9:	vcvtsi2sd xmm1,xmm1,rdx
  40b2be:	vsubsd xmm0,xmm0,xmm1
  40b2c2:	vmulsd xmm0,xmm0,xmm6
  40b2c6:	vcvttsd2si rdx,xmm0
  40b2cb:	mov    r11b,dl
  40b2ce:	add    r11b,0x30
  40b2d2:	mov    BYTE PTR [r9+0xf],r11b
  40b2d6:	lea    r10,[r10+0x2]
  40b2da:	lea    r10,[r10+0x2]
  40b2de:	lea    r10,[r10+0x2]
  40b2e2:	lea    r10,[r10+0x2]
  40b2e6:	lea    r10,[r10+0x2]
  40b2ea:	vxorpd xmm1,xmm1,xmm1
  40b2ee:	movzx  edx,dl
  40b2f1:	vcvtsi2sd xmm1,xmm1,rdx
  40b2f6:	vsubsd xmm0,xmm0,xmm1
  40b2fa:	vmulsd xmm0,xmm0,xmm6
  40b2fe:	vcvttsd2si rdx,xmm0
  40b303:	mov    r11b,dl
  40b306:	add    r11b,0x30
  40b30a:	mov    BYTE PTR [r9+0x10],r11b
  40b30e:	vxorpd xmm1,xmm1,xmm1
  40b312:	movzx  edx,dl
  40b315:	vcvtsi2sd xmm1,xmm1,rdx
  40b31a:	vsubsd xmm0,xmm0,xmm1
  40b31e:	vmulsd xmm0,xmm0,xmm6
  40b322:	vcvttsd2si rdx,xmm0
  40b327:	add    dl,0x30
  40b32a:	mov    BYTE PTR [r9+0x11],dl
  40b32e:	mov    BYTE PTR [r10+0x2],0x65
  40b333:	lea    r9,[r10+0x3]
  40b337:	test   r8,r8
  40b33a:	jl     40b343 <__swc_fn_7069e055_000150_6203dca2+0xd43>
  40b33c:	mov    BYTE PTR [r9],0x2b
  40b340:	inc    r9
  40b343:	mov    r10,r9
  40b346:	mov    rdx,r8
  40b349:	nop    DWORD PTR [rax+0x0]
  40b350:	mov    r11,rdx
  40b353:	movabs rdx,0x6666666666666667
  40b35d:	mov    rax,r11
  40b360:	imul   rdx
  40b363:	sar    rdx,0x2
  40b367:	mov    r12,rdx
  40b36a:	shr    rdx,0x3f
  40b36e:	add    r12,rdx
  40b371:	mov    rdx,r12
  40b374:	imul   r13,r12,0xa
  40b378:	sub    r11,r13
  40b37b:	mov    r13,QWORD PTR [rip+0x828e]        # 413610 <__swc_rdata_base_7069e055+0x500>
  40b382:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b387:	mov    BYTE PTR [r10],r11b
  40b38a:	lea    r11,[r10+0x1]
  40b38e:	mov    r10,r11
  40b391:	test   r12,r12
  40b394:	jne    40b350 <__swc_fn_7069e055_000150_6203dca2+0xd50>
  40b396:	test   r8,r8
  40b399:	jge    40b3a3 <__swc_fn_7069e055_000150_6203dca2+0xda3>
  40b39b:	mov    BYTE PTR [r11],0x2d
  40b39f:	lea    r10,[r11+0x1]
  40b3a3:	mov    BYTE PTR [r10],0x0
  40b3a7:	sub    r10,0x1
  40b3ab:	nop    DWORD PTR [rax+rax*1+0x0]
  40b3b0:	cmp    r9,r10
  40b3b3:	jae    40b628 <__swc_fn_7069e055_000150_6203dca2+0x1028>
  40b3b9:	mov    al,BYTE PTR [r10]
  40b3bc:	mov    dl,BYTE PTR [r9]
  40b3bf:	mov    BYTE PTR [r10],dl
  40b3c2:	sub    r10,0x1
  40b3c6:	mov    BYTE PTR [r9],al
  40b3c9:	inc    r9
  40b3cc:	jmp    40b3b0 <__swc_fn_7069e055_000150_6203dca2+0xdb0>
  40b3ce:	vcvttsd2si rdx,xmm0
  40b3d3:	mov    r8,rdx
  40b3d6:	vxorpd xmm1,xmm1,xmm1
  40b3da:	vcvtsi2sd xmm1,xmm1,rdx
  40b3df:	vsubsd xmm1,xmm0,xmm1
  40b3e3:	mov    r9d,0x8
  40b3e9:	vxorpd xmm2,xmm2,xmm2
  40b3ed:	vcomisd xmm2,xmm1
  40b3f1:	ja     40b3fe <__swc_fn_7069e055_000150_6203dca2+0xdfe>
  40b3f3:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40b3fc:	jmp    40b40f <__swc_fn_7069e055_000150_6203dca2+0xe0f>
  40b3fe:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x821a]        # 413620 <__swc_rdata_base_7069e055+0x510>
  40b406:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40b40f:	test   r9d,r9d
  40b412:	je     40b429 <__swc_fn_7069e055_000150_6203dca2+0xe29>
  40b414:	cs nop WORD PTR [rax+rax*1+0x0]
  40b41e:	xchg   ax,ax
  40b420:	vmulsd xmm1,xmm1,xmm6
  40b424:	dec    r9d
  40b427:	jne    40b420 <__swc_fn_7069e055_000150_6203dca2+0xe20>
  40b429:	vcvttsd2si r9,xmm1
  40b42e:	mov    r10,r9
  40b431:	vxorpd xmm2,xmm2,xmm2
  40b435:	vcvtsi2sd xmm2,xmm2,r9
  40b43a:	vsubsd xmm1,xmm1,xmm2
  40b43e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  40b447:	vcomisd xmm1,xmm6
  40b44b:	lea    r9,[r9+0x1]
  40b44f:	cmova  r10,r9
  40b453:	cmp    r10,0x5f5e100
  40b45a:	jne    40b473 <__swc_fn_7069e055_000150_6203dca2+0xe73>
  40b45c:	lea    r8,[rdx-0x1]
  40b460:	vxorpd xmm1,xmm1,xmm1
  40b464:	vcomisd xmm1,xmm0
  40b468:	lea    rdx,[rdx+0x1]
  40b46c:	cmovbe r8,rdx
  40b470:	xor    r10d,r10d
  40b473:	mov    r9,rcx
  40b476:	test   r8,r8
  40b479:	jne    40b499 <__swc_fn_7069e055_000150_6203dca2+0xe99>
  40b47b:	vxorpd xmm1,xmm1,xmm1
  40b47f:	vcomisd xmm1,xmm0
  40b483:	jbe    40b48c <__swc_fn_7069e055_000150_6203dca2+0xe8c>
  40b485:	mov    BYTE PTR [rcx],0x2d
  40b488:	lea    r9,[rcx+0x1]
  40b48c:	mov    BYTE PTR [r9],0x30
  40b490:	add    r9,0x1
  40b494:	jmp    40b52b <__swc_fn_7069e055_000150_6203dca2+0xf2b>
  40b499:	mov    r9,rcx
  40b49c:	mov    rdx,r8
  40b49f:	nop
  40b4a0:	mov    r11,rdx
  40b4a3:	movabs rdx,0x6666666666666667
  40b4ad:	mov    r15,rax
  40b4b0:	mov    rax,r11
  40b4b3:	imul   rdx
  40b4b6:	mov    r12,rdx
  40b4b9:	mov    rax,r15
  40b4bc:	sar    r12,0x2
  40b4c0:	mov    rdx,r12
  40b4c3:	shr    rdx,0x3f
  40b4c7:	add    r12,rdx
  40b4ca:	mov    rdx,r12
  40b4cd:	imul   r13,r12,0xa
  40b4d1:	sub    r11,r13
  40b4d4:	mov    r13,QWORD PTR [rip+0x8135]        # 413610 <__swc_rdata_base_7069e055+0x500>
  40b4db:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b4e0:	mov    BYTE PTR [r9],r11b
  40b4e3:	lea    r11,[r9+0x1]
  40b4e7:	mov    r9,r11
  40b4ea:	test   r12,r12
  40b4ed:	jne    40b4a0 <__swc_fn_7069e055_000150_6203dca2+0xea0>
  40b4ef:	test   r8,r8
  40b4f2:	jge    40b4fc <__swc_fn_7069e055_000150_6203dca2+0xefc>
  40b4f4:	mov    BYTE PTR [r11],0x2d
  40b4f8:	lea    r9,[r11+0x1]
  40b4fc:	mov    rdx,r9
  40b4ff:	mov    BYTE PTR [r9],0x0
  40b503:	sub    r9,0x1
  40b507:	mov    r8,rcx
  40b50a:	cmp    r8,r9
  40b50d:	jae    40b528 <__swc_fn_7069e055_000150_6203dca2+0xf28>
  40b50f:	nop
  40b510:	mov    r11b,BYTE PTR [r9]
  40b513:	mov    r12b,BYTE PTR [r8]
  40b516:	mov    BYTE PTR [r9],r12b
  40b519:	sub    r9,0x1
  40b51d:	mov    BYTE PTR [r8],r11b
  40b520:	inc    r8
  40b523:	cmp    r8,r9
  40b526:	jb     40b510 <__swc_fn_7069e055_000150_6203dca2+0xf10>
  40b528:	mov    r9,rdx
  40b52b:	mov    BYTE PTR [r9],0x2e
  40b52f:	add    r9,0x1
  40b533:	xor    r8d,r8d
  40b536:	test   r10,r10
  40b539:	je     40b57f <__swc_fn_7069e055_000150_6203dca2+0xf7f>
  40b53b:	mov    r11d,0x989680
  40b541:	cmp    r10,r11
  40b544:	jge    40b57f <__swc_fn_7069e055_000150_6203dca2+0xf7f>
  40b546:	cs nop WORD PTR [rax+rax*1+0x0]
  40b550:	inc    r8d
  40b553:	movabs rdx,0x6666666666666667
  40b55d:	mov    r15,rax
  40b560:	mov    rax,r11
  40b563:	imul   rdx
  40b566:	mov    r11,rdx
  40b569:	mov    rax,r15
  40b56c:	sar    r11,0x2
  40b570:	mov    rdx,r11
  40b573:	shr    rdx,0x3f
  40b577:	add    r11,rdx
  40b57a:	cmp    r10,r11
  40b57d:	jl     40b550 <__swc_fn_7069e055_000150_6203dca2+0xf50>
  40b57f:	test   r8d,r8d
  40b582:	je     40b59d <__swc_fn_7069e055_000150_6203dca2+0xf9d>
  40b584:	cs nop WORD PTR [rax+rax*1+0x0]
  40b58e:	xchg   ax,ax
  40b590:	mov    BYTE PTR [r9],0x30
  40b594:	add    r9,0x1
  40b598:	dec    r8d
  40b59b:	jne    40b590 <__swc_fn_7069e055_000150_6203dca2+0xf90>
  40b59d:	mov    r8,r9
  40b5a0:	mov    rdx,r10
  40b5a3:	cs nop WORD PTR [rax+rax*1+0x0]
  40b5ad:	nop    DWORD PTR [rax]
  40b5b0:	mov    r11,rdx
  40b5b3:	movabs rdx,0x6666666666666667
  40b5bd:	mov    rax,r11
  40b5c0:	imul   rdx
  40b5c3:	sar    rdx,0x2
  40b5c7:	mov    r12,rdx
  40b5ca:	shr    rdx,0x3f
  40b5ce:	add    r12,rdx
  40b5d1:	mov    rdx,r12
  40b5d4:	imul   r13,r12,0xa
  40b5d8:	sub    r11,r13
  40b5db:	mov    r13,QWORD PTR [rip+0x802e]        # 413610 <__swc_rdata_base_7069e055+0x500>
  40b5e2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b5e7:	mov    BYTE PTR [r8],r11b
  40b5ea:	lea    r11,[r8+0x1]
  40b5ee:	mov    r8,r11
  40b5f1:	test   r12,r12
  40b5f4:	jne    40b5b0 <__swc_fn_7069e055_000150_6203dca2+0xfb0>
  40b5f6:	test   r10,r10
  40b5f9:	jge    40b603 <__swc_fn_7069e055_000150_6203dca2+0x1003>
  40b5fb:	mov    BYTE PTR [r11],0x2d
  40b5ff:	lea    r8,[r11+0x1]
  40b603:	mov    BYTE PTR [r8],0x0
  40b607:	sub    r8,0x1
  40b60b:	cmp    r9,r8
  40b60e:	jae    40b628 <__swc_fn_7069e055_000150_6203dca2+0x1028>
  40b610:	mov    al,BYTE PTR [r8]
  40b613:	mov    dl,BYTE PTR [r9]
  40b616:	mov    BYTE PTR [r8],dl
  40b619:	sub    r8,0x1
  40b61d:	mov    BYTE PTR [r9],al
  40b620:	inc    r9
  40b623:	cmp    r9,r8
  40b626:	jb     40b610 <__swc_fn_7069e055_000150_6203dca2+0x1010>
  40b628:	xor    eax,eax
  40b62a:	test   rcx,rcx
  40b62d:	je     40b650 <__swc_fn_7069e055_000150_6203dca2+0x1050>
  40b62f:	mov    rdx,rcx
  40b632:	mov    r8b,BYTE PTR [rdx]
  40b635:	test   r8b,r8b
  40b638:	je     40b650 <__swc_fn_7069e055_000150_6203dca2+0x1050>
  40b63a:	nop    WORD PTR [rax+rax*1+0x0]
  40b640:	add    rdx,0x1
  40b644:	add    rax,0x1
  40b648:	mov    r8b,BYTE PTR [rdx]
  40b64b:	test   r8b,r8b
  40b64e:	jne    40b640 <__swc_fn_7069e055_000150_6203dca2+0x1040>
  40b650:	mov    QWORD PTR [rsp+0x3f8],rcx
  40b658:	mov    QWORD PTR [rsp+0x400],rax
  40b660:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  40b669:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  40b672:	lea    rcx,[rsp+0x408]
  40b67a:	call   409d90 <__swc_fn_7069e055_000120_2648f149>
  40b67f:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40b681:	mov    rcx,rdx
  40b684:	call   409d90 <__swc_fn_7069e055_000120_2648f149>
  40b689:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40b68b:	mov    al,BYTE PTR [rdx]
  40b68d:	test   al,al
  40b68f:	je     40b69a <__swc_fn_7069e055_000150_6203dca2+0x109a>
  40b691:	lea    rax,[rip+0x7f98]        # 413630 <__swc_rdata_base_7069e055+0x520>
  40b698:	jmp    40b6a1 <__swc_fn_7069e055_000150_6203dca2+0x10a1>
  40b69a:	lea    rax,[rip+0x7f9f]        # 413640 <__swc_rdata_base_7069e055+0x530>
  40b6a1:	mov    rcx,rax
  40b6a4:	call   409d90 <__swc_fn_7069e055_000120_2648f149>
  40b6a9:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40b6ab:	lea    rcx,[rip+0x7f9e]        # 413650 <__swc_rdata_base_7069e055+0x540>
  40b6b2:	call   409d90 <__swc_fn_7069e055_000120_2648f149>
  40b6b7:	jmp    40b6c5 <__swc_fn_7069e055_000150_6203dca2+0x10c5>
  40b6b9:	lea    rcx,[rip+0x7f90]        # 413650 <__swc_rdata_base_7069e055+0x540>
  40b6c0:	call   409d90 <__swc_fn_7069e055_000120_2648f149>
  40b6c5:	add    rdi,0x1
  40b6c9:	sub    rsi,0x1
  40b6cd:	vmovups xmm0,xmm12
  40b6d2:	vmovsd xmm6,QWORD PTR [rip+0x7f86]        # 413660 <__swc_rdata_base_7069e055+0x550>
  40b6da:	test   rsi,rsi
  40b6dd:	jne    40a710 <__swc_fn_7069e055_000150_6203dca2+0x110>
  40b6e3:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  40b6ec:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  40b6f5:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  40b6fe:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  40b707:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  40b710:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  40b719:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  40b722:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  40b72b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  40b734:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  40b73d:	add    rsp,0x4e8
  40b744:	pop    r15
  40b746:	pop    r13
  40b748:	pop    r12
  40b74a:	pop    rdi
  40b74b:	pop    rsi
  40b74c:	pop    rbx
  40b74d:	ret
	...

000000000040b750 <__swc_fn_7069e055_000153_86f1d437>:
  40b750:	vxorps xmm0,xmm0,xmm0
  40b754:	vmovups XMMWORD PTR [rcx],xmm0
  40b758:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b75d:	ret
	...

000000000040b760 <__swc_fn_7069e055_000156_86f1d437>:
  40b760:	vxorps xmm0,xmm0,xmm0
  40b764:	vmovups XMMWORD PTR [rcx],xmm0
  40b768:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b76d:	vxorps xmm0,xmm0,xmm0
  40b771:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b776:	vmovups xmm0,XMMWORD PTR [rip+0x7ff2]        # 413770 <__swc_rdata_base_7069e055+0x660>
  40b77e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b783:	vxorps xmm0,xmm0,xmm0
  40b787:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b78c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40b791:	vxorps xmm0,xmm0,xmm0
  40b795:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40b79a:	mov    QWORD PTR [rcx+0x70],0x0
  40b7a2:	ret
	...

000000000040b7b0 <__swc_fn_7069e055_000159_86f1d437>:
  40b7b0:	vxorps xmm0,xmm0,xmm0
  40b7b4:	vmovups XMMWORD PTR [rcx],xmm0
  40b7b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b7bd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b7c2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b7c7:	ret
	...

000000000040b7d0 <__swc_fn_7069e055_000162_e36363a8>:
  40b7d0:	push   rsi
  40b7d1:	push   rdi
  40b7d2:	sub    rsp,0x8
  40b7d6:	mov    rsi,rcx
  40b7d9:	mov    rdi,QWORD PTR [rsi+0x50]
  40b7dd:	test   rdi,rdi
  40b7e0:	je     40b7e7 <__swc_fn_7069e055_000162_e36363a8+0x17>
  40b7e2:	mov    rcx,rsi
  40b7e5:	call   rdi
  40b7e7:	mov    QWORD PTR [rsi+0x20],0x0
  40b7ef:	mov    rax,QWORD PTR [rsi+0x30]
  40b7f3:	test   rax,rax
  40b7f6:	je     40b824 <__swc_fn_7069e055_000162_e36363a8+0x54>
  40b7f8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b800:	mov    rdi,QWORD PTR [rax+0x8]
  40b804:	mov    rcx,rsi
  40b807:	mov    rdx,QWORD PTR [rax+0x10]
  40b80b:	mov    rax,QWORD PTR [rax+0x18]
  40b80f:	mov    r8,rax
  40b812:	call   40e970 <__swc_fn_7069e055_000160_47b270e1>
  40b817:	mov    QWORD PTR [rsi+0x30],rdi
  40b81b:	mov    rax,QWORD PTR [rsi+0x30]
  40b81f:	test   rax,rax
  40b822:	jne    40b800 <__swc_fn_7069e055_000162_e36363a8+0x30>
  40b824:	mov    QWORD PTR [rsi+0x38],0x0
  40b82c:	add    rsp,0x8
  40b830:	pop    rdi
  40b831:	pop    rsi
  40b832:	ret
	...

000000000040b840 <__swc_fn_7069e055_000165_016ee66a>:
  40b840:	push   rbx
  40b841:	push   rsi
  40b842:	push   rdi
  40b843:	push   r12
  40b845:	sub    rsp,0x188
  40b84c:	mov    rbx,rcx
  40b84f:	lea    rsi,[rip+0x1b532]        # 426d88 <__swc_bss_base_7069e055+0x2d48>
  40b856:	mov    rcx,rsi
  40b859:	call   40e380 <__swc_fn_7069e055_000139_86bb0f90>
  40b85e:	mov    rax,QWORD PTR [rip+0x1b52b]        # 426d90 <__swc_bss_base_7069e055+0x2d50>
  40b865:	mov    rdi,rax
  40b868:	test   rdi,rdi
  40b86b:	je     40b899 <__swc_fn_7069e055_000165_016ee66a+0x59>
  40b86d:	nop    DWORD PTR [rax]
  40b870:	cmp    QWORD PTR [rdi+0x8],rbx
  40b874:	jne    40b88e <__swc_fn_7069e055_000165_016ee66a+0x4e>
  40b876:	mov    rcx,rsi
  40b879:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40b87e:	mov    rax,rdi
  40b881:	add    rsp,0x188
  40b888:	pop    r12
  40b88a:	pop    rdi
  40b88b:	pop    rsi
  40b88c:	pop    rbx
  40b88d:	ret
  40b88e:	mov    rax,QWORD PTR [rdi]
  40b891:	mov    rdi,rax
  40b894:	test   rax,rax
  40b897:	jne    40b870 <__swc_fn_7069e055_000165_016ee66a+0x30>
  40b899:	call   411960 <__swc_fn_7069e055_000143_d299b428>
  40b89e:	mov    rdi,rax
  40b8a1:	test   rax,rax
  40b8a4:	jne    40b8bd <__swc_fn_7069e055_000165_016ee66a+0x7d>
  40b8a6:	mov    rcx,rsi
  40b8a9:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40b8ae:	xor    eax,eax
  40b8b0:	add    rsp,0x188
  40b8b7:	pop    r12
  40b8b9:	pop    rdi
  40b8ba:	pop    rsi
  40b8bb:	pop    rbx
  40b8bc:	ret
  40b8bd:	lea    rax,[rsp+0x18]
  40b8c2:	mov    QWORD PTR [rax+0x10],0x0
  40b8ca:	mov    QWORD PTR [rax+0x18],0x0
  40b8d2:	mov    DWORD PTR [rax+0x20],0x0
  40b8d9:	mov    BYTE PTR [rax+0x24],0x0
  40b8dd:	mov    rax,QWORD PTR [rip+0x1b4ac]        # 426d90 <__swc_bss_base_7069e055+0x2d50>
  40b8e4:	mov    QWORD PTR [rsp+0x18],rax
  40b8e9:	mov    QWORD PTR [rsp+0x20],rbx
  40b8ee:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40b8f4:	vmovups XMMWORD PTR [rdi],xmm0
  40b8f8:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40b8fe:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  40b903:	mov    rax,QWORD PTR [rsp+0x38]
  40b908:	mov    QWORD PTR [rdi+0x20],rax
  40b90c:	mov    QWORD PTR [rip+0x1b47d],rdi        # 426d90 <__swc_bss_base_7069e055+0x2d50>
  40b913:	lea    rax,[rsp+0x40]
  40b918:	mov    QWORD PTR [rax],0x0
  40b91f:	mov    rcx,rbx
  40b922:	mov    rdx,rax
  40b925:	call   40e460 <__swc_fn_7069e055_000145_1534de9a>
  40b92a:	mov    rbx,rax
  40b92d:	test   rax,rax
  40b930:	jne    40b94a <__swc_fn_7069e055_000165_016ee66a+0x10a>
  40b932:	mov    rcx,rsi
  40b935:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40b93a:	mov    rax,rdi
  40b93d:	add    rsp,0x188
  40b944:	pop    r12
  40b946:	pop    rdi
  40b947:	pop    rsi
  40b948:	pop    rbx
  40b949:	ret
  40b94a:	lea    r12,[rsp+0x50]
  40b94f:	mov    QWORD PTR [r12],0x0
  40b957:	mov    rcx,rbx
  40b95a:	mov    rdx,QWORD PTR [rsp+0x40]
  40b95f:	mov    r8,r12
  40b962:	call   411a10 <__swc_fn_7069e055_000146_162f363d>
  40b967:	test   rax,rax
  40b96a:	jne    40b984 <__swc_fn_7069e055_000165_016ee66a+0x144>
  40b96c:	mov    rcx,rsi
  40b96f:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40b974:	mov    rax,rdi
  40b977:	add    rsp,0x188
  40b97e:	pop    r12
  40b980:	pop    rdi
  40b981:	pop    rsi
  40b982:	pop    rbx
  40b983:	ret
  40b984:	cmp    QWORD PTR [r12],0x10
  40b989:	jb     40ba8c <__swc_fn_7069e055_000165_016ee66a+0x24c>
  40b98f:	mov    ecx,DWORD PTR [rax]
  40b991:	cmp    ecx,0x42445753
  40b997:	jne    40ba8c <__swc_fn_7069e055_000165_016ee66a+0x24c>
  40b99d:	mov    ecx,DWORD PTR [rax+0x4]
  40b9a0:	cmp    ecx,0x1
  40b9a3:	jne    40ba8c <__swc_fn_7069e055_000165_016ee66a+0x24c>
  40b9a9:	mov    ecx,DWORD PTR [rax+0x8]
  40b9ac:	mov    edx,DWORD PTR [rax+0xc]
  40b9af:	imul   r8,rcx,0x14
  40b9b3:	mov    r9,QWORD PTR [rsp+0x50]
  40b9b8:	sub    r9,0x10
  40b9bc:	cmp    r8,r9
  40b9bf:	ja     40ba8c <__swc_fn_7069e055_000165_016ee66a+0x24c>
  40b9c5:	lea    r8,[r8+0x10]
  40b9c9:	cmp    rdx,r8
  40b9cc:	jb     40ba8c <__swc_fn_7069e055_000165_016ee66a+0x24c>
  40b9d2:	mov    r8,QWORD PTR [rsp+0x50]
  40b9d7:	cmp    rdx,r8
  40b9da:	ja     40ba8c <__swc_fn_7069e055_000165_016ee66a+0x24c>
  40b9e0:	xor    r8d,r8d
  40b9e3:	test   rcx,rcx
  40b9e6:	jbe    40bab2 <__swc_fn_7069e055_000165_016ee66a+0x272>
  40b9ec:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  40b9f2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b9fc:	nop    DWORD PTR [rax+0x0]
  40ba00:	imul   r9,r8,0x14
  40ba04:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  40ba09:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  40ba0e:	add    r10,r11
  40ba11:	movabs r11,0x100000000
  40ba1b:	cmp    r10,r11
  40ba1e:	ja     40ba8c <__swc_fn_7069e055_000165_016ee66a+0x24c>
  40ba20:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  40ba25:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  40ba2a:	test   r10d,r10d
  40ba2d:	setne  r11b
  40ba31:	je     40ba4b <__swc_fn_7069e055_000165_016ee66a+0x20b>
  40ba33:	cmp    r10d,edx
  40ba36:	setb   r11b
  40ba3a:	jb     40ba4b <__swc_fn_7069e055_000165_016ee66a+0x20b>
  40ba3c:	vmovq  r11,xmm1
  40ba41:	cmp    r10,r11
  40ba44:	setae  r10b
  40ba48:	mov    r11b,r10b
  40ba4b:	mov    r10,r11
  40ba4e:	test   r11b,r11b
  40ba51:	jne    40ba78 <__swc_fn_7069e055_000165_016ee66a+0x238>
  40ba53:	test   r9d,r9d
  40ba56:	setne  r10b
  40ba5a:	je     40ba78 <__swc_fn_7069e055_000165_016ee66a+0x238>
  40ba5c:	cmp    r9d,edx
  40ba5f:	setb   r10b
  40ba63:	jb     40ba78 <__swc_fn_7069e055_000165_016ee66a+0x238>
  40ba65:	vmovq  r10,xmm1
  40ba6a:	cmp    r9,r10
  40ba6d:	setae  r9b
  40ba71:	movzx  r9d,r9b
  40ba75:	mov    r10b,r9b
  40ba78:	test   r10b,r10b
  40ba7b:	jne    40ba8c <__swc_fn_7069e055_000165_016ee66a+0x24c>
  40ba7d:	add    r8,0x1
  40ba81:	cmp    r8,rcx
  40ba84:	jb     40ba00 <__swc_fn_7069e055_000165_016ee66a+0x1c0>
  40ba8a:	jmp    40bab2 <__swc_fn_7069e055_000165_016ee66a+0x272>
  40ba8c:	xor    ecx,ecx
  40ba8e:	cmp    rax,rbx
  40ba91:	cmovne rcx,rax
  40ba95:	call   40a550 <__swc_fn_7069e055_000147_d7edc04f>
  40ba9a:	mov    rcx,rsi
  40ba9d:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40baa2:	mov    rax,rdi
  40baa5:	add    rsp,0x188
  40baac:	pop    r12
  40baae:	pop    rdi
  40baaf:	pop    rsi
  40bab0:	pop    rbx
  40bab1:	ret
  40bab2:	mov    QWORD PTR [rdi+0x10],rax
  40bab6:	mov    rcx,QWORD PTR [rsp+0x50]
  40babb:	mov    QWORD PTR [rdi+0x18],rcx
  40babf:	mov    eax,DWORD PTR [rax+0x8]
  40bac2:	mov    DWORD PTR [rdi+0x20],eax
  40bac5:	rex mov BYTE PTR [rdi+0x24],0x1
  40baca:	mov    rcx,rsi
  40bacd:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40bad2:	mov    rax,rdi
  40bad5:	add    rsp,0x188
  40badc:	pop    r12
  40bade:	pop    rdi
  40badf:	pop    rsi
  40bae0:	pop    rbx
  40bae1:	ret
	...

000000000040baf0 <__swc_fn_7069e055_000168_3459066f>:
  40baf0:	push   rsi
  40baf1:	push   rdi
  40baf2:	push   r12
  40baf4:	mov    rsi,rdx
  40baf7:	mov    rdi,rcx
  40bafa:	mov    rcx,QWORD PTR [rip+0x1853f]        # 424040 <__swc_bss_base_7069e055>
  40bb01:	test   rcx,rcx
  40bb04:	jne    40bb16 <__swc_fn_7069e055_000168_3459066f+0x26>
  40bb06:	call   40ec80 <__swc_fn_7069e055_000169_994c8876>
  40bb0b:	lea    rcx,[rax+0x1]
  40bb0f:	mov    QWORD PTR [rip+0x1852a],rcx        # 424040 <__swc_bss_base_7069e055>
  40bb16:	dec    rcx
  40bb19:	call   40bb40 <__swc_fn_7069e055_000171_360af05d>
  40bb1e:	mov    r12,QWORD PTR [rax+0xbe0]
  40bb25:	test   r12,r12
  40bb28:	setne  al
  40bb2b:	je     40bb36 <__swc_fn_7069e055_000168_3459066f+0x46>
  40bb2d:	mov    rcx,rdi
  40bb30:	mov    rdx,rsi
  40bb33:	call   r12
  40bb36:	pop    r12
  40bb38:	pop    rdi
  40bb39:	pop    rsi
  40bb3a:	ret
  40bb3b:	add    BYTE PTR [rax],al
  40bb3d:	add    BYTE PTR [rax],al
	...

000000000040bb40 <__swc_fn_7069e055_000171_360af05d>:
  40bb40:	push   r12
  40bb42:	push   rdi
  40bb43:	push   rsi
  40bb44:	sub    rsp,0xd0
  40bb4b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40bb51:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40bb57:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40bb5d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40bb63:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40bb69:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40bb6f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40bb78:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40bb81:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40bb8a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40bb93:	mov    r12,rcx
  40bb96:	mov    edi,ecx
  40bb98:	xor    eax,eax
  40bb9a:	call   407000 <pthread_getspecific@plt>
  40bb9f:	test   rax,rax
  40bba2:	je     40bba6 <__swc_fn_7069e055_000171_360af05d+0x66>
  40bba4:	jmp    40bbae <__swc_fn_7069e055_000171_360af05d+0x6e>
  40bba6:	mov    rcx,r12
  40bba9:	call   40ece0 <__swc_fn_7069e055_000172_cbeff767>
  40bbae:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40bbb4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40bbba:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40bbc0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40bbc6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40bbcc:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40bbd2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40bbdb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40bbe4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40bbed:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40bbf6:	add    rsp,0xd0
  40bbfd:	pop    rsi
  40bbfe:	pop    rdi
  40bbff:	pop    r12
  40bc01:	ret
	...

000000000040bc10 <__swc_fn_7069e055_000174_5eac0ab4>:
  40bc10:	push   rsi
  40bc11:	sub    rsp,0x30
  40bc15:	lea    rsi,[rip+0x1b184]        # 426da0 <__swc_bss_base_7069e055+0x2d60>
  40bc1c:	mov    rax,QWORD PTR [rsi]
  40bc1f:	test   rax,rax
  40bc22:	je     40bc2a <__swc_fn_7069e055_000174_5eac0ab4+0x1a>
  40bc24:	add    rsp,0x30
  40bc28:	pop    rsi
  40bc29:	ret
  40bc2a:	mov    ecx,0x3
  40bc2f:	mov    edx,0x10
  40bc34:	call   4096b0 <__swc_fn_7069e055_000111_6814119b>
  40bc39:	test   rax,rax
  40bc3c:	jne    40bc4d <__swc_fn_7069e055_000174_5eac0ab4+0x3d>
  40bc3e:	mov    QWORD PTR [rsp+0x18],rax
  40bc43:	call   4114b0 <__swc_fn_7069e055_000122_be2e2f68>
  40bc48:	mov    rax,QWORD PTR [rsp+0x18]
  40bc4d:	mov    rcx,rax
  40bc50:	xchg   QWORD PTR [rsi],rcx
  40bc53:	add    rsp,0x30
  40bc57:	pop    rsi
  40bc58:	ret
  40bc59:	add    BYTE PTR [rax],al
  40bc5b:	add    BYTE PTR [rax],al
  40bc5d:	add    BYTE PTR [rax],al
	...

000000000040bc60 <__swc_fn_7069e055_000177_cf4ffedd>:
  40bc60:	push   rsi
  40bc61:	push   rdi
  40bc62:	sub    rsp,0x8
  40bc66:	mov    rsi,rdx
  40bc69:	mov    rdi,rcx
  40bc6c:	mov    rax,QWORD PTR [rsi+0x8]
  40bc70:	test   rax,rax
  40bc73:	je     40bc7d <__swc_fn_7069e055_000177_cf4ffedd+0x1d>
  40bc75:	mov    rcx,QWORD PTR [rsi]
  40bc78:	mov    QWORD PTR [rax],rcx
  40bc7b:	jmp    40bc84 <__swc_fn_7069e055_000177_cf4ffedd+0x24>
  40bc7d:	mov    rax,QWORD PTR [rsi]
  40bc80:	mov    QWORD PTR [rdi+0x8],rax
  40bc84:	mov    rax,QWORD PTR [rsi]
  40bc87:	test   rax,rax
  40bc8a:	je     40bc94 <__swc_fn_7069e055_000177_cf4ffedd+0x34>
  40bc8c:	mov    rcx,QWORD PTR [rsi+0x8]
  40bc90:	mov    QWORD PTR [rax+0x8],rcx
  40bc94:	mov    rcx,rdi
  40bc97:	mov    rdx,QWORD PTR [rsi+0x10]
  40bc9b:	mov    r8,QWORD PTR [rsi+0x18]
  40bc9f:	mov    r9,0xffffffffffffffff
  40bca6:	call   412060 <__swc_fn_7069e055_000176_4de704de>
  40bcab:	mov    QWORD PTR [rsi+0x18],0x0
  40bcb3:	mov    rax,QWORD PTR [rdi+0x8]
  40bcb7:	test   rax,rax
  40bcba:	jne    40bccc <__swc_fn_7069e055_000177_cf4ffedd+0x6c>
  40bcbc:	call   40bc10 <__swc_fn_7069e055_000174_5eac0ab4>
  40bcc1:	xor    ecx,ecx
  40bcc3:	mov    QWORD PTR [rax+0x8],rcx
  40bcc7:	xor    ecx,ecx
  40bcc9:	mov    QWORD PTR [rax],rcx
  40bccc:	add    rsp,0x8
  40bcd0:	pop    rdi
  40bcd1:	pop    rsi
  40bcd2:	ret
	...

000000000040bce0 <__swc_fn_7069e055_000001_5d3d19bd>:
  40bce0:	push   rbx
  40bce1:	sub    rsp,0x70
  40bce5:	test   rcx,rcx
  40bce8:	jne    40bcf0 <__swc_fn_7069e055_000001_5d3d19bd+0x10>
  40bcea:	add    rsp,0x70
  40bcee:	pop    rbx
  40bcef:	ret
  40bcf0:	vxorps xmm0,xmm0,xmm0
  40bcf4:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40bcfa:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40bd00:	vzeroupper
  40bd03:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40bd09:	lea    rax,[rcx-0x10]
  40bd0d:	mov    QWORD PTR [rsp+0x48],rax
  40bd12:	mov    rax,QWORD PTR [rcx-0x10]
  40bd16:	mov    QWORD PTR [rsp+0x50],rax
  40bd1b:	mov    rcx,QWORD PTR [rip+0x1831e]        # 424040 <__swc_bss_base_7069e055>
  40bd22:	test   rcx,rcx
  40bd25:	jne    40bd37 <__swc_fn_7069e055_000001_5d3d19bd+0x57>
  40bd27:	call   40ec80 <__swc_fn_7069e055_000169_994c8876>
  40bd2c:	lea    rcx,[rax+0x1]
  40bd30:	mov    QWORD PTR [rip+0x18309],rcx        # 424040 <__swc_bss_base_7069e055>
  40bd37:	dec    rcx
  40bd3a:	call   40bb40 <__swc_fn_7069e055_000171_360af05d>
  40bd3f:	mov    rcx,QWORD PTR [rax]
  40bd42:	lea    rdx,[rsp+0x8]
  40bd47:	mov    rbx,QWORD PTR [rax+0x8]
  40bd4b:	mov    rbx,QWORD PTR [rbx+0x18]
  40bd4f:	call   rbx
  40bd51:	add    rsp,0x70
  40bd55:	pop    rbx
  40bd56:	ret
	...

000000000040bd60 <__swc_fn_7069e055_000004_9ee35b18>:
  40bd60:	vxorps xmm0,xmm0,xmm0
  40bd64:	vmovups XMMWORD PTR [rcx],xmm0
  40bd68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40bd6d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40bd72:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40bd77:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40bd7c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40bd81:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40bd86:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40bd8b:	ret
  40bd8c:	add    BYTE PTR [rax],al
	...

000000000040bd90 <__swc_fn_7069e055_000007_f7acedb0>:
  40bd90:	push   rsi
  40bd91:	mov    rsi,rdx
  40bd94:	test   rdx,rdx
  40bd97:	jne    40bda0 <__swc_fn_7069e055_000007_f7acedb0+0x10>
  40bd99:	mov    eax,0x1
  40bd9e:	pop    rsi
  40bd9f:	ret
  40bda0:	mov    rdx,rsi
  40bda3:	call   40dd20 <__swc_fn_7069e055_000115_36905703>
  40bda8:	test   al,al
  40bdaa:	jne    40bdb0 <__swc_fn_7069e055_000007_f7acedb0+0x20>
  40bdac:	xor    eax,eax
  40bdae:	pop    rsi
  40bdaf:	ret
  40bdb0:	lea    rcx,[rip+0x182c1]        # 424078 <__swc_bss_base_7069e055+0x38>
  40bdb7:	mov    rdx,QWORD PTR [rip+0x182ba]        # 424078 <__swc_bss_base_7069e055+0x38>
  40bdbe:	xchg   ax,ax
  40bdc0:	lea    r8,[rdx+rsi*1]
  40bdc4:	mov    rax,rdx
  40bdc7:	lock cmpxchg QWORD PTR [rcx],r8
  40bdcc:	cmp    rax,rdx
  40bdcf:	je     40bdd6 <__swc_fn_7069e055_000007_f7acedb0+0x46>
  40bdd1:	mov    rdx,rax
  40bdd4:	jmp    40bdc0 <__swc_fn_7069e055_000007_f7acedb0+0x30>
  40bdd6:	lea    rcx,[rip+0x182a3]        # 424080 <__swc_bss_base_7069e055+0x40>
  40bddd:	mov    rdx,QWORD PTR [rip+0x1829c]        # 424080 <__swc_bss_base_7069e055+0x40>
  40bde4:	cs nop WORD PTR [rax+rax*1+0x0]
  40bdee:	xchg   ax,ax
  40bdf0:	lea    r8,[rdx+0x1]
  40bdf4:	mov    rax,rdx
  40bdf7:	lock cmpxchg QWORD PTR [rcx],r8
  40bdfc:	cmp    rax,rdx
  40bdff:	je     40be06 <__swc_fn_7069e055_000007_f7acedb0+0x76>
  40be01:	mov    rdx,rax
  40be04:	jmp    40bdf0 <__swc_fn_7069e055_000007_f7acedb0+0x60>
  40be06:	mov    eax,0x1
  40be0b:	pop    rsi
  40be0c:	ret
  40be0d:	add    BYTE PTR [rax],al
	...

000000000040be10 <__swc_fn_7069e055_000010_24a20786>:
  40be10:	push   rbx
  40be11:	push   rsi
  40be12:	push   rdi
  40be13:	push   r12
  40be15:	sub    rsp,0x18
  40be19:	mov    rbx,rcx
  40be1c:	mov    rsi,rcx
  40be1f:	and    rsi,0xffffffffffc00000
  40be26:	movzx  eax,BYTE PTR [rbx+0x3a]
  40be2a:	mov    ecx,DWORD PTR [rsi+0x28]
  40be2d:	shrx   eax,eax,ecx
  40be32:	lea    rdi,[rsp+0x8]
  40be37:	mov    DWORD PTR [rsp+0x8],eax
  40be3b:	mov    rcx,rsi
  40be3e:	mov    rax,rdi
  40be41:	mov    edx,DWORD PTR [rax]
  40be43:	call   407be0 <__swc_fn_7069e055_000015_9dea5065>
  40be48:	mov    r12,rax
  40be4b:	mov    rcx,rsi
  40be4e:	mov    edx,DWORD PTR [rdi]
  40be50:	call   40bf40 <__swc_fn_7069e055_000016_9afb7cfb>
  40be55:	mov    rcx,r12
  40be58:	mov    edx,DWORD PTR [rbx+0x3c]
  40be5b:	add    rcx,rdx
  40be5e:	cmp    rcx,rax
  40be61:	jb     40be6f <__swc_fn_7069e055_000010_24a20786+0x5f>
  40be63:	xor    eax,eax
  40be65:	add    rsp,0x18
  40be69:	pop    r12
  40be6b:	pop    rdi
  40be6c:	pop    rsi
  40be6d:	pop    rbx
  40be6e:	ret
  40be6f:	mov    rdx,QWORD PTR [rbx+0x20]
  40be73:	mov    r8d,DWORD PTR [rbx+0x2c]
  40be77:	add    rdx,r8
  40be7a:	lea    rsi,[rdx+0xffff]
  40be81:	and    rsi,0xffffffffffff0000
  40be88:	cmp    rax,rsi
  40be8b:	cmovbe rsi,rax
  40be8f:	mov    rax,rsi
  40be92:	sub    rax,rcx
  40be95:	mov    rdx,rax
  40be98:	call   40bd90 <__swc_fn_7069e055_000007_f7acedb0>
  40be9d:	test   al,al
  40be9f:	jne    40bead <__swc_fn_7069e055_000010_24a20786+0x9d>
  40bea1:	xor    eax,eax
  40bea3:	add    rsp,0x18
  40bea7:	pop    r12
  40bea9:	pop    rdi
  40beaa:	pop    rsi
  40beab:	pop    rbx
  40beac:	ret
  40bead:	sub    rsi,r12
  40beb0:	mov    DWORD PTR [rbx+0x3c],esi
  40beb3:	mov    ecx,DWORD PTR [rbx+0x2c]
  40beb6:	mov    rax,rsi
  40beb9:	xor    edx,edx
  40bebb:	div    rcx
  40bebe:	imul   rax,rcx
  40bec2:	add    r12,rax
  40bec5:	mov    QWORD PTR [rbx+0x18],r12
  40bec9:	mov    eax,0x1
  40bece:	add    rsp,0x18
  40bed2:	pop    r12
  40bed4:	pop    rdi
  40bed5:	pop    rsi
  40bed6:	pop    rbx
  40bed7:	ret
	...

000000000040bee0 <__swc_fn_7069e055_000013_e4b0ddfc>:
  40bee0:	sub    rsp,0x8
  40bee4:	mov    rdx,rcx
  40bee7:	lea    r9,[rcx+0x60]
  40beeb:	mov    rax,QWORD PTR [r9]
  40beee:	test   rax,rax
  40bef1:	jne    40bef8 <__swc_fn_7069e055_000013_e4b0ddfc+0x18>
  40bef3:	add    rsp,0x8
  40bef7:	ret
  40bef8:	mov    rcx,rdx
  40befb:	call   40f010 <__swc_fn_7069e055_000011_c3647f66>
  40bf00:	xor    eax,eax
  40bf02:	xchg   QWORD PTR [r9],rax
  40bf05:	mov    r8,rax
  40bf08:	mov    rcx,rdx
  40bf0b:	call   407bd0 <__swc_fn_7069e055_000012_861b8b62>
  40bf10:	xor    eax,eax
  40bf12:	test   r8,r8
  40bf15:	je     40bf36 <__swc_fn_7069e055_000013_e4b0ddfc+0x56>
  40bf17:	nop    WORD PTR [rax+rax*1+0x0]
  40bf20:	mov    rcx,QWORD PTR [r8]
  40bf23:	mov    r9,QWORD PTR [rdx]
  40bf26:	mov    QWORD PTR [r8],r9
  40bf29:	mov    QWORD PTR [rdx],r8
  40bf2c:	mov    r8,rcx
  40bf2f:	inc    eax
  40bf31:	test   rcx,rcx
  40bf34:	jne    40bf20 <__swc_fn_7069e055_000013_e4b0ddfc+0x40>
  40bf36:	sub    DWORD PTR [rdx+0x28],eax
  40bf39:	add    rsp,0x8
  40bf3d:	ret
	...

000000000040bf40 <__swc_fn_7069e055_000016_9afb7cfb>:
  40bf40:	lea    eax,[rdx+0x1]
  40bf43:	mov    edx,DWORD PTR [rcx+0x28]
  40bf46:	shlx   eax,eax,edx
  40bf4b:	shl    rax,0x10
  40bf4f:	add    rax,rcx
  40bf52:	ret
	...

000000000040bf60 <__swc_fn_7069e055_000019_adca76cf>:
  40bf60:	push   rbx
  40bf61:	push   rsi
  40bf62:	push   rdi
  40bf63:	push   r12
  40bf65:	push   r13
  40bf67:	push   r14
  40bf69:	push   r15
  40bf6b:	sub    rsp,0x30
  40bf6f:	mov    rbx,rcx
  40bf72:	lea    rsi,[rcx+0x48]
  40bf76:	mov    QWORD PTR [rsp+0x18],rsi
  40bf7b:	mov    rax,QWORD PTR [rsi]
  40bf7e:	mov    rdi,rax
  40bf81:	lea    r12,[rsp+0x8]
  40bf86:	lea    r13,[rcx+0x40]
  40bf8a:	nop    WORD PTR [rax+rax*1+0x0]
  40bf90:	test   rdi,rdi
  40bf93:	je     40c0d3 <__swc_fn_7069e055_000019_adca76cf+0x173>
  40bf99:	xor    eax,eax
  40bf9b:	tzcnt  rax,rdi
  40bfa0:	mov    DWORD PTR [rsp+0x8],eax
  40bfa4:	mov    r14d,0x1
  40bfaa:	mov    ecx,eax
  40bfac:	shl    r14,cl
  40bfaf:	andn   rdi,r14,rdi
  40bfb4:	mov    rcx,QWORD PTR [r13+0x0]
  40bfb8:	test   rcx,r14
  40bfbb:	jne    40bf90 <__swc_fn_7069e055_000019_adca76cf+0x30>
  40bfbd:	mov    rdx,rcx
  40bfc0:	or     rdx,r14
  40bfc3:	mov    rax,rcx
  40bfc6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  40bfcc:	cmp    rax,rcx
  40bfcf:	je     40bfd9 <__swc_fn_7069e055_000019_adca76cf+0x79>
  40bfd1:	mov    rax,QWORD PTR [rsi]
  40bfd4:	mov    rdi,rax
  40bfd7:	jmp    40bf90 <__swc_fn_7069e055_000019_adca76cf+0x30>
  40bfd9:	mov    rcx,rbx
  40bfdc:	mov    rdx,r14
  40bfdf:	call   407d40 <__swc_fn_7069e055_000021_fd2b165c>
  40bfe4:	test   al,al
  40bfe6:	je     40c0be <__swc_fn_7069e055_000019_adca76cf+0x15e>
  40bfec:	mov    eax,DWORD PTR [r12]
  40bff0:	shl    rax,0x4
  40bff4:	lea    r15,[rbx+rax*8+0x80]
  40bffc:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  40c004:	lea    rcx,[rip+0x1807d]        # 424088 <__swc_bss_base_7069e055+0x48>
  40c00b:	mov    rdx,QWORD PTR [rip+0x18076]        # 424088 <__swc_bss_base_7069e055+0x48>
  40c012:	cs nop WORD PTR [rax+rax*1+0x0]
  40c01c:	nop    DWORD PTR [rax+0x0]
  40c020:	mov    r8,rdx
  40c023:	sub    r8,rsi
  40c026:	mov    rax,rdx
  40c029:	lock cmpxchg QWORD PTR [rcx],r8
  40c02e:	cmp    rax,rdx
  40c031:	je     40c038 <__swc_fn_7069e055_000019_adca76cf+0xd8>
  40c033:	mov    rdx,rax
  40c036:	jmp    40c020 <__swc_fn_7069e055_000019_adca76cf+0xc0>
  40c038:	mov    rcx,rbx
  40c03b:	mov    rax,r12
  40c03e:	mov    edx,DWORD PTR [rax]
  40c040:	call   407be0 <__swc_fn_7069e055_000015_9dea5065>
  40c045:	test   rsi,rsi
  40c048:	je     40c0b6 <__swc_fn_7069e055_000019_adca76cf+0x156>
  40c04e:	mov    rcx,rax
  40c051:	mov    rdx,rsi
  40c054:	call   411280 <__swc_fn_7069e055_000116_e9fc0224>
  40c059:	lea    rcx,[rip+0x18018]        # 424078 <__swc_bss_base_7069e055+0x38>
  40c060:	mov    rdx,QWORD PTR [rip+0x18011]        # 424078 <__swc_bss_base_7069e055+0x38>
  40c067:	nop    WORD PTR [rax+rax*1+0x0]
  40c070:	mov    r8,rdx
  40c073:	sub    r8,rsi
  40c076:	mov    rax,rdx
  40c079:	lock cmpxchg QWORD PTR [rcx],r8
  40c07e:	cmp    rax,rdx
  40c081:	je     40c088 <__swc_fn_7069e055_000019_adca76cf+0x128>
  40c083:	mov    rdx,rax
  40c086:	jmp    40c070 <__swc_fn_7069e055_000019_adca76cf+0x110>
  40c088:	lea    rcx,[rip+0x18001]        # 424090 <__swc_bss_base_7069e055+0x50>
  40c08f:	mov    rdx,QWORD PTR [rip+0x17ffa]        # 424090 <__swc_bss_base_7069e055+0x50>
  40c096:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0a0:	lea    r8,[rdx+0x1]
  40c0a4:	mov    rax,rdx
  40c0a7:	lock cmpxchg QWORD PTR [rcx],r8
  40c0ac:	cmp    rax,rdx
  40c0af:	je     40c0b6 <__swc_fn_7069e055_000019_adca76cf+0x156>
  40c0b1:	mov    rdx,rax
  40c0b4:	jmp    40c0a0 <__swc_fn_7069e055_000019_adca76cf+0x140>
  40c0b6:	mov    DWORD PTR [r15+0x3c],0x0
  40c0be:	mov    rcx,rbx
  40c0c1:	mov    rdx,r14
  40c0c4:	call   40c0f0 <__swc_fn_7069e055_000022_c8f5f27c>
  40c0c9:	mov    rsi,QWORD PTR [rsp+0x18]
  40c0ce:	jmp    40bf90 <__swc_fn_7069e055_000019_adca76cf+0x30>
  40c0d3:	add    rsp,0x30
  40c0d7:	pop    r15
  40c0d9:	pop    r14
  40c0db:	pop    r13
  40c0dd:	pop    r12
  40c0df:	pop    rdi
  40c0e0:	pop    rsi
  40c0e1:	pop    rbx
  40c0e2:	ret
	...

000000000040c0f0 <__swc_fn_7069e055_000022_c8f5f27c>:
  40c0f0:	mov    r8,QWORD PTR [rcx+0x40]
  40c0f4:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0fe:	xchg   ax,ax
  40c100:	mov    rax,rdx
  40c103:	not    rax
  40c106:	mov    r9,r8
  40c109:	and    r9,rax
  40c10c:	mov    rax,r8
  40c10f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  40c115:	cmp    rax,r8
  40c118:	jne    40c11b <__swc_fn_7069e055_000022_c8f5f27c+0x2b>
  40c11a:	ret
  40c11b:	mov    r8,rax
  40c11e:	jmp    40c100 <__swc_fn_7069e055_000022_c8f5f27c+0x10>

000000000040c120 <__swc_fn_7069e055_000025_aa910677>:
  40c120:	push   rsi
  40c121:	push   rdi
  40c122:	sub    rsp,0x8
  40c126:	mov    rsi,rcx
  40c129:	call   40bf60 <__swc_fn_7069e055_000019_adca76cf>
  40c12e:	lea    rdi,[rip+0x180eb]        # 424220 <__swc_bss_base_7069e055+0x1e0>
  40c135:	mov    rcx,rdi
  40c138:	call   40e380 <__swc_fn_7069e055_000139_86bb0f90>
  40c13d:	mov    QWORD PTR [rsi+0x8],0x0
  40c145:	mov    QWORD PTR [rsi+0x18],0x0
  40c14d:	mov    rax,QWORD PTR [rip+0x180d4]        # 424228 <__swc_bss_base_7069e055+0x1e8>
  40c154:	mov    QWORD PTR [rsi+0x10],rax
  40c158:	mov    QWORD PTR [rip+0x180c9],rsi        # 424228 <__swc_bss_base_7069e055+0x1e8>
  40c15f:	mov    rcx,rdi
  40c162:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40c167:	add    rsp,0x8
  40c16b:	pop    rdi
  40c16c:	pop    rsi
  40c16d:	ret
	...

000000000040c170 <__swc_fn_7069e055_000028_9798fb47>:
  40c170:	vxorps xmm0,xmm0,xmm0
  40c174:	vmovups XMMWORD PTR [rcx],xmm0
  40c178:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40c17d:	mov    QWORD PTR [rcx+0x20],0x0
  40c185:	ret
	...

000000000040c190 <__swc_fn_7069e055_000031_9798fb47>:
  40c190:	vxorps xmm0,xmm0,xmm0
  40c194:	vmovups XMMWORD PTR [rcx],xmm0
  40c198:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40c19d:	mov    QWORD PTR [rcx+0x20],0x0
  40c1a5:	ret
	...

000000000040c1b0 <__swc_fn_7069e055_000034_9128bcf9>:
  40c1b0:	push   r12
  40c1b2:	mov    r12,rdi
  40c1b5:	test   rdi,rdi
  40c1b8:	jne    40c1bd <__swc_fn_7069e055_000034_9128bcf9+0xd>
  40c1ba:	pop    r12
  40c1bc:	ret
  40c1bd:	lea    rax,[rip+0x15e44]        # 422008 <__swc_data_base_7069e055+0x8>
  40c1c4:	mov    rax,QWORD PTR [rax]
  40c1c7:	cmp    rax,0xffffffffffffffff
  40c1cb:	je     40c1da <__swc_fn_7069e055_000034_9128bcf9+0x2a>
  40c1cd:	mov    eax,eax
  40c1cf:	mov    edi,eax
  40c1d1:	xor    eax,eax
  40c1d3:	call   407000 <pthread_getspecific@plt>
  40c1d8:	jmp    40c1dc <__swc_fn_7069e055_000034_9128bcf9+0x2c>
  40c1da:	xor    eax,eax
  40c1dc:	cmp    rax,r12
  40c1df:	jne    40c1e8 <__swc_fn_7069e055_000034_9128bcf9+0x38>
  40c1e1:	xor    ecx,ecx
  40c1e3:	call   407f00 <__swc_fn_7069e055_000036_92d9bbff>
  40c1e8:	mov    rdx,QWORD PTR [r12]
  40c1ec:	test   rdx,rdx
  40c1ef:	je     40c208 <__swc_fn_7069e055_000034_9128bcf9+0x58>
  40c1f1:	mov    rcx,rdx
  40c1f4:	call   40c230 <__swc_fn_7069e055_000040_eb6108f2>
  40c1f9:	test   al,al
  40c1fb:	je     40c208 <__swc_fn_7069e055_000034_9128bcf9+0x58>
  40c1fd:	mov    rcx,rdx
  40c200:	mov    rdx,r12
  40c203:	call   40c320 <__swc_fn_7069e055_000046_b30433d0>
  40c208:	pop    r12
  40c20a:	ret
  40c20b:	add    BYTE PTR [rax],al
  40c20d:	add    BYTE PTR [rax],al
	...

000000000040c210 <__swc_fn_7069e055_000037_28d0e998>:
  40c210:	push   rsi
  40c211:	mov    rsi,rcx
  40c214:	call   40f4c0 <__swc_fn_7069e055_000035_cd1a4e8c>
  40c219:	mov    rcx,rax
  40c21c:	mov    rdx,rsi
  40c21f:	call   40e200 <__swc_fn_7069e055_000133_ae5891af>
  40c224:	mov    rcx,rsi
  40c227:	call   407f00 <__swc_fn_7069e055_000036_92d9bbff>
  40c22c:	pop    rsi
  40c22d:	ret
	...

000000000040c230 <__swc_fn_7069e055_000040_eb6108f2>:
  40c230:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40c23a:	sete   al
  40c23d:	ret
	...

000000000040c240 <__swc_fn_7069e055_000043_d3c2ab54>:
  40c240:	push   rsi
  40c241:	test   rdx,rdx
  40c244:	jne    40c248 <__swc_fn_7069e055_000043_d3c2ab54+0x8>
  40c246:	pop    rsi
  40c247:	ret
  40c248:	mov    rax,r8
  40c24b:	mov    ecx,0x1000
  40c250:	test   ecx,ecx
  40c252:	mov    r10d,0x8
  40c258:	cmove  ecx,r10d
  40c25c:	dec    rcx
  40c25f:	mov    r10,0xffffffffffffffff
  40c266:	sub    r10,rcx
  40c269:	cmp    r8,r10
  40c26c:	jbe    40c272 <__swc_fn_7069e055_000043_d3c2ab54+0x32>
  40c26e:	xor    eax,eax
  40c270:	jmp    40c27a <__swc_fn_7069e055_000043_d3c2ab54+0x3a>
  40c272:	add    rax,rcx
  40c275:	andn   rax,rcx,rax
  40c27a:	mov    ecx,0x1000
  40c27f:	test   ecx,ecx
  40c281:	mov    r8d,0x8
  40c287:	cmove  ecx,r8d
  40c28b:	dec    rcx
  40c28e:	mov    r8,0xffffffffffffffff
  40c295:	sub    r8,rcx
  40c298:	cmp    r9,r8
  40c29b:	jbe    40c2a1 <__swc_fn_7069e055_000043_d3c2ab54+0x61>
  40c29d:	xor    esi,esi
  40c29f:	jmp    40c2ac <__swc_fn_7069e055_000043_d3c2ab54+0x6c>
  40c2a1:	add    r9,rcx
  40c2a4:	andn   r9,rcx,r9
  40c2a9:	mov    rsi,r9
  40c2ac:	mov    rcx,rdx
  40c2af:	mov    rdx,rax
  40c2b2:	mov    r8,rsi
  40c2b5:	call   40de00 <__swc_fn_7069e055_000118_5208f471>
  40c2ba:	lea    rcx,[rip+0x17db7]        # 424078 <__swc_bss_base_7069e055+0x38>
  40c2c1:	mov    rdx,QWORD PTR [rip+0x17db0]        # 424078 <__swc_bss_base_7069e055+0x38>
  40c2c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40c2d0:	mov    r8,rdx
  40c2d3:	sub    r8,rsi
  40c2d6:	mov    rax,rdx
  40c2d9:	lock cmpxchg QWORD PTR [rcx],r8
  40c2de:	cmp    rax,rdx
  40c2e1:	je     40c2e8 <__swc_fn_7069e055_000043_d3c2ab54+0xa8>
  40c2e3:	mov    rdx,rax
  40c2e6:	jmp    40c2d0 <__swc_fn_7069e055_000043_d3c2ab54+0x90>
  40c2e8:	lea    rcx,[rip+0x17da1]        # 424090 <__swc_bss_base_7069e055+0x50>
  40c2ef:	mov    rdx,QWORD PTR [rip+0x17d9a]        # 424090 <__swc_bss_base_7069e055+0x50>
  40c2f6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c300:	lea    r8,[rdx+0x1]
  40c304:	mov    rax,rdx
  40c307:	lock cmpxchg QWORD PTR [rcx],r8
  40c30c:	cmp    rax,rdx
  40c30f:	je     40c316 <__swc_fn_7069e055_000043_d3c2ab54+0xd6>
  40c311:	mov    rdx,rax
  40c314:	jmp    40c300 <__swc_fn_7069e055_000043_d3c2ab54+0xc0>
  40c316:	pop    rsi
  40c317:	ret
	...

000000000040c320 <__swc_fn_7069e055_000046_b30433d0>:
  40c320:	push   rbx
  40c321:	push   rsi
  40c322:	push   rdi
  40c323:	push   r12
  40c325:	push   r13
  40c327:	push   r14
  40c329:	push   r15
  40c32b:	sub    rsp,0x30
  40c32f:	mov    rbx,rdx
  40c332:	mov    QWORD PTR [rsp+0x18],rdx
  40c337:	mov    rsi,rcx
  40c33a:	mov    eax,0x1
  40c33f:	xchg   DWORD PTR [rbx+0x20],eax
  40c342:	test   eax,eax
  40c344:	je     40c356 <__swc_fn_7069e055_000046_b30433d0+0x36>
  40c346:	add    rsp,0x30
  40c34a:	pop    r15
  40c34c:	pop    r14
  40c34e:	pop    r13
  40c350:	pop    r12
  40c352:	pop    rdi
  40c353:	pop    rsi
  40c354:	pop    rbx
  40c355:	ret
  40c356:	mov    rcx,rsi
  40c359:	mov    rdx,rbx
  40c35c:	mov    r8,0xffffffffffffffff
  40c363:	call   4084d0 <__swc_fn_7069e055_000063_dea90857>
  40c368:	lea    rdi,[rsi+0x10]
  40c36c:	mov    QWORD PTR [rsp+0x20],rdi
  40c371:	mov    rcx,rdi
  40c374:	call   40e380 <__swc_fn_7069e055_000139_86bb0f90>
  40c379:	xor    r12d,r12d
  40c37c:	cs nop WORD PTR [rax+rax*1+0x0]
  40c386:	cs nop WORD PTR [rax+rax*1+0x0]
  40c390:	mov    eax,r12d
  40c393:	lea    r13,[rax+rax*4]
  40c397:	lea    r13,[rbx+r13*8+0x28]
  40c39c:	mov    rax,QWORD PTR [r13+0x8]
  40c3a0:	mov    QWORD PTR [rsp+0x8],rax
  40c3a5:	mov    rax,QWORD PTR [r13+0x18]
  40c3a9:	mov    QWORD PTR [rsp+0x10],rax
  40c3ae:	mov    r14d,0x2
  40c3b4:	xor    r15d,r15d
  40c3b7:	test   r14,r14
  40c3ba:	je     40c437 <__swc_fn_7069e055_000046_b30433d0+0x117>
  40c3c0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  40c3c5:	mov    rdi,rax
  40c3c8:	test   rdi,rdi
  40c3cb:	je     40c429 <__swc_fn_7069e055_000046_b30433d0+0x109>
  40c3cd:	nop    DWORD PTR [rax]
  40c3d0:	mov    rbx,QWORD PTR [rdi+0x48]
  40c3d4:	mov    DWORD PTR [rdi+0x6c],0x0
  40c3db:	mov    rcx,rdi
  40c3de:	call   40bee0 <__swc_fn_7069e055_000013_e4b0ddfc>
  40c3e3:	cmp    DWORD PTR [rdi+0x28],0x0
  40c3e7:	jne    40c400 <__swc_fn_7069e055_000046_b30433d0+0xe0>
  40c3e9:	mov    rax,rdi
  40c3ec:	and    rax,0xffffffffffc00000
  40c3f3:	mov    rcx,rax
  40c3f6:	mov    rdx,rdi
  40c3f9:	call   407c00 <__swc_fn_7069e055_000018_283e2b5e>
  40c3fe:	jmp    40c421 <__swc_fn_7069e055_000046_b30433d0+0x101>
  40c400:	mov    QWORD PTR [rdi+0x40],0x0
  40c408:	rex mov BYTE PTR [rdi+0x3b],0x2
  40c40d:	mov    QWORD PTR [rdi+0x50],0x0
  40c415:	mov    rax,QWORD PTR [rsi+0x28]
  40c419:	mov    QWORD PTR [rdi+0x48],rax
  40c41d:	mov    QWORD PTR [rsi+0x28],rdi
  40c421:	mov    rdi,rbx
  40c424:	test   rbx,rbx
  40c427:	jne    40c3d0 <__swc_fn_7069e055_000046_b30433d0+0xb0>
  40c429:	add    r15,0x1
  40c42d:	sub    r14,0x1
  40c431:	jne    40c3c0 <__swc_fn_7069e055_000046_b30433d0+0xa0>
  40c437:	vxorps xmm0,xmm0,xmm0
  40c43b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  40c441:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40c447:	mov    QWORD PTR [r13+0x20],0x0
  40c44f:	add    r12,0x1
  40c453:	cmp    r12,0x2d
  40c457:	mov    rbx,QWORD PTR [rsp+0x18]
  40c45c:	jb     40c390 <__swc_fn_7069e055_000046_b30433d0+0x70>
  40c462:	mov    rcx,rsi
  40c465:	mov    rbx,QWORD PTR [rsp+0x18]
  40c46a:	mov    rdx,rbx
  40c46d:	mov    rdi,QWORD PTR [rsp+0x20]
  40c472:	call   40f680 <__swc_fn_7069e055_000047_6e7a8d58>
  40c477:	mov    rcx,rdi
  40c47a:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40c47f:	mov    rcx,rsi
  40c482:	mov    rdx,rbx
  40c485:	mov    r8d,0x9b8
  40c48b:	mov    r9d,0x9b8
  40c491:	call   40c240 <__swc_fn_7069e055_000043_d3c2ab54>
  40c496:	add    rsp,0x30
  40c49a:	pop    r15
  40c49c:	pop    r14
  40c49e:	pop    r13
  40c4a0:	pop    r12
  40c4a2:	pop    rdi
  40c4a3:	pop    rsi
  40c4a4:	pop    rbx
  40c4a5:	ret
	...

000000000040c4c0 <__swc_fn_7069e055_000049_ad48ec88>:
  40c4c0:	push   rbx
  40c4c1:	push   rsi
  40c4c2:	push   rdi
  40c4c3:	push   r12
  40c4c5:	push   r13
  40c4c7:	push   r14
  40c4c9:	push   r15
  40c4cb:	sub    rsp,0x30
  40c4cf:	mov    ebx,r8d
  40c4d2:	mov    rsi,rcx
  40c4d5:	mov    rdi,rdx
  40c4d8:	test   r8d,r8d
  40c4db:	jne    40c4e4 <__swc_fn_7069e055_000049_ad48ec88+0x24>
  40c4dd:	mov    eax,0x8
  40c4e2:	jmp    40c50b <__swc_fn_7069e055_000049_ad48ec88+0x4b>
  40c4e4:	cmp    ebx,0x8
  40c4e7:	ja     40c4f2 <__swc_fn_7069e055_000049_ad48ec88+0x32>
  40c4e9:	mov    rax,rbx
  40c4ec:	shl    rax,0x4
  40c4f0:	jmp    40c50b <__swc_fn_7069e055_000049_ad48ec88+0x4b>
  40c4f2:	lea    eax,[rbx-0x9]
  40c4f5:	mov    ecx,eax
  40c4f7:	shr    ecx,0x2
  40c4fa:	and    eax,0x3
  40c4fd:	lea    ecx,[rcx+0x7]
  40c500:	lea    ecx,[rcx-0x2]
  40c503:	lea    eax,[rax+0x5]
  40c506:	shlx   rax,rax,rcx
  40c50b:	lea    r12,[rsp+0x8]
  40c510:	mov    DWORD PTR [rsp+0x8],eax
  40c514:	lea    r13,[rsp+0xc]
  40c519:	mov    QWORD PTR [rsp+0x18],r13
  40c51e:	xor    eax,eax
  40c520:	cmp    ebx,0x21
  40c523:	setae  al
  40c526:	lea    eax,[rax+rax*2]
  40c529:	mov    DWORD PTR [rsp+0xc],eax
  40c52d:	lea    r14,[rsi+0x10]
  40c531:	mov    rcx,r14
  40c534:	call   40e380 <__swc_fn_7069e055_000139_86bb0f90>
  40c539:	xor    eax,eax
  40c53b:	mov    rcx,QWORD PTR [rsi+0x28]
  40c53f:	mov    r15,rcx
  40c542:	test   r15,r15
  40c545:	je     40c5f6 <__swc_fn_7069e055_000049_ad48ec88+0x136>
  40c54b:	cs nop WORD PTR [rax+rax*1+0x0]
  40c555:	cs nop WORD PTR [rax+rax*1+0x0]
  40c55f:	nop
  40c560:	mov    rcx,QWORD PTR [r15+0x48]
  40c564:	movzx  edx,BYTE PTR [r15+0x39]
  40c569:	cmp    edx,ebx
  40c56b:	jne    40c5e7 <__swc_fn_7069e055_000049_ad48ec88+0x127>
  40c56d:	test   rax,rax
  40c570:	jne    40c578 <__swc_fn_7069e055_000049_ad48ec88+0xb8>
  40c572:	mov    QWORD PTR [rsi+0x28],rcx
  40c576:	jmp    40c57c <__swc_fn_7069e055_000049_ad48ec88+0xbc>
  40c578:	mov    QWORD PTR [rax+0x48],rcx
  40c57c:	vxorps xmm0,xmm0,xmm0
  40c580:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  40c586:	mov    BYTE PTR [r15+0x3b],0x1
  40c58b:	mov    QWORD PTR [r15+0x40],rdi
  40c58f:	mov    rcx,r15
  40c592:	call   40bee0 <__swc_fn_7069e055_000013_e4b0ddfc>
  40c597:	movzx  eax,BYTE PTR [r15+0x39]
  40c59c:	lea    rax,[rax+rax*4]
  40c5a0:	lea    rax,[rdi+rax*8+0x28]
  40c5a5:	mov    rcx,QWORD PTR [rax+0x10]
  40c5a9:	mov    QWORD PTR [r15+0x50],rcx
  40c5ad:	mov    QWORD PTR [r15+0x48],0x0
  40c5b5:	mov    rcx,QWORD PTR [rax+0x10]
  40c5b9:	test   rcx,rcx
  40c5bc:	je     40c5c4 <__swc_fn_7069e055_000049_ad48ec88+0x104>
  40c5be:	mov    QWORD PTR [rcx+0x48],r15
  40c5c2:	jmp    40c5c8 <__swc_fn_7069e055_000049_ad48ec88+0x108>
  40c5c4:	mov    QWORD PTR [rax+0x8],r15
  40c5c8:	mov    QWORD PTR [rax+0x10],r15
  40c5cc:	mov    rcx,r14
  40c5cf:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40c5d4:	mov    rax,r15
  40c5d7:	add    rsp,0x30
  40c5db:	pop    r15
  40c5dd:	pop    r14
  40c5df:	pop    r13
  40c5e1:	pop    r12
  40c5e3:	pop    rdi
  40c5e4:	pop    rsi
  40c5e5:	pop    rbx
  40c5e6:	ret
  40c5e7:	mov    rax,r15
  40c5ea:	mov    r15,rcx
  40c5ed:	test   rcx,rcx
  40c5f0:	jne    40c560 <__swc_fn_7069e055_000049_ad48ec88+0xa0>
  40c5f6:	mov    rax,QWORD PTR [rsi+0x18]
  40c5fa:	mov    r15,rax
  40c5fd:	test   r15,r15
  40c600:	je     40c696 <__swc_fn_7069e055_000049_ad48ec88+0x1d6>
  40c606:	cs nop WORD PTR [rax+rax*1+0x0]
  40c610:	mov    eax,DWORD PTR [rsp+0xc]
  40c614:	cmp    DWORD PTR [r15+0x28],eax
  40c618:	jne    40c686 <__swc_fn_7069e055_000049_ad48ec88+0x1c6>
  40c61a:	mov    rcx,r15
  40c61d:	mov    edx,ebx
  40c61f:	mov    rax,r12
  40c622:	mov    r8d,DWORD PTR [rax]
  40c625:	call   40f0c0 <__swc_fn_7069e055_000017_efc44797>
  40c62a:	mov    r13,rax
  40c62d:	test   rax,rax
  40c630:	je     40c686 <__swc_fn_7069e055_000049_ad48ec88+0x1c6>
  40c632:	mov    QWORD PTR [r13+0x40],rdi
  40c636:	movzx  eax,BYTE PTR [r13+0x39]
  40c63b:	lea    rax,[rax+rax*4]
  40c63f:	lea    rax,[rdi+rax*8+0x28]
  40c644:	mov    rcx,QWORD PTR [rax+0x10]
  40c648:	mov    QWORD PTR [r13+0x50],rcx
  40c64c:	mov    QWORD PTR [r13+0x48],0x0
  40c654:	mov    rcx,QWORD PTR [rax+0x10]
  40c658:	test   rcx,rcx
  40c65b:	je     40c663 <__swc_fn_7069e055_000049_ad48ec88+0x1a3>
  40c65d:	mov    QWORD PTR [rcx+0x48],r13
  40c661:	jmp    40c667 <__swc_fn_7069e055_000049_ad48ec88+0x1a7>
  40c663:	mov    QWORD PTR [rax+0x8],r13
  40c667:	mov    QWORD PTR [rax+0x10],r13
  40c66b:	mov    rcx,r14
  40c66e:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40c673:	mov    rax,r13
  40c676:	add    rsp,0x30
  40c67a:	pop    r15
  40c67c:	pop    r14
  40c67e:	pop    r13
  40c680:	pop    r12
  40c682:	pop    rdi
  40c683:	pop    rsi
  40c684:	pop    rbx
  40c685:	ret
  40c686:	mov    rax,QWORD PTR [r15+0x10]
  40c68a:	mov    r15,rax
  40c68d:	test   rax,rax
  40c690:	jne    40c610 <__swc_fn_7069e055_000049_ad48ec88+0x150>
  40c696:	mov    rcx,rsi
  40c699:	mov    r13,QWORD PTR [rsp+0x18]
  40c69e:	mov    edx,DWORD PTR [r13+0x0]
  40c6a2:	call   407d80 <__swc_fn_7069e055_000024_2685aade>
  40c6a7:	mov    r13,rax
  40c6aa:	test   rax,rax
  40c6ad:	jne    40c6c9 <__swc_fn_7069e055_000049_ad48ec88+0x209>
  40c6af:	mov    rcx,r14
  40c6b2:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40c6b7:	xor    eax,eax
  40c6b9:	add    rsp,0x30
  40c6bd:	pop    r15
  40c6bf:	pop    r14
  40c6c1:	pop    r13
  40c6c3:	pop    r12
  40c6c5:	pop    rdi
  40c6c6:	pop    rsi
  40c6c7:	pop    rbx
  40c6c8:	ret
  40c6c9:	mov    rcx,r13
  40c6cc:	mov    edx,ebx
  40c6ce:	mov    r8d,DWORD PTR [r12]
  40c6d2:	call   40f0c0 <__swc_fn_7069e055_000017_efc44797>
  40c6d7:	mov    rbx,rax
  40c6da:	test   rax,rax
  40c6dd:	jne    40c701 <__swc_fn_7069e055_000049_ad48ec88+0x241>
  40c6df:	mov    rcx,r13
  40c6e2:	call   40c120 <__swc_fn_7069e055_000025_aa910677>
  40c6e7:	mov    rcx,r14
  40c6ea:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40c6ef:	xor    eax,eax
  40c6f1:	add    rsp,0x30
  40c6f5:	pop    r15
  40c6f7:	pop    r14
  40c6f9:	pop    r13
  40c6fb:	pop    r12
  40c6fd:	pop    rdi
  40c6fe:	pop    rsi
  40c6ff:	pop    rbx
  40c700:	ret
  40c701:	mov    rax,QWORD PTR [rsi+0x18]
  40c705:	mov    QWORD PTR [r13+0x10],rax
  40c709:	mov    rax,QWORD PTR [rsi+0x18]
  40c70d:	test   rax,rax
  40c710:	je     40c716 <__swc_fn_7069e055_000049_ad48ec88+0x256>
  40c712:	mov    QWORD PTR [rax+0x18],r13
  40c716:	mov    QWORD PTR [rsi+0x18],r13
  40c71a:	mov    QWORD PTR [rbx+0x40],rdi
  40c71e:	movzx  eax,BYTE PTR [rbx+0x39]
  40c722:	lea    rax,[rax+rax*4]
  40c726:	lea    rax,[rdi+rax*8+0x28]
  40c72b:	mov    rcx,QWORD PTR [rax+0x10]
  40c72f:	mov    QWORD PTR [rbx+0x50],rcx
  40c733:	mov    QWORD PTR [rbx+0x48],0x0
  40c73b:	mov    rcx,QWORD PTR [rax+0x10]
  40c73f:	test   rcx,rcx
  40c742:	je     40c74a <__swc_fn_7069e055_000049_ad48ec88+0x28a>
  40c744:	mov    QWORD PTR [rcx+0x48],rbx
  40c748:	jmp    40c74e <__swc_fn_7069e055_000049_ad48ec88+0x28e>
  40c74a:	mov    QWORD PTR [rax+0x8],rbx
  40c74e:	mov    QWORD PTR [rax+0x10],rbx
  40c752:	mov    rcx,r14
  40c755:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40c75a:	mov    rax,rbx
  40c75d:	add    rsp,0x30
  40c761:	pop    r15
  40c763:	pop    r14
  40c765:	pop    r13
  40c767:	pop    r12
  40c769:	pop    rdi
  40c76a:	pop    rsi
  40c76b:	pop    rbx
  40c76c:	ret
	...

000000000040c780 <__swc_fn_7069e055_000052_d846b172>:
  40c780:	push   rsi
  40c781:	push   rdi
  40c782:	push   r12
  40c784:	mov    rsi,rdx
  40c787:	mov    rdi,rcx
  40c78a:	lea    rax,[rcx+0x2a80]
  40c791:	mov    rcx,QWORD PTR [rax]
  40c794:	test   rcx,rcx
  40c797:	jne    40c79e <__swc_fn_7069e055_000052_d846b172+0x1e>
  40c799:	pop    r12
  40c79b:	pop    rdi
  40c79c:	pop    rsi
  40c79d:	ret
  40c79e:	xor    ecx,ecx
  40c7a0:	xchg   QWORD PTR [rax],rcx
  40c7a3:	mov    r12,rcx
  40c7a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c7b0:	cs nop WORD PTR [rax+rax*1+0x0]
  40c7ba:	nop    WORD PTR [rax+rax*1+0x0]
  40c7c0:	test   r12,r12
  40c7c3:	je     40c85a <__swc_fn_7069e055_000052_d846b172+0xda>
  40c7c9:	mov    r8,r12
  40c7cc:	mov    r12,QWORD PTR [r12+0x78]
  40c7d1:	lea    rcx,[r8+0x70]
  40c7d5:	xor    eax,eax
  40c7d7:	xchg   DWORD PTR [r8+0x70],eax
  40c7db:	cmp    QWORD PTR [r8+0x40],rsi
  40c7df:	jne    40c7f6 <__swc_fn_7069e055_000052_d846b172+0x76>
  40c7e1:	mov    eax,DWORD PTR [r8+0x6c]
  40c7e5:	test   eax,eax
  40c7e7:	je     40c7c0 <__swc_fn_7069e055_000052_d846b172+0x40>
  40c7e9:	mov    rcx,rdi
  40c7ec:	mov    rdx,rsi
  40c7ef:	call   408130 <__swc_fn_7069e055_000051_e072b516>
  40c7f4:	jmp    40c7c0 <__swc_fn_7069e055_000052_d846b172+0x40>
  40c7f6:	mov    rax,QWORD PTR [r8+0x40]
  40c7fa:	test   rax,rax
  40c7fd:	je     40c7c0 <__swc_fn_7069e055_000052_d846b172+0x40>
  40c7ff:	mov    eax,DWORD PTR [r8+0x6c]
  40c803:	test   eax,eax
  40c805:	je     40c7c0 <__swc_fn_7069e055_000052_d846b172+0x40>
  40c807:	mov    r9d,0x1
  40c80d:	xor    eax,eax
  40c80f:	lock cmpxchg DWORD PTR [rcx],r9d
  40c814:	test   eax,eax
  40c816:	jne    40c7c0 <__swc_fn_7069e055_000052_d846b172+0x40>
  40c818:	mov    rax,r8
  40c81b:	and    rax,0xffffffffffc00000
  40c822:	mov    rax,QWORD PTR [rax+0x8]
  40c826:	test   rax,rax
  40c829:	jne    40c831 <__swc_fn_7069e055_000052_d846b172+0xb1>
  40c82b:	xor    eax,eax
  40c82d:	xchg   DWORD PTR [rcx],eax
  40c82f:	jmp    40c7c0 <__swc_fn_7069e055_000052_d846b172+0x40>
  40c831:	lea    rcx,[rax+0x2a80]
  40c838:	mov    rax,QWORD PTR [rcx]
  40c83b:	mov    rdx,rax
  40c83e:	xchg   ax,ax
  40c840:	mov    QWORD PTR [r8+0x78],rdx
  40c844:	mov    rax,rdx
  40c847:	lock cmpxchg QWORD PTR [rcx],r8
  40c84c:	cmp    rax,rdx
  40c84f:	je     40c7c0 <__swc_fn_7069e055_000052_d846b172+0x40>
  40c855:	mov    rdx,rax
  40c858:	jmp    40c840 <__swc_fn_7069e055_000052_d846b172+0xc0>
  40c85a:	pop    r12
  40c85c:	pop    rdi
  40c85d:	pop    rsi
  40c85e:	ret
	...

000000000040c860 <__swc_fn_7069e055_000055_2e3450f7>:
  40c860:	sub    rsp,0x8
  40c864:	mov    r9,r8
  40c867:	movzx  eax,BYTE PTR [r9+0x39]
  40c86c:	lea    rax,[rax+rax*4]
  40c870:	lea    rax,[rdx+rax*8+0x28]
  40c875:	cmp    QWORD PTR [rax],r9
  40c878:	je     40c880 <__swc_fn_7069e055_000055_2e3450f7+0x20>
  40c87a:	cmp    QWORD PTR [rax+0x20],r9
  40c87e:	jne    40c885 <__swc_fn_7069e055_000055_2e3450f7+0x25>
  40c880:	add    rsp,0x8
  40c884:	ret
  40c885:	cmp    QWORD PTR [rax+0x20],0x0
  40c88a:	je     40c897 <__swc_fn_7069e055_000055_2e3450f7+0x37>
  40c88c:	mov    r8,QWORD PTR [rax+0x20]
  40c890:	cmp    DWORD PTR [r8+0x28],0x0
  40c895:	je     40c8a0 <__swc_fn_7069e055_000055_2e3450f7+0x40>
  40c897:	mov    QWORD PTR [rax+0x20],r9
  40c89b:	add    rsp,0x8
  40c89f:	ret
  40c8a0:	mov    r8,r9
  40c8a3:	call   408090 <__swc_fn_7069e055_000048_137687bb>
  40c8a8:	mov    rax,r9
  40c8ab:	and    rax,0xffffffffffc00000
  40c8b2:	mov    rcx,rax
  40c8b5:	mov    rdx,r9
  40c8b8:	call   407c00 <__swc_fn_7069e055_000018_283e2b5e>
  40c8bd:	add    rsp,0x8
  40c8c1:	ret
	...

000000000040c8d0 <__swc_fn_7069e055_000058_1bb23e77>:
  40c8d0:	push   rsi
  40c8d1:	push   rdi
  40c8d2:	push   r12
  40c8d4:	mov    rsi,rdx
  40c8d7:	mov    rax,rdx
  40c8da:	shr    rax,0xc
  40c8de:	movabs rdx,0x9e3779b97f4a7c15
  40c8e8:	imul   rax,rdx
  40c8ec:	shr    rax,0x20
  40c8f0:	lea    rax,[rax*8+0x0]
  40c8f8:	shr    rax,0x20
  40c8fc:	lea    rax,[rax*8+0x0]
  40c904:	lea    rax,[rcx+rax*8+0x40]
  40c909:	xor    edx,edx
  40c90b:	test   dl,dl
  40c90d:	lea    rdi,[rcx+0x8]
  40c911:	cmove  rdi,rax
  40c915:	xor    edx,edx
  40c917:	test   dl,dl
  40c919:	lea    r12,[rcx+0x30]
  40c91d:	lea    rax,[rax+0x8]
  40c921:	cmove  r12,rax
  40c925:	mov    rcx,rdi
  40c928:	call   40e380 <__swc_fn_7069e055_000139_86bb0f90>
  40c92d:	mov    rax,QWORD PTR [rsi+0x30]
  40c931:	test   rax,rax
  40c934:	jne    40c940 <__swc_fn_7069e055_000058_1bb23e77+0x70>
  40c936:	mov    rax,QWORD PTR [rsi+0x38]
  40c93a:	mov    QWORD PTR [r12],rax
  40c93e:	jmp    40c948 <__swc_fn_7069e055_000058_1bb23e77+0x78>
  40c940:	mov    rcx,QWORD PTR [rsi+0x38]
  40c944:	mov    QWORD PTR [rax+0x38],rcx
  40c948:	mov    rax,QWORD PTR [rsi+0x38]
  40c94c:	test   rax,rax
  40c94f:	je     40c959 <__swc_fn_7069e055_000058_1bb23e77+0x89>
  40c951:	mov    rcx,QWORD PTR [rsi+0x30]
  40c955:	mov    QWORD PTR [rax+0x30],rcx
  40c959:	vxorps xmm0,xmm0,xmm0
  40c95d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  40c962:	mov    rcx,rdi
  40c965:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40c96a:	pop    r12
  40c96c:	pop    rdi
  40c96d:	pop    rsi
  40c96e:	ret
	...

000000000040c970 <__swc_fn_7069e055_000061_ad030a10>:
  40c970:	mov    rax,QWORD PTR [rcx+0x250]
  40c977:	mov    rcx,rax
  40c97a:	cmp    rax,0x1000000
  40c981:	mov    eax,0x1000000
  40c986:	cmovb  rcx,rax
  40c98a:	mov    rax,rcx
  40c98d:	cmp    rcx,0x10000000
  40c994:	mov    ecx,0x10000000
  40c999:	cmova  rax,rcx
  40c99d:	ret
	...

000000000040c9a0 <__swc_fn_7069e055_000064_ffcd96eb>:
  40c9a0:	push   rsi
  40c9a1:	push   rdi
  40c9a2:	push   r12
  40c9a4:	mov    rsi,rcx
  40c9a7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  40c9ae:	xor    r12d,r12d
  40c9b1:	test   rdi,rdi
  40c9b4:	jbe    40c9eb <__swc_fn_7069e055_000064_ffcd96eb+0x4b>
  40c9b6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c9c0:	lea    rax,[r12+r12*4]
  40c9c4:	lea    rax,[rsi+rax*8+0x268]
  40c9cc:	mov    rcx,rsi
  40c9cf:	mov    rdx,QWORD PTR [rax]
  40c9d2:	mov    r8,QWORD PTR [rax+0x8]
  40c9d6:	mov    rax,QWORD PTR [rax+0x10]
  40c9da:	mov    r9,rax
  40c9dd:	call   40c240 <__swc_fn_7069e055_000043_d3c2ab54>
  40c9e2:	add    r12,0x1
  40c9e6:	cmp    r12,rdi
  40c9e9:	jb     40c9c0 <__swc_fn_7069e055_000064_ffcd96eb+0x20>
  40c9eb:	vxorps xmm0,xmm0,xmm0
  40c9ef:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  40c9f7:	pop    r12
  40c9f9:	pop    rdi
  40c9fa:	pop    rsi
  40c9fb:	ret
  40c9fc:	add    BYTE PTR [rax],al
	...

000000000040ca00 <__swc_fn_7069e055_000067_8c7d044b>:
  40ca00:	push   rsi
  40ca01:	push   rdi
  40ca02:	sub    rsp,0x8
  40ca06:	mov    rsi,rcx
  40ca09:	call   40fa00 <__swc_fn_7069e055_000056_df0696cd>
  40ca0e:	mov    rdi,rax
  40ca11:	mov    rcx,rsi
  40ca14:	mov    rdx,rax
  40ca17:	call   40c8d0 <__swc_fn_7069e055_000058_1bb23e77>
  40ca1c:	mov    rcx,QWORD PTR [rdi+0x28]
  40ca20:	mov    rdx,QWORD PTR [rsi+0x250]
  40ca27:	nop    WORD PTR [rax+rax*1+0x0]
  40ca30:	mov    r8,rdx
  40ca33:	sub    r8,rcx
  40ca36:	mov    rax,rdx
  40ca39:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40ca42:	cmp    rax,rdx
  40ca45:	je     40ca4c <__swc_fn_7069e055_000067_8c7d044b+0x4c>
  40ca47:	mov    rdx,rax
  40ca4a:	jmp    40ca30 <__swc_fn_7069e055_000067_8c7d044b+0x30>
  40ca4c:	mov    rcx,rsi
  40ca4f:	mov    rdx,QWORD PTR [rdi]
  40ca52:	mov    r8,QWORD PTR [rdi+0x8]
  40ca56:	mov    r9,QWORD PTR [rdi+0x10]
  40ca5a:	call   40fb20 <__swc_fn_7069e055_000062_b304235a>
  40ca5f:	mov    rcx,rsi
  40ca62:	call   40f760 <__swc_fn_7069e055_000053_3af34d7f>
  40ca67:	add    rsp,0x8
  40ca6b:	pop    rdi
  40ca6c:	pop    rsi
  40ca6d:	ret
	...

000000000040ca70 <__swc_fn_7069e055_000070_97813b89>:
  40ca70:	push   r12
  40ca72:	push   r13
  40ca74:	push   r14
  40ca76:	push   rdi
  40ca77:	push   rsi
  40ca78:	sub    rsp,0x1b0
  40ca7f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  40ca88:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  40ca91:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  40ca9a:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  40caa3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  40caac:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  40cab5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  40cabe:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  40cac7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  40cad0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  40cad9:	mov    r8,rdx
  40cadc:	mov    r12,rcx
  40cadf:	mov    r13,QWORD PTR [r8+0x40]
  40cae3:	test   r13,r13
  40cae6:	jne    40caf8 <__swc_fn_7069e055_000070_97813b89+0x88>
  40cae8:	add    rsp,0x1b0
  40caef:	pop    rsi
  40caf0:	pop    rdi
  40caf1:	pop    r14
  40caf3:	pop    r13
  40caf5:	pop    r12
  40caf7:	ret
  40caf8:	mov    QWORD PTR [r8+0x40],0x0
  40cb00:	lea    rax,[rip+0x17599]        # 4240a0 <__swc_bss_base_7069e055+0x60>
  40cb07:	mov    rcx,r13
  40cb0a:	sub    rcx,QWORD PTR [rax+0x8]
  40cb0e:	mov    rax,QWORD PTR [rip+0x1759b]        # 4240b0 <__swc_bss_base_7069e055+0x70>
  40cb15:	cmp    rcx,rax
  40cb18:	jae    40cb44 <__swc_fn_7069e055_000070_97813b89+0xd4>
  40cb1a:	mov    rax,r13
  40cb1d:	and    rax,0xffffffffffc00000
  40cb24:	mov    rcx,r13
  40cb27:	shr    rcx,0x10
  40cb2b:	and    ecx,0x3f
  40cb2e:	mov    edx,DWORD PTR [rax+0x28]
  40cb31:	shrx   ecx,ecx,edx
  40cb36:	shl    rcx,0x4
  40cb3a:	lea    r14,[rax+rcx*8+0x80]
  40cb42:	jmp    40cb5f <__swc_fn_7069e055_000070_97813b89+0xef>
  40cb44:	mov    rcx,r13
  40cb47:	mov    QWORD PTR [rsp+0xf8],r8
  40cb4f:	call   40f3f0 <__swc_fn_7069e055_000026_bcdc5519>
  40cb54:	mov    r8,QWORD PTR [rsp+0xf8]
  40cb5c:	mov    r14,rax
  40cb5f:	test   r14,r14
  40cb62:	jne    40cb74 <__swc_fn_7069e055_000070_97813b89+0x104>
  40cb64:	mov    rcx,r12
  40cb67:	mov    rdx,r13
  40cb6a:	call   40ca00 <__swc_fn_7069e055_000067_8c7d044b>
  40cb6f:	jmp    40cc02 <__swc_fn_7069e055_000070_97813b89+0x192>
  40cb74:	lea    rax,[rip+0x1548d]        # 422008 <__swc_data_base_7069e055+0x8>
  40cb7b:	mov    rax,QWORD PTR [rax]
  40cb7e:	cmp    rax,0xffffffffffffffff
  40cb82:	je     40cb91 <__swc_fn_7069e055_000070_97813b89+0x121>
  40cb84:	mov    eax,eax
  40cb86:	mov    edi,eax
  40cb88:	xor    eax,eax
  40cb8a:	call   407000 <pthread_getspecific@plt>
  40cb8f:	jmp    40cb93 <__swc_fn_7069e055_000070_97813b89+0x123>
  40cb91:	xor    eax,eax
  40cb93:	test   rax,rax
  40cb96:	jne    40cba5 <__swc_fn_7069e055_000070_97813b89+0x135>
  40cb98:	call   40f4c0 <__swc_fn_7069e055_000035_cd1a4e8c>
  40cb9d:	mov    rcx,rax
  40cba0:	call   40a0c0 <__swc_fn_7069e055_000132_5f757033>
  40cba5:	test   rax,rax
  40cba8:	je     40cbf7 <__swc_fn_7069e055_000070_97813b89+0x187>
  40cbaa:	cmp    QWORD PTR [r14+0x40],rax
  40cbae:	jne    40cbf7 <__swc_fn_7069e055_000070_97813b89+0x187>
  40cbb0:	mov    ecx,DWORD PTR [r14+0x6c]
  40cbb4:	test   ecx,ecx
  40cbb6:	je     40cbd6 <__swc_fn_7069e055_000070_97813b89+0x166>
  40cbb8:	mov    rcx,r12
  40cbbb:	mov    rdx,rax
  40cbbe:	mov    r8,r14
  40cbc1:	mov    QWORD PTR [rsp+0x100],rax
  40cbc9:	call   408130 <__swc_fn_7069e055_000051_e072b516>
  40cbce:	mov    rax,QWORD PTR [rsp+0x100]
  40cbd6:	mov    rcx,QWORD PTR [r14]
  40cbd9:	mov    QWORD PTR [r13+0x0],rcx
  40cbdd:	mov    QWORD PTR [r14],r13
  40cbe0:	sub    DWORD PTR [r14+0x28],0x1
  40cbe5:	jne    40cc02 <__swc_fn_7069e055_000070_97813b89+0x192>
  40cbe7:	mov    rcx,r12
  40cbea:	mov    rdx,rax
  40cbed:	mov    r8,r14
  40cbf0:	call   40c860 <__swc_fn_7069e055_000055_2e3450f7>
  40cbf5:	jmp    40cc02 <__swc_fn_7069e055_000070_97813b89+0x192>
  40cbf7:	mov    rcx,r14
  40cbfa:	mov    rdx,r13
  40cbfd:	call   40f030 <__swc_fn_7069e055_000014_524c1f23>
  40cc02:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40cc0b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  40cc14:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40cc1d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  40cc26:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40cc2f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  40cc38:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  40cc41:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40cc4a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  40cc53:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40cc5c:	add    rsp,0x1b0
  40cc63:	pop    rsi
  40cc64:	pop    rdi
  40cc65:	pop    r14
  40cc67:	pop    r13
  40cc69:	pop    r12
  40cc6b:	ret
  40cc6c:	add    BYTE PTR [rax],al
	...

000000000040cc70 <__swc_fn_7069e055_000073_9c99bf04>:
  40cc70:	push   rsi
  40cc71:	mov    rsi,rcx
  40cc74:	call   40c230 <__swc_fn_7069e055_000040_eb6108f2>
  40cc79:	test   al,al
  40cc7b:	jne    40cc7f <__swc_fn_7069e055_000073_9c99bf04+0xf>
  40cc7d:	pop    rsi
  40cc7e:	ret
  40cc7f:	lea    rax,[rip+0x175ba]        # 424240 <__swc_bss_base_7069e055+0x200>
  40cc86:	cmp    rsi,rax
  40cc89:	jne    40cc8d <__swc_fn_7069e055_000073_9c99bf04+0x1d>
  40cc8b:	pop    rsi
  40cc8c:	ret
  40cc8d:	mov    rcx,rsi
  40cc90:	call   40e380 <__swc_fn_7069e055_000139_86bb0f90>
  40cc95:	mov    rcx,rsi
  40cc98:	call   408900 <__swc_fn_7069e055_000072_61e60aab>
  40cc9d:	mov    rcx,rsi
  40cca0:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40cca5:	pop    rsi
  40cca6:	ret
	...

000000000040ccb0 <__swc_fn_7069e055_000076_15bd096c>:
  40ccb0:	sub    rsp,0x8
  40ccb4:	call   408650 <__swc_fn_7069e055_000069_7130736e>
  40ccb9:	add    rsp,0x8
  40ccbd:	ret
	...

000000000040ccc0 <__swc_fn_7069e055_000079_a5fd3362>:
  40ccc0:	push   rsi
  40ccc1:	mov    rsi,rdx
  40ccc4:	call   408900 <__swc_fn_7069e055_000072_61e60aab>
  40ccc9:	mov    QWORD PTR [rsi+0x40],0x0
  40ccd1:	pop    rsi
  40ccd2:	ret
	...

000000000040cce0 <__swc_fn_7069e055_000082_63a67586>:
  40cce0:	mov    r8,rcx
  40cce3:	mov    rcx,QWORD PTR [rcx]
  40cce6:	cs nop WORD PTR [rax+rax*1+0x0]
  40ccf0:	mov    r9,rcx
  40ccf3:	sub    r9,rdx
  40ccf6:	mov    rax,rcx
  40ccf9:	lock cmpxchg QWORD PTR [r8],r9
  40ccfe:	cmp    rax,rcx
  40cd01:	je     40cd08 <__swc_fn_7069e055_000082_63a67586+0x28>
  40cd03:	mov    rcx,rax
  40cd06:	jmp    40ccf0 <__swc_fn_7069e055_000082_63a67586+0x10>
  40cd08:	mov    rax,rcx
  40cd0b:	ret
  40cd0c:	add    BYTE PTR [rax],al
	...

000000000040cd10 <__swc_fn_7069e055_000085_c618ff58>:
  40cd10:	vxorps xmm0,xmm0,xmm0
  40cd14:	vmovups XMMWORD PTR [rcx],xmm0
  40cd18:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40cd1d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cd22:	ret
	...

000000000040cd30 <__swc_fn_7069e055_000088_0d280354>:
  40cd30:	push   rsi
  40cd31:	push   rdi
  40cd32:	push   r12
  40cd34:	push   r13
  40cd36:	push   r15
  40cd38:	push   r14
  40cd3a:	push   rbx
  40cd3b:	sub    rsp,0x60
  40cd3f:	mov    QWORD PTR [rsp+0x28],r11
  40cd44:	mov    rsi,rcx
  40cd47:	mov    rdi,rdx
  40cd4a:	mov    QWORD PTR [rsp+0x30],rdx
  40cd4f:	mov    r12,r8
  40cd52:	mov    r13,r9
  40cd55:	mov    QWORD PTR [rsp+0x38],r10
  40cd5a:	xor    r8d,r8d
  40cd5d:	call   40d080 <__swc_fn_7069e055_000094_63c1827b>
  40cd62:	test   al,al
  40cd64:	je     40cd79 <__swc_fn_7069e055_000088_0d280354+0x49>
  40cd66:	mov    rax,r12
  40cd69:	add    rsp,0x60
  40cd6d:	pop    rbx
  40cd6e:	pop    r14
  40cd70:	pop    r15
  40cd72:	pop    r13
  40cd74:	pop    r12
  40cd76:	pop    rdi
  40cd77:	pop    rsi
  40cd78:	ret
  40cd79:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40cd7e:	je     40cd92 <__swc_fn_7069e055_000088_0d280354+0x62>
  40cd80:	xor    eax,eax
  40cd82:	add    rsp,0x60
  40cd86:	pop    rbx
  40cd87:	pop    r14
  40cd89:	pop    r15
  40cd8b:	pop    r13
  40cd8d:	pop    r12
  40cd8f:	pop    rdi
  40cd90:	pop    rsi
  40cd91:	ret
  40cd92:	mov    r15,rdi
  40cd95:	mov    QWORD PTR [rsp+0x40],rdi
  40cd9a:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40cd9f:	jne    40ce0f <__swc_fn_7069e055_000088_0d280354+0xdf>
  40cda1:	mov    r14,QWORD PTR [r15+0xb8]
  40cda8:	mov    rax,QWORD PTR [r15+0xc0]
  40cdaf:	mov    r15,rax
  40cdb2:	xor    edi,edi
  40cdb4:	test   r15,r15
  40cdb7:	je     40ce0f <__swc_fn_7069e055_000088_0d280354+0xdf>
  40cdb9:	nop    DWORD PTR [rax+0x0]
  40cdc0:	lea    rbx,[rdi*8+0x0]
  40cdc8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  40cdcd:	mov    rcx,rax
  40cdd0:	mov    rdx,rsi
  40cdd3:	xor    r8d,r8d
  40cdd6:	call   40d080 <__swc_fn_7069e055_000094_63c1827b>
  40cddb:	test   al,al
  40cddd:	je     40ce05 <__swc_fn_7069e055_000088_0d280354+0xd5>
  40cddf:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  40cde4:	test   rax,rax
  40cde7:	je     40ce05 <__swc_fn_7069e055_000088_0d280354+0xd5>
  40cde9:	test   r13,r13
  40cdec:	je     40cdf2 <__swc_fn_7069e055_000088_0d280354+0xc2>
  40cdee:	mov    QWORD PTR [r13+0x8],rax
  40cdf2:	mov    rax,r12
  40cdf5:	add    rsp,0x60
  40cdf9:	pop    rbx
  40cdfa:	pop    r14
  40cdfc:	pop    r15
  40cdfe:	pop    r13
  40ce00:	pop    r12
  40ce02:	pop    rdi
  40ce03:	pop    rsi
  40ce04:	ret
  40ce05:	add    rdi,0x1
  40ce09:	sub    r15,0x1
  40ce0d:	jne    40cdc0 <__swc_fn_7069e055_000088_0d280354+0x90>
  40ce0f:	test   r12,r12
  40ce12:	jne    40ce26 <__swc_fn_7069e055_000088_0d280354+0xf6>
  40ce14:	xor    eax,eax
  40ce16:	add    rsp,0x60
  40ce1a:	pop    rbx
  40ce1b:	pop    r14
  40ce1d:	pop    r15
  40ce1f:	pop    r13
  40ce21:	pop    r12
  40ce23:	pop    rdi
  40ce24:	pop    rsi
  40ce25:	ret
  40ce26:	mov    rbx,QWORD PTR [rsp+0x28]
  40ce2b:	mov    rdi,QWORD PTR [rsp+0x30]
  40ce30:	mov    rax,rbx
  40ce33:	test   rax,rax
  40ce36:	je     40ce66 <__swc_fn_7069e055_000088_0d280354+0x136>
  40ce38:	nop    DWORD PTR [rax+rax*1+0x0]
  40ce40:	cmp    QWORD PTR [rax+0x8],r12
  40ce44:	jne    40ce5d <__swc_fn_7069e055_000088_0d280354+0x12d>
  40ce46:	cmp    QWORD PTR [rax],rdi
  40ce49:	jne    40ce5d <__swc_fn_7069e055_000088_0d280354+0x12d>
  40ce4b:	xor    eax,eax
  40ce4d:	add    rsp,0x60
  40ce51:	pop    rbx
  40ce52:	pop    r14
  40ce54:	pop    r15
  40ce56:	pop    r13
  40ce58:	pop    r12
  40ce5a:	pop    rdi
  40ce5b:	pop    rsi
  40ce5c:	ret
  40ce5d:	mov    rax,QWORD PTR [rax+0x10]
  40ce61:	test   rax,rax
  40ce64:	jne    40ce40 <__swc_fn_7069e055_000088_0d280354+0x110>
  40ce66:	lea    r14,[rsp+0x8]
  40ce6b:	mov    QWORD PTR [rsp+0x48],r14
  40ce70:	mov    QWORD PTR [rsp+0x8],rdi
  40ce75:	mov    QWORD PTR [rsp+0x10],r12
  40ce7a:	mov    QWORD PTR [rsp+0x18],rbx
  40ce7f:	mov    r15,QWORD PTR [rsp+0x40]
  40ce84:	mov    rbx,QWORD PTR [r15+0x98]
  40ce8b:	mov    rax,QWORD PTR [r15+0xa0]
  40ce92:	mov    rdi,rax
  40ce95:	mov    r15,QWORD PTR [rsp+0x38]
  40ce9a:	xor    r14d,r14d
  40ce9d:	test   rdi,rdi
  40cea0:	je     40cf4a <__swc_fn_7069e055_000088_0d280354+0x21a>
  40cea6:	cs nop WORD PTR [rax+rax*1+0x0]
  40ceb0:	mov    QWORD PTR [rsp+0x50],rdi
  40ceb5:	lea    rdi,[r14*8+0x0]
  40cebd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  40cec2:	mov    rcx,rax
  40cec5:	call   410b00 <__swc_fn_7069e055_000086_3953ef98>
  40ceca:	test   DWORD PTR [rax+0x28],0x10000
  40ced1:	je     40ced8 <__swc_fn_7069e055_000088_0d280354+0x1a8>
  40ced3:	test   r15b,r15b
  40ced6:	je     40cf31 <__swc_fn_7069e055_000088_0d280354+0x201>
  40ced8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  40cedc:	lea    rdi,[r12+rcx*1]
  40cee0:	cmp    BYTE PTR [rax+0x2c],0x6
  40cee4:	jne    40cef8 <__swc_fn_7069e055_000088_0d280354+0x1c8>
  40cee6:	mov    rax,QWORD PTR [rax+0x40]
  40ceea:	mov    rcx,rax
  40ceed:	call   410b00 <__swc_fn_7069e055_000086_3953ef98>
  40cef2:	mov    rcx,QWORD PTR [rdi]
  40cef5:	mov    rdi,rcx
  40cef8:	test   rdi,rdi
  40cefb:	je     40cf31 <__swc_fn_7069e055_000088_0d280354+0x201>
  40cefd:	mov    rcx,rsi
  40cf00:	mov    rdx,rax
  40cf03:	mov    r8,rdi
  40cf06:	mov    r9,r13
  40cf09:	mov    al,r15b
  40cf0c:	mov    r10,rax
  40cf0f:	mov    rdi,QWORD PTR [rsp+0x48]
  40cf14:	mov    r11,rdi
  40cf17:	call   40cd30 <__swc_fn_7069e055_000088_0d280354>
  40cf1c:	test   rax,rax
  40cf1f:	je     40cf31 <__swc_fn_7069e055_000088_0d280354+0x201>
  40cf21:	add    rsp,0x60
  40cf25:	pop    rbx
  40cf26:	pop    r14
  40cf28:	pop    r15
  40cf2a:	pop    r13
  40cf2c:	pop    r12
  40cf2e:	pop    rdi
  40cf2f:	pop    rsi
  40cf30:	ret
  40cf31:	add    r14,0x1
  40cf35:	mov    rax,QWORD PTR [rsp+0x50]
  40cf3a:	sub    rax,0x1
  40cf3e:	mov    rdi,rax
  40cf41:	test   rax,rax
  40cf44:	jne    40ceb0 <__swc_fn_7069e055_000088_0d280354+0x180>
  40cf4a:	xor    eax,eax
  40cf4c:	add    rsp,0x60
  40cf50:	pop    rbx
  40cf51:	pop    r14
  40cf53:	pop    r15
  40cf55:	pop    r13
  40cf57:	pop    r12
  40cf59:	pop    rdi
  40cf5a:	pop    rsi
  40cf5b:	ret
  40cf5c:	add    BYTE PTR [rax],al
	...

000000000040cf60 <__swc_fn_7069e055_000091_c1c9085b>:
  40cf60:	push   rsi
  40cf61:	push   rdi
  40cf62:	push   r12
  40cf64:	push   r13
  40cf66:	push   r14
  40cf68:	push   r15
  40cf6a:	sub    rsp,0x78
  40cf6e:	mov    rsi,r10
  40cf71:	mov    QWORD PTR [rsp+0x68],r10
  40cf76:	mov    rdi,rcx
  40cf79:	mov    r12,rdx
  40cf7c:	mov    r13,r8
  40cf7f:	mov    r14,r9
  40cf82:	xor    r8d,r8d
  40cf85:	call   40d080 <__swc_fn_7069e055_000094_63c1827b>
  40cf8a:	test   al,al
  40cf8c:	je     40cfb5 <__swc_fn_7069e055_000091_c1c9085b+0x55>
  40cf8e:	mov    rcx,r14
  40cf91:	mov    rdx,r12
  40cf94:	mov    r8,r13
  40cf97:	mov    r9,rsi
  40cf9a:	call   408d60 <__swc_fn_7069e055_000090_23214800>
  40cf9f:	test   al,al
  40cfa1:	je     40cfb5 <__swc_fn_7069e055_000091_c1c9085b+0x55>
  40cfa3:	mov    rax,r13
  40cfa6:	add    rsp,0x78
  40cfaa:	pop    r15
  40cfac:	pop    r14
  40cfae:	pop    r13
  40cfb0:	pop    r12
  40cfb2:	pop    rdi
  40cfb3:	pop    rsi
  40cfb4:	ret
  40cfb5:	cmp    BYTE PTR [r12+0x2c],0xe
  40cfbb:	je     40cfce <__swc_fn_7069e055_000091_c1c9085b+0x6e>
  40cfbd:	xor    eax,eax
  40cfbf:	add    rsp,0x78
  40cfc3:	pop    r15
  40cfc5:	pop    r14
  40cfc7:	pop    r13
  40cfc9:	pop    r12
  40cfcb:	pop    rdi
  40cfcc:	pop    rsi
  40cfcd:	ret
  40cfce:	mov    r15,QWORD PTR [r12+0x98]
  40cfd6:	mov    rax,QWORD PTR [r12+0xa0]
  40cfde:	mov    r12,rax
  40cfe1:	xor    esi,esi
  40cfe3:	test   r12,r12
  40cfe6:	je     40d059 <__swc_fn_7069e055_000091_c1c9085b+0xf9>
  40cfe8:	nop    DWORD PTR [rax+rax*1+0x0]
  40cff0:	mov    QWORD PTR [rsp+0x70],r12
  40cff5:	lea    r12,[rsi*8+0x0]
  40cffd:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  40d002:	mov    rcx,rax
  40d005:	call   410b00 <__swc_fn_7069e055_000086_3953ef98>
  40d00a:	cmp    BYTE PTR [rax+0x2c],0xe
  40d00e:	jne    40d044 <__swc_fn_7069e055_000091_c1c9085b+0xe4>
  40d010:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  40d015:	lea    r8,[r13+rcx*1+0x0]
  40d01a:	mov    rcx,rdi
  40d01d:	mov    rdx,rax
  40d020:	mov    r9,r14
  40d023:	mov    r12,QWORD PTR [rsp+0x68]
  40d028:	mov    r10,r12
  40d02b:	call   40cf60 <__swc_fn_7069e055_000091_c1c9085b>
  40d030:	test   rax,rax
  40d033:	je     40d044 <__swc_fn_7069e055_000091_c1c9085b+0xe4>
  40d035:	add    rsp,0x78
  40d039:	pop    r15
  40d03b:	pop    r14
  40d03d:	pop    r13
  40d03f:	pop    r12
  40d041:	pop    rdi
  40d042:	pop    rsi
  40d043:	ret
  40d044:	add    rsi,0x1
  40d048:	mov    rax,QWORD PTR [rsp+0x70]
  40d04d:	sub    rax,0x1
  40d051:	mov    r12,rax
  40d054:	test   rax,rax
  40d057:	jne    40cff0 <__swc_fn_7069e055_000091_c1c9085b+0x90>
  40d059:	xor    eax,eax
  40d05b:	add    rsp,0x78
  40d05f:	pop    r15
  40d061:	pop    r14
  40d063:	pop    r13
  40d065:	pop    r12
  40d067:	pop    rdi
  40d068:	pop    rsi
  40d069:	ret
	...

000000000040d080 <__swc_fn_7069e055_000094_63c1827b>:
  40d080:	push   rbx
  40d081:	push   rsi
  40d082:	push   rdi
  40d083:	push   r12
  40d085:	push   r13
  40d087:	push   r14
  40d089:	push   r15
  40d08b:	sub    rsp,0x120
  40d092:	mov    rbx,r8
  40d095:	mov    rsi,rdx
  40d098:	test   rcx,rcx
  40d09b:	jne    40d0ba <__swc_fn_7069e055_000094_63c1827b+0x3a>
  40d09d:	test   rsi,rsi
  40d0a0:	jne    40d0ba <__swc_fn_7069e055_000094_63c1827b+0x3a>
  40d0a2:	mov    eax,0x1
  40d0a7:	add    rsp,0x120
  40d0ae:	pop    r15
  40d0b0:	pop    r14
  40d0b2:	pop    r13
  40d0b4:	pop    r12
  40d0b6:	pop    rdi
  40d0b7:	pop    rsi
  40d0b8:	pop    rbx
  40d0b9:	ret
  40d0ba:	test   rcx,rcx
  40d0bd:	je     40d0c4 <__swc_fn_7069e055_000094_63c1827b+0x44>
  40d0bf:	test   rsi,rsi
  40d0c2:	jne    40d0d9 <__swc_fn_7069e055_000094_63c1827b+0x59>
  40d0c4:	xor    eax,eax
  40d0c6:	add    rsp,0x120
  40d0cd:	pop    r15
  40d0cf:	pop    r14
  40d0d1:	pop    r13
  40d0d3:	pop    r12
  40d0d5:	pop    rdi
  40d0d6:	pop    rsi
  40d0d7:	pop    rbx
  40d0d8:	ret
  40d0d9:	call   410b00 <__swc_fn_7069e055_000086_3953ef98>
  40d0de:	mov    rdi,rax
  40d0e1:	mov    rcx,rsi
  40d0e4:	call   410b00 <__swc_fn_7069e055_000086_3953ef98>
  40d0e9:	test   bl,0x1
  40d0ec:	je     40d12a <__swc_fn_7069e055_000094_63c1827b+0xaa>
  40d0ee:	rex cmp BYTE PTR [rdi+0x2c],0x6
  40d0f3:	jne    40d12a <__swc_fn_7069e055_000094_63c1827b+0xaa>
  40d0f5:	mov    ecx,DWORD PTR [rdi+0x28]
  40d0f8:	test   ecx,0x1000
  40d0fe:	je     40d12a <__swc_fn_7069e055_000094_63c1827b+0xaa>
  40d100:	test   ecx,0x10000
  40d106:	je     40d12a <__swc_fn_7069e055_000094_63c1827b+0xaa>
  40d108:	mov    rcx,QWORD PTR [rdi+0x40]
  40d10c:	mov    rdx,rax
  40d10f:	mov    r8d,ebx
  40d112:	call   40d080 <__swc_fn_7069e055_000094_63c1827b>
  40d117:	add    rsp,0x120
  40d11e:	pop    r15
  40d120:	pop    r14
  40d122:	pop    r13
  40d124:	pop    r12
  40d126:	pop    rdi
  40d127:	pop    rsi
  40d128:	pop    rbx
  40d129:	ret
  40d12a:	mov    cl,BYTE PTR [rax+0x2c]
  40d12d:	rex cmp BYTE PTR [rdi+0x2c],cl
  40d131:	jne    40d13b <__swc_fn_7069e055_000094_63c1827b+0xbb>
  40d133:	mov    ecx,DWORD PTR [rax+0x20]
  40d136:	cmp    DWORD PTR [rdi+0x20],ecx
  40d139:	je     40d150 <__swc_fn_7069e055_000094_63c1827b+0xd0>
  40d13b:	xor    eax,eax
  40d13d:	add    rsp,0x120
  40d144:	pop    r15
  40d146:	pop    r14
  40d148:	pop    r13
  40d14a:	pop    r12
  40d14c:	pop    rdi
  40d14d:	pop    rsi
  40d14e:	pop    rbx
  40d14f:	ret
  40d150:	mov    ecx,DWORD PTR [rdi+0x28]
  40d153:	and    ecx,0xffb5ffff
  40d159:	mov    edx,DWORD PTR [rax+0x28]
  40d15c:	and    edx,0xffb5ffff
  40d162:	cmp    ecx,edx
  40d164:	je     40d17b <__swc_fn_7069e055_000094_63c1827b+0xfb>
  40d166:	xor    eax,eax
  40d168:	add    rsp,0x120
  40d16f:	pop    r15
  40d171:	pop    r14
  40d173:	pop    r13
  40d175:	pop    r12
  40d177:	pop    rdi
  40d178:	pop    rsi
  40d179:	pop    rbx
  40d17a:	ret
  40d17b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  40d180:	jne    40d1d5 <__swc_fn_7069e055_000094_63c1827b+0x155>
  40d182:	mov    cl,BYTE PTR [rax+0x40]
  40d185:	rex cmp BYTE PTR [rdi+0x40],cl
  40d189:	je     40d1a0 <__swc_fn_7069e055_000094_63c1827b+0x120>
  40d18b:	xor    eax,eax
  40d18d:	add    rsp,0x120
  40d194:	pop    r15
  40d196:	pop    r14
  40d198:	pop    r13
  40d19a:	pop    r12
  40d19c:	pop    rdi
  40d19d:	pop    rsi
  40d19e:	pop    rbx
  40d19f:	ret
  40d1a0:	rex cmp BYTE PTR [rdi+0x40],0xd
  40d1a5:	je     40d1bd <__swc_fn_7069e055_000094_63c1827b+0x13d>
  40d1a7:	rex cmp BYTE PTR [rdi+0x40],0xf
  40d1ac:	sete   cl
  40d1af:	je     40d1b9 <__swc_fn_7069e055_000094_63c1827b+0x139>
  40d1b1:	rex cmp BYTE PTR [rdi+0x40],0xe
  40d1b6:	sete   cl
  40d1b9:	test   cl,cl
  40d1bb:	je     40d1d5 <__swc_fn_7069e055_000094_63c1827b+0x155>
  40d1bd:	mov    eax,0x1
  40d1c2:	add    rsp,0x120
  40d1c9:	pop    r15
  40d1cb:	pop    r14
  40d1cd:	pop    r13
  40d1cf:	pop    r12
  40d1d1:	pop    rdi
  40d1d2:	pop    rsi
  40d1d3:	pop    rbx
  40d1d4:	ret
  40d1d5:	test   DWORD PTR [rdi+0x28],0x200200
  40d1dc:	je     40d38f <__swc_fn_7069e055_000094_63c1827b+0x30f>
  40d1e2:	mov    rsi,QWORD PTR [rdi+0x88]
  40d1e9:	mov    rdi,QWORD PTR [rdi+0x90]
  40d1f0:	mov    r12,QWORD PTR [rax+0x88]
  40d1f7:	mov    rax,QWORD PTR [rax+0x90]
  40d1fe:	cmp    rdi,rax
  40d201:	je     40d218 <__swc_fn_7069e055_000094_63c1827b+0x198>
  40d203:	xor    eax,eax
  40d205:	add    rsp,0x120
  40d20c:	pop    r15
  40d20e:	pop    r14
  40d210:	pop    r13
  40d212:	pop    r12
  40d214:	pop    rdi
  40d215:	pop    rsi
  40d216:	pop    rbx
  40d217:	ret
  40d218:	test   rsi,rsi
  40d21b:	je     40d222 <__swc_fn_7069e055_000094_63c1827b+0x1a2>
  40d21d:	test   r12,r12
  40d220:	jne    40d23a <__swc_fn_7069e055_000094_63c1827b+0x1ba>
  40d222:	mov    eax,0x1
  40d227:	add    rsp,0x120
  40d22e:	pop    r15
  40d230:	pop    r14
  40d232:	pop    r13
  40d234:	pop    r12
  40d236:	pop    rdi
  40d237:	pop    rsi
  40d238:	pop    rbx
  40d239:	ret
  40d23a:	xor    r13d,r13d
  40d23d:	test   rdi,rdi
  40d240:	jbe    40d377 <__swc_fn_7069e055_000094_63c1827b+0x2f7>
  40d246:	lea    r14,[rsp+0x78]
  40d24b:	lea    r15,[rsp+0xb8]
  40d253:	cs nop WORD PTR [rax+rax*1+0x0]
  40d25d:	cs nop WORD PTR [rax+rax*1+0x0]
  40d267:	nop    WORD PTR [rax+rax*1+0x0]
  40d270:	lea    rax,[r13*8+0x0]
  40d278:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40d27d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40d283:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  40d289:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40d292:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  40d298:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40d2a1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  40d2a7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40d2b0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  40d2b6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40d2bf:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  40d2c6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  40d2cf:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  40d2d6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  40d2df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  40d2e6:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40d2ef:	xor    al,al
  40d2f1:	rex test BYTE PTR [rsp+0xb0],0x1
  40d2fa:	je     40d301 <__swc_fn_7069e055_000094_63c1827b+0x281>
  40d2fc:	mov    eax,0x1
  40d301:	rex test BYTE PTR [rsp+0xf0],0x1
  40d30a:	je     40d311 <__swc_fn_7069e055_000094_63c1827b+0x291>
  40d30c:	mov    eax,0x1
  40d311:	test   al,al
  40d313:	jne    40d339 <__swc_fn_7069e055_000094_63c1827b+0x2b9>
  40d315:	mov    rcx,r14
  40d318:	mov    rdx,r15
  40d31b:	call   40e890 <__swc_fn_7069e055_000151_6fb05988>
  40d320:	test   al,al
  40d322:	jne    40d339 <__swc_fn_7069e055_000094_63c1827b+0x2b9>
  40d324:	xor    eax,eax
  40d326:	add    rsp,0x120
  40d32d:	pop    r15
  40d32f:	pop    r14
  40d331:	pop    r13
  40d333:	pop    r12
  40d335:	pop    rdi
  40d336:	pop    rsi
  40d337:	pop    rbx
  40d338:	ret
  40d339:	mov    rcx,QWORD PTR [rsp+0x88]
  40d341:	mov    rdx,QWORD PTR [rsp+0xc8]
  40d349:	mov    r8d,ebx
  40d34c:	call   40d080 <__swc_fn_7069e055_000094_63c1827b>
  40d351:	test   al,al
  40d353:	jne    40d36a <__swc_fn_7069e055_000094_63c1827b+0x2ea>
  40d355:	xor    eax,eax
  40d357:	add    rsp,0x120
  40d35e:	pop    r15
  40d360:	pop    r14
  40d362:	pop    r13
  40d364:	pop    r12
  40d366:	pop    rdi
  40d367:	pop    rsi
  40d368:	pop    rbx
  40d369:	ret
  40d36a:	add    r13,0x1
  40d36e:	cmp    r13,rdi
  40d371:	jb     40d270 <__swc_fn_7069e055_000094_63c1827b+0x1f0>
  40d377:	mov    eax,0x1
  40d37c:	add    rsp,0x120
  40d383:	pop    r15
  40d385:	pop    r14
  40d387:	pop    r13
  40d389:	pop    r12
  40d38b:	pop    rdi
  40d38c:	pop    rsi
  40d38d:	pop    rbx
  40d38e:	ret
  40d38f:	test   bl,0x2
  40d392:	je     40d3b4 <__swc_fn_7069e055_000094_63c1827b+0x334>
  40d394:	lea    rcx,[rdi+0x10]
  40d398:	lea    rdx,[rax+0x10]
  40d39c:	call   40e890 <__swc_fn_7069e055_000151_6fb05988>
  40d3a1:	add    rsp,0x120
  40d3a8:	pop    r15
  40d3aa:	pop    r14
  40d3ac:	pop    r13
  40d3ae:	pop    r12
  40d3b0:	pop    rdi
  40d3b1:	pop    rsi
  40d3b2:	pop    rbx
  40d3b3:	ret
  40d3b4:	mov    rcx,rdi
  40d3b7:	mov    rdx,rax
  40d3ba:	call   40e890 <__swc_fn_7069e055_000151_6fb05988>
  40d3bf:	add    rsp,0x120
  40d3c6:	pop    r15
  40d3c8:	pop    r14
  40d3ca:	pop    r13
  40d3cc:	pop    r12
  40d3ce:	pop    rdi
  40d3cf:	pop    rsi
  40d3d0:	pop    rbx
  40d3d1:	ret
	...

000000000040d3e0 <__swc_fn_7069e055_000097_4185993f>:
  40d3e0:	push   rbx
  40d3e1:	mov    rbx,rcx
  40d3e4:	call   410c30 <__swc_fn_7069e055_000095_ad13d15c>
  40d3e9:	movzx  r11d,al
  40d3ed:	mov    r8b,r11b
  40d3f0:	test   r8b,r8b
  40d3f3:	jne    40d40d <__swc_fn_7069e055_000097_4185993f+0x2d>
  40d3f5:	mov    r11d,0x1
  40d3fb:	mov    r10,rbx
  40d3fe:	mov    r9,r11
  40d401:	and    r10,r11
  40d404:	test   r10,r10
  40d407:	setne  dl
  40d40a:	mov    r8b,dl
  40d40d:	mov    r10b,r8b
  40d410:	test   r10b,r10b
  40d413:	je     40d417 <__swc_fn_7069e055_000097_4185993f+0x37>
  40d415:	pop    rbx
  40d416:	ret
  40d417:	call   40a260 <__swc_fn_7069e055_000141_519fdf94>
  40d41c:	movzx  r10d,al
  40d420:	test   r10b,r10b
  40d423:	je     40d427 <__swc_fn_7069e055_000097_4185993f+0x47>
  40d425:	pop    rbx
  40d426:	ret
  40d427:	lea    r10,[rip+0x5eba]        # 4132e8 <__swc_rdata_base_7069e055+0x1d8>
  40d42e:	mov    rax,r10
  40d431:	mov    rcx,rax
  40d434:	call   409d90 <__swc_fn_7069e055_000120_2648f149>
  40d439:	call   4114b0 <__swc_fn_7069e055_000122_be2e2f68>
  40d43e:	pop    rbx
  40d43f:	ret

000000000040d440 <__swc_fn_7069e055_000100_d4bdcaa4>:
  40d440:	push   rbx
  40d441:	sub    rsp,0x70
  40d445:	vxorps xmm0,xmm0,xmm0
  40d449:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40d44f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40d455:	vzeroupper
  40d458:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40d45e:	mov    QWORD PTR [rsp+0x48],rdx
  40d463:	mov    rax,r8
  40d466:	cmp    r8,0x1
  40d46a:	mov    edx,0x1
  40d46f:	cmovb  rax,rdx
  40d473:	mov    QWORD PTR [rsp+0x50],rax
  40d478:	mov    rbx,QWORD PTR [rcx+0x8]
  40d47c:	mov    rbx,QWORD PTR [rbx+0x18]
  40d480:	mov    rcx,QWORD PTR [rcx]
  40d483:	lea    rdx,[rsp+0x8]
  40d488:	call   rbx
  40d48a:	add    rsp,0x70
  40d48e:	pop    rbx
  40d48f:	ret

000000000040d490 <__swc_fn_7069e055_000103_2fdd2c61>:
  40d490:	push   rbx
  40d491:	push   rsi
  40d492:	push   rdi
  40d493:	sub    rsp,0x30
  40d497:	mov    rbx,rcx
  40d49a:	test   rcx,rcx
  40d49d:	je     40d4b2 <__swc_fn_7069e055_000103_2fdd2c61+0x22>
  40d49f:	mov    rcx,rbx
  40d4a2:	mov    edx,0x1
  40d4a7:	call   40cce0 <__swc_fn_7069e055_000082_63a67586>
  40d4ac:	cmp    rax,0x1
  40d4b0:	je     40d4ba <__swc_fn_7069e055_000103_2fdd2c61+0x2a>
  40d4b2:	add    rsp,0x30
  40d4b6:	pop    rdi
  40d4b7:	pop    rsi
  40d4b8:	pop    rbx
  40d4b9:	ret
  40d4ba:	lea    rsi,[rsp+0x8]
  40d4bf:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40d4c4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d4ca:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  40d4cf:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40d4d5:	mov    rax,QWORD PTR [rsp+0x20]
  40d4da:	test   rax,rax
  40d4dd:	je     40d4f3 <__swc_fn_7069e055_000103_2fdd2c61+0x63>
  40d4df:	test   DWORD PTR [rax+0x28],0x400000
  40d4e6:	je     40d4f3 <__swc_fn_7069e055_000103_2fdd2c61+0x63>
  40d4e8:	mov    rcx,QWORD PTR [rax+0x30]
  40d4ec:	test   rcx,rcx
  40d4ef:	cmovne rax,rcx
  40d4f3:	mov    edi,DWORD PTR [rax+0x20]
  40d4f6:	lea    rcx,[rsp+0x18]
  40d4fb:	call   410e10 <__swc_fn_7069e055_000104_3c3b96fb>
  40d500:	mov    rcx,rsi
  40d503:	mov    rdx,QWORD PTR [rsp+0x18]
  40d508:	mov    r8,rdi
  40d50b:	call   40d440 <__swc_fn_7069e055_000100_d4bdcaa4>
  40d510:	mov    rcx,QWORD PTR [rbx+0x28]
  40d514:	call   409340 <__swc_fn_7069e055_000102_e34f54dc>
  40d519:	mov    rcx,rsi
  40d51c:	mov    rdx,rbx
  40d51f:	mov    r8d,0x30
  40d525:	call   40d440 <__swc_fn_7069e055_000100_d4bdcaa4>
  40d52a:	add    rsp,0x30
  40d52e:	pop    rdi
  40d52f:	pop    rsi
  40d530:	pop    rbx
  40d531:	ret
	...

000000000040d540 <__swc_fn_7069e055_000106_ffe51047>:
  40d540:	push   rbp
  40d541:	push   rbx
  40d542:	push   rsi
  40d543:	push   rdi
  40d544:	push   r12
  40d546:	push   r13
  40d548:	push   r14
  40d54a:	push   r15
  40d54c:	sub    rsp,0x500
  40d553:	mov    rbp,rsp
  40d556:	mov    rbx,rsp
  40d559:	mov    rsi,rdx
  40d55c:	mov    rdi,rcx
  40d55f:	mov    rcx,QWORD PTR [rip+0x16ada]        # 424040 <__swc_bss_base_7069e055>
  40d566:	test   rcx,rcx
  40d569:	jne    40d583 <__swc_fn_7069e055_000106_ffe51047+0x43>
  40d56b:	sub    rsp,0x8
  40d56f:	call   40ec80 <__swc_fn_7069e055_000169_994c8876>
  40d574:	add    rsp,0x8
  40d578:	lea    rcx,[rax+0x1]
  40d57c:	mov    QWORD PTR [rip+0x16abd],rcx        # 424040 <__swc_bss_base_7069e055>
  40d583:	dec    rcx
  40d586:	sub    rsp,0x8
  40d58a:	call   40bb40 <__swc_fn_7069e055_000171_360af05d>
  40d58f:	add    rsp,0x8
  40d593:	mov    r12,rax
  40d596:	mov    QWORD PTR [rsp+0x4f0],rax
  40d59e:	lea    rax,[rip+0x5e83]        # 413428 <__swc_rdata_base_7069e055+0x318>
  40d5a5:	sub    rsp,0x20
  40d5a9:	mov    rcx,rsp
  40d5ac:	mov    QWORD PTR [rcx],rax
  40d5af:	lea    r13,[rip+0x5b7a]        # 413130 <__swc_rdata_base_7069e055+0x20>
  40d5b6:	mov    QWORD PTR [rcx+0x8],r13
  40d5ba:	mov    QWORD PTR [rcx+0x10],rsp
  40d5be:	mov    QWORD PTR [rcx+0x18],0x1
  40d5c6:	lea    rcx,[rsp+0x10]
  40d5cb:	sub    rsp,0x8
  40d5cf:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40d5d4:	add    rsp,0x8
  40d5d8:	add    rsp,0x20
  40d5dc:	lea    rax,[rip+0x5e55]        # 413438 <__swc_rdata_base_7069e055+0x328>
  40d5e3:	sub    rsp,0x20
  40d5e7:	mov    rcx,rsp
  40d5ea:	mov    QWORD PTR [rcx],rax
  40d5ed:	mov    QWORD PTR [rcx+0x8],r13
  40d5f1:	mov    QWORD PTR [rcx+0x10],rsp
  40d5f5:	mov    QWORD PTR [rcx+0x18],0x1
  40d5fd:	lea    rcx,[rsp+0x10]
  40d602:	sub    rsp,0x8
  40d606:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40d60b:	add    rsp,0x8
  40d60f:	add    rsp,0x20
  40d613:	lea    r14,[rip+0x5b06]        # 413120 <__swc_rdata_base_7069e055+0x10>
  40d61a:	sub    rsp,0x50
  40d61e:	mov    rax,rsp
  40d621:	vmovups xmm0,XMMWORD PTR [rip+0x5f47]        # 413570 <__swc_rdata_base_7069e055+0x460>
  40d629:	vmovups XMMWORD PTR [rax],xmm0
  40d62d:	mov    QWORD PTR [rax+0x10],rsp
  40d631:	mov    QWORD PTR [rax+0x18],r13
  40d635:	mov    QWORD PTR [rax+0x20],rdi
  40d639:	lea    rdi,[rip+0x5e08]        # 413448 <__swc_rdata_base_7069e055+0x338>
  40d640:	mov    QWORD PTR [rax+0x28],rdi
  40d644:	mov    QWORD PTR [rax+0x30],r14
  40d648:	mov    QWORD PTR [rax+0x38],r13
  40d64c:	lea    rcx,[rsp+0x10]
  40d651:	mov    QWORD PTR [rax+0x40],rcx
  40d655:	mov    QWORD PTR [rax+0x48],0x3
  40d65d:	lea    rcx,[rsp+0x40]
  40d662:	sub    rsp,0x8
  40d666:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40d66b:	add    rsp,0x8
  40d66f:	add    rsp,0x50
  40d673:	lea    rax,[rip+0x5e16]        # 413490 <__swc_rdata_base_7069e055+0x380>
  40d67a:	sub    rsp,0x20
  40d67e:	mov    rcx,rsp
  40d681:	mov    QWORD PTR [rcx],rax
  40d684:	mov    QWORD PTR [rcx+0x8],r13
  40d688:	mov    QWORD PTR [rcx+0x10],rsp
  40d68c:	mov    QWORD PTR [rcx+0x18],0x1
  40d694:	lea    rcx,[rsp+0x10]
  40d699:	sub    rsp,0x8
  40d69d:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40d6a2:	add    rsp,0x8
  40d6a6:	add    rsp,0x20
  40d6aa:	mov    eax,DWORD PTR [rsi+0x20]
  40d6ad:	mov    ecx,DWORD PTR [rsi+0x24]
  40d6b0:	sub    rsp,0xa0
  40d6b7:	mov    rdx,rsp
  40d6ba:	mov    QWORD PTR [rdx+0x30],rsi
  40d6be:	mov    QWORD PTR [rdx+0x38],rdi
  40d6c2:	vmovups xmm0,XMMWORD PTR [rip+0x5e3e]        # 413508 <__swc_rdata_base_7069e055+0x3f8>
  40d6ca:	vmovups XMMWORD PTR [rdx],xmm0
  40d6ce:	mov    QWORD PTR [rdx+0x40],rsp
  40d6d2:	mov    QWORD PTR [rdx+0x48],r13
  40d6d6:	mov    DWORD PTR [rdx+0x10],eax
  40d6d9:	lea    rax,[rsp+0x10]
  40d6de:	mov    QWORD PTR [rdx+0x50],rax
  40d6e2:	lea    rax,[rip+0x5db7]        # 4134a0 <__swc_rdata_base_7069e055+0x390>
  40d6e9:	mov    QWORD PTR [rdx+0x58],rax
  40d6ed:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  40d6f2:	lea    r8,[rsp+0x18]
  40d6f7:	mov    QWORD PTR [rdx+0x60],r8
  40d6fb:	mov    QWORD PTR [rdx+0x68],r13
  40d6ff:	mov    DWORD PTR [rdx+0x28],ecx
  40d702:	lea    rcx,[rdx+0x28]
  40d706:	mov    QWORD PTR [rdx+0x70],rcx
  40d70a:	mov    QWORD PTR [rdx+0x78],rax
  40d70e:	mov    QWORD PTR [rdx+0x80],r14
  40d715:	mov    QWORD PTR [rdx+0x88],r13
  40d71c:	lea    rax,[rdx+0x30]
  40d720:	mov    QWORD PTR [rdx+0x90],rax
  40d727:	mov    QWORD PTR [rdx+0x98],0x6
  40d732:	lea    rcx,[rdx+0x90]
  40d739:	sub    rsp,0x8
  40d73d:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40d742:	add    rsp,0x8
  40d746:	add    rsp,0xa0
  40d74d:	sub    rsp,0x20
  40d751:	mov    rax,rsp
  40d754:	mov    QWORD PTR [rax],r14
  40d757:	mov    QWORD PTR [rax+0x8],r13
  40d75b:	mov    QWORD PTR [rax+0x10],rsp
  40d75f:	mov    QWORD PTR [rax+0x18],0x1
  40d767:	lea    rcx,[rsp+0x10]
  40d76c:	sub    rsp,0x8
  40d770:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40d775:	add    rsp,0x8
  40d779:	add    rsp,0x20
  40d77d:	mov    eax,DWORD PTR [r12+0x9ac]
  40d785:	test   eax,eax
  40d787:	je     40d9c0 <__swc_fn_7069e055_000106_ffe51047+0x480>
  40d78d:	lea    rax,[rip+0x5d54]        # 4134e8 <__swc_rdata_base_7069e055+0x3d8>
  40d794:	sub    rsp,0x20
  40d798:	mov    rcx,rsp
  40d79b:	mov    QWORD PTR [rcx],rax
  40d79e:	mov    QWORD PTR [rcx+0x8],r13
  40d7a2:	mov    QWORD PTR [rcx+0x10],rsp
  40d7a6:	mov    QWORD PTR [rcx+0x18],0x1
  40d7ae:	lea    rcx,[rsp+0x10]
  40d7b3:	sub    rsp,0x8
  40d7b7:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40d7bc:	add    rsp,0x8
  40d7c0:	add    rsp,0x20
  40d7c4:	mov    eax,DWORD PTR [r12+0x9ac]
  40d7cc:	dec    eax
  40d7ce:	mov    esi,eax
  40d7d0:	test   esi,esi
  40d7d2:	jl     40d990 <__swc_fn_7069e055_000106_ffe51047+0x450>
  40d7d8:	jmp    40d7e4 <__swc_fn_7069e055_000106_ffe51047+0x2a4>
  40d7da:	nop    WORD PTR [rax+rax*1+0x0]
  40d7e0:	dec    esi
  40d7e2:	jmp    40d7d0 <__swc_fn_7069e055_000106_ffe51047+0x290>
  40d7e4:	lea    rax,[rip+0x5d0d]        # 4134f8 <__swc_rdata_base_7069e055+0x3e8>
  40d7eb:	sub    rsp,0x20
  40d7ef:	mov    rcx,rsp
  40d7f2:	mov    QWORD PTR [rcx],rax
  40d7f5:	mov    QWORD PTR [rcx+0x8],r13
  40d7f9:	mov    QWORD PTR [rcx+0x10],rsp
  40d7fd:	mov    QWORD PTR [rcx+0x18],0x1
  40d805:	lea    rcx,[rsp+0x10]
  40d80a:	sub    rsp,0x8
  40d80e:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40d813:	add    rsp,0x8
  40d817:	add    rsp,0x20
  40d81b:	movsxd rax,esi
  40d81e:	imul   r15,rax,0x30
  40d822:	add    r15,r12
  40d825:	add    r15,0xf8
  40d82c:	sub    rsp,0x20
  40d830:	mov    rax,rsp
  40d833:	mov    QWORD PTR [rax],r15
  40d836:	mov    QWORD PTR [rax+0x8],rdi
  40d83a:	mov    QWORD PTR [rax+0x10],rsp
  40d83e:	mov    QWORD PTR [rax+0x18],0x1
  40d846:	lea    rcx,[rsp+0x10]
  40d84b:	sub    rsp,0x8
  40d84f:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40d854:	add    rsp,0x8
  40d858:	add    rsp,0x20
  40d85c:	mov    QWORD PTR [rsp+0x4f8],rsi
  40d864:	lea    rsi,[rip+0x5c9d]        # 413508 <__swc_rdata_base_7069e055+0x3f8>
  40d86b:	sub    rsp,0x20
  40d86f:	mov    rax,rsp
  40d872:	mov    QWORD PTR [rax],rsi
  40d875:	mov    QWORD PTR [rax+0x8],r13
  40d879:	mov    QWORD PTR [rax+0x10],rsp
  40d87d:	mov    QWORD PTR [rax+0x18],0x1
  40d885:	lea    rcx,[rsp+0x10]
  40d88a:	sub    rsp,0x8
  40d88e:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40d893:	add    rsp,0x8
  40d897:	add    rsp,0x20
  40d89b:	sub    rsp,0x30
  40d89f:	mov    rax,rsp
  40d8a2:	mov    ecx,DWORD PTR [r15+0x20]
  40d8a6:	mov    QWORD PTR [rax],rcx
  40d8a9:	mov    QWORD PTR [rax+0x8],rsp
  40d8ad:	lea    rdi,[rip+0x5c64]        # 413518 <__swc_rdata_base_7069e055+0x408>
  40d8b4:	mov    QWORD PTR [rax+0x10],rdi
  40d8b8:	lea    rcx,[rsp+0x8]
  40d8bd:	mov    QWORD PTR [rax+0x18],rcx
  40d8c1:	mov    QWORD PTR [rax+0x20],0x1
  40d8c9:	lea    rcx,[rsp+0x18]
  40d8ce:	sub    rsp,0x8
  40d8d2:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40d8d7:	add    rsp,0x8
  40d8db:	add    rsp,0x30
  40d8df:	sub    rsp,0x20
  40d8e3:	mov    rax,rsp
  40d8e6:	mov    QWORD PTR [rax],rsi
  40d8e9:	mov    QWORD PTR [rax+0x8],r13
  40d8ed:	mov    QWORD PTR [rax+0x10],rsp
  40d8f1:	mov    QWORD PTR [rax+0x18],0x1
  40d8f9:	lea    rcx,[rsp+0x10]
  40d8fe:	sub    rsp,0x8
  40d902:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40d907:	add    rsp,0x8
  40d90b:	add    rsp,0x20
  40d90f:	sub    rsp,0x30
  40d913:	mov    rax,rsp
  40d916:	mov    ecx,DWORD PTR [r15+0x24]
  40d91a:	mov    QWORD PTR [rax],rcx
  40d91d:	mov    QWORD PTR [rax+0x8],rsp
  40d921:	mov    QWORD PTR [rax+0x10],rdi
  40d925:	lea    rcx,[rsp+0x8]
  40d92a:	mov    QWORD PTR [rax+0x18],rcx
  40d92e:	mov    QWORD PTR [rax+0x20],0x1
  40d936:	lea    rcx,[rsp+0x18]
  40d93b:	sub    rsp,0x8
  40d93f:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40d944:	add    rsp,0x8
  40d948:	add    rsp,0x30
  40d94c:	sub    rsp,0x20
  40d950:	mov    rax,rsp
  40d953:	mov    QWORD PTR [rax],r14
  40d956:	mov    QWORD PTR [rax+0x8],r13
  40d95a:	mov    QWORD PTR [rax+0x10],rsp
  40d95e:	mov    QWORD PTR [rax+0x18],0x1
  40d966:	lea    rcx,[rsp+0x10]
  40d96b:	sub    rsp,0x8
  40d96f:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40d974:	add    rsp,0x8
  40d978:	add    rsp,0x20
  40d97c:	lea    rdi,[rip+0x5ac5]        # 413448 <__swc_rdata_base_7069e055+0x338>
  40d983:	mov    rsi,QWORD PTR [rsp+0x4f8]
  40d98b:	jmp    40d7e0 <__swc_fn_7069e055_000106_ffe51047+0x2a0>
  40d990:	sub    rsp,0x20
  40d994:	mov    rax,rsp
  40d997:	mov    QWORD PTR [rax],r14
  40d99a:	mov    QWORD PTR [rax+0x8],r13
  40d99e:	mov    QWORD PTR [rax+0x10],rsp
  40d9a2:	mov    QWORD PTR [rax+0x18],0x1
  40d9aa:	lea    rcx,[rsp+0x10]
  40d9af:	sub    rsp,0x8
  40d9b3:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40d9b8:	add    rsp,0x8
  40d9bc:	add    rsp,0x20
  40d9c0:	lea    rax,[rbx+0x28]
  40d9c4:	mov    rcx,rax
  40d9c7:	mov    QWORD PTR [rbx+0x28],0x0
  40d9cf:	mov    QWORD PTR [rbx+0x30],0x0
  40d9d7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  40d9dc:	add    rcx,0x10
  40d9e0:	mov    edx,0x1f
  40d9e5:	cs nop WORD PTR [rax+rax*1+0x0]
  40d9ef:	nop
  40d9f0:	vmovups XMMWORD PTR [rcx],xmm0
  40d9f4:	add    rcx,0x10
  40d9f8:	sub    rdx,0x1
  40d9fc:	jne    40d9f0 <__swc_fn_7069e055_000106_ffe51047+0x4b0>
  40d9fe:	lea    rsi,[rbx+0x228]
  40da05:	xor    ecx,ecx
  40da07:	cs nop WORD PTR [rax+rax*1+0x0]
  40da11:	cs nop WORD PTR [rax+rax*1+0x0]
  40da1b:	nop    DWORD PTR [rax+rax*1+0x0]
  40da20:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  40da25:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  40da2a:	add    rcx,0x10
  40da2e:	cmp    rcx,0x200
  40da35:	jne    40da20 <__swc_fn_7069e055_000106_ffe51047+0x4e0>
  40da37:	mov    eax,DWORD PTR [r12+0xbc8]
  40da3f:	lea    rcx,[r12+0x9c8]
  40da47:	mov    QWORD PTR [rbx+0x428],rcx
  40da4e:	mov    QWORD PTR [rbx+0x430],rax
  40da55:	lea    rdi,[rbx+0x438]
  40da5c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  40da64:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40da6c:	mov    eax,DWORD PTR [r12+0xbc8]
  40da74:	test   eax,eax
  40da76:	jne    40dac3 <__swc_fn_7069e055_000106_ffe51047+0x583>
  40da78:	lea    rax,[rbx+0x448]
  40da7f:	mov    QWORD PTR [rbx+0x448],rsi
  40da86:	mov    QWORD PTR [rax+0x8],0x40
  40da8e:	mov    ecx,0x1
  40da93:	mov    rdx,rax
  40da96:	sub    rsp,0x8
  40da9a:	call   409ea0 <__swc_fn_7069e055_000123_4f256d58>
  40da9f:	add    rsp,0x8
  40daa3:	mov    QWORD PTR [rbx+0x460],rsi
  40daaa:	mov    ecx,eax
  40daac:	mov    QWORD PTR [rbx+0x468],rcx
  40dab3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  40dabb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40dac3:	mov    rsi,QWORD PTR [rbx+0x438]
  40daca:	mov    rax,QWORD PTR [rbx+0x440]
  40dad1:	mov    r15,rax
  40dad4:	xor    r12d,r12d
  40dad7:	test   r15,r15
  40dada:	je     40db90 <__swc_fn_7069e055_000106_ffe51047+0x650>
  40dae0:	mov    rax,QWORD PTR [rsi+r12*8]
  40dae4:	test   rax,rax
  40dae7:	je     40db06 <__swc_fn_7069e055_000106_ffe51047+0x5c6>
  40dae9:	lea    rcx,[rbx+0x4b8]
  40daf0:	mov    rdx,rax
  40daf3:	sub    rsp,0x8
  40daf7:	call   40e9f0 <__swc_fn_7069e055_000166_cc119975>
  40dafc:	add    rsp,0x8
  40db00:	mov    al,BYTE PTR [rax]
  40db02:	test   al,al
  40db04:	jne    40db12 <__swc_fn_7069e055_000106_ffe51047+0x5d2>
  40db06:	add    r12,0x1
  40db0a:	sub    r15,0x1
  40db0e:	jne    40dae0 <__swc_fn_7069e055_000106_ffe51047+0x5a0>
  40db10:	jmp    40db90 <__swc_fn_7069e055_000106_ffe51047+0x650>
  40db12:	lea    rax,[rip+0x5a47]        # 413560 <__swc_rdata_base_7069e055+0x450>
  40db19:	sub    rsp,0x20
  40db1d:	mov    rcx,rsp
  40db20:	mov    QWORD PTR [rcx],rax
  40db23:	mov    QWORD PTR [rcx+0x8],r13
  40db27:	mov    QWORD PTR [rcx+0x10],rsp
  40db2b:	mov    QWORD PTR [rcx+0x18],0x1
  40db33:	lea    rcx,[rsp+0x10]
  40db38:	sub    rsp,0x8
  40db3c:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40db41:	add    rsp,0x8
  40db45:	add    rsp,0x20
  40db49:	mov    rcx,rdi
  40db4c:	xor    edx,edx
  40db4e:	mov    al,0x1
  40db50:	mov    r8,rax
  40db53:	sub    rsp,0x8
  40db57:	call   411d40 <__swc_fn_7069e055_000167_bcc835b8>
  40db5c:	add    rsp,0x8
  40db60:	sub    rsp,0x20
  40db64:	mov    rax,rsp
  40db67:	mov    QWORD PTR [rax],r14
  40db6a:	mov    QWORD PTR [rax+0x8],r13
  40db6e:	mov    QWORD PTR [rax+0x10],rsp
  40db72:	mov    QWORD PTR [rax+0x18],0x1
  40db7a:	lea    rcx,[rsp+0x10]
  40db7f:	sub    rsp,0x8
  40db83:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  40db88:	add    rsp,0x8
  40db8c:	add    rsp,0x20
  40db90:	mov    r12,QWORD PTR [rsp+0x4f0]
  40db98:	mov    DWORD PTR [r12+0xbc8],0x0
  40dba4:	add    rsp,0x500
  40dbab:	pop    r15
  40dbad:	pop    r14
  40dbaf:	pop    r13
  40dbb1:	pop    r12
  40dbb3:	pop    rdi
  40dbb4:	pop    rsi
  40dbb5:	pop    rbx
  40dbb6:	pop    rbp
  40dbb7:	ret
	...

000000000040dbc0 <__swc_fn_7069e055_000109_7c204aac>:
  40dbc0:	sub    rsp,0x8
  40dbc4:	test   r8,r8
  40dbc7:	je     40dbce <__swc_fn_7069e055_000109_7c204aac+0xe>
  40dbc9:	call   4095d0 <__swc_fn_7069e055_000108_c51c3158>
  40dbce:	add    rsp,0x8
  40dbd2:	ret
	...

000000000040dbe0 <__swc_fn_7069e055_000112_126150d1>:
  40dbe0:	push   rsi
  40dbe1:	push   rdi
  40dbe2:	push   r12
  40dbe4:	push   r13
  40dbe6:	sub    rsp,0xd8
  40dbed:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40dbf3:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40dbf9:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40dbff:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40dc05:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40dc0b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40dc14:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40dc1d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40dc26:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40dc2f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40dc38:	xor    eax,eax
  40dc3a:	call   407050 <getpid@plt>
  40dc3f:	mov    rsi,rax
  40dc42:	lea    rdi,[rip+0x190f7]        # 426d40 <__swc_bss_base_7069e055+0x2d00>
  40dc49:	mov    r12,QWORD PTR [rdi]
  40dc4c:	test   r12,r12
  40dc4f:	je     40dc5d <__swc_fn_7069e055_000112_126150d1+0x7d>
  40dc51:	cmp    DWORD PTR [r12+0x10],esi
  40dc56:	jne    40dc5d <__swc_fn_7069e055_000112_126150d1+0x7d>
  40dc58:	mov    rax,r12
  40dc5b:	jmp    40dcc0 <__swc_fn_7069e055_000112_126150d1+0xe0>
  40dc5d:	mov    ecx,0x4
  40dc62:	mov    edx,0x18
  40dc67:	call   4096b0 <__swc_fn_7069e055_000111_6814119b>
  40dc6c:	mov    rcx,rax
  40dc6f:	test   rax,rax
  40dc72:	jne    40dc78 <__swc_fn_7069e055_000112_126150d1+0x98>
  40dc74:	xor    eax,eax
  40dc76:	jmp    40dcc0 <__swc_fn_7069e055_000112_126150d1+0xe0>
  40dc78:	mov    DWORD PTR [rcx+0x10],esi
  40dc7b:	mov    rax,r12
  40dc7e:	lock cmpxchg QWORD PTR [rdi],rcx
  40dc83:	mov    r13,rax
  40dc86:	cmp    rax,r12
  40dc89:	je     40dc9f <__swc_fn_7069e055_000112_126150d1+0xbf>
  40dc8b:	mov    rdi,rcx
  40dc8e:	mov    esi,0x18
  40dc93:	xor    eax,eax
  40dc95:	call   407160 <munmap@plt>
  40dc9a:	mov    rax,r13
  40dc9d:	jmp    40dcc0 <__swc_fn_7069e055_000112_126150d1+0xe0>
  40dc9f:	test   r12,r12
  40dca2:	je     40dcbd <__swc_fn_7069e055_000112_126150d1+0xdd>
  40dca4:	mov    rdi,r12
  40dca7:	mov    esi,0x18
  40dcac:	xor    eax,eax
  40dcae:	mov    QWORD PTR [rsp+0x28],rcx
  40dcb3:	call   407160 <munmap@plt>
  40dcb8:	mov    rcx,QWORD PTR [rsp+0x28]
  40dcbd:	mov    rax,rcx
  40dcc0:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40dcc6:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40dccc:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40dcd2:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40dcd8:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40dcde:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40dce7:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40dcf0:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40dcf9:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40dd02:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40dd0b:	add    rsp,0xd8
  40dd12:	pop    r13
  40dd14:	pop    r12
  40dd16:	pop    rdi
  40dd17:	pop    rsi
  40dd18:	ret
  40dd19:	add    BYTE PTR [rax],al
  40dd1b:	add    BYTE PTR [rax],al
  40dd1d:	add    BYTE PTR [rax],al
	...

000000000040dd20 <__swc_fn_7069e055_000115_36905703>:
  40dd20:	push   rbx
  40dd21:	push   r12
  40dd23:	push   rdi
  40dd24:	push   rsi
  40dd25:	sub    rsp,0xa8
  40dd2c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40dd32:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40dd38:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40dd3e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40dd44:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40dd4a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40dd50:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40dd56:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40dd5c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40dd65:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40dd6e:	mov    rbx,rdx
  40dd71:	mov    r12,rcx
  40dd74:	mov    rdi,rcx
  40dd77:	mov    rsi,rdx
  40dd7a:	mov    edx,0x3
  40dd7f:	xor    eax,eax
  40dd81:	call   407170 <mprotect@plt>
  40dd86:	test   eax,eax
  40dd88:	je     40dd8e <__swc_fn_7069e055_000115_36905703+0x6e>
  40dd8a:	xor    eax,eax
  40dd8c:	jmp    40dda3 <__swc_fn_7069e055_000115_36905703+0x83>
  40dd8e:	mov    rcx,r12
  40dd91:	mov    rdx,rbx
  40dd94:	mov    al,0x1
  40dd96:	mov    r8,rax
  40dd99:	call   409ce0 <__swc_fn_7069e055_000114_5f48311c>
  40dd9e:	mov    eax,0x1
  40dda3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40dda9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ddaf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ddb5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ddbb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ddc1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ddc7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ddcd:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ddd3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40dddc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40dde5:	add    rsp,0xa8
  40ddec:	pop    rsi
  40dded:	pop    rdi
  40ddee:	pop    r12
  40ddf0:	pop    rbx
  40ddf1:	ret
	...

000000000040de00 <__swc_fn_7069e055_000118_5208f471>:
  40de00:	sub    rsp,0x8
  40de04:	test   rcx,rcx
  40de07:	jne    40de0e <__swc_fn_7069e055_000118_5208f471+0xe>
  40de09:	add    rsp,0x8
  40de0d:	ret
  40de0e:	call   411360 <__swc_fn_7069e055_000119_d3318640>
  40de13:	add    rsp,0x8
  40de17:	ret
	...

000000000040de20 <__swc_fn_7069e055_000121_0a5fa85a>:
  40de20:	push   rdi
  40de21:	push   rsi
  40de22:	sub    rsp,0xa8
  40de29:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40de2f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40de35:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40de3b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40de41:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40de47:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40de4d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40de53:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40de59:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40de62:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40de6b:	xor    edi,edi
  40de6d:	xor    eax,eax
  40de6f:	call   407180 <exit@plt>
  40de74:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40de7a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40de80:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40de86:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40de8c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40de92:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40de98:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40de9e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40dea4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40dead:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40deb6:	add    rsp,0xa8
  40debd:	pop    rsi
  40debe:	pop    rdi
  40debf:	ret

000000000040dec0 <__swc_fn_7069e055_000124_83db7238>:
  40dec0:	push   rbx
  40dec1:	push   rsi
  40dec2:	push   rdi
  40dec3:	push   r12
  40dec5:	sub    rsp,0x18
  40dec9:	mov    rbx,r8
  40decc:	mov    rsi,rcx
  40decf:	mov    rdi,rdx
  40ded2:	mov    rcx,QWORD PTR [rip+0x16167]        # 424040 <__swc_bss_base_7069e055>
  40ded9:	test   rcx,rcx
  40dedc:	jne    40deee <__swc_fn_7069e055_000124_83db7238+0x2e>
  40dede:	call   40ec80 <__swc_fn_7069e055_000169_994c8876>
  40dee3:	lea    rcx,[rax+0x1]
  40dee7:	mov    QWORD PTR [rip+0x16152],rcx        # 424040 <__swc_bss_base_7069e055>
  40deee:	dec    rcx
  40def1:	call   40bb40 <__swc_fn_7069e055_000171_360af05d>
  40def6:	mov    r12,rax
  40def9:	cmp    ebx,0x3
  40defc:	jne    40df0f <__swc_fn_7069e055_000124_83db7238+0x4f>
  40defe:	mov    rax,QWORD PTR [r12+0xbd0]
  40df06:	test   rax,rax
  40df09:	jne    40e04c <__swc_fn_7069e055_000124_83db7238+0x18c>
  40df0f:	cmp    ebx,0x5
  40df12:	jne    40df36 <__swc_fn_7069e055_000124_83db7238+0x76>
  40df14:	call   410c30 <__swc_fn_7069e055_000095_ad13d15c>
  40df19:	test   al,al
  40df1b:	jne    40df36 <__swc_fn_7069e055_000124_83db7238+0x76>
  40df1d:	mov    rcx,rsi
  40df20:	mov    rdx,rdi
  40df23:	call   40baf0 <__swc_fn_7069e055_000168_3459066f>
  40df28:	test   al,al
  40df2a:	je     40df36 <__swc_fn_7069e055_000124_83db7238+0x76>
  40df2c:	add    rsp,0x18
  40df30:	pop    r12
  40df32:	pop    rdi
  40df33:	pop    rsi
  40df34:	pop    rbx
  40df35:	ret
  40df36:	call   410c30 <__swc_fn_7069e055_000095_ad13d15c>
  40df3b:	test   al,al
  40df3d:	jne    40dfaf <__swc_fn_7069e055_000124_83db7238+0xef>
  40df3f:	vmovups xmm0,XMMWORD PTR [rsi]
  40df43:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40df49:	mov    rax,QWORD PTR [rsp+0x8]
  40df4e:	test   rax,rax
  40df51:	jne    40dfa2 <__swc_fn_7069e055_000124_83db7238+0xe2>
  40df53:	cmp    ebx,0x3
  40df56:	je     40df64 <__swc_fn_7069e055_000124_83db7238+0xa4>
  40df58:	cmp    ebx,0x4
  40df5b:	je     40df74 <__swc_fn_7069e055_000124_83db7238+0xb4>
  40df5d:	cmp    ebx,0x5
  40df60:	je     40df84 <__swc_fn_7069e055_000124_83db7238+0xc4>
  40df62:	jmp    40df94 <__swc_fn_7069e055_000124_83db7238+0xd4>
  40df64:	vmovups xmm0,XMMWORD PTR [rip+0x5644]        # 4135b0 <__swc_rdata_base_7069e055+0x4a0>
  40df6c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40df72:	jmp    40dfa2 <__swc_fn_7069e055_000124_83db7238+0xe2>
  40df74:	vmovups xmm0,XMMWORD PTR [rip+0x5644]        # 4135c0 <__swc_rdata_base_7069e055+0x4b0>
  40df7c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40df82:	jmp    40dfa2 <__swc_fn_7069e055_000124_83db7238+0xe2>
  40df84:	vmovups xmm0,XMMWORD PTR [rip+0x5644]        # 4135d0 <__swc_rdata_base_7069e055+0x4c0>
  40df8c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40df92:	jmp    40dfa2 <__swc_fn_7069e055_000124_83db7238+0xe2>
  40df94:	vmovups xmm0,XMMWORD PTR [rip+0x5644]        # 4135e0 <__swc_rdata_base_7069e055+0x4d0>
  40df9c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dfa2:	lea    rcx,[rsp+0x8]
  40dfa7:	mov    rdx,rdi
  40dfaa:	call   410e80 <__swc_fn_7069e055_000107_90faaa26>
  40dfaf:	vmovups xmm0,XMMWORD PTR [rdi]
  40dfb3:	vmovups XMMWORD PTR [r12+0x940],xmm0
  40dfbd:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  40dfc2:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40dfcc:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  40dfd1:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40dfdb:	lea    rax,[r12+0x940]
  40dfe3:	mov    QWORD PTR [r12+0x970],rax
  40dfeb:	mov    rax,QWORD PTR [rsi]
  40dfee:	mov    QWORD PTR [r12+0x978],rax
  40dff6:	mov    rax,QWORD PTR [rsi+0x8]
  40dffa:	mov    QWORD PTR [r12+0x980],rax
  40e002:	movsxd rax,ebx
  40e005:	mov    QWORD PTR [r12+0x988],rax
  40e00d:	cmp    ebx,0x5
  40e010:	je     40e019 <__swc_fn_7069e055_000124_83db7238+0x159>
  40e012:	xor    ecx,ecx
  40e014:	call   40edb0 <__swc_fn_7069e055_000178_718d7b54>
  40e019:	mov    rbx,QWORD PTR [r12+0xbe8]
  40e021:	test   rbx,rbx
  40e024:	je     40e035 <__swc_fn_7069e055_000124_83db7238+0x175>
  40e026:	mov    rcx,r12
  40e029:	call   rbx
  40e02b:	add    rsp,0x18
  40e02f:	pop    r12
  40e031:	pop    rdi
  40e032:	pop    rsi
  40e033:	pop    rbx
  40e034:	ret
  40e035:	mov    rcx,rsi
  40e038:	call   409d90 <__swc_fn_7069e055_000120_2648f149>
  40e03d:	call   4114b0 <__swc_fn_7069e055_000122_be2e2f68>
  40e042:	add    rsp,0x18
  40e046:	pop    r12
  40e048:	pop    rdi
  40e049:	pop    rsi
  40e04a:	pop    rbx
  40e04b:	ret
  40e04c:	mov    rcx,rsi
  40e04f:	mov    rdx,rdi
  40e052:	call   410e80 <__swc_fn_7069e055_000107_90faaa26>
  40e057:	jmp    40df0f <__swc_fn_7069e055_000124_83db7238+0x4f>
  40e05c:	add    BYTE PTR [rax],al
	...

000000000040e060 <__swc_fn_7069e055_000127_58f0f391>:
  40e060:	push   rdi
  40e061:	push   rsi
  40e062:	sub    rsp,0xb8
  40e069:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40e06f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40e075:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40e07b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40e081:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40e087:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40e08d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40e093:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40e09c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40e0a5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40e0ae:	mov    DWORD PTR [rsp+0x8],0x0
  40e0b6:	lea    rdi,[rsp+0x8]
  40e0bb:	xor    esi,esi
  40e0bd:	xor    eax,eax
  40e0bf:	call   407190 <pthread_key_create@plt>
  40e0c4:	test   eax,eax
  40e0c6:	jne    40e0ce <__swc_fn_7069e055_000127_58f0f391+0x6e>
  40e0c8:	mov    eax,DWORD PTR [rsp+0x8]
  40e0cc:	jmp    40e0d5 <__swc_fn_7069e055_000127_58f0f391+0x75>
  40e0ce:	mov    rax,0xffffffffffffffff
  40e0d5:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40e0db:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40e0e1:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40e0e7:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40e0ed:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40e0f3:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40e0f9:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40e0ff:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40e108:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40e111:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40e11a:	add    rsp,0xb8
  40e121:	pop    rsi
  40e122:	pop    rdi
  40e123:	ret
	...

000000000040e130 <__swc_fn_7069e055_000130_4a82cdf6>:
  40e130:	push   rdi
  40e131:	push   rsi
  40e132:	sub    rsp,0xb8
  40e139:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40e13f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40e145:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40e14b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40e151:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40e157:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40e15d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40e163:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40e16c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40e175:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40e17e:	mov    DWORD PTR [rsp+0x8],0x0
  40e186:	lea    rdi,[rsp+0x8]
  40e18b:	mov    rsi,rcx
  40e18e:	xor    eax,eax
  40e190:	call   407190 <pthread_key_create@plt>
  40e195:	test   eax,eax
  40e197:	jne    40e1a2 <__swc_fn_7069e055_000130_4a82cdf6+0x72>
  40e199:	mov    eax,DWORD PTR [rsp+0x8]
  40e19d:	inc    rax
  40e1a0:	jmp    40e1a4 <__swc_fn_7069e055_000130_4a82cdf6+0x74>
  40e1a2:	xor    eax,eax
  40e1a4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40e1aa:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40e1b0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40e1b6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40e1bc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40e1c2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40e1c8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40e1ce:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40e1d7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40e1e0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40e1e9:	add    rsp,0xb8
  40e1f0:	pop    rsi
  40e1f1:	pop    rdi
  40e1f2:	ret
	...

000000000040e200 <__swc_fn_7069e055_000133_ae5891af>:
  40e200:	push   rdi
  40e201:	push   rsi
  40e202:	sub    rsp,0xa8
  40e209:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e20f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e215:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e21b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e221:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e227:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e22d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e233:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e239:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e242:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e24b:	test   rcx,rcx
  40e24e:	setne  al
  40e251:	je     40e26a <__swc_fn_7069e055_000133_ae5891af+0x6a>
  40e253:	lea    rax,[rcx-0x1]
  40e257:	mov    eax,eax
  40e259:	mov    edi,eax
  40e25b:	mov    rsi,rdx
  40e25e:	xor    eax,eax
  40e260:	call   407120 <pthread_setspecific@plt>
  40e265:	test   eax,eax
  40e267:	sete   al
  40e26a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e270:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e276:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e27c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e282:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e288:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e28e:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e294:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e29a:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e2a3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e2ac:	add    rsp,0xa8
  40e2b3:	pop    rsi
  40e2b4:	pop    rdi
  40e2b5:	ret
	...

000000000040e2c0 <__swc_fn_7069e055_000136_865f5106>:
  40e2c0:	push   rdi
  40e2c1:	push   rsi
  40e2c2:	sub    rsp,0xa8
  40e2c9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e2cf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e2d5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e2db:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e2e1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e2e7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e2ed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e2f3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e2f9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e302:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e30b:	mov    rax,rdx
  40e30e:	mov    QWORD PTR [rsp],0x0
  40e316:	mov    edi,0xca
  40e31b:	mov    rsi,rcx
  40e31e:	mov    edx,0x81
  40e323:	mov    eax,eax
  40e325:	mov    ecx,eax
  40e327:	xor    r8d,r8d
  40e32a:	xor    r9d,r9d
  40e32d:	xor    eax,eax
  40e32f:	call   4071a0 <syscall@plt>
  40e334:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e33a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e340:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e346:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e34c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e352:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e358:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e35e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e364:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e36d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e376:	add    rsp,0xa8
  40e37d:	pop    rsi
  40e37e:	pop    rdi
  40e37f:	ret

000000000040e380 <__swc_fn_7069e055_000139_86bb0f90>:
  40e380:	sub    rsp,0x8
  40e384:	call   411850 <__swc_fn_7069e055_000137_8c07c14b>
  40e389:	add    rsp,0x8
  40e38d:	ret
	...

000000000040e390 <__swc_fn_7069e055_000142_be4c2719>:
  40e390:	push   rdi
  40e391:	push   rsi
  40e392:	sub    rsp,0xc8
  40e399:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40e39f:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40e3a5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40e3ab:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40e3b1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40e3b7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40e3bd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40e3c6:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40e3cf:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40e3d8:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40e3e1:	vxorps xmm0,xmm0,xmm0
  40e3e5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e3eb:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e3f1:	mov    rdi,rcx
  40e3f4:	lea    rsi,[rsp+0x8]
  40e3f9:	xor    eax,eax
  40e3fb:	call   4071b0 <dladdr@plt>
  40e400:	xor    ecx,ecx
  40e402:	test   eax,eax
  40e404:	je     40e40b <__swc_fn_7069e055_000142_be4c2719+0x7b>
  40e406:	mov    rcx,QWORD PTR [rsp+0x10]
  40e40b:	mov    rax,rcx
  40e40e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40e414:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40e41a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40e420:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40e426:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40e42c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40e432:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40e43b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40e444:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40e44d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40e456:	add    rsp,0xc8
  40e45d:	pop    rsi
  40e45e:	pop    rdi
  40e45f:	ret

000000000040e460 <__swc_fn_7069e055_000145_1534de9a>:
  40e460:	push   rbx
  40e461:	push   r12
  40e463:	push   r13
  40e465:	push   rdi
  40e466:	push   rsi
  40e467:	push   r14
  40e469:	push   r15
  40e46b:	sub    rsp,0x150
  40e472:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40e47b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40e484:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40e48d:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40e496:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40e49f:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40e4a8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40e4b1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40e4ba:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40e4c3:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40e4cc:	mov    rbx,rdx
  40e4cf:	mov    QWORD PTR [rsp+0x98],rdx
  40e4d7:	mov    r12,rcx
  40e4da:	mov    QWORD PTR [rsp+0xa0],rcx
  40e4e2:	mov    QWORD PTR [rbx],0x0
  40e4e9:	lea    r13,[rip+0x18888]        # 426d78 <__swc_bss_base_7069e055+0x2d38>
  40e4f0:	mov    rcx,r13
  40e4f3:	call   40e380 <__swc_fn_7069e055_000139_86bb0f90>
  40e4f8:	mov    rax,QWORD PTR [rip+0x18881]        # 426d80 <__swc_bss_base_7069e055+0x2d40>
  40e4ff:	test   rax,rax
  40e502:	je     40e539 <__swc_fn_7069e055_000145_1534de9a+0xd9>
  40e504:	cs nop WORD PTR [rax+rax*1+0x0]
  40e50e:	xchg   ax,ax
  40e510:	cmp    QWORD PTR [rax+0x8],r12
  40e514:	jne    40e531 <__swc_fn_7069e055_000145_1534de9a+0xd1>
  40e516:	mov    rcx,QWORD PTR [rax+0x18]
  40e51a:	mov    QWORD PTR [rbx],rcx
  40e51d:	mov    rbx,QWORD PTR [rax+0x10]
  40e521:	mov    rcx,r13
  40e524:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40e529:	mov    rax,rbx
  40e52c:	jmp    40e71b <__swc_fn_7069e055_000145_1534de9a+0x2bb>
  40e531:	mov    rax,QWORD PTR [rax]
  40e534:	test   rax,rax
  40e537:	jne    40e510 <__swc_fn_7069e055_000145_1534de9a+0xb0>
  40e539:	vxorps xmm0,xmm0,xmm0
  40e53d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  40e543:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  40e549:	mov    rdi,r12
  40e54c:	lea    rsi,[rsp+0x10]
  40e551:	xor    eax,eax
  40e553:	call   4071b0 <dladdr@plt>
  40e558:	test   eax,eax
  40e55a:	sete   al
  40e55d:	je     40e56a <__swc_fn_7069e055_000145_1534de9a+0x10a>
  40e55f:	mov    rax,QWORD PTR [rsp+0x10]
  40e564:	test   rax,rax
  40e567:	sete   al
  40e56a:	test   al,al
  40e56c:	je     40e57d <__swc_fn_7069e055_000145_1534de9a+0x11d>
  40e56e:	mov    rcx,r13
  40e571:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40e576:	xor    eax,eax
  40e578:	jmp    40e71b <__swc_fn_7069e055_000145_1534de9a+0x2bb>
  40e57d:	mov    rdi,QWORD PTR [rsp+0x10]
  40e582:	mov    esi,0x80000
  40e587:	xor    eax,eax
  40e589:	call   407010 <open@plt>
  40e58e:	lea    r14,[rsp+0x30]
  40e593:	mov    DWORD PTR [rsp+0x30],eax
  40e597:	cmp    DWORD PTR [r14],0x0
  40e59b:	jge    40e5ac <__swc_fn_7069e055_000145_1534de9a+0x14c>
  40e59d:	mov    rcx,r13
  40e5a0:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40e5a5:	xor    eax,eax
  40e5a7:	jmp    40e71b <__swc_fn_7069e055_000145_1534de9a+0x2bb>
  40e5ac:	mov    rax,r14
  40e5af:	movsxd rdi,DWORD PTR [rax]
  40e5b2:	xor    esi,esi
  40e5b4:	mov    edx,0x2
  40e5b9:	xor    eax,eax
  40e5bb:	call   4070c0 <lseek@plt>
  40e5c0:	mov    r15,rax
  40e5c3:	test   rax,rax
  40e5c6:	jg     40e5e1 <__swc_fn_7069e055_000145_1534de9a+0x181>
  40e5c8:	movsxd rdi,DWORD PTR [r14]
  40e5cb:	xor    eax,eax
  40e5cd:	call   407040 <close@plt>
  40e5d2:	mov    rcx,r13
  40e5d5:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40e5da:	xor    eax,eax
  40e5dc:	jmp    40e71b <__swc_fn_7069e055_000145_1534de9a+0x2bb>
  40e5e1:	xor    edi,edi
  40e5e3:	mov    rsi,r15
  40e5e6:	mov    edx,0x1
  40e5eb:	mov    ecx,0x2
  40e5f0:	mov    rax,r14
  40e5f3:	movsxd r8,DWORD PTR [rax]
  40e5f6:	xor    r9d,r9d
  40e5f9:	xor    eax,eax
  40e5fb:	call   4070d0 <mmap@plt>
  40e600:	mov    rbx,rax
  40e603:	test   rax,rax
  40e606:	sete   al
  40e609:	cmp    rbx,0xffffffffffffffff
  40e60d:	sete   cl
  40e610:	or     al,cl
  40e612:	je     40e62d <__swc_fn_7069e055_000145_1534de9a+0x1cd>
  40e614:	movsxd rdi,DWORD PTR [r14]
  40e617:	xor    eax,eax
  40e619:	call   407040 <close@plt>
  40e61e:	mov    rcx,r13
  40e621:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40e626:	xor    eax,eax
  40e628:	jmp    40e71b <__swc_fn_7069e055_000145_1534de9a+0x2bb>
  40e62d:	lea    rax,[rsp+0x50]
  40e632:	mov    QWORD PTR [rax],0x0
  40e639:	mov    rcx,rbx
  40e63c:	mov    rdx,r15
  40e63f:	mov    r8,rax
  40e642:	call   40a320 <__swc_fn_7069e055_000144_d5d4d43f>
  40e647:	mov    r12,rax
  40e64a:	test   rax,rax
  40e64d:	jne    40e675 <__swc_fn_7069e055_000145_1534de9a+0x215>
  40e64f:	mov    rdi,rbx
  40e652:	mov    rsi,r15
  40e655:	xor    eax,eax
  40e657:	call   407160 <munmap@plt>
  40e65c:	movsxd rdi,DWORD PTR [r14]
  40e65f:	xor    eax,eax
  40e661:	call   407040 <close@plt>
  40e666:	mov    rcx,r13
  40e669:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40e66e:	xor    eax,eax
  40e670:	jmp    40e71b <__swc_fn_7069e055_000145_1534de9a+0x2bb>
  40e675:	mov    edi,0x20
  40e67a:	xor    eax,eax
  40e67c:	call   4071c0 <malloc@plt>
  40e681:	test   rax,rax
  40e684:	jne    40e6a9 <__swc_fn_7069e055_000145_1534de9a+0x249>
  40e686:	mov    rdi,rbx
  40e689:	mov    rsi,r15
  40e68c:	xor    eax,eax
  40e68e:	call   407160 <munmap@plt>
  40e693:	movsxd rdi,DWORD PTR [r14]
  40e696:	xor    eax,eax
  40e698:	call   407040 <close@plt>
  40e69d:	mov    rcx,r13
  40e6a0:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40e6a5:	xor    eax,eax
  40e6a7:	jmp    40e71b <__swc_fn_7069e055_000145_1534de9a+0x2bb>
  40e6a9:	mov    rcx,QWORD PTR [rip+0x186d0]        # 426d80 <__swc_bss_base_7069e055+0x2d40>
  40e6b0:	mov    QWORD PTR [rsp+0x70],rcx
  40e6b5:	mov    rcx,QWORD PTR [rsp+0xa0]
  40e6bd:	mov    QWORD PTR [rsp+0x78],rcx
  40e6c2:	mov    QWORD PTR [rsp+0x80],r12
  40e6ca:	mov    rcx,QWORD PTR [rsp+0x50]
  40e6cf:	mov    QWORD PTR [rsp+0x88],rcx
  40e6d7:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  40e6dd:	vmovups XMMWORD PTR [rax],xmm0
  40e6e1:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  40e6ea:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e6ef:	mov    QWORD PTR [rip+0x1868a],rax        # 426d80 <__swc_bss_base_7069e055+0x2d40>
  40e6f6:	mov    rax,QWORD PTR [rsp+0x50]
  40e6fb:	mov    rbx,QWORD PTR [rsp+0x98]
  40e703:	mov    QWORD PTR [rbx],rax
  40e706:	movsxd rdi,DWORD PTR [r14]
  40e709:	xor    eax,eax
  40e70b:	call   407040 <close@plt>
  40e710:	mov    rcx,r13
  40e713:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40e718:	mov    rax,r12
  40e71b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40e724:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40e72d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40e736:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40e73f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40e748:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40e751:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40e75a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40e763:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40e76c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40e775:	add    rsp,0x150
  40e77c:	pop    r15
  40e77e:	pop    r14
  40e780:	pop    rsi
  40e781:	pop    rdi
  40e782:	pop    r13
  40e784:	pop    r12
  40e786:	pop    rbx
  40e787:	ret
	...

000000000040e790 <__swc_fn_7069e055_000148_43c96957>:
  40e790:	push   rbx
  40e791:	sub    rsp,0xe0
  40e798:	lea    rbx,[rsp+0x8]
  40e79d:	vxorps xmm0,xmm0,xmm0
  40e7a1:	vmovups YMMWORD PTR [rbx],ymm0
  40e7a5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40e7aa:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40e7af:	vzeroupper
  40e7b2:	mov    DWORD PTR [rbx+0x60],0x0
  40e7b9:	mov    r8,rbx
  40e7bc:	nop    DWORD PTR [rax+0x0]
  40e7c0:	mov    r9,rcx
  40e7c3:	movabs rcx,0xcccccccccccccccd
  40e7cd:	mov    rax,r9
  40e7d0:	mul    rcx
  40e7d3:	mov    r10,rdx
  40e7d6:	shr    r10,0x3
  40e7da:	mov    rcx,r10
  40e7dd:	imul   rdx,r10,0xa
  40e7e1:	sub    r9,rdx
  40e7e4:	mov    rdx,QWORD PTR [rip+0x4e25]        # 413610 <__swc_rdata_base_7069e055+0x500>
  40e7eb:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  40e7f0:	mov    BYTE PTR [r8],dl
  40e7f3:	lea    rdx,[r8+0x1]
  40e7f7:	mov    r8,rdx
  40e7fa:	test   r10,r10
  40e7fd:	jne    40e7c0 <__swc_fn_7069e055_000148_43c96957+0x30>
  40e7ff:	mov    BYTE PTR [rdx],0x0
  40e802:	sub    r8,0x1
  40e806:	mov    rax,rbx
  40e809:	cmp    rax,r8
  40e80c:	jae    40e826 <__swc_fn_7069e055_000148_43c96957+0x96>
  40e80e:	xchg   ax,ax
  40e810:	mov    cl,BYTE PTR [r8]
  40e813:	mov    dl,BYTE PTR [rax]
  40e815:	mov    BYTE PTR [r8],dl
  40e818:	sub    r8,0x1
  40e81c:	mov    BYTE PTR [rax],cl
  40e81e:	inc    rax
  40e821:	cmp    rax,r8
  40e824:	jb     40e810 <__swc_fn_7069e055_000148_43c96957+0x80>
  40e826:	xor    eax,eax
  40e828:	test   rbx,rbx
  40e82b:	je     40e84e <__swc_fn_7069e055_000148_43c96957+0xbe>
  40e82d:	mov    rcx,rbx
  40e830:	mov    dl,BYTE PTR [rcx]
  40e832:	test   dl,dl
  40e834:	je     40e84e <__swc_fn_7069e055_000148_43c96957+0xbe>
  40e836:	cs nop WORD PTR [rax+rax*1+0x0]
  40e840:	add    rcx,0x1
  40e844:	add    rax,0x1
  40e848:	mov    dl,BYTE PTR [rcx]
  40e84a:	test   dl,dl
  40e84c:	jne    40e840 <__swc_fn_7069e055_000148_43c96957+0xb0>
  40e84e:	mov    QWORD PTR [rbx+0xa8],rbx
  40e855:	mov    QWORD PTR [rbx+0xb0],rax
  40e85c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40e864:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40e86c:	lea    rcx,[rbx+0xb8]
  40e873:	call   409d90 <__swc_fn_7069e055_000120_2648f149>
  40e878:	add    rsp,0xe0
  40e87f:	pop    rbx
  40e880:	ret
	...

000000000040e890 <__swc_fn_7069e055_000151_6fb05988>:
  40e890:	sub    rsp,0x8
  40e894:	mov    rax,QWORD PTR [rcx+0x8]
  40e898:	mov    r8,QWORD PTR [rdx+0x8]
  40e89c:	cmp    rax,r8
  40e89f:	je     40e8a8 <__swc_fn_7069e055_000151_6fb05988+0x18>
  40e8a1:	xor    eax,eax
  40e8a3:	add    rsp,0x8
  40e8a7:	ret
  40e8a8:	test   rax,rax
  40e8ab:	jne    40e8bc <__swc_fn_7069e055_000151_6fb05988+0x2c>
  40e8ad:	test   r8,r8
  40e8b0:	jne    40e8bc <__swc_fn_7069e055_000151_6fb05988+0x2c>
  40e8b2:	mov    eax,0x1
  40e8b7:	add    rsp,0x8
  40e8bb:	ret
  40e8bc:	mov    rcx,QWORD PTR [rcx]
  40e8bf:	mov    rdx,QWORD PTR [rdx]
  40e8c2:	test   rcx,rcx
  40e8c5:	sete   r8b
  40e8c9:	test   rdx,rdx
  40e8cc:	sete   r9b
  40e8d0:	or     r8b,r9b
  40e8d3:	je     40e8e0 <__swc_fn_7069e055_000151_6fb05988+0x50>
  40e8d5:	cmp    rcx,rdx
  40e8d8:	sete   al
  40e8db:	add    rsp,0x8
  40e8df:	ret
  40e8e0:	cmp    rcx,rdx
  40e8e3:	jne    40e8ef <__swc_fn_7069e055_000151_6fb05988+0x5f>
  40e8e5:	mov    eax,0x1
  40e8ea:	add    rsp,0x8
  40e8ee:	ret
  40e8ef:	mov    r8,rax
  40e8f2:	call   410f40 <__swc_fn_7069e055_000110_3dc01326>
  40e8f7:	test   eax,eax
  40e8f9:	sete   al
  40e8fc:	add    rsp,0x8
  40e900:	ret
	...

000000000040e910 <__swc_fn_7069e055_000154_86f1d437>:
  40e910:	vxorps xmm0,xmm0,xmm0
  40e914:	vmovups XMMWORD PTR [rcx],xmm0
  40e918:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e91d:	vxorps xmm0,xmm0,xmm0
  40e921:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e926:	vmovups xmm0,XMMWORD PTR [rip+0x4d9a]        # 4136c8 <__swc_rdata_base_7069e055+0x5b8>
  40e92e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e933:	ret
	...

000000000040e940 <__swc_fn_7069e055_000157_86f1d437>:
  40e940:	vxorps xmm0,xmm0,xmm0
  40e944:	vmovups XMMWORD PTR [rcx],xmm0
  40e948:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e94d:	vxorps xmm0,xmm0,xmm0
  40e951:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e956:	vmovups xmm0,XMMWORD PTR [rip+0x4e8a]        # 4137e8 <__swc_rdata_base_7069e055+0x6d8>
  40e95e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e963:	mov    QWORD PTR [rcx+0x40],0x0
  40e96b:	ret
  40e96c:	add    BYTE PTR [rax],al
	...

000000000040e970 <__swc_fn_7069e055_000160_47b270e1>:
  40e970:	push   rbx
  40e971:	sub    rsp,0x70
  40e975:	mov    rax,QWORD PTR [rcx]
  40e978:	mov    rbx,QWORD PTR [rcx+0x8]
  40e97c:	vxorps xmm0,xmm0,xmm0
  40e980:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40e986:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40e98c:	vzeroupper
  40e98f:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40e995:	mov    QWORD PTR [rsp+0x48],rdx
  40e99a:	mov    QWORD PTR [rsp+0x50],r8
  40e99f:	mov    rcx,rax
  40e9a2:	lea    rdx,[rsp+0x8]
  40e9a7:	mov    rbx,QWORD PTR [rbx+0x18]
  40e9ab:	call   rbx
  40e9ad:	add    rsp,0x70
  40e9b1:	pop    rbx
  40e9b2:	ret
	...

000000000040e9c0 <__swc_fn_7069e055_000163_8a3d304f>:
  40e9c0:	push   rbx
  40e9c1:	push   rsi
  40e9c2:	push   rdi
  40e9c3:	mov    rbx,r8
  40e9c6:	mov    rsi,rcx
  40e9c9:	mov    rdi,rdx
  40e9cc:	call   411c50 <__swc_fn_7069e055_000161_13ead2ff>
  40e9d1:	vmovups xmm0,XMMWORD PTR [rbx]
  40e9d5:	vmovups XMMWORD PTR [rsi],xmm0
  40e9d9:	mov    QWORD PTR [rsi+0x18],rdi
  40e9dd:	pop    rdi
  40e9de:	pop    rsi
  40e9df:	pop    rbx
  40e9e0:	ret
	...

000000000040e9f0 <__swc_fn_7069e055_000166_cc119975>:
  40e9f0:	push   rbx
  40e9f1:	push   rsi
  40e9f2:	push   rdi
  40e9f3:	push   r12
  40e9f5:	push   r13
  40e9f7:	sub    rsp,0x50
  40e9fb:	mov    rbx,rcx
  40e9fe:	mov    rsi,rdx
  40ea01:	vmovups xmm0,XMMWORD PTR [rip+0x4eef]        # 4138f8 <__swc_rdata_base_7069e055+0x7e8>
  40ea09:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ea0f:	vmovups xmm0,XMMWORD PTR [rip+0x4ef1]        # 413908 <__swc_rdata_base_7069e055+0x7f8>
  40ea17:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ea1d:	vxorps xmm0,xmm0,xmm0
  40ea21:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ea27:	mov    rcx,rdx
  40ea2a:	call   40e390 <__swc_fn_7069e055_000142_be4c2719>
  40ea2f:	mov    rdi,rax
  40ea32:	test   rax,rax
  40ea35:	jne    40ea66 <__swc_fn_7069e055_000166_cc119975+0x76>
  40ea37:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ea3d:	vmovups XMMWORD PTR [rbx],xmm0
  40ea41:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ea47:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ea4c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40ea52:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ea57:	mov    rax,rbx
  40ea5a:	add    rsp,0x50
  40ea5e:	pop    r13
  40ea60:	pop    r12
  40ea62:	pop    rdi
  40ea63:	pop    rsi
  40ea64:	pop    rbx
  40ea65:	ret
  40ea66:	mov    rcx,rdi
  40ea69:	call   40b840 <__swc_fn_7069e055_000165_016ee66a>
  40ea6e:	mov    r11,rax
  40ea71:	test   rax,rax
  40ea74:	je     40ea7e <__swc_fn_7069e055_000166_cc119975+0x8e>
  40ea76:	mov    al,BYTE PTR [r11+0x24]
  40ea7a:	test   al,al
  40ea7c:	jne    40eaad <__swc_fn_7069e055_000166_cc119975+0xbd>
  40ea7e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ea84:	vmovups XMMWORD PTR [rbx],xmm0
  40ea88:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ea8e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ea93:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40ea99:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ea9e:	mov    rax,rbx
  40eaa1:	add    rsp,0x50
  40eaa5:	pop    r13
  40eaa7:	pop    r12
  40eaa9:	pop    rdi
  40eaaa:	pop    rsi
  40eaab:	pop    rbx
  40eaac:	ret
  40eaad:	sub    rsi,rdi
  40eab0:	mov    eax,0xffffffff
  40eab5:	cmp    rsi,rax
  40eab8:	jbe    40eae9 <__swc_fn_7069e055_000166_cc119975+0xf9>
  40eaba:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40eac0:	vmovups XMMWORD PTR [rbx],xmm0
  40eac4:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40eaca:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40eacf:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40ead5:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40eada:	mov    rax,rbx
  40eadd:	add    rsp,0x50
  40eae1:	pop    r13
  40eae3:	pop    r12
  40eae5:	pop    rdi
  40eae6:	pop    rsi
  40eae7:	pop    rbx
  40eae8:	ret
  40eae9:	mov    rdi,QWORD PTR [r11+0x10]
  40eaed:	mov    eax,DWORD PTR [r11+0x20]
  40eaf1:	xor    ecx,ecx
  40eaf3:	test   rax,rax
  40eaf6:	jbe    40ec48 <__swc_fn_7069e055_000166_cc119975+0x258>
  40eafc:	nop    DWORD PTR [rax+0x0]
  40eb00:	mov    edx,ecx
  40eb02:	imul   r12,rdx,0x14
  40eb06:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40eb0b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40eb10:	mov    r9d,esi
  40eb13:	cmp    r9,rdx
  40eb16:	jb     40ec3b <__swc_fn_7069e055_000166_cc119975+0x24b>
  40eb1c:	add    rdx,r8
  40eb1f:	mov    r8d,esi
  40eb22:	cmp    r8,rdx
  40eb25:	jae    40ec3b <__swc_fn_7069e055_000166_cc119975+0x24b>
  40eb2b:	lea    rsi,[rsp+0x38]
  40eb30:	mov    eax,DWORD PTR [rdi+0xc]
  40eb33:	mov    DWORD PTR [rsp+0x38],eax
  40eb37:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40eb3c:	mov    rcx,rdi
  40eb3f:	mov    rdx,QWORD PTR [r11+0x18]
  40eb43:	mov    r8,rsi
  40eb46:	mov    r8d,DWORD PTR [r8]
  40eb49:	mov    r9,rax
  40eb4c:	lea    r10,[rsp+0x10]
  40eb51:	call   411ca0 <__swc_fn_7069e055_000164_72795826>
  40eb56:	test   al,al
  40eb58:	jne    40eb8b <__swc_fn_7069e055_000166_cc119975+0x19b>
  40eb5a:	vmovups xmm0,XMMWORD PTR [rip+0x4dc6]        # 413928 <__swc_rdata_base_7069e055+0x818>
  40eb62:	vmovups XMMWORD PTR [rbx],xmm0
  40eb66:	vmovups xmm0,XMMWORD PTR [rip+0x4dca]        # 413938 <__swc_rdata_base_7069e055+0x828>
  40eb6e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40eb73:	vxorps xmm0,xmm0,xmm0
  40eb77:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40eb7c:	mov    rax,rbx
  40eb7f:	add    rsp,0x50
  40eb83:	pop    r13
  40eb85:	pop    r12
  40eb87:	pop    rdi
  40eb88:	pop    rsi
  40eb89:	pop    rbx
  40eb8a:	ret
  40eb8b:	lea    r13,[rsp+0x3c]
  40eb90:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40eb95:	mov    DWORD PTR [rsp+0x3c],eax
  40eb99:	test   eax,eax
  40eb9b:	je     40ebec <__swc_fn_7069e055_000166_cc119975+0x1fc>
  40eb9d:	mov    rcx,rdi
  40eba0:	mov    rdx,QWORD PTR [r11+0x18]
  40eba4:	mov    r8d,DWORD PTR [rsi]
  40eba7:	mov    rax,r13
  40ebaa:	mov    r9d,DWORD PTR [rax]
  40ebad:	lea    r10,[rsp+0x20]
  40ebb2:	call   411ca0 <__swc_fn_7069e055_000164_72795826>
  40ebb7:	test   al,al
  40ebb9:	jne    40ebec <__swc_fn_7069e055_000166_cc119975+0x1fc>
  40ebbb:	vmovups xmm0,XMMWORD PTR [rip+0x4d95]        # 413958 <__swc_rdata_base_7069e055+0x848>
  40ebc3:	vmovups XMMWORD PTR [rbx],xmm0
  40ebc7:	vmovups xmm0,XMMWORD PTR [rip+0x4d99]        # 413968 <__swc_rdata_base_7069e055+0x858>
  40ebcf:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ebd4:	vxorps xmm0,xmm0,xmm0
  40ebd8:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ebdd:	mov    rax,rbx
  40ebe0:	add    rsp,0x50
  40ebe4:	pop    r13
  40ebe6:	pop    r12
  40ebe8:	pop    rdi
  40ebe9:	pop    rsi
  40ebea:	pop    rbx
  40ebeb:	ret
  40ebec:	mov    eax,0x1
  40ebf1:	rex mov BYTE PTR [rsp+0x8],al
  40ebf6:	cmp    DWORD PTR [r13+0x0],0x0
  40ebfb:	je     40ec0c <__swc_fn_7069e055_000166_cc119975+0x21c>
  40ebfd:	rex mov BYTE PTR [rsp+0x9],0x1
  40ec03:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40ec08:	mov    DWORD PTR [rsp+0x30],eax
  40ec0c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ec12:	vmovups XMMWORD PTR [rbx],xmm0
  40ec16:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ec1c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ec21:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40ec27:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ec2c:	mov    rax,rbx
  40ec2f:	add    rsp,0x50
  40ec33:	pop    r13
  40ec35:	pop    r12
  40ec37:	pop    rdi
  40ec38:	pop    rsi
  40ec39:	pop    rbx
  40ec3a:	ret
  40ec3b:	add    rcx,0x1
  40ec3f:	cmp    rcx,rax
  40ec42:	jb     40eb00 <__swc_fn_7069e055_000166_cc119975+0x110>
  40ec48:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ec4e:	vmovups XMMWORD PTR [rbx],xmm0
  40ec52:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ec58:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ec5d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40ec63:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ec68:	mov    rax,rbx
  40ec6b:	add    rsp,0x50
  40ec6f:	pop    r13
  40ec71:	pop    r12
  40ec73:	pop    rdi
  40ec74:	pop    rsi
  40ec75:	pop    rbx
  40ec76:	ret
	...

000000000040ec80 <__swc_fn_7069e055_000169_994c8876>:
  40ec80:	sub    rsp,0x48
  40ec84:	call   40e060 <__swc_fn_7069e055_000127_58f0f391>
  40ec89:	cmp    rax,0xffffffffffffffff
  40ec8d:	je     40ec94 <__swc_fn_7069e055_000169_994c8876+0x14>
  40ec8f:	add    rsp,0x48
  40ec93:	ret
  40ec94:	lea    rcx,[rip+0x4cfd]        # 413998 <__swc_rdata_base_7069e055+0x888>
  40ec9b:	vmovups xmm0,XMMWORD PTR [rip+0x4d05]        # 4139a8 <__swc_rdata_base_7069e055+0x898>
  40eca3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40eca9:	vmovups xmm0,XMMWORD PTR [rip+0x4d07]        # 4139b8 <__swc_rdata_base_7069e055+0x8a8>
  40ecb1:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ecb7:	vmovups xmm0,XMMWORD PTR [rip+0x4d09]        # 4139c8 <__swc_rdata_base_7069e055+0x8b8>
  40ecbf:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ecc5:	lea    rdx,[rsp+0x8]
  40ecca:	mov    QWORD PTR [rsp+0x38],rax
  40eccf:	call   410e80 <__swc_fn_7069e055_000107_90faaa26>
  40ecd4:	mov    rax,QWORD PTR [rsp+0x38]
  40ecd9:	jmp    40ec8f <__swc_fn_7069e055_000169_994c8876+0xf>
  40ecdb:	add    BYTE PTR [rax],al
  40ecdd:	add    BYTE PTR [rax],al
	...

000000000040ece0 <__swc_fn_7069e055_000172_cbeff767>:
  40ece0:	push   rbx
  40ece1:	push   rsi
  40ece2:	sub    rsp,0x28
  40ece6:	mov    rbx,rcx
  40ece9:	mov    DWORD PTR [rsp+0x8],0xbf0
  40ecf1:	mov    ecx,0xbf0
  40ecf6:	call   410a70 <__swc_fn_7069e055_000083_4a10c7e7>
  40ecfb:	mov    rsi,rax
  40ecfe:	test   rax,rax
  40ed01:	jne    40ed0c <__swc_fn_7069e055_000172_cbeff767+0x2c>
  40ed03:	xor    eax,eax
  40ed05:	add    rsp,0x28
  40ed09:	pop    rsi
  40ed0a:	pop    rbx
  40ed0b:	ret
  40ed0c:	vxorps xmm0,xmm0,xmm0
  40ed10:	xor    eax,eax
  40ed12:	cs nop WORD PTR [rax+rax*1+0x0]
  40ed1c:	nop    DWORD PTR [rax+0x0]
  40ed20:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40ed25:	add    rax,0x10
  40ed29:	cmp    rax,0xbf0
  40ed30:	jne    40ed20 <__swc_fn_7069e055_000172_cbeff767+0x40>
  40ed32:	lea    rax,[rbx+0x1]
  40ed36:	mov    QWORD PTR [rsi+0x9c0],rax
  40ed3d:	mov    rcx,rbx
  40ed40:	mov    rdx,rsi
  40ed43:	call   412000 <__swc_fn_7069e055_000170_646fdf20>
  40ed48:	test   al,al
  40ed4a:	jne    40ed5d <__swc_fn_7069e055_000172_cbeff767+0x7d>
  40ed4c:	mov    rcx,rsi
  40ed4f:	call   408d10 <__swc_fn_7069e055_000084_cf82995a>
  40ed54:	xor    eax,eax
  40ed56:	add    rsp,0x28
  40ed5a:	pop    rsi
  40ed5b:	pop    rbx
  40ed5c:	ret
  40ed5d:	lea    rcx,[rsp+0x18]
  40ed62:	call   409290 <__swc_fn_7069e055_000096_93bfe675>
  40ed67:	mov    rax,rsi
  40ed6a:	add    rsp,0x28
  40ed6e:	pop    rsi
  40ed6f:	pop    rbx
  40ed70:	ret
	...

000000000040ed80 <__swc_fn_7069e055_000175_e09f8b62>:
  40ed80:	xor    eax,eax
  40ed82:	mov    edx,0x1
  40ed87:	lock cmpxchg QWORD PTR [rcx],rdx
  40ed8c:	test   rax,rax
  40ed8f:	jne    40ed92 <__swc_fn_7069e055_000175_e09f8b62+0x12>
  40ed91:	ret
  40ed92:	cs nop WORD PTR [rax+rax*1+0x0]
  40ed9c:	nop    DWORD PTR [rax+0x0]
  40eda0:	mov    rax,QWORD PTR [rcx]
  40eda3:	test   rax,rax
  40eda6:	je     40ed80 <__swc_fn_7069e055_000175_e09f8b62>
  40eda8:	jmp    40eda0 <__swc_fn_7069e055_000175_e09f8b62+0x20>
  40edaa:	add    BYTE PTR [rax],al
  40edac:	add    BYTE PTR [rax],al
	...

000000000040edb0 <__swc_fn_7069e055_000178_718d7b54>:
  40edb0:	push   rsi
  40edb1:	push   rdi
  40edb2:	sub    rsp,0x38
  40edb6:	mov    rsi,rcx
  40edb9:	call   412010 <__swc_fn_7069e055_000173_1e0ea8cf>
  40edbe:	mov    rdi,rax
  40edc1:	call   4117a0 <__swc_fn_7069e055_000134_a9c1c700>
  40edc6:	mov    r8,rax
  40edc9:	mov    rcx,rdi
  40edcc:	call   40ed80 <__swc_fn_7069e055_000175_e09f8b62>
  40edd1:	mov    rax,QWORD PTR [rdi+0x8]
  40edd5:	test   rax,rax
  40edd8:	je     40ee15 <__swc_fn_7069e055_000178_718d7b54+0x65>
  40edda:	nop    WORD PTR [rax+rax*1+0x0]
  40ede0:	cmp    rax,rsi
  40ede3:	je     40ee15 <__swc_fn_7069e055_000178_718d7b54+0x65>
  40ede5:	mov    r9,QWORD PTR [rax]
  40ede8:	cmp    QWORD PTR [rax+0x20],r8
  40edec:	jne    40ee0d <__swc_fn_7069e055_000178_718d7b54+0x5d>
  40edee:	mov    rcx,rdi
  40edf1:	mov    rdx,rax
  40edf4:	mov    QWORD PTR [rsp+0x28],r8
  40edf9:	mov    QWORD PTR [rsp+0x30],r9
  40edfe:	call   40bc60 <__swc_fn_7069e055_000177_cf4ffedd>
  40ee03:	mov    r8,QWORD PTR [rsp+0x28]
  40ee08:	mov    r9,QWORD PTR [rsp+0x30]
  40ee0d:	mov    rax,r9
  40ee10:	test   r9,r9
  40ee13:	jne    40ede0 <__swc_fn_7069e055_000178_718d7b54+0x30>
  40ee15:	xor    eax,eax
  40ee17:	mov    QWORD PTR [rdi],rax
  40ee1a:	add    rsp,0x38
  40ee1e:	pop    rdi
  40ee1f:	pop    rsi
  40ee20:	ret
	...

000000000040ee40 <__swc_fn_7069e055_000002_1ca87929>:
  40ee40:	push   rdi
  40ee41:	push   rsi
  40ee42:	sub    rsp,0xb8
  40ee49:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ee4f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40ee55:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40ee5b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ee61:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ee67:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ee6d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40ee73:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40ee7c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ee85:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ee8e:	vxorps xmm0,xmm0,xmm0
  40ee92:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ee98:	mov    edi,0x1
  40ee9d:	lea    rsi,[rsp+0x8]
  40eea2:	xor    eax,eax
  40eea4:	call   407130 <clock_gettime@plt>
  40eea9:	vxorpd xmm0,xmm0,xmm0
  40eead:	mov    rax,QWORD PTR [rsp+0x8]
  40eeb2:	vcvtsi2sd xmm0,xmm0,rax
  40eeb7:	vxorpd xmm1,xmm1,xmm1
  40eebb:	mov    rax,QWORD PTR [rsp+0x10]
  40eec0:	vcvtsi2sd xmm1,xmm1,rax
  40eec5:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x4243]        # 413110 <__swc_rdata_base_7069e055>
  40eecd:	vaddsd xmm0,xmm0,xmm1
  40eed1:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40eed7:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40eedd:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40eee3:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40eee9:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40eeef:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40eef5:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40eefb:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ef04:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ef0d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ef16:	add    rsp,0xb8
  40ef1d:	pop    rsi
  40ef1e:	pop    rdi
  40ef1f:	ret

000000000040ef20 <__swc_fn_7069e055_000005_9ee35b18>:
  40ef20:	vxorps xmm0,xmm0,xmm0
  40ef24:	xor    eax,eax
  40ef26:	cs nop WORD PTR [rax+rax*1+0x0]
  40ef30:	cs nop WORD PTR [rax+rax*1+0x0]
  40ef3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ef40:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40ef45:	add    rax,0x10
  40ef49:	cmp    rax,0x2080
  40ef50:	jne    40ef40 <__swc_fn_7069e055_000005_9ee35b18+0x20>
  40ef52:	ret
	...

000000000040ef60 <__swc_fn_7069e055_000008_d64b2baa>:
  40ef60:	push   rsi
  40ef61:	push   rdi
  40ef62:	push   r12
  40ef64:	push   r13
  40ef66:	push   r14
  40ef68:	mov    rsi,rcx
  40ef6b:	mov    edi,r10d
  40ef6e:	mov    r12,rcx
  40ef71:	mov    r13,r9
  40ef74:	mov    ecx,DWORD PTR [rdx+0x28]
  40ef77:	shlx   r14d,r8d,ecx
  40ef7c:	mov    rcx,rdx
  40ef7f:	mov    edx,r8d
  40ef82:	call   407be0 <__swc_fn_7069e055_000015_9dea5065>
  40ef87:	mov    rcx,rax
  40ef8a:	mov    eax,DWORD PTR [r12+0x3c]
  40ef8f:	xor    edx,edx
  40ef91:	div    rdi
  40ef94:	vxorps xmm0,xmm0,xmm0
  40ef98:	vmovdqu XMMWORD PTR [rsi],xmm0
  40ef9c:	mov    QWORD PTR [r12+0x60],0x0
  40efa5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40efaa:	mov    QWORD PTR [r12+0x10],rcx
  40efaf:	imul   rax,rdi
  40efb3:	lea    rdx,[rcx+rax*1]
  40efb7:	mov    QWORD PTR [r12+0x18],rdx
  40efbc:	mov    QWORD PTR [r12+0x20],rcx
  40efc1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40efc6:	mov    DWORD PTR [r12+0x28],0x0
  40efcf:	mov    DWORD PTR [r12+0x68],0x0
  40efd8:	mov    BYTE PTR [r12+0x39],r13b
  40efdd:	mov    BYTE PTR [r12+0x3a],r14b
  40efe2:	mov    BYTE PTR [r12+0x3b],0x1
  40efe8:	mov    DWORD PTR [r12+0x6c],0x0
  40eff1:	mov    rcx,r12
  40eff4:	mov    edx,edi
  40eff6:	call   407b40 <__swc_fn_7069e055_000009_065ed5b1>
  40effb:	pop    r14
  40effd:	pop    r13
  40efff:	pop    r12
  40f001:	pop    rdi
  40f002:	pop    rsi
  40f003:	ret
	...

000000000040f010 <__swc_fn_7069e055_000011_c3647f66>:
  40f010:	mov    r8d,0x1
  40f016:	xor    eax,eax
  40f018:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40f01e:	test   eax,eax
  40f020:	jne    40f010 <__swc_fn_7069e055_000011_c3647f66>
  40f022:	ret
	...

000000000040f030 <__swc_fn_7069e055_000014_524c1f23>:
  40f030:	lea    r8,[rcx+0x60]
  40f034:	mov    rax,QWORD PTR [r8]
  40f037:	mov    r9,rax
  40f03a:	nop    WORD PTR [rax+rax*1+0x0]
  40f040:	mov    QWORD PTR [rdx],r9
  40f043:	mov    rax,r9
  40f046:	lock cmpxchg QWORD PTR [r8],rdx
  40f04b:	cmp    rax,r9
  40f04e:	jne    40f0b7 <__swc_fn_7069e055_000014_524c1f23+0x87>
  40f050:	mov    eax,DWORD PTR [rcx+0x6c]
  40f053:	test   eax,eax
  40f055:	je     40f0b6 <__swc_fn_7069e055_000014_524c1f23+0x86>
  40f057:	lea    rdx,[rcx+0x70]
  40f05b:	mov    r9d,0x1
  40f061:	xor    eax,eax
  40f063:	lock cmpxchg DWORD PTR [rdx],r9d
  40f068:	test   eax,eax
  40f06a:	jne    40f0b6 <__swc_fn_7069e055_000014_524c1f23+0x86>
  40f06c:	mov    rax,rcx
  40f06f:	and    rax,0xffffffffffc00000
  40f076:	mov    rax,QWORD PTR [rax+0x8]
  40f07a:	test   rax,rax
  40f07d:	jne    40f085 <__swc_fn_7069e055_000014_524c1f23+0x55>
  40f07f:	xor    eax,eax
  40f081:	xchg   DWORD PTR [rdx],eax
  40f083:	jmp    40f0b6 <__swc_fn_7069e055_000014_524c1f23+0x86>
  40f085:	lea    rdx,[rax+0x2a80]
  40f08c:	mov    rax,QWORD PTR [rdx]
  40f08f:	mov    r8,rax
  40f092:	cs nop WORD PTR [rax+rax*1+0x0]
  40f09c:	nop    DWORD PTR [rax+0x0]
  40f0a0:	mov    QWORD PTR [rcx+0x78],r8
  40f0a4:	mov    rax,r8
  40f0a7:	lock cmpxchg QWORD PTR [rdx],rcx
  40f0ac:	cmp    rax,r8
  40f0af:	je     40f0b6 <__swc_fn_7069e055_000014_524c1f23+0x86>
  40f0b1:	mov    r8,rax
  40f0b4:	jmp    40f0a0 <__swc_fn_7069e055_000014_524c1f23+0x70>
  40f0b6:	ret
  40f0b7:	mov    r9,rax
  40f0ba:	jmp    40f040 <__swc_fn_7069e055_000014_524c1f23+0x10>
	...

000000000040f0c0 <__swc_fn_7069e055_000017_efc44797>:
  40f0c0:	push   rsi
  40f0c1:	push   rdi
  40f0c2:	push   r12
  40f0c4:	push   r13
  40f0c6:	push   r14
  40f0c8:	push   r15
  40f0ca:	push   rbx
  40f0cb:	sub    rsp,0x30
  40f0cf:	mov    QWORD PTR [rsp+0x18],r8
  40f0d4:	mov    rsi,rcx
  40f0d7:	mov    rdi,rdx
  40f0da:	mov    rdx,QWORD PTR [rsi+0x40]
  40f0de:	xchg   ax,ax
  40f0e0:	mov    rax,rdx
  40f0e3:	not    rax
  40f0e6:	and    rax,QWORD PTR [rsi+0x20]
  40f0ea:	test   rax,rax
  40f0ed:	jne    40f101 <__swc_fn_7069e055_000017_efc44797+0x41>
  40f0ef:	xor    eax,eax
  40f0f1:	add    rsp,0x30
  40f0f5:	pop    rbx
  40f0f6:	pop    r15
  40f0f8:	pop    r14
  40f0fa:	pop    r13
  40f0fc:	pop    r12
  40f0fe:	pop    rdi
  40f0ff:	pop    rsi
  40f100:	ret
  40f101:	xor    ecx,ecx
  40f103:	tzcnt  rcx,rax
  40f108:	lea    r12,[rsp+0x8]
  40f10d:	mov    DWORD PTR [rsp+0x8],ecx
  40f111:	mov    r13d,0x1
  40f117:	shl    r13,cl
  40f11a:	mov    rcx,rdx
  40f11d:	or     rcx,r13
  40f120:	mov    rax,rdx
  40f123:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40f129:	cmp    rax,rdx
  40f12c:	je     40f133 <__swc_fn_7069e055_000017_efc44797+0x73>
  40f12e:	mov    rdx,rax
  40f131:	jmp    40f0e0 <__swc_fn_7069e055_000017_efc44797+0x20>
  40f133:	mov    eax,DWORD PTR [r12]
  40f137:	shl    rax,0x4
  40f13b:	lea    r14,[rsi+rax*8+0x80]
  40f143:	mov    rcx,rsi
  40f146:	mov    rax,r12
  40f149:	mov    edx,DWORD PTR [rax]
  40f14b:	call   407be0 <__swc_fn_7069e055_000015_9dea5065>
  40f150:	mov    r15,rax
  40f153:	mov    rcx,rsi
  40f156:	mov    rdx,r13
  40f159:	call   407d40 <__swc_fn_7069e055_000021_fd2b165c>
  40f15e:	test   al,al
  40f160:	je     40f198 <__swc_fn_7069e055_000017_efc44797+0xd8>
  40f162:	mov    ecx,DWORD PTR [r14+0x3c]
  40f166:	lea    rdx,[rip+0x14f1b]        # 424088 <__swc_bss_base_7069e055+0x48>
  40f16d:	mov    r8,QWORD PTR [rip+0x14f14]        # 424088 <__swc_bss_base_7069e055+0x48>
  40f174:	cs nop WORD PTR [rax+rax*1+0x0]
  40f17e:	xchg   ax,ax
  40f180:	mov    r9,r8
  40f183:	sub    r9,rcx
  40f186:	mov    rax,r8
  40f189:	lock cmpxchg QWORD PTR [rdx],r9
  40f18e:	cmp    rax,r8
  40f191:	je     40f1f9 <__swc_fn_7069e055_000017_efc44797+0x139>
  40f193:	mov    r8,rax
  40f196:	jmp    40f180 <__swc_fn_7069e055_000017_efc44797+0xc0>
  40f198:	mov    rcx,rsi
  40f19b:	mov    rax,r12
  40f19e:	mov    edx,DWORD PTR [rax]
  40f1a0:	call   40bf40 <__swc_fn_7069e055_000016_9afb7cfb>
  40f1a5:	mov    rcx,r15
  40f1a8:	and    rcx,0xffffffffffff0000
  40f1af:	lea    rcx,[rcx+0x10000]
  40f1b6:	mov    rbx,rax
  40f1b9:	cmp    rax,rcx
  40f1bc:	cmova  rbx,rcx
  40f1c0:	mov    rax,rbx
  40f1c3:	sub    rax,r15
  40f1c6:	mov    rcx,r15
  40f1c9:	mov    rdx,rax
  40f1cc:	call   40bd90 <__swc_fn_7069e055_000007_f7acedb0>
  40f1d1:	test   al,al
  40f1d3:	jne    40f1f2 <__swc_fn_7069e055_000017_efc44797+0x132>
  40f1d5:	mov    rcx,rsi
  40f1d8:	mov    rdx,r13
  40f1db:	call   40c0f0 <__swc_fn_7069e055_000022_c8f5f27c>
  40f1e0:	xor    eax,eax
  40f1e2:	add    rsp,0x30
  40f1e6:	pop    rbx
  40f1e7:	pop    r15
  40f1e9:	pop    r14
  40f1eb:	pop    r13
  40f1ed:	pop    r12
  40f1ef:	pop    rdi
  40f1f0:	pop    rsi
  40f1f1:	ret
  40f1f2:	sub    rbx,r15
  40f1f5:	mov    DWORD PTR [r14+0x3c],ebx
  40f1f9:	mov    rcx,r14
  40f1fc:	mov    rdx,rsi
  40f1ff:	mov    r8d,DWORD PTR [r12]
  40f203:	mov    r9d,edi
  40f206:	mov    rbx,QWORD PTR [rsp+0x18]
  40f20b:	mov    r10d,ebx
  40f20e:	call   40ef60 <__swc_fn_7069e055_000008_d64b2baa>
  40f213:	mov    rax,r14
  40f216:	add    rsp,0x30
  40f21a:	pop    rbx
  40f21b:	pop    r15
  40f21d:	pop    r14
  40f21f:	pop    r13
  40f221:	pop    r12
  40f223:	pop    rdi
  40f224:	pop    rsi
  40f225:	ret
	...

000000000040f230 <__swc_fn_7069e055_000020_de02dbdf>:
  40f230:	mov    r8,QWORD PTR [rcx+0x48]
  40f234:	cs nop WORD PTR [rax+rax*1+0x0]
  40f23e:	xchg   ax,ax
  40f240:	mov    r9,r8
  40f243:	or     r9,rdx
  40f246:	mov    rax,r8
  40f249:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40f24f:	cmp    rax,r8
  40f252:	jne    40f255 <__swc_fn_7069e055_000020_de02dbdf+0x25>
  40f254:	ret
  40f255:	mov    r8,rax
  40f258:	jmp    40f240 <__swc_fn_7069e055_000020_de02dbdf+0x10>
  40f25a:	add    BYTE PTR [rax],al
  40f25c:	add    BYTE PTR [rax],al
	...

000000000040f260 <__swc_fn_7069e055_000023_2d0fcd2c>:
  40f260:	push   rsi
  40f261:	push   rdi
  40f262:	push   r12
  40f264:	mov    rsi,rcx
  40f267:	xor    edi,edi
  40f269:	lea    r12,[rip+0x14e28]        # 424098 <__swc_bss_base_7069e055+0x58>
  40f270:	mov    eax,DWORD PTR [r12]
  40f274:	xor    ecx,ecx
  40f276:	test   rax,rax
  40f279:	jbe    40f2b4 <__swc_fn_7069e055_000023_2d0fcd2c+0x54>
  40f27b:	nop    DWORD PTR [rax+rax*1+0x0]
  40f280:	lea    rdx,[rip+0x14e19]        # 4240a0 <__swc_bss_base_7069e055+0x60>
  40f287:	mov    r8d,ecx
  40f28a:	lea    r8,[r8+r8*2]
  40f28e:	lea    r8,[rdx+r8*8]
  40f292:	mov    rdx,QWORD PTR [r8+0x10]
  40f296:	add    rdx,0x400000
  40f29d:	cmp    rdx,0x40000000
  40f2a4:	ja     40f2ab <__swc_fn_7069e055_000023_2d0fcd2c+0x4b>
  40f2a6:	mov    rdi,r8
  40f2a9:	jmp    40f2b4 <__swc_fn_7069e055_000023_2d0fcd2c+0x54>
  40f2ab:	add    rcx,0x1
  40f2af:	cmp    rcx,rax
  40f2b2:	jb     40f280 <__swc_fn_7069e055_000023_2d0fcd2c+0x20>
  40f2b4:	test   rdi,rdi
  40f2b7:	jne    40f343 <__swc_fn_7069e055_000023_2d0fcd2c+0xe3>
  40f2bd:	cmp    DWORD PTR [r12],0x10
  40f2c2:	jae    40f32b <__swc_fn_7069e055_000023_2d0fcd2c+0xcb>
  40f2c4:	mov    ecx,0x40400000
  40f2c9:	call   407b00 <__swc_fn_7069e055_000006_81d2e1e9>
  40f2ce:	test   rax,rax
  40f2d1:	je     40f32b <__swc_fn_7069e055_000023_2d0fcd2c+0xcb>
  40f2d3:	lea    rcx,[rip+0x14dc6]        # 4240a0 <__swc_bss_base_7069e055+0x60>
  40f2da:	mov    edx,DWORD PTR [r12]
  40f2de:	lea    rdx,[rdx+rdx*2]
  40f2e2:	lea    rdx,[rcx+rdx*8]
  40f2e6:	mov    QWORD PTR [rdx],rax
  40f2e9:	lea    rax,[rax+0x3fffff]
  40f2f0:	and    rax,0xffffffffffc00000
  40f2f7:	mov    QWORD PTR [rdx+0x8],rax
  40f2fb:	mov    QWORD PTR [rdx+0x10],0x0
  40f303:	mov    edx,DWORD PTR [rip+0x14d8f]        # 424098 <__swc_bss_base_7069e055+0x58>
  40f309:	nop    DWORD PTR [rax+0x0]
  40f310:	lea    r9d,[rdx+0x1]
  40f314:	mov    rax,rdx
  40f317:	lock cmpxchg DWORD PTR [r12],r9d
  40f31d:	mov    r8d,eax
  40f320:	cmp    eax,edx
  40f322:	je     40f332 <__swc_fn_7069e055_000023_2d0fcd2c+0xd2>
  40f324:	mov    rdx,r8
  40f327:	jmp    40f310 <__swc_fn_7069e055_000023_2d0fcd2c+0xb0>
  40f329:	jmp    40f332 <__swc_fn_7069e055_000023_2d0fcd2c+0xd2>
  40f32b:	xor    eax,eax
  40f32d:	pop    r12
  40f32f:	pop    rdi
  40f330:	pop    rsi
  40f331:	ret
  40f332:	mov    eax,DWORD PTR [rip+0x14d60]        # 424098 <__swc_bss_base_7069e055+0x58>
  40f338:	sub    eax,0x1
  40f33b:	lea    rdi,[rax+rax*2]
  40f33f:	lea    rdi,[rcx+rdi*8]
  40f343:	mov    r12,QWORD PTR [rdi+0x8]
  40f347:	add    r12,QWORD PTR [rdi+0x10]
  40f34b:	mov    rcx,r12
  40f34e:	mov    edx,0x3000
  40f353:	call   40bd90 <__swc_fn_7069e055_000007_f7acedb0>
  40f358:	test   al,al
  40f35a:	jne    40f363 <__swc_fn_7069e055_000023_2d0fcd2c+0x103>
  40f35c:	xor    eax,eax
  40f35e:	pop    r12
  40f360:	pop    rdi
  40f361:	pop    rsi
  40f362:	ret
  40f363:	vxorps xmm0,xmm0,xmm0
  40f367:	xor    eax,eax
  40f369:	cs nop WORD PTR [rax+rax*1+0x0]
  40f373:	cs nop WORD PTR [rax+rax*1+0x0]
  40f37d:	nop    DWORD PTR [rax]
  40f380:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40f386:	add    rax,0x10
  40f38a:	cmp    rax,0x3000
  40f391:	jne    40f380 <__swc_fn_7069e055_000023_2d0fcd2c+0x120>
  40f393:	mov    DWORD PTR [r12+0x28],esi
  40f398:	mov    eax,0x40
  40f39d:	mov    ecx,esi
  40f39f:	shr    eax,cl
  40f3a1:	mov    DWORD PTR [r12+0x2c],eax
  40f3a6:	cmp    DWORD PTR [r12+0x2c],0x40
  40f3ac:	jb     40f3b7 <__swc_fn_7069e055_000023_2d0fcd2c+0x157>
  40f3ae:	mov    rax,0xffffffffffffffff
  40f3b5:	jmp    40f3c7 <__swc_fn_7069e055_000023_2d0fcd2c+0x167>
  40f3b7:	mov    eax,0x1
  40f3bc:	mov    ecx,DWORD PTR [r12+0x2c]
  40f3c1:	shl    rax,cl
  40f3c4:	dec    rax
  40f3c7:	mov    QWORD PTR [r12+0x20],rax
  40f3cc:	mov    DWORD PTR [r12],0x4e540001
  40f3d4:	mov    DWORD PTR [r12+0x4],0x53474d45
  40f3dd:	add    QWORD PTR [rdi+0x10],0x400000
  40f3e5:	mov    rax,r12
  40f3e8:	pop    r12
  40f3ea:	pop    rdi
  40f3eb:	pop    rsi
  40f3ec:	ret
  40f3ed:	add    BYTE PTR [rax],al
	...

000000000040f3f0 <__swc_fn_7069e055_000026_bcdc5519>:
  40f3f0:	mov    eax,0x1
  40f3f5:	mov    edx,DWORD PTR [rip+0x14c9d]        # 424098 <__swc_bss_base_7069e055+0x58>
  40f3fb:	cmp    eax,edx
  40f3fd:	jae    40f44b <__swc_fn_7069e055_000026_bcdc5519+0x5b>
  40f3ff:	nop
  40f400:	lea    r8,[rip+0x14c99]        # 4240a0 <__swc_bss_base_7069e055+0x60>
  40f407:	lea    r9,[rax+rax*2]
  40f40b:	lea    r9,[r8+r9*8]
  40f40f:	mov    r8,rcx
  40f412:	sub    r8,QWORD PTR [r9+0x8]
  40f416:	mov    r9,QWORD PTR [r9+0x10]
  40f41a:	cmp    r8,r9
  40f41d:	jae    40f445 <__swc_fn_7069e055_000026_bcdc5519+0x55>
  40f41f:	mov    rax,rcx
  40f422:	and    rax,0xffffffffffc00000
  40f429:	shr    rcx,0x10
  40f42d:	and    ecx,0x3f
  40f430:	mov    edx,DWORD PTR [rax+0x28]
  40f433:	shrx   ecx,ecx,edx
  40f438:	shl    rcx,0x4
  40f43c:	lea    rax,[rax+rcx*8+0x80]
  40f444:	ret
  40f445:	inc    eax
  40f447:	cmp    eax,edx
  40f449:	jb     40f400 <__swc_fn_7069e055_000026_bcdc5519+0x10>
  40f44b:	xor    eax,eax
  40f44d:	ret
	...

000000000040f450 <__swc_fn_7069e055_000029_9798fb47>:
  40f450:	vxorps xmm0,xmm0,xmm0
  40f454:	vmovups XMMWORD PTR [rcx],xmm0
  40f458:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f45d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f462:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f467:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40f46c:	mov    QWORD PTR [rcx+0x50],0x0
  40f474:	ret
	...

000000000040f480 <__swc_fn_7069e055_000032_9798fb47>:
  40f480:	vxorps xmm0,xmm0,xmm0
  40f484:	xor    eax,eax
  40f486:	cs nop WORD PTR [rax+rax*1+0x0]
  40f490:	cs nop WORD PTR [rax+rax*1+0x0]
  40f49a:	nop    WORD PTR [rax+rax*1+0x0]
  40f4a0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40f4a5:	add    rax,0x10
  40f4a9:	cmp    rax,0x9b0
  40f4b0:	jne    40f4a0 <__swc_fn_7069e055_000032_9798fb47+0x20>
  40f4b2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40f4bd:	ret
	...

000000000040f4c0 <__swc_fn_7069e055_000035_cd1a4e8c>:
  40f4c0:	push   rsi
  40f4c1:	push   rdi
  40f4c2:	sub    rsp,0x8
  40f4c6:	lea    rsi,[rip+0x12b43]        # 422010 <__swc_data_base_7069e055+0x10>
  40f4cd:	mov    rax,QWORD PTR [rsi]
  40f4d0:	mov    ecx,0xffffffff
  40f4d5:	cmp    rax,rcx
  40f4d8:	je     40f4e1 <__swc_fn_7069e055_000035_cd1a4e8c+0x21>
  40f4da:	add    rsp,0x8
  40f4de:	pop    rdi
  40f4df:	pop    rsi
  40f4e0:	ret
  40f4e1:	mov    rcx,QWORD PTR [rip+0x3c08]        # 4130f0 <__swc_fn_7069e055_000176_4de704de+0x1090>
  40f4e8:	call   40e130 <__swc_fn_7069e055_000130_4a82cdf6>
  40f4ed:	mov    rcx,rax
  40f4f0:	mov    eax,0xffffffff
  40f4f5:	lock cmpxchg QWORD PTR [rsi],rcx
  40f4fa:	mov    rdi,rax
  40f4fd:	mov    eax,0xffffffff
  40f502:	cmp    rdi,rax
  40f505:	je     40f516 <__swc_fn_7069e055_000035_cd1a4e8c+0x56>
  40f507:	call   4116f0 <__swc_fn_7069e055_000131_a611b8c4>
  40f50c:	mov    rax,rdi
  40f50f:	add    rsp,0x8
  40f513:	pop    rdi
  40f514:	pop    rsi
  40f515:	ret
  40f516:	mov    rax,rcx
  40f519:	add    rsp,0x8
  40f51d:	pop    rdi
  40f51e:	pop    rsi
  40f51f:	ret

000000000040f520 <__swc_fn_7069e055_000038_14f56618>:
  40f520:	sub    rsp,0x8
  40f524:	vxorps xmm0,xmm0,xmm0
  40f528:	xor    eax,eax
  40f52a:	cs nop WORD PTR [rax+rax*1+0x0]
  40f534:	cs nop WORD PTR [rax+rax*1+0x0]
  40f53e:	xchg   ax,ax
  40f540:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40f545:	add    rax,0x10
  40f549:	cmp    rax,0x2b00
  40f550:	jne    40f540 <__swc_fn_7069e055_000038_14f56618+0x20>
  40f552:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40f55c:	xor    al,al
  40f55e:	mov    rdx,rax
  40f561:	xor    al,al
  40f563:	mov    r8,rax
  40f566:	xor    al,al
  40f568:	mov    r9,rax
  40f56b:	xor    al,al
  40f56d:	mov    r10,rax
  40f570:	xor    al,al
  40f572:	mov    r11,rax
  40f575:	call   407f70 <__swc_fn_7069e055_000039_03f1bf9a>
  40f57a:	add    rsp,0x8
  40f57e:	ret
	...

000000000040f580 <__swc_fn_7069e055_000041_c90d80c1>:
  40f580:	push   rsi
  40f581:	push   rdi
  40f582:	push   r12
  40f584:	mov    rsi,r8
  40f587:	mov    rdi,rdx
  40f58a:	mov    rcx,rdx
  40f58d:	call   407b00 <__swc_fn_7069e055_000006_81d2e1e9>
  40f592:	mov    r12,rax
  40f595:	test   rax,rax
  40f598:	jne    40f5a1 <__swc_fn_7069e055_000041_c90d80c1+0x21>
  40f59a:	xor    eax,eax
  40f59c:	pop    r12
  40f59e:	pop    rdi
  40f59f:	pop    rsi
  40f5a0:	ret
  40f5a1:	mov    rcx,r12
  40f5a4:	mov    rdx,rsi
  40f5a7:	call   40bd90 <__swc_fn_7069e055_000007_f7acedb0>
  40f5ac:	test   al,al
  40f5ae:	jne    40f5c2 <__swc_fn_7069e055_000041_c90d80c1+0x42>
  40f5b0:	mov    rcx,r12
  40f5b3:	mov    rdx,rdi
  40f5b6:	call   409d70 <__swc_fn_7069e055_000117_ed2d8fed>
  40f5bb:	xor    eax,eax
  40f5bd:	pop    r12
  40f5bf:	pop    rdi
  40f5c0:	pop    rsi
  40f5c1:	ret
  40f5c2:	mov    rax,r12
  40f5c5:	pop    r12
  40f5c7:	pop    rdi
  40f5c8:	pop    rsi
  40f5c9:	ret
	...

000000000040f5e0 <__swc_fn_7069e055_000044_a78ae66b>:
  40f5e0:	push   rsi
  40f5e1:	push   rdi
  40f5e2:	push   r12
  40f5e4:	mov    rsi,rcx
  40f5e7:	mov    edx,0x9b8
  40f5ec:	call   407fe0 <__swc_fn_7069e055_000042_facd3e17>
  40f5f1:	mov    rdi,rax
  40f5f4:	test   rax,rax
  40f5f7:	jne    40f600 <__swc_fn_7069e055_000044_a78ae66b+0x20>
  40f5f9:	xor    eax,eax
  40f5fb:	pop    r12
  40f5fd:	pop    rdi
  40f5fe:	pop    rsi
  40f5ff:	ret
  40f600:	vxorps xmm0,xmm0,xmm0
  40f604:	xor    eax,eax
  40f606:	cs nop WORD PTR [rax+rax*1+0x0]
  40f610:	cs nop WORD PTR [rax+rax*1+0x0]
  40f61a:	nop    WORD PTR [rax+rax*1+0x0]
  40f620:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40f625:	add    rax,0x10
  40f629:	cmp    rax,0x9b0
  40f630:	jne    40f620 <__swc_fn_7069e055_000044_a78ae66b+0x40>
  40f632:	mov    QWORD PTR [rdi+0x9b0],0x0
  40f63d:	mov    QWORD PTR [rdi],rsi
  40f640:	call   4117a0 <__swc_fn_7069e055_000134_a9c1c700>
  40f645:	mov    QWORD PTR [rdi+0x18],rax
  40f649:	lea    r12,[rsi+0x10]
  40f64d:	mov    rcx,r12
  40f650:	call   40e380 <__swc_fn_7069e055_000139_86bb0f90>
  40f655:	mov    rax,QWORD PTR [rsi+0x20]
  40f659:	mov    QWORD PTR [rdi+0x8],rax
  40f65d:	mov    rax,QWORD PTR [rsi+0x20]
  40f661:	test   rax,rax
  40f664:	je     40f66a <__swc_fn_7069e055_000044_a78ae66b+0x8a>
  40f666:	mov    QWORD PTR [rax+0x10],rdi
  40f66a:	mov    QWORD PTR [rsi+0x20],rdi
  40f66e:	mov    rcx,r12
  40f671:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40f676:	mov    rax,rdi
  40f679:	pop    r12
  40f67b:	pop    rdi
  40f67c:	pop    rsi
  40f67d:	ret
	...

000000000040f680 <__swc_fn_7069e055_000047_6e7a8d58>:
  40f680:	mov    rax,QWORD PTR [rdx+0x10]
  40f684:	test   rax,rax
  40f687:	je     40f693 <__swc_fn_7069e055_000047_6e7a8d58+0x13>
  40f689:	mov    rcx,QWORD PTR [rdx+0x8]
  40f68d:	mov    QWORD PTR [rax+0x8],rcx
  40f691:	jmp    40f69b <__swc_fn_7069e055_000047_6e7a8d58+0x1b>
  40f693:	mov    rax,QWORD PTR [rdx+0x8]
  40f697:	mov    QWORD PTR [rcx+0x20],rax
  40f69b:	mov    rax,QWORD PTR [rdx+0x8]
  40f69f:	test   rax,rax
  40f6a2:	je     40f6ac <__swc_fn_7069e055_000047_6e7a8d58+0x2c>
  40f6a4:	mov    rcx,QWORD PTR [rdx+0x10]
  40f6a8:	mov    QWORD PTR [rax+0x10],rcx
  40f6ac:	vxorps xmm0,xmm0,xmm0
  40f6b0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40f6b5:	ret
	...

000000000040f6c0 <__swc_fn_7069e055_000050_129b9bf4>:
  40f6c0:	sub    rsp,0x8
  40f6c4:	mov    r9,r8
  40f6c7:	mov    r10,rdx
  40f6ca:	call   408090 <__swc_fn_7069e055_000048_137687bb>
  40f6cf:	mov    eax,0x1
  40f6d4:	xchg   DWORD PTR [r9+0x6c],eax
  40f6d8:	mov    rax,QWORD PTR [r9+0x60]
  40f6dc:	test   rax,rax
  40f6df:	je     40f723 <__swc_fn_7069e055_000050_129b9bf4+0x63>
  40f6e1:	xor    eax,eax
  40f6e3:	xchg   DWORD PTR [r9+0x6c],eax
  40f6e7:	movzx  eax,BYTE PTR [r9+0x39]
  40f6ec:	lea    rax,[rax+rax*4]
  40f6f0:	lea    rax,[r10+rax*8+0x28]
  40f6f5:	mov    QWORD PTR [r9+0x50],0x0
  40f6fd:	mov    rcx,QWORD PTR [rax+0x8]
  40f701:	mov    QWORD PTR [r9+0x48],rcx
  40f705:	mov    rcx,QWORD PTR [rax+0x8]
  40f709:	test   rcx,rcx
  40f70c:	je     40f714 <__swc_fn_7069e055_000050_129b9bf4+0x54>
  40f70e:	mov    QWORD PTR [rcx+0x50],r9
  40f712:	jmp    40f718 <__swc_fn_7069e055_000050_129b9bf4+0x58>
  40f714:	mov    QWORD PTR [rax+0x10],r9
  40f718:	mov    QWORD PTR [rax+0x8],r9
  40f71c:	xor    eax,eax
  40f71e:	add    rsp,0x8
  40f722:	ret
  40f723:	movzx  eax,BYTE PTR [r9+0x39]
  40f728:	lea    rax,[rax+rax*4]
  40f72c:	lea    rax,[r10+rax*8+0x28]
  40f731:	mov    QWORD PTR [r9+0x50],0x0
  40f739:	mov    rcx,QWORD PTR [rax+0x18]
  40f73d:	mov    QWORD PTR [r9+0x48],rcx
  40f741:	mov    rcx,QWORD PTR [rax+0x18]
  40f745:	test   rcx,rcx
  40f748:	je     40f74e <__swc_fn_7069e055_000050_129b9bf4+0x8e>
  40f74a:	mov    QWORD PTR [rcx+0x50],r9
  40f74e:	mov    QWORD PTR [rax+0x18],r9
  40f752:	mov    eax,0x1
  40f757:	add    rsp,0x8
  40f75b:	ret
  40f75c:	add    BYTE PTR [rax],al
	...

000000000040f760 <__swc_fn_7069e055_000053_3af34d7f>:
  40f760:	push   r12
  40f762:	push   r13
  40f764:	push   rdi
  40f765:	push   rsi
  40f766:	push   r14
  40f768:	push   r15
  40f76a:	sub    rsp,0x178
  40f771:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40f77a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40f783:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40f78c:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40f795:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40f79e:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40f7a7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40f7b0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40f7b9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40f7c2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40f7cb:	mov    r12,rcx
  40f7ce:	lea    rax,[rip+0x14a5b]        # 424230 <__swc_bss_base_7069e055+0x1f0>
  40f7d5:	mov    rcx,QWORD PTR [rax]
  40f7d8:	mov    r13,rcx
  40f7db:	test   rcx,rcx
  40f7de:	jne    40f7ee <__swc_fn_7069e055_000053_3af34d7f+0x8e>
  40f7e0:	mov    r13d,0x1dcd6500
  40f7e6:	mov    ecx,0x1dcd6500
  40f7eb:	xchg   QWORD PTR [rax],rcx
  40f7ee:	lea    rax,[rip+0x12813]        # 422008 <__swc_data_base_7069e055+0x8>
  40f7f5:	mov    rax,QWORD PTR [rax]
  40f7f8:	cmp    rax,0xffffffffffffffff
  40f7fc:	je     40f80b <__swc_fn_7069e055_000053_3af34d7f+0xab>
  40f7fe:	mov    eax,eax
  40f800:	mov    edi,eax
  40f802:	xor    eax,eax
  40f804:	call   407000 <pthread_getspecific@plt>
  40f809:	jmp    40f80d <__swc_fn_7069e055_000053_3af34d7f+0xad>
  40f80b:	xor    eax,eax
  40f80d:	test   rax,rax
  40f810:	jne    40f81f <__swc_fn_7069e055_000053_3af34d7f+0xbf>
  40f812:	call   40f4c0 <__swc_fn_7069e055_000035_cd1a4e8c>
  40f817:	mov    rcx,rax
  40f81a:	call   40a0c0 <__swc_fn_7069e055_000132_5f757033>
  40f81f:	test   rax,rax
  40f822:	je     40f834 <__swc_fn_7069e055_000053_3af34d7f+0xd4>
  40f824:	cmp    QWORD PTR [rax],r12
  40f827:	jne    40f834 <__swc_fn_7069e055_000053_3af34d7f+0xd4>
  40f829:	cmp    DWORD PTR [rax+0x20],0x0
  40f82d:	jne    40f834 <__swc_fn_7069e055_000053_3af34d7f+0xd4>
  40f82f:	mov    rsi,rax
  40f832:	jmp    40f836 <__swc_fn_7069e055_000053_3af34d7f+0xd6>
  40f834:	xor    esi,esi
  40f836:	lea    rdi,[r12+0x2a88]
  40f83e:	mov    r14,QWORD PTR [rdi]
  40f841:	test   r14,r14
  40f844:	jne    40f893 <__swc_fn_7069e055_000053_3af34d7f+0x133>
  40f846:	lea    rax,[rip+0x1483b]        # 424088 <__swc_bss_base_7069e055+0x48>
  40f84d:	mov    rax,QWORD PTR [rax]
  40f850:	test   rax,rax
  40f853:	setne  al
  40f856:	jne    40f87a <__swc_fn_7069e055_000053_3af34d7f+0x11a>
  40f858:	mov    rax,QWORD PTR [r12+0x2a70]
  40f860:	test   rax,rax
  40f863:	setne  al
  40f866:	jne    40f87a <__swc_fn_7069e055_000053_3af34d7f+0x11a>
  40f868:	test   rsi,rsi
  40f86b:	setne  al
  40f86e:	je     40f87a <__swc_fn_7069e055_000053_3af34d7f+0x11a>
  40f870:	cmp    DWORD PTR [rsi+0x730],0x0
  40f877:	setne  al
  40f87a:	test   al,al
  40f87c:	je     40f88e <__swc_fn_7069e055_000053_3af34d7f+0x12e>
  40f87e:	call   40a170 <__swc_fn_7069e055_000135_07d76562>
  40f883:	lea    rcx,[rax+r13*1]
  40f887:	xor    eax,eax
  40f889:	lock cmpxchg QWORD PTR [rdi],rcx
  40f88e:	jmp    40f993 <__swc_fn_7069e055_000053_3af34d7f+0x233>
  40f893:	call   40a170 <__swc_fn_7069e055_000135_07d76562>
  40f898:	mov    r15,rax
  40f89b:	cmp    rax,r14
  40f89e:	jb     40f8af <__swc_fn_7069e055_000053_3af34d7f+0x14f>
  40f8a0:	xor    ecx,ecx
  40f8a2:	mov    rax,r14
  40f8a5:	lock cmpxchg QWORD PTR [rdi],rcx
  40f8aa:	cmp    rax,r14
  40f8ad:	je     40f8b4 <__swc_fn_7069e055_000053_3af34d7f+0x154>
  40f8af:	jmp    40f993 <__swc_fn_7069e055_000053_3af34d7f+0x233>
  40f8b4:	test   rsi,rsi
  40f8b7:	je     40f8d2 <__swc_fn_7069e055_000053_3af34d7f+0x172>
  40f8b9:	cmp    r15,r13
  40f8bc:	jb     40f8d2 <__swc_fn_7069e055_000053_3af34d7f+0x172>
  40f8be:	mov    rax,r15
  40f8c1:	sub    rax,r13
  40f8c4:	mov    rcx,r12
  40f8c7:	mov    rdx,rsi
  40f8ca:	mov    r8,rax
  40f8cd:	call   4084d0 <__swc_fn_7069e055_000063_dea90857>
  40f8d2:	lea    rsi,[r12+0x10]
  40f8d7:	mov    rcx,rsi
  40f8da:	call   40e380 <__swc_fn_7069e055_000139_86bb0f90>
  40f8df:	mov    rax,QWORD PTR [r12+0x18]
  40f8e4:	mov    rdi,rax
  40f8e7:	test   rdi,rdi
  40f8ea:	je     40f914 <__swc_fn_7069e055_000053_3af34d7f+0x1b4>
  40f8ec:	cs nop WORD PTR [rax+rax*1+0x0]
  40f8f6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f900:	mov    rcx,rdi
  40f903:	call   40bf60 <__swc_fn_7069e055_000019_adca76cf>
  40f908:	mov    rax,QWORD PTR [rdi+0x10]
  40f90c:	mov    rdi,rax
  40f90f:	test   rax,rax
  40f912:	jne    40f900 <__swc_fn_7069e055_000053_3af34d7f+0x1a0>
  40f914:	mov    rcx,rsi
  40f917:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40f91c:	mov    rcx,r12
  40f91f:	call   40e380 <__swc_fn_7069e055_000139_86bb0f90>
  40f924:	xor    esi,esi
  40f926:	cs nop WORD PTR [rax+rax*1+0x0]
  40f930:	mov    rax,QWORD PTR [r12+0x2a70]
  40f938:	cmp    rsi,rax
  40f93b:	jae    40f98b <__swc_fn_7069e055_000053_3af34d7f+0x22b>
  40f93d:	lea    rax,[rsi+rsi*4]
  40f941:	lea    rax,[r12+rax*8+0x268]
  40f949:	mov    r8,QWORD PTR [rax]
  40f94c:	mov    r9,QWORD PTR [rax+0x8]
  40f950:	mov    r10,QWORD PTR [rax+0x10]
  40f954:	mov    rax,QWORD PTR [rax+0x20]
  40f958:	cmp    rax,r15
  40f95b:	jae    40f968 <__swc_fn_7069e055_000053_3af34d7f+0x208>
  40f95d:	mov    rcx,r15
  40f960:	sub    rcx,rax
  40f963:	cmp    rcx,r13
  40f966:	jae    40f96d <__swc_fn_7069e055_000053_3af34d7f+0x20d>
  40f968:	inc    rsi
  40f96b:	jmp    40f930 <__swc_fn_7069e055_000053_3af34d7f+0x1d0>
  40f96d:	mov    rcx,r12
  40f970:	mov    rdx,rsi
  40f973:	call   408480 <__swc_fn_7069e055_000060_15c28ca7>
  40f978:	mov    rcx,r12
  40f97b:	mov    rdx,r8
  40f97e:	mov    r8,r9
  40f981:	mov    r9,r10
  40f984:	call   40c240 <__swc_fn_7069e055_000043_d3c2ab54>
  40f989:	jmp    40f930 <__swc_fn_7069e055_000053_3af34d7f+0x1d0>
  40f98b:	mov    rcx,r12
  40f98e:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40f993:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40f99c:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40f9a5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40f9ae:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40f9b7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40f9c0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40f9c9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40f9d2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40f9db:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40f9e4:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40f9ed:	add    rsp,0x178
  40f9f4:	pop    r15
  40f9f6:	pop    r14
  40f9f8:	pop    rsi
  40f9f9:	pop    rdi
  40f9fa:	pop    r13
  40f9fc:	pop    r12
  40f9fe:	ret
	...

000000000040fa00 <__swc_fn_7069e055_000056_df0696cd>:
  40fa00:	lea    rax,[rdx-0x58]
  40fa04:	ret
	...

000000000040fa10 <__swc_fn_7069e055_000059_2ca0cb05>:
  40fa10:	push   rsi
  40fa11:	push   rdi
  40fa12:	push   r12
  40fa14:	push   r13
  40fa16:	sub    rsp,0x68
  40fa1a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40fa20:	mov    rsi,r9
  40fa23:	mov    rdi,rcx
  40fa26:	mov    r12,rdx
  40fa29:	mov    r13,r8
  40fa2c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40fa34:	jne    40fa43 <__swc_fn_7069e055_000059_2ca0cb05+0x33>
  40fa36:	xor    eax,eax
  40fa38:	add    rsp,0x68
  40fa3c:	pop    r13
  40fa3e:	pop    r12
  40fa40:	pop    rdi
  40fa41:	pop    rsi
  40fa42:	ret
  40fa43:	mov    rcx,rdi
  40fa46:	call   40e380 <__swc_fn_7069e055_000139_86bb0f90>
  40fa4b:	movabs rax,0x7fffffffffffffff
  40fa55:	cmp    r12,rax
  40fa58:	mov    rax,0xffffffffffffffff
  40fa5f:	lea    rcx,[r12+r12*1]
  40fa63:	cmovbe rax,rcx
  40fa67:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40fa6e:	mov    rdx,rcx
  40fa71:	sub    rax,r12
  40fa74:	inc    rax
  40fa77:	xor    r8d,r8d
  40fa7a:	test   rcx,rcx
  40fa7d:	jbe    40faa8 <__swc_fn_7069e055_000059_2ca0cb05+0x98>
  40fa7f:	nop
  40fa80:	lea    r9,[r8+r8*4]
  40fa84:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40fa8c:	sub    r9,r12
  40fa8f:	cmp    r9,rax
  40fa92:	jae    40fa9f <__swc_fn_7069e055_000059_2ca0cb05+0x8f>
  40fa94:	mov    rdx,r8
  40fa97:	mov    rax,r9
  40fa9a:	test   r9,r9
  40fa9d:	je     40faa8 <__swc_fn_7069e055_000059_2ca0cb05+0x98>
  40fa9f:	add    r8,0x1
  40faa3:	cmp    r8,rcx
  40faa6:	jb     40fa80 <__swc_fn_7069e055_000059_2ca0cb05+0x70>
  40faa8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40faaf:	cmp    rdx,rax
  40fab2:	jne    40facf <__swc_fn_7069e055_000059_2ca0cb05+0xbf>
  40fab4:	mov    rcx,rdi
  40fab7:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40fabc:	xor    eax,eax
  40fabe:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40fac4:	add    rsp,0x68
  40fac8:	pop    r13
  40faca:	pop    r12
  40facc:	pop    rdi
  40facd:	pop    rsi
  40face:	ret
  40facf:	lea    rax,[rdx+rdx*4]
  40fad3:	lea    rax,[rdi+rax*8+0x268]
  40fadb:	vmovups xmm6,XMMWORD PTR [rax]
  40fadf:	mov    r8,QWORD PTR [rax+0x10]
  40fae3:	mov    rcx,rdi
  40fae6:	call   408480 <__swc_fn_7069e055_000060_15c28ca7>
  40faeb:	vpshufd xmm0,xmm6,0xee
  40faf0:	vmovsd QWORD PTR [r13+0x0],xmm0
  40faf6:	mov    QWORD PTR [rsi],r8
  40faf9:	mov    rcx,rdi
  40fafc:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40fb01:	vmovq  rax,xmm6
  40fb06:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40fb0c:	add    rsp,0x68
  40fb10:	pop    r13
  40fb12:	pop    r12
  40fb14:	pop    rdi
  40fb15:	pop    rsi
  40fb16:	ret
	...

000000000040fb20 <__swc_fn_7069e055_000062_b304235a>:
  40fb20:	push   r12
  40fb22:	push   r13
  40fb24:	push   r14
  40fb26:	push   r15
  40fb28:	push   rdi
  40fb29:	push   rsi
  40fb2a:	sub    rsp,0x148
  40fb31:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40fb3a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40fb43:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40fb4c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40fb55:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40fb5e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40fb67:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40fb70:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40fb79:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40fb82:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40fb8b:	mov    r12,r9
  40fb8e:	mov    r13,rcx
  40fb91:	mov    r14,rdx
  40fb94:	mov    r15,r8
  40fb97:	test   rdx,rdx
  40fb9a:	jne    40fbae <__swc_fn_7069e055_000062_b304235a+0x8e>
  40fb9c:	add    rsp,0x148
  40fba3:	pop    rsi
  40fba4:	pop    rdi
  40fba5:	pop    r15
  40fba7:	pop    r14
  40fba9:	pop    r13
  40fbab:	pop    r12
  40fbad:	ret
  40fbae:	cmp    r12,0x200000
  40fbb5:	ja     40fc47 <__swc_fn_7069e055_000062_b304235a+0x127>
  40fbbb:	lea    rax,[rip+0x12446]        # 422008 <__swc_data_base_7069e055+0x8>
  40fbc2:	mov    rax,QWORD PTR [rax]
  40fbc5:	cmp    rax,0xffffffffffffffff
  40fbc9:	je     40fbd8 <__swc_fn_7069e055_000062_b304235a+0xb8>
  40fbcb:	mov    eax,eax
  40fbcd:	mov    edi,eax
  40fbcf:	xor    eax,eax
  40fbd1:	call   407000 <pthread_getspecific@plt>
  40fbd6:	jmp    40fbda <__swc_fn_7069e055_000062_b304235a+0xba>
  40fbd8:	xor    eax,eax
  40fbda:	test   rax,rax
  40fbdd:	je     40fbe4 <__swc_fn_7069e055_000062_b304235a+0xc4>
  40fbdf:	mov    rsi,rax
  40fbe2:	jmp    40fbf4 <__swc_fn_7069e055_000062_b304235a+0xd4>
  40fbe4:	call   40f4c0 <__swc_fn_7069e055_000035_cd1a4e8c>
  40fbe9:	mov    rcx,rax
  40fbec:	call   40a0c0 <__swc_fn_7069e055_000132_5f757033>
  40fbf1:	mov    rsi,rax
  40fbf4:	test   rsi,rsi
  40fbf7:	je     40fc47 <__swc_fn_7069e055_000062_b304235a+0x127>
  40fbf9:	cmp    QWORD PTR [rsi],r13
  40fbfc:	jne    40fc47 <__swc_fn_7069e055_000062_b304235a+0x127>
  40fbfe:	cmp    DWORD PTR [rsi+0x20],0x0
  40fc02:	jne    40fc47 <__swc_fn_7069e055_000062_b304235a+0x127>
  40fc04:	cmp    DWORD PTR [rsi+0x730],0x10
  40fc0b:	jae    40fc47 <__swc_fn_7069e055_000062_b304235a+0x127>
  40fc0d:	mov    eax,DWORD PTR [rsi+0x730]
  40fc13:	lea    rdi,[rax+rax*4]
  40fc17:	lea    rdi,[rsi+rdi*8+0x738]
  40fc1f:	mov    QWORD PTR [rdi],r14
  40fc22:	mov    QWORD PTR [rdi+0x8],r15
  40fc26:	mov    QWORD PTR [rdi+0x10],r12
  40fc2a:	mov    QWORD PTR [rdi+0x18],0x0
  40fc32:	call   40a170 <__swc_fn_7069e055_000135_07d76562>
  40fc37:	mov    QWORD PTR [rdi+0x20],rax
  40fc3b:	add    DWORD PTR [rsi+0x730],0x1
  40fc42:	jmp    40fda6 <__swc_fn_7069e055_000062_b304235a+0x286>
  40fc47:	mov    rcx,r13
  40fc4a:	call   40c970 <__swc_fn_7069e055_000061_ad030a10>
  40fc4f:	mov    rsi,rax
  40fc52:	cmp    r12,rax
  40fc55:	jbe    40fc8a <__swc_fn_7069e055_000062_b304235a+0x16a>
  40fc57:	cmp    r12,0x10000000
  40fc5e:	seta   al
  40fc61:	ja     40fc70 <__swc_fn_7069e055_000062_b304235a+0x150>
  40fc63:	mov    rax,QWORD PTR [r13+0x2a70]
  40fc6a:	test   rax,rax
  40fc6d:	setne  al
  40fc70:	test   al,al
  40fc72:	je     40fc8a <__swc_fn_7069e055_000062_b304235a+0x16a>
  40fc74:	mov    rcx,r13
  40fc77:	mov    rdx,r14
  40fc7a:	mov    r8,r15
  40fc7d:	mov    r9,r12
  40fc80:	call   40c240 <__swc_fn_7069e055_000043_d3c2ab54>
  40fc85:	jmp    40fda6 <__swc_fn_7069e055_000062_b304235a+0x286>
  40fc8a:	call   40a170 <__swc_fn_7069e055_000135_07d76562>
  40fc8f:	mov    rdi,rax
  40fc92:	mov    rcx,r13
  40fc95:	call   40e380 <__swc_fn_7069e055_000139_86bb0f90>
  40fc9a:	cmp    QWORD PTR [r13+0x2a70],0x0
  40fca2:	je     40fd5a <__swc_fn_7069e055_000062_b304235a+0x23a>
  40fca8:	nop    DWORD PTR [rax+rax*1+0x0]
  40fcb0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40fcbb:	jae    40fcd0 <__swc_fn_7069e055_000062_b304235a+0x1b0>
  40fcbd:	mov    rax,QWORD PTR [r13+0x2a68]
  40fcc4:	add    rax,r12
  40fcc7:	cmp    rax,rsi
  40fcca:	jbe    40fd5a <__swc_fn_7069e055_000062_b304235a+0x23a>
  40fcd0:	xor    eax,eax
  40fcd2:	mov    rcx,QWORD PTR [r13+0x2a70]
  40fcd9:	mov    edx,0x1
  40fcde:	cmp    rcx,0x1
  40fce2:	jbe    40fd19 <__swc_fn_7069e055_000062_b304235a+0x1f9>
  40fce4:	cs nop WORD PTR [rax+rax*1+0x0]
  40fcee:	xchg   ax,ax
  40fcf0:	lea    r8,[rdx+rdx*4]
  40fcf4:	lea    r8,[r13+r8*8+0x268]
  40fcfc:	lea    r9,[rax+rax*4]
  40fd00:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40fd08:	cmp    QWORD PTR [r8+0x18],r9
  40fd0c:	cmovb  rax,rdx
  40fd10:	add    rdx,0x1
  40fd14:	cmp    rdx,rcx
  40fd17:	jb     40fcf0 <__swc_fn_7069e055_000062_b304235a+0x1d0>
  40fd19:	lea    rcx,[rax+rax*4]
  40fd1d:	lea    rcx,[r13+rcx*8+0x268]
  40fd25:	mov    r8,QWORD PTR [rcx]
  40fd28:	mov    r9,QWORD PTR [rcx+0x8]
  40fd2c:	mov    r10,QWORD PTR [rcx+0x10]
  40fd30:	mov    rcx,r13
  40fd33:	mov    rdx,rax
  40fd36:	call   408480 <__swc_fn_7069e055_000060_15c28ca7>
  40fd3b:	mov    rcx,r13
  40fd3e:	mov    rdx,r8
  40fd41:	mov    r8,r9
  40fd44:	mov    r9,r10
  40fd47:	call   40c240 <__swc_fn_7069e055_000043_d3c2ab54>
  40fd4c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40fd54:	jne    40fcb0 <__swc_fn_7069e055_000062_b304235a+0x190>
  40fd5a:	add    QWORD PTR [r13+0x2a78],0x1
  40fd62:	mov    rax,QWORD PTR [r13+0x2a70]
  40fd69:	lea    rax,[rax+rax*4]
  40fd6d:	lea    rax,[r13+rax*8+0x268]
  40fd75:	mov    QWORD PTR [rax],r14
  40fd78:	mov    QWORD PTR [rax+0x8],r15
  40fd7c:	mov    QWORD PTR [rax+0x10],r12
  40fd80:	mov    rcx,QWORD PTR [r13+0x2a78]
  40fd87:	mov    QWORD PTR [rax+0x18],rcx
  40fd8b:	mov    QWORD PTR [rax+0x20],rdi
  40fd8f:	add    QWORD PTR [r13+0x2a68],r12
  40fd96:	add    QWORD PTR [r13+0x2a70],0x1
  40fd9e:	mov    rcx,r13
  40fda1:	call   411950 <__swc_fn_7069e055_000140_055b38a4>
  40fda6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40fdaf:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40fdb8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40fdc1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40fdca:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40fdd3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40fddc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40fde5:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40fdee:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40fdf7:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40fe00:	add    rsp,0x148
  40fe07:	pop    rsi
  40fe08:	pop    rdi
  40fe09:	pop    r15
  40fe0b:	pop    r14
  40fe0d:	pop    r13
  40fe0f:	pop    r12
  40fe11:	ret
	...

000000000040fe20 <__swc_fn_7069e055_000065_d9ee99ea>:
  40fe20:	push   rbx
  40fe21:	push   r12
  40fe23:	push   r13
  40fe25:	push   r14
  40fe27:	push   r15
  40fe29:	push   rdi
  40fe2a:	push   rsi
  40fe2b:	sub    rsp,0xf0
  40fe32:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40fe38:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40fe3e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40fe44:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40fe4a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40fe53:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40fe5c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40fe65:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40fe6e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40fe77:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40fe80:	mov    eax,r8d
  40fe83:	mov    rbx,rcx
  40fe86:	mov    r12,rdx
  40fe89:	mov    QWORD PTR [rsp+0x18],rdx
  40fe8e:	mov    ecx,DWORD PTR [r12+0x58]
  40fe93:	mov    r13d,ecx
  40fe96:	cmp    ecx,0x10
  40fe99:	mov    ecx,0x10
  40fe9e:	cmovb  r13d,ecx
  40fea2:	test   r13d,r13d
  40fea5:	mov    rcx,r13
  40fea8:	mov    edx,0x8
  40fead:	cmove  ecx,edx
  40feb0:	dec    rcx
  40feb3:	mov    rdx,0xffffffffffffffff
  40feba:	sub    rdx,rcx
  40febd:	xor    r14d,r14d
  40fec0:	mov    r8,rcx
  40fec3:	not    r8
  40fec6:	lea    rcx,[rcx+0x58]
  40feca:	and    rcx,r8
  40fecd:	cmp    rdx,0x58
  40fed1:	cmovae r14,rcx
  40fed5:	cmp    eax,0xffffffff
  40fed8:	jne    40fee1 <__swc_fn_7069e055_000065_d9ee99ea+0xc1>
  40feda:	mov    r15,QWORD PTR [r12+0x48]
  40fedf:	jmp    40ff13 <__swc_fn_7069e055_000065_d9ee99ea+0xf3>
  40fee1:	test   eax,eax
  40fee3:	jne    40feec <__swc_fn_7069e055_000065_d9ee99ea+0xcc>
  40fee5:	mov    eax,0x8
  40feea:	jmp    40ff10 <__swc_fn_7069e055_000065_d9ee99ea+0xf0>
  40feec:	cmp    eax,0x8
  40feef:	ja     40fef7 <__swc_fn_7069e055_000065_d9ee99ea+0xd7>
  40fef1:	shl    rax,0x4
  40fef5:	jmp    40ff10 <__swc_fn_7069e055_000065_d9ee99ea+0xf0>
  40fef7:	lea    eax,[rax-0x9]
  40fefa:	mov    ecx,eax
  40fefc:	shr    ecx,0x2
  40feff:	and    eax,0x3
  40ff02:	lea    ecx,[rcx+0x7]
  40ff05:	lea    ecx,[rcx-0x2]
  40ff08:	lea    eax,[rax+0x5]
  40ff0b:	shlx   rax,rax,rcx
  40ff10:	mov    r15,rax
  40ff13:	lea    rax,[r14+r13*1]
  40ff17:	mov    rcx,0xffffffffffffffff
  40ff1e:	sub    rcx,rax
  40ff21:	cmp    r15,rcx
  40ff24:	jbe    40ff34 <__swc_fn_7069e055_000065_d9ee99ea+0x114>
  40ff26:	mov    QWORD PTR [r12+0x40],0x0
  40ff2f:	jmp    410306 <__swc_fn_7069e055_000065_d9ee99ea+0x4e6>
  40ff34:	mov    QWORD PTR [rsp+0x20],r13
  40ff39:	lea    r13,[rsp+0x8]
  40ff3e:	add    rax,r15
  40ff41:	mov    ecx,0x1000
  40ff46:	test   ecx,ecx
  40ff48:	mov    edx,0x8
  40ff4d:	cmove  ecx,edx
  40ff50:	dec    rcx
  40ff53:	mov    rdx,0xffffffffffffffff
  40ff5a:	sub    rdx,rcx
  40ff5d:	cmp    rax,rdx
  40ff60:	jbe    40ff6c <__swc_fn_7069e055_000065_d9ee99ea+0x14c>
  40ff62:	mov    QWORD PTR [r13+0x0],0x0
  40ff6a:	jmp    40ff79 <__swc_fn_7069e055_000065_d9ee99ea+0x159>
  40ff6c:	add    rax,rcx
  40ff6f:	andn   rax,rcx,rax
  40ff74:	mov    QWORD PTR [rsp+0x8],rax
  40ff79:	cmp    QWORD PTR [r13+0x0],0x0
  40ff7e:	jne    40ff8e <__swc_fn_7069e055_000065_d9ee99ea+0x16e>
  40ff80:	mov    QWORD PTR [r12+0x40],0x0
  40ff89:	jmp    410306 <__swc_fn_7069e055_000065_d9ee99ea+0x4e6>
  40ff8e:	mov    QWORD PTR [rsp+0x30],r15
  40ff93:	xor    r15d,r15d
  40ff96:	mov    QWORD PTR [rsp+0x38],0x0
  40ff9f:	lea    r12,[rsp+0x10]
  40ffa4:	mov    QWORD PTR [rsp+0x28],r14
  40ffa9:	mov    r14,QWORD PTR [rsp+0x8]
  40ffae:	mov    QWORD PTR [rsp+0x10],r14
  40ffb3:	cmp    r14,0x10000
  40ffba:	ja     40ffc1 <__swc_fn_7069e055_000065_d9ee99ea+0x1a1>
  40ffbc:	mov    rax,r14
  40ffbf:	jmp    410012 <__swc_fn_7069e055_000065_d9ee99ea+0x1f2>
  40ffc1:	xor    eax,eax
  40ffc3:	lea    rcx,[r14-0x1]
  40ffc7:	lzcnt  rax,rcx
  40ffcc:	mov    ecx,0x3f
  40ffd1:	sub    rcx,rax
  40ffd4:	mov    eax,0x1
  40ffd9:	lea    rcx,[rcx-0x3]
  40ffdd:	shl    rax,cl
  40ffe0:	mov    rcx,rax
  40ffe3:	cmp    rax,0x1000
  40ffea:	mov    eax,0x1000
  40ffef:	cmovb  rcx,rax
  40fff3:	mov    rdx,0xffffffffffffffff
  40fffa:	sub    rdx,rcx
  40fffd:	mov    rax,r14
  410000:	lea    r8,[r14+rcx*1-0x1]
  410005:	neg    rcx
  410008:	and    r8,rcx
  41000b:	cmp    r14,rdx
  41000e:	cmovbe rax,r8
  410012:	mov    QWORD PTR [rsp+0x8],rax
  410017:	lea    rax,[rip+0x11fea]        # 422008 <__swc_data_base_7069e055+0x8>
  41001e:	mov    rax,QWORD PTR [rax]
  410021:	cmp    rax,0xffffffffffffffff
  410025:	je     410034 <__swc_fn_7069e055_000065_d9ee99ea+0x214>
  410027:	mov    eax,eax
  410029:	mov    edi,eax
  41002b:	xor    eax,eax
  41002d:	call   407000 <pthread_getspecific@plt>
  410032:	jmp    410036 <__swc_fn_7069e055_000065_d9ee99ea+0x216>
  410034:	xor    eax,eax
  410036:	test   rax,rax
  410039:	jne    410048 <__swc_fn_7069e055_000065_d9ee99ea+0x228>
  41003b:	call   40f4c0 <__swc_fn_7069e055_000035_cd1a4e8c>
  410040:	mov    rcx,rax
  410043:	call   40a0c0 <__swc_fn_7069e055_000132_5f757033>
  410048:	test   rax,rax
  41004b:	je     41013c <__swc_fn_7069e055_000065_d9ee99ea+0x31c>
  410051:	cmp    QWORD PTR [rax],rbx
  410054:	jne    41013c <__swc_fn_7069e055_000065_d9ee99ea+0x31c>
  41005a:	cmp    DWORD PTR [rax+0x20],0x0
  41005e:	jne    41013c <__swc_fn_7069e055_000065_d9ee99ea+0x31c>
  410064:	mov    rcx,QWORD PTR [rsp+0x8]
  410069:	movabs rdx,0x7fffffffffffffff
  410073:	cmp    rcx,rdx
  410076:	mov    rdx,0xffffffffffffffff
  41007d:	lea    r8,[rcx+rcx*1]
  410081:	cmovbe rdx,r8
  410085:	mov    r8d,DWORD PTR [rax+0x730]
  41008c:	mov    r9d,r8d
  41008f:	sub    rdx,rcx
  410092:	inc    rdx
  410095:	xor    r10d,r10d
  410098:	test   r8,r8
  41009b:	jbe    4100cb <__swc_fn_7069e055_000065_d9ee99ea+0x2ab>
  41009d:	nop    DWORD PTR [rax]
  4100a0:	mov    r11d,r10d
  4100a3:	lea    r11,[r11+r11*4]
  4100a7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  4100af:	sub    r11,rcx
  4100b2:	cmp    r11,rdx
  4100b5:	jae    4100c2 <__swc_fn_7069e055_000065_d9ee99ea+0x2a2>
  4100b7:	mov    r9d,r10d
  4100ba:	mov    rdx,r11
  4100bd:	test   r11,r11
  4100c0:	je     4100cb <__swc_fn_7069e055_000065_d9ee99ea+0x2ab>
  4100c2:	add    r10,0x1
  4100c6:	cmp    r10,r8
  4100c9:	jb     4100a0 <__swc_fn_7069e055_000065_d9ee99ea+0x280>
  4100cb:	mov    ecx,DWORD PTR [rax+0x730]
  4100d1:	cmp    r9d,ecx
  4100d4:	jne    4100da <__swc_fn_7069e055_000065_d9ee99ea+0x2ba>
  4100d6:	xor    eax,eax
  4100d8:	jmp    410139 <__swc_fn_7069e055_000065_d9ee99ea+0x319>
  4100da:	lea    rcx,[r9+r9*4]
  4100de:	lea    rcx,[rax+rcx*8+0x738]
  4100e6:	vmovups xmm0,XMMWORD PTR [rcx]
  4100ea:	mov    rdx,QWORD PTR [rcx+0x10]
  4100ee:	sub    DWORD PTR [rax+0x730],0x1
  4100f5:	mov    r8d,DWORD PTR [rax+0x730]
  4100fc:	lea    r8,[r8+r8*4]
  410100:	lea    r8,[rax+r8*8+0x738]
  410108:	vmovups xmm1,XMMWORD PTR [r8]
  41010d:	vmovups XMMWORD PTR [rcx],xmm1
  410111:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  410117:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  41011c:	mov    rax,QWORD PTR [r8+0x20]
  410120:	mov    QWORD PTR [rcx+0x20],rax
  410124:	vpshufd xmm1,xmm0,0xee
  410129:	vmovsd QWORD PTR [rsp+0x8],xmm1
  41012f:	mov    QWORD PTR [rsp+0x10],rdx
  410134:	vmovq  rax,xmm0
  410139:	mov    r15,rax
  41013c:	test   r15,r15
  41013f:	jne    410157 <__swc_fn_7069e055_000065_d9ee99ea+0x337>
  410141:	mov    rcx,rbx
  410144:	mov    rdx,QWORD PTR [rsp+0x8]
  410149:	mov    r8,r13
  41014c:	mov    r9,r12
  41014f:	call   40fa10 <__swc_fn_7069e055_000059_2ca0cb05>
  410154:	mov    r15,rax
  410157:	test   r15,r15
  41015a:	je     41019b <__swc_fn_7069e055_000065_d9ee99ea+0x37b>
  41015c:	cmp    QWORD PTR [r12],r14
  410160:	jae    41019b <__swc_fn_7069e055_000065_d9ee99ea+0x37b>
  410162:	mov    rax,r15
  410165:	add    rax,QWORD PTR [r12]
  410169:	mov    rdx,r14
  41016c:	sub    rdx,QWORD PTR [r12]
  410170:	mov    rcx,rax
  410173:	call   40bd90 <__swc_fn_7069e055_000007_f7acedb0>
  410178:	test   al,al
  41017a:	je     410183 <__swc_fn_7069e055_000065_d9ee99ea+0x363>
  41017c:	mov    QWORD PTR [rsp+0x10],r14
  410181:	jmp    41019b <__swc_fn_7069e055_000065_d9ee99ea+0x37b>
  410183:	mov    rcx,rbx
  410186:	mov    rdx,r15
  410189:	mov    r8,QWORD PTR [rsp+0x8]
  41018e:	mov    r9,QWORD PTR [rsp+0x10]
  410193:	call   40fb20 <__swc_fn_7069e055_000062_b304235a>
  410198:	xor    r15d,r15d
  41019b:	test   r15,r15
  41019e:	jne    41021a <__swc_fn_7069e055_000065_d9ee99ea+0x3fa>
  4101a0:	cmp    r14,0x10000
  4101a7:	ja     4101ae <__swc_fn_7069e055_000065_d9ee99ea+0x38e>
  4101a9:	mov    rax,r14
  4101ac:	jmp    4101ff <__swc_fn_7069e055_000065_d9ee99ea+0x3df>
  4101ae:	xor    eax,eax
  4101b0:	lea    rcx,[r14-0x1]
  4101b4:	lzcnt  rax,rcx
  4101b9:	mov    ecx,0x3f
  4101be:	sub    rcx,rax
  4101c1:	mov    eax,0x1
  4101c6:	lea    rcx,[rcx-0x3]
  4101ca:	shl    rax,cl
  4101cd:	mov    rcx,rax
  4101d0:	cmp    rax,0x1000
  4101d7:	mov    eax,0x1000
  4101dc:	cmovb  rcx,rax
  4101e0:	mov    rdx,0xffffffffffffffff
  4101e7:	sub    rdx,rcx
  4101ea:	mov    rax,r14
  4101ed:	lea    r8,[r14+rcx*1-0x1]
  4101f2:	neg    rcx
  4101f5:	and    r8,rcx
  4101f8:	cmp    r14,rdx
  4101fb:	cmovbe rax,r8
  4101ff:	mov    QWORD PTR [rsp+0x8],rax
  410204:	mov    QWORD PTR [rsp+0x10],r14
  410209:	mov    rcx,rbx
  41020c:	mov    rdx,rax
  41020f:	mov    r8,r14
  410212:	call   40f580 <__swc_fn_7069e055_000041_c90d80c1>
  410217:	mov    r15,rax
  41021a:	test   r15,r15
  41021d:	jne    41022b <__swc_fn_7069e055_000065_d9ee99ea+0x40b>
  41021f:	mov    r13,QWORD PTR [rsp+0x20]
  410224:	mov    rsi,QWORD PTR [rsp+0x38]
  410229:	jmp    410267 <__swc_fn_7069e055_000065_d9ee99ea+0x447>
  41022b:	mov    rax,r15
  41022e:	add    rax,QWORD PTR [rsp+0x28]
  410233:	mov    r13,QWORD PTR [rsp+0x20]
  410238:	test   r13d,r13d
  41023b:	mov    rcx,r13
  41023e:	mov    edx,0x8
  410243:	cmove  ecx,edx
  410246:	dec    rcx
  410249:	mov    rdx,0xffffffffffffffff
  410250:	sub    rdx,rcx
  410253:	cmp    rax,rdx
  410256:	jbe    41025c <__swc_fn_7069e055_000065_d9ee99ea+0x43c>
  410258:	xor    eax,eax
  41025a:	jmp    410264 <__swc_fn_7069e055_000065_d9ee99ea+0x444>
  41025c:	add    rax,rcx
  41025f:	andn   rax,rcx,rax
  410264:	mov    rsi,rax
  410267:	mov    rax,QWORD PTR [rsp+0x8]
  41026c:	test   r15,r15
  41026f:	je     410278 <__swc_fn_7069e055_000065_d9ee99ea+0x458>
  410271:	mov    rdi,QWORD PTR [rsp+0x18]
  410276:	jmp    41028a <__swc_fn_7069e055_000065_d9ee99ea+0x46a>
  410278:	mov    rdi,QWORD PTR [rsp+0x18]
  41027d:	mov    QWORD PTR [rdi+0x40],0x0
  410285:	jmp    410306 <__swc_fn_7069e055_000065_d9ee99ea+0x4e6>
  41028a:	lea    rdx,[rsi-0x58]
  41028e:	mov    QWORD PTR [rsi-0x58],r15
  410292:	mov    QWORD PTR [rsi-0x50],rax
  410296:	mov    rax,QWORD PTR [rsp+0x10]
  41029b:	mov    QWORD PTR [rsi-0x48],rax
  41029f:	mov    QWORD PTR [rsi-0x40],rsi
  4102a3:	mov    rax,QWORD PTR [rdi+0x48]
  4102a7:	mov    QWORD PTR [rsi-0x38],rax
  4102ab:	mov    rax,QWORD PTR [rsp+0x30]
  4102b0:	mov    QWORD PTR [rsi-0x30],rax
  4102b4:	mov    DWORD PTR [rsi-0x10],r13d
  4102b8:	mov    QWORD PTR [rsi-0x28],0x0
  4102c0:	mov    QWORD PTR [rsi-0x20],0x0
  4102c8:	add    r15,QWORD PTR [r12]
  4102cc:	sub    r15,rsi
  4102cf:	mov    QWORD PTR [rsi-0x30],r15
  4102d3:	mov    rcx,QWORD PTR [rbx+0x250]
  4102da:	nop    WORD PTR [rax+rax*1+0x0]
  4102e0:	lea    r8,[rcx+r15*1]
  4102e4:	mov    rax,rcx
  4102e7:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  4102f0:	cmp    rax,rcx
  4102f3:	je     4102fa <__swc_fn_7069e055_000065_d9ee99ea+0x4da>
  4102f5:	mov    rcx,rax
  4102f8:	jmp    4102e0 <__swc_fn_7069e055_000065_d9ee99ea+0x4c0>
  4102fa:	mov    rcx,rbx
  4102fd:	call   4083f0 <__swc_fn_7069e055_000057_7e1dbcb0>
  410302:	mov    QWORD PTR [rdi+0x40],rsi
  410306:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  41030c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  410312:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  410318:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  41031e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  410327:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  410330:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  410339:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  410342:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  41034b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  410354:	add    rsp,0xf0
  41035b:	pop    rsi
  41035c:	pop    rdi
  41035d:	pop    r15
  41035f:	pop    r14
  410361:	pop    r13
  410363:	pop    r12
  410365:	pop    rbx
  410366:	ret
	...

0000000000410370 <__swc_fn_7069e055_000068_f3aa21af>:
  410370:	push   rbx
  410371:	push   r12
  410373:	push   rdi
  410374:	push   rsi
  410375:	sub    rsp,0xb8
  41037c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410382:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410388:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41038e:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410394:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  41039a:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4103a0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4103a6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4103af:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4103b8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4103c1:	mov    rbx,rdx
  4103c4:	mov    r12,rcx
  4103c7:	cmp    DWORD PTR [rbx+0x58],0x0
  4103cb:	je     4103e5 <__swc_fn_7069e055_000068_f3aa21af+0x75>
  4103cd:	mov    eax,DWORD PTR [rbx+0x58]
  4103d0:	sub    eax,0x1
  4103d3:	test   DWORD PTR [rbx+0x58],eax
  4103d6:	je     4103e5 <__swc_fn_7069e055_000068_f3aa21af+0x75>
  4103d8:	mov    QWORD PTR [rbx+0x40],0x0
  4103e0:	jmp    4105f7 <__swc_fn_7069e055_000068_f3aa21af+0x287>
  4103e5:	cmp    QWORD PTR [rbx+0x48],0x0
  4103ea:	jne    4103f9 <__swc_fn_7069e055_000068_f3aa21af+0x89>
  4103ec:	mov    QWORD PTR [rbx+0x40],0x0
  4103f4:	jmp    4105f7 <__swc_fn_7069e055_000068_f3aa21af+0x287>
  4103f9:	lea    rax,[rsp+0x8]
  4103fe:	mov    rcx,QWORD PTR [rbx+0x48]
  410402:	cmp    rcx,0x8
  410406:	ja     410410 <__swc_fn_7069e055_000068_f3aa21af+0xa0>
  410408:	mov    DWORD PTR [rax],0x0
  41040e:	jmp    41046b <__swc_fn_7069e055_000068_f3aa21af+0xfb>
  410410:	cmp    rcx,0x80
  410417:	ja     410427 <__swc_fn_7069e055_000068_f3aa21af+0xb7>
  410419:	lea    rcx,[rcx+0xf]
  41041d:	shr    rcx,0x4
  410421:	mov    DWORD PTR [rsp+0x8],ecx
  410425:	jmp    41046b <__swc_fn_7069e055_000068_f3aa21af+0xfb>
  410427:	cmp    rcx,0x10000
  41042e:	jbe    410438 <__swc_fn_7069e055_000068_f3aa21af+0xc8>
  410430:	mov    DWORD PTR [rax],0xffffffff
  410436:	jmp    41046b <__swc_fn_7069e055_000068_f3aa21af+0xfb>
  410438:	dec    rcx
  41043b:	xor    edx,edx
  41043d:	lzcnt  rdx,rcx
  410442:	mov    r8d,0x3f
  410448:	sub    r8d,edx
  41044b:	lea    edx,[r8-0x2]
  41044f:	shrx   rcx,rcx,rdx
  410454:	and    ecx,0x3
  410457:	lea    edx,[r8-0x7]
  41045b:	lea    edx,[rdx*4+0x0]
  410462:	lea    edx,[rdx+0x9]
  410465:	add    edx,ecx
  410467:	mov    DWORD PTR [rsp+0x8],edx
  41046b:	cmp    DWORD PTR [rax],0x0
  41046e:	jne    41047e <__swc_fn_7069e055_000068_f3aa21af+0x10e>
  410470:	cmp    DWORD PTR [rbx+0x58],0x8
  410474:	jbe    41047e <__swc_fn_7069e055_000068_f3aa21af+0x10e>
  410476:	mov    DWORD PTR [rsp+0x8],0x1
  41047e:	cmp    DWORD PTR [rbx+0x58],0x10
  410482:	jbe    410501 <__swc_fn_7069e055_000068_f3aa21af+0x191>
  410488:	cmp    DWORD PTR [rbx+0x58],0x40
  41048c:	ja     410501 <__swc_fn_7069e055_000068_f3aa21af+0x191>
  41048e:	cmp    DWORD PTR [rax],0xffffffff
  410491:	je     410501 <__swc_fn_7069e055_000068_f3aa21af+0x191>
  410493:	mov    ecx,DWORD PTR [rsp+0x8]
  410497:	mov    edx,DWORD PTR [rbx+0x58]
  41049a:	dec    rdx
  41049d:	cmp    ecx,0x2d
  4104a0:	jae    4104f8 <__swc_fn_7069e055_000068_f3aa21af+0x188>
  4104a2:	cs nop WORD PTR [rax+rax*1+0x0]
  4104ac:	nop    DWORD PTR [rax+0x0]
  4104b0:	mov    r8d,ecx
  4104b3:	test   ecx,ecx
  4104b5:	jne    4104bf <__swc_fn_7069e055_000068_f3aa21af+0x14f>
  4104b7:	mov    r8d,0x8
  4104bd:	jmp    4104eb <__swc_fn_7069e055_000068_f3aa21af+0x17b>
  4104bf:	cmp    r8d,0x8
  4104c3:	ja     4104cb <__swc_fn_7069e055_000068_f3aa21af+0x15b>
  4104c5:	shl    r8,0x4
  4104c9:	jmp    4104eb <__swc_fn_7069e055_000068_f3aa21af+0x17b>
  4104cb:	lea    r8d,[r8-0x9]
  4104cf:	mov    r9d,r8d
  4104d2:	shr    r9d,0x2
  4104d6:	and    r8d,0x3
  4104da:	lea    r9d,[r9+0x7]
  4104de:	lea    r9d,[r9-0x2]
  4104e2:	lea    r8d,[r8+0x5]
  4104e6:	shlx   r8,r8,r9
  4104eb:	test   r8,rdx
  4104ee:	je     4104fd <__swc_fn_7069e055_000068_f3aa21af+0x18d>
  4104f0:	add    ecx,0x1
  4104f3:	cmp    ecx,0x2d
  4104f6:	jb     4104b0 <__swc_fn_7069e055_000068_f3aa21af+0x140>
  4104f8:	mov    ecx,0xffffffff
  4104fd:	mov    DWORD PTR [rsp+0x8],ecx
  410501:	mov    ecx,DWORD PTR [rsp+0x8]
  410505:	cmp    ecx,0xffffffff
  410508:	je     410510 <__swc_fn_7069e055_000068_f3aa21af+0x1a0>
  41050a:	cmp    DWORD PTR [rbx+0x58],0x40
  41050e:	jbe    410523 <__swc_fn_7069e055_000068_f3aa21af+0x1b3>
  410510:	mov    rcx,r12
  410513:	mov    rdx,rbx
  410516:	mov    r8d,DWORD PTR [rax]
  410519:	call   40fe20 <__swc_fn_7069e055_000065_d9ee99ea>
  41051e:	jmp    4105f7 <__swc_fn_7069e055_000068_f3aa21af+0x287>
  410523:	lea    rax,[rip+0x11ade]        # 422008 <__swc_data_base_7069e055+0x8>
  41052a:	mov    rax,QWORD PTR [rax]
  41052d:	cmp    rax,0xffffffffffffffff
  410531:	je     410540 <__swc_fn_7069e055_000068_f3aa21af+0x1d0>
  410533:	mov    eax,eax
  410535:	mov    edi,eax
  410537:	xor    eax,eax
  410539:	call   407000 <pthread_getspecific@plt>
  41053e:	jmp    410542 <__swc_fn_7069e055_000068_f3aa21af+0x1d2>
  410540:	xor    eax,eax
  410542:	test   rax,rax
  410545:	jne    410554 <__swc_fn_7069e055_000068_f3aa21af+0x1e4>
  410547:	call   40f4c0 <__swc_fn_7069e055_000035_cd1a4e8c>
  41054c:	mov    rcx,rax
  41054f:	call   40a0c0 <__swc_fn_7069e055_000132_5f757033>
  410554:	test   rax,rax
  410557:	je     410564 <__swc_fn_7069e055_000068_f3aa21af+0x1f4>
  410559:	cmp    QWORD PTR [rax],r12
  41055c:	jne    410564 <__swc_fn_7069e055_000068_f3aa21af+0x1f4>
  41055e:	cmp    DWORD PTR [rax+0x20],0x0
  410562:	je     41056f <__swc_fn_7069e055_000068_f3aa21af+0x1ff>
  410564:	mov    rcx,r12
  410567:	mov    rdx,rax
  41056a:	call   408030 <__swc_fn_7069e055_000045_d8bd27c3>
  41056f:	test   rax,rax
  410572:	jne    41057e <__swc_fn_7069e055_000068_f3aa21af+0x20e>
  410574:	mov    QWORD PTR [rbx+0x40],0x0
  41057c:	jmp    4105f7 <__swc_fn_7069e055_000068_f3aa21af+0x287>
  41057e:	lea    r8,[rsp+0xc]
  410583:	mov    ecx,DWORD PTR [rsp+0x8]
  410587:	mov    DWORD PTR [rsp+0xc],ecx
  41058b:	mov    ecx,DWORD PTR [r8]
  41058e:	lea    rcx,[rcx+rcx*4]
  410592:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  410597:	test   rcx,rcx
  41059a:	je     4105d3 <__swc_fn_7069e055_000068_f3aa21af+0x263>
  41059c:	mov    rdx,QWORD PTR [rcx]
  41059f:	test   rdx,rdx
  4105a2:	je     4105b0 <__swc_fn_7069e055_000068_f3aa21af+0x240>
  4105a4:	mov    r9,QWORD PTR [rdx]
  4105a7:	mov    QWORD PTR [rcx],r9
  4105aa:	add    DWORD PTR [rcx+0x28],0x1
  4105ae:	jmp    4105ce <__swc_fn_7069e055_000068_f3aa21af+0x25e>
  4105b0:	mov    rdx,QWORD PTR [rcx+0x18]
  4105b4:	cmp    QWORD PTR [rcx+0x20],rdx
  4105b8:	jae    4105cc <__swc_fn_7069e055_000068_f3aa21af+0x25c>
  4105ba:	mov    rdx,QWORD PTR [rcx+0x20]
  4105be:	mov    r9d,DWORD PTR [rcx+0x2c]
  4105c2:	add    QWORD PTR [rcx+0x20],r9
  4105c6:	add    DWORD PTR [rcx+0x28],0x1
  4105ca:	jmp    4105ce <__swc_fn_7069e055_000068_f3aa21af+0x25e>
  4105cc:	xor    edx,edx
  4105ce:	test   rdx,rdx
  4105d1:	jne    4105e4 <__swc_fn_7069e055_000068_f3aa21af+0x274>
  4105d3:	mov    rcx,r12
  4105d6:	mov    rdx,rax
  4105d9:	mov    r8d,DWORD PTR [r8]
  4105dc:	call   4081a0 <__swc_fn_7069e055_000054_faa92dcc>
  4105e1:	mov    rdx,rax
  4105e4:	test   rdx,rdx
  4105e7:	jne    4105f3 <__swc_fn_7069e055_000068_f3aa21af+0x283>
  4105e9:	mov    QWORD PTR [rbx+0x40],0x0
  4105f1:	jmp    4105f7 <__swc_fn_7069e055_000068_f3aa21af+0x287>
  4105f3:	mov    QWORD PTR [rbx+0x40],rdx
  4105f7:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4105fd:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410603:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410609:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41060f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410615:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41061b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410621:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41062a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410633:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  41063c:	add    rsp,0xb8
  410643:	pop    rsi
  410644:	pop    rdi
  410645:	pop    r12
  410647:	pop    rbx
  410648:	ret
  410649:	add    BYTE PTR [rax],al
  41064b:	add    BYTE PTR [rax],al
  41064d:	add    BYTE PTR [rax],al
	...

0000000000410650 <__swc_fn_7069e055_000071_b3d7b28e>:
  410650:	ret
	...

0000000000410660 <__swc_fn_7069e055_000074_042643a3>:
  410660:	push   r12
  410662:	push   r13
  410664:	push   r14
  410666:	push   rdi
  410667:	push   rsi
  410668:	sub    rsp,0x1a0
  41066f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  410678:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  410681:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  41068a:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  410693:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  41069c:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  4106a5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  4106ae:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  4106b7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  4106c0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  4106c9:	mov    r12,rdx
  4106cc:	mov    r13,rcx
  4106cf:	mov    rax,QWORD PTR [r12+0x48]
  4106d4:	mov    ecx,DWORD PTR [r12+0x58]
  4106d9:	lea    rdx,[rax-0x1]
  4106dd:	cmp    rdx,0x10000
  4106e4:	jae    4107de <__swc_fn_7069e055_000074_042643a3+0x17e>
  4106ea:	cmp    rax,0x8
  4106ee:	ja     4106f5 <__swc_fn_7069e055_000074_042643a3+0x95>
  4106f0:	xor    r14d,r14d
  4106f3:	jmp    410747 <__swc_fn_7069e055_000074_042643a3+0xe7>
  4106f5:	cmp    rax,0x80
  4106fc:	ja     410708 <__swc_fn_7069e055_000074_042643a3+0xa8>
  4106fe:	lea    r14,[rax+0xf]
  410702:	shr    r14,0x4
  410706:	jmp    410747 <__swc_fn_7069e055_000074_042643a3+0xe7>
  410708:	cmp    rax,0x10000
  41070f:	jbe    410719 <__swc_fn_7069e055_000074_042643a3+0xb9>
  410711:	mov    r14d,0xffffffff
  410717:	jmp    410747 <__swc_fn_7069e055_000074_042643a3+0xe7>
  410719:	xor    eax,eax
  41071b:	lzcnt  rax,rdx
  410720:	mov    r8d,0x3f
  410726:	sub    r8d,eax
  410729:	lea    eax,[r8-0x2]
  41072d:	shrx   rax,rdx,rax
  410732:	and    eax,0x3
  410735:	lea    edx,[r8-0x7]
  410739:	lea    edx,[rdx*4+0x0]
  410740:	lea    edx,[rdx+0x9]
  410743:	lea    r14d,[rdx+rax*1]
  410747:	cmp    ecx,0x8
  41074a:	jbe    410763 <__swc_fn_7069e055_000074_042643a3+0x103>
  41074c:	cmp    ecx,0x10
  41074f:	jne    4107de <__swc_fn_7069e055_000074_042643a3+0x17e>
  410755:	test   r14d,r14d
  410758:	mov    eax,0x1
  41075d:	cmove  r14d,eax
  410761:	jmp    41076a <__swc_fn_7069e055_000074_042643a3+0x10a>
  410763:	lea    eax,[rcx-0x1]
  410766:	test   eax,ecx
  410768:	jne    4107de <__swc_fn_7069e055_000074_042643a3+0x17e>
  41076a:	lea    rax,[rip+0x11897]        # 422008 <__swc_data_base_7069e055+0x8>
  410771:	mov    rax,QWORD PTR [rax]
  410774:	cmp    rax,0xffffffffffffffff
  410778:	je     410787 <__swc_fn_7069e055_000074_042643a3+0x127>
  41077a:	mov    eax,eax
  41077c:	mov    edi,eax
  41077e:	xor    eax,eax
  410780:	call   407000 <pthread_getspecific@plt>
  410785:	jmp    410789 <__swc_fn_7069e055_000074_042643a3+0x129>
  410787:	xor    eax,eax
  410789:	test   rax,rax
  41078c:	je     4107de <__swc_fn_7069e055_000074_042643a3+0x17e>
  41078e:	cmp    QWORD PTR [rax],r13
  410791:	jne    4107de <__swc_fn_7069e055_000074_042643a3+0x17e>
  410793:	lea    rcx,[r14+r14*4]
  410797:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  41079c:	test   rax,rax
  41079f:	je     4107de <__swc_fn_7069e055_000074_042643a3+0x17e>
  4107a1:	mov    rcx,QWORD PTR [rax]
  4107a4:	test   rcx,rcx
  4107a7:	je     4107b5 <__swc_fn_7069e055_000074_042643a3+0x155>
  4107a9:	mov    rdx,QWORD PTR [rcx]
  4107ac:	mov    QWORD PTR [rax],rdx
  4107af:	add    DWORD PTR [rax+0x28],0x1
  4107b3:	jmp    4107d2 <__swc_fn_7069e055_000074_042643a3+0x172>
  4107b5:	mov    rcx,QWORD PTR [rax+0x18]
  4107b9:	cmp    QWORD PTR [rax+0x20],rcx
  4107bd:	jae    4107d0 <__swc_fn_7069e055_000074_042643a3+0x170>
  4107bf:	mov    rcx,QWORD PTR [rax+0x20]
  4107c3:	mov    edx,DWORD PTR [rax+0x2c]
  4107c6:	add    QWORD PTR [rax+0x20],rdx
  4107ca:	add    DWORD PTR [rax+0x28],0x1
  4107ce:	jmp    4107d2 <__swc_fn_7069e055_000074_042643a3+0x172>
  4107d0:	xor    ecx,ecx
  4107d2:	test   rcx,rcx
  4107d5:	je     4107de <__swc_fn_7069e055_000074_042643a3+0x17e>
  4107d7:	mov    QWORD PTR [r12+0x40],rcx
  4107dc:	jmp    4107e9 <__swc_fn_7069e055_000074_042643a3+0x189>
  4107de:	mov    rcx,r13
  4107e1:	mov    rdx,r12
  4107e4:	call   408c20 <__swc_fn_7069e055_000075_64d36d78>
  4107e9:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  4107f2:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  4107fb:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  410804:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  41080d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  410816:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  41081f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  410828:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  410831:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  41083a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  410843:	add    rsp,0x1a0
  41084a:	pop    rsi
  41084b:	pop    rdi
  41084c:	pop    r14
  41084e:	pop    r13
  410850:	pop    r12
  410852:	ret
	...

0000000000410860 <__swc_fn_7069e055_000077_7b195156>:
  410860:	push   r12
  410862:	push   r13
  410864:	push   r14
  410866:	push   r15
  410868:	push   rdi
  410869:	push   rsi
  41086a:	sub    rsp,0x188
  410871:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  41087a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  410883:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  41088c:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  410895:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  41089e:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  4108a7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  4108b0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  4108b9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  4108c2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  4108cb:	mov    r12,rdx
  4108ce:	mov    r13,rcx
  4108d1:	mov    r14,QWORD PTR [r12+0x40]
  4108d6:	lea    rax,[rip+0x137c3]        # 4240a0 <__swc_bss_base_7069e055+0x60>
  4108dd:	mov    rcx,r14
  4108e0:	sub    rcx,QWORD PTR [rax+0x8]
  4108e4:	mov    rax,QWORD PTR [rip+0x137c5]        # 4240b0 <__swc_bss_base_7069e055+0x70>
  4108eb:	cmp    rcx,rax
  4108ee:	jae    41091a <__swc_fn_7069e055_000077_7b195156+0xba>
  4108f0:	mov    rax,r14
  4108f3:	and    rax,0xffffffffffc00000
  4108fa:	mov    rcx,r14
  4108fd:	shr    rcx,0x10
  410901:	and    ecx,0x3f
  410904:	mov    edx,DWORD PTR [rax+0x28]
  410907:	shrx   ecx,ecx,edx
  41090c:	shl    rcx,0x4
  410910:	lea    r15,[rax+rcx*8+0x80]
  410918:	jmp    410925 <__swc_fn_7069e055_000077_7b195156+0xc5>
  41091a:	mov    rcx,r14
  41091d:	call   40f3f0 <__swc_fn_7069e055_000026_bcdc5519>
  410922:	mov    r15,rax
  410925:	test   r15,r15
  410928:	je     4109cf <__swc_fn_7069e055_000077_7b195156+0x16f>
  41092e:	lea    rax,[rip+0x116d3]        # 422008 <__swc_data_base_7069e055+0x8>
  410935:	mov    rax,QWORD PTR [rax]
  410938:	cmp    rax,0xffffffffffffffff
  41093c:	je     41094b <__swc_fn_7069e055_000077_7b195156+0xeb>
  41093e:	mov    eax,eax
  410940:	mov    edi,eax
  410942:	xor    eax,eax
  410944:	call   407000 <pthread_getspecific@plt>
  410949:	jmp    41094d <__swc_fn_7069e055_000077_7b195156+0xed>
  41094b:	xor    eax,eax
  41094d:	mov    rcx,QWORD PTR [r15+0x40]
  410951:	cmp    rcx,rax
  410954:	jne    4109b4 <__swc_fn_7069e055_000077_7b195156+0x154>
  410956:	test   rax,rax
  410959:	je     4109cf <__swc_fn_7069e055_000077_7b195156+0x16f>
  41095b:	mov    ecx,DWORD PTR [r15+0x6c]
  41095f:	test   ecx,ecx
  410961:	je     410981 <__swc_fn_7069e055_000077_7b195156+0x121>
  410963:	mov    rcx,r13
  410966:	mov    rdx,rax
  410969:	mov    r8,r15
  41096c:	mov    QWORD PTR [rsp+0xd8],rax
  410974:	call   408130 <__swc_fn_7069e055_000051_e072b516>
  410979:	mov    rax,QWORD PTR [rsp+0xd8]
  410981:	mov    rcx,QWORD PTR [r15]
  410984:	mov    QWORD PTR [r14],rcx
  410987:	mov    QWORD PTR [r15],r14
  41098a:	sub    DWORD PTR [r15+0x28],0x1
  41098f:	jne    4109c4 <__swc_fn_7069e055_000077_7b195156+0x164>
  410991:	movzx  ecx,BYTE PTR [r15+0x39]
  410996:	lea    rcx,[rcx+rcx*4]
  41099a:	lea    rcx,[rax+rcx*8+0x28]
  41099f:	cmp    QWORD PTR [rcx],r15
  4109a2:	je     4109c4 <__swc_fn_7069e055_000077_7b195156+0x164>
  4109a4:	mov    rcx,r13
  4109a7:	mov    rdx,rax
  4109aa:	mov    r8,r15
  4109ad:	call   40c860 <__swc_fn_7069e055_000055_2e3450f7>
  4109b2:	jmp    4109c4 <__swc_fn_7069e055_000077_7b195156+0x164>
  4109b4:	test   rcx,rcx
  4109b7:	je     4109cf <__swc_fn_7069e055_000077_7b195156+0x16f>
  4109b9:	mov    rcx,r15
  4109bc:	mov    rdx,r14
  4109bf:	call   40f030 <__swc_fn_7069e055_000014_524c1f23>
  4109c4:	mov    QWORD PTR [r12+0x40],0x0
  4109cd:	jmp    4109da <__swc_fn_7069e055_000077_7b195156+0x17a>
  4109cf:	mov    rcx,r13
  4109d2:	mov    rdx,r12
  4109d5:	call   408c40 <__swc_fn_7069e055_000078_1966ae2e>
  4109da:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  4109e3:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  4109ec:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  4109f5:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  4109fe:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  410a07:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  410a10:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  410a19:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  410a22:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  410a2b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  410a34:	add    rsp,0x188
  410a3b:	pop    rsi
  410a3c:	pop    rdi
  410a3d:	pop    r15
  410a3f:	pop    r14
  410a41:	pop    r13
  410a43:	pop    r12
  410a45:	ret
	...

0000000000410a50 <__swc_fn_7069e055_000080_d2cd17e2>:
  410a50:	sub    rsp,0x8
  410a54:	mov    rax,rdx
  410a57:	mov    rdx,QWORD PTR [rax+0x40]
  410a5b:	mov    r8,rax
  410a5e:	call   410650 <__swc_fn_7069e055_000071_b3d7b28e>
  410a63:	add    rsp,0x8
  410a67:	ret
	...

0000000000410a70 <__swc_fn_7069e055_000083_4a10c7e7>:
  410a70:	push   rsi
  410a71:	push   rdi
  410a72:	sub    rsp,0x8
  410a76:	cmp    rcx,0xffffffffffffffef
  410a7a:	ja     410aa0 <__swc_fn_7069e055_000083_4a10c7e7+0x30>
  410a7c:	xor    esi,esi
  410a7e:	lea    rax,[rcx+0x100f]
  410a85:	and    rax,0xfffffffffffff000
  410a8c:	lea    rcx,[rcx+0x10]
  410a90:	cmp    rcx,0xfffffffffffff000
  410a97:	cmovbe rsi,rax
  410a9b:	test   rsi,rsi
  410a9e:	jne    410aa9 <__swc_fn_7069e055_000083_4a10c7e7+0x39>
  410aa0:	xor    eax,eax
  410aa2:	add    rsp,0x8
  410aa6:	pop    rdi
  410aa7:	pop    rsi
  410aa8:	ret
  410aa9:	mov    rcx,rsi
  410aac:	call   411100 <__swc_fn_7069e055_000113_6b799b8d>
  410ab1:	mov    rdi,rax
  410ab4:	test   rax,rax
  410ab7:	jne    410ac2 <__swc_fn_7069e055_000083_4a10c7e7+0x52>
  410ab9:	xor    eax,eax
  410abb:	add    rsp,0x8
  410abf:	pop    rdi
  410ac0:	pop    rsi
  410ac1:	ret
  410ac2:	mov    rcx,rdi
  410ac5:	mov    rdx,rsi
  410ac8:	call   40dd20 <__swc_fn_7069e055_000115_36905703>
  410acd:	test   al,al
  410acf:	jne    410ae5 <__swc_fn_7069e055_000083_4a10c7e7+0x75>
  410ad1:	mov    rcx,rdi
  410ad4:	mov    rdx,rsi
  410ad7:	call   409d70 <__swc_fn_7069e055_000117_ed2d8fed>
  410adc:	xor    eax,eax
  410ade:	add    rsp,0x8
  410ae2:	pop    rdi
  410ae3:	pop    rsi
  410ae4:	ret
  410ae5:	mov    QWORD PTR [rdi],rsi
  410ae8:	mov    QWORD PTR [rdi+0x8],0x0
  410af0:	lea    rax,[rdi+0x10]
  410af4:	add    rsp,0x8
  410af8:	pop    rdi
  410af9:	pop    rsi
  410afa:	ret
  410afb:	add    BYTE PTR [rax],al
  410afd:	add    BYTE PTR [rax],al
	...

0000000000410b00 <__swc_fn_7069e055_000086_3953ef98>:
  410b00:	sub    rsp,0x8
  410b04:	cmp    BYTE PTR [rcx+0x2c],0x10
  410b08:	jne    410b13 <__swc_fn_7069e055_000086_3953ef98+0x13>
  410b0a:	test   DWORD PTR [rcx+0x28],0x80
  410b11:	je     410b1b <__swc_fn_7069e055_000086_3953ef98+0x1b>
  410b13:	mov    rax,rcx
  410b16:	add    rsp,0x8
  410b1a:	ret
  410b1b:	mov    rcx,QWORD PTR [rcx+0x40]
  410b1f:	call   410b00 <__swc_fn_7069e055_000086_3953ef98>
  410b24:	add    rsp,0x8
  410b28:	ret
	...

0000000000410b40 <__swc_fn_7069e055_000089_d182c4dc>:
  410b40:	push   rsi
  410b41:	push   rdi
  410b42:	push   r12
  410b44:	push   r13
  410b46:	sub    rsp,0x8
  410b4a:	mov    rsi,rdx
  410b4d:	mov    rdi,rcx
  410b50:	xor    r8d,r8d
  410b53:	call   40d080 <__swc_fn_7069e055_000094_63c1827b>
  410b58:	test   al,al
  410b5a:	je     410b6c <__swc_fn_7069e055_000089_d182c4dc+0x2c>
  410b5c:	mov    eax,0x1
  410b61:	add    rsp,0x8
  410b65:	pop    r13
  410b67:	pop    r12
  410b69:	pop    rdi
  410b6a:	pop    rsi
  410b6b:	ret
  410b6c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  410b71:	je     410b80 <__swc_fn_7069e055_000089_d182c4dc+0x40>
  410b73:	xor    eax,eax
  410b75:	add    rsp,0x8
  410b79:	pop    r13
  410b7b:	pop    r12
  410b7d:	pop    rdi
  410b7e:	pop    rsi
  410b7f:	ret
  410b80:	mov    r12,QWORD PTR [rsi+0x98]
  410b87:	mov    rax,QWORD PTR [rsi+0xa0]
  410b8e:	mov    rsi,rax
  410b91:	xor    r13d,r13d
  410b94:	test   rsi,rsi
  410b97:	je     410bf4 <__swc_fn_7069e055_000089_d182c4dc+0xb4>
  410b99:	cs nop WORD PTR [rax+rax*1+0x0]
  410ba3:	cs nop WORD PTR [rax+rax*1+0x0]
  410bad:	nop    DWORD PTR [rax]
  410bb0:	lea    rax,[r13*8+0x0]
  410bb8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  410bbd:	mov    rcx,rax
  410bc0:	call   410b00 <__swc_fn_7069e055_000086_3953ef98>
  410bc5:	cmp    BYTE PTR [rax+0x2c],0xe
  410bc9:	jne    410bea <__swc_fn_7069e055_000089_d182c4dc+0xaa>
  410bcb:	mov    rcx,rdi
  410bce:	mov    rdx,rax
  410bd1:	call   410b40 <__swc_fn_7069e055_000089_d182c4dc>
  410bd6:	test   al,al
  410bd8:	je     410bea <__swc_fn_7069e055_000089_d182c4dc+0xaa>
  410bda:	mov    eax,0x1
  410bdf:	add    rsp,0x8
  410be3:	pop    r13
  410be5:	pop    r12
  410be7:	pop    rdi
  410be8:	pop    rsi
  410be9:	ret
  410bea:	add    r13,0x1
  410bee:	sub    rsi,0x1
  410bf2:	jne    410bb0 <__swc_fn_7069e055_000089_d182c4dc+0x70>
  410bf4:	xor    eax,eax
  410bf6:	add    rsp,0x8
  410bfa:	pop    r13
  410bfc:	pop    r12
  410bfe:	pop    rdi
  410bff:	pop    rsi
  410c00:	ret
	...

0000000000410c10 <__swc_fn_7069e055_000092_14c65203>:
  410c10:	sub    rsp,0x18
  410c14:	vxorps xmm0,xmm0,xmm0
  410c18:	vmovdqu XMMWORD PTR [rsp],xmm0
  410c1d:	call   408e50 <__swc_fn_7069e055_000093_c2567a3b>
  410c22:	add    rsp,0x18
  410c26:	ret
	...

0000000000410c30 <__swc_fn_7069e055_000095_ad13d15c>:
  410c30:	sub    rsp,0x8
  410c34:	mov    rcx,QWORD PTR [rip+0x13405]        # 424040 <__swc_bss_base_7069e055>
  410c3b:	test   rcx,rcx
  410c3e:	jne    410c50 <__swc_fn_7069e055_000095_ad13d15c+0x20>
  410c40:	call   40ec80 <__swc_fn_7069e055_000169_994c8876>
  410c45:	lea    rcx,[rax+0x1]
  410c49:	mov    QWORD PTR [rip+0x133f0],rcx        # 424040 <__swc_bss_base_7069e055>
  410c50:	dec    rcx
  410c53:	call   40bb40 <__swc_fn_7069e055_000171_360af05d>
  410c58:	mov    rax,QWORD PTR [rax+0xc0]
  410c5f:	and    eax,0x1
  410c62:	setne  al
  410c65:	add    rsp,0x8
  410c69:	ret
	...

0000000000410c80 <__swc_fn_7069e055_000098_4f209617>:
  410c80:	push   rbx
  410c81:	push   rsi
  410c82:	push   rdi
  410c83:	push   r12
  410c85:	sub    rsp,0x28
  410c89:	mov    rbx,rcx
  410c8c:	call   40d3e0 <__swc_fn_7069e055_000097_4185993f>
  410c91:	mov    rcx,QWORD PTR [rip+0x133a8]        # 424040 <__swc_bss_base_7069e055>
  410c98:	test   rcx,rcx
  410c9b:	jne    410cad <__swc_fn_7069e055_000098_4f209617+0x2d>
  410c9d:	call   40ec80 <__swc_fn_7069e055_000169_994c8876>
  410ca2:	lea    rcx,[rax+0x1]
  410ca6:	mov    QWORD PTR [rip+0x13393],rcx        # 424040 <__swc_bss_base_7069e055>
  410cad:	dec    rcx
  410cb0:	call   40bb40 <__swc_fn_7069e055_000171_360af05d>
  410cb5:	mov    rsi,rax
  410cb8:	lea    rcx,[rsp+0x8]
  410cbd:	call   409290 <__swc_fn_7069e055_000096_93bfe675>
  410cc2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  410cc9:	mov    r12,QWORD PTR [rsi+0xbe8]
  410cd0:	lea    rcx,[rsi+0x10]
  410cd4:	call   411c50 <__swc_fn_7069e055_000161_13ead2ff>
  410cd9:	mov    rcx,rsi
  410cdc:	call   409400 <__swc_fn_7069e055_000105_5a85fcf5>
  410ce1:	vxorps xmm0,xmm0,xmm0
  410ce5:	xor    eax,eax
  410ce7:	cs nop WORD PTR [rax+rax*1+0x0]
  410cf1:	cs nop WORD PTR [rax+rax*1+0x0]
  410cfb:	nop    DWORD PTR [rax+rax*1+0x0]
  410d00:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  410d05:	add    rax,0x10
  410d09:	cmp    rax,0xbf0
  410d10:	jne    410d00 <__swc_fn_7069e055_000098_4f209617+0x80>
  410d12:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  410d18:	vmovups XMMWORD PTR [rsi],xmm0
  410d1c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  410d22:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  410d2a:	mov    QWORD PTR [rsi+0x9c0],rdi
  410d31:	mov    QWORD PTR [rsi+0xbe8],r12
  410d38:	mov    rcx,QWORD PTR [rip+0x13301]        # 424040 <__swc_bss_base_7069e055>
  410d3f:	test   rcx,rcx
  410d42:	jne    410d54 <__swc_fn_7069e055_000098_4f209617+0xd4>
  410d44:	call   40ec80 <__swc_fn_7069e055_000169_994c8876>
  410d49:	lea    rcx,[rax+0x1]
  410d4d:	mov    QWORD PTR [rip+0x132ec],rcx        # 424040 <__swc_bss_base_7069e055>
  410d54:	dec    rcx
  410d57:	call   40bb40 <__swc_fn_7069e055_000171_360af05d>
  410d5c:	mov    rsi,rax
  410d5f:	mov    QWORD PTR [rsi+0xc0],rbx
  410d66:	and    ebx,0x1
  410d69:	jne    410d6d <__swc_fn_7069e055_000098_4f209617+0xed>
  410d6b:	xor    eax,eax
  410d6d:	test   rbx,rbx
  410d70:	sete   al
  410d73:	xor    cl,cl
  410d75:	xor    dl,dl
  410d77:	xor    r8b,r8b
  410d7a:	xor    r9b,r9b
  410d7d:	xor    r10b,r10b
  410d80:	mov    r11,rax
  410d83:	call   408c50 <__swc_fn_7069e055_000081_5cc7acfc>
  410d88:	lea    rbx,[rsp+0x18]
  410d8d:	mov    rcx,rbx
  410d90:	call   409290 <__swc_fn_7069e055_000096_93bfe675>
  410d95:	lea    rcx,[rsi+0x10]
  410d99:	mov    edx,0x400000
  410d9e:	mov    r8,rbx
  410da1:	call   40e9c0 <__swc_fn_7069e055_000163_8a3d304f>
  410da6:	lea    rcx,[rsi+0x68]
  410daa:	mov    edx,0x4000
  410daf:	mov    r8,rbx
  410db2:	call   40e9c0 <__swc_fn_7069e055_000163_8a3d304f>
  410db7:	add    rsp,0x28
  410dbb:	pop    r12
  410dbd:	pop    rdi
  410dbe:	pop    rsi
  410dbf:	pop    rbx
  410dc0:	ret
	...

0000000000410dd0 <__swc_fn_7069e055_000101_d0b19c14>:
  410dd0:	push   rbx
  410dd1:	push   rsi
  410dd2:	sub    rsp,0x18
  410dd6:	mov    rbx,rcx
  410dd9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  410dde:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410de4:	mov    rsi,QWORD PTR [rbx+0x70]
  410de8:	lea    rcx,[rcx+0x18]
  410dec:	call   411c50 <__swc_fn_7069e055_000161_13ead2ff>
  410df1:	lea    rcx,[rsp+0x8]
  410df6:	mov    rdx,rbx
  410df9:	mov    r8d,0x78
  410dff:	call   40d440 <__swc_fn_7069e055_000100_d4bdcaa4>
  410e04:	mov    rax,rsi
  410e07:	add    rsp,0x18
  410e0b:	pop    rsi
  410e0c:	pop    rbx
  410e0d:	ret
	...

0000000000410e10 <__swc_fn_7069e055_000104_3c3b96fb>:
  410e10:	push   rsi
  410e11:	push   rdi
  410e12:	sub    rsp,0x8
  410e16:	cmp    QWORD PTR [rcx],0x0
  410e1a:	jne    410e23 <__swc_fn_7069e055_000104_3c3b96fb+0x13>
  410e1c:	add    rsp,0x8
  410e20:	pop    rdi
  410e21:	pop    rsi
  410e22:	ret
  410e23:	mov    rsi,QWORD PTR [rcx]
  410e26:	mov    rax,QWORD PTR [rcx+0x8]
  410e2a:	test   rax,rax
  410e2d:	je     410e43 <__swc_fn_7069e055_000104_3c3b96fb+0x33>
  410e2f:	test   DWORD PTR [rax+0x28],0x400000
  410e36:	je     410e43 <__swc_fn_7069e055_000104_3c3b96fb+0x33>
  410e38:	mov    rcx,QWORD PTR [rax+0x30]
  410e3c:	test   rcx,rcx
  410e3f:	cmovne rax,rcx
  410e43:	lea    rdx,[rip+0x24ae]        # 4132f8 <__swc_rdata_base_7069e055+0x1e8>
  410e4a:	lea    rcx,[rip+0x258f]        # 4133e0 <__swc_rdata_base_7069e055+0x2d0>
  410e51:	mov    r8,rax
  410e54:	xor    r9d,r9d
  410e57:	xor    al,al
  410e59:	mov    r10,rax
  410e5c:	xor    r11d,r11d
  410e5f:	call   410c10 <__swc_fn_7069e055_000092_14c65203>
  410e64:	test   rax,rax
  410e67:	je     410e77 <__swc_fn_7069e055_000104_3c3b96fb+0x67>
  410e69:	mov    rdi,QWORD PTR [rax+0x48]
  410e6d:	test   rdi,rdi
  410e70:	je     410e77 <__swc_fn_7069e055_000104_3c3b96fb+0x67>
  410e72:	mov    rcx,rsi
  410e75:	call   rdi
  410e77:	add    rsp,0x8
  410e7b:	pop    rdi
  410e7c:	pop    rsi
  410e7d:	ret
	...

0000000000410e80 <__swc_fn_7069e055_000107_90faaa26>:
  410e80:	push   rbx
  410e81:	push   rsi
  410e82:	push   rdi
  410e83:	sub    rsp,0x20
  410e87:	mov    rbx,rdx
  410e8a:	mov    rsi,rcx
  410e8d:	mov    rcx,QWORD PTR [rip+0x131ac]        # 424040 <__swc_bss_base_7069e055>
  410e94:	test   rcx,rcx
  410e97:	jne    410ea9 <__swc_fn_7069e055_000107_90faaa26+0x29>
  410e99:	call   40ec80 <__swc_fn_7069e055_000169_994c8876>
  410e9e:	lea    rcx,[rax+0x1]
  410ea2:	mov    QWORD PTR [rip+0x13197],rcx        # 424040 <__swc_bss_base_7069e055>
  410ea9:	dec    rcx
  410eac:	call   40bb40 <__swc_fn_7069e055_000171_360af05d>
  410eb1:	mov    rdi,rax
  410eb4:	mov    rax,QWORD PTR [rdi+0xbd0]
  410ebb:	xor    ecx,ecx
  410ebd:	test   rax,rax
  410ec0:	je     410ec5 <__swc_fn_7069e055_000107_90faaa26+0x45>
  410ec2:	mov    rcx,QWORD PTR [rax]
  410ec5:	call   40edb0 <__swc_fn_7069e055_000178_718d7b54>
  410eca:	lea    rax,[rsp+0x8]
  410ecf:	lea    rcx,[rdi+0x9c8]
  410ed6:	mov    QWORD PTR [rsp+0x8],rcx
  410edb:	mov    QWORD PTR [rax+0x8],0x40
  410ee3:	xor    ecx,ecx
  410ee5:	mov    rdx,rax
  410ee8:	call   409ea0 <__swc_fn_7069e055_000123_4f256d58>
  410eed:	mov    DWORD PTR [rdi+0xbc8],eax
  410ef3:	mov    rdi,QWORD PTR [rdi+0x990]
  410efa:	test   rdi,rdi
  410efd:	je     410f07 <__swc_fn_7069e055_000107_90faaa26+0x87>
  410eff:	mov    rcx,rsi
  410f02:	mov    rdx,rbx
  410f05:	call   rdi
  410f07:	call   410c30 <__swc_fn_7069e055_000095_ad13d15c>
  410f0c:	test   al,al
  410f0e:	je     410f1e <__swc_fn_7069e055_000107_90faaa26+0x9e>
  410f10:	mov    rcx,rsi
  410f13:	mov    rdx,rbx
  410f16:	xor    r8d,r8d
  410f19:	call   40dec0 <__swc_fn_7069e055_000124_83db7238>
  410f1e:	mov    rcx,rsi
  410f21:	mov    rdx,rbx
  410f24:	call   40d540 <__swc_fn_7069e055_000106_ffe51047>
  410f29:	call   4114b0 <__swc_fn_7069e055_000122_be2e2f68>
  410f2e:	add    rsp,0x20
  410f32:	pop    rdi
  410f33:	pop    rsi
  410f34:	pop    rbx
  410f35:	ret
	...

0000000000410f40 <__swc_fn_7069e055_000110_3dc01326>:
  410f40:	test   r8,r8
  410f43:	jne    410f48 <__swc_fn_7069e055_000110_3dc01326+0x8>
  410f45:	xor    eax,eax
  410f47:	ret
  410f48:	xor    eax,eax
  410f4a:	nop    WORD PTR [rax+rax*1+0x0]
  410f50:	mov    r9,r8
  410f53:	sub    r9,rax
  410f56:	cmp    r9,0x10
  410f5a:	jb     410fa4 <__swc_fn_7069e055_000110_3dc01326+0x64>
  410f5c:	lea    r9,[rcx+rax*1]
  410f60:	lea    r10,[rdx+rax*1]
  410f64:	vmovups xmm0,XMMWORD PTR [r10]
  410f69:	vmovups xmm1,XMMWORD PTR [r9]
  410f6e:	vpcmpeqb xmm0,xmm1,xmm0
  410f72:	vpmovmskb r9d,xmm0
  410f76:	cmp    r9d,0xffff
  410f7d:	je     410f9e <__swc_fn_7069e055_000110_3dc01326+0x5e>
  410f7f:	not    r9d
  410f82:	xor    r8d,r8d
  410f85:	movzx  r9d,r9w
  410f89:	tzcnt  r8d,r9d
  410f8e:	add    rax,r8
  410f91:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410f95:	movzx  eax,BYTE PTR [rdx+rax*1]
  410f99:	sub    ecx,eax
  410f9b:	mov    eax,ecx
  410f9d:	ret
  410f9e:	lea    rax,[rax+0x10]
  410fa2:	jmp    410f50 <__swc_fn_7069e055_000110_3dc01326+0x10>
  410fa4:	cmp    r9,0x8
  410fa8:	jb     41101b <__swc_fn_7069e055_000110_3dc01326+0xdb>
  410faa:	lea    r9,[rcx+rax*1]
  410fae:	lea    r10,[rdx+rax*1]
  410fb2:	mov    r9,QWORD PTR [r9]
  410fb5:	xor    r9,QWORD PTR [r10]
  410fb8:	test   r9,r9
  410fbb:	je     410fd9 <__swc_fn_7069e055_000110_3dc01326+0x99>
  410fbd:	xor    r8d,r8d
  410fc0:	tzcnt  r8,r9
  410fc5:	shr    r8,0x3
  410fc9:	add    rax,r8
  410fcc:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410fd0:	movzx  eax,BYTE PTR [rdx+rax*1]
  410fd4:	sub    ecx,eax
  410fd6:	mov    eax,ecx
  410fd8:	ret
  410fd9:	lea    rax,[rax+0x8]
  410fdd:	cmp    rax,r8
  410fe0:	jne    410fe5 <__swc_fn_7069e055_000110_3dc01326+0xa5>
  410fe2:	xor    eax,eax
  410fe4:	ret
  410fe5:	lea    rax,[r8-0x8]
  410fe9:	lea    r8,[rcx+rax*1]
  410fed:	lea    r9,[rdx+rax*1]
  410ff1:	mov    r8,QWORD PTR [r8]
  410ff4:	xor    r8,QWORD PTR [r9]
  410ff7:	test   r8,r8
  410ffa:	je     411018 <__swc_fn_7069e055_000110_3dc01326+0xd8>
  410ffc:	xor    r9d,r9d
  410fff:	tzcnt  r9,r8
  411004:	shr    r9,0x3
  411008:	add    rax,r9
  41100b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  41100f:	movzx  eax,BYTE PTR [rdx+rax*1]
  411013:	sub    ecx,eax
  411015:	mov    eax,ecx
  411017:	ret
  411018:	xor    eax,eax
  41101a:	ret
  41101b:	cmp    r9,0x4
  41101f:	jb     411092 <__swc_fn_7069e055_000110_3dc01326+0x152>
  411021:	lea    r9,[rcx+rax*1]
  411025:	lea    r10,[rdx+rax*1]
  411029:	mov    r9d,DWORD PTR [r9]
  41102c:	xor    r9d,DWORD PTR [r10]
  41102f:	test   r9d,r9d
  411032:	je     411050 <__swc_fn_7069e055_000110_3dc01326+0x110>
  411034:	xor    r8d,r8d
  411037:	tzcnt  r8,r9
  41103c:	shr    r8,0x3
  411040:	add    rax,r8
  411043:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411047:	movzx  eax,BYTE PTR [rdx+rax*1]
  41104b:	sub    ecx,eax
  41104d:	mov    eax,ecx
  41104f:	ret
  411050:	lea    rax,[rax+0x4]
  411054:	cmp    rax,r8
  411057:	jne    41105c <__swc_fn_7069e055_000110_3dc01326+0x11c>
  411059:	xor    eax,eax
  41105b:	ret
  41105c:	lea    rax,[r8-0x4]
  411060:	lea    r8,[rcx+rax*1]
  411064:	lea    r9,[rdx+rax*1]
  411068:	mov    r8d,DWORD PTR [r8]
  41106b:	xor    r8d,DWORD PTR [r9]
  41106e:	test   r8d,r8d
  411071:	je     41108f <__swc_fn_7069e055_000110_3dc01326+0x14f>
  411073:	xor    r9d,r9d
  411076:	tzcnt  r9,r8
  41107b:	shr    r9,0x3
  41107f:	add    rax,r9
  411082:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411086:	movzx  eax,BYTE PTR [rdx+rax*1]
  41108a:	sub    ecx,eax
  41108c:	mov    eax,ecx
  41108e:	ret
  41108f:	xor    eax,eax
  411091:	ret
  411092:	cmp    r9,0x2
  411096:	jb     4110e9 <__swc_fn_7069e055_000110_3dc01326+0x1a9>
  411098:	lea    r9,[rcx+rax*1]
  41109c:	lea    r10,[rdx+rax*1]
  4110a0:	mov    r9w,WORD PTR [r9]
  4110a4:	xor    r9w,WORD PTR [r10]
  4110a8:	test   r9w,r9w
  4110ac:	je     4110ce <__swc_fn_7069e055_000110_3dc01326+0x18e>
  4110ae:	xor    r8d,r8d
  4110b1:	movzx  r9d,r9w
  4110b5:	tzcnt  r8,r9
  4110ba:	shr    r8,0x3
  4110be:	add    rax,r8
  4110c1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4110c5:	movzx  eax,BYTE PTR [rdx+rax*1]
  4110c9:	sub    ecx,eax
  4110cb:	mov    eax,ecx
  4110cd:	ret
  4110ce:	lea    rax,[rax+0x2]
  4110d2:	cmp    rax,r8
  4110d5:	jne    4110da <__swc_fn_7069e055_000110_3dc01326+0x19a>
  4110d7:	xor    eax,eax
  4110d9:	ret
  4110da:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  4110e0:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  4110e6:	sub    eax,ecx
  4110e8:	ret
  4110e9:	test   r9,r9
  4110ec:	je     4110fb <__swc_fn_7069e055_000110_3dc01326+0x1bb>
  4110ee:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4110f2:	movzx  eax,BYTE PTR [rdx+rax*1]
  4110f6:	sub    ecx,eax
  4110f8:	mov    eax,ecx
  4110fa:	ret
  4110fb:	xor    eax,eax
  4110fd:	ret
	...

0000000000411100 <__swc_fn_7069e055_000113_6b799b8d>:
  411100:	push   r12
  411102:	push   r13
  411104:	push   r14
  411106:	push   rdi
  411107:	push   rsi
  411108:	push   r15
  41110a:	sub    rsp,0xd8
  411111:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  411117:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  41111d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  411123:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  411129:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  41112f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  411138:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  411141:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  41114a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  411153:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  41115c:	mov    r12,rcx
  41115f:	test   rcx,rcx
  411162:	je     41117e <__swc_fn_7069e055_000113_6b799b8d+0x7e>
  411164:	mov    eax,r12d
  411167:	and    eax,0xfff
  41116d:	setne  al
  411170:	cmp    r12,0xffffffffffffefff
  411177:	seta   cl
  41117a:	or     al,cl
  41117c:	je     411185 <__swc_fn_7069e055_000113_6b799b8d+0x85>
  41117e:	xor    eax,eax
  411180:	jmp    41121b <__swc_fn_7069e055_000113_6b799b8d+0x11b>
  411185:	call   40dbe0 <__swc_fn_7069e055_000112_126150d1>
  41118a:	mov    r13,rax
  41118d:	test   rax,rax
  411190:	jne    411199 <__swc_fn_7069e055_000113_6b799b8d+0x99>
  411192:	xor    eax,eax
  411194:	jmp    41121b <__swc_fn_7069e055_000113_6b799b8d+0x11b>
  411199:	lea    r14,[r12+0x1000]
  4111a1:	xor    edi,edi
  4111a3:	mov    rsi,r14
  4111a6:	xor    edx,edx
  4111a8:	mov    ecx,0x22
  4111ad:	mov    eax,0xffffffff
  4111b2:	movsxd r8,eax
  4111b5:	xor    r9d,r9d
  4111b8:	xor    eax,eax
  4111ba:	call   4070d0 <mmap@plt>
  4111bf:	mov    r15,rax
  4111c2:	cmp    rax,0xffffffffffffffff
  4111c6:	jne    4111cc <__swc_fn_7069e055_000113_6b799b8d+0xcc>
  4111c8:	xor    eax,eax
  4111ca:	jmp    41121b <__swc_fn_7069e055_000113_6b799b8d+0x11b>
  4111cc:	mov    rdi,r15
  4111cf:	mov    esi,0x1000
  4111d4:	mov    edx,0x3
  4111d9:	xor    eax,eax
  4111db:	call   407170 <mprotect@plt>
  4111e0:	test   eax,eax
  4111e2:	je     4111f5 <__swc_fn_7069e055_000113_6b799b8d+0xf5>
  4111e4:	mov    rdi,r15
  4111e7:	mov    rsi,r14
  4111ea:	xor    eax,eax
  4111ec:	call   407160 <munmap@plt>
  4111f1:	xor    eax,eax
  4111f3:	jmp    41121b <__swc_fn_7069e055_000113_6b799b8d+0x11b>
  4111f5:	mov    QWORD PTR [r15+0x8],r12
  4111f9:	mov    rcx,r13
  4111fc:	call   411850 <__swc_fn_7069e055_000137_8c07c14b>
  411201:	mov    rax,QWORD PTR [r13+0x8]
  411205:	mov    QWORD PTR [r15],rax
  411208:	mov    QWORD PTR [r13+0x8],r15
  41120c:	mov    rcx,r13
  41120f:	call   40a240 <__swc_fn_7069e055_000138_715e84ff>
  411214:	lea    rax,[r15+0x1000]
  41121b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  411221:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  411227:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  41122d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  411233:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  411239:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  411242:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  41124b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  411254:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  41125d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  411266:	add    rsp,0xd8
  41126d:	pop    r15
  41126f:	pop    rsi
  411270:	pop    rdi
  411271:	pop    r14
  411273:	pop    r13
  411275:	pop    r12
  411277:	ret
	...

0000000000411280 <__swc_fn_7069e055_000116_e9fc0224>:
  411280:	push   rbx
  411281:	push   r12
  411283:	push   rdi
  411284:	push   rsi
  411285:	sub    rsp,0xa8
  41128c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  411292:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411298:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41129e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4112a4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4112aa:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4112b0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4112b6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4112bc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4112c5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4112ce:	mov    rbx,rdx
  4112d1:	mov    r12,rcx
  4112d4:	mov    rdi,rcx
  4112d7:	mov    rsi,rdx
  4112da:	xor    edx,edx
  4112dc:	xor    eax,eax
  4112de:	call   407170 <mprotect@plt>
  4112e3:	test   eax,eax
  4112e5:	jne    411309 <__swc_fn_7069e055_000116_e9fc0224+0x89>
  4112e7:	mov    rcx,r12
  4112ea:	mov    rdx,rbx
  4112ed:	xor    al,al
  4112ef:	mov    r8,rax
  4112f2:	call   409ce0 <__swc_fn_7069e055_000114_5f48311c>
  4112f7:	mov    rdi,r12
  4112fa:	mov    rsi,rbx
  4112fd:	mov    edx,0x4
  411302:	xor    eax,eax
  411304:	call   4071d0 <madvise@plt>
  411309:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41130f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411315:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41131b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411321:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411327:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  41132d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411333:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411339:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411342:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41134b:	add    rsp,0xa8
  411352:	pop    rsi
  411353:	pop    rdi
  411354:	pop    r12
  411356:	pop    rbx
  411357:	ret
	...

0000000000411360 <__swc_fn_7069e055_000119_d3318640>:
  411360:	push   rsi
  411361:	push   rdi
  411362:	push   r12
  411364:	push   r13
  411366:	push   r14
  411368:	sub    rsp,0xe0
  41136f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  411375:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  41137b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  411381:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  411387:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  41138d:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  411396:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  41139f:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  4113a8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  4113b1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  4113ba:	mov    rsi,rdx
  4113bd:	mov    rdi,rcx
  4113c0:	call   40dbe0 <__swc_fn_7069e055_000112_126150d1>
  4113c5:	mov    r12,rax
  4113c8:	test   rax,rax
  4113cb:	jne    4113d2 <__swc_fn_7069e055_000119_d3318640+0x72>
  4113cd:	jmp    411446 <__swc_fn_7069e055_000119_d3318640+0xe6>
  4113d2:	mov    rcx,r12
  4113d5:	call   411850 <__swc_fn_7069e055_000137_8c07c14b>
  4113da:	lea    r13,[r12+0x8]
  4113df:	mov    rax,QWORD PTR [r13+0x0]
  4113e3:	test   rax,rax
  4113e6:	je     41143e <__swc_fn_7069e055_000119_d3318640+0xde>
  4113e8:	nop    DWORD PTR [rax+rax*1+0x0]
  4113f0:	lea    rcx,[rax+0x1000]
  4113f7:	cmp    rcx,rdi
  4113fa:	jne    411432 <__swc_fn_7069e055_000119_d3318640+0xd2>
  4113fc:	cmp    QWORD PTR [rax+0x8],rsi
  411400:	je     41140c <__swc_fn_7069e055_000119_d3318640+0xac>
  411402:	mov    rcx,r12
  411405:	call   40a240 <__swc_fn_7069e055_000138_715e84ff>
  41140a:	jmp    411446 <__swc_fn_7069e055_000119_d3318640+0xe6>
  41140c:	mov    r14,QWORD PTR [rax]
  41140f:	mov    rdi,rax
  411412:	lea    rsi,[rsi+0x1000]
  411419:	xor    eax,eax
  41141b:	call   407160 <munmap@plt>
  411420:	test   eax,eax
  411422:	jne    411428 <__swc_fn_7069e055_000119_d3318640+0xc8>
  411424:	mov    QWORD PTR [r13+0x0],r14
  411428:	mov    rcx,r12
  41142b:	call   40a240 <__swc_fn_7069e055_000138_715e84ff>
  411430:	jmp    411446 <__swc_fn_7069e055_000119_d3318640+0xe6>
  411432:	mov    r13,rax
  411435:	mov    rax,QWORD PTR [r13+0x0]
  411439:	test   rax,rax
  41143c:	jne    4113f0 <__swc_fn_7069e055_000119_d3318640+0x90>
  41143e:	mov    rcx,r12
  411441:	call   40a240 <__swc_fn_7069e055_000138_715e84ff>
  411446:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  41144c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  411452:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  411458:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  41145e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  411464:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  41146d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  411476:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  41147f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  411488:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  411491:	add    rsp,0xe0
  411498:	pop    r14
  41149a:	pop    r13
  41149c:	pop    r12
  41149e:	pop    rdi
  41149f:	pop    rsi
  4114a0:	ret
	...

00000000004114b0 <__swc_fn_7069e055_000122_be2e2f68>:
  4114b0:	push   rdi
  4114b1:	push   rsi
  4114b2:	sub    rsp,0xa8
  4114b9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4114bf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4114c5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4114cb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4114d1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4114d7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4114dd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4114e3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4114e9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4114f2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4114fb:	mov    rdi,0xfffffffffffffd66
  411502:	xor    eax,eax
  411504:	call   407180 <exit@plt>
  411509:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41150f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411515:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41151b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411521:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411527:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  41152d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411533:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411539:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411542:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41154b:	add    rsp,0xa8
  411552:	pop    rsi
  411553:	pop    rdi
  411554:	ret
	...

0000000000411560 <__swc_fn_7069e055_000125_540bf7e8>:
  411560:	push   rbx
  411561:	push   rsi
  411562:	push   rdi
  411563:	sub    rsp,0x30
  411567:	mov    rbx,rdx
  41156a:	mov    esi,ecx
  41156c:	test   ecx,ecx
  41156e:	je     411643 <__swc_fn_7069e055_000125_540bf7e8+0xe3>
  411574:	mov    rcx,rsi
  411577:	shl    rcx,0x4
  41157b:	call   410a70 <__swc_fn_7069e055_000083_4a10c7e7>
  411580:	test   rax,rax
  411583:	je     411632 <__swc_fn_7069e055_000125_540bf7e8+0xd2>
  411589:	mov    rcx,rsi
  41158c:	xor    edx,edx
  41158e:	test   rsi,rsi
  411591:	jbe    411612 <__swc_fn_7069e055_000125_540bf7e8+0xb2>
  411597:	nop    WORD PTR [rax+rax*1+0x0]
  4115a0:	mov    r8d,edx
  4115a3:	mov    r9,QWORD PTR [rbx+r8*8]
  4115a7:	add    r8,r8
  4115aa:	lea    r8,[rax+r8*8]
  4115ae:	xor    r10d,r10d
  4115b1:	test   r9,r9
  4115b4:	je     4115f0 <__swc_fn_7069e055_000125_540bf7e8+0x90>
  4115b6:	mov    r11,r9
  4115b9:	mov    dil,BYTE PTR [r11]
  4115bc:	test   dil,dil
  4115bf:	je     4115f0 <__swc_fn_7069e055_000125_540bf7e8+0x90>
  4115c1:	cs nop WORD PTR [rax+rax*1+0x0]
  4115cb:	cs nop WORD PTR [rax+rax*1+0x0]
  4115d5:	cs nop WORD PTR [rax+rax*1+0x0]
  4115df:	nop
  4115e0:	add    r11,0x1
  4115e4:	add    r10,0x1
  4115e8:	mov    dil,BYTE PTR [r11]
  4115eb:	test   dil,dil
  4115ee:	jne    4115e0 <__swc_fn_7069e055_000125_540bf7e8+0x80>
  4115f0:	mov    QWORD PTR [rsp+0x18],r9
  4115f5:	mov    QWORD PTR [rsp+0x20],r10
  4115fa:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411600:	vmovups XMMWORD PTR [r8],xmm0
  411605:	add    rdx,0x1
  411609:	cmp    rdx,rcx
  41160c:	jb     4115a0 <__swc_fn_7069e055_000125_540bf7e8+0x40>
  411612:	lea    rcx,[rip+0x1572f]        # 426d48 <__swc_bss_base_7069e055+0x2d08>
  411619:	mov    QWORD PTR [rsp+0x8],rax
  41161e:	mov    esi,esi
  411620:	mov    QWORD PTR [rsp+0x10],rsi
  411625:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  41162b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411630:	jmp    411643 <__swc_fn_7069e055_000125_540bf7e8+0xe3>
  411632:	lea    rcx,[rip+0x1fb7]        # 4135f0 <__swc_rdata_base_7069e055+0x4e0>
  411639:	call   409d90 <__swc_fn_7069e055_000120_2648f149>
  41163e:	call   4114b0 <__swc_fn_7069e055_000122_be2e2f68>
  411643:	add    rsp,0x30
  411647:	pop    rdi
  411648:	pop    rsi
  411649:	pop    rbx
  41164a:	ret
  41164b:	add    BYTE PTR [rax],al
  41164d:	add    BYTE PTR [rax],al
	...

0000000000411650 <__swc_fn_7069e055_000128_a481cb88>:
  411650:	push   rdi
  411651:	push   rsi
  411652:	sub    rsp,0xa8
  411659:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41165f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411665:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41166b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411671:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411677:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41167d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411683:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411689:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411692:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41169b:	mov    edi,ecx
  41169d:	xor    eax,eax
  41169f:	call   4071e0 <pthread_key_delete@plt>
  4116a4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4116aa:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4116b0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4116b6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4116bc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4116c2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4116c8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4116ce:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4116d4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4116dd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4116e6:	add    rsp,0xa8
  4116ed:	pop    rsi
  4116ee:	pop    rdi
  4116ef:	ret

00000000004116f0 <__swc_fn_7069e055_000131_a611b8c4>:
  4116f0:	push   rdi
  4116f1:	push   rsi
  4116f2:	sub    rsp,0xa8
  4116f9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4116ff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411705:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41170b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411711:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411717:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41171d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411723:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411729:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411732:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41173b:	test   rcx,rcx
  41173e:	je     41174f <__swc_fn_7069e055_000131_a611b8c4+0x5f>
  411740:	lea    rax,[rcx-0x1]
  411744:	mov    eax,eax
  411746:	mov    edi,eax
  411748:	xor    eax,eax
  41174a:	call   4071e0 <pthread_key_delete@plt>
  41174f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  411755:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  41175b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411761:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411767:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41176d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411773:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411779:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41177f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411788:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411791:	add    rsp,0xa8
  411798:	pop    rsi
  411799:	pop    rdi
  41179a:	ret
  41179b:	add    BYTE PTR [rax],al
  41179d:	add    BYTE PTR [rax],al
	...

00000000004117a0 <__swc_fn_7069e055_000134_a9c1c700>:
  4117a0:	push   rsi
  4117a1:	push   rdi
  4117a2:	sub    rsp,0xa8
  4117a9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4117af:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4117b5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4117bb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4117c1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4117c7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4117cd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4117d3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4117d9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4117e2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4117eb:	xor    eax,eax
  4117ed:	call   4071f0 <gettid@plt>
  4117f2:	movsxd rax,eax
  4117f5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4117fb:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411801:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411807:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41180d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411813:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411819:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41181f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411825:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41182e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411837:	add    rsp,0xa8
  41183e:	pop    rdi
  41183f:	pop    rsi
  411840:	ret
	...

0000000000411850 <__swc_fn_7069e055_000137_8c07c14b>:
  411850:	push   rbx
  411851:	push   rdi
  411852:	push   rsi
  411853:	sub    rsp,0xc0
  41185a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  411860:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  411866:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41186c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  411872:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  411878:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41187e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  411884:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41188d:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  411896:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41189f:	mov    rbx,rcx
  4118a2:	cs nop WORD PTR [rax+rax*1+0x0]
  4118ac:	nop    DWORD PTR [rax+0x0]
  4118b0:	mov    edx,0x80000000
  4118b5:	xor    eax,eax
  4118b7:	lock cmpxchg DWORD PTR [rbx],edx
  4118bb:	test   eax,eax
  4118bd:	je     4118f4 <__swc_fn_7069e055_000137_8c07c14b+0xa4>
  4118bf:	mov    eax,DWORD PTR [rbx]
  4118c1:	lea    rcx,[rsp+0x14]
  4118c6:	mov    DWORD PTR [rsp+0x14],eax
  4118ca:	test   eax,eax
  4118cc:	je     4118b0 <__swc_fn_7069e055_000137_8c07c14b+0x60>
  4118ce:	mov    QWORD PTR [rsp],0x0
  4118d6:	mov    edi,0xca
  4118db:	mov    rsi,rbx
  4118de:	mov    edx,0x80
  4118e3:	mov    ecx,DWORD PTR [rcx]
  4118e5:	xor    r8d,r8d
  4118e8:	xor    r9d,r9d
  4118eb:	xor    eax,eax
  4118ed:	call   4071a0 <syscall@plt>
  4118f2:	jmp    4118b0 <__swc_fn_7069e055_000137_8c07c14b+0x60>
  4118f4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4118fa:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411900:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411906:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41190c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411912:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411918:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41191e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  411927:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  411930:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  411939:	add    rsp,0xc0
  411940:	pop    rsi
  411941:	pop    rdi
  411942:	pop    rbx
  411943:	ret
	...

0000000000411950 <__swc_fn_7069e055_000140_055b38a4>:
  411950:	sub    rsp,0x8
  411954:	call   40a240 <__swc_fn_7069e055_000138_715e84ff>
  411959:	add    rsp,0x8
  41195d:	ret
	...

0000000000411960 <__swc_fn_7069e055_000143_d299b428>:
  411960:	push   rdi
  411961:	push   rsi
  411962:	sub    rsp,0xa8
  411969:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41196f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411975:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41197b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411981:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411987:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41198d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411993:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411999:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4119a2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4119ab:	mov    edi,0x28
  4119b0:	xor    eax,eax
  4119b2:	call   4071c0 <malloc@plt>
  4119b7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4119bd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4119c3:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4119c9:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4119cf:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4119d5:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4119db:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4119e1:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4119e7:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4119f0:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4119f9:	add    rsp,0xa8
  411a00:	pop    rsi
  411a01:	pop    rdi
  411a02:	ret
	...

0000000000411a10 <__swc_fn_7069e055_000146_162f363d>:
  411a10:	mov    QWORD PTR [r8],0x0
  411a17:	cmp    rdx,0x10
  411a1b:	jae    411a20 <__swc_fn_7069e055_000146_162f363d+0x10>
  411a1d:	xor    eax,eax
  411a1f:	ret
  411a20:	mov    eax,DWORD PTR [rcx]
  411a22:	cmp    eax,0x42445753
  411a28:	jne    411a32 <__swc_fn_7069e055_000146_162f363d+0x22>
  411a2a:	mov    eax,DWORD PTR [rcx+0x4]
  411a2d:	cmp    eax,0x1
  411a30:	je     411a35 <__swc_fn_7069e055_000146_162f363d+0x25>
  411a32:	xor    eax,eax
  411a34:	ret
  411a35:	mov    QWORD PTR [r8],rdx
  411a38:	mov    rax,rcx
  411a3b:	ret
  411a3c:	add    BYTE PTR [rax],al
	...

0000000000411a40 <__swc_fn_7069e055_000149_2eb804cc>:
  411a40:	push   rbx
  411a41:	sub    rsp,0xe0
  411a48:	lea    rbx,[rsp+0x8]
  411a4d:	vxorps xmm0,xmm0,xmm0
  411a51:	vmovups YMMWORD PTR [rbx],ymm0
  411a55:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  411a5a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  411a5f:	vzeroupper
  411a62:	mov    DWORD PTR [rbx+0x60],0x0
  411a69:	mov    r8,rbx
  411a6c:	mov    rdx,rcx
  411a6f:	nop
  411a70:	mov    r9,rdx
  411a73:	movabs rdx,0x6666666666666667
  411a7d:	mov    rax,r9
  411a80:	imul   rdx
  411a83:	sar    rdx,0x2
  411a87:	mov    r10,rdx
  411a8a:	shr    rdx,0x3f
  411a8e:	add    r10,rdx
  411a91:	mov    rdx,r10
  411a94:	imul   r11,r10,0xa
  411a98:	sub    r9,r11
  411a9b:	mov    r11,QWORD PTR [rip+0x1b6e]        # 413610 <__swc_rdata_base_7069e055+0x500>
  411aa2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  411aa7:	mov    BYTE PTR [r8],r9b
  411aaa:	lea    r9,[r8+0x1]
  411aae:	mov    r8,r9
  411ab1:	test   r10,r10
  411ab4:	jne    411a70 <__swc_fn_7069e055_000149_2eb804cc+0x30>
  411ab6:	test   rcx,rcx
  411ab9:	jge    411ac3 <__swc_fn_7069e055_000149_2eb804cc+0x83>
  411abb:	mov    BYTE PTR [r9],0x2d
  411abf:	add    r8,0x1
  411ac3:	mov    BYTE PTR [r8],0x0
  411ac7:	sub    r8,0x1
  411acb:	mov    rax,rbx
  411ace:	cmp    rax,r8
  411ad1:	jae    411af6 <__swc_fn_7069e055_000149_2eb804cc+0xb6>
  411ad3:	cs nop WORD PTR [rax+rax*1+0x0]
  411add:	nop    DWORD PTR [rax]
  411ae0:	mov    cl,BYTE PTR [r8]
  411ae3:	mov    dl,BYTE PTR [rax]
  411ae5:	mov    BYTE PTR [r8],dl
  411ae8:	sub    r8,0x1
  411aec:	mov    BYTE PTR [rax],cl
  411aee:	inc    rax
  411af1:	cmp    rax,r8
  411af4:	jb     411ae0 <__swc_fn_7069e055_000149_2eb804cc+0xa0>
  411af6:	xor    eax,eax
  411af8:	test   rbx,rbx
  411afb:	je     411b1e <__swc_fn_7069e055_000149_2eb804cc+0xde>
  411afd:	mov    rcx,rbx
  411b00:	mov    dl,BYTE PTR [rcx]
  411b02:	test   dl,dl
  411b04:	je     411b1e <__swc_fn_7069e055_000149_2eb804cc+0xde>
  411b06:	cs nop WORD PTR [rax+rax*1+0x0]
  411b10:	add    rcx,0x1
  411b14:	add    rax,0x1
  411b18:	mov    dl,BYTE PTR [rcx]
  411b1a:	test   dl,dl
  411b1c:	jne    411b10 <__swc_fn_7069e055_000149_2eb804cc+0xd0>
  411b1e:	mov    QWORD PTR [rbx+0xa8],rbx
  411b25:	mov    QWORD PTR [rbx+0xb0],rax
  411b2c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  411b34:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  411b3c:	lea    rcx,[rbx+0xb8]
  411b43:	call   409d90 <__swc_fn_7069e055_000120_2648f149>
  411b48:	add    rsp,0xe0
  411b4f:	pop    rbx
  411b50:	ret
	...

0000000000411b60 <__swc_fn_7069e055_000152_86f1d437>:
  411b60:	vxorps xmm0,xmm0,xmm0
  411b64:	vmovups XMMWORD PTR [rcx],xmm0
  411b68:	mov    QWORD PTR [rcx+0x10],0x0
  411b70:	ret
	...

0000000000411b80 <__swc_fn_7069e055_000155_86f1d437>:
  411b80:	vxorps xmm0,xmm0,xmm0
  411b84:	vmovups XMMWORD PTR [rcx],xmm0
  411b88:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411b8d:	vxorps xmm0,xmm0,xmm0
  411b91:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411b96:	vmovups xmm0,XMMWORD PTR [rip+0x1b6a]        # 413708 <__swc_rdata_base_7069e055+0x5f8>
  411b9e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411ba3:	vxorps xmm0,xmm0,xmm0
  411ba7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411bac:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411bb1:	mov    QWORD PTR [rcx+0x60],0x0
  411bb9:	ret
  411bba:	add    BYTE PTR [rax],al
  411bbc:	add    BYTE PTR [rax],al
	...

0000000000411bc0 <__swc_fn_7069e055_000158_86f1d437>:
  411bc0:	vxorps xmm0,xmm0,xmm0
  411bc4:	vmovups XMMWORD PTR [rcx],xmm0
  411bc8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411bcd:	vxorps xmm0,xmm0,xmm0
  411bd1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411bd6:	vmovups xmm0,XMMWORD PTR [rip+0x1c52]        # 413830 <__swc_rdata_base_7069e055+0x720>
  411bde:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411be3:	vxorps xmm0,xmm0,xmm0
  411be7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411bec:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411bf1:	vxorps xmm0,xmm0,xmm0
  411bf5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411bfa:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  411bff:	vxorps xmm0,xmm0,xmm0
  411c03:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  411c0b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  411c13:	vxorps xmm0,xmm0,xmm0
  411c17:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  411c1f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  411c27:	vxorps xmm0,xmm0,xmm0
  411c2b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  411c33:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  411c3b:	mov    QWORD PTR [rcx+0xe0],0x0
  411c46:	ret
	...

0000000000411c50 <__swc_fn_7069e055_000161_13ead2ff>:
  411c50:	push   rbx
  411c51:	mov    rbx,rcx
  411c54:	call   40b7d0 <__swc_fn_7069e055_000162_e36363a8>
  411c59:	mov    rax,QWORD PTR [rbx+0x10]
  411c5d:	test   rax,rax
  411c60:	je     411c71 <__swc_fn_7069e055_000161_13ead2ff+0x21>
  411c62:	mov    rcx,rbx
  411c65:	mov    rdx,rax
  411c68:	mov    r8,QWORD PTR [rbx+0x18]
  411c6c:	call   40e970 <__swc_fn_7069e055_000160_47b270e1>
  411c71:	vxorps xmm0,xmm0,xmm0
  411c75:	vmovups XMMWORD PTR [rbx],xmm0
  411c79:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411c7e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411c83:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  411c88:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  411c8d:	mov    QWORD PTR [rbx+0x50],0x0
  411c95:	pop    rbx
  411c96:	ret
	...

0000000000411ca0 <__swc_fn_7069e055_000164_72795826>:
  411ca0:	sub    rsp,0x10
  411ca4:	mov    eax,r8d
  411ca7:	mov    r8d,r9d
  411caa:	test   r9d,r9d
  411cad:	jne    411cc6 <__swc_fn_7069e055_000164_72795826+0x26>
  411caf:	vmovups xmm0,XMMWORD PTR [rip+0x1c31]        # 4138e8 <__swc_rdata_base_7069e055+0x7d8>
  411cb7:	vmovups XMMWORD PTR [r10],xmm0
  411cbc:	mov    eax,0x1
  411cc1:	add    rsp,0x10
  411cc5:	ret
  411cc6:	mov    r9,r8
  411cc9:	cmp    r8,rax
  411ccc:	jb     411cd3 <__swc_fn_7069e055_000164_72795826+0x33>
  411cce:	cmp    r9,rdx
  411cd1:	jb     411cda <__swc_fn_7069e055_000164_72795826+0x3a>
  411cd3:	xor    eax,eax
  411cd5:	add    rsp,0x10
  411cd9:	ret
  411cda:	xor    eax,eax
  411cdc:	lea    r8,[r9+rax*1]
  411ce0:	cmp    r8,rdx
  411ce3:	jae    411d13 <__swc_fn_7069e055_000164_72795826+0x73>
  411ce5:	cs nop WORD PTR [rax+rax*1+0x0]
  411cef:	cs nop WORD PTR [rax+rax*1+0x0]
  411cf9:	nop    DWORD PTR [rax+0x0]
  411d00:	cmp    BYTE PTR [rcx+r8*1],0x0
  411d05:	je     411d13 <__swc_fn_7069e055_000164_72795826+0x73>
  411d07:	inc    rax
  411d0a:	lea    r8,[r9+rax*1]
  411d0e:	cmp    r8,rdx
  411d11:	jb     411d00 <__swc_fn_7069e055_000164_72795826+0x60>
  411d13:	cmp    r8,rdx
  411d16:	jne    411d1f <__swc_fn_7069e055_000164_72795826+0x7f>
  411d18:	xor    eax,eax
  411d1a:	add    rsp,0x10
  411d1e:	ret
  411d1f:	add    rcx,r9
  411d22:	mov    QWORD PTR [rsp],rcx
  411d26:	mov    QWORD PTR [rsp+0x8],rax
  411d2b:	vmovups xmm0,XMMWORD PTR [rsp]
  411d30:	vmovups XMMWORD PTR [r10],xmm0
  411d35:	mov    eax,0x1
  411d3a:	add    rsp,0x10
  411d3e:	ret
	...

0000000000411d40 <__swc_fn_7069e055_000167_bcc835b8>:
  411d40:	push   rbp
  411d41:	push   rbx
  411d42:	push   rsi
  411d43:	push   rdi
  411d44:	push   r12
  411d46:	push   r13
  411d48:	push   r14
  411d4a:	push   r15
  411d4c:	sub    rsp,0x10
  411d50:	mov    rbp,rsp
  411d53:	vmovups XMMWORD PTR [rsp],xmm6
  411d58:	sub    rsp,0x50
  411d5c:	mov    rbx,rsp
  411d5f:	mov    rsi,r8
  411d62:	mov    QWORD PTR [rsp+0x30],r8
  411d67:	mov    rdi,rcx
  411d6a:	mov    QWORD PTR [rsp+0x38],rcx
  411d6f:	mov    r12,rdx
  411d72:	xor    r13b,r13b
  411d75:	mov    r14,QWORD PTR [rdi+0x8]
  411d79:	mov    QWORD PTR [rsp+0x40],r14
  411d7e:	xor    r15d,r15d
  411d81:	test   r14,r14
  411d84:	jbe    411fde <__swc_fn_7069e055_000167_bcc835b8+0x29e>
  411d8a:	mov    r14,QWORD PTR [rdi]
  411d8d:	mov    rax,QWORD PTR [rsp+0x40]
  411d92:	mov    QWORD PTR [rsp+0x48],r14
  411d97:	vmovups xmm6,XMMWORD PTR [rip+0x1769]        # 413508 <__swc_rdata_base_7069e055+0x3f8>
  411d9f:	nop
  411da0:	cmp    QWORD PTR [r14+r15*8],0x0
  411da5:	jne    411daf <__swc_fn_7069e055_000167_bcc835b8+0x6f>
  411da7:	mov    r14,rax
  411daa:	jmp    411fbe <__swc_fn_7069e055_000167_bcc835b8+0x27e>
  411daf:	mov    rcx,QWORD PTR [rdi]
  411db2:	mov    rdx,QWORD PTR [rcx+r15*8]
  411db6:	mov    rdi,rbx
  411db9:	mov    rcx,rdi
  411dbc:	sub    rsp,0x8
  411dc0:	mov    r14,rax
  411dc3:	call   40e9f0 <__swc_fn_7069e055_000166_cc119975>
  411dc8:	add    rsp,0x8
  411dcc:	mov    al,BYTE PTR [rbx]
  411dce:	test   al,al
  411dd0:	je     411fbe <__swc_fn_7069e055_000167_bcc835b8+0x27e>
  411dd6:	mov    al,BYTE PTR [rbx+0x1]
  411dd9:	test   al,al
  411ddb:	jne    411de6 <__swc_fn_7069e055_000167_bcc835b8+0xa6>
  411ddd:	test   sil,sil
  411de0:	je     411fbe <__swc_fn_7069e055_000167_bcc835b8+0x27e>
  411de6:	test   r13b,r13b
  411de9:	jne    411ea7 <__swc_fn_7069e055_000167_bcc835b8+0x167>
  411def:	test   r12,r12
  411df2:	je     411ea7 <__swc_fn_7069e055_000167_bcc835b8+0x167>
  411df8:	mov    al,BYTE PTR [rbx+0x1]
  411dfb:	test   al,al
  411dfd:	je     411fbe <__swc_fn_7069e055_000167_bcc835b8+0x27e>
  411e03:	mov    eax,DWORD PTR [rbx+0x28]
  411e06:	cmp    DWORD PTR [r12+0x20],eax
  411e0b:	jne    411fbe <__swc_fn_7069e055_000167_bcc835b8+0x27e>
  411e11:	mov    rax,QWORD PTR [r12]
  411e15:	mov    rcx,QWORD PTR [r12+0x8]
  411e1a:	cmp    QWORD PTR [rbx+0x20],rcx
  411e1e:	jne    411fbe <__swc_fn_7069e055_000167_bcc835b8+0x27e>
  411e24:	mov    cl,0x1
  411e26:	test   rax,rax
  411e29:	je     411e92 <__swc_fn_7069e055_000167_bcc835b8+0x152>
  411e2f:	mov    rdx,QWORD PTR [rbx+0x20]
  411e33:	xor    r8d,r8d
  411e36:	test   rdx,rdx
  411e39:	jbe    411e92 <__swc_fn_7069e055_000167_bcc835b8+0x152>
  411e3b:	mov    r9,QWORD PTR [rbx+0x18]
  411e3f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  411e44:	cs nop WORD PTR [rax+rax*1+0x0]
  411e4e:	xchg   ax,ax
  411e50:	mov    r10b,BYTE PTR [rax+r8*1]
  411e54:	cmp    BYTE PTR [r9+r8*1],r10b
  411e58:	je     411e89 <__swc_fn_7069e055_000167_bcc835b8+0x149>
  411e5a:	vmovq  r10,xmm0
  411e5f:	cmp    BYTE PTR [r10+r8*1],0x5c
  411e64:	jne    411e6d <__swc_fn_7069e055_000167_bcc835b8+0x12d>
  411e66:	cmp    BYTE PTR [rax+r8*1],0x2f
  411e6b:	je     411e89 <__swc_fn_7069e055_000167_bcc835b8+0x149>
  411e6d:	vmovq  r10,xmm0
  411e72:	cmp    BYTE PTR [r10+r8*1],0x2f
  411e77:	jne    411e80 <__swc_fn_7069e055_000167_bcc835b8+0x140>
  411e79:	cmp    BYTE PTR [rax+r8*1],0x5c
  411e7e:	je     411e89 <__swc_fn_7069e055_000167_bcc835b8+0x149>
  411e80:	xor    eax,eax
  411e82:	movzx  eax,al
  411e85:	mov    cl,al
  411e87:	jmp    411e92 <__swc_fn_7069e055_000167_bcc835b8+0x152>
  411e89:	add    r8,0x1
  411e8d:	cmp    r8,rdx
  411e90:	jb     411e50 <__swc_fn_7069e055_000167_bcc835b8+0x110>
  411e92:	test   cl,cl
  411e94:	je     411fbe <__swc_fn_7069e055_000167_bcc835b8+0x27e>
  411e9a:	mov    eax,0x1
  411e9f:	mov    r13b,al
  411ea2:	jmp    411fbe <__swc_fn_7069e055_000167_bcc835b8+0x27e>
  411ea7:	mov    r13b,0x1
  411eaa:	sub    rsp,0x20
  411eae:	mov    rax,rsp
  411eb1:	lea    rcx,[rdi+0x8]
  411eb5:	mov    QWORD PTR [rax],rcx
  411eb8:	lea    rsi,[rip+0x1271]        # 413130 <__swc_rdata_base_7069e055+0x20>
  411ebf:	mov    QWORD PTR [rax+0x8],rsi
  411ec3:	mov    QWORD PTR [rax+0x10],rsp
  411ec7:	mov    QWORD PTR [rax+0x18],0x1
  411ecf:	lea    rcx,[rsp+0x10]
  411ed4:	sub    rsp,0x8
  411ed8:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  411edd:	add    rsp,0x8
  411ee1:	add    rsp,0x20
  411ee5:	mov    al,BYTE PTR [rbx+0x1]
  411ee8:	test   al,al
  411eea:	je     411f87 <__swc_fn_7069e055_000167_bcc835b8+0x247>
  411ef0:	lea    rax,[rip+0x1a91]        # 413988 <__swc_rdata_base_7069e055+0x878>
  411ef7:	sub    rsp,0x20
  411efb:	mov    rcx,rsp
  411efe:	mov    QWORD PTR [rcx],rax
  411f01:	mov    QWORD PTR [rcx+0x8],rsi
  411f05:	mov    QWORD PTR [rcx+0x10],rsp
  411f09:	mov    QWORD PTR [rcx+0x18],0x1
  411f11:	lea    rcx,[rsp+0x10]
  411f16:	sub    rsp,0x8
  411f1a:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  411f1f:	add    rsp,0x8
  411f23:	add    rsp,0x20
  411f27:	mov    eax,DWORD PTR [rbx+0x28]
  411f2a:	sub    rsp,0x60
  411f2e:	mov    rcx,rsp
  411f31:	lea    rdx,[rdi+0x18]
  411f35:	mov    QWORD PTR [rcx+0x18],rdx
  411f39:	mov    QWORD PTR [rcx+0x20],rsi
  411f3d:	vmovups XMMWORD PTR [rcx],xmm6
  411f41:	mov    QWORD PTR [rcx+0x28],rsp
  411f45:	mov    QWORD PTR [rcx+0x30],rsi
  411f49:	mov    DWORD PTR [rcx+0x10],eax
  411f4c:	lea    rax,[rsp+0x10]
  411f51:	mov    QWORD PTR [rcx+0x38],rax
  411f55:	lea    rax,[rip+0x1544]        # 4134a0 <__swc_rdata_base_7069e055+0x390>
  411f5c:	mov    QWORD PTR [rcx+0x40],rax
  411f60:	lea    rax,[rsp+0x18]
  411f65:	mov    QWORD PTR [rcx+0x48],rax
  411f69:	mov    QWORD PTR [rcx+0x50],0x3
  411f71:	lea    rcx,[rsp+0x48]
  411f76:	sub    rsp,0x8
  411f7a:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  411f7f:	add    rsp,0x8
  411f83:	add    rsp,0x60
  411f87:	lea    rax,[rip+0x1192]        # 413120 <__swc_rdata_base_7069e055+0x10>
  411f8e:	sub    rsp,0x20
  411f92:	mov    rcx,rsp
  411f95:	mov    QWORD PTR [rcx],rax
  411f98:	mov    QWORD PTR [rcx+0x8],rsi
  411f9c:	mov    QWORD PTR [rcx+0x10],rsp
  411fa0:	mov    QWORD PTR [rcx+0x18],0x1
  411fa8:	lea    rcx,[rsp+0x10]
  411fad:	sub    rsp,0x8
  411fb1:	call   40a600 <__swc_fn_7069e055_000150_6203dca2>
  411fb6:	add    rsp,0x8
  411fba:	add    rsp,0x20
  411fbe:	add    r15,0x1
  411fc2:	cmp    r15,r14
  411fc5:	jae    411fde <__swc_fn_7069e055_000167_bcc835b8+0x29e>
  411fc7:	mov    rsi,QWORD PTR [rsp+0x30]
  411fcc:	mov    rdi,QWORD PTR [rsp+0x38]
  411fd1:	mov    rax,r14
  411fd4:	mov    r14,QWORD PTR [rsp+0x48]
  411fd9:	jmp    411da0 <__swc_fn_7069e055_000167_bcc835b8+0x60>
  411fde:	add    rsp,0x50
  411fe2:	vmovups xmm6,XMMWORD PTR [rsp]
  411fe7:	add    rsp,0x10
  411feb:	pop    r15
  411fed:	pop    r14
  411fef:	pop    r13
  411ff1:	pop    r12
  411ff3:	pop    rdi
  411ff4:	pop    rsi
  411ff5:	pop    rbx
  411ff6:	pop    rbp
  411ff7:	ret
	...

0000000000412000 <__swc_fn_7069e055_000170_646fdf20>:
  412000:	sub    rsp,0x8
  412004:	call   40a010 <__swc_fn_7069e055_000129_4bbe3f14>
  412009:	add    rsp,0x8
  41200d:	ret
	...

0000000000412010 <__swc_fn_7069e055_000173_1e0ea8cf>:
  412010:	push   rsi
  412011:	sub    rsp,0x30
  412015:	lea    rsi,[rip+0x14d7c]        # 426d98 <__swc_bss_base_7069e055+0x2d58>
  41201c:	mov    rax,QWORD PTR [rsi]
  41201f:	test   rax,rax
  412022:	je     41202a <__swc_fn_7069e055_000173_1e0ea8cf+0x1a>
  412024:	add    rsp,0x30
  412028:	pop    rsi
  412029:	ret
  41202a:	mov    ecx,0x2
  41202f:	mov    edx,0x8020
  412034:	call   4096b0 <__swc_fn_7069e055_000111_6814119b>
  412039:	test   rax,rax
  41203c:	jne    41204d <__swc_fn_7069e055_000173_1e0ea8cf+0x3d>
  41203e:	mov    QWORD PTR [rsp+0x18],rax
  412043:	call   4114b0 <__swc_fn_7069e055_000122_be2e2f68>
  412048:	mov    rax,QWORD PTR [rsp+0x18]
  41204d:	mov    rcx,rax
  412050:	xchg   QWORD PTR [rsi],rcx
  412053:	add    rsp,0x30
  412057:	pop    rsi
  412058:	ret
  412059:	add    BYTE PTR [rax],al
  41205b:	add    BYTE PTR [rax],al
  41205d:	add    BYTE PTR [rax],al
	...

0000000000412060 <__swc_fn_7069e055_000176_4de704de>:
  412060:	push   rsi
  412061:	test   r8,r8
  412064:	jne    412068 <__swc_fn_7069e055_000176_4de704de+0x8>
  412066:	pop    rsi
  412067:	ret
  412068:	lea    rax,[rcx+0x18]
  41206c:	mov    r10,QWORD PTR [rax]
  41206f:	lea    r11,[r10+0x1]
  412073:	mov    QWORD PTR [rax],r11
  412076:	mov    r11,rdx
  412079:	not    rdx
  41207c:	lea    rsi,[r8-0x1]
  412080:	cmp    rsi,rdx
  412083:	ja     4120a3 <__swc_fn_7069e055_000176_4de704de+0x43>
  412085:	lea    rdx,[r11+r8*1]
  412089:	dec    rdx
  41208c:	shr    rdx,0x6
  412090:	mov    r8,r11
  412093:	shr    r8,0x6
  412097:	mov    rsi,rdx
  41209a:	sub    rsi,r8
  41209d:	cmp    rsi,0x8
  4120a1:	jb     4120b9 <__swc_fn_7069e055_000176_4de704de+0x59>
  4120a3:	lea    rcx,[rcx+0x10]
  4120a7:	mov    rdx,QWORD PTR [rcx]
  4120aa:	add    rdx,r9
  4120ad:	mov    QWORD PTR [rcx],rdx
  4120b0:	lea    rcx,[r10+0x2]
  4120b4:	mov    QWORD PTR [rax],rcx
  4120b7:	pop    rsi
  4120b8:	ret
  4120b9:	shr    r11,0x6
  4120bd:	nop    DWORD PTR [rax]
  4120c0:	cmp    r11,rdx
  4120c3:	ja     412103 <__swc_fn_7069e055_000176_4de704de+0xa3>
  4120c5:	jmp    4120d6 <__swc_fn_7069e055_000176_4de704de+0x76>
  4120c7:	nop    WORD PTR [rax+rax*1+0x0]
  4120d0:	add    r11,0x1
  4120d4:	jmp    4120c0 <__swc_fn_7069e055_000176_4de704de+0x60>
  4120d6:	mov    r8,r11
  4120d9:	shr    r8,0xc
  4120dd:	mov    rsi,r11
  4120e0:	xor    rsi,r8
  4120e3:	mov    r8,r11
  4120e6:	shr    r8,0x18
  4120ea:	xor    rsi,r8
  4120ed:	and    esi,0xfff
  4120f3:	lea    r8,[rcx+rsi*8+0x20]
  4120f8:	mov    rsi,QWORD PTR [r8]
  4120fb:	add    rsi,r9
  4120fe:	mov    QWORD PTR [r8],rsi
  412101:	jmp    4120d0 <__swc_fn_7069e055_000176_4de704de+0x70>
  412103:	lea    rcx,[r10+0x2]
  412107:	mov    QWORD PTR [rax],rcx
  41210a:	pop    rsi
  41210b:	ret
