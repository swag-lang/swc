from pathlib import Path
import json,hashlib
vocab=[]
for i in range(5000):
 nn=i+1;word=[]
 for k in range(3+i%6):word.append(97+nn%26);nn=nn//26+7*k
 vocab.append(bytes(word))
seed=12345;counts={};slots=[None]*16384
for _ in range(2000000):
 seed=seed*16807%2147483647;w=vocab[seed%5000]
 if w in counts:counts[w]+=1;continue
 counts[w]=1;h=2166136261
 for ch in w:h=((h^ch)*16777619)&0xffffffff
 slot=h&16383
 while slots[slot] is not None:slot=(slot+1)&16383
 slots[slot]=w
keys=[w for w in slots if w is not None];freq=[counts[w] for w in keys];indices=list(range(len(keys)));c={k:0 for k in ['left_adv_mismatch','right_adv_mismatch','left_adv_tie','right_adv_tie','left_comparisons','right_comparisons','partitions','swaps']}
def less(a,b,side):
 c[side+'_comparisons']+=1
 if freq[a]!=freq[b]:
  yes=freq[a]>freq[b]
  if yes:c[side+'_adv_mismatch']+=1
  return yes
 yes=keys[a]<keys[b]
 if yes:c[side+'_adv_tie']+=1
 return yes
def qsort(low,high):
 while low<high:
  c['partitions']+=1;p=indices[(low+high)//2];i=low;j=high
  while i<=j:
   while less(indices[i],p,'left'):i+=1
   while less(p,indices[j],'right'):j-=1
   if i<=j:indices[i],indices[j]=indices[j],indices[i];i+=1;j-=1;c['swaps']+=1
  qsort(low,j);low=i
qsort(0,len(keys)-1)
checksum=len(keys)*7+sum((k+1)*freq[indices[k]] for k in range(20));assert checksum==130489
c.update(distinct=len(keys),checksum=checksum,saved_instructions=3*c['left_adv_mismatch']+2*c['right_adv_mismatch'],saved_memory_reads=3*c['left_adv_mismatch']+2*c['right_adv_mismatch'],note='External diagnostic of unchanged deterministic words, FNV table insertion and quicksort; not benchmark timing.',source_sha256={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['bench/src/swagnat/wordfreq.swg','bench/src/swagnat/bytemap.swg','bench/src/swagnat/common.swg']})
Path('/workspace/prompt2-20261115/wordfreq-trip-counts.json').write_text(json.dumps(c,indent=2)+'\n');print(json.dumps(c,indent=2))
