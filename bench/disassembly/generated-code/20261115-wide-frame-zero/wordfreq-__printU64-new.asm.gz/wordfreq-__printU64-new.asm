
/workspace/prompt2-20261115/batch5-final-micro/new/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

000000000040a130 <__swc_fn_4fa09e82_000150_43c96957>:
  40a130:	push   rbx
  40a131:	sub    rsp,0xe0
  40a138:	lea    rbx,[rsp+0x8]
  40a13d:	vxorps xmm0,xmm0,xmm0
  40a141:	vmovups YMMWORD PTR [rbx],ymm0
  40a145:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40a14a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40a14f:	vzeroupper
  40a152:	mov    DWORD PTR [rbx+0x60],0x0
  40a159:	mov    r8,rbx
  40a15c:	nop    DWORD PTR [rax+0x0]
  40a160:	mov    r9,rcx
  40a163:	movabs rcx,0xcccccccccccccccd
  40a16d:	mov    rax,r9
  40a170:	mul    rcx
  40a173:	mov    r10,rdx
  40a176:	shr    r10,0x3
  40a17a:	mov    rcx,r10
  40a17d:	imul   rdx,r10,0xa
  40a181:	sub    r9,rdx
  40a184:	mov    rdx,QWORD PTR [rip+0x9485]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  40a18b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  40a190:	mov    BYTE PTR [r8],dl
  40a193:	lea    rdx,[r8+0x1]
  40a197:	mov    r8,rdx
  40a19a:	test   r10,r10
  40a19d:	jne    40a160 <__swc_fn_4fa09e82_000150_43c96957+0x30>
  40a19f:	mov    BYTE PTR [rdx],0x0
  40a1a2:	sub    r8,0x1
  40a1a6:	mov    rax,rbx
  40a1a9:	cmp    rax,r8
  40a1ac:	jae    40a1c6 <__swc_fn_4fa09e82_000150_43c96957+0x96>
  40a1ae:	xchg   ax,ax
  40a1b0:	mov    cl,BYTE PTR [r8]
  40a1b3:	mov    dl,BYTE PTR [rax]
  40a1b5:	mov    BYTE PTR [r8],dl
  40a1b8:	sub    r8,0x1
  40a1bc:	mov    BYTE PTR [rax],cl
  40a1be:	inc    rax
  40a1c1:	cmp    rax,r8
  40a1c4:	jb     40a1b0 <__swc_fn_4fa09e82_000150_43c96957+0x80>
  40a1c6:	xor    eax,eax
  40a1c8:	test   rbx,rbx
  40a1cb:	je     40a1ee <__swc_fn_4fa09e82_000150_43c96957+0xbe>
  40a1cd:	mov    rcx,rbx
  40a1d0:	mov    dl,BYTE PTR [rcx]
  40a1d2:	test   dl,dl
  40a1d4:	je     40a1ee <__swc_fn_4fa09e82_000150_43c96957+0xbe>
  40a1d6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a1e0:	add    rcx,0x1
  40a1e4:	add    rax,0x1
  40a1e8:	mov    dl,BYTE PTR [rcx]
  40a1ea:	test   dl,dl
  40a1ec:	jne    40a1e0 <__swc_fn_4fa09e82_000150_43c96957+0xb0>
  40a1ee:	mov    QWORD PTR [rbx+0xa8],rbx
  40a1f5:	mov    QWORD PTR [rbx+0xb0],rax
  40a1fc:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40a204:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40a20c:	lea    rcx,[rbx+0xb8]
  40a213:	call   4103d0 <__swc_fn_4fa09e82_000122_2648f149>
  40a218:	add    rsp,0xe0
  40a21f:	pop    rbx
  40a220:	ret
