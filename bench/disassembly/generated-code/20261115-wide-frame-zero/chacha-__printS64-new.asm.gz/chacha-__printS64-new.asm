
/workspace/prompt2-20261115/batch5-final-micro/new/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

000000000040d6c0 <__swc_fn_3464c816_000148_2eb804cc>:
  40d6c0:	push   rbx
  40d6c1:	sub    rsp,0xe0
  40d6c8:	lea    rbx,[rsp+0x8]
  40d6cd:	vxorps xmm0,xmm0,xmm0
  40d6d1:	vmovups YMMWORD PTR [rbx],ymm0
  40d6d5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40d6da:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40d6df:	vzeroupper
  40d6e2:	mov    DWORD PTR [rbx+0x60],0x0
  40d6e9:	mov    r8,rbx
  40d6ec:	mov    rdx,rcx
  40d6ef:	nop
  40d6f0:	mov    r9,rdx
  40d6f3:	movabs rdx,0x6666666666666667
  40d6fd:	mov    rax,r9
  40d700:	imul   rdx
  40d703:	sar    rdx,0x2
  40d707:	mov    r10,rdx
  40d70a:	shr    rdx,0x3f
  40d70e:	add    r10,rdx
  40d711:	mov    rdx,r10
  40d714:	imul   r11,r10,0xa
  40d718:	sub    r9,r11
  40d71b:	mov    r11,QWORD PTR [rip+0x5f1e]        # 413640 <__swc_rdata_base_3464c816+0x530>
  40d722:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40d727:	mov    BYTE PTR [r8],r9b
  40d72a:	lea    r9,[r8+0x1]
  40d72e:	mov    r8,r9
  40d731:	test   r10,r10
  40d734:	jne    40d6f0 <__swc_fn_3464c816_000148_2eb804cc+0x30>
  40d736:	test   rcx,rcx
  40d739:	jge    40d743 <__swc_fn_3464c816_000148_2eb804cc+0x83>
  40d73b:	mov    BYTE PTR [r9],0x2d
  40d73f:	add    r8,0x1
  40d743:	mov    BYTE PTR [r8],0x0
  40d747:	sub    r8,0x1
  40d74b:	mov    rax,rbx
  40d74e:	cmp    rax,r8
  40d751:	jae    40d776 <__swc_fn_3464c816_000148_2eb804cc+0xb6>
  40d753:	cs nop WORD PTR [rax+rax*1+0x0]
  40d75d:	nop    DWORD PTR [rax]
  40d760:	mov    cl,BYTE PTR [r8]
  40d763:	mov    dl,BYTE PTR [rax]
  40d765:	mov    BYTE PTR [r8],dl
  40d768:	sub    r8,0x1
  40d76c:	mov    BYTE PTR [rax],cl
  40d76e:	inc    rax
  40d771:	cmp    rax,r8
  40d774:	jb     40d760 <__swc_fn_3464c816_000148_2eb804cc+0xa0>
  40d776:	xor    eax,eax
  40d778:	test   rbx,rbx
  40d77b:	je     40d79e <__swc_fn_3464c816_000148_2eb804cc+0xde>
  40d77d:	mov    rcx,rbx
  40d780:	mov    dl,BYTE PTR [rcx]
  40d782:	test   dl,dl
  40d784:	je     40d79e <__swc_fn_3464c816_000148_2eb804cc+0xde>
  40d786:	cs nop WORD PTR [rax+rax*1+0x0]
  40d790:	add    rcx,0x1
  40d794:	add    rax,0x1
  40d798:	mov    dl,BYTE PTR [rcx]
  40d79a:	test   dl,dl
  40d79c:	jne    40d790 <__swc_fn_3464c816_000148_2eb804cc+0xd0>
  40d79e:	mov    QWORD PTR [rbx+0xa8],rbx
  40d7a5:	mov    QWORD PTR [rbx+0xb0],rax
  40d7ac:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d7b4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d7bc:	lea    rcx,[rbx+0xb8]
  40d7c3:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  40d7c8:	add    rsp,0xe0
  40d7cf:	pop    rbx
  40d7d0:	ret
