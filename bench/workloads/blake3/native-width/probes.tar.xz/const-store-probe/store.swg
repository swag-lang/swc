#global private
alias U32x8 = #simd [8] u32

#[Swag.NoInline]
func generate(output: [*] u32)
{
    const Words = cast(U32x8, [0x61707865'u32, 0x3320646E, 0x79622D32, 0x6B206574,
                              0x61707865, 0x3320646E, 0x79622D32, 0x6B206574])
    cast(*U32x8, output)[] = Words
}

#main
{
    var output: [8] u32
    const Expected = [0x61707865'u32, 0x3320646E, 0x79622D32, 0x6B206574]
    generate(output.buffer)
    for index in 8 do
        Swag.require(output[index] == Expected[index & 3])
}
