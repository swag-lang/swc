
/workspace/prompt2-20261115/batch3-final-micro/new/nbody/nbody:     file format elf64-x86-64


Disassembly of section .text:

000000000040a580 <__swc_fn_6b1cf01f_000001_0ce64436>:
  40a580:	push   rbp
  40a581:	push   rbx
  40a582:	push   rsi
  40a583:	sub    rsp,0xa8
  40a58a:	mov    rbp,rsp
  40a58d:	vmovups XMMWORD PTR [rsp],xmm6
  40a592:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  40a598:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  40a59e:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  40a5a4:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  40a5aa:	vmovups XMMWORD PTR [rsp+0x50],xmm11
  40a5b0:	vmovups XMMWORD PTR [rsp+0x60],xmm12
  40a5b6:	vmovups XMMWORD PTR [rsp+0x70],xmm13
  40a5bc:	vmovups XMMWORD PTR [rsp+0x80],xmm14
  40a5c5:	vmovups XMMWORD PTR [rsp+0x90],xmm15
  40a5ce:	sub    rsp,0x510
  40a5d5:	mov    rbx,rsp
  40a5d8:	lea    rax,[rip+0x8b41]        # 413120 <__swc_rdata_base_6b1cf01f+0x10>
  40a5df:	xor    ecx,ecx
  40a5e1:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5eb:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5f5:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5ff:	nop
  40a600:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  40a605:	vmovdqu XMMWORD PTR [rbx+rcx*1],xmm0
  40a60a:	add    rcx,0x10
  40a60e:	cmp    rcx,0x110
  40a615:	jne    40a600 <__swc_fn_6b1cf01f_000001_0ce64436+0x80>
  40a617:	mov    DWORD PTR [rbx+0x110],0x531799ac
  40a621:	mov    DWORD PTR [rbx+0x114],0x3f60a8f3
  40a62b:	sub    rsp,0x8
  40a62f:	call   407270 <__swc_fn_6b1cf01f_000000_1ca87929>
  40a634:	add    rsp,0x8
  40a638:	vmovsd QWORD PTR [rsp+0x2d0],xmm0
  40a641:	vxorpd xmm0,xmm0,xmm0
  40a645:	vmovups xmm2,xmm0
  40a649:	mov    rax,rbx
  40a64c:	vmovsd xmm3,QWORD PTR [rbx+0x18]
  40a651:	vmovsd xmm4,QWORD PTR [rbx+0x30]
  40a656:	vmulsd xmm3,xmm3,xmm4
  40a65a:	vaddsd xmm1,xmm0,xmm3
  40a65e:	vmovsd xmm3,QWORD PTR [rbx+0x20]
  40a663:	vfmadd231sd xmm2,xmm3,xmm4
  40a668:	vmovsd xmm3,QWORD PTR [rbx+0x28]
  40a66d:	vfmadd231sd xmm0,xmm3,xmm4
  40a672:	add    rax,0x38
  40a676:	vmovsd xmm3,QWORD PTR [rax+0x18]
  40a67b:	vmovsd xmm4,QWORD PTR [rax+0x30]
  40a680:	vfmadd231sd xmm1,xmm3,xmm4
  40a685:	vmovsd xmm3,QWORD PTR [rax+0x20]
  40a68a:	vfmadd231sd xmm2,xmm3,xmm4
  40a68f:	vmovsd xmm3,QWORD PTR [rax+0x28]
  40a694:	vfmadd231sd xmm0,xmm3,xmm4
  40a699:	vmovsd xmm3,QWORD PTR [rax+0x50]
  40a69e:	vmovsd xmm4,QWORD PTR [rax+0x68]
  40a6a3:	vfmadd231sd xmm1,xmm3,xmm4
  40a6a8:	vmovsd xmm3,QWORD PTR [rax+0x58]
  40a6ad:	vfmadd231sd xmm2,xmm3,xmm4
  40a6b2:	vmovsd xmm3,QWORD PTR [rax+0x60]
  40a6b7:	vfmadd231sd xmm0,xmm3,xmm4
  40a6bc:	vmovsd xmm3,QWORD PTR [rax+0x88]
  40a6c4:	vmovsd xmm4,QWORD PTR [rax+0xa0]
  40a6cc:	vfmadd231sd xmm1,xmm3,xmm4
  40a6d1:	vmovsd xmm3,QWORD PTR [rax+0x90]
  40a6d9:	vfmadd231sd xmm2,xmm3,xmm4
  40a6de:	vmovsd xmm3,QWORD PTR [rax+0x98]
  40a6e6:	vfmadd231sd xmm0,xmm3,xmm4
  40a6eb:	vmovsd xmm3,QWORD PTR [rax+0xc0]
  40a6f3:	vmovsd xmm4,QWORD PTR [rax+0xd8]
  40a6fb:	vfmadd231sd xmm1,xmm3,xmm4
  40a700:	vmovsd xmm3,QWORD PTR [rax+0xc8]
  40a708:	vfmadd231sd xmm2,xmm3,xmm4
  40a70d:	vmovsd xmm3,QWORD PTR [rax+0xd0]
  40a715:	vfmadd231sd xmm0,xmm3,xmm4
  40a71a:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x8b1e]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40a722:	vmovsd xmm3,QWORD PTR [rip+0x8c2e]        # 413358 <__swc_rdata_base_6b1cf01f+0x248>
  40a72a:	vdivsd xmm1,xmm1,xmm3
  40a72e:	vmovsd QWORD PTR [rbx+0x18],xmm1
  40a733:	vxorpd xmm2,xmm2,XMMWORD PTR [rip+0x8b05]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40a73b:	vdivsd xmm1,xmm2,xmm3
  40a73f:	vmovsd QWORD PTR [rbx+0x20],xmm1
  40a744:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x8af4]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40a74c:	vdivsd xmm0,xmm0,xmm3
  40a750:	vmovsd QWORD PTR [rbx+0x28],xmm0
  40a755:	xor    eax,eax
  40a757:	vmovsd xmm0,QWORD PTR [rip+0x8c02]        # 413361 <__swc_rdata_base_6b1cf01f+0x251>
  40a75f:	vpshufd xmm1,xmm0,0x44
  40a764:	vmovups XMMWORD PTR [rsp+0x2e0],xmm1
  40a76d:	vpunpcklqdq xmm2,xmm0,xmm0
  40a771:	vmovups XMMWORD PTR [rsp+0x2f0],xmm2
  40a77a:	vmovdqu xmm3,XMMWORD PTR [rsp]
  40a77f:	vmovdqu xmm4,XMMWORD PTR [rsp+0x18]
  40a785:	vmovdqu xmm5,XMMWORD PTR [rsp+0x38]
  40a78b:	vmovups XMMWORD PTR [rsp+0x320],xmm5
  40a794:	vmovdqu xmm7,XMMWORD PTR [rsp+0x50]
  40a79a:	vmovdqu xmm8,XMMWORD PTR [rsp+0x70]
  40a7a0:	vmovups XMMWORD PTR [rsp+0x340],xmm8
  40a7a9:	vmovdqu xmm9,XMMWORD PTR [rsp+0x88]
  40a7b2:	vmovdqu xmm10,XMMWORD PTR [rsp+0xa8]
  40a7bb:	vmovups XMMWORD PTR [rsp+0x350],xmm10
  40a7c4:	vmovdqu xmm11,XMMWORD PTR [rsp+0xc0]
  40a7cd:	vmovdqu xmm12,XMMWORD PTR [rsp+0xe0]
  40a7d6:	vmovups XMMWORD PTR [rsp+0x360],xmm11
  40a7df:	vmovups XMMWORD PTR [rsp+0x370],xmm12
  40a7e8:	vmovdqu xmm13,XMMWORD PTR [rsp+0xf8]
  40a7f1:	mov    rcx,QWORD PTR [rsp+0x68]
  40a7f6:	mov    rdx,QWORD PTR [rsp+0x30]
  40a7fb:	mov    r8,QWORD PTR [rsp+0xa0]
  40a803:	mov    r9,QWORD PTR [rsp+0xd8]
  40a80b:	mov    r10,QWORD PTR [rsp+0x110]
  40a813:	jmp    40a864 <__swc_fn_6b1cf01f_000001_0ce64436+0x2e4>
  40a815:	cs nop WORD PTR [rax+rax*1+0x0]
  40a81f:	nop
  40a820:	vmovups xmm2,XMMWORD PTR [rsp+0x2f0]
  40a829:	vmovups xmm4,XMMWORD PTR [rsp+0x310]
  40a832:	vmovups xmm5,XMMWORD PTR [rsp+0x320]
  40a83b:	vmovups xmm10,xmm13
  40a840:	vmovups XMMWORD PTR [rsp+0x360],xmm7
  40a849:	vmovups xmm12,xmm11
  40a84e:	vmovups xmm13,xmm3
  40a852:	vmovups xmm3,XMMWORD PTR [rsp+0x300]
  40a85b:	vmovups xmm7,XMMWORD PTR [rsp+0x330]
  40a864:	vsubpd xmm14,xmm3,xmm5
  40a868:	vpsrldq xmm6,xmm14,0x8
  40a86e:	vmovsd xmm15,QWORD PTR [rbx+0x10]
  40a873:	vmovsd QWORD PTR [rsp+0x390],xmm15
  40a87c:	vmovsd xmm0,QWORD PTR [rbx+0x48]
  40a881:	vmovq  rsi,xmm0
  40a886:	vsubsd xmm5,xmm15,xmm0
  40a88a:	vmulsd xmm0,xmm14,xmm14
  40a88f:	vfmadd231sd xmm0,xmm6,xmm6
  40a894:	vfmadd231sd xmm0,xmm5,xmm5
  40a899:	vsubpd xmm6,xmm3,xmm8
  40a89e:	vmulsd xmm8,xmm6,xmm6
  40a8a2:	vmovups XMMWORD PTR [rsp+0x380],xmm13
  40a8ab:	vpsrldq xmm13,xmm6,0x8
  40a8b0:	vfmadd231sd xmm8,xmm13,xmm13
  40a8b5:	vmovsd xmm13,QWORD PTR [rbx+0x80]
  40a8bd:	vmovsd QWORD PTR [rsp+0x3a0],xmm13
  40a8c6:	vsubsd xmm1,xmm15,xmm13
  40a8cb:	vfmadd231sd xmm8,xmm1,xmm1
  40a8d0:	vpunpcklqdq xmm0,xmm0,xmm8
  40a8d5:	vsqrtpd xmm8,xmm0
  40a8d9:	vmulpd xmm0,xmm0,xmm8
  40a8de:	vdivpd xmm0,xmm2,xmm0
  40a8e2:	vpshufd xmm8,xmm0,0x44
  40a8e7:	vmovq  xmm13,rcx
  40a8ec:	vpshufd xmm13,xmm13,0x44
  40a8f2:	vmulpd xmm11,xmm14,xmm13
  40a8f7:	vmovups XMMWORD PTR [rsp+0x3b0],xmm13
  40a900:	vmovq  xmm13,rcx
  40a905:	vmovsd QWORD PTR [rsp+0x3c0],xmm13
  40a90e:	vfnmadd231pd xmm4,xmm11,xmm8
  40a913:	vmulsd xmm11,xmm5,xmm13
  40a918:	vfnmadd213sd xmm11,xmm0,QWORD PTR [rbx+0x28]
  40a91e:	vmovq  xmm13,rdx
  40a923:	vpshufd xmm13,xmm13,0x44
  40a929:	vmulpd xmm14,xmm14,xmm13
  40a92e:	vmulpd xmm8,xmm14,xmm8
  40a933:	vmovq  xmm14,rdx
  40a938:	vaddpd xmm7,xmm7,xmm8
  40a93d:	vmovups XMMWORD PTR [rsp+0x3d0],xmm7
  40a946:	vmulsd xmm5,xmm5,xmm14
  40a94b:	vfmadd213sd xmm5,xmm0,QWORD PTR [rbx+0x60]
  40a951:	vmovsd QWORD PTR [rsp+0x3e0],xmm5
  40a95a:	vmulpd xmm8,xmm6,xmm13
  40a95f:	vpsrldq xmm0,xmm0,0x8
  40a964:	vpshufd xmm5,xmm0,0x44
  40a969:	vmulpd xmm8,xmm8,xmm5
  40a96d:	vmovq  xmm2,r8
  40a972:	vpshufd xmm2,xmm2,0x44
  40a977:	vmulpd xmm6,xmm6,xmm2
  40a97b:	vfnmadd231pd xmm4,xmm6,xmm5
  40a980:	vmovq  xmm5,r8
  40a985:	vmovq  r11,xmm5
  40a98a:	vmulsd xmm6,xmm1,xmm5
  40a98e:	vfnmadd213sd xmm6,xmm0,xmm11
  40a993:	vaddpd xmm8,xmm9,xmm8
  40a998:	vmovups XMMWORD PTR [rsp+0x410],xmm8
  40a9a1:	vmulsd xmm1,xmm1,xmm14
  40a9a6:	vmulsd xmm0,xmm1,xmm0
  40a9aa:	vaddsd xmm0,xmm0,QWORD PTR [rbx+0x98]
  40a9b2:	vmovsd QWORD PTR [rsp+0x420],xmm0
  40a9bb:	vsubpd xmm1,xmm3,xmm10
  40a9c0:	vmulpd xmm9,xmm1,xmm13
  40a9c5:	vpsrldq xmm0,xmm1,0x8
  40a9ca:	vmovsd xmm11,QWORD PTR [rbx+0xb8]
  40a9d2:	vmovsd QWORD PTR [rsp+0x428],xmm11
  40a9db:	vsubsd xmm5,xmm15,xmm11
  40a9e0:	vmulsd xmm8,xmm1,xmm1
  40a9e4:	vfmadd213sd xmm0,xmm0,xmm8
  40a9e9:	vfmadd231sd xmm0,xmm5,xmm5
  40a9ee:	vsubpd xmm8,xmm3,xmm12
  40a9f3:	vmulsd xmm12,xmm8,xmm8
  40a9f8:	vpsrldq xmm7,xmm8,0x8
  40a9fe:	vmulsd xmm7,xmm7,xmm7
  40aa02:	vaddsd xmm7,xmm12,xmm7
  40aa06:	vmovsd xmm12,QWORD PTR [rbx+0xf0]
  40aa0e:	vmovsd QWORD PTR [rsp+0x430],xmm12
  40aa17:	vsubsd xmm11,xmm15,xmm12
  40aa1c:	vfmadd231sd xmm7,xmm11,xmm11
  40aa21:	vpunpcklqdq xmm0,xmm0,xmm7
  40aa25:	vsqrtpd xmm7,xmm0
  40aa29:	vmulpd xmm0,xmm0,xmm7
  40aa2d:	vmovups xmm15,XMMWORD PTR [rsp+0x2f0]
  40aa36:	vdivpd xmm0,xmm15,xmm0
  40aa3a:	vpshufd xmm7,xmm0,0x44
  40aa3f:	vmulpd xmm9,xmm9,xmm7
  40aa43:	vmovq  xmm12,r9
  40aa48:	vpshufd xmm12,xmm12,0x44
  40aa4e:	vmulpd xmm1,xmm1,xmm12
  40aa53:	vfnmadd213pd xmm1,xmm7,xmm4
  40aa58:	vmovq  xmm7,r9
  40aa5d:	vmovsd QWORD PTR [rsp+0x450],xmm7
  40aa66:	vmulsd xmm4,xmm5,xmm7
  40aa6a:	vfnmadd231sd xmm6,xmm4,xmm0
  40aa6f:	vaddpd xmm9,xmm9,XMMWORD PTR [rsp+0x360]
  40aa78:	vmulsd xmm4,xmm5,xmm14
  40aa7d:	vmovsd xmm5,QWORD PTR [rbx+0xd0]
  40aa85:	vfmadd231sd xmm5,xmm4,xmm0
  40aa8a:	vmovsd QWORD PTR [rsp+0x458],xmm5
  40aa93:	vmulpd xmm4,xmm8,xmm13
  40aa98:	vpsrldq xmm0,xmm0,0x8
  40aa9d:	vpshufd xmm13,xmm0,0x44
  40aaa2:	vmulpd xmm4,xmm4,xmm13
  40aaa7:	vmovq  xmm5,r10
  40aaac:	vpshufd xmm5,xmm5,0x44
  40aab1:	vmovups XMMWORD PTR [rsp+0x460],xmm5
  40aaba:	vmulpd xmm8,xmm8,xmm5
  40aabe:	vmulpd xmm8,xmm8,xmm13
  40aac3:	vmovups xmm13,xmm4
  40aac7:	vsubpd xmm4,xmm1,xmm8
  40aacc:	vfmadd231pd xmm3,xmm4,XMMWORD PTR [rsp+0x2e0]
  40aad6:	vmovq  xmm8,r10
  40aadb:	vmovups XMMWORD PTR [rsp+0x300],xmm3
  40aae4:	vmovsd QWORD PTR [rsp+0x470],xmm8
  40aaed:	vaddpd xmm3,xmm13,XMMWORD PTR [rsp+0x380]
  40aaf6:	vmovups XMMWORD PTR [rsp+0x480],xmm3
  40aaff:	vmulsd xmm13,xmm11,xmm8
  40ab04:	vfnmadd231sd xmm6,xmm13,xmm0
  40ab09:	vmovsd QWORD PTR [rbx+0x28],xmm6
  40ab0e:	vmulsd xmm11,xmm11,xmm14
  40ab13:	vmulsd xmm0,xmm11,xmm0
  40ab17:	vaddsd xmm0,xmm0,QWORD PTR [rbx+0x108]
  40ab1f:	vmovups xmm13,XMMWORD PTR [rsp+0x320]
  40ab28:	vmovsd QWORD PTR [rsp+0x498],xmm0
  40ab31:	vsubpd xmm14,xmm13,XMMWORD PTR [rsp+0x340]
  40ab3a:	vmovups XMMWORD PTR [rsp+0x310],xmm4
  40ab43:	vmulpd xmm4,xmm14,xmm2
  40ab47:	vmovups xmm6,XMMWORD PTR [rsp+0x3b0]
  40ab50:	vmovups XMMWORD PTR [rsp+0x3f0],xmm2
  40ab59:	vmulpd xmm2,xmm14,xmm6
  40ab5d:	vpsrldq xmm8,xmm14,0x8
  40ab63:	vmovq  xmm0,rsi
  40ab68:	vsubsd xmm1,xmm0,QWORD PTR [rsp+0x3a0]
  40ab71:	vmulsd xmm3,xmm14,xmm14
  40ab76:	vfmadd231sd xmm3,xmm8,xmm8
  40ab7b:	vfmadd231sd xmm3,xmm1,xmm1
  40ab80:	vsubpd xmm8,xmm13,xmm10
  40ab85:	vmulsd xmm14,xmm8,xmm8
  40ab8a:	vpsrldq xmm10,xmm8,0x8
  40ab90:	vmulsd xmm10,xmm10,xmm10
  40ab95:	vaddsd xmm10,xmm14,xmm10
  40ab9a:	vsubsd xmm11,xmm0,QWORD PTR [rsp+0x428]
  40aba3:	vfmadd231sd xmm10,xmm11,xmm11
  40aba8:	vpunpcklqdq xmm3,xmm3,xmm10
  40abad:	vsqrtpd xmm10,xmm3
  40abb1:	vmulpd xmm3,xmm3,xmm10
  40abb6:	vdivpd xmm3,xmm15,xmm3
  40abba:	vpshufd xmm10,xmm3,0x44
  40abbf:	vfnmadd213pd xmm4,xmm10,XMMWORD PTR [rsp+0x3d0]
  40abc9:	vmulpd xmm2,xmm2,xmm10
  40abce:	vaddpd xmm2,xmm2,XMMWORD PTR [rsp+0x410]
  40abd7:	vmovq  xmm10,r11
  40abdc:	vmovups XMMWORD PTR [rsp+0x4a0],xmm2
  40abe5:	vmulsd xmm14,xmm1,xmm10
  40abea:	vmovsd xmm10,QWORD PTR [rsp+0x3e0]
  40abf3:	vfnmadd231sd xmm10,xmm14,xmm3
  40abf8:	vmovsd xmm14,QWORD PTR [rsp+0x3c0]
  40ac01:	vmulsd xmm1,xmm1,xmm14
  40ac06:	vfmadd213sd xmm1,xmm3,QWORD PTR [rsp+0x420]
  40ac10:	vmovsd QWORD PTR [rsp+0x4b0],xmm1
  40ac19:	vmulpd xmm2,xmm8,xmm12
  40ac1e:	vmulpd xmm8,xmm8,xmm6
  40ac22:	vpsrldq xmm3,xmm3,0x8
  40ac27:	vpshufd xmm1,xmm3,0x44
  40ac2c:	vfnmadd213pd xmm2,xmm1,xmm4
  40ac31:	vfmadd213pd xmm1,xmm8,xmm9
  40ac36:	vmulsd xmm4,xmm11,xmm7
  40ac3a:	vfnmadd213sd xmm4,xmm3,xmm10
  40ac3f:	vmulsd xmm8,xmm11,xmm14
  40ac44:	vmulsd xmm3,xmm8,xmm3
  40ac48:	vaddsd xmm3,xmm3,QWORD PTR [rsp+0x458]
  40ac51:	vmovsd QWORD PTR [rsp+0x4b8],xmm3
  40ac5a:	vsubpd xmm9,xmm13,XMMWORD PTR [rsp+0x370]
  40ac63:	vmulpd xmm10,xmm9,xmm5
  40ac67:	vmulpd xmm6,xmm9,xmm6
  40ac6b:	vpsrldq xmm7,xmm9,0x8
  40ac71:	vsubsd xmm5,xmm0,QWORD PTR [rsp+0x430]
  40ac7a:	vmulsd xmm0,xmm9,xmm9
  40ac7f:	vfmadd231sd xmm0,xmm7,xmm7
  40ac84:	vfmadd231sd xmm0,xmm5,xmm5
  40ac89:	vmovups xmm9,XMMWORD PTR [rsp+0x340]
  40ac92:	vsubpd xmm11,xmm9,XMMWORD PTR [rsp+0x350]
  40ac9b:	vmulsd xmm7,xmm11,xmm11
  40aca0:	vpsrldq xmm8,xmm11,0x8
  40aca6:	vfmadd231sd xmm7,xmm8,xmm8
  40acab:	vmovsd xmm8,QWORD PTR [rsp+0x3a0]
  40acb4:	vsubsd xmm3,xmm8,QWORD PTR [rsp+0x428]
  40acbd:	vfmadd231sd xmm7,xmm3,xmm3
  40acc2:	vpunpcklqdq xmm0,xmm0,xmm7
  40acc6:	vsqrtpd xmm7,xmm0
  40acca:	vmulpd xmm0,xmm0,xmm7
  40acce:	vdivpd xmm0,xmm15,xmm0
  40acd2:	vpshufd xmm9,xmm0,0x44
  40acd7:	vmulpd xmm7,xmm10,xmm9
  40acdc:	vmovsd xmm15,QWORD PTR [rsp+0x450]
  40ace5:	vsubpd xmm7,xmm2,xmm7
  40ace9:	vmovups xmm2,XMMWORD PTR [rsp+0x2e0]
  40acf2:	vfmadd231pd xmm13,xmm7,xmm2
  40acf7:	vmovups XMMWORD PTR [rsp+0x320],xmm13
  40ad00:	vmulpd xmm6,xmm6,xmm9
  40ad05:	vaddpd xmm6,xmm6,XMMWORD PTR [rsp+0x480]
  40ad0e:	vmovsd xmm10,QWORD PTR [rsp+0x470]
  40ad17:	vmulsd xmm9,xmm5,xmm10
  40ad1c:	vfnmadd231sd xmm4,xmm9,xmm0
  40ad21:	vmovsd QWORD PTR [rbx+0x60],xmm4
  40ad26:	vmulsd xmm5,xmm5,xmm14
  40ad2b:	vfmadd213sd xmm5,xmm0,QWORD PTR [rsp+0x498]
  40ad35:	vmulpd xmm9,xmm11,xmm12
  40ad3a:	vmovups xmm14,XMMWORD PTR [rsp+0x3f0]
  40ad43:	vmulpd xmm11,xmm11,xmm14
  40ad48:	vpsrldq xmm0,xmm0,0x8
  40ad4d:	vpshufd xmm13,xmm0,0x44
  40ad52:	vmovups XMMWORD PTR [rsp+0x330],xmm7
  40ad5b:	vmovups xmm7,XMMWORD PTR [rsp+0x4a0]
  40ad64:	vfnmadd231pd xmm7,xmm9,xmm13
  40ad69:	vfmadd231pd xmm1,xmm11,xmm13
  40ad6e:	vmovups XMMWORD PTR [rsp+0x4d0],xmm1
  40ad77:	vmulsd xmm9,xmm3,xmm15
  40ad7c:	vmovsd xmm11,QWORD PTR [rsp+0x4b0]
  40ad85:	vfnmadd231sd xmm11,xmm9,xmm0
  40ad8a:	vmovq  xmm13,r11
  40ad8f:	vmulsd xmm3,xmm3,xmm13
  40ad94:	vmulsd xmm0,xmm3,xmm0
  40ad98:	vaddsd xmm0,xmm0,QWORD PTR [rsp+0x4b8]
  40ada1:	vmovups xmm9,XMMWORD PTR [rsp+0x340]
  40adaa:	vmovups xmm3,XMMWORD PTR [rsp+0x370]
  40adb3:	vmovsd QWORD PTR [rsp+0x4e0],xmm0
  40adbc:	vsubpd xmm4,xmm9,xmm3
  40adc0:	vmulpd xmm15,xmm4,XMMWORD PTR [rsp+0x460]
  40adc9:	vmulpd xmm14,xmm4,xmm14
  40adce:	vpsrldq xmm0,xmm4,0x8
  40add3:	vmovsd xmm9,QWORD PTR [rsp+0x430]
  40addc:	vsubsd xmm1,xmm8,xmm9
  40ade1:	vmulsd xmm4,xmm4,xmm4
  40ade5:	vfmadd213sd xmm0,xmm0,xmm4
  40adea:	vfmadd231sd xmm0,xmm1,xmm1
  40adef:	vmovups xmm4,XMMWORD PTR [rsp+0x350]
  40adf8:	vsubpd xmm8,xmm4,xmm3
  40adfc:	vmovups XMMWORD PTR [rsp+0x4f0],xmm8
  40ae05:	vmulsd xmm3,xmm8,xmm8
  40ae0a:	vpsrldq xmm4,xmm8,0x8
  40ae10:	vfmadd231sd xmm3,xmm4,xmm4
  40ae15:	vmovsd xmm4,QWORD PTR [rsp+0x428]
  40ae1e:	vmovups XMMWORD PTR [rsp+0x440],xmm12
  40ae27:	vsubsd xmm12,xmm4,xmm9
  40ae2c:	vmovsd QWORD PTR [rsp+0x500],xmm12
  40ae35:	vfmadd231sd xmm3,xmm12,xmm12
  40ae3a:	vpunpcklqdq xmm0,xmm0,xmm3
  40ae3e:	vsqrtpd xmm3,xmm0
  40ae42:	vmulpd xmm0,xmm0,xmm3
  40ae46:	vmovups xmm4,XMMWORD PTR [rsp+0x2f0]
  40ae4f:	vdivpd xmm0,xmm4,xmm0
  40ae53:	vpshufd xmm3,xmm0,0x44
  40ae58:	vmulpd xmm15,xmm15,xmm3
  40ae5c:	vmovups xmm8,XMMWORD PTR [rsp+0x340]
  40ae65:	vmovups xmm4,xmm9
  40ae6a:	vmovups xmm12,XMMWORD PTR [rsp+0x460]
  40ae73:	vsubpd xmm9,xmm7,xmm15
  40ae78:	vfmadd231pd xmm8,xmm9,xmm2
  40ae7d:	vmovups XMMWORD PTR [rsp+0x340],xmm8
  40ae86:	vfmadd213pd xmm3,xmm14,xmm6
  40ae8b:	vmulsd xmm6,xmm1,xmm10
  40ae90:	vfnmadd213sd xmm6,xmm0,xmm11
  40ae95:	vmovsd QWORD PTR [rbx+0x98],xmm6
  40ae9d:	vmulsd xmm1,xmm1,xmm13
  40aea2:	vfmadd213sd xmm1,xmm0,xmm5
  40aea7:	vmovups xmm5,XMMWORD PTR [rsp+0x4f0]
  40aeb0:	vmulpd xmm7,xmm5,xmm12
  40aeb5:	vmulpd xmm5,xmm5,XMMWORD PTR [rsp+0x440]
  40aebe:	vpsrldq xmm0,xmm0,0x8
  40aec3:	vpshufd xmm11,xmm0,0x44
  40aec8:	vfnmadd213pd xmm7,xmm11,XMMWORD PTR [rsp+0x4d0]
  40aed2:	vmovups xmm13,XMMWORD PTR [rsp+0x350]
  40aedb:	vfmadd231pd xmm13,xmm7,xmm2
  40aee0:	vmovups XMMWORD PTR [rsp+0x350],xmm13
  40aee9:	vmulpd xmm5,xmm5,xmm11
  40aeee:	vmovups xmm11,XMMWORD PTR [rsp+0x370]
  40aef7:	vmovsd xmm12,QWORD PTR [rsp+0x3a0]
  40af00:	vaddpd xmm3,xmm3,xmm5
  40af04:	vfmadd231pd xmm11,xmm3,xmm2
  40af09:	vmovsd xmm5,QWORD PTR [rsp+0x500]
  40af12:	vmovups XMMWORD PTR [rsp+0x370],xmm11
  40af1b:	vmulsd xmm10,xmm5,xmm10
  40af20:	vfnmadd213sd xmm10,xmm0,QWORD PTR [rsp+0x4e0]
  40af2a:	vmovsd QWORD PTR [rbx+0xd0],xmm10
  40af32:	vmulsd xmm5,xmm5,QWORD PTR [rsp+0x450]
  40af3b:	vfmadd213sd xmm0,xmm5,xmm1
  40af40:	vmovsd QWORD PTR [rbx+0x108],xmm0
  40af48:	vmovsd xmm5,QWORD PTR [rip+0x8411]        # 413361 <__swc_rdata_base_6b1cf01f+0x251>
  40af50:	vmovsd xmm1,QWORD PTR [rbx+0x28]
  40af55:	vfmadd213sd xmm1,xmm5,QWORD PTR [rsp+0x390]
  40af5f:	vmovsd QWORD PTR [rbx+0x10],xmm1
  40af64:	vmovsd xmm1,QWORD PTR [rbx+0x60]
  40af69:	vmovq  xmm14,rsi
  40af6e:	vfmadd213sd xmm1,xmm5,xmm14
  40af73:	vmovsd QWORD PTR [rbx+0x48],xmm1
  40af78:	vmulsd xmm1,xmm6,xmm5
  40af7c:	vaddsd xmm1,xmm12,xmm1
  40af80:	vmovsd QWORD PTR [rbx+0x80],xmm1
  40af88:	vmulsd xmm1,xmm10,xmm5
  40af8c:	vaddsd xmm1,xmm1,QWORD PTR [rsp+0x428]
  40af95:	vmovsd QWORD PTR [rbx+0xb8],xmm1
  40af9d:	vfmadd213sd xmm0,xmm5,xmm4
  40afa2:	vmovsd QWORD PTR [rbx+0xf0],xmm0
  40afaa:	add    rax,0x1
  40afae:	cmp    rax,0x7a120
  40afb5:	jl     40a820 <__swc_fn_6b1cf01f_000001_0ce64436+0x2a0>
  40afbb:	vmovdqu XMMWORD PTR [rsp+0xa8],xmm13
  40afc4:	vmovdqu XMMWORD PTR [rsp+0xc0],xmm7
  40afcd:	vmovdqu XMMWORD PTR [rsp+0xe0],xmm11
  40afd6:	vmovdqu XMMWORD PTR [rsp+0xf8],xmm3
  40afdf:	vmovups xmm3,XMMWORD PTR [rsp+0x300]
  40afe8:	vmovdqu XMMWORD PTR [rsp],xmm3
  40afed:	vmovups xmm4,XMMWORD PTR [rsp+0x310]
  40aff6:	vmovdqu XMMWORD PTR [rsp+0x18],xmm4
  40affc:	vmovups xmm13,XMMWORD PTR [rsp+0x320]
  40b005:	vmovdqu XMMWORD PTR [rsp+0x38],xmm13
  40b00b:	vmovups xmm7,XMMWORD PTR [rsp+0x330]
  40b014:	vmovdqu XMMWORD PTR [rsp+0x50],xmm7
  40b01a:	vmovdqu XMMWORD PTR [rsp+0x70],xmm8
  40b020:	vmovdqu XMMWORD PTR [rsp+0x88],xmm9
  40b029:	mov    QWORD PTR [rbx+0x258],0x5
  40b034:	vxorpd xmm0,xmm0,xmm0
  40b038:	vmovsd xmm1,QWORD PTR [rip+0x832a]        # 41336a <__swc_rdata_base_6b1cf01f+0x25a>
  40b040:	vmovsd xmm3,QWORD PTR [rbx+0x30]
  40b045:	vmulsd xmm2,xmm1,xmm3
  40b049:	vmovsd xmm4,QWORD PTR [rbx+0x18]
  40b04e:	vmulsd xmm4,xmm4,xmm4
  40b052:	vmovsd xmm5,QWORD PTR [rbx+0x20]
  40b057:	vfmadd231sd xmm4,xmm5,xmm5
  40b05c:	vmovsd xmm5,QWORD PTR [rbx+0x28]
  40b061:	vfmadd231sd xmm4,xmm5,xmm5
  40b066:	vfmadd231sd xmm0,xmm2,xmm4
  40b06b:	vmovsd xmm2,QWORD PTR [rbx]
  40b06f:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x38]
  40b074:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  40b079:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x40]
  40b07e:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  40b083:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x48]
  40b088:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x68]
  40b08d:	vmulsd xmm2,xmm2,xmm2
  40b091:	vfmadd231sd xmm2,xmm4,xmm4
  40b096:	vfmadd231sd xmm2,xmm5,xmm5
  40b09b:	vsqrtsd xmm2,xmm2,xmm2
  40b09f:	vdivsd xmm2,xmm9,xmm2
  40b0a3:	vsubsd xmm0,xmm0,xmm2
  40b0a7:	vmovsd xmm2,QWORD PTR [rbx]
  40b0ab:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x70]
  40b0b0:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  40b0b5:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x78]
  40b0ba:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  40b0bf:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x80]
  40b0c7:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xa0]
  40b0cf:	vmulsd xmm2,xmm2,xmm2
  40b0d3:	vfmadd231sd xmm2,xmm4,xmm4
  40b0d8:	vfmadd231sd xmm2,xmm5,xmm5
  40b0dd:	vsqrtsd xmm2,xmm2,xmm2
  40b0e1:	vdivsd xmm2,xmm9,xmm2
  40b0e5:	vsubsd xmm0,xmm0,xmm2
  40b0e9:	vmovsd xmm2,QWORD PTR [rbx]
  40b0ed:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  40b0f5:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  40b0fa:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  40b102:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  40b107:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  40b10f:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  40b117:	vmulsd xmm2,xmm2,xmm2
  40b11b:	vfmadd231sd xmm2,xmm4,xmm4
  40b120:	vfmadd231sd xmm2,xmm5,xmm5
  40b125:	vsqrtsd xmm2,xmm2,xmm2
  40b129:	vdivsd xmm2,xmm9,xmm2
  40b12d:	vsubsd xmm0,xmm0,xmm2
  40b131:	vmovsd xmm2,QWORD PTR [rbx]
  40b135:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xe0]
  40b13d:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  40b142:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xe8]
  40b14a:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  40b14f:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xf0]
  40b157:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x110]
  40b15f:	vmulsd xmm2,xmm2,xmm2
  40b163:	vfmadd231sd xmm2,xmm4,xmm4
  40b168:	vfmadd231sd xmm2,xmm5,xmm5
  40b16d:	vsqrtsd xmm2,xmm2,xmm2
  40b171:	vdivsd xmm2,xmm9,xmm2
  40b175:	vsubsd xmm0,xmm0,xmm2
  40b179:	vmovsd xmm3,QWORD PTR [rbx+0x68]
  40b17e:	vmulsd xmm2,xmm1,xmm3
  40b182:	vmovsd xmm4,QWORD PTR [rbx+0x50]
  40b187:	vmulsd xmm4,xmm4,xmm4
  40b18b:	vmovsd xmm5,QWORD PTR [rbx+0x58]
  40b190:	vfmadd231sd xmm4,xmm5,xmm5
  40b195:	vmovsd xmm5,QWORD PTR [rbx+0x60]
  40b19a:	vfmadd231sd xmm4,xmm5,xmm5
  40b19f:	vfmadd231sd xmm0,xmm2,xmm4
  40b1a4:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  40b1a9:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x70]
  40b1ae:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  40b1b3:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x78]
  40b1b8:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  40b1bd:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x80]
  40b1c5:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xa0]
  40b1cd:	vmulsd xmm2,xmm2,xmm2
  40b1d1:	vfmadd231sd xmm2,xmm4,xmm4
  40b1d6:	vfmadd231sd xmm2,xmm5,xmm5
  40b1db:	vsqrtsd xmm2,xmm2,xmm2
  40b1df:	vdivsd xmm2,xmm9,xmm2
  40b1e3:	vsubsd xmm0,xmm0,xmm2
  40b1e7:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  40b1ec:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  40b1f4:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  40b1f9:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  40b201:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  40b206:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  40b20e:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  40b216:	vmulsd xmm2,xmm2,xmm2
  40b21a:	vfmadd231sd xmm2,xmm4,xmm4
  40b21f:	vfmadd231sd xmm2,xmm5,xmm5
  40b224:	vsqrtsd xmm2,xmm2,xmm2
  40b228:	vdivsd xmm2,xmm9,xmm2
  40b22c:	vsubsd xmm0,xmm0,xmm2
  40b230:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  40b235:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xe0]
  40b23d:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  40b242:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xe8]
  40b24a:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  40b24f:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xf0]
  40b257:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x110]
  40b25f:	vmulsd xmm2,xmm2,xmm2
  40b263:	vfmadd231sd xmm2,xmm4,xmm4
  40b268:	vfmadd231sd xmm2,xmm5,xmm5
  40b26d:	vsqrtsd xmm2,xmm2,xmm2
  40b271:	vdivsd xmm2,xmm9,xmm2
  40b275:	vsubsd xmm0,xmm0,xmm2
  40b279:	vmovsd xmm3,QWORD PTR [rbx+0xa0]
  40b281:	vmulsd xmm2,xmm1,xmm3
  40b285:	vmovsd xmm4,QWORD PTR [rbx+0x88]
  40b28d:	vmulsd xmm4,xmm4,xmm4
  40b291:	vmovsd xmm5,QWORD PTR [rbx+0x90]
  40b299:	vfmadd231sd xmm4,xmm5,xmm5
  40b29e:	vmovsd xmm5,QWORD PTR [rbx+0x98]
  40b2a6:	vfmadd231sd xmm4,xmm5,xmm5
  40b2ab:	vfmadd231sd xmm0,xmm2,xmm4
  40b2b0:	vmovsd xmm2,QWORD PTR [rbx+0x70]
  40b2b5:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  40b2bd:	vmovsd xmm4,QWORD PTR [rbx+0x78]
  40b2c2:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  40b2ca:	vmovsd xmm5,QWORD PTR [rbx+0x80]
  40b2d2:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  40b2da:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  40b2e2:	vmulsd xmm2,xmm2,xmm2
  40b2e6:	vfmadd231sd xmm2,xmm4,xmm4
  40b2eb:	vfmadd231sd xmm2,xmm5,xmm5
  40b2f0:	vsqrtsd xmm2,xmm2,xmm2
  40b2f4:	vdivsd xmm2,xmm9,xmm2
  40b2f8:	vsubsd xmm0,xmm0,xmm2
  40b2fc:	vmovsd xmm2,QWORD PTR [rbx+0x70]
  40b301:	vmovsd xmm6,QWORD PTR [rbx+0xe0]
  40b309:	vsubsd xmm2,xmm2,xmm6
  40b30d:	vmovsd xmm4,QWORD PTR [rbx+0x78]
  40b312:	vmovsd xmm7,QWORD PTR [rbx+0xe8]
  40b31a:	vsubsd xmm4,xmm4,xmm7
  40b31e:	vmovsd xmm5,QWORD PTR [rbx+0x80]
  40b326:	vmovsd xmm8,QWORD PTR [rbx+0xf0]
  40b32e:	vsubsd xmm5,xmm5,xmm8
  40b333:	vmovsd xmm10,QWORD PTR [rbx+0x110]
  40b33b:	vmulsd xmm9,xmm3,xmm10
  40b340:	vmulsd xmm2,xmm2,xmm2
  40b344:	vfmadd231sd xmm2,xmm4,xmm4
  40b349:	vfmadd231sd xmm2,xmm5,xmm5
  40b34e:	vsqrtsd xmm2,xmm2,xmm2
  40b352:	vdivsd xmm2,xmm9,xmm2
  40b356:	vsubsd xmm0,xmm0,xmm2
  40b35a:	vmovsd xmm3,QWORD PTR [rbx+0xd8]
  40b362:	vmulsd xmm2,xmm1,xmm3
  40b366:	vmovsd xmm4,QWORD PTR [rbx+0xc0]
  40b36e:	vmulsd xmm4,xmm4,xmm4
  40b372:	vmovsd xmm5,QWORD PTR [rbx+0xc8]
  40b37a:	vfmadd231sd xmm4,xmm5,xmm5
  40b37f:	vmovsd xmm5,QWORD PTR [rbx+0xd0]
  40b387:	vfmadd231sd xmm4,xmm5,xmm5
  40b38c:	vfmadd231sd xmm0,xmm2,xmm4
  40b391:	vmovsd xmm2,QWORD PTR [rbx+0xa8]
  40b399:	vsubsd xmm2,xmm2,xmm6
  40b39d:	vmovsd xmm4,QWORD PTR [rbx+0xb0]
  40b3a5:	vsubsd xmm4,xmm4,xmm7
  40b3a9:	vmovsd xmm5,QWORD PTR [rbx+0xb8]
  40b3b1:	vsubsd xmm5,xmm5,xmm8
  40b3b6:	vmulsd xmm9,xmm3,xmm10
  40b3bb:	vmulsd xmm2,xmm2,xmm2
  40b3bf:	vfmadd231sd xmm2,xmm4,xmm4
  40b3c4:	vfmadd231sd xmm2,xmm5,xmm5
  40b3c9:	vsqrtsd xmm2,xmm2,xmm2
  40b3cd:	vdivsd xmm2,xmm9,xmm2
  40b3d1:	vsubsd xmm0,xmm0,xmm2
  40b3d5:	vmulsd xmm2,xmm10,xmm1
  40b3d9:	vmovsd xmm4,QWORD PTR [rbx+0xf8]
  40b3e1:	vmulsd xmm4,xmm4,xmm4
  40b3e5:	vmovsd xmm5,QWORD PTR [rbx+0x100]
  40b3ed:	vfmadd231sd xmm4,xmm5,xmm5
  40b3f2:	vmovsd xmm5,QWORD PTR [rbx+0x108]
  40b3fa:	vfmadd231sd xmm4,xmm5,xmm5
  40b3ff:	vfmadd231sd xmm0,xmm2,xmm4
  40b404:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x7e34]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40b40c:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x7f5f]        # 413373 <__swc_rdata_base_6b1cf01f+0x263>
  40b414:	vroundsd xmm0,xmm0,xmm0,0x1
  40b41a:	vmovsd xmm1,QWORD PTR [rip+0x7f5a]        # 41337c <__swc_rdata_base_6b1cf01f+0x26c>
  40b422:	vcomisd xmm0,xmm1
  40b426:	jb     40b440 <__swc_fn_6b1cf01f_000001_0ce64436+0xec0>
  40b428:	vsubsd xmm0,xmm0,xmm1
  40b42c:	vcvttsd2si rsi,xmm0
  40b431:	movabs rax,0x8000000000000000
  40b43b:	xor    rsi,rax
  40b43e:	jmp    40b445 <__swc_fn_6b1cf01f_000001_0ce64436+0xec5>
  40b440:	vcvttsd2si rsi,xmm0
  40b445:	sub    rsp,0x8
  40b449:	call   407270 <__swc_fn_6b1cf01f_000000_1ca87929>
  40b44e:	add    rsp,0x8
  40b452:	vsubsd xmm0,xmm0,QWORD PTR [rsp+0x2d0]
  40b45b:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x7f22]        # 413385 <__swc_rdata_base_6b1cf01f+0x275>
  40b463:	lea    rax,[rip+0x7de6]        # 413250 <__swc_rdata_base_6b1cf01f+0x140>
  40b46a:	sub    rsp,0x90
  40b471:	mov    rcx,rsp
  40b474:	vmovups xmm1,XMMWORD PTR [rip+0x7ebc]        # 413338 <__swc_rdata_base_6b1cf01f+0x228>
  40b47c:	vmovups XMMWORD PTR [rcx],xmm1
  40b480:	mov    QWORD PTR [rcx+0x30],rsp
  40b484:	lea    rdx,[rip+0x7dd5]        # 413260 <__swc_rdata_base_6b1cf01f+0x150>
  40b48b:	mov    QWORD PTR [rcx+0x38],rdx
  40b48f:	mov    QWORD PTR [rcx+0x10],rsi
  40b493:	lea    r8,[rsp+0x10]
  40b498:	mov    QWORD PTR [rcx+0x40],r8
  40b49c:	lea    r8,[rip+0x7e05]        # 4132a8 <__swc_rdata_base_6b1cf01f+0x198>
  40b4a3:	mov    QWORD PTR [rcx+0x48],r8
  40b4a7:	vmovups xmm1,XMMWORD PTR [rip+0x7e99]        # 413348 <__swc_rdata_base_6b1cf01f+0x238>
  40b4af:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40b4b4:	lea    r8,[rsp+0x18]
  40b4b9:	mov    QWORD PTR [rcx+0x50],r8
  40b4bd:	mov    QWORD PTR [rcx+0x58],rdx
  40b4c1:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40b4c6:	lea    r8,[rcx+0x28]
  40b4ca:	mov    QWORD PTR [rcx+0x60],r8
  40b4ce:	lea    r8,[rip+0x7e1b]        # 4132f0 <__swc_rdata_base_6b1cf01f+0x1e0>
  40b4d5:	mov    QWORD PTR [rcx+0x68],r8
  40b4d9:	mov    QWORD PTR [rcx+0x70],rax
  40b4dd:	mov    QWORD PTR [rcx+0x78],rdx
  40b4e1:	lea    rax,[rcx+0x30]
  40b4e5:	mov    QWORD PTR [rcx+0x80],rax
  40b4ec:	mov    QWORD PTR [rcx+0x88],0x5
  40b4f7:	lea    rcx,[rcx+0x80]
  40b4fe:	sub    rsp,0x8
  40b502:	call   40e0a0 <__swc_fn_6b1cf01f_000148_6203dca2>
  40b507:	add    rsp,0x5a8
  40b50e:	vmovups xmm6,XMMWORD PTR [rsp]
  40b513:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  40b519:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  40b51f:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  40b525:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  40b52b:	vmovups xmm11,XMMWORD PTR [rsp+0x50]
  40b531:	vmovups xmm12,XMMWORD PTR [rsp+0x60]
  40b537:	vmovups xmm13,XMMWORD PTR [rsp+0x70]
  40b53d:	vmovups xmm14,XMMWORD PTR [rsp+0x80]
  40b546:	vmovups xmm15,XMMWORD PTR [rsp+0x90]
  40b54f:	add    rsp,0xa8
  40b556:	pop    rsi
  40b557:	pop    rbx
  40b558:	pop    rbp
  40b559:	ret
