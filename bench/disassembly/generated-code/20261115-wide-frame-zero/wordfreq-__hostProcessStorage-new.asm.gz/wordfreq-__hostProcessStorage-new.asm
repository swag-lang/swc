
/workspace/prompt2-20261115/batch5-final-micro/new/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

000000000040fcf0 <__swc_fn_4fa09e82_000113_6814119b>:
  40fcf0:	push   rbx
  40fcf1:	push   r12
  40fcf3:	push   rdi
  40fcf4:	push   rsi
  40fcf5:	push   r13
  40fcf7:	push   r14
  40fcf9:	push   r15
  40fcfb:	sub    rsp,0x170
  40fd02:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40fd0b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40fd14:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40fd1d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40fd26:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40fd2f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40fd38:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40fd41:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40fd4a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40fd53:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40fd5c:	mov    ebx,edx
  40fd5e:	mov    QWORD PTR [rsp+0xa8],rbx
  40fd66:	mov    r12d,ecx
  40fd69:	test   edx,edx
  40fd6b:	jne    40fd82 <__swc_fn_4fa09e82_000113_6814119b+0x92>
  40fd6d:	xor    eax,eax
  40fd6f:	add    rsp,0x170
  40fd76:	pop    r15
  40fd78:	pop    r14
  40fd7a:	pop    r13
  40fd7c:	pop    rsi
  40fd7d:	pop    rdi
  40fd7e:	pop    r12
  40fd80:	pop    rbx
  40fd81:	ret
  40fd82:	lea    rdi,[rip+0x37f7]        # 413580 <__swc_rdata_base_4fa09e82+0x470>
  40fd89:	mov    esi,0x90000
  40fd8e:	xor    eax,eax
  40fd90:	call   407090 <open@plt>
  40fd95:	mov    r13,rax
  40fd98:	mov    QWORD PTR [rsp+0xb0],rax
  40fda0:	test   eax,eax
  40fda2:	jge    40fdab <__swc_fn_4fa09e82_000113_6814119b+0xbb>
  40fda4:	xor    eax,eax
  40fda6:	jmp    4102a6 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  40fdab:	nop    DWORD PTR [rax+rax*1+0x0]
  40fdb0:	movsxd rdi,r13d
  40fdb3:	mov    esi,0x2
  40fdb8:	xor    eax,eax
  40fdba:	call   407120 <flock@plt>
  40fdbf:	test   eax,eax
  40fdc1:	je     40fde0 <__swc_fn_4fa09e82_000113_6814119b+0xf0>
  40fdc3:	xor    eax,eax
  40fdc5:	call   407130 <__errno_location@plt>
  40fdca:	cmp    DWORD PTR [rax],0x4
  40fdcd:	je     40fdb0 <__swc_fn_4fa09e82_000113_6814119b+0xc0>
  40fdcf:	movsxd rdi,r13d
  40fdd2:	xor    eax,eax
  40fdd4:	call   4070b0 <close@plt>
  40fdd9:	xor    eax,eax
  40fddb:	jmp    4102a6 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  40fde0:	lea    r14,[rsp+0x8]
  40fde5:	mov    QWORD PTR [rsp+0xb8],r14
  40fded:	vxorps xmm0,xmm0,xmm0
  40fdf1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fdf7:	mov    QWORD PTR [rsp+0x18],0x0
  40fe00:	mov    WORD PTR [rsp+0x20],0x0
  40fe07:	mov    DWORD PTR [r14],0x67617753
  40fe0e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40fe16:	xor    eax,eax
  40fe18:	call   407010 <getpid@plt>
  40fe1d:	mov    ecx,eax
  40fe1f:	mov    eax,0x1c
  40fe24:	shrx   eax,ecx,eax
  40fe29:	and    eax,0xf
  40fe2c:	mov    rdx,QWORD PTR [rip+0x376d]        # 4135a0 <__swc_rdata_base_4fa09e82+0x490>
  40fe33:	mov    al,BYTE PTR [rdx+rax*1]
  40fe36:	rex mov BYTE PTR [rsp+0x10],al
  40fe3b:	mov    eax,0x1c
  40fe40:	shrx   eax,r12d,eax
  40fe45:	and    eax,0xf
  40fe48:	mov    al,BYTE PTR [rdx+rax*1]
  40fe4b:	rex mov BYTE PTR [rsp+0x19],al
  40fe50:	mov    eax,0x18
  40fe55:	shrx   eax,ecx,eax
  40fe5a:	and    eax,0xf
  40fe5d:	mov    al,BYTE PTR [rdx+rax*1]
  40fe60:	rex mov BYTE PTR [rsp+0x11],al
  40fe65:	mov    eax,0x18
  40fe6a:	shrx   eax,r12d,eax
  40fe6f:	and    eax,0xf
  40fe72:	mov    al,BYTE PTR [rdx+rax*1]
  40fe75:	rex mov BYTE PTR [rsp+0x1a],al
  40fe7a:	mov    eax,0x14
  40fe7f:	shrx   eax,ecx,eax
  40fe84:	and    eax,0xf
  40fe87:	mov    al,BYTE PTR [rdx+rax*1]
  40fe8a:	rex mov BYTE PTR [rsp+0x12],al
  40fe8f:	mov    eax,0x14
  40fe94:	shrx   eax,r12d,eax
  40fe99:	and    eax,0xf
  40fe9c:	mov    al,BYTE PTR [rdx+rax*1]
  40fe9f:	rex mov BYTE PTR [rsp+0x1b],al
  40fea4:	mov    eax,0x10
  40fea9:	shrx   eax,ecx,eax
  40feae:	and    eax,0xf
  40feb1:	mov    al,BYTE PTR [rdx+rax*1]
  40feb4:	rex mov BYTE PTR [rsp+0x13],al
  40feb9:	mov    eax,0x10
  40febe:	shrx   eax,r12d,eax
  40fec3:	and    eax,0xf
  40fec6:	mov    al,BYTE PTR [rdx+rax*1]
  40fec9:	rex mov BYTE PTR [rsp+0x1c],al
  40fece:	mov    eax,0xc
  40fed3:	shrx   eax,ecx,eax
  40fed8:	and    eax,0xf
  40fedb:	mov    al,BYTE PTR [rdx+rax*1]
  40fede:	rex mov BYTE PTR [rsp+0x14],al
  40fee3:	mov    eax,0xc
  40fee8:	shrx   eax,r12d,eax
  40feed:	and    eax,0xf
  40fef0:	mov    al,BYTE PTR [rdx+rax*1]
  40fef3:	rex mov BYTE PTR [rsp+0x1d],al
  40fef8:	mov    eax,0x8
  40fefd:	shrx   eax,ecx,eax
  40ff02:	and    eax,0xf
  40ff05:	mov    al,BYTE PTR [rdx+rax*1]
  40ff08:	rex mov BYTE PTR [rsp+0x15],al
  40ff0d:	mov    eax,0x8
  40ff12:	shrx   eax,r12d,eax
  40ff17:	and    eax,0xf
  40ff1a:	mov    al,BYTE PTR [rdx+rax*1]
  40ff1d:	rex mov BYTE PTR [rsp+0x1e],al
  40ff22:	mov    eax,0x4
  40ff27:	shrx   eax,ecx,eax
  40ff2c:	and    eax,0xf
  40ff2f:	mov    al,BYTE PTR [rdx+rax*1]
  40ff32:	rex mov BYTE PTR [rsp+0x16],al
  40ff37:	mov    eax,0x4
  40ff3c:	shrx   eax,r12d,eax
  40ff41:	and    eax,0xf
  40ff44:	mov    al,BYTE PTR [rdx+rax*1]
  40ff47:	rex mov BYTE PTR [rsp+0x1f],al
  40ff4c:	xor    eax,eax
  40ff4e:	shrx   eax,ecx,eax
  40ff53:	and    eax,0xf
  40ff56:	mov    al,BYTE PTR [rdx+rax*1]
  40ff59:	rex mov BYTE PTR [rsp+0x17],al
  40ff5e:	xor    eax,eax
  40ff60:	shrx   eax,r12d,eax
  40ff65:	and    eax,0xf
  40ff68:	mov    al,BYTE PTR [rdx+rax*1]
  40ff6b:	rex mov BYTE PTR [rsp+0x20],al
  40ff70:	mov    BYTE PTR [r14+0x10],0x2e
  40ff75:	lea    r12,[rsp+0x22]
  40ff7a:	vxorps xmm0,xmm0,xmm0
  40ff7e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40ff84:	mov    DWORD PTR [r12],0x6d656d2f
  40ff8c:	mov    WORD PTR [r12+0x4],0x6466
  40ff94:	mov    BYTE PTR [r12+0x6],0x3a
  40ff9a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ffa0:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40ffa6:	mov    rax,QWORD PTR [rsp+0x18]
  40ffab:	mov    QWORD PTR [rsp+0x39],rax
  40ffb0:	rex mov al,BYTE PTR [rsp+0x20]
  40ffb5:	rex mov BYTE PTR [rsp+0x41],al
  40ffba:	mov    DWORD PTR [r12+0x20],0x65642820
  40ffc3:	mov    DWORD PTR [r12+0x24],0x6574656c
  40ffcc:	mov    WORD PTR [r12+0x28],0x2964
  40ffd4:	lea    rdi,[rip+0x35b0]        # 41358b <__swc_rdata_base_4fa09e82+0x47b>
  40ffdb:	xor    eax,eax
  40ffdd:	call   407140 <opendir@plt>
  40ffe2:	mov    r15,rax
  40ffe5:	test   rax,rax
  40ffe8:	jne    40fffb <__swc_fn_4fa09e82_000113_6814119b+0x30b>
  40ffea:	movsxd rdi,r13d
  40ffed:	xor    eax,eax
  40ffef:	call   4070b0 <close@plt>
  40fff4:	xor    eax,eax
  40fff6:	jmp    4102a6 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  40fffb:	mov    rdi,r15
  40fffe:	xor    eax,eax
  410000:	call   407150 <dirfd@plt>
  410005:	lea    r14,[rsp+0x54]
  41000a:	mov    DWORD PTR [rsp+0x54],eax
  41000e:	lea    rbx,[rsp+0x58]
  410013:	cs nop WORD PTR [rax+rax*1+0x0]
  41001d:	nop    DWORD PTR [rax]
  410020:	mov    rdi,r15
  410023:	xor    eax,eax
  410025:	call   407160 <readdir@plt>
  41002a:	test   rax,rax
  41002d:	jne    410044 <__swc_fn_4fa09e82_000113_6814119b+0x354>
  41002f:	mov    r12,QWORD PTR [rsp+0xa8]
  410037:	mov    r13,QWORD PTR [rsp+0xb0]
  41003f:	jmp    4101ca <__swc_fn_4fa09e82_000113_6814119b+0x4da>
  410044:	vxorps xmm0,xmm0,xmm0
  410048:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  41004e:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  410054:	vzeroupper
  410057:	lea    r13,[rax+0x13]
  41005b:	mov    rax,r14
  41005e:	movsxd rdi,DWORD PTR [rax]
  410061:	mov    rsi,r13
  410064:	mov    rdx,rbx
  410067:	mov    ecx,0x40
  41006c:	xor    eax,eax
  41006e:	call   407170 <readlinkat@plt>
  410073:	cmp    rax,0x2a
  410077:	jne    410020 <__swc_fn_4fa09e82_000113_6814119b+0x330>
  410079:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  41007f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  410085:	vptest xmm0,xmm0
  41008a:	jne    4100ba <__swc_fn_4fa09e82_000113_6814119b+0x3ca>
  41008c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  410092:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  410098:	vptest xmm0,xmm0
  41009d:	jne    4100ba <__swc_fn_4fa09e82_000113_6814119b+0x3ca>
  41009f:	mov    rcx,QWORD PTR [rsp+0x42]
  4100a4:	cmp    QWORD PTR [rsp+0x78],rcx
  4100a9:	jne    4100ba <__swc_fn_4fa09e82_000113_6814119b+0x3ca>
  4100ab:	mov    cx,WORD PTR [rsp+0x4a]
  4100b0:	cmp    WORD PTR [rsp+0x80],cx
  4100b8:	je     4100e4 <__swc_fn_4fa09e82_000113_6814119b+0x3f4>
  4100ba:	mov    rax,rbx
  4100bd:	mov    rcx,r12
  4100c0:	movzx  edx,BYTE PTR [rax]
  4100c3:	movzx  r8d,BYTE PTR [rcx]
  4100c7:	cmp    rdx,r8
  4100ca:	jne    4100d6 <__swc_fn_4fa09e82_000113_6814119b+0x3e6>
  4100cc:	add    rax,0x1
  4100d0:	add    rcx,0x1
  4100d4:	jmp    4100c0 <__swc_fn_4fa09e82_000113_6814119b+0x3d0>
  4100d6:	mov    rax,rdx
  4100d9:	sub    rax,r8
  4100dc:	test   eax,eax
  4100de:	jne    410020 <__swc_fn_4fa09e82_000113_6814119b+0x330>
  4100e4:	movsxd rdi,DWORD PTR [r14]
  4100e7:	mov    rsi,r13
  4100ea:	mov    edx,0x80002
  4100ef:	xor    eax,eax
  4100f1:	call   407180 <openat@plt>
  4100f6:	lea    rbx,[rsp+0x98]
  4100fe:	mov    DWORD PTR [rsp+0x98],eax
  410105:	test   eax,eax
  410107:	mov    r13,QWORD PTR [rsp+0xb0]
  41010f:	jge    410134 <__swc_fn_4fa09e82_000113_6814119b+0x444>
  410111:	mov    rdi,r15
  410114:	xor    eax,eax
  410116:	call   407190 <closedir@plt>
  41011b:	mov    r13,QWORD PTR [rsp+0xb0]
  410123:	movsxd rdi,r13d
  410126:	xor    eax,eax
  410128:	call   4070b0 <close@plt>
  41012d:	xor    eax,eax
  41012f:	jmp    4102a6 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  410134:	mov    rax,rbx
  410137:	movsxd rdi,DWORD PTR [rax]
  41013a:	xor    esi,esi
  41013c:	mov    edx,0x2
  410141:	xor    eax,eax
  410143:	call   4070a0 <lseek@plt>
  410148:	mov    r12,QWORD PTR [rsp+0xa8]
  410150:	cmp    rax,r12
  410153:	je     41017a <__swc_fn_4fa09e82_000113_6814119b+0x48a>
  410155:	movsxd rdi,DWORD PTR [rbx]
  410158:	xor    eax,eax
  41015a:	call   4070b0 <close@plt>
  41015f:	mov    rdi,r15
  410162:	xor    eax,eax
  410164:	call   407190 <closedir@plt>
  410169:	movsxd rdi,r13d
  41016c:	xor    eax,eax
  41016e:	call   4070b0 <close@plt>
  410173:	xor    eax,eax
  410175:	jmp    4102a6 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  41017a:	xor    edi,edi
  41017c:	mov    rsi,r12
  41017f:	mov    edx,0x3
  410184:	mov    ecx,0x1
  410189:	mov    rax,rbx
  41018c:	movsxd r8,DWORD PTR [rax]
  41018f:	xor    r9d,r9d
  410192:	xor    eax,eax
  410194:	call   4070c0 <mmap@plt>
  410199:	xor    r12d,r12d
  41019c:	cmp    rax,0xffffffffffffffff
  4101a0:	cmovne r12,rax
  4101a4:	movsxd rdi,DWORD PTR [rbx]
  4101a7:	xor    eax,eax
  4101a9:	call   4070b0 <close@plt>
  4101ae:	mov    rdi,r15
  4101b1:	xor    eax,eax
  4101b3:	call   407190 <closedir@plt>
  4101b8:	movsxd rdi,r13d
  4101bb:	xor    eax,eax
  4101bd:	call   4070b0 <close@plt>
  4101c2:	mov    rax,r12
  4101c5:	jmp    4102a6 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  4101ca:	mov    r14,QWORD PTR [rsp+0xb8]
  4101d2:	mov    rdi,r14
  4101d5:	mov    esi,0x1
  4101da:	xor    eax,eax
  4101dc:	call   4071a0 <memfd_create@plt>
  4101e1:	lea    rbx,[rsp+0x9c]
  4101e9:	mov    DWORD PTR [rsp+0x9c],eax
  4101f0:	test   eax,eax
  4101f2:	jge    41020f <__swc_fn_4fa09e82_000113_6814119b+0x51f>
  4101f4:	mov    rdi,r15
  4101f7:	xor    eax,eax
  4101f9:	call   407190 <closedir@plt>
  4101fe:	movsxd rdi,r13d
  410201:	xor    eax,eax
  410203:	call   4070b0 <close@plt>
  410208:	xor    eax,eax
  41020a:	jmp    4102a6 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  41020f:	mov    rax,rbx
  410212:	movsxd rdi,DWORD PTR [rax]
  410215:	mov    rsi,r12
  410218:	xor    eax,eax
  41021a:	call   4071b0 <ftruncate@plt>
  41021f:	test   eax,eax
  410221:	je     410245 <__swc_fn_4fa09e82_000113_6814119b+0x555>
  410223:	movsxd rdi,DWORD PTR [rbx]
  410226:	xor    eax,eax
  410228:	call   4070b0 <close@plt>
  41022d:	mov    rdi,r15
  410230:	xor    eax,eax
  410232:	call   407190 <closedir@plt>
  410237:	movsxd rdi,r13d
  41023a:	xor    eax,eax
  41023c:	call   4070b0 <close@plt>
  410241:	xor    eax,eax
  410243:	jmp    4102a6 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  410245:	xor    edi,edi
  410247:	mov    rsi,r12
  41024a:	mov    edx,0x3
  41024f:	mov    ecx,0x1
  410254:	mov    rax,rbx
  410257:	movsxd r8,DWORD PTR [rax]
  41025a:	xor    r9d,r9d
  41025d:	xor    eax,eax
  41025f:	call   4070c0 <mmap@plt>
  410264:	mov    r12,rax
  410267:	cmp    rax,0xffffffffffffffff
  41026b:	jne    41028f <__swc_fn_4fa09e82_000113_6814119b+0x59f>
  41026d:	movsxd rdi,DWORD PTR [rbx]
  410270:	xor    eax,eax
  410272:	call   4070b0 <close@plt>
  410277:	mov    rdi,r15
  41027a:	xor    eax,eax
  41027c:	call   407190 <closedir@plt>
  410281:	movsxd rdi,r13d
  410284:	xor    eax,eax
  410286:	call   4070b0 <close@plt>
  41028b:	xor    eax,eax
  41028d:	jmp    4102a6 <__swc_fn_4fa09e82_000113_6814119b+0x5b6>
  41028f:	mov    rdi,r15
  410292:	xor    eax,eax
  410294:	call   407190 <closedir@plt>
  410299:	movsxd rdi,r13d
  41029c:	xor    eax,eax
  41029e:	call   4070b0 <close@plt>
  4102a3:	mov    rax,r12
  4102a6:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  4102af:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  4102b8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  4102c1:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  4102ca:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  4102d3:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  4102dc:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  4102e5:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  4102ee:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  4102f7:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  410300:	add    rsp,0x170
  410307:	pop    r15
  410309:	pop    r14
  41030b:	pop    r13
  41030d:	pop    rsi
  41030e:	pop    rdi
  41030f:	pop    r12
  410311:	pop    rbx
  410312:	ret
