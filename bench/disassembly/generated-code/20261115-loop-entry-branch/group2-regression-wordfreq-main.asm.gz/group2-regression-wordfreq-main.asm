
/workspace/prompt2-20261115/group2-review/new/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

000000000040a880 <__swc_fn_4fa09e82_000004_913db40c>:
  40a880:	push   rbp
  40a881:	push   rbx
  40a882:	push   rsi
  40a883:	push   rdi
  40a884:	push   r12
  40a886:	push   r15
  40a888:	push   r13
  40a88a:	push   r14
  40a88c:	sub    rsp,0x10
  40a890:	mov    rbp,rsp
  40a893:	vmovups XMMWORD PTR [rsp],xmm6
  40a898:	sub    rsp,0x50
  40a89c:	mov    rbx,rsp
  40a89f:	sub    rsp,0x8
  40a8a3:	mov    ecx,0x13880
  40a8a8:	call   40a7e0 <__swc_fn_4fa09e82_000001_2744b483>
  40a8ad:	mov    rsi,rax
  40a8b0:	mov    ecx,0x9c40
  40a8b5:	call   40a7e0 <__swc_fn_4fa09e82_000001_2744b483>
  40a8ba:	mov    rdi,rax
  40a8bd:	mov    ecx,0x9c40
  40a8c2:	call   40a7e0 <__swc_fn_4fa09e82_000001_2744b483>
  40a8c7:	mov    r12,rax
  40a8ca:	xor    ecx,ecx
  40a8cc:	xor    r8d,r8d
  40a8cf:	cs nop WORD PTR [rax+rax*1+0x0]
  40a8d9:	nop    DWORD PTR [rax+0x0]
  40a8e0:	lea    r9,[r8+0x1]
  40a8e4:	mov    r10,r9
  40a8e7:	movabs rdx,0xaaaaaaaaaaaaaaab
  40a8f1:	mov    r15,rax
  40a8f4:	mov    rax,r8
  40a8f7:	mul    rdx
  40a8fa:	mov    r11,rdx
  40a8fd:	mov    rax,r15
  40a900:	shr    r11,0x2
  40a904:	imul   r11,r11,0x6
  40a908:	mov    rdx,r8
  40a90b:	sub    rdx,r11
  40a90e:	lea    r11,[rdx+0x3]
  40a912:	mov    QWORD PTR [rdi+r8*8],rcx
  40a916:	mov    QWORD PTR [r12+r8*8],r11
  40a91a:	xor    r8d,r8d
  40a91d:	test   r11,r11
  40a920:	jbe    40a974 <__swc_fn_4fa09e82_000004_913db40c+0xf4>
  40a922:	xor    r13d,r13d
  40a925:	cs nop WORD PTR [rax+rax*1+0x0]
  40a92f:	nop
  40a930:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40a93a:	mov    r15,rax
  40a93d:	mov    rax,r10
  40a940:	mul    rdx
  40a943:	mov    r14,rdx
  40a946:	mov    rax,r15
  40a949:	shr    r14,0x3
  40a94d:	imul   r14,r14,0x1a
  40a951:	sub    r10,r14
  40a954:	lea    r10,[r10+0x61]
  40a958:	mov    BYTE PTR [rsi+rcx*1],r10b
  40a95c:	inc    rcx
  40a95f:	shr    rdx,0x3
  40a963:	lea    r10,[rdx+r13*1]
  40a967:	add    r8,0x1
  40a96b:	add    r13,0x7
  40a96f:	cmp    r8,r11
  40a972:	jb     40a930 <__swc_fn_4fa09e82_000004_913db40c+0xb0>
  40a974:	mov    r8,r9
  40a977:	cmp    r9,0x1388
  40a97e:	jb     40a8e0 <__swc_fn_4fa09e82_000004_913db40c+0x60>
  40a984:	mov    ecx,0x16e3600
  40a989:	call   40a7e0 <__swc_fn_4fa09e82_000001_2744b483>
  40a98e:	mov    QWORD PTR [rip+0x196d3],rax        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40a995:	xor    ecx,ecx
  40a997:	xor    r8d,r8d
  40a99a:	nop    WORD PTR [rax+rax*1+0x0]
  40a9a0:	mov    r9,QWORD PTR [rip+0x17659]        # 422000 <__swc_data_base_4fa09e82>
  40a9a7:	imul   r9,r9,0x41a7
  40a9ae:	movabs rdx,0x200000005
  40a9b8:	mov    r11,rax
  40a9bb:	mov    rax,r9
  40a9be:	mul    rdx
  40a9c1:	mov    r10,rdx
  40a9c4:	mov    rdx,r9
  40a9c7:	sub    rdx,r10
  40a9ca:	shr    rdx,1
  40a9cd:	add    rdx,r10
  40a9d0:	shr    rdx,0x1e
  40a9d4:	imul   r10,rdx,0x7fffffff
  40a9db:	sub    r9,r10
  40a9de:	mov    QWORD PTR [rip+0x1761b],r9        # 422000 <__swc_data_base_4fa09e82>
  40a9e5:	movabs rdx,0x346dc5d63886594b
  40a9ef:	mov    rax,r9
  40a9f2:	mul    rdx
  40a9f5:	mov    rax,r11
  40a9f8:	shr    rdx,0xa
  40a9fc:	imul   rdx,rdx,0x1388
  40aa03:	sub    r9,rdx
  40aa06:	mov    rdx,QWORD PTR [rdi+r9*8]
  40aa0a:	mov    r9,QWORD PTR [r12+r9*8]
  40aa0e:	xor    r10d,r10d
  40aa11:	test   r9,r9
  40aa14:	jbe    40aa34 <__swc_fn_4fa09e82_000004_913db40c+0x1b4>
  40aa16:	mov    r11,QWORD PTR [rip+0x1964b]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40aa1d:	add    rdx,rsi
  40aa20:	mov    r13b,BYTE PTR [rdx+r10*1]
  40aa24:	mov    BYTE PTR [r11+rcx*1],r13b
  40aa28:	inc    rcx
  40aa2b:	add    r10,0x1
  40aa2f:	cmp    r10,r9
  40aa32:	jb     40aa20 <__swc_fn_4fa09e82_000004_913db40c+0x1a0>
  40aa34:	lea    r9,[r8+0x1]
  40aa38:	movabs rdx,0xaaaaaaaaaaaaaaab
  40aa42:	mov    r11,rax
  40aa45:	mov    rax,r9
  40aa48:	mul    rdx
  40aa4b:	mov    r8,rdx
  40aa4e:	mov    rax,r11
  40aa51:	shr    r8,0x3
  40aa55:	imul   r8,r8,0xc
  40aa59:	mov    rdx,r9
  40aa5c:	sub    rdx,r8
  40aa5f:	jne    40aa6e <__swc_fn_4fa09e82_000004_913db40c+0x1ee>
  40aa61:	mov    rdx,QWORD PTR [rip+0x19600]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40aa68:	mov    BYTE PTR [rdx+rcx*1],0xa
  40aa6c:	jmp    40aa79 <__swc_fn_4fa09e82_000004_913db40c+0x1f9>
  40aa6e:	mov    rdx,QWORD PTR [rip+0x195f3]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40aa75:	mov    BYTE PTR [rdx+rcx*1],0x20
  40aa79:	lea    r13,[rcx+0x1]
  40aa7d:	mov    r15,r13
  40aa80:	mov    rcx,r13
  40aa83:	mov    r8,r9
  40aa86:	cmp    r9,0x1e8480
  40aa8d:	jb     40a9a0 <__swc_fn_4fa09e82_000004_913db40c+0x120>
  40aa93:	mov    QWORD PTR [rsp+0x48],r15
  40aa98:	call   40dd00 <__swc_fn_4fa09e82_000002_1ca87929>
  40aa9d:	vmovups xmm6,xmm0
  40aaa1:	mov    rsi,rbx
  40aaa4:	mov    QWORD PTR [rsp+0x50],rsi
  40aaa9:	vxorps xmm0,xmm0,xmm0
  40aaad:	vmovups XMMWORD PTR [rbx],xmm0
  40aab1:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40aab6:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40aabb:	mov    QWORD PTR [rbx+0x30],0x0
  40aac3:	mov    r8,QWORD PTR [rip+0x1959e]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40aaca:	mov    rcx,rsi
  40aacd:	mov    edx,0x4000
  40aad2:	call   407270 <__swc_fn_4fa09e82_000000_e7f0b636>
  40aad7:	xor    edi,edi
  40aad9:	xor    al,al
  40aadb:	xor    r12d,r12d
  40aade:	cmp    r12,r13
  40aae1:	jae    40ac4f <__swc_fn_4fa09e82_000004_913db40c+0x3cf>
  40aae7:	nop    WORD PTR [rax+rax*1+0x0]
  40aaf0:	mov    rcx,QWORD PTR [rip+0x19571]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40aaf7:	mov    cl,BYTE PTR [rcx+r12*1]
  40aafb:	sub    cl,0x61
  40aafe:	cmp    cl,0x19
  40ab01:	ja     40ab18 <__swc_fn_4fa09e82_000004_913db40c+0x298>
  40ab03:	test   al,al
  40ab05:	jne    40ac3e <__swc_fn_4fa09e82_000004_913db40c+0x3be>
  40ab0b:	mov    rdi,r12
  40ab0e:	mov    eax,0x1
  40ab13:	jmp    40ac3e <__swc_fn_4fa09e82_000004_913db40c+0x3be>
  40ab18:	test   al,al
  40ab1a:	je     40ac3e <__swc_fn_4fa09e82_000004_913db40c+0x3be>
  40ab20:	mov    r14,r12
  40ab23:	sub    r14,rdi
  40ab26:	mov    eax,0x811c9dc5
  40ab2b:	xor    ecx,ecx
  40ab2d:	test   r14,r14
  40ab30:	jbe    40abb2 <__swc_fn_4fa09e82_000004_913db40c+0x332>
  40ab36:	mov    rdx,QWORD PTR [rbx+0x20]
  40ab3a:	add    rdx,rdi
  40ab3d:	cmp    r14,0x4
  40ab41:	jb     40aba0 <__swc_fn_4fa09e82_000004_913db40c+0x320>
  40ab47:	lea    r8,[r14-0x3]
  40ab4b:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab55:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab5f:	nop
  40ab60:	xor    al,BYTE PTR [rdx+rcx*1]
  40ab63:	imul   eax,eax,0x1000193
  40ab69:	xor    al,BYTE PTR [rdx+rcx*1+0x1]
  40ab6d:	imul   eax,eax,0x1000193
  40ab73:	xor    al,BYTE PTR [rdx+rcx*1+0x2]
  40ab77:	imul   eax,eax,0x1000193
  40ab7d:	xor    al,BYTE PTR [rdx+rcx*1+0x3]
  40ab81:	imul   eax,eax,0x1000193
  40ab87:	add    rcx,0x4
  40ab8b:	cmp    rcx,r8
  40ab8e:	jb     40ab60 <__swc_fn_4fa09e82_000004_913db40c+0x2e0>
  40ab90:	cmp    rcx,r14
  40ab93:	jae    40abb2 <__swc_fn_4fa09e82_000004_913db40c+0x332>
  40ab95:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab9f:	nop
  40aba0:	xor    al,BYTE PTR [rdx+rcx*1]
  40aba3:	imul   eax,eax,0x1000193
  40aba9:	add    rcx,0x1
  40abad:	cmp    rcx,r14
  40abb0:	jb     40aba0 <__swc_fn_4fa09e82_000004_913db40c+0x320>
  40abb2:	and    rax,QWORD PTR [rbx+0x28]
  40abb6:	mov    r15,rax
  40abb9:	mov    rsi,QWORD PTR [rbx+0x18]
  40abbd:	mov    r13,QWORD PTR [rbx+0x8]
  40abc1:	cmp    BYTE PTR [rsi+r15*1],0x0
  40abc6:	je     40ac06 <__swc_fn_4fa09e82_000004_913db40c+0x386>
  40abc8:	nop    DWORD PTR [rax+rax*1+0x0]
  40abd0:	cmp    QWORD PTR [r13+r15*8+0x0],r14
  40abd5:	jne    40abf8 <__swc_fn_4fa09e82_000004_913db40c+0x378>
  40abd7:	mov    rax,QWORD PTR [rbx]
  40abda:	mov    rax,QWORD PTR [rax+r15*8]
  40abde:	mov    rcx,QWORD PTR [rbx+0x20]
  40abe2:	add    rax,rcx
  40abe5:	lea    rdx,[rcx+rdi*1]
  40abe9:	mov    rcx,rax
  40abec:	mov    r8,r14
  40abef:	call   40cb10 <__swc_fn_4fa09e82_000112_3dc01326>
  40abf4:	test   eax,eax
  40abf6:	je     40ac06 <__swc_fn_4fa09e82_000004_913db40c+0x386>
  40abf8:	inc    r15
  40abfb:	and    r15,QWORD PTR [rbx+0x28]
  40abff:	cmp    BYTE PTR [rsi+r15*1],0x0
  40ac04:	jne    40abd0 <__swc_fn_4fa09e82_000004_913db40c+0x350>
  40ac06:	cmp    BYTE PTR [rsi+r15*1],0x0
  40ac0b:	jne    40ac34 <__swc_fn_4fa09e82_000004_913db40c+0x3b4>
  40ac0d:	mov    BYTE PTR [rsi+r15*1],0x1
  40ac12:	mov    rax,QWORD PTR [rbx]
  40ac15:	mov    QWORD PTR [rax+r15*8],rdi
  40ac19:	mov    rax,QWORD PTR [rbx+0x8]
  40ac1d:	mov    QWORD PTR [rax+r15*8],r14
  40ac21:	mov    rax,QWORD PTR [rbx+0x10]
  40ac25:	mov    QWORD PTR [rax+r15*8],0x1
  40ac2d:	add    QWORD PTR [rbx+0x30],0x1
  40ac32:	jmp    40ac3c <__swc_fn_4fa09e82_000004_913db40c+0x3bc>
  40ac34:	mov    rax,QWORD PTR [rbx+0x10]
  40ac38:	inc    QWORD PTR [rax+r15*8]
  40ac3c:	xor    eax,eax
  40ac3e:	inc    r12
  40ac41:	mov    r13,QWORD PTR [rsp+0x48]
  40ac46:	cmp    r12,r13
  40ac49:	jb     40aaf0 <__swc_fn_4fa09e82_000004_913db40c+0x270>
  40ac4f:	test   al,al
  40ac51:	je     40ad7b <__swc_fn_4fa09e82_000004_913db40c+0x4fb>
  40ac57:	mov    r13,QWORD PTR [rsp+0x48]
  40ac5c:	sub    r13,rdi
  40ac5f:	mov    eax,0x811c9dc5
  40ac64:	xor    ecx,ecx
  40ac66:	test   r13,r13
  40ac69:	jbe    40acf2 <__swc_fn_4fa09e82_000004_913db40c+0x472>
  40ac6f:	mov    rdx,QWORD PTR [rbx+0x20]
  40ac73:	add    rdx,rdi
  40ac76:	cmp    r13,0x4
  40ac7a:	jb     40ace0 <__swc_fn_4fa09e82_000004_913db40c+0x460>
  40ac80:	lea    r8,[r13-0x3]
  40ac84:	cs nop WORD PTR [rax+rax*1+0x0]
  40ac8e:	cs nop WORD PTR [rax+rax*1+0x0]
  40ac98:	nop    DWORD PTR [rax+rax*1+0x0]
  40aca0:	xor    al,BYTE PTR [rdx+rcx*1]
  40aca3:	imul   eax,eax,0x1000193
  40aca9:	xor    al,BYTE PTR [rdx+rcx*1+0x1]
  40acad:	imul   eax,eax,0x1000193
  40acb3:	xor    al,BYTE PTR [rdx+rcx*1+0x2]
  40acb7:	imul   eax,eax,0x1000193
  40acbd:	xor    al,BYTE PTR [rdx+rcx*1+0x3]
  40acc1:	imul   eax,eax,0x1000193
  40acc7:	add    rcx,0x4
  40accb:	cmp    rcx,r8
  40acce:	jb     40aca0 <__swc_fn_4fa09e82_000004_913db40c+0x420>
  40acd0:	cmp    rcx,r13
  40acd3:	jae    40acf2 <__swc_fn_4fa09e82_000004_913db40c+0x472>
  40acd5:	cs nop WORD PTR [rax+rax*1+0x0]
  40acdf:	nop
  40ace0:	xor    al,BYTE PTR [rdx+rcx*1]
  40ace3:	imul   eax,eax,0x1000193
  40ace9:	add    rcx,0x1
  40aced:	cmp    rcx,r13
  40acf0:	jb     40ace0 <__swc_fn_4fa09e82_000004_913db40c+0x460>
  40acf2:	mov    rsi,QWORD PTR [rsp+0x50]
  40acf7:	and    rax,QWORD PTR [rsi+0x28]
  40acfb:	mov    r12,rax
  40acfe:	mov    r14,QWORD PTR [rbx+0x18]
  40ad02:	mov    r15,QWORD PTR [rbx+0x8]
  40ad06:	cmp    BYTE PTR [r14+r12*1],0x0
  40ad0b:	je     40ad45 <__swc_fn_4fa09e82_000004_913db40c+0x4c5>
  40ad0d:	nop    DWORD PTR [rax]
  40ad10:	cmp    QWORD PTR [r15+r12*8],r13
  40ad14:	jne    40ad37 <__swc_fn_4fa09e82_000004_913db40c+0x4b7>
  40ad16:	mov    rax,QWORD PTR [rbx]
  40ad19:	mov    rax,QWORD PTR [rax+r12*8]
  40ad1d:	mov    rcx,QWORD PTR [rbx+0x20]
  40ad21:	add    rax,rcx
  40ad24:	lea    rdx,[rcx+rdi*1]
  40ad28:	mov    rcx,rax
  40ad2b:	mov    r8,r13
  40ad2e:	call   40cb10 <__swc_fn_4fa09e82_000112_3dc01326>
  40ad33:	test   eax,eax
  40ad35:	je     40ad45 <__swc_fn_4fa09e82_000004_913db40c+0x4c5>
  40ad37:	inc    r12
  40ad3a:	and    r12,QWORD PTR [rbx+0x28]
  40ad3e:	cmp    BYTE PTR [r14+r12*1],0x0
  40ad43:	jne    40ad10 <__swc_fn_4fa09e82_000004_913db40c+0x490>
  40ad45:	cmp    BYTE PTR [r14+r12*1],0x0
  40ad4a:	jne    40ad73 <__swc_fn_4fa09e82_000004_913db40c+0x4f3>
  40ad4c:	mov    BYTE PTR [r14+r12*1],0x1
  40ad51:	mov    rax,QWORD PTR [rbx]
  40ad54:	mov    QWORD PTR [rax+r12*8],rdi
  40ad58:	mov    rax,QWORD PTR [rbx+0x8]
  40ad5c:	mov    QWORD PTR [rax+r12*8],r13
  40ad60:	mov    rax,QWORD PTR [rbx+0x10]
  40ad64:	mov    QWORD PTR [rax+r12*8],0x1
  40ad6c:	add    QWORD PTR [rsi+0x30],0x1
  40ad71:	jmp    40ad7b <__swc_fn_4fa09e82_000004_913db40c+0x4fb>
  40ad73:	mov    rax,QWORD PTR [rbx+0x10]
  40ad77:	inc    QWORD PTR [rax+r12*8]
  40ad7b:	mov    rsi,QWORD PTR [rbx+0x30]
  40ad7f:	lea    rdi,[rsi*8+0x0]
  40ad87:	mov    rcx,rdi
  40ad8a:	call   40a7e0 <__swc_fn_4fa09e82_000001_2744b483>
  40ad8f:	mov    QWORD PTR [rip+0x192ba],rax        # 424050 <__swc_bss_base_4fa09e82+0x10>
  40ad96:	mov    rcx,rdi
  40ad99:	call   40a7e0 <__swc_fn_4fa09e82_000001_2744b483>
  40ad9e:	mov    QWORD PTR [rip+0x192bb],rax        # 424060 <__swc_bss_base_4fa09e82+0x20>
  40ada5:	mov    rcx,rdi
  40ada8:	call   40a7e0 <__swc_fn_4fa09e82_000001_2744b483>
  40adad:	mov    QWORD PTR [rip+0x192a4],rax        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40adb4:	mov    rcx,rdi
  40adb7:	call   40a7e0 <__swc_fn_4fa09e82_000001_2744b483>
  40adbc:	mov    QWORD PTR [rip+0x19285],rax        # 424048 <__swc_bss_base_4fa09e82+0x8>
  40adc3:	xor    ecx,ecx
  40adc5:	xor    edx,edx
  40adc7:	mov    r8,QWORD PTR [rip+0x19282]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  40adce:	mov    r9,QWORD PTR [rip+0x1928b]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  40add5:	mov    r10,QWORD PTR [rip+0x1927c]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40addc:	cs nop WORD PTR [rax+rax*1+0x0]
  40ade6:	cs nop WORD PTR [rax+rax*1+0x0]
  40adf0:	mov    r11,QWORD PTR [rbx+0x18]
  40adf4:	cmp    BYTE PTR [r11+rdx*1],0x0
  40adf9:	je     40ae25 <__swc_fn_4fa09e82_000004_913db40c+0x5a5>
  40adfb:	mov    r11,QWORD PTR [rbx+0x10]
  40adff:	mov    r11,QWORD PTR [r11+rdx*8]
  40ae03:	mov    QWORD PTR [r8+rcx*8],r11
  40ae07:	mov    r11,QWORD PTR [rbx]
  40ae0a:	mov    r11,QWORD PTR [r11+rdx*8]
  40ae0e:	mov    QWORD PTR [r9+rcx*8],r11
  40ae12:	mov    r11,QWORD PTR [rbx+0x8]
  40ae16:	mov    r11,QWORD PTR [r11+rdx*8]
  40ae1a:	mov    QWORD PTR [r10+rcx*8],r11
  40ae1e:	mov    QWORD PTR [rax+rcx*8],rcx
  40ae22:	inc    rcx
  40ae25:	add    rdx,0x1
  40ae29:	cmp    rdx,0x4000
  40ae30:	jb     40adf0 <__swc_fn_4fa09e82_000004_913db40c+0x570>
  40ae32:	xor    ecx,ecx
  40ae34:	lea    rdx,[rsi-0x1]
  40ae38:	call   4072f0 <__swc_fn_4fa09e82_000003_6937fe70>
  40ae3d:	imul   rsi,rsi,0x7
  40ae41:	xor    eax,eax
  40ae43:	mov    rcx,QWORD PTR [rip+0x191fe]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  40ae4a:	mov    rdx,QWORD PTR [rip+0x191ff]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  40ae51:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae5b:	nop    DWORD PTR [rax+rax*1+0x0]
  40ae60:	lea    r8,[rax+0x1]
  40ae64:	mov    rax,QWORD PTR [rcx+rax*8]
  40ae68:	mov    r9,r8
  40ae6b:	imul   r9,QWORD PTR [rdx+rax*8]
  40ae70:	add    rsi,r9
  40ae73:	mov    rax,r8
  40ae76:	cmp    r8,0x14
  40ae7a:	jb     40ae60 <__swc_fn_4fa09e82_000004_913db40c+0x5e0>
  40ae7c:	call   40dd00 <__swc_fn_4fa09e82_000002_1ca87929>
  40ae81:	vsubsd xmm0,xmm0,xmm6
  40ae85:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x839b]        # 413228 <__swc_rdata_base_4fa09e82+0x118>
  40ae8d:	lea    rax,[rip+0x828c]        # 413120 <__swc_rdata_base_4fa09e82+0x10>
  40ae94:	sub    rsp,0x88
  40ae9b:	mov    rcx,rsp
  40ae9e:	vmovups xmm1,XMMWORD PTR [rip+0x8362]        # 413208 <__swc_rdata_base_4fa09e82+0xf8>
  40aea6:	vmovups XMMWORD PTR [rcx],xmm1
  40aeaa:	mov    QWORD PTR [rcx+0x30],rsp
  40aeae:	lea    rdx,[rip+0x827b]        # 413130 <__swc_rdata_base_4fa09e82+0x20>
  40aeb5:	mov    QWORD PTR [rcx+0x38],rdx
  40aeb9:	mov    QWORD PTR [rcx+0x10],rsi
  40aebd:	lea    r8,[rsp+0x10]
  40aec2:	mov    QWORD PTR [rcx+0x40],r8
  40aec6:	lea    r8,[rip+0x82ab]        # 413178 <__swc_rdata_base_4fa09e82+0x68>
  40aecd:	mov    QWORD PTR [rcx+0x48],r8
  40aed1:	vmovups xmm1,XMMWORD PTR [rip+0x833f]        # 413218 <__swc_rdata_base_4fa09e82+0x108>
  40aed9:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40aede:	lea    r8,[rsp+0x18]
  40aee3:	mov    QWORD PTR [rcx+0x50],r8
  40aee7:	mov    QWORD PTR [rcx+0x58],rdx
  40aeeb:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40aef0:	lea    r8,[rcx+0x28]
  40aef4:	mov    QWORD PTR [rcx+0x60],r8
  40aef8:	lea    r8,[rip+0x82c1]        # 4131c0 <__swc_rdata_base_4fa09e82+0xb0>
  40aeff:	mov    QWORD PTR [rcx+0x68],r8
  40af03:	mov    QWORD PTR [rcx+0x70],rax
  40af07:	mov    QWORD PTR [rcx+0x78],rdx
  40af0b:	lea    rax,[rcx+0x30]
  40af0f:	mov    QWORD PTR [rcx+0x80],rax
  40af16:	mov    QWORD PTR [rcx+0x88],0x5
  40af21:	lea    rcx,[rcx+0x80]
  40af28:	sub    rsp,0x8
  40af2c:	call   410c40 <__swc_fn_4fa09e82_000152_6203dca2>
  40af31:	add    rsp,0xe8
  40af38:	vmovups xmm6,XMMWORD PTR [rsp]
  40af3d:	add    rsp,0x10
  40af41:	pop    r14
  40af43:	pop    r13
  40af45:	pop    r15
  40af47:	pop    r12
  40af49:	pop    rdi
  40af4a:	pop    rsi
  40af4b:	pop    rbx
  40af4c:	pop    rbp
  40af4d:	ret
