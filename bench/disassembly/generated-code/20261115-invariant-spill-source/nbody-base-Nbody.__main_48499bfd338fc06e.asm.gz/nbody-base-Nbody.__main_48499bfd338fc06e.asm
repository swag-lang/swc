
/workspace/prompt2-20261115/batch6-final-micro/base/nbody/nbody:     file format elf64-x86-64


Disassembly of section .text:

0000000000411820 <__swc_fn_6b1cf01f_000176_0ce64436>:
  411820:	push   rbp
  411821:	push   rbx
  411822:	push   rsi
  411823:	sub    rsp,0xa8
  41182a:	mov    rbp,rsp
  41182d:	vmovups XMMWORD PTR [rsp],xmm6
  411832:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  411838:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  41183e:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  411844:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  41184a:	vmovups XMMWORD PTR [rsp+0x50],xmm11
  411850:	vmovups XMMWORD PTR [rsp+0x60],xmm12
  411856:	vmovups XMMWORD PTR [rsp+0x70],xmm13
  41185c:	vmovups XMMWORD PTR [rsp+0x80],xmm14
  411865:	vmovups XMMWORD PTR [rsp+0x90],xmm15
  41186e:	sub    rsp,0x510
  411875:	mov    rbx,rsp
  411878:	lea    rax,[rip+0x2099]        # 413918 <__swc_rdata_base_6b1cf01f+0x808>
  41187f:	xor    ecx,ecx
  411881:	cs nop WORD PTR [rax+rax*1+0x0]
  41188b:	cs nop WORD PTR [rax+rax*1+0x0]
  411895:	cs nop WORD PTR [rax+rax*1+0x0]
  41189f:	nop
  4118a0:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  4118a5:	vmovdqu XMMWORD PTR [rbx+rcx*1],xmm0
  4118aa:	add    rcx,0x10
  4118ae:	cmp    rcx,0x110
  4118b5:	jne    4118a0 <__swc_fn_6b1cf01f_000176_0ce64436+0x80>
  4118b7:	mov    DWORD PTR [rbx+0x110],0x531799ac
  4118c1:	mov    DWORD PTR [rbx+0x114],0x3f60a8f3
  4118cb:	sub    rsp,0x8
  4118cf:	call   40d550 <__swc_fn_6b1cf01f_000175_1ca87929>
  4118d4:	add    rsp,0x8
  4118d8:	vmovsd QWORD PTR [rsp+0x2d0],xmm0
  4118e1:	vxorpd xmm0,xmm0,xmm0
  4118e5:	vmovups xmm2,xmm0
  4118e9:	mov    rax,rbx
  4118ec:	vmovsd xmm3,QWORD PTR [rbx+0x18]
  4118f1:	vmovsd xmm4,QWORD PTR [rbx+0x30]
  4118f6:	vmulsd xmm3,xmm3,xmm4
  4118fa:	vaddsd xmm1,xmm0,xmm3
  4118fe:	vmovsd xmm3,QWORD PTR [rbx+0x20]
  411903:	vfmadd231sd xmm2,xmm3,xmm4
  411908:	vmovsd xmm3,QWORD PTR [rbx+0x28]
  41190d:	vfmadd231sd xmm0,xmm3,xmm4
  411912:	add    rax,0x38
  411916:	vmovsd xmm3,QWORD PTR [rax+0x18]
  41191b:	vmovsd xmm4,QWORD PTR [rax+0x30]
  411920:	vfmadd231sd xmm1,xmm3,xmm4
  411925:	vmovsd xmm3,QWORD PTR [rax+0x20]
  41192a:	vfmadd231sd xmm2,xmm3,xmm4
  41192f:	vmovsd xmm3,QWORD PTR [rax+0x28]
  411934:	vfmadd231sd xmm0,xmm3,xmm4
  411939:	vmovsd xmm3,QWORD PTR [rax+0x50]
  41193e:	vmovsd xmm4,QWORD PTR [rax+0x68]
  411943:	vfmadd231sd xmm1,xmm3,xmm4
  411948:	vmovsd xmm3,QWORD PTR [rax+0x58]
  41194d:	vfmadd231sd xmm2,xmm3,xmm4
  411952:	vmovsd xmm3,QWORD PTR [rax+0x60]
  411957:	vfmadd231sd xmm0,xmm3,xmm4
  41195c:	vmovsd xmm3,QWORD PTR [rax+0x88]
  411964:	vmovsd xmm4,QWORD PTR [rax+0xa0]
  41196c:	vfmadd231sd xmm1,xmm3,xmm4
  411971:	vmovsd xmm3,QWORD PTR [rax+0x90]
  411979:	vfmadd231sd xmm2,xmm3,xmm4
  41197e:	vmovsd xmm3,QWORD PTR [rax+0x98]
  411986:	vfmadd231sd xmm0,xmm3,xmm4
  41198b:	vmovsd xmm3,QWORD PTR [rax+0xc0]
  411993:	vmovsd xmm4,QWORD PTR [rax+0xd8]
  41199b:	vfmadd231sd xmm1,xmm3,xmm4
  4119a0:	vmovsd xmm3,QWORD PTR [rax+0xc8]
  4119a8:	vfmadd231sd xmm2,xmm3,xmm4
  4119ad:	vmovsd xmm3,QWORD PTR [rax+0xd0]
  4119b5:	vfmadd231sd xmm0,xmm3,xmm4
  4119ba:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1b8e]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  4119c2:	vmovsd xmm3,QWORD PTR [rip+0x2116]        # 413ae0 <__swc_rdata_base_6b1cf01f+0x9d0>
  4119ca:	vdivsd xmm1,xmm1,xmm3
  4119ce:	vmovsd QWORD PTR [rbx+0x18],xmm1
  4119d3:	vxorpd xmm2,xmm2,XMMWORD PTR [rip+0x1b75]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  4119db:	vdivsd xmm1,xmm2,xmm3
  4119df:	vmovsd QWORD PTR [rbx+0x20],xmm1
  4119e4:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x1b64]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  4119ec:	vdivsd xmm0,xmm0,xmm3
  4119f0:	vmovsd QWORD PTR [rbx+0x28],xmm0
  4119f5:	xor    eax,eax
  4119f7:	vmovsd xmm0,QWORD PTR [rip+0x20ea]        # 413ae9 <__swc_rdata_base_6b1cf01f+0x9d9>
  4119ff:	vpshufd xmm1,xmm0,0x44
  411a04:	vmovups XMMWORD PTR [rsp+0x2e0],xmm1
  411a0d:	vpunpcklqdq xmm2,xmm0,xmm0
  411a11:	vmovups XMMWORD PTR [rsp+0x2f0],xmm2
  411a1a:	vmovdqu xmm3,XMMWORD PTR [rsp]
  411a1f:	vmovdqu xmm4,XMMWORD PTR [rsp+0x18]
  411a25:	vmovdqu xmm5,XMMWORD PTR [rsp+0x38]
  411a2b:	vmovups XMMWORD PTR [rsp+0x320],xmm5
  411a34:	vmovdqu xmm7,XMMWORD PTR [rsp+0x50]
  411a3a:	vmovdqu xmm8,XMMWORD PTR [rsp+0x70]
  411a40:	vmovups XMMWORD PTR [rsp+0x340],xmm8
  411a49:	vmovdqu xmm9,XMMWORD PTR [rsp+0x88]
  411a52:	vmovdqu xmm10,XMMWORD PTR [rsp+0xa8]
  411a5b:	vmovups XMMWORD PTR [rsp+0x350],xmm10
  411a64:	vmovdqu xmm11,XMMWORD PTR [rsp+0xc0]
  411a6d:	vmovdqu xmm12,XMMWORD PTR [rsp+0xe0]
  411a76:	vmovups XMMWORD PTR [rsp+0x360],xmm11
  411a7f:	vmovups XMMWORD PTR [rsp+0x370],xmm12
  411a88:	vmovdqu xmm13,XMMWORD PTR [rsp+0xf8]
  411a91:	mov    rcx,QWORD PTR [rsp+0x68]
  411a96:	mov    rdx,QWORD PTR [rsp+0x30]
  411a9b:	mov    r8,QWORD PTR [rsp+0xa0]
  411aa3:	mov    r9,QWORD PTR [rsp+0xd8]
  411aab:	mov    r10,QWORD PTR [rsp+0x110]
  411ab3:	jmp    411b04 <__swc_fn_6b1cf01f_000176_0ce64436+0x2e4>
  411ab5:	cs nop WORD PTR [rax+rax*1+0x0]
  411abf:	nop
  411ac0:	vmovups xmm2,XMMWORD PTR [rsp+0x2f0]
  411ac9:	vmovups xmm4,XMMWORD PTR [rsp+0x310]
  411ad2:	vmovups xmm5,XMMWORD PTR [rsp+0x320]
  411adb:	vmovups xmm10,xmm13
  411ae0:	vmovups XMMWORD PTR [rsp+0x360],xmm7
  411ae9:	vmovups xmm12,xmm11
  411aee:	vmovups xmm13,xmm3
  411af2:	vmovups xmm3,XMMWORD PTR [rsp+0x300]
  411afb:	vmovups xmm7,XMMWORD PTR [rsp+0x330]
  411b04:	vsubpd xmm14,xmm3,xmm5
  411b08:	vpsrldq xmm6,xmm14,0x8
  411b0e:	vmovsd xmm15,QWORD PTR [rbx+0x10]
  411b13:	vmovsd QWORD PTR [rsp+0x390],xmm15
  411b1c:	vmovsd xmm0,QWORD PTR [rbx+0x48]
  411b21:	vmovq  rsi,xmm0
  411b26:	vsubsd xmm5,xmm15,xmm0
  411b2a:	vmulsd xmm0,xmm14,xmm14
  411b2f:	vfmadd231sd xmm0,xmm6,xmm6
  411b34:	vfmadd231sd xmm0,xmm5,xmm5
  411b39:	vsubpd xmm6,xmm3,xmm8
  411b3e:	vmulsd xmm8,xmm6,xmm6
  411b42:	vmovups XMMWORD PTR [rsp+0x380],xmm13
  411b4b:	vpsrldq xmm13,xmm6,0x8
  411b50:	vfmadd231sd xmm8,xmm13,xmm13
  411b55:	vmovsd xmm13,QWORD PTR [rbx+0x80]
  411b5d:	vmovsd QWORD PTR [rsp+0x3a0],xmm13
  411b66:	vsubsd xmm1,xmm15,xmm13
  411b6b:	vfmadd231sd xmm8,xmm1,xmm1
  411b70:	vpunpcklqdq xmm0,xmm0,xmm8
  411b75:	vsqrtpd xmm8,xmm0
  411b79:	vmulpd xmm0,xmm0,xmm8
  411b7e:	vdivpd xmm0,xmm2,xmm0
  411b82:	vpshufd xmm8,xmm0,0x44
  411b87:	vmovq  xmm13,rcx
  411b8c:	vpshufd xmm13,xmm13,0x44
  411b92:	vmulpd xmm11,xmm14,xmm13
  411b97:	vmovups XMMWORD PTR [rsp+0x3b0],xmm13
  411ba0:	vmovq  xmm13,rcx
  411ba5:	vmovsd QWORD PTR [rsp+0x3c0],xmm13
  411bae:	vfnmadd231pd xmm4,xmm11,xmm8
  411bb3:	vmulsd xmm11,xmm5,xmm13
  411bb8:	vfnmadd213sd xmm11,xmm0,QWORD PTR [rbx+0x28]
  411bbe:	vmovq  xmm13,rdx
  411bc3:	vpshufd xmm13,xmm13,0x44
  411bc9:	vmulpd xmm14,xmm14,xmm13
  411bce:	vmulpd xmm8,xmm14,xmm8
  411bd3:	vmovq  xmm14,rdx
  411bd8:	vaddpd xmm7,xmm7,xmm8
  411bdd:	vmovups XMMWORD PTR [rsp+0x3d0],xmm7
  411be6:	vmulsd xmm5,xmm5,xmm14
  411beb:	vfmadd213sd xmm5,xmm0,QWORD PTR [rbx+0x60]
  411bf1:	vmovsd QWORD PTR [rsp+0x3e0],xmm5
  411bfa:	vmulpd xmm8,xmm6,xmm13
  411bff:	vpsrldq xmm0,xmm0,0x8
  411c04:	vpshufd xmm5,xmm0,0x44
  411c09:	vmulpd xmm8,xmm8,xmm5
  411c0d:	vmovq  xmm2,r8
  411c12:	vpshufd xmm2,xmm2,0x44
  411c17:	vmulpd xmm6,xmm6,xmm2
  411c1b:	vfnmadd231pd xmm4,xmm6,xmm5
  411c20:	vmovq  xmm5,r8
  411c25:	vmovq  r11,xmm5
  411c2a:	vmulsd xmm6,xmm1,xmm5
  411c2e:	vfnmadd213sd xmm6,xmm0,xmm11
  411c33:	vaddpd xmm8,xmm9,xmm8
  411c38:	vmovups XMMWORD PTR [rsp+0x410],xmm8
  411c41:	vmulsd xmm1,xmm1,xmm14
  411c46:	vmulsd xmm0,xmm1,xmm0
  411c4a:	vaddsd xmm0,xmm0,QWORD PTR [rbx+0x98]
  411c52:	vmovsd QWORD PTR [rsp+0x420],xmm0
  411c5b:	vsubpd xmm1,xmm3,xmm10
  411c60:	vmulpd xmm9,xmm1,xmm13
  411c65:	vpsrldq xmm0,xmm1,0x8
  411c6a:	vmovsd xmm11,QWORD PTR [rbx+0xb8]
  411c72:	vmovsd QWORD PTR [rsp+0x428],xmm11
  411c7b:	vsubsd xmm5,xmm15,xmm11
  411c80:	vmulsd xmm8,xmm1,xmm1
  411c84:	vfmadd213sd xmm0,xmm0,xmm8
  411c89:	vfmadd231sd xmm0,xmm5,xmm5
  411c8e:	vsubpd xmm8,xmm3,xmm12
  411c93:	vmulsd xmm12,xmm8,xmm8
  411c98:	vpsrldq xmm7,xmm8,0x8
  411c9e:	vmulsd xmm7,xmm7,xmm7
  411ca2:	vaddsd xmm7,xmm12,xmm7
  411ca6:	vmovsd xmm12,QWORD PTR [rbx+0xf0]
  411cae:	vmovsd QWORD PTR [rsp+0x430],xmm12
  411cb7:	vsubsd xmm11,xmm15,xmm12
  411cbc:	vfmadd231sd xmm7,xmm11,xmm11
  411cc1:	vpunpcklqdq xmm0,xmm0,xmm7
  411cc5:	vsqrtpd xmm7,xmm0
  411cc9:	vmulpd xmm0,xmm0,xmm7
  411ccd:	vmovups xmm15,XMMWORD PTR [rsp+0x2f0]
  411cd6:	vdivpd xmm0,xmm15,xmm0
  411cda:	vpshufd xmm7,xmm0,0x44
  411cdf:	vmulpd xmm9,xmm9,xmm7
  411ce3:	vmovq  xmm12,r9
  411ce8:	vpshufd xmm12,xmm12,0x44
  411cee:	vmulpd xmm1,xmm1,xmm12
  411cf3:	vfnmadd213pd xmm1,xmm7,xmm4
  411cf8:	vmovq  xmm7,r9
  411cfd:	vmovsd QWORD PTR [rsp+0x450],xmm7
  411d06:	vmulsd xmm4,xmm5,xmm7
  411d0a:	vfnmadd231sd xmm6,xmm4,xmm0
  411d0f:	vaddpd xmm9,xmm9,XMMWORD PTR [rsp+0x360]
  411d18:	vmulsd xmm4,xmm5,xmm14
  411d1d:	vmovsd xmm5,QWORD PTR [rbx+0xd0]
  411d25:	vfmadd231sd xmm5,xmm4,xmm0
  411d2a:	vmovsd QWORD PTR [rsp+0x458],xmm5
  411d33:	vmulpd xmm4,xmm8,xmm13
  411d38:	vpsrldq xmm0,xmm0,0x8
  411d3d:	vpshufd xmm13,xmm0,0x44
  411d42:	vmulpd xmm4,xmm4,xmm13
  411d47:	vmovq  xmm5,r10
  411d4c:	vpshufd xmm5,xmm5,0x44
  411d51:	vmovups XMMWORD PTR [rsp+0x460],xmm5
  411d5a:	vmulpd xmm8,xmm8,xmm5
  411d5e:	vmulpd xmm8,xmm8,xmm13
  411d63:	vmovups xmm13,xmm4
  411d67:	vsubpd xmm4,xmm1,xmm8
  411d6c:	vfmadd231pd xmm3,xmm4,XMMWORD PTR [rsp+0x2e0]
  411d76:	vmovq  xmm8,r10
  411d7b:	vmovups XMMWORD PTR [rsp+0x300],xmm3
  411d84:	vmovsd QWORD PTR [rsp+0x470],xmm8
  411d8d:	vaddpd xmm3,xmm13,XMMWORD PTR [rsp+0x380]
  411d96:	vmovups XMMWORD PTR [rsp+0x480],xmm3
  411d9f:	vmulsd xmm13,xmm11,xmm8
  411da4:	vfnmadd231sd xmm6,xmm13,xmm0
  411da9:	vmovsd QWORD PTR [rbx+0x28],xmm6
  411dae:	vmulsd xmm11,xmm11,xmm14
  411db3:	vmulsd xmm0,xmm11,xmm0
  411db7:	vaddsd xmm0,xmm0,QWORD PTR [rbx+0x108]
  411dbf:	vmovups xmm13,XMMWORD PTR [rsp+0x320]
  411dc8:	vmovsd QWORD PTR [rsp+0x498],xmm0
  411dd1:	vsubpd xmm14,xmm13,XMMWORD PTR [rsp+0x340]
  411dda:	vmovups XMMWORD PTR [rsp+0x310],xmm4
  411de3:	vmulpd xmm4,xmm14,xmm2
  411de7:	vmovups xmm6,XMMWORD PTR [rsp+0x3b0]
  411df0:	vmovups XMMWORD PTR [rsp+0x3f0],xmm2
  411df9:	vmulpd xmm2,xmm14,xmm6
  411dfd:	vpsrldq xmm8,xmm14,0x8
  411e03:	vmovq  xmm0,rsi
  411e08:	vsubsd xmm1,xmm0,QWORD PTR [rsp+0x3a0]
  411e11:	vmulsd xmm3,xmm14,xmm14
  411e16:	vfmadd231sd xmm3,xmm8,xmm8
  411e1b:	vfmadd231sd xmm3,xmm1,xmm1
  411e20:	vsubpd xmm8,xmm13,xmm10
  411e25:	vmulsd xmm14,xmm8,xmm8
  411e2a:	vpsrldq xmm10,xmm8,0x8
  411e30:	vmulsd xmm10,xmm10,xmm10
  411e35:	vaddsd xmm10,xmm14,xmm10
  411e3a:	vsubsd xmm11,xmm0,QWORD PTR [rsp+0x428]
  411e43:	vfmadd231sd xmm10,xmm11,xmm11
  411e48:	vpunpcklqdq xmm3,xmm3,xmm10
  411e4d:	vsqrtpd xmm10,xmm3
  411e51:	vmulpd xmm3,xmm3,xmm10
  411e56:	vdivpd xmm3,xmm15,xmm3
  411e5a:	vpshufd xmm10,xmm3,0x44
  411e5f:	vfnmadd213pd xmm4,xmm10,XMMWORD PTR [rsp+0x3d0]
  411e69:	vmulpd xmm2,xmm2,xmm10
  411e6e:	vaddpd xmm2,xmm2,XMMWORD PTR [rsp+0x410]
  411e77:	vmovq  xmm10,r11
  411e7c:	vmovups XMMWORD PTR [rsp+0x4a0],xmm2
  411e85:	vmulsd xmm14,xmm1,xmm10
  411e8a:	vmovsd xmm10,QWORD PTR [rsp+0x3e0]
  411e93:	vfnmadd231sd xmm10,xmm14,xmm3
  411e98:	vmovsd xmm14,QWORD PTR [rsp+0x3c0]
  411ea1:	vmulsd xmm1,xmm1,xmm14
  411ea6:	vfmadd213sd xmm1,xmm3,QWORD PTR [rsp+0x420]
  411eb0:	vmovsd QWORD PTR [rsp+0x4b0],xmm1
  411eb9:	vmulpd xmm2,xmm8,xmm12
  411ebe:	vmulpd xmm8,xmm8,xmm6
  411ec2:	vpsrldq xmm3,xmm3,0x8
  411ec7:	vpshufd xmm1,xmm3,0x44
  411ecc:	vfnmadd213pd xmm2,xmm1,xmm4
  411ed1:	vfmadd213pd xmm1,xmm8,xmm9
  411ed6:	vmulsd xmm4,xmm11,xmm7
  411eda:	vfnmadd213sd xmm4,xmm3,xmm10
  411edf:	vmulsd xmm8,xmm11,xmm14
  411ee4:	vmulsd xmm3,xmm8,xmm3
  411ee8:	vaddsd xmm3,xmm3,QWORD PTR [rsp+0x458]
  411ef1:	vmovsd QWORD PTR [rsp+0x4b8],xmm3
  411efa:	vsubpd xmm9,xmm13,XMMWORD PTR [rsp+0x370]
  411f03:	vmulpd xmm10,xmm9,xmm5
  411f07:	vmulpd xmm6,xmm9,xmm6
  411f0b:	vpsrldq xmm7,xmm9,0x8
  411f11:	vsubsd xmm5,xmm0,QWORD PTR [rsp+0x430]
  411f1a:	vmulsd xmm0,xmm9,xmm9
  411f1f:	vfmadd231sd xmm0,xmm7,xmm7
  411f24:	vfmadd231sd xmm0,xmm5,xmm5
  411f29:	vmovups xmm9,XMMWORD PTR [rsp+0x340]
  411f32:	vsubpd xmm11,xmm9,XMMWORD PTR [rsp+0x350]
  411f3b:	vmulsd xmm7,xmm11,xmm11
  411f40:	vpsrldq xmm8,xmm11,0x8
  411f46:	vfmadd231sd xmm7,xmm8,xmm8
  411f4b:	vmovsd xmm8,QWORD PTR [rsp+0x3a0]
  411f54:	vsubsd xmm3,xmm8,QWORD PTR [rsp+0x428]
  411f5d:	vfmadd231sd xmm7,xmm3,xmm3
  411f62:	vpunpcklqdq xmm0,xmm0,xmm7
  411f66:	vsqrtpd xmm7,xmm0
  411f6a:	vmulpd xmm0,xmm0,xmm7
  411f6e:	vdivpd xmm0,xmm15,xmm0
  411f72:	vpshufd xmm9,xmm0,0x44
  411f77:	vmulpd xmm7,xmm10,xmm9
  411f7c:	vmovsd xmm15,QWORD PTR [rsp+0x450]
  411f85:	vsubpd xmm7,xmm2,xmm7
  411f89:	vmovups xmm2,XMMWORD PTR [rsp+0x2e0]
  411f92:	vfmadd231pd xmm13,xmm7,xmm2
  411f97:	vmovups XMMWORD PTR [rsp+0x320],xmm13
  411fa0:	vmulpd xmm6,xmm6,xmm9
  411fa5:	vaddpd xmm6,xmm6,XMMWORD PTR [rsp+0x480]
  411fae:	vmovsd xmm10,QWORD PTR [rsp+0x470]
  411fb7:	vmulsd xmm9,xmm5,xmm10
  411fbc:	vfnmadd231sd xmm4,xmm9,xmm0
  411fc1:	vmovsd QWORD PTR [rbx+0x60],xmm4
  411fc6:	vmulsd xmm5,xmm5,xmm14
  411fcb:	vfmadd213sd xmm5,xmm0,QWORD PTR [rsp+0x498]
  411fd5:	vmulpd xmm9,xmm11,xmm12
  411fda:	vmovups xmm14,XMMWORD PTR [rsp+0x3f0]
  411fe3:	vmulpd xmm11,xmm11,xmm14
  411fe8:	vpsrldq xmm0,xmm0,0x8
  411fed:	vpshufd xmm13,xmm0,0x44
  411ff2:	vmovups XMMWORD PTR [rsp+0x330],xmm7
  411ffb:	vmovups xmm7,XMMWORD PTR [rsp+0x4a0]
  412004:	vfnmadd231pd xmm7,xmm9,xmm13
  412009:	vfmadd231pd xmm1,xmm11,xmm13
  41200e:	vmovups XMMWORD PTR [rsp+0x4d0],xmm1
  412017:	vmulsd xmm9,xmm3,xmm15
  41201c:	vmovsd xmm11,QWORD PTR [rsp+0x4b0]
  412025:	vfnmadd231sd xmm11,xmm9,xmm0
  41202a:	vmovq  xmm13,r11
  41202f:	vmulsd xmm3,xmm3,xmm13
  412034:	vmulsd xmm0,xmm3,xmm0
  412038:	vaddsd xmm0,xmm0,QWORD PTR [rsp+0x4b8]
  412041:	vmovups xmm9,XMMWORD PTR [rsp+0x340]
  41204a:	vmovups xmm3,XMMWORD PTR [rsp+0x370]
  412053:	vmovsd QWORD PTR [rsp+0x4e0],xmm0
  41205c:	vsubpd xmm4,xmm9,xmm3
  412060:	vmulpd xmm15,xmm4,XMMWORD PTR [rsp+0x460]
  412069:	vmulpd xmm14,xmm4,xmm14
  41206e:	vpsrldq xmm0,xmm4,0x8
  412073:	vmovsd xmm9,QWORD PTR [rsp+0x430]
  41207c:	vsubsd xmm1,xmm8,xmm9
  412081:	vmulsd xmm4,xmm4,xmm4
  412085:	vfmadd213sd xmm0,xmm0,xmm4
  41208a:	vfmadd231sd xmm0,xmm1,xmm1
  41208f:	vmovups xmm4,XMMWORD PTR [rsp+0x350]
  412098:	vsubpd xmm8,xmm4,xmm3
  41209c:	vmovups XMMWORD PTR [rsp+0x4f0],xmm8
  4120a5:	vmulsd xmm3,xmm8,xmm8
  4120aa:	vpsrldq xmm4,xmm8,0x8
  4120b0:	vfmadd231sd xmm3,xmm4,xmm4
  4120b5:	vmovsd xmm4,QWORD PTR [rsp+0x428]
  4120be:	vmovups XMMWORD PTR [rsp+0x440],xmm12
  4120c7:	vsubsd xmm12,xmm4,xmm9
  4120cc:	vmovsd QWORD PTR [rsp+0x500],xmm12
  4120d5:	vfmadd231sd xmm3,xmm12,xmm12
  4120da:	vpunpcklqdq xmm0,xmm0,xmm3
  4120de:	vsqrtpd xmm3,xmm0
  4120e2:	vmulpd xmm0,xmm0,xmm3
  4120e6:	vmovups xmm4,XMMWORD PTR [rsp+0x2f0]
  4120ef:	vdivpd xmm0,xmm4,xmm0
  4120f3:	vpshufd xmm3,xmm0,0x44
  4120f8:	vmulpd xmm15,xmm15,xmm3
  4120fc:	vmovups xmm8,XMMWORD PTR [rsp+0x340]
  412105:	vmovups xmm4,xmm9
  41210a:	vmovups xmm12,XMMWORD PTR [rsp+0x460]
  412113:	vsubpd xmm9,xmm7,xmm15
  412118:	vfmadd231pd xmm8,xmm9,xmm2
  41211d:	vmovups XMMWORD PTR [rsp+0x340],xmm8
  412126:	vfmadd213pd xmm3,xmm14,xmm6
  41212b:	vmulsd xmm6,xmm1,xmm10
  412130:	vfnmadd213sd xmm6,xmm0,xmm11
  412135:	vmovsd QWORD PTR [rbx+0x98],xmm6
  41213d:	vmulsd xmm1,xmm1,xmm13
  412142:	vfmadd213sd xmm1,xmm0,xmm5
  412147:	vmovups xmm5,XMMWORD PTR [rsp+0x4f0]
  412150:	vmulpd xmm7,xmm5,xmm12
  412155:	vmulpd xmm5,xmm5,XMMWORD PTR [rsp+0x440]
  41215e:	vpsrldq xmm0,xmm0,0x8
  412163:	vpshufd xmm11,xmm0,0x44
  412168:	vfnmadd213pd xmm7,xmm11,XMMWORD PTR [rsp+0x4d0]
  412172:	vmovups xmm13,XMMWORD PTR [rsp+0x350]
  41217b:	vfmadd231pd xmm13,xmm7,xmm2
  412180:	vmovups XMMWORD PTR [rsp+0x350],xmm13
  412189:	vmulpd xmm5,xmm5,xmm11
  41218e:	vmovups xmm11,XMMWORD PTR [rsp+0x370]
  412197:	vmovsd xmm12,QWORD PTR [rsp+0x3a0]
  4121a0:	vaddpd xmm3,xmm3,xmm5
  4121a4:	vfmadd231pd xmm11,xmm3,xmm2
  4121a9:	vmovsd xmm5,QWORD PTR [rsp+0x500]
  4121b2:	vmovups XMMWORD PTR [rsp+0x370],xmm11
  4121bb:	vmulsd xmm10,xmm5,xmm10
  4121c0:	vfnmadd213sd xmm10,xmm0,QWORD PTR [rsp+0x4e0]
  4121ca:	vmovsd QWORD PTR [rbx+0xd0],xmm10
  4121d2:	vmulsd xmm5,xmm5,QWORD PTR [rsp+0x450]
  4121db:	vfmadd213sd xmm0,xmm5,xmm1
  4121e0:	vmovsd QWORD PTR [rbx+0x108],xmm0
  4121e8:	vmovsd xmm5,QWORD PTR [rip+0x18f9]        # 413ae9 <__swc_rdata_base_6b1cf01f+0x9d9>
  4121f0:	vmovsd xmm1,QWORD PTR [rbx+0x28]
  4121f5:	vfmadd213sd xmm1,xmm5,QWORD PTR [rsp+0x390]
  4121ff:	vmovsd QWORD PTR [rbx+0x10],xmm1
  412204:	vmovsd xmm1,QWORD PTR [rbx+0x60]
  412209:	vmovq  xmm14,rsi
  41220e:	vfmadd213sd xmm1,xmm5,xmm14
  412213:	vmovsd QWORD PTR [rbx+0x48],xmm1
  412218:	vmulsd xmm1,xmm6,xmm5
  41221c:	vaddsd xmm1,xmm12,xmm1
  412220:	vmovsd QWORD PTR [rbx+0x80],xmm1
  412228:	vmulsd xmm1,xmm10,xmm5
  41222c:	vaddsd xmm1,xmm1,QWORD PTR [rsp+0x428]
  412235:	vmovsd QWORD PTR [rbx+0xb8],xmm1
  41223d:	vfmadd213sd xmm0,xmm5,xmm4
  412242:	vmovsd QWORD PTR [rbx+0xf0],xmm0
  41224a:	add    rax,0x1
  41224e:	cmp    rax,0x7a120
  412255:	jl     411ac0 <__swc_fn_6b1cf01f_000176_0ce64436+0x2a0>
  41225b:	vmovdqu XMMWORD PTR [rsp+0xa8],xmm13
  412264:	vmovdqu XMMWORD PTR [rsp+0xc0],xmm7
  41226d:	vmovdqu XMMWORD PTR [rsp+0xe0],xmm11
  412276:	vmovdqu XMMWORD PTR [rsp+0xf8],xmm3
  41227f:	vmovups xmm3,XMMWORD PTR [rsp+0x300]
  412288:	vmovdqu XMMWORD PTR [rsp],xmm3
  41228d:	vmovups xmm4,XMMWORD PTR [rsp+0x310]
  412296:	vmovdqu XMMWORD PTR [rsp+0x18],xmm4
  41229c:	vmovups xmm13,XMMWORD PTR [rsp+0x320]
  4122a5:	vmovdqu XMMWORD PTR [rsp+0x38],xmm13
  4122ab:	vmovups xmm7,XMMWORD PTR [rsp+0x330]
  4122b4:	vmovdqu XMMWORD PTR [rsp+0x50],xmm7
  4122ba:	vmovdqu XMMWORD PTR [rsp+0x70],xmm8
  4122c0:	vmovdqu XMMWORD PTR [rsp+0x88],xmm9
  4122c9:	mov    QWORD PTR [rbx+0x258],0x5
  4122d4:	vxorpd xmm0,xmm0,xmm0
  4122d8:	vmovsd xmm1,QWORD PTR [rip+0x12d4]        # 4135b4 <__swc_rdata_base_6b1cf01f+0x4a4>
  4122e0:	vmovsd xmm3,QWORD PTR [rbx+0x30]
  4122e5:	vmulsd xmm2,xmm1,xmm3
  4122e9:	vmovsd xmm4,QWORD PTR [rbx+0x18]
  4122ee:	vmulsd xmm4,xmm4,xmm4
  4122f2:	vmovsd xmm5,QWORD PTR [rbx+0x20]
  4122f7:	vfmadd231sd xmm4,xmm5,xmm5
  4122fc:	vmovsd xmm5,QWORD PTR [rbx+0x28]
  412301:	vfmadd231sd xmm4,xmm5,xmm5
  412306:	vfmadd231sd xmm0,xmm2,xmm4
  41230b:	vmovsd xmm2,QWORD PTR [rbx]
  41230f:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x38]
  412314:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  412319:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x40]
  41231e:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  412323:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x48]
  412328:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x68]
  41232d:	vmulsd xmm2,xmm2,xmm2
  412331:	vfmadd231sd xmm2,xmm4,xmm4
  412336:	vfmadd231sd xmm2,xmm5,xmm5
  41233b:	vsqrtsd xmm2,xmm2,xmm2
  41233f:	vdivsd xmm2,xmm9,xmm2
  412343:	vsubsd xmm0,xmm0,xmm2
  412347:	vmovsd xmm2,QWORD PTR [rbx]
  41234b:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x70]
  412350:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  412355:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x78]
  41235a:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  41235f:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x80]
  412367:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xa0]
  41236f:	vmulsd xmm2,xmm2,xmm2
  412373:	vfmadd231sd xmm2,xmm4,xmm4
  412378:	vfmadd231sd xmm2,xmm5,xmm5
  41237d:	vsqrtsd xmm2,xmm2,xmm2
  412381:	vdivsd xmm2,xmm9,xmm2
  412385:	vsubsd xmm0,xmm0,xmm2
  412389:	vmovsd xmm2,QWORD PTR [rbx]
  41238d:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  412395:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  41239a:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  4123a2:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  4123a7:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  4123af:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  4123b7:	vmulsd xmm2,xmm2,xmm2
  4123bb:	vfmadd231sd xmm2,xmm4,xmm4
  4123c0:	vfmadd231sd xmm2,xmm5,xmm5
  4123c5:	vsqrtsd xmm2,xmm2,xmm2
  4123c9:	vdivsd xmm2,xmm9,xmm2
  4123cd:	vsubsd xmm0,xmm0,xmm2
  4123d1:	vmovsd xmm2,QWORD PTR [rbx]
  4123d5:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xe0]
  4123dd:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  4123e2:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xe8]
  4123ea:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  4123ef:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xf0]
  4123f7:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x110]
  4123ff:	vmulsd xmm2,xmm2,xmm2
  412403:	vfmadd231sd xmm2,xmm4,xmm4
  412408:	vfmadd231sd xmm2,xmm5,xmm5
  41240d:	vsqrtsd xmm2,xmm2,xmm2
  412411:	vdivsd xmm2,xmm9,xmm2
  412415:	vsubsd xmm0,xmm0,xmm2
  412419:	vmovsd xmm3,QWORD PTR [rbx+0x68]
  41241e:	vmulsd xmm2,xmm1,xmm3
  412422:	vmovsd xmm4,QWORD PTR [rbx+0x50]
  412427:	vmulsd xmm4,xmm4,xmm4
  41242b:	vmovsd xmm5,QWORD PTR [rbx+0x58]
  412430:	vfmadd231sd xmm4,xmm5,xmm5
  412435:	vmovsd xmm5,QWORD PTR [rbx+0x60]
  41243a:	vfmadd231sd xmm4,xmm5,xmm5
  41243f:	vfmadd231sd xmm0,xmm2,xmm4
  412444:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  412449:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x70]
  41244e:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  412453:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x78]
  412458:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  41245d:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x80]
  412465:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xa0]
  41246d:	vmulsd xmm2,xmm2,xmm2
  412471:	vfmadd231sd xmm2,xmm4,xmm4
  412476:	vfmadd231sd xmm2,xmm5,xmm5
  41247b:	vsqrtsd xmm2,xmm2,xmm2
  41247f:	vdivsd xmm2,xmm9,xmm2
  412483:	vsubsd xmm0,xmm0,xmm2
  412487:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  41248c:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  412494:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  412499:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  4124a1:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  4124a6:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  4124ae:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  4124b6:	vmulsd xmm2,xmm2,xmm2
  4124ba:	vfmadd231sd xmm2,xmm4,xmm4
  4124bf:	vfmadd231sd xmm2,xmm5,xmm5
  4124c4:	vsqrtsd xmm2,xmm2,xmm2
  4124c8:	vdivsd xmm2,xmm9,xmm2
  4124cc:	vsubsd xmm0,xmm0,xmm2
  4124d0:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  4124d5:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xe0]
  4124dd:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  4124e2:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xe8]
  4124ea:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  4124ef:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xf0]
  4124f7:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x110]
  4124ff:	vmulsd xmm2,xmm2,xmm2
  412503:	vfmadd231sd xmm2,xmm4,xmm4
  412508:	vfmadd231sd xmm2,xmm5,xmm5
  41250d:	vsqrtsd xmm2,xmm2,xmm2
  412511:	vdivsd xmm2,xmm9,xmm2
  412515:	vsubsd xmm0,xmm0,xmm2
  412519:	vmovsd xmm3,QWORD PTR [rbx+0xa0]
  412521:	vmulsd xmm2,xmm1,xmm3
  412525:	vmovsd xmm4,QWORD PTR [rbx+0x88]
  41252d:	vmulsd xmm4,xmm4,xmm4
  412531:	vmovsd xmm5,QWORD PTR [rbx+0x90]
  412539:	vfmadd231sd xmm4,xmm5,xmm5
  41253e:	vmovsd xmm5,QWORD PTR [rbx+0x98]
  412546:	vfmadd231sd xmm4,xmm5,xmm5
  41254b:	vfmadd231sd xmm0,xmm2,xmm4
  412550:	vmovsd xmm2,QWORD PTR [rbx+0x70]
  412555:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  41255d:	vmovsd xmm4,QWORD PTR [rbx+0x78]
  412562:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  41256a:	vmovsd xmm5,QWORD PTR [rbx+0x80]
  412572:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  41257a:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  412582:	vmulsd xmm2,xmm2,xmm2
  412586:	vfmadd231sd xmm2,xmm4,xmm4
  41258b:	vfmadd231sd xmm2,xmm5,xmm5
  412590:	vsqrtsd xmm2,xmm2,xmm2
  412594:	vdivsd xmm2,xmm9,xmm2
  412598:	vsubsd xmm0,xmm0,xmm2
  41259c:	vmovsd xmm2,QWORD PTR [rbx+0x70]
  4125a1:	vmovsd xmm6,QWORD PTR [rbx+0xe0]
  4125a9:	vsubsd xmm2,xmm2,xmm6
  4125ad:	vmovsd xmm4,QWORD PTR [rbx+0x78]
  4125b2:	vmovsd xmm7,QWORD PTR [rbx+0xe8]
  4125ba:	vsubsd xmm4,xmm4,xmm7
  4125be:	vmovsd xmm5,QWORD PTR [rbx+0x80]
  4125c6:	vmovsd xmm8,QWORD PTR [rbx+0xf0]
  4125ce:	vsubsd xmm5,xmm5,xmm8
  4125d3:	vmovsd xmm10,QWORD PTR [rbx+0x110]
  4125db:	vmulsd xmm9,xmm3,xmm10
  4125e0:	vmulsd xmm2,xmm2,xmm2
  4125e4:	vfmadd231sd xmm2,xmm4,xmm4
  4125e9:	vfmadd231sd xmm2,xmm5,xmm5
  4125ee:	vsqrtsd xmm2,xmm2,xmm2
  4125f2:	vdivsd xmm2,xmm9,xmm2
  4125f6:	vsubsd xmm0,xmm0,xmm2
  4125fa:	vmovsd xmm3,QWORD PTR [rbx+0xd8]
  412602:	vmulsd xmm2,xmm1,xmm3
  412606:	vmovsd xmm4,QWORD PTR [rbx+0xc0]
  41260e:	vmulsd xmm4,xmm4,xmm4
  412612:	vmovsd xmm5,QWORD PTR [rbx+0xc8]
  41261a:	vfmadd231sd xmm4,xmm5,xmm5
  41261f:	vmovsd xmm5,QWORD PTR [rbx+0xd0]
  412627:	vfmadd231sd xmm4,xmm5,xmm5
  41262c:	vfmadd231sd xmm0,xmm2,xmm4
  412631:	vmovsd xmm2,QWORD PTR [rbx+0xa8]
  412639:	vsubsd xmm2,xmm2,xmm6
  41263d:	vmovsd xmm4,QWORD PTR [rbx+0xb0]
  412645:	vsubsd xmm4,xmm4,xmm7
  412649:	vmovsd xmm5,QWORD PTR [rbx+0xb8]
  412651:	vsubsd xmm5,xmm5,xmm8
  412656:	vmulsd xmm9,xmm3,xmm10
  41265b:	vmulsd xmm2,xmm2,xmm2
  41265f:	vfmadd231sd xmm2,xmm4,xmm4
  412664:	vfmadd231sd xmm2,xmm5,xmm5
  412669:	vsqrtsd xmm2,xmm2,xmm2
  41266d:	vdivsd xmm2,xmm9,xmm2
  412671:	vsubsd xmm0,xmm0,xmm2
  412675:	vmulsd xmm2,xmm10,xmm1
  412679:	vmovsd xmm4,QWORD PTR [rbx+0xf8]
  412681:	vmulsd xmm4,xmm4,xmm4
  412685:	vmovsd xmm5,QWORD PTR [rbx+0x100]
  41268d:	vfmadd231sd xmm4,xmm5,xmm5
  412692:	vmovsd xmm5,QWORD PTR [rbx+0x108]
  41269a:	vfmadd231sd xmm4,xmm5,xmm5
  41269f:	vfmadd231sd xmm0,xmm2,xmm4
  4126a4:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0xea4]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  4126ac:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x143e]        # 413af2 <__swc_rdata_base_6b1cf01f+0x9e2>
  4126b4:	vroundsd xmm0,xmm0,xmm0,0x1
  4126ba:	vmovsd xmm1,QWORD PTR [rip+0xee0]        # 4135a2 <__swc_rdata_base_6b1cf01f+0x492>
  4126c2:	vcomisd xmm0,xmm1
  4126c6:	jb     4126e0 <__swc_fn_6b1cf01f_000176_0ce64436+0xec0>
  4126c8:	vsubsd xmm0,xmm0,xmm1
  4126cc:	vcvttsd2si rsi,xmm0
  4126d1:	movabs rax,0x8000000000000000
  4126db:	xor    rsi,rax
  4126de:	jmp    4126e5 <__swc_fn_6b1cf01f_000176_0ce64436+0xec5>
  4126e0:	vcvttsd2si rsi,xmm0
  4126e5:	sub    rsp,0x8
  4126e9:	call   40d550 <__swc_fn_6b1cf01f_000175_1ca87929>
  4126ee:	add    rsp,0x8
  4126f2:	vsubsd xmm0,xmm0,QWORD PTR [rsp+0x2d0]
  4126fb:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x13f8]        # 413afb <__swc_rdata_base_6b1cf01f+0x9eb>
  412703:	lea    rax,[rip+0xc5e]        # 413368 <__swc_rdata_base_6b1cf01f+0x258>
  41270a:	sub    rsp,0x90
  412711:	mov    rcx,rsp
  412714:	vmovups xmm1,XMMWORD PTR [rip+0x13a4]        # 413ac0 <__swc_rdata_base_6b1cf01f+0x9b0>
  41271c:	vmovups XMMWORD PTR [rcx],xmm1
  412720:	mov    QWORD PTR [rcx+0x30],rsp
  412724:	lea    rdx,[rip+0xbe5]        # 413310 <__swc_rdata_base_6b1cf01f+0x200>
  41272b:	mov    QWORD PTR [rcx+0x38],rdx
  41272f:	mov    QWORD PTR [rcx+0x10],rsi
  412733:	lea    r8,[rsp+0x10]
  412738:	mov    QWORD PTR [rcx+0x40],r8
  41273c:	lea    r8,[rip+0x12ed]        # 413a30 <__swc_rdata_base_6b1cf01f+0x920>
  412743:	mov    QWORD PTR [rcx+0x48],r8
  412747:	vmovups xmm1,XMMWORD PTR [rip+0x1381]        # 413ad0 <__swc_rdata_base_6b1cf01f+0x9c0>
  41274f:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  412754:	lea    r8,[rsp+0x18]
  412759:	mov    QWORD PTR [rcx+0x50],r8
  41275d:	mov    QWORD PTR [rcx+0x58],rdx
  412761:	vmovsd QWORD PTR [rcx+0x28],xmm0
  412766:	lea    r8,[rcx+0x28]
  41276a:	mov    QWORD PTR [rcx+0x60],r8
  41276e:	lea    r8,[rip+0x1303]        # 413a78 <__swc_rdata_base_6b1cf01f+0x968>
  412775:	mov    QWORD PTR [rcx+0x68],r8
  412779:	mov    QWORD PTR [rcx+0x70],rax
  41277d:	mov    QWORD PTR [rcx+0x78],rdx
  412781:	lea    rax,[rcx+0x30]
  412785:	mov    QWORD PTR [rcx+0x80],rax
  41278c:	mov    QWORD PTR [rcx+0x88],0x5
  412797:	lea    rcx,[rcx+0x80]
  41279e:	sub    rsp,0x8
  4127a2:	call   410140 <__swc_fn_6b1cf01f_000146_07c5dbb8>
  4127a7:	add    rsp,0x5a8
  4127ae:	vmovups xmm6,XMMWORD PTR [rsp]
  4127b3:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  4127b9:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  4127bf:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  4127c5:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  4127cb:	vmovups xmm11,XMMWORD PTR [rsp+0x50]
  4127d1:	vmovups xmm12,XMMWORD PTR [rsp+0x60]
  4127d7:	vmovups xmm13,XMMWORD PTR [rsp+0x70]
  4127dd:	vmovups xmm14,XMMWORD PTR [rsp+0x80]
  4127e6:	vmovups xmm15,XMMWORD PTR [rsp+0x90]
  4127ef:	add    rsp,0xa8
  4127f6:	pop    rsi
  4127f7:	pop    rbx
  4127f8:	pop    rbp
  4127f9:	ret
