
/workspace/prompt2-20261115/batch5-final-micro/base/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

000000000040a140 <__swc_fn_4fa09e82_000147_4dba8c3c>:
  40a140:	push   rbx
  40a141:	push   rsi
  40a142:	push   rdi
  40a143:	push   r12
  40a145:	push   r13
  40a147:	push   r15
  40a149:	sub    rsp,0x4e8
  40a150:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  40a159:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  40a162:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  40a16b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  40a174:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  40a17d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  40a186:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  40a18f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  40a198:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  40a1a1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  40a1aa:	mov    rbx,QWORD PTR [rcx]
  40a1ad:	mov    rcx,QWORD PTR [rcx+0x8]
  40a1b1:	mov    rsi,rcx
  40a1b4:	xor    edi,edi
  40a1b6:	vmovsd xmm6,QWORD PTR [rip+0x93d2]        # 413590 <__swc_rdata_base_4fa09e82+0x480>
  40a1be:	vmovsd xmm7,QWORD PTR [rip+0x93d3]        # 413599 <__swc_rdata_base_4fa09e82+0x489>
  40a1c6:	vmovsd xmm8,QWORD PTR [rip+0x93d4]        # 4135a2 <__swc_rdata_base_4fa09e82+0x492>
  40a1ce:	vmovsd xmm9,QWORD PTR [rip+0x93d5]        # 4135ab <__swc_rdata_base_4fa09e82+0x49b>
  40a1d6:	vmovsd xmm10,QWORD PTR [rip+0x93d6]        # 4135b4 <__swc_rdata_base_4fa09e82+0x4a4>
  40a1de:	vmovups xmm11,xmm6
  40a1e2:	vmovsd QWORD PTR [rsp+0x418],xmm7
  40a1eb:	vmovsd QWORD PTR [rsp+0x420],xmm8
  40a1f4:	vmovsd QWORD PTR [rsp+0x428],xmm9
  40a1fd:	vmovsd QWORD PTR [rsp+0x430],xmm10
  40a206:	vmovsd xmm15,QWORD PTR [rip+0x93af]        # 4135bd <__swc_rdata_base_4fa09e82+0x4ad>
  40a20e:	vmovups xmm14,xmm15
  40a213:	vmovups xmm0,xmm9
  40a218:	vmovsd QWORD PTR [rsp+0x438],xmm15
  40a221:	vmovups xmm13,xmm8
  40a226:	vmovsd QWORD PTR [rsp+0x440],xmm15
  40a22f:	test   rsi,rsi
  40a232:	je     40b263 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1123>
  40a238:	cs nop WORD PTR [rax+rax*1+0x0]
  40a242:	cs nop WORD PTR [rax+rax*1+0x0]
  40a24c:	nop    DWORD PTR [rax+0x0]
  40a250:	lea    rcx,[rdi+rdi*1]
  40a254:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  40a259:	vpshufd xmm3,xmm2,0xee
  40a25e:	vmovq  rcx,xmm3
  40a263:	test   rcx,rcx
  40a266:	je     40a27c <__swc_fn_4fa09e82_000147_4dba8c3c+0x13c>
  40a268:	test   DWORD PTR [rcx+0x28],0x400000
  40a26f:	je     40a27c <__swc_fn_4fa09e82_000147_4dba8c3c+0x13c>
  40a271:	mov    rdx,QWORD PTR [rcx+0x30]
  40a275:	test   rdx,rdx
  40a278:	cmovne rcx,rdx
  40a27c:	test   DWORD PTR [rcx+0x28],0x1000
  40a283:	je     40a2a4 <__swc_fn_4fa09e82_000147_4dba8c3c+0x164>
  40a285:	mov    rdx,QWORD PTR [rcx+0x40]
  40a289:	mov    rcx,rdx
  40a28c:	vmovq  r8,xmm2
  40a291:	mov    r8,QWORD PTR [r8]
  40a294:	mov    QWORD PTR [rsp+0x60],r8
  40a299:	mov    QWORD PTR [rsp+0x68],rdx
  40a29e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  40a2a4:	test   BYTE PTR [rcx+0x28],0x1
  40a2a8:	jne    40a2b0 <__swc_fn_4fa09e82_000147_4dba8c3c+0x170>
  40a2aa:	vmovups xmm12,xmm0
  40a2ae:	jmp    40a2ca <__swc_fn_4fa09e82_000147_4dba8c3c+0x18a>
  40a2b0:	vmovq  rax,xmm2
  40a2b5:	mov    rax,QWORD PTR [rax]
  40a2b8:	lea    rcx,[rax+0x10]
  40a2bc:	vmovups xmm12,xmm0
  40a2c0:	call   4098c0 <__swc_fn_4fa09e82_000117_18ca1307>
  40a2c5:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40a2ca:	test   DWORD PTR [rcx+0x28],0x400
  40a2d1:	je     40a332 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1f2>
  40a2d3:	vmovq  rax,xmm2
  40a2d8:	mov    rax,QWORD PTR [rax]
  40a2db:	xor    ecx,ecx
  40a2dd:	test   rax,rax
  40a2e0:	je     40a310 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1d0>
  40a2e2:	mov    rdx,rax
  40a2e5:	mov    r8b,BYTE PTR [rdx]
  40a2e8:	test   r8b,r8b
  40a2eb:	je     40a310 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1d0>
  40a2ed:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2f7:	nop    WORD PTR [rax+rax*1+0x0]
  40a300:	add    rdx,0x1
  40a304:	add    rcx,0x1
  40a308:	mov    r8b,BYTE PTR [rdx]
  40a30b:	test   r8b,r8b
  40a30e:	jne    40a300 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1c0>
  40a310:	mov    QWORD PTR [rsp+0x88],rax
  40a318:	mov    QWORD PTR [rsp+0x90],rcx
  40a320:	lea    rcx,[rsp+0x88]
  40a328:	call   4098c0 <__swc_fn_4fa09e82_000117_18ca1307>
  40a32d:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40a332:	cmp    BYTE PTR [rcx+0x2c],0x6
  40a336:	jne    40a34d <__swc_fn_4fa09e82_000147_4dba8c3c+0x20d>
  40a338:	vmovq  rax,xmm2
  40a33d:	mov    rax,QWORD PTR [rax]
  40a340:	mov    rcx,rax
  40a343:	call   40ebf0 <__swc_fn_4fa09e82_000145_34d6a3dc>
  40a348:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40a34d:	cmp    BYTE PTR [rcx+0x2c],0x1
  40a351:	jne    40b239 <__swc_fn_4fa09e82_000147_4dba8c3c+0x10f9>
  40a357:	vmovq  rdx,xmm2
  40a35c:	mov    cl,BYTE PTR [rcx+0x40]
  40a35f:	cmp    cl,0x7
  40a362:	jb     40a3a5 <__swc_fn_4fa09e82_000147_4dba8c3c+0x265>
  40a364:	je     40a418 <__swc_fn_4fa09e82_000147_4dba8c3c+0x2d8>
  40a36a:	cmp    cl,0x8
  40a36d:	je     40a424 <__swc_fn_4fa09e82_000147_4dba8c3c+0x2e4>
  40a373:	cmp    cl,0x9
  40a376:	je     40a43d <__swc_fn_4fa09e82_000147_4dba8c3c+0x2fd>
  40a37c:	cmp    cl,0xa
  40a37f:	je     40ab24 <__swc_fn_4fa09e82_000147_4dba8c3c+0x9e4>
  40a385:	cmp    cl,0xb
  40a388:	je     40b20b <__swc_fn_4fa09e82_000147_4dba8c3c+0x10cb>
  40a38e:	cmp    cl,0xc
  40a391:	je     40a431 <__swc_fn_4fa09e82_000147_4dba8c3c+0x2f1>
  40a397:	cmp    cl,0xd
  40a39a:	je     40b201 <__swc_fn_4fa09e82_000147_4dba8c3c+0x10c1>
  40a3a0:	jmp    40b22b <__swc_fn_4fa09e82_000147_4dba8c3c+0x10eb>
  40a3a5:	cmp    cl,0x1
  40a3a8:	je     40a3c8 <__swc_fn_4fa09e82_000147_4dba8c3c+0x288>
  40a3aa:	cmp    cl,0x2
  40a3ad:	je     40a3d6 <__swc_fn_4fa09e82_000147_4dba8c3c+0x296>
  40a3af:	cmp    cl,0x3
  40a3b2:	je     40a3e4 <__swc_fn_4fa09e82_000147_4dba8c3c+0x2a4>
  40a3b4:	cmp    cl,0x4
  40a3b7:	je     40a3f1 <__swc_fn_4fa09e82_000147_4dba8c3c+0x2b1>
  40a3b9:	cmp    cl,0x5
  40a3bc:	je     40a3fe <__swc_fn_4fa09e82_000147_4dba8c3c+0x2be>
  40a3be:	cmp    cl,0x6
  40a3c1:	je     40a40b <__swc_fn_4fa09e82_000147_4dba8c3c+0x2cb>
  40a3c3:	jmp    40b22b <__swc_fn_4fa09e82_000147_4dba8c3c+0x10eb>
  40a3c8:	movsx  rcx,BYTE PTR [rdx]
  40a3cc:	call   411a40 <__swc_fn_4fa09e82_000146_140c84e9>
  40a3d1:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40a3d6:	movsx  rcx,WORD PTR [rdx]
  40a3da:	call   411a40 <__swc_fn_4fa09e82_000146_140c84e9>
  40a3df:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40a3e4:	movsxd rcx,DWORD PTR [rdx]
  40a3e7:	call   411a40 <__swc_fn_4fa09e82_000146_140c84e9>
  40a3ec:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40a3f1:	mov    rcx,QWORD PTR [rdx]
  40a3f4:	call   411a40 <__swc_fn_4fa09e82_000146_140c84e9>
  40a3f9:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40a3fe:	movzx  ecx,BYTE PTR [rdx]
  40a401:	call   40ebf0 <__swc_fn_4fa09e82_000145_34d6a3dc>
  40a406:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40a40b:	movzx  ecx,WORD PTR [rdx]
  40a40e:	call   40ebf0 <__swc_fn_4fa09e82_000145_34d6a3dc>
  40a413:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40a418:	mov    ecx,DWORD PTR [rdx]
  40a41a:	call   40ebf0 <__swc_fn_4fa09e82_000145_34d6a3dc>
  40a41f:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40a424:	mov    rcx,QWORD PTR [rdx]
  40a427:	call   40ebf0 <__swc_fn_4fa09e82_000145_34d6a3dc>
  40a42c:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40a431:	mov    ecx,DWORD PTR [rdx]
  40a433:	call   40ebf0 <__swc_fn_4fa09e82_000145_34d6a3dc>
  40a438:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40a43d:	lea    rcx,[rsp+0xa8]
  40a445:	vxorps xmm0,xmm0,xmm0
  40a449:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40a452:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40a45b:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  40a464:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  40a46d:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40a476:	vmovups XMMWORD PTR [rsp+0xf8],xmm0
  40a47f:	mov    DWORD PTR [rsp+0x108],0x0
  40a48a:	vxorpd xmm0,xmm0,xmm0
  40a48e:	vmovss xmm1,DWORD PTR [rdx]
  40a492:	vcvtss2sd xmm0,xmm0,xmm1
  40a496:	vmovsd xmm1,xmm1,xmm0
  40a49a:	vcomisd xmm0,xmm0
  40a49e:	setne  dl
  40a4a1:	movzx  edx,dl
  40a4a4:	setp   r8b
  40a4a8:	movzx  r8d,r8b
  40a4ac:	or     edx,r8d
  40a4af:	test   dl,dl
  40a4b1:	je     40a4be <__swc_fn_4fa09e82_000147_4dba8c3c+0x37e>
  40a4b3:	mov    DWORD PTR [rcx],0x6e616e
  40a4b9:	jmp    40aab8 <__swc_fn_4fa09e82_000147_4dba8c3c+0x978>
  40a4be:	vcomisd xmm1,xmm6
  40a4c2:	ja     40a4ca <__swc_fn_4fa09e82_000147_4dba8c3c+0x38a>
  40a4c4:	vcomisd xmm7,xmm1
  40a4c8:	jbe    40a4ee <__swc_fn_4fa09e82_000147_4dba8c3c+0x3ae>
  40a4ca:	vxorpd xmm0,xmm0,xmm0
  40a4ce:	vcomisd xmm0,xmm1
  40a4d2:	jbe    40a4e3 <__swc_fn_4fa09e82_000147_4dba8c3c+0x3a3>
  40a4d4:	mov    DWORD PTR [rcx],0x666e692d
  40a4da:	mov    BYTE PTR [rcx+0x4],0x0
  40a4de:	jmp    40aab8 <__swc_fn_4fa09e82_000147_4dba8c3c+0x978>
  40a4e3:	mov    DWORD PTR [rcx],0x666e69
  40a4e9:	jmp    40aab8 <__swc_fn_4fa09e82_000147_4dba8c3c+0x978>
  40a4ee:	vcomisd xmm1,xmm8
  40a4f3:	jae    40a4ff <__swc_fn_4fa09e82_000147_4dba8c3c+0x3bf>
  40a4f5:	vcomisd xmm9,xmm1
  40a4f9:	jbe    40a87e <__swc_fn_4fa09e82_000147_4dba8c3c+0x73e>
  40a4ff:	vmovups xmm0,xmm1
  40a503:	vxorpd xmm2,xmm2,xmm2
  40a507:	vcomisd xmm2,xmm1
  40a50b:	jbe    40a51b <__swc_fn_4fa09e82_000147_4dba8c3c+0x3db>
  40a50d:	vmovsd xmm1,xmm1,xmm0
  40a511:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x9037]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40a519:	jmp    40a51f <__swc_fn_4fa09e82_000147_4dba8c3c+0x3df>
  40a51b:	vmovsd xmm1,xmm1,xmm0
  40a51f:	xor    r8d,r8d
  40a522:	vcomisd xmm1,xmm15
  40a527:	jb     40a550 <__swc_fn_4fa09e82_000147_4dba8c3c+0x410>
  40a529:	cs nop WORD PTR [rax+rax*1+0x0]
  40a533:	cs nop WORD PTR [rax+rax*1+0x0]
  40a53d:	nop    DWORD PTR [rax]
  40a540:	vdivsd xmm1,xmm1,xmm15
  40a545:	add    r8,0x1
  40a549:	vcomisd xmm1,xmm15
  40a54e:	jae    40a540 <__swc_fn_4fa09e82_000147_4dba8c3c+0x400>
  40a550:	mov    r9,rcx
  40a553:	vxorpd xmm2,xmm2,xmm2
  40a557:	vcomisd xmm2,xmm0
  40a55b:	jbe    40a564 <__swc_fn_4fa09e82_000147_4dba8c3c+0x424>
  40a55d:	mov    BYTE PTR [rcx],0x2d
  40a560:	lea    r9,[rcx+0x1]
  40a564:	vcvttsd2si rdx,xmm1
  40a569:	mov    r10b,dl
  40a56c:	add    r10b,0x30
  40a570:	mov    BYTE PTR [r9],r10b
  40a573:	vxorpd xmm0,xmm0,xmm0
  40a577:	movzx  edx,dl
  40a57a:	vcvtsi2sd xmm0,xmm0,rdx
  40a57f:	vsubsd xmm0,xmm1,xmm0
  40a583:	vmulsd xmm1,xmm0,xmm15
  40a588:	mov    BYTE PTR [r9+0x1],0x2e
  40a58d:	vcvttsd2si rdx,xmm1
  40a592:	mov    r10b,dl
  40a595:	add    r10b,0x30
  40a599:	mov    BYTE PTR [r9+0x2],r10b
  40a59d:	vxorpd xmm0,xmm0,xmm0
  40a5a1:	movzx  edx,dl
  40a5a4:	vcvtsi2sd xmm0,xmm0,rdx
  40a5a9:	vsubsd xmm0,xmm1,xmm0
  40a5ad:	vmulsd xmm1,xmm0,xmm15
  40a5b2:	vcvttsd2si rdx,xmm1
  40a5b7:	mov    r10b,dl
  40a5ba:	add    r10b,0x30
  40a5be:	mov    BYTE PTR [r9+0x3],r10b
  40a5c2:	vxorpd xmm0,xmm0,xmm0
  40a5c6:	movzx  edx,dl
  40a5c9:	vcvtsi2sd xmm0,xmm0,rdx
  40a5ce:	vsubsd xmm0,xmm1,xmm0
  40a5d2:	vmulsd xmm1,xmm0,xmm15
  40a5d7:	vcvttsd2si rdx,xmm1
  40a5dc:	mov    r10b,dl
  40a5df:	add    r10b,0x30
  40a5e3:	mov    BYTE PTR [r9+0x4],r10b
  40a5e7:	vxorpd xmm0,xmm0,xmm0
  40a5eb:	movzx  edx,dl
  40a5ee:	vcvtsi2sd xmm0,xmm0,rdx
  40a5f3:	vsubsd xmm0,xmm1,xmm0
  40a5f7:	vmulsd xmm1,xmm0,xmm15
  40a5fc:	vcvttsd2si rdx,xmm1
  40a601:	mov    r10b,dl
  40a604:	add    r10b,0x30
  40a608:	mov    BYTE PTR [r9+0x5],r10b
  40a60c:	vxorpd xmm0,xmm0,xmm0
  40a610:	movzx  edx,dl
  40a613:	vcvtsi2sd xmm0,xmm0,rdx
  40a618:	vsubsd xmm0,xmm1,xmm0
  40a61c:	vmulsd xmm1,xmm0,xmm15
  40a621:	vcvttsd2si rdx,xmm1
  40a626:	mov    r10b,dl
  40a629:	add    r10b,0x30
  40a62d:	mov    BYTE PTR [r9+0x6],r10b
  40a631:	vxorpd xmm0,xmm0,xmm0
  40a635:	movzx  edx,dl
  40a638:	vcvtsi2sd xmm0,xmm0,rdx
  40a63d:	vsubsd xmm0,xmm1,xmm0
  40a641:	vmulsd xmm1,xmm0,xmm15
  40a646:	vcvttsd2si rdx,xmm1
  40a64b:	mov    r10b,dl
  40a64e:	add    r10b,0x30
  40a652:	mov    BYTE PTR [r9+0x7],r10b
  40a656:	vxorpd xmm0,xmm0,xmm0
  40a65a:	movzx  edx,dl
  40a65d:	vcvtsi2sd xmm0,xmm0,rdx
  40a662:	vsubsd xmm0,xmm1,xmm0
  40a666:	vmulsd xmm1,xmm0,xmm15
  40a66b:	vcvttsd2si rdx,xmm1
  40a670:	mov    r10b,dl
  40a673:	add    r10b,0x30
  40a677:	mov    BYTE PTR [r9+0x8],r10b
  40a67b:	vxorpd xmm0,xmm0,xmm0
  40a67f:	movzx  edx,dl
  40a682:	vcvtsi2sd xmm0,xmm0,rdx
  40a687:	vsubsd xmm0,xmm1,xmm0
  40a68b:	vmulsd xmm1,xmm0,xmm15
  40a690:	vcvttsd2si rdx,xmm1
  40a695:	mov    r10b,dl
  40a698:	add    r10b,0x30
  40a69c:	mov    BYTE PTR [r9+0x9],r10b
  40a6a0:	vxorpd xmm0,xmm0,xmm0
  40a6a4:	movzx  edx,dl
  40a6a7:	vcvtsi2sd xmm0,xmm0,rdx
  40a6ac:	vsubsd xmm0,xmm1,xmm0
  40a6b0:	vmulsd xmm1,xmm0,xmm15
  40a6b5:	vcvttsd2si rdx,xmm1
  40a6ba:	mov    r10b,dl
  40a6bd:	add    r10b,0x30
  40a6c1:	mov    BYTE PTR [r9+0xa],r10b
  40a6c5:	vxorpd xmm0,xmm0,xmm0
  40a6c9:	movzx  edx,dl
  40a6cc:	vcvtsi2sd xmm0,xmm0,rdx
  40a6d1:	vsubsd xmm0,xmm1,xmm0
  40a6d5:	vmulsd xmm1,xmm0,xmm15
  40a6da:	vcvttsd2si rdx,xmm1
  40a6df:	mov    r10b,dl
  40a6e2:	add    r10b,0x30
  40a6e6:	mov    BYTE PTR [r9+0xb],r10b
  40a6ea:	lea    r10,[r9+0x4]
  40a6ee:	vxorpd xmm0,xmm0,xmm0
  40a6f2:	movzx  edx,dl
  40a6f5:	vcvtsi2sd xmm0,xmm0,rdx
  40a6fa:	vsubsd xmm0,xmm1,xmm0
  40a6fe:	vmulsd xmm1,xmm0,xmm15
  40a703:	vcvttsd2si rdx,xmm1
  40a708:	mov    r11b,dl
  40a70b:	add    r11b,0x30
  40a70f:	mov    BYTE PTR [r9+0xc],r11b
  40a713:	vxorpd xmm0,xmm0,xmm0
  40a717:	movzx  edx,dl
  40a71a:	vcvtsi2sd xmm0,xmm0,rdx
  40a71f:	vsubsd xmm0,xmm1,xmm0
  40a723:	vmulsd xmm1,xmm0,xmm15
  40a728:	vcvttsd2si rdx,xmm1
  40a72d:	mov    r11b,dl
  40a730:	add    r11b,0x30
  40a734:	mov    BYTE PTR [r9+0xd],r11b
  40a738:	lea    r10,[r10+0x2]
  40a73c:	vxorpd xmm0,xmm0,xmm0
  40a740:	movzx  edx,dl
  40a743:	vcvtsi2sd xmm0,xmm0,rdx
  40a748:	vsubsd xmm0,xmm1,xmm0
  40a74c:	vmulsd xmm1,xmm0,xmm15
  40a751:	vcvttsd2si rdx,xmm1
  40a756:	mov    r11b,dl
  40a759:	add    r11b,0x30
  40a75d:	mov    BYTE PTR [r9+0xe],r11b
  40a761:	vxorpd xmm0,xmm0,xmm0
  40a765:	movzx  edx,dl
  40a768:	vcvtsi2sd xmm0,xmm0,rdx
  40a76d:	vsubsd xmm0,xmm1,xmm0
  40a771:	vmulsd xmm1,xmm0,xmm15
  40a776:	vcvttsd2si rdx,xmm1
  40a77b:	mov    r11b,dl
  40a77e:	add    r11b,0x30
  40a782:	mov    BYTE PTR [r9+0xf],r11b
  40a786:	lea    r10,[r10+0x2]
  40a78a:	lea    r10,[r10+0x2]
  40a78e:	lea    r10,[r10+0x2]
  40a792:	lea    r10,[r10+0x2]
  40a796:	lea    r10,[r10+0x2]
  40a79a:	vxorpd xmm0,xmm0,xmm0
  40a79e:	movzx  edx,dl
  40a7a1:	vcvtsi2sd xmm0,xmm0,rdx
  40a7a6:	vsubsd xmm0,xmm1,xmm0
  40a7aa:	vmulsd xmm1,xmm0,xmm15
  40a7af:	vcvttsd2si rdx,xmm1
  40a7b4:	mov    r11b,dl
  40a7b7:	add    r11b,0x30
  40a7bb:	mov    BYTE PTR [r9+0x10],r11b
  40a7bf:	vxorpd xmm0,xmm0,xmm0
  40a7c3:	movzx  edx,dl
  40a7c6:	vcvtsi2sd xmm0,xmm0,rdx
  40a7cb:	vsubsd xmm0,xmm1,xmm0
  40a7cf:	vmulsd xmm1,xmm0,xmm15
  40a7d4:	vcvttsd2si rdx,xmm1
  40a7d9:	add    dl,0x30
  40a7dc:	mov    BYTE PTR [r9+0x11],dl
  40a7e0:	mov    BYTE PTR [r10+0x2],0x65
  40a7e5:	lea    r9,[r10+0x3]
  40a7e9:	test   r8,r8
  40a7ec:	jl     40a7f5 <__swc_fn_4fa09e82_000147_4dba8c3c+0x6b5>
  40a7ee:	mov    BYTE PTR [r9],0x2b
  40a7f2:	inc    r9
  40a7f5:	mov    r10,r9
  40a7f8:	mov    rdx,r8
  40a7fb:	nop    DWORD PTR [rax+rax*1+0x0]
  40a800:	mov    r11,rdx
  40a803:	movabs rdx,0x6666666666666667
  40a80d:	mov    rax,r11
  40a810:	imul   rdx
  40a813:	sar    rdx,0x2
  40a817:	mov    r12,rdx
  40a81a:	shr    rdx,0x3f
  40a81e:	add    r12,rdx
  40a821:	mov    rdx,r12
  40a824:	imul   r13,r12,0xa
  40a828:	sub    r11,r13
  40a82b:	mov    r13,QWORD PTR [rip+0x8d0e]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40a832:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a837:	mov    BYTE PTR [r10],r11b
  40a83a:	lea    r11,[r10+0x1]
  40a83e:	mov    r10,r11
  40a841:	test   r12,r12
  40a844:	jne    40a800 <__swc_fn_4fa09e82_000147_4dba8c3c+0x6c0>
  40a846:	test   r8,r8
  40a849:	jge    40a853 <__swc_fn_4fa09e82_000147_4dba8c3c+0x713>
  40a84b:	mov    BYTE PTR [r11],0x2d
  40a84f:	lea    r10,[r11+0x1]
  40a853:	mov    BYTE PTR [r10],0x0
  40a857:	sub    r10,0x1
  40a85b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a860:	cmp    r9,r10
  40a863:	jae    40aab8 <__swc_fn_4fa09e82_000147_4dba8c3c+0x978>
  40a869:	mov    al,BYTE PTR [r10]
  40a86c:	mov    dl,BYTE PTR [r9]
  40a86f:	mov    BYTE PTR [r10],dl
  40a872:	sub    r10,0x1
  40a876:	mov    BYTE PTR [r9],al
  40a879:	inc    r9
  40a87c:	jmp    40a860 <__swc_fn_4fa09e82_000147_4dba8c3c+0x720>
  40a87e:	vcvttsd2si rdx,xmm1
  40a883:	mov    r8,rdx
  40a886:	vxorpd xmm0,xmm0,xmm0
  40a88a:	vcvtsi2sd xmm0,xmm0,rdx
  40a88f:	vsubsd xmm0,xmm1,xmm0
  40a893:	mov    r9d,0x8
  40a899:	vxorpd xmm2,xmm2,xmm2
  40a89d:	vcomisd xmm2,xmm0
  40a8a1:	jbe    40a8ab <__swc_fn_4fa09e82_000147_4dba8c3c+0x76b>
  40a8a3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x8ca5]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40a8ab:	test   r9d,r9d
  40a8ae:	je     40a8ba <__swc_fn_4fa09e82_000147_4dba8c3c+0x77a>
  40a8b0:	vmulsd xmm0,xmm0,xmm14
  40a8b5:	dec    r9d
  40a8b8:	jne    40a8b0 <__swc_fn_4fa09e82_000147_4dba8c3c+0x770>
  40a8ba:	vcvttsd2si r9,xmm0
  40a8bf:	mov    r10,r9
  40a8c2:	vxorpd xmm2,xmm2,xmm2
  40a8c6:	vcvtsi2sd xmm2,xmm2,r9
  40a8cb:	vsubsd xmm0,xmm0,xmm2
  40a8cf:	vcomisd xmm0,xmm10
  40a8d4:	lea    r9,[r9+0x1]
  40a8d8:	cmova  r10,r9
  40a8dc:	cmp    r10,0x5f5e100
  40a8e3:	jne    40a8fc <__swc_fn_4fa09e82_000147_4dba8c3c+0x7bc>
  40a8e5:	lea    r8,[rdx-0x1]
  40a8e9:	vxorpd xmm0,xmm0,xmm0
  40a8ed:	vcomisd xmm0,xmm1
  40a8f1:	lea    rdx,[rdx+0x1]
  40a8f5:	cmovbe r8,rdx
  40a8f9:	xor    r10d,r10d
  40a8fc:	mov    r9,rcx
  40a8ff:	test   r8,r8
  40a902:	jne    40a922 <__swc_fn_4fa09e82_000147_4dba8c3c+0x7e2>
  40a904:	vxorpd xmm0,xmm0,xmm0
  40a908:	vcomisd xmm0,xmm1
  40a90c:	jbe    40a915 <__swc_fn_4fa09e82_000147_4dba8c3c+0x7d5>
  40a90e:	mov    BYTE PTR [rcx],0x2d
  40a911:	lea    r9,[rcx+0x1]
  40a915:	mov    BYTE PTR [r9],0x30
  40a919:	add    r9,0x1
  40a91d:	jmp    40a9bb <__swc_fn_4fa09e82_000147_4dba8c3c+0x87b>
  40a922:	mov    r9,rcx
  40a925:	mov    rdx,r8
  40a928:	nop    DWORD PTR [rax+rax*1+0x0]
  40a930:	mov    r11,rdx
  40a933:	movabs rdx,0x6666666666666667
  40a93d:	mov    r15,rax
  40a940:	mov    rax,r11
  40a943:	imul   rdx
  40a946:	mov    r12,rdx
  40a949:	mov    rax,r15
  40a94c:	sar    r12,0x2
  40a950:	mov    rdx,r12
  40a953:	shr    rdx,0x3f
  40a957:	add    r12,rdx
  40a95a:	mov    rdx,r12
  40a95d:	imul   r13,r12,0xa
  40a961:	sub    r11,r13
  40a964:	mov    r13,QWORD PTR [rip+0x8bd5]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40a96b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a970:	mov    BYTE PTR [r9],r11b
  40a973:	lea    r11,[r9+0x1]
  40a977:	mov    r9,r11
  40a97a:	test   r12,r12
  40a97d:	jne    40a930 <__swc_fn_4fa09e82_000147_4dba8c3c+0x7f0>
  40a97f:	test   r8,r8
  40a982:	jge    40a98c <__swc_fn_4fa09e82_000147_4dba8c3c+0x84c>
  40a984:	mov    BYTE PTR [r11],0x2d
  40a988:	lea    r9,[r11+0x1]
  40a98c:	mov    rdx,r9
  40a98f:	mov    BYTE PTR [r9],0x0
  40a993:	sub    r9,0x1
  40a997:	mov    r8,rcx
  40a99a:	cmp    r8,r9
  40a99d:	jae    40a9b8 <__swc_fn_4fa09e82_000147_4dba8c3c+0x878>
  40a99f:	nop
  40a9a0:	mov    r11b,BYTE PTR [r9]
  40a9a3:	mov    r12b,BYTE PTR [r8]
  40a9a6:	mov    BYTE PTR [r9],r12b
  40a9a9:	sub    r9,0x1
  40a9ad:	mov    BYTE PTR [r8],r11b
  40a9b0:	inc    r8
  40a9b3:	cmp    r8,r9
  40a9b6:	jb     40a9a0 <__swc_fn_4fa09e82_000147_4dba8c3c+0x860>
  40a9b8:	mov    r9,rdx
  40a9bb:	mov    BYTE PTR [r9],0x2e
  40a9bf:	add    r9,0x1
  40a9c3:	xor    r8d,r8d
  40a9c6:	test   r10,r10
  40a9c9:	je     40aa0f <__swc_fn_4fa09e82_000147_4dba8c3c+0x8cf>
  40a9cb:	mov    r11d,0x989680
  40a9d1:	cmp    r10,r11
  40a9d4:	jge    40aa0f <__swc_fn_4fa09e82_000147_4dba8c3c+0x8cf>
  40a9d6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9e0:	inc    r8d
  40a9e3:	movabs rdx,0x6666666666666667
  40a9ed:	mov    r15,rax
  40a9f0:	mov    rax,r11
  40a9f3:	imul   rdx
  40a9f6:	mov    r11,rdx
  40a9f9:	mov    rax,r15
  40a9fc:	sar    r11,0x2
  40aa00:	mov    rdx,r11
  40aa03:	shr    rdx,0x3f
  40aa07:	add    r11,rdx
  40aa0a:	cmp    r10,r11
  40aa0d:	jl     40a9e0 <__swc_fn_4fa09e82_000147_4dba8c3c+0x8a0>
  40aa0f:	test   r8d,r8d
  40aa12:	je     40aa2d <__swc_fn_4fa09e82_000147_4dba8c3c+0x8ed>
  40aa14:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa1e:	xchg   ax,ax
  40aa20:	mov    BYTE PTR [r9],0x30
  40aa24:	add    r9,0x1
  40aa28:	dec    r8d
  40aa2b:	jne    40aa20 <__swc_fn_4fa09e82_000147_4dba8c3c+0x8e0>
  40aa2d:	mov    r8,r9
  40aa30:	mov    rdx,r10
  40aa33:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa3d:	nop    DWORD PTR [rax]
  40aa40:	mov    r11,rdx
  40aa43:	movabs rdx,0x6666666666666667
  40aa4d:	mov    rax,r11
  40aa50:	imul   rdx
  40aa53:	sar    rdx,0x2
  40aa57:	mov    r12,rdx
  40aa5a:	shr    rdx,0x3f
  40aa5e:	add    r12,rdx
  40aa61:	mov    rdx,r12
  40aa64:	imul   r13,r12,0xa
  40aa68:	sub    r11,r13
  40aa6b:	mov    r13,QWORD PTR [rip+0x8ace]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40aa72:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40aa77:	mov    BYTE PTR [r8],r11b
  40aa7a:	lea    r11,[r8+0x1]
  40aa7e:	mov    r8,r11
  40aa81:	test   r12,r12
  40aa84:	jne    40aa40 <__swc_fn_4fa09e82_000147_4dba8c3c+0x900>
  40aa86:	test   r10,r10
  40aa89:	jge    40aa93 <__swc_fn_4fa09e82_000147_4dba8c3c+0x953>
  40aa8b:	mov    BYTE PTR [r11],0x2d
  40aa8f:	lea    r8,[r11+0x1]
  40aa93:	mov    BYTE PTR [r8],0x0
  40aa97:	sub    r8,0x1
  40aa9b:	cmp    r9,r8
  40aa9e:	jae    40aab8 <__swc_fn_4fa09e82_000147_4dba8c3c+0x978>
  40aaa0:	mov    al,BYTE PTR [r8]
  40aaa3:	mov    dl,BYTE PTR [r9]
  40aaa6:	mov    BYTE PTR [r8],dl
  40aaa9:	sub    r8,0x1
  40aaad:	mov    BYTE PTR [r9],al
  40aab0:	inc    r9
  40aab3:	cmp    r9,r8
  40aab6:	jb     40aaa0 <__swc_fn_4fa09e82_000147_4dba8c3c+0x960>
  40aab8:	xor    eax,eax
  40aaba:	test   rcx,rcx
  40aabd:	je     40aaf0 <__swc_fn_4fa09e82_000147_4dba8c3c+0x9b0>
  40aabf:	mov    rdx,rcx
  40aac2:	mov    r8b,BYTE PTR [rdx]
  40aac5:	test   r8b,r8b
  40aac8:	je     40aaf0 <__swc_fn_4fa09e82_000147_4dba8c3c+0x9b0>
  40aaca:	cs nop WORD PTR [rax+rax*1+0x0]
  40aad4:	cs nop WORD PTR [rax+rax*1+0x0]
  40aade:	xchg   ax,ax
  40aae0:	add    rdx,0x1
  40aae4:	add    rax,0x1
  40aae8:	mov    r8b,BYTE PTR [rdx]
  40aaeb:	test   r8b,r8b
  40aaee:	jne    40aae0 <__swc_fn_4fa09e82_000147_4dba8c3c+0x9a0>
  40aaf0:	mov    QWORD PTR [rsp+0x240],rcx
  40aaf8:	mov    QWORD PTR [rsp+0x248],rax
  40ab00:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  40ab09:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  40ab12:	lea    rcx,[rsp+0x250]
  40ab1a:	call   4098c0 <__swc_fn_4fa09e82_000117_18ca1307>
  40ab1f:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40ab24:	lea    rcx,[rsp+0x260]
  40ab2c:	vxorps xmm0,xmm0,xmm0
  40ab30:	vmovups XMMWORD PTR [rsp+0x260],xmm0
  40ab39:	vmovups XMMWORD PTR [rsp+0x270],xmm0
  40ab42:	vmovups XMMWORD PTR [rsp+0x280],xmm0
  40ab4b:	vmovups XMMWORD PTR [rsp+0x290],xmm0
  40ab54:	vmovups XMMWORD PTR [rsp+0x2a0],xmm0
  40ab5d:	vmovups XMMWORD PTR [rsp+0x2b0],xmm0
  40ab66:	mov    DWORD PTR [rsp+0x2c0],0x0
  40ab71:	vmovsd xmm0,QWORD PTR [rdx]
  40ab75:	vcomisd xmm0,xmm0
  40ab79:	setne  dl
  40ab7c:	movzx  edx,dl
  40ab7f:	setp   r8b
  40ab83:	movzx  r8d,r8b
  40ab87:	or     edx,r8d
  40ab8a:	test   dl,dl
  40ab8c:	je     40ab99 <__swc_fn_4fa09e82_000147_4dba8c3c+0xa59>
  40ab8e:	mov    DWORD PTR [rcx],0x6e616e
  40ab94:	jmp    40b1a8 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1068>
  40ab99:	vcomisd xmm0,xmm11
  40ab9e:	ja     40abaf <__swc_fn_4fa09e82_000147_4dba8c3c+0xa6f>
  40aba0:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  40aba9:	vcomisd xmm6,xmm0
  40abad:	jbe    40abd3 <__swc_fn_4fa09e82_000147_4dba8c3c+0xa93>
  40abaf:	vxorpd xmm1,xmm1,xmm1
  40abb3:	vcomisd xmm1,xmm0
  40abb7:	jbe    40abc8 <__swc_fn_4fa09e82_000147_4dba8c3c+0xa88>
  40abb9:	mov    DWORD PTR [rcx],0x666e692d
  40abbf:	mov    BYTE PTR [rcx+0x4],0x0
  40abc3:	jmp    40b1a8 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1068>
  40abc8:	mov    DWORD PTR [rcx],0x666e69
  40abce:	jmp    40b1a8 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1068>
  40abd3:	vcomisd xmm0,xmm13
  40abd8:	jae    40abe4 <__swc_fn_4fa09e82_000147_4dba8c3c+0xaa4>
  40abda:	vcomisd xmm12,xmm0
  40abde:	jbe    40af4e <__swc_fn_4fa09e82_000147_4dba8c3c+0xe0e>
  40abe4:	vmovups xmm1,xmm0
  40abe8:	vxorpd xmm2,xmm2,xmm2
  40abec:	vcomisd xmm2,xmm0
  40abf0:	jbe    40ac00 <__swc_fn_4fa09e82_000147_4dba8c3c+0xac0>
  40abf2:	vmovsd xmm0,xmm0,xmm1
  40abf6:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x8952]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40abfe:	jmp    40ac04 <__swc_fn_4fa09e82_000147_4dba8c3c+0xac4>
  40ac00:	vmovsd xmm0,xmm0,xmm1
  40ac04:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  40ac0d:	xor    r8d,r8d
  40ac10:	vcomisd xmm0,xmm6
  40ac14:	jb     40ac2e <__swc_fn_4fa09e82_000147_4dba8c3c+0xaee>
  40ac16:	cs nop WORD PTR [rax+rax*1+0x0]
  40ac20:	vdivsd xmm0,xmm0,xmm6
  40ac24:	add    r8,0x1
  40ac28:	vcomisd xmm0,xmm6
  40ac2c:	jae    40ac20 <__swc_fn_4fa09e82_000147_4dba8c3c+0xae0>
  40ac2e:	mov    r9,rcx
  40ac31:	vxorpd xmm2,xmm2,xmm2
  40ac35:	vcomisd xmm2,xmm1
  40ac39:	jbe    40ac42 <__swc_fn_4fa09e82_000147_4dba8c3c+0xb02>
  40ac3b:	mov    BYTE PTR [rcx],0x2d
  40ac3e:	lea    r9,[rcx+0x1]
  40ac42:	vcvttsd2si rdx,xmm0
  40ac47:	mov    r10b,dl
  40ac4a:	add    r10b,0x30
  40ac4e:	mov    BYTE PTR [r9],r10b
  40ac51:	vxorpd xmm1,xmm1,xmm1
  40ac55:	movzx  edx,dl
  40ac58:	vcvtsi2sd xmm1,xmm1,rdx
  40ac5d:	vsubsd xmm0,xmm0,xmm1
  40ac61:	vmulsd xmm0,xmm0,xmm6
  40ac65:	mov    BYTE PTR [r9+0x1],0x2e
  40ac6a:	vcvttsd2si rdx,xmm0
  40ac6f:	mov    r10b,dl
  40ac72:	add    r10b,0x30
  40ac76:	mov    BYTE PTR [r9+0x2],r10b
  40ac7a:	vxorpd xmm1,xmm1,xmm1
  40ac7e:	movzx  edx,dl
  40ac81:	vcvtsi2sd xmm1,xmm1,rdx
  40ac86:	vsubsd xmm0,xmm0,xmm1
  40ac8a:	vmulsd xmm0,xmm0,xmm6
  40ac8e:	vcvttsd2si rdx,xmm0
  40ac93:	mov    r10b,dl
  40ac96:	add    r10b,0x30
  40ac9a:	mov    BYTE PTR [r9+0x3],r10b
  40ac9e:	vxorpd xmm1,xmm1,xmm1
  40aca2:	movzx  edx,dl
  40aca5:	vcvtsi2sd xmm1,xmm1,rdx
  40acaa:	vsubsd xmm0,xmm0,xmm1
  40acae:	vmulsd xmm0,xmm0,xmm6
  40acb2:	vcvttsd2si rdx,xmm0
  40acb7:	mov    r10b,dl
  40acba:	add    r10b,0x30
  40acbe:	mov    BYTE PTR [r9+0x4],r10b
  40acc2:	vxorpd xmm1,xmm1,xmm1
  40acc6:	movzx  edx,dl
  40acc9:	vcvtsi2sd xmm1,xmm1,rdx
  40acce:	vsubsd xmm0,xmm0,xmm1
  40acd2:	vmulsd xmm0,xmm0,xmm6
  40acd6:	vcvttsd2si rdx,xmm0
  40acdb:	mov    r10b,dl
  40acde:	add    r10b,0x30
  40ace2:	mov    BYTE PTR [r9+0x5],r10b
  40ace6:	vxorpd xmm1,xmm1,xmm1
  40acea:	movzx  edx,dl
  40aced:	vcvtsi2sd xmm1,xmm1,rdx
  40acf2:	vsubsd xmm0,xmm0,xmm1
  40acf6:	vmulsd xmm0,xmm0,xmm6
  40acfa:	vcvttsd2si rdx,xmm0
  40acff:	mov    r10b,dl
  40ad02:	add    r10b,0x30
  40ad06:	mov    BYTE PTR [r9+0x6],r10b
  40ad0a:	vxorpd xmm1,xmm1,xmm1
  40ad0e:	movzx  edx,dl
  40ad11:	vcvtsi2sd xmm1,xmm1,rdx
  40ad16:	vsubsd xmm0,xmm0,xmm1
  40ad1a:	vmulsd xmm0,xmm0,xmm6
  40ad1e:	vcvttsd2si rdx,xmm0
  40ad23:	mov    r10b,dl
  40ad26:	add    r10b,0x30
  40ad2a:	mov    BYTE PTR [r9+0x7],r10b
  40ad2e:	vxorpd xmm1,xmm1,xmm1
  40ad32:	movzx  edx,dl
  40ad35:	vcvtsi2sd xmm1,xmm1,rdx
  40ad3a:	vsubsd xmm0,xmm0,xmm1
  40ad3e:	vmulsd xmm0,xmm0,xmm6
  40ad42:	vcvttsd2si rdx,xmm0
  40ad47:	mov    r10b,dl
  40ad4a:	add    r10b,0x30
  40ad4e:	mov    BYTE PTR [r9+0x8],r10b
  40ad52:	vxorpd xmm1,xmm1,xmm1
  40ad56:	movzx  edx,dl
  40ad59:	vcvtsi2sd xmm1,xmm1,rdx
  40ad5e:	vsubsd xmm0,xmm0,xmm1
  40ad62:	vmulsd xmm0,xmm0,xmm6
  40ad66:	vcvttsd2si rdx,xmm0
  40ad6b:	mov    r10b,dl
  40ad6e:	add    r10b,0x30
  40ad72:	mov    BYTE PTR [r9+0x9],r10b
  40ad76:	vxorpd xmm1,xmm1,xmm1
  40ad7a:	movzx  edx,dl
  40ad7d:	vcvtsi2sd xmm1,xmm1,rdx
  40ad82:	vsubsd xmm0,xmm0,xmm1
  40ad86:	vmulsd xmm0,xmm0,xmm6
  40ad8a:	vcvttsd2si rdx,xmm0
  40ad8f:	mov    r10b,dl
  40ad92:	add    r10b,0x30
  40ad96:	mov    BYTE PTR [r9+0xa],r10b
  40ad9a:	vxorpd xmm1,xmm1,xmm1
  40ad9e:	movzx  edx,dl
  40ada1:	vcvtsi2sd xmm1,xmm1,rdx
  40ada6:	vsubsd xmm0,xmm0,xmm1
  40adaa:	vmulsd xmm0,xmm0,xmm6
  40adae:	vcvttsd2si rdx,xmm0
  40adb3:	mov    r10b,dl
  40adb6:	add    r10b,0x30
  40adba:	mov    BYTE PTR [r9+0xb],r10b
  40adbe:	lea    r10,[r9+0x4]
  40adc2:	vxorpd xmm1,xmm1,xmm1
  40adc6:	movzx  edx,dl
  40adc9:	vcvtsi2sd xmm1,xmm1,rdx
  40adce:	vsubsd xmm0,xmm0,xmm1
  40add2:	vmulsd xmm0,xmm0,xmm6
  40add6:	vcvttsd2si rdx,xmm0
  40addb:	mov    r11b,dl
  40adde:	add    r11b,0x30
  40ade2:	mov    BYTE PTR [r9+0xc],r11b
  40ade6:	vxorpd xmm1,xmm1,xmm1
  40adea:	movzx  edx,dl
  40aded:	vcvtsi2sd xmm1,xmm1,rdx
  40adf2:	vsubsd xmm0,xmm0,xmm1
  40adf6:	vmulsd xmm0,xmm0,xmm6
  40adfa:	vcvttsd2si rdx,xmm0
  40adff:	mov    r11b,dl
  40ae02:	add    r11b,0x30
  40ae06:	mov    BYTE PTR [r9+0xd],r11b
  40ae0a:	lea    r10,[r10+0x2]
  40ae0e:	vxorpd xmm1,xmm1,xmm1
  40ae12:	movzx  edx,dl
  40ae15:	vcvtsi2sd xmm1,xmm1,rdx
  40ae1a:	vsubsd xmm0,xmm0,xmm1
  40ae1e:	vmulsd xmm0,xmm0,xmm6
  40ae22:	vcvttsd2si rdx,xmm0
  40ae27:	mov    r11b,dl
  40ae2a:	add    r11b,0x30
  40ae2e:	mov    BYTE PTR [r9+0xe],r11b
  40ae32:	vxorpd xmm1,xmm1,xmm1
  40ae36:	movzx  edx,dl
  40ae39:	vcvtsi2sd xmm1,xmm1,rdx
  40ae3e:	vsubsd xmm0,xmm0,xmm1
  40ae42:	vmulsd xmm0,xmm0,xmm6
  40ae46:	vcvttsd2si rdx,xmm0
  40ae4b:	mov    r11b,dl
  40ae4e:	add    r11b,0x30
  40ae52:	mov    BYTE PTR [r9+0xf],r11b
  40ae56:	lea    r10,[r10+0x2]
  40ae5a:	lea    r10,[r10+0x2]
  40ae5e:	lea    r10,[r10+0x2]
  40ae62:	lea    r10,[r10+0x2]
  40ae66:	lea    r10,[r10+0x2]
  40ae6a:	vxorpd xmm1,xmm1,xmm1
  40ae6e:	movzx  edx,dl
  40ae71:	vcvtsi2sd xmm1,xmm1,rdx
  40ae76:	vsubsd xmm0,xmm0,xmm1
  40ae7a:	vmulsd xmm0,xmm0,xmm6
  40ae7e:	vcvttsd2si rdx,xmm0
  40ae83:	mov    r11b,dl
  40ae86:	add    r11b,0x30
  40ae8a:	mov    BYTE PTR [r9+0x10],r11b
  40ae8e:	vxorpd xmm1,xmm1,xmm1
  40ae92:	movzx  edx,dl
  40ae95:	vcvtsi2sd xmm1,xmm1,rdx
  40ae9a:	vsubsd xmm0,xmm0,xmm1
  40ae9e:	vmulsd xmm0,xmm0,xmm6
  40aea2:	vcvttsd2si rdx,xmm0
  40aea7:	add    dl,0x30
  40aeaa:	mov    BYTE PTR [r9+0x11],dl
  40aeae:	mov    BYTE PTR [r10+0x2],0x65
  40aeb3:	lea    r9,[r10+0x3]
  40aeb7:	test   r8,r8
  40aeba:	jl     40aec3 <__swc_fn_4fa09e82_000147_4dba8c3c+0xd83>
  40aebc:	mov    BYTE PTR [r9],0x2b
  40aec0:	inc    r9
  40aec3:	mov    r10,r9
  40aec6:	mov    rdx,r8
  40aec9:	nop    DWORD PTR [rax+0x0]
  40aed0:	mov    r11,rdx
  40aed3:	movabs rdx,0x6666666666666667
  40aedd:	mov    rax,r11
  40aee0:	imul   rdx
  40aee3:	sar    rdx,0x2
  40aee7:	mov    r12,rdx
  40aeea:	shr    rdx,0x3f
  40aeee:	add    r12,rdx
  40aef1:	mov    rdx,r12
  40aef4:	imul   r13,r12,0xa
  40aef8:	sub    r11,r13
  40aefb:	mov    r13,QWORD PTR [rip+0x863e]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40af02:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40af07:	mov    BYTE PTR [r10],r11b
  40af0a:	lea    r11,[r10+0x1]
  40af0e:	mov    r10,r11
  40af11:	test   r12,r12
  40af14:	jne    40aed0 <__swc_fn_4fa09e82_000147_4dba8c3c+0xd90>
  40af16:	test   r8,r8
  40af19:	jge    40af23 <__swc_fn_4fa09e82_000147_4dba8c3c+0xde3>
  40af1b:	mov    BYTE PTR [r11],0x2d
  40af1f:	lea    r10,[r11+0x1]
  40af23:	mov    BYTE PTR [r10],0x0
  40af27:	sub    r10,0x1
  40af2b:	nop    DWORD PTR [rax+rax*1+0x0]
  40af30:	cmp    r9,r10
  40af33:	jae    40b1a8 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1068>
  40af39:	mov    al,BYTE PTR [r10]
  40af3c:	mov    dl,BYTE PTR [r9]
  40af3f:	mov    BYTE PTR [r10],dl
  40af42:	sub    r10,0x1
  40af46:	mov    BYTE PTR [r9],al
  40af49:	inc    r9
  40af4c:	jmp    40af30 <__swc_fn_4fa09e82_000147_4dba8c3c+0xdf0>
  40af4e:	vcvttsd2si rdx,xmm0
  40af53:	mov    r8,rdx
  40af56:	vxorpd xmm1,xmm1,xmm1
  40af5a:	vcvtsi2sd xmm1,xmm1,rdx
  40af5f:	vsubsd xmm1,xmm0,xmm1
  40af63:	mov    r9d,0x8
  40af69:	vxorpd xmm2,xmm2,xmm2
  40af6d:	vcomisd xmm2,xmm1
  40af71:	ja     40af7e <__swc_fn_4fa09e82_000147_4dba8c3c+0xe3e>
  40af73:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40af7c:	jmp    40af8f <__swc_fn_4fa09e82_000147_4dba8c3c+0xe4f>
  40af7e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x85ca]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40af86:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40af8f:	test   r9d,r9d
  40af92:	je     40afa9 <__swc_fn_4fa09e82_000147_4dba8c3c+0xe69>
  40af94:	cs nop WORD PTR [rax+rax*1+0x0]
  40af9e:	xchg   ax,ax
  40afa0:	vmulsd xmm1,xmm1,xmm6
  40afa4:	dec    r9d
  40afa7:	jne    40afa0 <__swc_fn_4fa09e82_000147_4dba8c3c+0xe60>
  40afa9:	vcvttsd2si r9,xmm1
  40afae:	mov    r10,r9
  40afb1:	vxorpd xmm2,xmm2,xmm2
  40afb5:	vcvtsi2sd xmm2,xmm2,r9
  40afba:	vsubsd xmm1,xmm1,xmm2
  40afbe:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  40afc7:	vcomisd xmm1,xmm6
  40afcb:	lea    r9,[r9+0x1]
  40afcf:	cmova  r10,r9
  40afd3:	cmp    r10,0x5f5e100
  40afda:	jne    40aff3 <__swc_fn_4fa09e82_000147_4dba8c3c+0xeb3>
  40afdc:	lea    r8,[rdx-0x1]
  40afe0:	vxorpd xmm1,xmm1,xmm1
  40afe4:	vcomisd xmm1,xmm0
  40afe8:	lea    rdx,[rdx+0x1]
  40afec:	cmovbe r8,rdx
  40aff0:	xor    r10d,r10d
  40aff3:	mov    r9,rcx
  40aff6:	test   r8,r8
  40aff9:	jne    40b019 <__swc_fn_4fa09e82_000147_4dba8c3c+0xed9>
  40affb:	vxorpd xmm1,xmm1,xmm1
  40afff:	vcomisd xmm1,xmm0
  40b003:	jbe    40b00c <__swc_fn_4fa09e82_000147_4dba8c3c+0xecc>
  40b005:	mov    BYTE PTR [rcx],0x2d
  40b008:	lea    r9,[rcx+0x1]
  40b00c:	mov    BYTE PTR [r9],0x30
  40b010:	add    r9,0x1
  40b014:	jmp    40b0ab <__swc_fn_4fa09e82_000147_4dba8c3c+0xf6b>
  40b019:	mov    r9,rcx
  40b01c:	mov    rdx,r8
  40b01f:	nop
  40b020:	mov    r11,rdx
  40b023:	movabs rdx,0x6666666666666667
  40b02d:	mov    r15,rax
  40b030:	mov    rax,r11
  40b033:	imul   rdx
  40b036:	mov    r12,rdx
  40b039:	mov    rax,r15
  40b03c:	sar    r12,0x2
  40b040:	mov    rdx,r12
  40b043:	shr    rdx,0x3f
  40b047:	add    r12,rdx
  40b04a:	mov    rdx,r12
  40b04d:	imul   r13,r12,0xa
  40b051:	sub    r11,r13
  40b054:	mov    r13,QWORD PTR [rip+0x84e5]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40b05b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b060:	mov    BYTE PTR [r9],r11b
  40b063:	lea    r11,[r9+0x1]
  40b067:	mov    r9,r11
  40b06a:	test   r12,r12
  40b06d:	jne    40b020 <__swc_fn_4fa09e82_000147_4dba8c3c+0xee0>
  40b06f:	test   r8,r8
  40b072:	jge    40b07c <__swc_fn_4fa09e82_000147_4dba8c3c+0xf3c>
  40b074:	mov    BYTE PTR [r11],0x2d
  40b078:	lea    r9,[r11+0x1]
  40b07c:	mov    rdx,r9
  40b07f:	mov    BYTE PTR [r9],0x0
  40b083:	sub    r9,0x1
  40b087:	mov    r8,rcx
  40b08a:	cmp    r8,r9
  40b08d:	jae    40b0a8 <__swc_fn_4fa09e82_000147_4dba8c3c+0xf68>
  40b08f:	nop
  40b090:	mov    r11b,BYTE PTR [r9]
  40b093:	mov    r12b,BYTE PTR [r8]
  40b096:	mov    BYTE PTR [r9],r12b
  40b099:	sub    r9,0x1
  40b09d:	mov    BYTE PTR [r8],r11b
  40b0a0:	inc    r8
  40b0a3:	cmp    r8,r9
  40b0a6:	jb     40b090 <__swc_fn_4fa09e82_000147_4dba8c3c+0xf50>
  40b0a8:	mov    r9,rdx
  40b0ab:	mov    BYTE PTR [r9],0x2e
  40b0af:	add    r9,0x1
  40b0b3:	xor    r8d,r8d
  40b0b6:	test   r10,r10
  40b0b9:	je     40b0ff <__swc_fn_4fa09e82_000147_4dba8c3c+0xfbf>
  40b0bb:	mov    r11d,0x989680
  40b0c1:	cmp    r10,r11
  40b0c4:	jge    40b0ff <__swc_fn_4fa09e82_000147_4dba8c3c+0xfbf>
  40b0c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40b0d0:	inc    r8d
  40b0d3:	movabs rdx,0x6666666666666667
  40b0dd:	mov    r15,rax
  40b0e0:	mov    rax,r11
  40b0e3:	imul   rdx
  40b0e6:	mov    r11,rdx
  40b0e9:	mov    rax,r15
  40b0ec:	sar    r11,0x2
  40b0f0:	mov    rdx,r11
  40b0f3:	shr    rdx,0x3f
  40b0f7:	add    r11,rdx
  40b0fa:	cmp    r10,r11
  40b0fd:	jl     40b0d0 <__swc_fn_4fa09e82_000147_4dba8c3c+0xf90>
  40b0ff:	test   r8d,r8d
  40b102:	je     40b11d <__swc_fn_4fa09e82_000147_4dba8c3c+0xfdd>
  40b104:	cs nop WORD PTR [rax+rax*1+0x0]
  40b10e:	xchg   ax,ax
  40b110:	mov    BYTE PTR [r9],0x30
  40b114:	add    r9,0x1
  40b118:	dec    r8d
  40b11b:	jne    40b110 <__swc_fn_4fa09e82_000147_4dba8c3c+0xfd0>
  40b11d:	mov    r8,r9
  40b120:	mov    rdx,r10
  40b123:	cs nop WORD PTR [rax+rax*1+0x0]
  40b12d:	nop    DWORD PTR [rax]
  40b130:	mov    r11,rdx
  40b133:	movabs rdx,0x6666666666666667
  40b13d:	mov    rax,r11
  40b140:	imul   rdx
  40b143:	sar    rdx,0x2
  40b147:	mov    r12,rdx
  40b14a:	shr    rdx,0x3f
  40b14e:	add    r12,rdx
  40b151:	mov    rdx,r12
  40b154:	imul   r13,r12,0xa
  40b158:	sub    r11,r13
  40b15b:	mov    r13,QWORD PTR [rip+0x83de]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40b162:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b167:	mov    BYTE PTR [r8],r11b
  40b16a:	lea    r11,[r8+0x1]
  40b16e:	mov    r8,r11
  40b171:	test   r12,r12
  40b174:	jne    40b130 <__swc_fn_4fa09e82_000147_4dba8c3c+0xff0>
  40b176:	test   r10,r10
  40b179:	jge    40b183 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1043>
  40b17b:	mov    BYTE PTR [r11],0x2d
  40b17f:	lea    r8,[r11+0x1]
  40b183:	mov    BYTE PTR [r8],0x0
  40b187:	sub    r8,0x1
  40b18b:	cmp    r9,r8
  40b18e:	jae    40b1a8 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1068>
  40b190:	mov    al,BYTE PTR [r8]
  40b193:	mov    dl,BYTE PTR [r9]
  40b196:	mov    BYTE PTR [r8],dl
  40b199:	sub    r8,0x1
  40b19d:	mov    BYTE PTR [r9],al
  40b1a0:	inc    r9
  40b1a3:	cmp    r9,r8
  40b1a6:	jb     40b190 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1050>
  40b1a8:	xor    eax,eax
  40b1aa:	test   rcx,rcx
  40b1ad:	je     40b1d0 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1090>
  40b1af:	mov    rdx,rcx
  40b1b2:	mov    r8b,BYTE PTR [rdx]
  40b1b5:	test   r8b,r8b
  40b1b8:	je     40b1d0 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1090>
  40b1ba:	nop    WORD PTR [rax+rax*1+0x0]
  40b1c0:	add    rdx,0x1
  40b1c4:	add    rax,0x1
  40b1c8:	mov    r8b,BYTE PTR [rdx]
  40b1cb:	test   r8b,r8b
  40b1ce:	jne    40b1c0 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1080>
  40b1d0:	mov    QWORD PTR [rsp+0x3f8],rcx
  40b1d8:	mov    QWORD PTR [rsp+0x400],rax
  40b1e0:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  40b1e9:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  40b1f2:	lea    rcx,[rsp+0x408]
  40b1fa:	call   4098c0 <__swc_fn_4fa09e82_000117_18ca1307>
  40b1ff:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40b201:	mov    rcx,rdx
  40b204:	call   4098c0 <__swc_fn_4fa09e82_000117_18ca1307>
  40b209:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40b20b:	mov    al,BYTE PTR [rdx]
  40b20d:	test   al,al
  40b20f:	je     40b21a <__swc_fn_4fa09e82_000147_4dba8c3c+0x10da>
  40b211:	lea    rax,[rip+0x8348]        # 413560 <__swc_rdata_base_4fa09e82+0x450>
  40b218:	jmp    40b221 <__swc_fn_4fa09e82_000147_4dba8c3c+0x10e1>
  40b21a:	lea    rax,[rip+0x834f]        # 413570 <__swc_rdata_base_4fa09e82+0x460>
  40b221:	mov    rcx,rax
  40b224:	call   4098c0 <__swc_fn_4fa09e82_000117_18ca1307>
  40b229:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40b22b:	lea    rcx,[rip+0x834e]        # 413580 <__swc_rdata_base_4fa09e82+0x470>
  40b232:	call   4098c0 <__swc_fn_4fa09e82_000117_18ca1307>
  40b237:	jmp    40b245 <__swc_fn_4fa09e82_000147_4dba8c3c+0x1105>
  40b239:	lea    rcx,[rip+0x8340]        # 413580 <__swc_rdata_base_4fa09e82+0x470>
  40b240:	call   4098c0 <__swc_fn_4fa09e82_000117_18ca1307>
  40b245:	add    rdi,0x1
  40b249:	sub    rsi,0x1
  40b24d:	vmovups xmm0,xmm12
  40b252:	vmovsd xmm6,QWORD PTR [rip+0x8336]        # 413590 <__swc_rdata_base_4fa09e82+0x480>
  40b25a:	test   rsi,rsi
  40b25d:	jne    40a250 <__swc_fn_4fa09e82_000147_4dba8c3c+0x110>
  40b263:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  40b26c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  40b275:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  40b27e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  40b287:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  40b290:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  40b299:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  40b2a2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  40b2ab:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  40b2b4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  40b2bd:	add    rsp,0x4e8
  40b2c4:	pop    r15
  40b2c6:	pop    r13
  40b2c8:	pop    r12
  40b2ca:	pop    rdi
  40b2cb:	pop    rsi
  40b2cc:	pop    rbx
  40b2cd:	ret
