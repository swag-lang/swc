
/workspace/prompt2-20261115/batch2-final-micro/new/binarytrees/binarytrees:     file format elf64-x86-64


Disassembly of section .text:

000000000040eaa0 <__swc_fn_7dafa2b1_000002_6e6aee58>:
  40eaa0:	push   rbx
  40eaa1:	sub    rsp,0x80
  40eaa8:	mov    rax,rcx
  40eaab:	mov    rcx,QWORD PTR [rax]
  40eaae:	test   rcx,rcx
  40eab1:	je     40ead0 <__swc_fn_7dafa2b1_000002_6e6aee58+0x30>
  40eab3:	mov    QWORD PTR [rsp+0x68],rax
  40eab8:	call   40eaa0 <__swc_fn_7dafa2b1_000002_6e6aee58>
  40eabd:	mov    rax,QWORD PTR [rsp+0x68]
  40eac2:	mov    rcx,QWORD PTR [rax+0x8]
  40eac6:	call   40eaa0 <__swc_fn_7dafa2b1_000002_6e6aee58>
  40eacb:	mov    rax,QWORD PTR [rsp+0x68]
  40ead0:	test   rax,rax
  40ead3:	je     40eb3f <__swc_fn_7dafa2b1_000002_6e6aee58+0x9f>
  40ead5:	vxorps xmm0,xmm0,xmm0
  40ead9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40eadf:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40eae5:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40eaeb:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40eaf1:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40eaf7:	lea    rcx,[rax-0x10]
  40eafb:	mov    QWORD PTR [rsp+0x48],rcx
  40eb00:	mov    rax,QWORD PTR [rax-0x10]
  40eb04:	mov    QWORD PTR [rsp+0x50],rax
  40eb09:	mov    rcx,QWORD PTR [rip+0x14530]        # 423040 <__swc_bss_base_7dafa2b1>
  40eb10:	test   rcx,rcx
  40eb13:	jne    40eb25 <__swc_fn_7dafa2b1_000002_6e6aee58+0x85>
  40eb15:	call   411ab0 <__swc_fn_7dafa2b1_000170_994c8876>
  40eb1a:	lea    rcx,[rax+0x1]
  40eb1e:	mov    QWORD PTR [rip+0x1451b],rcx        # 423040 <__swc_bss_base_7dafa2b1>
  40eb25:	dec    rcx
  40eb28:	call   40e900 <__swc_fn_7dafa2b1_000172_360af05d>
  40eb2d:	mov    rcx,QWORD PTR [rax]
  40eb30:	lea    rdx,[rsp+0x8]
  40eb35:	mov    rbx,QWORD PTR [rax+0x8]
  40eb39:	mov    rbx,QWORD PTR [rbx+0x18]
  40eb3d:	call   rbx
  40eb3f:	add    rsp,0x80
  40eb46:	pop    rbx
  40eb47:	ret
