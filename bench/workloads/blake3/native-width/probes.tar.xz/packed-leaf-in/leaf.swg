#global private
#global #[Swag.Safety(.Overflow, false)]

private const Blake3BlockSize = 64

// BLAKE3's chunk size in bytes.
private const Blake3ChunkSize = 1024

// BLAKE3 key size in bytes.
private const Blake3KeySize = 32

private const Blake3Iv: [8] u32 = [
    0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A,
    0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19]

private const Blake3MessageSchedule: [7][16] u8 = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
    [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8],
    [3, 4, 10, 12, 13, 2, 7, 14, 6, 5, 9, 0, 11, 15, 8, 1],
    [10, 7, 12, 9, 14, 3, 13, 15, 4, 0, 11, 2, 5, 8, 1, 6],
    [12, 13, 9, 11, 15, 10, 14, 8, 7, 2, 5, 3, 0, 1, 6, 4],
    [9, 14, 11, 5, 8, 12, 15, 1, 13, 3, 0, 10, 2, 6, 4, 7],
    [11, 15, 5, 0, 1, 9, 8, 6, 14, 10, 2, 12, 3, 4, 7, 13]]

private const Blake3ChunkStart        = 1'u32
private const Blake3ChunkEnd          = 2'u32
private const Blake3Parent            = 4'u32
private const Blake3Root              = 8'u32
private const Blake3KeyedHash         = 16'u32
private const Blake3DeriveKeyContext  = 32'u32
private const Blake3DeriveKeyMaterial = 64'u32

private const Blake3ChunksPerBatch = 8
private const Blake3WordsPerCv     = Blake3KeySize / #sizeof(u32)

// Large updates can amortize worker scheduling across several complete batches.
private const Blake3ParallelBytes  = 64 * 1024
private const Blake3BlocksPerChunk = Blake3ChunkSize / Blake3BlockSize

private alias Blake3WideVector = #simd [8] u32

private func blake3TransposeWide(rows: *[8] Blake3WideVector)
{
    const All = cast(Blake3WideVector, [Swag.U32.Max, Swag.U32.Max, Swag.U32.Max, Swag.U32.Max,
                                       Swag.U32.Max, Swag.U32.Max, Swag.U32.Max, Swag.U32.Max])
    const Alternating = cast(Blake3WideVector, [Swag.U32.Max, 0, Swag.U32.Max, 0, Swag.U32.Max, 0, Swag.U32.Max, 0])
    const Pairs = cast(Blake3WideVector, [Swag.U32.Max, Swag.U32.Max, 0, 0, Swag.U32.Max, Swag.U32.Max, 0, 0])
    const Chunks = cast(Blake3WideVector, [Swag.U32.Max, Swag.U32.Max, Swag.U32.Max, Swag.U32.Max, 0, 0, 0, 0])
    const Low32 = cast(Blake3WideVector, [0'u32, 0, 1, 1, 4, 4, 5, 5])
    const High32 = cast(Blake3WideVector, [2'u32, 2, 3, 3, 6, 6, 7, 7])
    const Low64 = cast(Blake3WideVector, [0'u32, 1, 0, 1, 4, 5, 4, 5])
    const High64 = cast(Blake3WideVector, [2'u32, 3, 2, 3, 6, 7, 6, 7])
    const Low128 = cast(Blake3WideVector, [0'u32, 1, 2, 3, 0, 1, 2, 3])
    const High128 = cast(Blake3WideVector, [4'u32, 5, 6, 7, 4, 5, 6, 7])

    #[Swag.Mixin]
    func blend(left, right, indices, mask: Blake3WideVector)->Blake3WideVector
        => (Swag.vecShuffle(left, indices) & mask) | (Swag.vecShuffle(right, indices) & (All ^ mask))

    let p0 = blend(rows[][0], rows[][1], Low32, Alternating)
    let p1 = blend(rows[][0], rows[][1], High32, Alternating)
    let p2 = blend(rows[][2], rows[][3], Low32, Alternating)
    let p3 = blend(rows[][2], rows[][3], High32, Alternating)
    let p4 = blend(rows[][4], rows[][5], Low32, Alternating)
    let p5 = blend(rows[][4], rows[][5], High32, Alternating)
    let p6 = blend(rows[][6], rows[][7], Low32, Alternating)
    let p7 = blend(rows[][6], rows[][7], High32, Alternating)

    let q0 = blend(p0, p2, Low64, Pairs)
    let q1 = blend(p0, p2, High64, Pairs)
    let q2 = blend(p1, p3, Low64, Pairs)
    let q3 = blend(p1, p3, High64, Pairs)
    let q4 = blend(p4, p6, Low64, Pairs)
    let q5 = blend(p4, p6, High64, Pairs)
    let q6 = blend(p5, p7, Low64, Pairs)
    let q7 = blend(p5, p7, High64, Pairs)

    rows[][0] = blend(q0, q4, Low128, Chunks)
    rows[][1] = blend(q1, q5, Low128, Chunks)
    rows[][2] = blend(q2, q6, Low128, Chunks)
    rows[][3] = blend(q3, q7, Low128, Chunks)
    rows[][4] = blend(q0, q4, High128, Chunks)
    rows[][5] = blend(q1, q5, High128, Chunks)
    rows[][6] = blend(q2, q6, High128, Chunks)
    rows[][7] = blend(q3, q7, High128, Chunks)
}

// When the final block stays buffered, return the last lane's chaining value before it.
private func blake3EightChunkCvs(input: const [*] u8, firstChunk: u64, key: [8] u32, flags: u32, keepLastInput = false)->[Blake3ChunksPerBatch][8] u32
{
    // Each lane keeps one chunk's chaining value across all sixteen blocks.
    var cv: [8] Blake3WideVector
    #[Swag.Mixin]
    func broadcast(value: u32)->Blake3WideVector
    {
        var #uniq0: [8] u32
        for lane in 8 do
            #uniq0[lane] = value
        return cast(const *Blake3WideVector, &#uniq0)[]
    }

    for index in 8 do
        cv[index] = broadcast(key[index])

    var counterLow, counterHigh: [8] u32
    for lane in Blake3ChunksPerBatch
    {
        counterLow[lane]  = cast(u32, firstChunk + lane)
        counterHigh[lane] = cast(u32, (firstChunk + lane) >> 32)
    }

    let low       = cast(const *Blake3WideVector, &counterLow)[]
    let high      = cast(const *Blake3WideVector, &counterHigh)[]
    let blockSize = broadcast(Blake3BlockSize)
    for blockIndex in Blake3BlocksPerChunk
    {
        let base = input + blockIndex * Blake3BlockSize
        var message: [16] Blake3WideVector
        for group in 2
        {
            let bytes = base + group * #sizeof(Blake3WideVector)
            var rows: [8] Blake3WideVector
            for lane in Blake3ChunksPerBatch do
                rows[lane] = cast(const *Blake3WideVector, bytes + lane * Blake3ChunkSize)[]
            blake3TransposeWide(&rows)
            for lane in Blake3ChunksPerBatch do
                message[group * Blake3ChunksPerBatch + lane] = rows[lane]
        }

        var blockFlags = flags
        if blockIndex == 0 do
            blockFlags |= Blake3ChunkStart
        if blockIndex == Blake3BlocksPerChunk - 1 do
            blockFlags |= Blake3ChunkEnd
        // Keep the round state in separate vector locals so mixes can reuse registers.
        var a0 = cv[0]
        var a1 = cv[1]
        var a2 = cv[2]
        var a3 = cv[3]
        var b0 = cv[4]
        var b1 = cv[5]
        var b2 = cv[6]
        var b3 = cv[7]
        var c0 = broadcast(Blake3Iv[0])
        var c1 = broadcast(Blake3Iv[1])
        var c2 = broadcast(Blake3Iv[2])
        var c3 = broadcast(Blake3Iv[3])
        var d0 = low
        var d1 = high
        var d2 = blockSize
        var d3 = broadcast(blockFlags)

        #[Swag.Mixin]
        func(Bits: u64) rotateRight(value: Blake3WideVector)->Blake3WideVector => Swag.ror(value, cast(u8, Bits))

        #[Swag.Mixin]
        func mix(a, b, c, d: *Blake3WideVector, x, y: Blake3WideVector)
        {
            a[] += b[] + x
            d[] = rotateRight'16(d[] ^ a[])
            c[] += d[]
            b[] = rotateRight'12(b[] ^ c[])
            a[] += b[] + y
            d[] = rotateRight'8(d[] ^ a[])
            c[] += d[]
            b[] = rotateRight'7(b[] ^ c[])
        }

        #[Swag.Mixin]
        func(Round: u64) mixRound()
        {
            scope
            {
                const Schedule = Blake3MessageSchedule[Round]
                mix(&a0, &b0, &c0, &d0, message[Schedule[0]], message[Schedule[1]])
                mix(&a1, &b1, &c1, &d1, message[Schedule[2]], message[Schedule[3]])
                mix(&a2, &b2, &c2, &d2, message[Schedule[4]], message[Schedule[5]])
                mix(&a3, &b3, &c3, &d3, message[Schedule[6]], message[Schedule[7]])
                mix(&a0, &b1, &c2, &d3, message[Schedule[8]], message[Schedule[9]])
                mix(&a1, &b2, &c3, &d0, message[Schedule[10]], message[Schedule[11]])
                mix(&a2, &b3, &c0, &d1, message[Schedule[12]], message[Schedule[13]])
                mix(&a3, &b0, &c1, &d2, message[Schedule[14]], message[Schedule[15]])
            }
        }

        mixRound'0()
        mixRound'1()
        mixRound'2()
        mixRound'3()
        mixRound'4()
        mixRound'5()
        mixRound'6()
        var next: [8] Blake3WideVector = [a0 ^ c0, a1 ^ c1, a2 ^ c2, a3 ^ c3,
                                       b0 ^ d0, b1 ^ d1, b2 ^ d2, b3 ^ d3]
        if keepLastInput and blockIndex == Blake3BlocksPerChunk - 1
        {
            const RetainLast = cast(Blake3WideVector, [0'u32, 0, 0, 0, 0, 0, 0, Swag.U32.Max])
            const KeepNext = cast(Blake3WideVector, [Swag.U32.Max, Swag.U32.Max, Swag.U32.Max, Swag.U32.Max,
                                                    Swag.U32.Max, Swag.U32.Max, Swag.U32.Max, 0])
            for index in 8 do
                next[index] = (cv[index] & RetainLast) | (next[index] & KeepNext)
        }

        cv = next
    }

    var result: #returntype
    for word in Blake3WordsPerCv
    {
        let lanes = cast(const *[Blake3ChunksPerBatch] u32, &cv[word])[]
        result[0][word] = lanes[0]
        result[1][word] = lanes[1]
        result[2][word] = lanes[2]
        result[3][word] = lanes[3]
        result[4][word] = lanes[4]
        result[5][word] = lanes[5]
        result[6][word] = lanes[6]
        result[7][word] = lanes[7]
    }

    return result
}

#main
{
    var input: [8192] u8
    for index in input.count do
        input[index] = cast(u8, index % 251)
    let result = blake3EightChunkCvs(&input[0], 0, Blake3Iv, 0)
    Swag.require(result[0][0] == 0x44659e5c'u32, "chunk 0 word 0")
    Swag.require(result[0][1] == 0xd193e311'u32, "chunk 0 word 1")
    Swag.require(result[0][2] == 0x10c7bef4'u32, "chunk 0 word 2")
    Swag.require(result[0][3] == 0x56bcd5cc'u32, "chunk 0 word 3")
    Swag.require(result[0][4] == 0x7d17ab69'u32, "chunk 0 word 4")
    Swag.require(result[0][5] == 0xb60e0a61'u32, "chunk 0 word 5")
    Swag.require(result[0][6] == 0xe9fefc91'u32, "chunk 0 word 6")
    Swag.require(result[0][7] == 0xb1e8b42f'u32, "chunk 0 word 7")
    Swag.require(result[1][0] == 0xb8231f5b'u32, "chunk 1 word 0")
    Swag.require(result[1][1] == 0xa2680339'u32, "chunk 1 word 1")
    Swag.require(result[1][2] == 0x919550c1'u32, "chunk 1 word 2")
    Swag.require(result[1][3] == 0xb7d18903'u32, "chunk 1 word 3")
    Swag.require(result[1][4] == 0xa652eb16'u32, "chunk 1 word 4")
    Swag.require(result[1][5] == 0x0a4dd3df'u32, "chunk 1 word 5")
    Swag.require(result[1][6] == 0xa2226aa6'u32, "chunk 1 word 6")
    Swag.require(result[1][7] == 0xa71c761b'u32, "chunk 1 word 7")
    Swag.require(result[2][0] == 0xbe34af31'u32, "chunk 2 word 0")
    Swag.require(result[2][1] == 0xf7c0ab96'u32, "chunk 2 word 1")
    Swag.require(result[2][2] == 0x2b5c178f'u32, "chunk 2 word 2")
    Swag.require(result[2][3] == 0x5447f37a'u32, "chunk 2 word 3")
    Swag.require(result[2][4] == 0x161901a2'u32, "chunk 2 word 4")
    Swag.require(result[2][5] == 0x5843d3b9'u32, "chunk 2 word 5")
    Swag.require(result[2][6] == 0x6fd0742c'u32, "chunk 2 word 6")
    Swag.require(result[2][7] == 0xa83c1507'u32, "chunk 2 word 7")
    Swag.require(result[3][0] == 0x6f958423'u32, "chunk 3 word 0")
    Swag.require(result[3][1] == 0xd54c5c6c'u32, "chunk 3 word 1")
    Swag.require(result[3][2] == 0x111e7365'u32, "chunk 3 word 2")
    Swag.require(result[3][3] == 0x598cda3e'u32, "chunk 3 word 3")
    Swag.require(result[3][4] == 0x6e647424'u32, "chunk 3 word 4")
    Swag.require(result[3][5] == 0xd9b599b2'u32, "chunk 3 word 5")
    Swag.require(result[3][6] == 0x99687b0b'u32, "chunk 3 word 6")
    Swag.require(result[3][7] == 0x6e729b68'u32, "chunk 3 word 7")
    Swag.require(result[4][0] == 0x72994e62'u32, "chunk 4 word 0")
    Swag.require(result[4][1] == 0x3b34e325'u32, "chunk 4 word 1")
    Swag.require(result[4][2] == 0x4ab4ba77'u32, "chunk 4 word 2")
    Swag.require(result[4][3] == 0xf99b27d9'u32, "chunk 4 word 3")
    Swag.require(result[4][4] == 0xe1c88824'u32, "chunk 4 word 4")
    Swag.require(result[4][5] == 0x62a8b4b6'u32, "chunk 4 word 5")
    Swag.require(result[4][6] == 0x285b9efa'u32, "chunk 4 word 6")
    Swag.require(result[4][7] == 0x5eb7cbf9'u32, "chunk 4 word 7")
    Swag.require(result[5][0] == 0xbd174663'u32, "chunk 5 word 0")
    Swag.require(result[5][1] == 0x1cfa51bb'u32, "chunk 5 word 1")
    Swag.require(result[5][2] == 0xada921e3'u32, "chunk 5 word 2")
    Swag.require(result[5][3] == 0xdcd4c832'u32, "chunk 5 word 3")
    Swag.require(result[5][4] == 0x2198ff49'u32, "chunk 5 word 4")
    Swag.require(result[5][5] == 0x1d8b7dc7'u32, "chunk 5 word 5")
    Swag.require(result[5][6] == 0x240ff987'u32, "chunk 5 word 6")
    Swag.require(result[5][7] == 0x77b14679'u32, "chunk 5 word 7")
    Swag.require(result[6][0] == 0x42d9d344'u32, "chunk 6 word 0")
    Swag.require(result[6][1] == 0x12b009b1'u32, "chunk 6 word 1")
    Swag.require(result[6][2] == 0x9af87427'u32, "chunk 6 word 2")
    Swag.require(result[6][3] == 0xa879e2d9'u32, "chunk 6 word 3")
    Swag.require(result[6][4] == 0x8ca94134'u32, "chunk 6 word 4")
    Swag.require(result[6][5] == 0x6da059ae'u32, "chunk 6 word 5")
    Swag.require(result[6][6] == 0x9e4e13d9'u32, "chunk 6 word 6")
    Swag.require(result[6][7] == 0xf6324680'u32, "chunk 6 word 7")
    Swag.require(result[7][0] == 0x796044cc'u32, "chunk 7 word 0")
    Swag.require(result[7][1] == 0x25039898'u32, "chunk 7 word 1")
    Swag.require(result[7][2] == 0x630c71cd'u32, "chunk 7 word 2")
    Swag.require(result[7][3] == 0xd27c3d40'u32, "chunk 7 word 3")
    Swag.require(result[7][4] == 0x4b41146b'u32, "chunk 7 word 4")
    Swag.require(result[7][5] == 0x8f63d008'u32, "chunk 7 word 5")
    Swag.require(result[7][6] == 0x5b0c6324'u32, "chunk 7 word 6")
    Swag.require(result[7][7] == 0xb2b2cf3a'u32, "chunk 7 word 7")
}
